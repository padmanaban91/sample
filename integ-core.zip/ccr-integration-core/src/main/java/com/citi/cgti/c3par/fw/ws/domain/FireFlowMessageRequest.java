/**
 *  File Name       :   FireFlowMessageRequest.java  
 *  File Created on :   Sept 20, 2012   
 *  @Author         :   Vishy
 *  @version        :   1.0
 * --------------------------------------------------------------
 * Changed by       Date            Reason for change
 * --------------------------------------------------------------
 */

package com.citi.cgti.c3par.fw.ws.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="connectionId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="requestId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ffTicketId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ffSubTicketId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="workOrderId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="message" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RisksDetails" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InitialPlan" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WorkOrders" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "id",
    "type",
    "connectionId",
    "requestId",
    "ffTicketId",
    "ffSubTicketId",
    "workOrderId",
    "message",
    "risksDetails",
    "initialPlan",
    "workOrders"
})
@XmlRootElement(name = "FireFlowMessageRequest")
public class FireFlowMessageRequest implements Serializable 
{

    /**
	 * 
	 */
	private static final long serialVersionUID = -39812309725420083L;
	
	protected String id;
    protected String type;
    protected long connectionId;
    protected String requestId;
    protected String ffTicketId;
    protected String ffSubTicketId;
    protected String workOrderId;
    protected String message;
    @XmlElement(name = "RisksDetails")
    protected String risksDetails;
    @XmlElement(name = "InitialPlan")
    protected String initialPlan;
    @XmlElement(name = "WorkOrders")
    protected String workOrders;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the connectionId property.
     * 
     */
    public long getConnectionId() {
        return connectionId;
    }

    /**
     * Sets the value of the connectionId property.
     * 
     */
    public void setConnectionId(long value) {
        this.connectionId = value;
    }

    /**
     * Gets the value of the requestId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestId(String value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the ffTicketId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFfTicketId() {
        return ffTicketId;
    }

    /**
     * Sets the value of the ffTicketId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFfTicketId(String value) {
        this.ffTicketId = value;
    }

    /**
     * Gets the value of the ffSubTicketId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFfSubTicketId() {
        return ffSubTicketId;
    }

    /**
     * Sets the value of the ffSubTicketId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFfSubTicketId(String value) {
        this.ffSubTicketId = value;
    }

    /**
     * Gets the value of the workOrderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkOrderId() {
        return workOrderId;
    }

    /**
     * Sets the value of the workOrderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkOrderId(String value) {
        this.workOrderId = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the risksDetails property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRisksDetails() {
        return risksDetails;
    }

    /**
     * Sets the value of the risksDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRisksDetails(String value) {
        this.risksDetails = value;
    }

    /**
     * Gets the value of the initialPlan property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitialPlan() {
        return initialPlan;
    }

    /**
     * Sets the value of the initialPlan property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitialPlan(String value) {
        this.initialPlan = value;
    }

    /**
     * Gets the value of the workOrders property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkOrders() {
        return workOrders;
    }

    /**
     * Sets the value of the workOrders property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkOrders(String value) {
        this.workOrders = value;
    }
    
     
    @Override
    public String toString() {
    	return "id :: "+ getId()+
        " ; type :: "+ getType()+
        " ; connectionId :: "+getConnectionId()+
        " ; requestId :: "+getRequestId()+
        " ; ffTicketId :: "+getFfTicketId()+
        " ; ffSubTicketId :: "+getFfSubTicketId()+
        " ; workOrderId :: "+getWorkOrderId()+
        " ; message :: "+getMessage()+
        " ; RisksDetails :: "+getRisksDetails()+
        " ; InitialPlan :: "+getInitialPlan()+
        " ; WorkOrders :: "+getWorkOrders();
	}
}
