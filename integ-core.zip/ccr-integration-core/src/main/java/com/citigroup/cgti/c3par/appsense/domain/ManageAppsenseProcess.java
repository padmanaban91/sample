package com.citigroup.cgti.c3par.appsense.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.proxy.domain.ProxyFilter;
import com.citigroup.cgti.c3par.proxy.domain.ProxyInstance;
import com.citigroup.cgti.c3par.proxy.domain.ProxyProcess;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * The Class AppsenseProcess.
 */
public class ManageAppsenseProcess {

	
    CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	} 
	/** The black listed apps list. */
	private List<LookUpVO> blackListedAppsList = null;

	private String[] blackAppList;
	
	private String[] pathVarA;
	
	private String[] pathvarb;
	
	private String[] userList;
	
	private String[] proxyList;
	
	private List<GenericLookup> ostiaList;

	/** The appsense application list. */
	private List<AppsenseApplication> appsenseApplicationList = null;

	/** The appsense user list. */
	private List<AppsenseUser> appsenseUserList = null;

	/** The aps process. */
	private AppsenseDTO apsProcess = new AppsenseDTO();

	/** The appsense application. */
	private AppsenseApplication appsenseApplication = new AppsenseApplication();

	/** The appsense ostia list. */
	private List<AppsenseApplication> appsenseOstiaList = null;

	/** The appsense user. */
	private AppsenseUser appsenseUser = new AppsenseUser();
	
	private boolean isSelectAll;

	/** The apps ad group name. */
	private String appsADGroupName;

	/** The apps ad group status. */
	private String appsADGroupStatus;

	/** The apps adSearchDisabled. */
	private boolean adSearchDisabled;

	/** The appsense ad group name list. */
	private List<AppsenseADGroup> appsenseADGroupNameList = null;

	/** The apps policy id. */
	private String appsPolicyId;

	/** The apps policy name. */
	private String appsPolicyName;

	/** The apps policy status. */
	private String appsPolicyStatus;

	/** The apps policy master id. */
	private Long appsPolicyMasterId;

	/** The appsense upload excel form file. */
	private CommonsMultipartFile appsenseUploadExcelFormFile;

	/** The appsense aaf combination. */
	private AppsenseAAFCombination appsenseAAFCombination = new AppsenseAAFCombination();

	private int rowCount;
    private int offset;
    private int limit;
    private int pageNo;
    private int totalPages;

	/** The proxy process. */
	private ProxyProcess proxyProcess=new ProxyProcess();

	/** The ti request entity. */
	private TIRequest tirequest;

	/** The risk port list. */
	private List<LookUpVO> riskPortList = null;

	/** The appsense policy name. */
	private String appsensePolicyName;

	/** The resource type. */
	private String resourceType;

	/** The relationship type. */
	private String relationshipType;

	/** The total appsense apps. */
	private int totalAppsenseApps;

	/** The total appsense users. */
	private int totalAppsenseUsers;
	
	/** The proxy filter list. */
	private List<ProxyFilter> proxyFilterList =null ;
	
	/** The first name. */
	private	String	firstName;

	/** The last name. */
	private	String	lastName;

	/** The email. */
	private	String	email;

	/** The sso id. */
	private	String	ssoId;
	
	/** The proxy filter. */
	private ProxyFilter proxyFilter=null;
	
	/** The ip resource id. */
	private Long ipResourceId;
	
	/** The review. */
	boolean review;
	
	/** The proxy instance list. */
	private List<ProxyInstance> proxyInstanceList=null;

	/** The connection ostia group. */
	private ConnectionOstiaGroup connectionOstiaGroup = new ConnectionOstiaGroup();
	
	private CommonsMultipartFile usersUploadExcelFormFile;
	
	public List<AppsenseApplication> getAppsenseOstiaList() {
		return appsenseOstiaList;
	}

	public void setAppsenseOstiaList(List<AppsenseApplication> appsenseOstiaList) {
		this.appsenseOstiaList = appsenseOstiaList;
	}

	public CommonsMultipartFile getAppsenseUploadExcelFormFile() {
		return appsenseUploadExcelFormFile;
	}

	public void setAppsenseUploadExcelFormFile(
			CommonsMultipartFile appsenseUploadExcelFormFile) {
		this.appsenseUploadExcelFormFile = appsenseUploadExcelFormFile;
	}

	public List<LookUpVO> getBlackListedAppsList() {
		return blackListedAppsList;
	}

	public void setBlackListedAppsList(List<LookUpVO> blackListedAppsList) {
		this.blackListedAppsList = blackListedAppsList;
	}

	public String[] getBlackAppList() {
		return blackAppList;
	}

	public void setBlackAppList(String[] blackAppList) {
		this.blackAppList = blackAppList;
	}

	public String[] getPathVarA() {
		return pathVarA;
	}

	public void setPathVarA(String[] pathVarA) {
		this.pathVarA = pathVarA;
	}

	public String[] getPathvarb() {
		return pathvarb;
	}

	public void setPathvarb(String[] pathvarb) {
		this.pathvarb = pathvarb;
	}

	public String[] getUserList() {
		return userList;
	}

	public void setUserList(String[] userList) {
		this.userList = userList;
	}

	public String[] getProxyList() {
		return proxyList;
	}

	public void setProxyList(String[] proxyList) {
		this.proxyList = proxyList;
	}
	

	public List<GenericLookup> getOstiaList() {
		return ostiaList;
	}

	public void setOstiaList(List<GenericLookup> ostiaList) {
		this.ostiaList = ostiaList;
	}

	public List<AppsenseApplication> getAppsenseApplicationList() {
		return appsenseApplicationList;
	}

	public void setAppsenseApplicationList(
			List<AppsenseApplication> appsenseApplicationList) {
		this.appsenseApplicationList = appsenseApplicationList;
	}

	public List<AppsenseUser> getAppsenseUserList() {
		return appsenseUserList;
	}

	public void setAppsenseUserList(List<AppsenseUser> appsenseUserList) {
		this.appsenseUserList = appsenseUserList;
	}

	public AppsenseDTO getApsProcess() {
		return apsProcess;
	}

	public void setApsProcess(AppsenseDTO apsProcess) {
		this.apsProcess = apsProcess;
	}

	public AppsenseApplication getAppsenseApplication() {
		return appsenseApplication;
	}

	public void setAppsenseApplication(AppsenseApplication appsenseApplication) {
		this.appsenseApplication = appsenseApplication;
	}

	

	public AppsenseUser getAppsenseUser() {
		return appsenseUser;
	}

	public void setAppsenseUser(AppsenseUser appsenseUser) {
		this.appsenseUser = appsenseUser;
	}


	public boolean isSelectAll() {
		return isSelectAll;
	}

	public void setSelectAll(boolean isSelectAll) {
		this.isSelectAll = isSelectAll;
	}

	public String getAppsADGroupName() {
		return appsADGroupName;
	}

	public void setAppsADGroupName(String appsADGroupName) {
		this.appsADGroupName = appsADGroupName;
	}

	public String getAppsADGroupStatus() {
		return appsADGroupStatus;
	}

	public void setAppsADGroupStatus(String appsADGroupStatus) {
		this.appsADGroupStatus = appsADGroupStatus;
	}

	public boolean isAdSearchDisabled() {
		return adSearchDisabled;
	}

	public void setAdSearchDisabled(boolean adSearchDisabled) {
		this.adSearchDisabled = adSearchDisabled;
	}

	public List<AppsenseADGroup> getAppsenseADGroupNameList() {
		return appsenseADGroupNameList;
	}

	public void setAppsenseADGroupNameList(
			List<AppsenseADGroup> appsenseADGroupNameList) {
		this.appsenseADGroupNameList = appsenseADGroupNameList;
	}

	public String getAppsPolicyId() {
		return appsPolicyId;
	}

	public void setAppsPolicyId(String appsPolicyId) {
		this.appsPolicyId = appsPolicyId;
	}

	public String getAppsPolicyName() {
		return appsPolicyName;
	}

	public void setAppsPolicyName(String appsPolicyName) {
		this.appsPolicyName = appsPolicyName;
	}

	public String getAppsPolicyStatus() {
		return appsPolicyStatus;
	}

	public void setAppsPolicyStatus(String appsPolicyStatus) {
		this.appsPolicyStatus = appsPolicyStatus;
	}

	public Long getAppsPolicyMasterId() {
		return appsPolicyMasterId;
	}

	public void setAppsPolicyMasterId(Long appsPolicyMasterId) {
		this.appsPolicyMasterId = appsPolicyMasterId;
	}

	

	public AppsenseAAFCombination getAppsenseAAFCombination() {
		return appsenseAAFCombination;
	}

	public void setAppsenseAAFCombination(
			AppsenseAAFCombination appsenseAAFCombination) {
		this.appsenseAAFCombination = appsenseAAFCombination;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public ProxyProcess getProxyProcess() {
		return proxyProcess;
	}

	public void setProxyProcess(ProxyProcess proxyProcess) {
		this.proxyProcess = proxyProcess;
	}

	public TIRequest getTirequest() {
		return tirequest;
	}

	public void setTirequest(TIRequest tirequest) {
		this.tirequest = tirequest;
	}

	public List<LookUpVO> getRiskPortList() {
		return riskPortList;
	}

	public void setRiskPortList(List<LookUpVO> riskPortList) {
		this.riskPortList = riskPortList;
	}

	public String getAppsensePolicyName() {
		return appsensePolicyName;
	}

	public void setAppsensePolicyName(String appsensePolicyName) {
		this.appsensePolicyName = appsensePolicyName;
	}

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	public String getRelationshipType() {
		return relationshipType;
	}

	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

	public int getTotalAppsenseApps() {
		return totalAppsenseApps;
	}

	public void setTotalAppsenseApps(int totalAppsenseApps) {
		this.totalAppsenseApps = totalAppsenseApps;
	}

	public int getTotalAppsenseUsers() {
		return totalAppsenseUsers;
	}

	public void setTotalAppsenseUsers(int totalAppsenseUsers) {
		this.totalAppsenseUsers = totalAppsenseUsers;
	}

	public List<ProxyFilter> getProxyFilterList() {
		return proxyFilterList;
	}

	public void setProxyFilterList(List<ProxyFilter> proxyFilterList) {
		this.proxyFilterList = proxyFilterList;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSsoId() {
		return ssoId;
	}

	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	public ProxyFilter getProxyFilter() {
		return proxyFilter;
	}

	public void setProxyFilter(ProxyFilter proxyFilter) {
		this.proxyFilter = proxyFilter;
	}

	public Long getIpResourceId() {
		return ipResourceId;
	}

	public void setIpResourceId(Long ipResourceId) {
		this.ipResourceId = ipResourceId;
	}

	public boolean isReview() {
		return review;
	}

	public void setReview(boolean review) {
		this.review = review;
	}

	public List<ProxyInstance> getProxyInstanceList() {
		return proxyInstanceList;
	}

	public void setProxyInstanceList(List<ProxyInstance> proxyInstanceList) {
		this.proxyInstanceList = proxyInstanceList;
	}

	public ConnectionOstiaGroup getConnectionOstiaGroup() {
		return connectionOstiaGroup;
	}

	public void setConnectionOstiaGroup(ConnectionOstiaGroup connectionOstiaGroup) {
		this.connectionOstiaGroup = connectionOstiaGroup;
	}

	public CommonsMultipartFile getUsersUploadExcelFormFile() {
		return usersUploadExcelFormFile;
	}

	public void setUsersUploadExcelFormFile(
			CommonsMultipartFile usersUploadExcelFormFile) {
		this.usersUploadExcelFormFile = usersUploadExcelFormFile;
	}

	
	public AppsenseDTO getAppsenseProcess(long processId) {
		return ccrBeanFactory.getManageAppsensePersistable().getAppsenseProcess(processId);
	}

	
	public List<AppsenseApplication> loadAppsenseApplications(AppsenseDTO apsProcess, ManageAppsenseProcess manageAppsenseProcess) {
		return ccrBeanFactory.getManageAppsensePersistable().loadAppsenseApplications(apsProcess,
				manageAppsenseProcess);
	}

	
	public List<AppsenseUser> loadAppsenseUsers(AppsenseDTO apsProcess, ManageAppsenseProcess manageAppsenseProcess) {
		return ccrBeanFactory.getManageAppsensePersistable()
				.loadAppsenseUsers(apsProcess, manageAppsenseProcess);
	}

	
	public List<AppsenseApplication> loadAppsenseApplications(AppsenseDTO apsProcess, int pageNum,
			int pageSize) {
		return ccrBeanFactory.getManageAppsensePersistable().loadAppsenseApplications(apsProcess,
				pageNum, pageSize);
	}

	
	public List<AppsenseApplication> loadAppsenseOstiaApplications(AppsenseDTO apsProcess,
			ManageAppsenseProcess manageAppsenseProcess) {
		return ccrBeanFactory.getManageAppsensePersistable().loadAppsenseOstiaApplications(
				apsProcess, manageAppsenseProcess);
	}

	
	public List<AppsenseApplication> getAppsenseOstiaPortList(AppsenseDTO apsProcess) {
		return ccrBeanFactory.getManageAppsensePersistable().getAppsenseOstiaPortList(apsProcess);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void storeAppsenseApplication(AppsenseApplication appsenseApplication) {
		ccrBeanFactory.getManageAppsensePersistable().storeAppsenseApplication(appsenseApplication);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void storeAppsenseUser(AppsenseUser appsenseUser) {
		ccrBeanFactory.getManageAppsensePersistable().storeAppsenseUser(appsenseUser);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteAppsenseApplication(AppsenseDTO apsProcess) {
		ccrBeanFactory.getManageAppsensePersistable().deleteAppsenseApplication(apsProcess);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteAppsenseUser(AppsenseDTO apsProcess) {
		ccrBeanFactory.getManageAppsensePersistable().deleteAppsenseUser(apsProcess);
	}

	
	public AppsenseAAFCombination getApsNonNetworkCombination(Long processID,
			Long versionID, Long combType, Long fafType) {
		return ccrBeanFactory.getManageAppsensePersistable().getApsNonNetworkCombination(processID,
				versionID, combType, fafType);
	}


	
	public AppsenseAAFCombination getApsUserCombination(Long processID,
			Long versionID, Long combType, Long fafType) {
		return ccrBeanFactory.getManageAppsensePersistable().getApsUserCombination(processID,
				versionID, combType, fafType);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public AppsenseADGroup storeAppsADGroup(AppsenseADGroup appsenseADGroup) {
		return ccrBeanFactory.getManageAppsensePersistable().storeAppsADGroup(appsenseADGroup);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public AppsenseADGroup updateAppsADGroup(AppsenseADGroup appsenseADGroup) {
		return ccrBeanFactory.getManageAppsensePersistable().updateAppsADGroup(appsenseADGroup);
	}
	
	
	 public TIProcess getTIProcess(long tiRequestId){
		return ccrBeanFactory.getManageAppsensePersistable().getTIProcess(tiRequestId);
	 }
	
	
	public TIRequest getTIRequest(long tiRequestId){
		return ccrBeanFactory.getManageAppsensePersistable().getTIRequest(tiRequestId);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List<ProxyFilter> loadProxyFilters(ProxyProcess prxProcess,int pageNum,int pageSize){
		return ccrBeanFactory.getProxyPersistable().loadProxyFilters(prxProcess, pageSize);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	 public void storeProxyFilter(ProxyFilter proxyFilter){
		ccrBeanFactory.getProxyPersistable().storeProxyFilter(proxyFilter);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteProxyFilter(ProxyProcess prxProcess){
		ccrBeanFactory.getProxyPersistable().deleteProxyFilter(prxProcess);
	}
	
	
	public ProxyProcess getProxyProcess(long processId){
		return ccrBeanFactory.getProxyPersistable().getProxyProcess(processId);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List<ProxyFilter> loadProxyFilters(ManageAppsenseProcess manageAppsenseProcess){
		return ccrBeanFactory.getProxyPersistable().loadProxyFiltersAppsense(manageAppsenseProcess);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	 public Application storeApplication(Application application){
		 return ccrBeanFactory.getProxyPersistable().storeApplication(application);
	 }
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	 public void updateProxyFilter(ProxyProcess prxProcess,Application application){
		ccrBeanFactory.getProxyPersistable().updateProxyFilter(prxProcess,application);
	 }
	
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public AppsenseDTO addOstiaAnswers(AppsenseDTO apsProcess,Long groupId){
			return ccrBeanFactory.getManageAppsensePersistable().addOstiaAnswers(apsProcess,groupId);
	 }
	
	
	 public ConnectionOstiaGroup getOstiaGroup(Long ostiaGroupId){
		 return ccrBeanFactory.getManageAppsensePersistable().getOstiaGroup(ostiaGroupId);
	 }
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public AppsenseDTO updateOstiaGroup(AppsenseDTO appsenseProcess,ConnectionOstiaGroup conOstiaGroup){
		 return ccrBeanFactory.getManageAppsensePersistable().updateOstiaGroup(appsenseProcess,conOstiaGroup);
	 }
	
	
	public List<GenericLookup> getDeviceTypes(){
		 return ccrBeanFactory.getManageAppsensePersistable().getDeviceTypes();
	 }
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	 public Long saveConOstiaGroup(ConnectionOstiaGroup conOstiaGroup){
		  return ccrBeanFactory.getManageAppsensePersistable().saveConOstiaGroup(conOstiaGroup);
	 }
	
	
	public String getAppsenseAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID) {
		return ccrBeanFactory.getAccessFormText().getAppsenseAccessFormText(tiRequestId, connectionRequestId, versionID);
	}
	
	
	public String getAllAppsenseAccessFormText(Long tiRequestId, Long connectionRequestId) {
		return ccrBeanFactory.getAccessFormText().getAllAppsenseAccessFormText(tiRequestId, connectionRequestId);
	}
	
}


