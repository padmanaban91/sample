/**
 *
 */
package com.citigroup.cgti.c3par.common.domain;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;

import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.domain.Base;

/**
 * @author nc43495
 * 
 */
public class AuditObjectType extends Base {
	@Autowired
	private CommonServicePersistable commonServicePersistable;

	/** The log. */
	private static Logger log = Logger.getLogger(AuditObjectType.class);
	
	/** The Object Type id */
	private Long id;
	
	/** The Object Name */
	private String objectName;
	
	/** The Object Name History */
	private String objectNameHistory;
	
	/** The Display name */
	private String displayName;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getObjectNameHistory() {
		return objectNameHistory;
	}

	public void setObjectNameHistory(String objectNameHistory) {
		this.objectNameHistory = objectNameHistory;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
	
	
}
