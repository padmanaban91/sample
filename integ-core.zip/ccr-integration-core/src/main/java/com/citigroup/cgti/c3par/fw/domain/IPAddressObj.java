package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;

public class IPAddressObj extends Base {

    /**
     * 
     */
    
    private static final long serialVersionUID = 1L;

    private String ipAddress;

	public IPAddressObj() {
		setCreated_date(new Date());
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipObjectName) {
		this.ipAddress = ipObjectName;
	}

   
}
