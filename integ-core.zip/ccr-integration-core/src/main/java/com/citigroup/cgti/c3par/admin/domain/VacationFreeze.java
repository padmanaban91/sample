package com.citigroup.cgti.c3par.admin.domain;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.domain.Base;

public class VacationFreeze extends Base {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	
	private FirewallLocation fwLoc;
	
	private Date fromDate;
	
	private Date toDate;
	
	private String loadAvailable;
	
	private String updatedBy;
	
	private String updatedDateDisplay;
	
	private String fromDateDisplay;
	
	private String toDateDisplay;
	
	private String createdBy;
	
	
	public String getToDateDisplay() {
		if(getToDate() !=null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			return dateformat.format(getToDate());
		}
		return toDateDisplay;
	}

	public void setToDateDisplay(String toDateDisplay) {
		this.toDateDisplay = toDateDisplay;
	}

	public String getFromDateDisplay() {
		if(getFromDate() !=null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			return dateformat.format(getFromDate());
		}
		return fromDateDisplay;
	}

	public void setFromDateDisplay(String fromDateDisplay) {
		this.fromDateDisplay = fromDateDisplay;
	}

	public String getUpdatedDateDisplay() {
		if(getUpdated_date() != null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			return dateformat.format(getUpdated_date());
		}
		
		return updatedDateDisplay;
	}

	public void setUpdatedDateDisplay(String updatedDateDisplay) {
		this.updatedDateDisplay = updatedDateDisplay;
	}

	
	public Date getFromDate() {
		
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	
	
	public FirewallLocation getFwLoc() {
		return fwLoc;
	}

	public void setFwLoc(FirewallLocation fwLoc) {
		this.fwLoc = fwLoc;
	}

	private String uploadedBy;

	public String getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	

	public String getLoadAvailable() {
		return loadAvailable;
	}

	public void setLoadAvailable(String loadAvailable) {
		this.loadAvailable = loadAvailable;
	}
	

	
}
