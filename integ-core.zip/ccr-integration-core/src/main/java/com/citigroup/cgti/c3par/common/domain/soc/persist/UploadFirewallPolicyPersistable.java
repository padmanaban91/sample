package com.citigroup.cgti.c3par.common.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface UploadFirewallPolicyPersistable extends Persistable {

	void uploadFirewallStageData(List resultList);

	List executeSQL(String sql);

	List<FirewallPolicy> searchFireWall(String fireWallNameSearch,
			String fireWallTypeSearch, String managementRegionSearch);

}
