package com.citigroup.cgti.c3par.domain;


/**
 * The Class Role.
 */
public class Role extends Base {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
    private String displayName;
    private String citi;
    private String priempType;
    private String secempType;
    private String iscontact;
    private String name;
    
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getDisplayName() {
		return displayName;
	}
	
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
	public String getCiti() {
		return citi;
	}
	
	public void setCiti(String citi) {
		this.citi = citi;
	}
	
	public String getPriempType() {
		return priempType;
	}
	
	public void setPriempType(String priempType) {
		this.priempType = priempType;
	}
	
	public String getSecempType() {
		return secempType;
	}
	
	public void setSecempType(String secempType) {
		this.secempType = secempType;
	}
	
	public String getIscontact() {
		return iscontact;
	}
	
	public void setIscontact(String iscontact) {
		this.iscontact = iscontact;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
        
}
