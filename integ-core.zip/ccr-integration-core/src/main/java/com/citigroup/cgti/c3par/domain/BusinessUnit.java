package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;


/**
 * The Class BusinessUnit.
 */
@XmlType(name="BusinessUnitEntity")
public class BusinessUnit extends Name implements Serializable {

    /** The cost center. */
    private CostCenter costCenter =new CostCenter();

    /**
     * Gets the cost center.
     *
     * @return Returns the costCenter.
     */
    public CostCenter getCostCenter() {
	return costCenter;
    }

    /**
     * Sets the cost center.
     *
     * @param costCenter The costCenter to set.
     */
    public void setCostCenter(CostCenter costCenter) {
	this.costCenter = costCenter;
    }
}
