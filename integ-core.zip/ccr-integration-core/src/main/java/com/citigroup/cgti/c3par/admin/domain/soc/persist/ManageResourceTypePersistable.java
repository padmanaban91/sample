package com.citigroup.cgti.c3par.admin.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.common.domain.ProxyDeviceName;
import com.citigroup.cgti.c3par.common.domain.ProxyLocation;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface ManageResourceTypePersistable extends Persistable{
	
		//get ResourceType
		public List<ResourceType> getResourceType();
		//add ResourceType 
		public void addResourceType(ResourceType resourceType,String userID);
		//update ResourceType
		public void updateResourceType(String id,String status,String userID);
		
		List<ProxyDeviceName> getProxyDeviceNames();
		
		List<ProxyLocation> getProxyLocations();
		
		boolean updateProxyDeviceName(ProxyDeviceName proxyDeviceName);
		
		ProxyDeviceName loadProxyDeviceName(Long id);
		
		void deleteProxyDeviceName(Long id);

}
