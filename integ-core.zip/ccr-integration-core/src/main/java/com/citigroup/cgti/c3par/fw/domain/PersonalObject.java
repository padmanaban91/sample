/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

/**
 * 
 * @author ne36745
 *
 */
public class PersonalObject extends Base {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
   
    private String objectName;
    
    private String isDeleted;
    
    private C3parUser createdBy;
    
    private C3parUser updatedBy;
    
    private String type;
    
    private List<PersonalObjectIP> personalObjectIPs;
    
    private List<PersonalObjectPort> personalObjectPorts;
    
    private List<String> validationErrors;

    private String created_date_display;

    private String updated_date_display;

	public PersonalObject() {
		setCreated_date(new Date());
	}

	/**
	 * @return the objectName
	 */
	public String getObjectName() {
		return objectName;
	}

	/**
	 * @param objectName the objectName to set
	 */
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	/**
	 * @return the isDeleted
	 */
	public String getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the createdBy
	 */
	public C3parUser getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(C3parUser createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public C3parUser getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(C3parUser updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the personalObjectIPs
	 */
	public List<PersonalObjectIP> getPersonalObjectIPs() {
		return personalObjectIPs;
	}

	/**
	 * @param personalObjectIPs the personalObjectIPs to set
	 */
	public void setPersonalObjectIPs(List<PersonalObjectIP> personalObjectIPs) {
		this.personalObjectIPs = personalObjectIPs;
	}

	/**
	 * @return the personalObjectPorts
	 */
	public List<PersonalObjectPort> getPersonalObjectPorts() {
		return personalObjectPorts;
	}

	/**
	 * @param personalObjectPorts the personalObjectPorts to set
	 */
	public void setPersonalObjectPorts(List<PersonalObjectPort> personalObjectPorts) {
		this.personalObjectPorts = personalObjectPorts;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the validationErrors
	 */
	public List<String> getValidationErrors() {
		return validationErrors;
	}

	/**
	 * @param validationErrors the validationErrors to set
	 */
	public void setValidationErrors(List<String> validationErrors) {
		this.validationErrors = validationErrors;
	}

    public String getCreated_date_display() {
		if(getCreated_date() != null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			return dateformat.format(getCreated_date());
		}
		return created_date_display;
	}

	public void setCreated_date_display(String created_date_display) {
		this.created_date_display = created_date_display;
	}

	public String getUpdated_date_display() {
		if( getUpdated_date() != null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			return dateformat.format( getUpdated_date());
		}
		return updated_date_display;
	}

	public void setUpdated_date_display(String updated_date_display) {
		this.updated_date_display = updated_date_display;
	}	
}
