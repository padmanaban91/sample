package com.citigroup.cgti.c3par.connection.domain;

import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionVIPXref.
 */
public class ConnectionVIPXref extends PerformerPagerDO {

    /** The con vip master. */
    ConnectionVIPMaster conVIPMaster;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /** The nat ip. */
    private String natIp;


    /**
     * Instantiates a new connection vip xref.
     */
    public ConnectionVIPXref() {

	//---------------------
	setTableName(PerformerTypes.CONN_VIRTUAL_IP_XREF_TABEL);
	setSequenceName(PerformerTypes.CONN_VIRTUAL_IP_XREF_SEQ);
	//---------------------
	addToDBMapping("conVIPMaster","virtual_ip_id",1);
	addToDBMapping("created_date","created_date",2);
	addToDBMapping("updated_date","updated_date",3);
	addToDBMapping("natIp","nat_ip",4);
	//----------------------
	addToNonCompositionList("conVIPMaster");
	//----------------------
	addToParentsMap("com.citigroup.cgti.c3par.connection.domain.ConnectionIPXref" , "ip_xref_id");
	//----------------------
    }


    /**
     * Gets the con vip master.
     *
     * @return the con vip master
     */
    public ConnectionVIPMaster getConVIPMaster() {
	return conVIPMaster;
    }

    /**
     * Sets the con vip master.
     *
     * @param conVIPMaster the new con vip master
     */
    public void setConVIPMaster(ConnectionVIPMaster conVIPMaster) {
	this.conVIPMaster = conVIPMaster;
    }



    /**
     * Gets the created_date.
     *
     * @return Returns the created_date.
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date The created_date to set.
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return Returns the updated_date.
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date The updated_date to set.
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }


    /**
     * Gets the nat ip.
     *
     * @return the nat ip
     */
    public String getNatIp() {
	return natIp;
    }


    /**
     * Sets the nat ip.
     *
     * @param natIp the new nat ip
     */
    public void setNatIp(String natIp) {
	this.natIp = natIp;
    }
}
