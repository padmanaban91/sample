


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.ip.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.ip.model.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;

// Reference imports
import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.*;


// Entity name = IPRegDetailDAO
// Table name = IP_REG_DETAIL
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class IPRegDetailDAO.
 */
public class IPRegDetailDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "IP_REG_DETAIL";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(IPRegDetailDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "IPRegDetail";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_UPDATEDDATE. */
    public static final String	COLUMN_UPDATEDDATE = "UPDATED_DATE";

    /** The Constant COLUMN_SOURCESTARTIP. */
    public static final String	COLUMN_SOURCESTARTIP = "SOURCE_START_IP";

    /** The Constant COLUMN_SOURCESTARTIP_LEN. */
    public static final int		COLUMN_SOURCESTARTIP_LEN = 1000;

    /** The Constant COLUMN_SOURCESUBNETMASK. */
    public static final String	COLUMN_SOURCESUBNETMASK = "SOURCE_SUBNET_MASK";

    /** The Constant COLUMN_SOURCESUBNETMASK_LEN. */
    public static final int		COLUMN_SOURCESUBNETMASK_LEN = 1000;

    /** The Constant COLUMN_DESTINATIONIP. */
    public static final String	COLUMN_DESTINATIONIP = "DESTINATION_IP";

    /** The Constant COLUMN_DESTINATIONIP_LEN. */
    public static final int		COLUMN_DESTINATIONIP_LEN = 100;

    /** The Constant COLUMN_NETINFOID. */
    public static final String	COLUMN_NETINFOID = "NET_INFO_ID";

    /** The Constant COLUMN_NETINFOID_LEN. */
    public static final int		COLUMN_NETINFOID_LEN = 1000;

    /** The Constant COLUMN_DSN. */
    public static final String	COLUMN_DSN = "DSN";

    /** The Constant COLUMN_DSN_LEN. */
    public static final int		COLUMN_DSN_LEN = 1000;

    /** The Constant COLUMN_SOURCEUSERTYPE. */
    public static final String	COLUMN_SOURCEUSERTYPE = "SOURCE_USER_TYPE";

    /** The Constant COLUMN_SOURCEUSERTYPE_LEN. */
    public static final int		COLUMN_SOURCEUSERTYPE_LEN = 1000;

    /** The Constant COLUMN_SOURCEACCESSTYPE. */
    public static final String	COLUMN_SOURCEACCESSTYPE = "SOURCE_ACCESS_TYPE";

    /** The Constant COLUMN_SOURCEACCESSTYPE_LEN. */
    public static final int		COLUMN_SOURCEACCESSTYPE_LEN = 1000;

    /** The Constant COLUMN_SOURCECONNECTIONTYPE. */
    public static final String	COLUMN_SOURCECONNECTIONTYPE = "SOURCE_CONNECTION_TYPE";

    /** The Constant COLUMN_SOURCECONNECTIONTYPE_LEN. */
    public static final int		COLUMN_SOURCECONNECTIONTYPE_LEN = 1000;

    /** The Constant COLUMN_SOURCEACL. */
    public static final String	COLUMN_SOURCEACL = "SOURCE_ACL";

    /** The Constant COLUMN_SOURCEACL_LEN. */
    public static final int		COLUMN_SOURCEACL_LEN = 1000;

    /** The Constant COLUMN_DESTINATIONENDIP. */
    public static final String	COLUMN_DESTINATIONENDIP = "DESTINATION_END_IP";

    /** The Constant COLUMN_DESTINATIONENDIP_LEN. */
    public static final int		COLUMN_DESTINATIONENDIP_LEN = 100;

    /** The Constant COLUMN_DESTINATIONIPTYPE. */
    public static final String	COLUMN_DESTINATIONIPTYPE = "DESTINATION_IP_TYPE";

    /** The Constant COLUMN_DESTINATIONIPTYPE_LEN. */
    public static final int		COLUMN_DESTINATIONIPTYPE_LEN = 25;

    /** The Constant COLUMN_ISMANUALASSIGNEDACL. */
    public static final String	COLUMN_ISMANUALASSIGNEDACL = "IS_MANUAL_ASSIGNED_ACL";

    /** The Constant COLUMN_ISMANUALASSIGNEDACL_LEN. */
    public static final int		COLUMN_ISMANUALASSIGNEDACL_LEN = 1;
    // Column names of references
    /** The Constant COLUMN_IPREGISTRATION_ID. */
    public static final String	COLUMN_IPREGISTRATION_ID = "IP_REGISTRATION_ID";

    /** The Constant COLUMN_PROCESSSTATUS_ID. */
    public static final String	COLUMN_PROCESSSTATUS_ID = "PROCESS_STATUS_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_UPDATEDDATE
    + ", " + COLUMN_SOURCESTARTIP
    + ", " + COLUMN_SOURCESUBNETMASK
    + ", " + COLUMN_DESTINATIONIP
    + ", " + COLUMN_NETINFOID
    + ", " + COLUMN_DSN
    + ", " + COLUMN_SOURCEUSERTYPE
    + ", " + COLUMN_SOURCEACCESSTYPE
    + ", " + COLUMN_SOURCECONNECTIONTYPE
    + ", " + COLUMN_SOURCEACL
    + ", " + COLUMN_DESTINATIONENDIP
    + ", " + COLUMN_DESTINATIONIPTYPE
    + ", " + COLUMN_ISMANUALASSIGNEDACL
    + ", " + COLUMN_IPREGISTRATION_ID
    + ", " + COLUMN_PROCESSSTATUS_ID
    + " FROM " + IPRegDetailDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = IPRegDetailDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + IPRegDetailDAO.TABLE + " SET "
    + COLUMN_UPDATEDDATE + " = ? "
    + ", " + COLUMN_SOURCESTARTIP + " = ? "
    + ", " + COLUMN_SOURCESUBNETMASK + " = ? "
    + ", " + COLUMN_DESTINATIONIP + " = ? "
    + ", " + COLUMN_NETINFOID + " = ? "
    + ", " + COLUMN_DSN + " = ? "
    + ", " + COLUMN_SOURCEUSERTYPE + " = ? "
    + ", " + COLUMN_SOURCEACCESSTYPE + " = ? "
    + ", " + COLUMN_SOURCECONNECTIONTYPE + " = ? "
    + ", " + COLUMN_SOURCEACL + " = ? "
    + ", " + COLUMN_DESTINATIONENDIP + " = ? "
    + ", " + COLUMN_DESTINATIONIPTYPE + " = ? "
    + ", " + COLUMN_ISMANUALASSIGNEDACL + " = ? "
    + ", " + COLUMN_IPREGISTRATION_ID + " = ? "
    + ", " + COLUMN_PROCESSSTATUS_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + IPRegDetailDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_UPDATEDDATE 
    + ", " + COLUMN_SOURCESTARTIP 
    + ", " + COLUMN_SOURCESUBNETMASK 
    + ", " + COLUMN_DESTINATIONIP 
    + ", " + COLUMN_NETINFOID 
    + ", " + COLUMN_DSN 
    + ", " + COLUMN_SOURCEUSERTYPE 
    + ", " + COLUMN_SOURCEACCESSTYPE 
    + ", " + COLUMN_SOURCECONNECTIONTYPE 
    + ", " + COLUMN_SOURCEACL 
    + ", " + COLUMN_DESTINATIONENDIP 
    + ", " + COLUMN_DESTINATIONIPTYPE 
    + ", " + COLUMN_ISMANUALASSIGNEDACL 
    + ", " + COLUMN_IPREGISTRATION_ID
    + ", " + COLUMN_PROCESSSTATUS_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + IPRegDetailDAO.TABLE + " WHERE ID = ?";

    /** The Constant SELECT_IPREGDETAILAPPLICATIONXREF_REFERENCE_IDS_STMT. */
    private static final String SELECT_IPREGDETAILAPPLICATIONXREF_REFERENCE_IDS_STMT = "SELECT " + IPRegDetailApplicationXrefDAO.COLUMN_ID + " FROM " + IPRegDetailApplicationXrefDAO.TABLE + " WHERE " + IPRegDetailApplicationXrefDAO.COLUMN_IPREGDETAIL_ID + " = ?";

    /** The Constant SELECT_IPREGDESTINATIONPORTS_REFERENCE_IDS_STMT. */
    private static final String SELECT_IPREGDESTINATIONPORTS_REFERENCE_IDS_STMT = "SELECT " + IPRegDestinationPortsDAO.COLUMN_ID + " FROM " + IPRegDestinationPortsDAO.TABLE + " WHERE " + IPRegDestinationPortsDAO.COLUMN_IPREGDETAIL_ID + " = ?";


    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the iP reg detail dao
     */
    public static IPRegDetailDAO createInstance(DatabaseSession session)
    {
	return new IPRegDetailDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new iP reg detail dao.
     *
     * @param session the session
     */
    public IPRegDetailDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating IPRegDetailDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The IPRegDetailEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(IPRegDetailEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(IPRegDetailEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The IPRegDetailEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(IPRegDetailEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(IPRegDetailEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting IPRegDetailEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + IPRegDetailDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, IPRegDetailDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setDateToStatement(st, position, entity.getUpdatedDate());
	    position = setStringToStatement(st, position, entity.getSourceStartIp(), COLUMN_SOURCESTARTIP_LEN);
	    position = setStringToStatement(st, position, entity.getSourceSubnetMask(), COLUMN_SOURCESUBNETMASK_LEN);
	    position = setStringToStatement(st, position, entity.getDestinationIp(), COLUMN_DESTINATIONIP_LEN);
	    position = setStringToStatement(st, position, entity.getNetInfoId(), COLUMN_NETINFOID_LEN);
	    position = setStringToStatement(st, position, entity.getDsn(), COLUMN_DSN_LEN);
	    position = setStringToStatement(st, position, entity.getSourceUserType(), COLUMN_SOURCEUSERTYPE_LEN);
	    position = setStringToStatement(st, position, entity.getSourceAccessType(), COLUMN_SOURCEACCESSTYPE_LEN);
	    position = setStringToStatement(st, position, entity.getSourceConnectionType(), COLUMN_SOURCECONNECTIONTYPE_LEN);
	    position = setStringToStatement(st, position, entity.getSourceAcl(), COLUMN_SOURCEACL_LEN);
	    position = setStringToStatement(st, position, entity.getDestinationEndIp(), COLUMN_DESTINATIONENDIP_LEN);
	    position = setStringToStatement(st, position, entity.getDestinationIpType(), COLUMN_DESTINATIONIPTYPE_LEN);
	    position = setStringToStatement(st, position, entity.getIsManualAssignedAcl(), COLUMN_ISMANUALASSIGNEDACL_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateIPRegDetailApplicationXrefReferences((IPRegDetailEntity) entity);
	    updateIPRegDestinationPortsReferences((IPRegDetailEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + IPRegDetailDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The IPRegDetailEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(IPRegDetailEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(IPRegDetailEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The IPRegDetailEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(IPRegDetailEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(IPRegDetailEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating IPRegDetailEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + IPRegDetailDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setDateToStatement(st, position, entity.getUpdatedDate());
	    position = setStringToStatement(st, position, entity.getSourceStartIp(), COLUMN_SOURCESTARTIP_LEN);
	    position = setStringToStatement(st, position, entity.getSourceSubnetMask(), COLUMN_SOURCESUBNETMASK_LEN);
	    position = setStringToStatement(st, position, entity.getDestinationIp(), COLUMN_DESTINATIONIP_LEN);
	    position = setStringToStatement(st, position, entity.getNetInfoId(), COLUMN_NETINFOID_LEN);
	    position = setStringToStatement(st, position, entity.getDsn(), COLUMN_DSN_LEN);
	    position = setStringToStatement(st, position, entity.getSourceUserType(), COLUMN_SOURCEUSERTYPE_LEN);
	    position = setStringToStatement(st, position, entity.getSourceAccessType(), COLUMN_SOURCEACCESSTYPE_LEN);
	    position = setStringToStatement(st, position, entity.getSourceConnectionType(), COLUMN_SOURCECONNECTIONTYPE_LEN);
	    position = setStringToStatement(st, position, entity.getSourceAcl(), COLUMN_SOURCEACL_LEN);
	    position = setStringToStatement(st, position, entity.getDestinationEndIp(), COLUMN_DESTINATIONENDIP_LEN);
	    position = setStringToStatement(st, position, entity.getDestinationIpType(), COLUMN_DESTINATIONIPTYPE_LEN);
	    position = setStringToStatement(st, position, entity.getIsManualAssignedAcl(), COLUMN_ISMANUALASSIGNEDACL_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateIPRegDetailApplicationXrefReferences((IPRegDetailEntity) entity);
	    updateIPRegDestinationPortsReferences((IPRegDetailEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + IPRegDetailDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public IPRegDetailEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public IPRegDetailEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	IPRegDetailEntity obj = (IPRegDetailEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting IPRegDetailEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> IPRegDetailEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (IPRegDetailEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + IPRegDetailDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + IPRegDetailDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting IPRegDetailEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    IPRegDetailEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (IPRegDetailEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (IPRegDetailEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + IPRegDetailDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type IPRegDetailEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		IPRegDetailEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM IP_REG_DETAIL";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (IPRegDetailEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + IPRegDetailDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type IPRegDetailEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + IPRegDetailDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    IPRegDetailEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    IPRegDetailEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(IPRegDetailEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(IPRegDetailEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + IPRegDetailDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(IPRegDetailEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();

	    // Go through the many association list and delete any entities that exist in it.
	    IPRegDetailApplicationXrefDAO iPRegDetailApplicationXrefDAO = getIPRegDetailApplicationXrefDAO();
	    List original_iPRegDetailApplicationXref_ids = entity.getOriginalIPRegDetailApplicationXrefIds();
	    Iterator iPRegDetailApplicationXrefIt = entity.getIPRegDetailApplicationXref().getDeletedList().iterator();
	    while (iPRegDetailApplicationXrefIt.hasNext())
	    {
		IPRegDetailApplicationXrefEntity o = (IPRegDetailApplicationXrefEntity)iPRegDetailApplicationXrefIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_iPRegDetailApplicationXref_ids.remove(id);
		}
		iPRegDetailApplicationXrefDAO.delete(o);
	    }

	    iPRegDetailApplicationXrefIt = entity.getIPRegDetailApplicationXref().iterator();
	    while (iPRegDetailApplicationXrefIt.hasNext())
	    {
		IPRegDetailApplicationXrefEntity o = (IPRegDetailApplicationXrefEntity)iPRegDetailApplicationXrefIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_iPRegDetailApplicationXref_ids.remove(id);
		}
		iPRegDetailApplicationXrefDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    iPRegDetailApplicationXrefDAO.delete(original_iPRegDetailApplicationXref_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    IPRegDestinationPortsDAO iPRegDestinationPortsDAO = getIPRegDestinationPortsDAO();
	    List original_iPRegDestinationPorts_ids = entity.getOriginalIPRegDestinationPortsIds();
	    Iterator iPRegDestinationPortsIt = entity.getIPRegDestinationPorts().getDeletedList().iterator();
	    while (iPRegDestinationPortsIt.hasNext())
	    {
		IPRegDestinationPortsEntity o = (IPRegDestinationPortsEntity)iPRegDestinationPortsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_iPRegDestinationPorts_ids.remove(id);
		}
		iPRegDestinationPortsDAO.delete(o);
	    }

	    iPRegDestinationPortsIt = entity.getIPRegDestinationPorts().iterator();
	    while (iPRegDestinationPortsIt.hasNext())
	    {
		IPRegDestinationPortsEntity o = (IPRegDestinationPortsEntity)iPRegDestinationPortsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_iPRegDestinationPorts_ids.remove(id);
		}
		iPRegDestinationPortsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    iPRegDestinationPortsDAO.delete(original_iPRegDestinationPorts_ids);
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + IPRegDetailDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	IPRegDetailEntity entity = (IPRegDetailEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setUpdatedDate(getDateFromResultSet(rs, COLUMN_UPDATEDDATE));
	    entity.setUpdatedDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalUpdatedDate(entity.getUpdatedDate());
	    //			entity.setSourceStartIp(getStringFromResultSet(rs, COLUMN_SOURCESTARTIP));
	    entity.setSourceStartIp(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSourceStartIp(entity.getSourceStartIp());
	    //			entity.setSourceSubnetMask(getStringFromResultSet(rs, COLUMN_SOURCESUBNETMASK));
	    entity.setSourceSubnetMask(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSourceSubnetMask(entity.getSourceSubnetMask());
	    //			entity.setDestinationIp(getStringFromResultSet(rs, COLUMN_DESTINATIONIP));
	    entity.setDestinationIp(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalDestinationIp(entity.getDestinationIp());
	    //			entity.setNetInfoId(getStringFromResultSet(rs, COLUMN_NETINFOID));
	    entity.setNetInfoId(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalNetInfoId(entity.getNetInfoId());
	    //			entity.setDsn(getStringFromResultSet(rs, COLUMN_DSN));
	    entity.setDsn(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalDsn(entity.getDsn());
	    //			entity.setSourceUserType(getStringFromResultSet(rs, COLUMN_SOURCEUSERTYPE));
	    entity.setSourceUserType(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSourceUserType(entity.getSourceUserType());
	    //			entity.setSourceAccessType(getStringFromResultSet(rs, COLUMN_SOURCEACCESSTYPE));
	    entity.setSourceAccessType(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSourceAccessType(entity.getSourceAccessType());
	    //			entity.setSourceConnectionType(getStringFromResultSet(rs, COLUMN_SOURCECONNECTIONTYPE));
	    entity.setSourceConnectionType(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSourceConnectionType(entity.getSourceConnectionType());
	    //			entity.setSourceAcl(getStringFromResultSet(rs, COLUMN_SOURCEACL));
	    entity.setSourceAcl(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSourceAcl(entity.getSourceAcl());
	    //			entity.setDestinationEndIp(getStringFromResultSet(rs, COLUMN_DESTINATIONENDIP));
	    entity.setDestinationEndIp(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalDestinationEndIp(entity.getDestinationEndIp());
	    //			entity.setDestinationIpType(getStringFromResultSet(rs, COLUMN_DESTINATIONIPTYPE));
	    entity.setDestinationIpType(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalDestinationIpType(entity.getDestinationIpType());
	    //			entity.setIsManualAssignedAcl(getStringFromResultSet(rs, COLUMN_ISMANUALASSIGNEDACL));
	    entity.setIsManualAssignedAcl(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIsManualAssignedAcl(entity.getIsManualAssignedAcl());

	    // Single References
	    //			entity.setIpRegistrationId(getLongFromResultSet(rs, COLUMN_IPREGISTRATION_ID));
	    entity.setIpRegistrationId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIpRegistrationId(entity.getIpRegistrationId());
	    //			entity.setProcessStatusId(getLongFromResultSet(rs, COLUMN_PROCESSSTATUS_ID));
	    entity.setProcessStatusId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcessStatusId(entity.getProcessStatusId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	IPRegDetailEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (IPRegDetailEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new IPRegDetailEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	IPRegDetailEntity entity = (IPRegDetailEntity)obj;
	loadIPRegDetailApplicationXrefReferenceIds(entity);
	loadIPRegDestinationPortsReferenceIds(entity);
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("IPRegDestinationPortsDAO.loadReferences(): References for IPRegDetailEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("IPRegDestinationPortsDAO.loadReferences(): Loading references for IPRegDetailEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    IPRegDetailEntity entity = (IPRegDetailEntity)obj;

	    Long ipRegistrationId = entity.getIpRegistrationId();
	    if (ipRegistrationId != null)
	    {
		//			IPRegistrationDAO ipRegistrationDAO = new IPRegistrationDAO(getSession());
		IPRegistrationDAO ipRegistrationDAO = getIpRegistrationDAO();
		entity.setIpRegistration((IPRegistrationEntity)ipRegistrationDAO.get(ipRegistrationId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalIpRegistration(entity.getIpRegistration());
	    }

	    Long processStatusId = entity.getProcessStatusId();
	    if (processStatusId != null)
	    {
		//			TIStatusTypeDAO processStatusDAO = new TIStatusTypeDAO(getSession());
		TIStatusTypeDAO processStatusDAO = getProcessStatusDAO();
		entity.setProcessStatus((TIStatusTypeEntity)processStatusDAO.get(processStatusId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalProcessStatus(entity.getProcessStatus());
	    }

	    loadIPRegDetailApplicationXrefReferences(entity);

	    loadIPRegDestinationPortsReferences(entity);

	}
	catch(Exception e)
	{
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for IPRegDetailEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load ip registration with id.
     *
     * @param id the id
     * @return the iP registration entity
     * @throws DatabaseException the database exception
     */
    public IPRegistrationEntity loadIpRegistrationWithId(Long id) throws DatabaseException
    {
	IPRegistrationEntity entity = null;
	if (id != null)
	{
	    //			IPRegistrationDAO ipRegistrationDAO = new IPRegistrationDAO(getSession());
	    IPRegistrationDAO ipRegistrationDAO = getIpRegistrationDAO();
	    entity = (IPRegistrationEntity)ipRegistrationDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load process status with id.
     *
     * @param id the id
     * @return the tI status type entity
     * @throws DatabaseException the database exception
     */
    public TIStatusTypeEntity loadProcessStatusWithId(Long id) throws DatabaseException
    {
	TIStatusTypeEntity entity = null;
	if (id != null)
	{
	    //			TIStatusTypeDAO processStatusDAO = new TIStatusTypeDAO(getSession());
	    TIStatusTypeDAO processStatusDAO = getProcessStatusDAO();
	    entity = (TIStatusTypeEntity)processStatusDAO.get(id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	IPRegDetailEntity entity = (IPRegDetailEntity) obj;

	setLongToStatement(st, position++, entity.getIpRegistration() != null ? entity.getIpRegistration().getId() : entity.getIpRegistrationId());
	setLongToStatement(st, position++, entity.getProcessStatus() != null ? entity.getProcessStatus().getId() : entity.getProcessStatusId());

	return position;
    }

    // Single non-composition 'ipRegistration' helpers 'IPRegDetail' does not need helper
    // Single non-composition 'processStatus' helpers 'IPRegDetail' does not need helper
    // Many Composition 'IPRegDetailApplicationXref' helpers 'ipRegDetail'
    //======================================================================
    /**
     * Loads all the IPRegDetailApplicationXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadIPRegDetailApplicationXrefReferences(IPRegDetailEntity entity) throws DatabaseException
    {
	loadIPRegDetailApplicationXrefReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the IPRegDetailApplicationXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadIPRegDetailApplicationXrefReferences(IPRegDetailEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading IPRegDetailApplicationXref references for IPRegDetailEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getIPRegDetailApplicationXref();
	    List id_list = entity.getOriginalIPRegDetailApplicationXrefIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		IPRegDetailApplicationXrefDAO dao = getIPRegDetailApplicationXrefDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		IPRegDetailApplicationXrefDAO dao = getIPRegDetailApplicationXrefDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading IPRegDetailApplicationXref references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load IPRegDetailApplicationXref References for IPRegDetailEntity [" + entity.getId() + "].", e);
	}


	//		entity.setIPRegDetailApplicationXref(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the IPRegDetailApplicationXref references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadIPRegDetailApplicationXrefReferenceIds(IPRegDetailEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_IPREGDETAILAPPLICATIONXREF_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalIPRegDetailApplicationXrefIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load IPRegDetailApplicationXref Reference IDs from IPRegDetailEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update ip reg detail application xref references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateIPRegDetailApplicationXrefReferences(IPRegDetailEntity entity) throws DatabaseException
    {
	ManyAssociationList iPRegDetailApplicationXref = entity.getIPRegDetailApplicationXref();
	IPRegDetailApplicationXrefDAO dao = getIPRegDetailApplicationXrefDAO();

	Iterator itDeleted = iPRegDetailApplicationXref.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    IPRegDetailApplicationXrefEntity e = (IPRegDetailApplicationXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = iPRegDetailApplicationXref.iterator();
	while (it.hasNext())
	{
	    IPRegDetailApplicationXrefEntity e = (IPRegDetailApplicationXrefEntity) it.next();
	    e.setIpRegDetail(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'IPRegDestinationPorts' helpers 'IpRegdetail'
    //======================================================================
    /**
     * Loads all the IPRegDestinationPorts references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadIPRegDestinationPortsReferences(IPRegDetailEntity entity) throws DatabaseException
    {
	loadIPRegDestinationPortsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the IPRegDestinationPorts references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadIPRegDestinationPortsReferences(IPRegDetailEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading IPRegDestinationPorts references for IPRegDetailEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getIPRegDestinationPorts();
	    List id_list = entity.getOriginalIPRegDestinationPortsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		IPRegDestinationPortsDAO dao = getIPRegDestinationPortsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		IPRegDestinationPortsDAO dao = getIPRegDestinationPortsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading IPRegDestinationPorts references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load IPRegDestinationPorts References for IPRegDetailEntity [" + entity.getId() + "].", e);
	}


	//		entity.setIPRegDestinationPorts(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the IPRegDestinationPorts references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadIPRegDestinationPortsReferenceIds(IPRegDetailEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_IPREGDESTINATIONPORTS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalIPRegDestinationPortsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load IPRegDestinationPorts Reference IDs from IPRegDetailEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update ip reg destination ports references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateIPRegDestinationPortsReferences(IPRegDetailEntity entity) throws DatabaseException
    {
	ManyAssociationList iPRegDestinationPorts = entity.getIPRegDestinationPorts();
	IPRegDestinationPortsDAO dao = getIPRegDestinationPortsDAO();

	Iterator itDeleted = iPRegDestinationPorts.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    IPRegDestinationPortsEntity e = (IPRegDestinationPortsEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = iPRegDestinationPorts.iterator();
	while (it.hasNext())
	{
	    IPRegDestinationPortsEntity e = (IPRegDestinationPortsEntity) it.next();
	    e.setIpRegdetail(entity);
	    dao.update(e, false);
	}
    }

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A IPRegistrationDAO object 
     */
    protected IPRegistrationDAO getIpRegistrationDAO()
    {
	IPRegistrationDAO dao = (IPRegistrationDAO)getSession().getDAO("IPRegistration");  
	if(dao == null)
	{
	    dao = new IPRegistrationDAO(getSession());  		
	    getSession().putDAO("IPRegistration", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A TIStatusTypeDAO object 
     */
    protected TIStatusTypeDAO getProcessStatusDAO()
    {
	TIStatusTypeDAO dao = (TIStatusTypeDAO)getSession().getDAO("TIStatusType");  
	if(dao == null)
	{
	    dao = new TIStatusTypeDAO(getSession());  		
	    getSession().putDAO("TIStatusType", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A IPRegDetailApplicationXrefDAO object 
     */
    protected IPRegDetailApplicationXrefDAO getIPRegDetailApplicationXrefDAO()
    {
	IPRegDetailApplicationXrefDAO dao = (IPRegDetailApplicationXrefDAO)getSession().getDAO("IPRegDetailApplicationXref");  
	if(dao == null)
	{
	    dao = new IPRegDetailApplicationXrefDAO(getSession());  		
	    getSession().putDAO("IPRegDetailApplicationXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A IPRegDestinationPortsDAO object 
     */
    protected IPRegDestinationPortsDAO getIPRegDestinationPortsDAO()
    {
	IPRegDestinationPortsDAO dao = (IPRegDestinationPortsDAO)getSession().getDAO("IPRegDestinationPorts");  
	if(dao == null)
	{
	    dao = new IPRegDestinationPortsDAO(getSession());  		
	    getSession().putDAO("IPRegDestinationPorts", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [UpdatedDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByUpdatedDate(Date value) throws DatabaseException
    {
	return findByUpdatedDate(value, getSession());
    }

    /**
     * Find by updated date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByUpdatedDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_UPDATEDDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SourceStartIp] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySourceStartIp(String value) throws DatabaseException
    {
	return findBySourceStartIp(value, getSession());
    }

    /**
     * Find by source start ip.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySourceStartIp(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_SOURCESTARTIP + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SourceSubnetMask] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySourceSubnetMask(String value) throws DatabaseException
    {
	return findBySourceSubnetMask(value, getSession());
    }

    /**
     * Find by source subnet mask.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySourceSubnetMask(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_SOURCESUBNETMASK + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [DestinationIp] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByDestinationIp(String value) throws DatabaseException
    {
	return findByDestinationIp(value, getSession());
    }

    /**
     * Find by destination ip.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByDestinationIp(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_DESTINATIONIP + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [NetInfoId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByNetInfoId(String value) throws DatabaseException
    {
	return findByNetInfoId(value, getSession());
    }

    /**
     * Find by net info id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByNetInfoId(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_NETINFOID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Dsn] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByDsn(String value) throws DatabaseException
    {
	return findByDsn(value, getSession());
    }

    /**
     * Find by dsn.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByDsn(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_DSN + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SourceUserType] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySourceUserType(String value) throws DatabaseException
    {
	return findBySourceUserType(value, getSession());
    }

    /**
     * Find by source user type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySourceUserType(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_SOURCEUSERTYPE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SourceAccessType] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySourceAccessType(String value) throws DatabaseException
    {
	return findBySourceAccessType(value, getSession());
    }

    /**
     * Find by source access type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySourceAccessType(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_SOURCEACCESSTYPE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SourceConnectionType] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySourceConnectionType(String value) throws DatabaseException
    {
	return findBySourceConnectionType(value, getSession());
    }

    /**
     * Find by source connection type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySourceConnectionType(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_SOURCECONNECTIONTYPE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SourceAcl] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySourceAcl(String value) throws DatabaseException
    {
	return findBySourceAcl(value, getSession());
    }

    /**
     * Find by source acl.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySourceAcl(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_SOURCEACL + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [DestinationEndIp] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByDestinationEndIp(String value) throws DatabaseException
    {
	return findByDestinationEndIp(value, getSession());
    }

    /**
     * Find by destination end ip.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByDestinationEndIp(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_DESTINATIONENDIP + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [DestinationIpType] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByDestinationIpType(String value) throws DatabaseException
    {
	return findByDestinationIpType(value, getSession());
    }

    /**
     * Find by destination ip type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByDestinationIpType(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_DESTINATIONIPTYPE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IsManualAssignedAcl] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIsManualAssignedAcl(String value) throws DatabaseException
    {
	return findByIsManualAssignedAcl(value, getSession());
    }

    /**
     * Find by is manual assigned acl.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIsManualAssignedAcl(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_ISMANUALASSIGNEDACL + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [IpRegistration] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIpRegistration(Long value) throws DatabaseException
    {
	return findByIpRegistration(value, getSession());
    }

    /**
     * Find by ip registration.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIpRegistration(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_IPREGISTRATION_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [ProcessStatus] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcessStatus(Long value) throws DatabaseException
    {
	return findByProcessStatus(value, getSession());
    }

    /**
     * Find by process status.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcessStatus(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPRegDetailDAO.TABLE + " WHERE " + COLUMN_PROCESSSTATUS_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by ProcessStatus", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(IPRegDetailEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
