/**
 * 
 */
package com.citigroup.cgti.c3par.common.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.bpm.ejb.domain.C3PARUserDTO;
import com.citigroup.cgti.c3par.domain.C3PARUser;
import com.citigroup.cgti.c3par.persistance.Persistable;


/**
 * @author pc79439
 * 
 */
public interface UserAdminServicePersistable extends Persistable {
	/**
	 * Gets the user data.
	 *
	 * @param soeId the soe id
	 * @return the user data
	 * @throws Exception the exception
	 */
	public C3PARUser getUserData(String soeId) throws Exception;
	
	/**
	 * Gets the user dto.
	 *
	 * @param soeId the soe id
	 * @return the user dto
	 * @throws Exception the exception
	 */
	public C3PARUserDTO getUserDTO(String soeId) throws Exception;
	
	/**
	 * Activate user.
	 *
	 * @param requesterSOEId the requester soe id
	 * @param isaDOEId the isa doe id
	 * @throws Exception the exception
	 */
	public void activateUser(String requesterSOEId, String isaDOEId) throws Exception;
	
	/**
	 * Update approver.
	 *
	 * @param requesterSOEId the requester soe id
	 * @param approverSOEId the approver soe id
	 * @param role the role
	 * @throws Exception the exception
	 */
	public void updateApprover(String requesterSOEId, String approverSOEId,String role) throws Exception;
	
	/**
	 * Gets the bulk upload users.
	 *
	 * @param isaSOEId the isa soe id
	 * @return the bulk upload users
	 * @throws Exception the exception
	 */
	public List getBulkUploadUsers(String isaSOEId) throws Exception;
	
	/**
	 * Gets the pending users.
	 *
	 * @return the pending users
	 * @throws Exception the exception
	 */
	//public List getPendingUsers() throws Exception;
	
	/**
	 * Update status.
	 *
	 * @param strSOEId the str soe id
	 * @param strIsActive the str is active
	 * @param strWFStatus the str wf status
	 * @throws Exception the exception
	 */
	public void updateStatus(String strSOEId, String strIsActive, String strWFStatus) throws Exception;
	
	/**
	 * Gets the iSA edit users.
	 *
	 * @param isaSOEId the isa soe id
	 * @return the iSA edit users
	 * @throws Exception the exception
	 */
	public List getISAEditUsers(String isaSOEId) throws Exception;
	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean isGIDACMPReady() throws Exception;
}
