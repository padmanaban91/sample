package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;


/**
 * The Class Template.
 */
public class Template extends Base implements Serializable{

    /** The key. */
    private String key;

    /** The description. */
    private String description;

    /** The default value. */
    private String defaultValue;

    /** The position. */
    private Integer position;

    /** The template lookup. */
    private GenericLookup templateLookup;

    /** The parent id. */
    private Integer parentId;

    /** The path value. */
    private String pathValue;

    /** The position value. */
    private Integer positionValue;
    
    private String isActive;

    /**
     * Gets the key.
     *
     * @return the key
     */
    public String getKey() {
	return key;
    }

    /**
     * Sets the key.
     *
     * @param key the new key
     */
    public void setKey(String key) {
	this.key = key;
    }

    /**
     * get the isActive
     * @return
     */
    public String getIsActive() {
		return isActive;
	}

    /**
     * sets the isActive
     * @param isActive
     */
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	/**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
	return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
	this.description = description;
    }

    /**
     * Gets the default value.
     *
     * @return the default value
     */
    public String getDefaultValue() {
	return defaultValue;
    }

    /**
     * Sets the default value.
     *
     * @param defaultValue the new default value
     */
    public void setDefaultValue(String defaultValue) {
	this.defaultValue = defaultValue;
    }

    /**
     * Gets the position.
     *
     * @return the position
     */
    public Integer getPosition() {
	return position;
    }

    /**
     * Sets the position.
     *
     * @param position the new position
     */
    public void setPosition(Integer position) {
	this.position = position;
    }

    /**
     * Gets the template lookup.
     *
     * @return the template lookup
     */
    public GenericLookup getTemplateLookup() {
	return templateLookup;
    }

    /**
     * Sets the template lookup.
     *
     * @param templateLookup the new template lookup
     */
    public void setTemplateLookup(GenericLookup templateLookup) {
	this.templateLookup = templateLookup;
    }

    /**
     * Gets the parent id.
     *
     * @return the parent id
     */
    public Integer getParentId() {
	return parentId;
    }

    /**
     * Sets the parent id.
     *
     * @param parentId the new parent id
     */
    public void setParentId(Integer parentId) {
	this.parentId = parentId;
    }

    /**
     * Gets the path value.
     *
     * @return the path value
     */
    public String getPathValue() {
	return pathValue;
    }

    /**
     * Sets the path value.
     *
     * @param pathValue the new path value
     */
    public void setPathValue(String pathValue) {
	this.pathValue = pathValue;
    }

    /**
     * Gets the position value.
     *
     * @return the position value
     */
    public Integer getPositionValue() {
	return positionValue;
    }

    /**
     * Sets the position value.
     *
     * @param positionValue the new position value
     */
    public void setPositionValue(Integer positionValue) {
	this.positionValue = positionValue;
    }
}