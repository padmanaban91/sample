package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * 
 * @author ne36745
 *
 */
public class PossibleAnswers extends Base implements Comparable<PossibleAnswers>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private OstiaQuestion ostiaQuestion;
	
	private String answer;
	
	private String optionsGroupName;

	public PossibleAnswers() {
		setCreated_date(new Date());
	}
	
	/**
	 * @return the ostiaQuestion
	 */
	public OstiaQuestion getOstiaQuestion() {
		return ostiaQuestion;
	}

	/**
	 * @param ostiaQuestion the ostiaQuestion to set
	 */
	public void setOstiaQuestion(OstiaQuestion ostiaQuestion) {
		this.ostiaQuestion = ostiaQuestion;
	}

	/**
	 * @return the answer
	 */
	public String getAnswer() {
		return answer;
	}

	/**
	 * @param answer the answer to set
	 */
	public void setAnswer(String answer) {
		this.answer = answer;
	}

	/**
	 * @return the optionsGroupName
	 */
	public String getOptionsGroupName() {
		return optionsGroupName;
	}

	/**
	 * @param optionsGroupName the optionsGroupName to set
	 */
	public void setOptionsGroupName(String optionsGroupName) {
		this.optionsGroupName = optionsGroupName;
	}
	
	@Override
	public int compareTo(PossibleAnswers obj) { 
		int result=0;
        result = this.getAnswer().compareTo(obj.getAnswer() );
        return result;
  
	}

}
