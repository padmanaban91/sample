package com.citigroup.cgti.c3par.fw.service;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.jms.core.MessageCreator;

import com.citigroup.cgti.c3par.bpm.ejb.search.ServiceNowQueueSender;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class ServiceNowQueueSenderImpl implements ServiceNowQueueSender {
	private static Logger LOGGER = Logger.getLogger(ServiceNowQueueSenderImpl.class);


	public void sendMesage(final String message) {
		LOGGER.debug("message to be sent to ServiceNow : " + message);
		ApplicationContext appContext = CCRApplicationContextUtils.getApplicationContext();
		CCRBeanFactory ccrBeanFactory = (CCRBeanFactory) appContext.getBean("cCRBeanFactory");

		MessageCreator messageCreator = new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage(message);
			}
		};
		
			LOGGER.debug("ccrBeanFactory.getJmsTemplate_snow(): "+ccrBeanFactory.getJmsTemplate_snow());
			LOGGER.debug("ccrBeanFactory.getSnowSender(): "+ccrBeanFactory.getSnowSender());
			LOGGER.debug("messageCreator : "+messageCreator.toString());
		
		ccrBeanFactory.getJmsTemplate_snow().send(ccrBeanFactory.getSnowSender(),
				messageCreator);
		LOGGER.info("Message sent to ServiceNow Successfully..!!");
	}
}