/*
 * 
 */
package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;
import java.sql.Clob;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * The Class TIMailAuditResponse.
 */
public class TIMailAuditResponse extends Base implements Serializable {

	private TIMailAudit tiMailAudit;

	private String fromUserID;

	private String mailSubject;

	private Clob mailBody;

	private String actionTaken;

	private String remarks;

	private String createdDateDisplay;

	private String mailBodyDisplay;

	public TIMailAudit getTiMailAudit() {
		return tiMailAudit;
	}

	public void setTiMailAudit(TIMailAudit tiMailAudit) {
		this.tiMailAudit = tiMailAudit;
	}

	public String getFromUserID() {
		return fromUserID;
	}

	public void setFromUserID(String fromUserID) {
		this.fromUserID = fromUserID;
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

	public Clob getMailBody() {
		return mailBody;
	}

	public void setMailBody(Clob mailBody) {
		this.mailBody = mailBody;
	}

	public String getActionTaken() {
		return actionTaken;
	}

	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCreatedDateDisplay() {
		if(getCreated_date() != null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			return dateformat.format(getCreated_date());
		}
		return createdDateDisplay;
	}

	public void setCreatedDateDisplay(String createdDateDisplay) {
		this.createdDateDisplay = createdDateDisplay;
	}

	public String getMailBodyDisplay() {
		Clob mailbody = getMailBody();
		if(mailbody != null){
			int len = 0;
			try {
				len = (int)mailbody.length();
				return new String(mailbody.getSubString(1, len));
			} catch (SQLException e) {
			}
		}		
		return mailBodyDisplay;
	}

	public void setMailBodyDisplay(String mailBodyDisplay) {
		this.mailBodyDisplay = mailBodyDisplay;
	}

}
