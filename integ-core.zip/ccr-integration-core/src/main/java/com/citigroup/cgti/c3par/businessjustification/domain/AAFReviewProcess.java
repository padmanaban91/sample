/**
 *
 */
package com.citigroup.cgti.c3par.businessjustification.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.appsense.domain.AppsenseAAFCombination;
import com.citigroup.cgti.c3par.appsense.domain.logic.ManageAppsensePersistable;
import com.citigroup.cgti.c3par.businessjustification.domain.soc.persist.AAFReviewServicePersistable;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.TIRequest;

public class AAFReviewProcess {

	@Autowired
	AAFReviewServicePersistable reviewServicePersistable;

	@Autowired
	ManageAppsensePersistable appsensePersistable;

	
	public TIRequest getTIRequestDetails(Long tiRequestId) {

		return getReviewServicePersistable().getTIRequest(tiRequestId);
	}

	
	public Long getPlanningId(Long tirequestid) {
		return getReviewServicePersistable().getPlanningIdForTiRequestId(
				tirequestid);
	}

	
	public Planning getPlanningDetails(Long planningid) {

		return getReviewServicePersistable().getPlanningDetails(planningid);
	}

	
	public AppsenseAAFCombination getApsNonNetworkCombination(Long processID,
			Long versionID, Long combType, Long fafType) {

		return getAppsensePersistable().getApsNonNetworkCombination(processID,
				versionID, combType, fafType);
	}

	
	public List getApsNetworkCombFilter(Long processID, Long versionID,
			Long combType, Long fafType) {

		return getAppsensePersistable().getApsNetworkCombFilter(processID,
				versionID, combType, fafType);
	}

	
	public AppsenseAAFCombination getApsUserCombination(Long processID,
			Long versionID, Long combType, Long fafType) {

		return getAppsensePersistable().getApsUserCombination(processID,
				versionID, combType, fafType);
	}

	public ManageAppsensePersistable getAppsensePersistable() {
		return appsensePersistable;
	}

	public void setAppsensePersistable(
			ManageAppsensePersistable appsensePersistable) {
		this.appsensePersistable = appsensePersistable;
	}

	public AAFReviewServicePersistable getReviewServicePersistable() {
		return reviewServicePersistable;
	}

	public void setReviewServicePersistable(
			AAFReviewServicePersistable reviewServicePersistable) {
		this.reviewServicePersistable = reviewServicePersistable;
	}

}
