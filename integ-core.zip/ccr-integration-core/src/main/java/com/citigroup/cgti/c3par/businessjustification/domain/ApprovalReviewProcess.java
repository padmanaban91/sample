/**
 *
 */
package com.citigroup.cgti.c3par.businessjustification.domain;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.businessjustification.domain.soc.persist.ApprovalReviewServicePersistable;
import com.citigroup.cgti.c3par.domain.TIRequest;

public class ApprovalReviewProcess {

	@Autowired
	private ApprovalReviewServicePersistable approvalReviewServicePersistable;

	
	public HashMap<String, String> fetchRequestInfo(String requestId,String action){
		return getApprovalReviewServicePersistable().fetchRequestInfo(requestId, action);
	}

	
	public HashMap<String, String> extractReviewComments(long requestId) throws Exception{
		return getApprovalReviewServicePersistable().extractReviewComments(requestId);
	}			

	
	public int getCount(String listType, Long ti_request_id, String role) throws Exception {
		return getApprovalReviewServicePersistable().getCount(listType,ti_request_id,role);
	}

	
	public HashMap extractReviewInfo(long requestId) throws Exception{
		return getApprovalReviewServicePersistable().extractReviewInfo(requestId);
	}

	
	public HashMap extractReviewInfoForIP(long requestId) throws Exception{
		return getApprovalReviewServicePersistable().extractReviewInfoForIP(requestId);
	}	

	
	public List getAllDiscussions(String listType, Long ti_request_id, String role, int pageNum, int pageSize) throws RemoteException {
		return getApprovalReviewServicePersistable().getAllDiscussions(listType,ti_request_id,role,pageNum,pageSize);
	}

	
	public TIRequest getTIRequestDetails(Long tiRequestId){
		return getApprovalReviewServicePersistable().getTIRequest(tiRequestId);
	}

	public ApprovalReviewServicePersistable getApprovalReviewServicePersistable() {
		return approvalReviewServicePersistable;
	}

	public void setApprovalReviewServicePersistable(
			ApprovalReviewServicePersistable approvalReviewServicePersistable) {
		this.approvalReviewServicePersistable = approvalReviewServicePersistable;
	}

}
