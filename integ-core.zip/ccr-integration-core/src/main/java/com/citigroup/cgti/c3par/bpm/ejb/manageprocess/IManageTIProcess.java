package com.citigroup.cgti.c3par.bpm.ejb.manageprocess;


import java.util.Date;
import java.util.List;
import java.util.Map;
import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;

import com.citigroup.cgti.c3par.domain.TIProcess;


/**
 * The Interface IManageTIProcess.
 */
public interface IManageTIProcess {
	//Depricate gets Connection and IP registration information used in viewing the details screen of a SCHEDEDULED activity and also gets the business params which derives the workflows  
	  	  /**
	 * Insert process.
	 *
	 * @param tiProcess the ti process
	 * @return the long
	 * @throws Exception the exception
	 */
	public long  insertProcess(TIProcess tiProcess)  throws Exception;
	  
  	/**
  	 * Update process.
  	 *
  	 * @param tiProcess the ti process
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long  updateProcess(TIProcess tiProcess) throws Exception ;
	  
  	/**
  	 * Terminate process.
  	 *
  	 * @param tiProcess the ti process
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long  terminateProcess(TIProcess tiProcess) throws Exception ;
	  
	  /**
  	 * Gets the process data.
  	 *
  	 * @param requestID the request id
  	 * @return the process data
  	 * @throws Exception the exception
  	 */
  	public  TIProcess getProcessData(long requestID) throws Exception ;	  
	  
  	/**
  	 * Gets the process data.
  	 *
  	 * @param requestID the request id
  	 * @param activityCode the activity code
  	 * @param prInfoRequestedActivityCode the pr info requested activity code
  	 * @return the process data
  	 * @throws Exception the exception
  	 */
  	public  TIProcess getProcessData(long requestID,String activityCode,String prInfoRequestedActivityCode) throws Exception ;
	  
  	/**
  	 * Insert process.
  	 *
  	 * @param tiProcessDTO the ti process dto
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long  insertProcess(TIProcessDTO tiProcessDTO)  throws Exception;
	  
  	/**
  	 * Gets the process dto.
  	 *
  	 * @param requestID the request id
  	 * @return the process dto
  	 * @throws Exception the exception
  	 */
  	public  TIProcessDTO getProcessDTO(long requestID) throws Exception ;
	  
  	/**
  	 * Gets the process dto.
  	 *
  	 * @param requestID the request id
  	 * @param activityCode the activity code
  	 * @param prInfoRequestedActivityCode the pr info requested activity code
  	 * @return the process dto
  	 * @throws Exception the exception
  	 */
  	public  TIProcessDTO getProcessDTO(long requestID,String activityCode,String prInfoRequestedActivityCode) throws Exception ;
	  
  	/**
  	 * Update process mode.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @param mode the mode
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long  updateProcessMode(long tiRequestId, String mode) throws Exception ;
	  
  	/**
  	 * Update process.
  	 *
  	 * @param processDTO the process dto
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long  updateProcess(TIProcessDTO processDTO) throws Exception ;
	  
  	/**
  	 * Terminate process.
  	 *
  	 * @param processDTO the process dto
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long  terminateProcess(TIProcessDTO processDTO) throws Exception ;

	  /**
  	 * Gets the approval control flags.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @return the approval control flags
  	 * @throws Exception the exception
  	 */
  	public Map getApprovalControlFlags(long tiRequestId) throws Exception ;
	  
  	/**
  	 * Gets the implementation control flags.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @return the implementation control flags
  	 * @throws Exception the exception
  	 */
  	public Map getImplementationControlFlags(long tiRequestId) throws Exception ;
	  
  	/**
  	 * Checks if is data entry complete.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @return true, if is data entry complete
  	 * @throws Exception the exception
  	 */
  	public boolean isDataEntryComplete(long tiRequestId) throws Exception;
	  //update the process status to the current activity id
	  /**
  	 * Update process status.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @param activityID the activity id
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long  updateProcessStatus(long tiRequestId,long activityID) throws Exception ;
	  
  	/**
  	 * Update autopush status.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @param autopushStatus the autopush status
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long updateAutopushStatus(long tiRequestId, String autopushStatus) throws Exception;
	  
  	/**
  	 * Gets the processes for autopush.
  	 *
  	 * @return the processes for autopush
  	 * @throws Exception the exception
  	 */
  	public List getProcessesForAutopush() throws Exception;
	  
  	/**
  	 * Gets the requests for notification.
  	 *
  	 * @return the requests for notification
  	 * @throws Exception the exception
  	 */
  	public List getRequestsForNotification() throws Exception;
	  
  	/**
  	 * End process.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @param activityCode the activity code
  	 * @param activityStatus the activity status
  	 * @throws Exception the exception
  	 */
  	public void endProcess(long tiRequestID,String activityCode,String activityStatus) throws Exception;
	  
  	/**
  	 * Lock comments.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @throws Exception the exception
  	 */
  	public void lockComments(long tiRequestID) throws Exception;
	  
  	/**
  	 * Sets the request deadline.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @param date the date
  	 * @throws Exception the exception
  	 */
  	public void setRequestDeadline(long tiRequestID,Date date) throws Exception;
	  
  	/**
  	 * Sets the activation deadline.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @param date the date
  	 * @throws Exception the exception
  	 */
  	public void setActivationDeadline(long tiRequestID,Date date) throws Exception;
	  
  	/**
  	 * Gets the extended time.
  	 *
  	 * @param value the value
  	 * @return the extended time
  	 * @throws Exception the exception
  	 */
  	public List getExtendedTime(String value) throws Exception;
	  
  	/**
  	 * Send email to app owners.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @throws Exception the exception
  	 */
  	public void sendEmailToAppOwners(long tiRequestId) throws Exception;
	  
  	/**
  	 * Send email to app owners.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @param firewallFlag the firewall flag
  	 * @param proxyFlag the proxy flag
  	 * @param appSenseFlag the app sense flag
  	 * @throws Exception the exception
  	 */
  	public void sendEmailToAppOwners(long tiRequestId,boolean firewallFlag,boolean proxyFlag,boolean appSenseFlag) throws Exception;
	  
	  /**
  	 * Gets the expiration actions.
  	 *
  	 * @param activityCode the activity code
  	 * @return the expiration actions
  	 * @throws Exception the exception
  	 */
  	public List getExpirationActions(String activityCode) throws Exception;
	  
	    
	  /**
  	 * Gets the processes for acv.
  	 *
  	 * @return the processes for acv
  	 * @throws Exception the exception
  	 */
  	public List getProcessesForACV() throws Exception;
	  
  	/**
  	 * Gets the processes for approval expiration.
  	 *
  	 * @return the processes for approval expiration
  	 * @throws Exception the exception
  	 */
  	public List getProcessesForApprovalExpiration() throws Exception;	  
	  
  	/**
  	 * Gets the annual verification flag value.
  	 *
  	 * @param processId the process id
  	 * @return the annual verification flag value
  	 * @throws Exception the exception
  	 */
  	public String getAnnualVerificationFlagValue(long processId)  throws Exception;
	  
  	/**
  	 * Creates the acv.
  	 *
  	 * @param tiProcess the ti process
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long createACV(TIProcessDTO tiProcess) throws Exception;
	  
  	/**
  	 * Extend expiration.
  	 *
  	 * @param processId the process id
  	 * @return true, if successful
  	 * @throws Exception the exception
  	 */
  	public boolean extendExpiration(long processId) throws Exception;
	  
	  /**
  	 * Checks if is mAD business unit.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @return true, if is mAD business unit
  	 * @throws Exception the exception
  	 */
  	public boolean isMADBusinessUnit(long tiRequestId) throws Exception;
	  
  	/**
  	 * Gets the supplement review roles.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @return the supplement review roles
  	 * @throws Exception the exception
  	 */
  	public String getSupplementReviewRoles(long tiRequestId) throws Exception;
	  
  	/**
  	 * Checks if is deferred review.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @return true, if is deferred review
  	 * @throws Exception the exception
  	 */
  	public boolean isDeferredReview(long tiRequestId) throws Exception;
	  
  	/**
  	 * Gets the check completion flags.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @return the check completion flags
  	 * @throws Exception the exception
  	 */
  	public Map getCheckCompletionFlags(long tiRequestId) throws Exception;
	  
 	/**
  	 * Copy tech arch data.
  	 *
  	 * @param processId the process id
  	 * @param tiRequestId the ti request id
  	 * @return the string
  	 * @throws Exception the exception
  	 */
  	public String copyTechArchData(long processId,long tiRequestId) throws Exception;
 	
 	
 	  	/**
  	 * Copy tech arch data.
  	 *
  	 * @param processId the process id
  	 * @param tiRequestId the ti request id
  	 * @return the string
  	 * @throws Exception the exception
  	 */
  	public String copyTechArchData(long processId,long tiRequestId,String requestType) throws Exception;
	  
  	/**
  	 * Abort tech arch data.
  	 *
  	 * @param processId the process id
  	 * @param tiRequestId the ti request id
  	 * @throws Exception the exception
  	 */
  	public void abortTechArchData(long processId,long tiRequestId) throws Exception;
	  
  	/**
  	 * Update schedule date.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @param activityCode the activity code
  	 * @param scheduleDate the schedule date
  	 * @throws Exception the exception
  	 */
  	public void updateScheduleDate(long tiRequestId,String activityCode,Date scheduleDate) throws Exception;
	  
	  /**
  	 * Checks if is manager approval required.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @return true, if is manager approval required
  	 * @throws Exception the exception
  	 */
  	public boolean isManagerApprovalRequired(long tiRequestId) throws Exception;
	  
  	/**
  	 * Checks if is request rolled back.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @return true, if is request rolled back
  	 * @throws Exception the exception
  	 */
  	public boolean isRequestRolledBack(long tiRequestId)  throws Exception;
	  
  	/**
  	 * Checks if is bulk request.
  	 *
  	 * @param tiRequestId the ti request id
  	 * @return true, if is bulk request
  	 * @throws Exception the exception
  	 */
  	public boolean isBulkRequest(long tiRequestId) throws Exception;
	  
  	/**
  	 * Manage user contacts process.
  	 *
  	 * @param processDTO the process dto
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long  manageUserContactsProcess(TIProcessDTO processDTO) throws Exception ;
  	
  	/**
  	 * Copy Uploaded documents to next cycle.
  	 * 
  	 * @param processId
  	 * @param tiRequestId
  	 * @return
  	 * @throws Exception 
  	 */
  	public String copyUploadedDocuments(long processId, long tiRequestId) throws Exception;
  	
  	public String getTiRequestAuditVersion(long tirequestId) throws Exception ;
  	public boolean verifySOWUpdate(long tiRequestId, String verificationFlag, String SOW) throws Exception;
  	
  	Date getHoldingPeriod(long tiRequestId)  throws Exception;
  
}
