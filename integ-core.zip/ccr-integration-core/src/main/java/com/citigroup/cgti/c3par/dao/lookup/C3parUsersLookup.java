

/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright ? 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.dao.lookup;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;


/**
 * The Class C3parUsersLookup.
 */
public class C3parUsersLookup
{

    /** The initialized. */
    private boolean		initialized = false;

    /** The ordered list. */
    private ArrayList 	orderedList = new ArrayList();

    /** The values by id. */
    private HashMap		valuesById = new HashMap();

    /** The values by sso id. */
    private HashMap		valuesBySsoId = new HashMap();

    /** The values by first name. */
    private HashMap		valuesByFirstName = new HashMap();

    /** The values by last name. */
    private HashMap		valuesByLastName = new HashMap();

    /** The values by description. */
    private HashMap		valuesByDescription = new HashMap();

    /** The values by is active. */
    private HashMap		valuesByIsActive = new HashMap();

    /** The values by is admin. */
    private HashMap		valuesByIsAdmin = new HashMap();

    /** The values by password. */
    private HashMap		valuesByPassword = new HashMap();

    /** The values by email. */
    private HashMap		valuesByEmail = new HashMap();

    /** The values by created user. */
    private HashMap		valuesByCreatedUser = new HashMap();

    /** The values by created date. */
    private HashMap		valuesByCreatedDate = new HashMap();

    /** The values by updated user. */
    private HashMap		valuesByUpdatedUser = new HashMap();

    /** The values by updated date. */
    private HashMap		valuesByUpdatedDate = new HashMap();

    /** The values by wf status. */
    private HashMap		valuesByWfStatus = new HashMap();

    /** The values by non employee. */
    private HashMap		valuesByNonEmployee = new HashMap();

    /** The values by requested by. */
    private HashMap		valuesByRequestedBy = new HashMap();

    /** The values by isa approver. */
    private HashMap		valuesByIsaApprover = new HashMap();

    /** The values by manager approver. */
    private HashMap		valuesByManagerApprover = new HashMap();

    /** The values by rejection comments. */
    private HashMap		valuesByRejectionComments = new HashMap();

    /** The values by activated date. */
    private HashMap		valuesByActivatedDate = new HashMap();

    /** The values by mgr reviewed date. */
    private HashMap		valuesByMgrReviewedDate = new HashMap();

    /** The values by isa reviewed date. */
    private HashMap		valuesByIsaReviewedDate = new HashMap();

    /** The values by requested date. */
    private HashMap		valuesByRequestedDate = new HashMap();

    /** The values by sysadmin approver. */
    private HashMap		valuesBySysadminApprover = new HashMap();

    /** The values by sysadmin reviewed date. */
    private HashMap		valuesBySysadminReviewedDate = new HashMap();

    /** The instance. */
    static private C3parUsersLookup instance = null;

    //======================================================================
    /**
     * Gets the single instance of C3parUsersLookup.
     *
     * @return single instance of C3parUsersLookup
     */
    synchronized static public C3parUsersLookup getInstance()
    {
	if (instance == null)
	{
	    instance = new C3parUsersLookup();
	}
	return instance;
    }

    //======================================================================
    /**
     * Gets the single instance of C3parUsersLookup.
     *
     * @param session the session
     * @return single instance of C3parUsersLookup
     * @throws DatabaseException the database exception
     */
    synchronized static public C3parUsersLookup getInstance(DatabaseSession session) throws DatabaseException
    {
	if (instance == null)
	{
	    instance = new C3parUsersLookup();
	    instance.initialize(session);	
	}
	else if(!instance.isInitialized())
	{
	    instance.initialize(session);	
	}
	return instance;
    }

    //======================================================================
    /**
     * Instantiates a new c3par users lookup.
     */
    private C3parUsersLookup()
    {
	super();
	initialized = false;
    }

    //======================================================================
    /**
     * Initialize.
     *
     * @param session the session
     * @throws DatabaseException the database exception
     */
    synchronized public void initialize(DatabaseSession session) throws DatabaseException
    {
	if (!initialized)
	{
	    C3parUsersDAO dao = new C3parUsersDAO(session);
	    C3parUsersEntity entity = null;
	    Condition condition = new Condition();
	    condition.addOrderByField(C3parUsersDAO.COLUMN_SSOID);
	    try
	    {
		List list = dao.query(condition, false);
		Iterator it = list.iterator();

		while (it.hasNext())
		{
		    entity = (C3parUsersEntity) it.next();
		    valuesById.put(entity.getId(), entity);
		    valuesBySsoId.put(entity.getSsoId(), entity);
		    valuesByFirstName.put(entity.getFirstName(), entity);
		    valuesByLastName.put(entity.getLastName(), entity);
		    valuesByDescription.put(entity.getDescription(), entity);
		    valuesByIsActive.put(entity.getIsActive(), entity);
		    valuesByIsAdmin.put(entity.getIsAdmin(), entity);
		    valuesByPassword.put(entity.getPassword(), entity);
		    valuesByEmail.put(entity.getEmail(), entity);
		    valuesByCreatedUser.put(entity.getCreatedUser(), entity);
		    valuesByCreatedDate.put(entity.getCreatedDate(), entity);
		    valuesByUpdatedUser.put(entity.getUpdatedUser(), entity);
		    valuesByUpdatedDate.put(entity.getUpdatedDate(), entity);
		    valuesByWfStatus.put(entity.getWfStatus(), entity);
		    valuesByNonEmployee.put(entity.getNonEmployee(), entity);
		    valuesByRequestedBy.put(entity.getRequestedBy(), entity);
		    valuesByIsaApprover.put(entity.getIsaApprover(), entity);
		    valuesByManagerApprover.put(entity.getManagerApprover(), entity);
		    valuesByRejectionComments.put(entity.getRejectionComments(), entity);
		    valuesByActivatedDate.put(entity.getActivatedDate(), entity);
		    valuesByMgrReviewedDate.put(entity.getMgrReviewedDate(), entity);
		    valuesByIsaReviewedDate.put(entity.getIsaReviewedDate(), entity);
		    valuesByRequestedDate.put(entity.getRequestedDate(), entity);
		    valuesBySysadminApprover.put(entity.getSysadminApprover(), entity);
		    valuesBySysadminReviewedDate.put(entity.getSysadminReviewedDate(), entity);
		    orderedList.add(entity);
		}
		initialized = true;

		it = list.iterator();
		while (it.hasNext())
		{
		    entity = (C3parUsersEntity) it.next();
		    dao.loadReferences((C3parUsersEntity)entity);
		}
	    }
	    catch (DatabaseException e)
	    {
		throw e;
	    }
	}
    }

    //======================================================================
    /**
     * Reset.
     */
    synchronized public void reset()
    {
	valuesById = new HashMap();
	orderedList = new ArrayList();
	initialized = false;
	valuesBySsoId = new HashMap();
	valuesByFirstName = new HashMap();
	valuesByLastName = new HashMap();
	valuesByDescription = new HashMap();
	valuesByIsActive = new HashMap();
	valuesByIsAdmin = new HashMap();
	valuesByPassword = new HashMap();
	valuesByEmail = new HashMap();
	valuesByCreatedUser = new HashMap();
	valuesByCreatedDate = new HashMap();
	valuesByUpdatedUser = new HashMap();
	valuesByUpdatedDate = new HashMap();
	valuesByWfStatus = new HashMap();
	valuesByNonEmployee = new HashMap();
	valuesByRequestedBy = new HashMap();
	valuesByIsaApprover = new HashMap();
	valuesByManagerApprover = new HashMap();
	valuesByRejectionComments = new HashMap();
	valuesByActivatedDate = new HashMap();
	valuesByMgrReviewedDate = new HashMap();
	valuesByIsaReviewedDate = new HashMap();
	valuesByRequestedDate = new HashMap();
	valuesBySysadminApprover = new HashMap();
	valuesBySysadminReviewedDate = new HashMap();
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param id the id
     * @return the by id
     */
    synchronized public C3parUsersEntity getById(Long id)
    {
	return (C3parUsersEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param session the session
     * @param id the id
     * @return the by id
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getById(DatabaseSession session, Long id) throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by sso id.
     *
     * @param v the v
     * @return the by sso id
     */
    synchronized public C3parUsersEntity getBySsoId(String v)
    {
	return (C3parUsersEntity) valuesBySsoId.get(v);
    }

    //======================================================================
    /**
     * Gets the by sso id.
     *
     * @param session the session
     * @param v the v
     * @return the by sso id
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getBySsoId(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesBySsoId.get(v);
    }
    //======================================================================
    /**
     * Gets the by first name.
     *
     * @param v the v
     * @return the by first name
     */
    synchronized public C3parUsersEntity getByFirstName(String v)
    {
	return (C3parUsersEntity) valuesByFirstName.get(v);
    }

    //======================================================================
    /**
     * Gets the by first name.
     *
     * @param session the session
     * @param v the v
     * @return the by first name
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByFirstName(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByFirstName.get(v);
    }
    //======================================================================
    /**
     * Gets the by last name.
     *
     * @param v the v
     * @return the by last name
     */
    synchronized public C3parUsersEntity getByLastName(String v)
    {
	return (C3parUsersEntity) valuesByLastName.get(v);
    }

    //======================================================================
    /**
     * Gets the by last name.
     *
     * @param session the session
     * @param v the v
     * @return the by last name
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByLastName(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByLastName.get(v);
    }
    //======================================================================
    /**
     * Gets the by description.
     *
     * @param v the v
     * @return the by description
     */
    synchronized public C3parUsersEntity getByDescription(String v)
    {
	return (C3parUsersEntity) valuesByDescription.get(v);
    }

    //======================================================================
    /**
     * Gets the by description.
     *
     * @param session the session
     * @param v the v
     * @return the by description
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByDescription(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByDescription.get(v);
    }
    //======================================================================
    /**
     * Gets the by is active.
     *
     * @param v the v
     * @return the by is active
     */
    synchronized public C3parUsersEntity getByIsActive(String v)
    {
	return (C3parUsersEntity) valuesByIsActive.get(v);
    }

    //======================================================================
    /**
     * Gets the by is active.
     *
     * @param session the session
     * @param v the v
     * @return the by is active
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByIsActive(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByIsActive.get(v);
    }
    //======================================================================
    /**
     * Gets the by is admin.
     *
     * @param v the v
     * @return the by is admin
     */
    synchronized public C3parUsersEntity getByIsAdmin(Boolean v)
    {
	return (C3parUsersEntity) valuesByIsAdmin.get(v);
    }

    //======================================================================
    /**
     * Gets the by is admin.
     *
     * @param session the session
     * @param v the v
     * @return the by is admin
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByIsAdmin(DatabaseSession session, Boolean v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByIsAdmin.get(v);
    }
    //======================================================================
    /**
     * Gets the by password.
     *
     * @param v the v
     * @return the by password
     */
    synchronized public C3parUsersEntity getByPassword(String v)
    {
	return (C3parUsersEntity) valuesByPassword.get(v);
    }

    //======================================================================
    /**
     * Gets the by password.
     *
     * @param session the session
     * @param v the v
     * @return the by password
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByPassword(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByPassword.get(v);
    }
    //======================================================================
    /**
     * Gets the by email.
     *
     * @param v the v
     * @return the by email
     */
    synchronized public C3parUsersEntity getByEmail(String v)
    {
	return (C3parUsersEntity) valuesByEmail.get(v);
    }

    //======================================================================
    /**
     * Gets the by email.
     *
     * @param session the session
     * @param v the v
     * @return the by email
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByEmail(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByEmail.get(v);
    }
    //======================================================================
    /**
     * Gets the by created user.
     *
     * @param v the v
     * @return the by created user
     */
    synchronized public C3parUsersEntity getByCreatedUser(String v)
    {
	return (C3parUsersEntity) valuesByCreatedUser.get(v);
    }

    //======================================================================
    /**
     * Gets the by created user.
     *
     * @param session the session
     * @param v the v
     * @return the by created user
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByCreatedUser(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByCreatedUser.get(v);
    }
    //======================================================================
    /**
     * Gets the by created date.
     *
     * @param v the v
     * @return the by created date
     */
    synchronized public C3parUsersEntity getByCreatedDate(Date v)
    {
	return (C3parUsersEntity) valuesByCreatedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the by created date.
     *
     * @param session the session
     * @param v the v
     * @return the by created date
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByCreatedDate(DatabaseSession session, Date v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByCreatedDate.get(v);
    }
    //======================================================================
    /**
     * Gets the by updated user.
     *
     * @param v the v
     * @return the by updated user
     */
    synchronized public C3parUsersEntity getByUpdatedUser(String v)
    {
	return (C3parUsersEntity) valuesByUpdatedUser.get(v);
    }

    //======================================================================
    /**
     * Gets the by updated user.
     *
     * @param session the session
     * @param v the v
     * @return the by updated user
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByUpdatedUser(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByUpdatedUser.get(v);
    }
    //======================================================================
    /**
     * Gets the by updated date.
     *
     * @param v the v
     * @return the by updated date
     */
    synchronized public C3parUsersEntity getByUpdatedDate(Date v)
    {
	return (C3parUsersEntity) valuesByUpdatedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the by updated date.
     *
     * @param session the session
     * @param v the v
     * @return the by updated date
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByUpdatedDate(DatabaseSession session, Date v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByUpdatedDate.get(v);
    }
    //======================================================================
    /**
     * Gets the by wf status.
     *
     * @param v the v
     * @return the by wf status
     */
    synchronized public C3parUsersEntity getByWfStatus(String v)
    {
	return (C3parUsersEntity) valuesByWfStatus.get(v);
    }

    //======================================================================
    /**
     * Gets the by wf status.
     *
     * @param session the session
     * @param v the v
     * @return the by wf status
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByWfStatus(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByWfStatus.get(v);
    }
    //======================================================================
    /**
     * Gets the by non employee.
     *
     * @param v the v
     * @return the by non employee
     */
    synchronized public C3parUsersEntity getByNonEmployee(String v)
    {
	return (C3parUsersEntity) valuesByNonEmployee.get(v);
    }

    //======================================================================
    /**
     * Gets the by non employee.
     *
     * @param session the session
     * @param v the v
     * @return the by non employee
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByNonEmployee(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByNonEmployee.get(v);
    }
    //======================================================================
    /**
     * Gets the by requested by.
     *
     * @param v the v
     * @return the by requested by
     */
    synchronized public C3parUsersEntity getByRequestedBy(String v)
    {
	return (C3parUsersEntity) valuesByRequestedBy.get(v);
    }

    //======================================================================
    /**
     * Gets the by requested by.
     *
     * @param session the session
     * @param v the v
     * @return the by requested by
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByRequestedBy(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByRequestedBy.get(v);
    }
    //======================================================================
    /**
     * Gets the by isa approver.
     *
     * @param v the v
     * @return the by isa approver
     */
    synchronized public C3parUsersEntity getByIsaApprover(String v)
    {
	return (C3parUsersEntity) valuesByIsaApprover.get(v);
    }

    //======================================================================
    /**
     * Gets the by isa approver.
     *
     * @param session the session
     * @param v the v
     * @return the by isa approver
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByIsaApprover(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByIsaApprover.get(v);
    }
    //======================================================================
    /**
     * Gets the by manager approver.
     *
     * @param v the v
     * @return the by manager approver
     */
    synchronized public C3parUsersEntity getByManagerApprover(String v)
    {
	return (C3parUsersEntity) valuesByManagerApprover.get(v);
    }

    //======================================================================
    /**
     * Gets the by manager approver.
     *
     * @param session the session
     * @param v the v
     * @return the by manager approver
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByManagerApprover(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByManagerApprover.get(v);
    }
    //======================================================================
    /**
     * Gets the by rejection comments.
     *
     * @param v the v
     * @return the by rejection comments
     */
    synchronized public C3parUsersEntity getByRejectionComments(String v)
    {
	return (C3parUsersEntity) valuesByRejectionComments.get(v);
    }

    //======================================================================
    /**
     * Gets the by rejection comments.
     *
     * @param session the session
     * @param v the v
     * @return the by rejection comments
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByRejectionComments(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByRejectionComments.get(v);
    }
    //======================================================================
    /**
     * Gets the by activated date.
     *
     * @param v the v
     * @return the by activated date
     */
    synchronized public C3parUsersEntity getByActivatedDate(Date v)
    {
	return (C3parUsersEntity) valuesByActivatedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the by activated date.
     *
     * @param session the session
     * @param v the v
     * @return the by activated date
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByActivatedDate(DatabaseSession session, Date v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByActivatedDate.get(v);
    }
    //======================================================================
    /**
     * Gets the by mgr reviewed date.
     *
     * @param v the v
     * @return the by mgr reviewed date
     */
    synchronized public C3parUsersEntity getByMgrReviewedDate(Date v)
    {
	return (C3parUsersEntity) valuesByMgrReviewedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the by mgr reviewed date.
     *
     * @param session the session
     * @param v the v
     * @return the by mgr reviewed date
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByMgrReviewedDate(DatabaseSession session, Date v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByMgrReviewedDate.get(v);
    }
    //======================================================================
    /**
     * Gets the by isa reviewed date.
     *
     * @param v the v
     * @return the by isa reviewed date
     */
    synchronized public C3parUsersEntity getByIsaReviewedDate(Date v)
    {
	return (C3parUsersEntity) valuesByIsaReviewedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the by isa reviewed date.
     *
     * @param session the session
     * @param v the v
     * @return the by isa reviewed date
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByIsaReviewedDate(DatabaseSession session, Date v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByIsaReviewedDate.get(v);
    }
    //======================================================================
    /**
     * Gets the by requested date.
     *
     * @param v the v
     * @return the by requested date
     */
    synchronized public C3parUsersEntity getByRequestedDate(Date v)
    {
	return (C3parUsersEntity) valuesByRequestedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the by requested date.
     *
     * @param session the session
     * @param v the v
     * @return the by requested date
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getByRequestedDate(DatabaseSession session, Date v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesByRequestedDate.get(v);
    }
    //======================================================================
    /**
     * Gets the by sysadmin approver.
     *
     * @param v the v
     * @return the by sysadmin approver
     */
    synchronized public C3parUsersEntity getBySysadminApprover(String v)
    {
	return (C3parUsersEntity) valuesBySysadminApprover.get(v);
    }

    //======================================================================
    /**
     * Gets the by sysadmin approver.
     *
     * @param session the session
     * @param v the v
     * @return the by sysadmin approver
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getBySysadminApprover(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesBySysadminApprover.get(v);
    }
    //======================================================================
    /**
     * Gets the by sysadmin reviewed date.
     *
     * @param v the v
     * @return the by sysadmin reviewed date
     */
    synchronized public C3parUsersEntity getBySysadminReviewedDate(Date v)
    {
	return (C3parUsersEntity) valuesBySysadminReviewedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the by sysadmin reviewed date.
     *
     * @param session the session
     * @param v the v
     * @return the by sysadmin reviewed date
     * @throws DatabaseException the database exception
     */
    synchronized public C3parUsersEntity getBySysadminReviewedDate(DatabaseSession session, Date v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (C3parUsersEntity) valuesBySysadminReviewedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the all.
     *
     * @return the all
     */
    synchronized public ArrayList getAll()
    {
	return orderedList;
    }

    //======================================================================
    /**
     * Checks if is initialized.
     *
     * @return true, if is initialized
     */
    synchronized public boolean isInitialized()
    {
	return initialized;
    }
}
