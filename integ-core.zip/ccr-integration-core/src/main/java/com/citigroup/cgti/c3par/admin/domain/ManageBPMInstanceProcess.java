package com.citigroup.cgti.c3par.admin.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityBPMDTO;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;


public class ManageBPMInstanceProcess {
	
   CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

	private Long processID;
	
	private String activity;
	
	private String newActivity;
	
	private String action;
	
	private Long tiReq;
	
	private List<ActivityBPMDTO> activityBpm;
	
	public ActivityBPMDTO activityDTO;
	
	private String delete;
	
	private String add;
	
	
	public String getDelete() {
		return delete;
	}

	public void setDelete(String delete) {
		this.delete = delete;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	public Long getTiReq() {
		return tiReq;
	}

	public void setTiReq(Long tiReq) {
		this.tiReq = tiReq;
	}

	public String getNewActivity() {
		return newActivity;
	}

	public void setNewActivity(String newActivity) {
		this.newActivity = newActivity;
	}

	public ActivityBPMDTO getActivityDTO() {
		return activityDTO;
	}

	public void setActivityDTO(ActivityBPMDTO activityDTO) {
		this.activityDTO = activityDTO;
	}

	public List<ActivityBPMDTO> getActivityBpm() {
		return activityBpm;
	}

	public void setActivityBpm(List<ActivityBPMDTO> activityBpm) {
		this.activityBpm = activityBpm;
	}

	public Long getProcessID() {
		return processID;
	}

	public void setProcessID(Long processID) {
		this.processID = processID;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	
	
	public List<ActivityBPMDTO> getActivityDetails(Long processID) {
		return ccrBeanFactory.getCommonServicePersistable().getActivity(processID);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateInstance(Long processID,String activityID) {
		ccrBeanFactory.getCommonServicePersistable().updateInstance(processID,activityID);
	}

	
	public List<ActivityBPMDTO> getAllActivityDetails() {
		return ccrBeanFactory.getCommonServicePersistable().getAllActivity();
	}
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateActivityTrail(Long activityTrailId) {
		ccrBeanFactory.getCommonServicePersistable().updateActivityTrail(activityTrailId);
		
	}

}
