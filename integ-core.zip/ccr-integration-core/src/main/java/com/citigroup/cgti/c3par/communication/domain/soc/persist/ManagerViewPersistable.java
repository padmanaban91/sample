package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.communication.domain.ManagerViewProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface ManagerViewPersistable extends Persistable {

	public Map<String, List<ManagerViewProcess>> getDetails();

}