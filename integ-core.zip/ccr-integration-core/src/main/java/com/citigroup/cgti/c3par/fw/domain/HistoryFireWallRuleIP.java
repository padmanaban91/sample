/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * 
 * @author ne36745
 *
 */
public class HistoryFireWallRuleIP extends Base {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private HistoryFireWallRule fireWallRule;
    private TIRequest updatedTIRequest;
    private TIRequest deletedTIRequest;
    private IPAddress ipAddress;
    private String NAT;
    private String resourceType;
    private Long objRuleID;

    /**
     * @return the fireWallRule
     */
    public HistoryFireWallRule getFireWallRule() {
	return fireWallRule;
    }

    /**
     * @param fireWallRule the fireWallRule to set
     */
    public void setFireWallRule(HistoryFireWallRule fireWallRule) {
	this.fireWallRule = fireWallRule;
    }

    /**
     * @return the updatedTIRequest
     */
    public TIRequest getUpdatedTIRequest() {
	return updatedTIRequest;
    }

    /**
     * @param updatedTIRequest the updatedTIRequest to set
     */
    public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
	this.updatedTIRequest = updatedTIRequest;
    }

    /**
     * @return the deletedTIRequest
     */
    public TIRequest getDeletedTIRequest() {
	return deletedTIRequest;
    }

    /**
     * @param deletedTIRequest the deletedTIRequest to set
     */
    public void setDeletedTIRequest(TIRequest deletedTIRequest) {
	this.deletedTIRequest = deletedTIRequest;
    }

    /**
     * @return the ipAddress
     */
    public IPAddress getIpAddress() {
	return ipAddress;
    }

    /**
     * @param ipAddress the ipAddress to set
     */
    public void setIpAddress(IPAddress ipAddress) {
	this.ipAddress = ipAddress;
    }

    /**
     * @return the nAT
     */
    public String getNAT() {
	return NAT;
    }

    /**
     * @param nAT the nAT to set
     */
    public void setNAT(String nAT) {
	NAT = nAT;
    }

	/**
	 * @return the resourceType
	 */
	public String getResourceType() {
		return resourceType;
	}

	/**
	 * @param resourceType the resourceType to set
	 */
	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	public Long getObjRuleID() {
		return objRuleID;
	}

	public void setObjRuleID(Long objRuleID) {
		this.objRuleID = objRuleID;
	}
    
}
