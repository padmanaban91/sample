/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.sql.Timestamp;

import org.springframework.format.annotation.DateTimeFormat;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class Firewall.
 */
public class Firewall extends Base {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The check point name. */
    private String firewallName;

    /** The firewall policy. */
    private FirewallPolicy firewallPolicy;

    /** The type. */
    private String netInfoType;

    /** The ip address. */
    private String ipAddress;

    /** The building name. */
    private String buildingName;

    /** The address1. */
    private String address;

    /** The city. */
    private String city;

    /** The county. */
    private String county;

    /** The country. */
    private String country;

    /** The region. */
    private String region;

    /** The approver groups. */
    private String approverGroups;

    /** The invalid approver groups. */
    private String invalidApproverGroups;

    /** The device id. */
    private String deviceId;

    /** The location. */
    private String location;

    /** The delete flag. */
    private String deleteFlag;
    
    private String lastUpdatedBy;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Timestamp lastUpdatedTimestamp;
    
    private String greenzoneStartTime;
    
	private String greenzoneEndTime;
    
    private String changeCABaApprover;
    
    private String timezone;
    
    private Timestamp createdDate;
    
    
    public String getGreenzoneStartTime() {
		return greenzoneStartTime;
	}

    public void setGreenzoneStartTime(String greenzoneStartTime) {
		this.greenzoneStartTime = greenzoneStartTime;
	}

	public String getGreenzoneEndTime() {
		return greenzoneEndTime;
	}

	public void setGreenzoneEndTime(String greenzoneEndTime) {
		this.greenzoneEndTime = greenzoneEndTime;
	}

	public String getChangeCABaApprover() {
		return changeCABaApprover;
	}

	public void setChangeCABaApprover(String changeCABaApprover) {
		this.changeCABaApprover = changeCABaApprover;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
    
    public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}


	/**
	 * Gets the firewall name.
	 *
	 * @return the firewall name
	 */
	public String getFirewallName() {
		return firewallName;
	}

	/**
	 * Sets the firewall name.
	 *
	 * @param firewallName the new firewall name
	 */
	public void setFirewallName(String firewallName) {
		this.firewallName = firewallName;
	}

	/**
	 * Gets the firewall policy.
	 *
	 * @return the firewall policy
	 */
	public FirewallPolicy getFirewallPolicy() {
		return firewallPolicy;
	}

	/**
	 * Sets the firewall policy.
	 *
	 * @param firewallPolicy the new firewall policy
	 */
	public void setFirewallPolicy(FirewallPolicy firewallPolicy) {
		this.firewallPolicy = firewallPolicy;
	}

	/**
	 * Gets the net info type.
	 *
	 * @return the net info type
	 */
	public String getNetInfoType() {
		return netInfoType;
	}

	/**
	 * Sets the net info type.
	 *
	 * @param netInfoType the new net info type
	 */
	public void setNetInfoType(String netInfoType) {
		this.netInfoType = netInfoType;
	}

	/**
	 * Gets the ip address.
	 *
	 * @return the ip address
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * Sets the ip address.
	 *
	 * @param ipAddress the new ip address
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * Gets the building name.
	 *
	 * @return the building name
	 */
	public String getBuildingName() {
		return buildingName;
	}

	/**
	 * Sets the building name.
	 *
	 * @param buildingName the new building name
	 */
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Sets the city.
	 *
	 * @param city the new city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets the county.
	 *
	 * @return the county
	 */
	public String getCounty() {
		return county;
	}

	/**
	 * Sets the county.
	 *
	 * @param county the new county
	 */
	public void setCounty(String county) {
		this.county = county;
	}

	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Sets the country.
	 *
	 * @param country the new country
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Gets the region.
	 *
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * Sets the region.
	 *
	 * @param region the new region
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * Gets the approver groups.
	 *
	 * @return the approver groups
	 */
	public String getApproverGroups() {
		return approverGroups;
	}

	/**
	 * Sets the approver groups.
	 *
	 * @param approverGroups the new approver groups
	 */
	public void setApproverGroups(String approverGroups) {
		this.approverGroups = approverGroups;
	}

	/**
	 * Gets the invalid approver groups.
	 *
	 * @return the invalid approver groups
	 */
	public String getInvalidApproverGroups() {
		return invalidApproverGroups;
	}

	/**
	 * Sets the invalid approver groups.
	 *
	 * @param invalidApproverGroups the new invalid approver groups
	 */
	public void setInvalidApproverGroups(String invalidApproverGroups) {
		this.invalidApproverGroups = invalidApproverGroups;
	}

	/**
	 * Gets the device id.
	 *
	 * @return the device id
	 */
	public String getDeviceId() {
		return deviceId;
	}

	/**
	 * Sets the device id.
	 *
	 * @param deviceId the new device id
	 */
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * Gets the delete flag.
	 *
	 * @return the delete flag
	 */
	public String getDeleteFlag() {
		return deleteFlag;
	}

	/**
	 * Sets the delete flag.
	 *
	 * @param deleteFlag the new delete flag
	 */
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public String toString(){
		return firewallName; 
	}
}
