/*
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.user.domain.C3parUser;


/**
 * The Class TIRequest.
 *
 * @author dr97938
 */
@SuppressWarnings("unchecked")
public class TIRequest extends Base implements Serializable{

    private static final long serialVersionUID = 1L;

    public static final String CREATE = "Create";

    public static final String MAINTAIN = "Maintain";

    public static final String TERMINATE = "Teminate";

    public static final String ACV = "ACV";

    public static final String BAU="BAU";

    public static final String BUSCRIT="BUSCRIT";

    public static final String EMER="EMER";

        
	private C3parUser user;

    private TIProcess tiProcess;

    private TIRequestType tiRequestType=new TIRequestType();

    private Integer versionNumber;
    
    private GenericLookup priority = new GenericLookup();
    
    private String isdeleted;

    private	Date plannedCompletionDate;
    
    private	Date completionDate;

    private Date requestDeadline;

    private String scheduledEmailFlag;

    private String iscitiRiskAssessed;
    
    private String tpwappReviewType;
    
    private String tpwappReviewStatus;

    private Date TPASWGReviewDate;
    
    private Date TPASWGRejectedDate;

    private Long infomanID;

    private Date opeImpScheduledDate;

    private Date opeImpCompletedDate;

    private String emerBuscritJustification;

    private String altBussMethods;

    private String reqNewAccess;

    private String vtTicketNo;

    private Date TPASWGTempApprovalDate;

    private String annaualVerFlag;

    private String sowNumber;

    private Date apsImpScheduledDate;

    private Date apsImpCompletedDate;

    private Long apsInfomanId;

    private Date prxImpScheduledDate;

    private Date prxImpCompletedDate;

    private Long prxInfomanId;

	private String cmpId;

    private Date gnccImpScheduledDate;

    private Date gnccImpCompletedDate;

    private Long gnccInfomanId;

    private String fireflowJMSSentFlag;

    private String directorAppComments;

    private String fireflowFlag;

    private String rfcGenFlag;

    private String riskExeStatus;

    private String snowId;

    private String ipRfcGenFlag;

    private Date ipregImpScheduledDate;

    private Date ipregImpCompletedDate;

    private Date loggingUntil;

    private Long reclogPrd;

    private String enggcmpId;

    //other than TI_REQUEST table fields
    private Status tiRequestStatus=new Status();
    
    private ActivityData activityData=new ActivityData();

    private List activityDataList = new ArrayList();

    private String busJusParticipants;

    private String tecArcParticipants;

    private List suppReviewRoles= new ArrayList();

    private String activityStartDate;

    private String netInfomanId;

    private String isHighRisk;

    private String isBroadAccess;

    private String tpaFlag;
    private String ofacFlag;
    
    

    
    
	public String getOfacFlag() {
		return ofacFlag;
	}

	public void setOfacFlag(String ofacFlag) {
		this.ofacFlag = ofacFlag;
	}

	public C3parUser getUser() {
		return user;
	}

	public void setUser(C3parUser user) {
		this.user = user;
	}

	public TIProcess getTiProcess() {
		return tiProcess;
	}

	public void setTiProcess(TIProcess tiProcess) {
		this.tiProcess = tiProcess;
	}

	public TIRequestType getTiRequestType() {
		return tiRequestType;
	}

	public void setTiRequestType(TIRequestType tiRequestType) {
		this.tiRequestType = tiRequestType;
	}

	public Integer getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(Integer versionNumber) {
		this.versionNumber = versionNumber;
	}

	public GenericLookup getPriority() {
		return priority;
	}

	public void setPriority(GenericLookup priority) {
		this.priority = priority;
	}

	public String getIsdeleted() {
		return isdeleted;
	}

	public void setIsdeleted(String isdeleted) {
		this.isdeleted = isdeleted;
	}

	public Date getPlannedCompletionDate() {
		return plannedCompletionDate;
	}

	public void setPlannedCompletionDate(Date plannedCompletionDate) {
		this.plannedCompletionDate = plannedCompletionDate;
	}

	public Date getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(Date completionDate) {
		this.completionDate = completionDate;
	}

	public Date getRequestDeadline() {
		return requestDeadline;
	}

	public void setRequestDeadline(Date requestDeadline) {
		this.requestDeadline = requestDeadline;
	}

	public String getScheduledEmailFlag() {
		return scheduledEmailFlag;
	}

	public void setScheduledEmailFlag(String scheduledEmailFlag) {
		this.scheduledEmailFlag = scheduledEmailFlag;
	}

	public String getIscitiRiskAssessed() {
		return iscitiRiskAssessed;
	}

	public void setIscitiRiskAssessed(String iscitiRiskAssessed) {
		this.iscitiRiskAssessed = iscitiRiskAssessed;
	}

	public String getTpwappReviewType() {
		return tpwappReviewType;
	}

	public void setTpwappReviewType(String tpwappReviewType) {
		this.tpwappReviewType = tpwappReviewType;
	}

	public String getTpwappReviewStatus() {
		return tpwappReviewStatus;
	}

	public void setTpwappReviewStatus(String tpwappReviewStatus) {
		this.tpwappReviewStatus = tpwappReviewStatus;
	}

	public Date getTPASWGReviewDate() {
		return TPASWGReviewDate;
	}

	public void setTPASWGReviewDate(Date tPASWGReviewDate) {
		TPASWGReviewDate = tPASWGReviewDate;
	}

	public Date getTPASWGRejectedDate() {
		return TPASWGRejectedDate;
	}

	public void setTPASWGRejectedDate(Date tPASWGRejectedDate) {
		TPASWGRejectedDate = tPASWGRejectedDate;
	}

	public Long getInfomanID() {
		return infomanID;
	}

	public void setInfomanID(Long infomanID) {
		this.infomanID = infomanID;
	}

	public Date getOpeImpScheduledDate() {
		return opeImpScheduledDate;
	}

	public void setOpeImpScheduledDate(Date opeImpScheduledDate) {
		this.opeImpScheduledDate = opeImpScheduledDate;
	}

	public Date getOpeImpCompletedDate() {
		return opeImpCompletedDate;
	}

	public void setOpeImpCompletedDate(Date opeImpCompletedDate) {
		this.opeImpCompletedDate = opeImpCompletedDate;
	}

	public String getEmerBuscritJustification() {
		return emerBuscritJustification;
	}

	public void setEmerBuscritJustification(String emerBuscritJustification) {
		this.emerBuscritJustification = emerBuscritJustification;
	}

	public String getAltBussMethods() {
		return altBussMethods;
	}

	public void setAltBussMethods(String altBussMethods) {
		this.altBussMethods = altBussMethods;
	}

	public String getReqNewAccess() {
		return reqNewAccess;
	}

	public void setReqNewAccess(String reqNewAccess) {
		this.reqNewAccess = reqNewAccess;
	}

	public String getVtTicketNo() {
		return vtTicketNo;
	}

	public void setVtTicketNo(String vtTicketNo) {
		this.vtTicketNo = vtTicketNo;
	}

	public Date getTPASWGTempApprovalDate() {
		return TPASWGTempApprovalDate;
	}

	public void setTPASWGTempApprovalDate(Date tPASWGTempApprovalDate) {
		TPASWGTempApprovalDate = tPASWGTempApprovalDate;
	}

	public String getAnnaualVerFlag() {
		return annaualVerFlag;
	}

	public void setAnnaualVerFlag(String annaualVerFlag) {
		this.annaualVerFlag = annaualVerFlag;
	}

	public String getSowNumber() {
		return sowNumber;
	}

	public void setSowNumber(String sowNumber) {
		this.sowNumber = sowNumber;
	}

	public Date getApsImpScheduledDate() {
		return apsImpScheduledDate;
	}

	public void setApsImpScheduledDate(Date apsImpScheduledDate) {
		this.apsImpScheduledDate = apsImpScheduledDate;
	}

	public Date getApsImpCompletedDate() {
		return apsImpCompletedDate;
	}

	public void setApsImpCompletedDate(Date apsImpCompletedDate) {
		this.apsImpCompletedDate = apsImpCompletedDate;
	}


	public Long getApsInfomanId() {
		return apsInfomanId;
	}

	public void setApsInfomanId(Long apsInfomanId) {
		this.apsInfomanId = apsInfomanId;
	}

	public Date getPrxImpScheduledDate() {
		return prxImpScheduledDate;
	}

	public void setPrxImpScheduledDate(Date prxImpScheduledDate) {
		this.prxImpScheduledDate = prxImpScheduledDate;
	}

	public Date getPrxImpCompletedDate() {
		return prxImpCompletedDate;
	}

	public void setPrxImpCompletedDate(Date prxImpCompletedDate) {
		this.prxImpCompletedDate = prxImpCompletedDate;
	}

	public Long getPrxInfomanId() {
		return prxInfomanId;
	}

	public void setPrxInfomanId(Long prxInfomanId) {
		this.prxInfomanId = prxInfomanId;
	}

	public String getCmpId() {
		return cmpId;
	}

	public void setCmpId(String cmpId) {
		this.cmpId = cmpId;
	}

	public Date getGnccImpScheduledDate() {
		return gnccImpScheduledDate;
	}

	public void setGnccImpScheduledDate(Date gnccImpScheduledDate) {
		this.gnccImpScheduledDate = gnccImpScheduledDate;
	}

	public Date getGnccImpCompletedDate() {
		return gnccImpCompletedDate;
	}

	public void setGnccImpCompletedDate(Date gnccImpCompletedDate) {
		this.gnccImpCompletedDate = gnccImpCompletedDate;
	}

	public Long getGnccInfomanId() {
		return gnccInfomanId;
	}

	public void setGnccInfomanId(Long gnccInfomanId) {
		this.gnccInfomanId = gnccInfomanId;
	}

	public String getFireflowJMSSentFlag() {
		return fireflowJMSSentFlag;
	}

	public void setFireflowJMSSentFlag(String fireflowJMSSentFlag) {
		this.fireflowJMSSentFlag = fireflowJMSSentFlag;
	}

	public String getDirectorAppComments() {
		return directorAppComments;
	}

	public void setDirectorAppComments(String directorAppComments) {
		this.directorAppComments = directorAppComments;
	}

	public String getFireflowFlag() {
		return fireflowFlag;
	}

	public void setFireflowFlag(String fireflowFlag) {
		this.fireflowFlag = fireflowFlag;
	}

	public String getRfcGenFlag() {
		return rfcGenFlag;
	}

	public void setRfcGenFlag(String rfcGenFlag) {
		this.rfcGenFlag = rfcGenFlag;
	}

	public String getRiskExeStatus() {
		return riskExeStatus;
	}

	public void setRiskExeStatus(String riskExeStatus) {
		this.riskExeStatus = riskExeStatus;
	}

	public String getSnowId() {
		return snowId;
	}

	public void setSnowId(String snowId) {
		this.snowId = snowId;
	}

	public String getIpRfcGenFlag() {
		return ipRfcGenFlag;
	}

	public void setIpRfcGenFlag(String ipRfcGenFlag) {
		this.ipRfcGenFlag = ipRfcGenFlag;
	}

	public Date getIpregImpScheduledDate() {
		return ipregImpScheduledDate;
	}

	public void setIpregImpScheduledDate(Date ipregImpScheduledDate) {
		this.ipregImpScheduledDate = ipregImpScheduledDate;
	}

	public Date getIpregImpCompletedDate() {
		return ipregImpCompletedDate;
	}

	public void setIpregImpCompletedDate(Date ipregImpCompletedDate) {
		this.ipregImpCompletedDate = ipregImpCompletedDate;
	}

	public Date getLoggingUntil() {
		return loggingUntil;
	}

	public void setLoggingUntil(Date loggingUntil) {
		this.loggingUntil = loggingUntil;
	}

	public Long getReclogPrd() {
		return reclogPrd;
	}

	public void setReclogPrd(Long reclogPrd) {
		this.reclogPrd = reclogPrd;
	}

	public String getEnggcmpId() {
		return enggcmpId;
	}

	public void setEnggcmpId(String enggcmpId) {
		this.enggcmpId = enggcmpId;
	}

	public Status getTiRequestStatus() {
		return tiRequestStatus;
	}

	public void setTiRequestStatus(Status tiRequestStatus) {
		this.tiRequestStatus = tiRequestStatus;
	}

	public ActivityData getActivityData() {
		return activityData;
	}

	public void setActivityData(ActivityData activityData) {
		this.activityData = activityData;
	}

	public List getActivityDataList() {
		return activityDataList;
	}

	public void setActivityDataList(List activityDataList) {
		this.activityDataList = activityDataList;
	}

	public String getBusJusParticipants() {
		return busJusParticipants;
	}

	public void setBusJusParticipants(String busJusParticipants) {
		this.busJusParticipants = busJusParticipants;
	}

	public String getTecArcParticipants() {
		return tecArcParticipants;
	}

	public void setTecArcParticipants(String tecArcParticipants) {
		this.tecArcParticipants = tecArcParticipants;
	}

	public List getSuppReviewRoles() {
		return suppReviewRoles;
	}

	public void setSuppReviewRoles(List suppReviewRoles) {
		this.suppReviewRoles = suppReviewRoles;
	}	

	public String getActivityStartDate() {
		return activityStartDate;
	}

	public void setActivityStartDate(String activityStartDate) {
		this.activityStartDate = activityStartDate;
	}

	public String getNetInfomanId() {
		return netInfomanId;
	}

	public void setNetInfomanId(String netInfomanId) {
		this.netInfomanId = netInfomanId;
	}

	public String getIsHighRisk() {
		return isHighRisk;
	}

	public void setIsHighRisk(String isHighRisk) {
		this.isHighRisk = isHighRisk;
	}

	public String getIsBroadAccess() {
		return isBroadAccess;
	}

	public void setIsBroadAccess(String isBroadAccess) {
		this.isBroadAccess = isBroadAccess;
	}

	public String getTpaFlag() {
		return tpaFlag;
	}

	public void setTpaFlag(String tpaFlag) {
		this.tpaFlag = tpaFlag;
	}

}