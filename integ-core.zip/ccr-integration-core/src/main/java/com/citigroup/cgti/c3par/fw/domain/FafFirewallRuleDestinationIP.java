/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

/**
 * @author bs45969
 *
 */
public class FafFirewallRuleDestinationIP extends FafFirewallRuleIP {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public FafFirewallRuleDestinationIP() {
	setCreated_date(new Date());
    }

}
