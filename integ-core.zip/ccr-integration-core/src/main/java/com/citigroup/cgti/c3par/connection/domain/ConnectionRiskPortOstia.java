package com.citigroup.cgti.c3par.connection.domain;


import java.util.Date;

import com.citigroup.cgti.c3par.appsense.domain.ConnectionOstiaGroup;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionRiskPortOstia.
 */
public class ConnectionRiskPortOstia extends PerformerPagerDO {
    //	private Long riskPortId;
    /** The ostia group. */
    private ConnectionOstiaGroup ostiaGroup;

    /** The risk flag. */
    private String riskFlag;

    /** The pair id. */
    private Long pairId;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /**
     * Instantiates a new connection risk port ostia.
     */
    public ConnectionRiskPortOstia() {


	addToNonPersistanceList("pairId");
	addToNonPersistanceList("riskFlag");
	//---------------------
	setTableName(PerformerTypes.CON_RISKPORT_OSTIA_TABLE);
	setSequenceName(PerformerTypes.CON_RISKPORT_OSTIA_SEQ);
	//---------------------
	//		addToDBMapping("riskPortId","risk_port_id");
	addToDBMapping("ostiaGroup","group_id",1);
	addToDBMapping("created_date","created_date",2);
	addToDBMapping("updated_date","updated_date",3);
	//----------------------
	addToNonCompositionList("ostiaGroup");
	//		----------------------
	addToParentsMap("com.citigroup.cgti.c3par.connection.domain.ConnectionPortMaster" , "port_id");
	//----------------------

    }




    /**
     * Gets the ostia group.
     *
     * @return the ostia group
     */
    public ConnectionOstiaGroup getOstiaGroup() {
	return ostiaGroup;
    }

    /**
     * Sets the ostia group.
     *
     * @param ostiaGroup the new ostia group
     */
    public void setOstiaGroup(ConnectionOstiaGroup ostiaGroup) {
	this.ostiaGroup = ostiaGroup;
    }
    //	public Long getRiskPortId() {
    //		return riskPortId;
    //	}
    //	public void setRiskPortId(Long riskPortId) {
    //		this.riskPortId = riskPortId;
    //	}

    /**
     * Gets the created_date.
     *
     * @return Returns the created_date.
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date The created_date to set.
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return Returns the updated_date.
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date The updated_date to set.
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }




    /**
     * Gets the pair id.
     *
     * @return the pair id
     */
    public Long getPairId() {
	return pairId;
    }




    /**
     * Sets the pair id.
     *
     * @param pairId the new pair id
     */
    public void setPairId(Long pairId) {
	this.pairId = pairId;
    }




    /**
     * Gets the risk flag.
     *
     * @return the risk flag
     */
    public String getRiskFlag() {
	return riskFlag;
    }




    /**
     * Sets the risk flag.
     *
     * @param riskFlag the new risk flag
     */
    public void setRiskFlag(String riskFlag) {
	this.riskFlag = riskFlag;
    }
}
