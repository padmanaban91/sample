/*
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.util.Date;


/**
 * The Class Planning.
 *
 * @author PC79439
 */
@SuppressWarnings("unchecked")
public class Planning extends Base implements Serializable{
 
    private	Date plannedActivateDate;
    
    private String securityReviewCmt;

    private String sponserReviewCmt;
    
    private String activateConnectionCmt;
    
    private String approveDetailDesignCmt;

    private String integcompleted;

    private String integStatusCmt;

    private Date procurementDate;

    private String procurementCmt;

    private String procurementOptional;

    private String systemAdminCmt;

    private String operationalAnalystCmt;

    private String istgCmt;

    private Long infomanId;

    private Date opanalystScheduleDate;

    private Date opanalystCompletedDate;

    private String vaflag;

    private String vanumber;

    private Date vaschDate;

    private String vacmts;

    private String descbusinessPerspective;

    private String managerName;

    private String groupRaisingRFC;

    private String implbauTimelines;

    private String standardChangeCycle;

    private String deptownerProcess;

    private String clashRequest;

    private String riskunplannedChange;

    private String addbusinessTesting;

    private String testingplanContactPer;

    private String directorAppMailFlag;

    private Date directorAppMailSentDate;

    private Date dontImplBeforeDate;

    
    
	public Date getPlannedActivateDate() {
		return plannedActivateDate;
	}

	public void setPlannedActivateDate(Date plannedActivateDate) {
		this.plannedActivateDate = plannedActivateDate;
	}

	public String getSecurityReviewCmt() {
		return securityReviewCmt;
	}

	public void setSecurityReviewCmt(String securityReviewCmt) {
		this.securityReviewCmt = securityReviewCmt;
	}

	public String getSponserReviewCmt() {
		return sponserReviewCmt;
	}

	public void setSponserReviewCmt(String sponserReviewCmt) {
		this.sponserReviewCmt = sponserReviewCmt;
	}

	public String getActivateConnectionCmt() {
		return activateConnectionCmt;
	}

	public void setActivateConnectionCmt(String activateConnectionCmt) {
		this.activateConnectionCmt = activateConnectionCmt;
	}

	public String getApproveDetailDesignCmt() {
		return approveDetailDesignCmt;
	}

	public void setApproveDetailDesignCmt(String approveDetailDesignCmt) {
		this.approveDetailDesignCmt = approveDetailDesignCmt;
	}

	public String getIntegcompleted() {
		return integcompleted;
	}

	public void setIntegcompleted(String integcompleted) {
		this.integcompleted = integcompleted;
	}

	public String getIntegStatusCmt() {
		return integStatusCmt;
	}

	public void setIntegStatusCmt(String integStatusCmt) {
		this.integStatusCmt = integStatusCmt;
	}

	public Date getProcurementDate() {
		return procurementDate;
	}

	public void setProcurementDate(Date procurementDate) {
		this.procurementDate = procurementDate;
	}

	public String getProcurementCmt() {
		return procurementCmt;
	}

	public void setProcurementCmt(String procurementCmt) {
		this.procurementCmt = procurementCmt;
	}

	public String getProcurementOptional() {
		return procurementOptional;
	}

	public void setProcurementOptional(String procurementOptional) {
		this.procurementOptional = procurementOptional;
	}

	public String getSystemAdminCmt() {
		return systemAdminCmt;
	}

	public void setSystemAdminCmt(String systemAdminCmt) {
		this.systemAdminCmt = systemAdminCmt;
	}

	public String getOperationalAnalystCmt() {
		return operationalAnalystCmt;
	}

	public void setOperationalAnalystCmt(String operationalAnalystCmt) {
		this.operationalAnalystCmt = operationalAnalystCmt;
	}

	public String getIstgCmt() {
		return istgCmt;
	}

	public void setIstgCmt(String istgCmt) {
		this.istgCmt = istgCmt;
	}

	public Long getInfomanId() {
		return infomanId;
	}

	public void setInfomanId(Long infomanId) {
		this.infomanId = infomanId;
	}

	public Date getOpanalystScheduleDate() {
		return opanalystScheduleDate;
	}

	public void setOpanalystScheduleDate(Date opanalystScheduleDate) {
		this.opanalystScheduleDate = opanalystScheduleDate;
	}

	public Date getOpanalystCompletedDate() {
		return opanalystCompletedDate;
	}

	public void setOpanalystCompletedDate(Date opanalystCompletedDate) {
		this.opanalystCompletedDate = opanalystCompletedDate;
	}

	public String getVaflag() {
		return vaflag;
	}

	public void setVaflag(String vaflag) {
		this.vaflag = vaflag;
	}

	public String getVanumber() {
		return vanumber;
	}

	public void setVanumber(String vanumber) {
		this.vanumber = vanumber;
	}

	public Date getVaschDate() {
		return vaschDate;
	}

	public void setVaschDate(Date vaschDate) {
		this.vaschDate = vaschDate;
	}

	public String getVacmts() {
		return vacmts;
	}

	public void setVacmts(String vacmts) {
		this.vacmts = vacmts;
	}

	public String getDescbusinessPerspective() {
		return descbusinessPerspective;
	}

	public void setDescbusinessPerspective(String descbusinessPerspective) {
		this.descbusinessPerspective = descbusinessPerspective;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getGroupRaisingRFC() {
		return groupRaisingRFC;
	}

	public void setGroupRaisingRFC(String groupRaisingRFC) {
		this.groupRaisingRFC = groupRaisingRFC;
	}

	public String getImplbauTimelines() {
		return implbauTimelines;
	}

	public void setImplbauTimelines(String implbauTimelines) {
		this.implbauTimelines = implbauTimelines;
	}

	public String getStandardChangeCycle() {
		return standardChangeCycle;
	}

	public void setStandardChangeCycle(String standardChangeCycle) {
		this.standardChangeCycle = standardChangeCycle;
	}

	public String getDeptownerProcess() {
		return deptownerProcess;
	}

	public void setDeptownerProcess(String deptownerProcess) {
		this.deptownerProcess = deptownerProcess;
	}

	public String getClashRequest() {
		return clashRequest;
	}

	public void setClashRequest(String clashRequest) {
		this.clashRequest = clashRequest;
	}

	public String getRiskunplannedChange() {
		return riskunplannedChange;
	}

	public void setRiskunplannedChange(String riskunplannedChange) {
		this.riskunplannedChange = riskunplannedChange;
	}

	public String getAddbusinessTesting() {
		return addbusinessTesting;
	}

	public void setAddbusinessTesting(String addbusinessTesting) {
		this.addbusinessTesting = addbusinessTesting;
	}

	public String getTestingplanContactPer() {
		return testingplanContactPer;
	}

	public void setTestingplanContactPer(String testingplanContactPer) {
		this.testingplanContactPer = testingplanContactPer;
	}

	public String getDirectorAppMailFlag() {
		return directorAppMailFlag;
	}

	public void setDirectorAppMailFlag(String directorAppMailFlag) {
		this.directorAppMailFlag = directorAppMailFlag;
	}

	public Date getDirectorAppMailSentDate() {
		return directorAppMailSentDate;
	}

	public void setDirectorAppMailSentDate(Date directorAppMailSentDate) {
		this.directorAppMailSentDate = directorAppMailSentDate;
	}

	public Date getDontImplBeforeDate() {
		return dontImplBeforeDate;
	}

	public void setDontImplBeforeDate(Date dontImplBeforeDate) {
		this.dontImplBeforeDate = dontImplBeforeDate;
	}

}