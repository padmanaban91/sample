package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.persistance.Persistable;


public interface CMPRequestPersistable extends Persistable{
	
	public Long saveCmpRequestfield(String cmpRequestString);
	
	public void cmpActivityTrail(Long cmpId, String ssoId, String taskCode, String activityStatus);
 
	public CitiContact getUserIdForSsoId(String ssoId);
	
	public byte[] getCmpData(String cmpReqId);
	
	CitiContact getuserIdForgGeid (String geId);
}
