package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.CitiContactXrefExtEntity;
import com.citigroup.cgti.c3par.model.CitiReqContactXrefExtEntity;
import com.citigroup.cgti.c3par.model.ConnectionRequestEntity;
import com.citigroup.cgti.c3par.model.ConnectionRequestExtEntity;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.dao.audit.AuditArchiver;


/**
 * The Class ConnectionRequestExtDAO.
 *
 * @author NE36745
 */
public class ConnectionRequestExtDAO
extends ConnectionRequestDAO
implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** New Fields - SOWNO and CMPID. */
    public static final String	COLUMN_SOWNO = "SOW_NUMBER";

    /** The Constant COLUMN_PLANNEDACTIVATEDATE. */
    public static final String	COLUMN_DONT_IMPL_BEFORE_DATE = "DONT_IMPL_BEFORE_DATE";
    public static final String	COLUMN_CONN_FOR_CUST_CLIENT = "CONN_FOR_CUST_CLIENT";


    /** The Constant COLUMN_CMPID. */
    public static final String	COLUMN_CMPID = "CMP_ID";


    /** The Constant COLUMN_ENGG_CMPID. */
    public static final String	COLUMN_ENGG_CMPID = "ENGG_CMP_ID";

    /** The Constant COLUMN_SERVICE_NOW_ID. */
    public static final String	COLUMN_SERVICENOWID = "SERVICE_NOW_ID";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";
    
    /** The connectivity estimate. */
    private static final String COLUMN_CONN_ESTIMATE="connectivity_estimate";
    
    /** The detailed information. */
    private static final String COLUMN_DET_INFORMATION="detailed_information";
     
    /** The Constant TABLE_NAME. */
    public static final String  TABLE_NAME="TI_REQUEST";
    
    public static final String TI_REQUEST_XREF = "TI_REQUEST_PLANNING_XREF";
    public static final String VIRTUAL_CONN_REASON = "VIRTUAL_CONN_REASON";

    /** Update Query. */
    private static String SELECT_CON_REQ="SELECT TRPX.TI_REQUEST_ID FROM TI_REQUEST_PLANNING_XREF TRPX WHERE TRPX.PLANNING_ID=?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE  "+ConnectionRequestExtDAO.TABLE_NAME +  " SET "
    + " " + COLUMN_SOWNO + " = ? "
    + ", " + COLUMN_CMPID + " = ? "
    + ", " + COLUMN_SERVICENOWID + " = ? "
    + ", " + COLUMN_ENGG_CMPID + " = ? "
    + " WHERE " + COLUMN_ID + " IN ("+SELECT_CON_REQ+")";
    
    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_PLANNING_TABLE = "UPDATE  "+PlanningDAO.TABLE+  " SET "
    + " " + COLUMN_DONT_IMPL_BEFORE_DATE + " = ? "
    + " WHERE " + COLUMN_ID + " = ? ";

    public static final String	COLUMN_DIRECT_ACCESSBY_THIRDPRT = "DIRECT_ACCESSBY_THIRDPRT";
    public static final String	COLUMN_CAB_APPR_GRP_CODE = "CAB_APPR_GRP_CODE";
    public static final String	COLUMN_REASON_FOR_VIRTU_CONN = "REASON_FOR_VIRTU_CONN";
    public static final String	COLUMN_SEMI_ANNUAL_ENTITL_REVIEW = "SEMI_ANNUAL_ENTITL_REVIEW";
    public static final String	COLUMN_TP_TRAINING_AWARNESS_PRG = "TP_TRAINING_AWARNESS_PRG";
    public static final String	COLUMN_EXPORT_LICENSE_CORDINATOR ="EXPORT_LICENSE_CORDINATOR_NEW";
    /*public static final String  COLUMN_CURR_BUS_JUSTFICATION = "CURR_BUS_JUSTFICATION";*/
    
    /** The Update con_req table */
    private static String UPDATE_BY_CON_REQ_TABLE = "UPDATE  "+ConnectionRequestDAO.TABLE+  " SET "
    + " " + COLUMN_CONN_FOR_CUST_CLIENT + " = ? "
    + "," + COLUMN_CAB_APPR_GRP_CODE + " = ? "
    + "," + COLUMN_DIRECT_ACCESSBY_THIRDPRT + " = ? "
    + "," + COLUMN_SEMI_ANNUAL_ENTITL_REVIEW + " = ? "
    + "," + COLUMN_TP_TRAINING_AWARNESS_PRG + " = ? "
    + "," + COLUMN_EXPORT_LICENSE_CORDINATOR + " = ? "
    + "," + COLUMN_CONN_ESTIMATE + " = ? "
    + "," + COLUMN_DET_INFORMATION + " = ? "
    
    /*+ "," + COLUMN_REASON_FOR_VIRTU_CONN + " = ? "*/
    /*+ "," + COLUMN_CURR_BUS_JUSTFICATION + " = ? "*/
    + " WHERE " + COLUMN_ID + " = ? ";
    
    /** The Constant COLUMN_ID. */
    public static final String	CON_REQ_ID = "CON_REQ_ID";
    
    public static final String	ID = "ID";
    
    public static final String GENERIC_LOOKUP_ID = "GENERIC_LOOKUP_ID";
    
    /** The Update con_req table */
    private static String DELETE_VIRTUAL_CONN_REASON_TABLE = "DELETE  "+ConnectionRequestExtDAO.VIRTUAL_CONN_REASON
    + " WHERE " + CON_REQ_ID + " = ? ";
    
    public static final String SEQ_VIRTUAL_CONN_REASON ="SEQ_VIRTUAL_CONN_REASON";
    
    /** The Update con_req table */
    private static String INSERT_VIRTUAL_CONN_REASON_TABLE = "INSERT INTO " +ConnectionRequestExtDAO.VIRTUAL_CONN_REASON
    + "(" + ID 
    + ", " + CON_REQ_ID
    + ", " + GENERIC_LOOKUP_ID
    + ") VALUES (?, ?, ?)";
    
    
    public static final String  COLUMN_SEMI_ANNUAL_ENTITLEMENT_REVIEW  = "SEMI_ANNUAL_ENTITLEMENT_REVIEW";
    public static final String  COLUMN_TP_TRAINING_AWARNESS_PROGRAM = "TP_TRAINING_AWARNESS_PROGRAM";
    public static final String  COLUMN_CITI_POLICY_ADHERENCE = "CITI_POLICY_ADHERENCE";
    
    /** The Update con_req table */
    /*private static String UPDATE_BY_CON_REQ_TABLE_TO_DEFAULT_VAL = "UPDATE  "+ConnectionRequestDAO.TABLE+  " SET "
    + " " + COLUMN_SEMI_ANNUAL_ENTITLEMENT_REVIEW + " = ? "
    + "," + COLUMN_TP_TRAINING_AWARNESS_PROGRAM + " = ? "
    + "," + COLUMN_CITI_POLICY_ADHERENCE + " = ? "
    + " WHERE " + COLUMN_ID + " = ? ";*/
    
    /** The Update con_req table */
    private static String UPDATE_BY_CON_REQ_TABLE_TO_DEFAULT_VALS = "UPDATE  "+ConnectionRequestDAO.TABLE+  " SET "
    + " " + COLUMN_SEMI_ANNUAL_ENTITLEMENT_REVIEW + " = ? "
    + "," + COLUMN_TP_TRAINING_AWARNESS_PROGRAM + " = ? "
    + " WHERE " + COLUMN_ID + " = ? ";
    
    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_SOWNO
    + ", " + COLUMN_CMPID
    + ", " + COLUMN_SERVICENOWID
    + ", " + COLUMN_ENGG_CMPID
    + " FROM " + ConnectionRequestExtDAO.TABLE_NAME;
    
    /** The SELEC t_ stmt. */
    private static String SELECT_PLANING_STMT = "SELECT "  + COLUMN_DONT_IMPL_BEFORE_DATE
    + " FROM " + PlanningDAO.TABLE;



    /** Select Query. */
    private static String SELECT_BY_ID_STMT = ConnectionRequestExtDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " IN ("+SELECT_CON_REQ+")";
    
    /** Select Query. */
    private static String SELECT_PLANNING_DNTDATE_STMT = ConnectionRequestExtDAO.SELECT_PLANING_STMT + " WHERE " + COLUMN_ID + " = ? ";
    
    
    /** The SELEC t_ stmt. */
    private static String SELECT_CON_REQ_STMT = "SELECT "  + COLUMN_CONN_FOR_CUST_CLIENT
    +","+ COLUMN_CAB_APPR_GRP_CODE 
    +","+ COLUMN_DIRECT_ACCESSBY_THIRDPRT 
    + "," + COLUMN_SEMI_ANNUAL_ENTITL_REVIEW 
    + "," + COLUMN_TP_TRAINING_AWARNESS_PRG
    + "," + COLUMN_EXPORT_LICENSE_CORDINATOR 
    + "," + COLUMN_CONN_ESTIMATE
    + "," + COLUMN_DET_INFORMATION
    
    /*+","+ COLUMN_REASON_FOR_VIRTU_CONN */
    /*+","+ COLUMN_CURR_BUS_JUSTFICATION*/
    + " FROM " + ConnectionRequestDAO.TABLE;
    
    /** The SELEC t_ stmt. */
    private static String SELECT_DEFAULT_VAL_STMT = "SELECT "  + COLUMN_SEMI_ANNUAL_ENTITLEMENT_REVIEW 
    + "," + COLUMN_TP_TRAINING_AWARNESS_PROGRAM
    + " FROM " + ConnectionRequestDAO.TABLE;
    
    /** The SELEC t_ stmt. */
    private static String SELECT_PLANNING_RATIONAL_CON_REQ = "SELECT CONREQ.RATIONALE  FROM "+ConnectionRequestExtDAO.TI_REQUEST_XREF+" TXREF,"+ConnectionRequestExtDAO.TABLE_NAME+" TREQ,"+ConnectionRequestDAO.TABLE+" CONREQ "+
    		" WHERE TXREF.PLANNING_ID = ? AND TREQ.ID = TXREF.TI_REQUEST_ID AND CONREQ.ID = TREQ.PROCESS_ID";
    
    private static String SELECT_VIRTUAL_CONN_REASON ="SELECT  "+ GENERIC_LOOKUP_ID + " FROM " +VIRTUAL_CONN_REASON 
    +" WHERE "+CON_REQ_ID+" = ?";
    
    
    
    /** Select Query. */
    private static String SEL_CON_REQ_CONN_FOR_CUST_CLIENT = ConnectionRequestExtDAO.SELECT_CON_REQ_STMT +" WHERE " + COLUMN_ID + " = ? ";
    

    /** Select Query. */
    private static String SEL_CON_REQ_DEFAULT_VAL = ConnectionRequestExtDAO.SELECT_DEFAULT_VAL_STMT +" WHERE " + COLUMN_ID + " = ? ";
    
    
    /** The log. */
    private static Logger log = Logger.getLogger(ConnectionRequestExtDAO.class);

    /**
     * Instantiates a new connection request ext dao.
     *
     * @param session the session
     */
    public ConnectionRequestExtDAO(DatabaseSession session) {
	super(session);
	// TODO Auto-generated constructor stub
    }

    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionRequestEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionRequestEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionRequestEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionRequestEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.dao.ConnectionRequestDAO#update(com.citigroup.cgti.c3par.model.ConnectionRequestEntity, com.mentisys.dao.audit.AuditArchiver, boolean)
     */
    public Long update(ConnectionRequestEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Updating ConnectionRequestExtEntity [" + entity.getId() + "]");
	/*boolean setDefaultValFalg = false;
	if(entity.getPrimaryKey() == null){
		setDefaultValFalg = true;
		log.debug("ConnectionRequestExtEntity setDefaultValFalg::"+setDefaultValFalg);
	}*/
	Long primaryId  = super.update(entity, archiver, true);

	if (entity instanceof ConnectionRequestExtEntity) {
	    ConnectionRequestExtEntity extEntity = (ConnectionRequestExtEntity) entity;

	    
	    DatabaseSession session = getSession();

	    if(primaryId.longValue() == 0)
		throw new DatabaseException("Could not insert '" + ConnectionRequestDAO.ENTITY_NAME + "' with id = " + primaryId + " due to unique key constraint violation", null);

	    Connection connection = null;
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    log.debug("ConnectionRequestExtEntity.update() :- " + primaryId);
	    try
	    {
	    log.debug("ConnectionRequestExtEntity.update() :: updating SOW and CMPID");
		connection = session.getConnection();
		st = connection.prepareStatement(UPDATE_BY_ID_STMT);
		st.setString(1, extEntity.getSOW());
		st.setString(2, extEntity.getCmpId());
		st.setString(3, extEntity.getServiceNowID());
		st.setString(4, extEntity.getEnggCmpID());
		st.setLong(5, primaryId.longValue());
		st.executeUpdate();
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not insert '" + ConnectionRequestDAO.ENTITY_NAME + "' with id = "
			+ primaryId, e);
	    }
	    log.debug("ConnectionRequestExtEntity.update() :: End");
	    //Updating the Don't implement Before date.
	    try
	    {
	    log.debug("ConnectionRequestExtEntity.update() :: updating Dont Implement before dt in planning::"+extEntity.getDontImplementBeforeDt());
		st = connection.prepareStatement(UPDATE_BY_PLANNING_TABLE);
		log.debug("UPDATE_BY_PLANNING_TABLE:"+UPDATE_BY_PLANNING_TABLE);
		setDateToStatement(st, 1, extEntity.getDontImplementBeforeDt());
		st.setLong(2, primaryId.longValue());
		st.executeUpdate();
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not update '" + PlanningDAO.TABLE + "' with id = "
			+ primaryId, e);
	    }
	    try
	    {
	    log.debug("ConnectionRequestExtEntity.update() :: updating ConnForCustORClient::"+extEntity.getConnForCustORClient()
	    		+"CabApprGrpCode::"+extEntity.getCabApprGrpCode()+"DirectAccessByThirdPrt::"+extEntity.getDirectAccessByThirdPrt()
	    		+"updating SetEntitlement Review::"+extEntity.getSemiAnnualEntitlReview() 
	    		+"TpTrainingAwarnessProgram::"+extEntity.getTpTrainingAwarnessPrg());
		st = connection.prepareStatement(UPDATE_BY_CON_REQ_TABLE);
		log.debug("UPDATE_BY_CON_REQ_TABLE::"+UPDATE_BY_CON_REQ_TABLE);
		setStringToStatement(st, 1, extEntity.getConnForCustORClient(),COLUMN_CONN_FOR_CUST_LEN);
		setStringToStatement(st, 2, extEntity.getCabApprGrpCode(), COLUMN_RATIONALE_LEN);
		setStringToStatement(st, 3, extEntity.getDirectAccessByThirdPrt(),COLUMN_DIRECT_ACCESS_LEN);
		setStringToStatement(st, 4, extEntity.getSemiAnnualEntitlReview(),COLUMN_SEMI_ANNUAL_LEN);
		setStringToStatement(st, 5, extEntity.getTpTrainingAwarnessPrg(),COLUMN_TP_TRAINING_LEN);
		setStringToStatement(st, 6, extEntity.getExportLicenseCordinatorNew(),COLUMN_EXPORT_LICENCE_LEN);
		setStringToStatement(st, 7, extEntity.getConnEstimate(),COLUMN_CONN_ESTIMATE_LEN);
		
		setStringToStatement(st, 8, extEntity.getDetInformation(),COLUMN_DET_INFORMATION_LEN);
		// for closure comments COLUMN_CLOS_COMMENTS
		 
		st.setLong(9, primaryId.longValue());
		st.executeUpdate();
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not update '" + ConnectionRequestDAO.TABLE + "' with id = "
			+ primaryId, e);
	    }
	    try
	    {
	    log.debug("ConnectionRequestExtEntity.delete() :: DELETING VIRTUAL_CONN_REASON::"+extEntity.getReasonForVirtuConn());
	    if(extEntity.getReasonForVirtuConn() != null){
	    	log.debug("ConnectionRequestExtEntity.delete() ::LENGTH OF REASON FOR VIRTU::"+extEntity.getReasonForVirtuConn().length);
			st = connection.prepareStatement(DELETE_VIRTUAL_CONN_REASON_TABLE);
			log.debug("DELETE_VIRTUAL_CONN_REASON_TABLE::"+DELETE_VIRTUAL_CONN_REASON_TABLE);
			st.setLong(1, primaryId.longValue());
			st.executeUpdate();
	    }
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not insert  '" + ConnectionRequestDAO.TABLE + "' with id = "
			+ primaryId, e);
	    }
	    
	    try
	    {
	    	PreparedStatement stmt = null;
		    ResultSet rsOne = null;
		    log.debug("ConnectionRequestExtEntity.update() :: INSERTING VIRTUAL_CONN_REASON::"+extEntity.getReasonForVirtuConn());
		    if(extEntity.getReasonForVirtuConn() != null){
			    log.debug("ConnectionRequestExtEntity.insert() ::LENGTH OF REASON FOR VIRTU::"+extEntity.getReasonForVirtuConn().length);
			    for(int i=0;i<extEntity.getReasonForVirtuConn().length;i++){
			    	Long virtual_id = null;
			    	try{
				    	stmt=connection.prepareStatement("Select "+SEQ_VIRTUAL_CONN_REASON+".nextval from dual");
					    rsOne = stmt.executeQuery();
					    if (rsOne.next())
					    {
					     virtual_id=rsOne.getLong(1);
					    }
			    	}
				    catch (SQLException e)
				    {
					throw new DatabaseException("Could not get value form sequence  '" + SEQ_VIRTUAL_CONN_REASON, e);
				    }
					st = connection.prepareStatement(INSERT_VIRTUAL_CONN_REASON_TABLE);
					log.debug("INSERT_VIRTUAL_CONN_REASON_TABLE::"+INSERT_VIRTUAL_CONN_REASON_TABLE);
					st.setLong(1,virtual_id.longValue());
					st.setLong(2, primaryId.longValue());
					st.setLong(3,extEntity.getReasonForVirtuConn()[i].longValue());
					st.executeUpdate();
			    }
		   	}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not insert  '" + ConnectionRequestDAO.TABLE + "' with id = "
			+ primaryId, e);
	    }
	    /*try{
	    	if(setDefaultValFalg){
	    		log.debug("ConnectionRequestExtEntity.update() :: updating to default values for semiAnnualEntitlementReview,tpTrainingAwarnessProgram and citiPolicyAdherence");
	    		connection = session.getConnection();
	    		st = connection.prepareStatement(UPDATE_BY_CON_REQ_TABLE_TO_DEFAULT_VAL);
	    		st.setString(1, null);
	    		st.setString(2, null);
	    		st.setString(3, null);
	    		st.setLong(4, primaryId.longValue());
	    		st.executeUpdate();	
	    	}
	    }
	    catch(SQLException e)
	    {
			throw new DatabaseException("Could not set default val in  '" + ConnectionRequestDAO.TABLE + "' with id = "
				+ primaryId, e);
		}*/
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	    log.debug("PlaningTable.update() :: End");
	}
	
	return primaryId;
    }


    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public ConnectionRequestEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.dao.ConnectionRequestDAO#get(java.lang.Long, boolean)
     */
    public ConnectionRequestEntity get(Long id, boolean load_refs) throws DatabaseException
    {

   	// Need to get the values from db setEntView if it is null just update to null after super.get
	ConnectionRequestEntity entity = super.get(id, load_refs);

	ConnectionRequestExtEntity extEntity = null;

	if (entity instanceof ConnectionRequestExtEntity) {
	    extEntity = (ConnectionRequestExtEntity) entity;
	}

	Long id_to_get = id;

	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    setLongToStatement(st, 1, id_to_get);
	    rs = st.executeQuery();

	    if (rs.next())
	    {
		extEntity.setSOW(rs.getString(1));
		extEntity.setCmpId(rs.getString(2));
		extEntity.setServiceNowID(rs.getString(3));
		extEntity.setEnggCmpID(rs.getString(4));
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not load " + ConnectionRequestDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	}
	try
	{	st = null; rs = null;
	    st = connection.prepareStatement(SELECT_PLANNING_DNTDATE_STMT);
	    setLongToStatement(st, 1, id_to_get);
	    log.debug("SELECT_PLANNING_DNTDATE_STMT:"+SELECT_PLANNING_DNTDATE_STMT);
	    rs = st.executeQuery();

	    if (rs.next())
	    {
		extEntity.setDontImplementBeforeDt(rs.getDate(1));
		log.debug("DontImplmentBeforeDate from planning table:"+extEntity.getDontImplementBeforeDt());
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not load " + PlanningDAO.TABLE +"."+COLUMN_DONT_IMPL_BEFORE_DATE +" with id = " + id_to_get, e);
	}
	try
	{	
		st = null; rs = null;
	    st = connection.prepareStatement(SEL_CON_REQ_CONN_FOR_CUST_CLIENT);
	    setLongToStatement(st, 1, id_to_get);
	    log.debug("SEL_CON_REQ_CONN_FOR_CUST_CLIENT:"+SEL_CON_REQ_CONN_FOR_CUST_CLIENT +"ConnID::"+id_to_get);
	    rs = st.executeQuery();

	    if (rs.next())
		{
		    log.debug("CONN_FOR_CUST_CLIENT from Result rs.getString(1)::"+rs.getString(COLUMN_CONN_FOR_CUST_CLIENT));
		    String connForCustORClient = rs.getString(COLUMN_CONN_FOR_CUST_CLIENT);
		    if(connForCustORClient != null && !connForCustORClient.equals("")){
		    	extEntity.setConnForCustORClient(connForCustORClient.trim());
		    }
		    
		    log.debug("COLUMN_CAB_APPR_GRP_CODE from Result rs.getString(2)::"+rs.getString(COLUMN_CAB_APPR_GRP_CODE));
		    extEntity.setCabApprGrpCode(rs.getString(COLUMN_CAB_APPR_GRP_CODE));
		    
		    String direct_Accessby_Thirdprt = rs.getString(COLUMN_DIRECT_ACCESSBY_THIRDPRT);
		    log.debug("COLUMN_DIRECT_ACCESSBY_THIRDPRT from Result rs.getString(3)::"+direct_Accessby_Thirdprt);
		    if(direct_Accessby_Thirdprt != null && !direct_Accessby_Thirdprt.equals("")){
		    	extEntity.setDirectAccessByThirdPrt(direct_Accessby_Thirdprt.trim());
		    }
		   
		    String semi_annual_entitl_review = rs.getString(COLUMN_SEMI_ANNUAL_ENTITL_REVIEW);
		    log.debug("COLUMN_SEMI_ANNUAL_ENTITL_REVIEW from Result rs.getString(4)::"+semi_annual_entitl_review);
		    if(semi_annual_entitl_review != null && !semi_annual_entitl_review.equals("")){
		    	extEntity.setSemiAnnualEntitlReview(semi_annual_entitl_review.trim());
		    }
		    
		    String tp_training_awarness_prg = rs.getString(COLUMN_TP_TRAINING_AWARNESS_PRG);
		    log.debug("COLUMN_TP_TRAINING_AWARNESS_PRG from Result rs.getString(5)::"+tp_training_awarness_prg);
		    if(tp_training_awarness_prg != null && !tp_training_awarness_prg.equals("")){
		    	extEntity.setTpTrainingAwarnessPrg(tp_training_awarness_prg.trim());
		    }
		    
		    String export_license_cordinator = rs.getString(COLUMN_EXPORT_LICENSE_CORDINATOR);
		    log.debug("COLUMN_EXPORT_LICENSE_CORDINATOR from Result rs.getString(6)::"+export_license_cordinator);
		    if(export_license_cordinator != null && !export_license_cordinator.equals("")){
		    	extEntity.setExportLicenseCordinatorNew(export_license_cordinator.trim());
		    }
		    
		    String connEstimate = rs.getString(COLUMN_CONN_ESTIMATE);
		    log.debug("COLUMN_CONN_ESTIMATE from Result rs.getString(6)::"+connEstimate);
		    if(connEstimate != null && !connEstimate.equals("")){
		    	extEntity.setConnEstimate(connEstimate.trim());
		    }
		    
		    String detInformation = rs.getString(COLUMN_DET_INFORMATION);
		    log.debug("COLUMN_DET_INFORMATION from Result rs.getString(6)::"+detInformation);
		    if(detInformation != null && !detInformation.equals("")){
		    	extEntity.setDetInformation(detInformation.trim());
		    }
		    
		   
		    
		    
		    /*Long test[] = new Long[3];
		    if(rs.getInt(4) != 0 ){
		    	test[0] = Long.valueOf(rs.getInt(COLUMN_REASON_FOR_VIRTU_CONN));
		    	log.debug("COLUMN_REASON_FOR_VIRTU_CONN from Result rs.getString(4)::"+rs.getInt(COLUMN_REASON_FOR_VIRTU_CONN));
		    	extEntity.setReasonForVirtuConn(test);
		    }*/
		    
		    /*log.debug("COLUMN_CURR_BUS_JUSTFICATION from Result rs.getString(5)::"+rs.getString(COLUMN_CURR_BUS_JUSTFICATION));
		    extEntity.setCurrBusJustfi(rs.getString(5));*/
		    
		 }
	}
	catch (SQLException e)
	{
		log.error(e,e);
	    throw new DatabaseException("Could not load " + ConnectionRequestDAO.TABLE +"."+COLUMN_CONN_FOR_CUST_CLIENT +" with id = " + id_to_get, e);
	}
	try{
		
		st = null; rs = null;
	    st = connection.prepareStatement(SELECT_PLANNING_RATIONAL_CON_REQ);
	    setLongToStatement(st, 1, id_to_get);
	    log.debug("SELECT_PLANNING_RATIONAL_CON_REQ:"+SELECT_PLANNING_RATIONAL_CON_REQ +"ConnID::"+id_to_get);
	    rs = st.executeQuery();
	    if (rs.next())
		{
		    log.debug("CONREQ.RATIONALE from Result rs.getString(1)::"+rs.getString(1));
		    String planingCycleRational = rs.getString(1);
		    if(planingCycleRational != null && !planingCycleRational.equals("")){
		    	extEntity.setCurrBusJustfi(planingCycleRational);
		    }
		}
	}
	catch (SQLException e)
	{
		log.error(e,e);
	    throw new DatabaseException("Could not load CONREQ.RATIONALE with id = " + id_to_get, e);
	}
	try{
		
		st = null; rs = null;
	    st = connection.prepareStatement(SELECT_VIRTUAL_CONN_REASON);
	    setLongToStatement(st, 1, id_to_get);
	    log.debug("SELECT_VIRTUAL_CONN_REASON:"+SELECT_VIRTUAL_CONN_REASON +"ConnID::"+id_to_get);
	    rs = st.executeQuery();
	    List<Long> reasonList =new ArrayList<Long>();
	    while (rs.next())
		{
		    log.debug("VIRTUAL_CONN_REASON from Result rs.getLong(1)::"+rs.getLong(1));
		    reasonList.add(Long.valueOf(rs.getLong(1)));
		}
	    if(reasonList.size() > 0){
	    	Long longarray[] = new Long[reasonList.size()];
	    	reasonList.toArray(longarray);
	    	log.debug("VIRTUAL_CONN_REASON reasonList::"+reasonList);
	    	extEntity.setReasonForVirtuConn(longarray);
	    }
	}
	catch (SQLException e)
	{
		log.error(e,e);
	    throw new DatabaseException("Could not load "+VIRTUAL_CONN_REASON+" with id = " + id_to_get, e);
	}
	
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	if (extEntity != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadExtReferences(extEntity, load_refs);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + ConnectionRequestDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}

	log.debug("DONE Getting ConnectionRequestExtEntity with id = " + id_to_get); 

	return extEntity;
    }

    /*public Map<String,String> getDefaultValues(Long id) throws DatabaseException{
    	
    	DatabaseSession session = getSession();
    	Connection connection = null;

    	PreparedStatement st = null;
    	ResultSet rs = null;
    	
    	Map<String,String> map = new HashMap<String,String>(); 

    	try
    	{
    	    connection = session.getConnection();
    	    st = connection.prepareStatement(SEL_CON_REQ_DEFAULT_VAL);
    	    setLongToStatement(st, 1, id);
    	    rs = st.executeQuery();

    	    if (rs.next())
    	    {
    	    	map.put(COLUMN_SEMI_ANNUAL_ENTITLEMENT_REVIEW, rs.getString(1));
    	    	map.put(COLUMN_TP_TRAINING_AWARNESS_PROGRAM,rs.getString(2));
    	    }
    	}
    	catch (SQLException e)
    	{
    	    throw new DatabaseException("Could not load " + ConnectionRequestDAO.TABLE + " with id = " + id, e);
    	}
    	finally
    	{
    	    closeResultSet(rs);
    	    closeStatement(st);
    	    session.releaseConnection();
    	}
    	
    	return map;
    }
    
   public void updateDefaultVal(boolean entitleFlag,boolean tpTrainingFlag,Long id)throws DatabaseException{
	   
   	DatabaseSession session = getSession();
    Connection connection = null;
    PreparedStatement st = null;
    ResultSet rs = null;
    
    StringBuffer sql = new StringBuffer();
    sql.append("UPDATE  "+ConnectionRequestDAO.TABLE+  " SET ");
   

    log.debug("ConnectionRequestExtEntity.updateDefaultVal() :- " + id);
    try
    {
    log.debug("ConnectionRequestExtEntity.updateDefaultVal() :: sql:: "+UPDATE_BY_CON_REQ_TABLE_TO_DEFAULT_VALS);
	connection = session.getConnection();
	
	if(entitleFlag){
		sql.append(" "+COLUMN_SEMI_ANNUAL_ENTITLEMENT_REVIEW + " = ? " );
	}
	if(tpTrainingFlag){
		sql.append( "," + COLUMN_TP_TRAINING_AWARNESS_PROGRAM + " = ? " );
		   
	}
	sql.append(  " WHERE " + COLUMN_ID + " = ? " );
	
	st = connection.prepareStatement(sql.toString());
	if(entitleFlag && tpTrainingFlag){
		st.setString(1, null);
		st.setString(2, null);
		st.setLong(3, id.longValue());
	}else {
		st.setString(1, null);
		st.setLong(2, id.longValue());
	}
	st.executeUpdate();
	connection.commit();
    }
    catch (SQLException e)
    {
	throw new DatabaseException("Could not insert '" + ConnectionRequestDAO.ENTITY_NAME + "' with id = "
		+ id, e);
    }
    finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}
    log.debug("ConnectionRequestExtEntity.updateDefaultVal() :: End");
   }*/
    
    
    /**
     * Load ext references.
     *
     * @param obj the obj
     * @param load_refs the load_refs
     * @throws DatabaseException the database exception
     */
    public void loadExtReferences(ConnectionRequestExtEntity obj, boolean load_refs) throws DatabaseException
    {
	loadCitiContactsExtReferences(obj, load_refs);
	loadCitiReqContactsExtReferences(obj, load_refs);
    }

    /**
     * Load citi contacts ext references.
     *
     * @param entity the entity
     * @param load_refs the load_refs
     * @throws DatabaseException the database exception
     */
    public void loadCitiContactsExtReferences(ConnectionRequestExtEntity entity, boolean load_refs) throws DatabaseException
    {
	HashMap<Long, CitiContactXrefExtEntity> entity_list = new HashMap<Long, CitiContactXrefExtEntity>();
	try
	{
	    log.debug("Loading CitiContacts references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    List id_list = entity.getOriginalCitiContactsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		CitiContactXrefExtDAO dao = getCitiContactsDAO();
		entity_list.put((Long)id_list.get(0),dao.getNotifyContact((Long)id_list.get(0)));

	    }
	    else if(id_list.size() > 1)
	    {
		CitiContactXrefExtDAO dao = getCitiContactsDAO();
		entity_list.putAll(dao.getNotifyList(id_list, load_refs));
	    }
	    log.debug("Finished loading CitiContacts references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiContacts References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	entity.setCitiExtContacts(entity_list);
    }

    /**
     * Load citi req contacts ext references.
     *
     * @param entity the entity
     * @param load_refs the load_refs
     * @throws DatabaseException the database exception
     */
    public void loadCitiReqContactsExtReferences(ConnectionRequestExtEntity entity, boolean load_refs) throws DatabaseException
    {
	HashMap<Long, CitiReqContactXrefExtEntity> entity_list = new HashMap<Long, CitiReqContactXrefExtEntity>();
	try
	{
	    log.debug("Loading CitiContacts references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    List id_list = entity.getOriginalCitiReqContactsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		CitiReqContactXrefExtDAO dao = getCitiReqContactsDAO();
		entity_list.put((Long)id_list.get(0),dao.getNotifyContact((Long)id_list.get(0)));

	    }
	    else if(id_list.size() > 1)
	    {
		CitiReqContactXrefExtDAO dao = getCitiReqContactsDAO();
		entity_list.putAll(dao.getNotifyList(id_list, load_refs));
	    }
	    log.debug("Finished loading CitiContacts references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiContacts References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	entity.setCitiReqExtContacts(entity_list);
    }

    //Added for 9479 - Add new buttons - Previous and Next in Target Contacts - Starts
    /**
     * Load citi contacts references list.
     *
     * @param id_list the id_list
     * @return the array list
     * @throws DatabaseException the database exception
     */
    public ArrayList loadCitiContactsReferencesList(ArrayList id_list) throws DatabaseException
    {
	ArrayList contacts_list = new ArrayList();

	try
	{

	    log.debug("Loading CitiContacts references for ConnectionRequestEntity [" + id_list + "].");

	    if(id_list.size() == 1)
	    {
		CitiContactXrefExtDAO dao = getCitiContactsDAO();
		contacts_list.add(dao.get((Long)id_list.get(0), true));

	    }
	    else if(id_list.size() > 1)
	    {
		CitiContactXrefExtDAO dao = getCitiContactsDAO();
		contacts_list.addAll(dao.get(id_list, true));
	    }
	    log.debug("Finished loading CitiContacts references. Count = " + contacts_list.size());

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiContacts References for ConnectionRequestEntity [" + id_list + "].", e);
	}

	return contacts_list;
    }

    /**
     * Load req citi contacts references list.
     *
     * @param id_list the id_list
     * @return the array list
     * @throws DatabaseException the database exception
     */
    public ArrayList loadReqCitiContactsReferencesList(ArrayList id_list) throws DatabaseException
    {
	ArrayList contacts_list = new ArrayList();

	try
	{

	    log.debug("Loading CitiContacts references for ConnectionRequestEntity [" + id_list + "].");

	    if(id_list.size() == 1)
	    {
		CitiReqContactXrefExtDAO dao = getCitiReqContactsDAO();
		contacts_list.add(dao.get((Long)id_list.get(0), true));

	    }
	    else if(id_list.size() > 1)
	    {
		CitiReqContactXrefExtDAO dao = getCitiReqContactsDAO();
		contacts_list.addAll(dao.get(id_list, true));
	    }
	    log.debug("Finished loading CitiContacts references. Count = " + contacts_list.size());

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiContacts References for ConnectionRequestEntity [" + id_list + "].", e);
	}

	return contacts_list;
    }
    //Added for 9479 - Add new buttons - Previous and Next in Target Contacts - Ends
}
