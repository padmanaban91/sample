package com.citigroup.cgti.c3par.fw.domain.admin.util;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.citigroup.cgti.c3par.fw.domain.Firewall;

public interface FirewallCrud {
	public List<Firewall> findFireWalls(String firewallName);
	public void updateFirewall(Firewall firewall);
	public void deleteFirewall(Firewall firewall);
	public Map<Long, String> getFirewallPolicyMap();
	public void insertFirewall(Firewall firewall) throws DataAccessException, Exception;
}
