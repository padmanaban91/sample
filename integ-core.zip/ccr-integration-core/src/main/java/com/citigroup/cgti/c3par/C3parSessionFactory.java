package com.citigroup.cgti.c3par;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.citigroup.cgti.c3par.performer.util.PerformerConnection;
import com.mentisys.dao.DatabaseSession;


/**
 * A factory for creating C3parSession objects.
 */
public class C3parSessionFactory {

    /** The ctx. */
    private XmlBeanFactory ctx = null;

    /** The performer connection holder. */
    private ThreadLocal performerConnectionHolder;

    /** The log. */
    protected static Logger log = Logger.getLogger(C3parSessionFactory.class);

    /** The instance. */
    private static C3parSessionFactory instance;

    /**
     * Instantiates a new c3par session factory.
     */
    private C3parSessionFactory() {
	setContext();
	performerConnectionHolder = new ThreadLocal() {
	    protected synchronized Object initialValue() {
		return new C3parPerformerConnection(true);
	    }
	};

    }

    /**
     * Gets the context.
     *
     * @return the context
     */
    private XmlBeanFactory getContext() {
	return ctx;
    }

    /**
     * Sets the context.
     */
    private void setContext() {
	log.debug("getContext(): Start");
	if (ctx == null) {
	    log.debug("Getting Spring  Context ....");
	    Resource rs = new FileSystemResource(System
		    .getProperty("c3par.root")
		    + "/WEB-INF/dataAccessContext.xml");
	    ctx = new XmlBeanFactory(rs);
	    log.debug("Getting Spring  Context ....");
	}
	log.debug("getContext(): End");

    }

    /**
     * Gets the c3par session factory.
     *
     * @return the c3par session factory
     */
    private static C3parSessionFactory getC3parSessionFactory() {

	if (instance == null)
	    instance = new C3parSessionFactory();
	return instance;

    }

    /**
     * Gets the performer connection holder.
     *
     * @return the performer connection holder
     */
    private ThreadLocal getPerformerConnectionHolder() {
	return performerConnectionHolder;
    }

    /**
     * Gets the c3par session.
     *
     * @return the c3par session
     */
    public static DatabaseSession getC3parSession() {

	return (DatabaseSession) getC3parSessionFactory().getContext().getBean(
	"c3parSession");

    }

    /**
     * Gets the performer session.
     *
     * @return the performer session
     */
    public static PerformerConnection getPerformerSession() {

	C3parPerformerConnection prefCon = (C3parPerformerConnection) getC3parSessionFactory()
	.getPerformerConnectionHolder().get();
	log.debug("Returning C3parPerformerConnection Instance "+prefCon.toString());
	prefCon.setDataSource((DataSource) getC3parSessionFactory()
		.getContext().getBean("dataSource"));
	return prefCon;

    }

}
