package com.citigroup.cgti.c3par.fw.domain.soc.persist;

import java.util.HashMap;
import java.util.List;

import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleOstiaQuestion;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.RiskDefinition;

public interface OstiaRiskPersistable extends FirewallRuleProcessPersistable {

	public List<RiskDefinition> findRiskDefinitions(
			FireWallRuleProcess fireWallRuleProcess);

	public List<FirewallRuleQuestionnaire> findFirewallRuleQuestionnaires(
			FireWallRuleProcess fireWallRuleProcess);

	public List<FirewallRuleOstiaQuestion> findFirewallRuleOstiaAnswers(
			FireWallRuleProcess fireWallRuleProcess);

	public HashMap<String, List<FirewallRuleOstiaQuestion>> findFirewallRuleOstiaMapAnswers(
			FireWallRuleProcess fireWallRuleProcess);
	
	public void updateAnswer(FireWallRuleProcess fireWallRuleProcess);

	String saveOstiaQuestionnaire(FireWallRule firewallRule,
			OstiaQuestionnaire ostiaQuestionnaire, TIRequest tiRequest, boolean deleteFlag);
	
	String saveRequestOstiaQuestionnaire(OstiaQuestionnaire ostiaQuestionnaire, TIRequest tiRequest);

	public void cloneFirewallRuleOstiaAnswers(Long cloneFrom, List<Long> cloneTo);

	public Long addUserFirewallRuleQuestionnaire(FirewallRuleQuestionnaire obj);

	public FirewallRuleQuestionnaire findFirewallRuleQuestionnaire(Long id);
	public void updateFirewallRuleQuestionnaire(long fwQuestionnaireId,String status);

	void updateAnswer(List<Long> cloneTo);

	void updateAnswer(FirewallRuleQuestionnaire firewallRuleQuestionnaire);

	public void cloneFirewallRuleQuestionnaire(
			List<FirewallRuleQuestionnaire> list);

	void updateFirewallRuleQuestionnaire(
			FirewallRuleQuestionnaire firewallRuleQuestionnaire);

	public FirewallRuleQuestionnaire findFWQuestionnaireByRuleId(Long ruleId);

	public boolean isRisk(Long id);
	
	List<Long> rulesExistsWithOlderBaseline(Long tiRequestId,String isIpReg);

	List<Long> getTIRequestsinRiskExecutionQueue();
	
	void updateRiskExecutionStatus(Long tiRequestId, String status, String userId,String ruleType);
	
	boolean isRiskExecutionInProgress(Long tiRequestId);
	
	void riskExecutionHistory(Long tiRequestId, String userId, String baselineName, Long ruleId,String isIpReg);

	public Double getRiskForCurrentCycle(Long tiRequestId, String conType);

	public void updateFirewallRuleQuestionnaire(Long fireWallRuleId);

	public Double getRiskForConn(Long processId,String conType);

	public Long getIPForConn(Long tiProcessId, String conType);
}

