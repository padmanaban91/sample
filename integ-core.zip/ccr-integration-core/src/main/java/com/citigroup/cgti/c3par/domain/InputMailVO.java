package com.citigroup.cgti.c3par.domain;


/**
 * The Class InputMailVO.
 */
public class InputMailVO extends BaseMailVO {
    // The below variable MAY or MAY NOT be present in the passed object (depends on the template requirement)

    /** The ti process. */
    private TIProcess tiProcess;

    /** The days remaining. */
    private String daysRemaining;

    /** The work item url. */
    private String workItemUrl;

    /** The implementation results. */
    private String implementationResults;

    /** The activity names. */
    private String activityNames;

    /** The display roles. */
    private String displayRoles;

    /** The last submitter comments. */
    private String lastSubmitterComments;

    /** The last submitter role. */
    private String lastSubmitterRole;
    
    private String projCoordInfo;
    
    private String businessJustification; 

    private String name;
    private String projectCoordinatorNames;
    private String businessOwnerNames;
    private String businessManagerNames;
    private String requestorNames;
    private String isoNames;
    
    private String approveURL;
    
    private String rejectURL;
    
    private String referenceNo;
    
    private int versionNumber;

    private C3PARUser user;
    
    
    public C3PARUser getUser() {
		return user;
	}

	public void setUser(C3PARUser user) {
		this.user = user;
	}

	public String getProjCoordInfo() {
		return projCoordInfo;
	}

	public void setProjCoordInfo(String projCoordInfo) {
		this.projCoordInfo = projCoordInfo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
     * Gets the last submitter comments.
     *
     * @return the last submitter comments
     */
    public String getLastSubmitterComments() {
	return lastSubmitterComments;
    }

    /**
     * Sets the last submitter comments.
     *
     * @param lastSubmitterComments the new last submitter comments
     */
    public void setLastSubmitterComments(String lastSubmitterComments) {
	this.lastSubmitterComments = lastSubmitterComments;
    }

    /**
     * Gets the last submitter role.
     *
     * @return the last submitter role
     */
    public String getLastSubmitterRole() {
	return lastSubmitterRole;
    }

    /**
     * Sets the last submitter role.
     *
     * @param lastSubmitterRole the new last submitter role
     */
    public void setLastSubmitterRole(String lastSubmitterRole) {
	this.lastSubmitterRole = lastSubmitterRole;
    }

    /**
     * Gets the activity names.
     *
     * @return the activity names
     */
    public String getActivityNames() {
	return activityNames;
    }

    /**
     * Sets the activity names.
     *
     * @param activityNames the new activity names
     */
    public void setActivityNames(String activityNames) {
	this.activityNames = activityNames;
    }

    /**
     * Gets the display roles.
     *
     * @return the display roles
     */
    public String getDisplayRoles() {
	return displayRoles;
    }

    /**
     * Sets the display roles.
     *
     * @param displayRoles the new display roles
     */
    public void setDisplayRoles(String displayRoles) {
	this.displayRoles = displayRoles;
    }

    /**
     * Gets the days remaining.
     *
     * @return the days remaining
     */
    public String getDaysRemaining() {
	return daysRemaining;
    }

    /**
     * Sets the days remaining.
     *
     * @param daysRemaining the new days remaining
     */
    public void setDaysRemaining(String daysRemaining) {
	this.daysRemaining = daysRemaining;
    }

    /**
     * Gets the ti process.
     *
     * @return the ti process
     */
    public TIProcess getTiProcess() {
	return tiProcess;
    }

    /**
     * Sets the ti process.
     *
     * @param tiProcess the new ti process
     */
    public void setTiProcess(TIProcess tiProcess) {
	this.tiProcess = tiProcess;
    }

    /**
     * Gets the work item url.
     *
     * @return the work item url
     */
    public String getWorkItemUrl() {
	return workItemUrl;
    }

    /**
     * Sets the work item url.
     *
     * @param workItemUrl the new work item url
     */
    public void setWorkItemUrl(String workItemUrl) {
	this.workItemUrl = workItemUrl;
    }

    /**
     * Gets the implementation results.
     *
     * @return the implementation results
     */
    public String getImplementationResults() {
	return implementationResults;
    }

    /**
     * Sets the implementation results.
     *
     * @param implementationResults the new implementation results
     */
    public void setImplementationResults(String implementationResults) {
	this.implementationResults = implementationResults;
    }

	public String getProjectCoordinatorNames() {
		return projectCoordinatorNames;
	}

	public void setProjectCoordinatorNames(String projectCoordinatorNames) {
		this.projectCoordinatorNames = projectCoordinatorNames;
	}

	public String getBusinessOwnerNames() {
		return businessOwnerNames;
	}

	public void setBusinessOwnerNames(String businessOwnerNames) {
		this.businessOwnerNames = businessOwnerNames;
	}

	public String getBusinessManagerNames() {
		return businessManagerNames;
	}

	public void setBusinessManagerNames(String businessManagerNames) {
		this.businessManagerNames = businessManagerNames;
	}

	public String getRequestorNames() {
		return requestorNames;
	}

	public void setRequestorNames(String requestorNames) {
		this.requestorNames = requestorNames;
	}

	public String getIsoNames() {
		return isoNames;
	}

	public void setIsoNames(String isoNames) {
		this.isoNames = isoNames;
	}

	/**
	 * @return the approveURL
	 */
	public String getApproveURL() {
		return approveURL;
	}

	/**
	 * @param approveURL the approveURL to set
	 */
	public void setApproveURL(String approveURL) {
		this.approveURL = approveURL;
	}

	/**
	 * @return the rejectURL
	 */
	public String getRejectURL() {
		return rejectURL;
	}

	/**
	 * @param rejectURL the rejectURL to set
	 */
	public void setRejectURL(String rejectURL) {
		this.rejectURL = rejectURL;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}

	public int getVersionNumber() {
		return versionNumber;
	}

	public String getBusinessJustification() {
		return businessJustification;
	}

	public void setBusinessJustification(String businessJustification) {
		this.businessJustification = businessJustification;
	}
	
}
