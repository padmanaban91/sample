package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

/**
 * The Class ProcessType.
 */
public class ProcessType extends Name implements Serializable {

}
