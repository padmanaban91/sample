/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;

/**
 * @author bv49858
 *
 */
public interface ECMConstants {

	public static final String GENERIC_LOOKUP_PROCESS_PRIORITY = "Process Priority";
	public static final String GENERIC_LOOKUP_REGION  = "Region";
	public static final String GENERIC_LOOKUP_COUNTRY  = "Country";
	
	public static final String GENERIC_LOOKUP_TYPE_OF_CONNECTIVITY_INVOLVED = "TYPE_OF_CONNECTIVITY_INVOLVED";
	public static final String CMP_REQUEST_TYPE = "CMP_REQUEST_TYPE";
	public static final String GENERIC_LOOKUP_AFFECTED_BUSINESS = "AFFECTED_BUSINESS";
	public static final String GENERIC_LOOKUP_GROUP_SECTOR_MAPPING = "GROUP_SECTOR_MAPPING";
	public static final String EMAIL_TEMPLATE_NAME = "COMMUNICATION_EMAIL_TEMPLATE_NAME";
	public static final String SLO_DAYS = "SLO_Days";
	public static final String GENERIC_LOOKUP_REQUEST_URGENCY ="REQUEST_URGENCY";
	public static final String STATUS_COMPLETED = "COMPLETED";
	public static final String IS_NEW = "NEW";
	public static final String STATUS_STARTED = "STARTED";
	public static final String CMP_REQUEST_CREATED = "CMP Request Created";
	public static final String CMP_REQUEST_ASSIGNED = "ECM Agent Assigned";
	public static final String CMP_REQUEST_REASSIGNED = "ECM Agent Reassigned";
	public static final String CMP_REQUEST_AWAITING = "Awaiting ECM Input";
	public static final String AWAITING_ADDITIONAL_INFO = "Awaiting Additional Information";
	public static final String RESPONSE_ADDITIONAL_INFO = "Additional Information Received";
	public static final String AWAITING_PAF_FAF_VERIFICATION = "Awaiting PAF/FAF Verification";
	public static final String RESPONSE_PAF_FAF_VERIFICATION = "PAF/FAF Response Received";
	public static final String CMP_REQUEST_CREATION="cmp_request_create";	
	public static final String TRANSFER_AGENT_TASK_CODE = "cmp_reassign_user";
	public static final String CANCEL_TASK_CODE = "cmp_cancel_request";
	public static final String CMP_USER_CREATION = "system";
	public static final String ASSIGN_AGENT_TASK_CODE = "cmp_assign_user";
	public static final String ECM = "ECM";
	public static final String EMAIL = "EMAIL";
	
	public static final String APPROVED = "Approved";
	public static final String ECM_TIMER = "ECM TIMER";
	public static final String BUSINESS_TIMER = "BUSINESS TIMER";
	public static final String GENERIC_LOOKUP_SLO_DAYS ="SLO_DAYS_REQUEST_URGENCY";
	public static final String ERROR_MSG_SOA="An error occurred while trying to fetch the details. Please enter valid input or contact helpdesk for assistance.";
	
}
