package com.citigroup.cgti.c3par.appsense.domain;

import com.citigroup.cgti.c3par.domain.Base;



/**
 * The Class OstiaQuestion.
 */
public class AppsenseOstiaQuestion extends Base {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The question id. */
    Long questionID;

    /** The answer desc. */
    String answerDesc;
    
    private ConnectionOstiaGroup conOstiagroup;
    
    public ConnectionOstiaGroup getConOstiagroup() {
		return conOstiagroup;
	}

	public void setConOstiagroup(ConnectionOstiaGroup conOstiagroup) {
		this.conOstiagroup = conOstiagroup;
	}

	/**
     * Gets the answer desc.
     *
     * @return the answer desc
     */
    public String getAnswerDesc() {
	return answerDesc;
    }

    /**
     * Sets the answer desc.
     *
     * @param answerDesc the new answer desc
     */
    public void setAnswerDesc(String answerDesc) {
	this.answerDesc = answerDesc;
    }

    /**
     * Gets the question id.
     *
     * @return the question id
     */
    public Long getQuestionID() {
	return questionID;
    }

    /**s
     * Sets the question id.
     *
     * @param questionID the new question id
     */
    public void setQuestionID(Long questionID) {
	this.questionID = questionID;
    }

}
