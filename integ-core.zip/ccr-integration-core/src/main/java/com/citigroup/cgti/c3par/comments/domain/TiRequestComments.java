package com.citigroup.cgti.c3par.comments.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

/*
 * @nc43495
 */
public class TiRequestComments extends Base{

	
	private static final long serialVersionUID = 1L;
	
	private TIRequest tiRequest;
	
	private Role role;
	
	private C3parUser user;
	
	private String comments;
	
	private String commentType;
	
	private Date commentDate;
	
	private String locked;
	
	private String activityId;
	
    private String approverSoeID;
    
    private String roleName;
    
    private int versionNumber;
    
    
	public int getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}

	public String getApproverSoeID() {
		return approverSoeID;
	}

	public void setApproverSoeID(String approverSoeID) {
		this.approverSoeID = approverSoeID;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public TIRequest getTiRequest() {
		return tiRequest;
	}

	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public C3parUser getUser() {
		return user;
	}

	public void setUser(C3parUser user) {
		this.user = user;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCommentType() {
		return commentType;
	}

	public void setCommentType(String commentType) {
		this.commentType = commentType;
	}

	public Date getCommentDate() {
		return commentDate;
	}

	public void setCommentDate(Date commentDate) {
		this.commentDate = commentDate;
	}

	public String getLocked() {
		return locked;
	}

	public void setLocked(String locked) {
		this.locked = locked;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	
	
	
	

}
