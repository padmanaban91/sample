/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * 
 * @author ne36745
 *
 */
public class HistoryFireWallRulePort extends Base {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private HistoryFireWallRule fireWallRule;
    private TIRequest updatedTIRequest;
    private TIRequest deletedTIRequest;
    private Port port;
    private String description;
    private String serviceName;
    private String defaultService;
    private String typeOfTraffic;
    private String controlMessage;
    private boolean deleted;
    private Long objRuleID;
    private Long rulePortId;

    public HistoryFireWallRulePort() {
    
    }

    /**
     * @return the fireWallRule
     */
    public HistoryFireWallRule getFireWallRule() {
	return fireWallRule;
    }

    /**
     * @param fireWallRule the fireWallRule to set
     */
    public void setFireWallRule(HistoryFireWallRule fireWallRule) {
	this.fireWallRule = fireWallRule;
    }

    /**
     * @return the updatedTIRequest
     */
    public TIRequest getUpdatedTIRequest() {
	return updatedTIRequest;
    }

    /**
     * @param updatedTIRequest the updatedTIRequest to set
     */
    public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
	this.updatedTIRequest = updatedTIRequest;
    }

    /**
     * @return the deletedTIRequest
     */
    public TIRequest getDeletedTIRequest() {
	return deletedTIRequest;
    }

    /**
     * @param deletedTIRequest the deletedTIRequest to set
     */
    public void setDeletedTIRequest(TIRequest deletedTIRequest) {
	this.deletedTIRequest = deletedTIRequest;
    }

    /**
     * @return the port
     */
    public Port getPort() {
	return port;
    }

    /**
     * @param port the port to set
     */
    public void setPort(Port port) {
	this.port = port;
    }

    /**
     * @return the description
     */
    public String getDescription() {
	return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
	this.description = description;
    }

    /**
     * @return the serviceName
     */
    public String getServiceName() {
	return serviceName;
    }

    /**
     * @param serviceName the serviceName to set
     */
    public void setServiceName(String serviceName) {
	this.serviceName = serviceName;
    }

    /**
     * @return the defaultService
     */
    public String getDefaultService() {
	return defaultService;
    }

    /**
     * @param defaultService the defaultService to set
     */
    public void setDefaultService(String defaultService) {
	this.defaultService = defaultService;
    }

    /**
     * @return the typeOfTraffic
     */
    public String getTypeOfTraffic() {
	return typeOfTraffic;
    }

    /**
     * @param typeOfTraffic the typeOfTraffic to set
     */
    public void setTypeOfTraffic(String typeOfTraffic) {
	this.typeOfTraffic = typeOfTraffic;
    }

	/**
	 * @return the deleted
	 */
	public boolean isDeleted() {
		return deleted;
	}

	/**
	 * @param deleted the deleted to set
	 */
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	/**
	 * @return the rulePortId
	 */
	public Long getRulePortId() {
		return rulePortId;
	}

	/**
	 * @param rulePortId the rulePortId to set
	 */
	public void setRulePortId(Long rulePortId) {
		this.rulePortId = rulePortId;
	}

	public Long getObjRuleID() {
		return objRuleID;
	}

	public void setObjRuleID(Long objRuleID) {
		this.objRuleID = objRuleID;
	}

	public String getControlMessage() {
		return controlMessage;
	}

	public void setControlMessage(String controlMessage) {
		this.controlMessage = controlMessage;
	}
    
}
