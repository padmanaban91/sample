

/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.businessjustification.domain;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.Location;


/**
 * The Class CitiContactEntity.
 */
@XmlRootElement
public class CitiContact
extends Base
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    /** The first name. */
    private	String	firstName;

    /** The last name. */
    private	String	lastName;
    
    private	String	roleName;
    
    private	String	roleId;

    /** The rits id. */
    private	String	ritsId;

    /** The itlc. */
    private	String	itlc;

    /** The organization. */
    private	String	organization;

    /** The phone. */
    private	String	phone;

    /** The email. */
    private	String	email;

    /** The sso id. */
    private	String	ssoId;
    
    private String employeeType;
    
    private String geId;
    
    private String isTerminated;
    
    private String managerGeId; 

    private String employeeStatus;

    private String supervisorGeId;
    
    private String supervisorEmail;

    private String latestSupervisorGeId;

    private String supervisorLimit;
    
    private String supervisorFirstName;
    
    private String supervisorLastName;
    
    private BusinessUnit businessUnit;
    
    private Location location;
    
    /** The dev access. */
    private String devAccess;

    /** The prd access. */
    private String prdAccess;

    /** The cross environment access. */
    private String crossEnvironmentAccess ;
    
    /** The local folder access. */
    private String localFolderAccess;

    
    private String devAccessXsl;
    
    private String prdAccessXsl;
    
    private String crossEnvXsl;
    
    private String localFolderXsl;
    
    private String gocCode;
    private String manSegmentId;
    private String dsmtRegionId;
    private String dsmtRegionName;
    private String dsmtSectorId;
    private String dsmtSectorName;
    private String dsmtBusinessUnitId;
    private String dsmtBusinessUnitName;
    
    
    @XmlElement
   	public String getDevAccessXsl() {
   		StringBuilder str = new StringBuilder();
   		if(this.devAccess != null && this.devAccess.equalsIgnoreCase("N")){
   			str.append("No Access");
   		}if(this.devAccess != null && this.devAccess.equalsIgnoreCase("U")){
   			str.append("User Access");
   		}if(this.devAccess != null && this.devAccess.equalsIgnoreCase("A")){
   			str.append("Admin Access");
   		}
   		return str.toString();
   	}
    

	public void setDevAccessXsl(String devAccessXsl) {
		this.devAccessXsl = devAccessXsl;
	}
	
	 @XmlElement
	public String getPrdAccessXsl() {
		StringBuilder str = new StringBuilder();
		if(this.prdAccess != null && this.prdAccess.equalsIgnoreCase("N")){
			str.append("No Access");
		}if(this.prdAccess != null && this.prdAccess.equalsIgnoreCase("U")){
			str.append("User Access");
		}if(this.prdAccess != null && this.prdAccess.equalsIgnoreCase("A")){
			str.append("Admin Access");
		}
		return str.toString();
	}

	public void setPrdAccessXsl(String prdAccessXsl) {
		this.prdAccessXsl = prdAccessXsl;
	}
	 @XmlElement
	public String getCrossEnvXsl() {
		StringBuilder str = new StringBuilder();
		if(this.crossEnvironmentAccess != null && this.crossEnvironmentAccess.equalsIgnoreCase("N")){
			str.append("No");
		}if(this.crossEnvironmentAccess != null && this.crossEnvironmentAccess.equalsIgnoreCase("Y")){
			str.append("Yes");
		}
		return str.toString();
	}

	public void setCrossEnvXsl(String crossEnvXsl) {
		this.crossEnvXsl = crossEnvXsl;
	}
	 @XmlElement
	public String getLocalFolderXsl() {
		StringBuilder str = new StringBuilder();
		if(this.localFolderAccess != null && this.localFolderAccess.equalsIgnoreCase("N")){
			str.append("No");
		}if(this.localFolderAccess != null && this.localFolderAccess.equalsIgnoreCase("Y")){
			str.append("Yes");
		}
		return str.toString();
	}
	 
	 public CitiContact() {
		setCreated_date(new Date());
	}
	 

	public void setLocalFolderXsl(String localFolderXsl) {
		this.localFolderXsl = localFolderXsl;
	}

	public String getDevAccess() {
		return devAccess;
	}

	public void setDevAccess(String devAccess) {
		this.devAccess = devAccess;
	}

	public String getPrdAccess() {
		return prdAccess;
	}

	public void setPrdAccess(String prdAccess) {
		this.prdAccess = prdAccess;
	}

	public String getCrossEnvironmentAccess() {
		return crossEnvironmentAccess;
	}

	public void setCrossEnvironmentAccess(String crossEnvironmentAccess) {
		this.crossEnvironmentAccess = crossEnvironmentAccess;
	}

	public String getLocalFolderAccess() {
		return localFolderAccess;
	}

	public void setLocalFolderAccess(String localFolderAccess) {
		this.localFolderAccess = localFolderAccess;
	}
	
	 @XmlElement
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	 @XmlElement
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getRitsId() {
		return ritsId;
	}

	public void setRitsId(String ritsId) {
		this.ritsId = ritsId;
	}

	public String getItlc() {
		return itlc;
	}

	public void setItlc(String itlc) {
		this.itlc = itlc;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	 @XmlElement
	public String getSsoId() {
		return ssoId;
	}

	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public String getGeId() {
		return geId;
	}

	public void setGeId(String geId) {
		this.geId = geId;
	}

	public String getIsTerminated() {
		return isTerminated;
	}

	public void setIsTerminated(String isTerminated) {
		this.isTerminated = isTerminated;
	}

	public String getManagerGeId() {
		return managerGeId;
	}

	public void setManagerGeId(String managerGeId) {
		this.managerGeId = managerGeId;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public String getSupervisorGeId() {
		return supervisorGeId;
	}

	public void setSupervisorGeId(String supervisorGeId) {
		this.supervisorGeId = supervisorGeId;
	}

	public String getSupervisorEmail() {
		return supervisorEmail;
	}

	public void setSupervisorEmail(String supervisorEmail) {
		this.supervisorEmail = supervisorEmail;
	}

	public String getLatestSupervisorGeId() {
		return latestSupervisorGeId;
	}

	public void setLatestSupervisorGeId(String latestSupervisorGeId) {
		this.latestSupervisorGeId = latestSupervisorGeId;
	}

	public String getSupervisorLimit() {
		return supervisorLimit;
	}

	public void setSupervisorLimit(String supervisorLimit) {
		this.supervisorLimit = supervisorLimit;
	}

	public String getSupervisorFirstName() {
		return supervisorFirstName;
	}

	public void setSupervisorFirstName(String supervisorFirstName) {
		this.supervisorFirstName = supervisorFirstName;
	}

	public String getSupervisorLastName() {
		return supervisorLastName;
	}

	public void setSupervisorLastName(String supervisorLastName) {
		this.supervisorLastName = supervisorLastName;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public BusinessUnit getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(BusinessUnit businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}


	public String getGocCode() {
		return gocCode;
	}


	public void setGocCode(String gocCode) {
		this.gocCode = gocCode;
	}


	public String getManSegmentId() {
		return manSegmentId;
	}


	public void setManSegmentId(String manSegmentId) {
		this.manSegmentId = manSegmentId;
	}


	public String getDsmtRegionId() {
		return dsmtRegionId;
	}


	public void setDsmtRegionId(String dsmtRegionId) {
		this.dsmtRegionId = dsmtRegionId;
	}


	public String getDsmtRegionName() {
		return dsmtRegionName;
	}


	public void setDsmtRegionName(String dsmtRegionName) {
		this.dsmtRegionName = dsmtRegionName;
	}


	public String getDsmtSectorId() {
		return dsmtSectorId;
	}


	public void setDsmtSectorId(String dsmtSectorId) {
		this.dsmtSectorId = dsmtSectorId;
	}


	public String getDsmtSectorName() {
		return dsmtSectorName;
	}


	public void setDsmtSectorName(String dsmtSectorName) {
		this.dsmtSectorName = dsmtSectorName;
	}


	public String getDsmtBusinessUnitId() {
		return dsmtBusinessUnitId;
	}


	public void setDsmtBusinessUnitId(String dsmtBusinessUnitId) {
		this.dsmtBusinessUnitId = dsmtBusinessUnitId;
	}


	public String getDsmtBusinessUnitName() {
		return dsmtBusinessUnitName;
	}


	public void setDsmtBusinessUnitName(String dsmtBusinessUnitName) {
		this.dsmtBusinessUnitName = dsmtBusinessUnitName;
	}
	
	
 }
