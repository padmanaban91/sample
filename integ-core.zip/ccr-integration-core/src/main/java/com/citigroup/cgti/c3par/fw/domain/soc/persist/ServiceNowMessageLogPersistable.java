/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain.soc.persist;

import com.citigroup.cgti.c3par.fw.domain.ServiceNowMessageLog;
import com.citigroup.cgti.c3par.persistance.Persistable;

/**
 * @author nc43495
 *
 */
public interface ServiceNowMessageLogPersistable extends Persistable {

 void saveServiceNowMessage(ServiceNowMessageLog serviceNowMessage);
	
 void updateServiceNowMessage(ServiceNowMessageLog serviceNowMessage);

 void purgeLogText();
	


 ServiceNowMessageLog findServiceNowMessageLogByID(Long id);

public String getServiceNowCTXml(Long tiReqId, Long rfcReqId, String changeRequestNumber, ServiceNowMessageLog snowMessageLog);
 
}