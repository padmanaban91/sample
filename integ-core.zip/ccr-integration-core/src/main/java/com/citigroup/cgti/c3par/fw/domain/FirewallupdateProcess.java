package com.citigroup.cgti.c3par.fw.domain;

import java.util.List;

public class FirewallupdateProcess {
	
	private String firewallName;
	private List<Firewall> firewalls;
	private Firewall selectedFirewall;
	private String firewallsJson;
	
	public String getFirewallsJson() {
		return firewallsJson;
	}
	public void setFirewallsJson(String firewallsJson) {
		this.firewallsJson = firewallsJson;
	}
	public Firewall getSelectedFirewall() {
		return selectedFirewall;
	}
	public void setSelectedFirewall(Firewall selectedFirewall) {
		this.selectedFirewall = selectedFirewall;
	}
	public String getFirewallName() {
		return firewallName;
	}
	public void setFirewallName(String firewallName) {
		this.firewallName = firewallName;
	}
	public List<Firewall> getFirewalls() {
		return firewalls;
	}
	public void setFirewalls(List<Firewall> firewalls) {
		this.firewalls = firewalls;
	} 

}
