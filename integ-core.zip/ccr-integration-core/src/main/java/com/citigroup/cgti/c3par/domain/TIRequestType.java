package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

/**
 * The Class TIRequestType.
 */
public class TIRequestType implements Serializable {

    private Long id;
	
    private String name;

    public void setId(Long id) {
    	this.id = id;
    }

    public Long getId() {
    	return id;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
