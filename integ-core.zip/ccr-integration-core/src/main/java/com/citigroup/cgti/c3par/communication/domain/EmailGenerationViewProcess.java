package com.citigroup.cgti.c3par.communication.domain;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.domain.CMPRole;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.DsmtSgmntSector;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;


public class EmailGenerationViewProcess {
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	private CMPRequest cmpRequest;
	private List<CMPRequest> resolveITMessageList;	
	
	private String cmpreqID;
	private Date dateAssigned; 
	private Date chgDate;
	private Date implementedDate;
	private String ccrID;
	private String requester;
	private String primaryOwner;
	private String additionalContacts;
	private String chooseEmail;
	private String ecmAgent;
	private String addNote;
	private String chgID;
	private String affectedBus;
	private String link;
	private String projectName;
	private String phoneNo;
	private String firstName;
	private String lastName;
	private String soeId;
	private String roleName;
	private String caspUrl;
	private String globalDirUrl;
	private String resolveItDetailUrl;
	
	private List itemValueList;
	private List<CMPRole> cmprolesList;
	private List<Region> regionList;
	private List<Sector> sectorList;
	private List<BusinessUnit> businessUnitList;
	
	private List<GenericLookup> urgencyList;
	private List<GenericLookup> requestTypeList;
	private List<GenericLookup> affectedBusinessList;
	private List<GenericLookup> typeOfConnectivityList;
	private List<GenericLookup> emailTemplateList;
	private List<GenericLookup> slodaysList;
	private List<TIMailAudit> tiMailAuditList;

	private String textForSubject;
	private String additionalText;
	private String additionalTextHold;
	

	private String assignedUser;
	private String assistanceRequested;
	private String cancelReason;
	private Long sloDays;
	private String assignUser;
	private String leadComment;
/*ECM Start Work FLow*/	
	private String comments;
	private String reqAdditionalInfo;
	/*ECM End Work FLow*/	

	private List<CommonsMultipartFile> attachedFile;
	private boolean closeAssistanceReqFlag;
	private List<Sector> projectSectorList;
	
	private List<DsmtSgmntSector> dsmtSegmentSectorList;

    
	
	
	public EmailGenerationViewProcess(){		
	}
	
	public EmailGenerationViewProcess(String soeId,String lasName,String firstName){
		super();
		this.soeId = soeId;
		this.lastName = lasName;
		this.firstName = firstName;
	}
	public List<Sector> getProjectSectorList() {
        return projectSectorList;
    }

    public void setProjectSectorList(List<Sector> projectSectorList) {
        this.projectSectorList = projectSectorList;
    }
	
	public String getAdditionalTextHold() {
		return additionalTextHold;
	}

	public void setAdditionalTextHold(String additionalTextHold) {
		this.additionalTextHold = additionalTextHold;
	}
	
	/*ECM Start Work FLow*/	
	
	
	public String getComments() {
		return comments;
	}

	public boolean isCloseAssistanceReqFlag() {
		return closeAssistanceReqFlag;
	}

	public void setCloseAssistanceReqFlag(boolean closeAssistanceReqFlag) {
		this.closeAssistanceReqFlag = closeAssistanceReqFlag;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getReqAdditionalInfo() {
		return reqAdditionalInfo;
	}

	public void setReqAdditionalInfo(String reqAdditionalInfo) {
		this.reqAdditionalInfo = reqAdditionalInfo;
	}
	
	/*ECM End Work FLow*/

	

	public String getLeadComment() { 
		return leadComment;
	}

	public List<DsmtSgmntSector> getDsmtSegmentSectorList() {
		return dsmtSegmentSectorList;
	}

	public void setDsmtSegmentSectorList(List<DsmtSgmntSector> dsmtSegmentSectorList) {
		this.dsmtSegmentSectorList = dsmtSegmentSectorList;
	}

	public void setLeadComment(String leadComment) {
		this.leadComment = leadComment;
	}

	public List<CMPRequest> getResolveITMessageList() {
		return resolveITMessageList;
	}

	public void setResolveITMessageList(List<CMPRequest> resolveITMessageList) {
		this.resolveITMessageList = resolveITMessageList;
	}

	public CMPRequest getCmpRequest() {
		return cmpRequest;
	}

	public void setCmpRequest(CMPRequest cmpRequest) {
		this.cmpRequest = cmpRequest;
	}

	public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

	public Long getSloDays() {
		return sloDays;
	}

	public void setSloDays(Long sloDays) {
		this.sloDays = sloDays;
	}

	public String getCmpreqID() {
		return cmpreqID;
	}

	public void setCmpreqID(String cmpreqID) {
		this.cmpreqID = cmpreqID;
	}

	public Date getDateAssigned() {
		return dateAssigned;
	}

	public void setDateAssigned(Date dateAssigned) {
		this.dateAssigned = dateAssigned;
	}

	public Date getChgDate() {
		return chgDate;
	}

	public void setChgDate(Date chgDate) {
		this.chgDate = chgDate;
	}

	public Date getImplementedDate() {
		return implementedDate;
	}

	public void setImplementedDate(Date implementedDate) {
		this.implementedDate = implementedDate;
	}

	public String getCcrID() {
		return ccrID;
	}

	public void setCcrID(String ccrID) {
		this.ccrID = ccrID;
	}

	public String getRequester() {
		return requester;
	}

	public void setRequester(String requester) {
		this.requester = requester;
	}

	public String getPrimaryOwner() {
		return primaryOwner;
	}

	public void setPrimaryOwner(String primaryOwner) {
		this.primaryOwner = primaryOwner;
	}

	public String getAdditionalContacts() {
		return additionalContacts;
	}

	public void setAdditionalContacts(String additionalContacts) {
		this.additionalContacts = additionalContacts;
	}

	public String getChooseEmail() {
		return chooseEmail;
	}

	public void setChooseEmail(String chooseEmail) {
		this.chooseEmail = chooseEmail;
	}

	public String getAdditionalText() {
		return additionalText;
	}

	public void setAdditionalText(String additionalText) {
		this.additionalText = additionalText;
	}

	public String getEcmAgent() {
		return ecmAgent;
	}

	public void setEcmAgent(String ecmAgent) {
		this.ecmAgent = ecmAgent;
	}

	public String getAddNote() {
		return addNote;
	}

	public void setAddNote(String addNote) {
		this.addNote = addNote;
	}

	public String getChgID() {
		return chgID;
	}

	public void setChgID(String chgID) {
		this.chgID = chgID;
	}

	public String getAffectedBus() {
		return affectedBus;
	}

	public void setAffectedBus(String affectedBus) {
		this.affectedBus = affectedBus;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public List<Region> getRegionList() {
		return regionList;
	}

	public void setRegionList(List<Region> regionList) {
		this.regionList = regionList;
	}

	public List<Sector> getSectorList() {
		return sectorList;
	}

	public void setSectorList(List<Sector> sectorList) {
		this.sectorList = sectorList;
	}

	public List<GenericLookup> getUrgencyList() {
		return urgencyList;
	}

	public void setUrgencyList(List<GenericLookup> urgencyList) {
		this.urgencyList = urgencyList;
	}

	public List<GenericLookup> getRequestTypeList() {
		return requestTypeList;
	}

	public void setRequestTypeList(List<GenericLookup> requestTypeList) {
		this.requestTypeList = requestTypeList;
	}

	public List<GenericLookup> getAffectedBusinessList() {
		return affectedBusinessList;
	}

	public void setAffectedBusinessList(List<GenericLookup> affectedBusinessList) {
		this.affectedBusinessList = affectedBusinessList;
	}

	public List<BusinessUnit> getBusinessUnitList() {
		return businessUnitList;
	}

	public void setBusinessUnitList(List<BusinessUnit> businessUnitList) {
		this.businessUnitList = businessUnitList;
	}

	public String getAssignedUser() {
		return assignedUser;
	}

	public void setAssignedUser(String assignedUser) {
		this.assignedUser = assignedUser;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getTextForSubject() {
		return textForSubject;
	}

	public void setTextForSubject(String textForSubject) {
		this.textForSubject = textForSubject;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSoeId() {
		return soeId;
	}

	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}
	
	public List getItemValueList() {
		return itemValueList;
	}

	public void setItemValueList(List itemValueList) {
		this.itemValueList = itemValueList;
	}

	public List<CMPRole> getCmprolesList() {
		return cmprolesList;
	}

	public void setCmprolesList(List<CMPRole> cmprolesList) {
		this.cmprolesList = cmprolesList;
	}

	public List<GenericLookup> getTypeOfConnectivityList() {
		return typeOfConnectivityList;
	}

	public void setTypeOfConnectivityList(List<GenericLookup> typeOfConnectivityList) {
		this.typeOfConnectivityList = typeOfConnectivityList;
	}

	public List<GenericLookup> getEmailTemplateList() {
		return emailTemplateList;
	}

	public void setEmailTemplateList(List<GenericLookup> emailTemplateList) {
		this.emailTemplateList = emailTemplateList;
	}
	
	public List<TIMailAudit> getTiMailAuditList() {
		return tiMailAuditList;
	}

	public void setTiMailAuditList(List<TIMailAudit> tiMailAuditList) {
		this.tiMailAuditList = tiMailAuditList;
	}

	public String getAssistanceRequested() {
		return assistanceRequested;
	}

	public void setAssistanceRequested(String assistanceRequested) {
		this.assistanceRequested = assistanceRequested;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getCaspUrl() {
		return caspUrl;
	}

	public void setCaspUrl(String caspUrl) {
		this.caspUrl = caspUrl;
	}

	public String getGlobalDirUrl() {
		return globalDirUrl;
	}

	public void setGlobalDirUrl(String globalDirUrl) {
		this.globalDirUrl = globalDirUrl;
	}

	public String getResolveItDetailUrl() {
		return resolveItDetailUrl;
	}

	public void setResolveItDetailUrl(String resolveItDetailUrl) {
		this.resolveItDetailUrl = resolveItDetailUrl;
	}

	public List<CommonsMultipartFile> getAttachedFile() {
		return attachedFile;
	}

	public void setAttachedFile(List<CommonsMultipartFile> attachedFile) {
		this.attachedFile = attachedFile;
	}

	public List<GenericLookup> getSlodaysList() {
		return slodaysList;
	}

	public void setSlodaysList(List<GenericLookup> slodaysList) {
		this.slodaysList = slodaysList;
	}

	
	public void sendEmailGenView(String  chooseEmail,CMPRequest resolveITMessage) {
		ccrBeanFactory.getiMailModule().sendEcmEmailGeneration(chooseEmail,resolveITMessage); 
	}

	
	public void sendEmailGenerationView(String  chooseEmail,CmpRequestDTO commEmail) {
		ccrBeanFactory.getiMailModule().sendEcmEmailViewGeneration(chooseEmail,commEmail); 
	}
		
	
	public List<GenericLookup> loadGenericLookupByName(String name) {
		return ccrBeanFactory.getCommonServicePersistable().getGenericLookupByName(name);
	}
	public List<GenericLookup> loadEmailTemplatesByName(String name) {
		return ccrBeanFactory.getCommonServicePersistable().getEmailTemplateList(name);
	}
	
	
	
	public List<GenericLookup> loadGenericLookupData(List<String> names) {
		return ccrBeanFactory.getCommonServicePersistable().getGenericLookupData(names);
	}

	
	public List<Region> loadRegionList() {
		return ccrBeanFactory.getRelationshipServicePersistable().getRegionList();
	}

	
	public CitiContact getCitiContactDetails(String ssoId) {
		return ccrBeanFactory.getCmpRequestPersistable().getUserIdForSsoId(ssoId);
	}	

	
	public void cmpActivityTrail(Long cmpId, String ssoId, String taskCode, String activityStatus) {
		ccrBeanFactory.getCmpRequestPersistable().cmpActivityTrail(cmpId, ssoId, taskCode, activityStatus);
	}	
	
	
	public List<Sector> loadSectorList(String regionName) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().loadSectorListByName(regionName);
	}	
	
	
	public List<BusinessUnit> loadBusinessUnitList(String regionName,String sectorName) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().loadBusinessUnitListByName(regionName, sectorName);
	}

	
	public List<CMPRole> loadCMPRoles() {
		return ccrBeanFactory.getEmailGenViewServicePersistable().loadCMPRoles();
	}
	
	
	public CMPRequest getCMPRequestDetails(String cmpReqId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getCMPRequestDetails(cmpReqId);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateCMPRequestDetails(CMPRequest cmpRequest) {
		ccrBeanFactory.getEmailGenViewServicePersistable().updateCMPRequestDetails(cmpRequest);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateAddNoteDetails(CMPRequestNotes cmpRequestNotes) {
		ccrBeanFactory.getEmailGenViewServicePersistable().updateAddNoteDetails(cmpRequestNotes);
	}

	
	public void transferEcmAgent(String reassignedUser,String cmpId , String userId) {
		ccrBeanFactory.getEmailGenViewServicePersistable().transferEcmAgent(reassignedUser, cmpId, userId);
	}

	
	public CitiContact getAgentDetails(String ssoId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getAgentDetails(ssoId);		
	}
	
	
	public CMPRequest getCMPRequestDetailsByOerderId(String cmpReqId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getCMPRequestDetailsByOrderId(cmpReqId);
	}

	
	public int updateCMPRequestStatus(Long cmpId,String status) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().updateCMPRequestStatus(cmpId,status);
	}

	
	public List<Map<String, String>> getChangeRequestDetails(Long conReqId, String cmpId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getChangeRequestDetails(conReqId,cmpId);
	}
	
	
	public List<TIMailAudit> getAuditTrialDetail(Long cmpId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getAuditTrialDetail(cmpId);
	}

	
	public boolean isWaitingforBusinessReply(Long cmpId,String activityCode) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().isWaitingforBusinessReply(cmpId,activityCode);
	}
	
	
	public boolean checkValidUser(String ssoid){		
		return  ccrBeanFactory.getResolveITFieldPersistable().checkValidUser(ssoid);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public boolean updateAssignedEcmUser(String orderId, String assignedUser2,
			Long sloDays2, String remoteUser,String leadComments) {
		return ccrBeanFactory.getResolveITFieldPersistable().updateAssignedEcmUser(orderId,assignedUser2,sloDays2,remoteUser,leadComments);
	}
	
	/*@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public void checkTi(CMPRequest cmprequest){		
		return  emailGenViewServicePersistable.checkTi(cmprequest);
	}*/

	public String getAssignUser() {
		return assignUser;
	}

	public void setAssignUser(String assignUser) {
		this.assignUser = assignUser;
	}
	
	
	public void checkColourstatus(CMPRequest cmprequest){		
		ccrBeanFactory.getEmailGenViewServicePersistable().checkColourstatus(cmprequest);
		}

	public boolean checkCmpAssitanceReqFlag(Long cmpId) {
		// TODO Auto-generated method stub
		boolean cmpCloseAssistanceReqFlag=ccrBeanFactory.getEmailGenViewServicePersistable().checkCmpAssitanceReqFlag(cmpId);
		return cmpCloseAssistanceReqFlag;
	}
	  public List<Sector> loadProjectSectorList() {
	        
	        return ccrBeanFactory.getResolveITFieldPersistable().getProjectSectorList();
	    }
	  @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	    public boolean updateAssignedEcmUser(String orderId, String assignedUser2, Long sloDays2, String remoteUser,
	            String leadComments,String projectSector) {
	        return ccrBeanFactory.getResolveITFieldPersistable().updateAssignedEcmUser(orderId, assignedUser2, sloDays2,
	                remoteUser, leadComments,projectSector);
	    }
	  
	  public CitiContact getCitiContactByGEId(String geId) {
			return ccrBeanFactory.getCmpRequestPersistable().getuserIdForgGeid(geId);
		}
	  
	  public List<DsmtSgmntSector> getDsmtSgmntSectorList() {
	        
	        return ccrBeanFactory.getResolveITFieldPersistable().getDsmtSgmntSectorList();
	    }
	
}
