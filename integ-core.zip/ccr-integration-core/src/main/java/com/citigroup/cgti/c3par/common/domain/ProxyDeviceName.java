package com.citigroup.cgti.c3par.common.domain;

import com.citigroup.cgti.c3par.domain.Base;

public class ProxyDeviceName extends Base {

private static final long serialVersionUID = 1L;

private ProxyLocation proxyLocation;

private String policyName;

private String instanceName;

private String installTarget;

private String deviceName;

private String countryCode;

private String createdBy;

private String modifiedBy;

private String country;

/**
 * @return the createdBy
 */
public String getCreatedBy() {
	return createdBy;
}

/**
 * @param createdBy the createdBy to set
 */
public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}

/**
 * @return the modifiedBy
 */
public String getModifiedBy() {
	return modifiedBy;
}

/**
 * @param modifiedBy the modifiedBy to set
 */
public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
}

/**
 * @return the proxyLocation
 */
public ProxyLocation getProxyLocation() {
	return proxyLocation;
}

/**
 * @param proxyLocation the proxyLocation to set
 */
public void setProxyLocation(ProxyLocation proxyLocation) {
	this.proxyLocation = proxyLocation;
}

/**
 * @return the policyName
 */
public String getPolicyName() {
	return policyName;
}

/**
 * @param policyName the policyName to set
 */
public void setPolicyName(String policyName) {
	this.policyName = policyName;
}

/**
 * @return the instanceName
 */
public String getInstanceName() {
	return instanceName;
}

/**
 * @param instanceName the instanceName to set
 */
public void setInstanceName(String instanceName) {
	this.instanceName = instanceName;
}

/**
 * @return the installTarget
 */
public String getInstallTarget() {
	return installTarget;
}

/**
 * @param installTarget the installTarget to set
 */
public void setInstallTarget(String installTarget) {
	this.installTarget = installTarget;
}

/**
 * @return the deviceName
 */
public String getDeviceName() {
	return deviceName;
}

/**
 * @param deviceName the deviceName to set
 */
public void setDeviceName(String deviceName) {
	this.deviceName = deviceName;
}

/**
 * 
 * @return
 */
public String getCountryCode() {
	return countryCode;
}

/**
 * 
 * @param countryCode
 */
public void setCountryCode(String countryCode) {
	this.countryCode = countryCode;
}


/**
 * @return
 */
public String getCountry() {
	return country;
}

public void setCountry(String country) {
	this.country = country;
}


}
