package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

/**
 * The Class Region.
 */
@XmlType(name="RegionEntity")
public class Region extends Name implements Serializable{

}
