/**
 * 
 */
package com.citigroup.cgti.c3par.audit.domain;

import java.util.Calendar;
import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * @author bv49858
 *
 */
public class AuditC3parUsersData extends Base {
	
	private static final long serialVersionUID = 1L;
	
	private Long userId;
	private String action;
	private String updatedByUser;
	private String mgrApprover;
	private Date mgrApprovedDate;
	private String isaApprover;
	private Date isaApprovedDate;
	private String isActiveCurrent;
	private String isActivePrev;
	private String roleStrCurrent;
	private String roleStrPrev;
	private String entStrCurrent;
	private String entStrPrev;
	private Date auditLogInsertedDate;
	private String sysadminApprover;
	private Date sysadminReviewedDate;
	private String hostName;
	private Calendar logDateTime;
	private String hostNameAddress;
	private String eventDescription;
	private String affectedUser;
	
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getUpdatedByUser() {
		return updatedByUser;
	}
	public void setUpdatedByUser(String updatedByUser) {
		this.updatedByUser = updatedByUser;
	}
	public String getMgrApprover() {
		return mgrApprover;
	}
	public void setMgrApprover(String mgrApprover) {
		this.mgrApprover = mgrApprover;
	}
	public Date getMgrApprovedDate() {
		return mgrApprovedDate;
	}
	public void setMgrApprovedDate(Date mgrApprovedDate) {
		this.mgrApprovedDate = mgrApprovedDate;
	}
	public String getIsaApprover() {
		return isaApprover;
	}
	public void setIsaApprover(String isaApprover) {
		this.isaApprover = isaApprover;
	}
	public Date getIsaApprovedDate() {
		return isaApprovedDate;
	}
	public void setIsaApprovedDate(Date isaApprovedDate) {
		this.isaApprovedDate = isaApprovedDate;
	}
	public String getIsActiveCurrent() {
		return isActiveCurrent;
	}
	public void setIsActiveCurrent(String isActiveCurrent) {
		this.isActiveCurrent = isActiveCurrent;
	}
	public String getIsActivePrev() {
		return isActivePrev;
	}
	public void setIsActivePrev(String isActivePrev) {
		this.isActivePrev = isActivePrev;
	}
	public String getRoleStrCurrent() {
		return roleStrCurrent;
	}
	public void setRoleStrCurrent(String roleStrCurrent) {
		this.roleStrCurrent = roleStrCurrent;
	}
	public String getRoleStrPrev() {
		return roleStrPrev;
	}
	public void setRoleStrPrev(String roleStrPrev) {
		this.roleStrPrev = roleStrPrev;
	}
	public String getEntStrCurrent() {
		return entStrCurrent;
	}
	public void setEntStrCurrent(String entStrCurrent) {
		this.entStrCurrent = entStrCurrent;
	}
	public String getEntStrPrev() {
		return entStrPrev;
	}
	public void setEntStrPrev(String entStrPrev) {
		this.entStrPrev = entStrPrev;
	}
	public Date getAuditLogInsertedDate() {
		return auditLogInsertedDate;
	}
	public void setAuditLogInsertedDate(Date auditLogInsertedDate) {
		this.auditLogInsertedDate = auditLogInsertedDate;
	}
	public String getSysadminApprover() {
		return sysadminApprover;
	}
	public void setSysadminApprover(String sysadminApprover) {
		this.sysadminApprover = sysadminApprover;
	}
	public Date getSysadminReviewedDate() {
		return sysadminReviewedDate;
	}
	public void setSysadminReviewedDate(Date sysadminReviewedDate) {
		this.sysadminReviewedDate = sysadminReviewedDate;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public Calendar getLogDateTime() {
		return logDateTime;
	}
	public void setLogDateTime(Calendar logDateTime) {
		this.logDateTime = logDateTime;
	}
	public String getHostNameAddress() {
		return hostNameAddress;
	}
	public void setHostNameAddress(String hostNameAddress) {
		this.hostNameAddress = hostNameAddress;
	}
	public String getEventDescription() {
		return eventDescription;
	}
	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}
	
	public String getAffectedUser() {
		return affectedUser;
	}
	public void setAffectedUser(String affectedUser) {
		this.affectedUser = affectedUser;
	}
	@Override
	public String toString() {
		return "AuditC3parUsersData [action=" + action
				+ ", auditLogInsertedDate=" + auditLogInsertedDate
				+ ", entStrCurrent=" + entStrCurrent + ", entStrPrev="
				+ entStrPrev + ", eventDescription=" + eventDescription
				+ ", hostName=" + hostName + ", hostNameAddress="
				+ hostNameAddress + ", isActiveCurrent=" + isActiveCurrent
				+ ", isActivePrev=" + isActivePrev + ", isaApprovedDate="
				+ isaApprovedDate + ", isaApprover=" + isaApprover
				+ ", logDateTime=" + logDateTime.getTime().toString() + ", mgrApprovedDate="
				+ mgrApprovedDate + ", mgrApprover=" + mgrApprover
				+ ", roleStrCurrent=" + roleStrCurrent + ", roleStrPrev="
				+ roleStrPrev + ", sysadminApprover=" + sysadminApprover
				+ ", sysadminReviewedDate=" + sysadminReviewedDate
				+ ", updatedByUser=" + updatedByUser + ", userId=" + userId
				+ ", affectedUser=" + affectedUser+"]";
	}
	

}
