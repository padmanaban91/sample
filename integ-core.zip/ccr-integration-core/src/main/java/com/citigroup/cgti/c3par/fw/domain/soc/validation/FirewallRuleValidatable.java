/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain.soc.validation;

import java.util.Map;

/**
 * @author bs45969
 *
 */
public interface FirewallRuleValidatable {

    public Map<String, String> validateOnCreate();

    public Map<String, String> validateOnUpdate();

    public Map<String, String> validateOnDelete();
}
