package com.citigroup.cgti.c3par;

import com.mentisys.dao.DatabaseException;


/**
 * The Class UpdateException.
 */
public class UpdateException extends DatabaseException
{

    /** The m_ nested exception. */
    Throwable m_NestedException = null;

    /**
     * Instantiates a new update exception.
     *
     * @param msg the msg
     * @param t the t
     */
    public UpdateException(String msg, Throwable t)
    {
	super(msg,t );
	m_NestedException = t;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
	String s = super.toString();
	if (m_NestedException != null)
	{
	    s += " >>>NESTED>>> " + m_NestedException.toString();
	}

	return s;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseException#getNestedException()
     */
    public Throwable getNestedException()
    {
	return m_NestedException;
    }
}
