package com.citigroup.cgti.c3par.fw.service;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.citigroup.cgti.c3par.bpm.ejb.search.ResolveITQueueSender;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;
import com.tibco.tibjms.TibjmsQueue;

public class ResolveITQueueSenderImpl implements ResolveITQueueSender {

	private static Logger LOGGER = Logger.getLogger(ResolveITQueueSenderImpl.class);

	@Autowired
	private TibjmsQueue resolveITSender;
	private JmsTemplate jmsTemplate_resolveIT;
	
	public JmsTemplate getJmsTemplate_resolveIT() {
		return jmsTemplate_resolveIT;
	}

	public void setJmsTemplate_resolveIT(JmsTemplate jmsTemplate_resolveIT) {
		this.jmsTemplate_resolveIT = jmsTemplate_resolveIT;
	}

	CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		if(appContext!=null && appContext.containsBean("cCRBeanFactory")){
			ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
		}else{
			System.out.println("appContext is null");
		}
		
	}

	public void sendMesage(final String message) {
		LOGGER.debug("message to be sent to ResolveIT : " + message);
		MessageCreator messageCreator = new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage(message);
			}
		};
		
		if(ccrBeanFactory.getJmsTemplate_resolveIT()!=null){
			jmsTemplate_resolveIT=ccrBeanFactory.getJmsTemplate_resolveIT();
		}else{
			ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
			if(appContext!=null && appContext.containsBean("jmsTemplate_resolveIT")){
				jmsTemplate_resolveIT=(JmsTemplate)appContext.getBean("jmsTemplate_resolveIT");
			}
		}
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("JMSTemplate from ccrbeanFactory: " + jmsTemplate_resolveIT);
			LOGGER.debug("messageCreator : " + messageCreator.toString());
		}
		jmsTemplate_resolveIT.send(resolveITSender == null ? ccrBeanFactory.getResolveITSender() : resolveITSender, messageCreator);
		LOGGER.info("Message sent to ResolveIT Successfully..!!");
	}
}