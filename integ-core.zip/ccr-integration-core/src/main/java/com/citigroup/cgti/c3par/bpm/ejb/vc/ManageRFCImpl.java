package com.citigroup.cgti.c3par.bpm.ejb.vc;

import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.BASICINFO;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.IMPLEMENTATIONPLAN;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.RFC_REQ_TYPE_FIREWALL;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.RFC_REQ_TYPE_PROXY;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_BACKOUTPLAN;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_BASICINFO;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_DESCRIPTION;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_NETINFO;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_NETWORKDATA;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_REASON;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_TESTPLAN;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_DESCRIPTION_PROXY;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_BACKOUTPLAN_PROXY;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_TESTPLAN_PROXY;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_PRE_TESTPLAN_PROXY;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.ADD_REQ_DETAILS;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.APP_INSTANCE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.ASSIGNMENT_GROUP;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.AUDIT;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.BACKOUTPLAN;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.BOOLEAN_FALSE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.BOOLEAN_FALSE_STR;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.BOOLEAN_TRUE_STR;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CHANGE_CATALOG;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CATEGORY;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CHANGE_REQUEST_CODE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CHANGE_REQUEST_ID;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.COMMENTS;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CONFIGITEM;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CR_CREATE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.DESCRIPTION;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.EXPEDITED;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.EXPEDITED_REASON;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.GROUPAPPROVAL;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.HEADER;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.ID;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.IMPACTED;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.IMPACTED_COUNTRIES;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.JUSTIFICATION;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.MSG_TYPE_OUTBOUND;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.NAME;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.POST_IMP_TEST_PLAN;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.PRIMARY_APP_INSTANCE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.REQUESTOR;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.SEQ_SERVICENOW_MESSAGE_LOG;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.SERVICE_NOW;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.SOURCE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.SYSTEM_ID;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.TEST_DETAILS;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.TITLE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.UTC_END_DATE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.UTC_START_DATE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.PRE_TEST_EXCEMPT;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.TEST_PLAN;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfDataField;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfDataFieldGroup;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfString;
import net.nsroot.eur.servicesolutions.cate.integration.DataField;
import net.nsroot.eur.servicesolutions.cate.integration.DataFieldGroup;
import net.nsroot.eur.servicesolutions.cate.integration.DataForm;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentItem;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentSystem;
import net.nsroot.eur.servicesolutions.cate.integration.OrderSystem;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescriptionDocument;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ProcessRFCDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.ServiceNowMessageLog;
import com.citigroup.cgti.c3par.fw.domain.ServiceNowMessageText;
import com.citigroup.cgti.c3par.fw.service.ServiceNowQueueSenderImpl;
import com.citigroup.cgti.c3par.snow.util.ServiceNowUserGroupUtil;
import com.citigroup.cgti.c3par.soa.vc.dao.RFCPersistable;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetail;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetailAnswer;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.soa.vc.logic.RFCService;
import com.citigroup.cgti.c3par.soa.vc.util.RFCUtil;
/*import com.citigroup.cgti.cate.vc.VirtualChange_PortType_;
import com.tibco.www.schemas.CATEINT.Hub_VirtualChange.Schemas.vc.request.xsd.AddmodRecord;
import com.tibco.www.schemas.CATEINT.Hub_VirtualChange.Schemas.vc.request.xsd.GetRecord;
import com.tibco.www.schemas.CATEINT.Hub_VirtualChange.Schemas.vc.request.xsd.Param;*/


/**
 * The Class ManageRFCImpl.
 */
@SuppressWarnings( { "unchecked", "deprecation", "unused" })
public class ManageRFCImpl implements IManageRFC {

	/** The rfc util. */
	RFCUtil rfcUtil = null;

	/** The rfc persistable. */
	RFCPersistable rfcPersistable = null;
	
	private ServiceNowUserGroupUtil snowUserGroupUtil;

	private RFCService rfc;
	
	/** The log. */
	protected Logger log = Logger.getLogger(this.getClass().getName());

	/**
	 * Gets the rfc util.
	 *
	 * @return the rfc util
	 */
	public RFCUtil getRfcUtil() {
		return rfcUtil;
	}

	/**
	 * Sets the rfc util.
	 *
	 * @param rfcUtil the new rfc util
	 */
	public void setRfcUtil(RFCUtil rfcUtil) {
		this.rfcUtil = rfcUtil;
	}

	/**
	 * Gets the rfc persistable.
	 *
	 * @return the rfc persistable
	 */
	public RFCPersistable getRfcPersistable() {
		return rfcPersistable;
	}

	/**
	 * Sets the rfc persistable.
	 *
	 * @param rfcPersistable the new rfc persistable
	 */
	public void setRfcPersistable(RFCPersistable rfcPersistable) {
		this.rfcPersistable = rfcPersistable;
	}
	
	public ServiceNowUserGroupUtil getSnowUserGroupUtil() {
		return snowUserGroupUtil;
	}

	public void setSnowUserGroupUtil(ServiceNowUserGroupUtil snowUserGroupUtil) {
		this.snowUserGroupUtil = snowUserGroupUtil;
	}

	public RFCService getRfc() {
		return rfc;
	}

	public void setRfc(RFCService rfc) {
		this.rfc = rfc;
	}

	/**
	 * Check rfc generation errors.
	 *
	 * @param rfcRequestDTO the rfc request dto
	 * @return the rFC request dto
	 */
	RFCRequestDTO checkRFCGenerationErrors(RFCRequestDTO rfcRequestDTO) {
		// return with Errors code EC_GENERATE if rfc has a error code in its
		// column
		return rfcRequestDTO;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#postRFC(com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO)
	 */
	public RFCRequestDTO postRFC(RFCRequestDTO rfcReqDTO) {
		log.info("ManageRFCImpl  : postRFC :: Starts");
		String rfcFlag = null;
		try {
			rfcFlag = rfcUtil.getRFCPostFlag(rfcReqDTO.getId());
		} catch (Exception e1) {
			log.error(e1, e1);
		}
		/* commented Reason: HandleChangeException - Retry option to make work any number of times 
		 * without any backend update
		 * 
		if (rfcFlag != null && rfcFlag.trim().equalsIgnoreCase("Y"))
		{
			*/
			rfcUtil.updateRFCPostFlag(rfcReqDTO.getId(),"Y");// can be posted
			RFCRequest rfcRequest = new RFCRequest();
			Map secName = rfcUtil.getSectionName();
			List paramList = new ArrayList();
//			Param[] paramArr = null;
			List<RFCDetail> rfcDetailList = null;
			String errorMsg = "";
			Long rfcReqID = null;
			if (rfcReqDTO.getId() != null)
				rfcReqID = rfcReqDTO.getId();
			rfcReqDTO.setErrorCode(null);
			rfcReqDTO.setErrorMessage(null);
			String rfcPostFlag = null;
			if(rfcReqID!=null)
			{
				rfcPostFlag=rfcUtil.updateRFCPostFlag(rfcReqID,"Q");// post begin
			}
			log.info("rfcPostFlag::"+rfcPostFlag);
			if (rfcReqID != null && rfcReqID.longValue() != 0) {
				rfcRequest.setId(rfcReqID);
				rfcDetailList = new ArrayList();
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_BASICINFO,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_NETWORKDATA,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				//try {
				//	rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,
				//			SECTION_PRODUCTIONCONTINGENCY));
				//} catch (Exception e) {
				//	errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				//}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_REASON,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}

//				setRFCDataParamList(rfcDetailList, paramList);
				rfcDetailList = new ArrayList();
				try {
					rfcRequest.setDisplayType("post");
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_DESCRIPTION,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_BACKOUTPLAN,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_TESTPLAN,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,IMPLEMENTATIONPLAN,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
//				setRFCTemplateParamList(rfcDetailList, paramList);
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_NETINFO,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();

				}
//				setRFCNetInfoDataParamList(rfcDetailList, paramList);
				if (errorMsg != null && errorMsg != "") {
					rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_PREPARE);
					rfcReqDTO.setErrorMessage(errorMsg);
				}
				/*if (paramList != null && paramList.size() > 0)
					paramArr = new Param[paramList.size()];
				int count = paramArr.length;
				for (int i = 0; i < count; i++) {
					paramArr[i] = (Param) paramList.get(i);

					log.info("Logic paramArr[i].getName()::"+paramArr[i].getName()+" , "+secName.get(paramArr[i].getName()));
					if (paramArr[i] != null
							&& paramArr[i].getName() != null
							&& secName != null
							&& secName.get(paramArr[i].getName()) != null
							&& (secName.get(paramArr[i].getName()).toString()
									.equalsIgnoreCase(
											SECTION_DESCRIPTION)
											|| secName
											.get(paramArr[i].getName())
											.toString()
											.equalsIgnoreCase(
													SECTION_BACKOUTPLAN) || secName
													.get(paramArr[i].getName())
													.toString()
													.equalsIgnoreCase(SECTION_TESTPLAN)
													|| secName.get(paramArr[i].getName()).toString()
													.equalsIgnoreCase(
															IMPLEMENTATIONPLAN))) {
						paramArr[i].setName(URLEncoder
								.encode(breakLongString(paramArr[i].getName())));
						paramArr[i].setValue(URLEncoder
								.encode(breakLongString(paramArr[i].getValue())));
					} else {
						paramArr[i].setName(URLEncoder
								.encode(paramArr[i].getName()));
						paramArr[i].setValue(URLEncoder.encode(paramArr[i]
						                                                .getValue()));
					}

				}*/


			}

			if (rfcReqDTO.getErrorCode() == null) {
				//addModRecord(paramArr, rfcReqDTO);
				rfcPostFlag=rfcUtil.updateRFCPostFlag(rfcReqID,"T");//post completed successfully
				//if(rfcReqDTO.getErrorCode() == null){
					//submitForReview(rfcReqDTO);
					createServiceNowRequest(rfcReqDTO, rfcRequest);
				//}
			}
			
			if(rfcReqDTO.getErrorCode() != null){
				int updInsert = 0;
				updInsert =rfcUtil.updateRFCError(rfcReqDTO);
				rfcUtil.updateRFCPostFlag(rfcReqID,"E");// Issue in posting
				if(updInsert > 0)
					log.info("Error codes and messages have been sucessfully logged");
			}
		/*}else{
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_NOTVALID);
			rfcUtil.updateRFCError(rfcReqDTO);
			rfcUtil.updateRFCPostFlag(rfcReqDTO.getId(),"N");//Not valid to post
			log.info("RFC Request not posted....");
		}*/
		log.info("ManageRFCImpl  : postRFC :: Ends");
		return rfcReqDTO;
	}

	/**
	 * Break long string.
	 *
	 * @param data the data
	 * @return the string
	 */
	private String breakLongString(String data) {
		String strdata = "";
		if (data != null && !data.trim().equals("") && data.length() > 72) {
			String strv[] = data.split("\n");

			for (String element : strv) {
				strdata = strdata + spliltNewLineValues(element) + "\n";
			}
		} else {
			return data;
		}
		return strdata;
	}

	/**
	 * Splilt new line values.
	 *
	 * @param data the data
	 * @return the string
	 */
	private String spliltNewLineValues(String data) {
		String finalResult = "";
		String temp1 = "";
		String temp2 = "";
		int brkData = 72;
		if (data != null) {
			if (!data.trim().equals("") && data.length() > brkData) {
				while (data.length() > brkData) {
					temp1 = data.substring(0, brkData - 1);
					if (temp1.indexOf(" ") != -1)
					{
						if (temp1.lastIndexOf(temp1.length() - 1) != ' ') {
							String temp4 = temp1.substring(0, temp1.lastIndexOf(" ")+1) + "\n";
							finalResult = finalResult + temp4;
							temp2 = temp1.substring(temp1.lastIndexOf(" ") + 1);
						}
					}
					data = temp2 + data.substring(brkData - 1);
					temp2 = "";
				}
				if (!data.trim().equals("") && data.length() > 0) {
					finalResult = finalResult + data;
				}
			} else {
				return data;
			}
		}
		return finalResult;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#checkRFCDataComplete(com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO)
	 */
	public RFCRequestDTO checkRFCDataComplete(RFCRequestDTO rfcReqDTO) {
		log.info("ManageRFCImpl::checkRFCDataComplete :: starts");
		List rfcDataError = new ArrayList();
		if (rfcReqDTO != null) {
			if ((rfcReqDTO.getErrorCode() == null)
					|| (rfcReqDTO.getErrorCode() != null && !rfcReqDTO
							.getErrorCode().equalsIgnoreCase(
									RFCRequestDTO.ERRORCODE_GENERATE))) {
				rfcReqDTO.setErrorCode(null);
				rfcReqDTO.setErrorMessage(null);
				Long rfcReqID = rfcReqDTO.getId();
				if (rfcReqID != null) {/*
					String status = rfcDateUpdate(rfcReqID);
					String fafStatus = rfcImplFAFCheck(rfcReqID);
					if (status != null
							&& status
							.equalsIgnoreCase(RFCRequestDTO.RFC_REQ_STATUS_FAIL)) {
						log.info("status::" + status);
						rfcReqDTO
						.setErrorCode(RFCRequestDTO.ERRORCODE_POST_DATACOMPLETION);
						rfcReqDTO
						.setErrorMessage("Failed while updating RFC Request Date and Time information.");
					}else if(fafStatus != null
							&& fafStatus
							.equalsIgnoreCase(RFCRequestDTO.RFC_REQ_STATUS_FAIL)){
						rfcReqDTO
						.setErrorCode(RFCRequestDTO.ERRORCODE_POST_DATACOMPLETION);
						rfcReqDTO
						.setErrorMessage("Failed while computing FAF information.");
					}else {
						long detailDataCount = rfcUtil
						.rfcDetailDataCheck(rfcReqID);
						if (detailDataCount > 0) {
							rfcDataError = rfcUtil.rfcDataErrorCheck(rfcReqID);
							if (rfcDataError != null && rfcDataError.size() > 0) {
								String errorDataMsg = "";
								for (int i = 0; i < rfcDataError.size(); i++) {
									if (i == 0) {
										errorDataMsg = (String) rfcDataError
										.get(i);
									} else {
										errorDataMsg = errorDataMsg
										+ (String) rfcDataError.get(i);
									}

								}

								rfcReqDTO
								.setErrorCode(RFCRequestDTO.ERRORCODE_POST_DATACOMPLETION);
								rfcReqDTO
								.setErrorMessage("Missing Answers for the following parameters "
										+ errorDataMsg);
							}
						} else {
							rfcReqDTO
							.setErrorCode(RFCRequestDTO.ERRORCODE_POST_DATACOMPLETION);
							rfcReqDTO.setErrorMessage("No Answers");
						}
					}
				*/}
				//call the error code
				if(rfcReqDTO.getErrorCode() != null){
					int updInsert = 0;
					updInsert =rfcUtil.updateRFCError(rfcReqDTO);
					if(updInsert > 0)
						log.info("Error codes and messages have been sucessfully logged");
				}
			}
		}
		log.info("ManageRFCImpl::checkRFCDataComplete :: Ends");
		return rfcReqDTO;

	}

	/**
	 * Sets the rfc data param list.
	 *
	 * @param rfcDetailList the rfc detail list
	 * @param paramList the param list
	 */
	/*private void setRFCDataParamList(List rfcDetailList, List paramList) {
		log.info("ManageRFCImpl :: setRFCDataParamList :starts");
		Param tempParam = null;
		if (rfcDetailList != null) {
			for (int i = 0; i < rfcDetailList.size(); i++) {
				RFCDetail rfcDetail = (RFCDetail) rfcDetailList.get(i);
				String paramName = rfcDetail.getRfcLookup().getParamName();
				RFCDetailAnswer paramValue = null;
				List paramValueList = rfcDetail.getRfcDetailAnswerList();
				if (paramValueList != null) {
					for (int j = 0; j < paramValueList.size(); j++) {
						if (j == 0) {
							tempParam = new Param();
							paramValue = (RFCDetailAnswer) paramValueList
							.get(j);
							if (paramName!=null && paramValue.getAnswer() != null
									&& paramValue.getAnswer().length() > 0
									&& paramValue.getAnswer() != "null") {
								tempParam.setName(paramName);
								String temp = paramValue.getAnswer();
								temp = replaceParamValue(temp);
								tempParam.setValue(temp);
								paramList.add(tempParam);
							}
						} else {
							tempParam = new Param();
							paramValue = (RFCDetailAnswer) paramValueList
							.get(j);
							if (paramName!=null && paramValue.getAnswer() != null
									&& paramValue.getAnswer().length() > 0
									&& paramValue.getAnswer() != "null") {
								if (paramName
										.equals(LOCATION) || paramName
										.equals(COUNTRY_CODE) || paramName
										.equals(FFTEXT_FLAG)) {
									tempParam.setName(paramName);
								} else {
									tempParam.setName(paramName + "_LIST");
								}
								String temp = paramValue.getAnswer();
								temp = replaceParamValue(temp);
								tempParam.setValue(temp);
								paramList.add(tempParam);
							}
						}
					}
				}

			}
		}
		log.info("ManageRFCImpl :: setRFCDataParamList :Ends");
	}*/

	/**
	 * Sets the rfc template param list.
	 *
	 * @param rfcDetailList the rfc detail list
	 * @param paramList the param list
	 */
	/*private void setRFCTemplateParamList(List rfcDetailList, List paramList) {
		log.info("ManageRFCImpl :: setRFCTemplateParamList :starts");
		Param tempParam = null;
		if (rfcDetailList != null) {
			Iterator rfcDetailIter = rfcDetailList.iterator();
			while (rfcDetailIter.hasNext()) {
				RFCDetail rfcDetail = (RFCDetail) rfcDetailIter.next();
				String paramName = rfcDetail.getRfcLookup().getParamName();
				RFCDetailAnswer paramValue = null;
				List paramValueList = rfcDetail.getRfcDetailAnswerList();
				StringBuffer tempValue = new StringBuffer();
				if (paramValueList != null) {
					for (int j = 0; j < paramValueList.size(); j++) {
						tempParam = new Param();
						paramValue = (RFCDetailAnswer) paramValueList.get(j);
						if (paramValue.getTemplateKey().getPosition() != null) {
							if (paramValue.getAnswer() != null
									&& paramValue.getAnswer().length() > 0
									&& paramValue.getAnswer() != "null") {
								String temp = paramValue.getAnswer();
								temp = replaceParamValue(temp);

								tempValue
								.append(paramValue.getTemplateKey()
										.getPathValue()
										+ ". "
										+ paramValue.getTemplateKey()
										.getDescription()
										+ quesSeperator);
								tempValue.append(("IMPPLAN_NONGNOTASKS".equalsIgnoreCase(paramValue.getTemplateKey().getKey())?
										temp:temp.toUpperCase())+quesAnswerSeperator+quesAnswerSeperator);
							}
						}
					}
				}

				if (paramName!=null && tempValue != null && tempValue.length() > 0) {
					tempParam.setName(paramName);
					tempParam.setValue(tempValue.toString());
					paramList.add(tempParam);
				}
			}
		}
		log.info("ManageRFCImpl :: setRFCTemplateParamList :Ends");

	}*/

	/**
	 * Sets the rfc net info data param list.
	 *
	 * @param rfcDetailList the rfc detail list
	 * @param paramList the param list
	 */
	/*private void setRFCNetInfoDataParamList(List<RFCDetail> rfcDetailList, List paramList) {
		log.info("ManageRFCImpl :: setRFCNetInfoDataParamList :starts");

		if (rfcDetailList != null) {
				for (RFCDetail rfcDetail : rfcDetailList) {
				String paramName = rfcDetail.getRfcLookup().getParamName();
				List paramValueList = rfcDetail.getRfcDetailAnswerList();
				if (paramValueList != null) {
					if (paramName
							.equalsIgnoreCase(NETINFO_DATA)) {
						if (!paramValueList.isEmpty()) {
							Iterator netInfoVal = paramValueList.iterator();
							while (netInfoVal.hasNext()) {
								Firewall firewall = (Firewall) netInfoVal
								.next();

								if (firewall.getFirewallName() != null
										&& firewall.getFirewallName()
										.length() > 0
										&& firewall.getFirewallName() != "null") {
									Param netInfoDataParam = new Param();
									netInfoDataParam
									.setName(RFC_NETINFO_HOST_NAME);
									netInfoDataParam.setValue(firewall
											.getFirewallName());
									paramList.add(netInfoDataParam);
								}
								if (firewall.getNetInfoType() != null
										&& firewall.getNetInfoType().length() > 0
										&& firewall.getNetInfoType() != "null") {
									Param netInfoDataParam = new Param();
									netInfoDataParam
									.setName(RFC_NETINFO_DEVICE_TYPE);
									netInfoDataParam.setValue(firewall
											.getNetInfoType());
									paramList.add(netInfoDataParam);
								}

								if (firewall.getLocation() != null
										&& firewall.getLocation()
										.length() > 0
										&& firewall.getLocation() != "null") {
									Param netInfoDataParam = new Param();
									netInfoDataParam
									.setName(RFC_NETINFO_DEVICE_LOCATION);
									netInfoDataParam.setValue(firewall
											.getLocation());
									paramList.add(netInfoDataParam);
								}
								if (firewall.getIpAddress() != null
										&& firewall.getIpAddress()
										.length() > 0
										&& firewall.getIpAddress() != "null") {
									Param netInfoDataParam = new Param();
									netInfoDataParam
									.setName(RFC_NETINFO_IP_ADDRESS);
									netInfoDataParam.setValue(firewall
											.getIpAddress());
									paramList.add(netInfoDataParam);
								}
								if (firewall.getApproverGroups() != null
										&& firewall.getApproverGroups()
										.length() > 0
										&& firewall.getApproverGroups() != "null") {
									Param netInfoDataParam = new Param();
									netInfoDataParam
									.setName(RFC_NETINFO_GREEN_ZONE_APPROVERS);
									netInfoDataParam.setValue(firewall
											.getApproverGroups());
									paramList.add(netInfoDataParam);
								}
								if (firewall.getDeviceId() != null
										&& firewall.getDeviceId()
										.length() > 0
										&& firewall.getDeviceId() != "null") {
									Param netInfoDataParam = new Param();
									netInfoDataParam
									.setName(RFC_NETINFO_DEVICE_NUMBER);
									netInfoDataParam.setValue(firewall
											.getDeviceId());
									paramList.add(netInfoDataParam);
								}

							}
						}
					} else {
						if (paramName != null && paramValueList != null && !paramValueList.isEmpty()) {
							Param netInfoParam = new Param();
							netInfoParam.setName(paramName);
							String tempNetInfoAns = "";
							for (int netInfo = 0; netInfo < paramValueList
							.size(); netInfo++) {
								RFCDetailAnswer NetInfoAnswer = (RFCDetailAnswer) paramValueList
								.get(netInfo);
								if ((NetInfoAnswer.getAnswer() != null && NetInfoAnswer
										.getAnswer().length() > 0)
										|| NetInfoAnswer.getAnswer() != "null") {
									tempNetInfoAns = tempNetInfoAns
									+ NetInfoAnswer.getAnswer();
									tempNetInfoAns = replaceParamValue(tempNetInfoAns);
									netInfoParam.setValue(tempNetInfoAns);
								}
							}
							if ((netInfoParam.getValue() != null && netInfoParam
									.getValue().length() > 0)
									|| netInfoParam.getValue() != "null") {
								paramList.add(netInfoParam);
							}
						}

					}
				}
			}
		}
		log.info("ManageRFCImpl :: setRFCNetInfoDataParamList :Ends");
	}*/

	/**
	 * Replace param value.
	 *
	 * @param paramValue the param value
	 * @return the string
	 */
	private String replaceParamValue(String paramValue) {
		paramValue = paramValue.replaceAll("\\\\n", "\n");
		return paramValue;
	}

	/**
	 * Adds the mod record.
	 *
	 * @param paramArr the param arr
	 * @param rfcReqDTO the rfc req dto
	 */
	/*private void addModRecord(Param[] paramArr, RFCRequestDTO rfcReqDTO) {
		VirtualChange_PortType_ infomanStub = null;
		infomanStub = rfcUtil.intializeVirtualChangePortType();
		AddmodRecord record = new AddmodRecord();
		record.setIAm(RFC_APPLICATION_ALIAS);
		String userId = rfcUtil.getaddMODUserId(rfcReqDTO.getTiRequestId());
		log.info("userId" + userId);
		record.setUserId(userId);
		record.setType(RFC_CREATE);
		record.setParam(paramArr);
		String status =null;

		try {
			SOAPElement xmlResponse = infomanStub.addModRecord(record);
			log.info("Response " + xmlResponse.toString());
			Map hm = rfcUtil.updateRFCDetails(rfcUtil.xmlElements(),
					xmlResponse.toString());

			if (hm != null) {
				if (hm.get("error") != null) {
					String resError = hm.get("error").toString();
					rfcReqDTO
					.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
					rfcReqDTO
					.setErrorMessage("Exception occurred while handling VC Response"
							+ resError);
				}  if (hm.get("CURRENT_STATUS") != null) {
					rfcReqDTO.setRfcStatus(hm.get("CURRENT_STATUS").toString());
				} if (hm.get("RECORD_ID") != null) {
					rfcReqDTO.setRfcId(hm.get("RECORD_ID").toString());
				}
			}
			if (rfcReqDTO.getErrorCode() == null) {
				status = rfcUtil.updateRFCRequestDetails(
						xmlResponse.toString(), rfcReqDTO);
			}
			if (status != null
					&& status
					.equalsIgnoreCase(RFCRequestDTO.RFC_REQ_STATUS_FAIL)) {
				log.info("status::" + status);
				rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
				rfcReqDTO
				.setErrorMessage("Exception occurred while handling VC Response");
			}
		} catch (RemoteException xe) {
			log.error("Remote exception");
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
			if (xe.getMessage() != null) {
				rfcReqDTO.setErrorMessage(xe.getMessage());
			} else {
				rfcReqDTO
				.setErrorMessage("Exception occurred while posting RFC to webservice.");
			}

			log.error(xe.getMessage(), xe);

		} catch (SOAPFaultException xe) {
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
			rfcReqDTO.setErrorMessage(xe.getFaultCode() + xe.getFaultString());
			log.error("FaultActor" + xe.getFaultActor());
			log.error("getFaultString" + xe.getFaultString());
			log.error("FaultCode" + xe.getFaultCode());
			log.error(xe.getMessage(), xe);
		} catch (Exception xe) {
			log.error(xe, xe);
			if (xe.getMessage() != null) {
				rfcReqDTO.setErrorMessage(xe.getMessage());
			} else {
				rfcReqDTO
				.setErrorMessage("Exception occurred while postign RFC to webservice");
			}
		}
	}*/

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#getRFCRequestList(com.citigroup.cgti.c3par.bpm.ejb.domain.ProcessRFCDTO)
	 */
	public ProcessRFCDTO getRFCRequestList(ProcessRFCDTO processRFCDTO) {
		log.info("ManageRFCImpl :: getRFCRequestList :Starts");
		List rfcRequestDTOList = new ArrayList();
		Object[] temp = null;
		boolean createTypeFlag=false;
		Long tiRequestId = processRFCDTO.getTiRequestId();
		if (tiRequestId != null) {
			Map rfcFlag = rfcUtil.getRFCFlag(tiRequestId);
			String bulkReq = (String) rfcFlag.get("BulkRequestFlag");
			String aclVariance = (String) rfcFlag.get("AclVarianceFlag");
			if ((bulkReq != null && !(bulkReq.trim().equals(""))
					&& bulkReq.equalsIgnoreCase("Y")) ||(aclVariance != null
							&& !(aclVariance.trim().equals("")) && aclVariance.trim().equalsIgnoreCase("Y")) ) {
				createTypeFlag=true;
			} else {
				Map rfcManualFlag = rfcUtil.getRFCReqManualFlag(tiRequestId);
				String createManualTypeFlag = "N";
				if (rfcManualFlag != null)
					createManualTypeFlag = (String) rfcManualFlag.get("MANUAL_TYPE");
				if (createManualTypeFlag != null
						&& createManualTypeFlag.equalsIgnoreCase("Y")) {
					createTypeFlag = true;
				}
			}
			List rfcRequestList = rfcPersistable.getRFCRequestList(tiRequestId,createTypeFlag,processRFCDTO.getConType());

			if (rfcRequestList != null && rfcRequestList.size() > 0) {
				for (int i = 0; i < rfcRequestList.size(); i++) {
					RFCRequestDTO rfcRequestDTO = new RFCRequestDTO();
					
					rfcRequestDTO.setTiRequestId(tiRequestId);
					rfcRequestDTO.setRfcType(processRFCDTO.getConType());
					
					temp = (Object[]) rfcRequestList.get(i);

					String createType = null;
					String conReqId = null;
					String versionNo = null;
					String errorCode = null;
					String errorMsg = null;
					String shortDescription = null;
					if (temp[4] != null) {
						createType = temp[4].toString();
						if (createType.equalsIgnoreCase(RFCRequestDTO.RFC_CREATE_TYPE_MANUAL)) {
							if (rfcFlag.get("CON_REQ_ID") != null)
								conReqId = (String) rfcFlag.get("CON_REQ_ID");
							if (rfcFlag.get("VERSION_NO") != null)
								versionNo = (String) rfcFlag.get("VERSION_NO");

							if (bulkReq != null && !(bulkReq.trim().equals(""))
									&& bulkReq.equalsIgnoreCase("Y")) {
								errorCode = RFCRequestDTO.ERRORCODE_POST_BULK;
								errorMsg = RFCRequestDTO.ERRORMSG_POST_BULK;
							} else if (aclVariance != null
									&& !(aclVariance.trim().equals("")) && aclVariance
									.trim().equalsIgnoreCase("Y")) {
								errorCode = RFCRequestDTO.ERRORCODE_POST_ACL;
								errorMsg = RFCRequestDTO.ERRORMSG_POST_ACL;
							}else {
								errorCode = RFCRequestDTO.ERRORCODE_POST_NOTAPPLICABLE;

							}
							if (conReqId != null && versionNo != null)
								shortDescription = conReqId + "." + versionNo;
							else
								shortDescription = "";
						} else {
							if (temp[5] != null)
								shortDescription = temp[5].toString();
							if (temp[3] != null) {
								errorCode = temp[3].toString();
								errorMsg = RFCRequestDTO.ERRORMSG_GENERATE;
							}

						}

					}
					if (temp[0] != null){
						rfcRequestDTO.setId(Long.valueOf(temp[0].toString()));
						if(errorCode!=null && !errorCode.trim().equalsIgnoreCase("")){
							Long tmpRfcId=Long.valueOf(temp[0].toString());
							String tmpLog=rfcUtil.getRFCERequestErrorLog(tmpRfcId);
							if(tmpLog!=null){
								errorMsg=tmpLog;
							}else{
								errorMsg=null;
							}
						}
					}
					if (temp[1] != null)
						rfcRequestDTO.setRfcStatus(temp[1].toString());
					else
						rfcRequestDTO.setRfcStatus("");
					if (shortDescription != null)
						rfcRequestDTO.setShortDescription(shortDescription);
					else
						rfcRequestDTO.setShortDescription("");
					if (temp[2] != null)
						rfcRequestDTO.setRfcId(temp[2].toString());
					if (errorCode != null) {
						rfcRequestDTO.setErrorCode(errorCode);
						rfcRequestDTO.setErrorMessage(errorMsg);
					}
					if (temp[4] != null)
						rfcRequestDTO.setCreateType(createType);

					rfcRequestDTOList.add(rfcRequestDTO);
				}

			} else {

				if (rfcFlag != null) {
					RFCRequestDTO rfcRequestDTO = new RFCRequestDTO();
					String conReqId = null;
					String versionNo = null;
					rfcRequestDTO.setTiRequestId(tiRequestId);
					if (rfcFlag.get("CON_REQ_ID") != null)
						conReqId = (String) rfcFlag.get("CON_REQ_ID");
					if (rfcFlag.get("VERSION_NO") != null)
						versionNo = (String) rfcFlag.get("VERSION_NO");

					if (bulkReq != null && !(bulkReq.trim().equals(""))
							&& bulkReq.equalsIgnoreCase("Y")) {
						rfcRequestDTO
						.setErrorCode(RFCRequestDTO.ERRORCODE_POST_BULK);
						rfcRequestDTO
						.setErrorMessage(RFCRequestDTO.ERRORMSG_POST_BULK);
					} else if (aclVariance != null
							&& !(aclVariance.trim().equals(""))
							&& aclVariance.trim().equalsIgnoreCase("Y")) {
						rfcRequestDTO
						.setErrorCode(RFCRequestDTO.ERRORCODE_POST_ACL);
						rfcRequestDTO
						.setErrorMessage(RFCRequestDTO.ERRORMSG_POST_ACL);
					} else {
						rfcRequestDTO
						.setErrorCode(RFCRequestDTO.ERRORCODE_POST_NOTAPPLICABLE);
						rfcRequestDTO
						.setErrorMessage("RFCRequest data is not  available for the connection Request id "
								+ conReqId
								+ " and the version no "
								+ versionNo);

					}
					String shortDesc = null;
					if (conReqId != null && versionNo != null)
						shortDesc = conReqId + "." + versionNo;
					else
						shortDesc = "";
					rfcRequestDTO.setShortDescription(shortDesc);
					rfcRequestDTOList.add(rfcRequestDTO);

				}
			}
			if (rfcRequestDTOList != null && rfcRequestDTOList.size() > 0)
				processRFCDTO.setRfcRequestDTOList(rfcRequestDTOList);

		}
		log.info("ManageRFCImpl :: getRFCRequestList :Ends");
		return processRFCDTO;

	}

	/**
	 * Rfc date update.
	 *
	 * @param rfcId the rfc id
	 * @return the string
	 */
	public String rfcDateUpdate(Long rfcId) {
		String dateCall = rfcUtil.updateRFCRequestDates(rfcId);
		return dateCall;
	}

	/**
	 * Rfc impl faf check.
	 *
	 * @param rfcId the rfc id
	 * @return the string
	 */
	public String rfcImplFAFCheck(Long rfcId){
		String fafStatus = "";
		try{
			rfcUtil.getFAFString(rfcId);
		}catch(Exception e){
			fafStatus = "failure";
		}
		return fafStatus;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#registerRFC(com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO)
	 */
	public RFCRequestDTO registerRFC(RFCRequestDTO rfcRequestDTO) {
		log.info("ManageRFCImpl::registerRFC :: starts");
		String status = null;
		try {

			log.info("registerRFC ::::: not calling getRFCRecord from VC ");
			rfcRequestDTO.setRfcStatus("DESIGN");
			status = rfcUtil.updateRFCRequestDetails("",
					rfcRequestDTO);
			log.info("registerRFC ::::: updated the table rfc_request  "+status);
			/*
			boolean validRFCFlag=false;
			String responseXml = getRFCRecord(rfcRequestDTO);
			if (isValidRFC(responseXml, rfcRequestDTO)) {
				rfcRequestDTO.setErrorCode(null);
				rfcRequestDTO.setErrorMessage(null);
				Map hm = rfcUtil.updateRFCDetails(rfcUtil.xmlElements(),
						responseXml);

				if (hm != null) {
					if (hm.get("error") != null) {
						String resError = hm.get("error").toString();
						rfcRequestDTO
								.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
						rfcRequestDTO
								.setErrorMessage("Exception occurred while handling VC Response "
										+ resError);
					} else if (hm.get("CURRENT_STATUS") != null) {
						rfcRequestDTO.setRfcStatus(hm.get("CURRENT_STATUS")
								.toString());
					} else if (hm.get("RECORD_ID") != null) {
						rfcRequestDTO.setRfcId(hm.get("RECORD_ID").toString());
					}
				}else{
					status = RFCRequestDTO.RFC_REQ_STATUS_FAIL;
				}
				if (rfcRequestDTO.getErrorCode() == null) {
					status = rfcUtil.updateRFCRequestDetails(responseXml,
							rfcRequestDTO);
				}
			} else {
		        status=RFCRequestDTO.RFC_REQ_STATUS_FAIL;
		        validRFCFlag=true;
			}
			if (status != null
					&& status
							.equalsIgnoreCase(RFCRequestDTO.RFC_REQ_STATUS_FAIL)) {
				rfcRequestDTO
				.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
				if(!validRFCFlag){
				rfcRequestDTO
						.setErrorMessage("Exception occurred while handling VC Response");
				}else{
			        rfcRequestDTO
					.setErrorMessage("RFC ID provided is not valid.");
				}
			} else {
				rfcRequestDTO.setErrorCode(null);
				rfcRequestDTO.setErrorMessage(null);

			}
			 */} catch (Exception ex) {
				 log.error(ex.getMessage(), ex);
				 rfcRequestDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
				 rfcRequestDTO
				 .setErrorMessage("Exception occurred while handling VC Response");
			 }
			 if (rfcRequestDTO.getErrorCode() != null
					 && !(rfcRequestDTO.getErrorCode().trim().equalsIgnoreCase(""))) {
				 rfcUtil.updateRFCError(rfcRequestDTO);
			 }
			 log.info("ManageRFCImpl::registerRFC :: Ends");
			 return rfcRequestDTO;
	}

	/**
	 * Gets the rFC record.
	 *
	 * @param rfcRequestDTO the rfc request dto
	 * @return the rFC record
	 * @throws Exception the exception
	 */
	/*private String getRFCRecord(RFCRequestDTO rfcRequestDTO) throws Exception {
		log.info("ManageRFCImpl::getRFCRecord :: starts");
		String responseXml = null;
		VirtualChange_PortType_ infomanStub = null;
		try {
			infomanStub = rfcUtil.intializeVirtualChangePortType();
			if (rfcRequestDTO != null) {

				GetRecord record = new GetRecord();
				record.setIAm(RFC_APPLICATION_ALIAS);
				String userId = rfcUtil.getaddMODUserId(rfcRequestDTO.getTiRequestId());
				log.info("userId" + userId);
				record.setUserId(userId);
				String rfcId=null;
				rfcId=rfcRequestDTO.getRfcId();
				log.info("rfcId  "+rfcId+"  rfc Id length"+rfcId.length());
				if (rfcId != null) {
					while (rfcId.length() < 8) {
						rfcId = "0" + rfcId;
					}
				}

				if(rfcRequestDTO.getRfcId().startsWith("0"))
			   rfcId=rfcRequestDTO.getRfcId();
			else
			   rfcId="0"+rfcRequestDTO.getRfcId();
				log.info("rfc Id "+rfcId);
				record.setRecordId(rfcId);
				log.info(record);
				SOAPElement s = infomanStub.getRecord(record);
				log.info("Response " + s);
				responseXml=s.toString();
			}
		} catch (RemoteException xe) {
			log.error("Remote Exception " + xe.getMessage(), xe);
			throw new Exception(xe.getMessage());
		} catch (SOAPFaultException xe) {
			log.error("SOAPFaultException  " + xe.getMessage(), xe);
			throw new Exception(xe.getMessage());
		} catch (Exception xe) {
			log.error(xe.getMessage(), xe);
			throw new Exception(xe.getMessage());
		}


		log.info("ManageRFCImpl::getRFCRecord :: Ends");
		return responseXml;
	}*/


	/**
	 * Checks if is valid rfc.
	 *
	 * @param response the response
	 * @param rfcRequestDTO the rfc request dto
	 * @return true, if is valid rfc
	 * @throws Exception the exception
	 */
	private boolean isValidRFC(String response, RFCRequestDTO rfcRequestDTO)
	throws Exception {
		log.info("ManageRFCImpl::isValidRFC :: Starts");
		boolean isValidRFC = false;
		if (rfcRequestDTO != null) {
			Map processMap = rfcUtil.getRFCFlag(rfcRequestDTO.getTiRequestId());
			List xmlList = rfcUtil.xmlElements();
			if (xmlList != null) {
				Map rfcDetailMap = rfcUtil.updateRFCDetails(xmlList, response);
				if (rfcDetailMap.containsKey("BRIEF_DESCRIPTION")
						&& processMap.containsKey("CON_REQ_ID")
						&& processMap.containsKey("VERSION_NO")) {
					String briefDesc = null;
					String processId = null;
					if (processMap.get("CON_REQ_ID") != null
							&& processMap.get("VERSION_NO") != null) {
						processId = processMap.get("CON_REQ_ID") + "."
						+ processMap.get("VERSION_NO");
					}
					if (rfcDetailMap.get("BRIEF_DESCRIPTION") != null) {
						briefDesc = rfcDetailMap.get("BRIEF_DESCRIPTION")
						.toString();
					}
					if (briefDesc!=null && briefDesc.indexOf(processId) != -1) {
						isValidRFC = true;
					}else{
						isValidRFC=false;
					}

				}
			}
		}
		log.info("ManageRFCImpl::isValidRFC :: Ends");
		return isValidRFC;
	}

	/**
	 * Submit for review.
	 *
	 * @param rfcReqDTO the rfc req dto
	 */

	/*private void  submitForReview(RFCRequestDTO rfcReqDTO) {
		log.info("submitForReview(RFCRequestDTO rfcReqDTO) method starts");
		//RFCUtil rfcUtil=new RFCUtil();
		MessageFactory messageFactory;
		try {
			messageFactory = MessageFactory.newInstance();
			final SOAPMessage soapMessage = messageFactory.createMessage();
			// Object for message parts
			final SOAPPart soapPart = soapMessage.getSOAPPart();
			final SOAPEnvelope envelope = soapPart.getEnvelope();


			// add the technet namespace as "technet"
			envelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
			envelope.addNamespaceDeclaration("vc", "http://www.tibco.com/schemas/CATEINT/Hub_VirtualChange/Schemas/vc-request.xsd");

			envelope.setEncodingStyle("http://schemas.xmlsoap.org/soap/encoding/");

			final SOAPBody soapBody = envelope.getBody();


			VirtualChange_PortType_ virtualChange_PortType_ =rfcUtil.intializeVirtualChangePortType();
			Name bodyName = envelope.createName("Envelope", "soapenv", "http://schemas.xmlsoap.org/soap/envelope/");

			final SOAPElement env=soapBody.addChildElement(bodyName);
			env.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
			env.addNamespaceDeclaration("vc", "http://www.tibco.com/schemas/CATEINT/Hub_VirtualChange/Schemas/vc-request.xsd");

			env.addChildElement("Header","soapenv");
			final SOAPElement body= env.addChildElement("Body","soapenv");
			final SOAPElement func = body.addChildElement("function","vc");
			func.addNamespaceDeclaration("vc", "http://www.tibco.com/schemas/CATEINT/Hub_VirtualChange/Schemas/vc-request.xsd");


			String classValue = rfcUtil.getPrivilegeClass(rfcReqDTO.getId(),rfcReqDTO.getTiRequestId());
			log.info("classValue:: "+classValue);
			String userId = rfcUtil.getaddMODUserId(rfcReqDTO.getTiRequestId());
			log.info("userId" + userId);
			func.addAttribute(envelope.createName("class"), classValue);
			func.addAttribute(envelope.createName("functionName"), RFC_REQ_STATUS_REVIEW);
			func.addAttribute(envelope.createName("iAm"), RFC_APPLICATION_ALIAS);
			func.addAttribute(envelope.createName("recordId"), rfcReqDTO.getRfcId());
			func.addAttribute(envelope.createName("userId"), userId);
			log.info("Soap Message"+soapMessage);
			String status =null;

			SOAPElement xmlResponse=virtualChange_PortType_.executeFunction(func);
			log.info(xmlResponse);

			Map hm = rfcUtil.updateRFCDetails(rfcUtil.xmlElements(),
					xmlResponse.toString());

			if (hm != null) {
				if (hm.get("error") != null) {
					String resError = hm.get("error").toString();
					rfcReqDTO
					.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
					rfcReqDTO
					.setErrorMessage("Exception occurred while handling VC Response"
							+ resError);
				}  if (hm.get("CURRENT_STATUS") != null) {
					rfcReqDTO.setRfcStatus(hm.get("CURRENT_STATUS").toString());
				} if (hm.get("RECORD_ID") != null) {
					rfcReqDTO.setRfcId(hm.get("RECORD_ID").toString());
				}
			}
			if (rfcReqDTO.getErrorCode() == null) {
				status = rfcUtil.updateRFCRequestDetails(
						xmlResponse.toString(), rfcReqDTO);
			}
			if (status != null
					&& status
					.equalsIgnoreCase(RFCRequestDTO.RFC_REQ_STATUS_FAIL)) {
				log.info("status::" + status);
				rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
				rfcReqDTO
				.setErrorMessage("Exception occurred while handling VC Response");
			}
		}catch (RemoteException xe) {
			log.error("Remote exception");
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
			if (xe.getMessage() != null) {
				rfcReqDTO.setErrorMessage(xe.getMessage());
			} else {
				rfcReqDTO
				.setErrorMessage("Exception occurred while posting RFC to webservice.");
			}

			log.error(xe.getMessage(), xe);

		} catch (SOAPFaultException xe) {
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
			rfcReqDTO.setErrorMessage(xe.getFaultCode() + xe.getFaultString());
			log.error("FaultActor" + xe.getFaultActor());
			log.error("getFaultString" + xe.getFaultString());
			log.error("FaultCode" + xe.getFaultCode());
			log.error(xe.getMessage(), xe);
			log.error(xe, xe);
		} catch (Exception xe) {
			log.error(xe, xe);
			if (xe.getMessage() != null) {
				rfcReqDTO.setErrorMessage(xe.getMessage());
			} else {
				rfcReqDTO
				.setErrorMessage("Exception occurred while postign RFC to webservice");
			}
		}
		log.info("submitForReview(RFCRequestDTO rfcReqDTO) method ends");
	}*/

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#getPeopleRecord(java.lang.Long)
	 */
	public String getPeopleRecord(Long tiRequestId) {
		/*log.info("ManageRFCImpl::getPeopleRecord :: starts");
		String ssoID = null;
		String rfcErrorMessage =null;
		boolean isValidSsoId = false;
		try {
			Set userIdSet = rfcUtil.getaddMODUserIds(tiRequestId);
			if(userIdSet != null && userIdSet.size() > 0){
				for (Iterator iterator = userIdSet.iterator(); iterator.hasNext();) {
					ssoID = (String) iterator.next();

					log.info("ssoID:: " + ssoID);
					if (ssoID != null) {
						rfcErrorMessage = "People record in VC system does not exists for the user "+ssoID+"."
						+" Please request the credentials for VC System in Citi Market place.";
						String responseXml = getPeopleRecord(ssoID, ssoID);
						log.info("ManageRFCIMPL.getPeopleRecord.responseXml::"+responseXml);
						List xmlList = rfcUtil.xmlPeopleElements();
						if (xmlList != null) {
							Map rfcDetailMap = rfcUtil.updateRFCDetails(xmlList,
									responseXml);
							log.info("rfcDetailMap:: " + rfcDetailMap);
							if (rfcDetailMap != null) {
								if (rfcDetailMap.containsKey("SOE_ID")
										&& (rfcDetailMap.containsKey("INFOMAN_NAME")
										)) {
									String infomanName = (String) rfcDetailMap
									.get("INFOMAN_NAME");
									String sso_Id = (String) rfcDetailMap.get("SOE_ID");
									String phoneNo ="0000000000";
									if( rfcDetailMap.containsKey("INFOMAN_NAME") && rfcDetailMap
											.get("REPORTER_PHONE") != null) {
										phoneNo = (String) rfcDetailMap
										.get("REPORTER_PHONE");
									}
									if ((infomanName != null
											&& !(infomanName.trim()
													.equalsIgnoreCase(""))
													&& !(infomanName.trim().equalsIgnoreCase(
													"null")))&&(sso_Id != null
															&& !(sso_Id.trim()
																	.equalsIgnoreCase(""))
																	&& !(sso_Id.trim().equalsIgnoreCase(
																	"null")))) {
										log.info("Found valid REPORTER_PHONE= "+phoneNo+" and INFOMAN_NAME = "+infomanName);
										boolean isValidSsoIdTemp = rfcUtil.updateRFCRequestorName(
												tiRequestId, infomanName,phoneNo,sso_Id);
										if(isValidSsoIdTemp) {
											isValidSsoId = true;
											log.info("Updated succesfully with valid REPORTER_PHONE= "+phoneNo+" and INFOMAN_NAME = "+infomanName);
										}
									}

								}
							}
						}
					}

				}
			}
			log.info("final update status from the table " +isValidSsoId);
			if (isValidSsoId) {
				rfcErrorMessage = "success";
			}
		} catch (Exception ex) {
			log.error("Exception Occurred while getting and updating People Record "
					+ ex.getMessage());
		}
		log.info("ManageRFCImpl::getPeopleRecord :: ends");
		return rfcErrorMessage;*/
		return "success";
	}

	/**
	 * Gets the people record.
	 *
	 * @param recordId the record id
	 * @param userId the user id
	 * @return the people record
	 * @throws Exception the exception
	 */
	/*private String getPeopleRecord(String recordId, String userId) throws Exception {
		log.info("ManageRFCImpl::getPeopleRecord :: starts");
		String responseXml = null;
		VirtualChange_PortType_ infomanStub = null;
		try {
			infomanStub = rfcUtil.intializeVirtualChangePortType();
			GetRecord record=new GetRecord();
			record.setIAm(RFC_APPLICATION_ALIAS);
			record.setUserId(userId);
			record.setRecordId(recordId);
			log.info(record);
			Object o=infomanStub.getRecord(record);
			log.info(o);
			javax.xml.soap.SOAPElement s = (javax.xml.soap.SOAPElement)o;
			Iterator iter=s.getChildElements();
			SOAPMessage msg = MessageFactory.newInstance().createMessage();
			log.info("SOAP MESSAGE::" + msg.toString());
			SOAPEnvelope envelope = msg.getSOAPPart().getEnvelope();
			SOAPBody body = envelope.getBody();
			javax.xml.soap.Name name = envelope.createName("field");
			while(iter.hasNext()){
				SOAPElement elem=(SOAPElement)iter.next();
				log.info(elem.getAttributeValue(name) +" :: "+elem.getValue());
			}
			Iterator attrs=s.getAllAttributes();
			while (attrs.hasNext()){
				log.info(attrs.next());
			}
			log.info(s);
			responseXml= s.toString();
		} catch (RemoteException xe) {
			log.error("Remote Exception " + xe.getMessage(), xe);
			throw new Exception(xe.getMessage());
		} catch (SOAPFaultException xe) {
			log.error("SOAPFaultException  " + xe.getMessage(), xe);
			throw new Exception(xe.getMessage());
		} catch (Exception xe) {
			log.error(xe.getMessage(), xe);
			throw new Exception(xe.getMessage());
		}
		log.info("ManageRFCImpl::getPeopleRecord :: Ends");
		return responseXml;

	}*/
	
	public Map<String,String> getCabApproverCode(String groupid)throws Exception{
		log.info("Enter into ManageRFCImpl.getCabApproverCode:");
		String rfcErrorMessage = null;
		Map<String,String> groupDtlsMap = null ;
		Map<String,String> matchGroupDtlsMap = null;
		try {
			
//			StringBuffer response = rfcUtil.getApproverGroup();
			groupDtlsMap = snowUserGroupUtil.getUserGroup();
			//log.info("REsponse::"+response);
			/*List xmlElements = new ArrayList();
			xmlElements.add("RECORD");
			groupDtlsMap = rfcUtil.getGroupDetails(xmlElements,response);*/
			matchGroupDtlsMap = new HashMap<String,String>();
			
			if (groupid != null && !groupid.trim().equalsIgnoreCase("*") && !groupDtlsMap.isEmpty()) {
				Set<String> keySet = groupDtlsMap.keySet();
				for (Iterator iterator = keySet.iterator(); iterator
						.hasNext();) {
					String key = (String) iterator.next();
					log.debug("key value" +key);
					if(key != null && !key.isEmpty()){
					if(key.contains(groupid.toUpperCase()) ){
						matchGroupDtlsMap.put(key,groupDtlsMap.get(key));
					}
					}
				}
			}else if(groupid.trim().equalsIgnoreCase("*")){
				matchGroupDtlsMap = groupDtlsMap;
			}
			if(matchGroupDtlsMap.isEmpty()){
				rfcErrorMessage = "Group Code is not existed.";
				matchGroupDtlsMap.put("ERRORMSG",rfcErrorMessage);
				log.info("ManageRFCImpl.getCabApproverCode:.rfcErrorMessage:: " + rfcErrorMessage);
			}

		} catch (Exception ex) {
			log.error("Exception Occurred while getting People Record "
					+ ex.getMessage());
			throw ex;
		}
	
		log.info("Exited from ManageRFCImpl.getCabApproverCode:");
		return matchGroupDtlsMap;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#storeGenericRFC(java.lang.Long)
	 */
	public void storeGenericRFC(Long tiRequestId) {
		log.info("ManageRFCImpl::storeGenericRFC :: Starts");

		TIRequest tiRequest = new TIRequest();
		tiRequest.setId(tiRequestId);
		boolean  rfcRequestIdFlag = false;
		String createType = RFCRequestDTO.RFC_CREATE_TYPE_MANUAL;
		try {
			List rfcRequestList = getRFCRequest(tiRequest);
			if (rfcRequestList != null && rfcRequestList.size() > 0) {
				if (rfcRequestList.size() == 1) {
					RFCRequest rfcReq = (RFCRequest) rfcRequestList.get(0);
					String rfcType = rfcReq.getRfcRequestType();
					if (rfcType.equals(RFCRequestDTO.RFC_REQ_TYPE_GENERIC)) {
						rfcRequestIdFlag = storeManualRFC(tiRequest,
								RFC_REQ_TYPE_FIREWALL, createType);
					}
				} else if (rfcRequestList.size() > 1) {
					boolean rfcFirewallflag = false;
					String rfcType = null;
					for (int i = 0; i < rfcRequestList.size(); i++) {
						RFCRequest rfcReq = (RFCRequest) rfcRequestList.get(i);
						rfcReq.getRfcRequestType();
						if (rfcReq.getRfcRequestType() != null
								&& rfcReq.getRfcRequestType().equals(
										RFC_REQ_TYPE_FIREWALL)) {
							rfcFirewallflag = true;
						} else if (rfcReq.getRfcRequestType() != null
								&& rfcReq.getRfcRequestType().equals(
										RFCRequestDTO.RFC_REQ_TYPE_GENERIC)) {
							rfcType = rfcReq.getRfcRequestType();
						}
					}
					if (!rfcFirewallflag) {

						if (rfcType.equals(RFCRequestDTO.RFC_REQ_TYPE_GENERIC)) {
							rfcRequestIdFlag = storeManualRFC(tiRequest,
									RFC_REQ_TYPE_FIREWALL,
									createType);
						}
					}
				}
			} else {
				// store RFC request with generic
				rfcRequestIdFlag = storeManualRFC(tiRequest,
						RFCRequestDTO.RFC_REQ_TYPE_GENERIC, null);
				if (rfcRequestIdFlag) {
					boolean rfcReqId = storeManualRFC(tiRequest,
							RFC_REQ_TYPE_FIREWALL, createType);
				}
			}

		} catch (Exception ex) {
			log.error("Exception occurred while creating RFC request manually."
					+ ex.getMessage());
		}
		log.info("ManageRFCImpl::storeGenericRFC :: Ends ");
	}

	/**
	 * Store manual rfc.
	 *
	 * @param tiRequest the ti request
	 * @param rfcRequestType the rfc request type
	 * @param createType the create type
	 * @return true, if successful
	 */
	private boolean storeManualRFC(TIRequest tiRequest, String rfcRequestType,
			String createType) {
		log.info(" ManageRFCImpl : storeManualRFC()  :Starts ");
		boolean rfcRequestIdFlag=false;
		RFCRequest rfcRequest = new RFCRequest();
		rfcRequest.setTiRequest(tiRequest);
		rfcRequest.setRfcRequestType(rfcRequestType);
		if (createType != null) {
			rfcRequest.setCreate_type(createType);
			rfcRequest
			.setRfcErrorCode(RFCRequestDTO.ERRORCODE_POST_NOTAPPLICABLE);
		}
		rfcRequest.setCreated_date(new Date());
//		Long rfcRequestId = rfcPersistable.storeRFCRequest(rfcRequest);
		//Long rfcRequestId = rfcUtil.insertManualRFC(rfcRequest);//rfcPersistable.storeRFCRequest(rfcRequest);
		RFCRequestDTO rfcRequestDTO=new RFCRequestDTO();
//		rfcRequestDTO.setId(rfcRequestId);
		rfcRequestDTO.setTiRequestId(tiRequest.getId());
		rfcRequestDTO.setErrorMessage("Unknown Exception Occurred");
		int count=rfcUtil.insertRFCError(rfcRequestDTO);
		if(count>0){
			rfcRequestIdFlag=true;
		}
		log.info(" ManageRFCImpl : storeManualRFC()  :Ends "+rfcRequestIdFlag);
		return rfcRequestIdFlag;

	}

	/**
	 * Gets the rFC request.
	 *
	 * @param tiRequest the ti request
	 * @return the rFC request
	 */
	public List getRFCRequest(TIRequest tiRequest) {
		log.info(" ManageRFCImpl : getRFCRequest()  :Starts ");
//		List rfcRequestList = rfcPersistable.findRFCRequestList(tiRequest,
//				true);
		log.info(" ManageRFCImpl : getRFCRequest()  :Ends ");
		return null;
	}
	private void  createServiceNowRequest(RFCRequestDTO rfcReqDTO, RFCRequest rfcRequest) {
		log.info("ManageRFCImpl :: createServiceNowRequest method starts");
		try{
			ServiceNowMessageLog snowMessageLog = new ServiceNowMessageLog();
			
			snowMessageLog.setId(rfcUtil.getSequenceNextVal(SEQ_SERVICENOW_MESSAGE_LOG));
			snowMessageLog.setTiRequestID(rfcReqDTO.getTiRequestId());
			snowMessageLog.setType(CHANGE_REQUEST_CODE);

			List<ServiceNowMessageText> snowMsgTextList = new ArrayList<ServiceNowMessageText>();
			ServiceNowMessageText snowMsgText = new ServiceNowMessageText();
			snowMsgText.setMessageType(MSG_TYPE_OUTBOUND);
			snowMsgTextList.add(snowMsgText);
			snowMessageLog.setServiceNowMessageText(snowMsgTextList);
			
			//snowMessageLog.save();
			//ServiceNowMessageLog newSNowMsgLog = snowMessageLog.findServiceNowMessageLogByID(snowMessageLog.getId());
			
			Long connectionID = rfcUtil.getConnectionRequestId(rfcReqDTO.getTiRequestId());
			ArrayList contactDetails = rfcUtil.getBusinessContactsDetails(connectionID,"'Requestor','DESIGN ENGINEER'");
			ServiceNowQueueSenderImpl serviceNowQueueSenderImpl = new ServiceNowQueueSenderImpl();
			String serviceNowCreateRequest = null;

			log.info("ManageRFCImpl :: createServiceNowRequest :: getRfcType - "+rfcReqDTO.getRfcType());
			
			if(rfcReqDTO.getRfcType() != null && rfcReqDTO.getRfcType().equalsIgnoreCase("FW")){
				serviceNowCreateRequest = getServiceNowChangeRequestXml(rfcReqDTO, rfcRequest, snowMessageLog, contactDetails);			
			}else if(rfcReqDTO.getRfcType() != null && rfcReqDTO.getRfcType().equalsIgnoreCase("Proxy")){
				serviceNowCreateRequest = getServiceNowChgReqtXml4Proxy(rfcReqDTO, rfcRequest, snowMessageLog, contactDetails);
			}			
			//log.info("serviceNowCreateRequest XML ==> "+serviceNowCreateRequest);
			
			//Blob msgText = Hibernate.createBlob(serviceNowCreateRequest.getBytes());
			//snowMsgText.setMessageText(msgText);
			if(rfcReqDTO.getErrorCode() == null && serviceNowCreateRequest != null){ //if the RequestXML preparation has error, dont post request to ServiceNow.
				rfcUtil.serviceNowMessageLogSave(snowMessageLog,serviceNowCreateRequest.getBytes());
				log.info("Sending Request to ServiceNow");
				serviceNowQueueSenderImpl.sendMesage(serviceNowCreateRequest);
				log.info("Updating RFCRequest ReqStatus as POSTED");
				rfcReqDTO.setRfcId("");
				rfcReqDTO.setRfcStatus("POSTED");
				rfcUtil.updateRFCRequestDetails("", rfcReqDTO);	
			}
		}catch(Exception ex){
			log.error(ex,ex);
			log.error("Error while Sending ServieNow ChangeRequest");
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
			rfcReqDTO.setErrorMessage(ex.getMessage());
		}
		log.info("ManageRFCImpl :: createServiceNowRequest method ends");
	}
	
	private String getServiceNowChangeRequestXml(RFCRequestDTO rfcReqDTO, RFCRequest rfcRequest, ServiceNowMessageLog SNMsgLog, ArrayList contactDetails) {
		log.info("ManageRFCImpl :: getServiceNowChangeRequestXml method starts");
		String temp = "";
		try{
			/*PurchaseOrderDocument purchaseOrderDocument = PurchaseOrderDocument.Factory.newInstance();
			PurchaseOrder purchaseOrder = purchaseOrderDocument.addNewPurchaseOrder();
			ArrayOfPurchaseOptionDescription arrayOfPurchaseOptionDescription = purchaseOrder.addNewPurchaseOptions();
			PurchaseOptionDescription pod = arrayOfPurchaseOptionDescription.addNewPurchaseOptionDescription();*/
			PurchaseOptionDescriptionDocument podDoc = PurchaseOptionDescriptionDocument.Factory.newInstance();			
			PurchaseOptionDescription pod = podDoc.addNewPurchaseOptionDescription();
            
			OrderSystem os = pod.addNewOrderSystem();
			os.setSystemID(SYSTEM_ID);
			StringBuffer mappingRef = new StringBuffer();
			mappingRef.append(rfcReqDTO.getId());
			mappingRef.append("-");			
			if(rfcRequest.getRfcLocationID() != null){
				mappingRef.append(rfcRequest.getRfcLocationID().getFwLocation());
			}else{
				mappingRef.append("");
			}
			mappingRef.append("-");
			mappingRef.append(rfcReqDTO.getTiRequestId());
			mappingRef.append("-");
			mappingRef.append(SNMsgLog.getId());
			/*mappingRef.append("-");
			mappingRef.append(VERSION);		*/
			os.setMappingReference(mappingRef.toString());
			
		    String installDate = rfcUtil.insertTimeDetails(rfcReqDTO.getTiRequestId(), rfcReqDTO.getId());			   
		    log.info("ManageRFCImpl :: installDate:-"+installDate);	
			
			FulfilmentSystem ffs = pod.addNewFulfilmentSystem();
			ffs.setSystemID(SERVICE_NOW);
			FulfilmentItem ffi = pod.addNewFulfilmentItem();
			ffi.setFulfilmentItemName(CR_CREATE);//ChangeRequestCreate,ChangeRequestUpdate
			DataForm df = ffi.addNewDataForm();
			//df.setVersion(VERSION_1);
			df.setIsDetached(BOOLEAN_FALSE);
			ArrayOfDataFieldGroup dfgs= df.addNewDataFieldGroups();
			DataFieldGroup dfg = dfgs.addNewDataFieldGroup();
			dfg.setName(HEADER);
			
			String RequesterID = "", shortDescription = "", description = "", backoutPlan = "", testPlan = "", applicationInstance = "", expedited = ""
					, expedited_reason = "", utcStartDate = "", utcEndDate = "", countryCode = "", justification = "";
			
			rfcRequest = rfc.getRFCDetails(rfcRequest,BASICINFO,RFC_REQ_TYPE_FIREWALL);			
			if(rfcRequest != null){	
				RequesterID = getRFCAnswer(rfcRequest.getSnowRequester(), true);
				shortDescription = getRFCAnswer(rfcRequest.getShortDescription(), false);	
				applicationInstance = getRFCAnswer(rfcRequest.getApplicationInstance(), true);				
				expedited = getRFCAnswer(rfcRequest.getExpideted(), true);
				expedited_reason = getRFCAnswer(rfcRequest.getExpidetedReason(), false);
				utcStartDate = getRFCAnswer(rfcRequest.getInstallStartDate(), true);
				utcEndDate = getRFCAnswer(rfcRequest.getInstallEndDate(), true);
				countryCode = getMultipleRFCDetailAnswerWithComma(rfcRequest.getCountryCode());
				justification = getRFCAnswer(rfcRequest.getJustification(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_DESCRIPTION,RFC_REQ_TYPE_FIREWALL);	
			if(rfcRequest != null){
				description = getRFCAnswer(rfcRequest.getDescription(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_BACKOUTPLAN,RFC_REQ_TYPE_FIREWALL);	
			if(rfcRequest != null){
				backoutPlan = getRFCAnswer(rfcRequest.getBackoutPlan(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_TESTPLAN,RFC_REQ_TYPE_FIREWALL);	
			if(rfcRequest != null){
				testPlan = getRFCAnswer(rfcRequest.getTestPlan(), false);
			}
			
			ArrayOfDataField dfs = dfg.addNewDataFields();

            DataField catdatafield = dfs.addNewDataField();
            catdatafield.setName(CATEGORY);
            ArrayOfString catdatastr = catdatafield.addNewValues();
            catdatastr.addValue("SECURITY/FIREWALL");
            
			DataField dfield2 = dfs.addNewDataField();
			dfield2.setName(TITLE);
			ArrayOfString str2 = dfield2.addNewValues();
			str2.addValue(shortDescription);
			//dfield2.setValues(str2);

			DataField dfield3 = dfs.addNewDataField();
			dfield3.setName(PRIMARY_APP_INSTANCE);
			ArrayOfString str3 = dfield3.addNewValues();
			str3.addValue(applicationInstance);
			//dfield3.setValues(str3);

			DataField dfield5 = dfs.addNewDataField();
			dfield5.setName(REQUESTOR);
			ArrayOfString str5 = dfield5.addNewValues();
			str5.addValue(RequesterID);
			//dfield5.setValues(str5);	

			DataField dfield7 = dfs.addNewDataField();
			dfield7.setName(JUSTIFICATION);
			ArrayOfString str7 = dfield7.addNewValues();
			str7.addValue(justification);
			//dfield7.setValues(str7);
			
			DataField dfield6 = dfs.addNewDataField();
			dfield6.setName(DESCRIPTION);
			ArrayOfString str6 = dfield6.addNewValues();
			str6.addValue(description);
			//dfield6.setValues(str6);

			DataFieldGroup dfg2 = dfgs.addNewDataFieldGroup();
			dfg2.setName(ADD_REQ_DETAILS);
			ArrayOfDataField dfs2 = dfg2.addNewDataFields();

			DataField dfield11 = dfs2.addNewDataField();
			dfield11.setName(CHANGE_CATALOG);
			ArrayOfString str11 = dfield11.addNewValues();
			String change_catalog = rfcUtil.getGenericLookUpValue(CHANGE_REQUEST_ID);
			str11.addValue(change_catalog); //UAT:- CTMP0000002707,CTMP0000003935 , DEV:- CTMP0000002701 
			//dfield11.setValues(str11);
			
			DataField dfield14 = dfs2.addNewDataField();
			dfield14.setName(UTC_START_DATE);
			ArrayOfString str14 = dfield14.addNewValues();	
			str14.addValue(utcStartDate);
			//dfield14.setValues(str14);
			
			DataField dfield15 = dfs2.addNewDataField();	
			dfield15.setName(UTC_END_DATE);
			ArrayOfString str15 = dfield15.addNewValues();	
			str15.addValue(utcEndDate);
			//dfield15.setValues(str15);
			
			DataField dfield17 = dfs2.addNewDataField();
			dfield17.setName(IMPACTED_COUNTRIES);
			ArrayOfString str17 = dfield17.addNewValues();
			str17.addValue(countryCode);
			//dfield17.setValues(str17);
			
			DataField dfield120 = dfs2.addNewDataField();
			dfield120.setName(BACKOUTPLAN);
			ArrayOfString str120 = dfield120.addNewValues();
			str120.addValue(backoutPlan);
			//dfield120.setValues(str120);
			
			DataField dfield122 = dfs2.addNewDataField();
			dfield122.setName(EXPEDITED);
			ArrayOfString str122 = dfield122.addNewValues();
			str122.addValue(expedited);
			//dfield122.setValues(str122);
			
			DataField dfield1123 = dfs2.addNewDataField();
			dfield1123.setName(EXPEDITED_REASON);
			ArrayOfString str1123 = dfield1123.addNewValues();
			str1123.addValue(expedited_reason);
			//dfield1123.setValues(str1123);
			
			DataFieldGroup dfg3 = dfgs.addNewDataFieldGroup();
			dfg3.setName(TEST_DETAILS);
			ArrayOfDataField dfs3 = dfg3.addNewDataFields();
			
			DataField dfield21 = dfs3.addNewDataField();
			dfield21.setName(POST_IMP_TEST_PLAN);
			ArrayOfString str21 = dfield21.addNewValues();
			str21.addValue(testPlan);
			//dfield21.setValues(str21);
			
			DataFieldGroup dfg4 = dfgs.addNewDataFieldGroup();
			dfg4.setName(AUDIT);
			ArrayOfDataField dfs4 = dfg4.addNewDataFields();
			
			int counter = 0;
			
			DataFieldGroup dfgArr[] = null;
			
			ArrayOfDataField arrDF[] = null;
			
			ArrayOfString arrStr[] = null;
			ArrayOfString arrStr2[] = null;
			
			DataField dataFld[] = null;
			DataField dataFld2[] = null;
			
			//Add Additional application details in ApplicationInstance
			if(rfcRequest.getSnowApplicationInstance() != null){
				log.info("ManageRFCImpl :: rfcRequest.getSnowApplicationInstance().."+rfcRequest.getSnowApplicationInstance());
				RFCDetail rfcDetail = rfcRequest.getSnowApplicationInstance();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArr = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDF = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStr = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2 = new ArrayOfString[rfcDtlAnswers.size()];
				dataFld = new DataField[rfcDtlAnswers.size()];
				dataFld2 = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddAppInstance(dfgs, rfcAns, BOOLEAN_TRUE_STR,dfgArr[counter],arrDF[counter],arrStr[counter],arrStr2[counter],dataFld[counter],dataFld2[counter],APP_INSTANCE,NAME,IMPACTED);
						counter=counter+1;
					}
				}				
			}
			
			counter = 0;
			DataFieldGroup dfgArry[] = null;
			
			ArrayOfDataField arrDFy[] = null;
			
			ArrayOfString arrStry[] = null;
			ArrayOfString arrStr2y[] = null;
			
			DataField dataFldy[] = null;
			DataField dataFld2y[] = null;

			if(rfcRequest.getCSIApplicationInstance() != null){
				RFCDetail rfcDetail = rfcRequest.getCSIApplicationInstance();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArry = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFy = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStry = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2y = new ArrayOfString[rfcDtlAnswers.size()];
				dataFldy = new DataField[rfcDtlAnswers.size()];
				dataFld2y = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddAppInstance(dfgs, rfcAns, BOOLEAN_FALSE_STR,dfgArry[counter],arrDFy[counter],arrStry[counter],arrStr2y[counter],dataFldy[counter],dataFld2y[counter],APP_INSTANCE,NAME,IMPACTED);
						counter=counter+1;
					}
				}				
			}			
			

			counter = 0;
			DataFieldGroup dfgArra[] = null;
			
			ArrayOfDataField arrDFa[] = null;
			
			ArrayOfString arrStra[] = null;
			ArrayOfString arrStr2a[] = null;
			
			DataField dataFlda[] = null;
			DataField dataFld2a[] = null;

		/*	DataFieldGroup dfg6 = dfgs.addNewDataFieldGroup();
			dfg6.setName(CONFIGITEM);
			ArrayOfDataField dfs6 = dfg6.addNewDataFields();
			
			DataField dfield51 = dfs6.addNewDataField();
			dfield51.setName(SOURCE);
			ArrayOfString str51 = dfield51.addNewValues();
			str51.addValue("NetInfo");
			//dfield51.setValues(str51);
			
			DataField dfield52 = dfs6.addNewDataField();
			dfield52.setName(ID);
			ArrayOfString str52 = dfield52.addNewValues();
			str52.addValue("");
			//dfield52.setValues(str52);
*/			
			if(rfcRequest.getSnowDeviceId() != null){
				RFCDetail rfcDetail = rfcRequest.getSnowDeviceId();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArra = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFa = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStra = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2a = new ArrayOfString[rfcDtlAnswers.size()];
				dataFlda = new DataField[rfcDtlAnswers.size()];
				dataFld2a = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddDeviceIds(dfgs, rfcAns, "NetInfo",dfgArra[counter],arrDFa[counter],arrStra[counter],arrStr2a[counter],dataFlda[counter],
								dataFld2a[counter],CONFIGITEM,SOURCE,ID);
						counter=counter+1;
					}
				}				
			}
			
			
			counter = 0;
			DataFieldGroup dfgArrz[] = null;
			
			ArrayOfDataField arrDFz[] = null;
			
			ArrayOfString arrStrz[] = null;
			ArrayOfString arrStr2z[] = null;
			
			DataField dataFldz[] = null;
			DataField dataFld2z[] = null;
			
			if(rfcRequest.getMultiCABAppCode() != null){
				RFCDetail rfcDetail = rfcRequest.getMultiCABAppCode();
				
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				
				dfgArrz = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFz = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStrz = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2z = new ArrayOfString[rfcDtlAnswers.size()];
				dataFldz = new DataField[rfcDtlAnswers.size()];
				dataFld2z = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() >= 1){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){	
						snowAddAppInstance(dfgs, rfcAns, "Not Applicable",dfgArrz[counter],arrDFz[counter],arrStrz[counter],arrStr2z[counter],dataFldz[counter],dataFld2z[counter],
								GROUPAPPROVAL,ASSIGNMENT_GROUP,COMMENTS);
						counter=counter+1;
					}
				}				
			}			
			
			temp = podDoc.toString();
			/*temp = temp.replaceAll(PURCHASE_OPTION_DES, PURCHASE_OPTION_DES_1);
			temp = temp.replaceAll(PURCHASE_ORDER, "");
			temp = temp.replaceAll(PURCHASE_OPTIONS,"");
			temp = temp.replaceAll(PURCHASE_OPTIONS_END,"");
			temp = temp.replaceAll(PURCHASE_ORDER_END,"");
			temp = temp.trim();
			temp = XML_HEADER + temp;*/
		}catch(Exception ex){
			log.error(ex,ex);
			log.error("ManageRFCImpl :: Error while Preparing RequestXML for ServieNow ChangeRequest");
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
			rfcReqDTO.setErrorMessage(ex.getMessage());
		}
		log.info("ManageRFCImpl :: getServiceNowChangeRequestXml method ends");
		return temp;		
	}
	
	private String getServiceNowChgReqtXml4Proxy(RFCRequestDTO rfcReqDTO, RFCRequest rfcRequest, ServiceNowMessageLog SNMsgLog, ArrayList contactDetails) {
		log.info("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy method starts");
		String temp = "";
		try{
			PurchaseOptionDescriptionDocument podDoc = PurchaseOptionDescriptionDocument.Factory.newInstance();			
			PurchaseOptionDescription pod = podDoc.addNewPurchaseOptionDescription();
            
			OrderSystem os = pod.addNewOrderSystem();
			os.setSystemID(SYSTEM_ID);
			StringBuffer mappingRef = new StringBuffer();
			mappingRef.append(rfcReqDTO.getId());
			mappingRef.append("-");			
			if(rfcRequest.getRfcLocationID() != null){
				mappingRef.append(rfcRequest.getRfcLocationID().getFwLocation());
			}else{
				mappingRef.append("");
			}
			mappingRef.append("-");
			mappingRef.append(rfcReqDTO.getTiRequestId());
			mappingRef.append("-");
			mappingRef.append(SNMsgLog.getId());
			os.setMappingReference(mappingRef.toString());
			
		    String installDate = rfcUtil.insertTimeDetailsForProxy(rfcReqDTO.getTiRequestId(), rfcReqDTO.getId());			   
		    log.info("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy:: installDate:-"+installDate);	
			
			FulfilmentSystem ffs = pod.addNewFulfilmentSystem();
			ffs.setSystemID(SERVICE_NOW);
			FulfilmentItem ffi = pod.addNewFulfilmentItem();
			ffi.setFulfilmentItemName(CR_CREATE);//ChangeRequestCreate,ChangeRequestUpdate
			DataForm df = ffi.addNewDataForm();

			df.setIsDetached(BOOLEAN_FALSE);
			ArrayOfDataFieldGroup dfgs= df.addNewDataFieldGroups();
			DataFieldGroup dfg = dfgs.addNewDataFieldGroup();
			dfg.setName(HEADER);
			
			String RequesterID = "", shortDescription = "", description = "", backoutPlan = "", testPlan = "", applicationInstance = "", expedited = ""
					, expedited_reason = "", utcStartDate = "", utcEndDate = "", countryCode = "", justification = "", pretestexcempt = "",pretestexcempt_testplan = "";
		
			rfcRequest = rfc.getRFCDetails(rfcRequest,BASICINFO,RFC_REQ_TYPE_PROXY);			
			if(rfcRequest != null){	
				RequesterID = getRFCAnswer(rfcRequest.getSnowRequester(), true);
				shortDescription = getRFCAnswer(rfcRequest.getShortDescription(), false);	
				applicationInstance = getRFCAnswer(rfcRequest.getApplicationInstance(), true);				
				expedited = getRFCAnswer(rfcRequest.getExpideted(), true);
				expedited_reason = getRFCAnswer(rfcRequest.getExpidetedReason(), false);
				utcStartDate = getRFCAnswer(rfcRequest.getInstallStartDate(), true);
				utcEndDate = getRFCAnswer(rfcRequest.getInstallEndDate(), true);
				countryCode = getMultipleRFCDetailAnswerWithComma(rfcRequest.getCountryCode());
				justification = getRFCAnswer(rfcRequest.getJustification(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_DESCRIPTION_PROXY,RFC_REQ_TYPE_PROXY);	
			if(rfcRequest != null){
				description = getRFCAnswer(rfcRequest.getDescription(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_BACKOUTPLAN_PROXY,RFC_REQ_TYPE_PROXY);	
			if(rfcRequest != null){
				backoutPlan = getRFCAnswer(rfcRequest.getBackoutPlan(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_TESTPLAN_PROXY,RFC_REQ_TYPE_PROXY);	
			if(rfcRequest != null){
				testPlan = getRFCAnswer(rfcRequest.getTestPlan(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_PRE_TESTPLAN_PROXY,RFC_REQ_TYPE_PROXY);	
			if(rfcRequest != null){
				pretestexcempt = getRFCAnswer(rfcRequest.getPretestexcempt(), true);
				pretestexcempt_testplan = getRFCAnswer(rfcRequest.getPretestexcempttestPlan(), true);
			}			   
		    log.info("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy:: pretestexcempt:-"+pretestexcempt+" , pretestexcempt_testplan :: "+pretestexcempt_testplan);	
			
			ArrayOfDataField dfs = dfg.addNewDataFields();

            DataField catdatafield = dfs.addNewDataField();
            catdatafield.setName(CATEGORY);
            ArrayOfString catdatastr = catdatafield.addNewValues();
            catdatastr.addValue("SECURITY/PROXY");
            
			DataField dfield2 = dfs.addNewDataField();
			dfield2.setName(TITLE);
			ArrayOfString str2 = dfield2.addNewValues();
			str2.addValue(shortDescription);

			DataField dfield3 = dfs.addNewDataField();
			dfield3.setName(PRIMARY_APP_INSTANCE);
			ArrayOfString str3 = dfield3.addNewValues();
			str3.addValue(applicationInstance);

			DataField dfield5 = dfs.addNewDataField();
			dfield5.setName(REQUESTOR);
			ArrayOfString str5 = dfield5.addNewValues();
			str5.addValue(RequesterID);

			DataField dfield7 = dfs.addNewDataField();
			dfield7.setName(JUSTIFICATION);
			ArrayOfString str7 = dfield7.addNewValues();
			str7.addValue(justification);
			
			DataField dfield6 = dfs.addNewDataField();
			dfield6.setName(DESCRIPTION);
			ArrayOfString str6 = dfield6.addNewValues();
			str6.addValue(description);

			DataFieldGroup dfg2 = dfgs.addNewDataFieldGroup();
			dfg2.setName(ADD_REQ_DETAILS);
			ArrayOfDataField dfs2 = dfg2.addNewDataFields();

			DataField dfield11 = dfs2.addNewDataField();
			dfield11.setName(CHANGE_CATALOG);
			ArrayOfString str11 = dfield11.addNewValues();
			String change_catalog = rfcUtil.getGenericLookUpValue(CHANGE_REQUEST_ID);
			str11.addValue(change_catalog); //UAT:- CTMP0000002707,CTMP0000003935 , DEV:- CTMP0000002701 
			
			DataField dfield14 = dfs2.addNewDataField();
			dfield14.setName(UTC_START_DATE);
			ArrayOfString str14 = dfield14.addNewValues();	
			str14.addValue(utcStartDate);
			
			DataField dfield15 = dfs2.addNewDataField();	
			dfield15.setName(UTC_END_DATE);
			ArrayOfString str15 = dfield15.addNewValues();	
			str15.addValue(utcEndDate);
			
			DataField dfield17 = dfs2.addNewDataField();
			dfield17.setName(IMPACTED_COUNTRIES);
			ArrayOfString str17 = dfield17.addNewValues();
			str17.addValue(countryCode);
			
			DataField dfield120 = dfs2.addNewDataField();
			dfield120.setName(BACKOUTPLAN);
			ArrayOfString str120 = dfield120.addNewValues();
			str120.addValue(backoutPlan);
			
			DataField dfield122 = dfs2.addNewDataField();
			dfield122.setName(EXPEDITED);
			ArrayOfString str122 = dfield122.addNewValues();
			str122.addValue(expedited);
			
			DataField dfield1123 = dfs2.addNewDataField();
			dfield1123.setName(EXPEDITED_REASON);
			ArrayOfString str1123 = dfield1123.addNewValues();
			str1123.addValue(expedited_reason);
			
			DataFieldGroup dfg3 = dfgs.addNewDataFieldGroup();
			dfg3.setName(TEST_DETAILS);
			ArrayOfDataField dfs3 = dfg3.addNewDataFields();
			
			if(pretestexcempt != null && pretestexcempt.equalsIgnoreCase("false")){

				DataField dfield24 = dfs3.addNewDataField();
				dfield24.setName(PRE_TEST_EXCEMPT);
				ArrayOfString str24 = dfield24.addNewValues();
				str24.addValue(pretestexcempt);

				DataField dfield25 = dfs3.addNewDataField();
				dfield25.setName(TEST_PLAN);
				ArrayOfString str25 = dfield25.addNewValues();
				str25.addValue(pretestexcempt_testplan);
				
			}
			
			DataField dfield21 = dfs3.addNewDataField();
			dfield21.setName(POST_IMP_TEST_PLAN);
			ArrayOfString str21 = dfield21.addNewValues();
			str21.addValue(testPlan);
			
			DataFieldGroup dfg4 = dfgs.addNewDataFieldGroup();
			dfg4.setName(AUDIT);
			ArrayOfDataField dfs4 = dfg4.addNewDataFields();
			
			int counter = 0;
			
			DataFieldGroup dfgArr[] = null;
			
			ArrayOfDataField arrDF[] = null;
			
			ArrayOfString arrStr[] = null;
			ArrayOfString arrStr2[] = null;
			
			DataField dataFld[] = null;
			DataField dataFld2[] = null;
			
			//Add Additional application details in ApplicationInstance
			if(rfcRequest.getSnowApplicationInstance() != null){
				log.info("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy:: rfcRequest.getSnowApplicationInstance().."+rfcRequest.getSnowApplicationInstance());
				RFCDetail rfcDetail = rfcRequest.getSnowApplicationInstance();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArr = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDF = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStr = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2 = new ArrayOfString[rfcDtlAnswers.size()];
				dataFld = new DataField[rfcDtlAnswers.size()];
				dataFld2 = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddAppInstance(dfgs, rfcAns, BOOLEAN_TRUE_STR,dfgArr[counter],arrDF[counter],arrStr[counter],arrStr2[counter],dataFld[counter],dataFld2[counter],APP_INSTANCE,NAME,IMPACTED);
						counter=counter+1;
					}
				}				
			}
			counter = 0;
			DataFieldGroup dfgArry[] = null;
			
			ArrayOfDataField arrDFy[] = null;
			
			ArrayOfString arrStry[] = null;
			ArrayOfString arrStr2y[] = null;
			
			DataField dataFldy[] = null;
			DataField dataFld2y[] = null;

			if(rfcRequest.getCSIApplicationInstance() != null){
				RFCDetail rfcDetail = rfcRequest.getCSIApplicationInstance();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				log.debug("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy :: rfcDtlAnswers.size.."+rfcDtlAnswers.size());
				dfgArry = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFy = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStry = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2y = new ArrayOfString[rfcDtlAnswers.size()];
				dataFldy = new DataField[rfcDtlAnswers.size()];
				dataFld2y = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddAppInstance(dfgs, rfcAns, BOOLEAN_FALSE_STR,dfgArry[counter],arrDFy[counter],arrStry[counter],arrStr2y[counter],dataFldy[counter],dataFld2y[counter],APP_INSTANCE,NAME,IMPACTED);
						counter=counter+1;
					}
				}				
			}
			counter = 0;
			DataFieldGroup dfgArra[] = null;
			
			ArrayOfDataField arrDFa[] = null;
			
			ArrayOfString arrStra[] = null;
			ArrayOfString arrStr2a[] = null;
			
			DataField dataFlda[] = null;
			DataField dataFld2a[] = null;

			if(rfcRequest.getSnowDeviceId() != null){
				RFCDetail rfcDetail = rfcRequest.getSnowDeviceId();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArra = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFa = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStra = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2a = new ArrayOfString[rfcDtlAnswers.size()];
				dataFlda = new DataField[rfcDtlAnswers.size()];
				dataFld2a = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddDeviceIds(dfgs, rfcAns, "NetInfo_Name",dfgArra[counter],arrDFa[counter],arrStra[counter],arrStr2a[counter],dataFlda[counter],
								dataFld2a[counter],CONFIGITEM,SOURCE,ID);
						counter=counter+1;
					}
				}				
			}			
			counter = 0;
			DataFieldGroup dfgArrz[] = null;
			
			ArrayOfDataField arrDFz[] = null;
			
			ArrayOfString arrStrz[] = null;
			ArrayOfString arrStr2z[] = null;
			
			DataField dataFldz[] = null;
			DataField dataFld2z[] = null;
			
			if(rfcRequest.getMultiCABAppCode() != null){
				RFCDetail rfcDetail = rfcRequest.getMultiCABAppCode();
				
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				
				dfgArrz = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFz = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStrz = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2z = new ArrayOfString[rfcDtlAnswers.size()];
				dataFldz = new DataField[rfcDtlAnswers.size()];
				dataFld2z = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() >= 1){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){	
						snowAddAppInstance(dfgs, rfcAns, "Not Applicable",dfgArrz[counter],arrDFz[counter],arrStrz[counter],arrStr2z[counter],dataFldz[counter],dataFld2z[counter],
								GROUPAPPROVAL,ASSIGNMENT_GROUP,COMMENTS);
						counter=counter+1;
					}
				}				
			}	
			temp = podDoc.toString();
		}catch(Exception ex){
			log.error(ex,ex);
			log.error("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy:: Error while Preparing RequestXML for ServieNow ChangeRequest");
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
			rfcReqDTO.setErrorMessage(ex.getMessage());
		}
		log.info("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy method ends");
		return temp;		
	}
	
	private String getRFCAnswer(RFCDetail rfcDetail, boolean isSingleAnswer)
    {
		String separator = System.getProperty( "line.separator" );
		String answer = "";
		if(isSingleAnswer == false && rfcDetail != null){
	    	List<RFCDetailAnswer> rda = rfcDetail.getRfcDetailAnswerList();
	    	answer=getMultipleRFCDetailAnswer(rda);
		}else if (isSingleAnswer == true && rfcDetail != null){
	    	List<RFCDetailAnswer> rda = rfcDetail.getRfcDetailAnswerList();
	    	RFCDetailAnswer rfcDetailAns = (RFCDetailAnswer) rda.get(0);
	    	answer = rfcDetailAns.getAnswer();
		}
		
		StringBuilder lines = new StringBuilder((answer.replaceAll("\\\\n", separator)).replaceAll("\n", separator));
		//log.info("value:-"+lines.toString());
		return lines.toString();
    }
	
	public String getMultipleRFCDetailAnswer(List<RFCDetailAnswer> rda)
	{
		StringBuffer question = new StringBuffer();
		for(RFCDetailAnswer rfcDetailAns:rda){
    		
    		if(rfcDetailAns.getTemplateKey()!=null)
			{
				question.append(rfcDetailAns.getTemplateKey().getPositionValue());
				question.append(". ");
				question.append(rfcDetailAns.getTemplateKey().getDescription());
				question.append("\\n");
			}else{
				question.append("");
			}
			question.append(rfcDetailAns.getAnswer());
			question.append("\\n");
			question.append("\\n");
    	}
		
		return question.toString();				
	}
	
	public String getMultipleRFCDetailAnswerWithComma(RFCDetail rfcDetail)
	{
		String str = "";		
		if(rfcDetail != null ){
			List<RFCDetailAnswer> rda = rfcDetail.getRfcDetailAnswerList();
			StringBuffer question = new StringBuffer();
			question.append("");
			for(RFCDetailAnswer rfcDetailAns:rda){
				question.append(rfcDetailAns.getAnswer());
				question.append(",");			
	    	}
			str = question.toString();
			if(str.indexOf(",")!=-1)
			{
				str = str.substring(0,str.lastIndexOf(","));
			}
		}
		return str;				
	}
	private void snowAddAppInstance(ArrayOfDataFieldGroup dfgs, RFCDetailAnswer rfcDetailsAns, String impacted,DataFieldGroup dfgArr,ArrayOfDataField arrDF,ArrayOfString arrStr,ArrayOfString arrStr2,DataField dfld,DataField dfld2,
			String att1,String att2,String att3){
		
		log.debug("ManageRFCImpl :: snowAddAppInstance :: appInstance :-"+rfcDetailsAns.getAnswer());
		dfgArr = dfgs.addNewDataFieldGroup();
		dfgArr.setName(att1);
		arrDF = dfgArr.addNewDataFields();
		
		
		dfld = arrDF.addNewDataField();
		dfld.setName(att2);
		arrStr = dfld.addNewValues();
		arrStr.addValue(rfcDetailsAns.getAnswer());
		//dfield41_2.setValues(str41_2);
		
		dfld2 = arrDF.addNewDataField();
		dfld2.setName(att3);
		arrStr2 = dfld2.addNewValues();
		arrStr2.addValue(impacted);
		//dfield41_app_2.setValues(str41_app_2);
	}
	
	private void snowAddDeviceIds(ArrayOfDataFieldGroup dfgs, RFCDetailAnswer rfcDetailsAns, String impacted,DataFieldGroup dfgArr,ArrayOfDataField arrDF,ArrayOfString arrStr,ArrayOfString arrStr2,DataField dfld,DataField dfld2,
			String att1,String att2,String att3){
		
		//log.info("appInstance:-"+rfcDetailsAns.getAnswer());
		dfgArr = dfgs.addNewDataFieldGroup();
		dfgArr.setName(att1);
		arrDF = dfgArr.addNewDataFields();
		
		
		dfld = arrDF.addNewDataField();
		dfld.setName(att2);
		arrStr = dfld.addNewValues();
		arrStr.addValue(impacted);
		//dfield41_2.setValues(str41_2);
		
		dfld2 = arrDF.addNewDataField();
		dfld2.setName(att3);
		arrStr2 = dfld2.addNewValues();
		arrStr2.addValue(rfcDetailsAns.getAnswer());
		//dfield41_app_2.setValues(str41_app_2);
	}

	@Override
	public Map getSchedulerValues() {
		return rfcUtil.getSchedulerValues();
		
		
	}

	@Override
	public void insertSNActivity(Long tiRequestId) {
		log.debug("insertSNActivity :"+tiRequestId);
		rfcUtil.insertSNActivity(tiRequestId);
		
	}

	@Override
	public void updateSNActivity(Long tiRequestId) {
		log.debug("updateSNActivity :"+tiRequestId);
		rfcUtil.updateSNActivity(tiRequestId);
		
	}

	@Override
	public String getServiceNowCRXml(RFCRequestDTO rfcReqDTO,
			RFCRequest rfcRequest, ServiceNowMessageLog SNMsgLog,
			ArrayList contactDetails) {
		// TODO Auto-generated method stub
		return getServiceNowChangeRequestXml(rfcReqDTO, rfcRequest, SNMsgLog, contactDetails);
	}
	
	@Override
	public boolean isChangeRequestsCreated(ProcessRFCDTO processRFCDTO) {
		boolean processRFCIncomplete=false;
		processRFCDTO=getRFCRequestList(processRFCDTO) ;
		List rfcRequestList=processRFCDTO.getRfcRequestDTOList();

        if (rfcRequestList != null && rfcRequestList.size() > 0) {
            for (int i = 0; i < rfcRequestList.size(); i++) {
                RFCRequestDTO rfcRequestDTO = (RFCRequestDTO) rfcRequestList.get(i);
                String rfcStatus = rfcRequestDTO.getRfcStatus();

                log.debug(" RFC Request ID:  " + rfcRequestDTO.getId() + "  RFC Request Status: " + rfcRequestDTO.getRfcStatus() + " RFC ID" + rfcRequestDTO.getRfcId() + " RFC ERRORCODE " + rfcRequestDTO.getErrorCode());

                if (rfcStatus == null || (rfcStatus != null && (rfcStatus.length() == 0) || (RFCRequestDTO.STATUS_GENERATED == rfcStatus))) {
                    processRFCIncomplete = true;

                    log.debug(" RFC Request Id : " + rfcRequestDTO.getId() + " is routed to HandleRFCException (" + processRFCIncomplete + ") as RFCSTatus is " + rfcRequestDTO.getRfcStatus());

                    break;
                }
            }

            if (! processRFCIncomplete) {
            	  for (int i = 0; i < rfcRequestList.size(); i++) {
                      RFCRequestDTO rfcRequestDTO = (RFCRequestDTO) rfcRequestList.get(i);
                    String rfcId = rfcRequestDTO.getRfcId();

                    log.debug(" RFC Request ID:  " + rfcRequestDTO.getId() + "  RFC Request Status: " + rfcRequestDTO.getRfcStatus() + " RFC ID" + rfcRequestDTO.getRfcId() + " RFC ERRORCODE " + rfcRequestDTO.getErrorCode());

                    if (rfcId == null || ((rfcId != null) && ("0" == rfcId))) {
                        processRFCIncomplete = true;

                        log.debug(" RFC Request Id : " + rfcRequestDTO.getId()+ " is routed to HandleRFCException (" + processRFCIncomplete + ") as RFCID is " + rfcId);

                        break;
                    }
                }
            }
        }
        else {
            log.debug("RFCDTO List is empty for tiRequestId " + processRFCDTO.getTiRequestId() + "routing to HandleRFCException");

            processRFCIncomplete = true;
        }

        // chk and see if rfcRequestIds are if present then for all rfzRequests ids there should be RFC with rfcstatus as design or review else send to excetion
       
       
   
		log.debug("isChangeRequests Not Created :"+processRFCDTO.getTiRequestId()+processRFCIncomplete);
		return processRFCIncomplete;
		
	}
}
