package com.citigroup.cgti.c3par.admin.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.soc.persist.ManageBusinessUnitPersistable;
import com.citigroup.cgti.c3par.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

@SuppressWarnings( { "unchecked", "unused" })
public class CitiGroupInfoProcess {
	
	private static Logger log = Logger.getLogger(CitiGroupInfoProcess.class);
	
	private String region;
	private Sector sector;
	private BusinessUnit bUnit;
	private CitiHierarchyMaster citiHierMaster;
	private String bUnitIdString;
	private String sectorIdString;
	private String regionIdString;
	private String citiHierMasterIdString;
	private List<BusinessUnit> bUnitList = new ArrayList<BusinessUnit>();
	
	CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public Sector getSector() {
		return sector;
	}
	public void setSector(Sector sector) {
		this.sector = sector;
	}
	public BusinessUnit getbUnit() {
		return bUnit;
	}
	public void setbUnit(BusinessUnit bUnit) {
		this.bUnit = bUnit;
	}
	public String getbUnitIdString() {
		return bUnitIdString;
	}
	public void setbUnitIdString(String bUnitIdString) {
		this.bUnitIdString = bUnitIdString;
	}
	public String getRegionIdString() {
		return regionIdString;
	}
	public void setRegionIdString(String regionIdString) {
		this.regionIdString = regionIdString;
	}
	public String getSectorIdString() {
		return sectorIdString;
	}
	public void setSectorIdString(String sectorIdString) {
		this.sectorIdString = sectorIdString;
	}
	
	public CitiHierarchyMaster getCitiHierMaster() {
		return citiHierMaster;
	}
	
	public void setCitiHierMaster(CitiHierarchyMaster citiHierMaster) {
		this.citiHierMaster = citiHierMaster;
	}
	
	public String getCitiHierMasterIdString() {
		return citiHierMasterIdString;
	}
	public void setCitiHierMasterIdString(String citiHierMasterIdString) {
		this.citiHierMasterIdString = citiHierMasterIdString;
	}
	public List<BusinessUnit> getbUnitList() {
		return bUnitList;
	}
	public void setbUnitList(List<BusinessUnit> bUnitList) {
		this.bUnitList = bUnitList;
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public String addBusinessUnit(BusinessUnit busUnit) throws Exception {
		String result =ccrBeanFactory.getManageBusinessUnitPersistable().addBusinessUnit(busUnit);
		return result;
	}
	
	public void validate(String message) throws Exception {
		log.debug("In validate"+message);
		throw new Exception(message);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public HashMap<String, String> getRegionList() throws Exception {
				
		HashMap<String, String> regMap = new HashMap<String, String>();	
		log.info("In getRegionList CitiGroupInfoForm");
			List<Region> regList = ccrBeanFactory.getManageBusinessUnitPersistable().getRegionList();
			for(Region reg: regList){
				regMap.put(reg.getId().toString(),reg.getName());
			}
			return regMap;
		
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public HashMap<String, String> getSectorList() throws Exception {
		HashMap<String, String> secMap = new HashMap<String, String>();	
		log.info("In getSectorList CitiGroupInfoForm");
			List<Sector> secList = ccrBeanFactory.getManageBusinessUnitPersistable().getSectorList();
			for(Sector sec: secList){
				secMap.put(sec.getId().toString(),sec.getName());
			}
			return secMap;
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List<BusinessUnit> getBusinessUnit(String sector) throws Exception {
		List <BusinessUnit> bUnitList = ccrBeanFactory.getManageBusinessUnitPersistable().getBusinessUnitList(sector);
		return bUnitList;
		
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public String addCitiHierMaster(String region, String sector, String bUnit) throws Exception{
		Region reg = new Region();
		reg.setId(Long.valueOf(region));
		Sector sec = new Sector();
		sec.setId(Long.valueOf(sector));
		BusinessUnit busUnit = new BusinessUnit();
		busUnit.setId(Long.valueOf(bUnit));
		CitiHierarchyMaster citiHierarchyMaster = new CitiHierarchyMaster();
		citiHierarchyMaster.setRegion(reg);
		citiHierarchyMaster.setSector(sec);
		citiHierarchyMaster.setBusinessUnit(busUnit);
		String result = ccrBeanFactory.getManageBusinessUnitPersistable().mapHierarcy(citiHierarchyMaster);
		return result;
	}
	
	
}
