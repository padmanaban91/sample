/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author bs45969
 *
 */
public class FireWallRuleIP extends Base {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private FireWallRule fireWallRule;
    @NotNull(message = "Request ID of the cycle in which the source/destination IP added/edited not assigned")
    private TIRequest updatedTIRequest;
    private TIRequest deletedTIRequest;
    private Integer appCount;

    @NotNull(message = "IP address not avaliable for source/destination IP ")
    @Valid
    private IPAddress ipAddress;
    private String NAT;
    /** The updated_date. */
    private String updated_date_hdn;
    private String resourceType;
    
    private Long objRuleID;

    /**
     * @return the fireWallRule
     */
    public FireWallRule getFireWallRule() {
	return fireWallRule;
    }

    /**
     * @param fireWallRule the fireWallRule to set
     */
    public void setFireWallRule(FireWallRule fireWallRule) {
	this.fireWallRule = fireWallRule;
    }

    /**
     * @return the updatedTIRequest
     */
    public TIRequest getUpdatedTIRequest() {
	return updatedTIRequest;
    }

    /**
     * @param updatedTIRequest the updatedTIRequest to set
     */
    public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
	this.updatedTIRequest = updatedTIRequest;
    }

    /**
     * @return the deletedTIRequest
     */
    public TIRequest getDeletedTIRequest() {
	return deletedTIRequest;
    }

    /**
     * @param deletedTIRequest the deletedTIRequest to set
     */
    public void setDeletedTIRequest(TIRequest deletedTIRequest) {
	this.deletedTIRequest = deletedTIRequest;
    }

    /**
     * @return the ipAddress
     */
    public IPAddress getIpAddress() {
	return ipAddress;
    }

    /**
     * @param ipAddress the ipAddress to set
     */
    public void setIpAddress(IPAddress ipAddress) {
	this.ipAddress = ipAddress;
    }

    /**
     * @return the nAT
     */
    public String getNAT() {
	return NAT;
    }

    /**
     * @param nAT the nAT to set
     */
    public void setNAT(String nAT) {
	NAT = nAT;
    }

	/**
	 * @return the appCount
	 */
	public Integer getAppCount() {
		return appCount;
	}

	/**
	 * @param appCount the appCount to set
	 */
	public void setAppCount(Integer appCount) {
		this.appCount = appCount;
	}

	/**
	 * @return the updated_date_hdn
	 */
	public String getUpdated_date_hdn() {
		return updated_date_hdn;
	}

	/**
	 * @param updatedDateHdn the updated_date_hdn to set
	 */
	public void setUpdated_date_hdn(String updatedDateHdn) {
		updated_date_hdn = updatedDateHdn;
	}

	/**
	 * @return the resourceType
	 */
	public String getResourceType() {
		return resourceType;
	}

	/**
	 * @param resourceType the resourceType to set
	 */
	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	public Long getObjRuleID() {
		return objRuleID;
	}

	public void setObjRuleID(Long objRuleID) {
		this.objRuleID = objRuleID;
	}
    
}
