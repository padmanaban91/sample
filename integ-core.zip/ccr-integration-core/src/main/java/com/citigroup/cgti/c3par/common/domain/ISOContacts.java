/*
 * 
 */
package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * The Class ISOContact.
 */
public class ISOContacts extends Base implements Serializable {

	private String soeID;
	
	private String isDeleted;

	public String getSoeID() {
		return soeID;
	}

	public void setSoeID(String soeID) {
		this.soeID = soeID;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}
	
}
