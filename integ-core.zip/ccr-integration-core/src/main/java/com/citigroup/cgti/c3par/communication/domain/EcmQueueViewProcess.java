package com.citigroup.cgti.c3par.communication.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.communication.domain.soc.persist.EcmQueueViewPersistable;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class EcmQueueViewProcess {
			 
	
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

	
	
	private List<EcmQueue> ecmQueue;
	
	
	private List<Sector> secList;
	
	private List<EcmQueueUsers> ecmQueueUsersList;
	
	
	private Long ecmQueueId;
	
	private String ecmQueueName;
	
	private String ecmDisplayName;
	
	private String[] sectorListValuesArr;
	
	private List<Long> selectedSectors;
	
	private String errorMessage;

	public EcmQueueViewPersistable getEcmQueueViewPersistable() {
		return ccrBeanFactory.getEcmQueueViewPersistable();
	}



	public List<EcmQueue> getEcmQueue() {
		return ecmQueue;
	}


	public void setEcmQueue(List<EcmQueue> ecmQueue) {
		this.ecmQueue = ecmQueue;
	}
	
	
	
	

	public String[] getSectorListValuesArr() {
		return sectorListValuesArr;
	}


	public void setSectorListValuesArr(String[] sectorListValuesArr) {
		this.sectorListValuesArr = sectorListValuesArr;
	}


	public EcmQueueViewProcess(){  
		
	} 
	
	
	
	


	public Long getEcmQueueId() {
		return ecmQueueId;
	}


	public void setEcmQueueId(Long ecmQueueId) {
		this.ecmQueueId = ecmQueueId;
	}


	
		public String getEcmQueueName() {
		return ecmQueueName;
	}


	public void setEcmQueueName(String ecmQueueName) {
		this.ecmQueueName = ecmQueueName;
	}


	public String getEcmDisplayName() {
		return ecmDisplayName;
	}


	public void setEcmDisplayName(String ecmDisplayName) {
		this.ecmDisplayName = ecmDisplayName;
	}


	public List<Sector> getSecList() {
		return secList;
	}


	public void setSecList(List<Sector> secList) {
		this.secList = secList;
	}

	


	public List<EcmQueueUsers> getEcmQueueUsersList() {
		return ecmQueueUsersList;
	}


	public void setEcmQueueUsersList(List<EcmQueueUsers> ecmQueueUsersList) {
		this.ecmQueueUsersList = ecmQueueUsersList;
	}

	
	/**
	 * @return the selectedSectors
	 */
	public List<Long> getSelectedSectors() {
		return selectedSectors;
	}

	/**
	 * @param selectedSectors the selectedSectors to set
	 */
	public void setSelectedSectors(List<Long> selectedSectors) {
		this.selectedSectors = selectedSectors;
	}

	
	public List<EcmQueue>  selectQueueDetails(EcmQueueViewProcess ecmQueueViewProcess) { 
		List<EcmQueue> ecmQueueViewList = ccrBeanFactory.getEcmQueueViewPersistable().selectQueueDetails(this);
		return  ecmQueueViewList;
	}
	
	
	
	public List<Sector>  selectSectorList() throws Exception { 
		List<Sector> secList =ccrBeanFactory.getManageBusinessUnitPersistable().getSectorList();
		return  secList;
	}
	
	
	public List<EcmQueueUsers>  ecmUserRoleList(long ecmqueueId) throws Exception { 
		List<EcmQueueUsers> ecmUserroles = ccrBeanFactory.getEcmQueueViewPersistable().ecmUserRoleList(ecmqueueId);
		return  ecmUserroles;
	}
	
	
	public List<Long>  selectedEcmSector(long ecmqueueId)  throws Exception { 
		List<Long> ecmselectedSectors = ccrBeanFactory.getEcmQueueViewPersistable().selectedEcmSector(ecmqueueId);
		return  ecmselectedSectors;
	}
	 
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public boolean mapEcmUsertoSector(Long sector, String ecmUser,String userId) {
            boolean mapUserSuccess = ccrBeanFactory.getEcmQueueViewPersistable().mapEcmUsertoSector(sector,ecmUser,userId);
            return  mapUserSuccess;
    }

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateEcmQueueViewDetails(EcmQueueViewProcess ecmqueueViewProcess) {
		ccrBeanFactory.getEcmQueueViewPersistable().updateEcmQueueViewDetails(ecmqueueViewProcess);
		 
	}
	 
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
	public boolean checkValidUser(String ssoid){		
		return ccrBeanFactory.getResolveITFieldPersistable().checkValidUser(ssoid);
	}
	 
}
