package com.citigroup.cgti.c3par.domain.accessform;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.Person;
import com.citigroup.cgti.c3par.model.RelationshipEntity;

/*
 * The common Bean for five Access Forms
 * @nc43495
 */
@XmlRootElement
public class AccessFormXsl{

	private static final long serialVersionUID = 1L;

	private Long conID;
	
	private Long version;
	
	private String conName;
	
	private RelationshipDTO relDTO;
	
	/** The requestor. */
    private Person requestor = new Person();

    /** The curr cycle requestor. */
    private Person currCycleRequestor = new Person();

	private ArrayList<Application> applicationDetails;
	
	private String originalBusJus;
	
	/** The business contacts. */
    private ArrayList<Person> businessContacts = new ArrayList();

    /** The application list. */
    private ArrayList applicationList = new ArrayList();

	private String currentBusJus;
	
	private String systemID;
	
	private String SOW;
	
	private String specialInstructions;
	
	private String completionDate;
	
	private String changeNumber;
	
	private Long infomanID;
	
	private String implStatus;
	
	private String cabApprovers;

	private String riskInformation;
	
	private List<FafAccessForm> fwImplDetails;
	
	private List<AAFAccessForm> appsenseAccessformList;
	
	private List<AAFAccessForm> nwList;
	
	private List<AAFAccessForm> userList;
	
	private ArrayList<Application> appsenseApplDetails;
	
	private AppsenseADGroup appsenseADGroup;
	
	private List<PafAccessForm> proxyAccessformList;
	
	private List<String> docDetails;
	
	@XmlElement
	public Long getConID() {
		return conID;
	}

	public void setConID(Long conID) {
		this.conID = conID;
	}
	@XmlElement
	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}
	@XmlElement
	public String getConName() {
		return conName;
	}

	public void setConName(String conName) {
		this.conName = conName;
	}

	@XmlElement
	public ArrayList<Application> getApplicationDetails() {
		return applicationDetails;
	}

	public void setApplicationDetails(ArrayList<Application> applicationDetails) {
		this.applicationDetails = applicationDetails;
	}

	
	@XmlElement
	public String getOriginalBusJus() {
		return originalBusJus;
	}

	public void setOriginalBusJus(String originalBusJus) {
		this.originalBusJus = originalBusJus;
	}

	@XmlElement
	public String getCurrentBusJus() {
		return currentBusJus;
	}

	
	public void setCurrentBusJus(String currentBusJus) {
		this.currentBusJus = currentBusJus;
	}
	@XmlElement
	public String getSystemID() {
		return systemID;
	}

	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}
	@XmlElement
	public String getSOW() {
		return SOW;
	}

	public void setSOW(String sOW) {
		SOW = sOW;
	}

	@XmlElement
	public String getSpecialInstructions() {
		return specialInstructions;
	}

	public void setSpecialInstructions(String specialInstructions) {
		this.specialInstructions = specialInstructions;
	}
	@XmlElement
	public String getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(String completionDate) {
		this.completionDate = completionDate;
	}
	@XmlElement
	public String getChangeNumber() {
		return changeNumber;
	}

	public void setChangeNumber(String changeNumber) {
		this.changeNumber = changeNumber;
	}
	@XmlElement
	public Long getInfomanID() {
		return infomanID;
	}

	public void setInfomanID(Long infomanID) {
		this.infomanID = infomanID;
	}
	@XmlElement
	public String getCabApprovers() {
		return cabApprovers;
	}

	public void setCabApprovers(String cabApprovers) {
		this.cabApprovers = cabApprovers;
	}
	@XmlElement
	public String getImplStatus() {
		return implStatus;
	}

	public void setImplStatus(String implStatus) {
		this.implStatus = implStatus;
	}
	@XmlElement
	public String getRiskInformation() {
		return riskInformation;
	}

	public void setRiskInformation(String riskInformation) {
		this.riskInformation = riskInformation;
	}
	@XmlElement
	public ArrayList<Application> getAppsenseApplDetails() {
		return appsenseApplDetails;
	}

	public void setAppsenseApplDetails(ArrayList<Application> appsenseApplDetails) {
		this.appsenseApplDetails = appsenseApplDetails;
	}

	@XmlElement	
	public List<FafAccessForm> getFwImplDetails() {
		return fwImplDetails;
	}

	public void setFwImplDetails(List<FafAccessForm> fwImplDetails) {
		this.fwImplDetails = fwImplDetails;
	}

	@XmlElement
	public Person getRequestor() {
		return requestor;
	}

	public void setRequestor(Person requestor) {
		this.requestor = requestor;
	}
	@XmlElement
	public Person getCurrCycleRequestor() {
		return currCycleRequestor;
	}

	public void setCurrCycleRequestor(Person currCycleRequestor) {
		this.currCycleRequestor = currCycleRequestor;
	}
	
	@XmlElement
	public ArrayList<Person> getBusinessContacts() {
		return businessContacts;
	}

	public void setBusinessContacts(ArrayList<Person> businessContacts) {
		this.businessContacts = businessContacts;
	}
	@XmlElement
	public ArrayList getApplicationList() {
		return applicationList;
	}

	public void setApplicationList(ArrayList applicationList) {
		this.applicationList = applicationList;
	}
	@XmlElement
	public List<AAFAccessForm> getAppsenseAccessformList() {
		return appsenseAccessformList;
	}

	public void setAppsenseAccessformList(List<AAFAccessForm> appsenseAccessformList) {
		this.appsenseAccessformList = appsenseAccessformList;
	}
	
	
	@XmlElement
	public AppsenseADGroup getAppsenseADGroup() {
		return appsenseADGroup;
	}
	public void setAppsenseADGroup(AppsenseADGroup appsenseADGroup) {
		this.appsenseADGroup = appsenseADGroup;
	}

	@XmlElement
	public RelationshipDTO getRelDTO() {
		return relDTO;
	}

	public void setRelDTO(RelationshipDTO relDTO) {
		this.relDTO = relDTO;
	}

	
	public void setNwList(List<AAFAccessForm> nwList) {
		this.nwList = nwList;
	}
	@XmlElement
	public List<AAFAccessForm> getNwList() {
		return nwList;
	}
	@XmlElement
	public List<AAFAccessForm> getUserList() {
		return userList;
	}

	public void setUserList(List<AAFAccessForm> userList) {
		this.userList = userList;
	}
	public void setProxyAccessformList(List<PafAccessForm> proxyAccessformList) {
		this.proxyAccessformList = proxyAccessformList;
	}
	
	@XmlElement
	public List<PafAccessForm> getProxyAccessformList() {
		return proxyAccessformList;
	}

	public void setDocDetails(List<String> docDetails) {
		this.docDetails = docDetails;
	}

	@XmlElement
	public List<String> getDocDetails() {
		return docDetails;
	}

	
	

}
