

/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright ? 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.dao.lookup;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;


/**
 * The Class GenericLookupLookup.
 */
public class GenericLookupLookup
{

    /** The initialized. */
    private boolean		initialized = false;

    /** The ordered list. */
    private ArrayList 	orderedList = new ArrayList();

    /** The values by id. */
    private HashMap		valuesById = new HashMap();

    /** The values by value1. */
    private HashMap		valuesByValue1 = new HashMap();

    /** The values by value2. */
    private HashMap		valuesByValue2 = new HashMap();

    /** The values by deleted. */
    private HashMap		valuesByDeleted = new HashMap();

    /** The instance. */
    static private GenericLookupLookup instance = null;

    //======================================================================
    /**
     * Gets the single instance of GenericLookupLookup.
     *
     * @return single instance of GenericLookupLookup
     */
    synchronized static public GenericLookupLookup getInstance()
    {
	if (instance == null)
	{
	    instance = new GenericLookupLookup();
	}
	return instance;
    }

    //======================================================================
    /**
     * Gets the single instance of GenericLookupLookup.
     *
     * @param session the session
     * @return single instance of GenericLookupLookup
     * @throws DatabaseException the database exception
     */
    synchronized static public GenericLookupLookup getInstance(DatabaseSession session) throws DatabaseException
    {
	if (instance == null)
	{
	    instance = new GenericLookupLookup();
	    instance.initialize(session);	
	}
	else if(!instance.isInitialized())
	{
	    instance.initialize(session);	
	}
	return instance;
    }

    //======================================================================
    /**
     * Instantiates a new generic lookup lookup.
     */
    private GenericLookupLookup()
    {
	super();
	initialized = false;
    }

    //======================================================================
    /**
     * Initialize.
     *
     * @param session the session
     * @throws DatabaseException the database exception
     */
    synchronized public void initialize(DatabaseSession session) throws DatabaseException
    {
	if (!initialized)
	{
	    GenericLookupDAO dao = new GenericLookupDAO(session);
	    GenericLookupEntity entity = null;
	    Condition condition = new Condition();
	    condition.addOrderByField(GenericLookupDAO.COLUMN_VALUE1);
	    try
	    {
		List list = dao.query(condition, false);
		Iterator it = list.iterator();

		while (it.hasNext())
		{
		    entity = (GenericLookupEntity) it.next();
		    valuesById.put(entity.getId(), entity);
		    valuesByValue1.put(entity.getValue1(), entity);
		    valuesByValue2.put(entity.getValue2(), entity);
		    valuesByDeleted.put(entity.getDeleted(), entity);
		    orderedList.add(entity);
		}
		initialized = true;

		it = list.iterator();
		while (it.hasNext())
		{
		    entity = (GenericLookupEntity) it.next();
		    dao.loadReferences((GenericLookupEntity)entity);
		}
	    }
	    catch (DatabaseException e)
	    {
		throw e;
	    }
	}
    }

    //======================================================================
    /**
     * Reset.
     */
    synchronized public void reset()
    {
	valuesById = new HashMap();
	orderedList = new ArrayList();
	initialized = false;
	valuesByValue1 = new HashMap();
	valuesByValue2 = new HashMap();
	valuesByDeleted = new HashMap();
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param id the id
     * @return the by id
     */
    synchronized public GenericLookupEntity getById(Long id)
    {
	return (GenericLookupEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param session the session
     * @param id the id
     * @return the by id
     * @throws DatabaseException the database exception
     */
    synchronized public GenericLookupEntity getById(DatabaseSession session, Long id) throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (GenericLookupEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by value1.
     *
     * @param v the v
     * @return the by value1
     */
    synchronized public GenericLookupEntity getByValue1(String v)
    {
	return (GenericLookupEntity) valuesByValue1.get(v);
    }

    //======================================================================
    /**
     * Gets the by value1.
     *
     * @param session the session
     * @param v the v
     * @return the by value1
     * @throws DatabaseException the database exception
     */
    synchronized public GenericLookupEntity getByValue1(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (GenericLookupEntity) valuesByValue1.get(v);
    }
    //======================================================================
    /**
     * Gets the by value2.
     *
     * @param v the v
     * @return the by value2
     */
    synchronized public GenericLookupEntity getByValue2(String v)
    {
	return (GenericLookupEntity) valuesByValue2.get(v);
    }

    //======================================================================
    /**
     * Gets the by value2.
     *
     * @param session the session
     * @param v the v
     * @return the by value2
     * @throws DatabaseException the database exception
     */
    synchronized public GenericLookupEntity getByValue2(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (GenericLookupEntity) valuesByValue2.get(v);
    }
    //======================================================================
    /**
     * Gets the by deleted.
     *
     * @param v the v
     * @return the by deleted
     */
    synchronized public GenericLookupEntity getByDeleted(Boolean v)
    {
	return (GenericLookupEntity) valuesByDeleted.get(v);
    }

    //======================================================================
    /**
     * Gets the by deleted.
     *
     * @param session the session
     * @param v the v
     * @return the by deleted
     * @throws DatabaseException the database exception
     */
    synchronized public GenericLookupEntity getByDeleted(DatabaseSession session, Boolean v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (GenericLookupEntity) valuesByDeleted.get(v);
    }

    //======================================================================
    /**
     * Gets the all.
     *
     * @return the all
     */
    synchronized public ArrayList getAll()
    {
	return orderedList;
    }

    //======================================================================
    /**
     * Checks if is initialized.
     *
     * @return true, if is initialized
     */
    synchronized public boolean isInitialized()
    {
	return initialized;
    }
}
