/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.Application;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author ne36745
 *
 */
public class IPDetailsRequest {
  
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

    //properties used for search
    private long ruleId;
    private long tiProcess;
    private long tiRequest;
    private long updatedTIRequest;
    private long deletedTIRequest;
    private String filterText;
    private String filterType;
    //properties used for returning result
    //@Valid
    //properties used for pagination
    private int rowCount;
    private int offset;
    private int limit;
    private int pageNo;
    private String field;
    private int totalPages;
    /** The is select all. */
    private boolean isSelectAll;
    private String isIpReg;

    private IPAddress ipAddress;
    private List<FireWallRuleIP> ipAddressList;
    
    //Application related
    private Application application;
    private List<Application> applicationList;
    private List<GenericLookup> deviceTypeList;
	private String biso_VA_YES_NO_NR;
	private String biso_VA_No ;
	private String biso_VA_Yes ;
	private String biso_VA_Date;
	private String biso_VA_NR_Comments ;
	
	private Long selectedRuleId;
	private Long sourceRuleId;
	private List<Long> selectedIPs;
	private List<FirewallRuleApplication> firewallRuleAppList;
	
	private PersonalObject personalObject;
	
	private List<PersonalObjectIP> personalObjectIPs;
	
	private List<PersonalObjectPort> personalObjectPorts;

    /**
     * @return the ruleId
     */
    public long getRuleId() {
	return ruleId;
    }

    /**
     * @param ruleId the ruleId to set
     */
    public void setRuleId(long ruleId) {
	this.ruleId = ruleId;
    }

    /**
     * @return the tiProcess
     */
    public long getTiProcess() {
	return tiProcess;
    }

    /**
     * @param tiProcess the tiProcess to set
     */
    public void setTiProcess(long tiProcess) {
	this.tiProcess = tiProcess;
    }

    /**
     * @return the tiRequest
     */
    public long getTiRequest() {
	return tiRequest;
    }

    /**
     * @param tiRequest the tiRequest to set
     */
    public void setTiRequest(long tiRequest) {
	this.tiRequest = tiRequest;
    }

    /**
     * @return the updatedTIRequest
     */
    public long getUpdatedTIRequest() {
	return updatedTIRequest;
    }

    /**
     * @param updatedTIRequest the updatedTIRequest to set
     */
    public void setUpdatedTIRequest(long updatedTIRequest) {
	this.updatedTIRequest = updatedTIRequest;
    }

    /**
     * @return the deletedTIRequest
     */
    public long getDeletedTIRequest() {
	return deletedTIRequest;
    }

    /**
     * @param deletedTIRequest the deletedTIRequest to set
     */
    public void setDeletedTIRequest(long deletedTIRequest) {
	this.deletedTIRequest = deletedTIRequest;
    }


    /**
     * @return the rowCount
     */
    public int getRowCount() {
	return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
	this.rowCount = rowCount;
    }

    /**
     * @return the offset
     */
    public int getOffset() {
	return offset;
    }

    /**
     * @param offset the offset to set
     */
    public void setOffset(int offset) {
	this.offset = offset;
    }

    /**
     * @return the limit
     */
    public int getLimit() {
	return limit;
    }

    /**
     * @param limit the limit to set
     */
    public void setLimit(int limit) {
	this.limit = limit;
    }


    /**
     * @return the filterText
     */
    public String getFilterText() {
	return filterText;
    }

    /**
     * @param filterText the filterText to set
     */
    public void setFilterText(String filterText) {
	this.filterText = filterText;
    }


    /**
	 * @return the ipAddressList
	 */
	public List<FireWallRuleIP> getIpAddressList() {
		return ipAddressList;
	}

	/**
	 * @param ipAddressList the ipAddressList to set
	 */
	public void setIpAddressList(List<FireWallRuleIP> ipAddressList) {
		this.ipAddressList = ipAddressList;
	}
	
	/**
	 * @return the field
	 */
	public String getField() {
		return field;
	}

	/**
	 * @param field the field to set
	 */
	public void setField(String field) {
		this.field = field;
	}

	/**
	 * @return the pageNo
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * @param pageNo the pageNo to set
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	
	/**
	 * @return the totalPages
	 */
	public int getTotalPages() {
		return totalPages;
	}

	/**
	 * @param totalPages the totalPages to set
	 */
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	/**
	 * @return the application
	 */
	public Application getApplication() {
		return application;
	}

	/**
	 * @param application the application to set
	 */
	public void setApplication(Application application) {
		this.application = application;
	}

	/**
	 * @return the applicationList
	 */
	public List<Application> getApplicationList() {
		return applicationList;
	}

	/**
	 * @param applicationList the applicationList to set
	 */
	public void setApplicationList(List<Application> applicationList) {
		this.applicationList = applicationList;
	}
	
	/**
	 * @return the deviceTypeList
	 */
	public List<GenericLookup> getDeviceTypeList() {
		return deviceTypeList;
	}

	/**
	 * @param deviceTypeList the deviceTypeList to set
	 */
	public void setDeviceTypeList(List<GenericLookup> deviceTypeList) {
		this.deviceTypeList = deviceTypeList;
	}
	
	/**
	 * @return the biso_VA_YES_NO_NR
	 */
	public String getBiso_VA_YES_NO_NR() {
		return biso_VA_YES_NO_NR;
	}

	/**
	 * @param bisoVAYESNONR the biso_VA_YES_NO_NR to set
	 */
	public void setBiso_VA_YES_NO_NR(String bisoVAYESNONR) {
		biso_VA_YES_NO_NR = bisoVAYESNONR;
	}

	/**
	 * @return the biso_VA_No
	 */
	public String getBiso_VA_No() {
		return biso_VA_No;
	}

	/**
	 * @param bisoVANo the biso_VA_No to set
	 */
	public void setBiso_VA_No(String bisoVANo) {
		biso_VA_No = bisoVANo;
	}

	/**
	 * @return the biso_VA_Yes
	 */
	public String getBiso_VA_Yes() {
		return biso_VA_Yes;
	}

	/**
	 * @param bisoVAYes the biso_VA_Yes to set
	 */
	public void setBiso_VA_Yes(String bisoVAYes) {
		biso_VA_Yes = bisoVAYes;
	}

	/**
	 * @return the biso_VA_Date
	 */
	public String getBiso_VA_Date() {
		return biso_VA_Date;
	}

	/**
	 * @param bisoVADate the biso_VA_Date to set
	 */
	public void setBiso_VA_Date(String bisoVADate) {
		biso_VA_Date = bisoVADate;
	}

	/**
	 * @return the biso_VA_NR_Comments
	 */
	public String getBiso_VA_NR_Comments() {
		return biso_VA_NR_Comments;
	}

	/**
	 * @param bisoVANRComments the biso_VA_NR_Comments to set
	 */
	public void setBiso_VA_NR_Comments(String bisoVANRComments) {
		biso_VA_NR_Comments = bisoVANRComments;
	}
	
	/**
	 * @return the ipAddress
	 */
	public IPAddress getIpAddress() {
		return ipAddress;
	}

	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(IPAddress ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	/**
	 * @return the selectedIPs
	 */
	public List<Long> getSelectedIPs() {
		return selectedIPs;
	}
	
	/**
	 * @return the filterType
	 */
	public String getFilterType() {
		return filterType;
	}

	/**
	 * @param filterType the filterType to set
	 */
	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}

	/**
	 * @param selectedIPs the selectedIPs to set
	 */
	public void setSelectedIPs(List<Long> selectedIPs) {
		this.selectedIPs = selectedIPs;
	}
	
	/**
	 * @return the selectedRuleId
	 */
	public Long getSelectedRuleId() {
		return selectedRuleId;
	}

	/**
	 * @param selectedRuleId the selectedRuleId to set
	 */
	public void setSelectedRuleId(Long selectedRuleId) {
		this.selectedRuleId = selectedRuleId;
	}

	/**
	 * @return the isSelectAll
	 */
	public boolean isSelectAll() {
		return isSelectAll;
	}

	/**
	 * @param isSelectAll the isSelectAll to set
	 */
	public void setSelectAll(boolean isSelectAll) {
		this.isSelectAll = isSelectAll;
	}

	/**
	 * @return the firewallRuleAppList
	 */
	public List<FirewallRuleApplication> getFirewallRuleAppList() {
		return firewallRuleAppList;
	}

	/**
	 * @param firewallRuleAppList the firewallRuleAppList to set
	 */
	public void setFirewallRuleAppList(
			List<FirewallRuleApplication> firewallRuleAppList) {
		this.firewallRuleAppList = firewallRuleAppList;
	}
	
	/**
	 * @return the personalObject
	 */
	public PersonalObject getPersonalObject() {
		return personalObject;
	}

	/**
	 * @param personalObject the personalObject to set
	 */
	public void setPersonalObject(PersonalObject personalObject) {
		this.personalObject = personalObject;
	}

	/**
	 * @return the personalObjectIPs
	 */
	public List<PersonalObjectIP> getPersonalObjectIPs() {
		return personalObjectIPs;
	}

	/**
	 * @param personalObjectIPs the personalObjectIPs to set
	 */
	public void setPersonalObjectIPs(List<PersonalObjectIP> personalObjectIPs) {
		this.personalObjectIPs = personalObjectIPs;
	}

	/**
	 * @return the personalObjectPorts
	 */
	public List<PersonalObjectPort> getPersonalObjectPorts() {
		return personalObjectPorts;
	}

	/**
	 * @param personalObjectPorts the personalObjectPorts to set
	 */
	public void setPersonalObjectPorts(List<PersonalObjectPort> personalObjectPorts) {
		this.personalObjectPorts = personalObjectPorts;
	}
	
	/**
	 * @return the sourceRuleId
	 */
	public Long getSourceRuleId() {
		return sourceRuleId;
	}

	/**
	 * @param sourceRuleId the sourceRuleId to set
	 */
	public void setSourceRuleId(Long sourceRuleId) {
		this.sourceRuleId = sourceRuleId;
	}

	
    public List<FireWallRuleIP> loadIPDetails() {
	return ccrBeanFactory.getIpDetailsPersistable().loadIPDetails(this);
	}

	
    public List<GenericLookup> getDeviceTypes() {
	return ccrBeanFactory.getCommonServicePersistable().getDeviceTypes();
    }
	
	
    public List<FirewallRuleApplication> getFirewallRuleApplications() {
	return ccrBeanFactory.getIpDetailsPersistable().getFirewallRuleApplications(this);
    }
	
	
    public List<FireWallRule> getFirewallRulesByIPId() {
		return ccrBeanFactory.getIpDetailsPersistable().getFirewallRulesByIPId(this);
    }
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void saveFirewallRuleApplications() {
		ccrBeanFactory.getIpDetailsPersistable().saveFirewallRuleApplications(this);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void editFirewallRuleApplications(Application app,List selectedIPs,List selectedRules) {
		ccrBeanFactory.getIpDetailsPersistable().editFirewallRuleApplications(app,selectedIPs,selectedRules);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public Application checkApplicationExists(Application app){
		return ccrBeanFactory.getIpDetailsPersistable().checkApplicationExists(app);
	}
	
	
	public FirewallRuleApplication getFirewallRuleApplication(Long id) {
		return ccrBeanFactory.getIpDetailsPersistable().getFirewallRuleApplication(id);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteFirewallRuleApplications() {
		ccrBeanFactory.getIpDetailsPersistable().deleteFirewallRuleApplications(this);
	}
	
	
	public List<IPAddress> getIPsByFirewallRuleId() {
		return ccrBeanFactory.getIpDetailsPersistable().getIPsByFirewallRuleId(this);
	}

	public void setIsIpReg(String isIpReg) {
		this.isIpReg = isIpReg;
	}

	public String getIsIpReg() {
		return isIpReg;
	}
}
