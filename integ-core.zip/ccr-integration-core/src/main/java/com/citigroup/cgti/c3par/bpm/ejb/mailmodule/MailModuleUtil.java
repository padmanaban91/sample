package com.citigroup.cgti.c3par.bpm.ejb.mailmodule;

import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.ELEMENT_INFO;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.ELEMENT_ROW;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.ELEMENT_SQLPARAM;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMAIL_ADDRESS_SEPERATOR;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_ADD_BUS_TESTING;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_CLASH_REQUEST;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_DESC_BUS_PERSPECTIVE;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_DPT_OWNER_PROCESS;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_GRP_RAISING_RFC;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_IMPL_BAU_TIMELINES;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_MAIl_TEMPLATE_FILE_NAME;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_MGR_NAME;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_RISK_UNPLANNED_CHANGE;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_STD_CHANGE_CYCLE;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.EMER_TESTING_PLAN_CONT_PERSON;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.IP_TEMPLATE;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.PORT_TEMPLATE;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.ROLE_BUS_OWNER;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.ROLE_PC;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.TEMPLATE;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.TEMPLATE_FILE_LOC;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.TEMPLATE_VAR_PATTERN_REGEX;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.PROXY_CONNECTION_DL;

import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sql.DataSource;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.citigroup.cgti.c3par.bpm.ejb.domain.C3PARUserDTO;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.BaseMailVO;
import com.citigroup.cgti.c3par.domain.C3PARMailMessage;
import com.citigroup.cgti.c3par.domain.C3PARUser;
import com.citigroup.cgti.c3par.domain.InputMailVO;
import com.citigroup.cgti.c3par.domain.MailMsgDisplayInfo;
import com.citigroup.cgti.c3par.domain.MailMsgDisplayRow;
import com.citigroup.cgti.c3par.domain.MailTemplates;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.domain.TargetContactEmail;
import com.citigroup.cgti.c3par.lookup.C3parUsersLookup;
import com.citigroup.cgti.c3par.model.C3parUserRoleXrefEntity;
import com.citigroup.cgti.c3par.model.C3parUsersEntity;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;


/**
 * The Class MailModuleUtil.
 */
@SuppressWarnings({"unchecked", "unused" })
public class MailModuleUtil {

	/** The log. */
	private static Logger log = Logger.getLogger(MailModuleUtil.class);

	private DataSource  dataSource;
	
	private JdbcTemplate jdbcTemplate;
	

	Set<String> doNotSendEmailList = new HashSet();
     
	 	 
	 /**
	 * Gets the fW mgmt region email.
	 *
	 * @param connectionRequestId the connection request id
	 * @param testMode the test mode
	 * @return the fW mgmt region email
	 */
	// JDBCTemplate Refactored Change
	public String getFWMgmtRegionEmail(String connectionRequestId,String testMode) {
			
		log.debug("MailModule:MailModuleUtil:getFWMgmtRegionEmail:: Entered");
		String sql = "select distinct cfmr.operation_analyst_email,cfmr.mgt_region from ti_request tr, CON_FW_POLICY_XREF cfpx, con_fw_policy_master cfpm, con_fw_mgmt_region cfmr where tr.process_id="
				+ connectionRequestId
				+ " and tr.process_id = cfpx.connection_request_id and cfpx.firewall_policy_id=cfpm.id and cfpm.fw_mgmt_region_id=cfmr.id";

		Map data = new HashMap(); 
		String ownerEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getFWMgmtRegionEmail:: SQL::"	+ sql);
		try {
			data = runQuery(sql, 2, "SELECT", false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && !data.isEmpty()) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && !dataList.isEmpty()) {
					if ("true".equalsIgnoreCase(testMode)){
						ownerEmail = (String) dataList.get(1)
								+ EMAIL_ADDRESS_SEPERATOR;
						break;
					} else {
						ownerEmail = (String) dataList.get(0)
								+ EMAIL_ADDRESS_SEPERATOR;
						break;
					}
				}
			}
		} else{
			ownerEmail = getRoleEmail(ActivityData.ROLE_OA, testMode);
		}
		log.debug("MailModule:MailModuleUtil:getFWMgmtRegionEmail:: Exited");
		return ownerEmail;
	}

	 
	
	
	/**
	 * Gets the all version role email.
	 *
	 * @param connectionRequestId the connection request id
	 * @param testMode the test mode
	 * @return the all version role email
	 */
	// JDBCTemplate Refactored Change
	public String getAllVersionRoleEmail(String connectionRequestId, String userRole,String testMode) {
		log.debug("MailModule:MailModuleUtil:getAllVersionRoleEmail:: Entered");

		String sql = "select distinct cc.email,cc.sso_id,cc.FIRST_NAME,cc.LAST_NAME from con_req_citi_contact_xref crcrx,citi_contact cc,role rl,ti_request tir,ti_request_planning_xref trpx "
				+" where trpx.planning_id=crcrx.request_id and trpx.ti_request_id=tir.id and cc.id=crcrx.citi_contact_id and tir.process_id = "
				+ connectionRequestId
				+ " and rl.id=crcrx.role_id and crcrx.notify_contact in ('Y','N') and crcrx.role_id = rl.id "
				+" and rl.name = '" + userRole + "'";
		String non3rdPartysql = "select distinct cc.email,cc.sso_id,cc.FIRST_NAME,cc.LAST_NAME from CON_REQ_CIT_RQCON_XREF crcrx,citi_contact cc,role rl,ti_request tir,ti_request_planning_xref trpx "
			+" where trpx.planning_id=crcrx.request_id and trpx.ti_request_id=tir.id and cc.id=crcrx.citi_contact_id and tir.process_id = "
			+ connectionRequestId
			+ " and rl.id=crcrx.role_id and crcrx.notify_contact in ('Y','N') and crcrx.role_id = rl.id "
			+" and rl.name = '" + userRole + "'";
		String finalsql = sql + " union " + non3rdPartysql;
		Map data = new HashMap();
		String userRoleEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getAllVersionRoleEmail:: SQL::"
				+ finalsql);
		try {
			data = runQuery(finalsql, 4, "SELECT",  false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && !data.isEmpty()) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && !dataList.isEmpty()) {
					if("".equals(userRoleEmail)){
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						}else if("names".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(2) + " " +(String) dataList.get(3)
									+ " , ";
						}else {
							userRoleEmail = (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					} else {
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						}else if("names".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(2) + " " +(String) dataList.get(3)
									+ " , ";
						} else {
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There is no contact specified with Role \"" + userRole
					+ "\" in the connection id " + connectionRequestId);
		}
		
		log.debug("MailModule:MailModuleUtil:getAllVersionRoleEmail:: Exited");
		return userRoleEmail;
	}

	 
	
	
	public String getManagerEmail(String connectionRequestId, String userRole,String testMode) {
			
		log.debug("getManagerEmail :: Entered");

		
		 String sql = "select distinct cc.SUPERVISOR_EMAIL,cc.SUPERVISOR_GEID from con_req_citi_contact_xref crcrx,citi_contact cc,role rl,ti_request tir,ti_request_planning_xref trpx "
		        +" where trpx.planning_id=crcrx.request_id and trpx.ti_request_id=tir.id and tir.id = (select max(id) from ti_request where process_id = "
		        + connectionRequestId
		        + " ) and cc.id=crcrx.citi_contact_id and tir.process_id = "
		        + connectionRequestId
		        + " and rl.id=crcrx.role_id and crcrx.notify_contact in ('Y','N') and crcrx.role_id = rl.id and crcrx.notify_contact = 'Y' "
		        +" and rl.name = '" + userRole + "'"; 

		   String non3rdPartysql = "select distinct cc.SUPERVISOR_EMAIL,cc.SUPERVISOR_GEID from CON_REQ_CIT_RQCON_XREF crcrx,citi_contact cc,role rl,ti_request tir,ti_request_planning_xref trpx "
		        +" where trpx.planning_id=crcrx.request_id and trpx.ti_request_id=tir.id and tir.id = (select max(id) from ti_request where process_id = "
		        + connectionRequestId
		        + " ) and cc.id=crcrx.citi_contact_id and tir.process_id = "
		        + connectionRequestId
		        + " and rl.id=crcrx.role_id and crcrx.notify_contact in ('Y','N') and crcrx.role_id = rl.id and crcrx.notify_contact = 'Y' "
		        +" and rl.name = '" + userRole + "'"; 

		 
		String finalsql = sql + " union " + non3rdPartysql;
		Map data = new HashMap();
		String userRoleEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getAllVersionRoleEmail:: SQL:: " + finalsql);
				
		try {
			data = runQuery(finalsql, 2, "SELECT",  false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && !data.isEmpty()) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if(dataList != null && !dataList.isEmpty()) {
					if("".equals(userRoleEmail)){
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(1) + EMAIL_ADDRESS_SEPERATOR;
						}else{
							userRoleEmail = (String) dataList.get(0) + EMAIL_ADDRESS_SEPERATOR;
						}
					} else{
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail + (String) dataList.get(1) + EMAIL_ADDRESS_SEPERATOR;
						}else{
							userRoleEmail = userRoleEmail + (String) dataList.get(0) + EMAIL_ADDRESS_SEPERATOR;
						}
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There is no contact specified with Role \"" + userRole
					+ "\" in the connection id " + connectionRequestId);
		}
		log.debug("MailModule:MailModuleUtil:getAllVersionRoleEmail:: Exited");
		return userRoleEmail;
	}

	public String getManagerName(String connectionRequestId, String userRole,
			String testMode) {

		log.debug("getManagerEmail :: Entered");

		String sql = "select distinct cc.SUPERVISOR_FIRST_NAME,cc.SUPERVISOR_LAST_NAME from con_req_citi_contact_xref crcrx,citi_contact cc,role rl,ti_request tir,ti_request_planning_xref trpx "
				+ " where trpx.planning_id=crcrx.request_id and trpx.ti_request_id=tir.id and tir.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId
				+ " ) and cc.id=crcrx.citi_contact_id and cc.id not in (select CITI_CONTACT_ID from DO_NOT_SEND_LIST where is_deleted !='Y' and CITI_CONTACT_ID is not null) and tir.process_id = "
				+ connectionRequestId
				+ " and rl.id=crcrx.role_id and crcrx.notify_contact in ('Y','N') and crcrx.role_id = rl.id and crcrx.notify_contact = 'Y' "
				+ " and rl.name = '" + userRole + "'";

		String non3rdPartysql = "select distinct cc.SUPERVISOR_FIRST_NAME,cc.SUPERVISOR_LAST_NAME from CON_REQ_CIT_RQCON_XREF crcrx,citi_contact cc,role rl,ti_request tir,ti_request_planning_xref trpx "
				+ " where trpx.planning_id=crcrx.request_id and trpx.ti_request_id=tir.id and tir.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId
				+ " ) and cc.id=crcrx.citi_contact_id and cc.id  not in (select CITI_CONTACT_ID from DO_NOT_SEND_LIST where is_deleted !='Y' and CITI_CONTACT_ID is not null) and tir.process_id = "
				+ connectionRequestId
				+ " and rl.id=crcrx.role_id and crcrx.notify_contact in ('Y','N') and crcrx.role_id = rl.id and crcrx.notify_contact = 'Y' "
				+ " and rl.name = '" + userRole + "'";

		String finalsql = sql + " union " + non3rdPartysql;
		Map data = new HashMap();
		String userRoleEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getAllVersionRoleEmail:: SQL:: "
				+ finalsql);

		try {
			data = runQuery(finalsql, 2, "SELECT", false);
		} catch (Exception e) {
			log.error(e, e);
		}
		int counter = 1;
		if (data != null && !data.isEmpty()) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && !dataList.isEmpty()) {
					if ("".equals(userRoleEmail)) {
						userRoleEmail = (String) dataList.get(0) + " "
								+ (String) dataList.get(1)
								+ EMAIL_ADDRESS_SEPERATOR;

					} else {

						userRoleEmail = userRoleEmail
								+ (String) dataList.get(0) + " "
								+ (String) dataList.get(1)
								+ EMAIL_ADDRESS_SEPERATOR;

					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There is no contact specified with Role \"" + userRole
					+ "\" in the connection id " + connectionRequestId);
		}
		log.debug("MailModule:MailModuleUtil:getAllVersionRoleEmail:: Exited");
		return userRoleEmail;
	}

	/**
	 * Gets the user role email.
	 *
	 * @param connectionRequestId the connection request id
	 * @param testMode the test mode
	 * @return the user role email
	 */
	public String getUserRoleEmail(String connectionRequestId,String testMode) {
			
		log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: Entered");
		// String sql =
		// "select distinct cc.EMAIL,cc.SSO_ID from con_req_citi_contact_xref ccx,role rr,citi_contact cc where ccx.request_id = "+connectionRequestId+" and ccx.role_id=rr.id and rr.name = '"+userRole+"' and ccx.citi_contact_id = cc.id"
		// ;
		String sql = "select distinct cc.EMAIL,cc.SSO_ID from ti_request_planning_xref trpx, ti_request tr, con_req_citi_contact_xref crccx,planning p,citi_contact cc,role rr where tr.process_id = "
				+ connectionRequestId
				+ " and trpx.ti_request_id = tr.id and tr.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId
				+ " ) and trpx.planning_id = p.id and crccx.request_id = p.id and crccx.citi_contact_id = cc.id and crccx.role_id=rr.id and crccx.notify_contact = 'Y' ";
		String non3rdPartysql = "select distinct cc.EMAIL,cc.SSO_ID from ti_request_planning_xref trpx, ti_request tr, CON_REQ_CIT_RQCON_XREF crcrx,planning p,citi_contact cc,role rr where tr.process_id = "
				+ connectionRequestId
				+ " and trpx.ti_request_id = tr.id and tr.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId
				+ " ) and trpx.planning_id = p.id and crcrx.request_id = p.id and crcrx.citi_contact_id = cc.id and crcrx.role_id=rr.id and crcrx.notify_contact = 'Y' ";
		String ipsql = "select distinct cc.EMAIL,cc.SSO_ID from c3par_process_role_xref cprx, ti_process tp, role rr, citi_contact cc where tp.id ="
				+ connectionRequestId
				+ " and tp.process_type_id=2 and tp.id=cprx.process_id and cprx.role_id=rr.id "
				+ " and cprx.citi_contact_id=cc.id and cprx.is_active = 'Y'";
		/*
		 * select distinct cc.EMAIL,cc.SSO_ID from c3par_process_role_xref cprx,
		 * ti_process tp,ti_request tr, role rr, citi_contact cc where tr.id =
		 * 2457 and tp.id=tr.process_id and tp.process_type_id=2 and
		 * tp.id=cprx.process_id and cprx.role_id=rr.id and rr.name = 'DESIGN
		 * ENGINEER' and cprx.citi_contact_id=cc.id
		*/
		String finalsql = sql + " union " + non3rdPartysql + " union " + ipsql;
		Map data = new HashMap();
		String userRoleEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: SQL::" + finalsql);
		try {
			data = runQuery(finalsql, 2, "SELECT",  false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if("".equals(userRoleEmail)){
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(1) + EMAIL_ADDRESS_SEPERATOR;
									
						} else {
							userRoleEmail = (String) dataList.get(0) + EMAIL_ADDRESS_SEPERATOR;
									
						}
					} else {
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail + (String) dataList.get(1) + EMAIL_ADDRESS_SEPERATOR;
						} else {
							userRoleEmail = userRoleEmail 	+ (String) dataList.get(0) 	+ EMAIL_ADDRESS_SEPERATOR;
						}
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There is no contact specified with Role \""
					+ "\" in the connection id " + connectionRequestId);
		}
		log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: Exited");
		return userRoleEmail;
	}
	
	
public String getUserRoleEmailCSI(String connectionRequestId, String userRole,String testMode) {
		
		log.debug("MailModule:MailModuleUtil:getUserRoleEmailCSI:: Entered");
		// String sql =
		// "select distinct cc.EMAIL,cc.SSO_ID from con_req_citi_contact_xref ccx,role rr,citi_contact cc where ccx.request_id = "+connectionRequestId+" and ccx.role_id=rr.id and rr.name = '"+userRole+"' and ccx.citi_contact_id = cc.id"
		// ;
		String sql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from ti_request_planning_xref trpx, ti_request tr, con_req_citi_contact_xref crccx,planning p,citi_contact cc,role rr where tr.process_id = "
				+ connectionRequestId
				+ " and trpx.ti_request_id = tr.id and tr.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId
				+ " ) and trpx.planning_id = p.id and crccx.request_id = p.id and crccx.citi_contact_id = cc.id and crccx.role_id=rr.id and crccx.notify_contact = 'Y' and rr.name = '"
				+ userRole + "' and cc.id not in (select CITI_CONTACT_ID from DO_NOT_SEND_LIST where is_deleted !='Y' and CITI_CONTACT_ID is not null)";
		String non3rdPartysql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from ti_request_planning_xref trpx, ti_request tr, CON_REQ_CIT_RQCON_XREF crcrx,planning p,citi_contact cc,role rr where tr.process_id = "
				+ connectionRequestId
				+ " and trpx.ti_request_id = tr.id and tr.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId
				+ " ) and trpx.planning_id = p.id and crcrx.request_id = p.id and crcrx.citi_contact_id = cc.id and crcrx.role_id=rr.id and crcrx.notify_contact = 'Y' and rr.name = '"
				+ userRole + "' and cc.id not in (select CITI_CONTACT_ID from DO_NOT_SEND_LIST where is_deleted !='Y' and CITI_CONTACT_ID is not null)";
		String ipsql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from c3par_process_role_xref cprx, ti_process tp, role rr, citi_contact cc where tp.id ="
				+ connectionRequestId
				+ " and tp.process_type_id=2 and tp.id=cprx.process_id and cprx.role_id=rr.id and rr.name = '"
				+ userRole
				+ "' and cprx.citi_contact_id=cc.id and cprx.is_active = 'Y' and cc.id not in (select CITI_CONTACT_ID from DO_NOT_SEND_LIST where is_deleted !='Y' and CITI_CONTACT_ID is not null)";
		/*
		 * select distinct cc.EMAIL,cc.SSO_ID from c3par_process_role_xref cprx,
		 * ti_process tp,ti_request tr, role rr, citi_contact cc where tr.id =
		 * 2457 and tp.id=tr.process_id and tp.process_type_id=2 and
		 * tp.id=cprx.process_id and cprx.role_id=rr.id and rr.name = 'DESIGN
		 * ENGINEER' and cprx.citi_contact_id=cc.id
		*/
		String finalsql = sql + " union " + non3rdPartysql + " union " + ipsql;
		Map data = new HashMap();
		String userRoleEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: SQL::"
				+ finalsql);
		try {
			data = runQuery(finalsql, 4, "SELECT",  false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if("".equals(userRoleEmail)){
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						}else if("names".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(2) + " " +(String) dataList.get(3)
									+ " , ";
						} else {
							userRoleEmail = (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					} else {
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						}else if("names".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(2) + " " +(String) dataList.get(3)
									+ " , ";
						} else {
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There is no contact specified with Role \"" + userRole
					+ "\" in the connection id " + connectionRequestId);
		}
		log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: Exited");
		return userRoleEmail;
	}
	
 
	
	// JDBCTemplate Refactored 
	public List<String> getUsrRleEmailPrjInfo(String connectionRequestId, String userRole,String testMode ){
		log.debug("MailModule:MailModuleUtil:getUsrRleEmailPrjInfo:: Entered");
		List<String> info = new ArrayList<String>();
		// String sql =
		// "select distinct cc.EMAIL,cc.SSO_ID from con_req_citi_contact_xref ccx,role rr,citi_contact cc where ccx.request_id = "+connectionRequestId+" and ccx.role_id=rr.id and rr.name = '"+userRole+"' and ccx.citi_contact_id = cc.id"
		// ;
		String sql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from ti_request_planning_xref trpx, ti_request tr, con_req_citi_contact_xref crccx,planning p,citi_contact cc,role rr where tr.process_id = "
				+ connectionRequestId
				+ " and trpx.ti_request_id = tr.id and tr.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId
				+ " ) and trpx.planning_id = p.id and crccx.request_id = p.id and crccx.citi_contact_id = cc.id and crccx.role_id=rr.id and crccx.notify_contact = 'Y' and rr.name = '"
				+ userRole + "'";
		String non3rdPartysql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from ti_request_planning_xref trpx, ti_request tr, CON_REQ_CIT_RQCON_XREF crcrx,planning p,citi_contact cc,role rr where tr.process_id = "
				+ connectionRequestId
				+ " and trpx.ti_request_id = tr.id and tr.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId
				+ " ) and trpx.planning_id = p.id and crcrx.request_id = p.id and crcrx.citi_contact_id = cc.id and crcrx.role_id=rr.id and crcrx.notify_contact = 'Y' and rr.name = '"
				+ userRole + "'";
		String ipsql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from c3par_process_role_xref cprx, ti_process tp, role rr, citi_contact cc where tp.id ="
				+ connectionRequestId
				+ " and tp.process_type_id=2 and tp.id=cprx.process_id and cprx.role_id=rr.id and rr.name = '"
				+ userRole
				+ "' and cprx.citi_contact_id=cc.id and cprx.is_active = 'Y'";
		/*
		 * select distinct cc.EMAIL,cc.SSO_ID from c3par_process_role_xref cprx,
		 * ti_process tp,ti_request tr, role rr, citi_contact cc where tr.id =
		 * 2457 and tp.id=tr.process_id and tp.process_type_id=2 and
		 * tp.id=cprx.process_id and cprx.role_id=rr.id and rr.name = 'DESIGN
		 * ENGINEER' and cprx.citi_contact_id=cc.id
		*/
		String finalsql = sql + " union " + non3rdPartysql + " union " + ipsql;
		Map data = new HashMap();
		String userRoleEmail = "";
		String projectCoordName = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: SQL:: "+ finalsql);
				
		try {
			data = runQuery(finalsql, 4, "SELECT",   false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if("".equals(userRoleEmail)){
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(1) + EMAIL_ADDRESS_SEPERATOR;
									
						} else {
							userRoleEmail = (String) dataList.get(0) + EMAIL_ADDRESS_SEPERATOR;
									
						}
					} else {
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail + (String) dataList.get(1) + EMAIL_ADDRESS_SEPERATOR;
									
									
						} else {
							userRoleEmail = userRoleEmail + (String) dataList.get(0) + EMAIL_ADDRESS_SEPERATOR;
									
									
						}
					}
					if(userRole.equalsIgnoreCase("PROJECT COORDINATOR")){
						if(counter==data.size()){
							projectCoordName +=dataList.get(2)+" "+dataList.get(3)+" ";
						} else {
							projectCoordName +=dataList.get(2)+" "+dataList.get(3)+" , ";
						}
							
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There is no contact specified with Role \"" + userRole
					+ "\" in the connection id " + connectionRequestId);
		}
		log.debug("MailModule:MailModuleUtil:getUsrRleEmailPrjInfo:: Exited");
		info.add(userRoleEmail);
		info.add(projectCoordName);
		return info;
	
	}
	
	 
	
	
	/**
	 * Gets the user role email.
	 *
	 * @param connectionRequestId the connection request id
	 * @param userRole the user role
	 * @param testMode the test mode
	 * @return the user role email
	 */
	// JDBCTemplate Refactored 
	public String getUserRoleEmail(String connectionRequestId, String userRole,String testMode) {
			
		log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: Entered");
		// String sql =
		// "select distinct cc.EMAIL,cc.SSO_ID from con_req_citi_contact_xref ccx,role rr,citi_contact cc where ccx.request_id = "+connectionRequestId+" and ccx.role_id=rr.id and rr.name = '"+userRole+"' and ccx.citi_contact_id = cc.id"
		// ;
		String sql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from ti_request_planning_xref trpx, ti_request tr, con_req_citi_contact_xref crccx,planning p,citi_contact cc,role rr where tr.process_id = "
				+ connectionRequestId
				+ " and trpx.ti_request_id = tr.id and tr.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId
				+ " ) and trpx.planning_id = p.id and crccx.request_id = p.id and crccx.citi_contact_id = cc.id and crccx.role_id=rr.id and crccx.notify_contact = 'Y' and rr.name = '"
				+ userRole + "'";
		String non3rdPartysql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from ti_request_planning_xref trpx, ti_request tr, CON_REQ_CIT_RQCON_XREF crcrx,planning p,citi_contact cc,role rr where tr.process_id = "
				+ connectionRequestId
				+ " and trpx.ti_request_id = tr.id and tr.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId
				+ " ) and trpx.planning_id = p.id and crcrx.request_id = p.id and crcrx.citi_contact_id = cc.id and crcrx.role_id=rr.id and crcrx.notify_contact = 'Y' and rr.name = '"
				+ userRole + "'";
		String ipsql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from c3par_process_role_xref cprx, ti_process tp, role rr, citi_contact cc where tp.id ="
				+ connectionRequestId
				+ " and tp.process_type_id=2 and tp.id=cprx.process_id and cprx.role_id=rr.id and rr.name = '"
				+ userRole
				+ "' and cprx.citi_contact_id=cc.id and cprx.is_active = 'Y'";
		/*
		 * select distinct cc.EMAIL,cc.SSO_ID from c3par_process_role_xref cprx,
		 * ti_process tp,ti_request tr, role rr, citi_contact cc where tr.id =
		 * 2457 and tp.id=tr.process_id and tp.process_type_id=2 and
		 * tp.id=cprx.process_id and cprx.role_id=rr.id and rr.name = 'DESIGN
		 * ENGINEER' and cprx.citi_contact_id=cc.id
		*/
		String finalsql = sql + " union " + non3rdPartysql + " union " + ipsql;
		Map data = new HashMap();
		String userRoleEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: SQL::"
				+ finalsql);
		try {
			data = runQuery(finalsql, 4, "SELECT",  false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if("".equals(userRoleEmail)){
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						}else if("names".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(2) + " " +(String) dataList.get(3)
									+ " , ";
						} else {
							userRoleEmail = (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					} else {
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						}else if("names".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(2) + " " +(String) dataList.get(3)
									+ " , ";
						} else {
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There is no contact specified with Role \"" + userRole
					+ "\" in the connection id " + connectionRequestId);
		}
		log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: Exited");
		return userRoleEmail;
	}

	
	
	 
	
	/**
	 * Gets the all requestors email.
	 *
	 * @param connectionRequestId the connection request id
	 * @param testMode the test mode
	 * @return the all requestors email
	 */
	// JDBCTemplate Refactored Changed
	public String getAllRequestorsEmail(String connectionRequestId,String testMode) {
		log.debug("MailModule:MailModuleUtil:getAllRequestorsEmail:: Entered");
		String sql = "select distinct cu.EMAIL e_mail,cu.SSO_ID from ti_request tr1,ti_request tr2,c3par_users cu where tr1.process_id = "
				+ connectionRequestId
				+ " and tr1.process_id = tr2.process_id and tr2.user_id = cu.id and nvl(cu.is_terminated,' ') != 'TE' ";
		//and lower(cu.sso_id)!='system'
		Map data = new HashMap();
		String userRoleEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getAllRequestorsEmail:: SQL:: "+ sql);

		try {
			data = runQuery(sql, 2, "SELECT",   false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if("".equals(userRoleEmail)){
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						} else {
							userRoleEmail = (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					} else {
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						} else {
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There was a problem in fetching all the requestors from ti_request for the connection id "
							+ connectionRequestId);
		}
		log.debug("MailModule:MailModuleUtil:getAllRequestorsEmail:: Exited");
		return userRoleEmail;
	}

	/**
	 * Gets the implementation results.
	 *
	 * @param connectionRequestId the connection request id
	 * @return the implementation results
	 */
	public String getImplementationResults(String connectionRequestId) {
		log.debug("MailModule:MailModuleUtil:getImplementationResults:: Entered");
		String sql = "select ttt.task||' : '||tat.ACTIVITY_STATUS from ti_activity_trail tat,ti_task_type ttt,ti_process tp,ti_request tr"
				+ " where tr.process_id=tp.id and tp.version_number=tr.version_number and tr.id=tat.ti_request_id and tat.activity_id=ttt.id and ttt.task_code in ('appsense_imp','proxy_imp','ope_imp','gncc_imp','uat_appsense_imp') and tp.id="
				+ connectionRequestId
					+" and tat.id in (select max(tat1.id) from ti_activity_trail tat1,ti_task_type ttt1 where ttt1.task_code in ('appsense_imp','proxy_imp','ope_imp','gncc_imp','uat_appsense_imp' )"
					+" and tat1.activity_id=ttt1.id and tat1.ti_request_id=tr.id group by ttt1.task_code)";

		Map data = new HashMap();
		String implementationResults = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getImplementationResults:: SQL::"
				+ sql);
		try {
			data = runQuery(sql, 1, "SELECT",  false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if("".equals(implementationResults)){
						implementationResults = (String) dataList.get(0)
								+ "<br>";
					} else {
						implementationResults = implementationResults
								+ (String) dataList.get(0) + "<br>";
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There was a problem in fetching the Implementation Results from ti_activity_trail for the connection id "
							+ connectionRequestId);
		}
		log.debug("MailModule:MailModuleUtil:getImplementationResults:: Exited");
		return implementationResults;
	}

	/*public String getLastSubmitterComments(long tiRequestID) {

		log.debug("MailModule:MailModuleUtil:getLastSubmitterRole:: Entered");
		Connection connection = null;
		Statement stmt = null;

		ResultSet rs = null;
		String LastSubmitterComments = "";

		try {
			connection = (new C3parSession()).getConnection();
			stmt = connection.createStatement();
			String sql = "select comments from TI_REQUEST_COMMENTS where ti_request_id = "
					+ tiRequestID
					+ "and id=(select max(id) from ti_request_comments where ti_request_id = "
					+ tiRequestID + ")";
			log.debug("MailModule:MailModuleUtil:getLastSubmitterRole:: SQL::"
					+ sql);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {

				LastSubmitterComments = rs.getString(1);

			}

		} catch (Exception e) {
			log.error(e);
		}
		return LastSubmitterComments;

	}*/

	 


	/**
	 * Gets the last submitter role.
	 *
	 * @param tiRequestID the ti request id
	 * @param c3parSession the c3par session
	 * @return the last submitter role
	 */
	public String getLastSubmitterRole(Long tiRequestID) {

		log.debug("MailModule:MailModuleUtil:getLastSubmitterRole:: Entered");
		String sql = "select rr.display_name from TI_REQUEST_COMMENTS trc,role rr "
					+"where trc.role_id=rr.id and ti_request_id =" + tiRequestID + "and trc.id=(select max(id) from"
					+" ti_request_comments where ti_request_id =" + tiRequestID +")";

		Map data = new HashMap();
		String lastSubmitterRole = "";
		List dataList = null;

		log.debug("MailModule:MailModuleUtil:getLastSubmitterRole:: SQL::" + sql);


		try {
			data = runQuery(sql, 1, "SELECT", false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {

			dataList = (ArrayList) data.get(Integer.valueOf(counter));
			if (dataList != null && dataList.size() > 0) {
				if ("".equals(lastSubmitterRole)) {
					lastSubmitterRole = (String) dataList.get(0);
				} else {
					lastSubmitterRole = lastSubmitterRole + (String) dataList.get(0);
				}

			}

			counter = counter + 1;
		} else {
			log.error("There was a problem in fetching the TI request roles from ti_request_comments for the connection id "
							+ tiRequestID);
		}

		log.debug("MailModule:MailModuleUtil:getTiRequestComments:: Exited");
		return lastSubmitterRole;


	}

	 
	/**
	 * Gets the last submitter comments.
	 *
	 * @param tiRequestID the ti request id
	 * @param c3parSession the c3par session
	 * @return the last submitter comments
	 */
	public String getLastSubmitterComments (Long tiRequestID) {
		log.debug("MailModule:MailModuleUtil:getImplementationResults:: Entered");

		String sql = "select comments from TI_REQUEST_COMMENTS where ti_request_id = "
				+ tiRequestID
				+ " and id=(select max(id) from ti_request_comments where ti_request_id = "
				+ tiRequestID + ")";

		Map data = new HashMap();
		String comments = "";
		List dataList = null;

		log.debug("MailModule:MailModuleUtil:getLastSubmitterComments:: SQL::"
				+ sql);
		try {
			data = runQuery(sql, 1, "SELECT",  false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {

			dataList = (ArrayList) data.get(Integer.valueOf(counter));
			if (dataList != null && dataList.size() > 0) {
				if ("".equals(comments)) {
					comments = (String) dataList.get(0);
				} else {
					comments = comments + (String) dataList.get(0);
				}

			}

			counter = counter + 1;
		} else {
			log.error("There was a problem in fetching the TI request comments from ti_request_comments for the connection id " + tiRequestID);
							
		}
		log.debug("MailModule:MailModuleUtil:getTiRequestComments:: Exited");
		return comments;
	}

	/**
	 * Gets the aAF combinations.
	 *
	 * @param conReqID the con req id
	 * @return the aAF combinations
	 */
	public List getAAFCombinations(String conReqID){
		log.debug("MailModule:MailModuleUtil:getAAFCombinations:: Entered");

		String sql =
			"select (case when  p.m is null then q.m else p.m end)||' : '||'ADD'||'('||" +
			"(case when  p.n is null then 0 else p.n end)||') / '||'DELETE'||'('||" +
			"(case  when q.n is null then 0 else q.n end)||')' combination from(select (case faf_type " +
			"when 1 then 'NON_NETWORK' " +
			"when 2 then 'NETWORK' " +
			"when 3 then 'USERS_ADD' " +
			"END " +
			")m,count(faf_type)n from aps_impl_history where process_id=" + conReqID + " AND comb_type_id=1 and ti_request_id =" +
			"(select max(ti_request_id) from aps_impl_history where process_id = " + conReqID + ")" +
			"group by (case faf_type " +
			"when 1 then 'NON_NETWORK'" +
			"when 2 then 'NETWORK' " +
			"when 3 then 'USERS_ADD' " +
			"END ) )p full outer join" +
			"(select (case faf_type " +
			"when 1 then 'NON_NETWORK' " +
			"when 2 then 'NETWORK' " +
			"when 3 then 'USERS' " +
			"END " +
			")m,count(faf_type)n from aps_impl_history where process_id=" + conReqID + " AND comb_type_id=3 and ti_request_id =  " +
			"(select max(ti_request_id) from aps_impl_history where process_id = " + conReqID + ")group by (case faf_type " +
			"when 1 then 'NON_NETWORK' " +
			"when 2 then 'NETWORK'" +
			"when 3 then 'USERS' " +
			"END ) )q on p.m=q.m";
		 
	  	List policynameList = new ArrayList();
		log.debug("MailModule:MailModuleUtil:getAAFCombinations:: SQL::" 	+ sql);

		try {
			//comment for c3par session for junit and use obtainconnection
			
			SqlRowSet  rs =  jdbcTemplate.queryForRowSet(sql);
			if (rs != null) {
				while (rs.next()) {
		     		policynameList.add(rs.getString(1));
		     	}
		    }
		} catch (Exception e) {
			log.error(e,e);
		}  

		log.debug("MailModule:MailModuleUtil:getAAFCombinations:: Exited");
		return policynameList;
	}

	/**
	 * Gets the pAF combinations.
	 *
	 * @param conReqID the con req id
	 * @return the pAF combinations
	 */
	public List getPAFCombinations(String conReqID){
		log.debug("MailModule:MailModuleUtil:getPAFCombinations:: Entered");

		String sql = "select (case when  p.m is null then q.m else p.m end)||' : '||'ADD'||'('||" +
		"(case when  p.s is null then 0 else p.s end)||') / '||'DELETE'||'('||" +
		"(case  when q.s is null then 0 else q.s end)||')' combination from(" +
		"select (case y.record_type WHEN 'BASIC' THEN 'PROXY_FILTER' ELSE y.record_type END)m," +
		"count(y.record_type)s from prx_paf_history x," +
		"prx_instance_master y  where  x.proxy_inst_mst_id=y.id and x.process_id=" + conReqID + "and x.comb_type_id=1 and ti_request_id =" +
		"(select max(ti_request_id) from prx_paf_history where process_id = " + conReqID + ")" +
		"group by x.comb_type_id,y.record_type,x.process_id)p  full outer join" +
		"(select (case y.record_type WHEN 'BASIC' THEN 'PROXY_FILTER' ELSE y.record_type END)m," +
		"count(y.record_type)s from prx_paf_history x, " +
		"prx_instance_master y  where  x.proxy_inst_mst_id=y.id and x.process_id=" + conReqID + "and x.comb_type_id=3 and ti_request_id =" +
		"(select max(ti_request_id) from prx_paf_history where process_id = " + conReqID + ")" +
		"group by x.comb_type_id,y.record_type,x.process_id)q on p.m=q.m";

	   
	   
		List policynameList = new ArrayList();

		log.debug("MailModule:MailModuleUtil:getPAFCombinations:: SQL:: " 	+ sql);

		try {
			//commentn for c3par session for junit and use obtainconnection
			SqlRowSet rs =  jdbcTemplate.queryForRowSet(sql);
			if (rs != null) {
				while (rs.next()) {
		     		policynameList.add(rs.getString(1));
		     	}
		    }

		} catch (Exception e) {
			log.error(e,e);
		} 

		log.debug("MailModule:MailModuleUtil:getFirewallAddDeleteRules:: Exited");
		return policynameList;



	}

	/**
	 * Gets the fAF combinations.
	 *
	 * @param conReqID the con req id
	 * @return the fAF combinations
	 */
	public List getFAFCombinations(String conReqID) {
		log.debug("MailModule:MailModuleUtil:getFAFCombinations:: Entered");

		String sql = "select (case when  addcount.policyID is null then deletecount.policyName else addcount.policyName end)||' : '||'ADD'||'('|| "  +
		"(case when  addcount.count is null then 0 else addcount.count end)||') / '||'DELETE'||'('|| " +
		"(case  when deletecount.count is null then 0 else deletecount.count end)||')' combination from " +
		
		"    (select conPolicy.ID policyID, conPolicy.POLICY_NAME||'-'||conPolicy.FW_TYPE policyName,count(conPolicy.ID) count " +
		"        from FAF_FW_RULE fafRule,FAF_FW_RULE_POLICY fafPolicy,CON_FW_POLICY conPolicy,FAF_FIREFLOW_TICKET fafTicket "+
		"    where fafTicket.ID = fafRule.FIREFLOW_TICKET_ID and fafRule.ID = fafPolicy.FAF_FW_RULE_ID " +
		"    and fafPolicy.Policy_ID = conPolicy.ID and fafTicket.Ti_Request_ID = (select max(id) from ti_request where process_id="+conReqID+") " +
		"    and fafTicket.Type = 'A' and upper(fafTicket.Status) not in ('DELETED','REJECTED','REJRCTED') " +
		"    group by conPolicy.POLICY_NAME,conPolicy.FW_TYPE,conPolicy.ID) addcount " +
		
		"full outer join " +
		
		"    (select conPolicy.ID policyID, conPolicy.POLICY_NAME||'-'||conPolicy.FW_TYPE policyName,count(conPolicy.ID) count "+
		"        from FAF_FW_RULE fafRule,FAF_FW_RULE_POLICY fafPolicy,CON_FW_POLICY conPolicy,FAF_FIREFLOW_TICKET fafTicket " +
		"    where fafTicket.ID = fafRule.FIREFLOW_TICKET_ID and fafRule.ID = fafPolicy.FAF_FW_RULE_ID " +
		"    and fafPolicy.Policy_ID = conPolicy.ID and fafTicket.Ti_Request_ID = (select max(id) from ti_request where process_id="+conReqID+") " +
		"    and fafTicket.Type = 'D' and upper(fafTicket.Status) not in ('DELETED','REJECTED','REJRCTED') " +
		"    group by conPolicy.POLICY_NAME,conPolicy.FW_TYPE,conPolicy.ID) deletecount " +
		"on addcount.policyID = deletecount.policyID";
			  
		List policynameList = new ArrayList();

		log.debug("MailModule:MailModuleUtil:getFAFCombinations:: SQL::"+ sql);

		try {
			 
			SqlRowSet rs =  jdbcTemplate.queryForRowSet(sql);
		     
			if (rs != null) {
				while (rs.next()) {
		     		policynameList.add(rs.getString(1));
		     	}
		    }
		} catch (Exception e) {
			log.error(e,e);
		} 
		log.debug("MailModule:MailModuleUtil:getFAFCombinations:: Exited");
		return policynameList;
	}

	
	/**
	 * Gets the owner email.
	 *
	 * @param connectionRequestId the connection request id
	 * @param testMode the test mode
	 * @return the owner email
	 *//*
	public String getOwnerEmail(String connectionRequestId, String testMode) {
		log.debug("MailModule:MailModuleUtil:getOwnerEmail:: Entered");
		// select cu.EMAIL e_mail,cu.SSO_ID from c3par_users cu, ti_request tr
		// where tr.process_id = 1823 and tr.user_id = cu.id
		//and tr.id = (select max(id) from ti_request where process_id = 1823)
		String sql = "select cu.EMAIL e_mail,cu.SSO_ID, cu.first_name, cu.last_name from c3par_users cu, ti_request tr where tr.process_id = "
				+ connectionRequestId
				+ " and tr.user_id = cu.id "
				+ " and tr.id = (select max(id) from ti_request where process_id = "
				+ connectionRequestId + ")";

		Map data = new HashMap();
		String ownerEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getOwnerEmail:: SQL::" + sql);
		try {
			data = runQuery(sql, 4, "SELECT", c3parSession, false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && !data.isEmpty()) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && !dataList.isEmpty()) {
					if("true".equalsIgnoreCase(testMode)){
						ownerEmail = (String) dataList.get(1)
								+ EMAIL_ADDRESS_SEPERATOR;
						break;
					} else if("names".equalsIgnoreCase(testMode)){
						ownerEmail = ownerEmail
								+ (String) dataList.get(2) + " " +(String) dataList.get(3);
						break;
					} else {
						ownerEmail = (String) dataList.get(0)
								+ EMAIL_ADDRESS_SEPERATOR;
						break;
					}
				}
			}
		}
		log.debug("MailModule:MailModuleUtil:getOwnerEmail:: Exited");
		return ownerEmail;
	}*/

	 
	
	
	// JDBCTemplate Refactored 
	public String getOwnerEmail(String connectionRequestId, String testMode) {
		log.debug("MailModule:MailModuleUtil:getOwnerEmail:: Entered");
		Map data = null;
		String ownerEmail = "";
		String sqlFinal = null;
		List dataList = null;
		 
		
		final String sqlStart = "select cu.EMAIL e_mail,cu.SSO_ID, cu.first_name, cu.last_name from c3par_users cu, ti_request tr where tr.process_id = ";
		final String sqlEnd = " and tr.user_id = cu.id and nvl(cu.is_terminated,' ') != 'TE' and tr.id = (select max(id) from ti_request where process_id = ";
	 
		 sqlFinal = sqlStart + connectionRequestId + sqlEnd + connectionRequestId + ")";
		 
		 log.debug("MailModule:MailModuleUtil:getOwnerEmail:: SQL::" + sqlFinal);
	
		 try {
			data = runQuery(sqlFinal, 4, "SELECT",   false);
		 } catch (Exception e) {
			log.error(e,e);
		 }
		
		int counter = 1;
		if (data != null && !data.isEmpty()) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && !dataList.isEmpty()) {
					if("true".equalsIgnoreCase(testMode)){
						ownerEmail = (String) dataList.get(1) + EMAIL_ADDRESS_SEPERATOR;
						break;
					} else if("names".equalsIgnoreCase(testMode)){
						ownerEmail = ownerEmail + (String) dataList.get(2) + " " +(String) dataList.get(3);
						break;
					} else {
						ownerEmail = (String) dataList.get(0) + EMAIL_ADDRESS_SEPERATOR;
						break;
					}
				}
			}
		}
		return ownerEmail;
	}
    
    
	 

	/**
	 * Gets the to addr for scheduled email.
	 *
	 * @param requestId the request id
	 * @param connectionRequestId the connection request id
	 * @param testMode the test mode
	 * @return the to addr for scheduled email
	 */
	public String getToAddrForScheduledEmail(long requestId,String connectionRequestId, String testMode) {
		log.debug("MailModule:MailModuleUtil:getToAddrForScheduledEmail:: Entered");
		String sql = "select ttt.task_code,gl.value2 from ti_activity_trail tat,ti_task_type ttt, generic_lookup gl, generic_lookup_defs gld where tat.ti_request_id = "
				+ requestId
				+ " and tat.activity_status = 'SCHEDULED' and tat.activity_id=ttt.id and ttt.task_code = gl.value1 and gl.definition_id = gld.id and gld.name = 'Expiration EmailTo'";

		Map data = new HashMap();
		String email = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getToAddrForScheduledEmail:: SQL::"
						+ sql);
		try {
			data = runQuery(sql, 2, "SELECT",  false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					String taskCode = (String) dataList.get(0);
					String roleNames = (String) dataList.get(1);

					String[] roleCategories = roleNames.split("\\,");
					for (int i = 0; i < roleCategories.length; i++) {

						if (roleCategories[i] != null
								&& "CURRENT_PC".equals(roleCategories[i])) {
							email = email
									+ getOwnerEmail(connectionRequestId,
											testMode);
						} else if (roleCategories[i] != null
								&& "ALL_REQUESTORS".equals(roleCategories[i])) {
							email = email
									+ getAllRequestorsEmail(
											connectionRequestId, testMode);
						} else if (roleCategories[i] != null
								&& !("".equals(roleCategories[i].trim()))) {
							if ("bus_jus".equals(taskCode)
									|| "ip_det".equals(taskCode)
									|| "tec_arc".equals(taskCode)
									|| "ost_upd".equals(taskCode)
									|| "pro_inf".equals(taskCode)
									|| "pro_inf1".equals(taskCode)
									|| "pro_inf2".equals(taskCode)
									|| "pro_inf7".equals(taskCode)
									|| "iso_app".equals(taskCode)
									|| "bu_mgr_app".equals(taskCode)
									|| "act_con".equals(taskCode)
									|| "ver_sow".equals(taskCode)) {
								email = email
										+ getUserRoleEmail(connectionRequestId,
												roleCategories[i], testMode);
							} else if ("se_app".equals(taskCode)
									|| "tpw_app".equals(taskCode)
									|| "ist_app".equals(taskCode)
									|| "pro_inf6".equals(taskCode)
									|| "pro_inf3".equals(taskCode)
									|| "pro_inf4".equals(taskCode)
									|| "pro_inf8".equals(taskCode)
									|| "pro_inf9".equals(taskCode)
									|| "otrm_app".equals(taskCode)
									|| "mad_app".equals(taskCode)
									|| "rol_fw_imp".equals(taskCode)
									|| "mad_pro_inf".equals(taskCode)
									|| "otrm_pro_inf".equals(taskCode)
									|| "otrm_ret_app".equals(taskCode)
									|| "mad_ret_app".equals(taskCode)
									|| "tpw_ret_app".equals(taskCode)
									|| "fix_con".equals(taskCode)
									|| "appsense_imp".equals(taskCode)
									|| "gncc_imp".equals(taskCode)
									|| "pro_inf10".equals(taskCode)
									|| "proxy_imp".equals(taskCode)) {
								email = email
										+ getRoleEmail(roleCategories[i],
												testMode);
							} else if ("ope_imp".equals(taskCode)
									|| "pro_inf5".equals(taskCode)) {
								email = email
										+ getFWMgmtRegionEmail(
												connectionRequestId, testMode);
	    					} else {
								email = email
										+ getOwnerEmail(connectionRequestId,
												testMode);
	    					}
	                    } else {
							email = email
									+ getOwnerEmail(connectionRequestId,
											testMode);
    					}
                    }
				}
				//counter = counter+1;
				break;
			}
		} else {
			log.error("There was a problem in fetching all the ToAddrForScheduledEmail for the request id "
							+ requestId);
			email = getOwnerEmail(connectionRequestId, testMode);
		}
		log.debug("MailModule:MailModuleUtil:getToAddrForScheduledEmail:: Exited");
		return email;
	}

 
	
	
	public String getToAddrForScheduledExpirationEmail(long requestId, String connectionRequestId, String testMode) {
		log.debug("MailModule:MailModuleUtil:getToAddrForScheduledExpirationEmail:: Entered");
		String sql = "select distinct cu.EMAIL e_mail, cu.SSO_ID, cu.first_name, cu.last_name from c3par_users cu, ti_activity_trail ta "
				+ " where ta.lockedby = cu.id and nvl(cu.is_terminated,' ') != 'TE' and ta.activity_status = 'EXPIRED' and ta.ti_request_id = " + requestId;

		Map data = new HashMap();
		String email = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getToAddrForScheduledEmail:: SQL::" + sql);
		try {
			data = runQuery(sql, 4, "SELECT",   false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if("".equals(email)){
						if("true".equalsIgnoreCase(testMode)){
							email = (String) dataList.get(1) + EMAIL_ADDRESS_SEPERATOR;
									
						} else if("names".equalsIgnoreCase(testMode)){
							email = (String) dataList.get(2) + " " +(String) dataList.get(3) + " and ";
						} else {
							email = (String) dataList.get(0) + EMAIL_ADDRESS_SEPERATOR;
						}
					} else {
						if("true".equalsIgnoreCase(testMode)){
							email = email + (String) dataList.get(1)+ EMAIL_ADDRESS_SEPERATOR;
								
						} else if("names".equalsIgnoreCase(testMode)){
							email = email
									+ (String) dataList.get(2) + " " +(String) dataList.get(3)
									+ " and ";
						} else {
							email = email
									+ (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There was a problem in fetching all the getToAddrForScheduledExpirationEmail for the request id "+ requestId);
			email = getOwnerEmail(connectionRequestId, testMode);
		}
		if(testMode != null && testMode.equalsIgnoreCase("names") && email.lastIndexOf("and") != -1 && email.length() > 1){
			email = email.substring(0, email.length()-4 );
		}
		log.debug("MailModule:MailModuleUtil:getToAddrForScheduledExpirationEmail:: Exited");
		return email;
	}

	/**
	 * Populate user entitlement data.
	 *
	 * @param ssoId the sso id
	 * @param user the user
	 * @return the c3 par user
	 */
	public C3PARUser populateUserEntitlementData(String ssoId,C3PARUser user) {
		log.debug("MailModule:MailModuleUtil:populateUserEntitlementData:: Entered");
		C3parUsersLookup dao = C3parUsersLookup.getInstance();
		C3parUsersEntity entity = null;
		entity = dao.getBySsoId(ssoId);
		List entList = getEntitlementsForUser(entity.getId());
		String[] entArr = new String[entList.size()];
		user.setEntitlements((String[])entList.toArray(entArr));
		List roleList = entity.getRole();
		String [] roles = new String[roleList.size()];
		String displayRoles = "";
		String displayEntitlements = "";

		for(int i=0;i<entList.size();i++)
			displayEntitlements = displayEntitlements+entList.get(i)+"; \n";
		Iterator rit = roleList.iterator();
		int i = 0;
		while (rit.hasNext()) {
			C3parUserRoleXrefEntity xrefEntity = (C3parUserRoleXrefEntity) rit
					.next();
				roles[i++] = xrefEntity.getRole().getName();
			displayRoles = displayRoles + xrefEntity.getRole().getDisplayName()
					+ "; \n";
		}
		user.setRoles(roles);
		user.setDisplayEntitlements(displayEntitlements);
		user.setDisplayRoles(displayRoles);
		user.setRequestedBy(entity.getRequestedBy());
		user.setManagerApprover(entity.getManagerApprover());
		user.setManagerReviewedDate(entity.getMgrReviewedDate());
		user.setComments(entity.getRejectionComments());
		user.setSysadminApprover(entity.getSysadminApprover());
		user.setSysadminReviewedDate(entity.getSysadminReviewedDate());
		return user;
	}

	/**
	 * Convert c3 par user dto.
	 *
	 * @param userDTO the user dto
	 * @return the c3 par user
	 */
	public C3PARUser convertC3PARUserDTO(C3PARUserDTO userDTO) {
		C3PARUser user = new C3PARUser();
		try {
		user.setSsoId(userDTO.getSsoId());
		user.setFirstName(userDTO.getFirstName());
		user.setLastName(userDTO.getLastName());
		user.setActive(userDTO.isActive());
		user.setComments(userDTO.getComments());
		user.setDisplayName(userDTO.getDisplayName());
		user.setDisplayEntitlements(userDTO.getDisplayEntitlements());
		user.setDisplayRoles(userDTO.getDisplayRoles());
		user.setEmail(userDTO.getEmail());
		user.setEntitlements(userDTO.getEntitlements());
		user.setRoles(userDTO.getRoles());
		user.setFax(userDTO.getFax());
		user.setManagerApprover(userDTO.getManagerApprover());
		user.setManagerReviewedDate(userDTO.getManagerReviewedDate());
		user.setOrganizationUnit(userDTO.getOrganizationUnit());
		user.setPassword(userDTO.getPassword());
		user.setRequestedBy(userDTO.getRequestedBy());
		user.setSysadminApprover(userDTO.getSysadminApprover());
		user.setSysadminReviewedDate(userDTO.getSysadminReviewedDate());
		user.setTelephone(userDTO.getTelephone());
		} catch (Exception e) {
			log.error(e, e);
		}
		return user;

	}

	/**
	 * Gets the entitlements for user.
	 *
	 * @param userId the user id
	 * @return the entitlements for user
	 */
	private List getEntitlementsForUser(Long userId) {
		List userEntitlementList = new ArrayList();

		/*try {
			C3parUsersLookup dao = C3parUsersLookup.getInstance();
			C3parUsersEntity entity = dao.getById(userId);
			List entitlements = entity.getUserEntitlements();
			if (entitlements != null) {
				Iterator itr = entitlements.iterator();
				while (itr.hasNext()) {
					C3parUserEntitlementXrefEntity userEntXref = (C3parUserEntitlementXrefEntity) itr
							.next();
					userEntitlementList.add(userEntXref
							.getEntitlementInstance().getName());
				}
			}
		} catch (Exception e) {
			log.error(e,e);
		}*/
		return userEntitlementList;
	}
 
	
	
	/**
	 * Gets the role email.
	 *
	 * @param userRole the user role
	 * @param testMode the test mode
	 * @return the role email
	 */
	// JDBCTemplate Refactored 
	public String getRoleEmail(String userRole,String testMode) {
		log.debug("MailModule:MailModuleUtil:getRoleEmail:: Entered");
		String sql = "select distinct cu.email,cu.SSO_ID from c3par_user_role_xref curx,security_role sr ,c3par_users cu " +
				"where curx.role_id = sr.id and curx.user_id = cu.id and cu.is_active='Y' and nvl(cu.is_terminated,' ') != 'TE' and sr.name = '"
				+ userRole + "' order by cu.SSO_ID asc";
		/*
		 * select cu.email from c3par_user_role_xref curx,security_role sr
		 * ,c3par_users cu where curx.role_id = sr.id and curx.user_id = cu.id
		 * and sr.name ='BISO'
*/
		Map data = new HashMap();
		String roleEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getRoleEmail:: SQL::" + sql);
		
		try {
			data = runQuery(sql, 2, "SELECT",   false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if("".equals(roleEmail)){
						if("true".equalsIgnoreCase(testMode)){
							roleEmail = (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						} else {
							roleEmail = (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					} else {
						if("true".equalsIgnoreCase(testMode)){
							roleEmail = roleEmail
									+ (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						} else {
							roleEmail = roleEmail
									+ (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					}
				}
				counter = counter+1;
			}
		} else {
			log.error("There is no contact available with role::"+userRole);
		}
		log.debug("MailModule:MailModuleUtil:getRoleEmail:: Exited");
		return roleEmail;
	}

	/**
	 * Gets the connection app owner email.
	 *
	 * @param connID the conn id
	 * @return the connection app owner email
	 */
	public String getConnectionAppOwnerEmail(String connID) {
		log.debug("MailModule:MailModuleUtil:getRoleEmail:: Entered");
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT DISTINCT CON.CONNECTION_NAME,");
		sql.append("USR.FIRST_NAME,");
		sql.append("USR.LAST_NAME,");
		sql.append("CON.REQUESTER_ID,");
		sql.append("REG.NAME,");
		sql.append("SEC.NAME ,");
		sql.append("BU.BUSINESS_NAME,");
		sql.append("APP.APPLICATION_ID,");
		sql.append("APP.APPLICATION_NAME,");
		sql.append("APP.APP_OWNER_FULL_NAME,");
		sql.append("APP.APP_OWNER_EMAIL ");
		sql.append("FROM C3PAR.CON_REQ CON,");
		sql.append("C3PAR.RELATIONSHIP REL,");
		sql.append("C3PAR.REL_CITI_HIERARCHY_XREF RELXREF,");
		sql.append("C3PAR.CITI_HIERARCHY_MASTER CITIMASTER,");
		sql.append("C3PAR.TI_APPLICATION APP,");
		sql.append("C3PAR.REGION REG,");
		sql.append("C3PAR.SECTOR SEC,");
		sql.append("C3PAR.BUSINESS_UNIT BU,");
		sql.append("C3PAR.CON_IP_XREF CIPX,");
		sql.append("C3PAR.CON_IP_MASTER CIPM,");
		sql.append("C3PAR.C3PAR_USERS USR ");
		sql.append("WHERE CON.RELATIONSHIP_ID       =REL.ID ");
		sql.append("AND RELXREF.RELATIONSHIP_ID = REL.ID ");
		sql.append("AND CITIMASTER.ID = RELXREF.CITI_HIERARCHY_MASTER_ID ");
		sql.append("AND CITIMASTER.REGION_ID = REG.ID  ");
		sql.append("AND CITIMASTER.SECTOR_ID = SEC.ID ");
		sql.append("AND CITIMASTER.BU_ID = BU.ID ");
		sql.append("AND CON.ID                      =CIPX.CONNECTION_REQUEST_ID ");
		sql.append("AND CIPX.IP_ID                  =CIPM.ID ");
		sql.append("AND CIPM.DELETE_FLAG!           ='T' ");
		sql.append("AND CIPX.APPLICATION_ID         =APP.ID ");
		sql.append("AND APP.IS_CSI                  ='Y' ");
		sql.append("AND APP.IS_DEVICE               ='N' ");
		sql.append("AND CON.REQUESTER_ID            =USR.SSO_ID ");
		sql.append("AND NVL(USR.IS_TERMINATED,' ') != 'TE' ");
		sql.append("AND CON.ID                      = "+connID);
		
		Map data = new HashMap();
		String roleEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getConnAppOwnerEmail:: SQL::"
				+ sql);
		try {
			data = runQuery(sql.toString(), 1, "SELECT", false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if("".equals(roleEmail)){
						roleEmail = (String) dataList.get(0)
								+ EMAIL_ADDRESS_SEPERATOR;
					} else {
						roleEmail = roleEmail + (String) dataList.get(0)
								+ EMAIL_ADDRESS_SEPERATOR;
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There is no app owner available for connection ID::"
					+ connID);
		}
		log.debug("MailModule:MailModuleUtil:getConnAppOwnerEmail:: Exited");
		return roleEmail;
	}
	
	

	/**
	 * Run query.
	 *
	 * @param statement the statement
	 * @param columns the columns
	 * @param type the type
	 * @param c3parSession the c3par session
	 * @param isTransaction the is transaction
	 * @return the map
	 * @throws Exception the exception
	 */
	private Map runQuery(String statement, int columns, String type, boolean isTransaction) throws Exception {
 		
		//JdbcTemplate jdbcTemplateLocal  =  ( (jdbcTemplateVar == null) ? jdbcTemplate : jdbcTemplateVar);
		
		if (type.toUpperCase().equals("SELECT")) {
			Map data = null;
			List dataList = null;
			int counter = 0;
			int rowId = 0;
			SqlRowSet result = null;
			Statement st = null;
			try {
				 
				result =  jdbcTemplate.queryForRowSet(statement);
				while (result.next()) {
					if (data == null)
						data = new HashMap();
					rowId = rowId + 1;
					counter = 1;
					dataList = new ArrayList();
					dataList.add(result.getString(counter));
					data.put(Integer.valueOf(rowId), dataList);
					while (counter < columns) {
						counter = counter + 1;
						dataList.add(result.getString(counter));
					}
				}
			} catch (Exception e) {
				log.error(e,e);
			}  
			return data;
		} else if (type.toUpperCase().equals("DML")) {
			try {
				jdbcTemplate.update(statement);
			} catch (Exception e) {
				log.error(e,e);
			}  
			return null;
		}
		return null;

	}

	/**
	 * Gets the connection.
	 *
	 * @return the connection
	 *//*
	private Connection getConnection() {
		Connection connection = null;

		try {
			InitialContext ctx = new InitialContext();
			DataSource source = (DataSource) ctx
					.lookup(C3parProperties.JDBC_DS);
			if (null != source) {
				connection = source.getConnection();
			}
		} catch (Exception e) {
			log.error(e,e);
		}
		return connection;
	}
	*/
	

	/**
	 * Run query.
	 *
	 * @param statement the statement
	 * @param columns the columns
	 * @param type the type
	 * @param c3parSession the c3par session
	 * @param isTransaction the is transaction
	 * @return the map
	 * @throws Exception the exception
	 */
	/*private Map runQuery(String statement, int columns, String type,
			C3parSession c3parSession, boolean isTransaction) throws Exception {

		Connection connection = c3parSession.getConnection();
		//uncomment for Junit
		//Connection connection = obtainConnection();
		if (type.toUpperCase().equals("SELECT")) {
			Map data = null;
			List dataList = null;
			int counter = 0;
			int rowId = 0;
			ResultSet result = null;
			Statement st = null;
			try {
				st = connection.createStatement();
				result = st.executeQuery(statement);
				while (result.next()) {
					if (data == null)
						data = new HashMap();
					rowId = rowId + 1;
					counter = 1;
					dataList = new ArrayList();
					dataList.add(result.getString(counter));
					data.put(Integer.valueOf(rowId), dataList);
					while (counter < columns) {
						counter = counter + 1;
						dataList.add(result.getString(counter));
					}
				}
			} catch (Exception e) {
				log.error(e,e);
			} finally {
				try {
					if (!isTransaction)
						connection.close();
					st.close();
					result.close();
				} catch (Exception e) {
					log.error(e,e);
				}
			}
			return data;
		} else if (type.toUpperCase().equals("DML")) {
			try {
				connection.createStatement().executeUpdate(statement);
			} catch (Exception e) {
				log.error(e,e);
			} finally {
				try {
					if (!isTransaction)
						connection.close();
				} catch (Exception e) {
					log.error(e,e);
				}
			}
			return null;
		}
		return null;

	}

	*//**
	 * Obtain connection.
	 *
	 * @return the connection
	 *//*
	private Connection obtainConnection() {
		Connection con = null;
		try{

		 Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			con = DriverManager.getConnection(
					"url=jdbc:oracle:thin:@CPNAWRNWV-501MV:1521:CCRDEV",
					"c3par", "c3pardev1231");
		} catch (Exception e) {
			log.error(e, e);
		}
		return con;

	}*/

	
	 

	/**
	 * Gets the proj coordinator contacts.
	 *
	 * @param connectionRequestId the connection request id
	 * @param toUserRole the to user role
	 * @param testMode the test mode
	 * @return the proj coordinator contacts
	 */
	public String getProjCoordinatorContacts(String connectionRequestId,String toUserRole,String testMode) {
			
		log.debug("MailModule:MailModuleUtil:getProjCoordinatorContacts:: Entered");
		String sql = "select distinct citi_con.email, citi_con.sso_id from REL_CITI_CONT_XREF rel_con,ti_process pro,citi_contact citi_con,c3par.role ro where pro.id = "
			+ connectionRequestId+"  and pro.relationship_id= rel_con.relationship_id and citi_con.id= rel_con.contact_id and ro.id= rel_con.role_id and " +
			"lower(ro.name) =lower('"+toUserRole+"')";

		Map data = new HashMap();
		String userRoleEmail = "";
		List dataList = null;
		log.debug("MailModule:MailModuleUtil:getProjCoordinatorContacts:: SQL::"
				+ sql);
		try {
			data = runQuery(sql, 2, "SELECT",   false);
		} catch (Exception e) {
			log.error(e,e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if("".equals(userRoleEmail)){
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						} else {
							userRoleEmail = (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					} else {
						if("true".equalsIgnoreCase(testMode)){
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(1)
									+ EMAIL_ADDRESS_SEPERATOR;
						} else {
							userRoleEmail = userRoleEmail
									+ (String) dataList.get(0)
									+ EMAIL_ADDRESS_SEPERATOR;
						}
					}
				}
				counter = counter + 1;
			}
		} else {
			log.error("There was a problem in fetching all the requestors from ti_request for the connection id "
							+ connectionRequestId);
		}
		log.debug("MailModule:MailModuleUtil:getProjCoordinatorContacts:: Exited");
		return userRoleEmail;
	}

	/**
	 * Gets the emer buscrit questions.
	 *
	 * @return the emer buscrit questions
	 */
	public Map getEmerBuscritQuestions(){
		log.debug("MailModule:MailModuleUtil:emerBuscritQuestionList:: Entered");
		//C3parSession c3parSession=null;
	  
	 
		
		String emerBusQuestionSQL="select value1,value2 from generic_lookup where definition_id in (select id from generic_lookup_defs where upper(name) = upper('EMER_BUSCRIT_QUESTIONS')) and deleted = 'N'";
		Map dataemerBuscritQuestion = new HashMap();
		log.debug("MailModule:MailModuleUtil:emerBuscritQuestionList:: emerBusQuestionSQL::"+emerBusQuestionSQL);
		try {

			//c3parSession = new C3parSession();
			SqlRowSet rs =  jdbcTemplate.queryForRowSet(emerBusQuestionSQL);

			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null && rs.getString(2) != null)
		     		 dataemerBuscritQuestion.put(rs.getString(1), rs.getString(2));
		     	}
		    }

		} catch (Exception e) {
			log.error(e,e);
		} 
		log.debug("MailModule:MailModuleUtil:emerBuscritQuestionList:: Exited");
		return dataemerBuscritQuestion;
	}

	
	
	/**
	 * Gets the emer buscrit answers.
	 *
	 * @param primaryId the primary id
	 * @return the emer buscrit answers
	 */
	public Map<String, String> getEmerBuscritQuesAnswers(String connectionId){
		log.debug("MailModule:MailModuleUtil:getEmerBuscritAnswers:: Entered");
		String rfc_type = "GENERIC";
		String templateKey = "DESC_EMERBUSCRIT_QUESTIONAIRE";
		String isActive = "Y";

		StringBuffer sb = new StringBuffer();
		sb.append("select temp.description, rdans.answer ");
		sb.append("from rfc_request rreq,rfc_detail rdet, rfc_detail_answers rdans, template temp ");
		sb.append(",(select max(id) id from c3par.ti_request where process_id=? group by process_id) tireq ");
		sb.append("where rreq.ti_request_id = tireq.id and upper(rreq.rfc_type)=? ");
		sb.append("and rdet.rfc_request_id = rreq.id and rdans.rfc_detail_id = rdet.id ");
		sb.append("and rdans.template_key in (select id from template temp where parent_id = ");
		sb.append("(select id from template where upper(key) = ?) ");
		sb.append("and upper(isactive) =? ) and temp.id = rdans.template_key order by temp.position");

		Map<String, String> quesAndAns = new LinkedHashMap<String, String>();
		log.debug("MailModule:MailModuleUtil:getEmerBuscritAnswers:: emerBusAnswerSQL ::"+ sb.toString());

		try {   
		  	 

			SqlRowSet rs =  jdbcTemplate.queryForRowSet(sb.toString(),new Object[] {connectionId,rfc_type,templateKey,isActive});
 
			while (rs.next()) {
				if (rs.getString(1) != null){
					quesAndAns.put( rs.getString(1), rs.getString(2));
				}
			}
		}catch (Exception e) {
			log.error(e, e);
		}  

		log.debug("MailModule:MailModuleUtil:getEmerBuscritAnswers:: Exited");
		return quesAndAns;
	}

	/**
	 * Populate info.
	 *
	 * @param emerBuscritQuesAndAnswers the dataemer buscrit answers
	 * @return the list
	 * @throws MailModuleException the mail module exception
	 */
	private MailMsgDisplayRow[] populateInfo(
			Map emerBuscritQuesAndAnswers) throws MailModuleException {
		log.debug("MailModule:MailModuleUtil:populateInfo:: Entered");
		List emerBuscritMailList = new ArrayList();
		MailMsgDisplayRow[] rows = new MailMsgDisplayRow[emerBuscritQuesAndAnswers.size()];
		/*rows[s1].setInfo(populateInfo(rowElement, mailVO));
		MailMsgDisplayInfo[] infos = null;
		infos[s1].setLabel(returninfoStr);
		infos[s1].setValue(returninfoStr);*/
		Set set = emerBuscritQuesAndAnswers.keySet();
		int i=0;
		for (Object object : set) {
			MailMsgDisplayInfo[] infos = new MailMsgDisplayInfo[1];
			String tempQus = (String) object;
			String tempAns = (String) emerBuscritQuesAndAnswers.get(object);
			log.debug("tempQus   "+tempQus + "tempAns  " + tempAns);
			infos[0].setLabel(tempQus);
			infos[0].setValue(tempAns);
			rows[i].setInfo(infos);
			i++;
		}
		log.debug("MailModuleUtil:: Exited");
		return rows;
	}

	
	

	
	/**
	 * Gets the director mai id.
	 *
	 * @param primaryId the primary id
	 * @param relationShipType the relation ship type
	 * @return the director mai id
	 */
	public List getDirectorMaiId(BaseMailVO mailVO,String roleName){
		log.info("MailModule:MailModuleUtil:getDirectorMaiId:: Entered");

		List directorMailInfoList = new ArrayList();
		StringBuffer directorSQL = new StringBuffer();
		//String relationShipType = "";
		InputMailVO inputMailVO =(InputMailVO)mailVO;
		//relationShipType = inputMailVO.getTiProcess().getRelationship().getRelationshipType();//check tiprocess always have this value or not
		
		directorSQL.append("select cont.first_name, cont.last_name " );
		directorSQL.append("from c3par.ti_request_planning_xref trpx, (select max(id) id from ti_request where process_id="+inputMailVO.getConnectionId()+" group by process_id) max_tir, ");
		directorSQL.append("citi_contact cont, con_req cr,con_req_citi_contact_xref citi_con_xref ,role rol ");
		directorSQL.append("where trpx.ti_request_id=max_tir.id and cr.id=trpx.planning_id and  citi_con_xref.request_id=cr.id and ");
		directorSQL.append("citi_con_xref.citi_contact_id=cont.id and citi_con_xref.role_id=rol.id and rol.name in ("+roleName+") " );
		directorSQL.append(" union " );
		directorSQL.append("select cont.first_name, cont.last_name " );
		directorSQL.append("from c3par.ti_request_planning_xref trpx, (select max(id) id from ti_request where process_id="+inputMailVO.getConnectionId()+" group by process_id) max_tir, ");
		directorSQL.append("citi_contact cont, con_req cr,con_req_cit_rqcon_xref citi_con_xref ,role rol " );
		directorSQL.append("where trpx.ti_request_id=max_tir.id and cr.id=trpx.planning_id and  citi_con_xref.request_id=cr.id and " );
		directorSQL.append("citi_con_xref.citi_contact_id=cont.id and citi_con_xref.role_id=rol.id and rol.name in ("+roleName+") " );
			 
		 log.debug("MailModule:MailModuleUtil:getDirectorMaiId::directorSQL:"+directorSQL.toString());
		try {
		  	 
		   	 
		
		   	SqlRowSet rs =  jdbcTemplate.queryForRowSet(directorSQL.toString());
		 
			if (rs != null) {
				while (rs.next()) {
					Map<String,String> directorMailInfo = new HashMap<String,String>();
					if (rs.getString(1) != null) {
						directorMailInfo.put("firstName", rs.getString(1));
					} else {
						directorMailInfo.put("firstName", "");
					}
					if (rs.getString(2) != null) {
						directorMailInfo.put("lastName", rs.getString(2));
					} else {
						directorMailInfo.put("lastName", "");
					}
					directorMailInfoList.add(directorMailInfo);
				}
			}
		} catch (Exception e) {
			log.error("There was a problem in fetching director information for the Connection id "
							+ inputMailVO.getConnectionId());
			log.error(e,e);
		} 
		log.info("MailModule:MailModuleUtil:getDirectorMaiId:: Exited");
		return directorMailInfoList;
	}

	

	/**
	 * Emer buscrit question map.
	 *
	 * @return the map
	 */
	private Map emerBuscritQuestionMap() {
		Map dataemerBuscritQuestion = new HashMap();
		dataemerBuscritQuestion.put(Integer.valueOf(1), EMER_DESC_BUS_PERSPECTIVE);
		dataemerBuscritQuestion.put(Integer.valueOf(2), EMER_MGR_NAME);
		dataemerBuscritQuestion.put(Integer.valueOf(3), EMER_GRP_RAISING_RFC);
		dataemerBuscritQuestion.put(Integer.valueOf(4), EMER_IMPL_BAU_TIMELINES);
		dataemerBuscritQuestion.put(Integer.valueOf(5), EMER_STD_CHANGE_CYCLE);
		dataemerBuscritQuestion.put(Integer.valueOf(6), EMER_DPT_OWNER_PROCESS);
		dataemerBuscritQuestion.put(Integer.valueOf(7), EMER_CLASH_REQUEST);
		dataemerBuscritQuestion.put(Integer.valueOf(8), EMER_RISK_UNPLANNED_CHANGE);
		dataemerBuscritQuestion.put(Integer.valueOf(9), EMER_ADD_BUS_TESTING);
		dataemerBuscritQuestion.put(Integer.valueOf(10), EMER_TESTING_PLAN_CONT_PERSON);
	return dataemerBuscritQuestion;
	}

	/**
	 * Generate c3par mail message xml.
	 *
	 * @param info the info
	 * @return the string
	 */
	private String generateC3parMailMessageXML(List info){
		log.debug("MailModule:MailModuleUtil:generateC3parMailMessageXML:: Entered");
		String mailMsg = "";
		try {
		XStream stream = new XStream(new DomDriver());
		stream.alias("MailMsgDisplayInfo", MailMsgDisplayInfo.class);
		mailMsg = stream.toXML(info);
		} catch (Exception ex) {
			log.error(ex,ex);
		}
		//System.out.println("mailMsg" +mailMsg);
		log.debug("MailModule:MailModuleUtil:generateC3parMailMessageXML:: Exited");
		return mailMsg;
	}

	/**
	 * Apply xsl.
	 *
	 * @param msg the msg
	 * @param templateFileLocation the template file location
	 * @return the string
	 */
	private String applyXSL(String msg,String templateFileLocation){
		log.debug("MailModule:MailModuleImpl:applyXSL:: Entered");
		Writer outWriter;
		StreamResult result = null;
		try {
		outWriter = new StringWriter();
		result = new StreamResult(outWriter);
		TransformerFactory tFactory = TransformerFactory.newInstance();
		//System.out.println(" Template Location emer xls "+TEMPLATE_FILE_LOC+templateFileLocation+EMER_MAIl_TEMPLATE_FILE_NAME);
		 Transformer transformer =
   	      tFactory.newTransformer
   	         (new javax.xml.transform.stream.StreamSource(
   	        		 TEMPLATE_FILE_LOC+templateFileLocation+EMER_MAIl_TEMPLATE_FILE_NAME));
   	         		/*"C:\\ccr\\uat\\workspace\\C3parEar\\c3parWebApp\\WEB-INF\\mailmodule\\EmerMailTemplate.xsl"));// For JUnit*/
		 transformer.transform
  	      (new javax.xml.transform.stream.StreamSource
  	            (new StringReader(msg)),result);
		} catch (Exception e) {
			log.error(e,e);
		}
		log.debug("MailModule:MailModuleImpl:applyXSL:: Exited");

		return result.getWriter().toString();
	}


	/**
	 * Gets the rFC people record addresses.
	 *
	 * @param requestId the request id
	 * @param relationShipType the relation ship type
	 * @param role the role
	 * @return the rFC people record addresses
	 */
	public Map getRFCPeopleRecordAddresses(Long requestId,
			String relationShipType, String role) {
		log.debug("MailModule:MailModuleUtil:getRFCPeopleRecordAddresses:: Entered");

	  	SqlRowSet rs = null;
	 
		
		Map peopleRecordAddressMap = new HashMap();
		String peopleRecAddressSQL = "";
		if (role.equalsIgnoreCase(ROLE_BUS_OWNER)) {
			peopleRecAddressSQL = " select distinct cont.email,usr.sso_id from citi_contact cont,ti_request req,"
					+ "ti_request_planning_xref planning_xref ,role rol,c3par_users usr, ";
			if (relationShipType.equalsIgnoreCase("THIRD_PARTY")) {
				peopleRecAddressSQL = peopleRecAddressSQL
						+ "con_req_citi_contact_xref citi_con_xref ";
			} else {
				peopleRecAddressSQL = peopleRecAddressSQL
						+ "con_req_cit_rqcon_xref citi_con_xref ";
			}
			peopleRecAddressSQL = peopleRecAddressSQL
					+ " where  citi_con_xref.request_id=planning_xref.planning_id and "
					+ " citi_con_xref.citi_contact_id=cont.id and req.id= planning_xref.ti_request_id "
					+ " and req.id="
					+ requestId
					+ " and nvl(usr.is_terminated,' ') != 'TE' and usr.id= req.user_id "
					+ " and citi_con_xref.role_id=rol.id and rol.name in ('Business_Owner')";
		} else if (role.equalsIgnoreCase(ROLE_PC)) {
			peopleRecAddressSQL = " select distinct cu.email,cu.sso_id,cr.connection_name ,req.process_id ,req.version_number "+
			 "from ti_request req,c3par_users cu,con_req cr where req.id="
					+ requestId + " and cr.id=req.process_id and req.user_id = cu.id and nvl(cu.is_terminated,' ') != 'TE' ";
		}
		try {
			log.debug("People Record SQL :: " + peopleRecAddressSQL.toString());
			 rs =  jdbcTemplate.queryForRowSet(peopleRecAddressSQL);
			
	 
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null) {
						String emailAddress = rs.getString(1);
						if (role.equalsIgnoreCase(ROLE_PC)) {
							peopleRecordAddressMap
									.put(
											ROLE_PC,
											emailAddress
													+ EMAIL_ADDRESS_SEPERATOR);

						} else if (role
								.equalsIgnoreCase(ROLE_BUS_OWNER)) {
							peopleRecordAddressMap
									.put(
											ROLE_BUS_OWNER,
											emailAddress
													+ EMAIL_ADDRESS_SEPERATOR);
						}
						if (rs.getString(2) != null) {
							peopleRecordAddressMap.put("SSO_ID", rs
									.getString(2).toString());
						}
						if (rs.getString(3) != null) {
							peopleRecordAddressMap.put("CON_NAME", rs
									.getString(3).toString());
						}
						if (rs.getString(4) != null) {
							peopleRecordAddressMap.put("CON_ID", rs
									.getString(4).toString());
						}
						if (rs.getString(5) != null) {
							peopleRecordAddressMap.put("CON_VERSION", rs
									.getString(5).toString());
						}
					}

				}
			}
		} catch (Exception e) {
			log.error("There was a problem in fetching Address information for the request id "
							+ requestId);
			log.error(e,e);
		}  

		log.debug("MailModule:MailModuleUtil:getRFCPeopleRecordAddresses:: Exited");
		return peopleRecordAddressMap;
	}
	
	public Long getTiRequestId(Long primaryId){
		List directorMailCCAddressList = new ArrayList();
		String sql = "select planning_xref.ti_request_id from ti_request_planning_xref planning_xref where planning_xref.planning_id ="+primaryId.longValue();
		Long tiReqId = null;

		
		try {
			SqlRowSet rs =  jdbcTemplate.queryForRowSet(sql);
			if (rs != null) {
				while (rs.next()) {
					Map directorMailCCAddressMap = new HashMap();
					if (rs.getString(1) != null) {
						tiReqId = Long.valueOf(rs.getString(1));
					}
				}
			}
		} catch (Exception e) {
			log.error(e,e);
		}  
		return tiReqId;
	}
	
	 
  
	// JDBCTemplate Refactored 
	public String getTemplateUsingConnOwners(BaseMailVO mailVO){
	  log.debug("MailModuleUtil.getTemplateUsingConnOwners():starts");
		InputMailVO inputMailVO =(InputMailVO)mailVO;
		String ownerEmail = "";
		String sql = "SELECT DISTINCT CR.EMAIL FROM TI_REQUEST TR1,TI_REQUEST TR2,CON_FW_RULE CFR,CON_FW_RULE CFR2,C3PAR_USERS CR  " +
						"WHERE TR1.ID = ? AND CFR.TI_REQUEST_ID = TR1.ID AND CFR.ID = CFR2.TMP_ID AND CFR2.TI_REQUEST_ID = TR2.ID AND TR2.USER_ID = CR.ID and nvl(CR.is_terminated,' ') != 'TE' ";
	 
		log.debug("MailModuleUtil.getTemplateUsingConnOwners():sql:"+sql.toString());

		try {
			   
		       SqlRowSet rs =  jdbcTemplate.queryForRowSet(sql,new Object[] {inputMailVO.getTiProcess().getTiRequest().getId()});
			
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null) {
						ownerEmail = (String) rs.getString(1)	+ EMAIL_ADDRESS_SEPERATOR;
					
					}
				}
			}
		} catch (Exception e) {
			log.error(e,e);
		}  
	  
		log.debug("MailModuleUtil.getTemplateUsingConnOwners():ownerEmail:"+ownerEmail);
		log.debug("MailModuleUtil.getTemplateUsingConnOwners():Ends");
	  return ownerEmail;
  }
  
	 
	 // JDBCTemplate Refactored 
  public String getTemplateConnOwners(BaseMailVO mailVO){
	  log.debug("MailModuleUtil.getTemplateConnOwners():starts");
		InputMailVO inputMailVO =(InputMailVO)mailVO;
		String ownerEmail = "";
		StringBuffer sql = new StringBuffer();
		
		/*sql.append("SELECT DISTINCT CR.EMAIL FROM CON_FW_RULE CFR,CON_FW_RULE CFR2,TI_REQUEST TR,C3PAR_USERS CR   ");
		sql.append("WHERE CFR.TI_REQUEST_ID = ? AND CFR2.id = CFR.tmp_id AND TR.ID = CFR2.TI_REQUEST_ID AND TR.USER_ID = CR.ID  ");*/
		sql.append("SELECT DISTINCT CU.EMAIL FROM CON_FW_RULE CFR,CON_FW_RULE CFR2,TI_REQUEST TR,C3PAR_USERS CU  ");
		sql.append("WHERE CFR.TI_REQUEST_ID = ? AND CFR2.id = CFR.tmp_id AND TR.ID = CFR2.TI_REQUEST_ID AND TR.USER_ID = CU.ID and nvl(CU.is_terminated,' ') != 'TE' ");
		sql.append("UNION ");
		sql.append("SELECT  DISTINCT CU.EMAIL FROM CON_FW_RULE CFR,CON_FW_RULE CFR2,CON_FW_RULE_SOURCE_IP SIP,TI_REQUEST TR,C3PAR_USERS CU ");
		sql.append("WHERE CFR.TI_REQUEST_ID = ? AND SIP.rule_id = CFR.ID AND SIP.obj_rule_id = CFR2.id AND CFR2.ti_request_id = TR.id AND TR.user_id = CU.id and nvl(CU.is_terminated,' ') != 'TE' ");
		sql.append("UNION ");
		sql.append("SELECT DISTINCT CU.EMAIL FROM CON_FW_RULE CFR,CON_FW_RULE CFR2,CON_FW_RULE_DESTINATION_IP DIP,TI_REQUEST TR,C3PAR_USERS CU ");
		sql.append("WHERE CFR.TI_REQUEST_ID = ? AND DIP.rule_id = CFR.ID AND DIP.obj_rule_id = CFR2.id AND CFR2.ti_request_id = TR.id AND TR.user_id = CU.id and nvl(CU.is_terminated,' ') != 'TE' ");
		sql.append("UNION ");
		sql.append("SELECT DISTINCT CU.EMAIL FROM CON_FW_RULE CFR,CON_FW_RULE CFR2,CON_FW_RULE_PORT PORT,TI_REQUEST TR,C3PAR_USERS CU ");
		sql.append("WHERE CFR.TI_REQUEST_ID = ? AND PORT.rule_id = CFR.ID AND PORT.obj_rule_id = CFR2.id AND CFR2.ti_request_id = TR.id AND TR.user_id = CU.id and nvl(CU.is_terminated,' ') != 'TE' ");

		log.debug("MailModuleUtil.getTemplateConnOwners():sql: "+sql.toString());
		try {
			
			Long tiRequestid = inputMailVO.getTiProcess().getTiRequest().getId();

			 
		    SqlRowSet rs =  jdbcTemplate.queryForRowSet(sql.toString(),new Object[] {tiRequestid,tiRequestid,tiRequestid,tiRequestid});
			
			
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null) {
						ownerEmail += (String) rs.getString(1)
						+ EMAIL_ADDRESS_SEPERATOR;
					}
				}
			}
		} catch (Exception e) {
			log.error(e,e);
		}  
	  
		log.debug("MailModuleUtil.getTemplateConnOwners():ownerEmail:"+ownerEmail);
		log.debug("MailModuleUtil.getTemplateConnOwners():Ends");
	  return ownerEmail;
  }
  
 
  
//JDBCTemplate Refactored 
  public String  getTemplateConnPreOwner(BaseMailVO mailVO){
	  log.debug("MailModuleUtil.getTemplateConnPreOwner():starts");
	
		InputMailVO inputMailVO =(InputMailVO)mailVO;
		String ownerEmail = "";
		
		String sql = "SELECT CR.EMAIL FROM TI_REQUEST TR1,TI_REQUEST TR2,C3PAR_USERS CR  WHERE TR1.ID = ? AND TR2.PROCESS_ID = TR1.PROCESS_ID AND TR2.VERSION_NUMBER = (TR1.VERSION_NUMBER -1) AND CR.ID = TR2.USER_ID and nvl(CR.is_terminated,' ') != 'TE'";
		log.debug("MailModuleUtil.getTemplateConnPreOwner():sql:"+sql.toString());
		
		try {
			   
			
			   SqlRowSet rs =  jdbcTemplate.queryForRowSet(sql.toString(),new Object[] {inputMailVO.getTiProcess().getTiRequest().getId()});
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null) {
						ownerEmail = (String) rs.getString(1) + EMAIL_ADDRESS_SEPERATOR;
					}
				}
			}
		} catch (Exception e) {
			log.error(e,e);
		}   
		log.debug("MailModuleUtil.getTemplateConnPreOwner():ownerEmail:"+ownerEmail);
		log.debug("MailModuleUtil.getTemplateConnPreOwner():Ends");
	  return ownerEmail;
  }
  public Map<String,String> getTmpltConIdsAndNamesForUsedConn(Long tiReqId){
	  Map<String,String> templateUsedConnDtls = new HashMap<String,String>();
	  log.debug("MailModuleUtil.getTmpltConIdsAndNamesForUsedConn:starts");
	  SqlRowSet rs = null;
	   
		String connectionIds = "";
		String connectionNames = "";
		String owners = "";
		StringBuffer sql = new StringBuffer();
		/*sql.append("SELECT DISTINCT TP.ID,TP.PROCESS_NAME,CU.SSO_ID FROM CON_FW_RULE CFR1,CON_FW_RULE CFR2,TI_REQUEST TR,TI_PROCESS TP,C3PAR_USERS CU ");
		sql.append("WHERE CFR1.TI_REQUEST_ID = ? AND CFR1.TMP_ID = CFR2.ID  ");
		sql.append("AND CFR2.TI_REQUEST_ID = TR.ID AND TR.PROCESS_ID = TP.ID AND CU.ID = TR.USER_ID ");*/
		
		sql.append("SELECT DISTINCT TP.ID,TP.PROCESS_NAME,CU.SSO_ID  FROM CON_FW_RULE CFR,CON_FW_RULE CFR2,TI_REQUEST TR,TI_PROCESS TP,C3PAR_USERS CU  ");
		sql.append("WHERE CFR.TI_REQUEST_ID = ? AND CFR2.id = CFR.tmp_id AND TR.ID = CFR2.TI_REQUEST_ID AND TR.PROCESS_ID = TP.ID AND TR.USER_ID = CU.ID and nvl(CU.is_terminated,' ') != 'TE' ");
		sql.append("UNION ");
		sql.append("SELECT  DISTINCT TP.ID,TP.PROCESS_NAME,CU.SSO_ID  FROM CON_FW_RULE CFR,CON_FW_RULE CFR2,CON_FW_RULE_SOURCE_IP SIP,TI_REQUEST TR,TI_PROCESS TP,C3PAR_USERS CU ");
		sql.append("WHERE CFR.TI_REQUEST_ID = ? AND SIP.rule_id = CFR.ID AND SIP.obj_rule_id = CFR2.id AND CFR2.ti_request_id = TR.id AND TR.PROCESS_ID = TP.ID AND TR.user_id = CU.id and nvl(CU.is_terminated,' ') != 'TE' ");
		sql.append("UNION ");
		sql.append("SELECT DISTINCT TP.ID,TP.PROCESS_NAME,CU.SSO_ID  FROM CON_FW_RULE CFR,CON_FW_RULE CFR2,CON_FW_RULE_DESTINATION_IP DIP,TI_REQUEST TR,TI_PROCESS TP,C3PAR_USERS CU ");
		sql.append("WHERE CFR.TI_REQUEST_ID = ? AND DIP.rule_id = CFR.ID AND DIP.obj_rule_id = CFR2.id AND CFR2.ti_request_id = TR.id AND TR.PROCESS_ID = TP.ID AND TR.user_id = CU.id and nvl(CU.is_terminated,' ') != 'TE' ");
		sql.append("UNION ");
		sql.append("SELECT DISTINCT TP.ID,TP.PROCESS_NAME,CU.SSO_ID  FROM CON_FW_RULE CFR,CON_FW_RULE CFR2,CON_FW_RULE_PORT PORT,TI_REQUEST TR,TI_PROCESS TP,C3PAR_USERS CU ");
		sql.append("WHERE CFR.TI_REQUEST_ID = ? AND PORT.rule_id = CFR.ID AND PORT.obj_rule_id = CFR2.id AND CFR2.ti_request_id = TR.id AND TR.PROCESS_ID = TP.ID AND TR.user_id = CU.id and nvl(CU.is_terminated,' ') != 'TE' ");

		
		log.debug("MailModuleUtil.getTmpltUsedConnIdsAndNames():sql:"+sql.toString());

		try {
			rs =  jdbcTemplate.queryForRowSet(sql.toString(),new Object[] {tiReqId,tiReqId,tiReqId,tiReqId});
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null) {
						connectionIds += (String) rs.getString(1)
						+ EMAIL_ADDRESS_SEPERATOR;
					}
					if (rs.getString(2) != null) {
						connectionNames += (String) rs.getString(2)
						+ EMAIL_ADDRESS_SEPERATOR;
					}
					if (rs.getString(3) != null) {
						owners += (String) rs.getString(3)
						+ EMAIL_ADDRESS_SEPERATOR;
					}
				}
			}
		} catch (Exception e) {
			log.error(e,e);
		}  
		templateUsedConnDtls.put("TMP_CONN_IDS", (connectionIds.isEmpty()?"No Template Connection Ids" : connectionIds));
		templateUsedConnDtls.put("TMP_CONN_NAMES", (connectionNames.isEmpty()?"No Template Connection Names" : connectionNames));
		templateUsedConnDtls.put("TMP_CONN_OWNERS", (owners.isEmpty()?"No Template Owners" : owners));
	  
		log.debug("MailModuleUtil.getTmpltConIdsAndNamesForUsedConn:connectionIds:"+connectionIds+"\n:connectionNames:"+connectionNames
				+"\n Owners:"+owners);
		log.debug("MailModuleUtil.getTmpltConIdsAndNamesForUsedConn:Ends");
	  
	  return templateUsedConnDtls;
  }
  
  public Map<String,String> getTmpltUsedConnIdsAndNames(Long tiRequestID,String relationshipType){
	  Map<String,String> templateUsedConnDtls = new HashMap<String,String>();
	  log.debug("MailModuleUtil.getTmpltUsedConnIdsAndNames:starts");
	  SqlRowSet rs = null;
	   
		String connectionIds = "";
		String connectionNames = "";
		StringBuffer sql = new StringBuffer();
		if(relationshipType.equalsIgnoreCase(TEMPLATE)){
			sql.append("SELECT DISTINCT TP.ID,TP.PROCESS_NAME FROM TI_REQUEST TR,TI_PROCESS TP,CON_FW_RULE CFR");
			sql.append(" WHERE TP.ID = TR.PROCESS_ID AND TR.ID = CFR.TI_REQUEST_ID AND");
			sql.append(" CFR.TMP_ID in (select ID from CON_FW_RULE CFR where CFR.TI_REQUEST_ID = ? )");
		}else if(relationshipType.equalsIgnoreCase(IP_TEMPLATE)){
			sql.append("SELECT DISTINCT TP.ID,TP.PROCESS_NAME FROM TI_REQUEST TR,TI_PROCESS TP,CON_FW_RULE CFR,CON_FW_RULE_SOURCE_IP CFRS");
			sql.append(" WHERE TP.ID = TR.PROCESS_ID AND TR.ID = CFR.TI_REQUEST_ID AND CFR.ID = CFRS.RULE_ID AND");
			sql.append(" CFRS.OBJ_RULE_ID in (select ID from CON_FW_RULE CFR where CFR.TI_REQUEST_ID = ?)");
			sql.append("UNION ");
			sql.append("SELECT DISTINCT TP.ID,TP.PROCESS_NAME FROM TI_REQUEST TR,TI_PROCESS TP,CON_FW_RULE CFR,CON_FW_RULE_DESTINATION_IP CFRD");
			sql.append(" WHERE TP.ID = TR.PROCESS_ID AND TR.ID = CFR.TI_REQUEST_ID AND CFR.ID = CFRD.RULE_ID AND");
			sql.append(" CFRD.OBJ_RULE_ID in (select ID from CON_FW_RULE CFR where CFR.TI_REQUEST_ID = ?)");
		}else if(relationshipType.equalsIgnoreCase(PORT_TEMPLATE)){
			sql.append("SELECT DISTINCT TP.ID,TP.PROCESS_NAME FROM TI_REQUEST TR,TI_PROCESS TP,CON_FW_RULE CFR,CON_FW_RULE_PORT CFRP");
			sql.append(" WHERE TP.ID = TR.PROCESS_ID AND TR.ID = CFR.TI_REQUEST_ID AND CFR.ID = CFRP.RULE_ID AND");
			sql.append(" CFRP.OBJ_RULE_ID in (select ID from CON_FW_RULE CFR where CFR.TI_REQUEST_ID = ?)");
		}		
		
		log.debug("MailModuleUtil.getTmpltUsedConnIdsAndNames:sql:"+sql.toString());

		try {
			rs =  jdbcTemplate.queryForRowSet(sql.toString(),new Object[] {tiRequestID});
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null) {
						connectionIds+= (String) rs.getString(1)
						+ EMAIL_ADDRESS_SEPERATOR;
					}
					if (rs.getString(2) != null) {
						connectionNames+= (String) rs.getString(2)
						+ EMAIL_ADDRESS_SEPERATOR;
					}
				}
			}
		} catch (Exception e) {
			log.error(e,e);
		}  
		templateUsedConnDtls.put("CONN_IDS", (connectionIds.isEmpty()?"No Used Connection Ids" : connectionIds));
		templateUsedConnDtls.put("CONN_NAMES", (connectionNames.isEmpty()?"No Used Connection Names" : connectionNames));
	  
		log.debug("MailModuleUtil.getTmpltUsedConnIdsAndNames:connectionIds:"+connectionIds+"\n:connectionNames:"+connectionNames);
		log.debug("MailModuleUtil.getTmpltUsedConnIdsAndNames:Ends");
	  
	  return templateUsedConnDtls;
  }
  
  public Map<String,String> getTmpltAppNamesForUsedConn(Long tiReqId){
	  Map<String,String> templateUsedConnDtls = new HashMap<String,String>();
	  log.debug("MailModuleUtil.getgetTmpltAppNamesForUsedConn:starts");
	 
	 
		String templtAppNames = "";
		String sql = "SELECT DISTINCT TAPP.ID FROM CON_FW_RULE CFR1,CON_FW_RULE CFR2,CON_FW_RULE_APPLICATION CFRA,TI_APPLICATION TAPP WHERE CFR1.TI_REQUEST_ID = ? AND CFR1.ID = CFR2.ID AND CFR2.ID = CFRA.IP_ID AND CFRA.APPLICATION_ID = TAPP.ID";
		log.debug("MailModuleUtil.getgetTmpltAppNamesForUsedConn:sql:"+sql.toString());
		
		try {
		 		
			SqlRowSet	rs =  jdbcTemplate.queryForRowSet(sql.toString(),new Object[] {tiReqId});
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null) {
						templtAppNames += (String) rs.getString(1)
						+ EMAIL_ADDRESS_SEPERATOR;
					}
				}
			}
		} catch (Exception e) {
			log.error(e,e);
		}  
		templateUsedConnDtls.put("TMP_APP_NAMES", (templtAppNames.isEmpty()?"No Application Names" : templtAppNames));
		log.debug("MailModuleUtil.getTmpltAppNamesForUsedConn:connectionIds:"+templtAppNames);
		log.debug("MailModuleUtil.getTmpltAppNamesForUsedConn:Ends");
	  
	  return templateUsedConnDtls;
  }

  public String getCSIApplicationForConnection(Long conID){
	  	log.debug("MailModuleUtil.getApplicationNamesForConnection :: starts");
	 
	  	StringBuilder csiAppID = new StringBuilder();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT TAPP.APPLICATION_ID FROM CON_FW_RULE CFR,CON_FW_RULE_SOURCE_IP CFRS,CON_FW_RULE_APPLICATION CFRA,TI_APPLICATION TAPP"); 
		sql.append(" WHERE CFR.TI_REQUEST_ID = (select max(id) from ti_request where process_id = ? and is_deleted='N')");
		sql.append(" AND CFR.ID = CFRS.RULE_ID AND CFRS.IP_ID = CFRA.IP_ID AND CFRA.APPLICATION_ID = TAPP.ID AND TAPP.IS_CSI = 'Y' and CFRA.rule_id = cfr.id");
		sql.append(" UNION ");
		sql.append(" SELECT DISTINCT TAPP.APPLICATION_ID FROM CON_FW_RULE CFR,CON_FW_RULE_DESTINATION_IP CFRS,CON_FW_RULE_APPLICATION CFRA,TI_APPLICATION TAPP");
		sql.append(" WHERE CFR.TI_REQUEST_ID = (select max(id) from ti_request where process_id = ? and is_deleted='N')");
		sql.append(" AND CFR.ID = CFRS.RULE_ID AND CFRS.IP_ID = CFRA.IP_ID AND CFRA.APPLICATION_ID = TAPP.ID AND TAPP.IS_CSI = 'Y' and CFRA.rule_id = cfr.id");
		
		log.debug("MailModuleUtil.getApplicationNamesForConnection :: sql:"+sql.toString());
		
		try {
		 		
			SqlRowSet	rs =  jdbcTemplate.queryForRowSet(sql.toString(),new Object[] {conID,conID});
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null) {
						csiAppID.append((String) rs.getString(1)+ EMAIL_ADDRESS_SEPERATOR);
					}
				}
			}
		} catch (Exception e) {
			log.error(e,e);
		}  
		log.debug("MailModuleUtil.getApplicationNamesForConnection :: Ends");
	  
	  return csiAppID.length()==0?"No Application" : csiAppID.toString();
  }

  @Transactional(propagation = Propagation.REQUIRES_NEW, timeout=1200)
  public void mailActivityAudit(C3PARMailMessage mailMessageVO){
	  	log.debug("MailModuleUtil.mailActivityAudit():starts");
	   
	 
		Connection con = null; 
		long id = 0, tiRequestID = 0;
		
		String sql = "INSERT INTO C3PAR.TI_MAIL_AUDIT(ID,TI_REQUEST_ID,TEMPLATE_ID,TO_LIST,CC_LIST,BCC_LIST,DONOTSEND_LIST,MAIL_SUBJECT,MAIL_BODY,EMAIL_REFERENCE_NO,CMP_ID,CREATED_DATE) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE)";
		byte[] mailContent = mailMessageVO.getMsgContent().getBytes();
		PreparedStatement stmt = null;
		

		try {
			id = getSequenceNextVal("SEQ_TI_MAIL_AUDIT");
			
			if(mailMessageVO.getTiRequestID() != null)
				tiRequestID = mailMessageVO.getTiRequestID().longValue();
			
			con =    DataSourceUtils.getConnection(dataSource);   
			/*BLOB blob = oracle.sql.BLOB.createTemporary(con, false,oracle.sql.BLOB.DURATION_SESSION);*/
			

			String mailContentString = new String(mailContent);
			/*Reader r = new StringReader(mailContentString);
			;*/
			//stmt.setCharacterStream(2, r, mailContent.length);

	 
			/*int totabytes = blob.setBytes(1, mailContent); 
			
			stmt = con.prepareStatement(sql);
			log.debug ("Blob Length: " +	blob.length());*/
			stmt = con.prepareStatement(sql);
			stmt.setLong(1, id);
			if(tiRequestID == 0){
				stmt.setObject(2, null);
			}else{
				stmt.setLong(2, tiRequestID);				
			}
			stmt.setString(3, mailMessageVO.getTemplateID());
			stmt.setString(4, mailMessageVO.getToAddresses());
			stmt.setString(5, mailMessageVO.getCcAddresses());
			stmt.setString(6, mailMessageVO.getBccAddresses());
			stmt.setString(7, mailMessageVO.getDoNotSendList());
			stmt.setString(8, mailMessageVO.getMsgSubject());    
			stmt.setBinaryStream(9, IOUtils.toInputStream(mailContentString, "UTF-8"),mailContent.length);
			stmt.setString(10, mailMessageVO.getReferenceNo());	
			if(mailMessageVO.getCmpRequestId() == null || mailMessageVO.getCmpRequestId().longValue() <= 0){
				stmt.setObject(11, null);
			}else{
				stmt.setLong(11, mailMessageVO.getCmpRequestId());			
			}
			
			stmt.executeUpdate();
		//	int rows = jdbcTemplate.update(sql, new Object[] {id,tiRequestID,mailMessageVO.getTemplateID(),mailMessageVO.getToAddresses(),mailMessageVO.getCcAddresses(),mailMessageVO.getBccAddresses(),mailMessageVO.getMsgSubject(),blob});
			log.debug("MailModuleUtil.mailActivityAudit() :ToAddress after audit"+mailMessageVO.getToAddresses());
			log.debug("MailModuleUtil.mailActivityAudit() :CCAddress after audit" +mailMessageVO.getCcAddresses());
			log.debug("MailModuleUtil.mailActivityAudit() :BCCAddress after audit"+mailMessageVO.getBccAddresses());
			
			log.debug("MailModuleUtil.mailActivityAudit(): ID ==> " +id+ " inserted rows ==> ");

		} catch (Exception e) {
			log.error(e,e);
		}    
			finally {
				JdbcUtils.closeStatement(stmt);
				DataSourceUtils.releaseConnection(con, dataSource);
			}
		log.debug("MailModuleUtil.mailActivityAudit():Ends");

}

  
  /**
   * Gets the sequence next val.
   *
   * @param dbSequenceName the db sequence name
   * @param c3parSession the c3par session
   * @return the sequence next val
   * @throws Exception the exception
   */
  private  long getSequenceNextVal(String dbSequenceName) throws Exception {
 	 
	long id = 0;

	if (dbSequenceName != null) {
	 
		try {
			SqlRowSet rs =  jdbcTemplate.queryForRowSet("Select " + dbSequenceName + ".nextval from dual");
		if (rs.next()) {
		    id = rs.getLong(1);
		}
		} catch (Exception xe) {}
	}
	return id;
  }



 

/**
 * Gets the element text value.
 *
 * @param templateElement the template element
 * @param elementTagName the element tag name
 * @param isMandatory the is mandatory
 * @return the element text value
 * @throws MailModuleException the mail module exception
 */
private String getElementTextValue (Element templateElement, String elementTagName, boolean isMandatory) throws MailModuleException {
	String returnStr="";
	//	log.debug("MailModule:MailModuleImpl:getElementTextValue:: Entered for "+elementTagName);
	NodeList nodeList = templateElement.getElementsByTagName(elementTagName);
	if(isMandatory && (nodeList == null || nodeList.getLength() == 0)){
		throw new MailModuleException("The Template MUST have the tag::"+elementTagName);
	} else if(nodeList != null && nodeList.getLength() != 0) {
		Element element = (Element)nodeList.item(0);
		NodeList textList = element.getChildNodes();
		if(textList.item(0) != null){
			returnStr = ((Node)textList.item(0)).getNodeValue().trim();
		}
	}
	//   log.debug("MailModule:MailModuleImpl:getElementTextValue:: Exited with "+returnStr);
	return returnStr;
}


/**
 * Validate mail vo.
 *
 * @param doc the doc
 * @param mailVO the mail vo
 * @return true, if successful
 * @throws MailModuleException the mail module exception
 */
private boolean validateMailVO(Document doc, BaseMailVO mailVO) throws MailModuleException{
	boolean retVal = true;
	//	log.debug("MailModule:MailModuleImpl:validateMailVO:: Entered");
	NodeList listOfSQLParams = doc.getElementsByTagName(ELEMENT_SQLPARAM);
	for (int s = 0; s < listOfSQLParams.getLength(); s++) {

		Node sqlParamNode = listOfSQLParams.item(s);
		if(sqlParamNode.getNodeType() == Node.ELEMENT_NODE){
			Element sqlParamElement = (Element)sqlParamNode;
			NodeList textsqlParamList = sqlParamElement.getChildNodes();
			if(textsqlParamList != null && textsqlParamList.getLength()!=0){
				String sqlParam = ((Node)textsqlParamList.item(0)).getNodeValue().trim();
				String sqlParamTextVal="";
				log.debug("MailModule:MailModuleImpl:validateMailVO:: Checking for variable "+sqlParam);
				try{
					Object obj=PropertyUtils.getProperty(mailVO,  sqlParam);
					if(obj != null){
						if (obj.getClass().isInstance(Long.valueOf("0"))) {
							sqlParamTextVal=((Long)obj).toString();
						} else {
							sqlParamTextVal=(String)obj;
						}
					}
					//sqlParamTextVal= (String)PropertyUtils.getProperty(mailVO, sqlParam);
					if(sqlParamTextVal==null || "".equals(sqlParamTextVal)){
						throw new MailModuleException("The mandatory SQL Parameter \""+sqlParam+"\" is null or blank in the input object");
					}
				}catch(MailModuleException ex){
					throw ex;
				}catch (Exception e){
					if(!(e instanceof MailModuleException))
						throw new MailModuleException("The mandatory SQL Parameter \""+sqlParam+"\" mentioned in the template is not present in the input mailVO object");
				}
			}
		}
	}
	//    log.debug("MailModule:MailModuleImpl:validateMailVO:: Exited");
	return retVal;
}




/**
 * Search vars and replace values.
 *
 * @param strTobeReplaced the str tobe replaced
 * @param mailVO the mail vo
 * @return the string
 */
private String searchVarsAndReplaceValues(String strTobeReplaced, BaseMailVO mailVO){
	//	log.debug("MailModule:MailModuleImpl:searchVarsAndReplaceValues:: Entered");
	String replacedStr="";
	try{
		if(strTobeReplaced != null && !"".equals(strTobeReplaced)){
			Pattern myPattern = Pattern.compile(TEMPLATE_VAR_PATTERN_REGEX, Pattern.MULTILINE);
			Matcher m = myPattern.matcher(strTobeReplaced);
			List vars = new ArrayList();
			while(m.find()){
				vars.add((m.group(0)).substring(2,  m.group(0).length() -2));
			}
			String[] str= myPattern.split(strTobeReplaced);
			String varValues[];
			varValues = new String[vars.size()];
			for (int x = 0; x < vars.size(); x++) {
				Object obj=PropertyUtils.getProperty(mailVO, (String)vars.get(x));
				if(obj != null){
					if (obj.getClass().isInstance(Long.valueOf("0"))) {
						varValues[x]=((Long)obj).toString();
					} else if(obj.getClass().isInstance(new Integer(0))) {
						varValues[x] = ((Integer)obj).toString();
					}else if(obj.getClass().isInstance(new Date())){
						DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
						Date date = (Date) obj;
						varValues[x] = df.format(date);
					} else if(obj.getClass().isInstance(new java.sql.Date(0))){
						DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
						Date date = (java.sql.Date) obj;
						varValues[x] = df.format(date);
					} else if(obj.getClass().isInstance(new java.sql.Timestamp(0))){
						DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
						Date date = (java.sql.Timestamp) obj;
						varValues[x] = df.format(date);
					} else{
						varValues[x] = (String) obj;
					}
				} else {
					varValues[x] = null;
				}
			}
			StringBuffer buf = new StringBuffer();
			if (str.length != 0) {
				for (int i = 0; i < str.length; i++) {
					buf.append(str[i]);
					if (i < varValues.length)
						buf.append(varValues[i]);
				}
			} else if (varValues.length != 0) {
				buf.append(varValues[0]);
			}
			if(buf.toString() != null && !(buf.toString().equalsIgnoreCase("null"))){
				replacedStr = buf.toString();
			}else{
				replacedStr	= "";
			}

		}
	} catch (Exception e){
		log.error(e,e);
	}
	//	log.debug("MailModule:MailModuleImpl:searchVarsAndReplaceValues:: Exited");
	return replacedStr;
}

/**
 * Populate row.
 *
 * @param templateElement the template element
 * @param mailVO the mail vo
 * @return the mail msg display row[]
 * @throws MailModuleException the mail module exception
 */
private MailMsgDisplayRow[] populateRow(Element templateElement, BaseMailVO mailVO) throws MailModuleException{
	//log.debug("MailModule:MailModuleImpl:populateInfo:: Entered");
	MailMsgDisplayRow[] rows = null;
	NodeList listOfRows = templateElement.getElementsByTagName(ELEMENT_ROW);
	rows = new MailMsgDisplayRow[listOfRows.getLength()];
	for (int s1 = 0; s1 < listOfRows.getLength(); s1++) {
		rows[s1] = new MailMsgDisplayRow();
		Node infoNode = listOfRows.item(s1);
		if(infoNode.getNodeType() == Node.ELEMENT_NODE){
			Element rowElement = (Element)infoNode;
			rows[s1].setInfo(populateInfo(rowElement, mailVO));
		}
	}
	//log.debug("MailModule:MailModuleImpl:populateInfo:: Exited");
	return rows;
}



/**
 * Populate info.
 *
 * @param templateElement the template element
 * @param mailVO the mail vo
 * @return the mail msg display info[]
 * @throws MailModuleException the mail module exception
 */
private MailMsgDisplayInfo[] populateInfo(Element templateElement, BaseMailVO mailVO) throws MailModuleException{
	//log.debug("MailModule:MailModuleImpl:populateInfo:: Entered");
MailMsgDisplayInfo[] infos = null;
NodeList listOfInfos = templateElement.getElementsByTagName(ELEMENT_INFO);
infos=new MailMsgDisplayInfo[listOfInfos.getLength()];
//log.debug("MailModule:MailModuleImpl:populateInfo:ListOfInfos:"+listOfInfos.getLength());
for (int s1 = 0; s1 < listOfInfos.getLength(); s1++) {
	infos[s1] = new MailMsgDisplayInfo();
	Node infoNode = listOfInfos.item(s1);
	if(infoNode!= null && infoNode.getNodeType() == Node.ELEMENT_NODE){
		Element infoElement = (Element)infoNode;
		NodeList infoChildList = infoElement.getChildNodes();
		//log.debug("MailModule:MailModuleImpl:populateInfo:infoChildListLength:"+infoChildList.getLength());
		if(infoChildList != null){
			for (int i = 0; i < infoChildList.getLength(); i++) {
				Node infoChildNode = infoChildList.item(i);
				//log.debug("MailModule:MailModuleImpl:populateInfo:infoNodeType:"+infoChildNode.getNodeType());
				/*System.out.println("MailModule:MailModuleImpl:populateInfo:infoNodeType:"+infoChildNode.getNodeType());*/
				if(infoChildNode != null && infoChildNode.getNodeType() == Node.ELEMENT_NODE){
					Element infoChildElement = (Element)infoChildNode;
					NodeList infoChldList = infoChildElement.getChildNodes();
					/*System.out.println("MailModuleImpl.populateinfo.infoChldList::"+infoChldList
							+"infoChldList.item(0):"+infoChldList.item(0));*/
					if(infoChldList != null && infoChldList.item(0)!= null){
						String infoLabel = ((Node)infoChldList.item(0)).getNodeValue().trim();
						/*System.out.println("MailModuleImpl.populateinfo.infoLabel::"+infoLabel);*/
						String returninfoStr = searchVarsAndReplaceValues(infoLabel, mailVO);
						//log.debug("MailModule:MailModuleImpl:populateInfo:returninfoStr:"+returninfoStr);
						if (i == 1) {
							infos[s1].setLabel(returninfoStr);
						} else {
							infos[s1].setValue(returninfoStr);
						}
					}
				}
			}
		}
	}
}
    //log.debug("MailModule:MailModuleImpl:populateInfo:: Exited");
return infos;
}


//get user role email - both Primary and Secondary contacts and considering Notify flag
public String getUserRoleEmailOfPrimaryAndSecondary(String connectionRequestId, String userRole, String testMode) {
      log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: Entered");
      // String sql =
      // "select distinct cc.EMAIL,cc.SSO_ID from con_req_citi_contact_xref ccx,role rr,citi_contact cc where ccx.request_id = "+connectionRequestId+" and ccx.role_id=rr.id and rr.name = '"+userRole+"' and ccx.citi_contact_id = cc.id"
      // ;
      String sql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from ti_request_planning_xref trpx, ti_request tr, con_req_citi_contact_xref crccx,planning p,citi_contact cc,role rr where tr.process_id = "
                  + connectionRequestId
                  + " and trpx.ti_request_id = tr.id and tr.id = (select max(id) from ti_request where process_id = "
                  + connectionRequestId
                  + " ) and trpx.planning_id = p.id and crccx.request_id = p.id and crccx.citi_contact_id = cc.id and cc.id  not in (select CITI_CONTACT_ID from DO_NOT_SEND_LIST where is_deleted !='Y' and CITI_CONTACT_ID is not null) and crccx.role_id=rr.id and crccx.notify_contact = 'Y' and rr.name = '"
                  + userRole + "'";
      String non3rdPartysql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from ti_request_planning_xref trpx, ti_request tr, CON_REQ_CIT_RQCON_XREF crcrx,planning p,citi_contact cc,role rr where tr.process_id = "
                  + connectionRequestId
                  + " and trpx.ti_request_id = tr.id and tr.id = (select max(id) from ti_request where process_id = "
                  + connectionRequestId
                  + " ) and trpx.planning_id = p.id and crcrx.request_id = p.id and crcrx.citi_contact_id = cc.id and cc.id  not in (select CITI_CONTACT_ID from DO_NOT_SEND_LIST where is_deleted !='Y' and CITI_CONTACT_ID is not null) and crcrx.role_id=rr.id and crcrx.notify_contact = 'Y' and rr.name = '"
                  + userRole + "'";
      String ipsql = "select distinct cc.EMAIL,cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME from c3par_process_role_xref cprx, ti_process tp, role rr, citi_contact cc where tp.id ="
                  + connectionRequestId
                  + " and tp.process_type_id=2 and tp.id=cprx.process_id and cprx.role_id=rr.id and rr.name = '"
                  + userRole
                  + "' and cprx.citi_contact_id=cc.id and cc.id  not in (select CITI_CONTACT_ID from DO_NOT_SEND_LIST where is_deleted !='Y' and CITI_CONTACT_ID is not null) and cprx.is_active = 'Y'";
      /*
      * select distinct cc.EMAIL,cc.SSO_ID from c3par_process_role_xref cprx,
      * ti_process tp,ti_request tr, role rr, citi_contact cc where tr.id =
      * 2457 and tp.id=tr.process_id and tp.process_type_id=2 and
      * tp.id=cprx.process_id and cprx.role_id=rr.id and rr.name = 'DESIGN
      * ENGINEER' and cprx.citi_contact_id=cc.id
      */
      String finalsql = sql + " union " + non3rdPartysql + " union " + ipsql;
      Map data = new HashMap();
      String userRoleEmail = "";
      List dataList = null;
      log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: SQL:: "  + finalsql);
      try {
            data = runQuery(finalsql, 4, "SELECT",   false);
      } catch (Exception e) {
            log.error(e,e);
      }
      int counter = 1;
      if (data != null && data.size() > 0) {
            while (counter <= data.size()) {
                  dataList = (ArrayList) data.get(Integer.valueOf(counter));
                  if (dataList != null && dataList.size() > 0) {
                        if("".equals(userRoleEmail)){
                              if("true".equalsIgnoreCase(testMode)){
                                    userRoleEmail = (String) dataList.get(1)
                                                + EMAIL_ADDRESS_SEPERATOR;
                              }else if("names".equalsIgnoreCase(testMode)){
                                    userRoleEmail = (String) dataList.get(2) + " " +(String) dataList.get(3)
                                                + " , ";
                              } else {
                                    userRoleEmail = (String) dataList.get(0)
                                                + EMAIL_ADDRESS_SEPERATOR;
                              }
                        } else {
                              if("true".equalsIgnoreCase(testMode)){
                                    userRoleEmail = userRoleEmail
                                                + (String) dataList.get(1)
                                                + EMAIL_ADDRESS_SEPERATOR;
                              }else if("names".equalsIgnoreCase(testMode)){
                                    userRoleEmail = userRoleEmail
                                                + (String) dataList.get(2) + " " +(String) dataList.get(3)
                                                + " , ";
                              } else {
                                    userRoleEmail = userRoleEmail
                                                + (String) dataList.get(0)
                                                + EMAIL_ADDRESS_SEPERATOR;
                              }
                        }
                  }
                  counter = counter + 1;
            }
      } else {
            log.error("There is no contact specified with Role \"" + userRole
                        + "\" in the connection id " + connectionRequestId);
      }
      log.debug("MailModule:MailModuleUtil:getUserRoleEmail:: Exited");
      return userRoleEmail;
}

	public String getMailTemplates(){
	  	log.debug("MailModuleUtil.getMailTemplates():starts");   
	 
		Connection con = null; 		
		String sql = "select FILE_TEXT from c3par.CCR_Reference_Files where FILE_NAME = 'MailTemplate.xml'";		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String templateXML = "";
		try {
			con = DataSourceUtils.getConnection(dataSource);   
			stmt = con.prepareStatement(sql);			
			rs = stmt.executeQuery();
			while (rs.next())
		    {
		    	Clob data = rs.getClob(1);
		    	log.debug("MailModuleUtil.getMailTemplates(): reading Data........");
		    	if(data != null && data.length() > 0){
		    		
		    		templateXML = data.getSubString(1, (int) data.length());
			    	log.debug("MailModuleUtil.getMailTemplates(): read Data completed ........");
		    	}
		    }
		} catch (Exception e) {
			log.error(e,e);
		}    
		finally {
			JdbcUtils.closeResultSet(rs);
			JdbcUtils.closeStatement(stmt);
			DataSourceUtils.releaseConnection(con, dataSource);
		}
		log.debug("MailModuleUtil.getMailTemplates():Ends");
		
		return templateXML;
	}
	
public MailTemplates getMailTemplateById(String templateId){
	  	
		log.info("MailModuleUtil.getMailTemplates():starts");   
	 
		Connection con = null; 		
		String sql = "select subject,body,template_id, TO_USER_ROLE, TO_OWNER, TO_ROLE, CC, CC_USER_ROLE,CC_OWNER, "
				+ "CC_ROLE,BCC, FROM_ADR, FOOT_NOTE from c3par.mail_templates where template_id = ?";
		
		
		MailTemplates xslTemplateText = jdbcTemplate.queryForObject(sql,  new Object[]{templateId},
        new RowMapper<MailTemplates>() {
            public MailTemplates mapRow(ResultSet rs, int rowNum) throws SQLException {
            	MailTemplates template = new MailTemplates();
                template.setSubject(rs.getString("subject"));
                template.setBody(rs.getString("body"));
                template.setTemplate_id(rs.getString("template_id"));
                template.setToUserRole(rs.getString("TO_USER_ROLE"));
                template.setToOwner(rs.getString("TO_OWNER"));
                template.setToRole(rs.getString("TO_ROLE"));
                template.setCc(rs.getString("CC"));
                template.setCcUserRole(rs.getString("CC_USER_ROLE"));
                template.setCcOwner(rs.getString("CC_OWNER"));
                template.setCcRole(rs.getString("CC_ROLE"));
                template.setBcc(rs.getString("BCC"));
                template.setFromAdr(rs.getString("FROM_ADR"));
                template.setFootNote(rs.getString("FOOT_NOTE"));
                return template;
            }
        });
		
		log.info("xslTemplateText ---->"+xslTemplateText.getSubject());   
		return xslTemplateText;
	}
	
	
	public List<MailTemplates> getAllMailTemplates(){
		log.info("MailModuleUtil.getMailTemplates():starts");   
		 
		Connection con = null; 		
		String sql = "select subject,body,template_id, updated_date,updated_by  from c3par.mail_templates";
		
		
		List<MailTemplates> mailTemplates = jdbcTemplate.query(sql,		
        new RowMapper<MailTemplates>() {
            public MailTemplates mapRow(ResultSet rs, int rowNum) throws SQLException {
            	MailTemplates template = new MailTemplates();
                template.setSubject(rs.getString("subject"));
                template.setBody(rs.getString("body"));
                template.setTemplate_id(rs.getString("template_id"));
                template.setLastUpdatedDate(rs.getTimestamp("updated_date"));
                template.setLastUpdatedBy(rs.getString("updated_by"));
                return template;
            }
        });
		
		log.info("MailTemplates count---->"+mailTemplates.size());   
		return mailTemplates;
	}
	
	public void updateMailTemplate(final String templateId, final String body, final String subject, final String updatedBySSOID){
	  	
		log.info("*******MailModuleUtil.updateMailTemplateById():starts");
		final StringReader clob = new StringReader(body); 
		String sql = "update c3par.mail_templates set body=?, updated_by=?, subject=?, updated_date=? where template_id = ?";
		
		jdbcTemplate.update(sql,  new PreparedStatementSetter() {
		      public void setValues(PreparedStatement ps) throws SQLException {
		          ps.setCharacterStream(1, clob, body.length());
		          ps.setString(2, updatedBySSOID);
		          ps.setString(3, subject);
		          ps.setTimestamp(4, getCurrentTimeStamp());
		          ps.setString(5, templateId);
		          
		        }
		      });
		log.info("MailModuleUtil.updateMailTemplateById():ends");
		
	}

	private static java.sql.Timestamp getCurrentTimeStamp() {

		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());

	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public String testModeFlag(Long process_id,String testMode)
	{
		if("false".equals(testMode))
		{
			String str  = "select decode(count(1),0,'Y','N') from email_notification where process_id=? and notification_required='N'";
			String flag =  (String)jdbcTemplate.queryForObject(str, new Object[]{process_id},String.class);
			if("Y".equals(flag))
			{
				return "false";
			}else{
				return "true";
			}
		}else{
			return testMode;
		}
		
	}




	public TargetContactEmail getConnDetails(TIRequest tiReq, final TargetContactEmail tarEmail) {
		
		log.info("Into MailModuleUtil : getConnDetails method");
		
		StringBuilder query = new StringBuilder();
		query.append("SELECT DISTINCT CR.RATIONALE JUSTIFICATION,");
		query.append("PRIOR_GL.VALUE1 PRIORITY,");
		query.append("REG.NAME REGION,");
		query.append("SEC.NAME SECTOR,");
		query.append("BU.BUSINESS_NAME BUSUNIT,");
		query.append("NVL(TIREQ.CMP_ID,'NONE') CMP_ID,");
		query.append("USR.SSO_ID REQ ,");
		query.append("TP.PROCESS_NAME CONNECTIONNAME ");
		query.append("FROM C3PAR.TI_REQUEST TIREQ,");
		query.append("C3PAR.REL_CITI_HIERARCHY_XREF RELXREF,");
		query.append("C3PAR.CITI_HIERARCHY_MASTER CITIMASTER,");
		query.append("C3PAR.REGION REG,");
		query.append("C3PAR.SECTOR SEC,");
		query.append("C3PAR_USERS USR,");
		query.append("CON_REQ CR,");
		query.append("C3PAR.GENERIC_LOOKUP PRIOR_GL,");
		query.append("C3PAR.BUSINESS_UNIT BU,");
		query.append("C3PAR.RELATIONSHIP REL,");
		query.append("TI_PROCESS TP,");
		query.append("TI_REQUEST_PLANNING_XREF X ");
		query.append("WHERE CR.ID                       =X.PLANNING_ID ");
		query.append("AND X.TI_REQUEST_ID               =TIREQ.ID ");
		query.append("AND CR.RELATIONSHIP_ID            = REL.ID ");
		query.append("AND RELXREF.RELATIONSHIP_ID = REL.ID ");
		query.append("AND CITIMASTER.ID = RELXREF.CITI_HIERARCHY_MASTER_ID ");
		query.append("AND CITIMASTER.REGION_ID = REG.ID  ");
		query.append("AND CITIMASTER.SECTOR_ID = SEC.ID ");
		query.append("AND CITIMASTER.BU_ID = BU.ID ");
		query.append("AND TIREQ.PROCESS_ID              = TP.ID ");
		query.append("AND TIREQ.PRIORITY_ID             =PRIOR_GL.ID(+) ");
		query.append("AND TIREQ.USER_ID                 =USR.ID(+) ");
		query.append("AND TIREQ.ID                      = ? ");
		
		
		/*TargetContactEmail xslTemplateText = jdbcTemplate.queryForObject(query.toString(), new Object[]{tiReq.getId()},
		        new RowMapper<TargetContactEmail>() {
		            public TargetContactEmail mapRow(ResultSet rs, int rowNum) throws SQLException {
		                tarEmail.setRegion(rs.getString("region"));
		                tarEmail.setSector(rs.getString("sector"));
		                tarEmail.setRequestor(rs.getString("req"));
		                tarEmail.setPriority(rs.getString("priority"));
		                tarEmail.setBusUnit(rs.getString("busUnit"));
		                tarEmail.setCmpId(rs.getString("cmp_id"));
		                tarEmail.setJustification(rs.getString("justification"));
		                //tarEmail.setJustification("");
		                tarEmail.setDesc(rs.getString("connectionname"));
		                return tarEmail;
		            }
		        });*/
		StringBuilder reg = new StringBuilder();
		SqlRowSet rs = jdbcTemplate.queryForRowSet(query.toString(), new Object[]{tiReq.getId()});
		int i = 0;
		while(rs.next()){
			if(i > 0) {
				reg.append(",");
	    	}
			i++;
			reg.append(rs.getString("region"));
			tarEmail.setRegion(reg.toString());
			log.debug("Region List"+reg+"+++"+tarEmail.getRegion());
			tarEmail.setSector(rs.getString("sector"));
            tarEmail.setRequestor(rs.getString("req"));
            tarEmail.setPriority(rs.getString("priority"));
            tarEmail.setBusUnit(rs.getString("busUnit"));
            tarEmail.setCmpId(rs.getString("cmp_id"));
            tarEmail.setJustification(rs.getString("justification"));
            tarEmail.setDesc(rs.getString("connectionname"));
          }
		
		log.info("End MailModuleUtil : getConnDetails method");
		return tarEmail;
		
		
	}

	/**
	 * 
	 * @param connId
	 * @return
	 */
	//If the special instruction for proxy contains the DL add it to the implemetation mail list
	public String getAdditionalMailForProxy(String connId) {
		
		log.info("Into MailModuleUtil : getAdditionalMailForProxy method");
		
		String str  = "select case when SPLINSTR_PROXY like '%*CTI GLOBAL CyberSecOps Proxy Service Delivery%' then 1 else 2 end from con_req where id=? ";
			String flag =  (String)jdbcTemplate.queryForObject(str, new Object[]{connId},String.class);
			if("1".equals(flag))
			{
				return PROXY_CONNECTION_DL;
			}else{
				return "";
			}
		
	}
	
	/*
	 * This is the method to retrieve the emailId's of DO_NOT_SEND_EMAIL
	 * nc43495
	 * 
	 */
	public Set getEmailAddressFromDoNotSendList(String testMode){
		log.info("MailModuleImpl : Inside getEmailAddressFromDoNotSendList method starts here...");
		
		String modifiedQuery = "select generic_lookup.value1 from generic_lookup where DEFINITION_ID in (select id from GENERIC_LOOKUP_DEFS where name ='DO_NOT_SEND_LIST_MODIFIED')";
		String flag =  (String)jdbcTemplate.queryForObject(modifiedQuery,String.class);
		
		log.debug("update query:Modified"+flag);

		if(flag.equalsIgnoreCase("Y") || doNotSendEmailList == null || doNotSendEmailList.isEmpty()) {
			doNotSendEmailList = new HashSet();
			String query = "select upper(citi.email) from citi_contact citi,do_not_send_list dlist where dlist.citi_contact_id = citi.id and dlist.is_deleted != 'Y'" ;
			//If we point ot test mode , we compare with SSOID otherwise we compare with emailID
			if(testMode.equalsIgnoreCase("true")){
				 query = "select upper(citi.sso_id) from citi_contact citi,do_not_send_list dlist where dlist.citi_contact_id = citi.id and dlist.is_deleted != 'Y'" ;
			}
			SqlRowSet rs = jdbcTemplate.queryForRowSet (query);
			while(rs.next()){
				doNotSendEmailList.add(rs.getString(1));
			}
			//update flag after retreival
			String updateQuery = "update generic_lookup set GENERIC_LOOKUP.VALUE1 = 'N' where DEFINITION_ID in (select id from GENERIC_LOOKUP_DEFS where name ='DO_NOT_SEND_LIST_MODIFIED')";
			jdbcTemplate.update(updateQuery);
			log.debug("update on generic lookup for do no send list modified:"+updateQuery);
			
		}else{
			return doNotSendEmailList;
		}
		
		log.debug("MailModuleImpl : Inside getEmailAddressFromDoNotSendList method ends here...");
		return doNotSendEmailList;
		
	}
	
	public Set getEmailAddressFromDoNotSendListCSI(){
        
        log.debug("MailModuleImpl : Inside getEmailAddressFromDoNotSendListCSI method starts here...");
        Set <String> doNotSendEmailList_emailIds = new HashSet();
        log.debug("doNotSendEmailList_emailIds declared" + doNotSendEmailList_emailIds + doNotSendEmailList_emailIds.size());
        if(doNotSendEmailList_emailIds == null || doNotSendEmailList_emailIds.isEmpty()) {
                        String query="select upper(citi.email) from citi_contact citi,do_not_send_list dlist where dlist.citi_contact_id = citi.id and dlist.is_deleted != 'Y'" ;;
                        SqlRowSet rs = jdbcTemplate.queryForRowSet (query);
                        while(rs.next()){
                                        doNotSendEmailList_emailIds.add(rs.getString(1));
                        }
                        log.debug("doNotSendEmailList_emailIds inside if ");
        }
        log.debug("MailModuleImpl : Inside getEmailAddressFromDoNotSendList method ends here..."+doNotSendEmailList_emailIds);
        return doNotSendEmailList_emailIds;
        
}

	 
	public CitiContact getContactDetailsBySSOId(final String ssoId){
		log.debug("Entering MailModuleImpl getContactDetailsBySSOId.");
		CitiContact citiContact = null;
			try {
				log.debug("getContactDetailsBySSOId :: ssoId"+ssoId.toUpperCase().trim());
				String sql = "select sso_id, first_name, last_name, email from Citi_Contact where upper(sso_id) = ?";
				log.debug("Printing Sql Query"+sql);
				citiContact = jdbcTemplate.query(sql,
						new PreparedStatementSetter() {
							@Override
							public void setValues(PreparedStatement preparedStatement) throws
							SQLException {
								preparedStatement.setString(1, ssoId.toUpperCase().trim());
							} 
						}, 
						new ResultSetExtractor<CitiContact>() {
							@Override
							public CitiContact extractData(ResultSet resultSet) throws SQLException,
							DataAccessException {
								CitiContact contactRecord = new CitiContact();
								if (resultSet.next()) {
									contactRecord.setSsoId(resultSet.getString(1));
									contactRecord.setFirstName(resultSet.getString(2));
									contactRecord.setLastName(resultSet.getString(3));
									contactRecord.setEmail(resultSet.getString(4));
									return contactRecord;
								}
								return null;
							}
						});
			} catch (DataAccessException e) {
				log.error("Error occured data access.",e);
			}
			log.debug("Size and contact list:"+citiContact);
			log.debug("Exiting MailModuleImpl getContactDetailsBySSOId.");
			return citiContact;
	}
	
	public String getLockedBy(Long tiReq){
		log.info("MailModuleUtil getLockedByUser"+tiReq);
		String gisUserEmail="";
		StringBuilder sql = new StringBuilder();
		sql.append("select usr.email from ti_activity_trail tat ");
		sql.append(" join ti_task_type task on tat.activity_id = task.id ");
		sql.append(" join c3par_users usr on usr.id = tat.lockedby ");
		sql.append(" where tat.ti_request_id = ? ");
		sql.append(" and task.TASK_CODE = 'otrm_app' order by tat.id desc");
		SqlRowSet rs = jdbcTemplate.queryForRowSet (sql.toString(),new Object[]{tiReq});
		while(rs.next()){
			gisUserEmail = rs.getString(1);
		}
		log.debug("GIS Locked user"+gisUserEmail);
		
		return gisUserEmail;	
	}
	
	public String getRisoMailId(){
		log.info("Inside MailModuleUtil getRisoMailId");
		String risoMailId="";
		String environment="";
		StringBuilder sql_env = new StringBuilder();
		StringBuilder sql_riso = new StringBuilder();
		sql_env.append("SELECT KEY_VALUE FROM SERVER_CONSTANTS WHERE KEY_NAME= 'ENVIRONMENT'");
		environment = jdbcTemplate.queryForObject(sql_env.toString(), String.class);
		log.debug("environment : "+environment);
		sql_riso.append(" SELECT KEY_VALUE FROM SERVER_CONSTANTS WHERE KEY_NAME='RISO_ADDITIONAL_CONTACTS' AND KEY_ENV='").append(environment).append("'");
		risoMailId = jdbcTemplate.queryForObject(sql_riso.toString(), String.class);		
		log.debug("risoMailId : "+risoMailId);		
		return risoMailId;		
	}

}
