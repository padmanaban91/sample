package com.citigroup.cgti.c3par.businessjustification.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.webtier.bean.WorkflowDocumentBean;

public class UploadDocumentsProcess {

	    /** The doc for upload. */
	    private CommonsMultipartFile docForUpload;

	    /** The doc type. */
	    private String docType;

	    /** The uploaded docs. */
	    private List<WorkflowDocumentBean> uploadedDocs;
	    
	    private List<String> docDropDownList;

	    /** The doc options. */
	    private int docOptions = 1;
	    
	    /** The version no. */
		private Integer versionNo;

		/** The curr version no. */
		private Integer currVersionNo;
		
		private Integer uploadedVersion;
		
		private String uploadedDate;

		private String tiRequestId;
		
		private WorkflowDocumentBean docBean;
	    /**
	     * Gets the doc for upload.
	     *
	     * @return the doc for upload
	     */
	    public CommonsMultipartFile getDocForUpload() {
		return docForUpload;
	    }

	    /**
	     * Sets the doc for upload.
	     *
	     * @param docForUpload the new doc for upload
	     */
	    public void setDocForUpload(CommonsMultipartFile docForUpload) {
		this.docForUpload = docForUpload;
	    }

	    /**
	     * Gets the doc type.
	     *
	     * @return the doc type
	     */
	    public String getDocType() {
		return docType;
	    }

	    /**
	     * Sets the doc type.
	     *
	     * @param docType the new doc type
	     */
	    public void setDocType(String docType) {
		this.docType = docType;
	    }

	    /**
	     * Gets the uploaded docs.
	     *
	     * @return the uploaded docs
	     */
	    public List<WorkflowDocumentBean> getUploadedDocs() {
		if (uploadedDocs == null){
		    uploadedDocs = new ArrayList<WorkflowDocumentBean>();
		}
		return uploadedDocs;
	    }

	    /**
	     * Sets the uploaded docs.
	     *
	     * @param uploadedDocs the new uploaded docs
	     */
	    public void setUploadedDocs(List<WorkflowDocumentBean> uploadedDocs) {
		this.uploadedDocs = uploadedDocs;
	    }

	    /**
	     * Gets the doc options.
	     *
	     * @return the doc options
	     */
	    public int getDocOptions() {
		return docOptions;
	    }

	    /**
	     * Sets the doc options.
	     *
	     * @param docOptions the new doc options
	     */
	    public void setDocOptions(int docOptions) {
		this.docOptions = docOptions;
	    }
	    
	    /**
	     * Gets the VersionNo 
	     * @return
	     */
	    public Integer getVersionNo() {
			return versionNo;
		}

	    /**
	     * Sets the version NO
	     * @param versionNo
	     */
		public void setVersionNo(Integer versionNo) {
			this.versionNo = versionNo;
		}

		/**
		 * Gets the CurrVersionNo
		 * @return
		 */
		public Integer getCurrVersionNo() {
			return currVersionNo;
		}

		/**
		 * Sets the CurrVersionNo
		 * @param currVersionNo
		 */
		public void setCurrVersionNo(Integer currVersionNo) {
			this.currVersionNo = currVersionNo;
		}

		public String getTiRequestId() {
			return tiRequestId;
		}

		public void setTiRequestId(String tiRequestId) {
			this.tiRequestId = tiRequestId;
		}

		public Integer getUploadedVersion() {
			return uploadedVersion;
		}

		public void setUploadedVersion(Integer uploadedVersion) {
			this.uploadedVersion = uploadedVersion;
		}

		public String getUploadedDate() {
			return uploadedDate;
		}

		public void setUploadedDate(String uploadedDate) {
			this.uploadedDate = uploadedDate;
		}

		public WorkflowDocumentBean getDocBean() {
			return docBean;
		}

		public void setDocBean(WorkflowDocumentBean docBean) {
			this.docBean = docBean;
		}
		

		public void validate(String message) throws Exception {
			
			throw new Exception(message);
		}

		public List<String> getDocDropDownList() {
			return docDropDownList;
		}

		public void setDocDropDownList(List<String> docDropDownList) {
			this.docDropDownList = docDropDownList;
		}
		

	}

