package com.citigroup.cgti.c3par.domain;



/**
 * The Class BaseMailVO.
 */
public class BaseMailVO {
    // The below variables MUST be present in the object for 'Mail Module' functionality to work properly
    /** The connection id. */
    private String connectionId;

    /** The to email address. */
    private String toEmailAddress;

    /** The cc email address. */
    private String ccEmailAddress;

    /** The bcc email address. */
    private String bccEmailAddress;

    /** The mail subject. */
    private String mailSubject;

    /** The mail body. */
    private String mailBody;

    private long tirequestID;

    public long getTirequestID() {
		return tirequestID;
	}

	public void setTirequestID(long tirequestID) {
		this.tirequestID = tirequestID;
	}

    /**
     * Gets the connection id.
     *
     * @return the connection id
     */
    public String getConnectionId() {
	return connectionId;
    }

    /**
     * Sets the connection id.
     *
     * @param connectionId the new connection id
     */
    public void setConnectionId(String connectionId) {
	this.connectionId = connectionId;
    }

    /**
     * Gets the to email address.
     *
     * @return the to email address
     */
    public String getToEmailAddress() {
	return toEmailAddress;
    }

    /**
     * Sets the to email address.
     *
     * @param toEmailAddress the new to email address
     */
    public void setToEmailAddress(String toEmailAddress) {
	this.toEmailAddress = toEmailAddress;
    }

    /**
     * Gets the cc email address.
     *
     * @return the cc email address
     */
    public String getCcEmailAddress() {
	return ccEmailAddress;
    }

    /**
     * Sets the cc email address.
     *
     * @param ccEmailAddress the new cc email address
     */
    public void setCcEmailAddress(String ccEmailAddress) {
	this.ccEmailAddress = ccEmailAddress;
    }

    /**
     * Gets the bcc email address.
     *
     * @return the bcc email address
     */
    public String getBccEmailAddress() {
	return bccEmailAddress;
    }

    /**
     * Sets the bcc email address.
     *
     * @param bccEmailAddress the new bcc email address
     */
    public void setBccEmailAddress(String bccEmailAddress) {
	this.bccEmailAddress = bccEmailAddress;
    }

    /**
     * Gets the mail subject.
     *
     * @return the mail subject
     */
    public String getMailSubject() {
	return mailSubject;
    }

    /**
     * Sets the mail subject.
     *
     * @param mailSubject the new mail subject
     */
    public void setMailSubject(String mailSubject) {
	this.mailSubject = mailSubject;
    }

    /**
     * Gets the mail body.
     *
     * @return the mail body
     */
    public String getMailBody() {
	return mailBody;
    }

    /**
     * Sets the mail body.
     *
     * @param mailBody the new mail body
     */
    public void setMailBody(String mailBody) {
	this.mailBody = mailBody;
    }


}
