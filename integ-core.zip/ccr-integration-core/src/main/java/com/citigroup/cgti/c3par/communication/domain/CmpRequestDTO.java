package com.citigroup.cgti.c3par.communication.domain;

import java.util.Date;
import java.util.HashMap;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.domain.C3PARMailMessage;

@XmlRootElement
public class CmpRequestDTO extends C3PARMailMessage{
	

	@SuppressWarnings("unused")
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	private String cmpId;
	
	private Date assignedDate;
	
	private String requestType;
	
	private String urgency;
	
	private String region;
	
	private String sector;
	
	private String assistanceRequested;
	
	private String ccrId;
	
	private String chgId;
	
	private String chgDate;
	
	private String rqdAddInfo;
	
	private String businessResponse;

	private String implementedDate;	
	
	private String requesterSsoId;	
	
	private String bj;
	
	private String emailAddress;
	
	private String connName;
	
	private String role;
	
	private String textForSubject;

	private String addInfo;
	
	private String phoneNo;	
	
	private String reAssignedUser;
	
	private String reAssignedUserEmail;
	
	private String reAssignedUserPhone;
	
	private	String ssoId;
	
	private	String requestorName;
	
	private	String primaryOwnerName;
	
	private	String secondaryOwnerName;
	
	private	String isoName;
	
	private	String assignedUserName;
	
	private	String agentName;
	
	private	String agentPhone;
	
	private	String agentEmail;
	
	private	String cancelReason;
	
	private boolean secondTemplate;

	private	HashMap<String, String> attachments;
	
	private String leadName;
	
	private String leadEmail;
	
	private String leadPhone;
	
	private String orderId;
	
	private String step;
	
	private String orderBy;
	
	private String orderFor;
	
	private String chooseEmail;
	
	private Date loggedDate;
	
	private Date dueDate;
	
	private String leadComments;
	/*Started For ECM FLOW*/
	private String reqAdditionalInfo;
	private String comments;
	public String getReqAdditionalInfo() {
		return reqAdditionalInfo;
	}

	public void setReqAdditionalInfo(String reqAdditionalInfo) {
		this.reqAdditionalInfo = reqAdditionalInfo;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	/*END  ECM FLOW*/
	
	
	
	

	private ChangeRequestDetails[] changeRequestDetails;
	

	public static class ChangeRequestDetails {

        

        private String chgNum;

           

        private String chgDate;
        		
    			@XmlElement
                public String getChgNum() {

                        return chgNum;

                }

                public void setChgNum(String chgNum) {

                        this.chgNum = chgNum;

                }

            	@XmlElement
                public String getChgDate() { 

                        return chgDate;

                }

                public void setChgDate(String chgDate) {

                        this.chgDate = chgDate;

                }

	}
    

	@XmlElement
	public String getLeadComments() {
		return leadComments;
	}

	public void setLeadComments(String leadComments) {
		this.leadComments = leadComments;
	}
	
	
	@XmlElement
	public String getChooseEmail() {
		return chooseEmail;
	}

	public void setChooseEmail(String chooseEmail) {
		this.chooseEmail = chooseEmail;
	}

	@XmlElement
	public String getChgDate() {
		return chgDate;
	}

	public void setChgDate(String chgDate) {
		this.chgDate = chgDate;
	}
	
	@XmlElement
	public String getRqdAddInfo() {
		return rqdAddInfo;
	}

	public void setRqdAddInfo(String rqdAddInfo) {
		this.rqdAddInfo = rqdAddInfo;
	}

	@XmlElement
	public String getBusinessResponse() {
		return businessResponse;
	}

	public void setBusinessResponse(String businessResponse) {
		this.businessResponse = businessResponse;
	}

	@XmlElement
	public String getReAssignedUser() {
		return reAssignedUser;
	}

	public void setReAssignedUser(String reAssignedUser) {
		this.reAssignedUser = reAssignedUser;
	}

	@XmlElement
	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	@XmlElement
	public String getPrimaryOwnerName() {
		return primaryOwnerName;
	}

	public void setPrimaryOwnerName(String primaryOwnerName) {
		this.primaryOwnerName = primaryOwnerName;
	}

	@XmlElement
	public String getSecondaryOwnerName() {
		return secondaryOwnerName;
	}

	public void setSecondaryOwnerName(String secondaryOwnerName) {
		this.secondaryOwnerName = secondaryOwnerName;
	}

	@XmlElement
	public String getIsoName() {
		return isoName;
	}

	public void setIsoName(String isoName) {
		this.isoName = isoName;
	}

	@XmlElement
	public String getAssignedUserName() {
		return assignedUserName;
	}

	public void setAssignedUserName(String assignedUserName) {
		this.assignedUserName = assignedUserName;
	}

	@XmlElement
	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	@XmlElement
	public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

	@XmlElement
	public String getRequesterSsoId() {
		return requesterSsoId;
	}

	public void setRequesterSsoId(String requesterSsoId) {
		this.requesterSsoId = requesterSsoId;
	}	

	@XmlElement
	public String getAgentPhone() {
		return agentPhone;
	}

	public void setAgentPhone(String agentPhone) {
		this.agentPhone = agentPhone;
	}

	@XmlElement
	public String getAgentEmail() {
		return agentEmail;
	}

	public void setAgentEmail(String agentEmail) {
		this.agentEmail = agentEmail;
	}

	@XmlElement
	public String getSsoId() {
		return ssoId;
	}

	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	@XmlElement
	public boolean isSecondTemplate() {
		return secondTemplate;
	}

	public void setSecondTemplate(boolean secondTemplate) {
		this.secondTemplate = secondTemplate;
	}

	@XmlElement
	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	@XmlElement
	public String getAddInfo() {
		return addInfo;
	}

	public void setAddInfo(String addInfo) {
		this.addInfo = addInfo;
	}

	@XmlElement
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	@XmlElement
	public String getConnName() {
		return connName;
	}

	public void setConnName(String connName) {
		this.connName = connName;
	}

	@XmlElement
	public String getCmpId() {
		return cmpId;
	}

	public void setCmpId(String cmpId) {
		this.cmpId = cmpId;
	}
	@XmlElement
	public Date getAssignedDate() {
		return assignedDate;
	}

	public void setAssignedDate(Date assignedDate) {
		this.assignedDate = assignedDate;
	}
	@XmlElement
	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	@XmlElement
	public String getUrgency() {
		return urgency;
	}

	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}
	@XmlElement
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}
	@XmlElement
	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}
	@XmlElement
	public String getAssistanceRequested() {
		return assistanceRequested;
	}

	public void setAssistanceRequested(String assistanceRequested) {
		this.assistanceRequested = assistanceRequested;
	}
	@XmlElement
	public String getCcrId() {
		return ccrId;
	}

	public void setCcrId(String ccrId) {
		this.ccrId = ccrId;
	}
	@XmlElement
	public String getChgId() {
		return chgId;
	}

	public void setChgId(String chgId) {
		this.chgId = chgId;
	}
	
	@XmlElement
	public String getImplementedDate() {
		return implementedDate;
	}

	public void setImplementedDate(String implementedDate) {
		this.implementedDate = implementedDate;
	}
	
	@XmlElement
	public String getBj() {
		return bj;
	}

	public void setBj(String bj) {
		this.bj = bj;
	}

	@XmlElement
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@XmlElement
	public String getTextForSubject() {
		return textForSubject;
	}

	public void setTextForSubject(String textForSubject) {
		this.textForSubject = textForSubject;
	}

	public HashMap<String, String> getAttachments() {
		return attachments;
	}

	public void setAttachments(HashMap<String, String> attachments) {
		this.attachments = attachments;
	}

	public String getLeadName() {
		return leadName;
	}

	public void setLeadName(String leadName) {
		this.leadName = leadName;
	}

	public String getLeadEmail() {
		return leadEmail;
	}

	public void setLeadEmail(String leadEmail) {
		this.leadEmail = leadEmail;
	}

	public String getLeadPhone() {
		return leadPhone;
	}

	public void setLeadPhone(String leadPhone) {
		this.leadPhone = leadPhone;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getStep() {
		return step;
	}

	public void setStep(String step) {
		this.step = step;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getOrderFor() {
		return orderFor;
	}

	public void setOrderFor(String orderFor) {
		this.orderFor = orderFor;
	}

	public Date getLoggedDate() {
		return loggedDate;
	}

	public void setLoggedDate(Date loggedDate) {
		this.loggedDate = loggedDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	@XmlElement
	public ChangeRequestDetails[] getChangeRequestDetails() {
		return changeRequestDetails;
	}

	public void setChangeRequestDetails(ChangeRequestDetails[] changeRequestDetails) {
		this.changeRequestDetails = changeRequestDetails;
	}

	@XmlElement
	public String getReAssignedUserEmail() {
		return reAssignedUserEmail;
	}

	public void setReAssignedUserEmail(String reAssignedUserEmail) {
		this.reAssignedUserEmail = reAssignedUserEmail;
	}

	@XmlElement
	public String getReAssignedUserPhone() {
		return reAssignedUserPhone;
	}

	public void setReAssignedUserPhone(String reAssignedUserPhone) {
		this.reAssignedUserPhone = reAssignedUserPhone;
	}
	
	

	
	

	
	
}