


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// TODO: Auto-generated Javadoc
// Reference imports

// Entity name = TIRequestDAO
// Table name = TI_REQUEST
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class TIRequestDAO.
 */
public class TIRequestDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "TI_REQUEST";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(TIRequestDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "TIRequest";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_CREATEDATE. */
    public static final String	COLUMN_CREATEDATE = "CREATE_DATE";

    /** The Constant COLUMN_VERSIONNUMBER. */
    public static final String	COLUMN_VERSIONNUMBER = "VERSION_NUMBER";

    /** The Constant COLUMN_ISDELETED. */
    public static final String	COLUMN_ISDELETED = "IS_DELETED";

    /** The Constant COLUMN_ISDELETED_LEN. */
    public static final int		COLUMN_ISDELETED_LEN = 1;

    /** The Constant COLUMN_PLANNEDCOMPLETIONDATE. */
    public static final String	COLUMN_PLANNEDCOMPLETIONDATE = "PLANNED_COMPLETION_DATE";

    /** The Constant COLUMN_EMERBUSCRITJUSTIFICATION. */
    public static final String	COLUMN_EMERBUSCRITJUSTIFICATION = "EMER_BUSCRIT_JUSTIFICATION";

    /** The Constant COLUMN_EMERBUSCRITJUSTIFICATION_LEN. */
    public static final int		COLUMN_EMERBUSCRITJUSTIFICATION_LEN = 1000;

    /** The Constant COLUMN_ALTBUSSMETHODS. */
    public static final String	COLUMN_ALTBUSSMETHODS = "ALT_BUSS_METHODS";

    /** The Constant COLUMN_ALTBUSSMETHODS_LEN. */
    public static final int		COLUMN_ALTBUSSMETHODS_LEN = 1000;

    /** The Constant COLUMN_REQNEWACCESS. */
    public static final String	COLUMN_REQNEWACCESS = "REQ_NEW_ACCESS";

    /** The Constant COLUMN_REQNEWACCESS_LEN. */
    public static final int		COLUMN_REQNEWACCESS_LEN = 1000;

    /** The Constant COLUMN_VTTICKETNO. */
    public static final String	COLUMN_VTTICKETNO = "VT_TICKET_NO";

    /** The Constant COLUMN_VTTICKETNO_LEN. */
    public static final int		COLUMN_VTTICKETNO_LEN = 100;

    /** The Constant COLUMN_REQUESTDEADLINE. */
    public static final String	COLUMN_REQUESTDEADLINE = "REQUEST_DEADLINE";
    // Column names of references
    /** The Constant COLUMN_USER_ID. */
    public static final String	COLUMN_USER_ID = "USER_ID";

    /** The Constant COLUMN_PROCESS_ID. */
    public static final String	COLUMN_PROCESS_ID = "PROCESS_ID";

    /** The Constant COLUMN_TIREQUESTTYPE_ID. */
    public static final String	COLUMN_TIREQUESTTYPE_ID = "TI_REQUEST_TYPE_ID";

    /** The Constant COLUMN_PRIORITY_ID. */
    public static final String	COLUMN_PRIORITY_ID = "PRIORITY_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + TIRequestDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_CREATEDATE
    + ", " + COLUMN_VERSIONNUMBER
    + ", " + COLUMN_ISDELETED
    + ", " + COLUMN_PLANNEDCOMPLETIONDATE
    + ", " + COLUMN_EMERBUSCRITJUSTIFICATION
    + ", " + COLUMN_ALTBUSSMETHODS
    + ", " + COLUMN_REQNEWACCESS
    + ", " + COLUMN_VTTICKETNO
    + ", " + COLUMN_REQUESTDEADLINE
    + ", " + COLUMN_USER_ID
    + ", " + COLUMN_PROCESS_ID
    + ", " + COLUMN_TIREQUESTTYPE_ID
    + ", " + COLUMN_PRIORITY_ID
    + " FROM " + TIRequestDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = TIRequestDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + TIRequestDAO.TABLE + " SET "
    + COLUMN_CREATEDATE + " = ? "
    + ", " + COLUMN_VERSIONNUMBER + " = ? "
    + ", " + COLUMN_ISDELETED + " = ? "
    + ", " + COLUMN_PLANNEDCOMPLETIONDATE + " = ? "
    + ", " + COLUMN_EMERBUSCRITJUSTIFICATION + " = ? "
    + ", " + COLUMN_ALTBUSSMETHODS + " = ? "
    + ", " + COLUMN_REQNEWACCESS + " = ? "
    + ", " + COLUMN_VTTICKETNO + " = ? "
    + ", " + COLUMN_REQUESTDEADLINE + " = ? "
    + ", " + COLUMN_USER_ID + " = ? "
    + ", " + COLUMN_PROCESS_ID + " = ? "
    + ", " + COLUMN_TIREQUESTTYPE_ID + " = ? "
    + ", " + COLUMN_PRIORITY_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + TIRequestDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_CREATEDATE 
    + ", " + COLUMN_VERSIONNUMBER 
    + ", " + COLUMN_ISDELETED 
    + ", " + COLUMN_PLANNEDCOMPLETIONDATE 
    + ", " + COLUMN_EMERBUSCRITJUSTIFICATION 
    + ", " + COLUMN_ALTBUSSMETHODS 
    + ", " + COLUMN_REQNEWACCESS 
    + ", " + COLUMN_VTTICKETNO 
    + ", " + COLUMN_REQUESTDEADLINE 
    + ", " + COLUMN_USER_ID
    + ", " + COLUMN_PROCESS_ID
    + ", " + COLUMN_TIREQUESTTYPE_ID
    + ", " + COLUMN_PRIORITY_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + TIRequestDAO.TABLE + " WHERE ID = ?";



    //======================================================================
    /**
     * Creates the instance.
     *
     * @param session the session
     * @return the tI request dao
     */
    public static TIRequestDAO createInstance(DatabaseSession session)
    {
	return new TIRequestDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new tI request dao.
     *
     * @param session the session
     */
    public TIRequestDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating TIRequestDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert.
     *
     * @param entity the entity
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(TIRequestEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * Insert.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(TIRequestEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(TIRequestEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * Insert.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(TIRequestEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting TIRequestEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + TIRequestDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, TIRequestDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setDateToStatement(st, position, entity.getCreateDate());
	    position = setIntegerToStatement(st, position, entity.getVersionNumber());
	    position = setStringToStatement(st, position, entity.getIsDeleted(), COLUMN_ISDELETED_LEN);
	    position = setDateToStatement(st, position, entity.getPlannedCompletionDate());
	    position = setStringToStatement(st, position, entity.getEmerBuscritJustification(), COLUMN_EMERBUSCRITJUSTIFICATION_LEN);
	    position = setStringToStatement(st, position, entity.getAltBussMethods(), COLUMN_ALTBUSSMETHODS_LEN);
	    position = setStringToStatement(st, position, entity.getReqNewAccess(), COLUMN_REQNEWACCESS_LEN);
	    position = setStringToStatement(st, position, entity.getVtTicketNo(), COLUMN_VTTICKETNO_LEN);
	    position = setDateToStatement(st, position, entity.getRequestDeadline());

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + TIRequestDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update.
     *
     * @param entity the entity
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(TIRequestEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * Update.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(TIRequestEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(TIRequestEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * Update.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(TIRequestEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating TIRequestEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + TIRequestDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setDateToStatement(st, position, entity.getCreateDate());
	    position = setIntegerToStatement(st, position, entity.getVersionNumber());
	    position = setStringToStatement(st, position, entity.getIsDeleted(), COLUMN_ISDELETED_LEN);
	    position = setDateToStatement(st, position, entity.getPlannedCompletionDate());
	    position = setStringToStatement(st, position, entity.getEmerBuscritJustification(), COLUMN_EMERBUSCRITJUSTIFICATION_LEN);
	    position = setStringToStatement(st, position, entity.getAltBussMethods(), COLUMN_ALTBUSSMETHODS_LEN);
	    position = setStringToStatement(st, position, entity.getReqNewAccess(), COLUMN_REQNEWACCESS_LEN);
	    position = setStringToStatement(st, position, entity.getVtTicketNo(), COLUMN_VTTICKETNO_LEN);
	    position = setDateToStatement(st, position, entity.getRequestDeadline());

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + TIRequestDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @return the tI request entity
     * @throws DatabaseException the database exception
     */
    public TIRequestEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @param load_refs the load_refs
     * @return the tI request entity
     * @throws DatabaseException the database exception
     */
    public TIRequestEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	TIRequestEntity obj = (TIRequestEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting TIRequestEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> TIRequestEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (TIRequestEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + TIRequestDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + TIRequestDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting TIRequestEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Gets the.
     *
     * @param id_list the id_list
     * @param load_refs the load_refs
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    TIRequestEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (TIRequestEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (TIRequestEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + TIRequestDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Gets the all.
     *
     * @param load_refs the load_refs
     * @return the all
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		TIRequestEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM TI_REQUEST";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (TIRequestEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + TIRequestDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Gets the all ids.
     *
     * @return the all ids
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Exists.
     *
     * @param id the id
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + TIRequestDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    TIRequestEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param archiver the archiver
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    TIRequestEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete.
     *
     * @param entity_ids the entity_ids
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete.
     *
     * @param entity_ids the entity_ids
     * @param archiver the archiver
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void delete(TIRequestEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @throws DatabaseException the database exception
     */
    public void delete(TIRequestEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + TIRequestDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(TIRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + TIRequestDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	TIRequestEntity entity = (TIRequestEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setCreateDate(getDateFromResultSet(rs, COLUMN_CREATEDATE));
	    entity.setCreateDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalCreateDate(entity.getCreateDate());
	    //			entity.setVersionNumber(getIntegerFromResultSet(rs, COLUMN_VERSIONNUMBER));
	    entity.setVersionNumber(getIntegerFromResultSetIndexed(rs, ++index));
	    entity.setOriginalVersionNumber(entity.getVersionNumber());
	    //			entity.setIsDeleted(getStringFromResultSet(rs, COLUMN_ISDELETED));
	    entity.setIsDeleted(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIsDeleted(entity.getIsDeleted());
	    //			entity.setPlannedCompletionDate(getDateFromResultSet(rs, COLUMN_PLANNEDCOMPLETIONDATE));
	    entity.setPlannedCompletionDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalPlannedCompletionDate(entity.getPlannedCompletionDate());
	    //			entity.setEmerBuscritJustification(getStringFromResultSet(rs, COLUMN_EMERBUSCRITJUSTIFICATION));
	    entity.setEmerBuscritJustification(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalEmerBuscritJustification(entity.getEmerBuscritJustification());
	    //			entity.setAltBussMethods(getStringFromResultSet(rs, COLUMN_ALTBUSSMETHODS));
	    entity.setAltBussMethods(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalAltBussMethods(entity.getAltBussMethods());
	    //			entity.setReqNewAccess(getStringFromResultSet(rs, COLUMN_REQNEWACCESS));
	    entity.setReqNewAccess(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalReqNewAccess(entity.getReqNewAccess());
	    //			entity.setVtTicketNo(getStringFromResultSet(rs, COLUMN_VTTICKETNO));
	    entity.setVtTicketNo(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalVtTicketNo(entity.getVtTicketNo());
	    //			entity.setRequestDeadline(getDateFromResultSet(rs, COLUMN_REQUESTDEADLINE));
	    entity.setRequestDeadline(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequestDeadline(entity.getRequestDeadline());

	    // Single References
	    //			entity.setUserId(getLongFromResultSet(rs, COLUMN_USER_ID));
	    entity.setUserId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalUserId(entity.getUserId());
	    //			entity.setProcessId(getLongFromResultSet(rs, COLUMN_PROCESS_ID));
	    entity.setProcessId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcessId(entity.getProcessId());
	    //			entity.setTiRequestTypeId(getLongFromResultSet(rs, COLUMN_TIREQUESTTYPE_ID));
	    entity.setTiRequestTypeId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalTiRequestTypeId(entity.getTiRequestTypeId());
	    //			entity.setPriorityId(getLongFromResultSet(rs, COLUMN_PRIORITY_ID));
	    entity.setPriorityId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalPriorityId(entity.getPriorityId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	TIRequestEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (TIRequestEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new TIRequestEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load reference ids.
     *
     * @param obj the obj
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	TIRequestEntity entity = (TIRequestEntity)obj;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#loadReferences(com.mentisys.model.Entity)
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("GenericLookupDAO.loadReferences(): References for TIRequestEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("GenericLookupDAO.loadReferences(): Loading references for TIRequestEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    TIRequestEntity entity = (TIRequestEntity)obj;

	    Long userId = entity.getUserId();
	    if (userId != null)
	    {
		// Use lookup for optimized access
		entity.setUser(C3parUsersLookup.getInstance().getById(getSession(), userId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalUser(entity.getUser());
	    }

	    Long processId = entity.getProcessId();
	    if (processId != null)
	    {
		//			TIProcessDAO processDAO = new TIProcessDAO(getSession());
		TIProcessDAO processDAO = getProcessDAO();
		entity.setProcess((TIProcessEntity)processDAO.get(processId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalProcess(entity.getProcess());
	    }

	    Long tiRequestTypeId = entity.getTiRequestTypeId();
	    if (tiRequestTypeId != null)
	    {
		//			TIRequestTypeDAO tiRequestTypeDAO = new TIRequestTypeDAO(getSession());
		TIRequestTypeDAO tiRequestTypeDAO = getTiRequestTypeDAO();
		entity.setTiRequestType((TIRequestTypeEntity)tiRequestTypeDAO.get(tiRequestTypeId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalTiRequestType(entity.getTiRequestType());
	    }

	    Long priorityId = entity.getPriorityId();
	    if (priorityId != null)
	    {
		// Use lookup for optimized access
		entity.setPriority(GenericLookupLookup.getInstance().getById(getSession(), priorityId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalPriority(entity.getPriority());
	    }

	}
	catch(Exception e)
	{
		log.error(e,e);
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for TIRequestEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load user with id.
     *
     * @param id the id
     * @return the c3par users entity
     * @throws DatabaseException the database exception
     */
    public C3parUsersEntity loadUserWithId(Long id) throws DatabaseException
    {
	C3parUsersEntity entity = null;
	if (id != null)
	{
	    // Use lookup for optimized access
	    entity = C3parUsersLookup.getInstance().getById(getSession(), id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load process with id.
     *
     * @param id the id
     * @return the tI process entity
     * @throws DatabaseException the database exception
     */
    public TIProcessEntity loadProcessWithId(Long id) throws DatabaseException
    {
	TIProcessEntity entity = null;
	if (id != null)
	{
	    //			TIProcessDAO processDAO = new TIProcessDAO(getSession());
	    TIProcessDAO processDAO = getProcessDAO();
	    entity = (TIProcessEntity)processDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load ti request type with id.
     *
     * @param id the id
     * @return the tI request type entity
     * @throws DatabaseException the database exception
     */
    public TIRequestTypeEntity loadTiRequestTypeWithId(Long id) throws DatabaseException
    {
	TIRequestTypeEntity entity = null;
	if (id != null)
	{
	    //			TIRequestTypeDAO tiRequestTypeDAO = new TIRequestTypeDAO(getSession());
	    TIRequestTypeDAO tiRequestTypeDAO = getTiRequestTypeDAO();
	    entity = (TIRequestTypeEntity)tiRequestTypeDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load priority with id.
     *
     * @param id the id
     * @return the generic lookup entity
     * @throws DatabaseException the database exception
     */
    public GenericLookupEntity loadPriorityWithId(Long id) throws DatabaseException
    {
	GenericLookupEntity entity = null;
	if (id != null)
	{
	    // Use lookup for optimized access
	    entity = GenericLookupLookup.getInstance().getById(getSession(), id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	TIRequestEntity entity = (TIRequestEntity) obj;

	setLongToStatement(st, position++, entity.getUser() != null ? entity.getUser().getId() : entity.getUserId());
	setLongToStatement(st, position++, entity.getProcess() != null ? entity.getProcess().getId() : entity.getProcessId());
	setLongToStatement(st, position++, entity.getTiRequestType() != null ? entity.getTiRequestType().getId() : entity.getTiRequestTypeId());
	setLongToStatement(st, position++, entity.getPriority() != null ? entity.getPriority().getId() : entity.getPriorityId());

	return position;
    }

    // Single non-composition 'user' helpers 'TIRequest' does not need helper
    // Single non-composition 'process' helpers 'TIRequest' does not need helper
    // Single non-composition 'tiRequestType' helpers 'TIRequest' does not need helper
    // Single non-composition 'priority' helpers 'TIRequest' does not need helper

    // Reference DAO caching methods	
    //======================================================================
    /**
     * Gets the user dao.
     *
     * @return the user dao
     */
    protected C3parUsersDAO getUserDAO()
    {
	C3parUsersDAO dao = (C3parUsersDAO)getSession().getDAO("C3parUsers");  
	if(dao == null)
	{
	    dao = new C3parUsersDAO(getSession());  		
	    getSession().putDAO("C3parUsers", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     * Gets the process dao.
     *
     * @return the process dao
     */
    protected TIProcessDAO getProcessDAO()
    {
	TIProcessDAO dao = (TIProcessDAO)getSession().getDAO("TIProcess");  
	if(dao == null)
	{
	    dao = new TIProcessDAO(getSession());  		
	    getSession().putDAO("TIProcess", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     * Gets the ti request type dao.
     *
     * @return the ti request type dao
     */
    protected TIRequestTypeDAO getTiRequestTypeDAO()
    {
	TIRequestTypeDAO dao = (TIRequestTypeDAO)getSession().getDAO("TIRequestType");  
	if(dao == null)
	{
	    dao = new TIRequestTypeDAO(getSession());  		
	    getSession().putDAO("TIRequestType", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     * Gets the priority dao.
     *
     * @return the priority dao
     */
    protected GenericLookupDAO getPriorityDAO()
    {
	GenericLookupDAO dao = (GenericLookupDAO)getSession().getDAO("GenericLookup");  
	if(dao == null)
	{
	    dao = new GenericLookupDAO(getSession());  		
	    getSession().putDAO("GenericLookup", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find by create date.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByCreateDate(Date value) throws DatabaseException
    {
	return findByCreateDate(value, getSession());
    }

    /**
     * Find by create date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByCreateDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_CREATEDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find by version number.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByVersionNumber(Integer value) throws DatabaseException
    {
	return findByVersionNumber(value, getSession());
    }

    /**
     * Find by version number.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByVersionNumber(Integer value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_VERSIONNUMBER + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find by is deleted.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIsDeleted(String value) throws DatabaseException
    {
	return findByIsDeleted(value, getSession());
    }

    /**
     * Find by is deleted.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIsDeleted(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_ISDELETED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find by planned completion date.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByPlannedCompletionDate(Date value) throws DatabaseException
    {
	return findByPlannedCompletionDate(value, getSession());
    }

    /**
     * Find by planned completion date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByPlannedCompletionDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_PLANNEDCOMPLETIONDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find by emer buscrit justification.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByEmerBuscritJustification(String value) throws DatabaseException
    {
	return findByEmerBuscritJustification(value, getSession());
    }

    /**
     * Find by emer buscrit justification.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByEmerBuscritJustification(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_EMERBUSCRITJUSTIFICATION + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find by alt buss methods.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByAltBussMethods(String value) throws DatabaseException
    {
	return findByAltBussMethods(value, getSession());
    }

    /**
     * Find by alt buss methods.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByAltBussMethods(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_ALTBUSSMETHODS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find by req new access.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByReqNewAccess(String value) throws DatabaseException
    {
	return findByReqNewAccess(value, getSession());
    }

    /**
     * Find by req new access.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByReqNewAccess(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_REQNEWACCESS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find by vt ticket no.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByVtTicketNo(String value) throws DatabaseException
    {
	return findByVtTicketNo(value, getSession());
    }

    /**
     * Find by vt ticket no.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByVtTicketNo(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_VTTICKETNO + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find by request deadline.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequestDeadline(Date value) throws DatabaseException
    {
	return findByRequestDeadline(value, getSession());
    }

    /**
     * Find by request deadline.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequestDeadline(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_REQUESTDEADLINE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find by user.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByUser(Long value) throws DatabaseException
    {
	return findByUser(value, getSession());
    }

    /**
     * Find by user.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByUser(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_USER_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find by process.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcess(Long value) throws DatabaseException
    {
	return findByProcess(value, getSession());
    }

    /**
     * Find by process.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcess(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_PROCESS_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find by ti request type.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByTiRequestType(Long value) throws DatabaseException
    {
	return findByTiRequestType(value, getSession());
    }

    /**
     * Find by ti request type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByTiRequestType(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_TIREQUESTTYPE_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find by priority.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByPriority(Long value) throws DatabaseException
    {
	return findByPriority(value, getSession());
    }

    /**
     * Find by priority.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByPriority(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + COLUMN_PRIORITY_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by Priority", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(TIRequestEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }

    /**
     * Gets the previous request entity for process.
     *Added for #10224
     * @param id the id
     * @return the previous request entity for process
     * @throws DatabaseException the database exception
     */
    public TIRequestEntity getPreviousRequestEntityForProcess(long id) throws DatabaseException{
	long previousRequestId = 0;
	DatabaseSession session = getSession();
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;
	String sel_stmt = "select tir.id from c3par.ti_request tir,c3par.ti_request_type trt where tir.process_id="+id+" and tir.ti_request_type_id = trt.id and trt.request_type not in('ACV','ManageContacts') ORDER BY TIR.ID DESC";
	log.debug(sel_stmt);
	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    while(rs.next())
	    {
		previousRequestId = Long.valueOf(rs.getLong(1));
		break;
	    }
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find PreviousRequestEntityForProcess +"+id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return get(previousRequestId, true);
    }

}
