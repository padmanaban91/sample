


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.CitiContactXrefEntity;
import com.citigroup.cgti.c3par.model.CitiReqContactXrefEntity;
import com.citigroup.cgti.c3par.model.CommonLookupDataEntity;
import com.citigroup.cgti.c3par.model.ConnectionProcessEntity;
import com.citigroup.cgti.c3par.model.ConnectionRequestEntity;
import com.citigroup.cgti.c3par.model.DocumentMetaDataEntity;
import com.citigroup.cgti.c3par.model.FacilitiesAffectedXrefEntity;
import com.citigroup.cgti.c3par.model.FirewallDetailsEntity;
import com.citigroup.cgti.c3par.model.MaterialBillEntity;
import com.citigroup.cgti.c3par.model.NetworkConnectionEntity;
import com.citigroup.cgti.c3par.model.PlanningEntity;
import com.citigroup.cgti.c3par.model.ProjectJustificationXrefEntity;
import com.citigroup.cgti.c3par.model.RelationshipEntity;
import com.citigroup.cgti.c3par.model.ResourceXrefEntity;
import com.citigroup.cgti.c3par.model.TPContactXrefEntity;
import com.citigroup.cgti.c3par.model.TPServiceXrefEntity;
import com.mentisys.dao.DatabaseAccessObject;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.dao.KeyGenerator;
import com.mentisys.dao.audit.AuditArchiver;
import com.mentisys.dao.query.Condition;
import com.mentisys.model.Entity;
import com.mentisys.model.ManyAssociationList;


// Reference imports

// Entity name = ConnectionRequestDAO
// Table name = CON_REQ
// Superclass = <none>
// Subclasses =  Planning 
/**
 * The Class ConnectionRequestDAO.
 */
public class ConnectionRequestDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "CON_REQ";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(ConnectionRequestDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "ConnectionRequest";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    /** The Constant COLUMN_DISCRIMINATOR. */
    public static final String	COLUMN_DISCRIMINATOR = "DISCRIMINATOR";

    /** The Constant COLUMN_DISCRIMINATOR_LEN. */
    public static final int		COLUMN_DISCRIMINATOR_LEN = 100;

    // Column names
    /** The Constant COLUMN_REQUIRENETWORKACCESS. */
    public static final String	COLUMN_REQUIRENETWORKACCESS = "REQUIRE_NETWORK_ACCESS";

    /** The Constant COLUMN_RATIONALE. */
    public static final String	COLUMN_RATIONALE = "RATIONALE";

    /** The Constant COLUMN_RATIONALE_LEN. */
    public static final int		COLUMN_RATIONALE_LEN = 2000;
    
    public static final int	COLUMN_SEMI_ANNUAL_LEN = 2000;
    public static final int	COLUMN_TP_TRAINING_LEN = 2000;
    public static final int	COLUMN_EXPORT_LICENCE_LEN = 2000;
    public static final int	COLUMN_CONN_ESTIMATE_LEN = 100;
    public static final int	COLUMN_DET_INFORMATION_LEN = 100;
    
    public static final int	COLUMN_CONN_FOR_CUST_LEN = 2000;
    public static final int	COLUMN_DIRECT_ACCESS_LEN = 2000;

    /** The Constant COLUMN_BENEFIT. */
    public static final String	COLUMN_BENEFIT = "BENEFIT";

    /** The Constant COLUMN_BENEFIT_LEN. */
    public static final int		COLUMN_BENEFIT_LEN = 500;

    /** The Constant COLUMN_PLCODE. */
    public static final String	COLUMN_PLCODE = "PLCODE";

    /** The Constant COLUMN_PLCODE_LEN. */
    public static final int		COLUMN_PLCODE_LEN = 25;

    /** The Constant COLUMN_ESTIMATEDREVENUEGENERATED. */
    public static final String	COLUMN_ESTIMATEDREVENUEGENERATED = "ESTIMATED_REVENUE_GENERATED";

    /** The Constant COLUMN_ESTIMATEDCOSTSAVING. */
    public static final String	COLUMN_ESTIMATEDCOSTSAVING = "ESTIMATED_COST_SAVING";

    /** The Constant COLUMN_COBREDUNDANCYREQUIRED. */
    public static final String	COLUMN_COBREDUNDANCYREQUIRED = "COB_REDUNDANCY_REQUIRED";

    /** The Constant COLUMN_CONNECTIONNAME. */
    public static final String	COLUMN_CONNECTIONNAME = "CONNECTION_NAME";

    /** The Constant COLUMN_CONNECTIONNAME_LEN. */
    public static final int		COLUMN_CONNECTIONNAME_LEN = 150;

    /** The Constant COLUMN_STATUS. */
    public static final String	COLUMN_STATUS = "STATUS";

    /** The Constant COLUMN_STATUS_LEN. */
    public static final int		COLUMN_STATUS_LEN = 100;

    /** The Constant COLUMN_REQUESTERID. */
    public static final String	COLUMN_REQUESTERID = "REQUESTER_ID";

    /** The Constant COLUMN_REQUESTERID_LEN. */
    public static final int		COLUMN_REQUESTERID_LEN = 100;

    /** The Constant COLUMN_SEMIANNUALENTITLEMENTREVIEW. */
    public static final String	COLUMN_SEMIANNUALENTITLEMENTREVIEW = "SEMI_ANNUAL_ENTITLEMENT_REVIEW";

    /** The Constant COLUMN_ISSCONNECTIONCOMPLIANCE. */
    public static final String	COLUMN_ISSCONNECTIONCOMPLIANCE = "ISS_CONNECTION_COMPLIANCE";

    /** The Constant COLUMN_ISSCONNECTIONCOMPLIANCE_LEN. */
    public static final int		COLUMN_ISSCONNECTIONCOMPLIANCE_LEN = 1000;

    /** The Constant COLUMN_CITIPOLICYADHERENCE. */
    public static final String	COLUMN_CITIPOLICYADHERENCE = "CITI_POLICY_ADHERENCE";

    /** The Constant COLUMN_CITIPOLICYADHERENCE_LEN. */
    public static final int		COLUMN_CITIPOLICYADHERENCE_LEN = 1;

    /** The Constant COLUMN_ACCESSCITIGLOBALNETWORK. */
    public static final String	COLUMN_ACCESSCITIGLOBALNETWORK = "ACCESS_CITI_GLOBAL_NETWORK";

    /** The Constant COLUMN_TPTRAININGAWARNESSPROGRAM. */
    public static final String	COLUMN_TPTRAININGAWARNESSPROGRAM = "TP_TRAINING_AWARNESS_PROGRAM";

    /** The Constant COLUMN_SPONSORBUSINESSCONSULTED. */
    public static final String	COLUMN_SPONSORBUSINESSCONSULTED = "SPONSOR_BUSINESS_CONSULTED";

    /** The Constant COLUMN_EXPORTLICENSECORDINATOR. */
    public static final String	COLUMN_EXPORTLICENSECORDINATOR = "EXPORT_LICENSE_CORDINATOR";
    // Column names of references
    /** The Constant COLUMN_LOOKUP_ID. */
    public static final String	COLUMN_LOOKUP_ID = "LOOKUP_ID";

    /** The Constant COLUMN_NETCON_ID. */
    public static final String	COLUMN_NETCON_ID = "NET_CON_ID";

    /** The Constant COLUMN_RELATIONSHIP_ID. */
    public static final String	COLUMN_RELATIONSHIP_ID = "RELATIONSHIP_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_DISCRIMINATOR
    + ", " + COLUMN_REQUIRENETWORKACCESS
    + ", " + COLUMN_RATIONALE
    + ", " + COLUMN_BENEFIT
    + ", " + COLUMN_PLCODE
    + ", " + COLUMN_ESTIMATEDREVENUEGENERATED
    + ", " + COLUMN_ESTIMATEDCOSTSAVING
    + ", " + COLUMN_COBREDUNDANCYREQUIRED
    + ", " + COLUMN_CONNECTIONNAME
    + ", " + COLUMN_STATUS
    + ", " + COLUMN_REQUESTERID
    + ", " + COLUMN_SEMIANNUALENTITLEMENTREVIEW
    + ", " + COLUMN_ISSCONNECTIONCOMPLIANCE
    + ", " + COLUMN_CITIPOLICYADHERENCE
    + ", " + COLUMN_ACCESSCITIGLOBALNETWORK
    + ", " + COLUMN_TPTRAININGAWARNESSPROGRAM
    + ", " + COLUMN_SPONSORBUSINESSCONSULTED
    + ", " + COLUMN_EXPORTLICENSECORDINATOR
    + ", " + COLUMN_LOOKUP_ID
    + ", " + COLUMN_NETCON_ID
    + ", " + COLUMN_RELATIONSHIP_ID
    + " FROM " + ConnectionRequestDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = ConnectionRequestDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + ConnectionRequestDAO.TABLE + " SET "
    + COLUMN_REQUIRENETWORKACCESS + " = ? "
    + ", " + COLUMN_RATIONALE + " = ? "
    + ", " + COLUMN_BENEFIT + " = ? "
    + ", " + COLUMN_PLCODE + " = ? "
    + ", " + COLUMN_ESTIMATEDREVENUEGENERATED + " = ? "
    + ", " + COLUMN_ESTIMATEDCOSTSAVING + " = ? "
    + ", " + COLUMN_COBREDUNDANCYREQUIRED + " = ? "
    + ", " + COLUMN_CONNECTIONNAME + " = ? "
    + ", " + COLUMN_STATUS + " = ? "
    + ", " + COLUMN_REQUESTERID + " = ? "
    + ", " + COLUMN_SEMIANNUALENTITLEMENTREVIEW + " = ? "
    + ", " + COLUMN_ISSCONNECTIONCOMPLIANCE + " = ? "
    + ", " + COLUMN_CITIPOLICYADHERENCE + " = ? "
    + ", " + COLUMN_ACCESSCITIGLOBALNETWORK + " = ? "
    + ", " + COLUMN_TPTRAININGAWARNESSPROGRAM + " = ? "
    + ", " + COLUMN_SPONSORBUSINESSCONSULTED + " = ? "
    + ", " + COLUMN_EXPORTLICENSECORDINATOR + " = ? "
    + ", " + COLUMN_LOOKUP_ID + " = ? "
    + ", " + COLUMN_NETCON_ID + " = ? "
    + ", " + COLUMN_RELATIONSHIP_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + ConnectionRequestDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_DISCRIMINATOR
    + ", " + COLUMN_REQUIRENETWORKACCESS 
    + ", " + COLUMN_RATIONALE 
    + ", " + COLUMN_BENEFIT 
    + ", " + COLUMN_PLCODE 
    + ", " + COLUMN_ESTIMATEDREVENUEGENERATED 
    + ", " + COLUMN_ESTIMATEDCOSTSAVING 
    + ", " + COLUMN_COBREDUNDANCYREQUIRED 
    + ", " + COLUMN_CONNECTIONNAME 
    + ", " + COLUMN_STATUS 
    + ", " + COLUMN_REQUESTERID 
    + ", " + COLUMN_SEMIANNUALENTITLEMENTREVIEW 
    + ", " + COLUMN_ISSCONNECTIONCOMPLIANCE 
    + ", " + COLUMN_CITIPOLICYADHERENCE 
    + ", " + COLUMN_ACCESSCITIGLOBALNETWORK 
    + ", " + COLUMN_TPTRAININGAWARNESSPROGRAM 
    + ", " + COLUMN_SPONSORBUSINESSCONSULTED 
    + ", " + COLUMN_EXPORTLICENSECORDINATOR 
    + ", " + COLUMN_LOOKUP_ID
    + ", " + COLUMN_NETCON_ID
    + ", " + COLUMN_RELATIONSHIP_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + ConnectionRequestDAO.TABLE + " WHERE ID = ?";

    /** The Constant SELECT_FACILITIESAFFECTED_REFERENCE_IDS_STMT. */
    private static final String SELECT_FACILITIESAFFECTED_REFERENCE_IDS_STMT = "SELECT " + FacilitiesAffectedXrefDAO.COLUMN_ID + " FROM " + FacilitiesAffectedXrefDAO.TABLE + " WHERE " + FacilitiesAffectedXrefDAO.COLUMN_REQUEST_ID + " = ?";

    /** The Constant SELECT_PROJECTJUSTIFICATIONS_REFERENCE_IDS_STMT. */
    private static final String SELECT_PROJECTJUSTIFICATIONS_REFERENCE_IDS_STMT = "SELECT " + ProjectJustificationXrefDAO.COLUMN_ID + " FROM " + ProjectJustificationXrefDAO.TABLE + " WHERE " + ProjectJustificationXrefDAO.COLUMN_REQUEST_ID + " = ?";

    /** The Constant SELECT_CITICONTACTS_REFERENCE_IDS_STMT. */
    private static final String SELECT_CITICONTACTS_REFERENCE_IDS_STMT = "SELECT " + CitiContactXrefDAO.COLUMN_ID + " FROM " + CitiContactXrefDAO.TABLE + " WHERE " + CitiContactXrefDAO.COLUMN_REQUEST_ID + " = ?";

    /** The Constant SELECT_TPCONTACTS_REFERENCE_IDS_STMT. */
    private static final String SELECT_TPCONTACTS_REFERENCE_IDS_STMT = "SELECT " + TPContactXrefDAO.COLUMN_ID + " FROM " + TPContactXrefDAO.TABLE + " WHERE " + TPContactXrefDAO.COLUMN_REQUEST_ID + " = ?";

    /** The Constant SELECT_RESOURCES_REFERENCE_IDS_STMT. */
    private static final String SELECT_RESOURCES_REFERENCE_IDS_STMT = "SELECT " + ResourceXrefDAO.COLUMN_ID + " FROM " + ResourceXrefDAO.TABLE + " WHERE " + ResourceXrefDAO.COLUMN_REQUEST_ID + " = ?";

    /** The Constant SELECT_DOCUMENT_REFERENCE_IDS_STMT. */
    private static final String SELECT_DOCUMENT_REFERENCE_IDS_STMT = "SELECT " + DocumentMetaDataDAO.COLUMN_ID + " FROM " + DocumentMetaDataDAO.TABLE + " WHERE " + DocumentMetaDataDAO.COLUMN_REQUEST_ID + " = ?";

    /** The Constant SELECT_SERVICES_REFERENCE_IDS_STMT. */
    private static final String SELECT_SERVICES_REFERENCE_IDS_STMT = "SELECT " + TPServiceXrefDAO.COLUMN_ID + " FROM " + TPServiceXrefDAO.TABLE + " WHERE " + TPServiceXrefDAO.COLUMN_REQUEST_ID + " = ?";

    /** The Constant SELECT_MATERIALBILL_REFERENCE_IDS_STMT. */
    private static final String SELECT_MATERIALBILL_REFERENCE_IDS_STMT = "SELECT " + MaterialBillDAO.COLUMN_ID + " FROM " + MaterialBillDAO.TABLE + " WHERE " + MaterialBillDAO.COLUMN_CONNECTIONREQUEST_ID + " = ?";

    /** The Constant SELECT_FIREWALLS_REFERENCE_IDS_STMT. */
    private static final String SELECT_FIREWALLS_REFERENCE_IDS_STMT = "SELECT " + FirewallDetailsDAO.COLUMN_ID + " FROM " + FirewallDetailsDAO.TABLE + " WHERE " + FirewallDetailsDAO.COLUMN_CONNECTIONREQUEST_ID + " = ?";

    /** The Constant SELECT_CONNECTIONREQUEST_REFERENCE_IDS_STMT. */
    private static final String SELECT_CONNECTIONREQUEST_REFERENCE_IDS_STMT = "SELECT " + ConnectionProcessDAO.COLUMN_ID + " FROM " + ConnectionProcessDAO.TABLE + " WHERE " + ConnectionProcessDAO.COLUMN_CONNECTIONREQUEST_ID + " = ?";

    /** The Constant SELECT_CITIREQCONTACTS_REFERENCE_IDS_STMT. */
    private static final String SELECT_CITIREQCONTACTS_REFERENCE_IDS_STMT = "SELECT " + CitiReqContactXrefDAO.COLUMN_ID + " FROM " + CitiReqContactXrefDAO.TABLE + " WHERE " + CitiReqContactXrefDAO.COLUMN_REQUEST_ID + " = ?";


    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the connection request dao
     */
    public static ConnectionRequestDAO createInstance(DatabaseSession session)
    {
	return new ConnectionRequestDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new connection request dao.
     *
     * @param session the session
     */
    public ConnectionRequestDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating ConnectionRequestDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The ConnectionRequestEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionRequestEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionRequestEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The ConnectionRequestEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionRequestEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionRequestEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting ConnectionRequestEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + ConnectionRequestDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER
	    beforeUpdateLookupReferences((ConnectionRequestEntity) entity);

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, ConnectionRequestDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());
	    setStringToStatement(st, position++, entity.getDiscriminator(), COLUMN_DISCRIMINATOR_LEN);

	    // Attributes
	    position = setBooleanToStatement(st, position, entity.getRequireNetworkAccess());
	    position = setStringToStatement(st, position, entity.getRationale(), COLUMN_RATIONALE_LEN);
	    position = setStringToStatement(st, position, entity.getBenefit(), COLUMN_BENEFIT_LEN);
	    position = setStringToStatement(st, position, entity.getPlcode(), COLUMN_PLCODE_LEN);
	    position = setDoubleToStatement(st, position, entity.getEstimatedRevenueGenerated());
	    position = setDoubleToStatement(st, position, entity.getEstimatedCostSaving());
	    position = setBooleanToStatement(st, position, entity.getCobRedundancyRequired());
	    position = setStringToStatement(st, position, entity.getConnectionName(), COLUMN_CONNECTIONNAME_LEN);
	    position = setStringToStatement(st, position, entity.getStatus(), COLUMN_STATUS_LEN);
	    position = setStringToStatement(st, position, entity.getRequesterId(), COLUMN_REQUESTERID_LEN);
	    position = setBooleanToStatement(st, position, entity.getSemiAnnualEntitlementReview());
	    position = setStringToStatement(st, position, entity.getIssConnectionCompliance(), COLUMN_ISSCONNECTIONCOMPLIANCE_LEN);
	    position = setStringToStatement(st, position, entity.getCitiPolicyAdherence(), COLUMN_CITIPOLICYADHERENCE_LEN);
	    position = setBooleanToStatement(st, position, entity.getAccessCitiGlobalNetwork());
	    position = setBooleanToStatement(st, position, entity.getTpTrainingAwarnessProgram());
	    position = setBooleanToStatement(st, position, entity.getSponsorBusinessConsulted());
	    position = setBooleanToStatement(st, position, entity.getExportLicenseCordinator());

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateFacilitiesAffectedReferences((ConnectionRequestEntity) entity);
	    updateProjectJustificationsReferences((ConnectionRequestEntity) entity);
	    updateCitiContactsReferences((ConnectionRequestEntity) entity);
	    updateTpContactsReferences((ConnectionRequestEntity) entity);
	    afterUpdateLookupReferences((ConnectionRequestEntity) entity);
	    updateResourcesReferences((ConnectionRequestEntity) entity);
	    updateDocumentReferences((ConnectionRequestEntity) entity);
	    updateServicesReferences((ConnectionRequestEntity) entity);
	    updateMaterialBillReferences((ConnectionRequestEntity) entity);
	    updateFirewallsReferences((ConnectionRequestEntity) entity);
	    updateConnectionrequestReferences((ConnectionRequestEntity) entity);
	    updateCitiReqContactsReferences((ConnectionRequestEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }

	    // TODO : Inheritance
	    String disc = entity.getDiscriminator();
	    if ("2000".equals(disc))
	    {
		// This is us...
	    }
	    else if ("PLANNING".equals(disc))
	    {
		// Delegate to the PlanningDAO
		PlanningDAO dao = new PlanningDAO(getSession());
		dao.insertPlanningPart((PlanningEntity) entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + ConnectionRequestDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionRequestEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionRequestEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionRequestEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionRequestEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionRequestEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionRequestEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
		log.debug("ConnectionRequestDAO.insert block");
	    // Not created yet
	    return insert(entity, archiver, reset);
	    
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating ConnectionRequestEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + ConnectionRequestDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER
	    beforeUpdateLookupReferences((ConnectionRequestEntity) entity);

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setBooleanToStatement(st, position, entity.getRequireNetworkAccess());
	    position = setStringToStatement(st, position, entity.getRationale(), COLUMN_RATIONALE_LEN);
	    position = setStringToStatement(st, position, entity.getBenefit(), COLUMN_BENEFIT_LEN);
	    position = setStringToStatement(st, position, entity.getPlcode(), COLUMN_PLCODE_LEN);
	    position = setDoubleToStatement(st, position, entity.getEstimatedRevenueGenerated());
	    position = setDoubleToStatement(st, position, entity.getEstimatedCostSaving());
	    position = setBooleanToStatement(st, position, entity.getCobRedundancyRequired());
	    position = setStringToStatement(st, position, entity.getConnectionName(), COLUMN_CONNECTIONNAME_LEN);
	    position = setStringToStatement(st, position, entity.getStatus(), COLUMN_STATUS_LEN);
	    position = setStringToStatement(st, position, entity.getRequesterId(), COLUMN_REQUESTERID_LEN);
	    position = setBooleanToStatement(st, position, entity.getSemiAnnualEntitlementReview());
	    position = setStringToStatement(st, position, entity.getIssConnectionCompliance(), COLUMN_ISSCONNECTIONCOMPLIANCE_LEN);
	    position = setStringToStatement(st, position, entity.getCitiPolicyAdherence(), COLUMN_CITIPOLICYADHERENCE_LEN);
	    position = setBooleanToStatement(st, position, entity.getAccessCitiGlobalNetwork());
	    position = setBooleanToStatement(st, position, entity.getTpTrainingAwarnessProgram());
	    position = setBooleanToStatement(st, position, entity.getSponsorBusinessConsulted());
	    position = setBooleanToStatement(st, position, entity.getExportLicenseCordinator());

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateFacilitiesAffectedReferences((ConnectionRequestEntity) entity);
	    updateProjectJustificationsReferences((ConnectionRequestEntity) entity);
	    updateCitiContactsReferences((ConnectionRequestEntity) entity);
	    updateTpContactsReferences((ConnectionRequestEntity) entity);
	    afterUpdateLookupReferences((ConnectionRequestEntity) entity);
	    updateResourcesReferences((ConnectionRequestEntity) entity);
	    updateDocumentReferences((ConnectionRequestEntity) entity);
	    updateServicesReferences((ConnectionRequestEntity) entity);
	    updateMaterialBillReferences((ConnectionRequestEntity) entity);
	    updateFirewallsReferences((ConnectionRequestEntity) entity);
	    updateConnectionrequestReferences((ConnectionRequestEntity) entity);
	    updateCitiReqContactsReferences((ConnectionRequestEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }

	    // TODO : Inheritance
	    String disc = entity.getDiscriminator();
	    if ("2000".equals(disc))
	    {
		// This is us...
	    }
	    else if ("PLANNING".equals(disc))
	    {
		// Delegate to the PlanningDAO
		PlanningDAO dao = new PlanningDAO(getSession());
		dao.updatePlanningPart((PlanningEntity) entity);
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + ConnectionRequestDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public ConnectionRequestEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public ConnectionRequestEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	ConnectionRequestEntity obj = (ConnectionRequestEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	
	if(obj != null)
	{
	    log.debug(">>> ConnectionRequestEntity >>> already LOADED !!!"); 
	    log.debug("Getting ConnectionRequestEntity with id = " + id_to_get); 
		log.debug("ConnectionRequestDao.semiAnnualElementReview1::"+obj.getSemiAnnualEntitlementReview());
	}

	if(obj == null)
	{
		log.debug(">>> ConnectionRequestEntity >>> not LOADED,trying to load !!!"); 
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (ConnectionRequestEntity) createEntity(rs);
		}
		//log.debug("ConnectionRequestDao.semiAnnualElementReview2::"+obj.getSemiAnnualEntitlementReview());
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + ConnectionRequestDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + ConnectionRequestDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting ConnectionRequestEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    ConnectionRequestEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (ConnectionRequestEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (ConnectionRequestEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + ConnectionRequestDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type ConnectionRequestEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		ConnectionRequestEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM CON_REQ";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (ConnectionRequestEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + ConnectionRequestDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type ConnectionRequestEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + ConnectionRequestDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    ConnectionRequestEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    ConnectionRequestEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(ConnectionRequestEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(ConnectionRequestEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }

	    // TODO : Inheritance
	    String disc = entity.getDiscriminator();
	    if ("2000".equals(disc))
	    {
		// This is us...
	    }
	    else if ("PLANNING".equals(disc))
	    {
		// Delegate to the PlanningDAO
		PlanningDAO dao = new PlanningDAO(getSession());
		dao.deletePlanningPart((PlanningEntity) entity);
	    }

	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...
		if(entity.getOriginalLookupId() != null)
		{
		    CommonLookupDataDAO lookupDAO = getLookupDAO();
		    if(entity.getOriginalLookup() != null)
		    {
			lookupDAO.delete(entity.getOriginalLookup());
		    }
		    else
		    {
			lookupDAO.delete(entity.getOriginalLookupId());
		    }
		}

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + ConnectionRequestDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();

	    // Go through the many association list and delete any entities that exist in it.
	    FacilitiesAffectedXrefDAO facilitiesAffectedDAO = getFacilitiesAffectedDAO();
	    List original_facilitiesAffected_ids = entity.getOriginalFacilitiesAffectedIds();
	    Iterator facilitiesAffectedIt = entity.getFacilitiesAffected().getDeletedList().iterator();
	    while (facilitiesAffectedIt.hasNext())
	    {
		FacilitiesAffectedXrefEntity o = (FacilitiesAffectedXrefEntity)facilitiesAffectedIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_facilitiesAffected_ids.remove(id);
		}
		facilitiesAffectedDAO.delete(o);
	    }

	    facilitiesAffectedIt = entity.getFacilitiesAffected().iterator();
	    while (facilitiesAffectedIt.hasNext())
	    {
		FacilitiesAffectedXrefEntity o = (FacilitiesAffectedXrefEntity)facilitiesAffectedIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_facilitiesAffected_ids.remove(id);
		}
		facilitiesAffectedDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    facilitiesAffectedDAO.delete(original_facilitiesAffected_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    ProjectJustificationXrefDAO projectJustificationsDAO = getProjectJustificationsDAO();
	    List original_projectJustifications_ids = entity.getOriginalProjectJustificationsIds();
	    Iterator projectJustificationsIt = entity.getProjectJustifications().getDeletedList().iterator();
	    while (projectJustificationsIt.hasNext())
	    {
		ProjectJustificationXrefEntity o = (ProjectJustificationXrefEntity)projectJustificationsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_projectJustifications_ids.remove(id);
		}
		projectJustificationsDAO.delete(o);
	    }

	    projectJustificationsIt = entity.getProjectJustifications().iterator();
	    while (projectJustificationsIt.hasNext())
	    {
		ProjectJustificationXrefEntity o = (ProjectJustificationXrefEntity)projectJustificationsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_projectJustifications_ids.remove(id);
		}
		projectJustificationsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    projectJustificationsDAO.delete(original_projectJustifications_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    CitiContactXrefDAO citiContactsDAO = getCitiContactsDAO();
	    List original_citiContacts_ids = entity.getOriginalCitiContactsIds();
	    Iterator citiContactsIt = entity.getCitiContacts().getDeletedList().iterator();
	    while (citiContactsIt.hasNext())
	    {
		CitiContactXrefEntity o = (CitiContactXrefEntity)citiContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiContacts_ids.remove(id);
		}
		citiContactsDAO.delete(o);
	    }

	    citiContactsIt = entity.getCitiContacts().iterator();
	    while (citiContactsIt.hasNext())
	    {
		CitiContactXrefEntity o = (CitiContactXrefEntity)citiContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiContacts_ids.remove(id);
		}
		citiContactsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    citiContactsDAO.delete(original_citiContacts_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    TPContactXrefDAO tpContactsDAO = getTpContactsDAO();
	    List original_tpContacts_ids = entity.getOriginalTpContactsIds();
	    Iterator tpContactsIt = entity.getTpContacts().getDeletedList().iterator();
	    while (tpContactsIt.hasNext())
	    {
		TPContactXrefEntity o = (TPContactXrefEntity)tpContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_tpContacts_ids.remove(id);
		}
		tpContactsDAO.delete(o);
	    }

	    tpContactsIt = entity.getTpContacts().iterator();
	    while (tpContactsIt.hasNext())
	    {
		TPContactXrefEntity o = (TPContactXrefEntity)tpContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_tpContacts_ids.remove(id);
		}
		tpContactsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    tpContactsDAO.delete(original_tpContacts_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    ResourceXrefDAO resourcesDAO = getResourcesDAO();
	    List original_resources_ids = entity.getOriginalResourcesIds();
	    Iterator resourcesIt = entity.getResources().getDeletedList().iterator();
	    while (resourcesIt.hasNext())
	    {
		ResourceXrefEntity o = (ResourceXrefEntity)resourcesIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_resources_ids.remove(id);
		}
		resourcesDAO.delete(o);
	    }

	    resourcesIt = entity.getResources().iterator();
	    while (resourcesIt.hasNext())
	    {
		ResourceXrefEntity o = (ResourceXrefEntity)resourcesIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_resources_ids.remove(id);
		}
		resourcesDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    resourcesDAO.delete(original_resources_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    DocumentMetaDataDAO documentDAO = getDocumentDAO();
	    List original_document_ids = entity.getOriginalDocumentIds();
	    Iterator documentIt = entity.getDocument().getDeletedList().iterator();
	    while (documentIt.hasNext())
	    {
		DocumentMetaDataEntity o = (DocumentMetaDataEntity)documentIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_document_ids.remove(id);
		}
		documentDAO.delete(o);
	    }

	    documentIt = entity.getDocument().iterator();
	    while (documentIt.hasNext())
	    {
		DocumentMetaDataEntity o = (DocumentMetaDataEntity)documentIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_document_ids.remove(id);
		}
		documentDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    documentDAO.delete(original_document_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    TPServiceXrefDAO servicesDAO = getServicesDAO();
	    List original_services_ids = entity.getOriginalServicesIds();
	    Iterator servicesIt = entity.getServices().getDeletedList().iterator();
	    while (servicesIt.hasNext())
	    {
		TPServiceXrefEntity o = (TPServiceXrefEntity)servicesIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_services_ids.remove(id);
		}
		servicesDAO.delete(o);
	    }

	    servicesIt = entity.getServices().iterator();
	    while (servicesIt.hasNext())
	    {
		TPServiceXrefEntity o = (TPServiceXrefEntity)servicesIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_services_ids.remove(id);
		}
		servicesDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    servicesDAO.delete(original_services_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    MaterialBillDAO materialBillDAO = getMaterialBillDAO();
	    List original_materialBill_ids = entity.getOriginalMaterialBillIds();
	    Iterator materialBillIt = entity.getMaterialBill().getDeletedList().iterator();
	    while (materialBillIt.hasNext())
	    {
		MaterialBillEntity o = (MaterialBillEntity)materialBillIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_materialBill_ids.remove(id);
		}
		materialBillDAO.delete(o);
	    }

	    materialBillIt = entity.getMaterialBill().iterator();
	    while (materialBillIt.hasNext())
	    {
		MaterialBillEntity o = (MaterialBillEntity)materialBillIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_materialBill_ids.remove(id);
		}
		materialBillDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    materialBillDAO.delete(original_materialBill_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    FirewallDetailsDAO firewallsDAO = getFirewallsDAO();
	    List original_firewalls_ids = entity.getOriginalFirewallsIds();
	    Iterator firewallsIt = entity.getFirewalls().getDeletedList().iterator();
	    while (firewallsIt.hasNext())
	    {
		FirewallDetailsEntity o = (FirewallDetailsEntity)firewallsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_firewalls_ids.remove(id);
		}
		firewallsDAO.delete(o);
	    }

	    firewallsIt = entity.getFirewalls().iterator();
	    while (firewallsIt.hasNext())
	    {
		FirewallDetailsEntity o = (FirewallDetailsEntity)firewallsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_firewalls_ids.remove(id);
		}
		firewallsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    firewallsDAO.delete(original_firewalls_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    ConnectionProcessDAO connectionrequestDAO = getConnectionrequestDAO();
	    List original_connectionrequest_ids = entity.getOriginalConnectionrequestIds();
	    Iterator connectionrequestIt = entity.getConnectionrequest().getDeletedList().iterator();
	    while (connectionrequestIt.hasNext())
	    {
		ConnectionProcessEntity o = (ConnectionProcessEntity)connectionrequestIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_connectionrequest_ids.remove(id);
		}
		connectionrequestDAO.delete(o);
	    }

	    connectionrequestIt = entity.getConnectionrequest().iterator();
	    while (connectionrequestIt.hasNext())
	    {
		ConnectionProcessEntity o = (ConnectionProcessEntity)connectionrequestIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_connectionrequest_ids.remove(id);
		}
		connectionrequestDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    connectionrequestDAO.delete(original_connectionrequest_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    CitiReqContactXrefDAO citiReqContactsDAO = getCitiReqContactsDAO();
	    List original_citiReqContacts_ids = entity.getOriginalCitiReqContactsIds();
	    Iterator citiReqContactsIt = entity.getCitiReqContacts().getDeletedList().iterator();
	    while (citiReqContactsIt.hasNext())
	    {
		CitiReqContactXrefEntity o = (CitiReqContactXrefEntity)citiReqContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiReqContacts_ids.remove(id);
		}
		citiReqContactsDAO.delete(o);
	    }

	    citiReqContactsIt = entity.getCitiReqContacts().iterator();
	    while (citiReqContactsIt.hasNext())
	    {
		CitiReqContactXrefEntity o = (CitiReqContactXrefEntity)citiReqContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiReqContacts_ids.remove(id);
		}
		citiReqContactsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    citiReqContactsDAO.delete(original_citiReqContacts_ids);
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + ConnectionRequestDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	ConnectionRequestEntity entity = (ConnectionRequestEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 2;

	    //			entity.setRequireNetworkAccess(getBooleanFromResultSet(rs, COLUMN_REQUIRENETWORKACCESS));
	    entity.setRequireNetworkAccess(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequireNetworkAccess(entity.getRequireNetworkAccess());
	    //			entity.setRationale(getStringFromResultSet(rs, COLUMN_RATIONALE));
	    entity.setRationale(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRationale(entity.getRationale());
	    //			entity.setBenefit(getStringFromResultSet(rs, COLUMN_BENEFIT));
	    entity.setBenefit(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalBenefit(entity.getBenefit());
	    //			entity.setPlcode(getStringFromResultSet(rs, COLUMN_PLCODE));
	    entity.setPlcode(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalPlcode(entity.getPlcode());
	    //			entity.setEstimatedRevenueGenerated(getDoubleFromResultSet(rs, COLUMN_ESTIMATEDREVENUEGENERATED));
	    entity.setEstimatedRevenueGenerated(getDoubleFromResultSetIndexed(rs, ++index));
	    entity.setOriginalEstimatedRevenueGenerated(entity.getEstimatedRevenueGenerated());
	    //			entity.setEstimatedCostSaving(getDoubleFromResultSet(rs, COLUMN_ESTIMATEDCOSTSAVING));
	    entity.setEstimatedCostSaving(getDoubleFromResultSetIndexed(rs, ++index));
	    entity.setOriginalEstimatedCostSaving(entity.getEstimatedCostSaving());
	    //			entity.setCobRedundancyRequired(getBooleanFromResultSet(rs, COLUMN_COBREDUNDANCYREQUIRED));
	    entity.setCobRedundancyRequired(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalCobRedundancyRequired(entity.getCobRedundancyRequired());
	    //			entity.setConnectionName(getStringFromResultSet(rs, COLUMN_CONNECTIONNAME));
	    entity.setConnectionName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalConnectionName(entity.getConnectionName());
	    //			entity.setStatus(getStringFromResultSet(rs, COLUMN_STATUS));
	    entity.setStatus(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalStatus(entity.getStatus());
	    //			entity.setRequesterId(getStringFromResultSet(rs, COLUMN_REQUESTERID));
	    entity.setRequesterId(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequesterId(entity.getRequesterId());
	    //			entity.setSemiAnnualEntitlementReview(getBooleanFromResultSet(rs, COLUMN_SEMIANNUALENTITLEMENTREVIEW));
	    log.debug("CreateEntity::SemiAnnualEntitlementReview::"+getStringFromResultSetIndexed(rs, index+1));
	    entity.setSemiAnnualEntitlementReview(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSemiAnnualEntitlementReview(entity.getSemiAnnualEntitlementReview());
	    //			entity.setIssConnectionCompliance(getStringFromResultSet(rs, COLUMN_ISSCONNECTIONCOMPLIANCE));
	    entity.setIssConnectionCompliance(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIssConnectionCompliance(entity.getIssConnectionCompliance());
	    //			entity.setCitiPolicyAdherence(getStringFromResultSet(rs, COLUMN_CITIPOLICYADHERENCE));
	    entity.setCitiPolicyAdherence(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalCitiPolicyAdherence(entity.getCitiPolicyAdherence());
	    //			entity.setAccessCitiGlobalNetwork(getBooleanFromResultSet(rs, COLUMN_ACCESSCITIGLOBALNETWORK));
	    entity.setAccessCitiGlobalNetwork(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalAccessCitiGlobalNetwork(entity.getAccessCitiGlobalNetwork());
	    //			entity.setTpTrainingAwarnessProgram(getBooleanFromResultSet(rs, COLUMN_TPTRAININGAWARNESSPROGRAM));
	    entity.setTpTrainingAwarnessProgram(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalTpTrainingAwarnessProgram(entity.getTpTrainingAwarnessProgram());
	    //			entity.setSponsorBusinessConsulted(getBooleanFromResultSet(rs, COLUMN_SPONSORBUSINESSCONSULTED));
	    entity.setSponsorBusinessConsulted(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSponsorBusinessConsulted(entity.getSponsorBusinessConsulted());
	    //			entity.setExportLicenseCordinator(getBooleanFromResultSet(rs, COLUMN_EXPORTLICENSECORDINATOR));
	    entity.setExportLicenseCordinator(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalExportLicenseCordinator(entity.getExportLicenseCordinator());

	    // Single References
	    //			entity.setLookupId(getLongFromResultSet(rs, COLUMN_LOOKUP_ID));
	    entity.setLookupId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalLookupId(entity.getLookupId());
	    //			entity.setNetConId(getLongFromResultSet(rs, COLUMN_NETCON_ID));
	    entity.setNetConId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalNetConId(entity.getNetConId());
	    //			entity.setRelationshipId(getLongFromResultSet(rs, COLUMN_RELATIONSHIP_ID));
	    entity.setRelationshipId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRelationshipId(entity.getRelationshipId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	ConnectionRequestEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (ConnectionRequestEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		// TODO : Inheritance
		String disc = getStringFromResultSet(rs, COLUMN_DISCRIMINATOR);
		if ("2000".equals(disc))
		{
		    // This is us...
		    entity = new ConnectionRequestEntity(_id);
		} else if ("PLANNING".equals(disc)) {
		    // Delegate to the PlanningDAO
		    PlanningDAO dao = new PlanningDAO(getSession());
		    entity = new PlanningEntity(_id);
		    dao.loadPlanningPart(entity);
		}
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	ConnectionRequestEntity entity = (ConnectionRequestEntity)obj;
	loadFacilitiesAffectedReferenceIds(entity);
	loadProjectJustificationsReferenceIds(entity);
	loadCitiContactsReferenceIds(entity);
	loadTpContactsReferenceIds(entity);
	loadResourcesReferenceIds(entity);
	loadDocumentReferenceIds(entity);
	loadServicesReferenceIds(entity);
	loadMaterialBillReferenceIds(entity);
	loadFirewallsReferenceIds(entity);
	loadConnectionrequestReferenceIds(entity);
	loadCitiReqContactsReferenceIds(entity);
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("CitiReqContactXrefDAO.loadReferences(): References for ConnectionRequestEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("CitiReqContactXrefDAO.loadReferences(): Loading references for ConnectionRequestEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    ConnectionRequestEntity entity = (ConnectionRequestEntity)obj;

	    loadFacilitiesAffectedReferences(entity);

	    loadProjectJustificationsReferences(entity);

	    loadCitiContactsReferences(entity);

	    loadTpContactsReferences(entity);

	    Long lookupId = entity.getLookupId();
	    if (lookupId != null)
	    {
		//			CommonLookupDataDAO lookupDAO = new CommonLookupDataDAO(getSession());
		CommonLookupDataDAO lookupDAO = getLookupDAO();
		entity.setLookup((CommonLookupDataEntity)lookupDAO.get(lookupId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalLookup(entity.getLookup());
		// Set the bi-directional reference to us
		if (entity.getLookup() != null)
		{
		    entity.getLookup().setOriginalRequest(entity);
		    entity.getLookup().setRequest(entity);
		}
	    }

	    loadResourcesReferences(entity);

	    loadDocumentReferences(entity);

	    Long netConId = entity.getNetConId();
	    if (netConId != null)
	    {
		//			NetworkConnectionDAO netConDAO = new NetworkConnectionDAO(getSession());
		NetworkConnectionDAO netConDAO = getNetConDAO();
		entity.setNetCon((NetworkConnectionEntity)netConDAO.get(netConId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalNetCon(entity.getNetCon());
	    }

	    loadServicesReferences(entity);

	    Long relationshipId = entity.getRelationshipId();
	    if (relationshipId != null)
	    {
		//			RelationshipDAO relationshipDAO = new RelationshipDAO(getSession());
		RelationshipDAO relationshipDAO = getRelationshipDAO();
		entity.setRelationship((RelationshipEntity)relationshipDAO.get(relationshipId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalRelationship(entity.getRelationship());
	    }

	    loadMaterialBillReferences(entity);

	    loadFirewallsReferences(entity);

	    loadConnectionrequestReferences(entity);

	    loadCitiReqContactsReferences(entity);

	    // TODO : Inheritance
	    String disc = entity.getDiscriminator();
	    if ("2000".equals(disc))
	    {
		// This is us...
	    }
	    else if ("PLANNING".equals(disc))
	    {
		// Delegate to the PlanningDAO
		PlanningDAO dao = new PlanningDAO(getSession());
		//			PlanningDAO dao = getPlanningDAO();
		dao.loadPlanningReferences(entity);
	    }
	}
	catch(Exception e)
	{
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for ConnectionRequestEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load lookup with id.
     *
     * @param id the id
     * @return the common lookup data entity
     * @throws DatabaseException the database exception
     */
    public CommonLookupDataEntity loadLookupWithId(Long id) throws DatabaseException
    {
	CommonLookupDataEntity entity = null;
	if (id != null)
	{
	    //			CommonLookupDataDAO lookupDAO = new CommonLookupDataDAO(getSession());
	    CommonLookupDataDAO lookupDAO = getLookupDAO();
	    entity = (CommonLookupDataEntity)lookupDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load net con with id.
     *
     * @param id the id
     * @return the network connection entity
     * @throws DatabaseException the database exception
     */
    public NetworkConnectionEntity loadNetConWithId(Long id) throws DatabaseException
    {
	NetworkConnectionEntity entity = null;
	if (id != null)
	{
	    //			NetworkConnectionDAO netConDAO = new NetworkConnectionDAO(getSession());
	    NetworkConnectionDAO netConDAO = getNetConDAO();
	    entity = (NetworkConnectionEntity)netConDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load relationship with id.
     *
     * @param id the id
     * @return the relationship entity
     * @throws DatabaseException the database exception
     */
    public RelationshipEntity loadRelationshipWithId(Long id) throws DatabaseException
    {
	RelationshipEntity entity = null;
	if (id != null)
	{
	    //			RelationshipDAO relationshipDAO = new RelationshipDAO(getSession());
	    RelationshipDAO relationshipDAO = getRelationshipDAO();
	    entity = (RelationshipEntity)relationshipDAO.get(id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	ConnectionRequestEntity entity = (ConnectionRequestEntity) obj;

	setLongToStatement(st, position++, entity.getLookup() != null ? entity.getLookup().getId() : entity.getLookupId());
	setLongToStatement(st, position++, entity.getNetCon() != null ? entity.getNetCon().getId() : entity.getNetConId());
	setLongToStatement(st, position++, entity.getRelationship() != null ? entity.getRelationship().getId() : entity.getRelationshipId());

	return position;
    }

    // Many Composition 'facilitiesAffected' helpers 'request'
    //======================================================================
    /**
     * Loads all the FacilitiesAffectedXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadFacilitiesAffectedReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadFacilitiesAffectedReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the FacilitiesAffectedXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadFacilitiesAffectedReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading FacilitiesAffected references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getFacilitiesAffected();
	    List id_list = entity.getOriginalFacilitiesAffectedIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		FacilitiesAffectedXrefDAO dao = getFacilitiesAffectedDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		FacilitiesAffectedXrefDAO dao = getFacilitiesAffectedDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading FacilitiesAffected references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load FacilitiesAffected References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setFacilitiesAffected(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the FacilitiesAffected references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadFacilitiesAffectedReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_FACILITIESAFFECTED_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalFacilitiesAffectedIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load FacilitiesAffected Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update facilities affected references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateFacilitiesAffectedReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList facilitiesAffected = entity.getFacilitiesAffected();
	FacilitiesAffectedXrefDAO dao = getFacilitiesAffectedDAO();

	Iterator itDeleted = facilitiesAffected.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    FacilitiesAffectedXrefEntity e = (FacilitiesAffectedXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = facilitiesAffected.iterator();
	while (it.hasNext())
	{
	    FacilitiesAffectedXrefEntity e = (FacilitiesAffectedXrefEntity) it.next();
	    e.setRequest(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'projectJustifications' helpers 'request'
    //======================================================================
    /**
     * Loads all the ProjectJustificationXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadProjectJustificationsReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadProjectJustificationsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the ProjectJustificationXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadProjectJustificationsReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading ProjectJustifications references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getProjectJustifications();
	    List id_list = entity.getOriginalProjectJustificationsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ProjectJustificationXrefDAO dao = getProjectJustificationsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ProjectJustificationXrefDAO dao = getProjectJustificationsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading ProjectJustifications references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ProjectJustifications References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setProjectJustifications(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the ProjectJustifications references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadProjectJustificationsReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_PROJECTJUSTIFICATIONS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalProjectJustificationsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ProjectJustifications Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update project justifications references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateProjectJustificationsReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList projectJustifications = entity.getProjectJustifications();
	ProjectJustificationXrefDAO dao = getProjectJustificationsDAO();

	Iterator itDeleted = projectJustifications.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    ProjectJustificationXrefEntity e = (ProjectJustificationXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = projectJustifications.iterator();
	while (it.hasNext())
	{
	    ProjectJustificationXrefEntity e = (ProjectJustificationXrefEntity) it.next();
	    e.setRequest(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'citiContacts' helpers 'request'
    //======================================================================
    /**
     * Loads all the CitiContactXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadCitiContactsReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadCitiContactsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the CitiContactXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadCitiContactsReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading CitiContacts references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getCitiContacts();
	    List id_list = entity.getOriginalCitiContactsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		CitiContactXrefExtDAO dao = getCitiContactsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		CitiContactXrefExtDAO dao = getCitiContactsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading CitiContacts references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiContacts References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setCitiContacts(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the CitiContacts references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadCitiContactsReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_CITICONTACTS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalCitiContactsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiContacts Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update citi contacts references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateCitiContactsReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList citiContacts = entity.getCitiContacts();
	CitiContactXrefExtDAO dao = getCitiContactsDAO();

	Iterator itDeleted = citiContacts.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    CitiContactXrefEntity e = (CitiContactXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = citiContacts.iterator();
	while (it.hasNext())
	{
	    CitiContactXrefEntity e = (CitiContactXrefEntity) it.next();
	    e.setRequest(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'tpContacts' helpers 'request'
    //======================================================================
    /**
     * Loads all the TPContactXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadTpContactsReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadTpContactsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the TPContactXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadTpContactsReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading TpContacts references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getTpContacts();
	    List id_list = entity.getOriginalTpContactsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		TPContactXrefDAO dao = getTpContactsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		TPContactXrefDAO dao = getTpContactsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading TpContacts references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load TpContacts References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setTpContacts(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the TpContacts references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadTpContactsReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_TPCONTACTS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalTpContactsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load TpContacts Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update tp contacts references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateTpContactsReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList tpContacts = entity.getTpContacts();
	TPContactXrefDAO dao = getTpContactsDAO();

	Iterator itDeleted = tpContacts.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    TPContactXrefEntity e = (TPContactXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = tpContacts.iterator();
	while (it.hasNext())
	{
	    TPContactXrefEntity e = (TPContactXrefEntity) it.next();
	    e.setRequest(entity);
	    dao.update(e, false);
	}
    }
    // Single Composition 'lookup' helpers 'request'
    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void beforeUpdateLookupReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	if (entity.getLookup() != null)
	{
	    CommonLookupDataDAO dao = getLookupDAO();
	    dao.update(entity.getLookup(), false);
	}
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void afterUpdateLookupReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	if (entity.getOriginalLookupId() != null && !entity.getOriginalLookupId().equals(entity.getLookupId()))
	{
	    CommonLookupDataDAO dao = getLookupDAO();
	    if(entity.getOriginalLookup() != null)
	    {
		dao.delete(entity.getOriginalLookup());
	    }
	    else
	    {
		dao.delete(entity.getOriginalLookupId());
	    }
	}

	//		if (entity.getOriginalLookup() != null && !entity.getOriginalLookup().equals(entity.getLookup()))
	//		{
	//			CommonLookupDataDAO dao = getLookupDAO();
	//			dao.delete(entity.getOriginalLookup());
	//		}
    }

    // Many Composition 'resources' helpers 'request'
    //======================================================================
    /**
     * Loads all the ResourceXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadResourcesReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadResourcesReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the ResourceXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadResourcesReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Resources references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getResources();
	    List id_list = entity.getOriginalResourcesIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ResourceXrefDAO dao = getResourcesDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ResourceXrefDAO dao = getResourcesDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Resources references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Resources References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setResources(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Resources references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadResourcesReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_RESOURCES_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalResourcesIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Resources Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update resources references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateResourcesReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList resources = entity.getResources();
	ResourceXrefDAO dao = getResourcesDAO();

	Iterator itDeleted = resources.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    ResourceXrefEntity e = (ResourceXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = resources.iterator();
	while (it.hasNext())
	{
	    ResourceXrefEntity e = (ResourceXrefEntity) it.next();
	    e.setRequest(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'document' helpers 'request'
    //======================================================================
    /**
     * Loads all the DocumentMetaData references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadDocumentReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadDocumentReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the DocumentMetaData references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadDocumentReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Document references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getDocument();
	    List id_list = entity.getOriginalDocumentIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		DocumentMetaDataDAO dao = getDocumentDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		DocumentMetaDataDAO dao = getDocumentDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Document references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Document References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setDocument(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Document references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadDocumentReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_DOCUMENT_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalDocumentIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Document Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update document references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateDocumentReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList document = entity.getDocument();
	DocumentMetaDataDAO dao = getDocumentDAO();

	Iterator itDeleted = document.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    DocumentMetaDataEntity e = (DocumentMetaDataEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = document.iterator();
	while (it.hasNext())
	{
	    DocumentMetaDataEntity e = (DocumentMetaDataEntity) it.next();
	    e.setRequest(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'netCon' helpers 'ConnectionRequest' does not need helper
    // Many Composition 'services' helpers 'request'
    //======================================================================
    /**
     * Loads all the TPServiceXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadServicesReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadServicesReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the TPServiceXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadServicesReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Services references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getServices();
	    List id_list = entity.getOriginalServicesIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		TPServiceXrefDAO dao = getServicesDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		TPServiceXrefDAO dao = getServicesDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Services references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Services References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setServices(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Services references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadServicesReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_SERVICES_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalServicesIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Services Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update services references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateServicesReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList services = entity.getServices();
	TPServiceXrefDAO dao = getServicesDAO();

	Iterator itDeleted = services.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    TPServiceXrefEntity e = (TPServiceXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = services.iterator();
	while (it.hasNext())
	{
	    TPServiceXrefEntity e = (TPServiceXrefEntity) it.next();
	    e.setRequest(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'relationship' helpers 'ConnectionRequest' does not need helper
    // Many Composition 'materialBill' helpers 'ConnectionRequest'
    //======================================================================
    /**
     * Loads all the MaterialBill references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadMaterialBillReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadMaterialBillReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the MaterialBill references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadMaterialBillReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading MaterialBill references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getMaterialBill();
	    List id_list = entity.getOriginalMaterialBillIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		MaterialBillDAO dao = getMaterialBillDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		MaterialBillDAO dao = getMaterialBillDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading MaterialBill references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load MaterialBill References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setMaterialBill(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the MaterialBill references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadMaterialBillReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_MATERIALBILL_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalMaterialBillIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load MaterialBill Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update material bill references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateMaterialBillReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList materialBill = entity.getMaterialBill();
	MaterialBillDAO dao = getMaterialBillDAO();

	Iterator itDeleted = materialBill.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    MaterialBillEntity e = (MaterialBillEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = materialBill.iterator();
	while (it.hasNext())
	{
	    MaterialBillEntity e = (MaterialBillEntity) it.next();
	    e.setConnectionRequest(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'firewalls' helpers 'connectionRequest'
    //======================================================================
    /**
     * Loads all the FirewallDetails references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadFirewallsReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadFirewallsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the FirewallDetails references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadFirewallsReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Firewalls references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getFirewalls();
	    List id_list = entity.getOriginalFirewallsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		FirewallDetailsDAO dao = getFirewallsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		FirewallDetailsDAO dao = getFirewallsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Firewalls references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Firewalls References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setFirewalls(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Firewalls references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadFirewallsReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_FIREWALLS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalFirewallsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Firewalls Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update firewalls references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateFirewallsReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList firewalls = entity.getFirewalls();
	FirewallDetailsDAO dao = getFirewallsDAO();

	Iterator itDeleted = firewalls.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    FirewallDetailsEntity e = (FirewallDetailsEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = firewalls.iterator();
	while (it.hasNext())
	{
	    FirewallDetailsEntity e = (FirewallDetailsEntity) it.next();
	    e.setConnectionRequest(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'connectionrequest' helpers 'ConnectionRequest'
    //======================================================================
    /**
     * Loads all the ConnectionProcess references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadConnectionrequestReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadConnectionrequestReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the ConnectionProcess references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadConnectionrequestReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Connectionrequest references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getConnectionrequest();
	    List id_list = entity.getOriginalConnectionrequestIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ConnectionProcessDAO dao = getConnectionrequestDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ConnectionProcessDAO dao = getConnectionrequestDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Connectionrequest references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Connectionrequest References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setConnectionrequest(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Connectionrequest references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadConnectionrequestReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_CONNECTIONREQUEST_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalConnectionrequestIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Connectionrequest Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update connectionrequest references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateConnectionrequestReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList connectionrequest = entity.getConnectionrequest();
	ConnectionProcessDAO dao = getConnectionrequestDAO();

	Iterator itDeleted = connectionrequest.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    ConnectionProcessEntity e = (ConnectionProcessEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = connectionrequest.iterator();
	while (it.hasNext())
	{
	    ConnectionProcessEntity e = (ConnectionProcessEntity) it.next();
	    e.setConnectionRequest(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'citiReqContacts' helpers 'request'
    //======================================================================
    /**
     * Loads all the CitiReqContactXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadCitiReqContactsReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	loadCitiReqContactsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the CitiReqContactXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadCitiReqContactsReferences(ConnectionRequestEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading CitiReqContacts references for ConnectionRequestEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getCitiReqContacts();
	    List id_list = entity.getOriginalCitiReqContactsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		CitiReqContactXrefExtDAO dao = getCitiReqContactsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		CitiReqContactXrefExtDAO dao = getCitiReqContactsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading CitiReqContacts references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiReqContacts References for ConnectionRequestEntity [" + entity.getId() + "].", e);
	}


	//		entity.setCitiReqContacts(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the CitiReqContacts references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadCitiReqContactsReferenceIds(ConnectionRequestEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_CITIREQCONTACTS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalCitiReqContactsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiReqContacts Reference IDs from ConnectionRequestEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update citi req contacts references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateCitiReqContactsReferences(ConnectionRequestEntity entity) throws DatabaseException
    {
	ManyAssociationList citiReqContacts = entity.getCitiReqContacts();
	CitiReqContactXrefExtDAO dao = getCitiReqContactsDAO();

	Iterator itDeleted = citiReqContacts.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    CitiReqContactXrefEntity e = (CitiReqContactXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = citiReqContacts.iterator();
	while (it.hasNext())
	{
	    CitiReqContactXrefEntity e = (CitiReqContactXrefEntity) it.next();
	    e.setRequest(entity);
	    dao.update(e, false);
	}
    }

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A FacilitiesAffectedXrefDAO object 
     */
    protected FacilitiesAffectedXrefDAO getFacilitiesAffectedDAO()
    {
	FacilitiesAffectedXrefDAO dao = (FacilitiesAffectedXrefDAO)getSession().getDAO("FacilitiesAffectedXref");  
	if(dao == null)
	{
	    dao = new FacilitiesAffectedXrefDAO(getSession());  		
	    getSession().putDAO("FacilitiesAffectedXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ProjectJustificationXrefDAO object 
     */
    protected ProjectJustificationXrefDAO getProjectJustificationsDAO()
    {
	ProjectJustificationXrefDAO dao = (ProjectJustificationXrefDAO)getSession().getDAO("ProjectJustificationXref");  
	if(dao == null)
	{
	    dao = new ProjectJustificationXrefDAO(getSession());  		
	    getSession().putDAO("ProjectJustificationXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A CitiContactXrefDAO object 
     */
    protected CitiContactXrefExtDAO getCitiContactsDAO()
    {
	CitiContactXrefExtDAO dao = (CitiContactXrefExtDAO)getSession().getDAO("CitiContactXref");  
	if(dao == null)
	{
	    dao = new CitiContactXrefExtDAO(getSession());  		
	    getSession().putDAO("CitiContactXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A TPContactXrefDAO object 
     */
    protected TPContactXrefDAO getTpContactsDAO()
    {
	TPContactXrefDAO dao = (TPContactXrefDAO)getSession().getDAO("TPContactXref");  
	if(dao == null)
	{
	    dao = new TPContactXrefDAO(getSession());  		
	    getSession().putDAO("TPContactXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A CommonLookupDataDAO object 
     */
    protected CommonLookupDataDAO getLookupDAO()
    {
	CommonLookupDataDAO dao = (CommonLookupDataDAO)getSession().getDAO("CommonLookupData");  
	if(dao == null)
	{
	    dao = new CommonLookupDataDAO(getSession());  		
	    getSession().putDAO("CommonLookupData", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ResourceXrefDAO object 
     */
    protected ResourceXrefDAO getResourcesDAO()
    {
	ResourceXrefDAO dao = (ResourceXrefDAO)getSession().getDAO("ResourceXref");  
	if(dao == null)
	{
	    dao = new ResourceXrefDAO(getSession());  		
	    getSession().putDAO("ResourceXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A DocumentMetaDataDAO object 
     */
    protected DocumentMetaDataDAO getDocumentDAO()
    {
	DocumentMetaDataDAO dao = (DocumentMetaDataDAO)getSession().getDAO("DocumentMetaData");  
	if(dao == null)
	{
	    dao = new DocumentMetaDataDAO(getSession());  		
	    getSession().putDAO("DocumentMetaData", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A NetworkConnectionDAO object 
     */
    protected NetworkConnectionDAO getNetConDAO()
    {
	NetworkConnectionDAO dao = (NetworkConnectionDAO)getSession().getDAO("NetworkConnection");  
	if(dao == null)
	{
	    dao = new NetworkConnectionDAO(getSession());  		
	    getSession().putDAO("NetworkConnection", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A TPServiceXrefDAO object 
     */
    protected TPServiceXrefDAO getServicesDAO()
    {
	TPServiceXrefDAO dao = (TPServiceXrefDAO)getSession().getDAO("TPServiceXref");  
	if(dao == null)
	{
	    dao = new TPServiceXrefDAO(getSession());  		
	    getSession().putDAO("TPServiceXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipDAO object 
     */
    protected RelationshipDAO getRelationshipDAO()
    {
	RelationshipDAO dao = (RelationshipDAO)getSession().getDAO("Relationship");  
	if(dao == null)
	{
	    dao = new RelationshipDAO(getSession());  		
	    getSession().putDAO("Relationship", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A MaterialBillDAO object 
     */
    protected MaterialBillDAO getMaterialBillDAO()
    {
	MaterialBillDAO dao = (MaterialBillDAO)getSession().getDAO("MaterialBill");  
	if(dao == null)
	{
	    dao = new MaterialBillDAO(getSession());  		
	    getSession().putDAO("MaterialBill", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A FirewallDetailsDAO object 
     */
    protected FirewallDetailsDAO getFirewallsDAO()
    {
	FirewallDetailsDAO dao = (FirewallDetailsDAO)getSession().getDAO("FirewallDetails");  
	if(dao == null)
	{
	    dao = new FirewallDetailsDAO(getSession());  		
	    getSession().putDAO("FirewallDetails", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionProcessDAO object 
     */
    protected ConnectionProcessDAO getConnectionrequestDAO()
    {
	ConnectionProcessDAO dao = (ConnectionProcessDAO)getSession().getDAO("ConnectionProcess");  
	if(dao == null)
	{
	    dao = new ConnectionProcessDAO(getSession());  		
	    getSession().putDAO("ConnectionProcess", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A CitiReqContactXrefDAO object 
     */
    protected CitiReqContactXrefExtDAO getCitiReqContactsDAO()
    {
	CitiReqContactXrefExtDAO dao = (CitiReqContactXrefExtDAO)getSession().getDAO("CitiReqContactXref");  
	if(dao == null)
	{
	    dao = new CitiReqContactXrefExtDAO(getSession());  		
	    getSession().putDAO("CitiReqContactXref", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [RequireNetworkAccess] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequireNetworkAccess(Boolean value) throws DatabaseException
    {
	return findByRequireNetworkAccess(value, getSession());
    }

    /**
     * Find by require network access.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequireNetworkAccess(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_REQUIRENETWORKACCESS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Rationale] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRationale(String value) throws DatabaseException
    {
	return findByRationale(value, getSession());
    }

    /**
     * Find by rationale.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRationale(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_RATIONALE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Benefit] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByBenefit(String value) throws DatabaseException
    {
	return findByBenefit(value, getSession());
    }

    /**
     * Find by benefit.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByBenefit(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_BENEFIT + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Plcode] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByPlcode(String value) throws DatabaseException
    {
	return findByPlcode(value, getSession());
    }

    /**
     * Find by plcode.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByPlcode(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_PLCODE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [EstimatedRevenueGenerated] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByEstimatedRevenueGenerated(Double value) throws DatabaseException
    {
	return findByEstimatedRevenueGenerated(value, getSession());
    }

    /**
     * Find by estimated revenue generated.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByEstimatedRevenueGenerated(Double value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_ESTIMATEDREVENUEGENERATED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [EstimatedCostSaving] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByEstimatedCostSaving(Double value) throws DatabaseException
    {
	return findByEstimatedCostSaving(value, getSession());
    }

    /**
     * Find by estimated cost saving.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByEstimatedCostSaving(Double value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_ESTIMATEDCOSTSAVING + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [CobRedundancyRequired] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByCobRedundancyRequired(Boolean value) throws DatabaseException
    {
	return findByCobRedundancyRequired(value, getSession());
    }

    /**
     * Find by cob redundancy required.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByCobRedundancyRequired(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_COBREDUNDANCYREQUIRED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ConnectionName] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByConnectionName(String value) throws DatabaseException
    {
	return findByConnectionName(value, getSession());
    }

    /**
     * Find by connection name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByConnectionName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_CONNECTIONNAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Status] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByStatus(String value) throws DatabaseException
    {
	return findByStatus(value, getSession());
    }

    /**
     * Find by status.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByStatus(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_STATUS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RequesterId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequesterId(String value) throws DatabaseException
    {
	return findByRequesterId(value, getSession());
    }

    /**
     * Find by requester id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequesterId(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_REQUESTERID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SemiAnnualEntitlementReview] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySemiAnnualEntitlementReview(Boolean value) throws DatabaseException
    {
	return findBySemiAnnualEntitlementReview(value, getSession());
    }

    /**
     * Find by semi annual entitlement review.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySemiAnnualEntitlementReview(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_SEMIANNUALENTITLEMENTREVIEW + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IssConnectionCompliance] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIssConnectionCompliance(String value) throws DatabaseException
    {
	return findByIssConnectionCompliance(value, getSession());
    }

    /**
     * Find by iss connection compliance.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIssConnectionCompliance(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_ISSCONNECTIONCOMPLIANCE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [CitiPolicyAdherence] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByCitiPolicyAdherence(String value) throws DatabaseException
    {
	return findByCitiPolicyAdherence(value, getSession());
    }

    /**
     * Find by citi policy adherence.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByCitiPolicyAdherence(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_CITIPOLICYADHERENCE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [AccessCitiGlobalNetwork] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByAccessCitiGlobalNetwork(Boolean value) throws DatabaseException
    {
	return findByAccessCitiGlobalNetwork(value, getSession());
    }

    /**
     * Find by access citi global network.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByAccessCitiGlobalNetwork(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_ACCESSCITIGLOBALNETWORK + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [TpTrainingAwarnessProgram] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByTpTrainingAwarnessProgram(Boolean value) throws DatabaseException
    {
	return findByTpTrainingAwarnessProgram(value, getSession());
    }

    /**
     * Find by tp training awarness program.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByTpTrainingAwarnessProgram(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_TPTRAININGAWARNESSPROGRAM + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SponsorBusinessConsulted] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySponsorBusinessConsulted(Boolean value) throws DatabaseException
    {
	return findBySponsorBusinessConsulted(value, getSession());
    }

    /**
     * Find by sponsor business consulted.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySponsorBusinessConsulted(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_SPONSORBUSINESSCONSULTED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ExportLicenseCordinator] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByExportLicenseCordinator(Boolean value) throws DatabaseException
    {
	return findByExportLicenseCordinator(value, getSession());
    }

    /**
     * Find by export license cordinator.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByExportLicenseCordinator(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_EXPORTLICENSECORDINATOR + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Lookup] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByLookup(Long value) throws DatabaseException
    {
	return findByLookup(value, getSession());
    }

    /**
     * Find by lookup.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByLookup(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_LOOKUP_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [NetCon] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByNetCon(Long value) throws DatabaseException
    {
	return findByNetCon(value, getSession());
    }

    /**
     * Find by net con.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByNetCon(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_NETCON_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Relationship] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRelationship(Long value) throws DatabaseException
    {
	return findByRelationship(value, getSession());
    }

    /**
     * Find by relationship.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRelationship(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionRequestDAO.TABLE + " WHERE " + COLUMN_RELATIONSHIP_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by Relationship", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(ConnectionRequestEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
