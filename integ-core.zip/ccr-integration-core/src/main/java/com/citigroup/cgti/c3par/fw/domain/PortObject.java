package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;

public class PortObject extends Base {
    public PortObject() {
    	setCreated_date(new Date());
	}

	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String portNumber;
    private String protocol;
    private String service;
 

    /**
     * @return the portNumber
     */
    public String getPortNumber() {
	return portNumber;
    }

    /**
     * @param portNumber the portNumber to set
     */
    public void setPortNumber(String portNumber) {
	this.portNumber = portNumber;
    }

    /**
     * @return the protocol
     */
    public String getProtocol() {
	return protocol;
    }

    /**
     * @param protocol the protocol to set
     */
    public void setProtocol(String protocol) {
	this.protocol = protocol;
    }

	/**
	 * @return the service
	 */
	public String getService() {
		return service;
	}

	/**
	 * @param service the service to set
	 */
	public void setService(String service) {
		this.service = service;
	}

}
