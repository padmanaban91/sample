package com.citigroup.cgti.c3par.configuation;


public class QueryConstants {
	
	public static final String WILDCARD_CHARACTER = "*";
	public static final String QUERY_TASK_SELECT = "getMyTaskQuerySelect";
	public static final String QUERY_TASK_STRING = "getQuerySelectString";
	public static final String QUERY_COUNT_GLOBAL_SEARCH = "getQuerySelectStringCount";
	public static final String QUERY_PROCESS_DATA = "getProcessData";
	public static final String QUERY_RFC_INFOMAN = "getInfomanRFC";
	public static final String QUERY_IS_BULK_REQUEST = "getBulkRequestFlag";
	public static final String QUERY_SOW_PROCESS_DATA = "getSowNumberProcessData";
	public static final String QUERY_COUNT_MY_TASK = "getMyTaskCount";
	public static final String QUERY_COUNT_MY_TASK_CONTACT = "getMyTaskContactWithEntitlementCount";
	public static final String QUERY_COUNT_GENERAL_SEARCH = "getGeneralSearchAttributesCount";
	public static final String QUERY_GENERAL_SEARCH = "getGeneralSearchAttributes";
	public static final String QUERY_GENERAL_SEARCH_WITH_PAGINATION = "getGeneralSearchAttributesWithPagination";
	public static final String GET_MYTASK_WITH_ENTITLEMENT = "GET_MYTASK_WITH_ENTITLEMENT";
	public static final String GET_MYTASK_WITH_ENTITLEMENT_PAGINATION = "GET_MYTASK_WITH_ENTITLEMENT_PAGINATION";
	public static final String GET_TASK_DETAILS_IN_MYTASK = "GET_TASK_DETAILS_IN_MYTASK";
	public static final String GET_ROLE_DETAILS_IN_MYTASK = "GET_ROLE_DETAILS_IN_MYTASK";
	public static final String GET_REGION_DETAILS_IN_MYTASK = "GET_REGION_DETAILS_IN_MYTASK";
	public static final String GET_SECTOR_DETAILS_IN_MYTASK = "GET_SECTOR_DETAILS_IN_MYTASK";
	public static final String VERIFY_SOW_ROLE_NAME = "VERIFY_SOW_ROLE_NAME";
	public static final String UPDATE_VERIFY_SOW_ROLE_IN_AUDIT_TRAIL = "UPDATE_VERIFY_SOW_ROLE_IN_AUDIT_TRAIL";
	
	public static final String MY_LOCKED_TASKS = "MY_LOCKED_TASKS";
	public static final String MY_LOCKED_TASKS_WITH_PAGINATION = "MY_LOCKED_TASKS_WITH_PAGINATION";
	public static final String MY_LOCKED_TASKS_COUNT = "MY_LOCKED_TASKS_COUNT";
	
	public static final String GENERAL_SEARCH_APPLICATION = "GENERAL_SEARCH_APPLICATION";
	public static final String GENERAL_SEARCH_APPLICATION_WITH_PAGINATION = "GENERAL_SEARCH_APPLICATION_WITH_PAGINATION";
	public static final String GENERAL_SEARCH_APPLICATION_COUNT = "GENERAL_SEARCH_APPLICATION_COUNT";
	
	public static final String GENERAL_SEARCH_IP_PORT_POLICY = "GENERAL_SEARCH_IP_PORT_POLICY";
	public static final String GENERAL_SEARCH_IP_PORT_POLICY_WITH_PAGINATION = "GENERAL_SEARCH_IP_PORT_POLICY_WITH_PAGINATION";
	public static final String GENERAL_SEARCH_IP_PORT_POLICY_COUNT = "GENERAL_SEARCH_IP_PORT_POLICY_COUNT";
	
	public static final String GENERAL_SEARCH_IP = "GENERAL_SEARCH_IP";
	public static final String GENERAL_SEARCH_IP_WITH_PAGINATION = "GENERAL_SEARCH_IP_WITH_PAGINATION";
	public static final String GENERAL_SEARCH_IP_COUNT = "GENERAL_SEARCH_IP_COUNT";
	
	public static final String GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP = "GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP";
	public static final String GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP_WITH_PAGINATION = "GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP_WITH_PAGINATION";
	public static final String GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP_COUNT = "GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP_COUNT";
	
	public static final String GENERAL_SEARCH_POLICY = "GENERAL_SEARCH_POLICY";
	public static final String GENERAL_SEARCH_POLICY_WITH_PAGINATION = "GENERAL_SEARCH_POLICY_WITH_PAGINATION";
	public static final String GENERAL_SEARCH_POLICY_COUNT = "GENERAL_SEARCH_POLICY_COUNT";
	
	public static final String GENERAL_SEARCH_PORT = "GENERAL_SEARCH_PORT";
	public static final String GENERAL_SEARCH_PORT_WITH_PAGINATION = "GENERAL_SEARCH_PORT_WITH_PAGINATION";
	public static final String COUNT_GENERAL_SEARCH_PORT = "COUNT_GENERAL_SEARCH_PORT";
	
	public static final String GENERAL_SEARCH_OPEIMP = "GENERAL_SEARCH_OPEIMP";
	public static final String GENERAL_SEARCH_OPEIMP_WITH_PAGINATION = "GENERAL_SEARCH_OPEIMP_WITH_PAGINATION";
	public static final String GENERAL_SEARCH_OPEIMP_COUNT = "GENERAL_SEARCH_OPEIMP_COUNT";
	
	public static final String GENERAL_SEARCH_APPSENSE = "GENERAL_SEARCH_APPSENSE";
	public static final String GENERAL_SEARCH_APPSENSE_WITH_PAGINATION = "GENERAL_SEARCH_APPSENSE_WITH_PAGINATION";
	public static final String GENERAL_SEARCH_APPSENSE_COUNT = "GENERAL_SEARCH_APPSENSE_COUNT";
	
	public static final String GENERAL_SEARCH_PROXY = "GENERAL_SEARCH_PROXY";
	public static final String GENERAL_SEARCH_PROXY_WITH_PAGINATION = "GENERAL_SEARCH_PROXY_WITH_PAGINATION";
	public static final String GENERAL_SEARCH_PROXY_COUNT = "GENERAL_SEARCH_PROXY_COUNT";
	
	public static final String GET_ACV_RECORDS_FOR_MIGRATION = "GET_ACV_RECORDS_FOR_MIGRATION";
	public static final String IS_TEMPLATE_CONNECTION_ABORTED = "IS_TEMPLATE_CONNECTION_ABORTED";
	
	public static final int QUERY_EXCLUDE = 0 ;
	public static final int QUERY_INCLUDE = 1 ;
	public static final String QUERY_STRING_EXCLUDE = "DUMMY" ;
	
	public static final String NONTHIRDPARTYACVCONNECTIONS = "NONTHIRDPARTYACVCONNECTIONS";
	public static final String EMAILCONTACTSFORCONNECTIONID = "EMAILCONTACTSFORCONNECTIONID";
	
	public static final String VIEW_TEMPLATES = "VIEW_TEMPLATES";
	public static final String COUNT_VIEW_TEMPLATES = "COUNT_VIEW_TEMPLATES";
	
	//Access form Query Constants
	public static final String ACCESSFORM_GETAPPLICATIONDETAILS_IPREG = "ACCESSFORM_GETAPPLICATIONDETAILS_IPREG";
	public static final String ACCESSFORM_GETAPPLICATIONDETAILS_FW = "ACCESSFORM_GETAPPLICATIONDETAILS_FW";
	public static final String ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_IPREG = "ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_IPREG";
	public static final String ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_FW = "ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_FW";
	
	public static final String ACCESSFORM_GETCABAPPROVERLIST = "ACCESSFORM_GETCABAPPROVERLIST";
	public static final String ACCESSFORM_GETSECACLAPPLICATIONDETAILS = "ACCESSFORM_GETSECACLAPPLICATIONDETAILS";
	
	public static final String ACCESSFORM_ISAPPSENSEHIGHRISK = "ACCESSFORM_ISAPPSENSEHIGHRISK";
	public static final String ACCESSFORM_ISPROXYHIGHRISK = "ACCESSFORM_ISPROXYHIGHRISK";
	public static final String ACCESSFORM_GETAPPSENSE_PROXY_IMPL = "ACCESSFORM_GETAPPSENSE_PROXY_IMPL";
	public static final String ACCESSFORM_GETPROXY_APPLICATION_DETAILS = "ACCESSFORM_GETPROXY_APPLICATION_DETAILS";
	
	public static final String ACCESSFORM_AAFIMPLINFO="ACCESSFORM_AAFIMPLINFO";
	public static final String ACCESSFORM_PAFIMPLINFO="ACCESSFORM_PAFIMPLINFO";
	public static final String ACCESSFORM_FAFIMPLINFO="ACCESSFORM_FAFIMPLINFO";
	public static final String ACCESSFORM_IPFAFIMPLINFO="ACCESSFORM_IPFAFIMPLINFO";
	public static final String ACCESSFORM_ACLIMPLINFO="ACCESSFORM_ACLIMPLINFO";
	
	public static final String GENERAL_SEARCH_SEC_ACL = "GENERAL_SEARCH_SEC_ACL";
	public static final String GENERAL_SEARCH_SEC_ACL_WITH_PAGINATION = "GENERAL_SEARCH_SEC_ACL_WITH_PAGINATION";
	public static final String GENERAL_SEARCH_SEC_ACL_COUNT = "GENERAL_SEARCH_SEC_ACL_COUNT";
	
	public static final String STATUS_LIST="SELECT tistatus.status statusName FROM ti_status_type tistatus";
	public static final String PRIORITY_LIST="SELECT lookup.value1 priority FROM generic_lookup lookup WHERE definition_id=(SELECT id FROM generic_lookup_defs WHERE name='Process Priority') order by lookup.value1";
	public static final String PROCESS_LIST="SELECT processtype.process_type process FROM ti_process_type processtype order by processtype.process_type";
	public static final String MODE_LIST="SELECT distinct tipro.process_activity_mode modename FROM ti_process tipro order by tipro.process_activity_mode";
	public static final String PHASE_LIST="SELECT tireqtype.request_type phaseName FROM c3par.ti_request_type tireqtype order by tireqtype.request_type";
	public static final String VIEW_NAME_LIST="select inboxview.GROUPVIEW_BY, inboxview.view_name,inboxview.view_code from inbox_view inboxview where inboxview.id in(select inboxRoleRef.INBOX_VIEW_ID from inboxview_role_ref inboxRoleRef  "
			+ "where inboxRoleRef.security_Role_Id in(select role_id from c3par_user_role_xref where user_id=:userId) and inboxRoleRef.DELETE_FLAG='N')  and inboxview.delete_Flag='N' GROUP BY  inboxview.view_name,inboxview.view_code, inboxview.GROUPVIEW_BY  "
			+ "union  select inboxview.GROUPVIEW_BY, inboxview.view_name,inboxview.view_code from inbox_view inboxview where inboxview.GROUPVIEW_BY=2 and inboxview.delete_Flag='N' "
			+ "union select customview.groupview_by,customview.view_name,customview.view_code from inbox_custom_view customview where customview.user_id=:userId and customview.DELETE_FLAG='N'"; 
	public static final String VIEW_NAME="from InboxView where viewCode =:viewCode and deleteFlag='N'";
	public static final String CUSTOM_VIEW_NAME="from InboxCustomView customView where customView.viewCode=:viewCode and customView.userId=:userId and customView.deletedFlag='N'";
	public static final String DELETE_CUSTOM_VIEW="UPDATE InboxCustomView SET deletedFlag='Y' where viewCode=:viewCode";
	public static final String CUSTOMVIEW_BYUSERID="from InboxCustomView where userId=:userId and deletedFlag='N' order by updatedDate desc LIMIT 1";
	public static final String CHECK_ADMIN="from C3parUserRoleXref userRoleXref where userRoleXref.userId=:userId and userRoleXref.roleId =(select securityRole.id from SecurityRole securityRole where securityRole.name='C3PARSYSTEMADMIN')";
	public static final String IS_ENTITLED_ADMIN="from C3parUserRoleXref userRoleXref where userRoleXref.userId=:userId and userRoleXref.roleId not in(select securityRole.id from SecurityRole securityRole where securityRole.name in('C3PARSYSTEMADMIN','C3PARUSER','Entitlement Requester'))";
	public static final String ROLE_SECTOR_LIST="from UserRoleSectorView where userId=:userId";
	public static final String UPDATE_ADMIN_SUPPORT="UPDATE ccr_task_ref set activity_name='admin_support' where id=:id";
	public static final String ASSIGN="UPDATE ccr_task_ref SET task_participant=:taskparticipant where id=:id";
	public static final String UNASSIGN="UPDATE ccr_task_ref SET task_participant=null where id=:id";
	public static final String ROLE_LIST="select securityRole.name from SecurityRole securityRole where securityRole.id in(select userRoleXref.roleId from C3parUserRoleXref userRoleXref where userRoleXref.userId=:userId)";
	//public static final String SECTOR_LIST="select distinct hierarchyMaster.sectorId from CitiHierarchyMaster hierarchyMaster where hierarchyMaster.id in(select hierarchyXref.hierarchyMasterId from C3parUserHierarchyXref hierarchyXref where hierarchyXref.userId =:userId)";
	public static final String SECTOR_LIST="select distinct hierarchymaster.sector_id sector from citi_hierarchy_master hierarchyMaster where hierarchymaster.id in(select hierarchyxref.citi_hierarchy_master_id from user_citi_hierarchy_xref hierarchyXref where hierarchyxref.user_id =:userId)";
	public static final String CHECK_BJ="from TIActivityTrail aTrail where aTrail.tiRequestId=:tiRequestId and (aTrail.activityStage='DC' or aTrail.activityStage=null) and (aTrail.userId=:userId or aTrail.userId is null) and aTrail.activityId=12";
	public static final String TASK_CODE="select ttt.taskCode from TITaskType ttt where ttt.id=(select tat.activityId from TIActivityTrail tat where tat.id =:activityTrailId)";
	public static final String EXP_MESSAGE="select ERROR_MESSAGE_TEXT from CCR_TASK_REF where Activity_name =:acitvityName and connection_id =:connectionId";
	public static final String ACTIVITY_NAMES="select distinct task from TITaskType order by task asc";
	
	//Export Rules 
	public static final String EXPORTRULES_GETAPPLICATIONDETAILS_IPREG = "EXPORTRULES_GETAPPLICATIONDETAILS_IPREG";
	public static final String EXPORTRULES_GETAPPLICATIONDETAILS_FW = "EXPORTRULES_GETAPPLICATIONDETAILS_FW";
		
	public static final String RELATIONSHIP_ID="select relationship_id relId from ti_process where id=(select process_id from ti_request where id=:tiRequestId)";
	public static final String CHECK_VERSION="select count(id) as count from ti_process where id=(select process_id from ti_request where id=:tiRequestId) and version_number>1";
	public static final String CON_FW_RULE="select count(id) as count from con_fw_rule where ti_request_id=:tiRequestId and status<>'DELETE'";
	public static final String PROXY_FILTER="select count(id) as count from prx_proxy_filter where process_id=(select process_id from ti_request where id=:tiRequestId)";
	public static final String ACL_VARIANCE="select count(id) as count from acl_variance WHERE ti_request_id=:tiRequestId";
	public static final String APS_APPSENSE="select count(id) as count from aps_appsense_policy  where ti_request_id=:tiRequestId";
	public static final String CONNECTION_NAME="select ti_pro.id id, ti_pro.process_name processName  from ti_process ti_pro where id=(select process_id from ti_request where  id=:tiRequestId)";
	public static final String UPDATE_CONNECTION_NAME="Update TIProcess set processName=:processName where id=:id";
	public static final String UPDATE_RELATIONSHIP_STATUS="Update Relationship set status=:status where id=:id ";
	public static final String UPDATE_RESOURCE_TYPE= "update Relationship set TARGET_RESOURCE_TYPE_ID =:targetResourceTypeId,REQUESTER_RESOURCE_TYPE_ID =:sourceResourceTypeId where ID =:id";
	public static final String TP_CONTACTS="SELECT * FROM REL_TP_CONT_XREF CONT WHERE CONT.RELATIONSHIP_ID =:RELID";
	public static final String UTURN_TP_CONTACTS="select * from rel_tp_cont_xref tpcon, tp_contact con where tpcon.relationship_id =:RELID and con.id=tpcon.tp_contact_id and con.thirdparty_id=:TPID";
	public static final String TP_LOCATION="SELECT * FROM REL_TP_LOC_XREF LOC WHERE LOC.RELATIONSHIP_ID =:RELID";
	public static final String REL_CITI_LOCs="select * from REL_REQ_CITI_LOC_XREF where relationship_id =:RELID";
		
}
