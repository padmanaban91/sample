/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author bs45969
 *
 */
public class FireWallRulePort extends Base {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private FireWallRule fireWallRule;
    private TIRequest updatedTIRequest;
    private TIRequest deletedTIRequest;
    @NotNull(message = "Port detail not available ")
    @Valid
    private Port port;
    private String description;
    private String serviceName;
    private String defaultService;
    private String typeOfTraffic;
    private String controlMessage;

    //UI Level Attributes and Flags
    private boolean deleted;
    
    private boolean serviceModified;
    private String orgServiceName;
    
    /** The updated_date. */
    private String updated_date_hdn;

    private Long objRuleID;

    public FireWallRulePort() {
	setCreated_date(new Date());
    }

    /**
     * @return the fireWallRule
     */
    public FireWallRule getFireWallRule() {
	return fireWallRule;
    }

    /**
     * @param fireWallRule the fireWallRule to set
     */
    public void setFireWallRule(FireWallRule fireWallRule) {
	this.fireWallRule = fireWallRule;
    }

    /**
     * @return the updatedTIRequest
     */
    public TIRequest getUpdatedTIRequest() {
	return updatedTIRequest;
    }

    /**
     * @param updatedTIRequest the updatedTIRequest to set
     */
    public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
	this.updatedTIRequest = updatedTIRequest;
    }

    /**
     * @return the deletedTIRequest
     */
    public TIRequest getDeletedTIRequest() {
	return deletedTIRequest;
    }

    /**
     * @param deletedTIRequest the deletedTIRequest to set
     */
    public void setDeletedTIRequest(TIRequest deletedTIRequest) {
	this.deletedTIRequest = deletedTIRequest;
    }

    /**
     * @return the port
     */
    public Port getPort() {
	return port;
    }

    /**
     * @param port the port to set
     */
    public void setPort(Port port) {
	this.port = port;
    }

    /**
     * @return the description
     */
    public String getDescription() {
	return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
	this.description = description;
    }

    /**
     * @return the serviceName
     */
    public String getServiceName() {
	return serviceName;
    }

    /**
     * @param serviceName the serviceName to set
     */
    public void setServiceName(String serviceName) {
	this.serviceName = serviceName;
    }

    /**
     * @return the defaultService
     */
    public String getDefaultService() {
	return defaultService;
    }

    /**
     * @param defaultService the defaultService to set
     */
    public void setDefaultService(String defaultService) {
	this.defaultService = defaultService;
    }

    /**
     * @return the typeOfTraffic
     */
    public String getTypeOfTraffic() {
	return typeOfTraffic;
    }

    /**
     * @param typeOfTraffic the typeOfTraffic to set
     */
    public void setTypeOfTraffic(String typeOfTraffic) {
	this.typeOfTraffic = typeOfTraffic;
    }

	/**
	 * @return the deleted
	 */
	public boolean isDeleted() {
		return deleted;
	}

	/**
	 * @param deleted the deleted to set
	 */
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	/**
	 * @return the serviceModified
	 */
	public boolean isServiceModified() {
		return serviceModified;
	}

	/**
	 * @param serviceModified the serviceModified to set
	 */
	public void setServiceModified(boolean serviceModified) {
		this.serviceModified = serviceModified;
	}

	/**
	 * @return the orgServiceName
	 */
	public String getOrgServiceName() {
		return orgServiceName;
	}

	/**
	 * @param orgServiceName the orgServiceName to set
	 */
	public void setOrgServiceName(String orgServiceName) {
		this.orgServiceName = orgServiceName;
	}

	/**
	 * @return the updated_date_hdn
	 */
	public String getUpdated_date_hdn() {
		return updated_date_hdn;
	}

	/**
	 * @param updatedDateHdn the updated_date_hdn to set
	 */
	public void setUpdated_date_hdn(String updatedDateHdn) {
		updated_date_hdn = updatedDateHdn;
	}

	public Long getObjRuleID() {
		return objRuleID;
	}

	public void setObjRuleID(Long objRuleID) {
		this.objRuleID = objRuleID;
	}

	public String getControlMessage() {
		return controlMessage;
	}

	public void setControlMessage(String controlMessage) {
		this.controlMessage = controlMessage;
	}
    
}
