

/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.ip;

import com.mentisys.dao.schema.*;



/**
 * The Class IPSchema.
 */
public class IPSchema extends DatabaseSchema {

    /** The instance. */
    static private IPSchema instance = null;

    /**
     * Gets the single instance of IPSchema.
     *
     * @return single instance of IPSchema
     */
    static public IPSchema getInstance() {
	if (instance == null) {
	    instance = new IPSchema();
	}
	return instance;
    }

    /**
     * Instantiates a new iP schema.
     */
    private IPSchema() {

	super("IP");
	// Add all our entities
	addEntityIPRegistration();
	addEntityIPRegion();
	addEntityIPConnection();
	addEntityIPRegDetail();
	addEntityIPMaster();
	addEntityIPAccessType();
	addEntityIPOstiaAnswer();
	addEntityRiskPortOstia();
	addEntityIPRegDetailApplicationXref();
	addEntityIPRegDetailProtocolXref();
	addEntityIPRegDestinationPorts();
	addEntityIPACLAssignment();
	addEntityIPRegDetailControlMessagesXref();

    }

    /**
     * Adds the entity ip registration.
     */
    private void addEntityIPRegistration() {

	EntityDefinition ed = new EntityDefinition("IPRegistration");

	// Add all our attributes
	ed.addAttribute("otherBusinessReason", "String", 100);
	ed.addAttribute("comments", "String", 250);
	ed.addAttribute("ap", "String", 150);
	ed.addAttribute("acl", "String", 100);
	ed.addAttribute("chngCtrId", "Long", 0);
	ed.addAttribute("scheduleDate", "Date", 0);
	ed.addAttribute("completeDate", "Date", 0);

	// All all our references
	ed.addReference("connectionType", false, false,  false , "GenericLookup");
	ed.addReference("businessType", false, false,  false , "GenericLookup");
	ed.addReference("process", false, false,  false , "TIProcess");
	ed.addReference("IPRegDetail", true, true,  false , "IPRegDetail");
	ed.addReference("IPAccessType", true, true,  true, "IPAccessType");
	ed.addReference("businessReason", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip region.
     */
    private void addEntityIPRegion() {

	EntityDefinition ed = new EntityDefinition("IPRegion");

	// Add all our attributes

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip connection.
     */
    private void addEntityIPConnection() {

	EntityDefinition ed = new EntityDefinition("IPConnection");

	// Add all our attributes

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip reg detail.
     */
    private void addEntityIPRegDetail() {

	EntityDefinition ed = new EntityDefinition("IPRegDetail");

	// Add all our attributes
	ed.addAttribute("updatedDate", "Date", 0);
	ed.addAttribute("sourceStartIp", "String", 1000);
	ed.addAttribute("sourceSubnetMask", "String", 1000);
	ed.addAttribute("destinationIp", "String", 100);
	ed.addAttribute("netInfoId", "String", 1000);
	ed.addAttribute("dsn", "String", 1000);
	ed.addAttribute("sourceUserType", "String", 1000);
	ed.addAttribute("sourceAccessType", "String", 1000);
	ed.addAttribute("sourceConnectionType", "String", 1000);
	ed.addAttribute("sourceAcl", "String", 1000);
	ed.addAttribute("destinationEndIp", "String", 100);
	ed.addAttribute("destinationIpType", "String", 25);
	ed.addAttribute("isManualAssignedAcl", "String", 1);

	// All all our references
	ed.addReference("ipRegistration", false, false,  false , "IPRegistration");
	ed.addReference("processStatus", false, false,  false , "TIStatusType");
	ed.addReference("IPRegDetailApplicationXref", true, true,  true, "IPRegDetailApplicationXref");
	ed.addReference("IPRegDestinationPorts", true, true,  true, "IPRegDestinationPorts");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip master.
     */
    private void addEntityIPMaster() {

	EntityDefinition ed = new EntityDefinition("IPMaster");

	// Add all our attributes
	ed.addAttribute("ipAddress", "String", 100);
	ed.addAttribute("portName", "String", 100);
	ed.addAttribute("portType", "String", 15);
	ed.addAttribute("endPort", "String", 100);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip access type.
     */
    private void addEntityIPAccessType() {

	EntityDefinition ed = new EntityDefinition("IPAccessType");

	// Add all our attributes

	// All all our references
	ed.addReference("ipRegistration", false, false,  false , "IPRegistration");
	ed.addReference("accessType", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip ostia answer.
     */
    private void addEntityIPOstiaAnswer() {

	EntityDefinition ed = new EntityDefinition("IPOstiaAnswer");

	// Add all our attributes
	ed.addAttribute("answer", "String", 1000);
	ed.addAttribute("ostiaGroupId", "Long", 0);

	// All all our references
	ed.addReference("ostiaQuestion", false, false,  false , "TIOstiaQuestion");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity risk port ostia.
     */
    private void addEntityRiskPortOstia() {

	EntityDefinition ed = new EntityDefinition("RiskPortOstia");

	// Add all our attributes
	ed.addAttribute("ostiaGroupId", "Long", 0);
	ed.addAttribute("status", "String", 50);

	// All all our references
	ed.addReference("IpRegDestinationPorts", false, false,  false , "IPRegDestinationPorts");
	ed.addReference("riskPort", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip reg detail application xref.
     */
    private void addEntityIPRegDetailApplicationXref() {

	EntityDefinition ed = new EntityDefinition("IPRegDetailApplicationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("ipRegDetail", false, false,  false , "IPRegDetail");
	ed.addReference("application", false, false,  false , "TIApplication");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip reg detail protocol xref.
     */
    private void addEntityIPRegDetailProtocolXref() {

	EntityDefinition ed = new EntityDefinition("IPRegDetailProtocolXref");

	// Add all our attributes

	// All all our references
	ed.addReference("IpRegDestinationPorts", false, false,  false , "IPRegDestinationPorts");
	ed.addReference("protocol", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip reg destination ports.
     */
    private void addEntityIPRegDestinationPorts() {

	EntityDefinition ed = new EntityDefinition("IPRegDestinationPorts");

	// Add all our attributes
	ed.addAttribute("startPort", "String", 1000);
	ed.addAttribute("endPort", "String", 10000);
	ed.addAttribute("serviceMapping", "String", 1000);
	ed.addAttribute("justification", "String", 1000);
	ed.addAttribute("serviceMappingType", "String", 1000);

	// All all our references
	ed.addReference("IpRegdetail", false, false,  false , "IPRegDetail");
	ed.addReference("RiskPortOstia", true, true,  false , "RiskPortOstia");
	ed.addReference("IPRegDetailProtocolXref", true, true,  true, "IPRegDetailProtocolXref");
	ed.addReference("portType", false, false,  false , "GenericLookup");
	ed.addReference("IPRegDetailControlMessagesXref", true, true,  true, "IPRegDetailControlMessagesXref");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ipacl assignment.
     */
    private void addEntityIPACLAssignment() {

	EntityDefinition ed = new EntityDefinition("IPACLAssignment");

	// Add all our attributes
	ed.addAttribute("userType", "String", 100);
	ed.addAttribute("accessType", "String", 100);
	ed.addAttribute("connectionType", "String", 100);
	ed.addAttribute("acl", "String", 100);
	ed.addAttribute("isActive", "String", 1);
	ed.addAttribute("startIp", "String", 100);
	ed.addAttribute("subnetMask", "String", 100);
	ed.addAttribute("createdDate", "Date", 0);
	ed.addAttribute("updatedDate", "Date", 0);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip reg detail control messages xref.
     */
    private void addEntityIPRegDetailControlMessagesXref() {

	EntityDefinition ed = new EntityDefinition("IPRegDetailControlMessagesXref");

	// Add all our attributes

	// All all our references
	ed.addReference("IpRegDestinationPorts", false, false,  false , "IPRegDestinationPorts");
	ed.addReference("controlMessageType", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }


}

