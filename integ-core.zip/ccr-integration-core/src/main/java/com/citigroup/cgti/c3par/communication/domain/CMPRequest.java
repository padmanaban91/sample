package com.citigroup.cgti.c3par.communication.domain;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.TIActivityTrail;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.CMPRequestPersistable;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

 
public class CMPRequest extends Base {
	
	
	   CCRBeanFactory ccrBeanFactory;
		{
			ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
			if(appContext!=null && appContext.containsBean("cCRBeanFactory")){
				ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
			}else{
				System.out.println("appContext is null");
			}
			
		}
	public CMPRequestPersistable getCmpRequestPersistable() {
		return ccrBeanFactory.getCmpRequestPersistable();
	}
	private String orderId;
	private String orderItemId;
	private String status;
	private String step;
	private Date availableDate;
	private Date closedDate;
	private String orderByUser;
	private String orderBySoeID;
	private String orderForUser;
	private String orderForSoeID;
	private String assignedGroup;
	
	
	
	private C3parUser assignedUser; 
	
	private String requestType;
	private String typeofConnectivityInvolved;
	private String id_2;
	private String requestUrgency;
	private String projectSector;
	private String region;
	private String businessjustification;
	private String terminationType;
	private String id_1;
	private Date updatedDate;
	private String businessGroup;
	private String affectedBusiness;
	private String thirdParty;
	private String supplierId;
	private String detailId;
	private String connectionName;
	private String relationshipId;
	private String ccrId;
	private Date updateAssignedUserDate;
	private String ecmSector;
	private String checkTiId;
	private String currentStatus; 

    private List<CMPRequestContactXref> cmpRequestContactXrefs;
    private List<TIActivityTrail> tiactivityTrail;
    private List<TIMailAudit> timailAudit;
    private List<CMPRequestNotes> cmpRequestNotes;
    private List<CMPRequestAttachments> cmpRequestAttachments;
    
    private Date accessFormRemainderDate;
    private Long sloDays;
    private Long ecmTimer;
    
    private List<Map<String, String>> changeRequestDetails;
    	
    
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public String getEcmSector() {
		return ecmSector;
	}
	public void setEcmSector(String ecmSector) {
		this.ecmSector = ecmSector;
	}
	public Date getUpdateAssignedUserDate() {
		return updateAssignedUserDate;
	}
	public void setUpdateAssignedUserDate(Date updateAssignedUserDate) {
		this.updateAssignedUserDate = updateAssignedUserDate;
	}	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}	
	public String getOrderItemId() {
		return orderItemId;
	}
	public void setOrderItemId(String orderItemId) {
		this.orderItemId = orderItemId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStep() {
		return step;
	}
	public void setStep(String step) {
		this.step = step;
	}
	public Date getAvailableDate() {
		return availableDate;
	}
	public void setAvailableDate(Date availableDate) {
		this.availableDate = availableDate;
	}
	public Date getClosedDate() {
		return closedDate;
	}
	public void setClosedDate(Date closedDate) {
		this.closedDate = closedDate;
	}
	public String getOrderByUser() {
		return orderByUser;
	}
	public void setOrderByUser(String orderByUser) {
		this.orderByUser = orderByUser;
	}
	public String getOrderBySoeID() {
		return orderBySoeID;
	}
	public void setOrderBySoeID(String orderBySoeID) {
		this.orderBySoeID = orderBySoeID;
	}
	public String getOrderForUser() {
		return orderForUser;
	}
	public void setOrderForUser(String orderForUser) {
		this.orderForUser = orderForUser;
	}
	public String getOrderForSoeID() {
		return orderForSoeID;
	}
	public void setOrderForSoeID(String orderForSoeID) {
		this.orderForSoeID = orderForSoeID;
	}
	public String getAssignedGroup() {
		return assignedGroup;
	}
	public void setAssignedGroup(String assignedGroup) {
		this.assignedGroup = assignedGroup;
	}
	public C3parUser getAssignedUser() {
		return assignedUser;
	}
	public void setAssignedUser(C3parUser assignedUser) {
		this.assignedUser = assignedUser;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getTypeofConnectivityInvolved() {
		return typeofConnectivityInvolved;
	}
	public void setTypeofConnectivityInvolved(String typeofConnectivityInvolved) {
		this.typeofConnectivityInvolved = typeofConnectivityInvolved;
	}
	public String getRequestUrgency() {
		return requestUrgency;
	}
	public void setRequestUrgency(String requestUrgency) {
		this.requestUrgency = requestUrgency;
	}
	public String getProjectSector() {
		return projectSector;
	}
	public void setProjectSector(String projectSector) {
		this.projectSector = projectSector;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getBusinessjustification() {
		return businessjustification;
	}
	public void setBusinessjustification(String businessjustification) {
		this.businessjustification = businessjustification;
	}
	public String getTerminationType() {
		return terminationType;
	}
	public void setTerminationType(String terminationType) {
		this.terminationType = terminationType;
	}
	public String getId_1() {
		return id_1;
	}
	public void setId_1(String id_1) {
		this.id_1 = id_1;
	}	
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getBusinessGroup() {
		return businessGroup;
	}
	public void setBusinessGroup(String businessGroup) {
		this.businessGroup = businessGroup;
	}
	public String getAffectedBusiness() {
		return affectedBusiness;
	}
	public void setAffectedBusiness(String affectedBusiness) {
		this.affectedBusiness = affectedBusiness;
	}
	public String getThirdParty() {
		return thirdParty;
	}
	public void setThirdParty(String thirdParty) {
		this.thirdParty = thirdParty;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getDetailId() {
		return detailId;
	}
	public void setDetailId(String detailId) {
		this.detailId = detailId;
	}
	public String getConnectionName() {
		return connectionName;
	}
	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}
	public String getRelationshipId() {
		return relationshipId;
	}
	public void setRelationshipId(String relationshipId) {
		this.relationshipId = relationshipId;
	}
	public String getCcrId() {
		return ccrId;
	}
	public void setCcrId(String ccrId) {
		this.ccrId = ccrId;
	}	
	public List<CMPRequestContactXref> getCmpRequestContactXrefs() {
		return cmpRequestContactXrefs;
	}
	public void setCmpRequestContactXrefs(List<CMPRequestContactXref> cmpRequestContactXrefs) {
		this.cmpRequestContactXrefs = cmpRequestContactXrefs;
	}	
	public List<TIActivityTrail> getTiactivityTrail() {
		return tiactivityTrail;
	}
	public void setTiactivityTrail(List<TIActivityTrail> tiactivityTrail) {
		this.tiactivityTrail = tiactivityTrail;
	}
	public List<TIMailAudit> getTimailAudit() {
		return timailAudit;
	}
	public void setTimailAudit(List<TIMailAudit> timailAudit) {
		this.timailAudit = timailAudit;
	}	
	public List<CMPRequestNotes> getCmpRequestNotes() {
		return cmpRequestNotes;
	}
	public void setCmpRequestNotes(List<CMPRequestNotes> cmpRequestNotes) {
		this.cmpRequestNotes = cmpRequestNotes;
	}
	public Date getAccessFormRemainderDate() {
		return accessFormRemainderDate;
	}
	public void setAccessFormRemainderDate(Date accessFormRemainderDate) {
		this.accessFormRemainderDate = accessFormRemainderDate;
	}	
	
	public Long getEcmTimer() {
	return ecmTimer;
	}
	public void setEcmTimer(Long ecmTimer) {
		this.ecmTimer = ecmTimer;
	}
	public Long getSloDays() {
		return sloDays;
	}
	public void setSloDays(Long sloDays) {
		this.sloDays = sloDays;
	}			
	public String getId_2() {
		return id_2;
	}
	public void setId_2(String id_2) {
		this.id_2 = id_2;
	}	
	public String getCheckTiId() {
		return checkTiId;
	}
	public void setCheckTiId(String checkTiId) {
		this.checkTiId = checkTiId;
	}
	public List<CMPRequestAttachments> getCmpRequestAttachments() {
		return cmpRequestAttachments;
	}
	public void setCmpRequestAttachments(
			List<CMPRequestAttachments> cmpRequestAttachments) {
		this.cmpRequestAttachments = cmpRequestAttachments;
	}
	public List<Map<String, String>> getChangeRequestDetails() {
		return changeRequestDetails;
	}
	public void setChangeRequestDetails(
			List<Map<String, String>> changeRequestDetails) {
		this.changeRequestDetails = changeRequestDetails;
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public Long saveCmpRequestfield(String cmpRequestString) {
		return ccrBeanFactory.getCmpRequestPersistable().saveCmpRequestfield(cmpRequestString);
	}
	
	
	public void cmpActivityTrail(Long cmpId, String ssoId, String taskCode, String activityStatus) {
		ccrBeanFactory.getCmpRequestPersistable().cmpActivityTrail(cmpId, ssoId, taskCode, activityStatus);
	}
	
	@Transactional(readOnly = true)
	public byte[] getCmpData(String cmpReqId){
		return ccrBeanFactory.getCmpRequestPersistable().getCmpData(cmpReqId);
	}

}
