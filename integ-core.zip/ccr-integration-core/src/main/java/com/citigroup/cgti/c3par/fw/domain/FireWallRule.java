/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author bs45969
 */

public class FireWallRule extends Base {
	
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    public static final String ADD = "ADD";
    public static final String EDIT = "EDIT";
    public static final String EDITorDELETE = "EDORDEL";
    public static final String DELETE = "DELETE";
    @NotNull(message = "Rule number not assigned")
    private Integer ruleNumber;
    @NotNull(message = "Request ID of the cycle in which the rule added/edited not assigned")
    private TIRequest tiRequest;
    private TIRequest updatedTIRequest;
    private TIRequest deletedTIRequest;
    private FireWallPolicyGroup policyGroup;
    private FirewallPolicy policy;
    //@NotEmpty(message = "No source IPs assigned")
    @Valid
    private List<FireWallRuleSourceIP> sourceIPs;
    //@NotEmpty(message = "No destination IPs assigned")
    @Valid
    private List<FireWallRuleDestinationIP> destinationIPs;
    //@NotEmpty(message = "No ports assigned")
    @Valid
    private List<FireWallRulePort> ports;
    private List<FirewallRulePolicy> policies;
    private FireWallZone sourceZone;
	private FireWallZone destinationZone;
    private ResourceType sourceNetworkZone;
    private ResourceType destinationNetworkZone;
    private String FAFGenerated;
    private String status;
    /** The updated_date. */
    private String updated_date_hdn;
    private String bidirectional;
    private List<String> validationErrors;
    
    private IPAddress sourceObject;
    private IPAddress destinationObject;
    private Port portObject;
    private Long templateID;
    private String templateConnectionName;
    private String riskyRule;
    private String isIpReg;
    private String ruleType;
    private String ofacFlag;
   
    public String getOfacFlag() {
		return ofacFlag;
	}

	public void setOfacFlag(String ofacFlag) {
		this.ofacFlag = ofacFlag;
	}
	


	CCRBeanFactory ccrBeanFactory;
 	{
 		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
 		if(appContext!=null && appContext.containsBean("cCRBeanFactory")){
 			ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
 		}else{
 			System.out.println("appContext is null");
 		}
 		
 	}
	private boolean ipPortModified;
    
    private List<FireWallRuleIP> riskSourceIPs;
    
    private List<FireWallRuleIP> riskDestinationIPs;
    
    private List<FireWallRulePort> riskPorts;
    
    private List<FirewallRuleQuestionnaire> fwOstiaQuestionnaires;
    
    //temporary flag for checking whether team server or drools for rules execustion TODO:Will remove below attributes once testing completed
    private boolean isDrools=false;
    
    private String boardAccess;
     
    private String tpa;
   
    
	public ResourceType getSourceNetworkZone() {
		return sourceNetworkZone;
	}

	public ResourceType getDestinationNetworkZone() {
		return destinationNetworkZone;
	}
    public void setSourceNetworkZone(ResourceType sourceNetworkZone) {
		this.sourceNetworkZone = sourceNetworkZone;
	}

	public void setDestinationNetworkZone(ResourceType destinationNetworkZone) {
		this.destinationNetworkZone = destinationNetworkZone;
	}

	
	

    public FireWallRule() {
	setCreated_date(new Date());
    }

    /**
     * @return the ruleNumber
     */
    public Integer getRuleNumber() {
	return ruleNumber;
    }

    /**
     * @param ruleNumber the ruleNumber to set
     */
    public void setRuleNumber(Integer ruleNumber) {
	this.ruleNumber = ruleNumber;
    }

    /**
     * @return the updatedTIRequest
     */
    public TIRequest getUpdatedTIRequest() {
	return updatedTIRequest;
    }

    /**
     * @param updatedTIRequest the updatedTIRequest to set
     */
    public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
	this.updatedTIRequest = updatedTIRequest;
    }

    /**
     * @return the deletedTIRequest
     */
    public TIRequest getDeletedTIRequest() {
	return deletedTIRequest;
    }

    /**
     * @param deletedTIRequest the deletedTIRequest to set
     */
    public void setDeletedTIRequest(TIRequest deletedTIRequest) {
	this.deletedTIRequest = deletedTIRequest;
    }

    /**
     * @return the policyGroup
     */
    public FireWallPolicyGroup getPolicyGroup() {
	return policyGroup;
    }

    /**
     * @param policyGroup the policyGroup to set
     */
    public void setPolicyGroup(FireWallPolicyGroup policyGroup) {
	this.policyGroup = policyGroup;
    }

    /**
     * @return the policy
     */
    public FirewallPolicy getPolicy() {
	return policy;
    }

    /**
     * @param policy the policy to set
     */
    public void setPolicy(FirewallPolicy policy) {
	this.policy = policy;
    }

    /**
     * @return the sourceIPs
     */
    public List<FireWallRuleSourceIP> getSourceIPs() {
	return sourceIPs;
    }

    /**
     * @param sourceIPs the sourceIPs to set
     */
    public void setSourceIPs(List<FireWallRuleSourceIP> sourceIPs) {
	this.sourceIPs = sourceIPs;
    }

    /**
     * @return the destinationIPs
     */
    public List<FireWallRuleDestinationIP> getDestinationIPs() {
	return destinationIPs;
    }

    /**
     * @param destinationIPs the destinationIPs to set
     */
    public void setDestinationIPs(List<FireWallRuleDestinationIP> destinationIPs) {
	this.destinationIPs = destinationIPs;
    }

    /**
     * @return the ports
     */
    public List<FireWallRulePort> getPorts() {
	return ports;
    }

    /**
     * @param ports the ports to set
     */
    public void setPorts(List<FireWallRulePort> ports) {
	this.ports = ports;
    }

    /**
     * @return the sourceZone
     */
    public FireWallZone getSourceZone() {
	return sourceZone;
    }

    /**
     * @param sourceZone the sourceZone to set
     */
    public void setSourceZone(FireWallZone sourceZone) {
	this.sourceZone = sourceZone;
    }

    /**
     * @return the destinationZone
     */
    public FireWallZone getDestinationZone() {
	return destinationZone;
    }

    /**
     * @param destinationZone the destinationZone to set
     */
    public void setDestinationZone(FireWallZone destinationZone) {
	this.destinationZone = destinationZone;
    }

    //Will be used while listing FireWallRule bean validation messages
    public String toString() {
	return "FW Rule :" + ruleNumber;
    }

    /**
     * @return the fAFGenerated
     */
    public String getFAFGenerated() {
	return FAFGenerated;
    }

    /**
     * @param fAFGenerated the fAFGenerated to set
     */
    public void setFAFGenerated(String fAFGenerated) {
	FAFGenerated = fAFGenerated;
    }

    /**
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
	this.status = status;
    }

	/**
	 * @return the tiRequest
	 */
	public TIRequest getTiRequest() {
		return tiRequest;
	}

	/**
	 * @param tiRequest the tiRequest to set
	 */
	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}
	
	/**
	 * @return the updated_date_hdn
	 */
	public String getUpdated_date_hdn() {
		return updated_date_hdn;
	}

	/**
	 * @param updatedDateHdn the updated_date_hdn to set
	 */
	public void setUpdated_date_hdn(String updatedDateHdn) {
		updated_date_hdn = updatedDateHdn;
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public Long save()  throws BusinessException {
		long id = ccrBeanFactory.getFirewallRuleProcessPersistable()
			.saveFireWallRule(this);
		return id;
    }
	
	
    public boolean isRuleModified() {
		 return ccrBeanFactory.getFirewallRuleProcessPersistable().isRuleModified(this);
    }
	
	
    public FireWallRule identifyExistingRules() {
		 return ccrBeanFactory.getFirewallRuleProcessPersistable().identifyExistingRules(this);
    }
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public FireWallRule identifyExistingIPsandPorts() {
		 return ccrBeanFactory.getFirewallRuleProcessPersistable().identifyExistingIPsandPorts(this);
    }
	
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = true)
    public FireWallRule validateIPsandPorts() {
		 return ccrBeanFactory.getFirewallRuleProcessPersistable().validateIPsandPorts(this);
    }
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public boolean isRisk() {
		 return ccrBeanFactory.getOstiaRiskPersistable().isRisk(this.getId());
    }

	public String getBidirectional() {
		return bidirectional;
	}

	public void setBidirectional(String bidirectional) {
		this.bidirectional = bidirectional;
	}

	/**
	 * @return the validationErrors
	 */
	public List<String> getValidationErrors() {
		return validationErrors;
	}

	/**
	 * @param validationErrors the validationErrors to set
	 */
	public void setValidationErrors(List<String> validationErrors) {
		this.validationErrors = validationErrors;
	}

	/**
	 * @return the sourceObject
	 */
	public IPAddress getSourceObject() {
		return sourceObject;
	}

	/**
	 * @param sourceObject the sourceObject to set
	 */
	public void setSourceObject(IPAddress sourceObject) {
		this.sourceObject = sourceObject;
	}

	/**
	 * @return the destinationObject
	 */
	public IPAddress getDestinationObject() {
		return destinationObject;
	}

	/**
	 * @param destinationObject the destinationObject to set
	 */
	public void setDestinationObject(IPAddress destinationObject) {
		this.destinationObject = destinationObject;
	}

	/**
	 * @return the portObject
	 */
	public Port getPortObject() {
		return portObject;
	}

	/**
	 * @param portObject the portObject to set
	 */
	public void setPortObject(Port portObject) {
		this.portObject = portObject;
	}

	/**
	 * @return the fwOstiaQuestionnaires
	 */
	public List<FirewallRuleQuestionnaire> getFwOstiaQuestionnaires() {
		return fwOstiaQuestionnaires;
	}

	/**
	 * @param fwOstiaQuestionnaires the fwOstiaQuestionnaires to set
	 */
	public void setFwOstiaQuestionnaires(
			List<FirewallRuleQuestionnaire> fwOstiaQuestionnaires) {
		this.fwOstiaQuestionnaires = fwOstiaQuestionnaires;
	}

	public Long getTemplateID() {
		return templateID;
	}

	public void setTemplateID(Long templateID) {
		this.templateID = templateID;
	}

	/**
	 * @return the isRiskyRule
	 */
	public String getRiskyRule() {
		
		if(isRisk()){
			return "Y";
		}else{
			return "N";
		}

	}

	/**
	 * @param isRiskyRule the isRiskyRule to set
	 */
	public void setRiskyRule(String isRiskyRule) {
		this.riskyRule = isRiskyRule;
	}

    public String getTemplateConnectionName() {
		return templateConnectionName;
	}

	public void setTemplateConnectionName(String templateConnectionName) {
		this.templateConnectionName = templateConnectionName;
	}

	/**
	 * @return the riskSourceIPs
	 */
	public List<FireWallRuleIP> getRiskSourceIPs() {
		return riskSourceIPs;
	}

	/**
	 * @param riskSourceIPs the riskSourceIPs to set
	 */
	public void setRiskSourceIPs(List<FireWallRuleIP> riskSourceIPs) {
		this.riskSourceIPs = riskSourceIPs;
	}

	/**
	 * @return the riskDestinationIPs
	 */
	public List<FireWallRuleIP> getRiskDestinationIPs() {
		return riskDestinationIPs;
	}

	/**
	 * @param riskDestinationIPs the riskDestinationIPs to set
	 */
	public void setRiskDestinationIPs(List<FireWallRuleIP> riskDestinationIPs) {
		this.riskDestinationIPs = riskDestinationIPs;
	}

	/**
	 * @return the riskPorts
	 */
	public List<FireWallRulePort> getRiskPorts() {
		return riskPorts;
	}

	/**
	 * @param riskPorts the riskPorts to set
	 */
	public void setRiskPorts(List<FireWallRulePort> riskPorts) {
		this.riskPorts = riskPorts;
	}

	/**
	 * @return the policies
	 */
	public List<FirewallRulePolicy> getPolicies() {
		return policies;
	}

	/**
	 * @param policies the policies to set
	 */
	public void setPolicies(List<FirewallRulePolicy> policies) {
		this.policies = policies;
	}

	/**
	 * @return the ipPortModified
	 */
	public boolean isIpPortModified() {
		return ipPortModified;
	}

	/**
	 * @param ipPortModified the ipPortModified to set
	 */
	public void setIpPortModified(boolean ipPortModified) {
		this.ipPortModified = ipPortModified;
	}

	public String getIsIpReg() {
		return isIpReg;
	}

	public void setIsIpReg(String isIpReg) {
		this.isIpReg = isIpReg;
	}

	public boolean isDrools() {
		return isDrools;
	}

	public void setDrools(boolean isDrools) {
		this.isDrools = isDrools;
	}

	public String getBoardAccess() {
		return boardAccess;
	}

	public void setBoardAccess(String boardAccess) {
		this.boardAccess = boardAccess;
	}

	public String getTpa() {
		return tpa;
	}

	public void setTpa(String tpa) {
		this.tpa = tpa;
	}

	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	

}
