package com.citigroup.cgti.c3par.domain;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



/**
 * The Class BaseMailVO.
 */
@XmlRootElement
public class SupervisorEmail extends C3PARMailMessage {

	
    private String managerName;
    
	
    private String formerEmpName;
    
    private String ccrEntCmpUrl;
    
	
    private ConnectionRole[] connRoles;
    
   

public static class ConnectionRole {
	   
    	private String ccr_id;
	   
    	private String role;
	   
	   @XmlElement
		public String getCcr_id() {
			return ccr_id;
		}
		public void setCcr_id(String ccr_id) {
			this.ccr_id = ccr_id;
		}
		
		@XmlElement
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
    	
    	
    }

   @XmlElement
	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	@XmlElement
	public String getFormerEmpName() {
		return formerEmpName;
	}

	public void setFormerEmpName(String formerEmpName) {
		this.formerEmpName = formerEmpName;
	}

	

	@XmlElement
	public ConnectionRole[] getConnRoles() {
		return connRoles;
	}

	public void setConnRoles(ConnectionRole[] connRoles) {
		this.connRoles = connRoles;
	}

	@XmlElement
	public String getCcrEntCmpUrl() {
		return ccrEntCmpUrl;
	}

	public void setCcrEntCmpUrl(String ccrEntCmpUrl) {
		this.ccrEntCmpUrl = ccrEntCmpUrl;
	}

	

    
    
}
