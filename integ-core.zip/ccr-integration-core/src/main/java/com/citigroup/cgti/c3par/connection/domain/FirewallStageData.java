package com.citigroup.cgti.c3par.connection.domain;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class FirewallStageData.
 */
public class FirewallStageData extends PerformerPagerDO {


    /** The fw name. */
    private String fwName;

    /** The fw type. */
    private String fwType;

    /** The fw policy. */
    private String fwPolicy;

    /** The mgmt region. */
    private String mgmtRegion;


    /**
     * Instantiates a new firewall stage data.
     */
    public FirewallStageData() {
	setTableName(PerformerTypes.FIREWALL_STAGE_DATA);
	setSequenceName(PerformerTypes.FIREWALL_STAGE_DATA_SEQ);
	// ----------
	addToDBMapping("fwName", "FIREWALL_NAME",1);
	addToDBMapping("fwType", "FIREWALL_TYPE",2);
	addToDBMapping("fwPolicy", "FIREWALL_POLICY",3);
	addToDBMapping("mgmtRegion", "MANAGEMENT_REGION",4);

    }


    /**
     * Gets the fw name.
     *
     * @return the fwName
     */
    public String getFwName() {
	return fwName;
    }


    /**
     * Sets the fw name.
     *
     * @param fwName the fwName to set
     */
    public void setFwName(String fwName) {
	this.fwName = fwName;
    }


    /**
     * Gets the fw policy.
     *
     * @return the fwPolicy
     */
    public String getFwPolicy() {
	return fwPolicy;
    }


    /**
     * Sets the fw policy.
     *
     * @param fwPolicy the fwPolicy to set
     */
    public void setFwPolicy(String fwPolicy) {
	this.fwPolicy = fwPolicy;
    }


    /**
     * Gets the fw type.
     *
     * @return the fwType
     */
    public String getFwType() {
	return fwType;
    }


    /**
     * Sets the fw type.
     *
     * @param fwType the fwType to set
     */
    public void setFwType(String fwType) {
	this.fwType = fwType;
    }


    /**
     * Gets the mgmt region.
     *
     * @return the mgmtRegion
     */
    public String getMgmtRegion() {
	return mgmtRegion;
    }


    /**
     * Sets the mgmt region.
     *
     * @param mgmtRegion the mgmtRegion to set
     */
    public void setMgmtRegion(String mgmtRegion) {
	this.mgmtRegion = mgmtRegion;
    }


}

