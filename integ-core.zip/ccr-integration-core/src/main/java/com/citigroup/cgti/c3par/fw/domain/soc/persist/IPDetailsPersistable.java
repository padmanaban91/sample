/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.common.domain.Application;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleApplication;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.IPDetailsRequest;
import com.citigroup.cgti.c3par.persistance.Persistable;

/**
 * @author ne36745
 *
 */
public interface IPDetailsPersistable extends Persistable {
	 List<FireWallRuleIP> loadIPDetails(IPDetailsRequest ipDetailsRequest);
	 List<FirewallRuleApplication> getFirewallRuleApplications(IPDetailsRequest ipDetailsRequest);
	 void saveFirewallRuleApplications(IPDetailsRequest ipDetailsRequest);
	 List<FireWallRule> getFirewallRulesByIPId(IPDetailsRequest ipDetailsRequest);
	 FirewallRuleApplication getFirewallRuleApplication(Long id);
	 void deleteFirewallRuleApplications(IPDetailsRequest ipDetailsRequest);
	 List<IPAddress> getIPsByFirewallRuleId(IPDetailsRequest ipDetailsRequest);
	void editFirewallRuleApplications(Application app, List<Long> selectedIPs, List<Long> selectedRules);
	Application checkApplicationExists(Application app);
}
