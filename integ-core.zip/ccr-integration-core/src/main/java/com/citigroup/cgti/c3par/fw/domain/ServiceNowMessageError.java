/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;


import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Configurable;

import com.citigroup.cgti.c3par.domain.Base;



/**
 * @author nc43495
 *
 */

public class ServiceNowMessageError extends Base {
	Logger log = Logger.getLogger(ServiceNowMessageError.class);
		
	private static final long serialVersionUID = 1L;
    
    
    private Long rfcID;
    private String errorKey;
    private String errorDescription;
  
    public ServiceNowMessageError() {
    	setCreated_date(new Date());
	}  
	
	
	public Long getRfcID() {
		return rfcID;
	}
	public void setRfcID(Long rfcID) {
		this.rfcID = rfcID;
	}
	public String getErrorKey() {
		return errorKey;
	}
	public void setErrorKey(String errorKey) {
		this.errorKey = errorKey;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	
   
}

