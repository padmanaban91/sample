package com.citigroup.cgti.c3par.admin.domain;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Configurable;

import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.Base;

public class DailyLoad extends Base{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private FirewallLocation fwLoc;
	
	private Long id;
	
	private GenericLookup genericLookup;
	
	private Long loadValue;
	
	private String globalData;
	
	private String updatedBy;
	
	
	private String createdBy;

	private String updatedDateDisplay;
	
	
	
	public String getUpdatedDateDisplay() {
		if(getUpdated_date() != null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			return dateformat.format(getUpdated_date());
		}
		
		return updatedDateDisplay;
	}

	public void setUpdatedDateDisplay(String updatedDateDisplay) {
		this.updatedDateDisplay = updatedDateDisplay;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public DailyLoad() {
    	setCreated_date(new Date());
    	
	}
	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public FirewallLocation getFwLoc() {
		return fwLoc;
	}

	public void setFwLoc(FirewallLocation fwLoc) {
		this.fwLoc = fwLoc;
	}

	

	public GenericLookup getGenericLookup() {
		return genericLookup;
	}

	public void setGenericLookup(GenericLookup genericLookup) {
		this.genericLookup = genericLookup;
	}

	public Long getLoadValue() {
		return loadValue;
	}

	public void setLoadValue(Long loadValue) {
		this.loadValue = loadValue;
	}

	public String getGlobalData() {
		return globalData;
	}

	public void setGlobalData(String globalData) {
		this.globalData = globalData;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	 
}
