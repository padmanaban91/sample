package com.citigroup.cgti.c3par.admin.service;


import java.util.List;

import com.citigroup.cgti.c3par.admin.domain.ManageOfacMasterDTO;
import com.citigroup.cgti.c3par.appsense.domain.OfacSubnetMaster;

public interface ManageOfacMasterService {
	public void saveManageOfacMasterList(ManageOfacMasterDTO manageOfacMasterDTO);
	
	public List<OfacSubnetMaster> getIpDetails(String ipAddress);
	
	public List<OfacSubnetMaster> getExactIpDetails(String ipAddress);
	
	public void deleteManageOfacMasterList(String ipAddress, String updatedUser);

}
