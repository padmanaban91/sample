package com.citigroup.cgti.c3par.admin.domain;

/*
 * CONFIDENTIAL  AND PROPRIETARY
 */
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;

import com.citigroup.cgti.c3par.common.domain.soc.persist.ManageBusinessUnitPersistable;
import com.citigroup.cgti.c3par.model.BusinessUnitEntity;


/**
 * The Class AddCitiBusinessUnitForm.
 */

@SuppressWarnings( { "unchecked", "unused" })
public class AddCitiBusinessUnitProcess 
{
	
private static Logger log = Logger.getLogger(AddCitiBusinessUnitProcess.class);
	
	@Autowired
	private ManageBusinessUnitPersistable manageBusinessUnitPersistable;
	

    /** The sector name. */
    private String sectorName;

    /** The sector id. */
    private Long sectorId;

    /** The unit name. */
    private String unitName;

    /** The cost center. */
    private String costCenter;

    /** The description. */
    private String description;

    /** The business unit. */
    private BusinessUnitEntity businessUnit;

    /**
     * Gets the sector id.
     *
     * @return Returns the sectorId.
     */
    public Long getSectorId() {
	return sectorId;
    }

    /**
     * Sets the sector id.
     *
     * @param sectorId The sectorId to set.
     */
    public void setSectorId(Long sectorId) {
	this.sectorId = sectorId;
    }

    /**
     * Gets the cost center.
     *
     * @return Returns the costCenter.
     */
    public String getCostCenter() {
	return costCenter;
    }

    /**
     * Sets the cost center.
     *
     * @param costCenter The costCenter to set.
     */
    public void setCostCenter(String costCenter) {
	this.costCenter = costCenter;
    }

    /**
     * Gets the description.
     *
     * @return Returns the description.
     */
    public String getDescription() {
	return description;
    }

    /**
     * Sets the description.
     *
     * @param description The description to set.
     */
    public void setDescription(String description) {
	this.description = description;
    }

    /**
     * Gets the unit name.
     *
     * @return Returns the unitName.
     */
    public String getUnitName() {
	return unitName;
    }

    /**
     * Sets the unit name.
     *
     * @param unitName The unitName to set.
     */
    public void setUnitName(String unitName) {
	this.unitName = unitName;
    }

    /**
     * Gets the sector name.
     *
     * @return Returns the sectorName.
     */
    public String getSectorName() {
	return sectorName;
    }

    /**
     * Sets the sector name.
     *
     * @param sectorName The sectorName to set.
     */
    public void setSectorName(String sectorName) {
	this.sectorName = sectorName;
    }


    /**
     * Sets the business unit.
     *
     * @param bu the new business unit
     */
    public void setBusinessUnit(BusinessUnitEntity bu) { businessUnit = bu; }

    /**
     * Gets the business unit.
     *
     * @return the business unit
     */
    public BusinessUnitEntity getBusinessUnit() { return businessUnit; }

}