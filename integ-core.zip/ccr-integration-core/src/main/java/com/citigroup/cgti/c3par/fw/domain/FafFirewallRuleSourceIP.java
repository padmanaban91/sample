/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

/**
 * @author bs45969
 *
 */
public class FafFirewallRuleSourceIP extends FafFirewallRuleIP {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public FafFirewallRuleSourceIP() {
	setCreated_date(new Date());
    }

}
