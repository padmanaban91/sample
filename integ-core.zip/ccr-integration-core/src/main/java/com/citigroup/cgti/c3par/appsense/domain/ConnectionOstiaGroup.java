package com.citigroup.cgti.c3par.appsense.domain;

import java.util.List;

import javax.xml.bind.annotation.XmlTransient;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class ConnectionOstiaGroup.
 */
public class ConnectionOstiaGroup extends Base{

    /** The status. */
    private String status;

    /** The ostia question list. */
    private List<AppsenseOstiaQuestion> ostiaQuestionList;

    @XmlTransient
    public List<AppsenseOstiaQuestion> getOstiaQuestionList() {
		return ostiaQuestionList;
	}

	public void setOstiaQuestionList(List<AppsenseOstiaQuestion> ostiaQuestionList) {
		this.ostiaQuestionList = ostiaQuestionList;
	}

	/**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
	this.status = status;
    }

    
}
