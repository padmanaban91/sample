/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain.soc.persist;

import java.sql.SQLException;
import java.util.List;

import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FafFireflowTicket;
import com.citigroup.cgti.c3par.fw.domain.FafFireflowTicketLog;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRule;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleSuggestion;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.Firewall;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.IPAddressObj;
import com.citigroup.cgti.c3par.fw.domain.PortObject;
import com.citigroup.cgti.c3par.persistance.Persistable;

/**
 * @author bs45969
 *
 */
public interface FireflowRequestPersistable extends Persistable {

	public FafFireflowTicket getFafFireflowTicket(
			FafFireflowTicket fireflowTicket);

	public FafFirewallRule getFafFirewallRule(long id);
	
	public List<FafFireflowTicket> getFafFireflowTickets(
			FafFireflowTicket fireflowTicket);

	public List<FafFireflowTicket> getFafFireflowTickets(
			FireWallRuleProcess fwRuleProcess);

	public void generateFAF(Long tiRequest,String isIPReg) throws SQLException;

	public List<FafFireflowTicket> getFafFireflowTickets(Long tiRequest, String isIpReg);
	
	public List<Long> getAllTiRequests(Long processId, String isIpReg, String expType);

	public FafFireflowTicket getFafFireflowTicket(Long id);

	public List<FafFireflowTicket> findFafFireflowTicketsByLocationId(
			Long locationId);

	public List<FafFireflowTicket> findFafFireflowTicketsByLocationAndTiRequest(
			Long locationId, Long tiRequestId);

	public List<FafFirewallRuleSuggestion> getFafFirewallRuleSuggestions(
			FafFirewallRuleSuggestion fafFirewallRuleSuggestion);

	public Long saveFafFirewallRuleSuggestion(
			FafFirewallRuleSuggestion fafFirewallRuleSuggestion);

	public FafFirewallRuleSuggestion getFafFirewallRuleSuggestionById(
			FafFirewallRuleSuggestion fafFirewallRuleSuggestion);

	public Long saveFafFirewallSuggestedSourceIpObj(
			FafFirewallRuleSuggestion fafFirewallRuleSuggestion);

	public Long saveFafFirewallSuggestedDestIpObj(
			FafFirewallRuleSuggestion fafFirewallRuleSuggestion);

	public Long saveFafFirewallSuggestedPortObj(
			FafFirewallRuleSuggestion fafFirewallRuleSuggestion);

	public Long updateFafFireflowTicket(FafFireflowTicket fafFireflowTicket);

	public List<FafFirewallRule> findRequestedRulesByRequest(
			FAFRequest fafRequest);

	public List<FafFirewallRuleSuggestion> findRecommendedRulesByRequest(
			FAFRequest fafRequest);

	public FirewallPolicy getFirewallPolicyByName(String policyName);

	public Firewall getFirewallByName(String firewallName);

	public FafFirewallRuleSuggestion getFafFirewallRuleSuggestion(
			String ticketNo, Long policyId, int ruleSeq);

	public FafFirewallRuleSuggestion getFafFirewallRuleSuggestion(
			Long fafFirewallRuleId, Long policyId);

	public List<FafFirewallRule> findRequestedRulesByLocation(Long locId, Long tiReqId, String isIPReg, String requestType);

	public List<FafFirewallRuleSuggestion> findRecommendedRulesByLocation(Long locId, Long tiReqId, String isIPReg);

	public List<FirewallLocation> findLocationsByRequest(Long tiReqId);

	public FafFireflowTicket getFafFireflowTicketByNumber(String ticketNo);

	public List<FafFireflowTicket> getTicketsToBeCreated(Long tiRequest);

	public void saveFafFireflowTicketLog(
			FafFireflowTicketLog fafFireflowTicketLog);

	public List<FafFireflowTicket> getTicketsToBeResolved(long tiRequest);

	public FafFireflowTicketLog findTicketLog(Long id);

	public FafFirewallRule findRequestedRule(String ticketNumber,
			int ccrRuleEquence);

	public void saveFafFirewallRuleSuggestions(
			List<FafFirewallRuleSuggestion> fafFirewallRuleSuggestions);

	public boolean isTicketsToBeCreated(long tiRequest);

	public boolean isFFTicketsImplemented(Long tiReqId);

	public void resetRFCGeneratedStatus(Long tiReqId,String conType);

	public boolean isFFTicketsValidated(Long tiReqId);

	public List<FafFireflowTicket> getFafFireflowTicketsByReqId(Long requestId);
	
	public List<FafFireflowTicket> getFafFireflowTicketsByReqIdNew(Long requestId);
	
	public IPAddressObj getIPAddressObj(String address);
	public PortObject getPortObject(String service);

	public void deleteRFCFirewallRecords(Long tiReqId, String type);

	public FafFirewallRuleSuggestion getFafFirewallRuleSuggestion(
			String ticketNo, Long policyId, int ruleSeq, String ffRuleNumber);

	public List<FireWallRuleIP> getIPsforTemplateObject(Long ipId, Long ruleId,
			String forFAF, Long tiReqId);

	public List<FireWallRulePort> getPortsforTemplateObject(Long ipId, Long ruleId,
			String forFAF, Long tiReqId);

	public boolean hasFailedChildTicket(String ticketNumber);

	public boolean hasChildTicket(String ticketNumber);
	public TIRequest getTIRequestForGlobalTx(long tiRequestId) ;

}