package com.citigroup.cgti.c3par.acl.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;


/**
 * The Class ACLVariance.
 */
public class ACLVariance extends Base implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The ti process. */
    private TIProcess tiProcess = new TIProcess();

    /** The ti request. */
    private TIRequest tiRequest = new TIRequest();

    /** The acl_name. */
    private String acl_name=null;

    /** The acl_device_routers. */
    private String acl_device_routers=null;

    /** The acl_justification. */
    private String acl_justification=null;

    /**
     * Gets the ti process.
     *
     * @return the ti process
     */
    public TIProcess getTiProcess() {
	return tiProcess;
    }

    /**
     * Sets the ti process.
     *
     * @param tiProcess the new ti process
     */
    public void setTiProcess(TIProcess tiProcess) {
	this.tiProcess = tiProcess;
    }

    /**
     * Gets the ti request.
     *
     * @return the ti request
     */
    public TIRequest getTiRequest() {
	return tiRequest;
    }

    /**
     * Sets the ti request.
     *
     * @param tiRequest the new ti request
     */
    public void setTiRequest(TIRequest tiRequest) {
	this.tiRequest = tiRequest;
    }

    /**
     * Gets the acl_name.
     *
     * @return the acl_name
     */
    public String getAcl_name() {
	return acl_name;
    }

    /**
     * Sets the acl_name.
     *
     * @param aclName the new acl_name
     */
    public void setAcl_name(String aclName) {
	acl_name = aclName;
    }

    /**
     * Gets the acl_device_routers.
     *
     * @return the acl_device_routers
     */
    public String getAcl_device_routers() {
	return acl_device_routers;
    }

    /**
     * Sets the acl_device_routers.
     *
     * @param aclDeviceRouters the new acl_device_routers
     */
    public void setAcl_device_routers(String aclDeviceRouters) {
	acl_device_routers = aclDeviceRouters;
    }

    /**
     * Gets the acl_justification.
     *
     * @return the acl_justification
     */
    public String getAcl_justification() {
	return acl_justification;
    }

    /**
     * Sets the acl_justification.
     *
     * @param aclJustification the new acl_justification
     */
    public void setAcl_justification(String aclJustification) {
	acl_justification = aclJustification;
    }
}