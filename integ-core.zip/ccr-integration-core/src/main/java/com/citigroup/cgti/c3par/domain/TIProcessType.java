package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

/**
 * The Class TIProcessType.
 */
public class TIProcessType implements Serializable {

    private Long id;
	
    private String processType;

    private String bpmprocessName;

    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getBpmprocessName() {
		return bpmprocessName;
	}

	public void setBpmprocessName(String bpmprocessName) {
		this.bpmprocessName = bpmprocessName;
	}

}
