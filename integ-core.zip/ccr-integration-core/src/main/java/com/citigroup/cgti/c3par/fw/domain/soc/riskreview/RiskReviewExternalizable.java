package com.citigroup.cgti.c3par.fw.domain.soc.riskreview;

import java.util.HashMap;

import com.citigroup.cgti.c3par.decisionservice.DecisionServiceSoapFault;
import com.citigroup.cgti.c3par.decisionservice.TiRequestDTO;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestionnaire;


public interface RiskReviewExternalizable {
	
	HashMap<String, OstiaQuestionnaire> executeRiskRules(FireWallRule fireWallRule, 
			TiRequestDTO tiRequestDTO, Long tiRequestId) throws DecisionServiceSoapFault;
	
}
