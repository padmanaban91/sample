package com.citigroup.cgti.c3par.domain;

import javax.xml.bind.annotation.XmlElement;

public class FirewallDetailEmailVO {
	
	private String firewallType;
	private String firewallRegion;
	
	@XmlElement
	public String getFirewallType() {
		return firewallType;
	}
	public void setFirewallType(String firewallType) {
		this.firewallType = firewallType;
	}
	@XmlElement
	public String getFirewallRegion() {
		return firewallRegion;
	}
	public void setFirewallRegion(String firewallRegion) {
		this.firewallRegion = firewallRegion;
	}
	
	
	
}
