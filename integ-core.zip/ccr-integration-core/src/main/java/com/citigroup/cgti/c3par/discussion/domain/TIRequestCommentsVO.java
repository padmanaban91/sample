package com.citigroup.cgti.c3par.discussion.domain;

import java.io.Serializable;
import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class TIRequestCommentsVO.
 */
public class TIRequestCommentsVO extends Base implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -287676109140205643L;

    /** The comment_id. */
    private Long comment_id;
    //private String approval_response_type;//A-Approve & R-Reject
    /** The ti_request_id. */
    private Long ti_request_id;

    /** The comment_date. */
    private Date comment_date;

    /** The comments. */
    private String comments;

    /** The approver soe id. */
    private String approverSoeID;

    /** The approver id. */
    private Long approverID;

    /** The role id. */
    private Long roleId;

    /** The role name. */
    private String roleName;

    /** The ti_version_no. */
    private int ti_version_no;

    /** The locked. */
    private String locked;

    /** The sup review roles. */
    private String [] supReviewRoles;


    /**
     * Gets the locked.
     *
     * @return the locked
     */
    public String getLocked() {
	return locked;
    }

    /**
     * Sets the locked.
     *
     * @param locked the new locked
     */
    public void setLocked(String locked) {
	this.locked = locked;
    }

    /**
     * Gets the role id.
     *
     * @return the role id
     */
    public Long getRoleId() {
	return roleId;
    }

    /**
     * Gets the role name.
     *
     * @return the role name
     */
    public String getRoleName() {
	return roleName;
    }

    /*public String getApproval_response_type() {
		return approval_response_type;
	}
	public void setApproval_response_type(String approval_response_type) {
		this.approval_response_type = approval_response_type;
	}*/
    /**
     * Gets the approver id.
     *
     * @return the approver id
     */
    public Long getApproverID() {
	return approverID;
    }

    /**
     * Sets the approver id.
     *
     * @param approverID the new approver id
     */
    public void setApproverID(Long approverID) {
	this.approverID = approverID;
    }

    /**
     * Gets the comments.
     *
     * @return the comments
     */
    public String getComments() {
	return comments;
    }

    /**
     * Sets the comments.
     *
     * @param comments the new comments
     */
    public void setComments(String comments) {
	this.comments = comments;
    }

    /**
     * Sets the role id.
     *
     * @param roleId the new role id
     */
    public void setRoleId(Long roleId) {
	this.roleId = roleId;
    }

    /**
     * Sets the role name.
     *
     * @param roleName the new role name
     */
    public void setRoleName(String roleName) {
	this.roleName = roleName;
    }

    /**
     * Gets the approver soe id.
     *
     * @return the approver soe id
     */
    public String getApproverSoeID() {
	return approverSoeID;
    }

    /**
     * Sets the approver soe id.
     *
     * @param approverSoeID the new approver soe id
     */
    public void setApproverSoeID(String approverSoeID) {
	this.approverSoeID = approverSoeID;
    }

    /**
     * Gets the comment_date.
     *
     * @return the comment_date
     */
    public Date getComment_date() {
	return comment_date;
    }

    /**
     * Sets the comment_date.
     *
     * @param comment_date the new comment_date
     */
    public void setComment_date(Date comment_date) {
	this.comment_date = comment_date;
    }

    /**
     * Gets the ti_request_id.
     *
     * @return the ti_request_id
     */
    public Long getTi_request_id() {
	return ti_request_id;
    }

    /**
     * Sets the ti_request_id.
     *
     * @param ti_request_id the new ti_request_id
     */
    public void setTi_request_id(Long ti_request_id) {
	this.ti_request_id = ti_request_id;
    }

    /**
     * Gets the comment_id.
     *
     * @return the comment_id
     */
    public Long getComment_id() {
	return comment_id;
    }

    /**
     * Sets the comment_id.
     *
     * @param comment_id the new comment_id
     */
    public void setComment_id(Long comment_id) {
	this.comment_id = comment_id;
    }

    /**
     * Gets the ti_version_no.
     *
     * @return the ti_version_no
     */
    public int getTi_version_no() {
	return ti_version_no;
    }

    /**
     * Sets the ti_version_no.
     *
     * @param ti_version_no the new ti_version_no
     */
    public void setTi_version_no(int ti_version_no) {
	this.ti_version_no = ti_version_no;
    }

    /**
     * Gets the sup review roles.
     *
     * @return the sup review roles
     */
    public String[] getSupReviewRoles() {
	return supReviewRoles;
    }

    /**
     * Sets the sup review roles.
     *
     * @param supReviewRoles the new sup review roles
     */
    public void setSupReviewRoles(String[] supReviewRoles) {
	this.supReviewRoles = supReviewRoles;
    }

}
