package com.citigroup.cgti.c3par.domain;

import java.util.HashSet;
import java.util.Set;

public class RecepientInfo {
	private String roleName;
	private String procedureName;
	private Set<String> emails = new HashSet<String>();
	private Set<String> ssoids = new HashSet<String>();
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getProcedureName() {
		return procedureName;
	}
	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}
	public Set<String> getEmails() {
		return emails;
	}
	public void setEmails(Set<String> emails) {
		this.emails = emails;
	}
	public Set<String> getSsoids() {
		return ssoids;
	}
	public void setSsoids(Set<String> ssoids) {
		this.ssoids = ssoids;
	}
	
	public String getUserEmails() {
		StringBuffer sb = new StringBuffer();
			for (String email : getEmails()) {
				sb.append(email);
				sb.append(";");
			}
		return sb.toString();
	}
	
	public String getUserSSOIds() {
		StringBuffer sb = new StringBuffer();
			for (String email : getSsoids()) {
				sb.append(email);
				sb.append(";");
			}
		return sb.toString();
	}
}
