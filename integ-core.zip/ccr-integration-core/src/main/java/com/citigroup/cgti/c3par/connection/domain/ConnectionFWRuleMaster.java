package com.citigroup.cgti.c3par.connection.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionFWRuleMaster.
 */
public class ConnectionFWRuleMaster extends PerformerPagerDO{

    /** The ip mst id. */
    private Long ipMstId;

    /** The vip mst id. */
    private Long vipMstId;
    //private String natted;
    /** The rule type. */
    private String ruleType;

    /** The share flag. */
    private String shareFlag;

    /** The delete flag. */
    private String deleteFlag;

    /** The firewall id. */
    private Long firewallId;

    /** The acl variance. */
    private String aclVariance;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /** The connection ip xref. */
    private ConnectionIPXref connectionIPXref;

    /** The connection vip xref. */
    private ConnectionVIPXref connectionVIPXref;


    /**
     * Instantiates a new connection fw rule master.
     */
    public ConnectionFWRuleMaster() {
	//		----------
	setTableName(PerformerTypes.CON_FW_RULE_MASTER_TABLE);
	setSequenceName(PerformerTypes.CON_FW_RULE_MASTER_SEQ);
	//----------
	addToDBMapping("ipMstId","IP_ID",1);
	addToDBMapping("vipMstId","VIRTUAL_IP_ID",2);
	//addToDBMapping("natted","NATTING_FLAG",3);
	addToDBMapping("ruleType","RULE_TYPE",3);
	addToDBMapping("shareFlag","SHARE_FLAG",4);
	addToDBMapping("deleteFlag","DELETE_FLAG",5);
	addToDBMapping("firewallId","FIREWALL_ID",6);
	addToDBMapping("aclVariance","ACL_VARIANCE",7);
	addToDBMapping("created_date","created_date",8);
	addToDBMapping("updated_date","updated_date",9);

	addToNonPersistanceList("connectionIPXref");
	addToNonPersistanceList("connectionVIPXref");

	//		 ----------------------
	addToParentsMap(
		"com.citigroup.cgti.c3par.connection.domain.ConnectionIPPairMaster",
	"IP_PAIR_ID");

	addToDefaultValueMap("shareFlag", "F");
	addToDefaultValueMap("deleteFlag", "F");

    }



    /**
     * Gets the delete flag.
     *
     * @return Returns the connectionVIPMaster.
     */
    /*public ConnectionVIPMaster getConnectionVIPMaster() {
		return connectionVIPMaster;
	}*/
    /**
     * @param connectionVIPMaster The connectionVIPMaster to set.
     */
    /*public void setConnectionVIPMaster(ConnectionVIPMaster connectionVIPMaster) {
		this.connectionVIPMaster = connectionVIPMaster;
	}*/
    /**
     * @return Returns the connectionIPMaster.
     */
    /*public ConnectionIPMaster getConnectionIPMaster() {
		return connectionIPMaster;
	}*/
    /**
     * @param connectionIPMaster The connectionIPMaster to set.
     */
    /*public void setConnectionIPMaster(ConnectionIPMaster connectionIPMaster) {
		this.connectionIPMaster = connectionIPMaster;
	}*/
    public String getDeleteFlag() {
	return deleteFlag;
    }

    /**
     * Sets the delete flag.
     *
     * @param deleteFlag the new delete flag
     */
    public void setDeleteFlag(String deleteFlag) {
	this.deleteFlag = deleteFlag;
    }

    /**
     * Gets the ip mst id.
     *
     * @return the ip mst id
     */
    public Long getIpMstId() {
	return ipMstId;
    }

    /**
     * Sets the ip mst id.
     *
     * @param ipMstId the new ip mst id
     */
    public void setIpMstId(Long ipMstId) {
	this.ipMstId = ipMstId;
    }
    /*public String getNatted() {
		return natted;
	}
	public void setNatted(String isNatted) {
		this.natted = isNatted;
	}*/
    /**
     * Gets the rule type.
     *
     * @return the rule type
     */
    public String getRuleType() {
	return ruleType;
    }

    /**
     * Sets the rule type.
     *
     * @param ruleType the new rule type
     */
    public void setRuleType(String ruleType) {
	this.ruleType = ruleType;
    }

    /**
     * Gets the share flag.
     *
     * @return the share flag
     */
    public String getShareFlag() {
	return shareFlag;
    }

    /**
     * Sets the share flag.
     *
     * @param shareFlag the new share flag
     */
    public void setShareFlag(String shareFlag) {
	this.shareFlag = shareFlag;
    }

    /**
     * Gets the vip mst id.
     *
     * @return the vip mst id
     */
    public Long getVipMstId() {
	return vipMstId;
    }

    /**
     * Sets the vip mst id.
     *
     * @param vipMstId the new vip mst id
     */
    public void setVipMstId(Long vipMstId) {
	this.vipMstId = vipMstId;
    }



    /**
     * Gets the created_date.
     *
     * @return Returns the created_date.
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date The created_date to set.
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return Returns the updated_date.
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date The updated_date to set.
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }



    /**
     * Gets the acl variance.
     *
     * @return the acl variance
     */
    public String getAclVariance() {
	return aclVariance;
    }



    /**
     * Sets the acl variance.
     *
     * @param aclVairiance the new acl variance
     */
    public void setAclVariance(String aclVairiance) {
	this.aclVariance = aclVairiance;
    }



    /**
     * Gets the firewall id.
     *
     * @return the firewall id
     */
    public Long getFirewallId() {
	return firewallId;
    }



    /**
     * Sets the firewall id.
     *
     * @param firewallId the new firewall id
     */
    public void setFirewallId(Long firewallId) {
	this.firewallId = firewallId;
    }



    /**
     * Gets the connection ip xref.
     *
     * @return the connection ip xref
     */
    public ConnectionIPXref getConnectionIPXref() {
	return connectionIPXref;
    }



    /**
     * Sets the connection ip xref.
     *
     * @param connectionIPXref the new connection ip xref
     */
    public void setConnectionIPXref(ConnectionIPXref connectionIPXref) {
	this.connectionIPXref = connectionIPXref;
    }



    /**
     * Gets the connection vip xref.
     *
     * @return the connection vip xref
     */
    public ConnectionVIPXref getConnectionVIPXref() {
	return connectionVIPXref;
    }



    /**
     * Sets the connection vip xref.
     *
     * @param connectionVIPXref the new connection vip xref
     */
    public void setConnectionVIPXref(ConnectionVIPXref connectionVIPXref) {
	this.connectionVIPXref = connectionVIPXref;
    }
}
