


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = ConnectionDAO
// Table name = CONNECTION
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class ConnectionDAO.
 */
public class ConnectionDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "CONNECTION";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(ConnectionDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "Connection";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_NAME. */
    public static final String	COLUMN_NAME = "NAME";

    /** The Constant COLUMN_NAME_LEN. */
    public static final int		COLUMN_NAME_LEN = 150;

    /** The Constant COLUMN_STATUS. */
    public static final String	COLUMN_STATUS = "STATUS";

    /** The Constant COLUMN_STATUS_LEN. */
    public static final int		COLUMN_STATUS_LEN = 100;

    /** The Constant COLUMN_REQUESTERID. */
    public static final String	COLUMN_REQUESTERID = "REQUESTER_ID";

    /** The Constant COLUMN_REQUESTERID_LEN. */
    public static final int		COLUMN_REQUESTERID_LEN = 100;

    /** The Constant COLUMN_RATIONALE. */
    public static final String	COLUMN_RATIONALE = "RATIONALE";

    /** The Constant COLUMN_RATIONALE_LEN. */
    public static final int		COLUMN_RATIONALE_LEN = 2000;
    
    public static final int	COLUMN_SEMI_ANNUAL_LEN = 2000;
    public static final int	COLUMN_TP_TRAINING_LEN = 2000;
    public static final int	COLUMN_EXPORT_LICENCE_LEN = 2000;
    public static final int	COLUMN_CONN_FOR_CUST_LEN = 2000;
    public static final int	COLUMN_DIRECT_ACCESS_LEN = 2000;
    public static final int	COLUMN_CONN_ESTIMATE_LEN = 100;
    
    public static final int	COLUMN_DET_INFORMATION_LEN = 100;
    
    /** The Constant COLUMN_BENEFIT. */
    public static final String	COLUMN_BENEFIT = "BENEFIT";

    /** The Constant COLUMN_BENEFIT_LEN. */
    public static final int		COLUMN_BENEFIT_LEN = 500;

    /** The Constant COLUMN_PLCODE. */
    public static final String	COLUMN_PLCODE = "PLCODE";

    /** The Constant COLUMN_PLCODE_LEN. */
    public static final int		COLUMN_PLCODE_LEN = 25;

    /** The Constant COLUMN_REQUIRENETWORKACCESS. */
    public static final String	COLUMN_REQUIRENETWORKACCESS = "REQUIRE_NETWORK_ACCESS";

    /** The Constant COLUMN_ESTIMATEDREVENUEGENERATED. */
    public static final String	COLUMN_ESTIMATEDREVENUEGENERATED = "ESTIMATED_REVENUE_GENERATED";

    /** The Constant COLUMN_ESTIMATEDCOSTSAVING. */
    public static final String	COLUMN_ESTIMATEDCOSTSAVING = "ESTIMATED_COST_SAVING";

    /** The Constant COLUMN_COBREDUNDANCYREQUIRED. */
    public static final String	COLUMN_COBREDUNDANCYREQUIRED = "COB_REDUNDANCY_REQUIRED";

    /** The Constant COLUMN_REQUESTDATE. */
    public static final String	COLUMN_REQUESTDATE = "REQUEST_DATE";

    /** The Constant COLUMN_READYDATE. */
    public static final String	COLUMN_READYDATE = "READY_DATE";

    /** The Constant COLUMN_COMMENTS. */
    public static final String	COLUMN_COMMENTS = "COMMENTS";

    /** The Constant COLUMN_COMMENTS_LEN. */
    public static final int		COLUMN_COMMENTS_LEN = 4000;

    /** The Constant COLUMN_SEMIANNUALENTITLEMENTREVIEW. */
    public static final String	COLUMN_SEMIANNUALENTITLEMENTREVIEW = "SEMI_ANNUAL_ENTITLEMENT_REVIEW";

    /** The Constant COLUMN_ISSCONNECTIONCOMPLIANCE. */
    public static final String	COLUMN_ISSCONNECTIONCOMPLIANCE = "ISS_CONNECTION_COMPLIANCE";

    /** The Constant COLUMN_ISSCONNECTIONCOMPLIANCE_LEN. */
    public static final int		COLUMN_ISSCONNECTIONCOMPLIANCE_LEN = 2000;

    /** The Constant COLUMN_CITIPOLICYADHERENCE. */
    public static final String	COLUMN_CITIPOLICYADHERENCE = "CITI_POLICY_ADHERENCE";

    /** The Constant COLUMN_CITIPOLICYADHERENCE_LEN. */
    public static final int		COLUMN_CITIPOLICYADHERENCE_LEN = 1;

    /** The Constant COLUMN_ACCESSCITIGLOBALNETWORK. */
    public static final String	COLUMN_ACCESSCITIGLOBALNETWORK = "ACCESS_CITI_GLOBAL_NETWORK";

    /** The Constant COLUMN_TPTRAININGAWARNESSPROGRAM. */
    public static final String	COLUMN_TPTRAININGAWARNESSPROGRAM = "TP_TRAINING_AWARNESS_PROGRAM";

    /** The Constant COLUMN_SECURITYREVIEWCOMMENTS. */
    public static final String	COLUMN_SECURITYREVIEWCOMMENTS = "SECURITY_REVIEW_COMMENTS";

    /** The Constant COLUMN_SECURITYREVIEWCOMMENTS_LEN. */
    public static final int		COLUMN_SECURITYREVIEWCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_SPONSORREVIEWCOMMENTS. */
    public static final String	COLUMN_SPONSORREVIEWCOMMENTS = "SPONSOR_REVIEW_COMMENTS";

    /** The Constant COLUMN_SPONSORREVIEWCOMMENTS_LEN. */
    public static final int		COLUMN_SPONSORREVIEWCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_ACTIVATECONCOMMENTS. */
    public static final String	COLUMN_ACTIVATECONCOMMENTS = "ACTIVATE_CON_COMMENTS";

    /** The Constant COLUMN_ACTIVATECONCOMMENTS_LEN. */
    public static final int		COLUMN_ACTIVATECONCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_APPROVEDESIGNCOMMENTS. */
    public static final String	COLUMN_APPROVEDESIGNCOMMENTS = "APPROVE_DESIGN_COMMENTS";

    /** The Constant COLUMN_APPROVEDESIGNCOMMENTS_LEN. */
    public static final int		COLUMN_APPROVEDESIGNCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_INTEGRATIONSTATUSCOMMENTS. */
    public static final String	COLUMN_INTEGRATIONSTATUSCOMMENTS = "INTEGRATION_STATUS_COMMENTS";

    /** The Constant COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN. */
    public static final int		COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_PROCUREMENTDATE. */
    public static final String	COLUMN_PROCUREMENTDATE = "PROCUREMENT_DATE";

    /** The Constant COLUMN_PROCUREMENTCOMMENTS. */
    public static final String	COLUMN_PROCUREMENTCOMMENTS = "PROCUREMENT_COMMENTS";

    /** The Constant COLUMN_PROCUREMENTCOMMENTS_LEN. */
    public static final int		COLUMN_PROCUREMENTCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_CONNECTIONREQUESTID. */
    public static final String	COLUMN_CONNECTIONREQUESTID = "CONNECTION_REQUEST_ID";

    /** The Constant COLUMN_SYSTEMADMINCOMMENTS. */
    public static final String	COLUMN_SYSTEMADMINCOMMENTS = "SYSTEM_ADMIN_COMMENTS";

    /** The Constant COLUMN_SYSTEMADMINCOMMENTS_LEN. */
    public static final int		COLUMN_SYSTEMADMINCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_INFOMANID. */
    public static final String	COLUMN_INFOMANID = "INFOMAN_ID";

    /** The Constant COLUMN_OPANALYSTSCHEDULEDATE. */
    public static final String	COLUMN_OPANALYSTSCHEDULEDATE = "OP_ANALYST_SCHEDULE_DATE";

    /** The Constant COLUMN_OPANALYSTCOMPLETEDDATE. */
    public static final String	COLUMN_OPANALYSTCOMPLETEDDATE = "OP_ANALYST_COMPLETED_DATE";

    /** The Constant COLUMN_OPERATIONALANALYSTCOMMENTS. */
    public static final String	COLUMN_OPERATIONALANALYSTCOMMENTS = "OPERATIONAL_ANALYST_COMMENTS";

    /** The Constant COLUMN_OPERATIONALANALYSTCOMMENTS_LEN. */
    public static final int		COLUMN_OPERATIONALANALYSTCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_ISTGCOMMENTS. */
    public static final String	COLUMN_ISTGCOMMENTS = "ISTG_COMMENTS";

    /** The Constant COLUMN_ISTGCOMMENTS_LEN. */
    public static final int		COLUMN_ISTGCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_SPONSORBUSINESSCONSULTED. */
    public static final String	COLUMN_SPONSORBUSINESSCONSULTED = "SPONSOR_BUSINESS_CONSULTED";

    /** The Constant COLUMN_EXPORTLICENSECORDINATOR. */
    public static final String	COLUMN_EXPORTLICENSECORDINATOR = "EXPORT_LICENSE_CORDINATOR";
    // Column names of references
    /** The Constant COLUMN_LOOKUP_ID. */
    public static final String	COLUMN_LOOKUP_ID = "LOOKUP_ID";

    /** The Constant COLUMN_RELATIONSHIP_ID. */
    public static final String	COLUMN_RELATIONSHIP_ID = "RELATIONSHIP_ID";

    /** The Constant COLUMN_NETCON_ID. */
    public static final String	COLUMN_NETCON_ID = "NET_CON_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + ConnectionDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_NAME
    + ", " + COLUMN_STATUS
    + ", " + COLUMN_REQUESTERID
    + ", " + COLUMN_RATIONALE
    + ", " + COLUMN_BENEFIT
    + ", " + COLUMN_PLCODE
    + ", " + COLUMN_REQUIRENETWORKACCESS
    + ", " + COLUMN_ESTIMATEDREVENUEGENERATED
    + ", " + COLUMN_ESTIMATEDCOSTSAVING
    + ", " + COLUMN_COBREDUNDANCYREQUIRED
    + ", " + COLUMN_REQUESTDATE
    + ", " + COLUMN_READYDATE
    + ", " + COLUMN_COMMENTS
    + ", " + COLUMN_SEMIANNUALENTITLEMENTREVIEW
    + ", " + COLUMN_ISSCONNECTIONCOMPLIANCE
    + ", " + COLUMN_CITIPOLICYADHERENCE
    + ", " + COLUMN_ACCESSCITIGLOBALNETWORK
    + ", " + COLUMN_TPTRAININGAWARNESSPROGRAM
    + ", " + COLUMN_SECURITYREVIEWCOMMENTS
    + ", " + COLUMN_SPONSORREVIEWCOMMENTS
    + ", " + COLUMN_ACTIVATECONCOMMENTS
    + ", " + COLUMN_APPROVEDESIGNCOMMENTS
    + ", " + COLUMN_INTEGRATIONSTATUSCOMMENTS
    + ", " + COLUMN_PROCUREMENTDATE
    + ", " + COLUMN_PROCUREMENTCOMMENTS
    + ", " + COLUMN_CONNECTIONREQUESTID
    + ", " + COLUMN_SYSTEMADMINCOMMENTS
    + ", " + COLUMN_INFOMANID
    + ", " + COLUMN_OPANALYSTSCHEDULEDATE
    + ", " + COLUMN_OPANALYSTCOMPLETEDDATE
    + ", " + COLUMN_OPERATIONALANALYSTCOMMENTS
    + ", " + COLUMN_ISTGCOMMENTS
    + ", " + COLUMN_SPONSORBUSINESSCONSULTED
    + ", " + COLUMN_EXPORTLICENSECORDINATOR
    + ", " + COLUMN_LOOKUP_ID
    + ", " + COLUMN_RELATIONSHIP_ID
    + ", " + COLUMN_NETCON_ID
    + " FROM " + ConnectionDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = ConnectionDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + ConnectionDAO.TABLE + " SET "
    + COLUMN_NAME + " = ? "
    + ", " + COLUMN_STATUS + " = ? "
    + ", " + COLUMN_REQUESTERID + " = ? "
    + ", " + COLUMN_RATIONALE + " = ? "
    + ", " + COLUMN_BENEFIT + " = ? "
    + ", " + COLUMN_PLCODE + " = ? "
    + ", " + COLUMN_REQUIRENETWORKACCESS + " = ? "
    + ", " + COLUMN_ESTIMATEDREVENUEGENERATED + " = ? "
    + ", " + COLUMN_ESTIMATEDCOSTSAVING + " = ? "
    + ", " + COLUMN_COBREDUNDANCYREQUIRED + " = ? "
    + ", " + COLUMN_REQUESTDATE + " = ? "
    + ", " + COLUMN_READYDATE + " = ? "
    + ", " + COLUMN_COMMENTS + " = ? "
    + ", " + COLUMN_SEMIANNUALENTITLEMENTREVIEW + " = ? "
    + ", " + COLUMN_ISSCONNECTIONCOMPLIANCE + " = ? "
    + ", " + COLUMN_CITIPOLICYADHERENCE + " = ? "
    + ", " + COLUMN_ACCESSCITIGLOBALNETWORK + " = ? "
    + ", " + COLUMN_TPTRAININGAWARNESSPROGRAM + " = ? "
    + ", " + COLUMN_SECURITYREVIEWCOMMENTS + " = ? "
    + ", " + COLUMN_SPONSORREVIEWCOMMENTS + " = ? "
    + ", " + COLUMN_ACTIVATECONCOMMENTS + " = ? "
    + ", " + COLUMN_APPROVEDESIGNCOMMENTS + " = ? "
    + ", " + COLUMN_INTEGRATIONSTATUSCOMMENTS + " = ? "
    + ", " + COLUMN_PROCUREMENTDATE + " = ? "
    + ", " + COLUMN_PROCUREMENTCOMMENTS + " = ? "
    + ", " + COLUMN_CONNECTIONREQUESTID + " = ? "
    + ", " + COLUMN_SYSTEMADMINCOMMENTS + " = ? "
    + ", " + COLUMN_INFOMANID + " = ? "
    + ", " + COLUMN_OPANALYSTSCHEDULEDATE + " = ? "
    + ", " + COLUMN_OPANALYSTCOMPLETEDDATE + " = ? "
    + ", " + COLUMN_OPERATIONALANALYSTCOMMENTS + " = ? "
    + ", " + COLUMN_ISTGCOMMENTS + " = ? "
    + ", " + COLUMN_SPONSORBUSINESSCONSULTED + " = ? "
    + ", " + COLUMN_EXPORTLICENSECORDINATOR + " = ? "
    + ", " + COLUMN_LOOKUP_ID + " = ? "
    + ", " + COLUMN_RELATIONSHIP_ID + " = ? "
    + ", " + COLUMN_NETCON_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + ConnectionDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_NAME 
    + ", " + COLUMN_STATUS 
    + ", " + COLUMN_REQUESTERID 
    + ", " + COLUMN_RATIONALE 
    + ", " + COLUMN_BENEFIT 
    + ", " + COLUMN_PLCODE 
    + ", " + COLUMN_REQUIRENETWORKACCESS 
    + ", " + COLUMN_ESTIMATEDREVENUEGENERATED 
    + ", " + COLUMN_ESTIMATEDCOSTSAVING 
    + ", " + COLUMN_COBREDUNDANCYREQUIRED 
    + ", " + COLUMN_REQUESTDATE 
    + ", " + COLUMN_READYDATE 
    + ", " + COLUMN_COMMENTS 
    + ", " + COLUMN_SEMIANNUALENTITLEMENTREVIEW 
    + ", " + COLUMN_ISSCONNECTIONCOMPLIANCE 
    + ", " + COLUMN_CITIPOLICYADHERENCE 
    + ", " + COLUMN_ACCESSCITIGLOBALNETWORK 
    + ", " + COLUMN_TPTRAININGAWARNESSPROGRAM 
    + ", " + COLUMN_SECURITYREVIEWCOMMENTS 
    + ", " + COLUMN_SPONSORREVIEWCOMMENTS 
    + ", " + COLUMN_ACTIVATECONCOMMENTS 
    + ", " + COLUMN_APPROVEDESIGNCOMMENTS 
    + ", " + COLUMN_INTEGRATIONSTATUSCOMMENTS 
    + ", " + COLUMN_PROCUREMENTDATE 
    + ", " + COLUMN_PROCUREMENTCOMMENTS 
    + ", " + COLUMN_CONNECTIONREQUESTID 
    + ", " + COLUMN_SYSTEMADMINCOMMENTS 
    + ", " + COLUMN_INFOMANID 
    + ", " + COLUMN_OPANALYSTSCHEDULEDATE 
    + ", " + COLUMN_OPANALYSTCOMPLETEDDATE 
    + ", " + COLUMN_OPERATIONALANALYSTCOMMENTS 
    + ", " + COLUMN_ISTGCOMMENTS 
    + ", " + COLUMN_SPONSORBUSINESSCONSULTED 
    + ", " + COLUMN_EXPORTLICENSECORDINATOR 
    + ", " + COLUMN_LOOKUP_ID
    + ", " + COLUMN_RELATIONSHIP_ID
    + ", " + COLUMN_NETCON_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + ConnectionDAO.TABLE + " WHERE ID = ?";

    /** The Constant SELECT_PROJECTJUSTIFICATIONS_REFERENCE_IDS_STMT. */
    private static final String SELECT_PROJECTJUSTIFICATIONS_REFERENCE_IDS_STMT = "SELECT " + ConnectionProjectJustificationXrefDAO.COLUMN_ID + " FROM " + ConnectionProjectJustificationXrefDAO.TABLE + " WHERE " + ConnectionProjectJustificationXrefDAO.COLUMN_CONNECTION_ID + " = ?";

    /** The Constant SELECT_FACILITIESAFFECTED_REFERENCE_IDS_STMT. */
    private static final String SELECT_FACILITIESAFFECTED_REFERENCE_IDS_STMT = "SELECT " + ConnectionFacilitiesAffectedXrefDAO.COLUMN_ID + " FROM " + ConnectionFacilitiesAffectedXrefDAO.TABLE + " WHERE " + ConnectionFacilitiesAffectedXrefDAO.COLUMN_CONNECTION_ID + " = ?";

    /** The Constant SELECT_CITICONTACTS_REFERENCE_IDS_STMT. */
    private static final String SELECT_CITICONTACTS_REFERENCE_IDS_STMT = "SELECT " + ConnectionCitiContactXrefDAO.COLUMN_ID + " FROM " + ConnectionCitiContactXrefDAO.TABLE + " WHERE " + ConnectionCitiContactXrefDAO.COLUMN_CONNECTION_ID + " = ?";

    /** The Constant SELECT_TPCONTACTS_REFERENCE_IDS_STMT. */
    private static final String SELECT_TPCONTACTS_REFERENCE_IDS_STMT = "SELECT " + ConnectionTPContactXrefDAO.COLUMN_ID + " FROM " + ConnectionTPContactXrefDAO.TABLE + " WHERE " + ConnectionTPContactXrefDAO.COLUMN_CONNECTION_ID + " = ?";

    /** The Constant SELECT_RESOURCES_REFERENCE_IDS_STMT. */
    private static final String SELECT_RESOURCES_REFERENCE_IDS_STMT = "SELECT " + ConnectionResourceXrefDAO.COLUMN_ID + " FROM " + ConnectionResourceXrefDAO.TABLE + " WHERE " + ConnectionResourceXrefDAO.COLUMN_CONNECTION_ID + " = ?";

    /** The Constant SELECT_SERVICES_REFERENCE_IDS_STMT. */
    private static final String SELECT_SERVICES_REFERENCE_IDS_STMT = "SELECT " + ConnectionTPServiceXrefDAO.COLUMN_ID + " FROM " + ConnectionTPServiceXrefDAO.TABLE + " WHERE " + ConnectionTPServiceXrefDAO.COLUMN_CONNECTION_ID + " = ?";

    /** The Constant SELECT_MATERIALBILLS_REFERENCE_IDS_STMT. */
    private static final String SELECT_MATERIALBILLS_REFERENCE_IDS_STMT = "SELECT " + MaterialBillDAO.COLUMN_ID + " FROM " + MaterialBillDAO.TABLE + " WHERE " + MaterialBillDAO.COLUMN_CONNECTION_ID + " = ?";

    /** The Constant SELECT_FIREWALLS_REFERENCE_IDS_STMT. */
    private static final String SELECT_FIREWALLS_REFERENCE_IDS_STMT = "SELECT " + FirewallDetailsDAO.COLUMN_ID + " FROM " + FirewallDetailsDAO.TABLE + " WHERE " + FirewallDetailsDAO.COLUMN_CONNECTION_ID + " = ?";

    /** The Constant SELECT_CITIREQCONTACTS_REFERENCE_IDS_STMT. */
    private static final String SELECT_CITIREQCONTACTS_REFERENCE_IDS_STMT = "SELECT " + ConnectionCitiReqContactXrefDAO.COLUMN_ID + " FROM " + ConnectionCitiReqContactXrefDAO.TABLE + " WHERE " + ConnectionCitiReqContactXrefDAO.COLUMN_CONNECTION_ID + " = ?";


    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the connection dao
     */
    public static ConnectionDAO createInstance(DatabaseSession session)
    {
	return new ConnectionDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new connection dao.
     *
     * @param session the session
     */
    public ConnectionDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating ConnectionDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The ConnectionEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The ConnectionEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting ConnectionEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + ConnectionDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, ConnectionDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setStringToStatement(st, position, entity.getName(), COLUMN_NAME_LEN);
	    position = setStringToStatement(st, position, entity.getStatus(), COLUMN_STATUS_LEN);
	    position = setStringToStatement(st, position, entity.getRequesterId(), COLUMN_REQUESTERID_LEN);
	    position = setStringToStatement(st, position, entity.getRationale(), COLUMN_RATIONALE_LEN);
	    position = setStringToStatement(st, position, entity.getBenefit(), COLUMN_BENEFIT_LEN);
	    position = setStringToStatement(st, position, entity.getPlcode(), COLUMN_PLCODE_LEN);
	    position = setBooleanToStatement(st, position, entity.getRequireNetworkAccess());
	    position = setDoubleToStatement(st, position, entity.getEstimatedRevenueGenerated());
	    position = setDoubleToStatement(st, position, entity.getEstimatedCostSaving());
	    position = setBooleanToStatement(st, position, entity.getCobRedundancyRequired());
	    position = setDateToStatement(st, position, entity.getRequestDate());
	    position = setDateToStatement(st, position, entity.getReadyDate());
	    position = setStringToStatement(st, position, entity.getComments(), COLUMN_COMMENTS_LEN);
	    position = setBooleanToStatement(st, position, entity.getSemiAnnualEntitlementReview());
	    position = setStringToStatement(st, position, entity.getIssConnectionCompliance(), COLUMN_ISSCONNECTIONCOMPLIANCE_LEN);
	    position = setStringToStatement(st, position, entity.getCitiPolicyAdherence(), COLUMN_CITIPOLICYADHERENCE_LEN);
	    position = setBooleanToStatement(st, position, entity.getAccessCitiGlobalNetwork());
	    position = setBooleanToStatement(st, position, entity.getTpTrainingAwarnessProgram());
	    position = setStringToStatement(st, position, entity.getSecurityReviewComments(), COLUMN_SECURITYREVIEWCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getSponsorReviewComments(), COLUMN_SPONSORREVIEWCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getActivateConComments(), COLUMN_ACTIVATECONCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getApproveDesignComments(), COLUMN_APPROVEDESIGNCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getIntegrationStatusComments(), COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN);
	    position = setDateToStatement(st, position, entity.getProcurementDate());
	    position = setStringToStatement(st, position, entity.getProcurementComments(), COLUMN_PROCUREMENTCOMMENTS_LEN);
	    position = setLongToStatement(st, position, entity.getConnectionRequestId());
	    position = setStringToStatement(st, position, entity.getSystemAdminComments(), COLUMN_SYSTEMADMINCOMMENTS_LEN);
	    position = setLongToStatement(st, position, entity.getInfomanId());
	    position = setDateToStatement(st, position, entity.getOpAnalystScheduleDate());
	    position = setDateToStatement(st, position, entity.getOpAnalystCompletedDate());
	    position = setStringToStatement(st, position, entity.getOperationalAnalystComments(), COLUMN_OPERATIONALANALYSTCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getIstgComments(), COLUMN_ISTGCOMMENTS_LEN);
	    position = setBooleanToStatement(st, position, entity.getSponsorBusinessConsulted());
	    position = setBooleanToStatement(st, position, entity.getExportLicenseCordinator());

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateProjectJustificationsReferences((ConnectionEntity) entity);
	    updateFacilitiesAffectedReferences((ConnectionEntity) entity);
	    updateCitiContactsReferences((ConnectionEntity) entity);
	    updateTpContactsReferences((ConnectionEntity) entity);
	    updateResourcesReferences((ConnectionEntity) entity);
	    updateServicesReferences((ConnectionEntity) entity);
	    updateMaterialBillsReferences((ConnectionEntity) entity);
	    updateFirewallsReferences((ConnectionEntity) entity);
	    updateCitiReqContactsReferences((ConnectionEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + ConnectionDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating ConnectionEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + ConnectionDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setStringToStatement(st, position, entity.getName(), COLUMN_NAME_LEN);
	    position = setStringToStatement(st, position, entity.getStatus(), COLUMN_STATUS_LEN);
	    position = setStringToStatement(st, position, entity.getRequesterId(), COLUMN_REQUESTERID_LEN);
	    position = setStringToStatement(st, position, entity.getRationale(), COLUMN_RATIONALE_LEN);
	    position = setStringToStatement(st, position, entity.getBenefit(), COLUMN_BENEFIT_LEN);
	    position = setStringToStatement(st, position, entity.getPlcode(), COLUMN_PLCODE_LEN);
	    position = setBooleanToStatement(st, position, entity.getRequireNetworkAccess());
	    position = setDoubleToStatement(st, position, entity.getEstimatedRevenueGenerated());
	    position = setDoubleToStatement(st, position, entity.getEstimatedCostSaving());
	    position = setBooleanToStatement(st, position, entity.getCobRedundancyRequired());
	    position = setDateToStatement(st, position, entity.getRequestDate());
	    position = setDateToStatement(st, position, entity.getReadyDate());
	    position = setStringToStatement(st, position, entity.getComments(), COLUMN_COMMENTS_LEN);
	    position = setBooleanToStatement(st, position, entity.getSemiAnnualEntitlementReview());
	    position = setStringToStatement(st, position, entity.getIssConnectionCompliance(), COLUMN_ISSCONNECTIONCOMPLIANCE_LEN);
	    position = setStringToStatement(st, position, entity.getCitiPolicyAdherence(), COLUMN_CITIPOLICYADHERENCE_LEN);
	    position = setBooleanToStatement(st, position, entity.getAccessCitiGlobalNetwork());
	    position = setBooleanToStatement(st, position, entity.getTpTrainingAwarnessProgram());
	    position = setStringToStatement(st, position, entity.getSecurityReviewComments(), COLUMN_SECURITYREVIEWCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getSponsorReviewComments(), COLUMN_SPONSORREVIEWCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getActivateConComments(), COLUMN_ACTIVATECONCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getApproveDesignComments(), COLUMN_APPROVEDESIGNCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getIntegrationStatusComments(), COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN);
	    position = setDateToStatement(st, position, entity.getProcurementDate());
	    position = setStringToStatement(st, position, entity.getProcurementComments(), COLUMN_PROCUREMENTCOMMENTS_LEN);
	    position = setLongToStatement(st, position, entity.getConnectionRequestId());
	    position = setStringToStatement(st, position, entity.getSystemAdminComments(), COLUMN_SYSTEMADMINCOMMENTS_LEN);
	    position = setLongToStatement(st, position, entity.getInfomanId());
	    position = setDateToStatement(st, position, entity.getOpAnalystScheduleDate());
	    position = setDateToStatement(st, position, entity.getOpAnalystCompletedDate());
	    position = setStringToStatement(st, position, entity.getOperationalAnalystComments(), COLUMN_OPERATIONALANALYSTCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getIstgComments(), COLUMN_ISTGCOMMENTS_LEN);
	    position = setBooleanToStatement(st, position, entity.getSponsorBusinessConsulted());
	    position = setBooleanToStatement(st, position, entity.getExportLicenseCordinator());

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateProjectJustificationsReferences((ConnectionEntity) entity);
	    updateFacilitiesAffectedReferences((ConnectionEntity) entity);
	    updateCitiContactsReferences((ConnectionEntity) entity);
	    updateTpContactsReferences((ConnectionEntity) entity);
	    updateResourcesReferences((ConnectionEntity) entity);
	    updateServicesReferences((ConnectionEntity) entity);
	    updateMaterialBillsReferences((ConnectionEntity) entity);
	    updateFirewallsReferences((ConnectionEntity) entity);
	    updateCitiReqContactsReferences((ConnectionEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + ConnectionDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public ConnectionEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public ConnectionEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	ConnectionEntity obj = (ConnectionEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting ConnectionEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> ConnectionEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (ConnectionEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + ConnectionDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + ConnectionDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting ConnectionEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    ConnectionEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (ConnectionEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (ConnectionEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + ConnectionDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type ConnectionEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		ConnectionEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM CONNECTION";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (ConnectionEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + ConnectionDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type ConnectionEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + ConnectionDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    ConnectionEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    ConnectionEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(ConnectionEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(ConnectionEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + ConnectionDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(ConnectionEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();

	    // Go through the many association list and delete any entities that exist in it.
	    ConnectionProjectJustificationXrefDAO projectJustificationsDAO = getProjectJustificationsDAO();
	    List original_projectJustifications_ids = entity.getOriginalProjectJustificationsIds();
	    Iterator projectJustificationsIt = entity.getProjectJustifications().getDeletedList().iterator();
	    while (projectJustificationsIt.hasNext())
	    {
		ConnectionProjectJustificationXrefEntity o = (ConnectionProjectJustificationXrefEntity)projectJustificationsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_projectJustifications_ids.remove(id);
		}
		projectJustificationsDAO.delete(o);
	    }

	    projectJustificationsIt = entity.getProjectJustifications().iterator();
	    while (projectJustificationsIt.hasNext())
	    {
		ConnectionProjectJustificationXrefEntity o = (ConnectionProjectJustificationXrefEntity)projectJustificationsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_projectJustifications_ids.remove(id);
		}
		projectJustificationsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    projectJustificationsDAO.delete(original_projectJustifications_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    ConnectionFacilitiesAffectedXrefDAO facilitiesAffectedDAO = getFacilitiesAffectedDAO();
	    List original_facilitiesAffected_ids = entity.getOriginalFacilitiesAffectedIds();
	    Iterator facilitiesAffectedIt = entity.getFacilitiesAffected().getDeletedList().iterator();
	    while (facilitiesAffectedIt.hasNext())
	    {
		ConnectionFacilitiesAffectedXrefEntity o = (ConnectionFacilitiesAffectedXrefEntity)facilitiesAffectedIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_facilitiesAffected_ids.remove(id);
		}
		facilitiesAffectedDAO.delete(o);
	    }

	    facilitiesAffectedIt = entity.getFacilitiesAffected().iterator();
	    while (facilitiesAffectedIt.hasNext())
	    {
		ConnectionFacilitiesAffectedXrefEntity o = (ConnectionFacilitiesAffectedXrefEntity)facilitiesAffectedIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_facilitiesAffected_ids.remove(id);
		}
		facilitiesAffectedDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    facilitiesAffectedDAO.delete(original_facilitiesAffected_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    ConnectionCitiContactXrefDAO citiContactsDAO = getCitiContactsDAO();
	    List original_citiContacts_ids = entity.getOriginalCitiContactsIds();
	    Iterator citiContactsIt = entity.getCitiContacts().getDeletedList().iterator();
	    while (citiContactsIt.hasNext())
	    {
		ConnectionCitiContactXrefEntity o = (ConnectionCitiContactXrefEntity)citiContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiContacts_ids.remove(id);
		}
		citiContactsDAO.delete(o);
	    }

	    citiContactsIt = entity.getCitiContacts().iterator();
	    while (citiContactsIt.hasNext())
	    {
		ConnectionCitiContactXrefEntity o = (ConnectionCitiContactXrefEntity)citiContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiContacts_ids.remove(id);
		}
		citiContactsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    citiContactsDAO.delete(original_citiContacts_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    ConnectionTPContactXrefDAO tpContactsDAO = getTpContactsDAO();
	    List original_tpContacts_ids = entity.getOriginalTpContactsIds();
	    Iterator tpContactsIt = entity.getTpContacts().getDeletedList().iterator();
	    while (tpContactsIt.hasNext())
	    {
		ConnectionTPContactXrefEntity o = (ConnectionTPContactXrefEntity)tpContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_tpContacts_ids.remove(id);
		}
		tpContactsDAO.delete(o);
	    }

	    tpContactsIt = entity.getTpContacts().iterator();
	    while (tpContactsIt.hasNext())
	    {
		ConnectionTPContactXrefEntity o = (ConnectionTPContactXrefEntity)tpContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_tpContacts_ids.remove(id);
		}
		tpContactsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    tpContactsDAO.delete(original_tpContacts_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    ConnectionResourceXrefDAO resourcesDAO = getResourcesDAO();
	    List original_resources_ids = entity.getOriginalResourcesIds();
	    Iterator resourcesIt = entity.getResources().getDeletedList().iterator();
	    while (resourcesIt.hasNext())
	    {
		ConnectionResourceXrefEntity o = (ConnectionResourceXrefEntity)resourcesIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_resources_ids.remove(id);
		}
		resourcesDAO.delete(o);
	    }

	    resourcesIt = entity.getResources().iterator();
	    while (resourcesIt.hasNext())
	    {
		ConnectionResourceXrefEntity o = (ConnectionResourceXrefEntity)resourcesIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_resources_ids.remove(id);
		}
		resourcesDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    resourcesDAO.delete(original_resources_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    ConnectionTPServiceXrefDAO servicesDAO = getServicesDAO();
	    List original_services_ids = entity.getOriginalServicesIds();
	    Iterator servicesIt = entity.getServices().getDeletedList().iterator();
	    while (servicesIt.hasNext())
	    {
		ConnectionTPServiceXrefEntity o = (ConnectionTPServiceXrefEntity)servicesIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_services_ids.remove(id);
		}
		servicesDAO.delete(o);
	    }

	    servicesIt = entity.getServices().iterator();
	    while (servicesIt.hasNext())
	    {
		ConnectionTPServiceXrefEntity o = (ConnectionTPServiceXrefEntity)servicesIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_services_ids.remove(id);
		}
		servicesDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    servicesDAO.delete(original_services_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    MaterialBillDAO materialBillsDAO = getMaterialBillsDAO();
	    List original_materialBills_ids = entity.getOriginalMaterialBillsIds();
	    Iterator materialBillsIt = entity.getMaterialBills().getDeletedList().iterator();
	    while (materialBillsIt.hasNext())
	    {
		MaterialBillEntity o = (MaterialBillEntity)materialBillsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_materialBills_ids.remove(id);
		}
		materialBillsDAO.delete(o);
	    }

	    materialBillsIt = entity.getMaterialBills().iterator();
	    while (materialBillsIt.hasNext())
	    {
		MaterialBillEntity o = (MaterialBillEntity)materialBillsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_materialBills_ids.remove(id);
		}
		materialBillsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    materialBillsDAO.delete(original_materialBills_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    FirewallDetailsDAO firewallsDAO = getFirewallsDAO();
	    List original_firewalls_ids = entity.getOriginalFirewallsIds();
	    Iterator firewallsIt = entity.getFirewalls().getDeletedList().iterator();
	    while (firewallsIt.hasNext())
	    {
		FirewallDetailsEntity o = (FirewallDetailsEntity)firewallsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_firewalls_ids.remove(id);
		}
		firewallsDAO.delete(o);
	    }

	    firewallsIt = entity.getFirewalls().iterator();
	    while (firewallsIt.hasNext())
	    {
		FirewallDetailsEntity o = (FirewallDetailsEntity)firewallsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_firewalls_ids.remove(id);
		}
		firewallsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    firewallsDAO.delete(original_firewalls_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    ConnectionCitiReqContactXrefDAO citiReqContactsDAO = getCitiReqContactsDAO();
	    List original_citiReqContacts_ids = entity.getOriginalCitiReqContactsIds();
	    Iterator citiReqContactsIt = entity.getCitiReqContacts().getDeletedList().iterator();
	    while (citiReqContactsIt.hasNext())
	    {
		ConnectionCitiReqContactXrefEntity o = (ConnectionCitiReqContactXrefEntity)citiReqContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiReqContacts_ids.remove(id);
		}
		citiReqContactsDAO.delete(o);
	    }

	    citiReqContactsIt = entity.getCitiReqContacts().iterator();
	    while (citiReqContactsIt.hasNext())
	    {
		ConnectionCitiReqContactXrefEntity o = (ConnectionCitiReqContactXrefEntity)citiReqContactsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiReqContacts_ids.remove(id);
		}
		citiReqContactsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    citiReqContactsDAO.delete(original_citiReqContacts_ids);
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + ConnectionDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	ConnectionEntity entity = (ConnectionEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setName(getStringFromResultSet(rs, COLUMN_NAME));
	    entity.setName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalName(entity.getName());
	    //			entity.setStatus(getStringFromResultSet(rs, COLUMN_STATUS));
	    entity.setStatus(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalStatus(entity.getStatus());
	    //			entity.setRequesterId(getStringFromResultSet(rs, COLUMN_REQUESTERID));
	    entity.setRequesterId(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequesterId(entity.getRequesterId());
	    //			entity.setRationale(getStringFromResultSet(rs, COLUMN_RATIONALE));
	    entity.setRationale(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRationale(entity.getRationale());
	    //			entity.setBenefit(getStringFromResultSet(rs, COLUMN_BENEFIT));
	    entity.setBenefit(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalBenefit(entity.getBenefit());
	    //			entity.setPlcode(getStringFromResultSet(rs, COLUMN_PLCODE));
	    entity.setPlcode(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalPlcode(entity.getPlcode());
	    //			entity.setRequireNetworkAccess(getBooleanFromResultSet(rs, COLUMN_REQUIRENETWORKACCESS));
	    entity.setRequireNetworkAccess(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequireNetworkAccess(entity.getRequireNetworkAccess());
	    //			entity.setEstimatedRevenueGenerated(getDoubleFromResultSet(rs, COLUMN_ESTIMATEDREVENUEGENERATED));
	    entity.setEstimatedRevenueGenerated(getDoubleFromResultSetIndexed(rs, ++index));
	    entity.setOriginalEstimatedRevenueGenerated(entity.getEstimatedRevenueGenerated());
	    //			entity.setEstimatedCostSaving(getDoubleFromResultSet(rs, COLUMN_ESTIMATEDCOSTSAVING));
	    entity.setEstimatedCostSaving(getDoubleFromResultSetIndexed(rs, ++index));
	    entity.setOriginalEstimatedCostSaving(entity.getEstimatedCostSaving());
	    //			entity.setCobRedundancyRequired(getBooleanFromResultSet(rs, COLUMN_COBREDUNDANCYREQUIRED));
	    entity.setCobRedundancyRequired(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalCobRedundancyRequired(entity.getCobRedundancyRequired());
	    //			entity.setRequestDate(getDateFromResultSet(rs, COLUMN_REQUESTDATE));
	    entity.setRequestDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequestDate(entity.getRequestDate());
	    //			entity.setReadyDate(getDateFromResultSet(rs, COLUMN_READYDATE));
	    entity.setReadyDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalReadyDate(entity.getReadyDate());
	    //			entity.setComments(getStringFromResultSet(rs, COLUMN_COMMENTS));
	    entity.setComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalComments(entity.getComments());
	    //			entity.setSemiAnnualEntitlementReview(getBooleanFromResultSet(rs, COLUMN_SEMIANNUALENTITLEMENTREVIEW));
	    entity.setSemiAnnualEntitlementReview(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSemiAnnualEntitlementReview(entity.getSemiAnnualEntitlementReview());
	    //			entity.setIssConnectionCompliance(getStringFromResultSet(rs, COLUMN_ISSCONNECTIONCOMPLIANCE));
	    entity.setIssConnectionCompliance(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIssConnectionCompliance(entity.getIssConnectionCompliance());
	    //			entity.setCitiPolicyAdherence(getStringFromResultSet(rs, COLUMN_CITIPOLICYADHERENCE));
	    entity.setCitiPolicyAdherence(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalCitiPolicyAdherence(entity.getCitiPolicyAdherence());
	    //			entity.setAccessCitiGlobalNetwork(getBooleanFromResultSet(rs, COLUMN_ACCESSCITIGLOBALNETWORK));
	    entity.setAccessCitiGlobalNetwork(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalAccessCitiGlobalNetwork(entity.getAccessCitiGlobalNetwork());
	    //			entity.setTpTrainingAwarnessProgram(getBooleanFromResultSet(rs, COLUMN_TPTRAININGAWARNESSPROGRAM));
	    entity.setTpTrainingAwarnessProgram(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalTpTrainingAwarnessProgram(entity.getTpTrainingAwarnessProgram());
	    //			entity.setSecurityReviewComments(getStringFromResultSet(rs, COLUMN_SECURITYREVIEWCOMMENTS));
	    entity.setSecurityReviewComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSecurityReviewComments(entity.getSecurityReviewComments());
	    //			entity.setSponsorReviewComments(getStringFromResultSet(rs, COLUMN_SPONSORREVIEWCOMMENTS));
	    entity.setSponsorReviewComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSponsorReviewComments(entity.getSponsorReviewComments());
	    //			entity.setActivateConComments(getStringFromResultSet(rs, COLUMN_ACTIVATECONCOMMENTS));
	    entity.setActivateConComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalActivateConComments(entity.getActivateConComments());
	    //			entity.setApproveDesignComments(getStringFromResultSet(rs, COLUMN_APPROVEDESIGNCOMMENTS));
	    entity.setApproveDesignComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalApproveDesignComments(entity.getApproveDesignComments());
	    //			entity.setIntegrationStatusComments(getStringFromResultSet(rs, COLUMN_INTEGRATIONSTATUSCOMMENTS));
	    entity.setIntegrationStatusComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIntegrationStatusComments(entity.getIntegrationStatusComments());
	    //			entity.setProcurementDate(getDateFromResultSet(rs, COLUMN_PROCUREMENTDATE));
	    entity.setProcurementDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcurementDate(entity.getProcurementDate());
	    //			entity.setProcurementComments(getStringFromResultSet(rs, COLUMN_PROCUREMENTCOMMENTS));
	    entity.setProcurementComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcurementComments(entity.getProcurementComments());
	    //			entity.setConnectionRequestId(getLongFromResultSet(rs, COLUMN_CONNECTIONREQUESTID));
	    entity.setConnectionRequestId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalConnectionRequestId(entity.getConnectionRequestId());
	    //			entity.setSystemAdminComments(getStringFromResultSet(rs, COLUMN_SYSTEMADMINCOMMENTS));
	    entity.setSystemAdminComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSystemAdminComments(entity.getSystemAdminComments());
	    //			entity.setInfomanId(getLongFromResultSet(rs, COLUMN_INFOMANID));
	    entity.setInfomanId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalInfomanId(entity.getInfomanId());
	    //			entity.setOpAnalystScheduleDate(getDateFromResultSet(rs, COLUMN_OPANALYSTSCHEDULEDATE));
	    entity.setOpAnalystScheduleDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOpAnalystScheduleDate(entity.getOpAnalystScheduleDate());
	    //			entity.setOpAnalystCompletedDate(getDateFromResultSet(rs, COLUMN_OPANALYSTCOMPLETEDDATE));
	    entity.setOpAnalystCompletedDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOpAnalystCompletedDate(entity.getOpAnalystCompletedDate());
	    //			entity.setOperationalAnalystComments(getStringFromResultSet(rs, COLUMN_OPERATIONALANALYSTCOMMENTS));
	    entity.setOperationalAnalystComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOperationalAnalystComments(entity.getOperationalAnalystComments());
	    //			entity.setIstgComments(getStringFromResultSet(rs, COLUMN_ISTGCOMMENTS));
	    entity.setIstgComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIstgComments(entity.getIstgComments());
	    //			entity.setSponsorBusinessConsulted(getBooleanFromResultSet(rs, COLUMN_SPONSORBUSINESSCONSULTED));
	    entity.setSponsorBusinessConsulted(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSponsorBusinessConsulted(entity.getSponsorBusinessConsulted());
	    //			entity.setExportLicenseCordinator(getBooleanFromResultSet(rs, COLUMN_EXPORTLICENSECORDINATOR));
	    entity.setExportLicenseCordinator(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalExportLicenseCordinator(entity.getExportLicenseCordinator());

	    // Single References
	    //			entity.setLookupId(getLongFromResultSet(rs, COLUMN_LOOKUP_ID));
	    entity.setLookupId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalLookupId(entity.getLookupId());
	    //			entity.setRelationshipId(getLongFromResultSet(rs, COLUMN_RELATIONSHIP_ID));
	    entity.setRelationshipId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRelationshipId(entity.getRelationshipId());
	    //			entity.setNetConId(getLongFromResultSet(rs, COLUMN_NETCON_ID));
	    entity.setNetConId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalNetConId(entity.getNetConId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	ConnectionEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (ConnectionEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new ConnectionEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	ConnectionEntity entity = (ConnectionEntity)obj;
	loadProjectJustificationsReferenceIds(entity);
	loadFacilitiesAffectedReferenceIds(entity);
	loadCitiContactsReferenceIds(entity);
	loadTpContactsReferenceIds(entity);
	loadResourcesReferenceIds(entity);
	loadServicesReferenceIds(entity);
	loadMaterialBillsReferenceIds(entity);
	loadFirewallsReferenceIds(entity);
	loadCitiReqContactsReferenceIds(entity);
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("ConnectionCitiReqContactXrefDAO.loadReferences(): References for ConnectionEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("ConnectionCitiReqContactXrefDAO.loadReferences(): Loading references for ConnectionEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    ConnectionEntity entity = (ConnectionEntity)obj;

	    loadProjectJustificationsReferences(entity);

	    loadFacilitiesAffectedReferences(entity);

	    Long lookupId = entity.getLookupId();
	    if (lookupId != null)
	    {
		//			CommonLookupDataDAO lookupDAO = new CommonLookupDataDAO(getSession());
		CommonLookupDataDAO lookupDAO = getLookupDAO();
		entity.setLookup((CommonLookupDataEntity)lookupDAO.get(lookupId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalLookup(entity.getLookup());
	    }

	    loadCitiContactsReferences(entity);

	    loadTpContactsReferences(entity);

	    loadResourcesReferences(entity);

	    loadServicesReferences(entity);

	    Long relationshipId = entity.getRelationshipId();
	    if (relationshipId != null)
	    {
		//			RelationshipDAO relationshipDAO = new RelationshipDAO(getSession());
		RelationshipDAO relationshipDAO = getRelationshipDAO();
		entity.setRelationship((RelationshipEntity)relationshipDAO.get(relationshipId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalRelationship(entity.getRelationship());
	    }

	    Long netConId = entity.getNetConId();
	    if (netConId != null)
	    {
		//			NetworkConnectionDAO netConDAO = new NetworkConnectionDAO(getSession());
		NetworkConnectionDAO netConDAO = getNetConDAO();
		entity.setNetCon((NetworkConnectionEntity)netConDAO.get(netConId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalNetCon(entity.getNetCon());
	    }

	    loadMaterialBillsReferences(entity);

	    loadFirewallsReferences(entity);

	    loadCitiReqContactsReferences(entity);

	}
	catch(Exception e)
	{
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for ConnectionEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load lookup with id.
     *
     * @param id the id
     * @return the common lookup data entity
     * @throws DatabaseException the database exception
     */
    public CommonLookupDataEntity loadLookupWithId(Long id) throws DatabaseException
    {
	CommonLookupDataEntity entity = null;
	if (id != null)
	{
	    //			CommonLookupDataDAO lookupDAO = new CommonLookupDataDAO(getSession());
	    CommonLookupDataDAO lookupDAO = getLookupDAO();
	    entity = (CommonLookupDataEntity)lookupDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load relationship with id.
     *
     * @param id the id
     * @return the relationship entity
     * @throws DatabaseException the database exception
     */
    public RelationshipEntity loadRelationshipWithId(Long id) throws DatabaseException
    {
	RelationshipEntity entity = null;
	if (id != null)
	{
	    //			RelationshipDAO relationshipDAO = new RelationshipDAO(getSession());
	    RelationshipDAO relationshipDAO = getRelationshipDAO();
	    entity = (RelationshipEntity)relationshipDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load net con with id.
     *
     * @param id the id
     * @return the network connection entity
     * @throws DatabaseException the database exception
     */
    public NetworkConnectionEntity loadNetConWithId(Long id) throws DatabaseException
    {
	NetworkConnectionEntity entity = null;
	if (id != null)
	{
	    //			NetworkConnectionDAO netConDAO = new NetworkConnectionDAO(getSession());
	    NetworkConnectionDAO netConDAO = getNetConDAO();
	    entity = (NetworkConnectionEntity)netConDAO.get(id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	ConnectionEntity entity = (ConnectionEntity) obj;

	setLongToStatement(st, position++, entity.getLookup() != null ? entity.getLookup().getId() : entity.getLookupId());
	setLongToStatement(st, position++, entity.getRelationship() != null ? entity.getRelationship().getId() : entity.getRelationshipId());
	setLongToStatement(st, position++, entity.getNetCon() != null ? entity.getNetCon().getId() : entity.getNetConId());

	return position;
    }

    // Many Composition 'projectJustifications' helpers 'connection'
    //======================================================================
    /**
     * Loads all the ConnectionProjectJustificationXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadProjectJustificationsReferences(ConnectionEntity entity) throws DatabaseException
    {
	loadProjectJustificationsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the ConnectionProjectJustificationXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadProjectJustificationsReferences(ConnectionEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading ProjectJustifications references for ConnectionEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getProjectJustifications();
	    List id_list = entity.getOriginalProjectJustificationsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ConnectionProjectJustificationXrefDAO dao = getProjectJustificationsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ConnectionProjectJustificationXrefDAO dao = getProjectJustificationsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading ProjectJustifications references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ProjectJustifications References for ConnectionEntity [" + entity.getId() + "].", e);
	}


	//		entity.setProjectJustifications(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the ProjectJustifications references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadProjectJustificationsReferenceIds(ConnectionEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_PROJECTJUSTIFICATIONS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalProjectJustificationsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ProjectJustifications Reference IDs from ConnectionEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update project justifications references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateProjectJustificationsReferences(ConnectionEntity entity) throws DatabaseException
    {
	ManyAssociationList projectJustifications = entity.getProjectJustifications();
	ConnectionProjectJustificationXrefDAO dao = getProjectJustificationsDAO();

	Iterator itDeleted = projectJustifications.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    ConnectionProjectJustificationXrefEntity e = (ConnectionProjectJustificationXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = projectJustifications.iterator();
	while (it.hasNext())
	{
	    ConnectionProjectJustificationXrefEntity e = (ConnectionProjectJustificationXrefEntity) it.next();
	    e.setConnection(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'facilitiesAffected' helpers 'connection'
    //======================================================================
    /**
     * Loads all the ConnectionFacilitiesAffectedXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadFacilitiesAffectedReferences(ConnectionEntity entity) throws DatabaseException
    {
	loadFacilitiesAffectedReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the ConnectionFacilitiesAffectedXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadFacilitiesAffectedReferences(ConnectionEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading FacilitiesAffected references for ConnectionEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getFacilitiesAffected();
	    List id_list = entity.getOriginalFacilitiesAffectedIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ConnectionFacilitiesAffectedXrefDAO dao = getFacilitiesAffectedDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ConnectionFacilitiesAffectedXrefDAO dao = getFacilitiesAffectedDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading FacilitiesAffected references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load FacilitiesAffected References for ConnectionEntity [" + entity.getId() + "].", e);
	}


	//		entity.setFacilitiesAffected(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the FacilitiesAffected references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadFacilitiesAffectedReferenceIds(ConnectionEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_FACILITIESAFFECTED_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalFacilitiesAffectedIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load FacilitiesAffected Reference IDs from ConnectionEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update facilities affected references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateFacilitiesAffectedReferences(ConnectionEntity entity) throws DatabaseException
    {
	ManyAssociationList facilitiesAffected = entity.getFacilitiesAffected();
	ConnectionFacilitiesAffectedXrefDAO dao = getFacilitiesAffectedDAO();

	Iterator itDeleted = facilitiesAffected.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    ConnectionFacilitiesAffectedXrefEntity e = (ConnectionFacilitiesAffectedXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = facilitiesAffected.iterator();
	while (it.hasNext())
	{
	    ConnectionFacilitiesAffectedXrefEntity e = (ConnectionFacilitiesAffectedXrefEntity) it.next();
	    e.setConnection(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'lookup' helpers 'Connection' does not need helper
    // Many Composition 'citiContacts' helpers 'connection'
    //======================================================================
    /**
     * Loads all the ConnectionCitiContactXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadCitiContactsReferences(ConnectionEntity entity) throws DatabaseException
    {
	loadCitiContactsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the ConnectionCitiContactXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadCitiContactsReferences(ConnectionEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading CitiContacts references for ConnectionEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getCitiContacts();
	    List id_list = entity.getOriginalCitiContactsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ConnectionCitiContactXrefDAO dao = getCitiContactsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ConnectionCitiContactXrefDAO dao = getCitiContactsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading CitiContacts references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiContacts References for ConnectionEntity [" + entity.getId() + "].", e);
	}


	//		entity.setCitiContacts(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the CitiContacts references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadCitiContactsReferenceIds(ConnectionEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_CITICONTACTS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalCitiContactsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiContacts Reference IDs from ConnectionEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update citi contacts references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateCitiContactsReferences(ConnectionEntity entity) throws DatabaseException
    {
	ManyAssociationList citiContacts = entity.getCitiContacts();
	ConnectionCitiContactXrefExtDAO dao = getCitiContactsDAO();

	Iterator itDeleted = citiContacts.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    ConnectionCitiContactXrefEntity e = (ConnectionCitiContactXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = citiContacts.iterator();
	while (it.hasNext())
	{
	    ConnectionCitiContactXrefEntity e = (ConnectionCitiContactXrefEntity) it.next();
	    e.setConnection(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'tpContacts' helpers 'connection'
    //======================================================================
    /**
     * Loads all the ConnectionTPContactXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadTpContactsReferences(ConnectionEntity entity) throws DatabaseException
    {
	loadTpContactsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the ConnectionTPContactXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadTpContactsReferences(ConnectionEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading TpContacts references for ConnectionEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getTpContacts();
	    List id_list = entity.getOriginalTpContactsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ConnectionTPContactXrefDAO dao = getTpContactsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ConnectionTPContactXrefDAO dao = getTpContactsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading TpContacts references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load TpContacts References for ConnectionEntity [" + entity.getId() + "].", e);
	}


	//		entity.setTpContacts(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the TpContacts references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadTpContactsReferenceIds(ConnectionEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_TPCONTACTS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalTpContactsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load TpContacts Reference IDs from ConnectionEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update tp contacts references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateTpContactsReferences(ConnectionEntity entity) throws DatabaseException
    {
	ManyAssociationList tpContacts = entity.getTpContacts();
	ConnectionTPContactXrefDAO dao = getTpContactsDAO();

	Iterator itDeleted = tpContacts.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    ConnectionTPContactXrefEntity e = (ConnectionTPContactXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = tpContacts.iterator();
	while (it.hasNext())
	{
	    ConnectionTPContactXrefEntity e = (ConnectionTPContactXrefEntity) it.next();
	    e.setConnection(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'resources' helpers 'connection'
    //======================================================================
    /**
     * Loads all the ConnectionResourceXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadResourcesReferences(ConnectionEntity entity) throws DatabaseException
    {
	loadResourcesReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the ConnectionResourceXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadResourcesReferences(ConnectionEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Resources references for ConnectionEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getResources();
	    List id_list = entity.getOriginalResourcesIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ConnectionResourceXrefDAO dao = getResourcesDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ConnectionResourceXrefDAO dao = getResourcesDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Resources references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Resources References for ConnectionEntity [" + entity.getId() + "].", e);
	}


	//		entity.setResources(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Resources references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadResourcesReferenceIds(ConnectionEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_RESOURCES_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalResourcesIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Resources Reference IDs from ConnectionEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update resources references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateResourcesReferences(ConnectionEntity entity) throws DatabaseException
    {
	ManyAssociationList resources = entity.getResources();
	ConnectionResourceXrefDAO dao = getResourcesDAO();

	Iterator itDeleted = resources.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    ConnectionResourceXrefEntity e = (ConnectionResourceXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = resources.iterator();
	while (it.hasNext())
	{
	    ConnectionResourceXrefEntity e = (ConnectionResourceXrefEntity) it.next();
	    e.setConnection(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'services' helpers 'connection'
    //======================================================================
    /**
     * Loads all the ConnectionTPServiceXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadServicesReferences(ConnectionEntity entity) throws DatabaseException
    {
	loadServicesReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the ConnectionTPServiceXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadServicesReferences(ConnectionEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Services references for ConnectionEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getServices();
	    List id_list = entity.getOriginalServicesIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ConnectionTPServiceXrefDAO dao = getServicesDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ConnectionTPServiceXrefDAO dao = getServicesDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Services references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Services References for ConnectionEntity [" + entity.getId() + "].", e);
	}


	//		entity.setServices(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Services references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadServicesReferenceIds(ConnectionEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_SERVICES_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalServicesIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Services Reference IDs from ConnectionEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update services references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateServicesReferences(ConnectionEntity entity) throws DatabaseException
    {
	ManyAssociationList services = entity.getServices();
	ConnectionTPServiceXrefDAO dao = getServicesDAO();

	Iterator itDeleted = services.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    ConnectionTPServiceXrefEntity e = (ConnectionTPServiceXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = services.iterator();
	while (it.hasNext())
	{
	    ConnectionTPServiceXrefEntity e = (ConnectionTPServiceXrefEntity) it.next();
	    e.setConnection(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'relationship' helpers 'connections' does not need helper
    // Single non-composition 'netCon' helpers 'Connection' does not need helper
    // Many Composition 'materialBills' helpers 'connection'
    //======================================================================
    /**
     * Loads all the MaterialBill references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadMaterialBillsReferences(ConnectionEntity entity) throws DatabaseException
    {
	loadMaterialBillsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the MaterialBill references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadMaterialBillsReferences(ConnectionEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading MaterialBills references for ConnectionEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getMaterialBills();
	    List id_list = entity.getOriginalMaterialBillsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		MaterialBillDAO dao = getMaterialBillsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		MaterialBillDAO dao = getMaterialBillsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading MaterialBills references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load MaterialBills References for ConnectionEntity [" + entity.getId() + "].", e);
	}


	//		entity.setMaterialBills(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the MaterialBills references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadMaterialBillsReferenceIds(ConnectionEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_MATERIALBILLS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalMaterialBillsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load MaterialBills Reference IDs from ConnectionEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update material bills references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateMaterialBillsReferences(ConnectionEntity entity) throws DatabaseException
    {
	ManyAssociationList materialBills = entity.getMaterialBills();
	MaterialBillDAO dao = getMaterialBillsDAO();

	Iterator itDeleted = materialBills.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    MaterialBillEntity e = (MaterialBillEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = materialBills.iterator();
	while (it.hasNext())
	{
	    MaterialBillEntity e = (MaterialBillEntity) it.next();
	    e.setConnection(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'firewalls' helpers 'connection'
    //======================================================================
    /**
     * Loads all the FirewallDetails references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadFirewallsReferences(ConnectionEntity entity) throws DatabaseException
    {
	loadFirewallsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the FirewallDetails references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadFirewallsReferences(ConnectionEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Firewalls references for ConnectionEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getFirewalls();
	    List id_list = entity.getOriginalFirewallsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		FirewallDetailsDAO dao = getFirewallsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		FirewallDetailsDAO dao = getFirewallsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Firewalls references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Firewalls References for ConnectionEntity [" + entity.getId() + "].", e);
	}


	//		entity.setFirewalls(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Firewalls references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadFirewallsReferenceIds(ConnectionEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_FIREWALLS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalFirewallsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Firewalls Reference IDs from ConnectionEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update firewalls references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateFirewallsReferences(ConnectionEntity entity) throws DatabaseException
    {
	ManyAssociationList firewalls = entity.getFirewalls();
	FirewallDetailsDAO dao = getFirewallsDAO();

	Iterator itDeleted = firewalls.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    FirewallDetailsEntity e = (FirewallDetailsEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = firewalls.iterator();
	while (it.hasNext())
	{
	    FirewallDetailsEntity e = (FirewallDetailsEntity) it.next();
	    e.setConnection(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'citiReqContacts' helpers 'connection'
    //======================================================================
    /**
     * Loads all the ConnectionCitiReqContactXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadCitiReqContactsReferences(ConnectionEntity entity) throws DatabaseException
    {
	loadCitiReqContactsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the ConnectionCitiReqContactXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadCitiReqContactsReferences(ConnectionEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading CitiReqContacts references for ConnectionEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getCitiReqContacts();
	    List id_list = entity.getOriginalCitiReqContactsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ConnectionCitiReqContactXrefDAO dao = getCitiReqContactsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ConnectionCitiReqContactXrefDAO dao = getCitiReqContactsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading CitiReqContacts references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiReqContacts References for ConnectionEntity [" + entity.getId() + "].", e);
	}


	//		entity.setCitiReqContacts(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the CitiReqContacts references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadCitiReqContactsReferenceIds(ConnectionEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_CITIREQCONTACTS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalCitiReqContactsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiReqContacts Reference IDs from ConnectionEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update citi req contacts references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateCitiReqContactsReferences(ConnectionEntity entity) throws DatabaseException
    {
	ManyAssociationList citiReqContacts = entity.getCitiReqContacts();
	ConnectionCitiReqContactXrefExtDAO dao = getCitiReqContactsDAO();

	Iterator itDeleted = citiReqContacts.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    ConnectionCitiReqContactXrefEntity e = (ConnectionCitiReqContactXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = citiReqContacts.iterator();
	while (it.hasNext())
	{
	    ConnectionCitiReqContactXrefEntity e = (ConnectionCitiReqContactXrefEntity) it.next();
	    e.setConnection(entity);
	    dao.update(e, false);
	}
    }

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionProjectJustificationXrefDAO object 
     */
    protected ConnectionProjectJustificationXrefDAO getProjectJustificationsDAO()
    {
	ConnectionProjectJustificationXrefDAO dao = (ConnectionProjectJustificationXrefDAO)getSession().getDAO("ConnectionProjectJustificationXref");  
	if(dao == null)
	{
	    dao = new ConnectionProjectJustificationXrefDAO(getSession());  		
	    getSession().putDAO("ConnectionProjectJustificationXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionFacilitiesAffectedXrefDAO object 
     */
    protected ConnectionFacilitiesAffectedXrefDAO getFacilitiesAffectedDAO()
    {
	ConnectionFacilitiesAffectedXrefDAO dao = (ConnectionFacilitiesAffectedXrefDAO)getSession().getDAO("ConnectionFacilitiesAffectedXref");  
	if(dao == null)
	{
	    dao = new ConnectionFacilitiesAffectedXrefDAO(getSession());  		
	    getSession().putDAO("ConnectionFacilitiesAffectedXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A CommonLookupDataDAO object 
     */
    protected CommonLookupDataDAO getLookupDAO()
    {
	CommonLookupDataDAO dao = (CommonLookupDataDAO)getSession().getDAO("CommonLookupData");  
	if(dao == null)
	{
	    dao = new CommonLookupDataDAO(getSession());  		
	    getSession().putDAO("CommonLookupData", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionCitiContactXrefDAO object 
     */
    protected ConnectionCitiContactXrefExtDAO getCitiContactsDAO()
    {
	ConnectionCitiContactXrefExtDAO dao = (ConnectionCitiContactXrefExtDAO)getSession().getDAO("ConnectionCitiContactXref");  
	if(dao == null)
	{
	    dao = new ConnectionCitiContactXrefExtDAO(getSession());  		
	    getSession().putDAO("ConnectionCitiContactXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionTPContactXrefDAO object 
     */
    protected ConnectionTPContactXrefDAO getTpContactsDAO()
    {
	ConnectionTPContactXrefDAO dao = (ConnectionTPContactXrefDAO)getSession().getDAO("ConnectionTPContactXref");  
	if(dao == null)
	{
	    dao = new ConnectionTPContactXrefDAO(getSession());  		
	    getSession().putDAO("ConnectionTPContactXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionResourceXrefDAO object 
     */
    protected ConnectionResourceXrefDAO getResourcesDAO()
    {
	ConnectionResourceXrefDAO dao = (ConnectionResourceXrefDAO)getSession().getDAO("ConnectionResourceXref");  
	if(dao == null)
	{
	    dao = new ConnectionResourceXrefDAO(getSession());  		
	    getSession().putDAO("ConnectionResourceXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionTPServiceXrefDAO object 
     */
    protected ConnectionTPServiceXrefDAO getServicesDAO()
    {
	ConnectionTPServiceXrefDAO dao = (ConnectionTPServiceXrefDAO)getSession().getDAO("ConnectionTPServiceXref");  
	if(dao == null)
	{
	    dao = new ConnectionTPServiceXrefDAO(getSession());  		
	    getSession().putDAO("ConnectionTPServiceXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipDAO object 
     */
    protected RelationshipDAO getRelationshipDAO()
    {
	RelationshipDAO dao = (RelationshipDAO)getSession().getDAO("Relationship");  
	if(dao == null)
	{
	    dao = new RelationshipDAO(getSession());  		
	    getSession().putDAO("Relationship", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A NetworkConnectionDAO object 
     */
    protected NetworkConnectionDAO getNetConDAO()
    {
	NetworkConnectionDAO dao = (NetworkConnectionDAO)getSession().getDAO("NetworkConnection");  
	if(dao == null)
	{
	    dao = new NetworkConnectionDAO(getSession());  		
	    getSession().putDAO("NetworkConnection", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A MaterialBillDAO object 
     */
    protected MaterialBillDAO getMaterialBillsDAO()
    {
	MaterialBillDAO dao = (MaterialBillDAO)getSession().getDAO("MaterialBill");  
	if(dao == null)
	{
	    dao = new MaterialBillDAO(getSession());  		
	    getSession().putDAO("MaterialBill", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A FirewallDetailsDAO object 
     */
    protected FirewallDetailsDAO getFirewallsDAO()
    {
	FirewallDetailsDAO dao = (FirewallDetailsDAO)getSession().getDAO("FirewallDetails");  
	if(dao == null)
	{
	    dao = new FirewallDetailsDAO(getSession());  		
	    getSession().putDAO("FirewallDetails", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionCitiReqContactXrefDAO object 
     */
    protected ConnectionCitiReqContactXrefExtDAO getCitiReqContactsDAO()
    {
	ConnectionCitiReqContactXrefExtDAO dao = (ConnectionCitiReqContactXrefExtDAO)getSession().getDAO("ConnectionCitiReqContactXref");  
	if(dao == null)
	{
	    dao = new ConnectionCitiReqContactXrefExtDAO(getSession());  		
	    getSession().putDAO("ConnectionCitiReqContactXref", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [Name] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByName(String value) throws DatabaseException
    {
	return findByName(value, getSession());
    }

    /**
     * Find by name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_NAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Status] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByStatus(String value) throws DatabaseException
    {
	return findByStatus(value, getSession());
    }

    /**
     * Find by status.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByStatus(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_STATUS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RequesterId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequesterId(String value) throws DatabaseException
    {
	return findByRequesterId(value, getSession());
    }

    /**
     * Find by requester id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequesterId(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_REQUESTERID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Rationale] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRationale(String value) throws DatabaseException
    {
	return findByRationale(value, getSession());
    }

    /**
     * Find by rationale.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRationale(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_RATIONALE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Benefit] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByBenefit(String value) throws DatabaseException
    {
	return findByBenefit(value, getSession());
    }

    /**
     * Find by benefit.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByBenefit(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_BENEFIT + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Plcode] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByPlcode(String value) throws DatabaseException
    {
	return findByPlcode(value, getSession());
    }

    /**
     * Find by plcode.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByPlcode(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_PLCODE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RequireNetworkAccess] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequireNetworkAccess(Boolean value) throws DatabaseException
    {
	return findByRequireNetworkAccess(value, getSession());
    }

    /**
     * Find by require network access.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequireNetworkAccess(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_REQUIRENETWORKACCESS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [EstimatedRevenueGenerated] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByEstimatedRevenueGenerated(Double value) throws DatabaseException
    {
	return findByEstimatedRevenueGenerated(value, getSession());
    }

    /**
     * Find by estimated revenue generated.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByEstimatedRevenueGenerated(Double value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_ESTIMATEDREVENUEGENERATED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [EstimatedCostSaving] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByEstimatedCostSaving(Double value) throws DatabaseException
    {
	return findByEstimatedCostSaving(value, getSession());
    }

    /**
     * Find by estimated cost saving.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByEstimatedCostSaving(Double value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_ESTIMATEDCOSTSAVING + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [CobRedundancyRequired] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByCobRedundancyRequired(Boolean value) throws DatabaseException
    {
	return findByCobRedundancyRequired(value, getSession());
    }

    /**
     * Find by cob redundancy required.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByCobRedundancyRequired(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_COBREDUNDANCYREQUIRED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RequestDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequestDate(Date value) throws DatabaseException
    {
	return findByRequestDate(value, getSession());
    }

    /**
     * Find by request date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequestDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_REQUESTDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ReadyDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByReadyDate(Date value) throws DatabaseException
    {
	return findByReadyDate(value, getSession());
    }

    /**
     * Find by ready date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByReadyDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_READYDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Comments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByComments(String value) throws DatabaseException
    {
	return findByComments(value, getSession());
    }

    /**
     * Find by comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_COMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SemiAnnualEntitlementReview] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySemiAnnualEntitlementReview(Boolean value) throws DatabaseException
    {
	return findBySemiAnnualEntitlementReview(value, getSession());
    }

    /**
     * Find by semi annual entitlement review.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySemiAnnualEntitlementReview(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_SEMIANNUALENTITLEMENTREVIEW + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IssConnectionCompliance] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIssConnectionCompliance(String value) throws DatabaseException
    {
	return findByIssConnectionCompliance(value, getSession());
    }

    /**
     * Find by iss connection compliance.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIssConnectionCompliance(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_ISSCONNECTIONCOMPLIANCE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [CitiPolicyAdherence] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByCitiPolicyAdherence(String value) throws DatabaseException
    {
	return findByCitiPolicyAdherence(value, getSession());
    }

    /**
     * Find by citi policy adherence.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByCitiPolicyAdherence(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_CITIPOLICYADHERENCE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [AccessCitiGlobalNetwork] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByAccessCitiGlobalNetwork(Boolean value) throws DatabaseException
    {
	return findByAccessCitiGlobalNetwork(value, getSession());
    }

    /**
     * Find by access citi global network.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByAccessCitiGlobalNetwork(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_ACCESSCITIGLOBALNETWORK + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [TpTrainingAwarnessProgram] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByTpTrainingAwarnessProgram(Boolean value) throws DatabaseException
    {
	return findByTpTrainingAwarnessProgram(value, getSession());
    }

    /**
     * Find by tp training awarness program.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByTpTrainingAwarnessProgram(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_TPTRAININGAWARNESSPROGRAM + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SecurityReviewComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySecurityReviewComments(String value) throws DatabaseException
    {
	return findBySecurityReviewComments(value, getSession());
    }

    /**
     * Find by security review comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySecurityReviewComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_SECURITYREVIEWCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SponsorReviewComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySponsorReviewComments(String value) throws DatabaseException
    {
	return findBySponsorReviewComments(value, getSession());
    }

    /**
     * Find by sponsor review comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySponsorReviewComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_SPONSORREVIEWCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ActivateConComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByActivateConComments(String value) throws DatabaseException
    {
	return findByActivateConComments(value, getSession());
    }

    /**
     * Find by activate con comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByActivateConComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_ACTIVATECONCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ApproveDesignComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByApproveDesignComments(String value) throws DatabaseException
    {
	return findByApproveDesignComments(value, getSession());
    }

    /**
     * Find by approve design comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByApproveDesignComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_APPROVEDESIGNCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IntegrationStatusComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIntegrationStatusComments(String value) throws DatabaseException
    {
	return findByIntegrationStatusComments(value, getSession());
    }

    /**
     * Find by integration status comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIntegrationStatusComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_INTEGRATIONSTATUSCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ProcurementDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcurementDate(Date value) throws DatabaseException
    {
	return findByProcurementDate(value, getSession());
    }

    /**
     * Find by procurement date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcurementDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_PROCUREMENTDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ProcurementComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcurementComments(String value) throws DatabaseException
    {
	return findByProcurementComments(value, getSession());
    }

    /**
     * Find by procurement comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcurementComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_PROCUREMENTCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ConnectionRequestId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByConnectionRequestId(Long value) throws DatabaseException
    {
	return findByConnectionRequestId(value, getSession());
    }

    /**
     * Find by connection request id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByConnectionRequestId(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_CONNECTIONREQUESTID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SystemAdminComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySystemAdminComments(String value) throws DatabaseException
    {
	return findBySystemAdminComments(value, getSession());
    }

    /**
     * Find by system admin comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySystemAdminComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_SYSTEMADMINCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [InfomanId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByInfomanId(Long value) throws DatabaseException
    {
	return findByInfomanId(value, getSession());
    }

    /**
     * Find by infoman id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByInfomanId(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_INFOMANID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OpAnalystScheduleDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOpAnalystScheduleDate(Date value) throws DatabaseException
    {
	return findByOpAnalystScheduleDate(value, getSession());
    }

    /**
     * Find by op analyst schedule date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOpAnalystScheduleDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_OPANALYSTSCHEDULEDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OpAnalystCompletedDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOpAnalystCompletedDate(Date value) throws DatabaseException
    {
	return findByOpAnalystCompletedDate(value, getSession());
    }

    /**
     * Find by op analyst completed date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOpAnalystCompletedDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_OPANALYSTCOMPLETEDDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OperationalAnalystComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOperationalAnalystComments(String value) throws DatabaseException
    {
	return findByOperationalAnalystComments(value, getSession());
    }

    /**
     * Find by operational analyst comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOperationalAnalystComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_OPERATIONALANALYSTCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IstgComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIstgComments(String value) throws DatabaseException
    {
	return findByIstgComments(value, getSession());
    }

    /**
     * Find by istg comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIstgComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_ISTGCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SponsorBusinessConsulted] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySponsorBusinessConsulted(Boolean value) throws DatabaseException
    {
	return findBySponsorBusinessConsulted(value, getSession());
    }

    /**
     * Find by sponsor business consulted.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySponsorBusinessConsulted(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_SPONSORBUSINESSCONSULTED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ExportLicenseCordinator] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByExportLicenseCordinator(Boolean value) throws DatabaseException
    {
	return findByExportLicenseCordinator(value, getSession());
    }

    /**
     * Find by export license cordinator.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByExportLicenseCordinator(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_EXPORTLICENSECORDINATOR + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Lookup] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByLookup(Long value) throws DatabaseException
    {
	return findByLookup(value, getSession());
    }

    /**
     * Find by lookup.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByLookup(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_LOOKUP_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Relationship] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRelationship(Long value) throws DatabaseException
    {
	return findByRelationship(value, getSession());
    }

    /**
     * Find by relationship.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRelationship(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_RELATIONSHIP_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [NetCon] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByNetCon(Long value) throws DatabaseException
    {
	return findByNetCon(value, getSession());
    }

    /**
     * Find by net con.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByNetCon(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + COLUMN_NETCON_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by NetCon", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(ConnectionEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
