package com.citigroup.cgti.c3par.domain.helper;

import com.citigroup.cgti.c3par.domain.ThirdParty;
import com.citigroup.cgti.c3par.model.ThirdPartyEntity;



/*
 * CONFIDENTIAL  AND PROPRIETARY
 */

/**
 * The Class ThirdPartyEntityToThirdPartyMapper.
 */
public class ThirdPartyEntityToThirdPartyMapper
{

    /**
     * Transform to third party.
     *
     * @param thirdPartyEntity the third party entity
     * @param thirdParty the third party
     */
    public static void transformToThirdParty(ThirdPartyEntity thirdPartyEntity,
	    ThirdParty thirdParty)
    {
	thirdParty.setId(thirdPartyEntity.getId());
	thirdParty.setName(thirdPartyEntity.getName());
    }
}