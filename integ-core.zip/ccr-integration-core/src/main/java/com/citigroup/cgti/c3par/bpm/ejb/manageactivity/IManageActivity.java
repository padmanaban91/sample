package com.citigroup.cgti.c3par.bpm.ejb.manageactivity;



import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.domain.ActivityData;  




/**
 * The Interface IManageActivity.
 */
public interface IManageActivity {
	//depricated methods
	/**
	 * Adds the activity.
	 *
	 * @param activityData the activity data
	 * @param tiRequestId the ti request id
	 * @return the long
	 * @throws Exception the exception
	 */
	public  long addActivity(ActivityData activityData,long tiRequestId)  throws Exception;
//	set the status of activity to Schedule and set  the start date.Activity id is obtained from getNextActivity().scheduleAxtivity() is called after getNextActivity().
	  /**
 * Schedule activity.
 *
 * @param activityID the activity id
 * @param bpmInstanceId the bpm instance id
 * @return the long
 * @throws Exception the exception
 */
public  long scheduleActivity(long activityID,String bpmInstanceId)  throws Exception;
	  
  	/**
  	 * Gets the current activity role.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @param activityCode the activity code
  	 * @return the current activity role
  	 * @throws Exception the exception
  	 */
  	public String getCurrentActivityRole(long tiRequestID,String activityCode) throws Exception;
	  
	  //inuse methods
	  //lock Activity set locked by and lockeddate
	  /**
  	 * Lock activity.
  	 *
  	 * @param activityID the activity id
  	 * @param lockedBy the locked by
  	 * @param isForceLock the is force lock
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public  long lockActivity(long activityID,String lockedBy,boolean isForceLock)  throws Exception;
	  //public  long lockActivity(long activityID,String lockedBy)  throws Exception;
	  // update activity_enddate,user_id,activitystatus
	  /**
  	 * Complete activity.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @param completedBy the completed by
  	 * @param Status the status
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long completeActivity(long tiRequestID,String completedBy, String Status)  throws Exception;
	   
   	/**
   	 * Lock activity.
   	 *
   	 * @param tiRequestId the ti request id
   	 * @param lockedBy the locked by
   	 * @throws Exception the exception
   	 */
   	public void lockActivity(long tiRequestId,String lockedBy) throws Exception;
	  
  	/**
  	 * Log activity.
  	 *
  	 * @param activityDataDTO the activity data dto
  	 * @param tiRequestId the ti request id
  	 * @param bpmInstanceId the bpm instance id
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long logActivity(ActivityDataDTO activityDataDTO ,long tiRequestId,String bpmInstanceId) throws Exception;
	  
  	/**
  	 * Gets the provide info activity.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @return the provide info activity
  	 * @throws Exception the exception
  	 */
  	public String getProvideInfoActivity(long tiRequestID) throws Exception;
	  
  	/**
  	 * Checks if is current activity scheduled.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @param activityCode the activity code
  	 * @param prInfoRequestedActivityCode the pr info requested activity code
  	 * @return true, if is current activity scheduled
  	 * @throws Exception the exception
  	 */
  	public boolean isCurrentActivityScheduled(long tiRequestID,String activityCode,String prInfoRequestedActivityCode) throws Exception;
	  
  	/**
  	 * Gets the current activity status.
  	 *
  	 * @param activityTrailId the activity trail id
  	 * @return the current activity status
  	 * @throws Exception the exception
  	 */
  	public String getCurrentActivityStatus(long activityTrailId) throws Exception;
	  
  	/**
  	 * Update bpm instance id.
  	 *
  	 * @param activityTrailId the activity trail id
  	 * @param bpmInstanceId the bpm instance id
  	 * @throws Exception the exception
  	 */
  	public void updateBPMInstanceId(long activityTrailId,String bpmInstanceId) throws Exception;
	  
  	/**
  	 * Gets the scheduled activity tral id.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @param activityCode the activity code
  	 * @param prInfoRequestedActivityCode the pr info requested activity code
  	 * @return the scheduled activity tral id
  	 * @throws Exception the exception
  	 */
  	public long getScheduledActivityTralId(long tiRequestID,String activityCode, String prInfoRequestedActivityCode) throws Exception;
	  
  	/**
  	 * Gets the pr info requested activity id.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @param activityCode the activity code
  	 * @param prInfoRequestedActivityCode the pr info requested activity code
  	 * @return the pr info requested activity id
  	 * @throws Exception the exception
  	 */
  	public long getPrInfoRequestedActivityId(long tiRequestID,String activityCode, String prInfoRequestedActivityCode) throws Exception;
	  
  	/**
  	 * Checks if is pr info requested activity.
  	 *
  	 * @param activityTrailId the activity trail id
  	 * @return true, if is pr info requested activity
  	 * @throws Exception the exception
  	 */
  	public boolean isPrInfoRequestedActivity(long activityTrailId) throws Exception;
	  
  	/**
  	 * Complete exception activity.
  	 *
  	 * @param tiRequestID the ti request id
  	 * @param activityCode the activity code
  	 * @param prInfoActivityCode the pr info activity code
  	 * @return the long
  	 * @throws Exception the exception
  	 */
  	public long completeExceptionActivity(long tiRequestID,String activityCode, String prInfoActivityCode)  throws Exception;
  	
    //public void ccrToResolveIt(Long tiRequestId);
  	public void _notifyResolveIT(String activity,long tirequestId);
} 

