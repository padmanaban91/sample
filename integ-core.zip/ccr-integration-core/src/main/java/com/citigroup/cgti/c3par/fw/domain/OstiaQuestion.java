package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;
import java.util.List;
import java.util.Collections;
import com.citigroup.cgti.c3par.domain.Base;

/**
 * 
 * @author ne36745
 *
 */
public class OstiaQuestion extends Base {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String question;
	
	private String questionControlNumber;
	
	private RiskDefinition riskDefinition;
	
	private String answerType;
	
	private String hint;
	
	private List<PossibleAnswers> possibleAnswers;

	
	
	public OstiaQuestion() {
		setCreated_date(new Date());
	}

	/**
	 * @return the question
	 */
	public String getQuestion() {
		return question;
	}

	/**
	 * @param question the question to set
	 */
	public void setQuestion(String question) {
		this.question = question;
	}

	/**
	 * @return the riskDefinition
	 */
	public RiskDefinition getRiskDefinition() {
		return riskDefinition;
	}

	/**
	 * @param riskDefinition the riskDefinition to set
	 */
	public void setRiskDefinition(RiskDefinition riskDefinition) {
		this.riskDefinition = riskDefinition;
	}

	/**
	 * @return the answerType
	 */
	public String getAnswerType() {
		return answerType;
	}

	/**
	 * @param answerType the answerType to set
	 */
	public void setAnswerType(String answerType) {
		this.answerType = answerType;
	}

	/**
	 * @return the hint
	 */
	public String getHint() {
		return hint;
	}

	/**
	 * @param hint the hint to set
	 */
	public void setHint(String hint) {
		this.hint = hint;
	}

	/**
	 * @return the possibleAnswers
	 */
	public List<PossibleAnswers> getPossibleAnswers() {
		if(this.possibleAnswers != null){
			Collections.sort(this.possibleAnswers);
		}
		return possibleAnswers;
	}

	/**
	 * @param possibleAnswers the possibleAnswers to set
	 */
	public void setPossibleAnswers(List<PossibleAnswers> possibleAnswers) {
		this.possibleAnswers = possibleAnswers;
	}

	/**
	 * @return the questionControlNumber
	 */
	public String getQuestionControlNumber() {
		return questionControlNumber;
	}

	/**
	 * @param questionControlNumber the questionControlNumber to set
	 */
	public void setQuestionControlNumber(String questionControlNumber) {
		this.questionControlNumber = questionControlNumber;
	}

}
