/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain.soc.persist;

import java.util.HashMap;
import java.util.List;

import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.fw.domain.FireWallPolicyGroup;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleDestinationIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleSourceIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallZone;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleApplication;
import com.citigroup.cgti.c3par.fw.domain.HistoryFireWallRule;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.IPDetailsRequest;
import com.citigroup.cgti.c3par.fw.domain.Port;
import com.citigroup.cgti.c3par.fw.domain.SearchFirewallRuleRequest;
import com.citigroup.cgti.c3par.fw.domain.TIUploadedDocs;
import com.citigroup.cgti.c3par.fw.domain.TemplateConnection;
import com.citigroup.cgti.c3par.persistance.Persistable;
 
/**
 * @author bs45969
 * 
 */
public interface FirewallRuleProcessPersistable extends Persistable {

    public FireWallRule getFirewallRule(long id);

    public List<FireWallRule> getFirewallRules(FireWallRuleProcess fwRuleProcess);
    public Long getPreviousVersionTIRequest(Long processID);
    public List<FireWallRuleSourceIP> getSoureIpsByFirewallRule(long firewallRuleId,int maxResults);
    public List<FireWallRuleDestinationIP> getDestinationIpsByFirewallRule(long firewallRuleId,int maxResults);
    public List<FireWallRulePort> getPortsByFirewallRule(long firewallRuleId,int maxResults);

    public Long saveFireWallRule(FireWallRule ruleData) throws BusinessException;

    public FirewallPolicy getFirewallPolicyForIPReg() throws BusinessException;
    
    public String getIpRegSourceIP(IPAddress ipAddress, String relationshipType) throws BusinessException;
     
    List<FireWallZone> getFirewallZones(Long firewallGroup, Long firewallPolicy);

    int getFirewallRulesRowCount(FireWallRuleProcess fwRuleProcess);

    String getServiceName(Long portNumber) throws BusinessException;

    List<FireWallPolicyGroup> getFirewallGroups(Long fwLocation,
	    Long connectivityType);

    List<FirewallPolicy> getFirewallPolicies(FireWallRuleProcess fwRuleProcess);

    public int resetFAFGeneratedStatus(long tiRequestId, long firewallGroupId,long ObjRuleID,String isIPReg);

    FirewallPolicy getFirewallPolicy(FireWallRuleProcess fwRuleProcess);

    void deleteFirewallRule(Long firewallRuleId, Long tirequestId);
    
    void toggleBidirectionalRule(Long firewallRuleId);

    List<IPAddress> getIPAddresses(SearchFirewallRuleRequest fwRuleProcess);

    List<FireWallRuleIP> searchTemplateIPObjects(SearchFirewallRuleRequest fwRuleProcess);
    
    HashMap<Long, Integer> applicationCountForIPs(FireWallRuleProcess fwRuleProcess);
    
    FireWallRule identifyExistingIPsandPorts(FireWallRule fireWallRule);
    
    FireWallRule validateIPsandPorts(FireWallRule fireWallRule);
    
    boolean isRuleModified(FireWallRule fireWallRule);
    
    FireWallRule identifyExistingRules(FireWallRule fireWallRule);
    
    public FireWallPolicyGroup getFirewallGroupByName(String name);

	public boolean isFireWallRulesHasChanged(Long tiRequestId, String type);
	
	boolean completeCheckIPDetails(FireWallRuleProcess fwRuleProcess,String con_type);
	
	
	boolean completeCheckFireWallRules(FireWallRuleProcess fwRuleProcess,String con_type); 
	
	public void saveFireWallRuleBulkUpload(Long tiRequestID, String docType, String contentType, String docName, byte[] fileContent);
	
	public List<TIUploadedDocs> getFireWallRuleBulkUploadFileList(Long tiRequestID, String docType);
	
	public TIUploadedDocs getFireWallRuleDownloadFile(Long id);

	List<FireWallRulePort> searchTemplatePortObjects(SearchFirewallRuleRequest fwRuleProcess);

	List<FirewallPolicy> getFirewallCircuitPolicyList(FireWallRuleProcess fwruleProcess);
	
	List<FireWallPolicyGroup> getFirewallCircuitGroupList(FireWallRuleProcess fwruleProcess);
	
	boolean getFirewallCircuitDetailsCheck(Long tiRequestId);

	List getTIReqeustRelationshipDetails(Long tiRequestid);

	List<TemplateConnection> getViewTemplate(FireWallRuleProcess fwRuleProcess);
	
	//Modified for task 42665-starts
	public List<HistoryFireWallRule> getTemplateFirewallRules(FireWallRuleProcess fwRuleProcess);
	//Modified for task 42665-ends
	
	public void deleteTemplateFirewallRules(FireWallRuleProcess fwRuleProcess);
	
    public void saveTemplateFireWallRules(List<FireWallRule> firewallrules);

    List<FireWallRuleIP> getTemplateObjects();

    public Long getFirewallGroupID(String firewallGroupName) throws BusinessException;

    public FireWallPolicyGroup getFirewallPolicyGroup(Long groupid) throws BusinessException;

    List<FireWallPolicyGroup> getSearchFirewallGroups(FireWallRuleProcess fwRuleProcess);

	int copyTemplateOstiaAnswers(long templFWRuleID,long fwRuleID);

	public List getObjectIPList(Long tiReqId, String conType);

	public List getObjectPortList(Long tiReqId, String conType);

	public void updatePortObjectNames(List<Port> ports);

	public void updateIPObjectNames(List<IPAddress> ipAddresses);

	public String getConnectionName(Long ruleID);
	 
	FireWallRule getFirewallRuleForRisk(long id);

	FirewallPolicy getFirewallPoliyByName(String name);
	
	void updateFirewallRuleQuestionnaires(FireWallRule ruleData, boolean deleteFlag);
	
	List<FirewallRuleApplication> getFirewallRuleApplications(IPDetailsRequest ipDetailsRequest);
	
	List<FireWallRuleSourceIP> getIPRegSoureIp(long connID,long tiReqID);

	//Added for task 42665-starts
	public Long getPreviousVersionTIRequestForTemplate(Long processID);

	public List<HistoryFireWallRule> getFirewallRulesForTemplate(
			FireWallRuleProcess fireWallRuleProcess); 	
	//Added for task 42665-ends

}
