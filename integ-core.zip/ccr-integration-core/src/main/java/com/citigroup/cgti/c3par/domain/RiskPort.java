package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;


/**
 * The Class RiskPort.
 */
public class RiskPort extends Name implements Serializable {

    /** The risk port protocol. */
    private Name riskPortProtocol=new Name();

    /**
     * Gets the risk port protocol.
     *
     * @return the risk port protocol
     */
    public Name getRiskPortProtocol() {
	return riskPortProtocol;
    }

    /**
     * Sets the risk port protocol.
     *
     * @param riskPortProtocol the new risk port protocol
     */
    public void setRiskPortProtocol(Name riskPortProtocol) {
	this.riskPortProtocol = riskPortProtocol;
    }

}
