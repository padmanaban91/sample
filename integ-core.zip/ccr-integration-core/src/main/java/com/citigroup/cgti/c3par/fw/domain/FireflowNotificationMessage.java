package com.citigroup.cgti.c3par.fw.domain;


import java.io.Serializable;

/** This example shows how to establish a connection
 * and send messages to the JMS queue. The classes in this
 * package operate on the same JMS queue. Run the classes together to
 * witness messages being sent and received, and to browse the queue
 * for messages. The class is used to send messages to the queue.
 *
 * @author Copyright (c) 1999-2008 by BEA Systems, Inc. All Rights Reserved.
 */
public class  FireflowNotificationMessage implements Serializable {

	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private String id;
	    private String type;
	    private long connectionId;
	    private String requestId;
	    private String ffTicketId;
	    private String ffSubTicketId;
	    private String workOrderId;
	    protected String message;
	    private String risksDetails;
	    private String initialPlan;
	    private String workOrders;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public long getConnectionId() {
			return connectionId;
		}
		public void setConnectionId(long connectionId) {
			this.connectionId = connectionId;
		}
		public String getRequestId() {
			return requestId;
		}
		public void setRequestId(String requestId) {
			this.requestId = requestId;
		}
		public String getFfTicketId() {
			return ffTicketId;
		}
		public void setFfTicketId(String ffTicketId) {
			this.ffTicketId = ffTicketId;
		}
		public String getFfSubTicketId() {
			return ffSubTicketId;
		}
		public void setFfSubTicketId(String ffSubTicketId) {
			this.ffSubTicketId = ffSubTicketId;
		}
		public String getWorkOrderId() {
			return workOrderId;
		}
		public void setWorkOrderId(String workOrderId) {
			this.workOrderId = workOrderId;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public String getRisksDetails() {
			return risksDetails;
		}
		public void setRisksDetails(String risksDetails) {
			this.risksDetails = risksDetails;
		}
		public String getInitialPlan() {
			return initialPlan;
		}
		public void setInitialPlan(String initialPlan) {
			this.initialPlan = initialPlan;
		}
		public String getWorkOrders() {
			return workOrders;
		}
		public void setWorkOrders(String workOrders) {
			this.workOrders = workOrders;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
	    
	    
}

