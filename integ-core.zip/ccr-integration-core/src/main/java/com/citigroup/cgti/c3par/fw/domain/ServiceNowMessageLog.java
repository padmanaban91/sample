/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.sql.Blob;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jms.TextMessage;
import javax.sql.rowset.serial.SerialBlob;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

import net.nsroot.eur.servicesolutions.cate.integration.DataField;
import net.nsroot.eur.servicesolutions.cate.integration.DataFieldGroup;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentItem;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentSystem;
import net.nsroot.eur.servicesolutions.cate.integration.OrderSystem;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescriptionDocument;


/**
 * @author nc43495
 *
 */

public class ServiceNowMessageLog extends Base {
	Logger log = Logger.getLogger(ServiceNowMessageLog.class);

	CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		if(appContext!=null && appContext.containsBean("cCRBeanFactory")){
			ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
		}else{
			System.out.println("appContext is null");
		}
		
	}
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private Long tiRequestID;    
    private String snNumber;
    private String type;
    private Long rfcReqId;
    
    
    private List<ServiceNowMessageText> serviceNowMessageText;
    
    private ServiceNowMessageLog serviceNowMessageLog;
   
    List<ServiceNowMessageError> serviceNowMessageErrorsList = new ArrayList<ServiceNowMessageError>();
    
	public ServiceNowMessageLog getServiceNowMessageLog() {
		return serviceNowMessageLog;
	}
	public void setServiceNowMessageLog(ServiceNowMessageLog serviceNowMessageLog) {
		this.serviceNowMessageLog = serviceNowMessageLog;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getTiRequestID() {
		return tiRequestID;
	}
	public void setTiRequestID(Long tiRequestID) {
		this.tiRequestID = tiRequestID;
	}
	
	public String getSnNumber() {
		return snNumber;
	}
	public void setSnNumber(String snNumber) {
		this.snNumber = snNumber;
	}
	
	
	public List<ServiceNowMessageText> getServiceNowMessageText() {
		return serviceNowMessageText;
	}
	public void setServiceNowMessageText(
			List<ServiceNowMessageText> serviceNowMessageText) {
		this.serviceNowMessageText = serviceNowMessageText;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public ServiceNowMessageLog() {
    	setCreated_date(new Date());
   }
    public byte[]  getxmlFromMessage(TextMessage msg){
 	   return null;
 	   }
	
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public void updateRfcRequestId(long rfcReqId){
	    	rfcReqId=this.rfcReqId;
	  }
	
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
    public void save(){
		ccrBeanFactory.getServiceNowMessageLogPersistable().saveServiceNowMessage(this);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
    public void update(){
    	ccrBeanFactory.getServiceNowMessageLogPersistable().updateServiceNowMessage(this);
    }

    
    public ServiceNowMessageLog findServiceNowMessageLogByID(Long id){
    	return 	ccrBeanFactory.getServiceNowMessageLogPersistable().findServiceNowMessageLogByID(id);
    }
    
    /**
     * 
     * @param ritToccr
     * @return
     * @throws Exception
     */
    public static ServiceNowMessageLog parseInputStream(String ritToccr) 
	{
		
		ServiceNowMessageLog serviceNowMessageLogRet = new ServiceNowMessageLog();
		try{
			PurchaseOptionDescriptionDocument purchaseOptionDescriptionDocument = PurchaseOptionDescriptionDocument.Factory.parse(ritToccr);
			PurchaseOptionDescription purchaseOptionDescription = purchaseOptionDescriptionDocument.getPurchaseOptionDescription();
			/*
			System.out.println(purchaseOptionDescription.getGlobalMappingReference());
			System.out.println(purchaseOptionDescription.getQuantity());
			System.out.println(purchaseOptionDescription.getHasQuantity());
			System.out.println(purchaseOptionDescription.getSenderPodElement());
			System.out.println(purchaseOptionDescription.getMessageType());
			*/
			OrderSystem orderSystem = purchaseOptionDescription.getOrderSystem();
			
			Long tiReq = null;
			Long msgId =null;
			Long rfcReqId = null;
			
			if (orderSystem!= null) {
				System.out.println(orderSystem.getSystemID());
				
				String temp=orderSystem.getMappingReference();
				String[] parts=temp.split("-");
				tiReq = Long.valueOf(parts[2]);
				msgId=Long.valueOf(parts[3]);
				rfcReqId=Long.valueOf(parts[0]);
				
				serviceNowMessageLogRet.setRfcReqId(rfcReqId);				
				serviceNowMessageLogRet.setTiRequestID(tiReq);
				serviceNowMessageLogRet.setId(msgId);

				/*System.out.println("RFC Request id is"+rfcReqId);
				System.out.println("TiRequest Id is:"+tiReq);
				System.out.println("Unique Id is:"+msgId);
				System.out.println(orderSystem.getMappingReference());
				System.out.println(orderSystem.getSystemName());
				System.out.println(orderSystem.getSystemDescription()); 
				System.out.println(orderSystem.getOrderID());
				System.out.println(orderSystem.getOrderItemID());*/
			}
			
			FulfilmentSystem fulfilmentSystem = purchaseOptionDescription.getFulfilmentSystem();
			
			if (fulfilmentSystem != null) {
				serviceNowMessageLogRet.setSnNumber(fulfilmentSystem.getMappingReference());
			}
			
			ServiceNowMessageError serviceNowMessageError = null;
			
			List<ServiceNowMessageError> serviceNowMessageErrors = new ArrayList<ServiceNowMessageError>();
			
			FulfilmentItem fulfilmentItem = purchaseOptionDescription.getFulfilmentItem();
			
			DataFieldGroup[] fieldGroupArray =  fulfilmentItem.getDataForm().getDataFieldGroups().getDataFieldGroupArray();
			
			DataField[] dataFields = fieldGroupArray[0].getDataFields().getDataFieldArray();
			
			boolean error = false;
			
			for (DataField dataField : dataFields) {
				if ("response_code".equalsIgnoreCase(dataField.getName())
						&& "ERROR".equalsIgnoreCase(dataField.getValues().getValueArray(0))) {
					error = true;
				} else if ((error && "response_message".equalsIgnoreCase(dataField.getName())) ||
						"warning".equalsIgnoreCase(dataField.getName())) {
					serviceNowMessageError = new ServiceNowMessageError();
					serviceNowMessageError.setErrorKey(dataField.getName());
					serviceNowMessageError.setErrorDescription(dataField.getValues().getValueArray(0));
					serviceNowMessageError.setRfcID(rfcReqId);
					serviceNowMessageError.setCreated_date(new Date());
					serviceNowMessageErrors.add(serviceNowMessageError);
				}
			}
			
			ServiceNowMessageText serviceNowMessageText = new ServiceNowMessageText();
			serviceNowMessageText.setMessageLogId(msgId);
			serviceNowMessageText.setCreated_date(new Date());
			serviceNowMessageText.setUpdated_date(new Date());
			byte[] buff = ritToccr.getBytes();
			Blob blob = new SerialBlob(buff);
			serviceNowMessageText.setMessageText(blob);
			serviceNowMessageText.setMessageType(ServiceNowConstants.MSG_TYPE_INBOUND);
			serviceNowMessageLogRet.setServiceNowMessageText(new ArrayList<ServiceNowMessageText>());
			serviceNowMessageLogRet.getServiceNowMessageText().add(serviceNowMessageText);
			serviceNowMessageLogRet.setServiceNowMessageErrorsList(serviceNowMessageErrors);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return serviceNowMessageLogRet;
	}
	public Long getRfcReqId() {
		return rfcReqId;
	}
	public void setRfcReqId(Long rfcReqId) {
		this.rfcReqId = rfcReqId;
	}
	
	/**
	 * @return the serviceNowMessageErrorsList
	 */
	public List<ServiceNowMessageError> getServiceNowMessageErrorsList() {
		return serviceNowMessageErrorsList;
	}
	/**
	 * @param serviceNowMessageErrorsList the serviceNowMessageErrorsList to set
	 */
	public void setServiceNowMessageErrorsList(
			List<ServiceNowMessageError> serviceNowMessageErrorsList) {
		this.serviceNowMessageErrorsList = serviceNowMessageErrorsList;
	}
}

