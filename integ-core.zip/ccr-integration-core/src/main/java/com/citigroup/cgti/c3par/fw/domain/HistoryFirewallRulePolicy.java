/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * 
 * @author ne36745
 *
 */
public class HistoryFirewallRulePolicy extends Base {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private HistoryFireWallRule fireWallRule;
    private TIRequest updatedTIRequest;
    private TIRequest deletedTIRequest;
    private FirewallPolicy firewallPolicy;
    
    private Long rulePolicyId;
    
  //UI Level Attributes and Flags
    private boolean isDeleted;
    

    public HistoryFirewallRulePolicy() {
    }

	/**
	 * @return the fireWallRule
	 */
	public HistoryFireWallRule getFireWallRule() {
		return fireWallRule;
	}



	/**
	 * @param fireWallRule the fireWallRule to set
	 */
	public void setFireWallRule(HistoryFireWallRule fireWallRule) {
		this.fireWallRule = fireWallRule;
	}



	/**
	 * @return the updatedTIRequest
	 */
	public TIRequest getUpdatedTIRequest() {
		return updatedTIRequest;
	}



	/**
	 * @param updatedTIRequest the updatedTIRequest to set
	 */
	public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
		this.updatedTIRequest = updatedTIRequest;
	}



	/**
	 * @return the deletedTIRequest
	 */
	public TIRequest getDeletedTIRequest() {
		return deletedTIRequest;
	}



	/**
	 * @param deletedTIRequest the deletedTIRequest to set
	 */
	public void setDeletedTIRequest(TIRequest deletedTIRequest) {
		this.deletedTIRequest = deletedTIRequest;
	}


	/**
	 * @return the firewallPolicy
	 */
	public FirewallPolicy getFirewallPolicy() {
		return firewallPolicy;
	}

	/**
	 * @param firewallPolicy the firewallPolicy to set
	 */
	public void setFirewallPolicy(FirewallPolicy firewallPolicy) {
		this.firewallPolicy = firewallPolicy;
	}

	/**
	 * @return the isDeleted
	 */
	public boolean isDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the rulePolicyId
	 */
	public Long getRulePolicyId() {
		return rulePolicyId;
	}

	/**
	 * @param rulePolicyId the rulePolicyId to set
	 */
	public void setRulePolicyId(Long rulePolicyId) {
		this.rulePolicyId = rulePolicyId;
	}

}
