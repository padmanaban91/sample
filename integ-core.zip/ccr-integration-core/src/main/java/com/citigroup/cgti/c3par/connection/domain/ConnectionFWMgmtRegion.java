package com.citigroup.cgti.c3par.connection.domain;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionFWMgmtRegion.
 */
public class ConnectionFWMgmtRegion extends PerformerPagerDO {


    /** The mgmt region. */
    private String mgmtRegion;

    /** The opr analyst email. */
    private String oprAnalystEmail;


    /**
     * Instantiates a new connection fw mgmt region.
     */
    public ConnectionFWMgmtRegion() {
	setTableName(PerformerTypes.CON_FW_MGMT_REGION);
	setSequenceName(PerformerTypes.CON_FW_MGMT_REGION_SEQ);
	//----------
	addToDBMapping("mgmtRegion","MGT_REGION",1);
	addToDBMapping("oprAnalystEmail","OPERATION_ANALYST_EMAIL",2);
	//-------------
    }


    /**
     * Gets the mgmt region.
     *
     * @return the mgmt region
     */
    public String getMgmtRegion() {
	return mgmtRegion;
    }


    /**
     * Sets the mgmt region.
     *
     * @param mgmtRegion the new mgmt region
     */
    public void setMgmtRegion(String mgmtRegion) {
	this.mgmtRegion = mgmtRegion;
    }


    /**
     * Gets the opr analyst email.
     *
     * @return the opr analyst email
     */
    public String getOprAnalystEmail() {
	return oprAnalystEmail;
    }


    /**
     * Sets the opr analyst email.
     *
     * @param oprAnalystEmail the new opr analyst email
     */
    public void setOprAnalystEmail(String oprAnalystEmail) {
	this.oprAnalystEmail = oprAnalystEmail;
    }

}
