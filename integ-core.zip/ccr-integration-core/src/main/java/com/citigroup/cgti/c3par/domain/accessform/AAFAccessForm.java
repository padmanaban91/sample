package com.citigroup.cgti.c3par.domain.accessform;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.citigroup.cgti.c3par.appsense.domain.AppsensePortMaster;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.domain.Application;

/*
 * Appsense Access Form
 * @nc43495 
 */

@XmlRootElement
public class AAFAccessForm {
	
	private String nwCombType;
	
	private String userCombType;
	
	private String nwAppsenseType;
	
	private String userAppsenseType;
	
	private List<Application> appsenseAppDetails;
	
	private List<AppsensePortMaster> nwPortMasterList; 
	
	private List<CitiContact> userRecordsList;
	
	@XmlElement
	public String getNwCombType() {
		return nwCombType;
	}

	public void setNwCombType(String nwCombType) {
		this.nwCombType = nwCombType;
	}
	@XmlElement
	public String getUserCombType() {
		return userCombType;
	}

	public void setUserCombType(String userCombType) {
		this.userCombType = userCombType;
	}
	@XmlElement
	public String getNwAppsenseType() {
		return nwAppsenseType;
	}

	public void setNwAppsenseType(String nwAppsenseType) {
		this.nwAppsenseType = nwAppsenseType;
	}

	
	@XmlElement
	public List<Application> getAppsenseAppDetails() {
		return appsenseAppDetails;
	}

	public void setAppsenseAppDetails(List<Application> appsenseAppDetails) {
		this.appsenseAppDetails = appsenseAppDetails;
	}
	@XmlElement
	public String getUserAppsenseType() {
		return userAppsenseType;
	}

	public void setUserAppsenseType(String userAppsenseType) {
		this.userAppsenseType = userAppsenseType;
	}
	@XmlElement
	public List<AppsensePortMaster> getNwPortMasterList() {
		return nwPortMasterList;
	}

	public void setNwPortMasterList(List<AppsensePortMaster> nwPortMasterList) {
		this.nwPortMasterList = nwPortMasterList;
	}
	@XmlElement
	public List<CitiContact> getUserRecordsList() {
		return userRecordsList;
	}

	public void setUserRecordsList(List<CitiContact> userRecordsList) {
		this.userRecordsList = userRecordsList;
	}
	
	
	

}
