/**
 * 
 */
package com.citigroup.cgti.c3par.businessjustification.domain.soc.persist;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiContactXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiReqConXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqTPContactXref;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.HistoryContact;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.persistance.Persistable;

/**
 * @author pc79439
 * 
 */
public interface BusinessJustificationServicePersistable extends Persistable {

	public List<GenericLookup> getGenericLookupDropDown(String defName);

	public void updateConnectionBasicInfoBySA(String connectionName, String oldConnectionName, Long tiRequestId, String soeId);
	
	public void updateConnectionBasicInfo(Long tiRequestID, Long priority, String donotimpl, String vtTicketNo, Date date);

	public void updateBusinessCaseInfo(TIRequest tirequest,ConnectionRequest conreq,String[] virtualConReason);
	
	public List<ConReqCitiReqConXref> getRequesterContactsList(Long PlanningId);
	
	public List<ConReqCitiContactXref> getTargetContactsList(Long PlanningId);
	
	List<Role> getRoles();  
	
	List<Long> saveConReqCitiContactXref(Long planningId, CitiContact citiContact, String[] roleIds);
	public boolean isValidateThridPartyConts(Long relId,String relType,Long reqTpId,Long tarTpId);
	
	void updateConReqCitiContactXref(List<ConReqCitiContactXref> citiContactXrefs);
	
	void deleteConReqCitiContactXref(String[] conIds);
	
	List<Long> saveConReqCitiReqContactXref(Long planningId, CitiContact citiContact, String[] roleIds);
	
	void updateConReqCitiReqContactXref(List<ConReqCitiReqConXref> citiContactXrefs);
	
	void deleteConReqCitiReqContactXref(String[] conIds);
	
	Long getTiRequestForVersion(Integer version, Long processId);
	
	List<ConReqTPContactXref> getRequesterTPContactsList(Long planningId);
	
	List<ConReqTPContactXref> getTargetTPContactsList(Long planningId);

	void deleteContactsBySA(List<HistoryContact> historyContacts, Long tiRequestId, String soeId, String requestFrom);
	
	void addContactsBySA(List<HistoryContact> historyContacts, Long tiRequestId, String soeId, String requestFrom);
	
	void updateContactsBySA(Map<Integer, HistoryContact> newHistoryContacts, Map<Integer, HistoryContact> oldHistoryContacts, Long tiRequestId, String soeId, String requestFrom);

	void updateBusinessCaseBySA(Long relationshipId, Long oldRelationshipId, Long tiRequestId, String soeId);
	
	void copyContactsFromRelationship(Long tiRequestId);

	String getConnectionBusinessJustification(Long processId, Long tiRequestId);
	
	CitiContact getGDWDataBySSOId(String ssoId);
	
	CitiContact getBusinessOwnerDetails(Long tiRequestId,String relationType);
}
