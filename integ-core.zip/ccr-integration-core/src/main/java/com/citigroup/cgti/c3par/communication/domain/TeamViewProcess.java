package com.citigroup.cgti.c3par.communication.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess;
import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.TeamViewPersistable;
import com.citigroup.cgti.c3par.soa.vc.logic.RFCService;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class TeamViewProcess {

CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

	@Autowired
	private RFCService rfc;

	private CMPRequest resolveITMessage;

	private List<CMPRequest> cmpRequestMessageList;

	private String team;

	private String servicenowURL;
	// pagination properties
	private int limit;
	private int rowCount;
	private int offset;

	private int pageNo;
	private String field;
	private int totalPages;

	private int recordStartCount;
	private int recordEndCount;
	private int totalRecords;

	private String orderBy;
	private String sortingColumnName;

	private String errorMessage;

	private String selectedColumnName;

	private String sameColumnSelected;

	private TIProcessDTO tiProcessDTO;
	
	private String lastNameFiler;
	
	private List<String> lastNameList;

	private List<String> sectorList;
	
	private String sectorFiler;

	
	public String getSectorFiler() {
		return sectorFiler;
	}

	public void setSectorFiler(String sectorFiler) {
		this.sectorFiler = sectorFiler;
	}

	public List<String> getSectorList() {
		return ccrBeanFactory.getTeamViewPersistable().getSectorList();
	}

	public void setSectorList(List<String> sectorList) {
		this.sectorList = sectorList;
	}

	public List<CMPRequest> getTeamCmpReqData() {

		return ccrBeanFactory.getTeamViewPersistable().getTeamViewCmpReqData(this);

	}
	
	public List<String> getAssignedLastNameList() {
		return ccrBeanFactory.getTeamViewPersistable().getAssignedLastNameList();
	}

	
	public Long getUserId(String ssoId) {
		return ccrBeanFactory.getAdminServicePersistable().getUserId(ssoId);
	}

	
	public String getSnUrl() {
		return ccrBeanFactory.getRfc().getSnUrl();
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public TeamViewPersistable getTeamViewPersistable() {
		return ccrBeanFactory.getTeamViewPersistable();
	}


	public AdminServicePersistable getAdminServicePersistable() {
		return ccrBeanFactory.getAdminServicePersistable();
	}

	public List<CMPRequest> getCmpRequestMessageList() {
		return cmpRequestMessageList;
	}

	public void setCmpRequestMessageList(List<CMPRequest> cmpRequestMessageList) {
		this.cmpRequestMessageList = cmpRequestMessageList;
	}

	public IManageTIProcess getManageTIProcessImpl() {
		return ccrBeanFactory.getManageTIProcess();
	}


	public CMPRequest getResolveITMessage() {
		return resolveITMessage;
	}

	public void setResolveITMessage(CMPRequest resolveITMessage) {
		this.resolveITMessage = resolveITMessage;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getRecordStartCount() {
		return recordStartCount;
	}

	public void setRecordStartCount(int recordStartCount) {
		this.recordStartCount = recordStartCount;
	}

	public int getRecordEndCount() {
		return recordEndCount;
	}

	public void setRecordEndCount(int recordEndCount) {
		this.recordEndCount = recordEndCount;
	}

	public int getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getSortingColumnName() {
		return sortingColumnName;
	}

	public void setSortingColumnName(String sortingColumnName) {
		this.sortingColumnName = sortingColumnName;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getSelectedColumnName() {
		return selectedColumnName;
	}

	public void setSelectedColumnName(String selectedColumnName) {
		this.selectedColumnName = selectedColumnName;
	}

	public String getSameColumnSelected() {
		return sameColumnSelected;
	}

	public void setSameColumnSelected(String sameColumnSelected) {
		this.sameColumnSelected = sameColumnSelected;
	}

	public TIProcessDTO getTiProcessDTO() {
		return tiProcessDTO;
	}

	public void setTiProcessDTO(TIProcessDTO tiProcessDTO) {
		this.tiProcessDTO = tiProcessDTO;
	}

	public RFCService getRfc() {
		return rfc;
	}

	public void setRfc(RFCService rfc) {
		this.rfc = rfc;
	}

	public String getServicenowURL() {
		return servicenowURL;
	}

	public void setServicenowURL(String servicenowURL) {
		this.servicenowURL = servicenowURL;
	}

	public String getLastNameFiler() {
		return lastNameFiler;
	}

	public void setLastNameFiler(String lastNameFiler) {
		this.lastNameFiler = lastNameFiler;
	}

	public List<String> getLastNameList() {
		return lastNameList;
	}

	public void setLastNameList(List<String> lastNameList) {
		this.lastNameList = lastNameList;
	}
	
	
}
