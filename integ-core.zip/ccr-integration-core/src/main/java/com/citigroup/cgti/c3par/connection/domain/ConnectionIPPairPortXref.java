package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;

/**
 * The Class ConnectionIPPairPortXref.
 */
public class ConnectionIPPairPortXref extends PerformerPagerDO implements Serializable {



}
