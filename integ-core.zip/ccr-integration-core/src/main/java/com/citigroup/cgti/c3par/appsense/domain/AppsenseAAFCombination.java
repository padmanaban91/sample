package com.citigroup.cgti.c3par.appsense.domain;

import java.util.ArrayList;
import java.util.List;

import com.citigroup.cgti.c3par.connection.domain.CitiContact;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.Name;


/**
 * The Class AppsenseAAFCombination.
 */
public class AppsenseAAFCombination extends Name {

    /** The AD d_ combinations. */
    final int ADD_COMBINATIONS = 1;

    /** The DELET e_ combinations. */
    final int DELETE_COMBINATIONS = 3;

    /** The NO n_ networkapp s_ type. */
    final int NON_NETWORKAPPS_TYPE = 1;

    /** The NETWORKAPP s_ type. */
    final int NETWORKAPPS_TYPE = 2;

    /** The USER s_ type. */
    final int USERS_TYPE = 3;

    /** The combination type. */
    private Long combinationType; //ADD OR DELETE

    /** The faf type. */
    private Long fafType; //NON_NETWORKAPPS OR  NETWORKAPPS OR  USERS

    /** The non network apps. */
    private List nonNetworkApps = new ArrayList();//List of Application objects;Used for faf type NON_NETWORKAPPS_TYPE

    /** The aps users. */
    private List apsUsers = new ArrayList();//List of AppsenseUser objects;Used for faf type USERS_TYPE

    /** The aps application. */
    private Application apsApplication = new Application();//Used for faf type NETWORKAPPS_TYPE

    /** The aps ports. */
    private List apsPorts= new ArrayList();//List of AppsensePortMaster objects;Used for faf type NETWORKAPPS_TYPE

    /** The citi contact. */
    private CitiContact citiContact = new CitiContact();

    /** The aps port master. */
    private AppsensePortMaster apsPortMaster = new AppsensePortMaster();

    /** The process id. */
    private Long processId;	

    /** The ti request id. */
    private Long tiRequestId;

    /** The version id. */
    private Long versionId;

    /** The dev access. */
    private String devAccess;

    /** The prd access. */
    private String prdAccess;

    /** The non network apps export. */
    private List nonNetworkAppsExport = new ArrayList();

    /** The aps users export. */
    private List apsUsersExport = new ArrayList();

    /** The aps ports export. */
    private List apsPortsExport= new ArrayList();

    /** The network detail count. */
    private int networkDetailCount;

    /** The cross environment access. */
    private String crossEnvironmentAccess ;

    /**
     * Gets the cross environment access.
     *
     * @return the crossEnvironmentAccess
     */
    public String getCrossEnvironmentAccess() {
	return crossEnvironmentAccess;
    }

    /**
     * Sets the cross environment access.
     *
     * @param crossEnvironmentAccess the crossEnvironmentAccess to set
     */
    public void setCrossEnvironmentAccess(String crossEnvironmentAccess) {
	this.crossEnvironmentAccess = crossEnvironmentAccess;
    }

    /**
     * Gets the local folder access.
     *
     * @return the localFolderAccess
     */
    public String getLocalFolderAccess() {
	return localFolderAccess;
    }

    /**
     * Sets the local folder access.
     *
     * @param localFolderAccess the localFolderAccess to set
     */
    public void setLocalFolderAccess(String localFolderAccess) {
	this.localFolderAccess = localFolderAccess;
    }

    /** The local folder access. */
    private String localFolderAccess;

    /** The appsense ad group. */
    private AppsenseADGroup appsenseADGroup = new AppsenseADGroup();//Corresponding AD Group Name	

    /**
     * Gets the appsense ad group.
     *
     * @return the appsense ad group
     */
    public AppsenseADGroup getAppsenseADGroup() {
	return appsenseADGroup;
    }

    /**
     * Sets the appsense ad group.
     *
     * @param appsenseADGroup the new appsense ad group
     */
    public void setAppsenseADGroup(AppsenseADGroup appsenseADGroup) {
	this.appsenseADGroup = appsenseADGroup;
    }

    /**
     * Gets the network detail count.
     *
     * @return the network detail count
     */
    public int getNetworkDetailCount() {
	return networkDetailCount;
    }

    /**
     * Sets the network detail count.
     *
     * @param networkDetailCount the new network detail count
     */
    public void setNetworkDetailCount(int networkDetailCount) {
	this.networkDetailCount = networkDetailCount;
    }

    /**
     * Gets the non network apps.
     *
     * @return the non network apps
     */
    public List getNonNetworkApps() {
	return nonNetworkApps;
    }

    /**
     * Sets the non network apps.
     *
     * @param nonNetworkApps the new non network apps
     */
    public void setNonNetworkApps(List nonNetworkApps) {
	this.nonNetworkApps = nonNetworkApps;
    }

    /**
     * Gets the aps users.
     *
     * @return the aps users
     */
    public List getApsUsers() {
	return apsUsers;
    }

    /**
     * Sets the aps users.
     *
     * @param apsUsers the new aps users
     */
    public void setApsUsers(List apsUsers) {
	this.apsUsers = apsUsers;
    }	

    /**
     * Gets the aps ports.
     *
     * @return the aps ports
     */
    public List getApsPorts() {
	return apsPorts;
    }

    /**
     * Sets the aps ports.
     *
     * @param apsPorts the new aps ports
     */
    public void setApsPorts(List apsPorts) {
	this.apsPorts = apsPorts;
    }

    /**
     * Gets the citi contact.
     *
     * @return the citi contact
     */
    public CitiContact getCitiContact() {
	return citiContact;
    }

    /**
     * Sets the citi contact.
     *
     * @param citiContact the new citi contact
     */
    public void setCitiContact(CitiContact citiContact) {
	this.citiContact = citiContact;
    }

    /**
     * Gets the combination type.
     *
     * @return the combination type
     */
    public Long getCombinationType() {
	return combinationType;
    }

    /**
     * Sets the combination type.
     *
     * @param combinationType the new combination type
     */
    public void setCombinationType(Long combinationType) {
	this.combinationType = combinationType;
    }

    /**
     * Gets the faf type.
     *
     * @return the faf type
     */
    public Long getFafType() {
	return fafType;
    }

    /**
     * Sets the faf type.
     *
     * @param fafType the new faf type
     */
    public void setFafType(Long fafType) {
	this.fafType = fafType;
    }

    /**
     * Gets the process id.
     *
     * @return the process id
     */
    public Long getProcessId() {
	return processId;
    }

    /**
     * Sets the process id.
     *
     * @param processId the new process id
     */
    public void setProcessId(Long processId) {
	this.processId = processId;
    }

    /**
     * Gets the ti request id.
     *
     * @return the ti request id
     */
    public Long getTiRequestId() {
	return tiRequestId;
    }

    /**
     * Sets the ti request id.
     *
     * @param tiRequestId the new ti request id
     */
    public void setTiRequestId(Long tiRequestId) {
	this.tiRequestId = tiRequestId;
    }

    /**
     * Gets the version id.
     *
     * @return the version id
     */
    public Long getVersionId() {
	return versionId;
    }

    /**
     * Sets the version id.
     *
     * @param versionId the new version id
     */
    public void setVersionId(Long versionId) {
	this.versionId = versionId;
    }

    /**
     * Gets the aps port master.
     *
     * @return the aps port master
     */
    public AppsensePortMaster getApsPortMaster() {
	return apsPortMaster;
    }

    /**
     * Sets the aps port master.
     *
     * @param apsPortMaster the new aps port master
     */
    public void setApsPortMaster(AppsensePortMaster apsPortMaster) {
	this.apsPortMaster = apsPortMaster;
    }

    /**
     * Gets the dev access.
     *
     * @return the dev access
     */
    public String getDevAccess() {
	return devAccess;
    }

    /**
     * Sets the dev access.
     *
     * @param devAccess the new dev access
     */
    public void setDevAccess(String devAccess) {
	this.devAccess = devAccess;
    }

    /**
     * Gets the prd access.
     *
     * @return the prd access
     */
    public String getPrdAccess() {
	return prdAccess;
    }

    /**
     * Sets the prd access.
     *
     * @param prdAccess the new prd access
     */
    public void setPrdAccess(String prdAccess) {
	this.prdAccess = prdAccess;
    }

    /**
     * Gets the aps application.
     *
     * @return the aps application
     */
    public Application getApsApplication() {
	return apsApplication;
    }

    /**
     * Sets the aps application.
     *
     * @param apsApplication the new aps application
     */
    public void setApsApplication(Application apsApplication) {
	this.apsApplication = apsApplication;
    }

    /**
     * Gets the non network apps export.
     *
     * @return the non network apps export
     */
    public List getNonNetworkAppsExport() {
	return nonNetworkAppsExport;
    }

    /**
     * Sets the non network apps export.
     *
     * @param nonNetworkAppsExport the new non network apps export
     */
    public void setNonNetworkAppsExport(List nonNetworkAppsExport) {
	this.nonNetworkAppsExport = nonNetworkAppsExport;
    }

    /**
     * Gets the aps users export.
     *
     * @return the aps users export
     */
    public List getApsUsersExport() {
	return apsUsersExport;
    }

    /**
     * Sets the aps users export.
     *
     * @param apsUsersExport the new aps users export
     */
    public void setApsUsersExport(List apsUsersExport) {
	this.apsUsersExport = apsUsersExport;
    }

    /**
     * Gets the aps ports export.
     *
     * @return the aps ports export
     */
    public List getApsPortsExport() {
	return apsPortsExport;
    }

    /**
     * Sets the aps ports export.
     *
     * @param apsPortsExport the new aps ports export
     */
    public void setApsPortsExport(List apsPortsExport) {
	this.apsPortsExport = apsPortsExport;
    }		

}
