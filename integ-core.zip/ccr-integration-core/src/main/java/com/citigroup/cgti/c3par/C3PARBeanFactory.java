package com.citigroup.cgti.c3par;

/**
 * 
 */


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;

import com.citigroup.cgti.c3par.bpm.ejb.fireflow.FireflowProcess;
import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess;
import com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship;
import com.citigroup.cgti.c3par.bpm.ejb.search.ISearchProcess;
import com.citigroup.cgti.c3par.bpm.ejb.search.ISearchProxy;
import com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC;

/**
 * @author bs45969
 *
 */
public class C3PARBeanFactory {
	@Autowired
	FireflowProcess fireflowProcessImpl;
	@Autowired
	IMailModule mailModuleImpl;
	@Autowired
	IManageActivity manageActivityImpl;
	@Autowired
	IManageTIProcess manageTIProcessImpl;
	@Autowired
	ISearchRelationship searchRelationship;
	@Autowired
	ISearchProcess searchProcesses;
	//@Autowired
	//IUserAdmin userAdminImpl;
	@Autowired
	IManageRFC manageRFCImpl;
	@Autowired
	ISearchProxy proxySearch;
	/*@Autowired
	ResolveITQueueSender resolveITQueueSender;*/




	/*public static C3PARBeanFactory getInstance() {
		if (factory == null)
			factory = new C3PARBeanFactory();

		return factory;
	}*/


	/**
	 * @return the fireflowProcessImpl
	 */
	public FireflowProcess getFireflowProcessImpl() {
		return fireflowProcessImpl;
	}

	/**
	 * @return the mailModuleImpl
	 */
	public IMailModule getMailModuleImpl() {
		return mailModuleImpl;
	}

	/**
	 * @return the manageActivityImpl
	 */
	public IManageActivity getManageActivityImpl() {
		return manageActivityImpl;
	}

	/**
	 * @return the manageTIProcessImpl
	 */
	public IManageTIProcess getManageTIProcessImpl() {
		return manageTIProcessImpl;
	}

	/**
	 * @return the searchRelationship
	 */
	public ISearchRelationship getSearchRelationship() {
		return searchRelationship;
	}

	/**
	 * @return the searchProcesses
	 */
	public ISearchProcess getSearchProcesses() {
		return searchProcesses;
	}

	/**
	 * @return the userAdminImpl
	 */
	/*public IUserAdmin getUserAdminImpl() {
		return userAdminImpl;
	}*/

	/**
	 * @return the manageRFCImpl
	 */
	public IManageRFC getManageRFCImpl() {
		return manageRFCImpl;
	}


	/**
	 * @return the proxySearch
	 */
	public ISearchProxy getProxySearch() {
		return proxySearch;
	}

	/*public ResolveITQueueSender getResolveITQueueSender() {
		return resolveITQueueSender;
	}


	public void setResolveITQueueSender(ResolveITQueueSender resolveITQueueSender) {
		this.resolveITQueueSender = resolveITQueueSender;
	}*/

}
