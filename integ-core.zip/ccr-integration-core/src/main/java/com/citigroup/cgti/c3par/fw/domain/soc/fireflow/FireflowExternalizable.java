package com.citigroup.cgti.c3par.fw.domain.soc.fireflow;

import java.util.List;

import javax.servlet.http.Cookie;

import com.citi.cgti.c3par.fw.ws.domain.FireFlowMessageRequest;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.fw.domain.FafFireflowTicket;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleSuggestion;

public interface FireflowExternalizable {
	
	public String createFireflowTicket(FafFireflowTicket ticket, Cookie[] requestCookie);
	public void getFFTicketDetails(String ticketId);
	//public void parseFireflowTicketXml(FafFireflowTicket ticket, String xmlString);

	public List<FafFirewallRuleSuggestion> parseFireflowTicketXml(FireFlowMessageRequest notifMsg) throws BusinessException;
	//public void resolveFireflowTicket(FafFireflowTicket ticket);
	
	public void updateFireflowTicketStatus(FafFireflowTicket ticket,Cookie[] requestCookie);
	
	
}
