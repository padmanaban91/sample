package com.citigroup.cgti.c3par.domain.accessform;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PafAccessForm extends AccessFormXsl{
	
	private String combiType;
	
	private String recType;
	
	private String region;
	
	private String instanceName;
	
	private String port;
	
	private String busDesc; 
	
	private String intReqd;
	
	private String proxyDetails;
	
	private String url;
	
	private String statement;
	
	private String domainUrl;
	
	private String reqType;

	private String instanceDescription;


	public void setRecType(String recType) {
		this.recType = recType;
	}
	
	@XmlElement
	public String getRecType() {
		return recType;
	}

	public void setCombiType(String combiType) {
		this.combiType = combiType;
	}

	@XmlElement
	public String getCombiType() {
		return combiType;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	@XmlElement
	public String getRegion() {
		return region;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	@XmlElement
	public String getInstanceName() {
		return instanceName;
	}

	public void setPort(String port) {
		this.port = port;
	}

	@XmlElement
	public String getPort() {
		return port;
	}

	public void setBusDesc(String busDesc) {
		this.busDesc = busDesc;
	}

	@XmlElement
	public String getBusDesc() {
		return busDesc;
	}

	public void setIntReqd(String intReqd) {
		this.intReqd = intReqd;
	}

	@XmlElement
	public String getIntReqd() {
		return intReqd;
	}

	public void setProxyDetails(String proxyDetails) {
		this.proxyDetails = proxyDetails;
	}

	@XmlElement
	public String getProxyDetails() {
		return proxyDetails;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@XmlElement
	public String getUrl() {
		return url;
	}

	public void setStatement(String statement) {
		this.statement = statement;
	}

	@XmlElement
	public String getStatement() {
		return statement;
	}

	public void setDomainUrl(String domainUrl) {
		this.domainUrl = domainUrl;
	}

	@XmlElement
	public String getDomainUrl() {
		return domainUrl;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public String getReqType() {
		return reqType;
	}

	public String getInstanceDescription() {
		return instanceDescription;
	}

	public void setInstanceDescription(String instanceDescription) {
		this.instanceDescription = instanceDescription;
	}
	
	

}
