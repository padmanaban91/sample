/**
 * 
 */
package com.citigroup.cgti.c3par;

import java.util.Date;


/**
 * @author ai82302
 *
 */

public class DropReportTableLog {
	
	//holds the table name to be dropped
    private String tempTableName;
    
    //holds the created date
    private Date createdDate;
    
    //holds the current date
    private Date deletedDate;
 
    
	public void setTempTableName(String tempTableName) {
		this.tempTableName = tempTableName;
	}
	public String getTempTableName() {
		return tempTableName;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setDeletedDate(Date deletedDate) {
		this.deletedDate = deletedDate;
	}
	public Date getDeletedDate() {
		return deletedDate;
	}
    
    

}

