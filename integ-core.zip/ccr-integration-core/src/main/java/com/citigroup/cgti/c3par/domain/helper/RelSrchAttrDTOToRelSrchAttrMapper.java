package com.citigroup.cgti.c3par.domain.helper;

import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipSearchAttributesDTO;
import com.citigroup.cgti.c3par.dashboard.webtier.helper.RelationshipSearchAttributes;


/**
 * The Class RelSrchAttrDTOToRelSrchAttrMapper.
 */
public class RelSrchAttrDTOToRelSrchAttrMapper {

    /**
     * Transform to rel search attributes.
     *
     * @param relSrchAttrDTO the rel srch attr dto
     * @param relSrchAttr the rel srch attr
     */
    public static void transformToRelSearchAttributes(RelationshipSearchAttributesDTO relSrchAttrDTO, RelationshipSearchAttributes relSrchAttr) {
	relSrchAttr.setAccessCitiData(relSrchAttrDTO.getAccessCitiData());
	relSrchAttr.setAccessCustomerData(relSrchAttrDTO.getAccessCustomerData());
	relSrchAttr.setBusinessUnitId(relSrchAttrDTO.getBusinessUnitId());
	relSrchAttr.setBusinessUnitName(relSrchAttrDTO.getBusinessUnitName());
	relSrchAttr.setConnectivityExists(relSrchAttrDTO.getConnectivityExists());
	relSrchAttr.setDataClassification(relSrchAttrDTO.getDataClassification());
	relSrchAttr.setEntInstList(relSrchAttrDTO.getEntInstList());
	relSrchAttr.setOspServiceName(relSrchAttrDTO.getOspServiceName());
	relSrchAttr.setOspServiceProvided(relSrchAttrDTO.getOspServiceProvided());
	relSrchAttr.setParticipantId(relSrchAttrDTO.getParticipantId());
	relSrchAttr.setProcessType(relSrchAttrDTO.getProcessType());
	relSrchAttr.setRelationshipId(relSrchAttrDTO.getRelationshipId());
	relSrchAttr.setRelationshipName(relSrchAttrDTO.getRelationshipName());
	relSrchAttr.setRelationshipType(relSrchAttrDTO.getRelationshipType());
	relSrchAttr.setRequesterBusinessUnitId(relSrchAttrDTO.getRequesterBusinessUnitId());
	relSrchAttr.setRequesterBusinessUnitName(relSrchAttrDTO.getRequesterBusinessUnitName());
	relSrchAttr.setRequesterResourceTypeId(relSrchAttrDTO.getRequesterResourceTypeId());
	relSrchAttr.setSomeConditionSet(relSrchAttrDTO.isSomeConditionSet());
	relSrchAttr.setSsoId(relSrchAttrDTO.getSsoId());
	relSrchAttr.setStatus(relSrchAttrDTO.getStatus());
	relSrchAttr.setTargetResourceTypeId(relSrchAttrDTO.getTargetResourceTypeId());
	relSrchAttr.setThirdPartyId(relSrchAttrDTO.getThirdPartyId());
	relSrchAttr.setThirdPartyName(relSrchAttrDTO.getThirdPartyName());
	relSrchAttr.setUserId(relSrchAttrDTO.getUserId());
    }
}
