/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.ArrayList;
import java.util.List;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * The Class 
 *
 * @author bs45969
 */
public class FirewallPolicy extends Base {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The name. */
	private String name;

	/** The fw type. */
	private String fwType;

	/** groupId  **/
	private FireWallPolicyGroup fireWallPolicyGroup;

	/** **/
	private FirewallRegion firewallRegion;

	/**
	 *
	 */
	private String isZoned;

	/** The firewalls. */
	private List<Firewall> firewalls;
	
    /** The delete flag. */
    private String deleteFlag;
    
    

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the fw type.
	 *
	 * @return the fw type
	 */
	public String getFwType() {
		return fwType;
	}

	/**
	 * Sets the fw type.
	 *
	 * @param fwType the new fw type
	 */
	public void setFwType(String fwType) {
		this.fwType = fwType;
	}

	/**
	 * @return the fireWallPolicyGroup
	 */
	public FireWallPolicyGroup getFireWallPolicyGroup() {
		return fireWallPolicyGroup;
	}

	/**
	 * @param fireWallPolicyGroup the fireWallPolicyGroup to set
	 */
	public void setFireWallPolicyGroup(FireWallPolicyGroup fireWallPolicyGroup) {
		this.fireWallPolicyGroup = fireWallPolicyGroup;
	}

	/**
	 * @return the firewallRegion
	 */
	public FirewallRegion getFirewallRegion() {
		return firewallRegion;
	}

	/**
	 * @param firewallRegion the firewallRegion to set
	 */
	public void setFirewallRegion(FirewallRegion firewallRegion) {
		this.firewallRegion = firewallRegion;
	}

	/**
	 * @return the isZoned
	 */
	public String getIsZoned() {
		return isZoned;
	}

	/**
	 * @param isZoned the isZoned to set
	 */
	public void setIsZoned(String isZoned) {
		this.isZoned = isZoned;
	}

	/**
	 * Gets the firewalls.
	 * 
	 * @return the firewalls
	 */
	public List<Firewall> getFirewalls() {
		
		return firewalls;
	}

	/**
	 * Sets the firewalls.
	 *
	 * @param firewalls the new firewalls
	 */
	public void setFirewalls(List<Firewall> firewalls) {
		this.firewalls = firewalls;
	}
	@Override
	public String toString() {
		List<Firewall> filteredFirewalls=new ArrayList<Firewall>();
		List<Firewall> originalFirewalls=getFirewalls();
		//Exclude deleted firewalls
		if(originalFirewalls!=null && !originalFirewalls.isEmpty()){
			for(Firewall firewall:originalFirewalls){
				if("Y".equalsIgnoreCase(firewall.getDeleteFlag())){
					filteredFirewalls.add(firewall);
				}
			}
		}
		if((originalFirewalls!=null && !originalFirewalls.isEmpty()) && (filteredFirewalls!=null && !filteredFirewalls.isEmpty())){
			originalFirewalls.removeAll(filteredFirewalls);
		}
		if(originalFirewalls==null || originalFirewalls.isEmpty()){
			return getName();
		}else{
			return getName()+" "+originalFirewalls.toString();
		}
		
	}

}