package com.citigroup.cgti.c3par.admin.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.ISOContacts;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class ManageISOContactProcess {

    CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
    //properties used for pagination
    private int rowCount;
    private int offset;
    private int limit;
    private int pageNo;
    private int totalPages;
    private boolean paginationRequired;
    private String pageType;
    
	private String soeID;
	private List<ISOContacts> isoContactList;
	
	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public boolean isPaginationRequired() {
		return paginationRequired;
	}

	public void setPaginationRequired(boolean paginationRequired) {
		this.paginationRequired = paginationRequired;
	}

	public String getPageType() {
		return pageType;
	}

	public void setPageType(String pageType) {
		this.pageType = pageType;
	}

	public String getSoeID() {
		return soeID;
	}

	public void setSoeID(String soeID) {
		this.soeID = soeID;
	}

	public List<ISOContacts> getIsoContactList() { 
		return isoContactList;
	}

	public void setIsoContactList(List<ISOContacts> isoContactList) {
		this.isoContactList = isoContactList;
	}

	//To retrieve getDoNotSendEmailList
	
	public List<ISOContacts> getManageISOContactList() {
		return ccrBeanFactory.getAdminServicePersistable().getManageISOContactList(this);
	}
	
	//To save DoNotSendEmailList
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void saveManageISOContactList(String soeId) {
		ccrBeanFactory.getAdminServicePersistable().saveManageISOContactList(soeId);
	}

	//To delete DoNotSendEmailList
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteManageISOContactList(List<String> soeIdlist) {
		ccrBeanFactory.getAdminServicePersistable().deleteManageISOContactList(soeIdlist);
	}
	
}
