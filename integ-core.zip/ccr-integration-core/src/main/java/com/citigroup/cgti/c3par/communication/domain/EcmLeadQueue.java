package com.citigroup.cgti.c3par.communication.domain;

import com.citigroup.cgti.c3par.domain.Base;

public class EcmLeadQueue extends Base {
	
	private String agentName;
	
	private Long inQueue;
	
	private Long isBAU;
	
	private Long isBusCrit;
	
	private Long isAssitance;
	
	private Long assignedThisWeek;
	
	private Long totalInQueue;
	
	private String agentID;
	
	private String isLocked;
	
	private String role;
	
	private String comments;
	
	private String sector;
	
	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public Long getInQueue() {
		return inQueue;
	}

	public void setInQueue(Long inQueue) {
		this.inQueue = inQueue;
	}

	public Long getIsBAU() {
		return isBAU;
	}

	public void setIsBAU(Long isBAU) {
		this.isBAU = isBAU;
	}

	public Long getIsBusCrit() {
		return isBusCrit;
	}

	public void setIsBusCrit(Long isBusCrit) {
		this.isBusCrit = isBusCrit;
	}

	public Long getIsAssitance() {
		return isAssitance;
	}

	public void setIsAssitance(Long isAssitance) {
		this.isAssitance = isAssitance;
	}

	public Long getAssignedThisWeek() {
		return assignedThisWeek;
	}

	public void setAssignedThisWeek(Long assignedThisWeek) {
		this.assignedThisWeek = assignedThisWeek;
	}

	public Long getTotalInQueue() {
		return totalInQueue;
	}

	public void setTotalInQueue(Long totalInQueue) {
		this.totalInQueue = totalInQueue;
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public String getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(String isLocked) {
		this.isLocked = isLocked;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}


}
