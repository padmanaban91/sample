/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author bs45969
 *
 */
public class FirewallRuleOstiaAnswer extends Base {
	private TIRequest updatedTIRequest;	
	private TIRequest deletedTIRequest;
	private String answer;
	private String otherText;
	private FirewallRuleOstiaQuestion firewallRuleOstiaQuestion;
	/**
	 * @return the firewallRuleOstiaQuestion
	 */
	public FirewallRuleOstiaQuestion getFirewallRuleOstiaQuestion() {
		return firewallRuleOstiaQuestion;
	}
	/**
	 * @param firewallRuleOstiaQuestion the firewallRuleOstiaQuestion to set
	 */
	public void setFirewallRuleOstiaQuestion(
			FirewallRuleOstiaQuestion firewallRuleOstiaQuestion) {
		this.firewallRuleOstiaQuestion = firewallRuleOstiaQuestion;
	}
	/**
	 * @return the updatedTIRequest
	 */
	public TIRequest getUpdatedTIRequest() {
		return updatedTIRequest;
	}
	/**
	 * @param updatedTIRequest the updatedTIRequest to set
	 */
	public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
		this.updatedTIRequest = updatedTIRequest;
	}
	/**
	 * @return the deletedTIRequest
	 */
	public TIRequest getDeletedTIRequest() {
		return deletedTIRequest;
	}
	/**
	 * @param deletedTIRequest the deletedTIRequest to set
	 */
	public void setDeletedTIRequest(TIRequest deletedTIRequest) {
		this.deletedTIRequest = deletedTIRequest;
	}
	/**
	 * @return the answer
	 */
	public String getAnswer() {
		return answer;
	}
	/**
	 * @param answer the answer to set
	 */
	public void setAnswer(String answer) {
		this.answer = answer;
	}
 /*   @Override
    public boolean equals(Object obj){
        if(obj == null) return false;
        if(!(obj instanceof FirewallRuleOstiaAnswer)) return false;

        FirewallRuleOstiaAnswer other = (FirewallRuleOstiaAnswer) obj;
        if(this.answer.equalsIgnoreCase(other.answer))   return false;      

        return true;
      }

    @Override
    public int hashCode(){
        return (int) (31 * this.answer.length()) ;
      }*/
	/**
	 * @return the otherText
	 */
	public String getOtherText() {
		return otherText;
	}
	/**
	 * @param otherText the otherText to set
	 */
	public void setOtherText(String otherText) {
		this.otherText = otherText;
	}


}
