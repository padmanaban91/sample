package com.citigroup.cgti.c3par.cache;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.ScenarioNames;
//import com.citigroup.cgti.c3par.dao.EntitlementXrefDAO;
import com.citigroup.cgti.c3par.dao.RelationshipDAO;
//import com.citigroup.cgti.c3par.dao.lookup.ContainerGroupsLookup;
import com.citigroup.cgti.c3par.dashboard.webtier.helper.CommonCode;
import com.citigroup.cgti.c3par.dashboard.webtier.helper.RelationshipSearchAttributes;
import com.citigroup.cgti.c3par.dashboard.webtier.helper.SearchRelationship;
//import com.citigroup.cgti.c3par.model.ContainerGroupsEntity;
//import com.citigroup.cgti.c3par.model.EntitlementXrefEntity;
import com.citigroup.cgti.c3par.model.RelationshipEntity;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.webtier.helper.LookupsManager;
import com.mentisys.dao.DatabaseException;
import org.apache.log4j.Logger;


/**
 * The Class CacheRelationship.
 */
public class CacheRelationship {
    /*
     * static { LookupsManager.resetC3parUserLookup(new C3parSession()); }
     */

    /** The owner relationship. */
    private Map ownerRelationship = Collections.synchronizedMap(new HashMap());

    /** The cache relationship. */
    private static CacheRelationship cacheRelationship;

    /** The log. */
    private static Logger log = Logger.getLogger(CacheRelationship.class);

    /** The loaded. */
    private boolean loaded = false;

    /** The c3par session. */
    private C3parSession c3parSession;

    /**
     * Instantiates a new cache relationship.
     *
     * @param c3parSession the c3par session
     */
    private CacheRelationship(C3parSession c3parSession) {
	this.c3parSession = c3parSession;

    }

    /**
     * Gets the single instance of CacheRelationship.
     *
     * @return single instance of CacheRelationship
     */
    public static CacheRelationship getInstance() {
	if (cacheRelationship == null)
	    cacheRelationship = new CacheRelationship(null);

	return cacheRelationship;
    }

    /**
     * Gets the single instance of CacheRelationship.
     *
     * @param c3parSession the c3par session
     * @return single instance of CacheRelationship
     */
    protected static CacheRelationship getInstance(C3parSession c3parSession) {
	if (cacheRelationship == null)
	    cacheRelationship = new CacheRelationship(c3parSession);

	return cacheRelationship;
    }

    /**
     * Load all.
     *
     * @throws DatabaseException the database exception
     */
    public synchronized void loadAll() throws DatabaseException {
	if (c3parSession == null)
	    c3parSession = new C3parSession();
	SearchRelationship search = new SearchRelationship(c3parSession);
	/*List list = search.runQuery(new RelationshipSearchAttributes(), null,
				null);*/
	List list = null;
	Iterator it = list.iterator();
	// ENTITLEMENT CHANGE
	// ContainerGroupsLookup groupLookup =
	// ContainerGroupsLookup.getInstance();
	while (it.hasNext()) {
	    RelationshipEntity entity = (RelationshipEntity) it.next();
	    /*
	     * Long ownedById = entity.getOwnedbyId(); EntitlementXrefDAO
	     * entitlementDAO = new EntitlementXrefDAO(c3parSession);
	     * EntitlementXrefEntity entitlementEntity =
	     * entitlementDAO.get(ownedById);
	     * 
	     * ContainerGroupsEntity groupEntity =
	     * groupLookup.getById(entitlementEntity.getGroupId());
	     */
	    log.info("Relationship id " + entity.getId());
	    /*Map relationshipList = (Map) ownerRelationship.get(entity
		    .getEntInstanceId().toString());
	    if (relationshipList == null)
		relationshipList = new HashMap();
	    relationshipList.put(entity.getId().toString(), entity);
	    ownerRelationship.put(entity.getEntInstanceId().toString(),
		    relationshipList);*/
	}
	/*
	 * Set se=ownerRelationship.keySet(); Iterator itr=se.iterator();
	 * 
	 * while(itr.hasNext()) { List entLists=new ArrayList(); String
	 * instid=(String)itr.next(); // Map
	 * map=(Map)ownerRelationship.get(instid);
	 * //entLists.addAll(map.values()); Set key=map.keySet(); Iterator
	 * keyitr=key.iterator(); while(keyitr.hasNext()) {
	 *  }
	 *  }
	 */

	loaded = true;
    }

    // done
    /**
     * Gets the relationship.
     *
     * @param entInstList the ent inst list
     * @param session the session
     * @param pageNum the page num
     * @param pageSize the page size
     * @return the relationship
     * @throws DatabaseException the database exception
     */
    public List getRelationship(List entInstList, HttpSession session,int pageNum,int pageSize)
    throws DatabaseException {

	boolean isAdmin = CommonCode.isAdmin(session);
	List actualList = new ArrayList();
	if (c3parSession == null)
	    c3parSession = new C3parSession();

	RelationshipSearchAttributes searchFilters = new RelationshipSearchAttributes();
	if (!isAdmin) {
	    searchFilters.setEntInstList(entInstList);
	}
	SearchRelationship search = new SearchRelationship(c3parSession,searchFilters);
	actualList = search.runQuery(pageNum,pageSize);
	return actualList;
    }


    // changed from groupname to entInstid
    /**
     * Gets the filtered relationship.
     *
     * @param filter the filter
     * @param entInstList the ent inst list
     * @param session the session
     * @return the filtered relationship
     * @throws DatabaseException the database exception
     */
    public List getFilteredRelationship(String filter, List entInstList,
	    HttpSession session) throws DatabaseException {
	if (!loaded)
	    loadAll();

	boolean isAdmin = CommonCode.isAdmin(session);
	// get relationships for user entitlements at one go
	List actualList = new ArrayList();
	if (!isAdmin) {
	    Iterator itr = entInstList.iterator();
	    while (itr.hasNext()) {
		Map map = (Map) ownerRelationship.get((itr.next()).toString());
		if (map != null)
		    actualList.addAll(map.values());
	    }
	} else {
	    // get all the list
	    Set set = ownerRelationship.keySet();
	    Iterator it = set.iterator();
	    while (it.hasNext()) {
		String key = (String) it.next();
		Map map = (Map) ownerRelationship.get(key);
		actualList.addAll(map.values());
	    }
	}
	Collections.sort(actualList, new RelationshipComparator());

	List returnedList = new ArrayList();
	Iterator it = actualList.iterator();
	while (it.hasNext()) {
	    RelationshipEntity entity = (RelationshipEntity) it.next();
	    if (entity.getName().toLowerCase().trim().indexOf(
		    filter.toLowerCase().trim()) > -1)
		returnedList.add(entity);
	}
	return returnedList;
    }

    /**
     * Gets the filtered relationship by process.
     *
     * @param filter the filter
     * @param entInstList the ent inst list
     * @param session the session
     * @param status the status
     * @return the filtered relationship by process
     * @throws DatabaseException the database exception
     */
    public List getFilteredRelationshipByProcess(String filter,
	    List entInstList, HttpSession session, String status)
    throws DatabaseException {
	if (!loaded)
	    loadAll();

	boolean isAdmin = CommonCode.isAdmin(session);
	if ((status == null) || ("null".equalsIgnoreCase(status)))
	    status = "";
	// get relationships for user entitlements at one go
	List actualList = new ArrayList();
	if (!isAdmin) {
	    Iterator itr = entInstList.iterator();
	    while (itr.hasNext()) {
		Map map = (Map) ownerRelationship.get((itr.next()).toString());
		if (map != null)
		    actualList.addAll(map.values());
	    }
	} else {
	    // get all the list
	    Set set = ownerRelationship.keySet();
	    Iterator it = set.iterator();
	    while (it.hasNext()) {
		String key = (String) it.next();
		Map map = (Map) ownerRelationship.get(key);
		actualList.addAll(map.values());
	    }
	}
	Collections.sort(actualList, new RelationshipComparator());

	String processType = (String) session.getAttribute("PROCESS_TYPE");
	if (processType == null || "null".equalsIgnoreCase(processType)) {
	    processType = "";
	}

	List returnedList = new ArrayList();
	Iterator it = actualList.iterator();
	while (it.hasNext()) {
	    RelationshipEntity entity = (RelationshipEntity) it.next();
	    if (processType.length() > 0) {
		if (ScenarioNames.PROCESS_TYPE_CONNECTION
			.equalsIgnoreCase(processType)) {
		    if ((entity.getRelationshipType() == null)
			    || C3parStaticNames.THIRD_PARTY
			    .equalsIgnoreCase(entity
				    .getRelationshipType())
				    || C3parStaticNames.CITI_CON
				    .equalsIgnoreCase(entity
					    .getRelationshipType())) {
			if ("".equalsIgnoreCase(status)) {
			    returnedList.add(entity);
			} else {
			    if (status.equalsIgnoreCase(entity.getStatus())) {
				returnedList.add(entity);
			    }
			}
		    }
		} else {
		    if ((entity.getRelationshipType() == null)
			    || C3parStaticNames.THIRD_PARTY
			    .equalsIgnoreCase(entity
				    .getRelationshipType())
				    || C3parStaticNames.CITI_IP.equalsIgnoreCase(entity
					    .getRelationshipType())) {
			if ("".equalsIgnoreCase(status)) {
			    returnedList.add(entity);
			} else {
			    if (status.equalsIgnoreCase(entity.getStatus())) {
				returnedList.add(entity);
			    }
			}
		    }
		}
	    }
	    // if(entity.getName().toLowerCase().trim().indexOf(filter.toLowerCase().trim())
	    // > -1)
	    // returnedList.add(entity);
	}
	return returnedList;
    }

    /**
     * Adds the.
     *
     * @param entity the entity
     * @param entInstID the ent inst id
     */
    public synchronized void add(RelationshipEntity entity, String entInstID) {
	Map relationshipList = (Map) ownerRelationship.get(entInstID);
	if (relationshipList == null)
	    relationshipList = new HashMap();

	relationshipList.put(entity.getId().toString(), entity);
	ownerRelationship.put(entInstID, relationshipList);
    }

    /**
     * Removes the.
     *
     * @param entity the entity
     * @param entInstID the ent inst id
     */
    public synchronized void remove(RelationshipEntity entity, String entInstID) {
	delete(entity.getId().toString(), entInstID);
    }

    /**
     * Update.
     *
     * @param entity the entity
     * @param entInstId the ent inst id
     */
    public synchronized void update(RelationshipEntity entity, String entInstId) {
	Map relationshipList = (Map) ownerRelationship.get(entInstId.trim());
	if (relationshipList == null)
	    return;

	relationshipList.put(entity.getId().toString(), entity);
    }

    /**
     * Invalidate cache.
     *
     * @param id the id
     * @param action the action
     * @param entInstId the ent inst id
     */
    public synchronized void invalidateCache(String id, String action,
	    String entInstId) {
	if (action.equals("insert")) {
	    if (c3parSession == null)
		c3parSession = new C3parSession();
	    RelationshipDAO dao = new RelationshipDAO(c3parSession);
	    try {
		Long entityId = Long.valueOf(id.trim());
		RelationshipEntity entity = dao.get(entityId);
		if (entity != null) {
		    Map relationshipList = (Map) ownerRelationship
		    .get(entInstId.trim());
		    if (relationshipList == null)
			relationshipList = new HashMap();
		    relationshipList.put(entity.getId().toString(), entity);
		    ownerRelationship.put(entInstId.trim(), relationshipList);
		}
	    } catch (Exception ex) {
		log.error(ex);
		// if any exception occurs then invalidate the cache and reload
		// the whole relationship
		try {
		    loadAll();
		} catch (DatabaseException de) {
		    loaded = false;
		}
	    }
	} else if (action.equalsIgnoreCase("update")) {
	    try {
		RelationshipEntity entity = load(Long.valueOf(id));
		update(entity, entInstId);
	    } catch (DatabaseException ex) {
		log.error(ex);
		// if any exception occurs then invalidate the cache and reload
		// the whole relationship
		try {
		    loadAll();
		} catch (DatabaseException de) {
		    loaded = false;
		}
	    }
	} else if (action.equalsIgnoreCase("delete")) {
	    delete(id, entInstId);
	}
    }

    /**
     * Reset.
     */
    public void reset() {
	loaded = false;
    }

    /**
     * Delete.
     *
     * @param id the id
     * @param entInstID the ent inst id
     */
    private void delete(String id, String entInstID) {
	Map relationshipList = (Map) ownerRelationship.get(entInstID.trim());
	if (relationshipList == null)
	    return;

	relationshipList.remove(id);
	ownerRelationship.put(entInstID, relationshipList);
    }

    /**
     * Load.
     *
     * @param id the id
     * @return the relationship entity
     * @throws DatabaseException the database exception
     */
    public RelationshipEntity load(Long id) throws DatabaseException {
	if (c3parSession == null)
	    c3parSession = new C3parSession();
	RelationshipDAO dao = new RelationshipDAO(c3parSession);
	return dao.get(id);
    }

    /**
     * The Class RelationshipComparator.
     */
    public class RelationshipComparator implements Comparator {

	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(T, T)
	 */
	public int compare(Object object1, Object object2) {
	    RelationshipEntity entity1 = (RelationshipEntity) object1;
	    RelationshipEntity entity2 = (RelationshipEntity) object2;

	    return entity1.getName().compareToIgnoreCase(entity2.getName());
	}
    }
}