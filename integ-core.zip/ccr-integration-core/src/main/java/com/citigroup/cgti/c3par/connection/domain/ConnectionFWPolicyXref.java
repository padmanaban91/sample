package com.citigroup.cgti.c3par.connection.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionFWPolicyXref.
 */
public class ConnectionFWPolicyXref extends PerformerPagerDO {



    /** The firewall policy master. */
    private ConnectionFWPolicyMaster firewallPolicyMaster= new ConnectionFWPolicyMaster();

    /** The firewall type. */
    private String firewallType;

    /** The primary flag. */
    private String primaryFlag;

    /** The acl variance. */
    private String aclVariance;

    /** The bandwidth id. */
    private Long bandwidthId;

    /** The circuit id. */
    private String circuitId;

    /** The created date. */
    private Date createdDate;

    /** The updated date. */
    private Date updatedDate;

    /** The router id. */
    private String routerId;

    /** The location. */
    private String location = new String();

    /** The ti request id. */
    private Long tiRequestId ;//Added for 4619

    /** The division code. */
    private Long divisionCode ;


    /**
     * Gets the division code.
     *
     * @return the division code
     */
    public Long getDivisionCode() {
	return divisionCode;
    }


    /**
     * Sets the division code.
     *
     * @param divisionCode the new division code
     */
    public void setDivisionCode(Long divisionCode) {
	this.divisionCode = divisionCode;
    }


    /**
     * Instantiates a new connection fw policy xref.
     */
    public ConnectionFWPolicyXref() {
	setTableName(PerformerTypes.CON_FW_POLICY_XREF);
	setSequenceName(PerformerTypes.CON_FW_POLICY_XREF_SEQ);
	// ----------
	addToDBMapping("firewallPolicyMaster", "FIREWALL_POLICY_ID",1);
	addToDBMapping("firewallType", "FIREWALL_TYPE",2);
	addToDBMapping("primaryFlag", "PRIMARY_FLAG",3);
	addToDBMapping("aclVariance", "ACL_VARIANCE",4);
	addToDBMapping("bandwidthId", "BANDWIDTH_ID",5);
	addToDBMapping("circuitId", "CIRCUIT_ID",6);
	addToDBMapping("createdDate", "CREATED_DATE",7);
	addToDBMapping("updatedDate", "UPDATED_DATE",8);
	addToDBMapping("routerId", "ROUTER_ID",9);
	addToDBMapping("tiRequestId", "TI_REQUEST_ID",10);//Added for 4619
	addToDBMapping("divisionCode", "division_code",12);
	// --------
	addToNonCompositionList("firewallPolicyMaster");
	addToParentsMap("com.citigroup.cgti.c3par.connection.domain.ConnectionProcess" , "CONNECTION_REQUEST_ID");

    }


    /**
     * Gets the ti request id.
     *
     * @return the ti request id
     */
    public Long getTiRequestId() {
	return tiRequestId;
    }


    /**
     * Sets the ti request id.
     *
     * @param tiRequestId the new ti request id
     */
    public void setTiRequestId(Long tiRequestId) {
	this.tiRequestId = tiRequestId;
    }


    /**
     * Gets the acl variance.
     *
     * @return the acl variance
     */
    public String getAclVariance() {
	return aclVariance;
    }


    /**
     * Sets the acl variance.
     *
     * @param aclVariance the new acl variance
     */
    public void setAclVariance(String aclVariance) {
	this.aclVariance = aclVariance;
    }


    /**
     * Gets the bandwidth id.
     *
     * @return the bandwidth id
     */
    public Long getBandwidthId() {
	return bandwidthId;
    }


    /**
     * Sets the bandwidth id.
     *
     * @param bandwidthId the new bandwidth id
     */
    public void setBandwidthId(Long bandwidthId) {
	this.bandwidthId = bandwidthId;
    }


    /**
     * Gets the circuit id.
     *
     * @return the circuit id
     */
    public String getCircuitId() {
	return circuitId;
    }


    /**
     * Sets the circuit id.
     *
     * @param circuitId the new circuit id
     */
    public void setCircuitId(String circuitId) {
	this.circuitId = circuitId;
    }


    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public Date getCreatedDate() {
	return createdDate;
    }


    /**
     * Sets the created date.
     *
     * @param createdDate the new created date
     */
    public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
    }


    /**
     * Gets the firewall policy master.
     *
     * @return the firewall policy master
     */
    public ConnectionFWPolicyMaster getFirewallPolicyMaster() {
	return firewallPolicyMaster;
    }


    /**
     * Sets the firewall policy master.
     *
     * @param firewallPolicyMaster the new firewall policy master
     */
    public void setFirewallPolicyMaster(
	    ConnectionFWPolicyMaster firewallPolicyMaster) {
	this.firewallPolicyMaster = firewallPolicyMaster;
    }


    /**
     * Gets the firewall type.
     *
     * @return the firewall type
     */
    public String getFirewallType() {
	return firewallType;
    }


    /**
     * Sets the firewall type.
     *
     * @param firewallType the new firewall type
     */
    public void setFirewallType(String firewallType) {
	this.firewallType = firewallType;
    }


    /**
     * Gets the primary flag.
     *
     * @return the primary flag
     */
    public String getPrimaryFlag() {
	return primaryFlag;
    }


    /**
     * Sets the primary flag.
     *
     * @param primaryFlag the new primary flag
     */
    public void setPrimaryFlag(String primaryFlag) {
	this.primaryFlag = primaryFlag;
    }


    /**
     * Gets the updated date.
     *
     * @return the updated date
     */
    public Date getUpdatedDate() {
	return updatedDate;
    }


    /**
     * Sets the updated date.
     *
     * @param updatedDate the new updated date
     */
    public void setUpdatedDate(Date updatedDate) {
	this.updatedDate = updatedDate;
    }


    /**
     * Gets the location.
     *
     * @return the location
     */
    public String getLocation() {
	return location;
    }


    /**
     * Sets the location.
     *
     * @param location the location to set
     */
    public void setLocation(String location) {
	this.location = location;
    }


    /**
     * Constructs a <code>String</code> with all attributes
     * in name = value format.
     *
     * @return a <code>String</code> representation 
     * of this object.
     */
    public String toString()
    {
	final String TAB = "    ";

	StringBuffer retValue = new StringBuffer();

	retValue.append("ConnectionFWPolicyXref ( ")
	.append(super.toString()).append(TAB)
	.append("aclVariance = ").append(this.aclVariance).append(TAB)
	.append("bandwidthId = ").append(this.bandwidthId).append(TAB)
	.append("circuitId = ").append(this.circuitId).append(TAB)
	.append("createdDate = ").append(this.createdDate).append(TAB)
	.append("firewallPolicyMaster = ").append(this.firewallPolicyMaster).append(TAB)
	.append("firewallType = ").append(this.firewallType).append(TAB)
	.append("location = ").append(this.location).append(TAB)
	.append("primaryFlag = ").append(this.primaryFlag).append(TAB)
	.append("updatedDate = ").append(this.updatedDate).append(TAB)
	.append(" )");

	return retValue.toString();
    }


    /**
     * Gets the router id.
     *
     * @return the routerId
     */
    public String getRouterId() {
	return routerId;
    }


    /**
     * Sets the router id.
     *
     * @param routerId the routerId to set
     */
    public void setRouterId(String routerId) {
	this.routerId = routerId;
    }


}
