package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlType;

import com.citigroup.cgti.c3par.C3parPerformerKeyGenerator;
import com.citigroup.cgti.c3par.dao.ResourceTypeDAO;
import com.citigroup.cgti.c3par.dao.TIApplicationDAO;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ResourceType.
 */
@XmlType(name="ResourceTypeEntity")
public class ResourceType  extends PerformerPagerDO implements Serializable{

    /** The perimeter. */
    private String perimeter;

    /** The status. */
    private String status;

    /** The created by. */
    private String createdBy;

    /** The created by name. */
    private String createdByName;

    /** The created date. */
    private Date createdDate;

    /** The modified by. */
    private String modifiedBy;

    /** The modified date. */
    private Date modifiedDate;

    /** The selected. */
    private boolean selected;

    /** The resource type name. */
    private String resourceTypeName;

    /** The resource type id. */
    private Long resourceTypeId;


    /**
     * Gets the resource type id.
     *
     * @return the resource type id
     */
    public Long getResourceTypeId() {
	return resourceTypeId;
    }

    /**
     * Sets the resource type id.
     *
     * @param resourceTypeId the new resource type id
     */
    public void setResourceTypeId(Long resourceTypeId) {
	this.resourceTypeId = resourceTypeId;
    }

    /**
     * Instantiates a new resource type.
     */
    public ResourceType() {
	//		----------
	setTableName(PerformerTypes.RESOURCE_TYPE);
	setSequenceName(new C3parPerformerKeyGenerator(ResourceTypeDAO.ENTITY_NAME));
	//----------
	//		addToDBMapping("id","ID",1);
	addToDBMapping("resourceTypeName","NAME",1);
	addToDBMapping("perimeter","PERIMETER",2);
	addToDBMapping("status","STATUS",3);
	addToDBMapping("createdBy","CREATED_BY",4);
	addToNonPersistanceList("createdDate");
	addToDBMapping("modifiedBy","MODIFIED_BY",5);
	addToNonPersistanceList("modifiedDate");

	addToNonPersistanceList("createdByName");
	addToNonPersistanceList("resourceTypeId");
	addToNonPersistanceList("selected");
    }

    /**
     * Gets the created by.
     *
     * @return the created by
     */
    public String getCreatedBy() {
	return createdBy;
    }

    /**
     * Sets the created by.
     *
     * @param createdBy the new created by
     */
    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public Date getCreatedDate() {
	return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate the new created date
     */
    public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
    }

    /**
     * Gets the modified by.
     *
     * @return the modified by
     */
    public String getModifiedBy() {
	return modifiedBy;
    }

    /**
     * Sets the modified by.
     *
     * @param modifiedBy the new modified by
     */
    public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
    }

    /**
     * Gets the modified date.
     *
     * @return the modified date
     */
    public Date getModifiedDate() {
	return modifiedDate;
    }

    /**
     * Sets the modified date.
     *
     * @param modifiedDate the new modified date
     */
    public void setModifiedDate(Date modifiedDate) {
	this.modifiedDate = modifiedDate;
    }

    /**
     * Gets the perimeter.
     *
     * @return the perimeter
     */
    public String getPerimeter() {
	return perimeter;
    }

    /**
     * Sets the perimeter.
     *
     * @param perimeter the new perimeter
     */
    public void setPerimeter(String perimeter) {
	this.perimeter = perimeter;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
	this.status = status;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#isSelected()
     */
    public boolean isSelected() {
	return selected;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#setSelected(boolean)
     */
    public void setSelected(boolean selected) {
	this.selected = selected;
    }

    /**
     * Gets the created by name.
     *
     * @return the created by name
     */
    public String getCreatedByName() {
	return createdByName;
    }

    /**
     * Sets the created by name.
     *
     * @param createdByName the new created by name
     */
    public void setCreatedByName(String createdByName) {
	this.createdByName = createdByName;
    }

    /**
     * Gets the resource type name.
     *
     * @return the resource type name
     */
    public String getResourceTypeName() {
	return resourceTypeName;
    }

    /**
     * Sets the resource type name.
     *
     * @param resourceTypeName the new resource type name
     */
    public void setResourceTypeName(String resourceTypeName) {
	this.resourceTypeName = resourceTypeName;
    }
}
