/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citi.cgti.c3par.fw.ws.domain.FireFlowMessageRequest;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.soc.fireflow.FireflowExternalizable;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author bs45969
 * 
 */
public class FafFireflowTicket extends Base {
	
	   CCRBeanFactory ccrBeanFactory;
		{
			ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
			if(appContext!=null && appContext.containsBean("cCRBeanFactory")) {
				ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
			}else{
				System.out.println("appContext is null");
			}
			
		}

	
	Logger log = Logger.getLogger(FafFireflowTicket.class);
	/**
	 *
	 */
	public static final String NOT_POSTED = "NOT_POSTED";
	public static final String CREATED = "CREATED";
	public static final String CANCELLED = "CANCELLED";
	public static final String DELETED = "DELETED";
	public static final String NEW = "NEW_TICK";
	public static final String OPEN = "OPEN_TICK";
	public static final String CHECK = "APP_TICK";
	public static final String APPROVE = "CHECK_DONE";
	public static final String PLAN = "APP_DONE";
	public static final String IMPLEMENT = "WO_GNR";
	public static final String LCK_TICK = "LCK_TICK";
	public static final String LCK_TICK_FAILED = "LCK_TICK_FAILED";
	public static final String VALIDATE = "VAL_TICK";
	public static final String UAT_ACC_PENDING = "UAT_ACC_PENDING";
	public static final String UAT_ACC_OK = "UAT_ACC_OK";
	public static final String UAT_ACC_NOK = "UAT_ACC_NOK";
	public static final String REQ_RES = "REQ_RES";
	public static final String PENDING_MATCH = "PENDING_MATCH";
	public static final String MATCHED = "MATCHED";
	public static final String PEN_CMA_INS = "PEN_CMA_INS";
	public static final String REJRCTED = "REJRCTED";
	public static final String REJECTED = "rejected";
	public static final String RESOLVED = "resolved";

	private static final long serialVersionUID = 1L;
	private TIRequest tiRequest;
	private FireWallPolicyGroup policyGroup;
	private String ticketNumber;
	private List<FafFirewallRule> fafFireWallRules;
	private char type;
	private char createType;// can remove 
	private String status;
	private String ipReg;
	// transient property used to transfer connection info to ticket type
	private FAFRequestInfo fafRequestInfo = new FAFRequestInfo();

	// private List<FafFireflowTicket> fafFireflowTicketList;

	public FafFireflowTicket() {
		setCreated_date(new Date());
	}

	/**
	 * @return the tiRequest
	 */
	public TIRequest getTiRequest() {
		return tiRequest;
	}
	public static String[] getStatusToConsiderImplemented(){
		String[] values = {NOT_POSTED,CREATED,NEW,OPEN,CHECK,APPROVE,PLAN,IMPLEMENT,LCK_TICK_FAILED};
		return values;
	}
	public static String[] getStatusToConsiderValidaed(){
		String[] values = {NOT_POSTED,CREATED,NEW,OPEN,CHECK,APPROVE,PLAN,IMPLEMENT,LCK_TICK,LCK_TICK_FAILED};
		return values;
	}
	/**
	 * @param tiRequest
	 *            the tiRequest to set
	 */
	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	/**
	 * @return the policyGroup
	 */
	public FireWallPolicyGroup getPolicyGroup() {
		return policyGroup;
	}

	/**
	 * @param policyGroup
	 *            the policyGroup to set
	 */
	public void setPolicyGroup(FireWallPolicyGroup policyGroup) {
		this.policyGroup = policyGroup;
	}

	/**
	 * @return the ticketNumber
	 */
	public String getTicketNumber() {
		return ticketNumber;
	}

	/**
	 * @param ticketNumber
	 *            the ticketNumber to set
	 */
	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	/**
	 * @return the fafFireWallRules
	 */
	public List<FafFirewallRule> getFafFireWallRules() {
		return fafFireWallRules;
	}

	/**
	 * @param fafFireWallRules
	 *            the fafFireWallRules to set
	 */
	public void setFafFireWallRules(List<FafFirewallRule> fafFireWallRules) {
		this.fafFireWallRules = fafFireWallRules;
	}

	/**
	 * @return the type
	 */
	public char getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(char type) {
		this.type = type;
	}

	/**
	 * @return the createType
	 */
	public char getCreateType() {
		return createType;
	}

	/**
	 * @param createType
	 *            the createType to set
	 */
	public void setCreateType(char createType) {
		this.createType = createType;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the fafRequestInfo
	 */
	public FAFRequestInfo getFafRequestInfo() {
		return fafRequestInfo;
	}

	/**
	 * @param fafRequestInfo
	 *            the fafRequestInfo to set
	 */
	public void setFafRequestInfo(FAFRequestInfo fafRequestInfo) {
		this.fafRequestInfo = fafRequestInfo;
	}

	
	public List<FafFireflowTicket> findFafFireflowTickets() {
		return ccrBeanFactory.getFireflowRequestPersistable().getFafFireflowTickets(this);

	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void createFireflowTicket(long tiRequest, Cookie[] requestCookies) {

		List<FafFireflowTicket> ticketsToCreate = getTicketsToBeCreated(tiRequest);
		List<FafFireflowTicket> ticketsToReject = getTicketsToBeRejected(tiRequest);
		for (FafFireflowTicket ticket : ticketsToCreate) {
			// populate requestInfo which will be used to post connection id and
			// name to fireflow
			ticket.setFafRequestInfo(this.fafRequestInfo);
			//String ticketNo = fireflowExternalizable.createFireflowTicket(ticket);
			String ticketNo = ccrBeanFactory.getFireflowExternalizable().createFireflowTicket(ticket,requestCookies);
			// update the ticket no and status post ticket creation @fireflow
			ticket.setTicketNumber(ticketNo);
			ticket.setStatus(CREATED);
			ccrBeanFactory.getFireflowRequestPersistable().updateFafFireflowTicket(ticket);
		}
		for (FafFireflowTicket ticket : ticketsToReject) {
			ticket.setStatus(REJECTED);
			ccrBeanFactory.getFireflowExternalizable().updateFireflowTicketStatus(ticket,requestCookies);
		}

	}

	private List<FafFireflowTicket> getTicketsToBeRejected(long tiRequest) {
		return ccrBeanFactory.getFireflowRequestPersistable().getTicketsToBeResolved(tiRequest);
	}

	private List<FafFireflowTicket> getTicketsToBeCreated(long tiRequest) {
		return ccrBeanFactory.getFireflowRequestPersistable().getTicketsToBeCreated(tiRequest);
	}

	
	public boolean isTicketsToBeCreated(long tiRequest) {
		return ccrBeanFactory.getFireflowRequestPersistable().isTicketsToBeCreated(tiRequest);
	}

	
	public void getFFTicketDetails(String ticketId) {

		ccrBeanFactory.getFireflowExternalizable().getFFTicketDetails(ticketId);

	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateFireflowTicket(FafFireflowTicket ticket) {
		ccrBeanFactory.getFireflowRequestPersistable().updateFafFireflowTicket(ticket);

	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void parseFireflowTicketXml(FireFlowMessageRequest notifMsg)
			throws BusinessException {
		List<FafFirewallRuleSuggestion> fafFirewallRuleSuggestions = ccrBeanFactory.getFireflowExternalizable()
				.parseFireflowTicketXml(notifMsg);

		if (fafFirewallRuleSuggestions != null
				&& fafFirewallRuleSuggestions.size() > 0) {
			ccrBeanFactory.getFireflowRequestPersistable()
					.saveFafFirewallRuleSuggestions(fafFirewallRuleSuggestions);
				
			
		}

	}

	
	public FirewallPolicy findFirewallPolicyByName(String policyName) {
		return ccrBeanFactory.getFireflowRequestPersistable().getFirewallPolicyByName(policyName);
	}

	
	public Firewall findFirewallByName(String firewallName) {
		return ccrBeanFactory.getFireflowRequestPersistable().getFirewallByName(firewallName);
	}

	
	public FafFireflowTicket getFireflowTicketById() {
		return ccrBeanFactory.getFireflowRequestPersistable().getFafFireflowTicket(this);
	}

	
	public FafFireflowTicket findFireflowTicketByNumber(String ticketNo) {
		return ccrBeanFactory.getFireflowRequestPersistable()
				.getFafFireflowTicketByNumber(ticketNo);
	}

	
	public FafFirewallRuleSuggestion getFafFirewallRuleSuggestion(
			Long fafFirewallRuleId, Long policyId) {
		return ccrBeanFactory.getFireflowRequestPersistable().getFafFirewallRuleSuggestion(
				fafFirewallRuleId, policyId);
	}

	@Transactional
	public List<FafFireflowTicket> findFafFireflowTicketsByReqId(Long requestId) {
		return ccrBeanFactory.getFireflowRequestPersistable()
				.getFafFireflowTicketsByReqId(requestId);
	}

	@Transactional
	public void updateFireflowTicketStatus(FafFireflowTicket ticket,Cookie[] requestCookies) {
		ccrBeanFactory.getFireflowExternalizable().updateFireflowTicketStatus(ticket,requestCookies);
	}
	@Transactional
	public IPAddressObj getIPAddressObj(String address) {
		return ccrBeanFactory.getFireflowRequestPersistable().getIPAddressObj(
				address);
	}
	@Transactional
	public boolean hasFailedChildTicket() {
		return ccrBeanFactory.getFireflowRequestPersistable().hasFailedChildTicket(
				this.getTicketNumber());
	}
@Transactional
	public boolean hasChildTicket() {
		return ccrBeanFactory.getFireflowRequestPersistable().hasChildTicket(
				this.getTicketNumber());
	}

public void setIpReg(String ipReg) {
	this.ipReg = ipReg;
}

public String getIpReg() {
	return ipReg;
}


public List<FafFireflowTicket> findFafFireflowTicketsByReqIdNew(Long tiReqId) {
	return ccrBeanFactory.getFireflowRequestPersistable()
	.getFafFireflowTicketsByReqIdNew(tiReqId);
}
}
