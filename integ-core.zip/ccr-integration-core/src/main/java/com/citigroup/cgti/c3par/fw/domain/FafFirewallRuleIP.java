/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author bs45969
 *
 */
public class FafFirewallRuleIP extends Base implements Comparable<FafFirewallRuleIP> {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private FafFirewallRule fafFireWallRule;
    private IPAddress ipAddress;
    private String NAT;
    private TIRequest tiRequest;
    private TIRequest updatedTIRequest;
    private Long objRuleID;
    /**
	 * @return the objRuleID
	 */
	public Long getObjRuleID() {
		return objRuleID;
	}
	/**
	 * @param objRuleID the objRuleID to set
	 */
	public void setObjRuleID(Long objRuleID) {
		this.objRuleID = objRuleID;
	}
	/**
     * @return the fafFireWallRule
     */
    public FafFirewallRule getFafFireWallRule() {
        return fafFireWallRule;
    }
    /**
     * @param fafFireWallRule the fafFireWallRule to set
     */
    public void setFafFireWallRule(FafFirewallRule fafFireWallRule) {
        this.fafFireWallRule = fafFireWallRule;
    }
    /**
     * @return the ipAddress
     */
    public IPAddress getIpAddress() {
        return ipAddress;
    }
    /**
     * @param ipAddress the ipAddress to set
     */
    public void setIpAddress(IPAddress ipAddress) {
        this.ipAddress = ipAddress;
    }
    /**
     * @return the nAT
     */
    public String getNAT() {
        return NAT;
    }
    /**
     * @param nAT the nAT to set
     */
    public void setNAT(String nAT) {
        NAT = nAT;
    }
    
    @Override
    public String toString(){
    	if(objRuleID!=null && objRuleID.longValue()>0){
    		return ipAddress.getAFAObjectName();
    	}else{
    		return ipAddress.toString();
    	}
    	
    }
	/**
	 * @return the tiRequest
	 */
	public TIRequest getTiRequest() {
		return tiRequest;
	}
	/**
	 * @param tiRequest the tiRequest to set
	 */
	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}
	/**
	 * @return the updatedTIRequest
	 */
	public TIRequest getUpdatedTIRequest() {
		return updatedTIRequest;
	}
	/**
	 * @param updatedTIRequest the updatedTIRequest to set
	 */
	public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
		this.updatedTIRequest = updatedTIRequest;
	}
	@Override
	public int compareTo(FafFirewallRuleIP obj) {
		int returnValue=0;
		IPAddress currentAddress=this.ipAddress;
		IPAddress againstAddress=obj.getIpAddress();
		if(currentAddress.getFormattedIP()!=null &&againstAddress.getFormattedIP()!=null){
			returnValue=currentAddress.getFormattedIP().compareToIgnoreCase(againstAddress.getFormattedIP());
		}
		if(currentAddress.getFormattedIP()!=null &&againstAddress.getFormattedStartIP()!=null){
			returnValue=currentAddress.getFormattedIP().compareToIgnoreCase(againstAddress.getFormattedStartIP());
		}
		if(currentAddress.getFormattedStartIP()!=null &&againstAddress.getFormattedIP()!=null){
			returnValue=currentAddress.getFormattedStartIP().compareToIgnoreCase(againstAddress.getFormattedIP());
		}
		if(currentAddress.getFormattedStartIP()!=null &&againstAddress.getFormattedStartIP()!=null){
			returnValue=currentAddress.getFormattedStartIP().compareToIgnoreCase(againstAddress.getFormattedStartIP());
		}
		return returnValue;
	}
    
}
