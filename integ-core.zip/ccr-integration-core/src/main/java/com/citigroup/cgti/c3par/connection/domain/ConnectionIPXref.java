package com.citigroup.cgti.c3par.connection.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import com.citigroup.cgti.c3par.appsense.domain.ConnectionIPMaster;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionIPXref.
 */
public class ConnectionIPXref extends PerformerPagerDO {

    /** The connection ip master. */
    private ConnectionIPMaster  connectionIPMaster;

    /** The connection vip xref list. */
    private List connectionVIPXrefList = new ArrayList();

    /** The resource type. */
    private Long resourceType ;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /** The nat ip address. */
    private String natIPAddress ;

    /** The end point. */
    private String endPoint;

    /** The application. */
    private Application  application =new Application();

    /** The third party id. */
    private Long thirdPartyId ;

    /** The ti request id. */
    private Long tiRequestId ;

    /**
     * Instantiates a new connection ip xref.
     */
    public ConnectionIPXref() {
	//---------------------
	setTableName(PerformerTypes.CONN_IP_XREF_TABEL);
	setSequenceName(PerformerTypes.CONN_IP_XREF_SEQ);
	//---------------------
	addToDBMapping("connectionIPMaster","IP_ID",1);
	//---------------------
	addToDBMapping("resourceType","resource_Type",2);
	//		---------------------
	addToDBMapping("created_date","created_date",3);
	//---------------------
	addToDBMapping("updated_date","updated_date",4);
	//----------------------
	addToDBMapping("natIPAddress","NAT_IP_ADDRESS",5);
	//----------------------
	addToDBMapping("application","application_id",6);
	//----------------------
	addToDBMapping("endPoint","END_POINT",7);
	//----------------------
	addToDBMapping("thirdPartyId","THIRD_PARTY_ID",8);
	//----------------------
	addToDBMapping("tiRequestId","TI_REQUEST_ID",9);
	//----------------------
	addToNonCompositionList("connectionIPMaster");
	//----------------------
	addToParentsMap("com.citigroup.cgti.c3par.connection.domain.ConnectionProcess" , "CONNECTION_REQUEST_ID");
	//----------------------
	addToChildList("connectionVIPXrefList",new ConnectionVIPXref());
	//----------------------
    }

    /**
     * Gets the connection ip master.
     *
     * @return the connection ip master
     */
    public ConnectionIPMaster getConnectionIPMaster() {
	return connectionIPMaster;
    }

    /**
     * Sets the connection ip master.
     *
     * @param connectionIPMaster the new connection ip master
     */
    public void setConnectionIPMaster(ConnectionIPMaster connectionIPMaster) {
	this.connectionIPMaster = connectionIPMaster;
    }

    /**
     * Gets the connection vip xref list.
     *
     * @return the connection vip xref list
     */
    public List getConnectionVIPXrefList() {
	return connectionVIPXrefList;
    }

    /**
     * Sets the connection vip xref list.
     *
     * @param connectionVIPXrefList the new connection vip xref list
     */
    public void setConnectionVIPXrefList(List connectionVIPXrefList) {
	this.connectionVIPXrefList = connectionVIPXrefList;
    }

    /**
     * Gets the created_date.
     *
     * @return Returns the created_date.
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date The created_date to set.
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return Returns the updated_date.
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date The updated_date to set.
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }

    /**
     * Gets the resource type.
     *
     * @return the resource type
     */
    public Long getResourceType() {
	return resourceType;
    }

    /**
     * Sets the resource type.
     *
     * @param resourceType the new resource type
     */
    public void setResourceType(Long resourceType) {
	this.resourceType = resourceType;
    }

    /**
     * Gets the nat ip address.
     *
     * @return Returns the natIPAddress.
     */
    public String getNatIPAddress() {
	return natIPAddress;
    }

    /**
     * Sets the nat ip address.
     *
     * @param natIPAddress The natIPAddress to set.
     */
    public void setNatIPAddress(String natIPAddress) {
	this.natIPAddress = natIPAddress;
    }

    /**
     * Gets the application.
     *
     * @return the application
     */
    public Application getApplication() {
	return application;
    }

    /**
     * Sets the application.
     *
     * @param application the new application
     */
    public void setApplication(Application application) {
	this.application = application;
    }

    /**
     * Gets the end point.
     *
     * @return the end point
     */
    public String getEndPoint() {
	return endPoint;
    }

    /**
     * Sets the end point.
     *
     * @param endPoint the new end point
     */
    public void setEndPoint(String endPoint) {
	this.endPoint = endPoint;
    }

    /**
     * Gets the third party id.
     *
     * @return the third party id
     */
    public Long getThirdPartyId() {
	return thirdPartyId;
    }

    /**
     * Sets the third party id.
     *
     * @param thirdPartyId the new third party id
     */
    public void setThirdPartyId(Long thirdPartyId) {
	this.thirdPartyId = thirdPartyId;
    }

    /**
     * Gets the ti request id.
     *
     * @return the ti request id
     */
    public Long getTiRequestId() {
	return tiRequestId;
    }

    /**
     * Sets the ti request id.
     *
     * @param tiRequestId the new ti request id
     */
    public void setTiRequestId(Long tiRequestId) {
	this.tiRequestId = tiRequestId;
    }


}
