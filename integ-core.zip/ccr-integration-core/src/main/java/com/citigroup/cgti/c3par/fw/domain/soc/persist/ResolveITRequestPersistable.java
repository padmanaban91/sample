/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain.soc.persist;


import java.util.List;
import com.citigroup.cgti.c3par.fw.domain.ResolveITNotifyLog;
import com.citigroup.cgti.c3par.persistance.Persistable;

/**
 * @author bs45969
 *
 */
public interface ResolveITRequestPersistable extends Persistable {

	public void saveResolveITNotifyLog(ResolveITNotifyLog resolveITNotifyLog);
	
	public void updateResolveITNotifyLog(ResolveITNotifyLog resolveITNotifyLog);
	
	public ResolveITNotifyLog findTicketLog(Long id);
	
	public ResolveITNotifyLog findTicketLogByCMPID(String cmpID);

	public List<ResolveITNotifyLog> getResolveITNotifyLogList();
	
	public List<ResolveITNotifyLog> getResolveITNotifyLogList(String searchString);

	public String getComments(Long tiReqId);

	public ResolveITNotifyLog findTicketLogByTiReqId(Long tiRequestId);

	void deleteUploadedDocument(String tiRequestId, String docType);

	void updateTiRequestCMP(String cmpID, String tiRequestId);
	
	public List<ResolveITNotifyLog> getCMPDetails(String searchString);

}