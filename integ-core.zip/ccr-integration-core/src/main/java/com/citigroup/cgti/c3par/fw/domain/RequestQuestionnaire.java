package com.citigroup.cgti.c3par.fw.domain;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * 
 * @author ne36745
 *
 */
public class RequestQuestionnaire extends Base {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private OstiaQuestionnaire questionnaire;
	
	private TIRequest tiRequest;
	
	private TIRequest deletedTIRequest;
	
	private String status;

	private String baselineName;
	
	private String riskAnalysisDate;
	
	private Date ruleExecutionDate;
	
	private String lastBaselineName;
	
	private String lastBaselineReportUrl;
	
	private String type;
	
	private String baselineReportUrl;
	
	private List<RequestOstiaQuestion> requestOstiaQuestions;
	
	public RequestQuestionnaire() {
		setCreated_date(new Date());
	}
	
	/**
	 * @return the questionnaire
	 */
	public OstiaQuestionnaire getQuestionnaire() {
		return questionnaire;
	}

	/**
	 * @param questionnaire the questionnaire to set
	 */
	public void setQuestionnaire(OstiaQuestionnaire questionnaire) {
		this.questionnaire = questionnaire;
	}

	
	/**
	 * @return the tiRequest
	 */
	public TIRequest getTiRequest() {
		return tiRequest;
	}

	/**
	 * @param tiRequest the tiRequest to set
	 */
	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	/**
	 * @return the deletedTIRequest
	 */
	public TIRequest getDeletedTIRequest() {
		return deletedTIRequest;
	}

	/**
	 * @param deletedTIRequest the deletedTIRequest to set
	 */
	public void setDeletedTIRequest(TIRequest deletedTIRequest) {
		this.deletedTIRequest = deletedTIRequest;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the baselineName
	 */
	public String getBaselineName() {
		return baselineName;
	}

	/**
	 * @param baselineName the baselineName to set
	 */
	public void setBaselineName(String baselineName) {
		this.baselineName = baselineName;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the baselineReportUrl
	 */
	public String getBaselineReportUrl() {
		return baselineReportUrl;
	}

	/**
	 * @param baselineReportUrl the baselineReportUrl to set
	 */
	public void setBaselineReportUrl(String baselineReportUrl) {
		this.baselineReportUrl = baselineReportUrl;
	}

	public String getRiskAnalysisDate() {
		Date displayDate=getCreated_date();
		if(displayDate != null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy");
			return dateformat.format(displayDate);
		}
		return riskAnalysisDate;
	}

	public void setRiskAnalysisDate(String riskAnalysisDate) {
		this.riskAnalysisDate = riskAnalysisDate;
	}

	/**
	 * @return the ruleExecutionDate
	 */
	public Date getRuleExecutionDate() {
		return ruleExecutionDate;
	}

	/**
	 * @param ruleExecutionDate the ruleExecutionDate to set
	 */
	public void setRuleExecutionDate(Date ruleExecutionDate) {
		this.ruleExecutionDate = ruleExecutionDate;
	}

	/**
	 * @return the lastBaselineName
	 */
	public String getLastBaselineName() {
		return lastBaselineName;
	}

	/**
	 * @param lastBaselineName the lastBaselineName to set
	 */
	public void setLastBaselineName(String lastBaselineName) {
		this.lastBaselineName = lastBaselineName;
	}

	/**
	 * @return the lastBaselineReportUrl
	 */
	public String getLastBaselineReportUrl() {
		return lastBaselineReportUrl;
	}

	/**
	 * @param lastBaselineReportUrl the lastBaselineReportUrl to set
	 */
	public void setLastBaselineReportUrl(String lastBaselineReportUrl) {
		this.lastBaselineReportUrl = lastBaselineReportUrl;
	}

	/**
	 * @return the requestOstiaQuestions
	 */
	public List<RequestOstiaQuestion> getRequestOstiaQuestions() {
		return requestOstiaQuestions;
	}

	/**
	 * @param requestOstiaQuestions the requestOstiaQuestions to set
	 */
	public void setRequestOstiaQuestions(
			List<RequestOstiaQuestion> requestOstiaQuestions) {
		this.requestOstiaQuestions = requestOstiaQuestions;
	}
	
}
