package com.citigroup.cgti.c3par.communication.domain;

import java.sql.Blob;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class BusinessUserProcess {
	
	private CMPRequest cmpRequest;
	private String addNote;
	

	private static Blob userUploadFileName;
	
	private CommonsMultipartFile addUploadfile;
   CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	

	private String cmpId;
	private String actCode;
	private String resolveItDetailUrl;
	private String caspUrl;
	private String assignedUser;
	private String assistanceRequested;
	private String cancelReason;
	private String textForSubject;
	private String additionalText;
	
	
	public String getTextForSubject() {
		return textForSubject;
	}

	public void setTextForSubject(String textForSubject) {
		this.textForSubject = textForSubject;
	}

	public String getAdditionalText() {
		return additionalText;
	}

	public void setAdditionalText(String additionalText) {
		this.additionalText = additionalText;
	}

	public String getAssignedUser() {
		return assignedUser;
	}

	public void setAssignedUser(String assignedUser) {
		this.assignedUser = assignedUser;
	}

	public String getAssistanceRequested() {
		return assistanceRequested;
	}

	public void setAssistanceRequested(String assistanceRequested) {
		this.assistanceRequested = assistanceRequested;
	}

	public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

	
	
	public CommonsMultipartFile getAddUploadfile() {
		return addUploadfile;
	}

	public void setAddUploadfile(CommonsMultipartFile addUploadfile) {
		this.addUploadfile = addUploadfile;
	}

	public static Blob getUserUploadFileName() {
		return userUploadFileName;
	}

	public void setUserUploadFileName(Blob userUploadFileName) {
		this.userUploadFileName = userUploadFileName;
	}
	
	public CMPRequest getCmpRequest() {
		return cmpRequest;
	}

	public void setCmpRequest(CMPRequest cmpRequest) {
		this.cmpRequest = cmpRequest;
	}
	
	public String getAddNote() {
		return addNote;
	}

	public void setAddNote(String addNote) {
		this.addNote = addNote;
	}
	
	public String getCmpId() {
		return cmpId;
	}

	public void setCmpId(String cmpId) {
		this.cmpId = cmpId;
	}

	public String getActCode() {
		return actCode;
	}

	public void setActCode(String actCode) {
		this.actCode = actCode;
	}
	public String getResolveItDetailUrl() {
		return resolveItDetailUrl;
	}

	public void setResolveItDetailUrl(String resolveItDetailUrl) {
		this.resolveItDetailUrl = resolveItDetailUrl;
	}
	public String getCaspUrl() {
		return caspUrl;
	}

	public void setCaspUrl(String caspUrl) {
		this.caspUrl = caspUrl;
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateAddNoteDetails(CMPRequestNotes cmpRequestNotes) {
		ccrBeanFactory.getEmailGenViewServicePersistable().updateAddNoteDetails(cmpRequestNotes);
	}
	
	public CitiContact getAgentDetails(String ssoId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getAgentDetails(ssoId);		
	}
	
	public void cmpActivityTrail(Long cmpId, String ssoId, String taskCode, String activityStatus) {
		ccrBeanFactory.getCmpRequestPersistable().cmpActivityTrail(cmpId, ssoId, taskCode, activityStatus);
	}
	
	
	public List<GenericLookup> loadGenericLookupByName(String name) {
		return ccrBeanFactory.getCommonServicePersistable().getGenericLookupByName(name);
	}
	
	
	public int updateCMPRequestStatus(Long cmpId,String status) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().updateCMPRequestStatus(cmpId,status);
	}
	
	
	public CMPRequest getCMPRequestDetails(String cmpReqId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getCMPRequestDetails(cmpReqId);
	}
	
	
	public void sendEmailGenerationView(String userComments , CmpRequestDTO commEmail) {
		ccrBeanFactory.getiMailModule().sendEcmEmailViewGeneration(userComments ,commEmail); 
	}
	
	
	public List<Map<String, String>> getChangeRequestDetails(Long conReqId, String cmpId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getChangeRequestDetails(conReqId, cmpId);
	}
	
	
	public CMPRequest getCMPRequestDetailsByOerderId(String cmpReqId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getCMPRequestDetailsByOrderId(cmpReqId);
	}
	
	
	public List<GenericLookup> loadGenericLookupData(List<String> names) {
		return ccrBeanFactory.getCommonServicePersistable().getGenericLookupData(names);
	} 

	
	
	public boolean isWaitingforECMUserReply(Long cmpId,String actCode) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().isWaitingforECMUserReply(cmpId,actCode);
	}
	
	/*@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public CMPRequest getCMPRequestDetails(String cmpReqId) {
		return emailGenViewServicePersistable.getCMPRequestDetailsByOrderId(cmpReqId);
	}*/

	
	
}
