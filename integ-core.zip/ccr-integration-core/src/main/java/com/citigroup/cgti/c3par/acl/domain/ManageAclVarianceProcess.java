package com.citigroup.cgti.c3par.acl.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.common.domain.AccessFormText;
import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.domain.Person;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.model.PlanningEntity;
import com.citigroup.cgti.c3par.secacl.domain.soc.persist.ManageAclVariancePersistable;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class ManageAclVarianceProcess {
	private ACLVariance aclVariance;

	private Planning planning;

	private TIRequest tirequest;

	private String aclString;

	private Long originalConnectionRequestId;

	private Integer currVersionNo;

	private Integer versionNo;

	private String rationale;

	private String CMPReview;

	private String SOWReview;

	private String currBusJustfi;

	private String conName;

	private Person requestor = new Person();

	private Person currCycleRequestor = new Person();

	private ArrayList businessContacts = new ArrayList();

	private ArrayList origBusJustification = new ArrayList();

	private String fafSplInstruction;

	private String fafCompletionDate;

	private Long fafInfomanId;

	private ArrayList uploadedDocumentACLList = new ArrayList();

	private String name;

	boolean review;

	private String reviewStatus;
	
    CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

	public boolean isReview() {
		return review;
	}

	public void setReview(boolean review) {
		this.review = review;
	}

	public ACLVariance getAclVariance() {
		return aclVariance;
	}

	public void setAclVariance(ACLVariance aclVariance) {
		this.aclVariance = aclVariance;
	}

	public Long getOriginalConnectionRequestId() {
		return originalConnectionRequestId;
	}

	public void setOriginalConnectionRequestId(Long originalConnectionRequestId) {
		this.originalConnectionRequestId = originalConnectionRequestId;
	}

	public Integer getCurrVersionNo() {
		return currVersionNo;
	}

	public void setCurrVersionNo(Integer currVersionNo) {
		this.currVersionNo = currVersionNo;
	}

	public Integer getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(Integer versionNo) {
		this.versionNo = versionNo;
	}

	public String getRationale() {
		return rationale;
	}

	public void setRationale(String rationale) {
		this.rationale = rationale;
	}

	public String getCMPReview() {
		return CMPReview;
	}

	public void setCMPReview(String cMPReview) {
		CMPReview = cMPReview;
	}

	public String getSOWReview() {
		return SOWReview;
	}

	public void setSOWReview(String sOWReview) {
		SOWReview = sOWReview;
	}

	public Person getRequestor() {
		return requestor;
	}

	public void setRequestor(Person requestor) {
		this.requestor = requestor;
	}

	public ArrayList getBusinessContacts() {
		return businessContacts;
	}

	public void setBusinessContacts(ArrayList businessContacts) {
		this.businessContacts = businessContacts;
	}

	public Person getCurrCycleRequestor() {
		return currCycleRequestor;
	}

	public void setCurrCycleRequestor(Person currCycleRequestor) {
		this.currCycleRequestor = currCycleRequestor;
	}

	public ArrayList getOrigBusJustification() {
		return origBusJustification;
	}

	public void setOrigBusJustification(ArrayList origBusJustification) {
		this.origBusJustification = origBusJustification;
	}

	public String getFafSplInstruction() {
		return fafSplInstruction;
	}

	public void setFafSplInstruction(String fafSplInstruction) {
		this.fafSplInstruction = fafSplInstruction;
	}

	public String getFafCompletionDate() {
		return fafCompletionDate;
	}

	public void setFafCompletionDate(String fafCompletionDate) {
		this.fafCompletionDate = fafCompletionDate;
	}

	public Long getFafInfomanId() {
		return fafInfomanId;
	}

	public void setFafInfomanId(Long fafInfomanId) {
		this.fafInfomanId = fafInfomanId;
	}

	public ArrayList getUploadedDocumentACLList() {
		return uploadedDocumentACLList;
	}

	public void setUploadedDocumentACLList(ArrayList uploadedDocumentACLList) {
		this.uploadedDocumentACLList = uploadedDocumentACLList;
	}

	public Planning getPlanning() {
		return planning;
	}

	public void setPlanning(Planning planning) {
		this.planning = planning;
	}

	public String getReviewStatus() {
		return reviewStatus;
	}

	public void setReviewStatus(String reviewStatus) {
		this.reviewStatus = reviewStatus;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAclString() {
		return aclString;
	}

	public void setAclString(String aclString) {
		this.aclString = aclString;
	}

	public String getCurrBusJustfi() {
		return currBusJustfi;
	}

	public void setCurrBusJustfi(String currBusJustfi) {
		this.currBusJustfi = currBusJustfi;
	}

	public String getConName() {
		return conName;
	}

	public void setConName(String conName) {
		this.conName = conName;
	}

	public TIRequest getTirequest() {
		return tirequest;
	}

	public void setTirequest(TIRequest tirequest) {
		this.tirequest = tirequest;
	}

	
	public ACLVariance getACLVarianceData(TIProcess tiProcess) {
		return ccrBeanFactory.getManageAclVariancePersistable().getACLVarianceData(tiProcess);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void storeACLVariance(ACLVariance aclVariance) {
		ccrBeanFactory.getManageAclVariancePersistable().storeACLVariance(aclVariance);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteACLVariance(ACLVariance aclVariance) {
		ccrBeanFactory.getManageAclVariancePersistable().deleteACLVariance(aclVariance);

	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateACLVariance(ACLVariance aclVariance) {
		ccrBeanFactory.getManageAclVariancePersistable().updateACLVariance(aclVariance);
	}

	
	public ACLVariance getACLVariance(TIProcess tiProcess) {
		return ccrBeanFactory.getManageAclVariancePersistable().getACLVariance(tiProcess);
	}

	
	public TIRequest getTIRequestDetails(Long tirequestid) {
		return ccrBeanFactory.getManageAclVariancePersistable().getTIRequest(tirequestid);
	}

	
	public Planning getPlanningDetails(Long planningid) {
		return ccrBeanFactory.getManageAclVariancePersistable().getPlanningDetails(planningid);
	}

	
	public Long getPlanningId(Long tirequestid) {
		return ccrBeanFactory.getCommonServicePersistable().getPlanningIdForTiRequestId(tirequestid); 
	}
	
	
	public String getSECACLAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID) {
		return ccrBeanFactory.getAccessFormText().getSECACLAccessFormText(tiRequestId, connectionRequestId, versionID);
		
	}
	
	
	public String getAllACLAccessFormText(Long tiRequestId, Long connectionRequestId) {
		return ccrBeanFactory.getAccessFormText().getAllACLAccessFormText(tiRequestId, connectionRequestId);
		
	}

}
