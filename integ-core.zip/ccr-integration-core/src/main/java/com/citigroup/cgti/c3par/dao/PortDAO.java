


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = PortDAO
// Table name = NET_PORT
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class PortDAO.
 */
public class PortDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "NET_PORT";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(PortDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "Port";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_APPLICATIONNAME. */
    public static final String	COLUMN_APPLICATIONNAME = "APPLICATION_NAME";

    /** The Constant COLUMN_APPLICATIONNAME_LEN. */
    public static final int		COLUMN_APPLICATIONNAME_LEN = 250;

    /** The Constant COLUMN_PORTNUMBER. */
    public static final String	COLUMN_PORTNUMBER = "PORT_NUMBER";

    /** The Constant COLUMN_PORTNUMBER_LEN. */
    public static final int		COLUMN_PORTNUMBER_LEN = 50;

    /** The Constant COLUMN_PROTOCOL. */
    public static final String	COLUMN_PROTOCOL = "PROTOCOL";

    /** The Constant COLUMN_PROTOCOL_LEN. */
    public static final int		COLUMN_PROTOCOL_LEN = 100;

    /** The Constant COLUMN_FLOWOFDATA. */
    public static final String	COLUMN_FLOWOFDATA = "FLOW_OF_DATA";

    /** The Constant COLUMN_FLOWOFDATA_LEN. */
    public static final int		COLUMN_FLOWOFDATA_LEN = 100;

    /** The Constant COLUMN_JUSTIFICATION. */
    public static final String	COLUMN_JUSTIFICATION = "JUSTIFICATION";

    /** The Constant COLUMN_JUSTIFICATION_LEN. */
    public static final int		COLUMN_JUSTIFICATION_LEN = 2000;
    // Column names of references
    /** The Constant COLUMN_IPPAIR_ID. */
    public static final String	COLUMN_IPPAIR_ID = "IP_PAIR_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + PortDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_APPLICATIONNAME
    + ", " + COLUMN_PORTNUMBER
    + ", " + COLUMN_PROTOCOL
    + ", " + COLUMN_FLOWOFDATA
    + ", " + COLUMN_JUSTIFICATION
    + ", " + COLUMN_IPPAIR_ID
    + " FROM " + PortDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = PortDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + PortDAO.TABLE + " SET "
    + COLUMN_APPLICATIONNAME + " = ? "
    + ", " + COLUMN_PORTNUMBER + " = ? "
    + ", " + COLUMN_PROTOCOL + " = ? "
    + ", " + COLUMN_FLOWOFDATA + " = ? "
    + ", " + COLUMN_JUSTIFICATION + " = ? "
    + ", " + COLUMN_IPPAIR_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + PortDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_APPLICATIONNAME 
    + ", " + COLUMN_PORTNUMBER 
    + ", " + COLUMN_PROTOCOL 
    + ", " + COLUMN_FLOWOFDATA 
    + ", " + COLUMN_JUSTIFICATION 
    + ", " + COLUMN_IPPAIR_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + PortDAO.TABLE + " WHERE ID = ?";

    /** The Constant SELECT_ANSWERS_REFERENCE_IDS_STMT. */
    private static final String SELECT_ANSWERS_REFERENCE_IDS_STMT = "SELECT " + OstiaAnsDAO.COLUMN_ID + " FROM " + OstiaAnsDAO.TABLE + " WHERE " + OstiaAnsDAO.COLUMN_PORT_ID + " = ?";

    /** The Constant SELECT_FIREWALLS_REFERENCE_IDS_STMT. */
    private static final String SELECT_FIREWALLS_REFERENCE_IDS_STMT = "SELECT " + PortFirewallXrefDAO.COLUMN_ID + " FROM " + PortFirewallXrefDAO.TABLE + " WHERE " + PortFirewallXrefDAO.COLUMN_PORT_ID + " = ?";


    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the port dao
     */
    public static PortDAO createInstance(DatabaseSession session)
    {
	return new PortDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new port dao.
     *
     * @param session the session
     */
    public PortDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating PortDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The PortEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(PortEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(PortEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The PortEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(PortEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(PortEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting PortEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + PortDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, PortDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setStringToStatement(st, position, entity.getApplicationName(), COLUMN_APPLICATIONNAME_LEN);
	    position = setStringToStatement(st, position, entity.getPortNumber(), COLUMN_PORTNUMBER_LEN);
	    position = setStringToStatement(st, position, entity.getProtocol(), COLUMN_PROTOCOL_LEN);
	    position = setStringToStatement(st, position, entity.getFlowOfData(), COLUMN_FLOWOFDATA_LEN);
	    position = setStringToStatement(st, position, entity.getJustification(), COLUMN_JUSTIFICATION_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateAnswersReferences((PortEntity) entity);
	    updateFirewallsReferences((PortEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + PortDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The PortEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(PortEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(PortEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The PortEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(PortEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(PortEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating PortEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + PortDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setStringToStatement(st, position, entity.getApplicationName(), COLUMN_APPLICATIONNAME_LEN);
	    position = setStringToStatement(st, position, entity.getPortNumber(), COLUMN_PORTNUMBER_LEN);
	    position = setStringToStatement(st, position, entity.getProtocol(), COLUMN_PROTOCOL_LEN);
	    position = setStringToStatement(st, position, entity.getFlowOfData(), COLUMN_FLOWOFDATA_LEN);
	    position = setStringToStatement(st, position, entity.getJustification(), COLUMN_JUSTIFICATION_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateAnswersReferences((PortEntity) entity);
	    updateFirewallsReferences((PortEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + PortDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public PortEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public PortEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	PortEntity obj = (PortEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting PortEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> PortEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (PortEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + PortDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + PortDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting PortEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    PortEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (PortEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (PortEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + PortDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type PortEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		PortEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM NET_PORT";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (PortEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + PortDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type PortEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + PortDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    PortEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    PortEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(PortEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(PortEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + PortDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(PortEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();

	    // Go through the many association list and delete any entities that exist in it.
	    OstiaAnsDAO answersDAO = getAnswersDAO();
	    List original_answers_ids = entity.getOriginalAnswersIds();
	    Iterator answersIt = entity.getAnswers().getDeletedList().iterator();
	    while (answersIt.hasNext())
	    {
		OstiaAnsEntity o = (OstiaAnsEntity)answersIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_answers_ids.remove(id);
		}
		answersDAO.delete(o);
	    }

	    answersIt = entity.getAnswers().iterator();
	    while (answersIt.hasNext())
	    {
		OstiaAnsEntity o = (OstiaAnsEntity)answersIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_answers_ids.remove(id);
		}
		answersDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    answersDAO.delete(original_answers_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    PortFirewallXrefDAO firewallsDAO = getFirewallsDAO();
	    List original_firewalls_ids = entity.getOriginalFirewallsIds();
	    Iterator firewallsIt = entity.getFirewalls().getDeletedList().iterator();
	    while (firewallsIt.hasNext())
	    {
		PortFirewallXrefEntity o = (PortFirewallXrefEntity)firewallsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_firewalls_ids.remove(id);
		}
		firewallsDAO.delete(o);
	    }

	    firewallsIt = entity.getFirewalls().iterator();
	    while (firewallsIt.hasNext())
	    {
		PortFirewallXrefEntity o = (PortFirewallXrefEntity)firewallsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_firewalls_ids.remove(id);
		}
		firewallsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    firewallsDAO.delete(original_firewalls_ids);
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + PortDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	PortEntity entity = (PortEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setApplicationName(getStringFromResultSet(rs, COLUMN_APPLICATIONNAME));
	    entity.setApplicationName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalApplicationName(entity.getApplicationName());
	    //			entity.setPortNumber(getStringFromResultSet(rs, COLUMN_PORTNUMBER));
	    entity.setPortNumber(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalPortNumber(entity.getPortNumber());
	    //			entity.setProtocol(getStringFromResultSet(rs, COLUMN_PROTOCOL));
	    entity.setProtocol(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProtocol(entity.getProtocol());
	    //			entity.setFlowOfData(getStringFromResultSet(rs, COLUMN_FLOWOFDATA));
	    entity.setFlowOfData(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalFlowOfData(entity.getFlowOfData());
	    //			entity.setJustification(getStringFromResultSet(rs, COLUMN_JUSTIFICATION));
	    entity.setJustification(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalJustification(entity.getJustification());

	    // Single References
	    //			entity.setIpPairId(getLongFromResultSet(rs, COLUMN_IPPAIR_ID));
	    entity.setIpPairId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIpPairId(entity.getIpPairId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	PortEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (PortEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new PortEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	PortEntity entity = (PortEntity)obj;
	loadAnswersReferenceIds(entity);
	loadFirewallsReferenceIds(entity);
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("PortFirewallXrefDAO.loadReferences(): References for PortEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("PortFirewallXrefDAO.loadReferences(): Loading references for PortEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    PortEntity entity = (PortEntity)obj;

	    loadAnswersReferences(entity);

	    Long ipPairId = entity.getIpPairId();
	    if (ipPairId != null)
	    {
		//			IPPairDAO ipPairDAO = new IPPairDAO(getSession());
		IPPairDAO ipPairDAO = getIpPairDAO();
		entity.setIpPair((IPPairEntity)ipPairDAO.get(ipPairId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalIpPair(entity.getIpPair());
	    }

	    loadFirewallsReferences(entity);

	}
	catch(Exception e)
	{
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for PortEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load ip pair with id.
     *
     * @param id the id
     * @return the iP pair entity
     * @throws DatabaseException the database exception
     */
    public IPPairEntity loadIpPairWithId(Long id) throws DatabaseException
    {
	IPPairEntity entity = null;
	if (id != null)
	{
	    //			IPPairDAO ipPairDAO = new IPPairDAO(getSession());
	    IPPairDAO ipPairDAO = getIpPairDAO();
	    entity = (IPPairEntity)ipPairDAO.get(id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	PortEntity entity = (PortEntity) obj;

	setLongToStatement(st, position++, entity.getIpPair() != null ? entity.getIpPair().getId() : entity.getIpPairId());

	return position;
    }

    // Many Composition 'answers' helpers 'Port'
    //======================================================================
    /**
     * Loads all the OstiaAns references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadAnswersReferences(PortEntity entity) throws DatabaseException
    {
	loadAnswersReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the OstiaAns references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadAnswersReferences(PortEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Answers references for PortEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getAnswers();
	    List id_list = entity.getOriginalAnswersIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		OstiaAnsDAO dao = getAnswersDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		OstiaAnsDAO dao = getAnswersDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Answers references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Answers References for PortEntity [" + entity.getId() + "].", e);
	}


	//		entity.setAnswers(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Answers references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadAnswersReferenceIds(PortEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_ANSWERS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalAnswersIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Answers Reference IDs from PortEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update answers references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateAnswersReferences(PortEntity entity) throws DatabaseException
    {
	ManyAssociationList answers = entity.getAnswers();
	OstiaAnsDAO dao = getAnswersDAO();

	Iterator itDeleted = answers.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    OstiaAnsEntity e = (OstiaAnsEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = answers.iterator();
	while (it.hasNext())
	{
	    OstiaAnsEntity e = (OstiaAnsEntity) it.next();
	    e.setPort(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'ipPair' helpers 'ports' does not need helper
    // Many Composition 'firewalls' helpers 'port'
    //======================================================================
    /**
     * Loads all the PortFirewallXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadFirewallsReferences(PortEntity entity) throws DatabaseException
    {
	loadFirewallsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the PortFirewallXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadFirewallsReferences(PortEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Firewalls references for PortEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getFirewalls();
	    List id_list = entity.getOriginalFirewallsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		PortFirewallXrefDAO dao = getFirewallsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		PortFirewallXrefDAO dao = getFirewallsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Firewalls references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Firewalls References for PortEntity [" + entity.getId() + "].", e);
	}


	//		entity.setFirewalls(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Firewalls references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadFirewallsReferenceIds(PortEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_FIREWALLS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalFirewallsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Firewalls Reference IDs from PortEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update firewalls references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateFirewallsReferences(PortEntity entity) throws DatabaseException
    {
	ManyAssociationList firewalls = entity.getFirewalls();
	PortFirewallXrefDAO dao = getFirewallsDAO();

	Iterator itDeleted = firewalls.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    PortFirewallXrefEntity e = (PortFirewallXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = firewalls.iterator();
	while (it.hasNext())
	{
	    PortFirewallXrefEntity e = (PortFirewallXrefEntity) it.next();
	    e.setPort(entity);
	    dao.update(e, false);
	}
    }

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A OstiaAnsDAO object 
     */
    protected OstiaAnsDAO getAnswersDAO()
    {
	OstiaAnsDAO dao = (OstiaAnsDAO)getSession().getDAO("OstiaAns");  
	if(dao == null)
	{
	    dao = new OstiaAnsDAO(getSession());  		
	    getSession().putDAO("OstiaAns", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A IPPairDAO object 
     */
    protected IPPairDAO getIpPairDAO()
    {
	IPPairDAO dao = (IPPairDAO)getSession().getDAO("IPPair");  
	if(dao == null)
	{
	    dao = new IPPairDAO(getSession());  		
	    getSession().putDAO("IPPair", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A PortFirewallXrefDAO object 
     */
    protected PortFirewallXrefDAO getFirewallsDAO()
    {
	PortFirewallXrefDAO dao = (PortFirewallXrefDAO)getSession().getDAO("PortFirewallXref");  
	if(dao == null)
	{
	    dao = new PortFirewallXrefDAO(getSession());  		
	    getSession().putDAO("PortFirewallXref", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [ApplicationName] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByApplicationName(String value) throws DatabaseException
    {
	return findByApplicationName(value, getSession());
    }

    /**
     * Find by application name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByApplicationName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PortDAO.TABLE + " WHERE " + COLUMN_APPLICATIONNAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [PortNumber] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByPortNumber(String value) throws DatabaseException
    {
	return findByPortNumber(value, getSession());
    }

    /**
     * Find by port number.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByPortNumber(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PortDAO.TABLE + " WHERE " + COLUMN_PORTNUMBER + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Protocol] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProtocol(String value) throws DatabaseException
    {
	return findByProtocol(value, getSession());
    }

    /**
     * Find by protocol.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProtocol(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PortDAO.TABLE + " WHERE " + COLUMN_PROTOCOL + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [FlowOfData] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByFlowOfData(String value) throws DatabaseException
    {
	return findByFlowOfData(value, getSession());
    }

    /**
     * Find by flow of data.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByFlowOfData(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PortDAO.TABLE + " WHERE " + COLUMN_FLOWOFDATA + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Justification] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByJustification(String value) throws DatabaseException
    {
	return findByJustification(value, getSession());
    }

    /**
     * Find by justification.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByJustification(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PortDAO.TABLE + " WHERE " + COLUMN_JUSTIFICATION + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [IpPair] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIpPair(Long value) throws DatabaseException
    {
	return findByIpPair(value, getSession());
    }

    /**
     * Find by ip pair.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIpPair(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PortDAO.TABLE + " WHERE " + COLUMN_IPPAIR_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by IpPair", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(PortEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
