package com.citigroup.cgti.c3par.bpm.ejb.search;
//Comment Added for check-in to RTC.
import java.util.List;

import com.citigroup.cgti.c3par.domain.logic.C3parServiceFacade;


/**
 * The Interface ISearchProxy.
 */
public interface ISearchProxy extends C3parServiceFacade {
	
	/**
	 * Gets the proxy instance.
	 *
	 * @return the proxy instance
	 * @throws Exception the exception
	 */
	public List getProxyInstance()throws Exception;
	
	/**
	 * Gets the proxy region.
	 *
	 * @param recordType the record type
	 * @return the proxy region
	 * @throws Exception the exception
	 */
	public List getProxyRegion(String recordType)throws Exception;
	
	/**
	 * Gets the prx instance name list.
	 *
	 * @param recordType the record type
	 * @param region the region
	 * @return the prx instance name list
	 * @throws Exception the exception
	 */
	public List getPrxInstanceNameList(String recordType,String region)throws Exception;
}
