package com.citigroup.cgti.c3par.common.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.persistance.Persistable;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.Sector;

public interface ManageBusinessUnitPersistable  extends Persistable {
	
	List<Relationship> getRelationshipList(CitiHierarchyMaster citiHierarchyMaster);
	List<Region> getRegionList() throws Exception;
	List<Sector> getSectorList() throws Exception;
	List<BusinessUnit> getBusinessUnitList(String sector) throws Exception;
	String addBusinessUnit(BusinessUnit bUnit) throws Exception;
	String mapHierarcy(CitiHierarchyMaster citiHierarchyMaster) throws Exception;
	
}
