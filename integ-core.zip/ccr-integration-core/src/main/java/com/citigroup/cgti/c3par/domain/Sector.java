package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

/**
 * The Class Sector.
 */
@XmlType(name="SectorEntity")
public class Sector extends Name implements Serializable {

}
