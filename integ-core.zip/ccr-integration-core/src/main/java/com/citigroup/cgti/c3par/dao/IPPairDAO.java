


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = IPPairDAO
// Table name = IP_PAIR
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class IPPairDAO.
 */
public class IPPairDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "IP_PAIR";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(IPPairDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "IPPair";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_NAME. */
    public static final String	COLUMN_NAME = "NAME";

    /** The Constant COLUMN_NAME_LEN. */
    public static final int		COLUMN_NAME_LEN = 100;

    /** The Constant COLUMN_RESOURCEID. */
    public static final String	COLUMN_RESOURCEID = "RESOURCE_ID";

    /** The Constant COLUMN_NATADDRESS. */
    public static final String	COLUMN_NATADDRESS = "N_A_T_ADDRESS";

    /** The Constant COLUMN_NATADDRESS_LEN. */
    public static final int		COLUMN_NATADDRESS_LEN = 100;

    /** The Constant COLUMN_IPA. */
    public static final String	COLUMN_IPA = "IP_A";

    /** The Constant COLUMN_IPA_LEN. */
    public static final int		COLUMN_IPA_LEN = 15;

    /** The Constant COLUMN_IPB. */
    public static final String	COLUMN_IPB = "IP_B";

    /** The Constant COLUMN_IPB_LEN. */
    public static final int		COLUMN_IPB_LEN = 15;

    /** The Constant COLUMN_CONNECTIONREQUESTID. */
    public static final String	COLUMN_CONNECTIONREQUESTID = "CONNECTION_REQUEST_ID";

    /** The Constant COLUMN_CONNECTIONID. */
    public static final String	COLUMN_CONNECTIONID = "CONNECTION_ID";
    // Column names of references
    /** The Constant COLUMN_APPLICATION_ID. */
    public static final String	COLUMN_APPLICATION_ID = "APPLICATION_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + IPPairDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_NAME
    + ", " + COLUMN_RESOURCEID
    + ", " + COLUMN_NATADDRESS
    + ", " + COLUMN_IPA
    + ", " + COLUMN_IPB
    + ", " + COLUMN_CONNECTIONREQUESTID
    + ", " + COLUMN_CONNECTIONID
    + ", " + COLUMN_APPLICATION_ID
    + " FROM " + IPPairDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = IPPairDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + IPPairDAO.TABLE + " SET "
    + COLUMN_NAME + " = ? "
    + ", " + COLUMN_RESOURCEID + " = ? "
    + ", " + COLUMN_NATADDRESS + " = ? "
    + ", " + COLUMN_IPA + " = ? "
    + ", " + COLUMN_IPB + " = ? "
    + ", " + COLUMN_CONNECTIONREQUESTID + " = ? "
    + ", " + COLUMN_CONNECTIONID + " = ? "
    + ", " + COLUMN_APPLICATION_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + IPPairDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_NAME 
    + ", " + COLUMN_RESOURCEID 
    + ", " + COLUMN_NATADDRESS 
    + ", " + COLUMN_IPA 
    + ", " + COLUMN_IPB 
    + ", " + COLUMN_CONNECTIONREQUESTID 
    + ", " + COLUMN_CONNECTIONID 
    + ", " + COLUMN_APPLICATION_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + IPPairDAO.TABLE + " WHERE ID = ?";

    /** The Constant SELECT_PORTS_REFERENCE_IDS_STMT. */
    private static final String SELECT_PORTS_REFERENCE_IDS_STMT = "SELECT " + PortDAO.COLUMN_ID + " FROM " + PortDAO.TABLE + " WHERE " + PortDAO.COLUMN_IPPAIR_ID + " = ?";


    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the iP pair dao
     */
    public static IPPairDAO createInstance(DatabaseSession session)
    {
	return new IPPairDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new iP pair dao.
     *
     * @param session the session
     */
    public IPPairDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating IPPairDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The IPPairEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(IPPairEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(IPPairEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The IPPairEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(IPPairEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(IPPairEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting IPPairEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + IPPairDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, IPPairDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setStringToStatement(st, position, entity.getName(), COLUMN_NAME_LEN);
	    position = setLongToStatement(st, position, entity.getResourceId());
	    position = setStringToStatement(st, position, entity.getNATAddress(), COLUMN_NATADDRESS_LEN);
	    position = setStringToStatement(st, position, entity.getIpA(), COLUMN_IPA_LEN);
	    position = setStringToStatement(st, position, entity.getIpB(), COLUMN_IPB_LEN);
	    position = setLongToStatement(st, position, entity.getConnectionRequestId());
	    position = setLongToStatement(st, position, entity.getConnectionId());

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updatePortsReferences((IPPairEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + IPPairDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The IPPairEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(IPPairEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(IPPairEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The IPPairEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(IPPairEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(IPPairEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating IPPairEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + IPPairDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setStringToStatement(st, position, entity.getName(), COLUMN_NAME_LEN);
	    position = setLongToStatement(st, position, entity.getResourceId());
	    position = setStringToStatement(st, position, entity.getNATAddress(), COLUMN_NATADDRESS_LEN);
	    position = setStringToStatement(st, position, entity.getIpA(), COLUMN_IPA_LEN);
	    position = setStringToStatement(st, position, entity.getIpB(), COLUMN_IPB_LEN);
	    position = setLongToStatement(st, position, entity.getConnectionRequestId());
	    position = setLongToStatement(st, position, entity.getConnectionId());

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updatePortsReferences((IPPairEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + IPPairDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public IPPairEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public IPPairEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	IPPairEntity obj = (IPPairEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting IPPairEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> IPPairEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (IPPairEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + IPPairDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + IPPairDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting IPPairEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    IPPairEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (IPPairEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (IPPairEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + IPPairDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type IPPairEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		IPPairEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM IP_PAIR";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (IPPairEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + IPPairDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type IPPairEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + IPPairDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    IPPairEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    IPPairEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(IPPairEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(IPPairEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + IPPairDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(IPPairEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();

	    // Go through the many association list and delete any entities that exist in it.
	    PortDAO portsDAO = getPortsDAO();
	    List original_ports_ids = entity.getOriginalPortsIds();
	    Iterator portsIt = entity.getPorts().getDeletedList().iterator();
	    while (portsIt.hasNext())
	    {
		PortEntity o = (PortEntity)portsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_ports_ids.remove(id);
		}
		portsDAO.delete(o);
	    }

	    portsIt = entity.getPorts().iterator();
	    while (portsIt.hasNext())
	    {
		PortEntity o = (PortEntity)portsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_ports_ids.remove(id);
		}
		portsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    portsDAO.delete(original_ports_ids);
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + IPPairDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	IPPairEntity entity = (IPPairEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setName(getStringFromResultSet(rs, COLUMN_NAME));
	    entity.setName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalName(entity.getName());
	    //			entity.setResourceId(getLongFromResultSet(rs, COLUMN_RESOURCEID));
	    entity.setResourceId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalResourceId(entity.getResourceId());
	    //			entity.setNATAddress(getStringFromResultSet(rs, COLUMN_NATADDRESS));
	    entity.setNATAddress(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalNATAddress(entity.getNATAddress());
	    //			entity.setIpA(getStringFromResultSet(rs, COLUMN_IPA));
	    entity.setIpA(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIpA(entity.getIpA());
	    //			entity.setIpB(getStringFromResultSet(rs, COLUMN_IPB));
	    entity.setIpB(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIpB(entity.getIpB());
	    //			entity.setConnectionRequestId(getLongFromResultSet(rs, COLUMN_CONNECTIONREQUESTID));
	    entity.setConnectionRequestId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalConnectionRequestId(entity.getConnectionRequestId());
	    //			entity.setConnectionId(getLongFromResultSet(rs, COLUMN_CONNECTIONID));
	    entity.setConnectionId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalConnectionId(entity.getConnectionId());

	    // Single References
	    //			entity.setApplicationId(getLongFromResultSet(rs, COLUMN_APPLICATION_ID));
	    entity.setApplicationId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalApplicationId(entity.getApplicationId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	IPPairEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (IPPairEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new IPPairEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	IPPairEntity entity = (IPPairEntity)obj;
	loadPortsReferenceIds(entity);
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("TIApplicationDAO.loadReferences(): References for IPPairEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("TIApplicationDAO.loadReferences(): Loading references for IPPairEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    IPPairEntity entity = (IPPairEntity)obj;

	    loadPortsReferences(entity);

	    Long applicationId = entity.getApplicationId();
	    if (applicationId != null)
	    {
		//			TIApplicationDAO applicationDAO = new TIApplicationDAO(getSession());
		TIApplicationDAO applicationDAO = getApplicationDAO();
		entity.setApplication((TIApplicationEntity)applicationDAO.get(applicationId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalApplication(entity.getApplication());
	    }

	}
	catch(Exception e)
	{
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for IPPairEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load application with id.
     *
     * @param id the id
     * @return the tI application entity
     * @throws DatabaseException the database exception
     */
    public TIApplicationEntity loadApplicationWithId(Long id) throws DatabaseException
    {
	TIApplicationEntity entity = null;
	if (id != null)
	{
	    //			TIApplicationDAO applicationDAO = new TIApplicationDAO(getSession());
	    TIApplicationDAO applicationDAO = getApplicationDAO();
	    entity = (TIApplicationEntity)applicationDAO.get(id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	IPPairEntity entity = (IPPairEntity) obj;

	setLongToStatement(st, position++, entity.getApplication() != null ? entity.getApplication().getId() : entity.getApplicationId());

	return position;
    }

    // Many Composition 'ports' helpers 'ipPair'
    //======================================================================
    /**
     * Loads all the Port references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadPortsReferences(IPPairEntity entity) throws DatabaseException
    {
	loadPortsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the Port references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadPortsReferences(IPPairEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Ports references for IPPairEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getPorts();
	    List id_list = entity.getOriginalPortsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		PortDAO dao = getPortsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		PortDAO dao = getPortsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Ports references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Ports References for IPPairEntity [" + entity.getId() + "].", e);
	}


	//		entity.setPorts(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Ports references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadPortsReferenceIds(IPPairEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_PORTS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalPortsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Ports Reference IDs from IPPairEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update ports references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updatePortsReferences(IPPairEntity entity) throws DatabaseException
    {
	ManyAssociationList ports = entity.getPorts();
	PortDAO dao = getPortsDAO();

	Iterator itDeleted = ports.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    PortEntity e = (PortEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = ports.iterator();
	while (it.hasNext())
	{
	    PortEntity e = (PortEntity) it.next();
	    e.setIpPair(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'application' helpers 'IPPair' does not need helper

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A PortDAO object 
     */
    protected PortDAO getPortsDAO()
    {
	PortDAO dao = (PortDAO)getSession().getDAO("Port");  
	if(dao == null)
	{
	    dao = new PortDAO(getSession());  		
	    getSession().putDAO("Port", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A TIApplicationDAO object 
     */
    protected TIApplicationDAO getApplicationDAO()
    {
	TIApplicationDAO dao = (TIApplicationDAO)getSession().getDAO("TIApplication");  
	if(dao == null)
	{
	    dao = new TIApplicationDAO(getSession());  		
	    getSession().putDAO("TIApplication", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [Name] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByName(String value) throws DatabaseException
    {
	return findByName(value, getSession());
    }

    /**
     * Find by name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPPairDAO.TABLE + " WHERE " + COLUMN_NAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ResourceId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByResourceId(Long value) throws DatabaseException
    {
	return findByResourceId(value, getSession());
    }

    /**
     * Find by resource id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByResourceId(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPPairDAO.TABLE + " WHERE " + COLUMN_RESOURCEID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [NATAddress] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByNATAddress(String value) throws DatabaseException
    {
	return findByNATAddress(value, getSession());
    }

    /**
     * Find by nat address.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByNATAddress(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPPairDAO.TABLE + " WHERE " + COLUMN_NATADDRESS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IpA] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIpA(String value) throws DatabaseException
    {
	return findByIpA(value, getSession());
    }

    /**
     * Find by ip a.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIpA(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPPairDAO.TABLE + " WHERE " + COLUMN_IPA + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IpB] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIpB(String value) throws DatabaseException
    {
	return findByIpB(value, getSession());
    }

    /**
     * Find by ip b.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIpB(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPPairDAO.TABLE + " WHERE " + COLUMN_IPB + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ConnectionRequestId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByConnectionRequestId(Long value) throws DatabaseException
    {
	return findByConnectionRequestId(value, getSession());
    }

    /**
     * Find by connection request id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByConnectionRequestId(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPPairDAO.TABLE + " WHERE " + COLUMN_CONNECTIONREQUESTID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ConnectionId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByConnectionId(Long value) throws DatabaseException
    {
	return findByConnectionId(value, getSession());
    }

    /**
     * Find by connection id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByConnectionId(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPPairDAO.TABLE + " WHERE " + COLUMN_CONNECTIONID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Application] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByApplication(Long value) throws DatabaseException
    {
	return findByApplication(value, getSession());
    }

    /**
     * Find by application.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByApplication(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + IPPairDAO.TABLE + " WHERE " + COLUMN_APPLICATION_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by Application", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(IPPairEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
