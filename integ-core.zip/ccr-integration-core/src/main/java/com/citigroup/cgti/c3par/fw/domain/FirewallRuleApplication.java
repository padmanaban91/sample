package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.common.domain.Application;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;


/**
 * 
 * @author ne36745
 *
 */
public class FirewallRuleApplication extends Base {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private FireWallRule fireWallRule;
	private TIRequest tiRequest;
    private TIRequest updatedTIRequest;
    private TIRequest deletedTIRequest;
    private Application application;
    private IPAddress ipAddress;
	/**
	 * @return the fireWallRule
	 */
	public FireWallRule getFireWallRule() {
		return fireWallRule;
	}
	/**
	 * @param fireWallRule the fireWallRule to set
	 */
	public void setFireWallRule(FireWallRule fireWallRule) {
		this.fireWallRule = fireWallRule;
	}
	/**
	 * @return the updatedTIRequest
	 */
	public TIRequest getUpdatedTIRequest() {
		return updatedTIRequest;
	}
	/**
	 * @param updatedTIRequest the updatedTIRequest to set
	 */
	public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
		this.updatedTIRequest = updatedTIRequest;
	}
	/**
	 * @return the deletedTIRequest
	 */
	public TIRequest getDeletedTIRequest() {
		return deletedTIRequest;
	}
	/**
	 * @param deletedTIRequest the deletedTIRequest to set
	 */
	public void setDeletedTIRequest(TIRequest deletedTIRequest) {
		this.deletedTIRequest = deletedTIRequest;
	}
	/**
	 * @return the application
	 */
	public Application getApplication() {
		return application;
	}
	/**
	 * @param application the application to set
	 */
	public void setApplication(Application application) {
		this.application = application;
	}
	/**
	 * @return the ipAddress
	 */
	public IPAddress getIpAddress() {
		return ipAddress;
	}
	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(IPAddress ipAddress) {
		this.ipAddress = ipAddress;
	}
	/**
	 * @return the tiRequest
	 */
	public TIRequest getTiRequest() {
		return tiRequest;
	}
	/**
	 * @param tiRequest the tiRequest to set
	 */
	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}
	
}
