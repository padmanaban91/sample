package com.citigroup.cgti.c3par.communication.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.EcmLeadViewPersistable;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;


public class EcmLeadViewProcess {
	  
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
	
	
	private List<String> cmpSectorList;
	private List<CMPRequest> resolveITMessage;
	
	private String orderId;
	private String orderItemId;
	private String status;
	private String step;
	private String sectorId;
	private String availableDate;
	private String closedDate;
	private String orderByUser;
	private String orderBySoeID;
	private String orderForUser;
	private String orderForSoeID;
	private String assignedGroup;
	private String assignedUser;
	private String requestType;
	private String typeofConnectivityInvolved;
	private String id_2;
	private String requestUrgency;
	private String projectSector;
	private String region;
	private String businessjustification;
	private String businessOwner_SOEID;
	private String SecondaryBusinessOwner;
	private String coordinator;
	private String biso;
	private String testerSOEID;
	private String terminationType; 
	private String ccrId;
	private List<String> ecmUsersList = null;  
	private List<String> ecmUsersoeIdList = null;
	private String firstName;
	private String lastName;
	private String soeId;
	private Long userId;
	private String isLocked;
	private String[] assignedUserArr;
	private List itemValueList;
	
	private int limit;
	private int rowCount;
    private int offset;
   
    private int pageNo;
    private String field;
    private int totalPages;
    
    private int recordStartCount;
    private int recordEndCount;
    private int totalRecords;
    
    private String orderBy;
	private String sortingColumnName;
	private String selectedColumnName;
	private String sameColumnSelected;
	
	private List<EcmLeadQueue> teamQueue;
	
	private String comments;
	
	private String leadId;
	
	private String dateForLeadQueue;
	
	private String errorMessage;
	private String searchFrom;
	
	private String[] sloDaysArr;
	private List<GenericLookup> urgencyList;
	private List<String> queueName;
	private List<String> teamQueueSectorList;
	private String teamQueueSectorId;

	public List<String> getQueueName() {
		return queueName;
	}

	public void setQueueName(List<String> queueName) {
		this.queueName = queueName;
	}

	public EcmLeadViewProcess(){
		
	}
	
	public EcmLeadViewProcess(String soeId,String lasName,String firstName, String isLocked, String comments){
		super();
		this.soeId = soeId;
		this.lastName = lasName;
		this.firstName = firstName;
		this.isLocked = isLocked;
		this.comments = comments;
	}
	
	
	
	public List<GenericLookup> getUrgencyList() {
		return urgencyList;
	}

	public void setUrgencyList(List<GenericLookup> urgencyList) {
		this.urgencyList = urgencyList;
	}

	public AdminServicePersistable getAdminServicePersistable() {
		return ccrBeanFactory.getAdminServicePersistable();
	}

	/*public void setAdminServicePersistable(	AdminServicePersistable adminServicePersistable) {
		this.adminServicePersistable = adminServicePersistable;
	}*/


	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getSortingColumnName() {
		return sortingColumnName;
	}

	public void setSortingColumnName(String sortingColumnName) {
		this.sortingColumnName = sortingColumnName;
	}
	

	public String getSelectedColumnName() {
		return selectedColumnName;
	}

	public void setSelectedColumnName(String selectedColumnName) {
		this.selectedColumnName = selectedColumnName;
	}

	public String getSameColumnSelected() {
		return sameColumnSelected;
	}

	public void setSameColumnSelected(String sameColumnSelected) {
		this.sameColumnSelected = sameColumnSelected;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getRecordStartCount() {
		return recordStartCount;
	}

	public void setRecordStartCount(int recordStartCount) {
		this.recordStartCount = recordStartCount;
	}

	public int getRecordEndCount() {
		return recordEndCount;
	}

	public void setRecordEndCount(int recordEndCount) {
		this.recordEndCount = recordEndCount;
	}

	public int getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}

	public List getItemValueList() {
		return itemValueList;
	}

	public void setItemValueList(List itemValueList) {
		this.itemValueList = itemValueList;
	}

	public String[] getAssignedUserArr() {
		return assignedUserArr;
	}
	public void setAssignedUserArr(String[] assignedUserArr) {
		this.assignedUserArr = assignedUserArr;
	}
	public List<String> getEcmUsersoeIdList() {
		return ecmUsersoeIdList;
	}
	public void setEcmUsersoeIdList(List<String> ecmUsersoeIdList) {
		this.ecmUsersoeIdList = ecmUsersoeIdList;
	}
	public String getStatus() {
		return status;
	}
	public String getClosedDate() {
		return closedDate;
	}
	public String getOrderByUser() {
		return orderByUser;
	}
	public String getOrderForUser() {
		return orderForUser;
	}
	public String getCcrId() {
		return ccrId;
	}
	public void setCcrId(String ccrId) {
		this.ccrId = ccrId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSoeId() {
		return soeId;
	}
	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}
	public void setOrderByUser(String orderByUser) {
		this.orderByUser = orderByUser;
	}
	public void setOrderForUser(String orderForUser) {
		this.orderForUser = orderForUser;
	}
	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the orderItemId
	 */
	public String getOrderItemId() {
		return orderItemId;
	}
	/**
	 * @param orderItemId the orderItemId to set
	 */
	public void setOrderItemId(String orderItemId) {
		this.orderItemId = orderItemId;
	}
	
	/**
	 * @return the step
	 */
	public String getStep() {
		return step;
	}
	/**
	 * @param step the step to set
	 */
	public void setStep(String step) {
		this.step = step;
	}
	/**
	 * @return the availableDate
	 */
	public String getAvailableDate() {
		return availableDate;
	}
	/**
	 * @param availableDate the availableDate to set
	 */
	public void setAvailableDate(String availableDate) {
		this.availableDate = availableDate;
	}
	
	/**
	 * @return the orderBySoeID
	 */
	public String getOrderBySoeID() {
		return orderBySoeID;
	}
	/**
	 * @param orderBySoeID the orderBySoeID to set
	 */
	public void setOrderBySoeID(String orderBySoeID) {
		this.orderBySoeID = orderBySoeID;
	}
	
	/**
	 * @return the orderForSoeID
	 */
	public String getOrderForSoeID() {
		return orderForSoeID;
	}
	/**
	 * @param orderForSoeID the orderForSoeID to set
	 */
	public void setOrderForSoeID(String orderForSoeID) {
		this.orderForSoeID = orderForSoeID;
	}
	/**
	 * @return the assignedGroup
	 */
	public String getAssignedGroup() {
		return assignedGroup;
	}
	/**
	 * @param assignedGroup the assignedGroup to set
	 */
	public void setAssignedGroup(String assignedGroup) {
		this.assignedGroup = assignedGroup;
	}
	/**
	 * @return the assignedUser
	 */
	public String getAssignedUser() {
		return assignedUser;
	}
	/**
	 * @param assignedUser the assignedUser to set
	 */
	public void setAssignedUser(String assignedUser) {
		this.assignedUser = assignedUser;
	}
	/**
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}
	
	/**
	 * @return the cmpSectorList
	 */
	public List<String> getCmpSectorList() {
		return cmpSectorList;
	}

	/**
	 * @param cmpSectorList the cmpSectorList to set
	 */
	public void setCmpSectorList(List<String> cmpSectorList) {
		this.cmpSectorList = cmpSectorList;
	}

	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	/**
	 * @return the typeofConnectivityInvolved
	 */
	public String getTypeofConnectivityInvolved() {
		return typeofConnectivityInvolved;
	}
	/**
	 * @param typeofConnectivityInvolved the typeofConnectivityInvolved to set
	 */
	public void setTypeofConnectivityInvolved(String typeofConnectivityInvolved) {
		this.typeofConnectivityInvolved = typeofConnectivityInvolved;
	}
	/**
	 * @return the id_2
	 */
	public String getId_2() {
		return id_2;
	}
	/**
	 * @param id_2 the id_2 to set
	 */
	public void setId_2(String id_2) {
		this.id_2 = id_2;
	}
	/**
	 * @return the requestUrgency
	 */
	public String getRequestUrgency() {
		return requestUrgency;
	}
	/**
	 * @param requestUrgency the requestUrgency to set
	 */
	public void setRequestUrgency(String requestUrgency) {
		this.requestUrgency = requestUrgency;
	}
	/**
	 * @return the projectSector
	 */
	public String getProjectSector() {
		return projectSector;
	}
	/**
	 * @param projectSector the projectSector to set
	 */
	public void setProjectSector(String projectSector) {
		this.projectSector = projectSector;
	}
	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return the businessjustification
	 */
	public String getBusinessjustification() {
		return businessjustification;
	}
	/**
	 * @param businessjustification the businessjustification to set
	 */
	public void setBusinessjustification(String businessjustification) {
		this.businessjustification = businessjustification;
	}
	/**
	 * @return the businessOwner_SOEID
	 */
	public String getBusinessOwner_SOEID() {
		return businessOwner_SOEID;
	}
	/**
	 * @param businessOwner_SOEID the businessOwner_SOEID to set
	 */
	public void setBusinessOwner_SOEID(String businessOwner_SOEID) {
		this.businessOwner_SOEID = businessOwner_SOEID;
	}
	/**
	 * @return the secondaryBusinessOwner
	 */
	public String getSecondaryBusinessOwner() {
		return SecondaryBusinessOwner;
	}
	/**
	 * @param secondaryBusinessOwner the secondaryBusinessOwner to set
	 */
	public void setSecondaryBusinessOwner(String secondaryBusinessOwner) {
		SecondaryBusinessOwner = secondaryBusinessOwner;
	}
	/**
	 * @return the coordinator
	 */
	public String getCoordinator() {
		return coordinator;
	}
	/**
	 * @param coordinator the coordinator to set
	 */
	public void setCoordinator(String coordinator) {
		this.coordinator = coordinator;
	}
	/**
	 * @return the biso
	 */
	public String getBiso() {
		return biso;
	}
	/**
	 * @param biso the biso to set
	 */
	public void setBiso(String biso) {
		this.biso = biso;
	}
	/**
	 * @return the testerSOEID
	 */
	public String getTesterSOEID() {
		return testerSOEID;
	}
	
	/**
	 * @return the sectorId
	 */
	public String getSectorId() {
		return sectorId;
	}

	/**
	 * @param sectorId the sectorId to set
	 */
	public void setSectorId(String sectorId) {
		this.sectorId = sectorId;
	}

	/**
	 * @param testerSOEID the testerSOEID to set
	 */
	public void setTesterSOEID(String testerSOEID) {
		this.testerSOEID = testerSOEID;
	}
	/**
	 * @return the terminationType
	 */
	public String getTerminationType() {
		return terminationType;
	}
	/**
	 * @param terminationType the terminationType to set
	 */
	public void setTerminationType(String terminationType) {
		this.terminationType = terminationType;
	}
		
	public EcmLeadViewPersistable getResolveITFieldPersistable() {
		return ccrBeanFactory.getResolveITFieldPersistable();
	}
	public List<String> getEcmUsersList() {
		return ecmUsersList;
	}
	public void setEcmUsersList(List<String> ecmUsersList) {
		this.ecmUsersList = ecmUsersList;
	}
	public List<CMPRequest> getResolveITMessage() {
		return resolveITMessage;
	}
	public void setResolveITMessage(List<CMPRequest> resolveITMessage) {
		this.resolveITMessage = resolveITMessage;
	}
	
	
	public Long getUserId(String ssoId){
		return ccrBeanFactory.getAdminServicePersistable().getUserId(ssoId);
	}
		
	
	public List<CMPRequest>  selectLeadDetails(EcmLeadViewProcess ecmLeadViewProcess,String secId) { 
		List<CMPRequest> resolveITMessage = ccrBeanFactory.getResolveITFieldPersistable().selectLeadDetails(this,secId);
		return  resolveITMessage;
	}
	
	 
	

	public boolean updateAssignedEcmUser(String cmpReqId, String AssignTo,Long sloDays,String userId,String leadComments) {  
		boolean assignedSuccess =ccrBeanFactory.getResolveITFieldPersistable().updateAssignedEcmUser(cmpReqId,AssignTo,sloDays,userId,leadComments);
		return  assignedSuccess;  
	}
	
	
	public List<EcmLeadQueue> getAgentListForSector(String soeId2) {
		return ccrBeanFactory.getResolveITFieldPersistable().getAgentListForSector(soeId2);
	}
	
	public List<String> getSupportTeamUsersList(String soeIds){
		return ccrBeanFactory.getResolveITFieldPersistable().getSupportTeamUsersList(soeIds);
	}
	

	public List<EcmLeadQueue> getTeamQueue() {
		return teamQueue;
	}

	public void setTeamQueue(List<EcmLeadQueue> teamQueue) {
		this.teamQueue = teamQueue;
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void addAgentToDoNotAssign(EcmLeadViewProcess ecmLeadViewProcess) {
		ccrBeanFactory.getResolveITFieldPersistable().addAgentToDoNotAssign(ecmLeadViewProcess);
		
	}
	

	
	public List<CmpConnectionDetail> getProcessList(String ccrId) {
		return ccrBeanFactory.getResolveITFieldPersistable().getProcessList(ccrId);
	}

	
	public CitiContact getCitiContactDetails(String ssoId) {
		return ccrBeanFactory.getCmpRequestPersistable().getUserIdForSsoId(ssoId);
	}
	
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments; 
	}

	public String getLeadId() {
		return leadId;
	}

	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}

	public String getDateForLeadQueue() {
		return dateForLeadQueue;
	} 
 
	public void setDateForLeadQueue(String dateForLeadQueue) {
		this.dateForLeadQueue = dateForLeadQueue;
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public String getdateForHeader() {
		return ccrBeanFactory.getResolveITFieldPersistable().getdateForHeader();
	}

	public String getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(String isLocked) {
		this.isLocked = isLocked;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String[] getSloDaysArr() {
		return sloDaysArr;
	}

	public void setSloDaysArr(String[] sloDaysArr) {
		this.sloDaysArr = sloDaysArr;
	}
	
	/**
	 * @return the searchFrom
	 */
	public String getSearchFrom() {
		return searchFrom;
	}

	/**
	 * @param searchFrom the searchFrom to set
	 */
	public void setSearchFrom(String searchFrom) {
		this.searchFrom = searchFrom;
	}

	
	public CMPRequest getCMPRequestDetails(String cmpReqId){
		
		return  ccrBeanFactory.getResolveITFieldPersistable().getCMPRequestDetails(cmpReqId);
	}
	
	
	public boolean checkValidUser(String ssoid){		
		return  ccrBeanFactory.getResolveITFieldPersistable().checkValidUser(ssoid);
	}
	
	
	public C3parUser retrieveC3parUser(String ssoId) {
		return ccrBeanFactory.getAdminServicePersistable().retrieveC3parUser(ssoId);
	}
	
	
	public List<GenericLookup> loadGenericLookupByName(String name) {
		return ccrBeanFactory.getCommonServicePersistable().getGenericLookupByName(name);
	}
	
	
	public List<String> loadCmpSectorList() {
		return ccrBeanFactory.getResolveITFieldPersistable().getCMPSectorList();
	}

	public List<String> getTeamQueueSectorList() {
		return teamQueueSectorList;
	}

	public void setTeamQueueSectorList(List<String> teamQueueSectorList) {
		this.teamQueueSectorList = teamQueueSectorList;
	}

	public String getTeamQueueSectorId() {
		return teamQueueSectorId;
	}

	public void setTeamQueueSectorId(String teamQueueSectorId) {
		this.teamQueueSectorId = teamQueueSectorId;
	}
	
}
