package com.citigroup.cgti.c3par.bpm.ejb.search;


/**
 * The Interface ServiceNowQueueSender.
 */
public interface ServiceNowQueueSender {
	
	public void sendMesage(String message);
}
