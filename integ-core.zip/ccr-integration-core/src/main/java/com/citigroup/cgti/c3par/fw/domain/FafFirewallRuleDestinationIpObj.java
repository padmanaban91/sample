/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

/**
 * @author bs45969
 *
 */
public class FafFirewallRuleDestinationIpObj extends FafFirewallRuleIpObj {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public FafFirewallRuleDestinationIpObj() {
	setCreated_date(new Date());
    }

}
