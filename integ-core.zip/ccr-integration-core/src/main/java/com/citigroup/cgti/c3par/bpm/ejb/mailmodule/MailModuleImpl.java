package com.citigroup.cgti.c3par.bpm.ejb.mailmodule;


import static com.citigroup.cgti.c3par.util.C3parProperties.C3PAR_BASE_URL;
import static com.citigroup.cgti.c3par.util.C3parProperties.WORKITEM_PARTIAL_URL;
import static com.citigroup.cgti.c3par.util.C3parProperties.BPM_HOST;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.swing.InputVerifier;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import org.springframework.core.io.InputStreamSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.C3PARUserDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessUtil;
import com.citigroup.cgti.c3par.bpm.ejb.useradmin.GDWUser;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.AccessFormText;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.CMPRequestPersistable;
import com.citigroup.cgti.c3par.domain.ACVSummaryEmailUserVO;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.AuditTrailDetailEmailVO;
import com.citigroup.cgti.c3par.domain.BaseMailVO;
import com.citigroup.cgti.c3par.domain.C3PARMailMessage;
import com.citigroup.cgti.c3par.domain.C3PARUser;
import com.citigroup.cgti.c3par.domain.ConnectionDetailEmailVO;
import com.citigroup.cgti.c3par.domain.DateDetailEmailVO;
import com.citigroup.cgti.c3par.domain.EntitlementInputMailVO;
import com.citigroup.cgti.c3par.domain.FirewallDetailEmailVO;
import com.citigroup.cgti.c3par.domain.InputMailVO;
import com.citigroup.cgti.c3par.domain.MailMsgDisplayInfo;
import com.citigroup.cgti.c3par.domain.MailMsgDisplayRow;
import com.citigroup.cgti.c3par.domain.MailTemplates;
import com.citigroup.cgti.c3par.domain.RecepientInfo;
import com.citigroup.cgti.c3par.domain.SupervisorEmail;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.domain.TargetContactEmail;
import com.citigroup.cgti.c3par.oneapproval.OneApprovalPersistable;
import com.citigroup.cgti.c3par.snByPass.domain.SnowByPassDTO;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;
import com.citigroup.cgti.c3par.util.C3parProperties;
import com.citigroup.cgti.c3par.webtier.forms.helper.GDIRConnectorHelper;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;



/**
 * The Class MailModuleImpl.
 */
@SuppressWarnings("unchecked")
public class MailModuleImpl implements IMailModule,MailModuleConstants {
	
	private Logger log = Logger.getLogger(MailModuleImpl.class);

	private ManageTIProcessUtil  manageTIProcessUtil;

	private String templateFileLocation;

	private String testMode;

	private String testEmail;

	private JavaMailSenderImpl mailSender;
	 
	private JdbcTemplate jdbcTemplate;
	
	private MailModuleUtil mailModuleUtil;
	
	private String ccrEntCmpUrl;
	
	private String mailTemplates;
	
	private AccessFormText accessFormTextGenerator;
	
	private String environment;	
	
	private CMPRequestPersistable cmpRequestPersistable;	
	
	private OneApprovalPersistable oneApprovalImpl;

	private CommonServicePersistable commonServicePersistable;

	private String ccrUrl;	

	private static final int MLS = (24 * 60 * 60 * 1000);	
	
	private Document doc;
	
	public String getCcrUrl() {
		return ccrUrl;
	}

	public void setCcrUrl(String ccrUrl) {
		this.ccrUrl = ccrUrl;
	}

	public CMPRequestPersistable getCmpRequestPersistable() {
		return cmpRequestPersistable;
	}

	public void setCmpRequestPersistable(CMPRequestPersistable cmpRequestPersistable) {
		this.cmpRequestPersistable = cmpRequestPersistable;
	}

	public OneApprovalPersistable getOneApprovalImpl() {
		return oneApprovalImpl;
	}

	public void setOneApprovalImpl(OneApprovalPersistable oneApprovalImpl) {
		this.oneApprovalImpl = oneApprovalImpl;
	}

	public CommonServicePersistable getCommonServicePersistable() {
		return commonServicePersistable;
	}

	public void setCommonServicePersistable(
			CommonServicePersistable commonServicePersistable) {
		this.commonServicePersistable = commonServicePersistable;
	}

	public void sendWorkItemNotification(long requestID, String activityCode, String activityStatus, String activityRole) throws Exception {

		TIProcess tiProcess = null;
		InputMailVO inputMailVO = new InputMailVO();
		C3PARMailMessage mailMsg = new C3PARMailMessage();
		String tempActivityCode = null;
		String templatId = null;
		//MailModuleUtil mmUtil = new MailModuleUtil(); // Junit

		log.debug("MailModuleImpl:sendWorkItemNotification: Entered with values:: requestID:"+requestID+" activityName:"+activityCode+" activityStatus"+activityStatus);
		try{
			inputMailVO.setTirequestID(requestID);
			if (activityCode.equals(APSE_SCHEDULE_USER_NOTIFICATION)) {
				tempActivityCode = activityCode;
				activityCode = APPSENSE_APPROVAL;
			} else if (activityCode.equals(PRXY_SCHEDULE_USER_NOTIFICATION)) {
				tempActivityCode = activityCode;
				activityCode = PROXY_APPROVAL;
			} else if (activityCode.equals(OA_SCHEDULE_USER_NOTIFICATION)) {
				tempActivityCode = activityCode;
				activityCode = OPERATIONAL_IMPLEMENTATION;
			} else if (activityCode.equals(TPWG_REVIEW_USER_NOTIFICATION)) {
				tempActivityCode = activityCode;
				activityCode = TPWG_APPROVAL;
			} else if (activityCode.equals(GNCC_SCHEDULE_USER_NOTIFICATION)) {
				tempActivityCode = activityCode;
				activityCode = GNCC_APPROVAL;
			}
			tiProcess = manageTIProcessUtil.getProcessData(requestID, activityCode, "");
			if (tempActivityCode != null) {
				activityCode = tempActivityCode;
				tempActivityCode = null;
			}
			if (tiProcess.getId() == null || tiProcess.getId().longValue() == 0) {
				tiProcess = manageTIProcessUtil.getProcessData(requestID);
			}
			String relationshipType="";
			if(tiProcess != null){
				//tiProcess.getRelationship().setRelationshipType("template");
				relationshipType = tiProcess.getRelationship().getRelationshipType();
			}			
			if (tiProcess != null){
				inputMailVO.setTiProcess(tiProcess);
				if(tiProcess.getId()!=null){
					inputMailVO.setConnectionId((tiProcess.getId()).longValue()+"");
				}
				if(PROVIDE_INFO.equalsIgnoreCase(activityStatus)){
					inputMailVO.setMailSubject(" - Information Updated");
				}
				if (tiProcess.getTiRequest() != null) {
					TIRequest req = (TIRequest) tiProcess.getTiRequest();
					if (req.getActivityData() != null) {
						ActivityData acdt = req.getActivityData();
						if (acdt.getEncodedAlbpmActivity() != null && !"".equals(acdt.getEncodedAlbpmActivity())) {
							//inputMailVO.setWorkItemUrl("https://c3par.nj.ssmb.com"); //For JUnit
							String workItemUrl = BPM_HOST;/* + WORKITEM_PARTIAL_URL + acdt.getEncodedAlbpmActivity();*/
							inputMailVO.setWorkItemUrl(workItemUrl);
						} else {
							inputMailVO.setWorkItemUrl(BPM_HOST);
						}
					} else {
						inputMailVO.setWorkItemUrl(BPM_HOST);
					}
				} else {
					inputMailVO.setWorkItemUrl(BPM_HOST);
				}
			}
			if(tiProcess != null && tiProcess.getTiRequest() != null && tiProcess.getTiRequest().getId() != null ){
				inputMailVO.setLastSubmitterComments(mailModuleUtil.getLastSubmitterComments(tiProcess.getTiRequest().getId()));
				inputMailVO.setLastSubmitterRole(mailModuleUtil.getLastSubmitterRole(tiProcess.getTiRequest().getId()));
			}
			//Retrieve CMP ID/SERVICENOW ID from last cycle
			if(activityCode != null && activityCode.equalsIgnoreCase(VERIFY_SOW)){
				String cmpIDSNowID = manageTIProcessUtil.getLastCmpServiceNowID(tiProcess.getId());
				if (tiProcess != null) {
					if(tiProcess.getTiRequest().getActivityData() != null){
						tiProcess.getTiRequest().setCmpId(cmpIDSNowID);
					}
				}					
			}
			if(activityCode.equals(PRO_INF)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(BUSINESS_JUSTIFICATION, inputMailVO, true);
			} else if (activityCode.equals(PROVIDEINFO1_DE)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(TECHNICAL_ARCHITECTURE, inputMailVO, true);
				//--sending mail for template when it it comes to technical architecture.
			} else if (activityCode.equals(PROVIDEINFO2_ISO)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(ISO_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(PROVIDEINFO3_TPW)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(TPWG_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(PROVIDEINFO4_IST)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(ISTG_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(PROVIDEINFO5_OPE)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(OPERATIONAL_IMPLEMENTATION, inputMailVO, true);
			} else if (activityCode.equals(PROVIDEINFO6_SE)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(SEC_ENG_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(PROVIDEINFO7_BUMGR)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(MANAGER_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(PROVIDEINFO8_APSE)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(APPSENSE_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(PROVIDEINFO9_PRXY)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(PROXY_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(PROVIDEINF_OTRM)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(OTRM_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(PROVIDEINFO10_GNCC)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(GNCC_APPROVAL, inputMailVO, true);
			}else if (activityCode.equals(PROVIDEINF_MAD)){
				inputMailVO.setMailSubject(" - Provide Info Notification");
				mailMsg = this.parseTemplateNew(MAD_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(TPWG_RETRO_APP)){
				mailMsg = this.parseTemplateNew(TPWG_REVIEW_USER_NOTIFICATION, inputMailVO, true);
				sendMail(mailMsg,mailModuleUtil.testModeFlag(tiProcess.getId(),mailModuleUtil.testModeFlag(tiProcess.getId(),testMode)));
				mailMsg = this.parseTemplateNew(TPWG_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(OTRM_RETRO_APP)){
				mailMsg = this.parseTemplateNew(OTRM_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(MAD_RETRO_APP)){ 
				mailMsg = this.parseTemplateNew(MAD_APPROVAL, inputMailVO, true);
			} else if (activityCode.equals(FIX_CONNECTIVITY)){
				mailMsg = this.parseTemplateNew(OPERATIONAL_IMPLEMENTATION, inputMailVO, true);
			} else if (activityCode.equals(ROLLBACK_FW_IMPLEMENTATION)){
				mailMsg = this.parseTemplateNew(OPERATIONAL_IMPLEMENTATION, inputMailVO, true);
			} else if (activityCode.equals(HANDLE_RFC_EXC)){
				mailMsg = this.parseTemplateNew(HANDLE_RFC_EXC, inputMailVO, true);
			} else if (activityCode.equals(TPWG_APPROVAL)){
				mailMsg = this.parseTemplateNew(TPWG_REVIEW_USER_NOTIFICATION, inputMailVO, true);
				sendMail(mailMsg,mailModuleUtil.testModeFlag(tiProcess.getId(),mailModuleUtil.testModeFlag(tiProcess.getId(),testMode)));
				mailMsg = this.parseTemplateNew(TPWG_APPROVAL, inputMailVO, true);
			}else if (activityCode.equals(REQUEST_VALIDATION)){
				//MailModuleUtil mmUtil1 = new MailModuleUtil();
				inputMailVO.setImplementationResults(mailModuleUtil.getImplementationResults(tiProcess.getId()+""));
				mailMsg = this.parseTemplateNew(REQUEST_VALIDATION, inputMailVO, true);
			} else if(activityCode.equals(APPROVAL_EXPIRATION) ||
					activityCode.equals(IMPLEMENTATION_EXPIRATION) ||
					activityCode.equals(INCOMPLETE_EXPIRATION) ||
					activityCode.equals(ACV_EXPIRATION) ||
					activityCode.equals(ACTIVATION_EXPIRATION) ) {
				//MailModuleUtil mmUtil1 = new MailModuleUtil();
				inputMailVO.setImplementationResults(mailModuleUtil.getImplementationResults(tiProcess.getId()+""));
				mailMsg = this.parseTemplateNew(SYSADMIN_EXPIRED_EMAIL, inputMailVO, true);
			} else if(activityCode.equals(TEMPAPPROVAL_EXPIRATION) || activityCode.equals(RECONCILE_EXPIRATION)){
				//MailModuleUtil mmUtil1 = new MailModuleUtil();
				inputMailVO.setImplementationResults(mailModuleUtil.getImplementationResults(tiProcess.getId()+""));
				mailMsg = this.parseTemplateNew(OTRM_EXPIRED_EMAIL, inputMailVO, true);
			} else if(activityCode.equalsIgnoreCase(ActivityDataDTO.FW_BY_PASS_SERVICE_NOW) || activityCode.equalsIgnoreCase(ActivityDataDTO.PROXY_BY_PASS_SERVICE_NOW))
			{
				if(activityCode.equalsIgnoreCase(ActivityDataDTO.FW_BY_PASS_SERVICE_NOW))
					templatId = "FIREWALL_SNOW_BYPASS_IMPL";
				else
					templatId = "PROXY_SNOW_BYPASS_IMPL";
				log.info("MailModuleImpl.sendWorkItemNotification():Activity::"+ActivityDataDTO.FW_BY_PASS_SERVICE_NOW+":templatId::"+templatId);
			} else {
				String preOwner = mailModuleUtil.getTemplateConnPreOwner(inputMailVO);
				log.debug("MailModuleImpl.sendWorkItemNotification():The activity code value is : "+activityCode);
				if(preOwner != null && !preOwner.isEmpty() && relationshipType != null 
						&& (relationshipType.trim().equalsIgnoreCase(TEMPLATE)||relationshipType.trim().equalsIgnoreCase(IP_TEMPLATE)||relationshipType.trim().equalsIgnoreCase(PORT_TEMPLATE)) 
						&& activityCode.equalsIgnoreCase(BUSINESS_JUSTIFICATION)){
					Map<String,String> templateDetls = mailModuleUtil.getTmpltUsedConnIdsAndNames(inputMailVO.getTiProcess().getTiRequest().getId(),relationshipType.trim());
					inputMailVO.getTiProcess().setTemplateConIds(templateDetls.get("CONN_IDS"));
					inputMailVO.getTiProcess().setTemplateConNames(templateDetls.get("CONN_NAMES"));
					log.debug("MailModuleImpl.sendWorkItemNotification():MailMessage::Before Parse");
					sendMail(this.parseTemplateNew(TEMPLATE_MAIL_B4_MANITENENCE, inputMailVO, true),mailModuleUtil.testModeFlag(tiProcess.getId(),testMode));
					log.debug("MailModuleImpl.sendWorkItemNotification():MailMessage::Successfully sent");
					return;
				}
				if(relationshipType != null && (relationshipType.trim().equalsIgnoreCase(TEMPLATE)||relationshipType.trim().equalsIgnoreCase(IP_TEMPLATE)||relationshipType.trim().equalsIgnoreCase(PORT_TEMPLATE))
						&& activityCode.equalsIgnoreCase(OPERATIONAL_IMPLEMENTATION)){
					Map<String,String> templateDetls = mailModuleUtil.getTmpltUsedConnIdsAndNames(inputMailVO.getTiProcess().getTiRequest().getId(),relationshipType.trim());
					inputMailVO.getTiProcess().setTemplateConIds(templateDetls.get("CONN_IDS"));
					inputMailVO.getTiProcess().setTemplateConNames(templateDetls.get("CONN_NAMES"));
					log.debug("MailModuleImpl.sendWorkItemNotification():MailMessage::Before Parse");
					sendMail(this.parseTemplateNew(TEMPLATE_MAIL_B4_FW_IMPL, inputMailVO, true),mailModuleUtil.testModeFlag(tiProcess.getId(),testMode));
					log.debug("MailModuleImpl.sendWorkItemNotification():MailMessage::Successfully sent");
					return;
				}
				String referenceNo = null;
				if (activityCode.equalsIgnoreCase(ISO_APPROVAL)) {
					log.debug("Setting the Approve and Reject URL for ISO");
					referenceNo = UUID.randomUUID().toString();
					oneApprovalImpl.createOneApproval(Long.valueOf(tiProcess.getId()),tiProcess.getTiRequest().getId(),
							referenceNo,Long.valueOf(tiProcess.getTiRequest().getVersionNumber()),OneApprovalConstants.ACTIVITY_ISO, false);
					inputMailVO.setApproveURL(getMailToEncodedString(environment,inputMailVO.getConnectionId(), tiProcess.getTiRequest().getVersionNumber(), OneApprovalConstants.ACTIVITY_ISO, false, referenceNo));
					inputMailVO.setRejectURL(getMailToEncodedString(environment,inputMailVO.getConnectionId(), tiProcess.getTiRequest().getVersionNumber(), OneApprovalConstants.ACTIVITY_ISO, true, referenceNo));
				} /*else if (activityCode.equalsIgnoreCase(OTRM_APPROVAL)) {
					log.debug("Setting the Approve and Reject URL for OTRM");
					referenceNo = UUID.randomUUID().toString();
					oneApprovalImpl.createOneApproval(Long.valueOf(tiProcess.getId()),tiProcess.getTiRequest().getId(),
							referenceNo,Long.valueOf(tiProcess.getTiRequest().getVersionNumber()),OneApprovalConstants.ACTIVITY_GIS, false);
					inputMailVO.setApproveURL(getMailToEncodedString(environment,inputMailVO.getConnectionId(), tiProcess.getTiRequest().getVersionNumber(), OneApprovalConstants.ACTIVITY_GIS, false, referenceNo));
					inputMailVO.setRejectURL(getMailToEncodedString(environment,inputMailVO.getConnectionId(), tiProcess.getTiRequest().getVersionNumber(), OneApprovalConstants.ACTIVITY_GIS, true, referenceNo));
				}*/ else if (activityCode.equalsIgnoreCase(VERIFY_SOW)) {
					log.debug("Setting the Approve and Reject URL for ACV");
					referenceNo = UUID.randomUUID().toString();
					try{
					oneApprovalImpl.createOneApproval(Long.valueOf(tiProcess.getId()),tiProcess.getTiRequest().getId(),
							referenceNo,Long.valueOf(tiProcess.getTiRequest().getVersionNumber()),OneApprovalConstants.ACTIVITY_ACV, false);
					} catch (Exception e) {
                        log.error("Exception caught while calling createOneApproval in VERIFY_SOW: "+ e.toString(), e);
					}					
					inputMailVO.setApproveURL(getMailToEncodedString(environment,inputMailVO.getConnectionId(), tiProcess.getTiRequest().getVersionNumber(), OneApprovalConstants.ACTIVITY_ACV, false, referenceNo));
				} else if (activityCode.equalsIgnoreCase(MANAGER_APPROVAL)) {
					log.debug("Setting the Approve and Reject URL for BMA Approval");
					referenceNo = UUID.randomUUID().toString();
					//oneApprovalImpl.createOneApproval(Long.valueOf(tiProcess.getId()),tiProcess.getTiRequest().getId(),
						//	referenceNo,Long.valueOf(tiProcess.getTiRequest().getVersionNumber()),OneApprovalConstants.ACTIVITY_BMA, false);
					inputMailVO.setApproveURL(getMailToEncodedString(environment,inputMailVO.getConnectionId(), tiProcess.getTiRequest().getVersionNumber(), OneApprovalConstants.ACTIVITY_BMA, false, referenceNo));
					inputMailVO.setRejectURL(getMailToEncodedString(environment,inputMailVO.getConnectionId(), tiProcess.getTiRequest().getVersionNumber(), OneApprovalConstants.ACTIVITY_BMA, true, referenceNo));
				}

				mailMsg = this.parseTemplateNew(activityCode, inputMailVO, true);
				mailMsg.setReferenceNo(referenceNo);
				
				//Modified for task 43752-starts
				try{
					if (activityCode.equalsIgnoreCase(MANAGER_APPROVAL) || activityCode.equalsIgnoreCase(ISO_APPROVAL) || activityCode.equalsIgnoreCase(OTRM_APPROVAL)) {
						mailMsg.setAttachments(accessFormTextGenerator.getAttachments(tiProcess.getTiRequest().getId(), tiProcess.getId(), Long.valueOf(tiProcess.getTiRequest().getVersionNumber()),"N"));
					}else if(activityCode.equalsIgnoreCase(VERIFY_SOW)){
						log.debug("into verify sow");
						mailMsg.setAttachments(accessFormTextGenerator.getAttachments(tiProcess.getTiRequest().getId(), tiProcess.getId(), Long.valueOf(tiProcess.getTiRequest().getVersionNumber()),"Y"));
					}
				} catch (Exception e) {
                    log.error("Exception caught while setting attachments in mailMsg: "+ e.toString(), e);
				}	
				//Modified for task 43752-ends
			}			
			
			if(activityCode.equalsIgnoreCase(ActivityDataDTO.FW_BY_PASS_SERVICE_NOW) || activityCode.equalsIgnoreCase(ActivityDataDTO.PROXY_BY_PASS_SERVICE_NOW))
			{	
				log.info("Before Calling sendSNByPassImplEmailGen!");
				sendSNByPassImplEmailGen(templatId, tiProcess);
			}
			else
			{
				log.info("Before Calling sendMail!");
				sendMail(mailMsg,mailModuleUtil.testModeFlag(tiProcess.getId(),mailModuleUtil.testModeFlag(tiProcess.getId(),testMode)));
			}
			
		} catch(Exception e){
			log.error("Exception in sending Mail for activity::"+activityCode+"::"+e.getMessage(),  e);
			try{
				mailMsg = this.parseTemplateNew(REDIRECTION_EMAIL, inputMailVO, false);
				sendMail(mailMsg,mailModuleUtil.testModeFlag(tiProcess.getId(),mailModuleUtil.testModeFlag(tiProcess.getId(),testMode)));
			} catch (Exception ex){
				log.error("Exception in sending RedirectionMail::"+e.getMessage(),  ex);
				ex.printStackTrace();
			}
		}
	}
	
	//To Form the Mailto href for Contacts Rejects
	/**
	 * 
	 * @param environment
	 * @param connectionID
	 * @param versionNumber
	 * @param activity
	 * @param referenceNo
	 * @return
	 */
	private String getMailToEncodedString_1(String environment, Long connectionID, int versionNumber, String activity, String referenceNo) {
			return "mailto:ccrnotifications@imcnam.ssmb.com?subject="+environment+"%3A"+connectionID+"%2E"+versionNumber+"%3A"+activity+"%3ARejectResponsibility&body=REF%3A"+referenceNo+"%0D" +
					"%3CPlease%20do%20not%20alter%20the%20mail%20subject%20and%20first%20two%20lines%20of%20mail%20content%20and%20enter%20the%20comments%20below:%3E";
	}
	
	//To Form the Mailto href for Email Approvals/Rejects
	/**
	 * 
	 * @param environment
	 * @param connectionID
	 * @param versionNumber
	 * @param activity
	 * @param reject
	 * @param referenceNo
	 * @return
	 */
	private String getMailToEncodedString(String environment, String connectionID, int versionNumber, String activity, boolean reject, String referenceNo) {
		if (reject) {
			return "mailto:ccrnotifications@imcnam.ssmb.com?subject="+environment+"%3A"+connectionID+"%2E"+versionNumber+"%3A"+activity+"%3AReject&body=REF%3A"+referenceNo+"%0D" +
			"%3CPlease%20do%20not%20alter%20the%20mail%20subject%20and%20first%20two%20lines%20of%20mail%20content%20and%20enter%20the%20comments%20below:%3E";
		} else 
			return "mailto:ccrnotifications@imcnam.ssmb.com?subject="+environment+"%3A"+connectionID+"%2E"+versionNumber+"%3A"+activity+"%3AApprove&body=REF%3A"+referenceNo+"%0D" +
			"%3CPlease%20do%20not%20alter%20the%20mail%20subject%20and%20first%20two%20lines%20of%20mail%20content%20and%20enter%20the%20comments%20below:%3E";
	}
	
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendEntitlementNotification(com.citigroup.cgti.c3par.domain.C3PARUser, java.lang.String)
	 */
	public void sendEntitlementNotification(C3PARUser user, String activityName) throws Exception{
		InputMailVO inputMailVO = new InputMailVO();
		C3PARMailMessage mailMsg = new C3PARMailMessage();
		try{
			//MailModuleUtil mmUtil = new MailModuleUtil();
			user = mailModuleUtil.populateUserEntitlementData(user.getSsoId(), user);
			inputMailVO.setUser(user);
			log.info("sendEntitlementNotification::"+activityName+" SSO_ID::"+user.getSsoId()+user.getDisplayName());
			if(ISA_APPROVAL.equals(activityName)){
				inputMailVO.setToEmailAddress(user.getEmail());
			} else if(ISA_REJECTION.equals(activityName)){
				inputMailVO.setToEmailAddress(user.getEmail());
			} else if(SYSADMIN_REJECTION.equals(activityName)){
				inputMailVO.setToEmailAddress(user.getEmail());
			} else if (MANAGER_REVIEW.equals(activityName)){
				inputMailVO.setToEmailAddress(user.getEmail());
			} else if(MANAGER_REJECTION.equals(activityName)){
				inputMailVO.setToEmailAddress(user.getEmail());
			} else if(MANAGER_ENT_NOTIFICATION.equals(activityName)){
				GDIRConnectorHelper connectorHelper = new GDIRConnectorHelper();
				inputMailVO.setCcEmailAddress(user.getEmail());
				if(user.getSsoId()!= null)
					inputMailVO.setToEmailAddress(connectorHelper.getMgrEmailFromSOEid(user.getSsoId().toUpperCase()));
			} else if(ISA_ENT_NOTIFICATION.equals(activityName)){
				inputMailVO.setCcEmailAddress(user.getEmail());
			} else if(SYSADMIN_ENT_NOTIFICATION.equals(activityName)){
				inputMailVO.setCcEmailAddress(user.getEmail());
			}
			mailMsg = this.parseTemplateNew(activityName, inputMailVO, true);
			sendMail(mailMsg,testMode);
		}catch (Exception e){
			log.error("MailModuleImpl:sendEntitlementNotification:Exception in sending Mail for activity::"+activityName+"::"+e.getMessage(), e);
		}
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendEntitlementNotification(com.citigroup.cgti.c3par.bpm.ejb.domain.C3PARUserDTO, java.lang.String)
	 */
	public void sendEntitlementNotification(C3PARUserDTO userDTO, String activityName) throws Exception{
		/*C3PARUser user = new C3PARUser();
		//MailModuleUtil mmUtil = new MailModuleUtil();
		user = mailModuleUtil.convertC3PARUserDTO(userDTO);
		sendEntitlementNotification(user, activityName);*/
	}


	public void sendScheduledExpirationNotification(long requestID, InputMailVO inputMailVO, String activityName) throws Exception{
		log.debug("MailModuleImpl:sendScheduledExpirationNotification: Entered");
		TIProcess tiProcess = null;
		//MailModuleUtil mmUtil = new MailModuleUtil();
		//	InputMailVO inputMailVO = new InputMailVO();
		C3PARMailMessage mailMsg = new C3PARMailMessage();
		try{
			inputMailVO.setTirequestID(requestID);
			tiProcess = manageTIProcessUtil.getProcessData(requestID);
			tiProcess.getTiRequest().getActivityData().setActivityName(activityName);
			String activityNameStr = getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "activityName");
			inputMailVO.setActivityNames(activityNameStr);
			String roleStr = getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "role");
			if (roleStr != null && !(roleStr.trim().equalsIgnoreCase("null"))) {
				inputMailVO.setDisplayRoles(roleStr);
			}else{
				inputMailVO.setDisplayRoles("");
			}
			inputMailVO.setTiProcess(tiProcess);
			String connectionRequestId = (tiProcess.getId()).longValue()+"";
			inputMailVO.setConnectionId(connectionRequestId);
			inputMailVO.setWorkItemUrl(C3PAR_BASE_URL);
			
			inputMailVO.setToEmailAddress(mailModuleUtil.getToAddrForScheduledExpirationEmail(requestID, connectionRequestId, mailModuleUtil.testModeFlag(tiProcess.getId(),testMode)));
			inputMailVO.setName(mailModuleUtil.getToAddrForScheduledExpirationEmail(requestID, connectionRequestId, "names"));
			
			mailMsg = this.parseTemplateNew(SCHEDULED_EXPIRATION_EMAIL, inputMailVO, false);
			sendMail(mailMsg,mailModuleUtil.testModeFlag(tiProcess.getId(),testMode));
		} catch(Exception e){
			log.error("Exception in sending Scheduled Expiration Mail Notification for request ID::" + requestID + "Exception::" + e.getMessage(), e);
		}
		log.debug("MailModuleImpl:sendScheduledExpirationNotification: Exited");
	}
	
	
	// JDBCTemplate Refactored  
	public void sendScheduledExpirationNotification(Map<String,String> data) throws Exception {
		log.debug("MailModuleImpl:sendScheduledExpirationNotification: Entered");
		Long requestID = null;
		List<InputMailVO> inputMailVOs =  new ArrayList<InputMailVO>();
		InputMailVO inputMailVO = new InputMailVO();
		List<TIProcess>	tiProcesses = null;
		
			try {
			
			log.debug("sendScheduledExpirationNotification - Getting ProcessData ");
			 tiProcesses = manageTIProcessUtil.getProcessData( Arrays.asList( data.keySet().toArray()) ); 
		
			} catch(Exception e){
				log.error("Could Not Get TIProcesses ", e);
			}
			
			log.debug("sendScheduledExpirationNotification - Got ProcessData ");
		
			for (TIProcess tiProcess:tiProcesses) { 
				log.debug("sendScheduledExpirationNotification - Processing TIProcess ");
				try {
				inputMailVO = new InputMailVO();
				requestID = tiProcess.getTiRequest().getId(); // tiProcess.getTiRequest().setId(Long.valueOf(requestID));
				inputMailVO.setTirequestID(requestID);
				tiProcess.getTiRequest().getActivityData().setActivityName( data.get(String.valueOf(requestID)) );
				String activityNameStr = getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "activityName");

				inputMailVO.setActivityNames(activityNameStr);
				String roleStr = getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "role");

				if (roleStr != null && !(roleStr.trim().equalsIgnoreCase("null"))) {
					inputMailVO.setDisplayRoles(roleStr);
				} else {
					inputMailVO.setDisplayRoles("");
			   }
			
				inputMailVO.setTiProcess(tiProcess);
				String connectionRequestId = (tiProcess.getId()).longValue()+"";
				inputMailVO.setConnectionId(connectionRequestId); //tiProcess.setId((rs.getLong("tiProc_ID")));
				inputMailVO.setWorkItemUrl(C3PAR_BASE_URL);
				inputMailVO.setToEmailAddress(mailModuleUtil.getToAddrForScheduledExpirationEmail(requestID, connectionRequestId, mailModuleUtil.testModeFlag(tiProcess.getId(),testMode)));
				inputMailVO.setName(mailModuleUtil.getToAddrForScheduledExpirationEmail(requestID, connectionRequestId, "names"));
				inputMailVOs.add(inputMailVO);
				} catch (Exception e) {
					log.error("Exception in sending Scheduled Mail Notification for request ID " + requestID,e);
				}
			}
			
			
			 List<String> mailSentRequestId = new ArrayList<String>();
				
				for (InputMailVO inputMailVo:inputMailVOs) {
					try {
						sendMail  ( parseTemplateNew(SCHEDULED_EXPIRATION_EMAIL,inputMailVo, false),mailModuleUtil.testModeFlag(inputMailVO.getTiProcess().getId(),testMode)) ;
						requestID = inputMailVo.getTiProcess().getId();
						mailSentRequestId.add(requestID.toString());
						log.debug("Completed sending mail for Request ID: "  + requestID);
						} catch (Exception e) {
							log.error("Exception in sending Scheduled Mail Notification for Request ID: " + requestID ,e);
						}
					}
			 
			 log.debug("sendScheduledExpirationNotification - Completed Sending Mail ");
	}
	
	// JDBCTemplate Refactored Changed
	public List<String> sendScheduledNotification(List<String> requestIDs) throws Exception {
		log.debug("MailModuleImpl:sendScheduledNotification: Entered");

		String activityNameStr = null;
		String connectionRequestId = null;
		Long requestid = null;
		String roleStr = null;
		List<InputMailVO> inputMailVOs =  new ArrayList<InputMailVO>();
		InputMailVO inputMailVO = null;
		List<TIProcess>	tiProcesses = null;
		List<String> mailSentRequestId = new ArrayList<String>();
		
		try {
				tiProcesses = manageTIProcessUtil.getProcessData(requestIDs);
		 
			} catch(Exception e){
				log.error("Could Not Get TIProcesses ", e);
				return mailSentRequestId;
			}
			
			for (TIProcess tiProcess:tiProcesses) {
				try {
					inputMailVO = new InputMailVO();
					requestid = tiProcess.getTiRequest().getId();
					log.debug("Creating Mail Text for Request ID: " + requestid);
					inputMailVO.setWorkItemUrl(C3PAR_BASE_URL);  
					inputMailVO.setTirequestID(requestid.longValue() ); // TODO - Is it same as Requestid
					activityNameStr = getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "activityName");
					inputMailVO.setActivityNames(activityNameStr);
					roleStr = getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "role");

					if (roleStr != null && !(roleStr.trim().equalsIgnoreCase("null"))) 
						inputMailVO.setDisplayRoles(roleStr);
					else
						inputMailVO.setDisplayRoles("");
			
					inputMailVO.setTiProcess(tiProcess); 
					connectionRequestId = (tiProcess.getId()).longValue() + "";
					inputMailVO.setConnectionId(connectionRequestId);
					inputMailVO.setWorkItemUrl(C3PAR_BASE_URL);
					inputMailVO.setToEmailAddress(mailModuleUtil.getToAddrForScheduledEmail(requestid, connectionRequestId, mailModuleUtil.testModeFlag(tiProcess.getId(),testMode)));
					
					log.debug("Getting EMail for RequestID: " + requestid);
				 
					inputMailVOs.add(inputMailVO);
					log.debug("Completed adding details for " + requestid);
				} catch (Exception e) {
					log.error("Exception in sending Scheduled Mail Notification for request ID " + requestid,e);
				}
			}
						
			for (InputMailVO inputMailVo:inputMailVOs) {
				try {
						sendMail  ( parseTemplateNew(SCHEDULED_EMAIL,inputMailVo, false),mailModuleUtil.testModeFlag(inputMailVO.getTiProcess().getId(),testMode)) ;
						requestid = inputMailVo.getTiProcess().getTiRequest().getId();
						mailSentRequestId.add(requestid.toString());
					
						log.debug("Completed sending mail for Request ID: "  + requestid);
					} catch (Exception e) {
				
						log.error("Exception in sending Scheduled Mail Notification for Request ID: " + requestid ,e);
					}
				}
				log.debug("MailModuleImpl:sendScheduledNotification: Exited");
		
		return mailSentRequestId;	
	}
	
		
	
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendScheduledNotification(long, com.citigroup.cgti.c3par.domain.InputMailVO)
	 */
	public void sendScheduledNotification(long requestID, InputMailVO inputMailVO) throws Exception{
		log.debug("MailModuleImpl:sendScheduledNotification: Entered");
		TIProcess tiProcess = null;
		//MailModuleUtil mmUtil = new MailModuleUtil();
		//	InputMailVO inputMailVO = new InputMailVO();
		C3PARMailMessage mailMsg = new C3PARMailMessage();
		try{
			inputMailVO.setTirequestID(requestID);
			tiProcess = manageTIProcessUtil.getProcessData(requestID);
			String activityNameStr = getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "activityName");
			inputMailVO.setActivityNames(activityNameStr);
			String roleStr = getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "role");
			if (roleStr != null && !(roleStr.trim().equalsIgnoreCase("null"))) {
				inputMailVO.setDisplayRoles(roleStr);
			}else{
				inputMailVO.setDisplayRoles("");
			}
			inputMailVO.setTiProcess(tiProcess);
			String connectionRequestId = (tiProcess.getId()).longValue()+"";
			inputMailVO.setConnectionId(connectionRequestId);
			inputMailVO.setWorkItemUrl(C3PAR_BASE_URL);
			inputMailVO.setToEmailAddress(mailModuleUtil.getToAddrForScheduledEmail(requestID, connectionRequestId, mailModuleUtil.testModeFlag(tiProcess.getId(),testMode)));
			
			mailMsg = this.parseTemplateNew(SCHEDULED_EMAIL, inputMailVO, false);
			sendMail(mailMsg,mailModuleUtil.testModeFlag(tiProcess.getId(),testMode));
		} catch(Exception e){
			log.error("Exception in sending Scheduled Mail Notification for request ID::" + requestID + "Exception::" + e.getMessage(), e);
		}
		log.debug("MailModuleImpl:sendScheduledNotification: Exited");
	}

	

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendActivationExpirationNotification(long, com.citigroup.cgti.c3par.domain.InputMailVO)
	 */
	public void sendActivationExpirationNotification(long requestID, InputMailVO inputMailVO,String notificationType) throws Exception{
		log.debug("MailModuleImpl:sendActivationExpirationNotification: Entered");
		TIProcess tiProcess = null;
		C3PARMailMessage mailMsg = new C3PARMailMessage();
		try{
			inputMailVO.setTirequestID(requestID);
			tiProcess=manageTIProcessUtil.getProcessData(requestID);
			String activityNameStr=getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "activityName");
			//inputMailVO.setActivityNames(activityNameStr);
			String roleStr=getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "role");
			//inputMailVO.setDisplayRoles(roleStr);
			if (tiProcess != null)
			{
				if(tiProcess.getTiRequest().getActivityData() != null)
				{
					tiProcess.getTiRequest().getActivityData().setActivityName(activityNameStr);
					tiProcess.getTiRequest().getActivityData().setDisplayUserRole(roleStr);
				}
			}
			if(notificationType != null && notificationType.equalsIgnoreCase(ACTIVATION_EXPIRATION_REMINDER_30DAYS)){
				Calendar expDate = Calendar.getInstance();
				expDate.setTime(tiProcess.getActivationExpiryDate());
				Calendar currDate = Calendar.getInstance();
				currDate.setTime(new Date());
				
				inputMailVO.setDaysRemaining(String.valueOf((currDate.getTimeInMillis() - expDate.getTimeInMillis()) / (24 * 60 * 60 * 1000)));
			}
			inputMailVO.setWorkItemUrl(C3PAR_BASE_URL);
			inputMailVO.setTiProcess(tiProcess);
			String connectionRequestId = (tiProcess.getId()).longValue()+"";
			inputMailVO.setConnectionId(connectionRequestId);
			mailMsg = this.parseTemplateNew(notificationType, inputMailVO, false);


			sendMail(mailMsg,mailModuleUtil.testModeFlag(tiProcess.getId(),testMode));
		} catch(Exception e){
			log.error("Exception in sending Scheduled Activation Expiration Mail Notification for request ID::"+requestID+"Exception::"+e.getMessage(), e);
		}
		log.debug("MailModuleImpl:sendActivationExpirationNotification: Exited");
	}

	
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendActivationExpirationNotification(long, com.citigroup.cgti.c3par.domain.InputMailVO)
	 */
	// JDBCTemplate Refactored 
	public void sendActivationExpirationNotification(List requestIDs, String notificationType) throws Exception {
		log.debug("MailModuleImpl:sendActivationExpirationNotification: Entered");
		 
	 
		Calendar expDate = Calendar.getInstance();
		Calendar currDate = Calendar.getInstance(); 
		currDate.setTime(new Date());
		String connectionRequestId = null;
		Long requestid = null;
		InputMailVO inputMailVO = null;
		List<TIProcess>	tiProcesses = null;
		String referenceNo = null;
		C3PARMailMessage mailMsg = new C3PARMailMessage();
		
		try {
			 	tiProcesses = manageTIProcessUtil.getProcessData(requestIDs);
		
		} catch(Exception e){
			log.error("Could Not Get TIProcesses ", e);
			return;
		}	
			
			List<InputMailVO>  inputMailVOs = new ArrayList<InputMailVO>();
			
			for (TIProcess tiProcess:tiProcesses) {
				try {
					requestid = tiProcess.getTiRequest().getId();
					inputMailVO = new InputMailVO();
					inputMailVO.setWorkItemUrl(C3PAR_BASE_URL);  
					inputMailVO.setTirequestID(requestid.longValue() );
					inputMailVO.setVersionNumber(tiProcess.getVersionNumber());
		 
				String activityNameStr = getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "activityName");
				String roleStr = getMultipleActivityDataAttrs(tiProcess.getTiRequest().getActivityDataList(), "role");
			
				if (tiProcess != null) {
					if(tiProcess.getTiRequest().getActivityData() != null){
						tiProcess.getTiRequest().getActivityData().setActivityName(activityNameStr);
						tiProcess.getTiRequest().getActivityData().setDisplayUserRole(roleStr);
					}
				}
			
				if(notificationType != null && notificationType.equalsIgnoreCase(ACTIVATION_EXPIRATION_REMINDER_30DAYS)){
					expDate.setTime(tiProcess.getActivationExpiryDate());
					inputMailVO.setDaysRemaining(String.valueOf((currDate.getTimeInMillis() - expDate.getTimeInMillis()) / MLS));
				}
				//Retrieve CMP ID/SERVICENOW ID from last cycle
				if(notificationType != null && notificationType.equalsIgnoreCase(ACTIVATION_EXPIRATION_REMINDER_7DAYS)){
					String cmpIDSNowID = manageTIProcessUtil.getLastCmpServiceNowID(tiProcess.getId());
					if (tiProcess != null) {
						if(tiProcess.getTiRequest().getActivityData() != null){
							tiProcess.getTiRequest().setCmpId(cmpIDSNowID);
						}
						log.debug("Setting the Approve and Reject URL for reminder mail");
						referenceNo = UUID.randomUUID().toString();
						inputMailVO.setApproveURL(getMailToEncodedString(environment,tiProcess.getId().toString(), tiProcess.getTiRequest().getVersionNumber(), OneApprovalConstants.ACTIVITY_ACV, false, referenceNo));
						inputMailVO.setReferenceNo(referenceNo);
					}
					
				}
				inputMailVO.setTiProcess(tiProcess);
				connectionRequestId = (tiProcess.getId()).longValue() + "";
				inputMailVO.setConnectionId(connectionRequestId);
				inputMailVOs.add(inputMailVO);
				} catch (Exception e) {
					log.error("Exception in sending Scheduled Mail Notification for request ID " + requestid,e);
				}
			}
			 
			 
			for (InputMailVO inputMailVo:inputMailVOs) {
			   try {
				   mailMsg = this.parseTemplateNew(notificationType, inputMailVo, false);
					mailMsg.setReferenceNo(inputMailVo.getReferenceNo());
					//Added for task 43752-starts
					if(notificationType.equalsIgnoreCase(ACTIVATION_EXPIRATION_REMINDER_7DAYS)){
						log.debug("7 day mail ");
						mailMsg.setAttachments(accessFormTextGenerator.getAttachments(inputMailVo.getTirequestID(),inputMailVo.getTiProcess().getId(), Long.valueOf(inputMailVo.getVersionNumber()),"Y"));
					}
					//Added for task 43752-Ends
					sendMail  ( mailMsg,mailModuleUtil.testModeFlag(inputMailVO.getTiProcess().getId(),testMode));
					requestid = inputMailVo.getTiProcess().getId();
					 log.debug("Completed sending mail for Request ID: "  + requestid);
				  } catch (Exception e) {
						log.error("Exception in sending Scheduled Mail Notification for Connection ID " + requestid,e);
					}
				}
		log.debug("MailModuleImpl:sendActivationExpirationNotification: Exited");
	}

	/**
	 * Gets the multiple activity data attrs.
	 *
	 * @param activityDataList the activity data list
	 * @param attrName the attr name
	 * @return the multiple activity data attrs
	 */
	private String getMultipleActivityDataAttrs(List activityDataList, String attrName){
		String returnStr = null;
		Iterator iter= activityDataList.iterator();
		ActivityData activityData = null;
		
		while(iter.hasNext()){
			activityData=(ActivityData)iter.next();
			if(returnStr==null){
				if("activityName".equalsIgnoreCase(attrName)){
					returnStr=activityData.getActivityName();
				} else if ("role".equalsIgnoreCase(attrName)){
					returnStr=activityData.getDisplayUserRole()+activityData.getDisplayInfoUserRole();
				}
			} else {
				if("activityName".equalsIgnoreCase(attrName)){
					returnStr=returnStr+";"+activityData.getActivityName();
				} else if ("role".equalsIgnoreCase(attrName)){
					returnStr=returnStr+";"+activityData.getDisplayUserRole()+activityData.getDisplayInfoUserRole();
				}
			}
		}
		return returnStr;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendEmailFAFQueueAlert(java.util.ArrayList)
	 */
	/*public void sendEmailFAFQueueAlert(ArrayList fafRequests) throws Exception {

		log.debug("MailModuleImpl:sendEmailFAFQueueAlert:Entered");
		MimeMessage msg = this.mailSender.createMimeMessage();
		String sendFAFQueueAlertEmail = FAF_QUEUE_ALERT_EMAIL;
		MimeMessageHelper helper = new MimeMessageHelper(msg, false);
		boolean msgExists = false;
		StringBuffer msgTxt = new StringBuffer();
		String mailSubject = "FAF ALERT: FAF Queue is growing ";
		helper.setSubject(mailSubject);
		msg.setSentDate(new Date());
		helper.setTo(sendFAFQueueAlertEmail);
		helper.setFrom("dl.otrm.us.ccr@imcnam.ssmb.com");
		msgTxt.append("Hello CCR Development Team");
		msgTxt.append("\n\n");
		msgTxt.append("This email has been auto-generated by the CCR system to alert you that FAF queue is growing. There are connections which are being computed since more than half an hour.");
		msgTxt.append("\n\n");
		msgTxt.append("Below is the list of connections which are being executed and waiting to be executed: ");
		msgTxt.append("\nNo. \t Conn ID \t Req Type \t\t Req Time \t\t\t Start Time \t\t\t Status \t Session Id \n");
		for (int i = 0; i < fafRequests.size(); i++) {
			HashMap fafReqs = new HashMap();
			fafReqs = (HashMap)fafRequests.get(i);
			msgTxt.append(fafReqs.get("WAITLIST_NO")+"\t"+fafReqs.get("CON_REQ_ID")+"\t\t"+fafReqs.get("REQ_TYPE")+"\t\t"+fafReqs.get("REQUESTED_TIME")+"\t"+(fafReqs.get("STARTED_TIME")==null?"\t\t\t":fafReqs.get("STARTED_TIME"))+"\t\t"+fafReqs.get("STATUS")+"\t"+fafReqs.get("SESSION_ID")+"\n");
		}

		msgTxt.append(" \nDO NOT Reply to this message. Please contact '*IS GLOBAL CCR', in case of any problem. "+"\n\n");
		msgTxt.append(" \nYou may click the below link to login to CCR."+"\n");
		msgTxt.append(" \n" + C3PAR_BASE_URL + "\n\n");
		msgTxt.append("Thank you,"+"\n");
		msgTxt.append("CCR");
		helper.setText(msgTxt.toString());
		if (msg != null) {
			msgExists = true;
		}
		if(msgExists){
			try{
				this.mailSender.send(msg);				
				//insert mail information into TI_MAIL_AUDIT for Audit
				C3PARMailMessage mailMsg = new C3PARMailMessage();
				mailMsg.setTiRequestID(new Long(0));
				mailMsg.setTemplateID("");
				mailMsg.setToAddresses(sendFAFQueueAlertEmail);
				mailMsg.setCcAddresses("");
				mailMsg.setMsgSubject(mailSubject);
				mailMsg.setMsgContent(msgTxt.toString());				
				this.mailModuleUtil.mailActivityAudit(mailMsg);
			}
			catch(MailException ex) {
				log.error(ex,ex);        // simply log it and go on...
			} catch (Exception e){
				log.error(e,e);
			}
			log.debug("MailModuleImpl:sendEmailFAFQueueAlert:Exiting");
		}
	}*/

	/**
	 * Parses the template.
	 *
	 * @param templateId the template id
	 * @param mailVO the mail vo
	 * @return the c3 par mail message
	 */
	/*public C3PARMailMessage parseTemplate (String templateId, BaseMailVO mailVO,boolean loadMailTemplates){
		log.info("MailModule:MailModuleImpl:parse:: Entered");

		C3PARMailMessage c3parMailMessage = new C3PARMailMessage();
		//MailModuleUtil mmUtil=new MailModuleUtil();//juint
		//c3parMailMessage.setC3parBaseUrl("http://GCOTDVM3713634:9001"); //For JUnit
		c3parMailMessage.setC3parBaseUrl(C3PAR_BASE_URL);
		c3parMailMessage.setTemplateID(templateId);
		c3parMailMessage.setTiRequestID(mailVO.getTirequestID());
		log.debug ("MailModule:MailModuleImpl:parse::templateId ==> "+templateId+" TirequestID ==> "+mailVO.getTirequestID());
		try {
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			//Document doc = docBuilder.parse ("C:\\ccr\\dev\\workspace\\C3parEar\\c3parWebApp\\WEB-INF\\mailmodule\\MailTemplates.xml"); //For JUnit
			//Document doc = docBuilder.parse(new File(TEMPLATE_FILE_LOC + templateFileLocation + TEMPLATE_XML_FILE_NAME));
			if(loadMailTemplates || mailTemplates == null || mailTemplates.isEmpty()){
				mailTemplates = mailModuleUtil.getMailTemplates().toString();
				log.debug ("MailModule:MailModuleImpl:parseTemplate: mailTemplates loaded .......");
			}
			
			 Moved the doc to instance variable so that we need not parse xml document everytime. We will only parse if it is null  
			if (doc == null)
			   //doc = docBuilder.parse ("C:\\ccr\\dev\\workspace\\C3parEar\\c3parWebApp\\WEB-INF\\mailmodule\\MailTemplates.xml"); //For JUnit
			  doc = docBuilder.parse(new InputSource(new StringReader(mailTemplates)));
			
			doc.getDocumentElement ().normalize ();
			log.debug ("MailModule:MailModuleImpl:parse:: Root element of the doc is " + doc.getDocumentElement().getNodeName());

			boolean inputValidated = validateMailVO(doc, mailVO);
			boolean isTemplateAvailable=false;
			if(inputValidated){

				NodeList listOfTemplates = doc.getElementsByTagName(TEMPLATE_ROOT);
				int totalTemplates = listOfTemplates.getLength();
				log.debug("MailModule:MailModuleImpl:parse:: Total no of templates : " + totalTemplates);

				for (int s = 0; s < totalTemplates; s++) {

					Node templateNode = listOfTemplates.item(s);
					NamedNodeMap nodeMap = templateNode.getAttributes();
					String id= ((Node)nodeMap.getNamedItem(ATTR_TEMPLATE_ID)).getNodeValue();
					log.info(id);
					if(id != null && id.equals(templateId)){
						log.info(id);
						log.info(templateNode.getNodeType() +"  ----- "+ Node.ELEMENT_NODE);
						if(templateNode.getNodeType() == Node.ELEMENT_NODE){

							log.info("templateId --> "+templateId);
							c3parMailMessage = processTemplateTags((Element)templateNode, templateId, c3parMailMessage, mailVO);
							isTemplateAvailable=true;
						}//end of if clause
						break;
					}
				}//end of for loop with s var
			}
			if(isTemplateAvailable){
					String mailMsg = generateC3parMailMessageXML(c3parMailMessage);
					//System.out.println(mailMsg);
					String finalMsgBody = applyXSL(mailMsg, c3parMailMessage.getXslFileName());//Need to check here
					//System.out.println("8888888888888888888888888888888888888888888");
					//System.out.println(finalMsgBody);
					c3parMailMessage.setMsgContent(finalMsgBody);
					//log.debug ("MailModuleImpl:parseTemplate:finalMsgBody:"+finalMsgBody);
					//System.out.println(finalMsgBody);
			}
		}catch(BusinessException be) {

			log.error("MailModuleImpl:parse::BusinessExceotuib "+be.getMessage());
			log.error(be,be);
			throw new BusinessException("Exception Occured");

		}catch(MailModuleException e) {

			log.error("MailModule:MailModuleImpl:parse:: "+e.getMessage());
			log.error(e,e);

		}catch (Throwable t) {
			log.error("MailModule:MailModuleImpl:parse:: "+t);
			log.error(t,t);
		}
		log.info("MailModule:MailModuleImpl:parse:: Exited");
		return c3parMailMessage;

	}*/
	
	//end of parse method

	
	private MailMsgDisplayRow[] populateInfo(
			Map emerBuscritQuesAndAnswers) throws MailModuleException {
		log.debug("MailModule:MailModuleUtil:populateInfo:: Entered");
		MailMsgDisplayRow[] rows = new MailMsgDisplayRow[emerBuscritQuesAndAnswers.size()];
		Set set = emerBuscritQuesAndAnswers.keySet();
		int i=0;
		for (Object object : set) {
			MailMsgDisplayInfo[] infos = new MailMsgDisplayInfo[1];
			String tempQus = (String) object;
			String tempAns = (String) emerBuscritQuesAndAnswers.get(object);
			log.debug("tempQus   "+tempQus + "tempAns  " + tempAns);
			infos[0] = new MailMsgDisplayInfo();
			infos[0].setLabel(tempQus);
			infos[0].setValue(tempAns);
			rows[i] = new MailMsgDisplayRow();
			rows[i].setInfo(infos);
			i++;
		}
		log.debug("MailModuleUtil:: Exited");
		return rows;
	}
	/**
	 * Generate c3par mail message xml.
	 *
	 * @param msg the msg
	 * @return the string
	 */
	private String generateC3parMailMessageXML(C3PARMailMessage msg){
		log.debug("MailModule:MailModuleImpl:generateC3parMailMessageXML:: Entered");
		String mailMsg = "";
		try{
			XStream stream = new XStream(new DomDriver());
			stream.alias("C3PARMailMessage", C3PARMailMessage.class);
			stream.alias("MailMsgDisplayInfo", MailMsgDisplayInfo.class);
			stream.alias("MailMsgDisplayRow", MailMsgDisplayRow.class);
			mailMsg = stream.toXML(msg);
		} catch (Exception ex) {
			log.error(ex,ex);
		}
		log.debug("MailModule:MailModuleImpl:generateC3parMailMessageXML:: Exited");
		return mailMsg;
	}

	/**
	 * Apply xsl.
	 *
	 * @param mailMsg the mail msg
	 * @param xslFileName the xsl file name
	 * @return the string
	 */
	private String applyXSL(String mailMsg, String xslFileName){
		//	log.debug("MailModule:MailModuleImpl:applyXSL:: Entered");
		//		Writer outWriter = new StringWriter();
		Writer outWriter;
		StreamResult result = null;
		try{
			outWriter = new StringWriter();
			result = new StreamResult( outWriter);
			TransformerFactory tFactory = TransformerFactory.newInstance();
			Transformer transformer =
				tFactory.newTransformer
				(new javax.xml.transform.stream.StreamSource
						//(("C:\\ccr\\dev\\workspace\\C3parEar\\c3parWebApp\\WEB-INF\\mailmodule\\GenericMailTemplate.xsl"))); // For JUnit
						(TEMPLATE_FILE_LOC+templateFileLocation+xslFileName));
			transformer.transform
			(new javax.xml.transform.stream.StreamSource
					(new StringReader(mailMsg)), result);
		} catch (Exception e) {
			log.error(e,e);
		}
		//	log.debug("MailModule:MailModuleImpl:applyXSL:: Exited");

		return result.getWriter().toString();
	}

	/**
	 * Gets the element text value.
	 *
	 * @param templateElement the template element
	 * @param elementTagName the element tag name
	 * @param isMandatory the is mandatory
	 * @return the element text value
	 * @throws MailModuleException the mail module exception
	 */
	private String getElementTextValue (Element templateElement, String elementTagName, boolean isMandatory) throws MailModuleException {
		String returnStr="";
		//	log.debug("MailModule:MailModuleImpl:getElementTextValue:: Entered for "+elementTagName);
		NodeList nodeList = templateElement.getElementsByTagName(elementTagName);
		if(isMandatory && (nodeList == null || nodeList.getLength() == 0)){
			throw new MailModuleException("The Template MUST have the tag::"+elementTagName);
		} else if(nodeList != null && nodeList.getLength() != 0) {
			Element element = (Element)nodeList.item(0);
			NodeList textList = element.getChildNodes();
			if(textList.item(0) != null){
				returnStr = ((Node)textList.item(0)).getNodeValue().trim();
			}
		}
		//   log.debug("MailModule:MailModuleImpl:getElementTextValue:: Exited with "+returnStr);
		return returnStr;
	}

	/**
	 * Search vars and replace values.
	 *
	 * @param strTobeReplaced the str tobe replaced
	 * @param mailVO the mail vo
	 * @return the string
	 */
	private String searchVarsAndReplaceValues(String strTobeReplaced, BaseMailVO mailVO){
		//	log.debug("MailModule:MailModuleImpl:searchVarsAndReplaceValues:: Entered");
		String replacedStr="";
		try{
			if(strTobeReplaced != null && !"".equals(strTobeReplaced)){
				Pattern myPattern = Pattern.compile(TEMPLATE_VAR_PATTERN_REGEX, Pattern.MULTILINE);
				Matcher m = myPattern.matcher(strTobeReplaced);
				List vars = new ArrayList();
				while(m.find()){
					vars.add((m.group(0)).substring(2,  m.group(0).length() -2));
				}
				String[] str= myPattern.split(strTobeReplaced);
				String varValues[];
				varValues = new String[vars.size()];
				for (int x = 0; x < vars.size(); x++) {
					Object obj=PropertyUtils.getProperty(mailVO, (String)vars.get(x));
					if(obj != null){
						if (obj.getClass().isInstance(Long.valueOf("0"))) {
							varValues[x]=((Long)obj).toString();
						} else if(obj.getClass().isInstance(new Integer(0))) {
							varValues[x] = ((Integer)obj).toString();
						}else if(obj.getClass().isInstance(new Date())){
							DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
							Date date = (Date) obj;
							varValues[x] = df.format(date);
						} else if(obj.getClass().isInstance(new java.sql.Date(0))){
							DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
							Date date = (java.sql.Date) obj;
							varValues[x] = df.format(date);
						} else if(obj.getClass().isInstance(new java.sql.Timestamp(0))){
							DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
							Date date = (java.sql.Timestamp) obj;
							varValues[x] = df.format(date);
						} else{
							varValues[x] = (String) obj;
						}
					} else {
						varValues[x] = null;
					}
				}
				StringBuffer buf = new StringBuffer();
				if (str.length != 0) {
					for (int i = 0; i < str.length; i++) {
						buf.append(str[i]);
						if (i < varValues.length)
							buf.append(varValues[i]);
					}
				} else if (varValues.length != 0) {
					buf.append(varValues[0]);
				}
				if(buf.toString() != null && !(buf.toString().equalsIgnoreCase("null"))){
					replacedStr = buf.toString();
				}else{
					replacedStr	= "";
				}

			}
		} catch (Exception e){
			log.error(e,e);
		}
		//	log.debug("MailModule:MailModuleImpl:searchVarsAndReplaceValues:: Exited");
		return replacedStr;
	}

	/**
	 * Search vars and replace values.
	 *
	 * @param strTobeReplaced the str tobe replaced
	 * @param mailVO the mail vo
	 * @return the string
	 */
	private String searchVarsAndReplaceValues(String strTobeReplaced, Map<String,Object> map){
		//	log.debug("MailModule:MailModuleImpl:searchVarsAndReplaceValues:: Entered");
		String replacedStr="";
		try{
			if(strTobeReplaced != null && !"".equals(strTobeReplaced)){
				Pattern myPattern = Pattern.compile(TEMPLATE_VAR_PATTERN_REGEX, Pattern.MULTILINE);
				Matcher m = myPattern.matcher(strTobeReplaced);
				List vars = new ArrayList();
				while(m.find()){
					vars.add((m.group(0)).substring(2,  m.group(0).length() -2));
				}
				String[] str= myPattern.split(strTobeReplaced);
				String varValues[];
				varValues = new String[vars.size()];
				for (int x = 0; x < vars.size(); x++) {
					Object obj=map.get((String)vars.get(x));
					if(obj != null){
						if (obj.getClass().isInstance(Long.valueOf("0"))) {
							varValues[x]=((Long)obj).toString();
						} else if(obj.getClass().isInstance(new Date())){
							DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
							Date date = (Date) obj;
							varValues[x] = df.format(date);
						} else if(obj.getClass().isInstance(new java.sql.Date(0))){
							DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
							Date date = (java.sql.Date) obj;
							varValues[x] = df.format(date);
						} else if(obj.getClass().isInstance(new java.sql.Timestamp(0))){
							DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
							Date date = (java.sql.Timestamp) obj;
							varValues[x] = df.format(date);
						} else {
							varValues[x] = (String) obj;
						}
					} else {
						varValues[x] = null;
					}
				}
				StringBuffer buf = new StringBuffer();
				if (str.length != 0) {
					for (int i = 0; i < str.length; i++) {
						buf.append(str[i]);
						if (i < varValues.length)
							buf.append(varValues[i]);
					}
				} else if (varValues.length != 0) {
					buf.append(varValues[0]);
				}
				if(buf.toString() != null && !(buf.toString().equalsIgnoreCase("null"))){
					replacedStr = buf.toString();
				}else{
					replacedStr	= "";
				}

			}
		} catch (Exception e){
			log.error(e,e);
		}
		//	log.debug("MailModule:MailModuleImpl:searchVarsAndReplaceValues:: Exited");
		return replacedStr;
	}

	/**
	 * Validate mail vo.
	 *
	 * @param doc the doc
	 * @param mailVO the mail vo
	 * @return true, if successful
	 * @throws MailModuleException the mail module exception
	 */
	private boolean validateMailVO(Document doc, BaseMailVO mailVO) throws MailModuleException{
		boolean retVal = true;
		//	log.debug("MailModule:MailModuleImpl:validateMailVO:: Entered");
		NodeList listOfSQLParams = doc.getElementsByTagName(ELEMENT_SQLPARAM);
		for (int s = 0; s < listOfSQLParams.getLength(); s++) {

			Node sqlParamNode = listOfSQLParams.item(s);
			if(sqlParamNode.getNodeType() == Node.ELEMENT_NODE){
				Element sqlParamElement = (Element)sqlParamNode;
				NodeList textsqlParamList = sqlParamElement.getChildNodes();
				if(textsqlParamList != null && textsqlParamList.getLength()!=0){
					String sqlParam = ((Node)textsqlParamList.item(0)).getNodeValue().trim();
					String sqlParamTextVal="";
					log.debug("MailModule:MailModuleImpl:validateMailVO:: Checking for variable "+sqlParam);
					try{
						Object obj=PropertyUtils.getProperty(mailVO,  sqlParam);
						if(obj != null){
							if (obj.getClass().isInstance(Long.valueOf("0"))) {
								sqlParamTextVal=((Long)obj).toString();
							} else {
								sqlParamTextVal=(String)obj;
							}
						}
						//sqlParamTextVal= (String)PropertyUtils.getProperty(mailVO, sqlParam);
						if(sqlParamTextVal==null || "".equals(sqlParamTextVal)){
							throw new MailModuleException("The mandatory SQL Parameter \""+sqlParam+"\" is null or blank in the input object");
						}
					}catch(MailModuleException ex){
						throw ex;
					}catch (Exception e){
						if(!(e instanceof MailModuleException))
							throw new MailModuleException("The mandatory SQL Parameter \""+sqlParam+"\" mentioned in the template is not present in the input mailVO object");
					}
				}
			}
		}
		//    log.debug("MailModule:MailModuleImpl:validateMailVO:: Exited");
		return retVal;
	}
	
	private C3PARMailMessage processTemplateTags(Element templateNode, String templateId, C3PARMailMessage c3parMailMessage, BaseMailVO mailVO) throws MailModuleException{
		
		Element templateElement = (Element)templateNode;

		//-------
		String xslFileName = getElementTextValue(templateElement, ELEMENT_XSLFILENAME, true);
		if(xslFileName == null || "".equals(xslFileName)){
			throw new MailModuleException("The tag XSLFILENAME is blank in the template : "+templateId);
		}
		c3parMailMessage.setXslFileName(xslFileName);
		log.debug ("MailModuleImpl:parseTemplate:xslFileName:"+xslFileName);

		//-------
		String from = getElementTextValue(templateElement, ELEMENT_FROM, true);
		if(from == null || "".equals(from)){
			throw new MailModuleException("The tag FROM is blank in the template : "+templateId);
		}
		c3parMailMessage.setFromAddress(from);
		log.debug ("MailModuleImpl:parseTemplate:from:"+from);

		//-------
		String toList = "";
		String toUserNamesList = "";
		String toUserRole = getElementTextValue(templateElement, ELEMENT_TO_USER_ROLE, false);
		String name="";
		 
		if(templateId.equals(DIR_MAIL_INFO)){
			String[] toUserRoleCategories = toUserRole.split("\\,");
			String roles = "";
			
			for(int i=0;i<toUserRoleCategories.length;i++){
				if(i==0){
					roles+="'"+toUserRoleCategories[i]+"'";
				}else{
					roles+=",'"+toUserRoleCategories[i]+"'";
				}
			}
			List directorApprovalMailList = mailModuleUtil.getDirectorMaiId(mailVO,roles);//'Director'
			if (directorApprovalMailList != null && !directorApprovalMailList.isEmpty()) {
				for (int i = 0; i < directorApprovalMailList.size(); i++) {
					Map directorApprovalMailInfo=(Map)directorApprovalMailList.get(i);
					String nameComb=(String)directorApprovalMailInfo.get("firstName")+" "+
					(String)directorApprovalMailInfo.get("lastName");
					if (!nameComb.trim().equals(""))
						name=name + nameComb + " and ";
				}
			}else{
				log.debug ("directorApprovalMailList is null or empty");
				throw new BusinessException("Please add Direct Level Approver in Target Contacts");
			}
			if(name.lastIndexOf("and") != -1 && name.length() > 1){
				name = name.substring(0, name.length()-4 );
			}
			((InputMailVO)mailVO).setName(name);
			log.debug ("MailModuleImpl:parseTemplate:name:"+name);
			
		}
        if(toUserRole != null && !("".equals(toUserRole))){
        	String[] toUserRoleCategories = toUserRole.split("\\,");
        	toUserRole = "";
			for (int i = 0; i < toUserRoleCategories.length; i++) {
       		 if(toUserRoleCategories[i] != null && !("".equals(toUserRoleCategories[i].trim()))){
       			if (templateId != null && !templateId.trim().equals("") &&(templateId.equals(ACTIVATION_EXPIRATION_REMINDER_7DAYS) || templateId.equals(VERIFY_SOW) || templateId.equals(ISO_APPROVAL) || templateId.equals(MANAGER_APPROVAL))){
       				toUserRole = toUserRole + mailModuleUtil.getUserRoleEmailOfPrimaryAndSecondary(mailVO.getConnectionId(), toUserRoleCategories[i],  mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
       				toUserNamesList = toUserNamesList + mailModuleUtil.getUserRoleEmailOfPrimaryAndSecondary(mailVO.getConnectionId(), toUserRoleCategories[i],  "names");
       			}else if (templateId != null && !templateId.trim().equals("") && templateId.equals(ACTIVATION_EXPIRATION_REMINDER_30DAYS)){
       				if("Manager".equalsIgnoreCase(toUserRoleCategories[i])){
       					toUserRole = toUserRole + mailModuleUtil.getUserRoleEmailOfPrimaryAndSecondary(mailVO.getConnectionId(), toUserRoleCategories[i],  mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
           				toUserNamesList = toUserNamesList + mailModuleUtil.getUserRoleEmailOfPrimaryAndSecondary(mailVO.getConnectionId(), toUserRoleCategories[i],  "names");
       				}else{
       					toUserRole = toUserRole + mailModuleUtil.getManagerEmail(mailVO.getConnectionId(), toUserRoleCategories[i],  mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
           				toUserNamesList = toUserNamesList + mailModuleUtil.getManagerName(mailVO.getConnectionId(), toUserRoleCategories[i],  "names");
       				}
       				
       			}else{
       			 toUserRole = toUserRole+mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),  toUserRoleCategories[i], mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
       		 }
       	}
       }
			
			  log.debug ("MailModuleImpl:parseTemplate:toUserRole:" + toUserRole);
        }
        toList = toUserRole;
        if (templateId != null && !templateId.trim().equals("") &&(templateId.equals(ACTIVATION_EXPIRATION_REMINDER_7DAYS) ||templateId.equals(ACTIVATION_EXPIRATION_REMINDER_30DAYS)|| templateId.equals(VERIFY_SOW) || templateId.equals(ISO_APPROVAL) || templateId.equals(MANAGER_APPROVAL))){
    		/*if(toUserNamesList.length() > 1 && toUserNamesList.lastIndexOf(",") != -1){
    			toUserNamesList = toUserNamesList.substring(0, toUserNamesList.length()- 2 );
    		}*/
    		String[] toUserList = toUserNamesList.split("\\,");
    		
    		  Set<String> nameSet = new HashSet<String>();
    	        StringBuffer newUserNameList=new StringBuffer();
    	        	for(String toUser:toUserList){
    	        		
    	                if(toUser!=null && !toUser.trim().isEmpty() && nameSet.add(toUser.trim())){
    	                	
    	                        newUserNameList.append(toUser+ ", ");
    	               }

    		 }
			((InputMailVO)mailVO).setName(newUserNameList.toString());
			log.debug("Business manager names:"+((InputMailVO)mailVO).getName());
        }

		/*if (templateId != null && !templateId.trim().equals("") &&(templateId.equals(ACTIVATION_EXPIRATION_REMINDER) ||
				templateId.equals(SCHEDULED_EMAIL)))
		{
			toList=mmUtil.getAllVersionRoleEmail(mailVO.getConnectionId(), testMode);
			log.info("getAllVersionRoleEmail toList Value ::: "+toList);
		}else{
			toList=mmUtil.getUserRoleEmail(mailVO.getConnectionId(), testMode);
			log.info("getUserRoleEmail toList Value ::: "+toList);
		}*/

		//----
		String toOwner = getElementTextValue(templateElement, ELEMENT_TO_OWNER, false);
		String[] toOwnerCategories = toOwner.split("\\,");
		toOwner = "";
		for (int i = 0; i < toOwnerCategories.length; i++) {
			if(toOwnerCategories[i]!= null && "CURRENT_PC".equals(toOwnerCategories[i])){
				toOwner = toOwner + mailModuleUtil.getOwnerEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			} else if(toOwnerCategories[i]!=null && "ALL_REQUESTORS".equals(toOwnerCategories[i])){
				toOwner = toOwner + mailModuleUtil.getAllRequestorsEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			} else if(toOwnerCategories[i]!=null && !("".equals(toOwnerCategories[i].trim()))){
				toOwner = toOwner + mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(), toOwnerCategories[i], mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			}
		}
		/*if(templateId != null && templateId.equalsIgnoreCase(BUSINESS_JUSTIFICATION )||
				( templateId.equalsIgnoreCase(IP_DETAIL))){
			toOwner = toOwner + mailModuleUtil.getProjCoordinatorContacts(mailVO.getConnectionId(), ROLE_PC, testMode);
		}*/
		log.debug ("MailModuleImpl:parseTemplate:toOwner:"+toOwner);
		toList = toList + toOwner;

		//----
		String toRole = getElementTextValue(templateElement, ELEMENT_TO_ROLE, false); 
		String[] toRoleCategories = toRole.split("\\,");


		if (toRole!=  null && !("".equals(toRole))){

			if(OPERATIONAL_IMPLEMENTATION.equalsIgnoreCase(templateId)){
				toRole="";
				toRole = mailModuleUtil.getFWMgmtRegionEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));

			} else {
				toRole="";
				for (String toRoleCategorie : toRoleCategories) {
					toRole = toRole + mailModuleUtil.getRoleEmail(toRoleCategorie, mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));

				}
			}
		}
		if(templateId.equalsIgnoreCase(TEMPLATE_MAIL_B4_FW_IMPL)){
			toRole = toRole + mailModuleUtil.getTemplateUsingConnOwners(mailVO);
			log.debug("TEMPLATE_MAIL_B4_FW_IMPL::toRole::"+toRole);
		}
		if(templateId.equalsIgnoreCase(TEMPLATE_MAIL_B4_MANITENENCE)){
			//Send to previous Template Connection owner
			toRole = toRole + mailModuleUtil.getTemplateConnPreOwner(mailVO);
			log.debug("TEMPLATE_MAIL_B4_MANITENENCE::toRole::"+toRole);
		}
		if(templateId.equalsIgnoreCase(TEMPLT_UING_CONN_MAIL_B4_TECH) || templateId.equalsIgnoreCase(TEMPLT_UING_CONN_MAIL_B4_TECH_TWO) ){
			toRole = toRole + mailModuleUtil.getTemplateConnOwners(mailVO);
			log.debug("TEMPLT_UING_CONN_MAIL_B4_TECH::toRole::"+toRole);
		}
		log.debug ("MailModuleImpl:parseTemplate:toRole:"+toRole);
		toList =  toList + toRole;

		if(mailVO.getToEmailAddress() != null && !("".equals(mailVO.getToEmailAddress()))){
			toList = toList + mailVO.getToEmailAddress();

		}
		//Added for task 42663-Starts
		//Add DL(*GT Global Proxy Integration) to mail list if it was added as part of special instruction
		if (templateId.equalsIgnoreCase(PROXY_APPROVAL)) {
				log.debug("Setting the mail id for proxy approval");
				toList = toList + mailModuleUtil.getAdditionalMailForProxy(mailVO.getConnectionId());
			}
		
		//Added for task 42663-Ends
		if (toList == null || "".equals(toList)){
			log.error(" there are no email addresses mentioned for sending the email TO");
		} else {
			c3parMailMessage.setToAddresses(toList);
			log.debug("MailModule:MailModuleImpl:parse:: Email Addresses in TO List::" + toList);
		}
		//----
		String cc = getElementTextValue(templateElement, ELEMENT_CC, false);
		if (cc != null && !("".equals(cc))){
			cc=cc + EMAIL_ADDRESS_SEPERATOR;
		}
		log.debug ("MailModuleImpl:parseTemplate:cc:"+cc);
		
		String ccUserRole = getElementTextValue(templateElement, ELEMENT_CC_USER_ROLE, false);
		String[] ccUsers = ccUserRole.split("\\,");
		String projectCoordInfo = "";
		
		if(templateId.equals(DIR_MAIL_INFO)){
			for(String strCC:ccUsers)
			{
				if(strCC != null && !strCC.isEmpty()){
					List<String> info = mailModuleUtil.getUsrRleEmailPrjInfo(mailVO.getConnectionId(),strCC,mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
					if(projectCoordInfo.equals("") && !info.isEmpty() && !info.get(1).equals("")){
						projectCoordInfo = info.get(1);
					}else if(!info.isEmpty() && !info.get(1).equals("")){
						projectCoordInfo+=","+info.get(1);
					}
					
					if(!info.isEmpty() && !info.get(0).equals(""))
					{
						cc=cc+info.get(0);
					}
				}
			}
			((InputMailVO)mailVO).setProjCoordInfo(projectCoordInfo);
			log.debug ("MailModuleImpl:parseTemplate:projectCoordInfo:"+projectCoordInfo);
			
		}else{
			String names = "";
			for(String strCC:ccUsers)
			{
				String emailData = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));

                if(templateId != null && !templateId.trim().equals("") && templateId.equals(ACTIVATION_EXPIRATION_REMINDER_30DAYS)){
                	if(strCC != null && strCC.equalsIgnoreCase("PROJECT COORDINATOR")){
                		names = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,"names");
                		if(names.length() > 1 && names.lastIndexOf(",") != -1){
                			names = names.substring(0, names.length() - 2);
                		}
                		((InputMailVO)mailVO).setProjectCoordinatorNames(names);
                	}else if(strCC != null && strCC.equalsIgnoreCase("Business_Owner")){
                		names = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,"names");
                		if(names.length() > 1 && names.lastIndexOf(",") != -1){
                			names = names.substring(0, names.length() - 2);
                		}
                		((InputMailVO)mailVO).setBusinessOwnerNames(names);
                	}else if(strCC != null && strCC.equalsIgnoreCase("Manager")){
                		names = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,"names");
                		if(names.length() > 1 && names.lastIndexOf(",") != -1){
                			names = names.substring(0, names.length() - 2);
                		}
                		((InputMailVO)mailVO).setBusinessManagerNames(names);
                	}else if(strCC != null && strCC.equalsIgnoreCase("Requestor")){
                		names = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,"names");
                		if(names.length() > 1 && names.lastIndexOf(",") != -1){
                			names = names.substring(0, names.length() - 2);
                		}
                		((InputMailVO)mailVO).setRequestorNames(names);
                	}else if(strCC != null && strCC.equalsIgnoreCase("BISO")){
                		names = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,"names");
                		if(names.length() > 1 && names.lastIndexOf(",") != -1){
                			names = names.substring(0, names.length() - 2);
                		}
                		((InputMailVO)mailVO).setIsoNames(names);
                	}
                }				                    
				if(emailData!=null && !emailData.trim().equals("") && !emailData.isEmpty()){
					cc=cc+emailData;
				}
			}
		}
		
		
		if (ccUserRole != null && !("".equals(ccUserRole))){
			ccUserRole = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(), ccUserRole, mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
		}
		cc = cc + ccUserRole;
		log.debug ("MailModuleImpl:parseTemplate:ccUserRole:"+ccUserRole);
		
		String ccOwner = getElementTextValue(templateElement, ELEMENT_CC_OWNER, false);
		String[] ccOwnerCategories = ccOwner.split("\\,");
		ccOwner = "";
		for (int i = 0; i < ccOwnerCategories.length; i++) {
			if(ccOwnerCategories[i] != null && "CURRENT_PC".equals(ccOwnerCategories[i])){
				ccOwner = ccOwner + mailModuleUtil.getOwnerEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			} else if(ccOwnerCategories[i] != null && "ALL_REQUESTORS".equals(ccOwnerCategories[i])){
				ccOwner = ccOwner + mailModuleUtil.getAllRequestorsEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			} else if(ccOwnerCategories[i]!=null && !("".equals(ccOwnerCategories[i].trim()))){
				ccOwner = ccOwner + mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(), ccOwnerCategories[i], mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			}
		}
		cc = cc + ccOwner;
		log.debug ("MailModuleImpl:parseTemplate:ccOwner:"+ccOwner);
		
		//----
		String ccRole = getElementTextValue(templateElement, ELEMENT_CC_ROLE, false);
		if (ccRole != null && !("".equals(ccRole))) {
			if(OPERATIONAL_IMPLEMENTATION.equalsIgnoreCase(templateId)){
				ccRole = mailModuleUtil.getFWMgmtRegionEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			} else{
				ccRole = mailModuleUtil.getRoleEmail(ccRole, mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			}
		}
		cc = cc + ccRole;
		log.debug ("MailModuleImpl:parseTemplate:ccRole:"+ccRole);

		if(mailVO.getCcEmailAddress() != null && !("".equals(mailVO.getCcEmailAddress()))){
			cc = cc + mailVO.getCcEmailAddress();
		}
		if(templateId.equals(DIR_MAIL_INFO)){
			//notifyUsers=mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),testMode);
			String directorCCDL = C3parProperties.DIRECTOR_CC_DL+";";
			cc = cc + directorCCDL;
			 //log.debug ("MailModuleImpl:parseTemplate:notifyUsers:"+notifyUsers);
		} 
		
		
		c3parMailMessage.setCcAddresses(cc);

		//-------
		String bcc = getElementTextValue(templateElement, ELEMENT_BCC, false);
		if (bcc != null && !("".equals(bcc))) {
			bcc = bcc + EMAIL_ADDRESS_SEPERATOR;
		}
		if(mailVO.getBccEmailAddress() != null && !("".equals(mailVO.getBccEmailAddress()))){
			bcc = bcc + mailVO.getBccEmailAddress();
		}
		c3parMailMessage.setBccAddresses(bcc);
		log.debug ("MailModuleImpl:parseTemplate:bcc:"+bcc);
		
		//-------
		String subject = getElementTextValue(templateElement, ELEMENT_SUBJECT, true);
		if(mailVO.getMailSubject() != null && !("".equals(mailVO.getMailSubject()))){
			subject = subject +" "+ mailVO.getMailSubject();
		}
		if(subject == null || "".equals(subject)){
			throw new MailModuleException("The tag "+ELEMENT_SUBJECT+" is blank in the template : " + templateId);
		}
		String returnSubjectStr = searchVarsAndReplaceValues(subject, mailVO);
		c3parMailMessage.setMsgSubject(returnSubjectStr);
		log.debug ("MailModuleImpl:parseTemplate:returnSubjectStr:"+returnSubjectStr);
		
		//----
		String body = getElementTextValue(templateElement, ELEMENT_BODY, true);
		if(mailVO.getMailBody() != null && !("".equals(mailVO.getMailBody()))){
			body = body + " " + mailVO.getMailBody();
		}
		if(body == null || "".equals(body)){
			throw new MailModuleException("The tag "+ELEMENT_BODY+" is blank in the template : "+templateId);
		}
		String returnBodyStr = searchVarsAndReplaceValues(body, mailVO);//Need to check
		
		c3parMailMessage.setMsgContent(returnBodyStr);
		log.debug ("MailModuleImpl:parseTemplate:returnBodyStr:"+returnBodyStr);
		
		
		if(!templateId.equals(DIR_MAIL_INFO)){
			//Checking DoNotSendMailList - Ignoring emailId's in to,CC,Bcc list
			c3parMailMessage = checkForDoNotSendEmail(c3parMailMessage);
		}
		

			
		if ("true".equalsIgnoreCase(mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode))) {
			StringBuffer buf = new StringBuffer("");
			buf.append("TO:" + c3parMailMessage.getToAddresses() + "\n <br>");
			buf.append("CC:" + c3parMailMessage.getCcAddresses() + "\n <br>");
			buf.append("BCC:" + c3parMailMessage.getBccAddresses() + "\n <br>");
			c3parMailMessage.setMsgContentFootNote(buf.toString());
		
		} else {
			c3parMailMessage.setMsgContentFootNote("");
		}
		
		if(templateId.equals(DIR_MAIL_INFO)){
			String footnote = getElementTextValue(templateElement, FOOT_NOTE, true);
			c3parMailMessage.setRow(populateRow(templateElement, mailVO));
			Map<String,String> emerBuscritQuesAndAnswers=mailModuleUtil.getEmerBuscritQuesAnswers(mailVO.getConnectionId());
			//populateRow(templateElement, mailVO);
			c3parMailMessage.setQuestRow(populateInfo(emerBuscritQuesAndAnswers));
			c3parMailMessage.setMsgContentFootNote(c3parMailMessage.getMsgContentFootNote()+footnote);
		}
		c3parMailMessage.setRow(populateRow(templateElement, mailVO));
		
	return c3parMailMessage;
		
	}

	/**
	 * Populate row.
	 *
	 * @param templateElement the template element
	 * @param mailVO the mail vo
	 * @return the mail msg display row[]
	 * @throws MailModuleException the mail module exception
	 */
	private MailMsgDisplayRow[] populateRow(Element templateElement, BaseMailVO mailVO) throws MailModuleException{
		//log.debug("MailModule:MailModuleImpl:populateInfo:: Entered");
		MailMsgDisplayRow[] rows = null;
		NodeList listOfRows = templateElement.getElementsByTagName(ELEMENT_ROW);
		rows = new MailMsgDisplayRow[listOfRows.getLength()];
		for (int s1 = 0; s1 < listOfRows.getLength(); s1++) {
			rows[s1] = new MailMsgDisplayRow();
			Node infoNode = listOfRows.item(s1);
			if(infoNode.getNodeType() == Node.ELEMENT_NODE){
				Element rowElement = (Element)infoNode;
				rows[s1].setInfo(populateInfo(rowElement, mailVO));
			}
		}
		//log.debug("MailModule:MailModuleImpl:populateInfo:: Exited");
		return rows;
	}

	/**
	 * Populate info.
	 *
	 * @param templateElement the template element
	 * @param mailVO the mail vo
	 * @return the mail msg display info[]
	 * @throws MailModuleException the mail module exception
	 */
	private MailMsgDisplayInfo[] populateInfo(Element templateElement, BaseMailVO mailVO) throws MailModuleException{
		//log.debug("MailModule:MailModuleImpl:populateInfo:: Entered");
	MailMsgDisplayInfo[] infos = null;
	NodeList listOfInfos = templateElement.getElementsByTagName(ELEMENT_INFO);
	infos=new MailMsgDisplayInfo[listOfInfos.getLength()];
	//log.debug("MailModule:MailModuleImpl:populateInfo:ListOfInfos:"+listOfInfos.getLength());
	for (int s1 = 0; s1 < listOfInfos.getLength(); s1++) {
		infos[s1] = new MailMsgDisplayInfo();
		Node infoNode = listOfInfos.item(s1);
		if(infoNode!= null && infoNode.getNodeType() == Node.ELEMENT_NODE){
			Element infoElement = (Element)infoNode;
			NodeList infoChildList = infoElement.getChildNodes();
			//log.debug("MailModule:MailModuleImpl:populateInfo:infoChildListLength:"+infoChildList.getLength());
			if(infoChildList != null){
				for (int i = 0; i < infoChildList.getLength(); i++) {
					Node infoChildNode = infoChildList.item(i);
					//log.debug("MailModule:MailModuleImpl:populateInfo:infoNodeType:"+infoChildNode.getNodeType());
					/*System.out.println("MailModule:MailModuleImpl:populateInfo:infoNodeType:"+infoChildNode.getNodeType());*/
					if(infoChildNode != null && infoChildNode.getNodeType() == Node.ELEMENT_NODE){
						Element infoChildElement = (Element)infoChildNode;
						NodeList infoChldList = infoChildElement.getChildNodes();
						/*System.out.println("MailModuleImpl.populateinfo.infoChldList::"+infoChldList
								+"infoChldList.item(0):"+infoChldList.item(0));*/
						if(infoChldList != null && infoChldList.item(0)!= null){
							String infoLabel = ((Node)infoChldList.item(0)).getNodeValue().trim();
							/*System.out.println("MailModuleImpl.populateinfo.infoLabel::"+infoLabel);*/
							String returninfoStr = searchVarsAndReplaceValues(infoLabel, mailVO);
							//log.debug("MailModule:MailModuleImpl:populateInfo:returninfoStr:"+returninfoStr);
							if (i == 1) {
								infos[s1].setLabel(returninfoStr);
							} else {
								infos[s1].setValue(returninfoStr);
							}
						}
					}
				}
			}
		}
	}
	    //log.debug("MailModule:MailModuleImpl:populateInfo:: Exited");
	return infos;
}

	/**
	 * Send mail.
	 *
	 * @param mailMsg the mail msg
	 * @throws Exception the exception
	 */
	public void sendMail(C3PARMailMessage mailMsg,String testModeParam) throws Exception{
		log.info("MailModule:MailModuleImpl:sendMail:: Entered");
		
		//	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {
		//   		 "ejbContext.xml",
		//	  "dataAccessContext.xml" });
		//	JavaMailSenderImpl mailSender = (JavaMailSenderImpl)context.getBean("mailSender");
		MimeMessage message = this.mailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = null;
			
			if ((mailMsg.getAttachments() != null && mailMsg.getAttachments().size() > 0)
					|| (mailMsg.getFileAttachments() != null && mailMsg.getFileAttachments().size() > 0)) {
				//helper = new MimeMessageHelper(message,"UTF-8");
				helper = new MimeMessageHelper(message,true,"UTF-8");
			} else {
				helper = new MimeMessageHelper(message,"UTF-8");
			}

			if("true".equalsIgnoreCase(testModeParam)){
				String[] emailIds = testEmail.split("\\;");
				ArrayList<String> removeEmptyEmails = new ArrayList<String>(Arrays.asList(emailIds));
				removeEmptyEmails.removeAll(Arrays.asList(null,""));
				String[] emailIdsChecked = removeEmptyEmails.toArray(new String[removeEmptyEmails.size()]);
				helper.setTo(emailIdsChecked);
				log.debug("MailModule:MailModuleImpl:sendMail:testEmail:"+testEmail);
			} else{
				String[] emailIds = mailMsg.getToAddresses().split("\\;");
				ArrayList<String> removeEmptyEmails = new ArrayList<String>(Arrays.asList(emailIds));
				removeEmptyEmails.removeAll(Arrays.asList(null,""));
				String[] emailIdsChecked = removeEmptyEmails.toArray(new String[removeEmptyEmails.size()]);
				helper.setTo(emailIdsChecked);
				log.debug("MailModule:MailModuleImpl:sendMail:ToemailIds:"+mailMsg.getToAddresses());
			}
			if(mailMsg.getCcAddresses() != null && !("".equals(mailMsg.getCcAddresses())) && !("true".equalsIgnoreCase(testModeParam))){
				String[] emailIds = mailMsg.getCcAddresses().split("\\;");
				ArrayList<String> removeEmptyEmails = new ArrayList<String>(Arrays.asList(emailIds));
				removeEmptyEmails.removeAll(Arrays.asList(null,""));
				String[] emailIdsChecked = removeEmptyEmails.toArray(new String[removeEmptyEmails.size()]);
				helper.setCc(emailIdsChecked);
				log.debug("MailModule:MailModuleImpl:sendMail:ccemailIds:"+emailIds);
			}
			if(mailMsg.getBccAddresses() != null && !("".equals(mailMsg.getBccAddresses())) && !("true".equalsIgnoreCase(testModeParam))){
				String[] emailIds = mailMsg.getBccAddresses().split("\\;");
				ArrayList<String> removeEmptyEmails = new ArrayList<String>(Arrays.asList(emailIds));
				removeEmptyEmails.removeAll(Arrays.asList(null,""));
				String[] emailIdsChecked = removeEmptyEmails.toArray(new String[removeEmptyEmails.size()]);
				helper.setBcc(emailIdsChecked);
				log.debug("MailModule:MailModuleImpl:sendMail:BccemailIds:"+emailIds);
			}
			
			/*gs71854: Prefix the environment variable in the subject line to differentiate source of generated email notifications
			If the environment is PRD then do not prefix else  subject line will be prefixed
			*/
			  helper.setSubject((("PRD").equalsIgnoreCase(environment) ? mailMsg.getMsgSubject() : environment+" : "+mailMsg.getMsgSubject()));
			helper.setFrom(mailMsg.getFromAddress());
			helper.setText(mailMsg.getMsgContent(), true);
			//helper.setText(message.getContent().toString(),true);
			//		log.info("SUBJECT::"+message.getSubject());
			//		log.info("BODY::"+message.getContent().toString());
			
			//getAttachments working only for text files 
			if (mailMsg.getAttachments() != null && mailMsg.getAttachments().size() > 0) {
				Set<Entry<String,String>> attachments =  mailMsg.getAttachments().entrySet();
				
				if (attachments != null && attachments.size() > 0) {
					for (final Entry<String,String> attachment : attachments) {
						InputStreamSource inputStreamSource = new InputStreamSource() {
							
							public InputStream getInputStream() throws IOException {
								InputStream inputStream = new ByteArrayInputStream(attachment.getValue().getBytes());
								return inputStream;
							}
						};
						helper.addAttachment(attachment.getKey(), inputStreamSource);
					}
				}
			}

			log.debug("MailModule:MailModuleImpl:sendMail: attaching files");
			//getFileAttachments for all type of files.
			if (mailMsg.getFileAttachments() != null && mailMsg.getFileAttachments().size() > 0) {
				Set<Entry<String,byte[]>> attachments =  mailMsg.getFileAttachments().entrySet();
				
				if (attachments != null && attachments.size() > 0) {
					for (final Entry<String,byte[]> attachment : attachments) {
						InputStreamSource inputStreamSource = new InputStreamSource() {
							
							public InputStream getInputStream() throws IOException {
								InputStream inputStream = new ByteArrayInputStream(attachment.getValue());
								return inputStream;
							}
						};
						helper.addAttachment(attachment.getKey(), inputStreamSource);
					}
				}
			}
			
			/*InputStreamSource inputStreamSource = new InputStreamSource() {
				
				@Override
				public InputStream getInputStream() throws IOException {
					DataHandler dataHandler = new DataHandler(new URL("https://ccgfwlm30d.nam.nsroot.net:31945/ctpar/manageAclVarianceAction.do?"));
					InputStream inputStream = dataHandler.getInputStream();
					return inputStream;
				}
			};
			helper.addAttachment(attachment.getKey(), inputStreamSource);*/
			
			this.mailSender.send(message);
			this.mailModuleUtil.mailActivityAudit(mailMsg);
			
		} catch (MessagingException e) {
			log.error(e, e);
		} catch (Exception e) {
			log.error(e, e);
		}
		log.info("MailModule:MailModuleImpl:sendMail:: Exited");
	}

	/**
	 * Sets the manage ti process impl.
	 *
	 * @param manageTIProcessImpl the new manage ti process impl
	 */
	public void setManageTIProcessUtil(ManageTIProcessUtil manageTIProcessUtil) {
		this.manageTIProcessUtil = manageTIProcessUtil;
	}

	/**
	 * Sets the template file location.
	 *
	 * @param templateFileLocation the new template file location
	 */
	public void setTemplateFileLocation(String templateFileLocation) {
		this.templateFileLocation = templateFileLocation;
	}

	/**
	 * Sets the test mode.
	 *
	 * @param testMode the new test mode
	 */
	public void setTestMode(String testMode) {
		this.testMode = testMode;
	}

	/**
	 * Sets the test email.
	 *
	 * @param testEmail the new test email
	 */
	public void setTestEmail(String testEmail) {
		this.testEmail = testEmail;
	}

	/**
	 * Sets the mail sender.
	 *
	 * @param mailSender the new mail sender
	 */
	public void setMailSender(JavaMailSenderImpl mailSender) {
		this.mailSender = mailSender;
	}

	/**
	 * Sets the mail module util.
	 *
	 * @param mailModuleUtil the new mail module util
	 */
	public void setMailModuleUtil(MailModuleUtil mailModuleUtil) {
		this.mailModuleUtil = mailModuleUtil;
	}
	/*private Connection obtainConnection(){
		Connection con=null;
		try{

		 Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			con = DriverManager.getConnection(
					"url=jdbc:oracle:thin:@CPNAWRNWV-501MV:1521:CCRDEV",
					"c3par", "c3pardev1231");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;

	} */
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendComputationCompletionEmail(long, boolean, boolean, boolean)
	 */
	public void sendComputationCompletionEmail(long connectionID, boolean isFWImplementation, boolean isAppsense , boolean isProxy ) throws Exception {
		log.info("Computation email for ConnectionId "+connectionID+" For flags "+isFWImplementation+" isAppsense "+" isProxy "+isProxy);
		/*if(isFWImplementation)
			sendEmailFAFCompletion(Long.valueOf(connectionID), "FAF");
		if(isProxy)
			sendEmailFAFCompletion(Long.valueOf(connectionID), "PAF");
		if(isAppsense)
			sendEmailFAFCompletion(Long.valueOf(connectionID), "AAF");*/

	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendEmailFAFCompletion(java.lang.Long, java.lang.String)
	 */
	/*public void sendEmailFAFCompletion(Long connectionID, String reportType) throws Exception {
		log.info("calling sendEmailFAFCompletion");

		//uncomment when checking in
		String sendFAFCompletionEmail = FAF_COMPLETION_EMAIL;
		String sendEmail = "TRUE";
		boolean tstSendMailMode = false;
		if (sendEmail != null && sendEmail.equalsIgnoreCase("TRUE"))
			tstSendMailMode = true;

		try {

			if (connectionID != null) {
				StringBuffer  sql = new StringBuffer(" select distinct cu.email, cu.first_name, cu.last_name, cr.connection_name from c3par_users cu, faf_queue_con_requests fqcr, con_req cr " );
				sql.append(" where fqcr.requester_soeid=cu.sso_id and nvl(cu.is_terminated,' ') != 'TE' and cr.id=fqcr.con_req_id and fqcr.id=(select max(id) from faf_queue_con_requests where con_req_id="+connectionID.toString()+") and fqcr.con_req_id= "+connectionID.toString());
				//		StringBuffer  updatesql= new StringBuffer("update faf_queue_con_requests set completed_time=sysdate where completed_time is null and con_req_id="+ connectionID.toString());
				String emailAddr = null;
				String requesterFirstName = null;
				String requesterLastName = null;
				String connectionName = null;
				String mailSubject = null;
				  
				SqlRowSet	rs =  jdbcTemplate.queryForRowSet(sql.toString());
				
				while (rs.next()){
					if (rs.getString(1) != null)
						emailAddr = rs.getString(1);
					requesterFirstName = rs.getString(2);
					requesterLastName = rs.getString(3);
					connectionName = rs.getString(4);
					break;
				}
				MimeMessage msg = this.mailSender.createMimeMessage();
				MimeMessageHelper helper = new MimeMessageHelper(msg, false);
				if (emailAddr != null) {
					String[] emailAddress = new String[1];
					emailAddress[0] = emailAddr;
					for (int j = 0; j < emailAddress.length; j++)
						log.debug(" email Address " + j + emailAddress[j]);
					boolean msgExists = false;
					StringBuffer msgTxt = new StringBuffer();
					String displayReportType = (reportType == "FAF") ? "Firewall Access Form (FAF)" : (reportType == "PAF") ? "Proxy Access Form (PAF)" : (reportType == "AAF") ? "AppSense Access Form (AAF)" : "";
					mailSubject = displayReportType+" Calculation Completed: Connection Request: "+connectionID+" - "+connectionName;
					helper.setSubject(mailSubject);
					helper.setSentDate(new Date());
					helper.setTo(emailAddress);
					helper.setCc(sendFAFCompletionEmail);
					msgTxt.append("Hello "+requesterFirstName+" "+requesterLastName+" ("+displayReportType+" Requester) :");
					msgTxt.append("\n\n");
					msgTxt.append("This email has been auto-generated by the C3PAR system to alert you that "+displayReportType+" has been successfully calculated for the below connection, as requested.");
					msgTxt.append("\n\n");
					msgTxt.append("Connection ID: "+connectionID.toString());
					msgTxt.append("\nConnection Name: "+connectionName);
					msgTxt.append("\n\n");
					String implementor = (reportType.equals("FAF")) ? "PSO" : (reportType.equals("PAF")) ? "PAFPSO" : (reportType.equals("AAF")) ? "AAFPSO" : "";
					msgTxt.append("Your "+displayReportType+" is now available for review in the system. Bel" +
							"ow is the summary of Add and /or Delete Combinations generated by "+displayReportType+" Computation. If the output contains delete rules and do not want them to be processed please contact " +implementor+" immediately.");

					msgTxt.append("\n");

					List policyNameList = new ArrayList();

					if (reportType.equals("FAF")) {

						policyNameList= mailModuleUtil.getFAFCombinations(connectionID.toString());
					}
					else if (reportType.equals("PAF")) {
						policyNameList= mailModuleUtil.getPAFCombinations(connectionID.toString());
					}
					else if (reportType.equals("AAF")) {
						policyNameList= mailModuleUtil.getAAFCombinations(connectionID.toString());
					}
					Iterator rit = policyNameList.iterator();
					if (policyNameList.size() == 0)
					{
						msgTxt.append("\n");
						msgTxt.append("There are no Add and /or Delete Combinations.");
					}
					while (rit.hasNext())
					{
						msgTxt.append("\n");
						msgTxt.append((String)rit.next());
					}

					msgTxt.append(" \n\nYou may view/review the connection for checking "+displayReportType+". "+"\n");
					msgTxt.append(" \nDO NOT Reply to this message. Please contact '*IS GLOBAL CCR', in case of any problem. "+"\n\n");
					msgTxt.append("Thank you," + "\n");
					msgTxt.append("C3PAR");
					if (msg != null){
						msg.setText(msgTxt.toString());
					}
					//log.debug("MESSAGE IS "+msgTxt.toString());
					if (msg != null) {
						msgExists = true;
					}
					if (msgExists && tstSendMailMode) {
						try {
							log.debug("sending email to FAFRequester for connection id"+connectionID);
							this.mailSender.send(msg);			
							//insert mail information into TI_MAIL_AUDIT for Audit
							C3PARMailMessage mailMsg = new C3PARMailMessage();
							mailMsg.setTiRequestID(new Long(0));
							mailMsg.setTemplateID("");
							mailMsg.setToAddresses(emailAddr);
							mailMsg.setCcAddresses(sendFAFCompletionEmail);
							mailMsg.setMsgSubject(mailSubject);
							mailMsg.setMsgContent(msgTxt.toString());				
							this.mailModuleUtil.mailActivityAudit(mailMsg);
						}
						catch(MailException ex) {
							// simply log it and go on...
							log.error(ex,ex);
						} catch (Exception e){
							log.error(e,e);
						}
						
						}
					}

				}
			}
		catch (Exception e) {
			log.error(e);
		} 
	}*/


	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendDirectorApprovalEmail(java.lang.Long, java.lang.String)
	 */
	public boolean sendDirectorApprovalEmail(Long primaryId, String relationShipType) {
		log.info("MailModuleImpl :: sendDirectorApprovalEmail Starts ");
		TIProcess tiProcess = null;
		InputMailVO inputMailVO = new InputMailVO();
		C3PARMailMessage mailMsg = new C3PARMailMessage();
		Long requestID =  null;
		boolean sendErrorFlag = false;
        try{
        	requestID = mailModuleUtil.getTiRequestId(primaryId);
        	if (tiProcess == null && requestID != null) {
				tiProcess = manageTIProcessUtil.getProcessData(requestID);
			}
			if (tiProcess != null){
				log.debug("MailModuleImpl :: tiProcess is not null");
				inputMailVO.setTiProcess(tiProcess);
				inputMailVO.setConnectionId((tiProcess.getId()).longValue()+"");
				inputMailVO.setVersionNumber(tiProcess.getVersionNumber());
				
				if(tiProcess.getTiRequest() != null && tiProcess.getTiRequest().getId() != null ){
					inputMailVO.setTirequestID(tiProcess.getTiRequest().getId());
					inputMailVO.setLastSubmitterComments(mailModuleUtil.getLastSubmitterComments(tiProcess.getTiRequest().getId()));
					inputMailVO.setLastSubmitterRole(mailModuleUtil.getLastSubmitterRole(tiProcess.getTiRequest().getId()));
				}
				String businessJustification = accessFormTextGenerator.getCurrentBusJustfication(requestID);
				log.debug("Managing director:: Business justification : "+businessJustification);				
				inputMailVO.setBusinessJustification(businessJustification);
			}
			log.debug("MailModuleImpl :: Before calling ParseTemplate");
			
			mailMsg = this.parseTemplateNew(DIR_MAIL_INFO, inputMailVO, true);
			sendMail(mailMsg,mailModuleUtil.testModeFlag(Long.valueOf(inputMailVO.getConnectionId()),testMode));
			
		} catch (BusinessException busiEx){
			log.debug("Inside Business ExceptionHandler");
			sendErrorFlag=true;
			throw new BusinessException("Please add Direct Level Approver in Target Contacts");
		} catch(Exception e){
			log.error("Exception in sending Director Approval Mail for planning id:"+primaryId+":"+e.getMessage(),  e);
			try{
				mailMsg = this.parseTemplateNew(REDIRECTION_EMAIL, inputMailVO, false);
				sendMail(mailMsg,mailModuleUtil.testModeFlag(Long.valueOf(inputMailVO.getConnectionId()),testMode));
			} catch (Exception ex){
				log.error("Exception in sending RedirectionMail::"+e.getMessage(),  ex);
				log.error(ex,  ex);
				sendErrorFlag = true;
			}
		}
		log.info("MailModuleImpl :: sendDirectorApprovalEmail Ends "+sendErrorFlag);
		return sendErrorFlag;
	}


	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendEmailToRegisterPeopleRecord(java.lang.Long, java.lang.String)
	 */
	public boolean sendEmailToRegisterPeopleRecord(Long tiRequestId, String relationShipType) {
		log.info("MailModuleImpl :: sendEmailToRegisterPeopleRecord Starts ");

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String toEmailAddress = null;
		String ccEmailAddress = null;
		// MailModuleUtil mmUtil = new MailModuleUtil();
		boolean mailSentFlag = true;
		try {
			MimeMessage msg = this.mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(msg, false,"UTF-8");
			boolean msgExists = false;
			StringBuffer msgTxt = new StringBuffer();
			String proCoordEmail = null;
			String busOwnerEmail = null;
			boolean busownerFlag = false;
			String userSoeId = null;
			String connectionName = null;
			String versionNo = null;
			String connectionId = null;
			String mailSubject=" Missing People Record - Action Required.";
			helper.setSentDate(new Date());

			helper.setFrom(DL_IS_GLOBAL_CCR);
			ccEmailAddress = DL_IS_GLOBAL_CCR;
			Map busOwnerEmailAddressMap = mailModuleUtil.getRFCPeopleRecordAddresses(
					tiRequestId, relationShipType,
					ROLE_BUS_OWNER);
			if (busOwnerEmailAddressMap != null
					&& !busOwnerEmailAddressMap.isEmpty()) {

				if (busOwnerEmailAddressMap
						.get(ROLE_BUS_OWNER) != null) {
					if (!busOwnerEmailAddressMap.get(
							ROLE_BUS_OWNER).toString()
							.trim().equals("")) {
						busOwnerEmail = (String) busOwnerEmailAddressMap
						.get(ROLE_BUS_OWNER);
						String soeId = (String) busOwnerEmailAddressMap
						.get("SSO_ID");
						userSoeId = soeId + "("
						+ ROLE_BUS_OWNER + ")";
						busownerFlag = true;
					} else {
						busownerFlag = false;
						throw new Exception(
						"Please provide business Owner Information in the contacts.");
					}

				}
			}

			Map projCoordEmailAddressMap = mailModuleUtil.getRFCPeopleRecordAddresses(
					tiRequestId, relationShipType, ROLE_PC);
			if (projCoordEmailAddressMap != null
					&& projCoordEmailAddressMap.size() > 0) {

				if (projCoordEmailAddressMap.get(ROLE_PC) != null) {
					if (!projCoordEmailAddressMap.get(
							ROLE_PC).toString().trim().equals("")) {
						proCoordEmail = (String) projCoordEmailAddressMap
						.get(ROLE_PC);
						String pcSoeId = (String) projCoordEmailAddressMap
						.get("SSO_ID");
						if (!busownerFlag) {
							userSoeId = pcSoeId + "("
							+ ROLE_PC + ")";
						}
					}
				}
				if (projCoordEmailAddressMap.get("CON_NAME") != null) {
					connectionName=(String)projCoordEmailAddressMap.get("CON_NAME");
				}
				if (projCoordEmailAddressMap.get("CON_ID") != null) {
					connectionId=(String)projCoordEmailAddressMap.get("CON_ID");
				}
				if (projCoordEmailAddressMap.get("CON_VERSION") != null) {
					versionNo=(String)projCoordEmailAddressMap.get("CON_VERSION");
				}

			}
			String tmpConnId = "";
			String tmpMailSub = null;
			if (connectionId != null && versionNo != null)
				tmpConnId = connectionId + "." + versionNo;
			if (connectionName != null)
				tmpMailSub = tmpConnId + " - " + connectionName;

			if (tmpMailSub != null)
				mailSubject=tmpMailSub+" - "+mailSubject;
			if (msg != null) {
				msg.setSubject(mailSubject);
			}
			if (busownerFlag) {
				toEmailAddress = busOwnerEmail;
				ccEmailAddress = ccEmailAddress + ";" + proCoordEmail;
			} else {
				toEmailAddress = proCoordEmail;
			}
			if ("true".equalsIgnoreCase(testMode)) {
				String[] emailIds = testEmail.split("\\;");
				helper.setTo(emailIds);
			} else {
				if (toEmailAddress != null && !("".equals(toEmailAddress))) {
					String[] emailIds = toEmailAddress.split("\\;");
					helper.setTo(emailIds);
				}
				if (ccEmailAddress != null && !("".equals(ccEmailAddress))) {
					String[] emailIds = ccEmailAddress.split("\\;");
					helper.setCc(emailIds);
				}
			}



			if (busownerFlag) {
				msgTxt.append("Dear Business Owner ");
			} else {
				msgTxt.append("Dear Project Coordinator,");
			}
			msgTxt.append("<br/><br />");
			msgTxt.append("User with SOE ID ");
			msgTxt.append(userSoeId);
			msgTxt.append(" requires a people record  ");
			msgTxt
			.append("in VirtualChange system for creating RFC (Request For Change) for CCR Id "+tmpConnId+" change implementation.");
			msgTxt.append("<br/><br />");
			msgTxt
			.append("You are required to login to Citi Marketplace and request for the people record entitlement in VirtualChange.");
			msgTxt
			.append("Failing to have this entitlement created will stop your request processing beyond Technical Architecture step ");
			msgTxt.append("for all firewall change requests.");
			msgTxt.append("<br/><br />");
			msgTxt
			.append("You may contact CCR helpdesk for further assistance.");

			msgTxt.append("<br/><br />");

			msgTxt.append("Thank you," + "<br />");
			msgTxt.append("The CCR");
			log.debug(msgTxt.toString());
			helper.setText(msgTxt.toString(), true);

			if (msg != null) {
				msgExists = true;
			}
			try {
				if (msgExists) {
					this.mailSender.send(msg);		
					//insert mail information into TI_MAIL_AUDIT for Audit
					C3PARMailMessage mailMsg = new C3PARMailMessage();
					mailMsg.setTiRequestID(tiRequestId);
					mailMsg.setTemplateID("");
					mailMsg.setToAddresses(toEmailAddress);
					mailMsg.setCcAddresses(ccEmailAddress);
					mailMsg.setMsgSubject(mailSubject);
					mailMsg.setMsgContent(msgTxt.toString());				
					this.mailModuleUtil.mailActivityAudit(mailMsg);
				}
			} catch (MailException ex) {
				log.error(ex,ex);
				mailSentFlag = false;
				throw new Exception(
				"Not able to send Mail, Please try again later.");
			} catch (Exception e) {
				log.error(e,e);
				mailSentFlag = false;
			}
		}catch (ApplicationException e) {
			log.error(e,e);
			mailSentFlag = false;
			throw new ApplicationException(e.getMessage());
		}
		catch (Exception e) {
			log.error(e,e);
			mailSentFlag = false;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();

			} catch (Exception e) {
				log.error(e,e);
			}
		}
		log.info("MailModuleImpl :: sendDirectorApprovalEmail Ends ");
		return mailSentFlag;
	}
	
/*
 gs71854: commented this code as template is migrated to new notification framework
 */
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendEmailOnBaseLineChange
	 */
/*	public void sendEmailOnBaseLineChange(String oldBaseLine, String newBaseLine) throws Exception {
		log.debug("calling sendEmailOnBaseLineChange :: starts");
		try {
			MimeMessage msg = this.mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(msg, false);
			
			DateFormat dateFormat= new SimpleDateFormat("MM-dd-yyyy");
			String strDate =dateFormat.format(new Date());
			//Date currentDate=(Date)dateFormat.parse(strDate);
			
			StringBuffer msgTxt = new StringBuffer();
			boolean msgExists = false;
			String mailSubject = "CCR Notification :: Rule Application Baseline Change";
			helper.setFrom(DL_IS_GLOBAL_CCR);
			helper.setSubject(mailSubject);
			helper.setSentDate(new Date());
			if("true".equalsIgnoreCase(testMode)){
				String[] emailIds = testEmail.split("\\;");
				log.debug("sendEmailOnBaseLineChange :: toAddress ==> "+emailIds);
				helper.setTo(emailIds);
			} else {
				helper.setTo("is3paswg@imcnam.ssmb.com");
				helper.setCc(DL_IS_GLOBAL_CCR);
			}
			//helper.setCc("");
			msgTxt.append("TPASWG,");
			msgTxt.append("<br/><br/>");
			msgTxt.append("The rules for determining the risk of connectivity change requests in the Citi Connectivity " +
					"Registry (CCR) has been updated.  The version has incremented from <b>["+oldBaseLine+"]</b> to <b>["+newBaseLine+"]</b>");
			msgTxt.append("<br/><br/>");
			msgTxt.append("This change went into effect on ["+strDate+"].  Please follow the GIS risk engine control procedures to verify the baseline changes.");
			msgTxt.append("<br/><br/>");
			msgTxt.append("- Citi Connectivity Registry");
			msgTxt.append("<br/><br/>");
			msgTxt.append(" Note:. If you need assistance, or want the detailed risk chart which describes this change please e-mail *IS GLOBAL CCR");
			msgTxt.append("<br/><br/>");	
			if (msg != null){
				msg.setText(msgTxt.toString());
			}
			log.debug("MESSAGE IS "+msgTxt.toString());
			helper.setText(msgTxt.toString(), true);
			if (msg != null) {
				msgExists = true;
			}
			if (msgExists) {
				try {
					this.mailSender.send(msg);
					//insert mail information into TI_MAIL_AUDIT for Audit
					C3PARMailMessage mailMsg = new C3PARMailMessage();
					mailMsg.setTiRequestID(new Long(0));
					mailMsg.setTemplateID("");
					if("true".equalsIgnoreCase(testMode)){
						String[] emailIds = testEmail.split("\\;");
						log.debug("sendEmailOnBaseLineChange :: toAddress ==> "+emailIds);
						mailMsg.setToAddresses(emailIds.toString());
					} else {
						mailMsg.setToAddresses("is3paswg@imcnam.ssmb.com");
						mailMsg.setCcAddresses(DL_IS_GLOBAL_CCR);
					}
					mailMsg.setMsgSubject(mailSubject);
					mailMsg.setMsgContent(msgTxt.toString());				
					this.mailModuleUtil.mailActivityAudit(mailMsg);
				}
				catch(MailException ex) {
					// simply log it and go on...
					log.error(ex,ex);
				} catch (Exception e){
					log.error(e,e);
				}
			}
		}catch (Exception e) {
			log.error(e);
		} 
		log.debug("calling sendEmailOnBaseLineChange :: ends");
	}
*/

public void sendEmailOnBaseLineChange (String oldBaseLine, String newBaseLine){
		log.info("sendEmailOnBaseLineChange method starts 1");
		
		//Reusing the same c3parMailMessage class that will be passed to xsl. C3parMailMessage has been annoted as rootElement
		C3PARMailMessage mailMessage = new C3PARMailMessage();
		
		//Date on which baseline change went to effect
		DateFormat dateFormat= new SimpleDateFormat("MM-dd-yyyy");
		String effectiveDate =dateFormat.format(new Date());
		   try{
			 //get the required XSL Template from Database new table MAIL_TEMPLATE. 
				MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(NOTIFY_RISK_BASELINE_CHANGE);

				//setting the from address
				mailMessage.setFromAddress(DL_IS_GLOBAL_CCR);
				
				//Reuse the Row/Info combination to set and pass the dynamic values
				
				//create and set info for oldBaseLine
				MailMsgDisplayInfo oldBaseLineInfo = new MailMsgDisplayInfo();
				oldBaseLineInfo.setLabel("oldBaseLine");
				oldBaseLineInfo.setValue(oldBaseLine);
				//create and set info for newBaseLine				
				MailMsgDisplayInfo newBaseLineInfo = new MailMsgDisplayInfo();
				newBaseLineInfo.setLabel("newBaseLine");
				newBaseLineInfo.setValue(newBaseLine);
				//create and set info for effectiveDate
				MailMsgDisplayInfo effectiveDateInfo = new MailMsgDisplayInfo();
				effectiveDateInfo.setLabel("effectiveDate");
				effectiveDateInfo.setValue(effectiveDate);

				//Add all 3 info objects into array
				MailMsgDisplayInfo[] infoArray = {oldBaseLineInfo,newBaseLineInfo,effectiveDateInfo};
				log.info("infoArray size -> "+infoArray.length);
				
				//Create a row object and set the infoArray into the row attribute
				MailMsgDisplayRow rowData = new MailMsgDisplayRow();
				rowData.setInfo(infoArray);
				
				//Create an array of Rows. In this case we have only single row containing 3 info objects
				MailMsgDisplayRow[] rowArray = {rowData};
				mailMessage.setRow(rowArray);
				
				//set ToAddress
				mailMessage.setToAddresses("is3paswg@imcnam.ssmb.com");
			
				log.debug("rowArray size -> "+rowArray.length);
				
				mailMessage.setC3parBaseUrl(C3PAR_BASE_URL);
				
				//Apply the XML values to XSL Template using XSLT transformation
				String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate, mailMessage);
				
				mailMessage.setMsgSubject(mailtemplate.getSubject());
				mailMessage.setMsgContent(mailContent);
				log.debug(mailContent);
				sendMail(mailMessage,mailModuleUtil.testModeFlag(null,testMode));			  
		   }
		   catch (Exception e) {
			   log.error("Exception in sending reject contact mail to TA or SA "+e.getMessage(),  e);
		}		
	}	
	
	private StringWriter convertoXML(Object o) throws JAXBException {
		
		JAXBContext context = JAXBContext.newInstance(o.getClass());
		Marshaller m = context.createMarshaller();
	    m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
	    StringWriter sw = new StringWriter();
		
		//Converting supervisorEmail object to XML file
		m.marshal(o, sw );
		
		//log.debug("marshaller output "+sw.toString());
		
		//Apply the XML values to XSL Template using XSLT transformation
			StringWriter outWriter = new StringWriter();
			StreamResult result = new StreamResult(outWriter);
			
			
		return sw;
	    
	    
	}
	
	private String transformObjectXMLtoXSLTemplate(MailTemplates mailtemplate,Object objectToTransform) {
		
		TransformerFactory tFactory = TransformerFactory.newInstance();
		Transformer transformer;
		StringWriter outWriter = new StringWriter();
		StreamResult result = new StreamResult(outWriter);
		try {
			log.debug("mailtemplate.getBody().getBytes() -> "+mailtemplate.getBody().getBytes());
			transformer = tFactory.newTransformer(new StreamSource(new ByteArrayInputStream(mailtemplate.getBody().getBytes())));
			transformer.transform(new javax.xml.transform.stream.StreamSource(new StringReader(convertoXML(objectToTransform).toString())), result);
		}
		 catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return outWriter.getBuffer().toString();
	}
	
	private String transformObjectXMLtoXSLTemplate(String mailtemplateBody,String transformedXml) {
		TransformerFactory tFactory = TransformerFactory.newInstance();
		Transformer transformer;
		StringWriter outWriter = new StringWriter();
		StreamResult result = new StreamResult(outWriter);
		try {
			transformer = tFactory.newTransformer(new StreamSource(new ByteArrayInputStream(mailtemplateBody.getBytes())));
			transformer.transform(new javax.xml.transform.stream.StreamSource(new StringReader(transformedXml)), result);
		}
		 catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return outWriter.getBuffer().toString();
	}
	 	
	public void sendEmailToSupervisorList(List<GDWUser> users) {
		log.info("MailModuleImpl :: sendEmailToSupervisorList Starts ");
		SupervisorEmail supervisorEmail = new SupervisorEmail();
	    
	   try{
		 //get the required XSL Template from Database new table MAIL_TEMPLATE. Currently, we are using GenericMailTemplate for supervisor emails
			MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById("NOTIFY_CONTACT_REPLACED");
			
		    //Group by Supervisor_geid and create Map key = Supervisor_geid and value is list of unique connections/roles
		    Map<String,List<GDWUser>> connRoleByManagerGeIdMap =  new LinkedHashMap<String,List<GDWUser>>();
		    for (GDWUser user : users) {
		    	    List connRoleForUser = connRoleByManagerGeIdMap.get(user.getGeid());
		    	    if (connRoleForUser == null) {
		    	    	connRoleForUser = new ArrayList<GDWUser>();
		    	    	connRoleByManagerGeIdMap.put(user.getGeid(), connRoleForUser);
		    	    }
		    	    connRoleForUser.add(user);
		    }
		    log.info("map size -->"+connRoleByManagerGeIdMap.size());

		    //Iterate over the Map containing Supervisor_geid and corresponding list of connRoles
		    for (Entry<String, List<GDWUser>> entry : connRoleByManagerGeIdMap.entrySet()){
			    ArrayList<SupervisorEmail.ConnectionRole> connRoleList = new ArrayList();
			    SupervisorEmail.ConnectionRole connRoleInnerObj = null;

			    List<GDWUser> connRoles = entry.getValue();
			    //loop
			    log.info("connRoles size-->"+connRoles.size());
			    
			    //We need create an Array of ConnectionRole objects and pass it to SupervisorEmail object
				for (GDWUser connRole : connRoles){
					connRoleInnerObj = new SupervisorEmail.ConnectionRole();
					connRoleInnerObj.setCcr_id(connRole.getFciid_2());
					//department code is nothing but the Role of the contact
					connRoleInnerObj.setRole(connRole.getDepartment_code());
					connRoleList.add(connRoleInnerObj);
					
				}
			    //setting the required values in SupervisorEmail object. This object will be marshalled to give us xml containing required values in XSL Template
				supervisorEmail.setC3parBaseUrl(C3PAR_BASE_URL); 
		    	supervisorEmail.setConnRoles(connRoleList.toArray(new SupervisorEmail.ConnectionRole[connRoleList.size()]));
				supervisorEmail.setToAddresses(connRoles.get(0).getEmail());
				supervisorEmail.setFormerEmpName(connRoles.get(0).getFull_name());
				supervisorEmail.setManagerName(connRoles.get(0).getDirect_manager1_name());
				supervisorEmail.setFromAddress(DL_IS_GLOBAL_CCR);
				supervisorEmail.setTiRequestID(Long.valueOf(connRoles.get(0).getFciid_1()));
				supervisorEmail.setTemplateID(mailtemplate.getTemplate_id());
				supervisorEmail.setCcrEntCmpUrl(ccrEntCmpUrl.toString());
				
				//Apply the XML values to XSL Template using XSLT transformation
				String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate,supervisorEmail);
					log.debug(mailContent);
					supervisorEmail.setMsgSubject(mailtemplate.getSubject());
					supervisorEmail.setMsgContent(mailContent);
					log.debug(mailContent);
					sendMail(supervisorEmail,testMode);
			}
	   }
		catch(Exception e){
			log.error("Exception in sending mail to supervisor "+e.getMessage(),  e);
		}
	}
	
	public void updateMailTemplate(String updatedBy, String subject, String templateId, String body){
		try{
			 mailModuleUtil.updateMailTemplate(templateId, body, subject, updatedBy);
		}catch(Exception e){
			log.error("Got exception while updating mail template", e);
		}
				
	}
	
	public List<MailTemplates> getAllMailTemplates(){
		 return mailModuleUtil.getAllMailTemplates();
	}

	public void sendMailToTargetContacts(List contacts, TIRequest tiReq,String contactType){
		log.info("sendMailToRejectContact method starts");
		
		//This class will be renamed to TargetContactEmail
		TargetContactEmail rejContact = new TargetContactEmail();
		StringBuffer targetUpdate = new StringBuffer();
		targetUpdate.append(" update con_req_citi_contact_xref contact set contact.notify_count = contact.notify_count + 1 where contact.id in(");
		targetUpdate.append(" select crccx.id from ti_request_planning_xref trpx, ti_request tr, con_req_citi_contact_xref crccx,planning p,citi_contact cc,role rr");
		targetUpdate.append(" where trpx.ti_request_id = tr.id and trpx.planning_id = p.id and crccx.request_id = p.id and crccx.citi_contact_id = cc.id ");
		targetUpdate.append(" and crccx.role_id=rr.id and tr.id = ? and rr.id = ? and upper(cc.sso_id) = upper(?))");
		
		StringBuffer requestorUpdate = new StringBuffer();
		requestorUpdate.append(" update CON_REQ_CIT_RQCON_XREF contact set contact.notify_count = contact.notify_count + 1 where contact.id in(");
		requestorUpdate.append(" select crcrx.id from ti_request_planning_xref trpx, ti_request tr, CON_REQ_CIT_RQCON_XREF crcrx,planning p,citi_contact cc,role rr");
		requestorUpdate.append(" where trpx.ti_request_id = tr.id and trpx.planning_id = p.id and crcrx.request_id = p.id and crcrx.citi_contact_id = cc.id");
		requestorUpdate.append(" and crcrx.role_id=rr.id and tr.id = ? and rr.id = ? and upper(cc.sso_id) = upper(?))");

		   try{
			  List<ContactDetailsDTO> contact = contacts;
			 //get the required XSL Template from Database new table MAIL_TEMPLATE. Currently, we are using GenericMailTemplate for supervisor emails
				MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(NOTIFY_CONNECTION_CONTACT);
				
				rejContact = mailModuleUtil.getConnDetails(tiReq,rejContact);
			    for (ContactDetailsDTO user : contact) {
			    	String referenceID = UUID.randomUUID().toString(); 
			    	rejContact.setC3parBaseUrl(C3PAR_BASE_URL); 
					rejContact.setConnRoles(user.getRole());
					rejContact.setManagerName(user.getName());
					rejContact.setCcr_id(tiReq.getTiProcess().getId());
					if(testMode.equalsIgnoreCase("true")){
						rejContact.setToAddresses(user.getSsoID());	
					}else{
						rejContact.setToAddresses(user.getEmailID());	
					}
					rejContact.setFromAddress(DL_IS_GLOBAL_CCR);
					rejContact.setUrl(getMailToEncodedString_1(environment,tiReq.getTiProcess().getId(), tiReq.getVersionNumber(), user.getRole().replaceAll("\\s+",""), referenceID));
					rejContact.setTemplateID(mailtemplate.getTemplate_id());
					rejContact.setReferenceNo(referenceID);
					rejContact.setTiRequestID(tiReq.getId());
					rejContact =  (TargetContactEmail)checkForDoNotSendEmail(rejContact);
					rejContact = setFootNote(rejContact);
					 
					String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate, rejContact);
					log.debug(mailContent);
					rejContact.setMsgSubject(mailtemplate.getSubject().replace("#CCR_ID#",tiReq.getTiProcess().getId().toString()));
					rejContact.setMsgContent(mailContent);
					sendMail(rejContact,mailModuleUtil.testModeFlag(tiReq.getTiProcess().getId(),testMode));
					
					//increase notifyCount by 1 in con_req_citi_contact_xref / CON_REQ_CIT_RQCON_XREF
					if(contactType.equalsIgnoreCase("requester")){
						log.debug("sendMailToTargetContacts :: requester increase notify count");
						jdbcTemplate.update(requestorUpdate.toString(),new Object[] {tiReq.getId(),user.getRoleId(),user.getSsoID()});
					}else{
						log.debug("sendMailToTargetContacts :: target increase notify count");
						jdbcTemplate.update(targetUpdate.toString(),new Object[] {tiReq.getId(),user.getRoleId(),user.getSsoID()});
					}
					
				}
		   }
		   catch (Exception e) {
			   log.error("Exception in sending reject contact mail "+e.getMessage(),  e);
		}
	}
		
	public void sendMailToNonThirdPartyACV(HashMap <String,ACVSummaryEmailUserVO>  nonThirdPartycontacts)   {
		
		log.info("sendMailToNonThirdPartyACV method starts");

		   try {
			   Collection<ACVSummaryEmailUserVO> lstNonThirdPartyContacts =  nonThirdPartycontacts.values();
			   Long tiRequestId = null;
			   C3PARMailMessage mailMessage = new C3PARMailMessage ();
			 //get the required XSL Template from Database new table MAIL_TEMPLATE. Currently, we are using GenericMailTemplate for supervisor emails
				MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(NOTIFY_NON_TP_ACV_SUMMARY);
				
			    for (ACVSummaryEmailUserVO user : lstNonThirdPartyContacts) {
					//Apply the XML values to XSL Template using XSLT transformation
					String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate, user);
					mailMessage.setC3parBaseUrl(C3PAR_BASE_URL);
			    	mailMessage.setToAddresses(user.getEmail() );
			    	mailMessage.setFromAddress(DL_IS_GLOBAL_CCR);
					mailMessage.setTemplateID(NOTIFY_NON_TP_ACV_SUMMARY);
					mailMessage.setMsgSubject( mailtemplate.getSubject().replace("#SSOID#",user.getSsoId()) );
					mailMessage.setMsgContent(mailContent);
					tiRequestId = Long.valueOf(user.getProcessIdVal());
					mailMessage.setTiRequestID( tiRequestId );  
					sendMail(mailMessage,mailModuleUtil.testModeFlag(tiRequestId,testMode));
				}
		   }
		   catch (Exception e) {
			   log.error("Exception in sendMailToNonThirdPartyACV  Mail ",  e);
		}
		   log.info("sendMailToNonThirdPartyACV method done");
	}
	
	public void sendMailToAddContact(Long processId,String ssoID,List contactList, Long tiReq){
		
		log.info("sendMailToAddContact method starts");
		
		//This class will be renamed to TargetContactEmail
		TargetContactEmail rejContact = new TargetContactEmail();
		   try{
			   List<ContactDetailsDTO> contact = contactList;
			 //get the required XSL Template from Database new table MAIL_TEMPLATE. Currently, we are using GenericMailTemplate for supervisor emails
				MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(NOTIFY_CONTACT_REJECT);
				
			    for (ContactDetailsDTO user : contact) {
					rejContact.setC3parBaseUrl(C3PAR_BASE_URL);
					rejContact.setConnRoles(user.getRole());
					rejContact.setManagerName(user.getName());
					rejContact.setCcr_id(processId);
					if(testMode.equalsIgnoreCase("true")){
						rejContact.setToAddresses(user.getSsoID());	
					}else{
						rejContact.setToAddresses(user.getEmailID());
					}
					
					final String rejUserName = "SELECT FIRST_NAME,LAST_NAME FROM CITI_CONTACT WHERE SSO_ID = UPPER(?)";
					SqlRowSet rs = getJdbcTemplate().queryForRowSet(rejUserName, new Object[]{ssoID});
					log.debug("Reject mail name:"+ssoID);
					
					if(rs.next()){
						rejContact.setRejectUserName(rs.getString(1)+" "+rs.getString(2));
					}
					
					log.debug("Reject mail:"+rejContact.getRejectUserName());
					rejContact.setFromAddress(DL_IS_GLOBAL_CCR);
					rejContact.setTemplateID(mailtemplate.getTemplate_id());
					rejContact.setTiRequestID(tiReq);
					rejContact =  (TargetContactEmail)checkForDoNotSendEmail(rejContact);
					rejContact = setFootNote(rejContact);
					
					//Apply the XML values to XSL Template using XSLT transformation
					String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate, rejContact);
						log.debug(mailContent);
						rejContact.setMsgSubject(mailtemplate.getSubject().replace("#CCR_ID#",processId.toString()).replace("#ROLE#",user.getRole()));
						rejContact.setMsgContent(mailContent);
						sendMail(rejContact,mailModuleUtil.testModeFlag(processId,testMode));
				}
			  
		   }
		   catch (Exception e) {
			   log.error("Exception in sending reject contact mail to TA or SA "+e.getMessage(),  e);
		}
	}

	public void setCcrEntCmpUrl(String ccrEntCmpUrl) {
		this.ccrEntCmpUrl = ccrEntCmpUrl;
	}

	public String getCcrEntCmpUrl() {
		return ccrEntCmpUrl;
	}  
	
	public void sendMailForUserEntitlementCreate(ContactDetailsDTO contactDto, TIRequest tiReq){		
		log.info("sendMailForUserEntitlementCreate method starts");
		
		TargetContactEmail targetContact = new TargetContactEmail();
	   try{
		   	//get the required XSL Template from Database new table MAIL_TEMPLATE.
			MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(REQUEST_ENTITLEMENT_BY_SYSTEM);
			
			targetContact = mailModuleUtil.getConnDetails(tiReq,targetContact);
			targetContact.setC3parBaseUrl(C3PAR_BASE_URL);
			targetContact.setManagerName(contactDto.getName());
			if(testMode.equalsIgnoreCase("true")){
				targetContact.setToAddresses(contactDto.getSsoID());	
			}else{
				targetContact.setToAddresses(contactDto.getEmailID());	
			}
			targetContact.setFromAddress(DL_IS_GLOBAL_CCR);
			targetContact.setTemplateID(mailtemplate.getTemplate_id());
			targetContact.setCcr_id(tiReq.getTiProcess().getId());
			targetContact.setTiRequestID(tiReq.getId());
			targetContact.setMsgSubject(mailtemplate.getSubject().replace("#CCR_ID#",tiReq.getTiProcess().getId().toString()));
			targetContact =  (TargetContactEmail)checkForDoNotSendEmail(targetContact);
			targetContact = setFootNote(targetContact);
			
			//Apply the XML values to XSL Template using XSLT transformation
		    String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate, targetContact);
			log.debug(mailContent);
			targetContact.setMsgContent(mailContent);
			sendMail(targetContact,mailModuleUtil.testModeFlag(tiReq.getTiProcess().getId(),testMode));						  
	   }
	   catch (Exception e) {
		   log.error("Exception in sending reject contact mail to TA or SA "+e.getMessage(),  e);
	}	
	log.info("sendMailForUserEntitlementCreate method ends");   
	}

	synchronized public TargetContactEmail setFootNote(TargetContactEmail email){
		//Checking DoNotSendMailList - Ignoring emailId's in to,CC,Bcc list
		//email = (TargetContactEmail) checkForDoNotSendEmail(email);
	
		if ("true".equalsIgnoreCase(mailModuleUtil.testModeFlag(Long.valueOf(email.getCcr_id()),testMode))) {
			StringBuffer buf = new StringBuffer("");
			buf.append("TO:" + email.getToAddresses() + "		\n <br>");
			buf.append("CC:" + email.getCcAddresses() + "		\n <br>");
			buf.append("BCC:" + email.getBccAddresses() + "		\n <br>");
			email.setMsgContentFootNote(buf.toString());
		} else {
			email.setMsgContentFootNote("");
		}
		return email;
	}
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	/**
	 * @return the accessFormTextGenerator
	 */
	public AccessFormText getAccessFormTextGenerator() {
		return accessFormTextGenerator;
	}

	/**
	 * @param accessFormTextGenerator the accessFormTextGenerator to set
	 */
	public void setAccessFormTextGenerator(AccessFormText accessFormTextGenerator) {
		this.accessFormTextGenerator = accessFormTextGenerator;
	}

	public void sendMailToAddContact(Long processId, List contactList) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}		
	
	 
	public void sendAckMail(Long processId, ContactDetailsDTO contact,
			Long tiRequestID, String status, String action) {
		log.info("sendMailToAddContact method starts");
		
		//This class will be renamed to TargetContactEmail
		TargetContactEmail rejContact = new TargetContactEmail();
		   try{
			 //get the required XSL Template from Database new table MAIL_TEMPLATE. Currently, we are using GenericMailTemplate for supervisor emails
				MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(NOTIFY_ACK);

				rejContact.setC3parBaseUrl(C3PAR_BASE_URL);
				rejContact.setConnRoles(contact.getRole());
				rejContact.setManagerName(contact.getName());
				rejContact.setCcr_id(processId);
				if(testMode.equalsIgnoreCase("true")){
					rejContact.setToAddresses(contact.getSsoID());	
				}else{
					rejContact.setToAddresses(contact.getEmailID());	
				}
				rejContact.setFromAddress(DL_IS_GLOBAL_CCR);
				rejContact.setTemplateID(mailtemplate.getTemplate_id());
				rejContact.setTiRequestID(tiRequestID);
				rejContact.setStatus(status);
				rejContact.setAction(action);
				rejContact =  (TargetContactEmail)checkForDoNotSendEmail(rejContact);
				rejContact = setFootNote(rejContact);
				
				//Apply the XML values to XSL Template using XSLT transformation
				String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate, rejContact);
				log.debug(mailContent);
				rejContact.setMsgSubject(mailtemplate.getSubject().replace("#CCR_ID#",processId.toString()).replace("#STATUS#",status).replace("#ACTION#", action));
				rejContact.setMsgContent(mailContent);
				sendMail(rejContact,mailModuleUtil.testModeFlag(processId,testMode));			  
		   }
		   catch (Exception e) {
			   log.error("Exception in sending reject contact mail to TA or SA "+e.getMessage(),  e);
		}		
	}

	public String getTestMode() {
		return testMode;
	}	

	/*
	 * (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule#sendApplicationOwnerMail(com.citigroup.cgti.c3par.domain.TargetContactEmail)
	 * added by nc43495
	 * This is to add Application owner mails in common template using xsl
	 *
	 */
	public void sendApplicationOwnerMail(TargetContactEmail sendAppOwner){
		
		log.info("Sending mail to Application Owners starts here...");
		//TargetContactEmail sendAppOwner = new TargetContactEmail();
		try {
			MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(NOTIFY_CONNECTION_APPLICATION_OWNER);
			
			
			sendAppOwner.setC3parBaseUrl(C3PAR_BASE_URL);
			sendAppOwner.setFromAddress(DL_IS_GLOBAL_CCR);
			sendAppOwner.setTemplateID(mailtemplate.getTemplate_id());
			sendAppOwner =  (TargetContactEmail)checkForDoNotSendEmail(sendAppOwner);
			sendAppOwner = setFootNote(sendAppOwner);
			
			//Apply the XML values to XSL Template using XSLT transformation
			String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate, sendAppOwner);
			log.debug(mailContent);
			sendAppOwner.setMsgSubject(mailtemplate.getSubject().replace("#CCR_ID#",sendAppOwner.getCcr_id().toString()).replace("#Connection_Name#",sendAppOwner.getConnName()));
			sendAppOwner.setMsgContent(mailContent);
			sendMail(sendAppOwner,mailModuleUtil.testModeFlag(sendAppOwner.getCcr_id(),testMode));
			
		}
		catch(Exception e) {
			log.error("Exception in sending Mail"+e.getMessage(),e);
		}
	}
	
	/**
	 * Check for DonotSendEmailList
	 */
	
	public C3PARMailMessage checkForDoNotSendEmail(C3PARMailMessage mailMsg){
		log.info("MailModuleImpl : checkForDoNotSendEmail starts here ...");
		
		StringBuffer toAddress  =  new StringBuffer();
		StringBuffer ccAddress  = new StringBuffer();
		StringBuffer bccAddress = new StringBuffer();
		StringBuffer doNotSendList =  new StringBuffer();
		String[] ToEmailIds = null;
		String[] CCEmailIds = null;
		String[] BccEmailIds = null;
		
		Set<String> doNotSendEmailList = null;
		
		doNotSendEmailList = mailModuleUtil.getEmailAddressFromDoNotSendList(testMode);
		

		//prints  lot of seo-id's consuming more data in file.
		//log.debug("checkForDoNotSendEmail : EmailList"+doNotSendEmailList);
		
		if(mailMsg.getToAddresses() !=null){
			ToEmailIds = mailMsg.getToAddresses().split("\\;");
		}
		
		if(mailMsg.getCcAddresses() !=null){
			CCEmailIds = mailMsg.getCcAddresses().split("\\;");
		}
		
		if(mailMsg.getBccAddresses() !=null){
			BccEmailIds = mailMsg.getBccAddresses().split("\\;");
			
		}
		
		if (ToEmailIds != null && ToEmailIds.length > 0) {
			for(String ToEmailAddress:ToEmailIds){
				if(!doNotSendEmailList.contains(ToEmailAddress.toUpperCase())){
					toAddress.append(ToEmailAddress + EMAIL_ADDRESS_SEPERATOR);
				} else {
					doNotSendList.append(ToEmailAddress + EMAIL_ADDRESS_SEPERATOR);
				}
			}
		}
		
		if (CCEmailIds != null && CCEmailIds.length > 0) {
			for(String CCAddress:CCEmailIds){
				if(!doNotSendEmailList.contains(CCAddress.toUpperCase())){
					ccAddress.append(CCAddress + EMAIL_ADDRESS_SEPERATOR);
				} else {
					doNotSendList.append(CCAddress + EMAIL_ADDRESS_SEPERATOR);
				}
				
			}
		}
		if (BccEmailIds != null && BccEmailIds.length > 0) {
			for(String BCCAddress:BccEmailIds){
				if(!doNotSendEmailList.contains(BCCAddress.toUpperCase())){
					bccAddress.append(BCCAddress + EMAIL_ADDRESS_SEPERATOR);
				} else {
					doNotSendList.append(BCCAddress + EMAIL_ADDRESS_SEPERATOR);
				}
			}
		}
		
		mailMsg.setToAddresses(toAddress.toString());
		mailMsg.setCcAddresses(ccAddress.toString());
		mailMsg.setBccAddresses(bccAddress.toString());
		
		log.debug("checkForDoNotSendEmail :ToAddress "+mailMsg.getToAddresses());
		log.debug("checkForDoNotSendEmail :CCAddress " +mailMsg.getCcAddresses());
		log.debug("checkForDoNotSendEmail :BCCAddress "+mailMsg.getBccAddresses());
		
		//Set the Do Not Send List
		if (doNotSendList != null && doNotSendList.length() > 0) {
			mailMsg.setDoNotSendList(doNotSendList.toString());
		}
		
		log.info("MailModuleImpl : checkForDoNotSendEmail ends here ...");
		return mailMsg;
	}
	
	
	public C3PARMailMessage checkForDoNotSendEmailCSI(C3PARMailMessage mailMsg){
		log.info("MailModuleImpl : checkForDoNotSendEmail starts here ...");
		
		StringBuffer toAddress  =  new StringBuffer();
		StringBuffer ccAddress  = new StringBuffer();
		StringBuffer bccAddress = new StringBuffer();
		StringBuffer doNotSendList =  new StringBuffer();
		String[] ToEmailIds = null;
		String[] CCEmailIds = null;
		String[] BccEmailIds = null;
		
		Set<String> doNotSendEmailList = null;
		
		doNotSendEmailList = mailModuleUtil.getEmailAddressFromDoNotSendListCSI();
		

		//prints  lot of seo-id's consuming more data in file.
		//log.debug("checkForDoNotSendEmail : EmailList"+doNotSendEmailList);
		
		if(mailMsg.getToAddresses() !=null){
			ToEmailIds = mailMsg.getToAddresses().split("\\;");
		}
		
		if(mailMsg.getCcAddresses() !=null){
			CCEmailIds = mailMsg.getCcAddresses().split("\\;");
		}
		
		if(mailMsg.getBccAddresses() !=null){
			BccEmailIds = mailMsg.getBccAddresses().split("\\;");
			
		}
		
		if (ToEmailIds != null && ToEmailIds.length > 0) {
			for(String ToEmailAddress:ToEmailIds){
				if(!doNotSendEmailList.contains(ToEmailAddress.toUpperCase())){
					toAddress.append(ToEmailAddress + EMAIL_ADDRESS_SEPERATOR);
				} else {
					doNotSendList.append(ToEmailAddress + EMAIL_ADDRESS_SEPERATOR);
				}
			}
		}
		mailMsg.setToAddresses(toAddress.toString());
		
		if (CCEmailIds != null && CCEmailIds.length > 0) {
			for(String CCAddress:CCEmailIds){
				if(!doNotSendEmailList.contains(CCAddress.toUpperCase())){
					ccAddress.append(CCAddress + EMAIL_ADDRESS_SEPERATOR);
				} else {
					doNotSendList.append(CCAddress + EMAIL_ADDRESS_SEPERATOR);
				}
				
			}
		}
		mailMsg.setCcAddresses(ccAddress.toString());
		
		if (BccEmailIds != null && BccEmailIds.length > 0) {
			for(String BCCAddress:BccEmailIds){
				if(!doNotSendEmailList.contains(BCCAddress.toUpperCase())){
					bccAddress.append(BCCAddress + EMAIL_ADDRESS_SEPERATOR);
				} else {
					doNotSendList.append(BCCAddress + EMAIL_ADDRESS_SEPERATOR);
				}
			}
		}
		mailMsg.setBccAddresses(bccAddress.toString());
		
		//printing in 3 different lines for readability.
		log.debug("checkForDoNotSendEmail :ToAddress "+mailMsg.getToAddresses());
		log.debug("checkForDoNotSendEmail :CCAddress " +mailMsg.getCcAddresses());
		log.debug("checkForDoNotSendEmail :BCCAddress "+mailMsg.getBccAddresses());
		
		//Set the Do Not Send List
		if (doNotSendList != null && doNotSendList.length() > 0) {
			mailMsg.setDoNotSendList(doNotSendList.toString());
		}
		
		log.info("MailModuleImpl : checkForDoNotSendEmail ends here ...");
		return mailMsg;
	}
	
	//Getting tabular detaied content of every notification sent to users(s)
	public ConnectionDetailEmailVO getConnnectionEmailObject(Long tiRequestId,String templateId,String mailSubject, String activityCode)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append("Tp.Id Connid, tir.temp_app_reason, to_char(tir.tpwapp_temp_app_date,'MM-DD-YYYY') as tpwapp_temp_app_date, tir.version_number, tp.process_name, tp.is_high_risk,  tir.cmp_id, tir.SERVICE_NOW_ID ");
		sb.append(",Tpt.Process_Type,Decode(Trt.Request_Type,'Create','Planning',Trt.Request_Type) Connectionphase ");
		sb.append(",Rel.Id Relationshipid,Rel.Name Relatinshipname,Rs.Name Sourceresource,Rd.Name Destnresource ");
		sb.append(",Bu.Business_Name Businessunit,Reg.Name Regionname,Sec.Name Sectorname  ");
		sb.append(",Cu.Sso_Id Requester ");
		sb.append(",gl.value1 priority, ttt.task ");
		sb.append("From ");
		sb.append("Ti_Process Tp ");
		sb.append("Join Ti_Request Tir On Tp.Id=Tir.Process_Id ");
		sb.append("Join Relationship Rel On Rel.Id=Tp.Relationship_Id ");
		sb.append("Join Ti_Request_Type Trt On Trt.Id=Tir.Ti_Request_Type_Id ");
		sb.append("Join REL_CITI_HIERARCHY_XREF rxref on rxref.RELATIONSHIP_ID = rel.id ");
		sb.append("Join CITI_HIERARCHY_MASTER cm on cm.ID = rxref.CITI_HIERARCHY_MASTER_ID ");
		sb.append("Join Business_Unit Bu On Bu.Id= cm.BU_ID ");
		sb.append("join Ti_Process_Type tpt on tpt.id=Tp.Process_Type_Id ");
		sb.append("Left Join Region Reg On Reg.ID= cm.REGION_ID ");
		sb.append("Left Join Sector Sec On Sec.ID= cm.SECTOR_ID ");
		sb.append("Left Join Resourcetype Rs On Rs.Id=Rel.Requester_Resource_Type_Id ");
		sb.append("Left Join Resourcetype Rd On Rd.Id=Rel.Target_Resource_Type_Id ");
		sb.append("Left Join C3par_Users Cu On Cu.Id=Tir.User_Id ");
		sb.append("left join generic_lookup gl on gl.id=tir.priority_id ");
		sb.append("join ti_activity_trail tat on tir.id=tat.ti_request_id and tat.ACTIVITY_STATUS ='SCHEDULED' ");
		sb.append("join ti_task_type ttt on ttt.id=tat.ACTIVITY_ID ");
		sb.append("Where ");
		sb.append("tir.id=? and tat.ACTIVITY_ID=(select id from c3par.ti_task_type where task_code =?)");
		 
		/*ConnectionDetailEmailVO cp = jdbcTemplate.queryForObject(sb.toString(), new Long[]{tiRequestId}, new RowMapper<ConnectionDetailEmailVO>() {

			@Override
			public ConnectionDetailEmailVO mapRow(ResultSet rs, int arg1)
					throws SQLException {
				ConnectionDetailEmailVO c = new ConnectionDetailEmailVO();
				c.setProcessId(rs.getLong("Connid"));
				c.setVersionNumber(rs.getLong("version_number"));
				c.setConnectionName(rs.getString("process_name"));
				c.setConnectionType(rs.getString("Process_Type"));
				c.setMode(rs.getString("Connectionphase"));
				c.setRelationshipId(rs.getLong("Relationshipid"));
				c.setRelationshipName(rs.getString("Relatinshipname"));
				c.setSourceResourceName(rs.getString("Sourceresource"));
				c.setDestnResourceName(rs.getString("Destnresource"));
				c.setBusinessUnit(rs.getString("Businessunit"));
				c.setRegion(rs.getString("Regionname"));
				c.setSector(rs.getString("Sectorname"));
				c.setRequester(rs.getString("Requester"));
				c.setPriority(rs.getString("priority"));
				c.setRisk(rs.getString("is_high_risk"));
				c.setSystemId(rs.getString("cmp_id"));
				
				return c;
			}
});*/ 	log.debug("Query in getConnnectionEmailObject : " +sb.toString());
		log.info("tiRequestId value "+tiRequestId+" activityCode "+activityCode);
		StringBuilder reg = new StringBuilder();
		int i = 0;
		ConnectionDetailEmailVO cp = new ConnectionDetailEmailVO();
		SqlRowSet rs = jdbcTemplate.queryForRowSet(sb.toString(), new Object[]{tiRequestId,activityCode});
		while(rs.next()){
			if(i > 0) {
				reg.append(",");
	    	}
			i++;
			reg.append(rs.getString("Regionname")); 
			cp.setProcessId(rs.getLong("Connid"));
			cp.setVersionNumber(rs.getLong("version_number"));
			cp.setConnectionName(rs.getString("process_name"));
			cp.setConnectionType(rs.getString("Process_Type")); 
			cp.setMode(rs.getString("Connectionphase"));
			cp.setRelationshipId(rs.getLong("Relationshipid"));
			cp.setRelationshipName(rs.getString("Relatinshipname"));
			cp.setSourceResourceName(rs.getString("Sourceresource"));
			cp.setDestnResourceName(rs.getString("Destnresource"));
			cp.setBusinessUnit(rs.getString("Businessunit"));
			cp.setRegion(reg.toString());
			cp.setSector(rs.getString("Sectorname"));
			cp.setRequester(rs.getString("Requester"));
			cp.setPriority(rs.getString("priority"));
			cp.setRisk(rs.getString("is_high_risk"));
			cp.setSystemId(rs.getString("cmp_id"));
			cp.setActivityName(rs.getString("task"));
			cp.setServiceNowID(rs.getString("SERVICE_NOW_ID"));
			cp.setCmpID(rs.getString("cmp_id")); 
			cp.setTempDate(rs.getString("tpwapp_temp_app_date"));
			cp.setTempReason(rs.getString("temp_app_reason"));
			log.info(" tpwapp_temp_app_date value is ::  "+rs.getString("tpwapp_temp_app_date")+" temp_app_reason value is ::"+rs.getString("temp_app_reason"));
		}
		cp.setTiRequestID(tiRequestId);
		cp.setFirewallDetailEmailVO(getFirewallInfoObject(tiRequestId));
		cp.setDateDetailEmailVO(getDateEmailObject(tiRequestId));
		cp.setAuditTrailDetailEmailVO(getAuditTrailObject(tiRequestId));
		
		cp.setC3parBaseUrl(C3PAR_BASE_URL);
		cp.setToAddresses(getRecepientInfoObject(templateId,"TO",cp.getProcessId(),tiRequestId).getUserEmails());
		cp.setCcAddresses(getRecepientInfoObject(templateId,"CC",cp.getProcessId(),tiRequestId).getUserEmails());
		cp.setBccAddresses(getRecepientInfoObject(templateId,"BCC",cp.getProcessId(),tiRequestId).getUserEmails());
		cp.setFromAddress(DL_IS_GLOBAL_CCR);
		
		if ("true".equalsIgnoreCase(mailModuleUtil.testModeFlag(cp.getProcessId(),testMode))) {
			StringBuffer buf = new StringBuffer("");
			buf.append("TO:" + cp.getToAddresses() + "\n <br></br>");
			buf.append("CC:" + cp.getCcAddresses() + "\n <br></br>");
			buf.append("BCC:" + cp.getBccAddresses() + "\n <br></br>");
			cp.setMsgContentFootNote(buf.toString());
		
		} else {
			cp.setMsgContentFootNote("");
		}
		
		cp.setMsgSubject(mailSubject.replaceAll("#CCR_ID#", cp.getProcessId()+"."+cp.getVersionNumber())
									 .replaceAll("#CCR_NAME#", cp.getConnectionName())
									 .replaceAll("#CCR_PRIORITY#", cp.getPriority())
						);
		
		return cp;
	}
	
	//Getting Firewall Details in tabular content of every notification sent to users(s)
	public FirewallDetailEmailVO getFirewallInfoObject(Long tiRequestId){
		StringBuilder sb = new StringBuilder();
		sb.append("Select a.Fw_Type,b.Fw_Region From ");
		sb.append("( ");
		sb.append("Select ");
		sb.append("Listagg(X.Fw_Type, ',') Within Group (Order By X.Fw_Type) Fw_Type ");
		sb.append("from( ");
		sb.append("select Cfp.Fw_Type ");
		sb.append("From ");
		sb.append("Faf_Fireflow_Ticket Fft ");
		sb.append("Join Faf_Fw_Rule Ffr On Fft.Id=Ffr.Fireflow_Ticket_Id ");
		sb.append("Join Faf_Fw_Rule_Policy Ffrp On Ffr.Id=Ffrp.Faf_Fw_Rule_Id ");
		sb.append("Join Con_Fw_Policy Cfp On Cfp.Id=Ffrp.Policy_Id ");
		sb.append("Join Con_Fw_Mgmt_Region Cfm On Cfm.Id=Cfp.Mgmt_Region_Id ");
		sb.append("Where ");
		sb.append("Fft.Ti_Request_Id=? ");
		sb.append("And Fft.Status<>'DELETED' ");
		sb.append("Group By Cfp.Fw_Type)X)A, ");
		sb.append("( ");
		sb.append("Select ");
		sb.append("Listagg(X.Mgt_Region, ',') Within Group (Order By X.Mgt_Region) Fw_Region ");
		sb.append("from( ");
		sb.append("select Cfm.Mgt_Region ");
		sb.append("From ");
		sb.append("Faf_Fireflow_Ticket Fft ");
		sb.append("Join Faf_Fw_Rule Ffr On Fft.Id=Ffr.Fireflow_Ticket_Id ");
		sb.append("Join Faf_Fw_Rule_Policy Ffrp On Ffr.Id=Ffrp.Faf_Fw_Rule_Id ");
		sb.append("Join Con_Fw_Policy Cfp On Cfp.Id=Ffrp.Policy_Id ");
		sb.append("Join Con_Fw_Mgmt_Region Cfm On Cfm.Id=Cfp.Mgmt_Region_Id ");
		sb.append("Where ");
		sb.append("Fft.Ti_Request_Id=? ");
		sb.append("And Fft.Status<>'DELETED' ");
		sb.append("group by Cfm.Mgt_Region)x)b");
		
		

		FirewallDetailEmailVO fw = jdbcTemplate.queryForObject(sb.toString(), new Long[]{tiRequestId,tiRequestId}, new RowMapper<FirewallDetailEmailVO>() {

			@Override
			public FirewallDetailEmailVO mapRow(ResultSet rs, int arg1)
					throws SQLException {
				FirewallDetailEmailVO f = new FirewallDetailEmailVO();
				f.setFirewallType(rs.getString("Fw_Type"));
				f.setFirewallRegion(rs.getString("fw_region"));
				return f;
			}
		});
		
		return fw;		
	}
	
	//Getting Date Details of Appsense/Proxy/Firewall/IPReg/SecACL in tabular content of every notification sent to users(s)
	public DateDetailEmailVO getDateEmailObject(Long tiRequestId)
	{
		
		StringBuilder sb = new StringBuilder();
		sb.append("Select  ");
		sb.append("planned_completion_date, ");
		sb.append("Request_Deadline, ");
		sb.append("Opeimp_Scheduled_Date, ");
		sb.append("Apsimp_Scheduled_Date, ");
		sb.append("Prximp_Scheduled_Date, ");
		sb.append("Gnccimp_Scheduled_Date, ");
		sb.append("Ipregimp_Scheduled_Date ");
		sb.append("From Ti_Request ");
		sb.append("Where ");
		sb.append("id=?");
		
		DateDetailEmailVO de = jdbcTemplate.queryForObject(sb.toString(), new Long[]{tiRequestId}, new RowMapper<DateDetailEmailVO>() {

			@Override
			public DateDetailEmailVO mapRow(ResultSet rs, int arg1)
					throws SQLException {
				DateDetailEmailVO d = new DateDetailEmailVO();
				d.setActivationDate(rs.getString("planned_completion_date"));
				d.setExpirationDate(rs.getString("Request_Deadline"));
				d.setOpeScheduledDate(rs.getString("Opeimp_Scheduled_Date"));
				d.setAppsenseScheduledDate(rs.getString("Apsimp_Scheduled_Date"));
				d.setProxyScheduledDate(rs.getString("Prximp_Scheduled_Date"));
				d.setGnccScheduledDate(rs.getString("Gnccimp_Scheduled_Date"));
				d.setIpregScheduledDate(rs.getString("Ipregimp_Scheduled_Date"));
				return d;
			}
		});
		
		return de;	
	}
	
	//Getting Audit information in tabular content of every notification sent to users(s)
	public AuditTrailDetailEmailVO getAuditTrailObject(Long tiRequestId)
	{
		AuditTrailDetailEmailVO a= new AuditTrailDetailEmailVO();
		StringBuilder sb = new StringBuilder();
		sb.append("Select distinct rl.display_name,tat.activity_mode,trc.comments ");
		sb.append("From  ");
		sb.append("Ti_Activity_Trail Tat ");
		sb.append("Join ");
		sb.append("(Select Max(Id) Id From Ti_Activity_Trail Tat Where Ti_Request_Id=?)Mxtat On Mxtat.Id=Tat.Id ");
		sb.append("Left Join Role Rl On Rl.Id=Tat.User_Role_Id ");
		sb.append("left join Ti_Request_Comments trc on trc.role_id=tat.user_role_id and trc.comment_type='A' and trc.ti_request_id=? ");
		sb.append("left join (select max(id)id from Ti_Request_Comments where Ti_Request_Id=? and comment_type='A')mxcom on mxcom.id=trc.id");
		

		SqlRowSet rs = jdbcTemplate.queryForRowSet(sb.toString(), new Object[]{tiRequestId,tiRequestId,tiRequestId});	
		while(rs.next()){
				a.setLastSubmittedRole(rs.getString("display_name"));
				a.setActivityMode(rs.getString("activity_mode"));
				a.setComments(rs.getString("comments"));
			}

		return a;
	}
	
	//Getting Query Information for retrieving TO/CC/BCC list of every notification sent to users(s)
	public RecepientInfo getRecepientInfoObject(String templateId,
			String recepientType,Long processId,Long tiRequestId) {
		StringBuilder sb = new StringBuilder();
		Set<String> doNotSendEmailList = null;
		sb.append("Select  ");
		sb.append("Rqm.Procedure_Name ");
		sb.append("From ");
		sb.append("Mail_Templates Mt ");
		sb.append("Join Template_Recepient_Xref Trx On Mt.Id=Trx.Mail_Template_Id ");
		sb.append("Join Recepient_Query_Master Rqm On Rqm.Id=Trx.Recepient_Query_Id ");
		sb.append("Where ");
		sb.append("MT.TEMPLATE_ID=? ");
		sb.append("and Trx.Is_Active='Y' ");
		sb.append("and Trx.Recepient_Type=? ");
		List<RecepientInfo> queryList = jdbcTemplate.query(sb.toString(),
				new String[] { templateId, recepientType },
				new RowMapper<RecepientInfo>() {
					@Override
					public RecepientInfo mapRow(ResultSet rs, int arg1)
							throws SQLException {
						RecepientInfo f = new RecepientInfo();
						f.setProcedureName(rs.getString("Procedure_Name"));
						return f;
					}
				});
		
		RecepientInfo rci = new RecepientInfo();
		
		for (RecepientInfo mp : queryList) {
			log.info("**mp.getProcedureName()  value is::  "+mp.getProcedureName());
			List<Map<String, Object>> emailList = getReceipientList(processId,tiRequestId, mp.getProcedureName());
			for (Map recs : emailList) {
				rci.getEmails().add(""+ (recs.get("email") == null ? "" : recs.get("email")));
				rci.getSsoids().add(""+ (recs.get("ssoid") == null ? "" : recs.get("ssoid")));
			}
			if(doNotSendEmailList == null || doNotSendEmailList.isEmpty()){
				doNotSendEmailList = mailModuleUtil.getEmailAddressFromDoNotSendList(testMode);
				if("true".equals(testMode))
						{
							rci.getSsoids().removeAll(doNotSendEmailList);							
						}else{
							rci.getEmails().removeAll(doNotSendEmailList);
						}
				
					
			}
		}

		return rci;
	}

	//Getting TO/CC/BCC list of every notification sent to users(s)
	public List<Map<String, Object>> getReceipientList(Long processId,
			Long tiRequestId, String procCall) {

		return jdbcTemplate.queryForList(procCall,
				new Object[] { processId, tiRequestId });

	}
	

	//Sending notification to user(s)
	@Override
	public void sendNotificationForWorkItem(Long tiRequestId,String activityCode,String activityName, String activityRole) {
		
		try {
			MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(activityCode);
			
			ConnectionDetailEmailVO ceo = getConnnectionEmailObject(tiRequestId,mailtemplate.getTemplate_id(),mailtemplate.getSubject(), activityCode);
			ceo.setActivityRole(activityRole);
		//ceo.setActivityName(activityName);
			ceo.setImplReault(mailModuleUtil.getImplementationResults(ceo.getProcessId() +""));
			String str = convertoXML(ceo).toString();
				 
			//Apply the XML values to XSL Template using XSLT transformation
			String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate.getBody(), str);
			ceo.setMsgContent(mailContent); 
			ceo.setTiRequestID(tiRequestId);
			ceo.setTemplateID(activityCode);
			log.debug("mailcontent in sendNotificationForWorkitem "+mailContent);
			
			sendMail(ceo,mailModuleUtil.testModeFlag(ceo.getProcessId(),testMode));
			
		}
		catch(Exception e) {
			log.error("Exception in sending Mail"+e.getMessage(),e);
		}
		
	}
	
	/**
	 * to send the comments from Temp Approval and Reconcile Expiration
	 */
	@Override
	public void sendCommentsEmail(Long tiRequestId, String activityCode, String comments,String extendedDate) {
		log.info("SendMail to GIS for temporary and reconcile Expiration starts here ...");
		try {
			MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(activityCode+"_cmts");
			
			ConnectionDetailEmailVO ceo = getConnnectionEmailObject(tiRequestId,mailtemplate.getTemplate_id(),mailtemplate.getSubject() ,activityCode);
			ceo.setActivityRole(ActivityData.ROLE_OTRM);
			ceo.setExtDate(extendedDate);
			ceo.setComment(comments);
			ceo.setMsgSubject(mailtemplate.getSubject().replaceAll("#CCR_ID#", ceo.getProcessId()+"."+ceo.getVersionNumber())
					 .replaceAll("#CCR_NAME#", ceo.getConnectionName())
					 .replaceAll("#CCR_PRIORITY#", ceo.getPriority())
					 .replaceAll("#EXP_DATE#", ceo.getExtDate())
			);
			ceo.setTiRequestID(tiRequestId);
			ceo.setTemplateID(activityCode+"_cmts");
			String str = convertoXML(ceo).toString();
				
			//Apply the XML values to XSL Template using XSLT transformation
			String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate.getBody(), str);
			ceo.setMsgContent(mailContent);
			sendMail(ceo,mailModuleUtil.testModeFlag(ceo.getProcessId(),testMode));
			
			log.debug("Send mail ends here .."+comments);
			
		}
		catch(Exception e) {
			log.error("Exception in sending Mail"+e.getMessage(),e);
		}
		
	}
	
	@Override
	public void sendEcmEmailGeneration(String chooseEmail,CMPRequest resolveITMessage) { 
		// TODO Auto-generated method stub
		log.info("sendMailToAddContact method starts"); 
        //This class will be renamed to TargetContactEmail
        
	}	
	
	@Override
	public void sendEcmEmailViewGeneration(String chooseEmail, CmpRequestDTO cmpRequestDTO) {
		log.info("MailModuleImpl: sendEcmEmailViewGeneration: starts");
		
		try{
			//Adding for ECM WORk FLow
			
			/*if("REQ_ASSIGNED_ASSISTANCE".equals(chooseEmail) && !"No Additional Information".equals(cmpRequestDTO.getReqAdditionalInfo())  )
			{
				 log.info(" additional information is required");
				 chooseEmail="REQ_ASSIGNED_ASSISTANCE_ADDITIONAL_INFO";	
			}*/
			//End for Ecm Work Flow
			
			MailTemplates mailTemplates = mailModuleUtil.getMailTemplateById(chooseEmail);
			String taskCode = "";
			
			if(testMode.equalsIgnoreCase("true")){
            	cmpRequestDTO.setMsgContentFootNote("true");      
            }
			
			cmpRequestDTO.setTemplateID(mailTemplates.getTemplate_id());
			cmpRequestDTO.setTiRequestID(0L);
			cmpRequestDTO = (CmpRequestDTO)checkForDoNotSendEmail(cmpRequestDTO);
			cmpRequestDTO.setFromAddress(DL_IS_GLOBAL_CCR);
			
			if(cmpRequestDTO.getCmpId() != null){
				mailTemplates.setSubject(mailTemplates.getSubject().replace("#CMPID#", cmpRequestDTO.getCmpId()));
			}
			if(cmpRequestDTO.getCcrId() != null){
				mailTemplates.setSubject(mailTemplates.getSubject().replace("#CCRID#", cmpRequestDTO.getCcrId()));
			}
			if(cmpRequestDTO.getChgId() != null){
				mailTemplates.setSubject(mailTemplates.getSubject().replace("#CHGID#", cmpRequestDTO.getChgId()));
			}
			if(cmpRequestDTO.getChgDate() != null){
				mailTemplates.setSubject(mailTemplates.getSubject().replace("#CHGDATE#", cmpRequestDTO.getChgDate()));
			}
			if(cmpRequestDTO.getReAssignedUser() != null){
				mailTemplates.setSubject(mailTemplates.getSubject().replace("#ReAssignedUser#", cmpRequestDTO.getReAssignedUser()));
			}			
			if(cmpRequestDTO.getSsoId() != null){
				cmpRequestDTO.setSsoId(cmpRequestDTO.getSsoId().toLowerCase());
			}
			if(cmpRequestDTO.getTextForSubject() != null && cmpRequestDTO.getTextForSubject().trim().length() > 0){
				mailTemplates.setSubject(mailTemplates.getSubject().replace("#ProjectName#", "- " +cmpRequestDTO.getTextForSubject()));
			}
			else{
				mailTemplates.setSubject(mailTemplates.getSubject().replace("#ProjectName#", ""));
			}
			cmpRequestDTO.setMsgSubject(mailTemplates.getSubject());
			
			List<String> templateList = new ArrayList<String>();
			templateList.add(chooseEmail.toUpperCase()+"_TASK");
			List<GenericLookup> emailTemplates = commonServicePersistable.getGenericLookupData(templateList);
			if(emailTemplates != null && !emailTemplates.isEmpty()){
				taskCode = emailTemplates.get(0).getValue2();
				log.debug("MailModuleImpl: sendEcmEmailViewGeneration: chooseEmail - "+chooseEmail+" :: taskCode - "+taskCode);
			}
			else{

                taskCode = cmpRequestDTO.getChooseEmail();

        }
			
			/*if("awaiting_assist_term_log".equals(taskCode) && "No Additional Information".equals(cmpRequestDTO.getReqAdditionalInfo()) )
			{
				 log.info("  No additional information is required");
				 taskCode="awaiting_assist_term_log_no_add_inofrm_req";	
			}*/
			
			
			if(chooseEmail.equalsIgnoreCase("BUSINESS_USER_REPLY")){
                cmpRequestDTO.setC3parBaseUrl(ccrUrl);
             }
           else{
                cmpRequestDTO.setC3parBaseUrl(ccrUrl+ "/businessUserComments.act?cmpId=" +cmpRequestDTO.getCmpId()+ "&actCode=" +taskCode);
            }

			String mailContent = transformObjectXMLtoXSLTemplate(mailTemplates, cmpRequestDTO);
			cmpRequestDTO.setMsgContent(mailContent);
			
			
			if(taskCode != null && (taskCode.equalsIgnoreCase("cmp_cancel_request") || "closed_assitance_req".equals(taskCode))){
				cmpRequestPersistable.cmpActivityTrail(cmpRequestDTO.getCmpRequestId(), cmpRequestDTO.getSsoId(), taskCode, ECMConstants.STATUS_COMPLETED);	
			}else{
				System.out.println("cmpRequestPersistable"+cmpRequestPersistable);
				if(cmpRequestPersistable!=null) {
					
				cmpRequestPersistable.cmpActivityTrail(cmpRequestDTO.getCmpRequestId(), cmpRequestDTO.getSsoId(), taskCode, ECMConstants.STATUS_STARTED);
				}
			}
			
            sendMail(cmpRequestDTO, testMode);            
            
            log.info("MailModuleImpl: sendEcmEmailViewGeneration: ends");
		}		
		catch(Exception e){
			log.error("MailModuleImpl: sendEcmEmailViewGeneration: exception: "+e.getMessage(),  e);
		}
	}

	@Override
	public void notificationForDecommissionedApp(
			List<ConnectionDetailEmailVO> connectionDetailEmailVOList) {

		log.info("Entering MailModuleImpl notificationForDecommissionedApp.");
		try {
			MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(NOTIFICATION_CSI_APPLICATION_DECOMMISSIONED);
			 
			String[] mailToRoles = new String[]{"DESIGN ENGINEER","Business_Owner"};
			for(ConnectionDetailEmailVO connectionVO : connectionDetailEmailVOList){
				Set<String> toUserRole = new HashSet<String>();
				Set<String> ccUserRole = new HashSet<String>();
				
				String busOwner="";
				String busOwnerNames="";
				/*Set<String> names = new HashSet<String>();*/
				log.debug("Connection Details. ");
				for(String roleName: mailToRoles){
						String ccIds=mailModuleUtil.getUserRoleEmail(String.valueOf(connectionVO.getProcessId()),roleName, "true");
						String citiContactEmailIds=mailModuleUtil.getUserRoleEmail(String.valueOf(connectionVO.getProcessId()),roleName, "false");
						String citiContactNames=mailModuleUtil.getUserRoleEmailCSI(String.valueOf(connectionVO.getProcessId()),roleName, "names");
						
						
						log.debug("printing ccIds: "+ccIds);
						log.debug("printing citiContactEmailIds: "+citiContactEmailIds);
						log.debug("printing citiContactNames: "+citiContactNames);
						
						if(roleName.equals("Business_Owner"))
						{
							if(citiContactEmailIds !=null && citiContactNames !=null)
								{
									toUserRole.add(citiContactEmailIds);
									//busOwnerCCR.add(citiContactNames);
									busOwnerNames=citiContactNames;
									
								}
						}
						else
						{
							ccUserRole.add(citiContactEmailIds);
						}
						
				}
				
				if(busOwnerNames.contains(",")){
					busOwner=busOwnerNames.substring(0, busOwnerNames.indexOf(","));
					}
					else{
						busOwner="Business Owner";
					}
				
				ccUserRole.add(DL_IS_GLOBAL_CCR+EMAIL_ADDRESS_SEPERATOR); 

				/*String toNames = setToString(names);
				toNames = toNames.endsWith("/") ? toNames.substring(0,toNames.length()-1) : toNames;
				log.debug("Dear names "+names);*/
				log.debug("Dear BusOwner"+busOwner);
				log.debug("CC mails"+ccUserRole);
				log.debug("To mails."+toUserRole);
				connectionVO.setToAddresses(setToString(toUserRole));
				if(!toUserRole.equals(ccUserRole)){
					connectionVO.setCcAddresses(setToString(ccUserRole));
				}
				/*connectionVO.setRequester(toNames);*/
				connectionVO=(ConnectionDetailEmailVO)checkForDoNotSendEmailCSI(connectionVO);
				connectionVO.setBusinessOwner(busOwner);
				connectionVO.setMsgSubject(mailtemplate.getSubject().replace("#CCRID#", String.valueOf(connectionVO.getProcessId())));
				connectionVO.setFromAddress(DL_IS_GLOBAL_CCR);
				try {
                    connectionVO.setAttachments(accessFormTextGenerator.getAttachments(connectionVO.getTiRequestID(), connectionVO.getProcessId(), Long.valueOf(connectionVO.getVersionNumber()),"Y"));
	             } catch (Exception e) {
	                    log.error("Exception caught while calling getAttachments : "+ e.toString(), e);
	             }

				log.debug("verify connection values. connectionVO.getProcessId() - "+connectionVO.getProcessId()+"," +
						"connectionVO.getApplicationName() - "+connectionVO.getApplicationName()+"," +
						"connectionVO.getConnectionName() - "+connectionVO.getConnectionName());
				
				//Apply the XML values to XSL Template using XSLT transformation
				String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate, connectionVO);
				log.debug("Mail Content Details. "+mailContent);
				connectionVO.setMsgContent(mailContent);
				connectionVO.setTemplateID(NOTIFICATION_CSI_APPLICATION_DECOMMISSIONED);
				sendMail(connectionVO,mailModuleUtil.testModeFlag(connectionVO.getProcessId(),testMode));
				log.debug("Send mail ends here ..");
			}
		}
		catch(Exception e) {
			log.error("Exception in sending Mail"+e.getMessage(),e);
		}
		log.info("Exiting MailModuleImpl notificationForDecommissionedApp.");
	}
	
	public void sendECMAgentWorkAssignedNotification(CmpRequestDTO cmpRequestDTO, Map<String,String> mailInfo){
		
		log.info("Entering into sendECMAgentWorkAssignedNotification()..");
		try {
			
			C3PARMailMessage mailMsg = new C3PARMailMessage();
			MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(SEND_EMAIL_TO_ECM_AGENT_ON_REQUEST_ASSIGNED);			
							
				//Apply the XML values to XSL Template using XSLT transformation
				String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate, cmpRequestDTO);
				log.debug("Mail Content Details. "+mailContent);
				
				mailMsg.setToAddresses(mailInfo.get("TO"));				
				mailMsg.setFromAddress(mailInfo.get("FROM"));
				mailMsg.setMsgSubject("Alert: The CMP Request( "+cmpRequestDTO.getCmpId()+" ) has been assigned to you.");
				mailMsg.setMsgContent(mailContent);
								
				
				MimeMessage message = this.mailSender.createMimeMessage();
				
					MimeMessageHelper helper = null;
					
					String testModeParam ="false";
					
					if (mailMsg.getAttachments() != null && mailMsg.getAttachments().size() > 0) {
						helper = new MimeMessageHelper(message, true,"UTF-8");
					} else {
						helper = new MimeMessageHelper(message, false,"UTF-8");
					}

					if("true".equalsIgnoreCase(testModeParam)){
						String[] emailIds = testEmail.split("\\;");
						helper.setTo(emailIds);
						log.debug("MailModule:MailModuleImpl:sendMail:testEmail:"+testEmail);
					} else{
						String[] emailIds = mailMsg.getToAddresses().split("\\;");
						helper.setTo(emailIds);
						log.debug("MailModule:MailModuleImpl:sendMail:ToemailIds:"+mailMsg.getToAddresses());
					}
					if(mailMsg.getCcAddresses() != null && !("".equals(mailMsg.getCcAddresses())) && !("true".equalsIgnoreCase(testModeParam))){
						String[] emailIds = mailMsg.getCcAddresses().split("\\;");
						helper.setCc(emailIds);
						log.debug("MailModule:MailModuleImpl:sendMail:ccemailIds:"+emailIds);
					}
					if(mailMsg.getBccAddresses() != null && !("".equals(mailMsg.getBccAddresses())) && !("true".equalsIgnoreCase(testModeParam))){
						String[] emailIds = mailMsg.getBccAddresses().split("\\;");
						helper.setBcc(emailIds);
						log.debug("MailModule:MailModuleImpl:sendMail:BccemailIds:"+emailIds);
					}
					
					
					helper.setSubject(mailMsg.getMsgSubject());
					helper.setFrom(mailMsg.getFromAddress());
					helper.setText(mailMsg.getMsgContent(), true);					
					
					this.mailSender.send(message);		
				
				
				
				log.debug("The mail for CMP Request:("+cmpRequestDTO.getCmpId()+") has been sent to: +"+mailInfo.get("TO")+" from:"+mailInfo.get("FROM") +" successfully.");
			
		}
		catch(Exception e) {
			log.error("Exception in sending Mail"+e.getMessage(),e);
		}
		
		log.info("Exit from sendECMAgentWorkAssignedNotification()..");
	}
	
	
	@Override
	public void sendRisoEmail(Long tiRequestId,String gisCmnts,CitiContact risoContactDetails) {
		log.info("SendMail to GIS for temporary and reconcile Expiration starts here ..."+risoContactDetails.getSsoId());
		try {
			MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(RISO_APPROVAL_MAIL);
			
			log.debug("**The template id value is "+mailtemplate.getTemplate_id());
			
			ConnectionDetailEmailVO ceo = getConnnectionEmailObject(tiRequestId,mailtemplate.getTemplate_id(),mailtemplate.getSubject() ,ActivityData.ACTIVITY_OTRM);
			
			String[] mailToRoles = new String[]{"DESIGN ENGINEER","OTRM", "BISO", "Requestor","Business_Owner"};
			StringBuffer ccUserRole = new StringBuffer();
			String busOwner="";
			String busRequestor="";
			String isoName = "";
			
			
			for(String roleName: mailToRoles){
					String ccIds=mailModuleUtil.getUserRoleEmail(String.valueOf(ceo.getProcessId()),roleName, "true");
					if(ccIds.contains(EMAIL_ADDRESS_SEPERATOR)){
						String[] ssoIds=ccIds.split(EMAIL_ADDRESS_SEPERATOR);
						CitiContact citiContact = mailModuleUtil.getContactDetailsBySSOId(ssoIds[0]);
						if(roleName.equals("DESIGN ENGINEER")) {
							ccUserRole.append(citiContact.getEmail()+EMAIL_ADDRESS_SEPERATOR);
						} else if(roleName.equals("OTRM")){
							ccUserRole.append(citiContact.getEmail()+EMAIL_ADDRESS_SEPERATOR);
						}else if(roleName.equals("BISO")){
							isoName = citiContact.getLastName()+" "+citiContact.getFirstName();
						}
						else if(roleName.equals("Requestor")){
							busRequestor = citiContact.getLastName()+" "+citiContact.getFirstName();
						}
						else{
							if(busOwner.isEmpty())
								busOwner=citiContact.getLastName()+" "+citiContact.getFirstName();
							else
								busOwner=","+citiContact.getLastName()+" "+citiContact.getFirstName();
							
						}
						
					}
			} 
			
			log.debug("Email::"+risoContactDetails.getEmail()+":: Last Name ::"+risoContactDetails.getLastName()+"::First Name"+risoContactDetails.getFirstName());
			
			ccUserRole.append(DL_IS_GLOBAL_CCR+EMAIL_ADDRESS_SEPERATOR);
			
			String risoMailId=mailModuleUtil.getRisoMailId();
			log.debug("risoMailId in MailModuleImpl : "+risoMailId);
			if(!"".equalsIgnoreCase(risoMailId)){
				ccUserRole.append(risoMailId+EMAIL_ADDRESS_SEPERATOR);
			}else{
				ccUserRole.append("");
			}	
			
			
			String gisLockedEmail=mailModuleUtil.getLockedBy(tiRequestId);
			log.debug("RisoApproverMail:Locked user"+gisLockedEmail);
			if(!"".equalsIgnoreCase(gisLockedEmail)){
				ccUserRole.append(gisLockedEmail+EMAIL_ADDRESS_SEPERATOR);
			}else{
				ccUserRole.append("");
			}
			log.debug("ccUserRole : "+ccUserRole.toString());
			
			ceo.setToAddresses(risoContactDetails.getEmail()+EMAIL_ADDRESS_SEPERATOR);
			ceo.setRisoApprover(risoContactDetails.getLastName()+" "+risoContactDetails.getFirstName());
			ceo.setGisComments(gisCmnts);
			ceo.setComment(accessFormTextGenerator.getCurrentBusJustfication(ceo.getTiRequestID()));
			ceo.setMsgSubject(mailtemplate.getSubject().replaceAll("#CCR_ID#", ceo.getProcessId()+"."+ceo.getVersionNumber()));
			ceo.setAttachments(accessFormTextGenerator.getAttachments(ceo.getTiRequestID(), ceo.getProcessId(), Long.valueOf(ceo.getVersionNumber()),"Y"));
			ceo.setFromAddress(DL_IS_GLOBAL_CCR);
			ceo.setToAddresses(risoContactDetails.getEmail());
			ceo.setCcAddresses(ccUserRole.toString());
			ceo.setTiRequestID(tiRequestId);
			ceo.setTempDate(ceo.getTempDate());
			ceo.setTempReason(ceo.getTempReason());
			ceo.setBusinessOwner(busOwner);
			ceo.setIsoName(isoName);
			ceo.setBusinessRequestor(busRequestor);
			
			log.info(" ceo.getTempDate() "+ceo.getTempDate()+" ceo.getTempReason() "+ceo.getTempReason()+ " isoName "+isoName);
			
			if ("true".equalsIgnoreCase(mailModuleUtil.testModeFlag(Long.valueOf(ceo.getProcessId()),testMode))) {
				StringBuffer buf = new StringBuffer("");
				buf.append("TO:" + ceo.getToAddresses() + "\n <br>");
				buf.append("CC:" + ceo.getCcAddresses() + "\n <br>");
				buf.append("BCC:" + ceo.getBccAddresses() + "\n <br>");
				ceo.setMsgContentFootNote(buf.toString());
			
			} else {
				ceo.setMsgContentFootNote("");
			}
			
			
			String str = convertoXML(ceo).toString();
				
			//Apply the XML values to XSL Template using XSLT transformation
			String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate.getBody(), str);
			ceo.setMsgContent(mailContent);
			log.debug("  mailContent value is :: "+mailContent);
			sendMail(ceo,mailModuleUtil.testModeFlag(ceo.getProcessId(),testMode));
			
			log.debug("Send mail ends here .."+gisCmnts+"RISO Approver"+risoContactDetails.getSsoId());
			
		}
		catch(Exception e) {
			log.error("Exception in sending Mail"+e.getMessage(),e);
		}
		
	}
	
	@Override
	public void sendSNByPassImplEmailGen(String templateId, TIProcess tiProcess) {
		log.info("MailModuleImpl: sendSNByPassImplEmailGen: starts");
		String toList = "";
		String toUserRole = "";
		String toRole = "";
		String ccList = "";
		String emailData ="";
		String ccOwner ="";
		String ConnectionId = "";
		try{			
			SnowByPassDTO snowByPassDTO = new SnowByPassDTO();
			MailTemplates mailTemplates = mailModuleUtil.getMailTemplateById(templateId);			
			if(testMode.equalsIgnoreCase("true")){
            	snowByPassDTO.setMsgContentFootNote("true");      
            }
			ConnectionId = String.valueOf(snowByPassDTO.getConnId());
						
			if(templateId!=null && templateId.equalsIgnoreCase("FIREWALL_SNOW_BYPASS_IMPL"))
			{
				//TO_USER_ROLE
				//Operational_Analyst				
				toUserRole = toUserRole+mailModuleUtil.getUserRoleEmail(ConnectionId,  "Operational_Analyst", mailModuleUtil.testModeFlag(Long.valueOf(ConnectionId),testMode));
				toList = toList+toUserRole;
				log.info("MailModuleImpl: sendSNByPassImplEmailGen : toUserRole : "+toUserRole);
	
				//TO_ROLE
				//Operational_Analyst
				toRole = mailModuleUtil.getFWMgmtRegionEmail(ConnectionId, mailModuleUtil.testModeFlag(Long.valueOf(ConnectionId),testMode));
				toList = toRole;
				log.info("MailModuleImpl: sendSNByPassImplEmailGen : toRole : "+toRole);
			} else {
				//TO_USER_ROLE
				//Proxy_Implementer
				toUserRole = toUserRole+mailModuleUtil.getUserRoleEmail(ConnectionId,  "Proxy_Implementer", mailModuleUtil.testModeFlag(Long.valueOf(ConnectionId),testMode));
				toList = toList+toUserRole;
				log.info("MailModuleImpl: sendSNByPassImplEmailGen : toUserRole : "+toUserRole);

				//TO_ROLE
				//Proxy_Implementer
				toRole = mailModuleUtil.getRoleEmail("Proxy_Implementer", mailModuleUtil.testModeFlag(Long.valueOf(ConnectionId),testMode));
				toList = toList + toUserRole;
				log.info("MailModuleImpl: sendSNByPassImplEmailGen : toRole : "+toRole);
				toList = toList + mailModuleUtil.getAdditionalMailForProxy(ConnectionId);
			}
			log.info("MailModuleImpl: sendSNByPassImplEmailGen : toList : "+toList);
			//CC_USER_ROLE
			//Business_Owner,Requestor,Business_Tester
			String[] arrCC = new String[]{"Business_Owner","Requestor", "Business_Tester"};
			for(String strCC: arrCC){
				emailData = emailData+mailModuleUtil.getUserRoleEmail(ConnectionId,strCC,mailModuleUtil.testModeFlag(Long.valueOf(ConnectionId),testMode));
			}
			log.info("MailModuleImpl: sendSNByPassImplEmailGen : emailData : "+emailData);
			ccList = ccList+emailData;			

			//CC_OWNER
			ccOwner = ccOwner + mailModuleUtil.getOwnerEmail(ConnectionId, mailModuleUtil.testModeFlag(Long.valueOf(ConnectionId),testMode));
			log.info("MailModuleImpl: sendSNByPassImplEmailGen : ccOwner : "+ccOwner);
			ccList = ccList+ccOwner;		
			
			snowByPassDTO.setToAddresses(toList);
			snowByPassDTO.setCcAddresses(ccList);			
			snowByPassDTO.setTemplateID(mailTemplates.getTemplate_id());
			snowByPassDTO.setTiRequestID(0L);
			snowByPassDTO = (SnowByPassDTO)checkForDoNotSendEmail(snowByPassDTO);
			snowByPassDTO.setFromAddress(DL_IS_GLOBAL_CCR);			
			snowByPassDTO.setConnId(tiProcess.getId());
			snowByPassDTO.setRequestorName("Team");
			snowByPassDTO.setTiProcessName(tiProcess.getBusinessCase().getProcessType().getName());
			snowByPassDTO.setRegionName(tiProcess.getBusinessCase().getRegionName());
			snowByPassDTO.setModeName(tiProcess.getTiRequest().getTiRequestType().getName());
			snowByPassDTO.setSectorName(tiProcess.getBusinessCase().getSector().getName());
			snowByPassDTO.setActivityModeType(tiProcess.getProcessActivityMode());
			snowByPassDTO.setBusinessUnit(tiProcess.getBusinessCase().getBusinessUnit().getName());
			snowByPassDTO.setRelationshipId(tiProcess.getRelationship().getId());
			snowByPassDTO.setRelationshipName(tiProcess.getRelationship().getName());
			snowByPassDTO.setVersionNumber(tiProcess.getTiRequest().getVersionNumber());
			snowByPassDTO.setDescription(tiProcess.getName());
			snowByPassDTO.setEndPointAResType(tiProcess.getEndPointAResType());
			snowByPassDTO.setEndPointBResType(tiProcess.getEndPointBResType());
			snowByPassDTO.setFirewallType(tiProcess.getConnectionRequest().getFirewallType());
			snowByPassDTO.setFirewallRegion(tiProcess.getConnectionRequest().getFirewallRegion());
			snowByPassDTO.setHighRisk(tiProcess.getIsHighRisk());
			snowByPassDTO.setPriority(tiProcess.getTiRequest().getPriority().getValue1());
			snowByPassDTO.setRequestor(tiProcess.getRequestor().getSoeID());
			snowByPassDTO.setRequestedActivationDate(tiProcess.getTiRequest().getPlannedCompletionDate());
			snowByPassDTO.setAppsenseScheduledDate(tiProcess.getTiRequest().getApsImpCompletedDate());
			snowByPassDTO.setProxyScheduledDate(tiProcess.getTiRequest().getPrxImpScheduledDate());
			snowByPassDTO.setFirewallScheduledDate(tiProcess.getTiRequest().getOpeImpScheduledDate());
			snowByPassDTO.setExpirationDate(tiProcess.getTiRequest().getRequestDeadline());
			snowByPassDTO.setGnoScheduledDate(tiProcess.getTiRequest().getGnccImpScheduledDate());
			snowByPassDTO.setSystemId(tiProcess.getTiRequest().getCmpId());
			snowByPassDTO.setDisplayUserRole(tiProcess.getTiRequest().getActivityData().getDisplayUserRole());
			snowByPassDTO.setActivityDescription(tiProcess.getTiRequest().getActivityData().getActivityName());
						
			if(snowByPassDTO.getConnId() > 0 && snowByPassDTO.getVersionNumber()>0){
				mailTemplates.setSubject(mailTemplates.getSubject().replace("#CCR_ID#", snowByPassDTO.getConnId()+"."+snowByPassDTO.getVersionNumber()));
			}
			
			if(snowByPassDTO.getDescription() != null){
				mailTemplates.setSubject(mailTemplates.getSubject().replace("#CCR_NAME#", snowByPassDTO.getDescription()));
			}
			
			if(snowByPassDTO.getPriority() != null){
				mailTemplates.setSubject(mailTemplates.getSubject().replace("#CCR_PRIORITY#", snowByPassDTO.getPriority()));
			}
			
			if(snowByPassDTO.getTemplateID() != null){
				if(snowByPassDTO.getTemplateID().equalsIgnoreCase("FIREWALL_SNOW_BYPASS_IMPL"))
					mailTemplates.setSubject(mailTemplates.getSubject().replace("#IMPL_TYPE#", "FireWall"));
				else
					mailTemplates.setSubject(mailTemplates.getSubject().replace("#IMPL_TYPE#", "Proxy"));
			}
			
			snowByPassDTO.setMsgSubject(mailTemplates.getSubject());			
			log.info("MailModuleImpl: sendSNByPassImplEmailGen : MsgSubject : "+snowByPassDTO.getMsgSubject());
			snowByPassDTO.setC3parBaseUrl(ccrUrl+ "/defaultInboxView.act");
			log.info("MailModuleImpl: sendSNByPassImplEmailGen : C3parBaseUrl : "+snowByPassDTO.getC3parBaseUrl());
			log.info("MailModuleImpl: sendSNByPassImplEmailGen : mailTemplates.getBody() : "+mailTemplates.getBody());
			String mailContent = transformObjectXMLtoXSLTemplate(mailTemplates, snowByPassDTO);
			log.info("MailModuleImpl: sendSNByPassImplEmailGen : mailContent : "+mailContent);
			snowByPassDTO.setMsgContent(mailContent);
			log.info("MailModuleImpl: sendSNByPassImplEmailGen : before calling sendMail : testMode :"+testMode);
            sendMail(snowByPassDTO, testMode);            
            
            log.info("MailModuleImpl: sendSNByPassImplEmailGen: ends");
		}		
		catch(Exception e){
			log.error("MailModuleImpl: sendSNByPassImplEmailGen: exception: "+e.getMessage(),  e);
		}
	}
	
	private String setToString(Set<String> set){
		StringBuffer buffer=new StringBuffer("");
		for(String str : set){
			buffer.append(str);
		}
		return buffer.toString();		
	}
	/**
	 * Added Newly for rearchitectering
	 */
	public  C3PARMailMessage parseTemplateNew(String templateId, InputMailVO mailVO,boolean loadMailTemplates){
		C3PARMailMessage mailMessage = new C3PARMailMessage();
		List<MailMsgDisplayInfo> allmailDisplayInfos=null;
		mailMessage.setC3parBaseUrl(C3PAR_BASE_URL);
		mailMessage.setTemplateID(templateId);
		mailMessage.setTiRequestID(mailVO.getTirequestID());
		log.debug ("MailModule:MailModuleImpl:parseTemplateNew::templateId ==> "+templateId+" TirequestID ==> "+mailVO.getTirequestID());
		try {
			MailTemplates mailtemplate = mailModuleUtil.getMailTemplateById(templateId);
			mailMessage = processTemplateBody(mailtemplate, mailMessage, templateId, mailVO);
			if(DIR_MAIL_INFO.equals(templateId)){
				mailMessage.setVersionNo(mailVO.getTiProcess().getVersionNumber());
				mailMessage.setBusinessJustification(mailVO.getBusinessJustification());
				mailMessage.setTiProcessName(mailVO.getTiProcess().getName());
				mailMessage.setProjCoordInfo(mailVO.getProjCoordInfo());				
				log.debug("version : "+mailMessage.getVersionNo() +" businessJust : "+mailMessage.getBusinessJustification() +" name : "+mailMessage.getTiProcessName());
			}
			
			if(ISA_APPROVAL.equals(templateId) || ISA_REJECTION.equals(templateId) || SYSADMIN_REJECTION.equals(templateId) || MANAGER_REVIEW.equals(templateId)
				|| MANAGER_REJECTION.equals(templateId) || MANAGER_ENT_NOTIFICATION.equals(templateId) || ISA_ENT_NOTIFICATION.equals(templateId)
				|| SYSADMIN_ENT_NOTIFICATION.equals(templateId)){
				InputMailVO inputMailVO = (InputMailVO) mailVO;
				mailMessage.setCcrID(inputMailVO.getConnectionId());
				mailMessage.setFirstName(inputMailVO.getUser().getFirstName());
				mailMessage.setLastName(inputMailVO.getUser().getLastName());
				mailMessage.setSsoId(inputMailVO.getUser().getSsoId());
				allmailDisplayInfos=getDisplayInfoList(inputMailVO,templateId);
			}
			else{
				InputMailVO	inputmailVo=(InputMailVO) mailVO;
				mailMessage.setCcrID(mailVO.getConnectionId());
				//setting the from address
				mailMessage.setName(inputmailVo.getName());
				mailMessage.setFromAddress(mailtemplate.getFromAdr());
				mailMessage.setDisplayUserRole(inputmailVo.getTiProcess().getTiRequest().getActivityData().getDisplayUserRole());
				mailMessage.setWorkItemUrl(inputmailVo.getWorkItemUrl());
				mailMessage.setApproveURL(inputmailVo.getApproveURL());
				mailMessage.setRejectURL(inputmailVo.getRejectURL());
				mailMessage.setDisplayInfoUserRole(inputmailVo.getTiProcess().getTiRequest().getActivityData().getDisplayInfoUserRole());
				if(	inputmailVo.getImplementationResults()!=null){
					
					mailMessage.setImplementationResults(inputmailVo.getImplementationResults().replace("<br>", "\n"));
				}
				//mailMessage.setImplementationResults(inputmailVo.getImplementationResults());
				if(	inputmailVo.getTiProcess().getRfc()!=null){
					
					mailMessage.setRfc(inputmailVo.getTiProcess().getRfc().replace("<br>", "\n"));
				}
				//mailMessage.setImplementationResults(inputmailVo.getImplementationResults());
				//mailMessage.setRfc(inputmailVo.getTiProcess().getRfc());
				mailMessage.setPrxImpScheduledDate(formatDate(inputmailVo.getTiProcess().getTiRequest().getPrxImpScheduledDate()));
				log.debug("inputmailVo.getTiProcess().getTiRequest().getPrxInfomanId() "+inputmailVo.getTiProcess().getTiRequest().getPrxInfomanId());
	            mailMessage.setPrxInfomanId(String.valueOf(inputmailVo.getTiProcess().getTiRequest().getPrxInfomanId()));
	            mailMessage.setActivationExpiryDate(formatDate(inputmailVo.getTiProcess().getActivationExpiryDate()));
	            mailMessage.setTPASWGReviewDate(formatDate(inputmailVo.getTiProcess().getTiRequest().getTPASWGReviewDate()));
	            mailMessage.setOpeImpScheduledDate(formatDate(inputmailVo.getTiProcess().getTiRequest().getGnccImpScheduledDate()));
	            mailMessage.setApsImpScheduledDate(formatDate(inputmailVo.getTiProcess().getTiRequest().getApsImpScheduledDate()));
	            mailMessage.setApsInfomanId(String.valueOf(inputmailVo.getTiProcess().getTiRequest().getApsInfomanId()));
	            mailMessage.setActivityStartDate(inputmailVo.getTiProcess().getTiRequest().getActivityStartDate());
				//Create a row object and set the infoArray into the row attribute
	            allmailDisplayInfos=getDisplayInfoList(inputmailVo,templateId);
	            //Anant Code changes start
	            mailMessage.setTemplateOwners(inputmailVo.getTiProcess().getTemplateOwners());
	            mailMessage.setTemplateAppNames(inputmailVo.getTiProcess().getTemplateAppNames());
	            mailMessage.setActivityName(inputmailVo.getTiProcess().getTiRequest().getActivityData().getActivityName());
	            mailMessage.setConName(inputmailVo.getTiProcess().getName());
	            mailMessage.setSoeID(inputmailVo.getTiProcess().getRequestor().getSoeID());
                mailMessage.setProjectCoordinatorNames(inputmailVo.getProjectCoordinatorNames());
                mailMessage.setBusinessOwnerNames(inputmailVo.getBusinessOwnerNames());
                mailMessage.setBusinessManagerNames(inputmailVo.getBusinessManagerNames());
                mailMessage.setRequestorNames(inputmailVo.getRequestorNames());
                mailMessage.setIsoNames(inputmailVo.getIsoNames());
                mailMessage.setTemplateConNames(inputmailVo.getTiProcess().getTemplateConNames());
                mailMessage.setTemplateConIds(inputmailVo.getTiProcess().getTemplateConIds());
                mailMessage.setNetInfomanId(String.valueOf(inputmailVo.getTiProcess().getTiRequest().getGnccInfomanId()));
                mailMessage.setDaysRemaining(inputmailVo.getDaysRemaining());
                //Anant Code changes End
			}
		    List<MailMsgDisplayRow> rowList=new ArrayList<MailMsgDisplayRow>();
		    int disPlaySize=allmailDisplayInfos.size();
		    if(disPlaySize%2!=0){
			    MailMsgDisplayInfo msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.EMPTY_VAL);
				msgDisplayInfo.setValue(MailModuleConstants.EMPTY_VAL);
				allmailDisplayInfos.add(msgDisplayInfo);
			    }
			    
		   
		    
		    for (int i = 0; i <disPlaySize; i=i+2) {
				MailMsgDisplayRow rowData = new MailMsgDisplayRow();
				MailMsgDisplayInfo[]  rowMailDisplayInfo={allmailDisplayInfos.get(i),allmailDisplayInfos.get(i+1)};
				rowData.setInfo(rowMailDisplayInfo);
				rowList.add(rowData);
				//rowArray[j]=rowData;
			}
		    
			/*for (int i = 0; i <disPlaySize ; i++){
				MailMsgDisplayRow rowData = new MailMsgDisplayRow();
				even=++i;
				if(even<disPlaySize){
					MailMsgDisplayInfo[]  rowMailDisplayInfo={allmailDisplayInfos.get(i),allmailDisplayInfos.get(even)};
					rowData.setInfo(rowMailDisplayInfo);
					rowList.add(rowData);	
				}else{
					MailMsgDisplayInfo msgDisplayInfo = new MailMsgDisplayInfo();
					msgDisplayInfo.setLabel(MailModuleConstants.EMPTY_VAL);
					msgDisplayInfo.setValue(MailModuleConstants.EMPTY_VAL);
					MailMsgDisplayInfo[]  rowMailDisplayInfo={allmailDisplayInfos.get(i),msgDisplayInfo};
					rowData.setInfo(rowMailDisplayInfo);
					rowList.add(rowData);
				}
				
			}*/
			//Create an array of Rows. In this case we have only single row containing 3 info objects
			//mailMessage.setRow(rowArray);
			mailMessage.setRowList(rowList);
			log.debug("rowArray size -> "+rowList.size());
			mailMessage.setC3parBaseUrl(C3PAR_BASE_URL);
			//Apply the XML values to XSL Template using XSLT transformation
			String mailContent = transformObjectXMLtoXSLTemplate(mailtemplate, mailMessage);
			mailMessage.setMsgContent(mailContent);
			//log.debug("Mail Content AFTER XML Parsing "+mailContent);
			//sendMail(mailMessage,mailModuleUtil.testModeFlag(null,testMode));
		}catch(Exception e) {
			log.error("Exception in sending Mail"+e.getMessage(),e);
		}
	
		return mailMessage;
	}
	//Element templateNode, String templateId, C3PARMailMessage c3parMailMessage, BaseMailVO mailVO
			private C3PARMailMessage processTemplateBody(MailTemplates mailtemplate, C3PARMailMessage c3parMailMessage,
								String templateId, BaseMailVO mailVO) throws MailModuleException{
				
					
					c3parMailMessage.setFromAddress(mailtemplate.getFromAdr());
					log.debug ("MailModuleImpl:parseTemplate:from:"+mailtemplate.getFromAdr());

					//-------
					String toList = "";
					String toUserNamesList = "";
					String toUserRole = mailtemplate.getToUserRole();
					String name="";
					 
					if(templateId.equals(DIR_MAIL_INFO)){
						String[] toUserRoleCategories = toUserRole.split("\\,");
						String roles = "";
						
						for(int i=0;i<toUserRoleCategories.length;i++){
							if(i==0){
								roles+="'"+toUserRoleCategories[i]+"'";
							}else{
								roles+=",'"+toUserRoleCategories[i]+"'";
							}
						}
						List directorApprovalMailList = mailModuleUtil.getDirectorMaiId(mailVO,roles);//'Director'
						if (directorApprovalMailList != null && !directorApprovalMailList.isEmpty()) {
							for (int i = 0; i < directorApprovalMailList.size(); i++) {
								Map directorApprovalMailInfo=(Map)directorApprovalMailList.get(i);
								String nameComb=(String)directorApprovalMailInfo.get("firstName")+" "+
								(String)directorApprovalMailInfo.get("lastName");
								if (!nameComb.trim().equals(""))
									name=name + nameComb + " and ";
							}
						}else{
							log.debug ("directorApprovalMailList is null or empty");
							throw new BusinessException("Please add Direct Level Approver in Target Contacts");
						}
						if(name.lastIndexOf("and") != -1 && name.length() > 1){
							name = name.substring(0, name.length()-4 );
						}
						((InputMailVO)mailVO).setName(name);
						log.debug ("MailModuleImpl:parseTemplate:name:"+name);
						
					}
			        if(toUserRole != null && !("".equals(toUserRole))){
			        	String[] toUserRoleCategories = toUserRole.split("\\,");
			        	toUserRole = "";
						for (int i = 0; i < toUserRoleCategories.length; i++) {
			       		 if(toUserRoleCategories[i] != null && !("".equals(toUserRoleCategories[i].trim()))){
			       			if (templateId != null && !templateId.trim().equals("") &&(templateId.equals(ACTIVATION_EXPIRATION_REMINDER_7DAYS) || templateId.equals(VERIFY_SOW) || templateId.equals(ISO_APPROVAL) || templateId.equals(MANAGER_APPROVAL))){
			       				toUserRole = toUserRole + mailModuleUtil.getUserRoleEmailOfPrimaryAndSecondary(mailVO.getConnectionId(), toUserRoleCategories[i],  mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			       				toUserNamesList = toUserNamesList + mailModuleUtil.getUserRoleEmailOfPrimaryAndSecondary(mailVO.getConnectionId(), toUserRoleCategories[i],  "names");
			       			}else if (templateId != null && !templateId.trim().equals("") && templateId.equals(ACTIVATION_EXPIRATION_REMINDER_30DAYS)){
			       				if("Manager".equalsIgnoreCase(toUserRoleCategories[i])){
			       					toUserRole = toUserRole + mailModuleUtil.getUserRoleEmailOfPrimaryAndSecondary(mailVO.getConnectionId(), toUserRoleCategories[i],  mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			           				toUserNamesList = toUserNamesList + mailModuleUtil.getUserRoleEmailOfPrimaryAndSecondary(mailVO.getConnectionId(), toUserRoleCategories[i],  "names");
			       				}else{
			       					toUserRole = toUserRole + mailModuleUtil.getManagerEmail(mailVO.getConnectionId(), toUserRoleCategories[i],  mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			           				toUserNamesList = toUserNamesList + mailModuleUtil.getManagerName(mailVO.getConnectionId(), toUserRoleCategories[i],  "names");
			       				}
			       				
			       			}else{
			       			 toUserRole = toUserRole+mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),  toUserRoleCategories[i], mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
			       		 }
			       	}
			       }
						
						  log.debug ("MailModuleImpl:parseTemplate:toUserRole:" + toUserRole);
			        }
			        toList = toUserRole;
			        if (templateId != null && !templateId.trim().equals("") &&(templateId.equals(ACTIVATION_EXPIRATION_REMINDER_7DAYS) ||templateId.equals(ACTIVATION_EXPIRATION_REMINDER_30DAYS)|| templateId.equals(VERIFY_SOW) || templateId.equals(ISO_APPROVAL) || templateId.equals(MANAGER_APPROVAL))){
			    		String[] toUserList = toUserNamesList.split("\\,");
			    		
			    		  Set<String> nameSet = new HashSet<String>();
			    	        StringBuffer newUserNameList=new StringBuffer();
			    	        	for(String toUser:toUserList){
			    	        		
			    	                if(toUser!=null && !toUser.trim().isEmpty() && nameSet.add(toUser.trim())){
			    	                	
			    	                        newUserNameList.append(toUser+ ", ");
			    	               }

			    		 }
						((InputMailVO)mailVO).setName(newUserNameList.toString());
						log.debug("Business manager names:"+((InputMailVO)mailVO).getName());
			        }
			      //----
					String toOwner = mailtemplate.getToOwner();
					String[] toOwnerCategories = toOwner.split("\\,");
					toOwner = "";
					for (int i = 0; i < toOwnerCategories.length; i++) {
						if(toOwnerCategories[i]!= null && "CURRENT_PC".equals(toOwnerCategories[i])){
							toOwner = toOwner + mailModuleUtil.getOwnerEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
						} else if(toOwnerCategories[i]!=null && "ALL_REQUESTORS".equals(toOwnerCategories[i])){
							toOwner = toOwner + mailModuleUtil.getAllRequestorsEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
						} else if(toOwnerCategories[i]!=null && !("".equals(toOwnerCategories[i].trim()))){
							toOwner = toOwner + mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(), toOwnerCategories[i], mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
						}
					}
					
					log.debug ("MailModuleImpl:parseTemplate:toOwner:"+toOwner);
					toList = toList + toOwner;

					//----
					String toRole = mailtemplate.getToRole(); 

					if (toRole!=  null && !("".equals(toRole))){
						String[] toRoleCategories = toRole.split("\\,");
						if(OPERATIONAL_IMPLEMENTATION.equalsIgnoreCase(templateId)){
							toRole="";
							toRole = mailModuleUtil.getFWMgmtRegionEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));

						} else {
							toRole="";
							for (String toRoleCategorie : toRoleCategories) {
								toRole = toRole + mailModuleUtil.getRoleEmail(toRoleCategorie, mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));

							}
						}
					}
					if(templateId.equalsIgnoreCase(TEMPLATE_MAIL_B4_FW_IMPL)){
						toRole = toRole + mailModuleUtil.getTemplateUsingConnOwners(mailVO);
						log.debug("TEMPLATE_MAIL_B4_FW_IMPL::toRole::"+toRole);
					}
					if(templateId.equalsIgnoreCase(TEMPLATE_MAIL_B4_MANITENENCE)){
						//Send to previous Template Connection owner
						toRole = toRole + mailModuleUtil.getTemplateConnPreOwner(mailVO);
						log.debug("TEMPLATE_MAIL_B4_MANITENENCE::toRole::"+toRole);
					}
					if(templateId.equalsIgnoreCase(TEMPLT_UING_CONN_MAIL_B4_TECH) || templateId.equalsIgnoreCase(TEMPLT_UING_CONN_MAIL_B4_TECH_TWO) ){
						toRole = toRole + mailModuleUtil.getTemplateConnOwners(mailVO);
						log.debug("TEMPLT_UING_CONN_MAIL_B4_TECH::toRole::"+toRole);
					}
					log.debug ("MailModuleImpl:parseTemplate:toRole:"+toRole);
					toList =  toList + toRole;

					if(mailVO.getToEmailAddress() != null && !("".equals(mailVO.getToEmailAddress()))){
						toList = toList + mailVO.getToEmailAddress();

					}
					//Added for task 42663-Starts
					//Add DL(*GT Global Proxy Integration) to mail list if it was added as part of special instruction
					if (templateId.equalsIgnoreCase(PROXY_APPROVAL)) {
							log.debug("Setting the mail id for proxy approval");
							toList = toList + mailModuleUtil.getAdditionalMailForProxy(mailVO.getConnectionId());
							log.debug("Proxy approval toList is "+toList);
						}
					
					//Added for task 42663-Ends
					if (toList == null || "".equals(toList)){
						log.error(" there are no email addresses mentioned for sending the email TO");
					} else {
						c3parMailMessage.setToAddresses(toList);
						log.debug("MailModule:MailModuleImpl:parse:: Email Addresses in TO List::" + toList);
					}
					//----
					String cc = mailtemplate.getCc();
					if (cc != null && !("".equals(cc))){
						cc=cc + EMAIL_ADDRESS_SEPERATOR;
					}
					log.debug ("MailModuleImpl:parseTemplate:cc:"+cc);
					
					String ccUserRole = mailtemplate.getCcUserRole();
					String[] ccUsers=null;
					if(ccUserRole != null && ccUserRole.trim().length() > 0){
						ccUsers = ccUserRole.split("\\,");
						String projectCoordInfo = "";						
						if(templateId.equals(DIR_MAIL_INFO)){
							for(String strCC:ccUsers)
							{
								if(strCC != null && !strCC.isEmpty()){
									List<String> info = mailModuleUtil.getUsrRleEmailPrjInfo(mailVO.getConnectionId(),strCC,mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
									if(projectCoordInfo.equals("") && !info.isEmpty() && !info.get(1).equals("")){
										projectCoordInfo = info.get(1);
									}else if(!info.isEmpty() && !info.get(1).equals("")){
										projectCoordInfo+=","+info.get(1);
									}
									
									if(!info.isEmpty() && !info.get(0).equals(""))
									{
										cc=cc+info.get(0);
									}
								}
							}
							((InputMailVO)mailVO).setProjCoordInfo(projectCoordInfo);
							log.debug ("MailModuleImpl:parseTemplate:projectCoordInfo:"+projectCoordInfo);
							
						}else{
							String names = "";
							for(String strCC:ccUsers)
							{
								String emailData = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
								log.debug ("MailModuleImpl:parseTemplate:emailData:"+emailData);
								log.debug ("MailModuleImpl:parseTemplate:templateId:"+templateId);
				                if(templateId != null && !templateId.trim().equals("") && templateId.equals(ACTIVATION_EXPIRATION_REMINDER_30DAYS)){
				                	if(strCC != null && strCC.equalsIgnoreCase("PROJECT COORDINATOR")){
				                		names = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,"names");
				                		if(names.length() > 1 && names.lastIndexOf(",") != -1){
				                			names = names.substring(0, names.length() - 2);
				                		}
				                		((InputMailVO)mailVO).setProjectCoordinatorNames(names);
				                	}else if(strCC != null && strCC.equalsIgnoreCase("Business_Owner")){
				                		names = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,"names");
				                		if(names.length() > 1 && names.lastIndexOf(",") != -1){
				                			names = names.substring(0, names.length() - 2);
				                		}
				                		((InputMailVO)mailVO).setBusinessOwnerNames(names);
				                	}else if(strCC != null && strCC.equalsIgnoreCase("Manager")){
				                		names = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,"names");
				                		if(names.length() > 1 && names.lastIndexOf(",") != -1){
				                			names = names.substring(0, names.length() - 2);
				                		}
				                		((InputMailVO)mailVO).setBusinessManagerNames(names);
				                	}else if(strCC != null && strCC.equalsIgnoreCase("Requestor")){
				                		names = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,"names");
				                		if(names.length() > 1 && names.lastIndexOf(",") != -1){
				                			names = names.substring(0, names.length() - 2);
				                		}
				                		((InputMailVO)mailVO).setRequestorNames(names);
				                	}else if(strCC != null && strCC.equalsIgnoreCase("BISO")){
				                		names = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),strCC,"names");
				                		if(names.length() > 1 && names.lastIndexOf(",") != -1){
				                			names = names.substring(0, names.length() - 2);
				                		}
				                		((InputMailVO)mailVO).setIsoNames(names);
				                	}
				                }				                    
								if(emailData!=null && !emailData.trim().equals("") && !emailData.isEmpty()){
									cc=cc+emailData;
								}
							}
						}
					}
					
					if (ccUserRole != null && !("".equals(ccUserRole))){
						ccUserRole = mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(), ccUserRole, mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
					}
					cc = cc + ccUserRole;
					log.debug ("MailModuleImpl:parseTemplate:ccUserRole:"+ccUserRole);
					
					String ccOwner = mailtemplate.getCcOwner();
					String[] ccOwnerCategories = ccOwner.split("\\,");
					ccOwner = "";
					for (int i = 0; i < ccOwnerCategories.length; i++) {
						if(ccOwnerCategories[i] != null && "CURRENT_PC".equals(ccOwnerCategories[i])){
							ccOwner = ccOwner + mailModuleUtil.getOwnerEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
						} else if(ccOwnerCategories[i] != null && "ALL_REQUESTORS".equals(ccOwnerCategories[i])){
							ccOwner = ccOwner + mailModuleUtil.getAllRequestorsEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
						} else if(ccOwnerCategories[i]!=null && !("".equals(ccOwnerCategories[i].trim()))){
							ccOwner = ccOwner + mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(), ccOwnerCategories[i], mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
						}
					}
					cc = cc + ccOwner;
					log.debug ("MailModuleImpl:parseTemplate:ccOwner:"+ccOwner);
					
					//----
					String ccRole = mailtemplate.getCcRole();
					if (ccRole != null && !("".equals(ccRole))) {
						if(OPERATIONAL_IMPLEMENTATION.equalsIgnoreCase(templateId)){
							ccRole = mailModuleUtil.getFWMgmtRegionEmail(mailVO.getConnectionId(), mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
						} else{
							ccRole = mailModuleUtil.getRoleEmail(ccRole, mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode));
						}
					}
					cc = cc + ccRole;
					log.debug ("MailModuleImpl:parseTemplate:ccRole:"+ccRole);

					if(mailVO.getCcEmailAddress() != null && !("".equals(mailVO.getCcEmailAddress()))){
						cc = cc + mailVO.getCcEmailAddress();
					}
					if(templateId.equals(DIR_MAIL_INFO)){
						//notifyUsers=mailModuleUtil.getUserRoleEmail(mailVO.getConnectionId(),testMode);
						String directorCCDL = C3parProperties.DIRECTOR_CC_DL+";";
						cc = cc + directorCCDL;
						 //log.debug ("MailModuleImpl:parseTemplate:notifyUsers:"+notifyUsers);
					} 
					
					
					c3parMailMessage.setCcAddresses(cc);

					//-------
					String bcc = mailtemplate.getBcc();
					if (bcc != null && !("".equals(bcc))) {
						bcc = bcc + EMAIL_ADDRESS_SEPERATOR;
					}
					if(mailVO.getBccEmailAddress() != null && !("".equals(mailVO.getBccEmailAddress()))){
						bcc = bcc + mailVO.getBccEmailAddress();
					}
					c3parMailMessage.setBccAddresses(bcc);
					log.debug ("MailModuleImpl:parseTemplate:bcc:"+bcc);
					
					//-------
					String subject = mailtemplate.getSubject();
					if(mailVO.getMailSubject() != null && !("".equals(mailVO.getMailSubject()))){
						subject = subject +" "+ mailVO.getMailSubject();
					}
					if(subject == null || "".equals(subject)){
						throw new MailModuleException("The tag "+ELEMENT_SUBJECT+" is blank in the template : " + templateId);
					}
					String returnSubjectStr = searchVarsAndReplaceValues(subject, mailVO);
					//Need to remove After Testing
					c3parMailMessage.setMsgSubject(returnSubjectStr);
					//c3parMailMessage.setMsgSubject(returnSubjectStr+"("+templateId+")");
					log.debug ("MailModuleImpl:parseTemplate:returnSubjectStr:"+returnSubjectStr);
					
					//----
					String body = mailtemplate.getBody();
					
					if(body == null || "".equals(body)){
						throw new MailModuleException("The tag "+ELEMENT_BODY+" is blank in the template : "+templateId);
					}
					
					c3parMailMessage.setMsgContent(body);
					//log.debug ("MailModuleImpl:parseTemplate:body:"+body);
					
					
					if(!templateId.equals(DIR_MAIL_INFO)){
						//Checking DoNotSendMailList - Ignoring emailId's in to,CC,Bcc list
						c3parMailMessage = checkForDoNotSendEmail(c3parMailMessage);
					}
					

						
					if ("true".equalsIgnoreCase(mailModuleUtil.testModeFlag(Long.valueOf(mailVO.getConnectionId()),testMode))) {
						StringBuffer buf = new StringBuffer("");
						buf.append("TO:" + c3parMailMessage.getToAddresses() + "\n <br>");
						buf.append("CC:" + c3parMailMessage.getCcAddresses() + "\n <br>");
						buf.append("BCC:" + c3parMailMessage.getBccAddresses() + "\n <br>");
						c3parMailMessage.setMsgContentFootNote(buf.toString());
					
					} else {
						c3parMailMessage.setMsgContentFootNote("");
					}
					
					if(templateId.equals(DIR_MAIL_INFO)){
						String footnote = mailtemplate.getFootNote();
						Map<String,String> emerBuscritQuesAndAnswers=mailModuleUtil.getEmerBuscritQuesAnswers(mailVO.getConnectionId());
						//populateRow(templateElement, mailVO);
						c3parMailMessage.setQuestRow(populateInfo(emerBuscritQuesAndAnswers));
						c3parMailMessage.setMsgContentFootNote(c3parMailMessage.getMsgContentFootNote()+footnote);
					}
					
				return c3parMailMessage;
					
			}
			
	private List<MailMsgDisplayInfo> getDisplayInfoList(InputMailVO mailVO,String templateId) {
		List<MailMsgDisplayInfo> mailInfoList = new ArrayList<MailMsgDisplayInfo>();
		MailMsgDisplayInfo msgDisplayInfo = null;
		try {
			if(ISA_APPROVAL.equals(templateId) || ISA_REJECTION.equals(templateId) || SYSADMIN_REJECTION.equals(templateId) || MANAGER_REVIEW.equals(templateId)
					|| MANAGER_REJECTION.equals(templateId) || MANAGER_ENT_NOTIFICATION.equals(templateId) || ISA_ENT_NOTIFICATION.equals(templateId)
					|| SYSADMIN_ENT_NOTIFICATION.equals(templateId)){
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.SSO_ID);
				msgDisplayInfo.setValue(mailVO.getUser().getSsoId());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.EMAIL);
				msgDisplayInfo.setValue(mailVO.getUser().getEmail());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.FIRST_NAME);
				msgDisplayInfo.setValue(mailVO.getUser().getFirstName());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.LAST_NAME);
				msgDisplayInfo.setValue(mailVO.getUser().getLastName());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.DISPLAY_NAME);
				msgDisplayInfo.setValue(mailVO.getUser().getDisplayName());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.REQUESTED_BY);
				msgDisplayInfo.setValue(mailVO.getUser().getRequestedBy());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.ROLE);
				msgDisplayInfo.setValue(mailVO.getUser().getDisplayRoles());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.ENTITLEMENTS);
				msgDisplayInfo.setValue(mailVO.getUser().getDisplayEntitlements());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.MANAGERAPPROVAL);
				msgDisplayInfo.setValue(mailVO.getUser().getManagerApprover());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.MANAGER_REV_DATE);
				msgDisplayInfo.setValue(formatDate(mailVO.getUser().getManagerReviewedDate()));
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.SYS_ADMIN_APPROVER);
				msgDisplayInfo.setValue(mailVO.getUser().getSysadminApprover());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.SYS_ADMIN_REV_DATE);
				msgDisplayInfo.setValue(formatDate(mailVO.getUser().getSysadminReviewedDate()));
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.COMMENT);
				msgDisplayInfo.setValue(mailVO.getUser().getComments());
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.LAST_SUBMITTED_BY);
				msgDisplayInfo.setValue(mailModuleUtil.getLastSubmitterRole(mailVO.getTirequestID()));
				mailInfoList.add(msgDisplayInfo);
				
				msgDisplayInfo = new MailMsgDisplayInfo();
				msgDisplayInfo.setLabel(MailModuleConstants.COMMENT);
				msgDisplayInfo.setValue(mailModuleUtil.getLastSubmitterComments(mailVO.getTirequestID()));
				mailInfoList.add(msgDisplayInfo);
				
			}
			else{
				
			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.TIPROCESS);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getBusinessCase().getProcessType().getName());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.REGION);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getBusinessCase().getRegionName());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.MODE);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getTiRequest().getTiRequestType().getName());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.SECTOR);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getBusinessCase().getSector().getName());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.TYPE);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getProcessActivityMode());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.BUS_UNIT);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getBusinessCase().getBusinessUnit().getName());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.REL_ID);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getRelationship().getId() + "");
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.REL_NAME);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getRelationship().getName());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.ID);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getId() +"."+mailVO.getTiProcess().getTiRequest().getVersionNumber() + "");
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.DESCRIPTION);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getName());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.ENDPOINT_A);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getEndPointAResType());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.ENDPOINT_B);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getEndPointBResType());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.FIREWALL_TYPE);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getConnectionRequest().getFirewallType());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.FIREWALL_REGION);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getConnectionRequest().getFirewallRegion());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.HIGH_RISK);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getIsHighRisk());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.PRIORITY);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getTiRequest().getPriority().getValue1());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.REQUESTER);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getRequestor().getSoeID());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.ACTIVIATION_DATE);
			msgDisplayInfo.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getPlannedCompletionDate()));
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.APPENSE_SCHE_DATE);
			msgDisplayInfo.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getApsImpScheduledDate()));
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.PROXY_SCHE_DATE);
			msgDisplayInfo.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getPrxImpScheduledDate()));
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.FW_OPS_SCHE_DATE);
			msgDisplayInfo.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getPrxImpScheduledDate()));
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.EXPIRATION_DATE);
			msgDisplayInfo.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getRequestDeadline()));
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.GNO_SCHE_DATE);
			msgDisplayInfo.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getGnccImpScheduledDate()));
			mailInfoList.add(msgDisplayInfo);
			
			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.SYSTEM_ID);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getTiRequest().getCmpId());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.ROLE);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getTiRequest().getActivityData().getDisplayUserRole()
					+ mailVO.getTiProcess().getTiRequest().getActivityData().getDisplayInfoUserRole());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.ACTIVITY_DESCRIPTION);
			msgDisplayInfo.setValue(mailVO.getTiProcess().getTiRequest().getActivityData().getActivityName());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.LAST_SUBMITTED_BY);
			msgDisplayInfo.setValue(mailVO.getLastSubmitterRole());
			mailInfoList.add(msgDisplayInfo);

			msgDisplayInfo = new MailMsgDisplayInfo();
			msgDisplayInfo.setLabel(MailModuleConstants.COMMENT);
			msgDisplayInfo.setValue(mailVO.getLastSubmitterComments());
			mailInfoList.add(msgDisplayInfo);

			}	
		
		} catch (Exception e) {
			log.error("Error has occurred in getDisplayInfo() ::" + e.toString());

		}
		return mailInfoList;
	}
	
			private MailMsgDisplayInfo[] getDisplayInfoArray(InputMailVO mailVO){
				MailMsgDisplayInfo[] msgDisplayInfoArray = new MailMsgDisplayInfo[28];
				int j=0;
				
				MailMsgDisplayInfo msgDisplayInfo1 = new MailMsgDisplayInfo();
				msgDisplayInfo1.setLabel("TI Process");
				msgDisplayInfo1.setValue(mailVO.getTiProcess().getBusinessCase().getProcessType().getName());
				msgDisplayInfoArray[j++]=msgDisplayInfo1;
				
				MailMsgDisplayInfo msgDisplayInfo2 = new MailMsgDisplayInfo();
				msgDisplayInfo2.setLabel("Region");
				msgDisplayInfo2.setValue(mailVO.getTiProcess().getBusinessCase().getRegionName());
				msgDisplayInfoArray[j++]=msgDisplayInfo2;
				
				MailMsgDisplayInfo msgDisplayInfo3 = new MailMsgDisplayInfo();
				msgDisplayInfo3.setLabel("Mode");
				msgDisplayInfo3.setValue(mailVO.getTiProcess().getTiRequest().getTiRequestType().getName());
				msgDisplayInfoArray[j++]=msgDisplayInfo3;
				
				MailMsgDisplayInfo msgDisplayInfo4 = new MailMsgDisplayInfo();
				msgDisplayInfo4.setLabel("Sector");
				msgDisplayInfo4.setValue(mailVO.getTiProcess().getBusinessCase().getSector().getName());
				msgDisplayInfoArray[j++]=msgDisplayInfo4;
				
				
				MailMsgDisplayInfo msgDisplayInfo5 = new MailMsgDisplayInfo();
				msgDisplayInfo5.setLabel("Type");
				msgDisplayInfo5.setValue(mailVO.getTiProcess().getProcessActivityMode());
				msgDisplayInfoArray[j++]=msgDisplayInfo5;
				
				MailMsgDisplayInfo msgDisplayInfo6 = new MailMsgDisplayInfo();
				msgDisplayInfo6.setLabel("Business Unit");
				msgDisplayInfo6.setValue(mailVO.getTiProcess().getBusinessCase().getBusinessUnit().getName());
				msgDisplayInfoArray[j++]=msgDisplayInfo6;
				
				
				MailMsgDisplayInfo msgDisplayInfo7 = new MailMsgDisplayInfo();
				msgDisplayInfo7.setLabel("Relationship ID");
				msgDisplayInfo7.setValue(mailVO.getTiProcess().getRelationship().getId()+"");
				msgDisplayInfoArray[j++]=msgDisplayInfo7;
				
				MailMsgDisplayInfo msgDisplayInfo8 = new MailMsgDisplayInfo();
				msgDisplayInfo8.setLabel("Relationship Name");
				msgDisplayInfo8.setValue(mailVO.getTiProcess().getRelationship().getName());
				msgDisplayInfoArray[j++]=msgDisplayInfo8;
				
				MailMsgDisplayInfo msgDisplayInfo9 = new MailMsgDisplayInfo();
				msgDisplayInfo9.setLabel("ID");
				msgDisplayInfo9.setValue(mailVO.getTiProcess().getTiRequest().getVersionNumber()+"");
				msgDisplayInfoArray[j++]=msgDisplayInfo9;
				
				MailMsgDisplayInfo maiDisplaInfoDescription = new MailMsgDisplayInfo();
				maiDisplaInfoDescription.setLabel("Description");
				maiDisplaInfoDescription.setValue(mailVO.getTiProcess().getName());
				msgDisplayInfoArray[j++]=maiDisplaInfoDescription;
				
				
				MailMsgDisplayInfo msgDisplayInfo10 = new MailMsgDisplayInfo();
				msgDisplayInfo10.setLabel("Endpoint A Resource Type");
				msgDisplayInfo10.setValue(mailVO.getTiProcess().getEndPointAResType());
				msgDisplayInfoArray[j++]=msgDisplayInfo10;
				
				MailMsgDisplayInfo msgDisplayInfo11 = new MailMsgDisplayInfo();
				msgDisplayInfo11.setLabel("Endpoint B Resource Type");
				msgDisplayInfo11.setValue(mailVO.getTiProcess().getEndPointBResType());
				
				msgDisplayInfoArray[j++]=msgDisplayInfo11;
				
				MailMsgDisplayInfo msgDisplayInfo12 = new MailMsgDisplayInfo();
				msgDisplayInfo12.setLabel("Firewall Type");
				msgDisplayInfo12.setValue(mailVO.getTiProcess().getConnectionRequest().getFirewallType());
				msgDisplayInfoArray[j++]=msgDisplayInfo12;
				
				MailMsgDisplayInfo msgDisplayInfo13 = new MailMsgDisplayInfo();
				msgDisplayInfo13.setLabel("Firewall Region");
				msgDisplayInfo13.setValue(mailVO.getTiProcess().getConnectionRequest().getFirewallRegion());
				msgDisplayInfoArray[j++]=msgDisplayInfo13;
				
				MailMsgDisplayInfo msgDisplayInfo14 = new MailMsgDisplayInfo();
				msgDisplayInfo14.setLabel("High Risk");
				msgDisplayInfo14.setValue(mailVO.getTiProcess().getIsHighRisk());
				msgDisplayInfoArray[j++]=msgDisplayInfo14;
						
				MailMsgDisplayInfo msgDisplayInfo15 = new MailMsgDisplayInfo();
				msgDisplayInfo15.setLabel("Priority");
				msgDisplayInfo15.setValue(mailVO.getTiProcess().getTiRequest().getPriority().getValue1());
				msgDisplayInfoArray[j++]=msgDisplayInfo15;
				
				MailMsgDisplayInfo msgDisplayInfo16 = new MailMsgDisplayInfo();
				msgDisplayInfo16.setLabel("Requester");
				msgDisplayInfo16.setValue(mailVO.getTiProcess().getRequestor().getSoeID());
				msgDisplayInfoArray[j++]=msgDisplayInfo16;
				
				
				MailMsgDisplayInfo msgDisplayInfo17 = new MailMsgDisplayInfo();
				msgDisplayInfo17.setLabel("Requested Activation Date");
				msgDisplayInfo17.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getPlannedCompletionDate()));
				msgDisplayInfoArray[j++]=msgDisplayInfo17;
				
				MailMsgDisplayInfo msgDisplayInfo18 = new MailMsgDisplayInfo();
				msgDisplayInfo18.setLabel("Appsense Scheduled Date");
				msgDisplayInfo18.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getApsImpScheduledDate()));
				msgDisplayInfoArray[j++]=msgDisplayInfo18;
				
				
				MailMsgDisplayInfo msgDisplayInfo19 = new MailMsgDisplayInfo();
				msgDisplayInfo19.setLabel("Proxy Scheduled Date");
				msgDisplayInfo19.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getPrxImpScheduledDate()));
				msgDisplayInfoArray[j++]=msgDisplayInfo19;
				
				
				MailMsgDisplayInfo msgDisplayInfo20 = new MailMsgDisplayInfo();
				msgDisplayInfo20.setLabel("FW OPS Scheduled Date");
				msgDisplayInfo20.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getPrxImpScheduledDate()));
				msgDisplayInfoArray[j++]=msgDisplayInfo20;
				
				MailMsgDisplayInfo msgDisplayInfo21 = new MailMsgDisplayInfo();
				msgDisplayInfo21.setLabel("Expiration Date");
				msgDisplayInfo21.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getRequestDeadline()));
				msgDisplayInfoArray[j++]=msgDisplayInfo21;
				MailMsgDisplayInfo msgDisplayInfo22 = new MailMsgDisplayInfo();
				msgDisplayInfo22.setLabel("GNO Scheduled Date");
				msgDisplayInfo22.setValue(formatDate(mailVO.getTiProcess().getTiRequest().getGnccImpScheduledDate()));
				msgDisplayInfoArray[j++]=msgDisplayInfo22;
				MailMsgDisplayInfo msgDisplayInfo23 = new MailMsgDisplayInfo();
				msgDisplayInfo23.setLabel("System ID");
				msgDisplayInfo23.setValue(mailVO.getTiProcess().getTiRequest().getCmpId());
				msgDisplayInfoArray[j++]=msgDisplayInfo23;
				MailMsgDisplayInfo msgDisplayInfo24 = new MailMsgDisplayInfo();
				msgDisplayInfo24.setLabel("Role");
				msgDisplayInfo24.setValue(mailVO.getTiProcess().getTiRequest().getActivityData().getDisplayUserRole() +
						mailVO.getTiProcess().getTiRequest().getActivityData().getDisplayInfoUserRole());
				msgDisplayInfoArray[j++]=msgDisplayInfo24;
				
				
				
				
				MailMsgDisplayInfo msgDisplayInfo26 = new MailMsgDisplayInfo();
				msgDisplayInfo26.setLabel("Activity Description");
				msgDisplayInfo26.setValue(mailVO.getTiProcess().getTiRequest().getActivityData().getActivityName());
				msgDisplayInfoArray[j++]=msgDisplayInfo26;
				
				MailMsgDisplayInfo msgDisplayInfo27 = new MailMsgDisplayInfo();
				msgDisplayInfo27.setLabel("Last Submitted by");
				msgDisplayInfo27.setValue(mailVO.getLastSubmitterRole());
				msgDisplayInfoArray[j++]=msgDisplayInfo27;
				
				MailMsgDisplayInfo msgDisplayInfo28 = new MailMsgDisplayInfo();
				msgDisplayInfo28.setLabel("Comment");
				msgDisplayInfo28.setValue(mailVO.getLastSubmitterComments());
				msgDisplayInfoArray[j++]=msgDisplayInfo28;
				
				
				return msgDisplayInfoArray;
				
			}
			private String formatDate(Date inputDate){
				SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
				if(inputDate == null) 
					return "";
					return sdf.format(inputDate);
			}
			

	

}