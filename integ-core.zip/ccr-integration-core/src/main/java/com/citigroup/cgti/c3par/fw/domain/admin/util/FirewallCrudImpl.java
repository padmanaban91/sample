package com.citigroup.cgti.c3par.fw.domain.admin.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.fw.domain.Firewall;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;

public class FirewallCrudImpl implements FirewallCrud{
	
	private JdbcTemplate jdbcTemplate;
	private static Logger log = Logger.getLogger(FirewallCrudImpl.class);

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<Firewall> findFireWalls(String firewallName){
		String sql = "select id, policy_id, firewall_name, created_date, updated_date, ip_address, building_name, "
				+ "address, city, country, county, region, approver_groups, device_id, delete_flag, greenzone_start_time, "
				+ "greenzone_end_time, location_code, country_code, timezone,INVALID_APPROVER_GROUPS, updated_by,"
				+ "NETINFO_TYPE, CHGCABAPPROVER"
				+ " from c3par.CON_FIREWALL where firewall_name like '%"+
				firewallName +"%'";
		List<Firewall> firewalls = jdbcTemplate.query(sql,new RowMapper<Firewall>() {
            public Firewall mapRow(ResultSet rs, int rowNum) throws SQLException {
            	Firewall firewall = new Firewall();
            	firewall.setId(rs.getLong("id"));
            	FirewallPolicy fp = new FirewallPolicy();
            	fp.setId(rs.getLong("policy_id"));
            	firewall.setFirewallPolicy(fp);
                firewall.setFirewallName(rs.getString("firewall_name"));
                firewall.setCreated_date(rs.getTimestamp("created_date"));
                firewall.setUpdated_date(rs.getTimestamp("updated_date"));
                firewall.setLastUpdatedTimestamp(rs.getTimestamp("updated_date"));
                firewall.setIpAddress(rs.getString("ip_address"));
                firewall.setBuildingName(rs.getString("building_name"));
                firewall.setAddress(rs.getString("address"));
                firewall.setCity(rs.getString("city"));
                firewall.setCountry(rs.getString("country"));
                firewall.setCounty(rs.getString("county"));
                firewall.setRegion(rs.getString("region"));
                firewall.setApproverGroups(rs.getString("approver_groups"));
                firewall.setDeviceId(rs.getString("device_id"));
                firewall.setDeleteFlag(rs.getString("delete_flag"));
                firewall.setLocation(rs.getString("location_code"));
                firewall.setInvalidApproverGroups(rs.getString("INVALID_APPROVER_GROUPS"));
                firewall.setLastUpdatedBy(rs.getString("updated_by"));
                firewall.setNetInfoType(rs.getString("NETINFO_TYPE"));
                firewall.setChangeCABaApprover(rs.getString("CHGCABAPPROVER"));
                firewall.setGreenzoneStartTime(rs.getString("greenzone_start_time"));
                firewall.setGreenzoneEndTime(rs.getString("greenzone_end_time"));
                firewall.setTimezone(rs.getString("timezone"));
                
                return firewall;
            }
        });
		log.info("FirewallCrudUtil.findFireWalls():ends");
		return firewalls;
	}
	
	public void insertFirewall(Firewall firewall) throws DataAccessException, Exception{
		String sql = "insert into c3par.CON_FIREWALL(id, policy_id, firewall_name, created_date, updated_date, ip_address, building_name, "
				+ "address, city, county, country, region, approver_groups, device_id, greenzone_start_time, "
				+ "greenzone_end_time, location_code, country_code, timezone, dsmt_country_code, INVALID_APPROVER_GROUPS, updated_by,"
				+ "NETINFO_TYPE, CHGCABAPPROVER, delete_flag)"
				+ " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'N')";
		
		jdbcTemplate.update(sql, new Object[] {
				getSequenceNextVal("SEQ_CON_FIREWALL"),
				firewall.getFirewallPolicy().getId(),
				firewall.getFirewallName(),
				firewall.getCreated_date(),
				getCurrentTimeStamp(),
				firewall.getIpAddress(),
				firewall.getBuildingName(),
				firewall.getAddress(),
				firewall.getCity(),
				firewall.getCounty(),
				firewall.getCountry(),
				firewall.getRegion(),
				firewall.getApproverGroups(),
				firewall.getDeviceId(),
				firewall.getGreenzoneStartTime(),
				firewall.getGreenzoneEndTime(),
				firewall.getLocation(),
				firewall.getCountry(),
				firewall.getTimezone(),
				firewall.getCountry(),
				firewall.getInvalidApproverGroups(),
				firewall.getLastUpdatedBy(),
				firewall.getNetInfoType(),
				firewall.getChangeCABaApprover()
			});
		
		log.info("FirewallCrudUtil.findFireWalls():ends");
	}
	
	public void updateFirewall(Firewall firewall){
		String sql = "update c3par.CON_FIREWALL set "
				+ "policy_id=?, firewall_name=?, updated_date=?, ip_address=?, building_name=?, address=?,"+
				" city=?, county=?, country=?, region=?, approver_groups=?, INVALID_APPROVER_GROUPS=?, device_id=?,"
				+ "country_code=?, NETINFO_TYPE=?, GREENZONE_START_TIME=?, GREENZONE_END_TIME=?, "
				+ " LOCATION_CODE=?, CHGCABAPPROVER=?, TIMEZONE=?, updated_by=? where id=?";
		
		jdbcTemplate.update(sql, new Object[] {
				firewall.getFirewallPolicy().getId(),
				firewall.getFirewallName(),
				getCurrentTimeStamp(),
				firewall.getIpAddress(),
				firewall.getBuildingName(),
				firewall.getAddress(),
				firewall.getCity(),
				firewall.getCounty(),
				firewall.getCountry(),
				firewall.getRegion(),
				firewall.getApproverGroups(),
				firewall.getInvalidApproverGroups(),
				firewall.getDeviceId(),
				firewall.getCountry(),
				firewall.getNetInfoType(),
				firewall.getGreenzoneStartTime(),
				firewall.getGreenzoneEndTime(),
				firewall.getLocation(),
				firewall.getChangeCABaApprover(),
				firewall.getTimezone(),
				firewall.getLastUpdatedBy(),
				firewall.getId()
			});
	}
	
	public Map<Long, String> getFirewallPolicyMap(){
		
		String sql="select id, policy_name from c3par.con_fw_policy";
		@SuppressWarnings("unchecked")
		HashMap<Long, String> firewallPolicyMap = (HashMap<Long, String>) jdbcTemplate.query(sql, new ResultSetExtractor() {
	        public Object extractData(ResultSet rs) throws SQLException {
	        	Map<Long, String> map = new HashMap<Long, String>();
	            while (rs.next()) {
	                Long policyId = rs.getLong("id");
	                String policyName = rs.getString("policy_name");
	                map.put(policyId, policyName);
	            }
	            log.info("FirewallPolicyMap size = "+map.size());
	            return map;
	        };
	    });
		return sortByValues(firewallPolicyMap);
		
	}
	
	public static <K, V extends Comparable<V>> Map<K, V> sortByValues(final Map<K, V> map) {
	    Comparator<K> valueComparator =  new Comparator<K>() {
	        public int compare(K k1, K k2) {
	            int compare = map.get(k1).compareTo(map.get(k2));
	            if (compare == 0) return 1;
	            else return compare;
	        }
	    };
	    Map<K, V> sortedByValues = new TreeMap<K, V>(valueComparator);
	    sortedByValues.putAll(map);
	    return sortedByValues;
	}
	
	public void deleteFirewall(Firewall firewall){
		String sql = "update c3par.CON_FIREWALL set "
				+ " DELETE_FLAG='Y', updated_by=?, updated_date=? where id=?";
		
		jdbcTemplate.update(sql, new Object[] {
				firewall.getLastUpdatedBy(),
				getCurrentTimeStamp(),
				firewall.getId()
		});
	}
	
	private static java.sql.Timestamp getCurrentTimeStamp() {

		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());

	}
	public void updateFirewall(){
		
	}
	
	 /**
	   * Gets the sequence next val.
	   *
	   * @param dbSequenceName the db sequence name
	   * @param c3parSession the c3par session
	   * @return the sequence next val
	   * @throws Exception the exception
	   */
	  private  long getSequenceNextVal(String dbSequenceName) throws Exception {
	 	 
		long id = 0;

		if (dbSequenceName != null) {
		 
			try {
				SqlRowSet rs =  jdbcTemplate.queryForRowSet("Select " + dbSequenceName + ".nextval from dual");
			if (rs.next()) {
			    id = rs.getLong(1);
			}
			} catch (Exception xe) {}
		}
		return id;
	  }
	
}
