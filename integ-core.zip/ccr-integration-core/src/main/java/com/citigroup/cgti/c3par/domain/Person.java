package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;


/**
 * The Class Person.
 */
public class Person extends Base implements Serializable{
    //Changed from Employee to E
    /** The Constant EMPLOYEE. */
    public static final String EMPLOYEE="E";

    /** The first name. */
    private String firstName;

    /** The last name. */
    private String lastName;

    /** The email address. */
    private String emailAddress;

    /** The region. */
    private String region;

    /** The department. */
    private String department;

    /** The telephone. */
    private String telephone;

    /** The address. */
    private Address address;

    /** The soe id. */
    private String soeID;

    /** The full name. */
    private String fullName;

    /** The geid. */
    private String geid; 

    /** The role. */
    private Role role = new Role();

    /** The citi employee. */
    private boolean citiEmployee;

    /** The contact id. */
    private Long contactID;
    
   
    /** The selected. */
    private boolean selected = false;

    private String systemGenerated;
    
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#isSelected()
     */
    public boolean isSelected() {
	return selected;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#setSelected(boolean)
     */
    public void setSelected(boolean selected) {
	this.selected = selected;
    }

    /**
     * Gets the contact id.
     *
     * @return the contact id
     */
    public Long getContactID() {
	return contactID;
    }

    /**
     * Sets the contact id.
     *
     * @param contactID the new contact id
     */
    public void setContactID(Long contactID) {
	this.contactID = contactID;
    }

    /**
     * Checks if is citi employee.
     *
     * @return true, if is citi employee
     */
    public boolean isCitiEmployee() {
	return citiEmployee;
    }

    /**
     * Sets the citi employee.
     *
     * @param citiEmployee the new citi employee
     */
    public void setCitiEmployee(boolean citiEmployee) {
	this.citiEmployee = citiEmployee;
    }

    /**
     * Gets the role.
     *
     * @return the role
     */
    public Role getRole() {
	return role;
    }

    /**
     * Sets the role.
     *
     * @param role the new role
     */
    public void setRole(Role role) {
	this.role = role;
    }

    /**
     * Gets the soe id.
     *
     * @return the soe id
     */
    public String getSoeID() {
	return soeID;
    }

    /**
     * Sets the soe id.
     *
     * @param soeID the new soe id
     */
    public void setSoeID(String soeID) {
	this.soeID = soeID;
    }

    /**
     * Gets the department.
     *
     * @return the department
     */
    public String getDepartment() {
	return department;
    }

    /**
     * Sets the department.
     *
     * @param department the new department
     */
    public void setDepartment(String department) {
	this.department = department;
    }

    /**
     * Gets the email address.
     *
     * @return the email address
     */
    public String getEmailAddress() {
	return emailAddress;
    }

    /**
     * Sets the email address.
     *
     * @param emailAddress the new email address
     */
    public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
    }

    /**
     * Gets the first name.
     *
     * @return the first name
     */
    public String getFirstName() {
	return firstName;
    }

    /**
     * Sets the first name.
     *
     * @param firstName the new first name
     */
    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    /**
     * Gets the last name.
     *
     * @return the last name
     */
    public String getLastName() {
	return lastName;
    }

    /**
     * Sets the last name.
     *
     * @param lastName the new last name
     */
    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    /**
     * Gets the region.
     *
     * @return the region
     */
    public String getRegion() {
	return region;
    }

    /**
     * Sets the region.
     *
     * @param region the new region
     */
    public void setRegion(String region) {
	this.region = region;
    }

    /**
     * Gets the telephone.
     *
     * @return the telephone
     */
    public String getTelephone() {
	return telephone;
    }

    /**
     * Sets the telephone.
     *
     * @param telephone the new telephone
     */
    public void setTelephone(String telephone) {
	this.telephone = telephone;
    }

    /**
     * Gets the address.
     *
     * @return the address
     */
    public Address getAddress() {
	return address;
    }

    /**
     * Sets the address.
     *
     * @param address the new address
     */
    public void setAddress(Address address) {
	this.address = address;
    }

    /**
     * Gets the full name.
     *
     * @return the full name
     */
    public String getFullName() {
	return fullName;
    }

    /**
     * Sets the full name.
     *
     * @param fullName the new full name
     */
    public void setFullName(String fullName) {
	this.fullName = fullName;
    }

    /**
     * Gets the geid.
     *
     * @return the geid
     */
    public String getGeid() {
	return geid;
    }

    /**
     * Sets the geid.
     *
     * @param geid the new geid
     */
    public void setGeid(String geid) {
	this.geid = geid;
    }

	public String getSystemGenerated() {
		return systemGenerated;
	}

	public void setSystemGenerated(String systemGenerated) {
		this.systemGenerated = systemGenerated;
	}

	

}
