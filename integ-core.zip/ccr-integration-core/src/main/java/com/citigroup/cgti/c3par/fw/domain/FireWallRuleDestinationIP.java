/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

/**
 * @author bs45969
 *
 */
public class FireWallRuleDestinationIP extends FireWallRuleIP {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
  //UI Level Attributes and Flags
    private boolean isDeleted;

    public FireWallRuleDestinationIP() {
	setCreated_date(new Date());
    }

	/**
	 * @return the isDeleted
	 */
	public boolean isDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
    
    

}
