package com.citigroup.cgti.c3par.businessjustification.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;


/**
 * The Class ConReqCitiContactXref.
 */
public class ConReqTPContactXref extends Base{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Role role;
	private Planning planning;
	private ThirdPartyContact thirdPartyContact;
	
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public Planning getPlanning() {
		return planning;
	}
	public void setPlanning(Planning planning) {
		this.planning = planning;
	}
	public ThirdPartyContact getThirdPartyContact() {
		return thirdPartyContact;
	}
	public void setThirdPartyContact(ThirdPartyContact thirdPartyContact) {
		this.thirdPartyContact = thirdPartyContact;
	}
	
	
	
}
