package com.citigroup.cgti.c3par.common.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.fw.domain.PortServiceMapping;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface PortServiceTypePersistable  extends Persistable{

	List getConnections(Long actualPortId) throws Exception;

	PortServiceMapping existPortServiceMapping(Long portId) throws Exception;

	void insertPortServiceMapping(PortServiceMapping portServiceMapping) throws Exception;

	List<PortServiceMapping> findByPortId(String searchService) throws Exception;

	List<PortServiceMapping> findByServiceType(String searchService) throws Exception;

	PortServiceMapping getPortServiceMapping(String iD) throws Exception;

	void updatePortServiceMapping(PortServiceMapping portServiceMapping) throws Exception;

	void deletePortServiceMapping(PortServiceMapping deletePortServiceMapping) throws Exception;

}
