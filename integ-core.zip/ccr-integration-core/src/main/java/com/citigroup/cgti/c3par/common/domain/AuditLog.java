/**
 *
 */
package com.citigroup.cgti.c3par.common.domain;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author nc43495
 * 
 */
public class AuditLog extends Base{
	@Autowired
	private CommonServicePersistable commonServicePersistable;

	/** The log. */
	private static Logger log = Logger.getLogger(AuditLog.class);
	
	/** The Audit Log id */
	private Long id;
	
	/** The user soeID */
	private String soeID;
	
	/** The action */
	private String action;
	
	/** The Old value */
	private String oldValue;
	
	/** The New value */
	private String newValue;
	
	/** The Object name */
	private String objectName;
	
	/** The Object Attribute */
	private String objectAttribute;
	
	/** The is Reference */
	private String isReference;
	
	/** Ti request table */
	private TIRequest tiRequest;
	
	private AuditObjectType newAuditObjectType;
	
	private AuditObjectType oldAuditObjectType;
	
	private String oldDisplayValue;
	
	private String newDisplayValue;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSoeID() {
		return soeID;
	}

	public void setSoeID(String soeID) {
		this.soeID = soeID;
	}

	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getObjectAttribute() {
		return objectAttribute;
	}

	public void setObjectAttribute(String objectAttribute) {
		this.objectAttribute = objectAttribute;
	}

	public String getIsReference() {
		return isReference;
	}

	public void setIsReference(String isReference) {
		this.isReference = isReference;
	}


	public TIRequest getTiRequest() {
		return tiRequest;
	}

	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the oldDisplayValue
	 */
	public String getOldDisplayValue() {
		return oldDisplayValue;
	}

	/**
	 * @param oldDisplayValue the oldDisplayValue to set
	 */
	public void setOldDisplayValue(String oldDisplayValue) {
		this.oldDisplayValue = oldDisplayValue;
	}

	/**
	 * @return the newDisplayValue
	 */
	public String getNewDisplayValue() {
		return newDisplayValue;
	}

	/**
	 * @param newDisplayValue the newDisplayValue to set
	 */
	public void setNewDisplayValue(String newDisplayValue) {
		this.newDisplayValue = newDisplayValue;
	}

	/**
	 * @return the newAuditObjectType
	 */
	public AuditObjectType getNewAuditObjectType() {
		return newAuditObjectType;
	}

	/**
	 * @param newAuditObjectType the newAuditObjectType to set
	 */
	public void setNewAuditObjectType(AuditObjectType newAuditObjectType) {
		this.newAuditObjectType = newAuditObjectType;
	}

	/**
	 * @return the oldAuditObjectType
	 */
	public AuditObjectType getOldAuditObjectType() {
		return oldAuditObjectType;
	}

	/**
	 * @param oldAuditObjectType the oldAuditObjectType to set
	 */
	public void setOldAuditObjectType(AuditObjectType oldAuditObjectType) {
		this.oldAuditObjectType = oldAuditObjectType;
	}

}
