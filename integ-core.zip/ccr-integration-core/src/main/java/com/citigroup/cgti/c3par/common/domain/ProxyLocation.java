package com.citigroup.cgti.c3par.common.domain;

import com.citigroup.cgti.c3par.domain.Base;

public class ProxyLocation extends Base {

private static final long serialVersionUID = 1L;

private String location;

private String rfcLocationCode;

/**
 * @return the location
 */
public String getLocation() {
	return location;
}

/**
 * @param location the location to set
 */
public void setLocation(String location) {
	this.location = location;
}

/**
 * @return the rfcLocationCode
 */
public String getRfcLocationCode() {
	return rfcLocationCode;
}

/**
 * @param rfcLocationCode the rfcLocationCode to set
 */
public void setRfcLocationCode(String rfcLocationCode) {
	this.rfcLocationCode = rfcLocationCode;
}

}
