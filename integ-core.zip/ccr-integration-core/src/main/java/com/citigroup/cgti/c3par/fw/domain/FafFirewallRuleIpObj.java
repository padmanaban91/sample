/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * @author gs71854
 *
 */
public class FafFirewallRuleIpObj extends Base {
	
    /**
     * 
     */
	public static final String YES="Y";
	public static final String NO="N";
    private static final long serialVersionUID = 1L;
    private FafFirewallRuleSuggestion implFafFirewallRule;
    private IPAddressObj ipAddress;
    private String NAT;
    private String currentValueFlag=NO;
    /**
     * @return the fafFireWallRule
     */
    public FafFirewallRuleSuggestion getImplFafFirewallRule() {
        return implFafFirewallRule;
    }
    /**
     * @param fafFireWallRule the fafFireWallRule to set
     */
    public void setImplFafFirewallRule(FafFirewallRuleSuggestion implFafFirewallRule) {
        this.implFafFirewallRule = implFafFirewallRule;
    }
    /**
     * @return the ipAddress
     */
    public IPAddressObj getIpAddress() {
        return ipAddress;
    }
    /**
     * @param ipAddress the ipAddress to set
     */
    public void setIpAddress(IPAddressObj ipAddress) {
        this.ipAddress = ipAddress;
    }
    /**
     * @return the nAT
     */
    public String getNAT() {
        return NAT;
    }
    /**
     * @param nAT the nAT to set
     */
    public void setNAT(String nAT) {
        NAT = nAT;
    }
    
    @Override
    public String toString(){
    	return ipAddress.toString();
    }
	/**
	 * @return the currentValueFlag
	 */
	public String getCurrentValueFlag() {
		return currentValueFlag;
	}
	/**
	 * @param currentValueFlag the currentValueFlag to set
	 */
	public void setCurrentValueFlag(String currentValueFlag) {
		this.currentValueFlag = currentValueFlag;
	}



}
