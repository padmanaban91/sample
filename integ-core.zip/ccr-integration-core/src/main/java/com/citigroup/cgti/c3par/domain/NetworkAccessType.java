package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

/**
 * The Class NetworkAccessType.
 */
public class NetworkAccessType extends Name implements Serializable{

}
