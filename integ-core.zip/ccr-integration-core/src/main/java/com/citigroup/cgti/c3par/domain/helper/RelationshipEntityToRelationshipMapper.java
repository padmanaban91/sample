package com.citigroup.cgti.c3par.domain.helper;

import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.domain.Relationship;
import com.citigroup.cgti.c3par.domain.ThirdParty;
import com.citigroup.cgti.c3par.model.RelationshipEntity;



/*
 * CONFIDENTIAL  AND PROPRIETARY
 */

/**
 * The Class RelationshipEntityToRelationshipMapper.
 */
public class RelationshipEntityToRelationshipMapper
{

    /**
     * Transform to relationship for search.
     *
     * @param relationshipEntity the relationship entity
     * @param relationship the relationship
     */
    public static void transformToRelationshipForSearch(RelationshipEntity relationshipEntity,
	    RelationshipDTO relationship)
    {
	relationship.setId(relationshipEntity.getId());
	relationship.setName(relationshipEntity.getName());
	ThirdParty thirdParty = null;
	if(relationshipEntity.getThirdParty()!=null){
	    thirdParty = new ThirdParty();
	    ThirdPartyEntityToThirdPartyMapper.transformToThirdParty(relationshipEntity.getThirdParty(),thirdParty);
	}

	//relationship.setThirdparty(thirdParty);
	relationship.setType(relationshipEntity.getRelationshipType());
	relationship.setRequestorSOEId(relationshipEntity.getRequesterId());
	relationship.setStatus(relationshipEntity.getStatus());

	// Set Requester Resource type id
	relationship.setEndPointAResTypeId(relationshipEntity.getRequesterResourceTypeId());

	// Set Target Resource type id
	relationship.setEndPointBResTypeId(relationshipEntity.getTargetResourceTypeId());			
    }
}