	package com.citigroup.cgti.c3par.domain;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * The Class IpPair.
 */
public class IpPair implements Serializable {

    /** The source ip list. */
    private List sourceIpList = new ArrayList();

    /** The destination ip list. */
    private List destinationIpList = new ArrayList();

    /** The port list. */
    private List portList = new ArrayList();

    /** The source key. */
    private String sourceKey;

    /** The destination key. */
    private String destinationKey;

    /** The source type. */
    private String sourceType;

    /** The destination type. */
    private String destinationType;

    /** The port. */
    private String port;

    /** The oldport. */
    private String oldport;

    /** The id. */
    private Long id;
    
     /** The ostia. */
    private String ostia;

    /**
     * 
     */
    private String fromZone;
    
    /**
     * 
     */
    private String toZone;
    
    /**
     * Gets the destination ip list.
     *
     * @return the destination ip list
     */
    public List getDestinationIpList() {
	return destinationIpList;
    }

    /**
     * Sets the destination ip list.
     *
     * @param destinationIpList the new destination ip list
     */
    public void setDestinationIpList(List destinationIpList) {
	this.destinationIpList = destinationIpList;
    }

    /**
     * Gets the destination key.
     *
     * @return the destination key
     */
    public String getDestinationKey() {
	return destinationKey;
    }

    /**
     * Sets the destination key.
     *
     * @param destinationKey the new destination key
     */
    public void setDestinationKey(String destinationKey) {
	this.destinationKey = destinationKey;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
	return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
	this.id = id;
    }

    /**
     * Gets the port list.
     *
     * @return the port list
     */
    public List getPortList() {
	return portList;
    }

    /**
     * Sets the port list.
     *
     * @param portList the new port list
     */
    public void setPortList(List portList) {
	this.portList = portList;
    }

    /**
     * Gets the source ip list.
     *
     * @return the source ip list
     */
    public List getSourceIpList() {
	return sourceIpList;
    }

    /**
     * Sets the source ip list.
     *
     * @param sourceIpList the new source ip list
     */
    public void setSourceIpList(List sourceIpList) {
	this.sourceIpList = sourceIpList;
    }

    /**
     * Gets the source key.
     *
     * @return the source key
     */
    public String getSourceKey() {
	return sourceKey;
    }

    /**
     * Sets the source key.
     *
     * @param sourceKey the new source key
     */
    public void setSourceKey(String sourceKey) {
	this.sourceKey = sourceKey;
    }

    /**
     * Gets the destination type.
     *
     * @return the destination type
     */
    public String getDestinationType() {
	return destinationType;
    }

    /**
     * Sets the destination type.
     *
     * @param destinationType the new destination type
     */
    public void setDestinationType(String destinationType) {
	this.destinationType = destinationType;
    }

    /**
     * Gets the source type.
     *
     * @return the source type
     */
    public String getSourceType() {
	return sourceType;
    }

    /**
     * Sets the source type.
     *
     * @param sourceType the new source type
     */
    public void setSourceType(String sourceType) {
	this.sourceType = sourceType;
    }

    /**
     * Gets the port.
     *
     * @return the port
     */
    public String getPort() {
	return port;
    }

    /**
     * Sets the port.
     *
     * @param port the new port
     */
    public void setPort(String port) {
	this.port = port;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#clone()
     */
    public Object clone(){

	try {
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    ObjectOutputStream oos = new ObjectOutputStream(baos);
	    oos.writeObject(this);
	    ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
	    ObjectInputStream ois = new ObjectInputStream(bais);
	    Object deepCopy = ois.readObject();
	    return deepCopy;
	} catch (Exception e) {
	    // TODO Auto-generated catch block
	    throw new RuntimeException (e);
	} 
    }

    /**
     * Gets the oldport.
     *
     * @return the oldport
     */
    public String getOldport() {
	return oldport;
    }

    /**
     * Sets the oldport.
     *
     * @param oldport the new oldport
     */
    public void setOldport(String oldport) {
	this.oldport = oldport;
    }

	/**
	 * @return the fromZone
	 */
	public String getFromZone() {
		return fromZone;
	}

	/**
	 * @param fromZone the fromZone to set
	 */
	public void setFromZone(String fromZone) {
		this.fromZone = fromZone;
	}

	/**
	 * @return the toZone
	 */
	public String getToZone() {
		return toZone;
	}

	/**
	 * @param toZone the toZone to set
	 */
	public void setToZone(String toZone) {
		this.toZone = toZone;
	}
    /**
	 * Gets the ostia.
	 *
	 * @return the ostia
	 */
	public String getOstia() {
		return ostia;
	}

	public void setOstia(String ostia) {
		this.ostia = ostia;
	}
    
}
