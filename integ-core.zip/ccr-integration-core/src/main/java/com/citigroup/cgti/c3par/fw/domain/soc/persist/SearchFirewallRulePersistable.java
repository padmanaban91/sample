package com.citigroup.cgti.c3par.fw.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.fw.domain.IPRegACL;
import com.citigroup.cgti.c3par.fw.domain.PersonalObject;
import com.citigroup.cgti.c3par.fw.domain.SearchFirewallRuleRequest;


public interface SearchFirewallRulePersistable extends FirewallRuleProcessPersistable {

	List<PersonalObject> listPersonalObjectIPs(SearchFirewallRuleRequest searchFirewallRuleRequest);
	
	List<PersonalObject> listPersonalObjectPorts(SearchFirewallRuleRequest searchFirewallRuleRequest);
	
	void savePersonalObjects(SearchFirewallRuleRequest searchFirewallRuleRequest);
	
	void savePersonalObjectsPort(SearchFirewallRuleRequest searchFirewallRuleRequest);
	
	PersonalObject findPersonalObject(SearchFirewallRuleRequest searchFirewallRuleRequest);
	
	PersonalObject validatePersonalObject(PersonalObject personalObject);
	
	PersonalObject validatePersonalObjectPort(PersonalObject personalObject);
	
	List<IPRegACL> getIpRegACL(SearchFirewallRuleRequest fwRuleProcess);
}
