package com.citigroup.cgti.c3par.connection.domain;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class PortServiceMapping.
 */
public class PortServiceMapping extends PerformerPagerDO {

    /** The port id. */
    private Long portId;

    /** The service type. */
    private String serviceType;

    /** The description. */
    private String description;

    /**
     * Instantiates a new port service mapping.
     */
    public PortServiceMapping() {
	//		---------------------
	setTableName(PerformerTypes.PORT_SERVICE_MAPPING);
	setSequenceName("");
	//---------------------
	addToDBMapping("portId","port_id",1);
	addToDBMapping("serviceType","service_type",2);
	addToDBMapping("description","description",3);

    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
	return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
	this.description = description;
    }

    /**
     * Gets the port id.
     *
     * @return the port id
     */
    public Long getPortId() {
	return portId;
    }

    /**
     * Sets the port id.
     *
     * @param portId the new port id
     */
    public void setPortId(Long portId) {
	this.portId = portId;
    }

    /**
     * Gets the service type.
     *
     * @return the service type
     */
    public String getServiceType() {
	return serviceType;
    }

    /**
     * Sets the service type.
     *
     * @param serviceType the new service type
     */
    public void setServiceType(String serviceType) {
	this.serviceType = serviceType;
    }
}
