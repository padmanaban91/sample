/**
 * 
 */
package com.citigroup.cgti.c3par.businessjustification.domain.soc.persist;

import com.citigroup.cgti.c3par.persistance.Persistable;

public interface AAFReviewServicePersistable extends Persistable {
	
	public Long getPlanningIdForTiRequestId(Long tirequestid);

}
