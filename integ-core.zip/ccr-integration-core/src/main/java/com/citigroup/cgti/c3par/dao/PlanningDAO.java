


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = PlanningDAO
// Table name = PLANNING
// Superclass = ConnectionRequest
// Subclasses = <none>

/**
 * The Class PlanningDAO.
 */
public class PlanningDAO
extends ConnectionRequestExtDAO
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "PLANNING";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(PlanningDAO.class);

    // No ID since it was generate on our superclass 'ConnectionRequest'

    // Column names
    /** The Constant COLUMN_PLANNEDACTIVATEDATE. */
    public static final String	COLUMN_PLANNEDACTIVATEDATE = "PLANNED_ACTIVATE_DATE";

    /** The Constant COLUMN_SECURITYREVIEWCOMMENT. */
    public static final String	COLUMN_SECURITYREVIEWCOMMENT = "SECURITY_REVIEW_COMMENT";

    /** The Constant COLUMN_SECURITYREVIEWCOMMENT_LEN. */
    public static final int		COLUMN_SECURITYREVIEWCOMMENT_LEN = 4000;

    /** The Constant COLUMN_SPONSORREVIEWCOMMENTS. */
    public static final String	COLUMN_SPONSORREVIEWCOMMENTS = "SPONSOR_REVIEW_COMMENTS";

    /** The Constant COLUMN_SPONSORREVIEWCOMMENTS_LEN. */
    public static final int		COLUMN_SPONSORREVIEWCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_ACTIVATECONNECTIONCOMMENT. */
    public static final String	COLUMN_ACTIVATECONNECTIONCOMMENT = "ACTIVATE_CONNECTION_COMMENT";

    /** The Constant COLUMN_ACTIVATECONNECTIONCOMMENT_LEN. */
    public static final int		COLUMN_ACTIVATECONNECTIONCOMMENT_LEN = 4000;

    /** The Constant COLUMN_APPROVEDETAILDESIGNCOMMENT. */
    public static final String	COLUMN_APPROVEDETAILDESIGNCOMMENT = "APPROVE_DETAIL_DESIGN_COMMENT";

    /** The Constant COLUMN_APPROVEDETAILDESIGNCOMMENT_LEN. */
    public static final int		COLUMN_APPROVEDETAILDESIGNCOMMENT_LEN = 4000;

    /** The Constant COLUMN_INTEGRATIONCOMPLETED. */
    public static final String	COLUMN_INTEGRATIONCOMPLETED = "INTEGRATION_COMPLETED";

    /** The Constant COLUMN_INTEGRATIONSTATUSCOMMENTS. */
    public static final String	COLUMN_INTEGRATIONSTATUSCOMMENTS = "INTEGRATION_STATUS_COMMENTS";

    /** The Constant COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN. */
    public static final int		COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_PROCUREMENTDATE. */
    public static final String	COLUMN_PROCUREMENTDATE = "PROCUREMENT_DATE";

    /** The Constant COLUMN_PROCUREMENTCOMMENTS. */
    public static final String	COLUMN_PROCUREMENTCOMMENTS = "PROCUREMENT_COMMENTS";

    /** The Constant COLUMN_PROCUREMENTCOMMENTS_LEN. */
    public static final int		COLUMN_PROCUREMENTCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_PROCUREMENTOPTIONAL. */
    public static final String	COLUMN_PROCUREMENTOPTIONAL = "PROCUREMENT_OPTIONAL";

    /** The Constant COLUMN_SYSTEMADMINCOMMENTS. */
    public static final String	COLUMN_SYSTEMADMINCOMMENTS = "SYSTEM_ADMIN_COMMENTS";

    /** The Constant COLUMN_SYSTEMADMINCOMMENTS_LEN. */
    public static final int		COLUMN_SYSTEMADMINCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_OPERATIONALANALYSTCOMMENTS. */
    public static final String	COLUMN_OPERATIONALANALYSTCOMMENTS = "OPERATIONAL_ANALYST_COMMENTS";

    /** The Constant COLUMN_OPERATIONALANALYSTCOMMENTS_LEN. */
    public static final int		COLUMN_OPERATIONALANALYSTCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_ISTGCOMMENTS. */
    public static final String	COLUMN_ISTGCOMMENTS = "ISTG_COMMENTS";

    /** The Constant COLUMN_ISTGCOMMENTS_LEN. */
    public static final int		COLUMN_ISTGCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_INFOMANID. */
    public static final String	COLUMN_INFOMANID = "INFOMAN_ID";

    /** The Constant COLUMN_OPANALYSTSCHEDULEDATE. */
    public static final String	COLUMN_OPANALYSTSCHEDULEDATE = "OP_ANALYST_SCHEDULE_DATE";

    /** The Constant COLUMN_OPANALYSTCOMPLETEDDATE. */
    public static final String	COLUMN_OPANALYSTCOMPLETEDDATE = "OP_ANALYST_COMPLETED_DATE";

    /** The Constant COLUMN_VAFLAG. */
    public static final String	COLUMN_VAFLAG = "VA_FLAG";

    /** The Constant COLUMN_VAFLAG_LEN. */
    public static final int		COLUMN_VAFLAG_LEN = 3;

    /** The Constant COLUMN_VANUMBER. */
    public static final String	COLUMN_VANUMBER = "VA_NUMBER";

    /** The Constant COLUMN_VANUMBER_LEN. */
    public static final int		COLUMN_VANUMBER_LEN = 20;

    /** The Constant COLUMN_VASCHDATE. */
    public static final String	COLUMN_VASCHDATE = "VA_SCH_DATE";

    /** The Constant COLUMN_VACOMMENTS. */
    public static final String	COLUMN_VACOMMENTS = "VA_COMMENTS";

    /** The Constant COLUMN_VACOMMENTS_LEN. */
    public static final int		COLUMN_VACOMMENTS_LEN = 2000;
    // Column names of references

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + PlanningDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_PLANNEDACTIVATEDATE
    + ", " + COLUMN_SECURITYREVIEWCOMMENT
    + ", " + COLUMN_SPONSORREVIEWCOMMENTS
    + ", " + COLUMN_ACTIVATECONNECTIONCOMMENT
    + ", " + COLUMN_APPROVEDETAILDESIGNCOMMENT
    + ", " + COLUMN_INTEGRATIONCOMPLETED
    + ", " + COLUMN_INTEGRATIONSTATUSCOMMENTS
    + ", " + COLUMN_PROCUREMENTDATE
    + ", " + COLUMN_PROCUREMENTCOMMENTS
    + ", " + COLUMN_PROCUREMENTOPTIONAL
    + ", " + COLUMN_SYSTEMADMINCOMMENTS
    + ", " + COLUMN_OPERATIONALANALYSTCOMMENTS
    + ", " + COLUMN_ISTGCOMMENTS
    + ", " + COLUMN_INFOMANID
    + ", " + COLUMN_OPANALYSTSCHEDULEDATE
    + ", " + COLUMN_OPANALYSTCOMPLETEDDATE
    + ", " + COLUMN_VAFLAG
    + ", " + COLUMN_VANUMBER
    + ", " + COLUMN_VASCHDATE
    + ", " + COLUMN_VACOMMENTS
    + " FROM " + PlanningDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = PlanningDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + PlanningDAO.TABLE + " SET "
    + COLUMN_PLANNEDACTIVATEDATE + " = ? "
    + ", " + COLUMN_SECURITYREVIEWCOMMENT + " = ? "
    + ", " + COLUMN_SPONSORREVIEWCOMMENTS + " = ? "
    + ", " + COLUMN_ACTIVATECONNECTIONCOMMENT + " = ? "
    + ", " + COLUMN_APPROVEDETAILDESIGNCOMMENT + " = ? "
    + ", " + COLUMN_INTEGRATIONCOMPLETED + " = ? "
    + ", " + COLUMN_INTEGRATIONSTATUSCOMMENTS + " = ? "
    + ", " + COLUMN_PROCUREMENTDATE + " = ? "
    + ", " + COLUMN_PROCUREMENTCOMMENTS + " = ? "
    + ", " + COLUMN_PROCUREMENTOPTIONAL + " = ? "
    + ", " + COLUMN_SYSTEMADMINCOMMENTS + " = ? "
    + ", " + COLUMN_OPERATIONALANALYSTCOMMENTS + " = ? "
    + ", " + COLUMN_ISTGCOMMENTS + " = ? "
    + ", " + COLUMN_INFOMANID + " = ? "
    + ", " + COLUMN_OPANALYSTSCHEDULEDATE + " = ? "
    + ", " + COLUMN_OPANALYSTCOMPLETEDDATE + " = ? "
    + ", " + COLUMN_VAFLAG + " = ? "
    + ", " + COLUMN_VANUMBER + " = ? "
    + ", " + COLUMN_VASCHDATE + " = ? "
    + ", " + COLUMN_VACOMMENTS + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + PlanningDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_PLANNEDACTIVATEDATE 
    + ", " + COLUMN_SECURITYREVIEWCOMMENT 
    + ", " + COLUMN_SPONSORREVIEWCOMMENTS 
    + ", " + COLUMN_ACTIVATECONNECTIONCOMMENT 
    + ", " + COLUMN_APPROVEDETAILDESIGNCOMMENT 
    + ", " + COLUMN_INTEGRATIONCOMPLETED 
    + ", " + COLUMN_INTEGRATIONSTATUSCOMMENTS 
    + ", " + COLUMN_PROCUREMENTDATE 
    + ", " + COLUMN_PROCUREMENTCOMMENTS 
    + ", " + COLUMN_PROCUREMENTOPTIONAL 
    + ", " + COLUMN_SYSTEMADMINCOMMENTS 
    + ", " + COLUMN_OPERATIONALANALYSTCOMMENTS 
    + ", " + COLUMN_ISTGCOMMENTS 
    + ", " + COLUMN_INFOMANID 
    + ", " + COLUMN_OPANALYSTSCHEDULEDATE 
    + ", " + COLUMN_OPANALYSTCOMPLETEDDATE 
    + ", " + COLUMN_VAFLAG 
    + ", " + COLUMN_VANUMBER 
    + ", " + COLUMN_VASCHDATE 
    + ", " + COLUMN_VACOMMENTS 
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + PlanningDAO.TABLE + " WHERE ID = ?";




    // Contructors
    //======================================================================
    /**
     * Instantiates a new planning dao.
     *
     * @param session the session
     */
    public PlanningDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating PlanningDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.dao.ConnectionRequestDAO#setCustomSequence(java.lang.String)
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.dao.ConnectionRequestDAO#setDatabaseSequence(java.lang.String)
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insertPlanningPart(PlanningEntity entity) throws DatabaseException
    {
	log.debug("Inserting PlanningEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + PlanningDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setDateToStatement(st, position, entity.getPlannedActivateDate());
	    position = setStringToStatement(st, position, entity.getSecurityReviewComment(), COLUMN_SECURITYREVIEWCOMMENT_LEN);
	    position = setStringToStatement(st, position, entity.getSponsorReviewComments(), COLUMN_SPONSORREVIEWCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getActivateConnectionComment(), COLUMN_ACTIVATECONNECTIONCOMMENT_LEN);
	    position = setStringToStatement(st, position, entity.getApproveDetailDesignComment(), COLUMN_APPROVEDETAILDESIGNCOMMENT_LEN);
	    position = setBooleanToStatement(st, position, entity.getIntegrationCompleted());
	    position = setStringToStatement(st, position, entity.getIntegrationStatusComments(), COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN);
	    position = setDateToStatement(st, position, entity.getProcurementDate());
	    position = setStringToStatement(st, position, entity.getProcurementComments(), COLUMN_PROCUREMENTCOMMENTS_LEN);
	    position = setBooleanToStatement(st, position, entity.getProcurementOptional());
	    position = setStringToStatement(st, position, entity.getSystemAdminComments(), COLUMN_SYSTEMADMINCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getOperationalAnalystComments(), COLUMN_OPERATIONALANALYSTCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getIstgComments(), COLUMN_ISTGCOMMENTS_LEN);
	    position = setLongToStatement(st, position, entity.getInfomanId());
	    position = setDateToStatement(st, position, entity.getOpAnalystScheduleDate());
	    position = setDateToStatement(st, position, entity.getOpAnalystCompletedDate());
	    position = setStringToStatement(st, position, entity.getVaFlag(), COLUMN_VAFLAG_LEN);
	    position = setStringToStatement(st, position, entity.getVaNumber(), COLUMN_VANUMBER_LEN);
	    position = setDateToStatement(st, position, entity.getVaSchDate());
	    position = setStringToStatement(st, position, entity.getVaComments(), COLUMN_VACOMMENTS_LEN);

	    // Association references
	    position = updatePlanningReferences(st, entity, position);

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + PlanningDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }


    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long updatePlanningPart(PlanningEntity entity) throws DatabaseException
    {
	log.debug("Updating PlanningEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + PlanningDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setDateToStatement(st, position, entity.getPlannedActivateDate());
	    position = setStringToStatement(st, position, entity.getSecurityReviewComment(), COLUMN_SECURITYREVIEWCOMMENT_LEN);
	    position = setStringToStatement(st, position, entity.getSponsorReviewComments(), COLUMN_SPONSORREVIEWCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getActivateConnectionComment(), COLUMN_ACTIVATECONNECTIONCOMMENT_LEN);
	    position = setStringToStatement(st, position, entity.getApproveDetailDesignComment(), COLUMN_APPROVEDETAILDESIGNCOMMENT_LEN);
	    position = setBooleanToStatement(st, position, entity.getIntegrationCompleted());
	    position = setStringToStatement(st, position, entity.getIntegrationStatusComments(), COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN);
	    position = setDateToStatement(st, position, entity.getProcurementDate());
	    position = setStringToStatement(st, position, entity.getProcurementComments(), COLUMN_PROCUREMENTCOMMENTS_LEN);
	    position = setBooleanToStatement(st, position, entity.getProcurementOptional());
	    position = setStringToStatement(st, position, entity.getSystemAdminComments(), COLUMN_SYSTEMADMINCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getOperationalAnalystComments(), COLUMN_OPERATIONALANALYSTCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getIstgComments(), COLUMN_ISTGCOMMENTS_LEN);
	    position = setLongToStatement(st, position, entity.getInfomanId());
	    position = setDateToStatement(st, position, entity.getOpAnalystScheduleDate());
	    position = setDateToStatement(st, position, entity.getOpAnalystCompletedDate());
	    position = setStringToStatement(st, position, entity.getVaFlag(), COLUMN_VAFLAG_LEN);
	    position = setStringToStatement(st, position, entity.getVaNumber(), COLUMN_VANUMBER_LEN);
	    position = setDateToStatement(st, position, entity.getVaSchDate());
	    position = setStringToStatement(st, position, entity.getVaComments(), COLUMN_VACOMMENTS_LEN);

	    // Association references
	    position = updatePlanningReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + PlanningDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param entity the entity
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public void loadPlanningPart(Entity entity) throws DatabaseException
    {
	loadPlanningPart(entity, true); 	
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param entity the entity
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public void loadPlanningPart(Entity entity, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = entity.getId();
	PlanningEntity obj = null;
	log.debug("Getting PlanningEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> PlanningEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    buildPlanningEntity(rs, entity);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + PlanningDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + PlanningDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting PlanningEntity with id = " + id_to_get); 
    }






    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void deletePlanningPart(PlanningEntity entity) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;



	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...

	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + PlanningDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(PlanningEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + PlanningDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Builds the planning entity.
     *
     * @param rs the rs
     * @param obj the obj
     * @throws DatabaseException the database exception
     */
    protected void buildPlanningEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	PlanningEntity entity = (PlanningEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setPlannedActivateDate(getDateFromResultSet(rs, COLUMN_PLANNEDACTIVATEDATE));
	    entity.setPlannedActivateDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalPlannedActivateDate(entity.getPlannedActivateDate());
	    //			entity.setSecurityReviewComment(getStringFromResultSet(rs, COLUMN_SECURITYREVIEWCOMMENT));
	    entity.setSecurityReviewComment(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSecurityReviewComment(entity.getSecurityReviewComment());
	    //			entity.setSponsorReviewComments(getStringFromResultSet(rs, COLUMN_SPONSORREVIEWCOMMENTS));
	    entity.setSponsorReviewComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSponsorReviewComments(entity.getSponsorReviewComments());
	    //			entity.setActivateConnectionComment(getStringFromResultSet(rs, COLUMN_ACTIVATECONNECTIONCOMMENT));
	    entity.setActivateConnectionComment(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalActivateConnectionComment(entity.getActivateConnectionComment());
	    //			entity.setApproveDetailDesignComment(getStringFromResultSet(rs, COLUMN_APPROVEDETAILDESIGNCOMMENT));
	    entity.setApproveDetailDesignComment(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalApproveDetailDesignComment(entity.getApproveDetailDesignComment());
	    //			entity.setIntegrationCompleted(getBooleanFromResultSet(rs, COLUMN_INTEGRATIONCOMPLETED));
	    entity.setIntegrationCompleted(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIntegrationCompleted(entity.getIntegrationCompleted());
	    //			entity.setIntegrationStatusComments(getStringFromResultSet(rs, COLUMN_INTEGRATIONSTATUSCOMMENTS));
	    entity.setIntegrationStatusComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIntegrationStatusComments(entity.getIntegrationStatusComments());
	    //			entity.setProcurementDate(getDateFromResultSet(rs, COLUMN_PROCUREMENTDATE));
	    entity.setProcurementDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcurementDate(entity.getProcurementDate());
	    //			entity.setProcurementComments(getStringFromResultSet(rs, COLUMN_PROCUREMENTCOMMENTS));
	    entity.setProcurementComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcurementComments(entity.getProcurementComments());
	    //			entity.setProcurementOptional(getBooleanFromResultSet(rs, COLUMN_PROCUREMENTOPTIONAL));
	    entity.setProcurementOptional(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcurementOptional(entity.getProcurementOptional());
	    //			entity.setSystemAdminComments(getStringFromResultSet(rs, COLUMN_SYSTEMADMINCOMMENTS));
	    entity.setSystemAdminComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSystemAdminComments(entity.getSystemAdminComments());
	    //			entity.setOperationalAnalystComments(getStringFromResultSet(rs, COLUMN_OPERATIONALANALYSTCOMMENTS));
	    entity.setOperationalAnalystComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOperationalAnalystComments(entity.getOperationalAnalystComments());
	    //			entity.setIstgComments(getStringFromResultSet(rs, COLUMN_ISTGCOMMENTS));
	    entity.setIstgComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIstgComments(entity.getIstgComments());
	    //			entity.setInfomanId(getLongFromResultSet(rs, COLUMN_INFOMANID));
	    entity.setInfomanId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalInfomanId(entity.getInfomanId());
	    //			entity.setOpAnalystScheduleDate(getDateFromResultSet(rs, COLUMN_OPANALYSTSCHEDULEDATE));
	    entity.setOpAnalystScheduleDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOpAnalystScheduleDate(entity.getOpAnalystScheduleDate());
	    //			entity.setOpAnalystCompletedDate(getDateFromResultSet(rs, COLUMN_OPANALYSTCOMPLETEDDATE));
	    entity.setOpAnalystCompletedDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOpAnalystCompletedDate(entity.getOpAnalystCompletedDate());
	    //			entity.setVaFlag(getStringFromResultSet(rs, COLUMN_VAFLAG));
	    entity.setVaFlag(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalVaFlag(entity.getVaFlag());
	    //			entity.setVaNumber(getStringFromResultSet(rs, COLUMN_VANUMBER));
	    entity.setVaNumber(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalVaNumber(entity.getVaNumber());
	    //			entity.setVaSchDate(getDateFromResultSet(rs, COLUMN_VASCHDATE));
	    entity.setVaSchDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalVaSchDate(entity.getVaSchDate());
	    //			entity.setVaComments(getStringFromResultSet(rs, COLUMN_VACOMMENTS));
	    entity.setVaComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalVaComments(entity.getVaComments());

	    // Single References

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }


    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	super.loadReferenceIds(obj);
	PlanningEntity entity = (PlanningEntity)obj;
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadPlanningReferences(Entity obj) throws DatabaseException
    {
	log.debug("MaintenanceDAO.loadReferences(): Loading references for PlanningEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    PlanningEntity entity = (PlanningEntity)obj;

	}
	catch(Exception e)
	{
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for PlanningEntity [" + obj.getId() + "].", e);
	}
    }


    //======================================================================
    /**
     * Update planning references.
     *
     * @param st the st
     * @param obj the obj
     * @param position the position
     * @return the int
     * @throws DatabaseException the database exception
     * @throws SQLException the sQL exception
     */
    protected int updatePlanningReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	PlanningEntity entity = (PlanningEntity) obj;


	return position;
    }


    // Reference DAO caching methods	

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [PlannedActivateDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByPlannedActivateDate(Date value) throws DatabaseException
    {
	return findByPlannedActivateDate(value, getSession());
    }

    /**
     * Find by planned activate date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByPlannedActivateDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_PLANNEDACTIVATEDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SecurityReviewComment] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySecurityReviewComment(String value) throws DatabaseException
    {
	return findBySecurityReviewComment(value, getSession());
    }

    /**
     * Find by security review comment.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySecurityReviewComment(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_SECURITYREVIEWCOMMENT + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SponsorReviewComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySponsorReviewComments(String value) throws DatabaseException
    {
	return findBySponsorReviewComments(value, getSession());
    }

    /**
     * Find by sponsor review comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySponsorReviewComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_SPONSORREVIEWCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ActivateConnectionComment] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByActivateConnectionComment(String value) throws DatabaseException
    {
	return findByActivateConnectionComment(value, getSession());
    }

    /**
     * Find by activate connection comment.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByActivateConnectionComment(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_ACTIVATECONNECTIONCOMMENT + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ApproveDetailDesignComment] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByApproveDetailDesignComment(String value) throws DatabaseException
    {
	return findByApproveDetailDesignComment(value, getSession());
    }

    /**
     * Find by approve detail design comment.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByApproveDetailDesignComment(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_APPROVEDETAILDESIGNCOMMENT + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IntegrationCompleted] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIntegrationCompleted(Boolean value) throws DatabaseException
    {
	return findByIntegrationCompleted(value, getSession());
    }

    /**
     * Find by integration completed.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIntegrationCompleted(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_INTEGRATIONCOMPLETED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IntegrationStatusComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIntegrationStatusComments(String value) throws DatabaseException
    {
	return findByIntegrationStatusComments(value, getSession());
    }

    /**
     * Find by integration status comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIntegrationStatusComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_INTEGRATIONSTATUSCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ProcurementDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcurementDate(Date value) throws DatabaseException
    {
	return findByProcurementDate(value, getSession());
    }

    /**
     * Find by procurement date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcurementDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_PROCUREMENTDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ProcurementComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcurementComments(String value) throws DatabaseException
    {
	return findByProcurementComments(value, getSession());
    }

    /**
     * Find by procurement comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcurementComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_PROCUREMENTCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ProcurementOptional] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcurementOptional(Boolean value) throws DatabaseException
    {
	return findByProcurementOptional(value, getSession());
    }

    /**
     * Find by procurement optional.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcurementOptional(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_PROCUREMENTOPTIONAL + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SystemAdminComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySystemAdminComments(String value) throws DatabaseException
    {
	return findBySystemAdminComments(value, getSession());
    }

    /**
     * Find by system admin comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySystemAdminComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_SYSTEMADMINCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OperationalAnalystComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOperationalAnalystComments(String value) throws DatabaseException
    {
	return findByOperationalAnalystComments(value, getSession());
    }

    /**
     * Find by operational analyst comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOperationalAnalystComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_OPERATIONALANALYSTCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IstgComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIstgComments(String value) throws DatabaseException
    {
	return findByIstgComments(value, getSession());
    }

    /**
     * Find by istg comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIstgComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_ISTGCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [InfomanId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByInfomanId(Long value) throws DatabaseException
    {
	return findByInfomanId(value, getSession());
    }

    /**
     * Find by infoman id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByInfomanId(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_INFOMANID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OpAnalystScheduleDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOpAnalystScheduleDate(Date value) throws DatabaseException
    {
	return findByOpAnalystScheduleDate(value, getSession());
    }

    /**
     * Find by op analyst schedule date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOpAnalystScheduleDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_OPANALYSTSCHEDULEDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OpAnalystCompletedDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOpAnalystCompletedDate(Date value) throws DatabaseException
    {
	return findByOpAnalystCompletedDate(value, getSession());
    }

    /**
     * Find by op analyst completed date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOpAnalystCompletedDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_OPANALYSTCOMPLETEDDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [VaFlag] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByVaFlag(String value) throws DatabaseException
    {
	return findByVaFlag(value, getSession());
    }

    /**
     * Find by va flag.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByVaFlag(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_VAFLAG + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [VaNumber] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByVaNumber(String value) throws DatabaseException
    {
	return findByVaNumber(value, getSession());
    }

    /**
     * Find by va number.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByVaNumber(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_VANUMBER + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [VaSchDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByVaSchDate(Date value) throws DatabaseException
    {
	return findByVaSchDate(value, getSession());
    }

    /**
     * Find by va sch date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByVaSchDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_VASCHDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [VaComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByVaComments(String value) throws DatabaseException
    {
	return findByVaComments(value, getSession());
    }

    /**
     * Find by va comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByVaComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + PlanningDAO.TABLE + " WHERE " + COLUMN_VACOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by VaComments", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.dao.ConnectionRequestDAO#dummyExceptionTosser(boolean)
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(PlanningEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
