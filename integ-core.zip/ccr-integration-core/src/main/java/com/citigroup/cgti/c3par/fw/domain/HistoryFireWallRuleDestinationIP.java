/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;


/**
 * 
 * @author ne36745
 *
 */
public class HistoryFireWallRuleDestinationIP extends HistoryFireWallRuleIP {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private boolean isDeleted;
    
    private Long ruleIPId;

    public HistoryFireWallRuleDestinationIP() {
    }

	/**
	 * @return the isDeleted
	 */
	public boolean isDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the ruleIPId
	 */
	public Long getRuleIPId() {
		return ruleIPId;
	}

	/**
	 * @param ruleIPId the ruleIPId to set
	 */
	public void setRuleIPId(Long ruleIPId) {
		this.ruleIPId = ruleIPId;
	}

}
