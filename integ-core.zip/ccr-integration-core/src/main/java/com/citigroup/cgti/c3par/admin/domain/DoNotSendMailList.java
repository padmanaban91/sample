/*
 * 
 */
package com.citigroup.cgti.c3par.admin.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * The Class DoNotSendEmailList
 */
public class DoNotSendMailList extends Base implements Serializable {

	private String soeID;
	
	private String isDeleted;
	
	private Long citiContactId;
		
	public Long getCitiContactId() {
		return citiContactId;
	}

	public void setCitiContactId(Long citiContactId) {
		this.citiContactId = citiContactId;
	}

	public String getSoeID() {
		return soeID;
	}

	public void setSoeID(String soeID) {
		this.soeID = soeID;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}
	
}
