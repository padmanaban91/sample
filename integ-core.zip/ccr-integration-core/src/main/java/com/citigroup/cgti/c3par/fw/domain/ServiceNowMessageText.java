package com.citigroup.cgti.c3par.fw.domain;

//import java.util.Date;

import java.sql.Blob;
import java.util.Date;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * @author nc43495
 *
 */

public class ServiceNowMessageText extends Base{
	Logger log = Logger.getLogger(ServiceNowMessageLog.class);

   
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private Long messageLogId;
    private Blob messageText;
    private String messageType;
   
    
 
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getMessageLogId() {
		return messageLogId;
	}
	public void setMessageLogId(Long messageLogId) {
		this.messageLogId = messageLogId;
	}
	public Blob getMessageText() {
		return messageText;
	}
	public void setMessageText(Blob messageText) {
		this.messageText = messageText;
	}
	
  
 

	
}
