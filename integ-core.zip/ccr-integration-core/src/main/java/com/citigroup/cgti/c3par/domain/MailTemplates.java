package com.citigroup.cgti.c3par.domain;

import java.sql.Timestamp;
import java.util.Date;




/**
 * The Class BaseMailVO.
 */
public class MailTemplates {
	
	private Long ID;
	
	private String subject;
	
	private String body;
	
	private String template_id;
	
	private Timestamp lastUpdatedDate;
	
	private String lastUpdatedBy;
	
	private String toUserRole;
	private String toOwner;
	private String toRole;
	private String cc;
	private String ccUserRole;
	private String ccOwner;
	private String ccRole;
	private String bcc;
	private String fromAdr;
	private String footNote;
	
	public String getFootNote() {
		return footNote;
	}

	public void setFootNote(String footNote) {
		this.footNote = footNote;
	}

	public String getToUserRole() {
		return toUserRole==null ? "":toUserRole;
	}

	public void setToUserRole(String toUserRole) {
		this.toUserRole = toUserRole;
	}

	public String getToOwner() {
		return toOwner == null ? "":toOwner;
	}

	public void setToOwner(String toOwner) {
		this.toOwner = toOwner;
	}

	public String getToRole() {
		return toRole == null ? "": toRole;
	}

	public void setToRole(String toRole) {
		this.toRole = toRole;
	}

	public String getCc() {
		return cc == null?"":cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getCcUserRole() {
		return ccUserRole;
	}

	public void setCcUserRole(String ccUserRole) {
		this.ccUserRole = (ccUserRole==null?"":ccUserRole);
	}

	public String getCcOwner() {
		return ccOwner;
	}

	public void setCcOwner(String ccOwner) {
		this.ccOwner = (ccOwner == null?"":ccOwner);
	}

	public String getCcRole() {
		return ccRole;
	}

	public void setCcRole(String ccRole) {
		this.ccRole = (ccRole==null?"":ccRole);
	}

	public String getBcc() {
		return bcc;
	}

	public void setBcc(String bcc) {
		this.bcc = (bcc==null?"":bcc);
	}

	public String getFromAdr() {
		return fromAdr;
	}

	public void setFromAdr(String fromAdr) {
		this.fromAdr = fromAdr;
	}

	public String getTemplate_id() {
		return template_id;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public void setTemplate_id(String template_id) {
		this.template_id = template_id;
	}

	public Long getID() {
		return ID;
	}

	public void setID(Long iD) {
		ID = iD;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}
	
	
	
	
}
