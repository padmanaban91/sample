package com.citigroup.cgti.c3par.appsense.domain;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;

// TODO: Auto-generated Javadoc
/**
 * The Class AppsenseApplication.
 */
public class AppsenseApplication extends Base {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The ti process. */
    private TIProcess tiProcess = new TIProcess();

    /** The ti request. */
    private TIRequest tiRequest = new TIRequest();

    /** The application. */
    private Application application = new Application();

    /** The aps port master. */
    private AppsensePortMaster apsPortMaster = new AppsensePortMaster();

    /** The record type. */
    private String recordType = "A";

    /** The port unblock. */
    private String portUnblock;

    /** The Appsense ad group. */
    private AppsenseADGroup AppsenseADGroup = new AppsenseADGroup();

    /** The status. */
    private String status;

    /** The select download type. */
    private String selectDownloadType;
    
    private boolean alreadyAccessed;
    
    /**
     * 
     */
    private static final String IPADDRESS_PATTERN_SINGLE = 
		"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
    
    /**
     * 
     */
    private static final String IPADDRESS_PATTERN_RANGE = 
		"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])"+
		"\\-"+
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
    
    /**
     * 
     */
    private static final String IPADDRESS_PATTERN_SUBNET = 
    	"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])"+
		"\\/"+
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
    
    /**
	 * @return the alreadyAccessed
	 */
	public boolean isAlreadyAccessed() {
		return alreadyAccessed;
	}

	/**
	 * @param alreadyAccessed the alreadyAccessed to set
	 */
	public void setAlreadyAccessed(boolean alreadyAccessed) {
		this.alreadyAccessed = alreadyAccessed;
	}

    /**
     * Gets the appsense ad group.
     * 
     * @return the appsense ad group
     */
    public AppsenseADGroup getAppsenseADGroup() {
	return AppsenseADGroup;
    }

    /**
     * Sets the appsense ad group.
     * 
     * @param appsenseADGroup
     *            the new appsense ad group
     */
    public void setAppsenseADGroup(AppsenseADGroup appsenseADGroup) {
	AppsenseADGroup = appsenseADGroup;
    }

    /**
     * Instantiates a new appsense application.
     */
    public AppsenseApplication() {
    }

    /**
     * Gets the application.
     * 
     * @return the application
     */
    public Application getApplication() {
	return application;
    }

    /**
     * Sets the application.
     * 
     * @param application
     *            the new application
     */
    public void setApplication(Application application) {
	this.application = application;
    }

    /**
     * Gets the aps port master.
     * 
     * @return the aps port master
     */
    public AppsensePortMaster getApsPortMaster() {
	return apsPortMaster;
    }

    /**
     * Sets the aps port master.
     * 
     * @param apsPortMaster
     *            the new aps port master
     */
    public void setApsPortMaster(AppsensePortMaster apsPortMaster) {
	this.apsPortMaster = apsPortMaster;
    }

    /**
     * Gets the ti process.
     * 
     * @return the ti process
     */
    public TIProcess getTiProcess() {
	return tiProcess;
    }

    /**
     * Sets the ti process.
     * 
     * @param tiProcess
     *            the new ti process
     */
    public void setTiProcess(TIProcess tiProcess) {
	this.tiProcess = tiProcess;
    }

    /**
     * Gets the ti request.
     * 
     * @return the ti request
     */
    public TIRequest getTiRequest() {
	return tiRequest;
    }

    /**
     * Sets the ti request.
     * 
     * @param tiRequest
     *            the new ti request
     */
    public void setTiRequest(TIRequest tiRequest) {
	this.tiRequest = tiRequest;
    }

    /**
     * Gets the record type.
     * 
     * @return the record type
     */
    private String getRecordType() {
	return recordType;
    }

    /**
     * Sets the record type.
     * 
     * @param recordType
     *            the new record type
     */
    private void setRecordType(String recordType) {
	this.recordType = recordType;
    }

    /**
     * Gets the port unblock.
     * 
     * @return the port unblock
     */
    public String getPortUnblock() {
	return portUnblock;
    }

    /**
     * Sets the port unblock.
     * 
     * @param portUnblock
     *            the new port unblock
     */
    public void setPortUnblock(String portUnblock) {
	this.portUnblock = portUnblock;
    }

    /**
     * Gets the status.
     * 
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     * 
     * @param status
     *            the new status
     */
    public void setStatus(String status) {
	this.status = status;
    }

    /**
     * Gets the select download type.
     * 
     * @return the select download type
     */
    public String getSelectDownloadType() {
	return selectDownloadType;
    }

    /**
     * Sets the select download type.
     * 
     * @param selectDownloadType
     *            the new select download type
     */
    public void setSelectDownloadType(String selectDownloadType) {
	this.selectDownloadType = selectDownloadType;
    }

    /**
     * Checks if is valid ip and ports.
     *Added for #10494
     * @return true, if is valid ip and ports
     */
    public boolean isValidIPAndPorts() {
	String portOrProtocol = getApsPortMaster().getPortLookUp()
	.getPortNumber();
	String ipAddress = getApsPortMaster().getConnectionIPMaster()
	.getIpAddress();
	boolean valid = false;
	if((portOrProtocol == null || "".equals(portOrProtocol)) && (ipAddress == null || "".equals(ipAddress))){
	    valid = true;
	}
	if((portOrProtocol != null && !"".equals(portOrProtocol)) && (ipAddress != null && !"".equals(ipAddress))){
	    valid = checkIp(ipAddress);
	}
	return valid;
    }

    /**
     * Check ip. Added for #10494
     * will have to move to Util 
     * @param sip the sip
     * @return true, if successful
     */

    public static boolean checkIp(String ip) {
    	Pattern pattern = null;
    	Matcher matcher = null;
    	  if (ip.indexOf("-") != -1) {
        	  pattern = Pattern.compile(IPADDRESS_PATTERN_RANGE);
          } else if (ip.indexOf("/") != -1) {
        	  pattern = Pattern.compile(IPADDRESS_PATTERN_SUBNET);
          } else {
        	  pattern = Pattern.compile(IPADDRESS_PATTERN_SINGLE);
          }
    	  matcher = pattern.matcher(ip);
    	  return matcher.matches();	
    }

    public boolean isValidSubnet(){
	return checkIp(getApsPortMaster().getConnectionIPMaster()
		.getSubnet());
    }

}
