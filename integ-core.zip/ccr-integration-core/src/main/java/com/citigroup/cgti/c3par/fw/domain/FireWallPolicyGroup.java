/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.Base;

/**
 * @author bs45969
 */
public class FireWallPolicyGroup extends Base {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * 
     */
    private String name;
    
    private String active;
    
    /**
     * 
     */
    private FirewallLocation connectionFWLocation;
    
    /**
     * 
     */
    private GenericLookup connectivityType;
    
    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
	/**
	 * @return the connectionFWLocation
	 */
	public FirewallLocation getConnectionFWLocation() {
		return connectionFWLocation;
	}
	/**
	 * @param connectionFWLocation the connectionFWLocation to set
	 */
	public void setConnectionFWLocation(FirewallLocation connectionFWLocation) {
		this.connectionFWLocation = connectionFWLocation;
	}
	/**
	 * @return the connectivityType
	 */
	public GenericLookup getConnectivityType() {
		return connectivityType;
	}
	/**
	 * @param connectivityType the connectivityType to set
	 */
	public void setConnectivityType(GenericLookup connectivityType) {
		this.connectivityType = connectivityType;
	}
	/**
	 * @return the active
	 */
	public String getActive() {
		return active;
	}
	/**
	 * @param active the active to set
	 */
	public void setActive(String active) {
		this.active = active;
	}
    
	
}
