package com.citigroup.cgti.c3par.bpm.ejb.mailmodule;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.bpm.ejb.domain.C3PARUserDTO;
import com.citigroup.cgti.c3par.bpm.ejb.useradmin.GDWUser;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.domain.ACVSummaryEmailUserVO;
import com.citigroup.cgti.c3par.domain.C3PARUser;
import com.citigroup.cgti.c3par.domain.ConnectionDetailEmailVO;
import com.citigroup.cgti.c3par.domain.InputMailVO;
import com.citigroup.cgti.c3par.domain.MailTemplates;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.domain.TargetContactEmail;


/**
 * The Interface IMailModule.
 */
public interface IMailModule {

	/**
	 * Send work item notification.
	 *
	 * @param requestID the request id
	 * @param activityCode the activity code
	 * @param activityStatus the activity status
	 * @param activityRole the activity role
	 * @throws Exception the exception
	 */
	public void sendWorkItemNotification(long requestID, String activityCode, String activityStatus,String activityRole) throws Exception;
	
	/**
	 * Send entitlement notification.
	 *
	 * @param user the user
	 * @param activityName the activity name
	 * @throws Exception the exception
	 */
	public void sendEntitlementNotification(C3PARUser user, String activityName) throws Exception;
	
	/**
	 * Send entitlement notification.
	 *
	 * @param userDTO the user dto
	 * @param activityName the activity name
	 * @throws Exception the exception
	 */
	public void sendEntitlementNotification(C3PARUserDTO userDTO, String activityName) throws Exception;
	
	/**
	 * Send scheduled notification.
	 *
	 * @param requestIds the request id
	 * @param inputMailVO the input mail vo
	 * @throws Exception the exception
	 */
	// JDBCTemplate Refactored Changed
	public List<String>  sendScheduledNotification(List<String> requestIDs) throws Exception;
	
	public void sendScheduledExpirationNotification(long requestID, InputMailVO inputMailVO, String activityName) throws Exception;
	
	public void sendActivationExpirationNotification(List requestIDs, String notificationType) throws Exception;
	
	
	public void sendScheduledExpirationNotification(Map<String,String> data) throws Exception;

	/**
	 * Send email faf queue alert.
	 *
	 * @param fafRequests the faf requests
	 * @throws Exception the exception
	 */
	//public void sendEmailFAFQueueAlert(ArrayList fafRequests) throws Exception;
	
	/**
	 * Send email faf completion.
	 *
	 * @param connectionID the connection id
	 * @param reportType the report type
	 * @throws Exception the exception
	 */
	//public void sendEmailFAFCompletion(Long connectionID,String reportType) throws Exception;
	
	/**
	 * Send activation expiration notification.
	 *
	 * @param requestID the request id
	 * @param inputMailVO the input mail vo
	 * @throws Exception the exception
	 */
	public void sendActivationExpirationNotification(long requestID,InputMailVO inputMailVO,String notificationType) throws Exception;
	
	/**
	 * Send computation completion email.
	 *
	 * @param connectionID the connection id
	 * @param isFWImplementation the is fw implementation
	 * @param isAppsense the is appsense
	 * @param isProxy the is proxy
	 * @throws Exception the exception
	 */
	public void sendComputationCompletionEmail(long connectionID, boolean isFWImplementation, boolean isAppsense , boolean isProxy)throws Exception;
	
	/**
	 * Send director approval email.
	 *
	 * @param requestID the request id
	 * @param relationShipType the relation ship type
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	public boolean sendDirectorApprovalEmail(Long requestID,String relationShipType) throws Exception;
	
	/**	
	 * Send email to register people record.
	 *
	 * @param requestID the request id
	 * @param relationShipType the relation ship type
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	public boolean sendEmailToRegisterPeopleRecord(Long requestID,String relationShipType)throws Exception;

	/**
	 * Send email on BaseLine change	 *
	 */	
	public void sendEmailOnBaseLineChange(String oldBaseLine, String newBaseLine) throws Exception;

	public void sendEmailToSupervisorList(List<GDWUser> users) throws Exception;

	public void sendMailToTargetContacts(List list, TIRequest tiReq,String contactType);

	public void sendMailToAddContact(Long processId,String ssoID,List contactList, Long tiReqID);
	
	public void sendMailForUserEntitlementCreate(ContactDetailsDTO contactDto, TIRequest tiReq);
	
	public void sendMailToNonThirdPartyACV(HashMap <String,ACVSummaryEmailUserVO>  nonThirdPartycontacts);

	public void sendAckMail(Long processId, ContactDetailsDTO contact,
			Long tiRequestID, String status, String role);
	
	public void sendApplicationOwnerMail(TargetContactEmail sendAppOwner);
	
	public void sendNotificationForWorkItem(Long tiRequestId,String activityCode,String activityName,String activityRole);
	
	void sendCommentsEmail(Long tiRequestId, String activityCode, String comments,String extendedDate);
	
	public void sendEcmEmailGeneration(String chooseEmail,CMPRequest resolveITMessage);
	
	public void sendEcmEmailViewGeneration(String chooseEmail,CmpRequestDTO commEmail); 
	
	public void notificationForDecommissionedApp(List<ConnectionDetailEmailVO> connectionDetailEmailVO);
	
	public void sendECMAgentWorkAssignedNotification(CmpRequestDTO cmpRequestDTO, Map<String,String> mailInfo);

	void sendRisoEmail(Long tiRequestId, String gisCmnts, CitiContact risoContact);
	
	public void updateMailTemplate(String updatedBy, String subject, String templateId, String body);
	
	public List<MailTemplates> getAllMailTemplates();
	
	public void sendSNByPassImplEmailGen(String templateId, TIProcess tiProcess);
	 

}
