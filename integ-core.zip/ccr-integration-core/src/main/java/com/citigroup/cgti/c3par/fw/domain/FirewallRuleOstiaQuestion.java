package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * 
 * @author ne36745
 *
 */
public class FirewallRuleOstiaQuestion extends Base {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private OstiaQuestion ostiaQuestion;
	
	private FirewallRuleQuestionnaire firewallRuleQuestionnaire;
	
	private TIRequest updatedTIRequest;
	
	private TIRequest deletedTIRequest;
	
	private String status;	
	private String textAnswer;
	private String singleAnswer;
	private String otherText;
	//transient field for handling multi select
	private Set<String> answersValue=new LinkedHashSet<String>();
	private Map<String,FirewallRuleOstiaAnswer> answersValueExists=new LinkedHashMap<String,FirewallRuleOstiaAnswer>();
	private Set<FirewallRuleOstiaAnswer> answers = new LinkedHashSet<FirewallRuleOstiaAnswer>();


	public FirewallRuleOstiaQuestion() {
		setCreated_date(new Date());
	}
	
	/**
	 * @return the ostiaQuestion
	 */
	public OstiaQuestion getOstiaQuestion() {
		return ostiaQuestion;
	}

	/**
	 * @param ostiaQuestion the ostiaQuestion to set
	 */
	public void setOstiaQuestion(OstiaQuestion ostiaQuestion) {
		this.ostiaQuestion = ostiaQuestion;
	}

	/**
	 * @return the firewallRuleQuestionnaire
	 */
	public FirewallRuleQuestionnaire getFirewallRuleQuestionnaire() {
		return firewallRuleQuestionnaire;
	}

	/**
	 * @param firewallRuleQuestionnaire the firewallRuleQuestionnaire to set
	 */
	public void setFirewallRuleQuestionnaire(
			FirewallRuleQuestionnaire firewallRuleQuestionnaire) {
		this.firewallRuleQuestionnaire = firewallRuleQuestionnaire;
	}

	/**
	 * @return the updatedTIRequest
	 */
	public TIRequest getUpdatedTIRequest() {
		return updatedTIRequest;
	}

	/**
	 * @param updatedTIRequest the updatedTIRequest to set
	 */
	public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
		this.updatedTIRequest = updatedTIRequest;
	}

	/**
	 * @return the deletedTIRequest
	 */
	public TIRequest getDeletedTIRequest() {
		return deletedTIRequest;
	}

	/**
	 * @param deletedTIRequest the deletedTIRequest to set
	 */
	public void setDeletedTIRequest(TIRequest deletedTIRequest) {
		this.deletedTIRequest = deletedTIRequest;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}


	

	/**
	 * @return the answers
	 */
	public Set<FirewallRuleOstiaAnswer> getAnswers() {
		return answers;
	}

	/**
	 * @param answers the answers to set
	 */
	public void setAnswers(Set<FirewallRuleOstiaAnswer> answers) {
		this.answers = answers;
	}

	/**
	 * @return the answersValue
	 */
	public Set<String> getAnswersValue() {
		if ((answersValue == null || answersValue.isEmpty()) || "[]".equals(answersValue)) {
			for (FirewallRuleOstiaAnswer firewallRuleOstiaAnswer:answers) {
				if(firewallRuleOstiaAnswer.getDeletedTIRequest()==null)
				{
					//if the above condition is true it will always through null pointer
					//exception therefore initializing after a null check to make sure error doesn't occur. 
					if(null==answersValue)
					{
						//initialize
						answersValue = new LinkedHashSet<String>();
					}
					answersValue.add(firewallRuleOstiaAnswer.getAnswer());
				}
				
			}
		}
		

		return answersValue;
	}

	/**
	 * @param answersValue the answersValue to set
	 */
	public void setAnswersValue(Set<String> answersValue) {
		this.answersValue = answersValue;
	}

	/**
	 * @return the textAnswer
	 */
	public String getTextAnswer() {
		return textAnswer;
	}

	/**
	 * @param textAnswer the textAnswer to set
	 */
	public void setTextAnswer(String textAnswer) {
		this.textAnswer = textAnswer;
	}

	/**
	 * @return the singleAnswer
	 */
	public String getSingleAnswer() {
		return singleAnswer;
	}

	/**
	 * @param singleAnswer the singleAnswer to set
	 */
	public void setSingleAnswer(String singleAnswer) {
		this.singleAnswer = singleAnswer;
	}

	/**
	 * @return the otherText
	 */
	public String getOtherText() {
		return otherText;
	}

	/**
	 * @param otherText the otherText to set
	 */
	public void setOtherText(String otherText) {
		this.otherText = otherText;
	}

	/**
	 * @return the answersValueExists
	 */
	public Map<String,FirewallRuleOstiaAnswer> getAnswersValueExists() {
		if(answers!=null){
			for (FirewallRuleOstiaAnswer firewallRuleOstiaAnswer:answers) {
				answersValueExists.put(firewallRuleOstiaAnswer.getAnswer(),firewallRuleOstiaAnswer);
			}
		}	
		return answersValueExists;
	}

}
