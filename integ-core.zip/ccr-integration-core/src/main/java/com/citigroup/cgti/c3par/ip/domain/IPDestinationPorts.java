package com.citigroup.cgti.c3par.ip.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class IPDestinationPorts.
 */
public class IPDestinationPorts extends Base implements Serializable{

    /** The start port. */
    private String startPort;

    /** The end port. */
    private String endPort;

    /** The service mapping. */
    private String serviceMapping;

    /** The service mapping type. */
    private String serviceMappingType;	

    /** The justification. */
    private String justification;

    /** The protocols. */
    private List protocols = new ArrayList();

    /** The risk ports ostia. */
    private List riskPortsOstia = new ArrayList();

    /** The control messages. */
    private List controlMessages = new ArrayList();

    /** The port type id. */
    private Long portTypeID;

    /** The protocol id. */
    private Long protocolID;

    /** The control messages id. */
    private Long controlMessagesID;

    /** The selected. */
    private boolean selected = false;

    /**
     * Gets the start port.
     *
     * @return the start port
     */
    public String getStartPort() {
	return startPort;
    }

    /**
     * Sets the start port.
     *
     * @param startPort the new start port
     */
    public void setStartPort(String startPort) {
	this.startPort = startPort;
    }

    /**
     * Gets the end port.
     *
     * @return the end port
     */
    public String getEndPort() {
	return endPort;
    }

    /**
     * Sets the end port.
     *
     * @param endPort the new end port
     */
    public void setEndPort(String endPort) {
	this.endPort = endPort;
    }

    /**
     * Gets the justification.
     *
     * @return the justification
     */
    public String getJustification() {
	return justification;
    }

    /**
     * Sets the justification.
     *
     * @param justification the new justification
     */
    public void setJustification(String justification) {
	this.justification = justification;
    }

    /**
     * Gets the port type id.
     *
     * @return the port type id
     */
    public Long getPortTypeID() {
	return portTypeID;
    }

    /**
     * Sets the port type id.
     *
     * @param portTypeID the new port type id
     */
    public void setPortTypeID(Long portTypeID) {
	this.portTypeID = portTypeID;
    }

    /**
     * Gets the protocols.
     *
     * @return the protocols
     */
    public List getProtocols() {
	return protocols;
    }

    /**
     * Sets the protocols.
     *
     * @param protocols the new protocols
     */
    public void setProtocols(List protocols) {
	this.protocols = protocols;
    }

    /**
     * Gets the risk ports ostia.
     *
     * @return the risk ports ostia
     */
    public List getRiskPortsOstia() {
	return riskPortsOstia;
    }

    /**
     * Sets the risk ports ostia.
     *
     * @param riskPortsOstia the new risk ports ostia
     */
    public void setRiskPortsOstia(List riskPortsOstia) {
	this.riskPortsOstia = riskPortsOstia;
    }

    /**
     * Gets the service mapping.
     *
     * @return the service mapping
     */
    public String getServiceMapping() {
	return serviceMapping;
    }

    /**
     * Sets the service mapping.
     *
     * @param serviceMapping the new service mapping
     */
    public void setServiceMapping(String serviceMapping) {
	this.serviceMapping = serviceMapping;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#isSelected()
     */
    public boolean isSelected() {
	return selected;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#setSelected(boolean)
     */
    public void setSelected(boolean selected) {
	this.selected = selected;
    }

    /**
     * Gets the service mapping type.
     *
     * @return the service mapping type
     */
    public String getServiceMappingType() {
	return serviceMappingType;
    }

    /**
     * Sets the service mapping type.
     *
     * @param serviceMappingType the new service mapping type
     */
    public void setServiceMappingType(String serviceMappingType) {
	this.serviceMappingType = serviceMappingType;
    }

    /**
     * Gets the control messages.
     *
     * @return the control messages
     */
    public List getControlMessages() {
	return controlMessages;
    }

    /**
     * Sets the control messages.
     *
     * @param controlMessages the new control messages
     */
    public void setControlMessages(List controlMessages) {

	this.controlMessages = controlMessages;
    }

    /**
     * Gets the control messages id.
     *
     * @return the control messages id
     */
    public Long getControlMessagesID() {
	return controlMessagesID;
    }

    /**
     * Sets the control messages id.
     *
     * @param controlMessagesID the new control messages id
     */
    public void setControlMessagesID(Long controlMessagesID) {
	this.controlMessagesID = controlMessagesID;
    }

    /**
     * Gets the protocol id.
     *
     * @return the protocol id
     */
    public Long getProtocolID() {
	return protocolID;
    }

    /**
     * Sets the protocol id.
     *
     * @param protocolID the new protocol id
     */
    public void setProtocolID(Long protocolID) {
	this.protocolID = protocolID;
    }


}
