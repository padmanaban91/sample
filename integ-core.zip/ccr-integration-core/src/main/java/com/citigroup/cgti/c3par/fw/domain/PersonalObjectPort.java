/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * 
 * @author ne36745
 *
 */
public class PersonalObjectPort extends Base {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private PersonalObject personalObject;
    
    private String description;
    private String serviceName;
    private String defaultService;
    private String typeOfTraffic;
    private String isDeleted;

    private Port port;
    
    //UI Level Attributes and Flags
    private boolean deleted;
    private boolean serviceModified;
    private String orgServiceName;
	
    public PersonalObjectPort() {
    	setCreated_date(new Date());
	}
    
    /**
	 * @return the personalObject
	 */
	public PersonalObject getPersonalObject() {
		return personalObject;
	}
	/**
	 * @param personalObject the personalObject to set
	 */
	public void setPersonalObject(PersonalObject personalObject) {
		this.personalObject = personalObject;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}
	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	/**
	 * @return the defaultService
	 */
	public String getDefaultService() {
		return defaultService;
	}
	/**
	 * @param defaultService the defaultService to set
	 */
	public void setDefaultService(String defaultService) {
		this.defaultService = defaultService;
	}
	/**
	 * @return the typeOfTraffic
	 */
	public String getTypeOfTraffic() {
		return typeOfTraffic;
	}
	/**
	 * @param typeOfTraffic the typeOfTraffic to set
	 */
	public void setTypeOfTraffic(String typeOfTraffic) {
		this.typeOfTraffic = typeOfTraffic;
	}
	/**
	 * @return the isDeleted
	 */
	public String getIsDeleted() {
		return isDeleted;
	}
	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}
	/**
	 * @return the deleted
	 */
	public boolean isDeleted() {
		return deleted;
	}
	/**
	 * @param deleted the deleted to set
	 */
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	/**
	 * @return the serviceModified
	 */
	public boolean isServiceModified() {
		return serviceModified;
	}
	/**
	 * @param serviceModified the serviceModified to set
	 */
	public void setServiceModified(boolean serviceModified) {
		this.serviceModified = serviceModified;
	}
	/**
	 * @return the orgServiceName
	 */
	public String getOrgServiceName() {
		return orgServiceName;
	}
	/**
	 * @param orgServiceName the orgServiceName to set
	 */
	public void setOrgServiceName(String orgServiceName) {
		this.orgServiceName = orgServiceName;
	}
	/**
	 * @return the port
	 */
	public Port getPort() {
		return port;
	}
	/**
	 * @param port the port to set
	 */
	public void setPort(Port port) {
		this.port = port;
	}

}
