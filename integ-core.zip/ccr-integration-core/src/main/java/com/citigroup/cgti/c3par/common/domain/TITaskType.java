/*
 * 
 */
package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * The Class TITaskType.
 */
public class TITaskType extends Base implements Serializable {

	private String task;
	private String taskCode;
	private String albpmActivityId;	
	private String process;
	private String taskTimerActivity;	
	
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getTaskCode() {
		return taskCode;
	}
	public void setTaskCode(String taskCode) {
		this.taskCode = taskCode;
	}
	public String getAlbpmActivityId() {
		return albpmActivityId;
	}
	public void setAlbpmActivityId(String albpmActivityId) {
		this.albpmActivityId = albpmActivityId;
	}
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public String getTaskTimerActivity() {
		return taskTimerActivity;
	}
	public void setTaskTimerActivity(String taskTimerActivity) {
		this.taskTimerActivity = taskTimerActivity;
	}	
	
}
