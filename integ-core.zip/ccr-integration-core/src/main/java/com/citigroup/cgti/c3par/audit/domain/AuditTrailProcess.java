/**
 *
 */
package com.citigroup.cgti.c3par.audit.domain;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.audit.domain.soc.persist.AuditTrialPersistable;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.common.domain.AuditLog;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditResponse;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author pc79439
 * 
 */
public class AuditTrailProcess {
	CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext = CCRApplicationContextUtils
				.getApplicationContext();
		ccrBeanFactory = (CCRBeanFactory) appContext.getBean("cCRBeanFactory");
	}

	/** The log. */
	private static Logger log = Logger.getLogger(AuditTrailProcess.class);

	private Long tiRequest;

	private Long tiProcess;

	private TIProcess tiProcess1;

	private Long emailAuditTrailID;

	private List<TIMailAudit> tiMailAuditList;

	private TIMailAudit tiMailAudit;

	private TIMailAuditResponse tiMailAuditResponse;

	private List<AuditLog> auditLogList;

	private List<ContactDetailsDTO> contactDetailsList;

	private List<RelationshipDTO> relationDetailsList;

	public List<RelationshipDTO> getRelationDetailsList() {
		return relationDetailsList;
	}

	public void setRelationDetailsList(List<RelationshipDTO> relationDetailsList) {
		this.relationDetailsList = relationDetailsList;
	}

	private AuditLog auditLog;

	public AuditLog getAuditLog() {
		return auditLog;
	}

	public void setAuditLog(AuditLog auditLog) {
		this.auditLog = auditLog;
	}

	public TIProcess getTiProcess1() {
		return tiProcess1;
	}

	public void setTiProcess1(TIProcess tiProcess1) {
		this.tiProcess1 = tiProcess1;
	}

	public List<ContactDetailsDTO> getContactDetailsList() {
		return contactDetailsList;
	}

	public void setContactDetailsList(List<ContactDetailsDTO> contactDetailsList) {
		this.contactDetailsList = contactDetailsList;
	}

	public List<AuditLog> getAuditLogList() {
		return auditLogList;
	}

	public void setAuditLogList(List<AuditLog> auditLogList) {
		this.auditLogList = auditLogList;
	}

	public Long getTiRequest() {
		return tiRequest;
	}

	public void setTiRequest(Long tiRequest) {
		this.tiRequest = tiRequest;
	}

	public Long getTiProcess() {
		return tiProcess;
	}

	public void setTiProcess(Long tiProcess) {
		this.tiProcess = tiProcess;
	}

	public List<TIMailAudit> getTiMailAuditList() {
		return tiMailAuditList;
	}

	public void setTiMailAuditList(List<TIMailAudit> tiMailAuditList) {
		this.tiMailAuditList = tiMailAuditList;
	}

	public Long getEmailAuditTrailID() {
		return emailAuditTrailID;
	}

	public void setEmailAuditTrailID(Long emailAuditTrailID) {
		this.emailAuditTrailID = emailAuditTrailID;
	}

	public TIMailAudit getTiMailAudit() {
		return tiMailAudit;
	}

	public void setTiMailAudit(TIMailAudit tiMailAudit) {
		this.tiMailAudit = tiMailAudit;
	}

	public TIMailAuditResponse getTiMailAuditResponse() {
		return tiMailAuditResponse;
	}

	public void setTiMailAuditResponse(TIMailAuditResponse tiMailAuditResponse) {
		this.tiMailAuditResponse = tiMailAuditResponse;
	}

	
	public TIProcess getAuditTrail(TIProcess tiProcess1) {
		return ccrBeanFactory.getAuditTrialPersistable().getAuditTrail(tiProcess1);
	}

	
	public List<TIMailAudit> getEMailAuditTrailList() {
		return ccrBeanFactory.getAuditTrialPersistable().getEMailAuditTrailList(this);
	}

	
	public TIRequest getTIRequestDetails(Long tirequestid) {
		return ccrBeanFactory.getAuditTrialPersistable().getTIRequest(tirequestid);
	}

	
	public TIMailAudit getEMailAuditTrail() {
		return ccrBeanFactory.getAuditTrialPersistable().getEMailAuditTrail(this);
	}

	
	public List<AuditLog> getAdminChangeDetails(Long processID) {
		return ccrBeanFactory.getAuditTrialPersistable().getAdminChangeDetails(processID);
	}

	
	public List<ContactDetailsDTO> getContactsDetails(Long contactID,
			String objectName, String entry) {
		return ccrBeanFactory.getAuditTrialPersistable().getContactsDetails(contactID, objectName,
				entry);
	}

	
	public List<RelationshipDTO> getRelationshipDetails(Long relationID) {
		return ccrBeanFactory.getAuditTrialPersistable().getRelationshipDetails(relationID);
	}

	
	public TIMailAuditResponse getResponseEMailAuditTrail() {
		return ccrBeanFactory.getAuditTrialPersistable().getResponseEMailAuditTrail(this);
	}

}
