package com.citigroup.cgti.c3par.audit.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.audit.domain.AuditTrailProcess;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.common.domain.AuditLog;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditResponse;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface AuditTrialPersistable extends Persistable {

	public TIProcess getAuditTrail(TIProcess tiProcess);

	List<TIMailAudit> getEMailAuditTrailList(AuditTrailProcess auditTrailProcess);

	TIMailAudit getEMailAuditTrail(AuditTrailProcess auditTrailProcess);

	TIMailAuditResponse getResponseEMailAuditTrail(
			AuditTrailProcess auditTrailProcess);

	List<AuditLog> getAdminChangeDetails(Long processID);

	List<ContactDetailsDTO> getContactsDetails(Long contactID,
			String objectName, String entry);

	List<RelationshipDTO> getRelationshipDetails(Long relationID);
}
