package com.citigroup.cgti.c3par.bpm.ejb.mailmodule;


/**
 * The Class MailModuleException.
 */
public class MailModuleException extends Exception {

	/**
	 * Instantiates a new mail module exception.
	 */
	MailModuleException(){
		super();
	}
	
	/**
	 * Instantiates a new mail module exception.
	 *
	 * @param message the message
	 */
	MailModuleException(String message){
		super(message);
	}
}
