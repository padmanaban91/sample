package com.citigroup.cgti.c3par.connection.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionCPFirewall.
 */
public class ConnectionCPFirewall extends PerformerPagerDO {



    /** The firewall policy master. */
    private ConnectionFWPolicyMaster firewallPolicyMaster;

    /** The check point name. */
    private String checkPointName;

    /** The created date. */
    private Date createdDate;

    /** The updated date. */
    private Date updatedDate;

    //netinfo data added
    /** The type. */
    private String type;

    /** The ip address. */
    private String ipAddress;

    /** The building name. */
    private String buildingName;

    /** The address1. */
    private String address1;

    /** The city. */
    private String city;

    /** The county. */
    private String county;

    /** The country. */
    private String country;

    /** The region. */
    private String region;

    /** The approver groups. */
    private String approverGroups;

    /** The device id. */
    private String deviceId;

    /** The net info delete flag. */
    private String netInfoDeleteFlag;

    /** The location. */
    private String location;

    /** The delete flag. */
    private String deleteFlag;


    /**
     * Gets the location.
     *
     * @return the location
     */
    public String getLocation() {
	return location;
    }


    /**
     * Sets the location.
     *
     * @param location the new location
     */
    public void setLocation(String location) {
	this.location = location;
    }


    /**
     * Instantiates a new connection cp firewall.
     */
    public ConnectionCPFirewall() {
	setTableName(PerformerTypes.CON_FW_CHECKPOINT);
	setSequenceName(PerformerTypes.CON_FW_CHECKPOINT_SEQ);
	// ----------
	addToDBMapping("checkPointName", "FIREWALL_CHECKPOINT_NAME",1);
	addToDBMapping("createdDate", "CREATED_DATE",2);
	addToDBMapping("updatedDate", "UPDATED_DATE",3);
	addToNonPersistanceList("firewallPolicyMaster");
	addToNonPersistanceList("type");
	addToNonPersistanceList("ipAddress");
	addToNonPersistanceList("buildingName");
	addToNonPersistanceList("address1");
	addToNonPersistanceList("city");
	addToNonPersistanceList("county");
	addToNonPersistanceList("country");
	addToNonPersistanceList("region");
	addToNonPersistanceList("approverGroups");
	addToNonPersistanceList("deviceId");
	addToNonPersistanceList("netInfoDeleteFlag");
	addToNonPersistanceList("location");
	addToDBMapping("deleteFlag","delete_flag",4);
	addToParentsMap("com.citigroup.cgti.c3par.connection.domain.ConnectionFWPolicyMaster" , "FIREWALL_POLICY_ID");

    }



    /**
     * Gets the delete flag.
     *
     * @return the delete flag
     */
    public String getDeleteFlag() {
	return deleteFlag;
    }


    /**
     * Sets the delete flag.
     *
     * @param deleteFlag the new delete flag
     */
    public void setDeleteFlag(String deleteFlag) {
	this.deleteFlag = deleteFlag;
    }


    /**
     * Gets the check point name.
     *
     * @return the check point name
     */
    public String getCheckPointName() {
	return checkPointName;
    }

    /**
     * Sets the check point name.
     *
     * @param checkPointName the new check point name
     */
    public void setCheckPointName(String checkPointName) {
	this.checkPointName = checkPointName;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public Date getCreatedDate() {
	return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate the new created date
     */
    public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
    }

    /**
     * Gets the firewall policy master.
     *
     * @return the firewall policy master
     */
    public ConnectionFWPolicyMaster getFirewallPolicyMaster() {
	return firewallPolicyMaster;
    }

    /**
     * Sets the firewall policy master.
     *
     * @param firewallPolicyMaster the new firewall policy master
     */
    public void setFirewallPolicyMaster(
	    ConnectionFWPolicyMaster firewallPolicyMaster) {
	this.firewallPolicyMaster = firewallPolicyMaster;
    }

    /**
     * Gets the updated date.
     *
     * @return the updated date
     */
    public Date getUpdatedDate() {
	return updatedDate;
    }

    /**
     * Sets the updated date.
     *
     * @param updatedDate the new updated date
     */
    public void setUpdatedDate(Date updatedDate) {
	this.updatedDate = updatedDate;
    }


    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
	return type;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(String type) {
	this.type = type;
    }

    /**
     * Gets the ip address.
     *
     * @return the ip address
     */
    public String getIpAddress() {
	return ipAddress;
    }

    /**
     * Sets the ip address.
     *
     * @param ipAddress the new ip address
     */
    public void setIpAddress(String ipAddress) {
	this.ipAddress = ipAddress;
    }

    /**
     * Gets the building name.
     *
     * @return the building name
     */
    public String getBuildingName() {
	return buildingName;
    }

    /**
     * Sets the building name.
     *
     * @param buildingName the new building name
     */
    public void setBuildingName(String buildingName) {
	this.buildingName = buildingName;
    }

    /**
     * Gets the address1.
     *
     * @return the address1
     */
    public String getAddress1() {
	return address1;
    }

    /**
     * Sets the address1.
     *
     * @param address1 the new address1
     */
    public void setAddress1(String address1) {
	this.address1 = address1;
    }

    /**
     * Gets the city.
     *
     * @return the city
     */
    public String getCity() {
	return city;
    }

    /**
     * Sets the city.
     *
     * @param city the new city
     */
    public void setCity(String city) {
	this.city = city;
    }

    /**
     * Gets the county.
     *
     * @return the county
     */
    public String getCounty() {
	return county;
    }

    /**
     * Sets the county.
     *
     * @param county the new county
     */
    public void setCounty(String county) {
	this.county = county;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
	return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
	this.country = country;
    }

    /**
     * Gets the region.
     *
     * @return the region
     */
    public String getRegion() {
	return region;
    }

    /**
     * Sets the region.
     *
     * @param region the new region
     */
    public void setRegion(String region) {
	this.region = region;
    }

    /**
     * Gets the approver groups.
     *
     * @return the approver groups
     */
    public String getApproverGroups() {
	return approverGroups;
    }

    /**
     * Sets the approver groups.
     *
     * @param approverGroups the new approver groups
     */
    public void setApproverGroups(String approverGroups) {
	this.approverGroups = approverGroups;
    }

    /**
     * Gets the device id.
     *
     * @return the device id
     */
    public String getDeviceId() {
	return deviceId;
    }

    /**
     * Sets the device id.
     *
     * @param deviceId the new device id
     */
    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }


    /**
     * Gets the net info delete flag.
     *
     * @return the net info delete flag
     */
    public String getNetInfoDeleteFlag() {
	return netInfoDeleteFlag;
    }


    /**
     * Sets the net info delete flag.
     *
     * @param netInfoDeleteFlag the new net info delete flag
     */
    public void setNetInfoDeleteFlag(String netInfoDeleteFlag) {
	this.netInfoDeleteFlag = netInfoDeleteFlag;
    }

}
