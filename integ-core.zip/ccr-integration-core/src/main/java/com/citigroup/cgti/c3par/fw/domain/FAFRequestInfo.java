/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.domain.Person;

/**
 * @author bs45969
 * 
 */
public class FAFRequestInfo {
	
	private long tiRequest;
    private Long originalConnectionRequestId;
    private Long planningEntityId;
    /**
	 * @return the planningEntityId
	 */
	public Long getPlanningEntityId() {
		return planningEntityId;
	}
	/**
	 * @param planningEntityId the planningEntityId to set
	 */
	public void setPlanningEntityId(Long planningEntityId) {
		this.planningEntityId = planningEntityId;
	}
	private String connectionName;
    private Person requestor = new Person();
    private Person currCycleRequestor = new Person();
    private ArrayList origBusJustification = new ArrayList();
    private ArrayList businessContacts = new ArrayList();
    private ArrayList applicationList = new ArrayList();
    private String cabApprovers;
    /** The faf spl instruction. */
    private String fafSplInstruction;

    /** The faf completion date. */
    private String fafCompletionDate;

    /** The faf infoman id. */
    private String fafInfomanId;
    private String isIpReg;
    /**
	 * @return the fafSplInstruction
	 */
	public String getFafSplInstruction() {
		return fafSplInstruction;
	}
	/**
	 * @param fafSplInstruction the fafSplInstruction to set
	 */
	public void setFafSplInstruction(String fafSplInstruction) {
		this.fafSplInstruction = fafSplInstruction;
	}
	/**
	 * @return the fafCompletionDate
	 */
	public String getFafCompletionDate() {
		return fafCompletionDate;
	}
	/**
	 * @param fafCompletionDate the fafCompletionDate to set
	 */
	public void setFafCompletionDate(String fafCompletionDate) {
		this.fafCompletionDate = fafCompletionDate;
	}
	/**
	 * @return the fafInfomanId
	 */
	public String getFafInfomanId() {
		return fafInfomanId;
	}
	/**
	 * @param fafInfomanId the fafInfomanId to set
	 */
	public void setFafInfomanId(String fafInfomanId) {
		this.fafInfomanId = fafInfomanId;
	}
	/**
	 * @return the applicationList
	 */
	public ArrayList getApplicationList() {
		return applicationList;
	}
	/**
	 * @param applicationList the applicationList to set
	 */
	public void setApplicationList(ArrayList applicationList) {
		this.applicationList = applicationList;
	}
	private String cmpID;
    private String sowNumber;
    private String fireflowFlag;
    private String displayUrl;
    private String relationshipId;
    private String relationshipName;
    private String buName;
    /**
	 * @return the currBusJustfication
	 */
	public String getCurrBusJustfication() {
		return currBusJustfication;
	}
	/**
	 * @param currBusJustfication the currBusJustfication to set
	 */
	public void setCurrBusJustfication(String currBusJustfication) {
		this.currBusJustfication = currBusJustfication;
	}
	private String rationale;
    private String currBusJustfication;
     
    /**
	 * @return the rationale
	 */
	public String getRationale() {
		return rationale;
	}
	/**
	 * @param rationale the rationale to set
	 */
	public void setRationale(String rationale) {
		this.rationale = rationale;
	}
	/**
	 * @return the relationshipId
	 */
	public String getRelationshipId() {
		return relationshipId;
	}
	/**
	 * @param relationshipId the relationshipId to set
	 */
	public void setRelationshipId(String relationshipId) {
		this.relationshipId = relationshipId;
	}
	/**
	 * @return the relationshipName
	 */
	public String getRelationshipName() {
		return relationshipName;
	}
	/**
	 * @param relationshipName the relationshipName to set
	 */
	public void setRelationshipName(String relationshipName) {
		this.relationshipName = relationshipName;
	}
	/**
	 * @return the buName
	 */
	public String getBuName() {
		return buName;
	}
	/**
	 * @param buName the buName to set
	 */
	public void setBuName(String buName) {
		this.buName = buName;
	}
	private Integer versionNumber;
    
    
    /**
     * @return the originalConnectionRequestId
     */
    public Long getOriginalConnectionRequestId() {
        return originalConnectionRequestId;
    }
    /**
     * @param originalConnectionRequestId the originalConnectionRequestId to set
     */
    public void setOriginalConnectionRequestId(Long originalConnectionRequestId) {
        this.originalConnectionRequestId = originalConnectionRequestId;
    }
    /**
     * @return the connectionName
     */
    public String getConnectionName() {
        return connectionName;
    }
    /**
     * @param connectionName the connectionName to set
     */
    public void setConnectionName(String connectionName) {
        this.connectionName = connectionName;
    }
    /**
     * @return the requestor
     */
    public Person getRequestor() {
        return requestor;
    }
    /**
     * @param requestor the requestor to set
     */
    public void setRequestor(Person requestor) {
        this.requestor = requestor;
    }
    /**
     * @return the currCycleRequestor
     */
    public Person getCurrCycleRequestor() {
        return currCycleRequestor;
    }
    /**
     * @param currCycleRequestor the currCycleRequestor to set
     */
    public void setCurrCycleRequestor(Person currCycleRequestor) {
        this.currCycleRequestor = currCycleRequestor;
    }
    /**
     * @return the origBusJustification
     */
    public ArrayList getOrigBusJustification() {
        return origBusJustification;
    }
    /**
     * @param origBusJustification the origBusJustification to set
     */
    public void setOrigBusJustification(ArrayList origBusJustification) {
        this.origBusJustification = origBusJustification;
    }
    /**
     * @return the businessContacts
     */
    public ArrayList getBusinessContacts() {
        return businessContacts;
    }
    /**
     * @param businessContacts the businessContacts to set
     */
    public void setBusinessContacts(ArrayList businessContacts) {
        this.businessContacts = businessContacts;
    }
    /**
     * @return the cmpID
     */
    public String getCmpID() {
        return cmpID;
    }
    /**
     * @param cmpID the cmpID to set
     */
    public void setCmpID(String cmpID) {
        this.cmpID = cmpID;
    }
    /**
     * @return the sowNumber
     */
    public String getSowNumber() {
        return sowNumber;
    }
    /**
     * @param sowNumber the sowNumber to set
     */
    public void setSowNumber(String sowNumber) {
        this.sowNumber = sowNumber;
    }
	public long getTiRequest() {
		return tiRequest;
	}
	public void setTiRequest(long tiRequest) {
		this.tiRequest = tiRequest;
	}
	public String getDisplayUrl() {
		return displayUrl;
	}
	public void setDisplayUrl(String displayUrl) {
		this.displayUrl = displayUrl;
	}
	public String getFireflowFlag() {
		return fireflowFlag;
	}
	public void setFireflowFlag(String fireflowFlag) {
		this.fireflowFlag = fireflowFlag;
	}
	public Integer getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(Integer versionNumber) {
		this.versionNumber = versionNumber;
	}
	public void setIsIpReg(String isIpReg) {
		this.isIpReg = isIpReg;
	}
	public String getIsIpReg() {
		return isIpReg;
	}
	public void setCabApprovers(String cabApprovers) {
		this.cabApprovers = cabApprovers;
	}
	public String getCabApprovers() {
		return cabApprovers;
	}
	
}
