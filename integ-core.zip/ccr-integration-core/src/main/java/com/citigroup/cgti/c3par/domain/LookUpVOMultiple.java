
/*
 * Created on Aug 8, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.domain;


/**
 * The Class LookUpVOMultiple.
 *
 * @author nu29793
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LookUpVOMultiple {

    /** The name1. */
    private String name1;

    /** The name2. */
    private String name2;

    /** The id. */
    private long id;


    /**
     * Sets the name1.
     *
     * @param name1 the new name1
     */
    public void setName1(String name1) {
	this.name1 = name1;
    }

    /**
     * Gets the name1.
     *
     * @return the name1
     */
    public String getName1() {
	return this.name1;
    }

    /**
     * Sets the name2.
     *
     * @param name2 the new name2
     */
    public void setName2(String name2) {
	this.name2 = name2;
    }

    /**
     * Gets the name2.
     *
     * @return the name2
     */
    public String getName2() {
	return this.name2;
    }

    /**
     * Sets the value.
     *
     * @param id the new value
     */
    public void setValue(long id) {
	this.id = id;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public long getValue() {
	return this.id;
    }

}


