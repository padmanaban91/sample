package com.citigroup.cgti.c3par.bpm.ejb.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



// TODO: Auto-generated Javadoc
/**
 * The Class TIProcessDTO.
 */
/**
 * @author mc29085
 *
 */
public class TIProcessDTO implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -2106830829533456983L;
    //tiProcess properties	
    /** The id. */
    private Long id;

    /** The name. */
    private String name;
    //connection/ip
    /** The process type. */
    private String processType;

    /** The version number. */
    private int versionNumber;     
    //private String tiProcessStatus; 
    //	could be 'New','Rework','Reconsile'
    /** The process mode. */
    private String processMode;

    /** The priority. */
    private String priority;

    /** The region. */
    private String region;

    /** The sector. */
    private String sector;

    /** The business unit. */
    private String businessUnit;

    /** The entitlement. */
    private String entitlement;

    /** The end point a res type. */
    private String endPointAResType;

    /** The end point b res type. */
    private String endPointBResType;

    /** The faf version number. */
    private String fafVersionNumber;

    /** The is high risk. */
    private String isHighRisk;

    /** The is broad access. */
    private String isBroadAccess;

    /** The bus jus participants. */
    private String busJusParticipants;

    /** The tec arc participants. */
    private String tecArcParticipants;

    /** The firewall type. */
    private String firewallType;

    /** The firewall region. */
    private String firewallRegion;

    /** The firewall location. */
    private String firewallLocation;

    /** The is acl variance. */
    private String isACLVariance;

    /** The acv deadline. */
    private Date acvDeadline;

    /** The activation expiry date. */
    private Date activationExpiryDate;

    /** The activity data dto list. */
    private List activityDataDTOList=new ArrayList();

    /** The temp approval flag. */
    private String tempApprovalFlag;

    //tiRequest properties	
    /** The ti request id. */
    private Long tiRequestId;
    //remove it
    //private int tiReqVersionNumber;
    //create /maintain/teminate/acv
    /** The ti req type. */
    private String tiReqType;

    /** The request deadline. */
    private Date requestDeadline;

    /** The Planned completion date. */
    private Date PlannedCompletionDate;

    /** The TPASWG review date. */
    private Date TPASWGReviewDate;

    /** The TPASWG temp approval date. */
    private Date TPASWGTempApprovalDate;

    /** The supp review roles. */
    private List suppReviewRoles= new ArrayList();

    //Relationship Domain properties	
    /** The relationship id. */
    private Long relationshipId;

    /** The relationship name. */
    private String relationshipName;

    /** The CaspId */
    private Long caspId;
    
    /** The Casp Detail Id */
    private Long caspDetailId;
    
	/** The relationship type. */
    private String relationshipType;

    /** The requestor soe id. */
    private String requestorSOEId;

    /** The relationship status. */
    private String relationshipStatus;

    /** The bulk request. */
    private String bulkRequest;

    /** The appsense type. */
    private String appsenseType;

    /** The proxy region. */
    private String proxyRegion;

    /** The proxy type. */
    private String proxyType;


    /** The tpa flag. */
    private String tpaFlag;

    /** The Ofac  flag. */
    private String ofacFlag;
    
    /** The is high risk. */
    private String isHighRiskTIReq;

    /** The is broad access. */
    private String isBroadAccessTIReq;
    
    /** The tpa flag. */
    private String tpaFlagTIReq;

    /** The isIPReg flag. */
    private String isIPReg;
    
    private Double connAggregate;
    
    
	private Double vendorAggregate;

    /** The activity data dto. */
    private ActivityDataDTO activityDataDto=new ActivityDataDTO();
    /** The tpa flag. */
    private String ofacFlagTIReq;

    /*// ActivityData domain properties
	private Long activityId;
	private String activityName;
	private String activityStage;
	private String activityType;

	//	TODO check if the below properties are requires
	private String userRole;
	private String infoUserRole;
	private String activityLockedBy;*/



    /** The Constant CONNECTION. */
    public static final String CONNECTION = "Connection";

    /** The Constant IPREGISTRATION. */
    public static final String IPREGISTRATION = "IP";

    // TIRequest 
    /** The Constant CREATE. */
    public static final String CREATE = "Create";

    /** The Constant MAINTAIN. */
    public static final String MAINTAIN = "Maintain";

    /** The Constant TERMINATE. */
    public static final String TERMINATE = "Teminate";

    /** The Constant ACV. */
    public static final String ACV = "ACV";

    /** The Constant DISPLAY_PLANNING. */
    public static final String DISPLAY_PLANNING = "Planning";

    /** The Constant DISPLAY_MAINTAIN. */
    public static final String DISPLAY_MAINTAIN = "Maintenance";

    /** The Constant DISPLAY_TERMINATE. */
    public static final String DISPLAY_TERMINATE = "Termination";

    /** The Constant DISPLAY_ACV. */
    public static final String DISPLAY_ACV = "ACV";

    /** The Constant SYSTEM_USER. */
    public static final String SYSTEM_USER="system";


    /** The Constant BAU. */
    public static final String BAU="BAU";

    /** The Constant BUSCRIT. */
    public static final String BUSCRIT="BUSCRIT";

    /** The Constant EMER. */
    public static final String EMER="EMER";

    //flags
    /** The Constant ACL_FLAG. */
    public static final String ACL_FLAG ="isAcl";

    /** The Constant HIGH_RISK_FLAG. */
    public static final String HIGH_RISK_FLAG="isHighRisk";

    /** The Constant BROAD_ACCESS_FLAG. */
    public static final String BROAD_ACCESS_FLAG="isBroadAccess";

    /** The Constant SEC_ENGG_FLAG. */
    public static final String SEC_ENGG_FLAG="isSecEngg";

    /** The Constant OSTIA_COMPLETE_FLAG. */
    public static final String OSTIA_COMPLETE_FLAG="ostiaComplete";

    /** The Constant RELATIONSHIP_COMPLETE_FLAG. */
    public static final String RELATIONSHIP_COMPLETE_FLAG="relationshipComplete";

    /** The Constant APPSENSE_REQD_FLAG. */
    public static final String APPSENSE_REQD_FLAG="isAppsense";

    /** The Constant PROXY_REQD_FLAG. */
    public static final String PROXY_REQD_FLAG="isProxy";

    /** The Constant FW_IMPLEMENTATION_REQD_FLAG. */
    public static final String FW_IMPLEMENTATION_REQD_FLAG="isFWImplementation";
    
    /** The Constant IPREG_IMPLEMENTATION_REQD_FLAG. */
    public static final String IPREG_IMPLEMENTATION_REQD_FLAG="isIPREGImplementation";

    /** The Constant GNCC_REQD_FLAG. */
    public static final String GNCC_REQD_FLAG="isACL";

    /** The Constant TPA_RISK_FLAG. */
    public static final String TPA_RISK_FLAG="isTPA";
    /** The Constant TPA_RISK_FLAG. */
    public static final String OFAC_RISK_FLAG="isOFAC";
    
    /** The Constant FIREFLOW_CONTROL_FLAG. */
    public static final String FIREFLOW_CONTROL_FLAG="isFireflow";
    
    /** The Constant FIREFLOW_NOTIFY_FLAG. */
    public static final String FIREFLOW_NOTIFY_FLAG="fireflowNotify";
    
    /** The Constant ECM_FLAG. */
    public static final String ECM_FLAG="isECM";

    public static final String IPREG_FLAG="isIPReg";
    
    public static final String DENY_FLAG ="isDeny";
    
    
    
    public String getOfacFlagTIReq() {
		return ofacFlagTIReq;
	}
	public void setOfacFlagTIReq(String ofacFlagTIReq) {
		this.ofacFlagTIReq = ofacFlagTIReq;
	}
	/**
     * Gets the OfacFlag
     *
     * @return the OfacFlag
     */
    public String getOfacFlag() {
		return ofacFlag;
	}
    /**
     * Sets the ofacFlag type.
     *
     * @param ofacFlag the new ofacFlag type
     */

	public void setOfacFlag(String ofacFlag) {
		this.ofacFlag = ofacFlag;
	}

	/**
     * Gets the appsense type.
     *
     * @return the appsense type
     */
    public String getAppsenseType() {
	return appsenseType;
    }

    /**
     * Sets the appsense type.
     *
     * @param appsenseType the new appsense type
     */
    public void setAppsenseType(String appsenseType) {
	this.appsenseType = appsenseType;
    }

    /**
     * Gets the proxy region.
     *
     * @return the proxy region
     */
    public String getProxyRegion() {
	return proxyRegion;
    }

    /**
     * Sets the proxy region.
     *
     * @param proxyRegion the new proxy region
     */
    public void setProxyRegion(String proxyRegion) {
	this.proxyRegion = proxyRegion;
    }

    /**
     * Gets the proxy type.
     *
     * @return the proxy type
     */
    public String getProxyType() {
	return proxyType;
    }

    /**
     * Sets the proxy type.
     *
     * @param proxyType the new proxy type
     */
    public void setProxyType(String proxyType) {
	this.proxyType = proxyType;
    }

    /**
     * Gets the bulk request.
     *
     * @return the bulk request
     */
    public String getBulkRequest() {
	return bulkRequest;
    }

    /**
     * Sets the bulk request.
     *
     * @param bulkRequest the new bulk request
     */
    public void setBulkRequest(String bulkRequest) {
	this.bulkRequest = bulkRequest;
    }

    /**
     * Gets the business unit.
     *
     * @return the business unit
     */
    public String getBusinessUnit() {
	return businessUnit;
    }

    /**
     * Sets the business unit.
     *
     * @param businessUnit the new business unit
     */
    public void setBusinessUnit(String businessUnit) {
	this.businessUnit = businessUnit;
    }

    /**
     * Gets the bus jus participants.
     *
     * @return the bus jus participants
     */
    public String getBusJusParticipants() {
	return busJusParticipants;
    }

    /**
     * Sets the bus jus participants.
     *
     * @param busJusParticipants the new bus jus participants
     */
    public void setBusJusParticipants(String busJusParticipants) {
	this.busJusParticipants = busJusParticipants;
    }

    /**
     * Gets the end point a res type.
     *
     * @return the end point a res type
     */
    public String getEndPointAResType() {
	return endPointAResType;
    }

    /**
     * Sets the end point a res type.
     *
     * @param endPointAResType the new end point a res type
     */
    public void setEndPointAResType(String endPointAResType) {
	this.endPointAResType = endPointAResType;
    }

    /**
     * Gets the end point b res type.
     *
     * @return the end point b res type
     */
    public String getEndPointBResType() {
	return endPointBResType;
    }

    /**
     * Sets the end point b res type.
     *
     * @param endPointBResType the new end point b res type
     */
    public void setEndPointBResType(String endPointBResType) {
	this.endPointBResType = endPointBResType;
    }



    /**
     * Gets the faf version number.
     *
     * @return the faf version number
     */
    public String getFafVersionNumber() {
	return fafVersionNumber;
    }

    /**
     * Sets the faf version number.
     *
     * @param fafVersionNumber the new faf version number
     */
    public void setFafVersionNumber(String fafVersionNumber) {
	this.fafVersionNumber = fafVersionNumber;
    }

    /**
     * Gets the firewall region.
     *
     * @return the firewall region
     */
    public String getFirewallRegion() {
	return firewallRegion;
    }

    /**
     * Sets the firewall region.
     *
     * @param firewallRegion the new firewall region
     */
    public void setFirewallRegion(String firewallRegion) {
	this.firewallRegion = firewallRegion;
    }

    /**
     * Gets the firewall type.
     *
     * @return the firewall type
     */
    public String getFirewallType() {
	return firewallType;
    }

    /**
     * Sets the firewall type.
     *
     * @param firewallType the new firewall type
     */
    public void setFirewallType(String firewallType) {
	this.firewallType = firewallType;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
	return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
	this.id = id;
    }

    /**
     * Gets the checks if is acl variance.
     *
     * @return the checks if is acl variance
     */
    public String getIsACLVariance() {
	return isACLVariance;
    }

    /**
     * Sets the checks if is acl variance.
     *
     * @param isACLVariance the new checks if is acl variance
     */
    public void setIsACLVariance(String isACLVariance) {
	this.isACLVariance = isACLVariance;
    }

    /**
     * Gets the checks if is broad access.
     *
     * @return the checks if is broad access
     */
    public String getIsBroadAccess() {
	return isBroadAccess;
    }

    /**
     * Sets the checks if is broad access.
     *
     * @param isBroadAccess the new checks if is broad access
     */
    public void setIsBroadAccess(String isBroadAccess) {
	this.isBroadAccess = isBroadAccess;
    }

    /**
     * Gets the checks if is high risk.
     *
     * @return the checks if is high risk
     */
    public String getIsHighRisk() {
	return isHighRisk;
    }

    /**
     * Sets the checks if is high risk.
     *
     * @param isHighRisk the new checks if is high risk
     */
    public void setIsHighRisk(String isHighRisk) {
	this.isHighRisk = isHighRisk;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
	return name;
    }

    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name) {
	this.name = name;
    }

    /**
     * Gets the planned completion date.
     *
     * @return the planned completion date
     */
    public Date getPlannedCompletionDate() {
	return PlannedCompletionDate;
    }

    /**
     * Sets the planned completion date.
     *
     * @param plannedCompletionDate the new planned completion date
     */
    public void setPlannedCompletionDate(Date plannedCompletionDate) {
	PlannedCompletionDate = plannedCompletionDate;
    }

    /**
     * Gets the priority.
     *
     * @return the priority
     */
    public String getPriority() {
	return priority;
    }

    /**
     * Sets the priority.
     *
     * @param priority the new priority
     */
    public void setPriority(String priority) {
	this.priority = priority;
    }



    /**
     * Gets the process type.
     *
     * @return the process type
     */
    public String getProcessType() {
	return processType;
    }

    /**
     * Sets the process type.
     *
     * @param processType the new process type
     */
    public void setProcessType(String processType) {
	this.processType = processType;
    }

    /**
     * Gets the relationship id.
     *
     * @return the relationship id
     */
    public Long getRelationshipId() {
	return relationshipId;
    }

    /**
     * Sets the relationship id.
     *
     * @param relationshipId the new relationship id
     */
    public void setRelationshipId(Long relationshipId) {
	this.relationshipId = relationshipId;
    }

    /**
     * Gets the relationship name.
     *
     * @return the relationship name
     */
    public String getRelationshipName() {
	return relationshipName;
    }

    /**
     * Sets the relationship name.
     *
     * @param relationshipName the new relationship name
     */
    public void setRelationshipName(String relationshipName) {
	this.relationshipName = relationshipName;
    }

    /**
     * Gets the relationship type.
     *
     * @return the relationship type
     */
    public String getRelationshipType() {
	return relationshipType;
    }

    /**
     * Sets the relationship type.
     *
     * @param relationshipType the new relationship type
     */
    public void setRelationshipType(String relationshipType) {
	this.relationshipType = relationshipType;
    }

    /**
     * Gets the request deadline.
     *
     * @return the request deadline
     */
    public Date getRequestDeadline() {
	return requestDeadline;
    }

    /**
     * Sets the request deadline.
     *
     * @param requestDeadline the new request deadline
     */
    public void setRequestDeadline(Date requestDeadline) {
	this.requestDeadline = requestDeadline;
    }

    /**
     * Gets the requestor soe id.
     *
     * @return the requestor soe id
     */
    public String getRequestorSOEId() {
	return requestorSOEId;
    }

    /**
     * Sets the requestor soe id.
     *
     * @param requestorSOEId the new requestor soe id
     */
    public void setRequestorSOEId(String requestorSOEId) {
	this.requestorSOEId = requestorSOEId;
    }

    /**
     * Gets the sector.
     *
     * @return the sector
     */
    public String getSector() {
	return sector;
    }

    /**
     * Sets the sector.
     *
     * @param sector the new sector
     */
    public void setSector(String sector) {
	this.sector = sector;
    }

    /**
     * Gets the tec arc participants.
     *
     * @return the tec arc participants
     */
    public String getTecArcParticipants() {
	return tecArcParticipants;
    }

    /**
     * Sets the tec arc participants.
     *
     * @param tecArcParticipants the new tec arc participants
     */
    public void setTecArcParticipants(String tecArcParticipants) {
	this.tecArcParticipants = tecArcParticipants;
    }

    /**
     * Gets the ti req type.
     *
     * @return the ti req type
     */
    public String getTiReqType() {
	return tiReqType;
    }

    /**
     * Sets the ti req type.
     *
     * @param tiReqType the new ti req type
     */
    public void setTiReqType(String tiReqType) {
	this.tiReqType = tiReqType;
    }

    /**
     * Gets the ti request id.
     *
     * @return the ti request id
     */
    public Long getTiRequestId() {
	return tiRequestId;
    }

    /**
     * Sets the ti request id.
     *
     * @param tiRequestId the new ti request id
     */
    public void setTiRequestId(Long tiRequestId) {
	this.tiRequestId = tiRequestId;
    }
    
    /**
     * 
     * @return
     */
    public String getRegion() {
		return region;
	}

    /**
     * 
     * @param region
     */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * 
	 * @return
	 */
	public String getEntitlement() {
		return entitlement;
	}

	/**
	 * 
	 * @param entitlement
	 */
	public void setEntitlement(String entitlement) {
		this.entitlement = entitlement;
	}

	/**
     * Gets the process mode.
     *
     * @return the process mode
     */
    public String getProcessMode() {
	return processMode;
    }

    /**
     * Sets the process mode.
     *
     * @param processMode the new process mode
     */
    public void setProcessMode(String processMode) {
	this.processMode = processMode;
    }

    /**
     * Gets the version number.
     *
     * @return the version number
     */
    public int getVersionNumber() {
	return versionNumber;
    }

    /**
     * Sets the version number.
     *
     * @param versionNumber the new version number
     */
    public void setVersionNumber(int versionNumber) {
	this.versionNumber = versionNumber;
    }


    /**
     * Gets the activity data dto.
     *
     * @return the activity data dto
     */
    public ActivityDataDTO getActivityDataDto() {
	return activityDataDto;
    }

    /**
     * Sets the activity data dto.
     *
     * @param activityDataDto the new activity data dto
     */
    public void setActivityDataDto(ActivityDataDTO activityDataDto) {
	this.activityDataDto = activityDataDto;
    }

    /**
     * Gets the relationship status.
     *
     * @return the relationship status
     */
    public String getRelationshipStatus() {
	return relationshipStatus;
    }

    /**
     * Sets the relationship status.
     *
     * @param relationshipStatus the new relationship status
     */
    public void setRelationshipStatus(String relationshipStatus) {
	this.relationshipStatus = relationshipStatus;
    }

    /**
     * Gets the activation expiry date.
     *
     * @return the activation expiry date
     */
    public Date getActivationExpiryDate() {
	return activationExpiryDate;
    }

    /**
     * Sets the activation expiry date.
     *
     * @param activationExpiryDate the new activation expiry date
     */
    public void setActivationExpiryDate(Date activationExpiryDate) {
	this.activationExpiryDate = activationExpiryDate;
    }

    /**
     * Gets the acv deadline.
     *
     * @return the acv deadline
     */
    public Date getAcvDeadline() {
	return acvDeadline;
    }

    /**
     * Sets the acv deadline.
     *
     * @param acvDeadline the new acv deadline
     */
    public void setAcvDeadline(Date acvDeadline) {
	this.acvDeadline = acvDeadline;
    }

    /**
     * Gets the tPASWG review date.
     *
     * @return the tPASWG review date
     */
    public Date getTPASWGReviewDate() {
	return TPASWGReviewDate;
    }

    /**
     * Sets the tPASWG review date.
     *
     * @param reviewDate the new tPASWG review date
     */
    public void setTPASWGReviewDate(Date reviewDate) {
	TPASWGReviewDate = reviewDate;
    }

    /**
     * Gets the tPASWG temp approval date.
     *
     * @return the tPASWG temp approval date
     */
    public Date getTPASWGTempApprovalDate() {
	return TPASWGTempApprovalDate;
    }

    /**
     * Sets the tPASWG temp approval date.
     *
     * @param tempApprovalDate the new tPASWG temp approval date
     */
    public void setTPASWGTempApprovalDate(Date tempApprovalDate) {
	TPASWGTempApprovalDate = tempApprovalDate;
    }

    /**
     * Gets the supp review roles.
     *
     * @return the supp review roles
     */
    public List getSuppReviewRoles() {
	return suppReviewRoles;
    }

    /**
     * Sets the supp review roles.
     *
     * @param suppReviewRoles the new supp review roles
     */
    public void setSuppReviewRoles(List suppReviewRoles) {
	this.suppReviewRoles = suppReviewRoles;
    }

    /**
     * Gets the activity data dto list.
     *
     * @return the activity data dto list
     */
    public List getActivityDataDTOList() {
	return activityDataDTOList;
    }

    /**
     * Sets the activity data dto list.
     *
     * @param activityDataDTOList the new activity data dto list
     */
    public void setActivityDataDTOList(List activityDataDTOList) {
	this.activityDataDTOList = activityDataDTOList;
    }

    /**
     * Gets the temp approval flag.
     *
     * @return the temp approval flag
     */
    public String getTempApprovalFlag() {
	return tempApprovalFlag;
    }

    /**
     * Sets the temp approval flag.
     *
     * @param tempApprovalFlag the new temp approval flag
     */
    public void setTempApprovalFlag(String tempApprovalFlag) {
	this.tempApprovalFlag = tempApprovalFlag;
    }

    /**
     * Gets the firewall location.
     *
     * @return the firewall location
     */
    public String getFirewallLocation() {
	return firewallLocation;
    }

    /**
     * Sets the firewall location.
     *
     * @param firewallLocation the new firewall location
     */
    public void setFirewallLocation(String firewallLocation) {
	this.firewallLocation = firewallLocation;
    }

    /**
     * Gets the tpa flag.
     *
     * @return the tpa flag
     */
    public String getTpaFlag() {
	return tpaFlag;
    }

    /**
     * Sets the tpa flag.
     *
     * @param tpaFlag the new tpa flag
     */
    public void setTpaFlag(String tpaFlag) {
	this.tpaFlag = tpaFlag;
    }

	/**
	 * @return the isHighRiskTIReq
	 */
	public String getIsHighRiskTIReq() {
		return isHighRiskTIReq;
	}

	/**
	 * @param isHighRiskTIReq the isHighRiskTIReq to set
	 */
	public void setIsHighRiskTIReq(String isHighRiskTIReq) {
		this.isHighRiskTIReq = isHighRiskTIReq;
	}

	/**
	 * @return the isBroadAccessTIReq
	 */
	public String getIsBroadAccessTIReq() {
		return isBroadAccessTIReq;
	}

	/**
	 * @param isBroadAccessTIReq the isBroadAccessTIReq to set
	 */
	public void setIsBroadAccessTIReq(String isBroadAccessTIReq) {
		this.isBroadAccessTIReq = isBroadAccessTIReq;
	}

	/**
	 * @return the tpaFlagTIReq
	 */
	public String getTpaFlagTIReq() {
		return tpaFlagTIReq;
	}

	/**
	 * @param tpaFlagTIReq the tpaFlagTIReq to set
	 */
	public void setTpaFlagTIReq(String tpaFlagTIReq) {
		this.tpaFlagTIReq = tpaFlagTIReq;
	}

	public String getIsIPReg() {
		return isIPReg;
	}

	public void setIsIPReg(String isIPReg) {
		this.isIPReg = isIPReg;
	}

    /**
     * @return caspId
     */
    public Long getCaspId() {
		return caspId;
	}

	/**
	 * @param caspId
	 */
	public void setCaspId(Long caspId) {
		this.caspId = caspId;
	}

	/**
	 * @return caspDetailId
	 */
	/**
	 * @return
	 */
	public Long getCaspDetailId() {
		return caspDetailId;
	}

	/**
	 * @param caspDetailId
	 */
	public void setCaspDetailId(Long caspDetailId) {
		this.caspDetailId = caspDetailId;
	}

	public void setConnAggregate(Double connAggregate) {
		this.connAggregate = connAggregate;
	}

	public Double getConnAggregate() {
		return connAggregate;
	}

	public void setVendorAggregate(Double vendorAggregate) {
		this.vendorAggregate = vendorAggregate;
	}

	public Double getVendorAggregate() {
		return vendorAggregate;
	}
	
}
