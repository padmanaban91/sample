package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class BaseSearchAttributes.
 */
public class BaseSearchAttributes implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -8325161116223076054L;

    /**
     * Valid string.
     *
     * @param filterText the filter text
     * @return the string
     */
    protected String validString(String filterText) {
	StringBuffer sbf = new StringBuffer();
	String retStr = null;
	if ((filterText == null) || (filterText.trim().equals("")) || (filterText.trim().equals("*"))) {
	    retStr =null;
	} else if(filterText.indexOf("*")>-1) {
	    sbf.append(filterText.replaceAll("\\*", "%"));
	    retStr = sbf.toString();
	}
	else {
	    sbf.append(filterText);
	    retStr = sbf.toString();
	}
	return retStr;

    }


    /**
     * Valid long.
     *
     * @param filterText the filter text
     * @return the long
     */
    protected Long validLong(Long filterText) {
	Long retLng = null;
	if (filterText!=null && filterText.longValue()==0) {
	    retLng =null;
	}else{
	    retLng = filterText;
	}
	return retLng;

    }

    /**
     * Valid long as string.
     *
     * @param filterText the filter text
     * @return the string
     */
    protected String validLongAsString(String filterText) {
	StringBuffer sbf = new StringBuffer();
	String retStr = null;
	if ((filterText == null) || (filterText.trim().equals("")) || (filterText.trim().equals("*"))) {
	    retStr =null;
	} else if(filterText.indexOf("*")>-1) {
	    sbf.append(filterText.replaceAll("\\*", "%"));
	    retStr = sbf.toString();
	}
	else {
	    sbf.append(filterText);
	    retStr = sbf.toString();
	}
	return retStr;

    }

}
