package com.citigroup.cgti.c3par.Exception;


/**
 * The Class OperationNotSupportedException.
 */
public class OperationNotSupportedException extends RuntimeException {


    /**
     * Instantiates a new operation not supported exception.
     *
     * @param errMsg the err msg
     */
    public OperationNotSupportedException (String errMsg){
	super(errMsg);
    }

    /**
     * Instantiates a new operation not supported exception.
     *
     * @param errMsg the err msg
     * @param xe the xe
     */
    public OperationNotSupportedException (String errMsg,Throwable xe){
	super(errMsg,xe);;
    }

}
