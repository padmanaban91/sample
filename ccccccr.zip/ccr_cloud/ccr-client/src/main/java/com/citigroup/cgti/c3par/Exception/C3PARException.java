/*
 * Created on Aug 4, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.Exception;


/**
 * The Class C3PARException.
 *
 * @author dr97938
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class C3PARException extends RuntimeException {

    /**
     * Instantiates a new c3 par exception.
     */
    C3PARException()
    {
	super();
    }

    /**
     * Instantiates a new c3 par exception.
     *
     * @param message the message
     */
    C3PARException(String message){
	super(message);
    }
    
    
    public C3PARException (String errMsg,Throwable xe){
    	super(errMsg,xe);;
    }
}
