package com.citigroup.cgti.c3par.bpm.ejb.rel.domain;

import java.io.Serializable;
import java.util.List;


/**
 * The Class RelationshipSearchAttributesDTO.
 */
public class RelationshipSearchAttributesDTO implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -2030380289915588035L;

    /** The third party id. */
    private Long thirdPartyId;

    /** The business unit id. */
    private Long businessUnitId ;

    /** The relationship name. */
    private String relationshipName = "";

    /** The relationship id. */
    private Long relationshipId;

    /** The connectivity exists. */
    private Long connectivityExists;

    /** The access citi data. */
    private Long accessCitiData;

    /** The access customer data. */
    private Long accessCustomerData;

    /** The osp service name. */
    private String ospServiceName;

    /** The is some condition set. */
    private boolean isSomeConditionSet = false ;

    /** The osp service provided. */
    private Long ospServiceProvided ;

    /** The data classification. */
    private Long dataClassification;

    /** The sso id. */
    private String ssoId;

    /** The status. */
    private String status;

    /** The requester resource type id. */
    private Long requesterResourceTypeId;

    /** The target resource type id. */
    private Long targetResourceTypeId;

    /** The relationship type. */
    private String relationshipType;

    /** The process type. */
    private String processType;

    /** The ent inst list. */
    private List entInstList;

    /** The user id. */
    private Long userId;

    /** The requester business unit id. */
    private Long requesterBusinessUnitId;

    /** The third party name. */
    private String thirdPartyName;

    /** The business unit name. */
    private String businessUnitName;

    /** The requester business unit name. */
    private String requesterBusinessUnitName;

    /** The participant id. */
    private String participantId;

    /**
     * Gets the participant id.
     *
     * @return the participantId
     */
    public String getParticipantId() {
	return participantId;
    }

    /**
     * Sets the participant id.
     *
     * @param participantId the participantId to set
     */
    public void setParticipantId(String participantId) {
	this.participantId = participantId;
    }

    /**
     * Gets the relationship type.
     *
     * @return the relationship type
     */
    public String getRelationshipType() {
	return relationshipType;
    }

    /**
     * Sets the relationship type.
     *
     * @param relationshipType the new relationship type
     */
    public void setRelationshipType(String relationshipType) {
	this.relationshipType = relationshipType;
    }

    /**
     * Gets the relationship id.
     *
     * @return Returns the relationshipId.
     */
    public Long getRelationshipId() {

	return relationshipId;
    }

    /**
     * Sets the relationship id.
     *
     * @param relationshipId The relationshipId to set.
     */
    public void setRelationshipId(Long relationshipId) {

	this.relationshipId = relationshipId;
    }

    /**
     * Gets the business unit id.
     *
     * @return Returns the businessUnitId.
     */
    public Long getBusinessUnitId() {
	return businessUnitId;
    }

    /**
     * Sets the business unit id.
     *
     * @param businessUnitId The businessUnitId to set.
     */
    public void setBusinessUnitId(Long businessUnitId) {
	this.businessUnitId = businessUnitId;
    }

    /**
     * Gets the relationship name.
     *
     * @return Returns the connectionName.
     */
    public String getRelationshipName() {
	return relationshipName;
    }

    /**
     * Sets the relationship name.
     *
     * @param relationshipName the new relationship name
     */
    public void setRelationshipName(String relationshipName) {
	this.relationshipName = relationshipName;
    }

    /**
     * Gets the third party id.
     *
     * @return Returns the thirdPartyId.
     */
    public Long getThirdPartyId() {
	return thirdPartyId;
    }

    /**
     * Sets the third party id.
     *
     * @param thirdPartyId The thirdPartyId to set.
     */
    public void setThirdPartyId(Long thirdPartyId) {
	this.thirdPartyId = thirdPartyId;
    }

    /**
     * Gets the access citi data.
     *
     * @return the access citi data
     */
    public Long getAccessCitiData() {
	return accessCitiData;
    }

    /**
     * Sets the access citi data.
     *
     * @param accessCitiData the new access citi data
     */
    public void setAccessCitiData(Long accessCitiData) {
	this.accessCitiData = accessCitiData;
    }

    /**
     * Gets the access customer data.
     *
     * @return the access customer data
     */
    public Long getAccessCustomerData() {
	return accessCustomerData;
    }

    /**
     * Sets the access customer data.
     *
     * @param accessCustomerData the new access customer data
     */
    public void setAccessCustomerData(Long accessCustomerData) {
	this.accessCustomerData = accessCustomerData;
    }

    /**
     * Gets the connectivity exists.
     *
     * @return the connectivity exists
     */
    public Long getConnectivityExists() {
	return connectivityExists;
    }

    /**
     * Sets the connectivity exists.
     *
     * @param connectivityExists the new connectivity exists
     */
    public void setConnectivityExists(Long connectivityExists) {
	this.connectivityExists = connectivityExists;
    }

    /**
     * Gets the osp service name.
     *
     * @return the osp service name
     */
    public String getOspServiceName() {
	return ospServiceName;
    }

    /**
     * Sets the osp service name.
     *
     * @param ospServiceName the new osp service name
     */
    public void setOspServiceName(String ospServiceName) {
	this.ospServiceName = ospServiceName;
    }

    /**
     * Checks if is some condition set.
     *
     * @return true, if is some condition set
     */
    public boolean isSomeConditionSet() {
	return isSomeConditionSet;
    }

    /**
     * Sets the some condition set.
     *
     * @param isSomeConditionSet the new some condition set
     */
    public void setSomeConditionSet(boolean isSomeConditionSet) {
	this.isSomeConditionSet = isSomeConditionSet;
    }

    /**
     * Gets the data classification.
     *
     * @return the data classification
     */
    public Long getDataClassification() {
	return dataClassification;
    }

    /**
     * Sets the data classification.
     *
     * @param dataClassification the new data classification
     */
    public void setDataClassification(Long dataClassification) {
	this.dataClassification = dataClassification;
    }	

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
	this.status = status;
    }

    /**
     * Gets the requester resource type id.
     *
     * @return the requester resource type id
     */
    public Long getRequesterResourceTypeId() {
	return requesterResourceTypeId;
    }

    /**
     * Sets the requester resource type id.
     *
     * @param requesterResourceTypeId the new requester resource type id
     */
    public void setRequesterResourceTypeId(Long requesterResourceTypeId) {
	this.requesterResourceTypeId = requesterResourceTypeId;
    }

    /**
     * Gets the target resource type id.
     *
     * @return the target resource type id
     */
    public Long getTargetResourceTypeId() {
	return targetResourceTypeId;
    }

    /**
     * Sets the target resource type id.
     *
     * @param targetResourceTypeId the new target resource type id
     */
    public void setTargetResourceTypeId(Long targetResourceTypeId) {
	this.targetResourceTypeId = targetResourceTypeId;
    }

    /**
     * Gets the process type.
     *
     * @return the process type
     */
    public String getProcessType() {
	return processType;
    }

    /**
     * Sets the process type.
     *
     * @param processType the new process type
     */
    public void setProcessType(String processType) {
	this.processType = processType;
    }

    /**
     * Gets the ent inst list.
     *
     * @return the ent inst list
     */
    public List getEntInstList() {
	return entInstList;
    }

    /**
     * Sets the ent inst list.
     *
     * @param entInstList the new ent inst list
     */
    public void setEntInstList(List entInstList) {
	this.entInstList = entInstList;
    }

    /**
     * Gets the user id.
     *
     * @return the user id
     */
    public Long getUserId() {
	return userId;
    }

    /**
     * Sets the user id.
     *
     * @param userId the new user id
     */
    public void setUserId(Long userId) {
	this.userId = userId;
    }

    /**
     * Gets the sso id.
     *
     * @return the ssoId
     */
    public String getSsoId() {
	return ssoId;
    }

    /**
     * Sets the sso id.
     *
     * @param ssoId the ssoId to set
     */
    public void setSsoId(String ssoId) {
	this.ssoId = ssoId;
    }

    /**
     * Gets the requester business unit id.
     *
     * @return the requesterBusinessUnitId
     */
    public Long getRequesterBusinessUnitId() {
	return requesterBusinessUnitId;
    }

    /**
     * Sets the requester business unit id.
     *
     * @param requesterBusinessUnitId the requesterBusinessUnitId to set
     */
    public void setRequesterBusinessUnitId(Long requesterBusinessUnitId) {
	this.requesterBusinessUnitId = requesterBusinessUnitId;
    }

    /**
     * Gets the osp service provided.
     *
     * @return the ospServiceProvided
     */
    public Long getOspServiceProvided() {
	return ospServiceProvided;
    }

    /**
     * Sets the osp service provided.
     *
     * @param ospServiceProvided the ospServiceProvided to set
     */
    public void setOspServiceProvided(Long ospServiceProvided) {
	this.ospServiceProvided = ospServiceProvided;
    }

    /**
     * Gets the business unit name.
     *
     * @return the businessUnitName
     */
    public String getBusinessUnitName() {
	return businessUnitName;
    }

    /**
     * Sets the business unit name.
     *
     * @param businessUnitName the businessUnitName to set
     */
    public void setBusinessUnitName(String businessUnitName) {
	this.businessUnitName = businessUnitName;
    }

    /**
     * Gets the requester business unit name.
     *
     * @return the requesterBusinessUnitName
     */
    public String getRequesterBusinessUnitName() {
	return requesterBusinessUnitName;
    }

    /**
     * Sets the requester business unit name.
     *
     * @param requesterBusinessUnitName the requesterBusinessUnitName to set
     */
    public void setRequesterBusinessUnitName(String requesterBusinessUnitName) {
	this.requesterBusinessUnitName = requesterBusinessUnitName;
    }

    /**
     * Gets the third party name.
     *
     * @return the thirdPartyName
     */
    public String getThirdPartyName() {
	return thirdPartyName;
    }

    /**
     * Sets the third party name.
     *
     * @param thirdPartyName the thirdPartyName to set
     */
    public void setThirdPartyName(String thirdPartyName) {
	this.thirdPartyName = thirdPartyName;
    }

}
