

/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright ? 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.dao.lookup;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;


/**
 * The Class ThirdPartyServiceLookup.
 */
public class ThirdPartyServiceLookup
{

    /** The initialized. */
    private boolean		initialized = false;

    /** The ordered list. */
    private ArrayList 	orderedList = new ArrayList();

    /** The values by id. */
    private HashMap		valuesById = new HashMap();

    /** The values by name. */
    private HashMap		valuesByName = new HashMap();

    /** The instance. */
    static private ThirdPartyServiceLookup instance = null;

    //======================================================================
    /**
     * Gets the single instance of ThirdPartyServiceLookup.
     *
     * @return single instance of ThirdPartyServiceLookup
     */
    synchronized static public ThirdPartyServiceLookup getInstance()
    {
	if (instance == null)
	{
	    instance = new ThirdPartyServiceLookup();
	}
	return instance;
    }

    //======================================================================
    /**
     * Gets the single instance of ThirdPartyServiceLookup.
     *
     * @param session the session
     * @return single instance of ThirdPartyServiceLookup
     * @throws DatabaseException the database exception
     */
    synchronized static public ThirdPartyServiceLookup getInstance(DatabaseSession session) throws DatabaseException
    {
	if (instance == null)
	{
	    instance = new ThirdPartyServiceLookup();
	    instance.initialize(session);	
	}
	else if(!instance.isInitialized())
	{
	    instance.initialize(session);	
	}
	return instance;
    }

    //======================================================================
    /**
     * Instantiates a new third party service lookup.
     */
    private ThirdPartyServiceLookup()
    {
	super();
	initialized = false;
    }

    //======================================================================
    /**
     * Initialize.
     *
     * @param session the session
     * @throws DatabaseException the database exception
     */
    synchronized public void initialize(DatabaseSession session) throws DatabaseException
    {
	if (!initialized)
	{
	    ThirdPartyServiceDAO dao = new ThirdPartyServiceDAO(session);
	    ThirdPartyServiceEntity entity = null;
	    Condition condition = new Condition();
	    condition.addOrderByField(ThirdPartyServiceDAO.COLUMN_NAME);
	    try
	    {
		List list = dao.query(condition, false);
		Iterator it = list.iterator();

		while (it.hasNext())
		{
		    entity = (ThirdPartyServiceEntity) it.next();
		    valuesById.put(entity.getId(), entity);
		    valuesByName.put(entity.getName(), entity);
		    orderedList.add(entity);
		}
		initialized = true;

		it = list.iterator();
		while (it.hasNext())
		{
		    entity = (ThirdPartyServiceEntity) it.next();
		    dao.loadReferences((ThirdPartyServiceEntity)entity);
		}
	    }
	    catch (DatabaseException e)
	    {
		throw e;
	    }
	}
    }

    //======================================================================
    /**
     * Reset.
     */
    synchronized public void reset()
    {
	valuesById = new HashMap();
	orderedList = new ArrayList();
	initialized = false;
	valuesByName = new HashMap();
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param id the id
     * @return the by id
     */
    synchronized public ThirdPartyServiceEntity getById(Long id)
    {
	return (ThirdPartyServiceEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param session the session
     * @param id the id
     * @return the by id
     * @throws DatabaseException the database exception
     */
    synchronized public ThirdPartyServiceEntity getById(DatabaseSession session, Long id) throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ThirdPartyServiceEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by name.
     *
     * @param v the v
     * @return the by name
     */
    synchronized public ThirdPartyServiceEntity getByName(String v)
    {
	return (ThirdPartyServiceEntity) valuesByName.get(v);
    }

    //======================================================================
    /**
     * Gets the by name.
     *
     * @param session the session
     * @param v the v
     * @return the by name
     * @throws DatabaseException the database exception
     */
    synchronized public ThirdPartyServiceEntity getByName(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ThirdPartyServiceEntity) valuesByName.get(v);
    }

    //======================================================================
    /**
     * Gets the all.
     *
     * @return the all
     */
    synchronized public ArrayList getAll()
    {
	return orderedList;
    }

    //======================================================================
    /**
     * Checks if is initialized.
     *
     * @return true, if is initialized
     */
    synchronized public boolean isInitialized()
    {
	return initialized;
    }
}
