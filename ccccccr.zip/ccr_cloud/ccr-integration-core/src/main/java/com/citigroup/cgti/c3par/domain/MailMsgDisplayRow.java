package com.citigroup.cgti.c3par.domain;

import javax.xml.bind.annotation.XmlElement;


/**
 * The Class MailMsgDisplayRow.
 */
public class MailMsgDisplayRow {

    /** The info. */
    private MailMsgDisplayInfo [] info;

    /**
     * Gets the info.
     *
     * @return the info
     */
    @XmlElement
    public MailMsgDisplayInfo[] getInfo() {
	return info;
    }

    /**
     * Sets the info.
     *
     * @param info the new info
     */
    public void setInfo(MailMsgDisplayInfo[] info) {
	this.info = info;
    }
}
