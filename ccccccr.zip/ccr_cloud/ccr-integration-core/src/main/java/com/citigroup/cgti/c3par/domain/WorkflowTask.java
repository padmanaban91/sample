package com.citigroup.cgti.c3par.domain;

import com.mentisys.bfc.util.BfcWorkItem;

import java.io.Serializable;
import java.util.Date;


/**
 * The Class WorkflowTask.
 */
public class WorkflowTask implements Serializable{

    /** The id. */
    private Long id;

    /** The requester. */
    private String requester;

    /** The process name. */
    private String processName;

    /** The process type. */
    private String processType;

    /** The due date. */
    private Date dueDate;

    /** The wor item id. */
    private String worItemId;

    /** The action. */
    private String action;

    /** The task code. */
    private String taskCode;

    /** The task name. */
    private String taskName;

    /** The process. */
    private Process process;

    /** The connection id. */
    private Long connectionId;

    /** The maintenance type. */
    private String maintenanceType;

    /** The status. */
    private String status;

    /** The planned activate date. */
    private Date plannedActivateDate;

    /** The bfc work item. */
    private BfcWorkItem bfcWorkItem;



    /** The Constant Start_IP_Registration_Process. */
    public static final String Start_IP_Registration_Process="start_workflow";

    /** The Constant Review_IP_Registration_Request_By_Manager. */
    public static final String Review_IP_Registration_Request_By_Manager="review_ip_mgr";

    /** The Constant Review_IP_Registration_Request_by_BISO. */
    public static final String Review_IP_Registration_Request_by_BISO="review_ip_biso";

    /** The Constant Approve_IP_Registration_Request. */
    public static final String Approve_IP_Registration_Request="review_ip_tpwg";

    /** The Constant ACL_Assignment. */
    public static final String ACL_Assignment="ip_acl_assign";

    /** The Constant WWDS_Token_Processing. */
    public static final String WWDS_Token_Processing="review_ip_isa";

    /** The Constant Operational_Implementation. */
    public static final String Operational_Implementation="ip_operational_impl";
    //Temp Value
    /** The Constant Terminate_IP. */
    public static final String Terminate_IP ="ip_operational_impl";

    /** The Constant Rework_IP_Registration_Request. */
    public static final String Rework_IP_Registration_Request="ip_rework_ipreg";

    /** The Constant Start_IP_Maintenance. */
    public static final String Start_IP_Maintenance="start_workflow";

    /** The Constant Start_IP_Termination. */
    public static final String Start_IP_Termination="start_workflow";

    /** The Constant IP_Registration. */
    public static final String IP_Registration="IPRegistration";

    /** The Constant IP_Maintenance. */
    public static final String IP_Maintenance="IPMaintenance";

    /** The Constant IP_Termination. */
    public static final String IP_Termination="IPTermination";

    /**
     * Sets the bfc work item.
     *
     * @param bfcWorkItem the new bfc work item
     */
    public void setBfcWorkItem(BfcWorkItem bfcWorkItem){
	this.bfcWorkItem = bfcWorkItem;
    }

    /**
     * Gets the bfc work item.
     *
     * @return the bfc work item
     */
    public BfcWorkItem getBfcWorkItem(){
	return bfcWorkItem;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id){
	this.id = id;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId(){
	return id;
    }

    /**
     * Sets the requester.
     *
     * @param requester the new requester
     */
    public void setRequester(String requester){
	this.requester = requester;
    }

    /**
     * Gets the requester.
     *
     * @return the requester
     */
    public String getRequester(){
	return requester;
    }

    /**
     * Sets the process name.
     *
     * @param processName the new process name
     */
    public void setProcessName(String processName){
	this.processName = processName;
    }

    /**
     * Gets the process name.
     *
     * @return the process name
     */
    public String getProcessName(){
	return processName;
    }

    /**
     * Sets the process type.
     *
     * @param processType the new process type
     */
    public void setProcessType(String processType){
	this.processType = processType;
    }

    /**
     * Gets the process type.
     *
     * @return the process type
     */
    public String getProcessType(){
	return processType;
    }

    /**
     * Sets the due date.
     *
     * @param dueDate the new due date
     */
    public void setDueDate(Date dueDate){
	this.dueDate = dueDate;
    }

    /**
     * Gets the due date.
     *
     * @return the due date
     */
    public Date getDueDate(){
	return dueDate;
    }

    /**
     * Sets the wor item id.
     *
     * @param worItemId the new wor item id
     */
    public void setWorItemId(String worItemId){
	this.worItemId = worItemId;
    }

    /**
     * Gets the wor item id.
     *
     * @return the wor item id
     */
    public String getWorItemId(){
	return worItemId;
    }

    /**
     * Sets the action.
     *
     * @param action the new action
     */
    public void setAction(String action){
	this.action = action;
    }

    /**
     * Gets the action.
     *
     * @return the action
     */
    public String getAction(){
	return action;
    }

    /**
     * Sets the task code.
     *
     * @param taskCode the new task code
     */
    public void setTaskCode(String taskCode){
	this.taskCode = taskCode;
    }

    /**
     * Gets the task code.
     *
     * @return the task code
     */
    public String getTaskCode(){
	return taskCode;
    }

    /**
     * Sets the connection id.
     *
     * @param connectionId the new connection id
     */
    public void setConnectionId(Long connectionId){
	this.connectionId = connectionId;
    }

    /**
     * Gets the connection id.
     *
     * @return the connection id
     */
    public Long getConnectionId(){
	return connectionId;
    }

    /**
     * Sets the maintenance type.
     *
     * @param maintenanceType the new maintenance type
     */
    public void setMaintenanceType(String maintenanceType){
	this.maintenanceType = maintenanceType;
    }

    /**
     * Gets the maintenance type.
     *
     * @return the maintenance type
     */
    public String getMaintenanceType(){
	return maintenanceType;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status){
	this.status = status;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus(){
	return status;
    }

    /**
     * Sets the planned activate date.
     *
     * @param plannedActivateDate the new planned activate date
     */
    public void setPlannedActivateDate(Date plannedActivateDate){
	this.plannedActivateDate = plannedActivateDate;
    }

    /**
     * Gets the planned activate date.
     *
     * @return the planned activate date
     */
    public Date getPlannedActivateDate(){
	return plannedActivateDate;
    }

    /**
     * Gets the task name.
     *
     * @return the task name
     */
    public String getTaskName() {
	return taskName;
    }

    /**
     * Sets the task name.
     *
     * @param taskName the new task name
     */
    public void setTaskName(String taskName) {
	this.taskName = taskName;
    }


}
