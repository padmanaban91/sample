/*
 * 
 */
package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * The Class TIMailAudit.
 */
public class TIMailAudit extends Base implements Serializable {

	private TIRequest tiRequest;

	private String templateID;

	private String toList;

	private String ccList;

	private String bccList;
	
	private String doNotSendList;

	private String mailSubject;

	private Blob mailBody;

	private String mailBodyDisplay;

	private Long processID;
	
	private String requestType;
	
	private Integer versionNumber;
	
	private String createdDateDisplay;
	
	private String notificationType;

    private List<TIMailAuditResponse> responseMails;
    
    private CMPRequest cmpRequest;

	public TIRequest getTiRequest() {
		return tiRequest;
	}

	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	public String getTemplateID() {
		return templateID;
	}

	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}

	public String getToList() {
		return toList;
	}

	public void setToList(String toList) {
		this.toList = toList;
	}

	public String getCcList() {
		return ccList;
	}

	public void setCcList(String ccList) {
		this.ccList = ccList;
	}

	public String getBccList() {
		return bccList;
	}

	public void setBccList(String bccList) {
		this.bccList = bccList;
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

	public Blob getMailBody() {
		return mailBody;
	}

	public void setMailBody(Blob mailBody) {
		this.mailBody = mailBody;
	}
	
	public Long getProcessID() {
		return processID;
	}

	public void setProcessID(Long processID) {
		this.processID = processID;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public Integer getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(Integer versionNumber) {
		this.versionNumber = versionNumber;
	}
	
	public CMPRequest getCmpRequest() {
		return cmpRequest;
	}

	public void setCmpRequest(CMPRequest cmpRequest) {
		this.cmpRequest = cmpRequest;
	}

	public String getCreatedDateDisplay() {
		if(getCreated_date() != null){
			SimpleDateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
			return dateformat.format(getCreated_date());
		}
		return createdDateDisplay;
	}

	public void setCreatedDateDisplay(String createdDateDisplay) {
		this.createdDateDisplay = createdDateDisplay;
	}

	public String getMailBodyDisplay() {
		Blob mailbody = getMailBody();
		if(mailbody != null){
			int len = 0;
			try {
				len = (int)mailbody.length();
				return new String(mailbody.getBytes(1, len));
			} catch (SQLException e) {
			}
		}		
		return mailBodyDisplay;
	}

	public void setMailBodyDisplay(String mailBodyDisplay) {
		this.mailBodyDisplay = mailBodyDisplay;
	}

	public List<TIMailAuditResponse> getResponseMails() {
		return responseMails;
	}

	public void setResponseMails(List<TIMailAuditResponse> responseMails) {
		this.responseMails = responseMails;
	}

	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	/**
	 * @return the doNotSendList
	 */
	public String getDoNotSendList() {
		return doNotSendList;
	}

	/**
	 * @param doNotSendList the doNotSendList to set
	 */
	public void setDoNotSendList(String doNotSendList) {
		this.doNotSendList = doNotSendList;
	}
	
}
