package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

import com.citigroup.cgti.c3par.C3parPerformerKeyGenerator;
import com.citigroup.cgti.c3par.dao.RelationshipDAO;
import com.citigroup.cgti.c3par.dao.ResourceTypeDAO;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class Relationship.
 */
@XmlType(name="RelationshipEntity")
public class Relationship extends PerformerPagerDO implements Serializable{

    /** The thirdparty. */
    private ThirdParty thirdparty=new ThirdParty();

    /** The requester resource type. */
    private ResourceType requesterResourceType = new ResourceType();

    /** The target resource type. */
    private ResourceType targetResourceType = new ResourceType();

    /** The relationship type. */
    private String relationshipType;

    /** The requester name. */
    private String requesterName;

    /** The status. */
    private String status;
    /*public static final String STATUS_CERTIFIED = "CERTIFIED";
	public static final String STATUS_PENDING = "CERTIFICATION PENDING";
	public static final String STATUS_NOTCERTIFIED="NOT CERTIFIED";
     */
    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
	this.status = status;
    }

    /**
     * Gets the thirdparty.
     *
     * @return the thirdparty
     */
    public ThirdParty getThirdparty() {
	return thirdparty;
    }

    /**
     * Gets the requester name.
     *
     * @return the requester name
     */
    public String getRequesterName() {
	return requesterName;
    }

    /**
     * Sets the requester name.
     *
     * @param requesterName the new requester name
     */
    public void setRequesterName(String requesterName) {
	this.requesterName = requesterName;
    }

    /**
     * Sets the thirdparty.
     *
     * @param thirdparty the new thirdparty
     */
    public void setThirdparty(ThirdParty thirdparty) {
	this.thirdparty = thirdparty;
    }

    /**
     * Instantiates a new relationship.
     */
    public Relationship() {
	setTableName(PerformerTypes.RELATIONSHIP);
	setSequenceName(new C3parPerformerKeyGenerator(RelationshipDAO.ENTITY_NAME));

	//		addToDBMapping("id", "ID",1);
	//		addToDBMapping("name", "NAME",1);
	addToDBMapping("requesterResourceType", "REQUESTER_RESOURCE_TYPE_ID",1);
	addToDBMapping("targetResourceType", "TARGET_RESOURCE_TYPE_ID",2);
	addToDBMapping("relationshipType", "RELATIONSHIP_TYPE",3);

	addToNonPersistanceList("requesterName");
	addToNonPersistanceList("status");
	addToNonPersistanceList("thirdparty");
    }

    /**
     * Gets the requester resource type.
     *
     * @return the requester resource type
     */
    public ResourceType getRequesterResourceType() {
	return requesterResourceType;
    }

    /**
     * Sets the requester resource type.
     *
     * @param requesterResourceType the new requester resource type
     */
    public void setRequesterResourceType(ResourceType requesterResourceType) {
	this.requesterResourceType = requesterResourceType;
    }

    /**
     * Gets the target resource type.
     *
     * @return the target resource type
     */
    public ResourceType getTargetResourceType() {
	return targetResourceType;
    }

    /**
     * Sets the target resource type.
     *
     * @param targetResourceType the new target resource type
     */
    public void setTargetResourceType(ResourceType targetResourceType) {
	this.targetResourceType = targetResourceType;
    }

    /**
     * Gets the relationship type.
     *
     * @return the relationship type
     */
    public String getRelationshipType() {
	return relationshipType;
    }

    /**
     * Sets the relationship type.
     *
     * @param relationshipType the new relationship type
     */
    public void setRelationshipType(String relationshipType) {
	this.relationshipType = relationshipType;
    }

}
