package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.TeamViewProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface TeamViewPersistable extends Persistable {

	public List<CMPRequest> getTeamViewCmpReqData(
			TeamViewProcess teamViewProcess);
	
	List<String> getAssignedLastNameList();
	
	List<String> getSectorList();

}
