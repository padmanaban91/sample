package com.citigroup.cgti.c3par.communication.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.relationship.domain.Sector;

public class EcmQueueSectors extends Base{
	
	private Sector sector;
	
	private EcmQueue ecmQueue;
	
	public Sector getSector() {
		return sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}

	public EcmQueue getEcmQueue() {
		return ecmQueue;
	}

	public void setEcmQueue(EcmQueue ecmQueue) {
		this.ecmQueue = ecmQueue;
	}
	
}
