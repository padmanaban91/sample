package com.citigroup.cgti.c3par.appsense.domain;
import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.fw.domain.Port;



/**
 * The Class AppsensePortMaster.
 * 
 */
@XmlRootElement
public class AppsensePortMaster extends Base implements
Serializable {

    /** The port look up. */
    private Port portLookUp = new Port();

    /** The connection ip master. */
    private ConnectionIPMaster  connectionIPMaster= new ConnectionIPMaster();

    /** The con ostia group. */
    private ConnectionOstiaGroup conOstiaGroup = new ConnectionOstiaGroup();


    /**
     * Instantiates a new appsense port master.
     */
    public AppsensePortMaster(){ }



    /**
     * Gets the connection ip master.
     *
     * @return the connection ip master
     */
    public ConnectionIPMaster getConnectionIPMaster() {
	return connectionIPMaster;
    }



    /**
     * Sets the connection ip master.
     *
     * @param connectionIPMaster the new connection ip master
     */
    public void setConnectionIPMaster(ConnectionIPMaster connectionIPMaster) {
	this.connectionIPMaster = connectionIPMaster;
    }


   


    public Port getPortLookUp() {
		return portLookUp;
	}



	public void setPortLookUp(Port portLookUp) {
		this.portLookUp = portLookUp;
	}



	/**
     * Gets the con ostia group.
     *
     * @return the con ostia group
     */
	@XmlTransient
    public ConnectionOstiaGroup getConOstiaGroup() {
	return conOstiaGroup;
    }



    /**
     * Sets the con ostia group.
     *
     * @param conOstiaGroup the new con ostia group
     */
    public void setConOstiaGroup(ConnectionOstiaGroup conOstiaGroup) {
	this.conOstiaGroup = conOstiaGroup;
    }


}
