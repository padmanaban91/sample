/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * 
 * @author ne36745
 *
 */
public class FirewallRulePolicy extends Base {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private FireWallRule fireWallRule;
    private TIRequest updatedTIRequest;
    private TIRequest deletedTIRequest;
    private FirewallPolicy firewallPolicy;
    
  //UI Level Attributes and Flags
    private boolean isDeleted;
    
    private String updated_date_hdn;

    public FirewallRulePolicy() {
	setCreated_date(new Date());
    }

	/**
	 * @return the fireWallRule
	 */
	public FireWallRule getFireWallRule() {
		return fireWallRule;
	}



	/**
	 * @param fireWallRule the fireWallRule to set
	 */
	public void setFireWallRule(FireWallRule fireWallRule) {
		this.fireWallRule = fireWallRule;
	}



	/**
	 * @return the updatedTIRequest
	 */
	public TIRequest getUpdatedTIRequest() {
		return updatedTIRequest;
	}



	/**
	 * @param updatedTIRequest the updatedTIRequest to set
	 */
	public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
		this.updatedTIRequest = updatedTIRequest;
	}



	/**
	 * @return the deletedTIRequest
	 */
	public TIRequest getDeletedTIRequest() {
		return deletedTIRequest;
	}



	/**
	 * @param deletedTIRequest the deletedTIRequest to set
	 */
	public void setDeletedTIRequest(TIRequest deletedTIRequest) {
		this.deletedTIRequest = deletedTIRequest;
	}


	/**
	 * @return the firewallPolicy
	 */
	public FirewallPolicy getFirewallPolicy() {
		return firewallPolicy;
	}

	/**
	 * @param firewallPolicy the firewallPolicy to set
	 */
	public void setFirewallPolicy(FirewallPolicy firewallPolicy) {
		this.firewallPolicy = firewallPolicy;
	}

	/**
	 * @return the isDeleted
	 */
	public boolean isDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the updated_date_hdn
	 */
	public String getUpdated_date_hdn() {
		return updated_date_hdn;
	}

	/**
	 * @param updatedDateHdn the updated_date_hdn to set
	 */
	public void setUpdated_date_hdn(String updatedDateHdn) {
		updated_date_hdn = updatedDateHdn;
	}

}
