package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.appsense.domain.ConnectionPortLookUp;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;



/**
 * The Class ConnectionPortMaster.
 */
public class ConnectionPortMaster extends PerformerPagerDO implements Serializable {

    /** The user entry type. */
    private String userEntryType;

    /** The start port. */
    private int startPort;

    /** The end port. */
    private int endPort;

    /** The share flag. */
    private String shareFlag;

    /** The delete flag. */
    private String deleteFlag;

    /** The protocol list. */
    private List protocolList;

    /** The control msg list. */
    private List controlMsgList;

    /** The port look up. */
    private ConnectionPortLookUp portLookUp;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /** The risk port ostia. */
    private ConnectionRiskPortOstia riskPortOstia;

    /** The pair id. */
    private Long pairId;

    /**
     * Instantiates a new connection port master.
     */
    public ConnectionPortMaster() {
	//---------------------
	setTableName(PerformerTypes.CONN_PORT_MASTER_TABEL);
	setSequenceName(PerformerTypes.CONN_PORT_MASTER_SEQ);
	//---------------------
	addToNonPersistanceList("userEntryType");
	addToNonPersistanceList("startPort");
	addToNonPersistanceList("endPort");
	addToNonPersistanceList("pairId");
	addToNonPersistanceList("protocolList");
	addToNonPersistanceList("controlMsgList");
	addToNonPersistanceList("pairId");
	//addToNonPersistanceList("riskPortOstia");
	//---------------------

	addToDBMapping("shareFlag","share_flag",1);
	addToDBMapping("deleteFlag","delete_flag",2);
	addToDBMapping("portLookUp","port_lookup_id",3);
	addToDBMapping("created_date","created_date",4);
	addToDBMapping("updated_date","updated_date",5);
	//		addToDBMapping("riskPortOstia","risk_port_ostia_id",6);


	//----------------------
	addToNonCompositionList("connectionIPMaster");
	//----------------------
	addToParentsMap("com.citigroup.cgti.c3par.connection.domain.ConnectionIPPairMaster" , "ip_pair_id");
	//		addToParentsMap("com.citigroup.cgti.c3par.connection.domain.ConnectionPortLookUp" , "port_lookup_id");
	//----------------------

	addToChildList("riskPortOstia",new ConnectionRiskPortOstia());
	//----------------------
	addToDefaultValueMap("shareFlag", "F");
	addToDefaultValueMap("deleteFlag", "F");

    }


    /**
     * Gets the pair id.
     *
     * @return the pair id
     */
    public Long getPairId() {
	return pairId;
    }

    /**
     * Sets the pair id.
     *
     * @param pairId the new pair id
     */
    public void setPairId(Long pairId) {
	this.pairId = pairId;
    }

    /**
     * Gets the control msg list.
     *
     * @return the control msg list
     */
    public List getControlMsgList() {
	return controlMsgList;
    }


    /**
     * Sets the control msg list.
     *
     * @param controlMsgList the new control msg list
     */
    public void setControlMsgList(List controlMsgList) {
	this.controlMsgList = controlMsgList;
    }


    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#getCreated_date()
     */
    public Date getCreated_date() {
	return created_date;
    }


    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#setCreated_date(java.util.Date)
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }


    /**
     * Gets the delete flag.
     *
     * @return the delete flag
     */
    public String getDeleteFlag() {
	return deleteFlag;
    }


    /**
     * Sets the delete flag.
     *
     * @param deleteFlag the new delete flag
     */
    public void setDeleteFlag(String deleteFlag) {
	this.deleteFlag = deleteFlag;
    }


    /**
     * Gets the end port.
     *
     * @return the end port
     */
    public int getEndPort() {
	return endPort;
    }


    /**
     * Sets the end port.
     *
     * @param endPort the new end port
     */
    public void setEndPort(int endPort) {
	this.endPort = endPort;
    }


    /**
     * Gets the port look up.
     *
     * @return the port look up
     */
    public ConnectionPortLookUp getPortLookUp() {
	return portLookUp;
    }


    /**
     * Sets the port look up.
     *
     * @param portLookUp the new port look up
     */
    public void setPortLookUp(ConnectionPortLookUp portLookUp) {
	this.portLookUp = portLookUp;
    }


    /**
     * Gets the protocol list.
     *
     * @return the protocol list
     */
    public List getProtocolList() {
	return protocolList;
    }


    /**
     * Sets the protocol list.
     *
     * @param protocolList the new protocol list
     */
    public void setProtocolList(List protocolList) {
	this.protocolList = protocolList;
    }


    /**
     * Gets the share flag.
     *
     * @return the share flag
     */
    public String getShareFlag() {
	return shareFlag;
    }


    /**
     * Sets the share flag.
     *
     * @param shareFlag the new share flag
     */
    public void setShareFlag(String shareFlag) {
	this.shareFlag = shareFlag;
    }


    /**
     * Gets the start port.
     *
     * @return the start port
     */
    public int getStartPort() {
	return startPort;
    }


    /**
     * Sets the start port.
     *
     * @param startPort the new start port
     */
    public void setStartPort(int startPort) {
	this.startPort = startPort;
    }


    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#getUpdated_date()
     */
    public Date getUpdated_date() {
	return updated_date;
    }


    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#setUpdated_date(java.util.Date)
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }


    /**
     * Gets the user entry type.
     *
     * @return the user entry type
     */
    public String getUserEntryType() {
	return userEntryType;
    }


    /**
     * Sets the user entry type.
     *
     * @param userEntryType the new user entry type
     */
    public void setUserEntryType(String userEntryType) {
	this.userEntryType = userEntryType;
    }


    /**
     * Gets the risk port ostia.
     *
     * @return the risk port ostia
     */
    public ConnectionRiskPortOstia getRiskPortOstia() {
	return riskPortOstia;
    }


    /**
     * Sets the risk port ostia.
     *
     * @param riskPortOstia the new risk port ostia
     */
    public void setRiskPortOstia(ConnectionRiskPortOstia riskPortOstia) {
	this.riskPortOstia = riskPortOstia;
    }


}
