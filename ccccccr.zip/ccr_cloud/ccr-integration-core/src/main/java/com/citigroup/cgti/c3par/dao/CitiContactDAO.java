


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = CitiContactDAO
// Table name = CITI_CONTACT
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class CitiContactDAO.
 */
public class CitiContactDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "CITI_CONTACT";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(CitiContactDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "CitiContact";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_FIRSTNAME. */
    public static final String	COLUMN_FIRSTNAME = "FIRST_NAME";

    /** The Constant COLUMN_FIRSTNAME_LEN. */
    public static final int		COLUMN_FIRSTNAME_LEN = 100;

    /** The Constant COLUMN_LASTNAME. */
    public static final String	COLUMN_LASTNAME = "LAST_NAME";

    /** The Constant COLUMN_LASTNAME_LEN. */
    public static final int		COLUMN_LASTNAME_LEN = 100;

    /** The Constant COLUMN_RITSID. */
    public static final String	COLUMN_RITSID = "RITS_ID";

    /** The Constant COLUMN_RITSID_LEN. */
    public static final int		COLUMN_RITSID_LEN = 100;

    /** The Constant COLUMN_ITLC. */
    public static final String	COLUMN_ITLC = "ITLC";

    /** The Constant COLUMN_ITLC_LEN. */
    public static final int		COLUMN_ITLC_LEN = 100;

    /** The Constant COLUMN_ORGANIZATION. */
    public static final String	COLUMN_ORGANIZATION = "ORGANIZATION";

    /** The Constant COLUMN_ORGANIZATION_LEN. */
    public static final int		COLUMN_ORGANIZATION_LEN = 100;

    /** The Constant COLUMN_PHONE. */
    public static final String	COLUMN_PHONE = "PHONE";

    /** The Constant COLUMN_PHONE_LEN. */
    public static final int		COLUMN_PHONE_LEN = 25;

    /** The Constant COLUMN_EMAIL. */
    public static final String	COLUMN_EMAIL = "EMAIL";

    /** The Constant COLUMN_EMAIL_LEN. */
    public static final int		COLUMN_EMAIL_LEN = 50;

    /** The Constant COLUMN_SSOID. */
    public static final String	COLUMN_SSOID = "SSO_ID";

    /** The Constant COLUMN_SSOID_LEN. */
    public static final int		COLUMN_SSOID_LEN = 100;
    // Column names of references
    /** The Constant COLUMN_BUSINESSUNIT_ID. */
    public static final String	COLUMN_BUSINESSUNIT_ID = "BUSINESSUNIT_ID";

    /** The Constant COLUMN_LOCATION_ID. */
    public static final String	COLUMN_LOCATION_ID = "LOCATION_ID";

    /** The Constant COLUMN_RESOURCETYPE_ID. */
    public static final String	COLUMN_RESOURCETYPE_ID = "RESOURCE_TYPE_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + CitiContactDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_FIRSTNAME
    + ", " + COLUMN_LASTNAME
    + ", " + COLUMN_RITSID
    + ", " + COLUMN_ITLC
    + ", " + COLUMN_ORGANIZATION
    + ", " + COLUMN_PHONE
    + ", " + COLUMN_EMAIL
    + ", " + COLUMN_SSOID
    + ", " + COLUMN_BUSINESSUNIT_ID
    + ", " + COLUMN_LOCATION_ID
    + ", " + COLUMN_RESOURCETYPE_ID
    + " FROM " + CitiContactDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = CitiContactDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + CitiContactDAO.TABLE + " SET "
    + COLUMN_FIRSTNAME + " = ? "
    + ", " + COLUMN_LASTNAME + " = ? "
    + ", " + COLUMN_RITSID + " = ? "
    + ", " + COLUMN_ITLC + " = ? "
    + ", " + COLUMN_ORGANIZATION + " = ? "
    + ", " + COLUMN_PHONE + " = ? "
    + ", " + COLUMN_EMAIL + " = ? "
    + ", " + COLUMN_SSOID + " = ? "
    + ", " + COLUMN_BUSINESSUNIT_ID + " = ? "
    + ", " + COLUMN_LOCATION_ID + " = ? "
    + ", " + COLUMN_RESOURCETYPE_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + CitiContactDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_FIRSTNAME 
    + ", " + COLUMN_LASTNAME 
    + ", " + COLUMN_RITSID 
    + ", " + COLUMN_ITLC 
    + ", " + COLUMN_ORGANIZATION 
    + ", " + COLUMN_PHONE 
    + ", " + COLUMN_EMAIL 
    + ", " + COLUMN_SSOID 
    + ", " + COLUMN_BUSINESSUNIT_ID
    + ", " + COLUMN_LOCATION_ID
    + ", " + COLUMN_RESOURCETYPE_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + CitiContactDAO.TABLE + " WHERE ID = ?";



    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the citi contact dao
     */
    public static CitiContactDAO createInstance(DatabaseSession session)
    {
	return new CitiContactDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new citi contact dao.
     *
     * @param session the session
     */
    public CitiContactDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating CitiContactDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The CitiContactEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(CitiContactEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(CitiContactEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The CitiContactEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(CitiContactEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(CitiContactEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting CitiContactEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + CitiContactDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER
	    beforeUpdateLocationReferences((CitiContactEntity) entity);

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, CitiContactDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setStringToStatement(st, position, entity.getFirstName(), COLUMN_FIRSTNAME_LEN);
	    position = setStringToStatement(st, position, entity.getLastName(), COLUMN_LASTNAME_LEN);
	    position = setStringToStatement(st, position, entity.getRitsId(), COLUMN_RITSID_LEN);
	    position = setStringToStatement(st, position, entity.getItlc(), COLUMN_ITLC_LEN);
	    position = setStringToStatement(st, position, entity.getOrganization(), COLUMN_ORGANIZATION_LEN);
	    position = setStringToStatement(st, position, entity.getPhone(), COLUMN_PHONE_LEN);
	    position = setStringToStatement(st, position, entity.getEmail(), COLUMN_EMAIL_LEN);
	    position = setStringToStatement(st, position, entity.getSsoId(), COLUMN_SSOID_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    afterUpdateLocationReferences((CitiContactEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + CitiContactDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The CitiContactEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(CitiContactEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(CitiContactEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The CitiContactEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(CitiContactEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(CitiContactEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating CitiContactEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + CitiContactDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER
	    beforeUpdateLocationReferences((CitiContactEntity) entity);

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setStringToStatement(st, position, entity.getFirstName(), COLUMN_FIRSTNAME_LEN);
	    position = setStringToStatement(st, position, entity.getLastName(), COLUMN_LASTNAME_LEN);
	    position = setStringToStatement(st, position, entity.getRitsId(), COLUMN_RITSID_LEN);
	    position = setStringToStatement(st, position, entity.getItlc(), COLUMN_ITLC_LEN);
	    position = setStringToStatement(st, position, entity.getOrganization(), COLUMN_ORGANIZATION_LEN);
	    position = setStringToStatement(st, position, entity.getPhone(), COLUMN_PHONE_LEN);
	    position = setStringToStatement(st, position, entity.getEmail(), COLUMN_EMAIL_LEN);
	    position = setStringToStatement(st, position, entity.getSsoId(), COLUMN_SSOID_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    afterUpdateLocationReferences((CitiContactEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + CitiContactDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public CitiContactEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public CitiContactEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	CitiContactEntity obj = (CitiContactEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting CitiContactEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> CitiContactEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (CitiContactEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + CitiContactDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + CitiContactDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting CitiContactEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    CitiContactEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (CitiContactEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (CitiContactEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + CitiContactDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type CitiContactEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		CitiContactEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM CITI_CONTACT";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (CitiContactEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + CitiContactDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type CitiContactEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + CitiContactDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    CitiContactEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    CitiContactEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(CitiContactEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(CitiContactEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...
		if(entity.getOriginalLocationId() != null)
		{
		    LocationDAO locationDAO = getLocationDAO();
		    if(entity.getOriginalLocation() != null)
		    {
			locationDAO.delete(entity.getOriginalLocation());
		    }
		    else
		    {
			locationDAO.delete(entity.getOriginalLocationId());
		    }
		}

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + CitiContactDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(CitiContactEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + CitiContactDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	CitiContactEntity entity = (CitiContactEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setFirstName(getStringFromResultSet(rs, COLUMN_FIRSTNAME));
	    entity.setFirstName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalFirstName(entity.getFirstName());
	    //			entity.setLastName(getStringFromResultSet(rs, COLUMN_LASTNAME));
	    entity.setLastName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalLastName(entity.getLastName());
	    //			entity.setRitsId(getStringFromResultSet(rs, COLUMN_RITSID));
	    entity.setRitsId(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRitsId(entity.getRitsId());
	    //			entity.setItlc(getStringFromResultSet(rs, COLUMN_ITLC));
	    entity.setItlc(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalItlc(entity.getItlc());
	    //			entity.setOrganization(getStringFromResultSet(rs, COLUMN_ORGANIZATION));
	    entity.setOrganization(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOrganization(entity.getOrganization());
	    //			entity.setPhone(getStringFromResultSet(rs, COLUMN_PHONE));
	    entity.setPhone(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalPhone(entity.getPhone());
	    //			entity.setEmail(getStringFromResultSet(rs, COLUMN_EMAIL));
	    entity.setEmail(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalEmail(entity.getEmail());
	    //			entity.setSsoId(getStringFromResultSet(rs, COLUMN_SSOID));
	    entity.setSsoId(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSsoId(entity.getSsoId());

	    // Single References
	    //			entity.setBusinessunitId(getLongFromResultSet(rs, COLUMN_BUSINESSUNIT_ID));
	    entity.setBusinessunitId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalBusinessunitId(entity.getBusinessunitId());
	    //			entity.setLocationId(getLongFromResultSet(rs, COLUMN_LOCATION_ID));
	    entity.setLocationId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalLocationId(entity.getLocationId());
	    //			entity.setResourceTypeId(getLongFromResultSet(rs, COLUMN_RESOURCETYPE_ID));
	    entity.setResourceTypeId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalResourceTypeId(entity.getResourceTypeId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	CitiContactEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (CitiContactEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new CitiContactEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	CitiContactEntity entity = (CitiContactEntity)obj;
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("ConnectionCitiReqContactXrefDAO.loadReferences(): References for CitiContactEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("ConnectionCitiReqContactXrefDAO.loadReferences(): Loading references for CitiContactEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    CitiContactEntity entity = (CitiContactEntity)obj;

	    Long businessunitId = entity.getBusinessunitId();
	    if (businessunitId != null)
	    {
		//			BusinessUnitDAO businessunitDAO = new BusinessUnitDAO(getSession());
		BusinessUnitDAO businessunitDAO = getBusinessunitDAO();
		entity.setBusinessunit((BusinessUnitEntity)businessunitDAO.get(businessunitId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalBusinessunit(entity.getBusinessunit());
	    }

	    Long locationId = entity.getLocationId();
	    if (locationId != null)
	    {
		//			LocationDAO locationDAO = new LocationDAO(getSession());
		LocationDAO locationDAO = getLocationDAO();
		entity.setLocation((LocationEntity)locationDAO.get(locationId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalLocation(entity.getLocation());
	    }

	    Long resourceTypeId = entity.getResourceTypeId();
	    if (resourceTypeId != null)
	    {
		// Use lookup for optimized access
		entity.setResourceType(ResourceTypeLookup.getInstance().getById(getSession(), resourceTypeId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalResourceType(entity.getResourceType());
	    }

	}
	catch(Exception e)
	{
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for CitiContactEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load businessunit with id.
     *
     * @param id the id
     * @return the business unit entity
     * @throws DatabaseException the database exception
     */
    public BusinessUnitEntity loadBusinessunitWithId(Long id) throws DatabaseException
    {
	BusinessUnitEntity entity = null;
	if (id != null)
	{
	    //			BusinessUnitDAO businessunitDAO = new BusinessUnitDAO(getSession());
	    BusinessUnitDAO businessunitDAO = getBusinessunitDAO();
	    entity = (BusinessUnitEntity)businessunitDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load location with id.
     *
     * @param id the id
     * @return the location entity
     * @throws DatabaseException the database exception
     */
    public LocationEntity loadLocationWithId(Long id) throws DatabaseException
    {
	LocationEntity entity = null;
	if (id != null)
	{
	    //			LocationDAO locationDAO = new LocationDAO(getSession());
	    LocationDAO locationDAO = getLocationDAO();
	    entity = (LocationEntity)locationDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load resource type with id.
     *
     * @param id the id
     * @return the resource type entity
     * @throws DatabaseException the database exception
     */
    public ResourceTypeEntity loadResourceTypeWithId(Long id) throws DatabaseException
    {
	ResourceTypeEntity entity = null;
	if (id != null)
	{
	    // Use lookup for optimized access
	    entity = ResourceTypeLookup.getInstance().getById(getSession(), id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	CitiContactEntity entity = (CitiContactEntity) obj;

	setLongToStatement(st, position++, entity.getBusinessunit() != null ? entity.getBusinessunit().getId() : entity.getBusinessunitId());
	setLongToStatement(st, position++, entity.getLocation() != null ? entity.getLocation().getId() : entity.getLocationId());
	setLongToStatement(st, position++, entity.getResourceType() != null ? entity.getResourceType().getId() : entity.getResourceTypeId());

	return position;
    }

    // Single non-composition 'businessunit' helpers 'CitiContact' does not need helper
    // Single Composition 'location' helpers 'citiContact'
    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void beforeUpdateLocationReferences(CitiContactEntity entity) throws DatabaseException
    {
	if (entity.getLocation() != null)
	{
	    LocationDAO dao = getLocationDAO();
	    dao.update(entity.getLocation(), false);
	}
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void afterUpdateLocationReferences(CitiContactEntity entity) throws DatabaseException
    {
	if (entity.getOriginalLocationId() != null && !entity.getOriginalLocationId().equals(entity.getLocationId()))
	{
	    LocationDAO dao = getLocationDAO();
	    if(entity.getOriginalLocation() != null)
	    {
		dao.delete(entity.getOriginalLocation());
	    }
	    else
	    {
		dao.delete(entity.getOriginalLocationId());
	    }
	}

	//		if (entity.getOriginalLocation() != null && !entity.getOriginalLocation().equals(entity.getLocation()))
	//		{
	//			LocationDAO dao = getLocationDAO();
	//			dao.delete(entity.getOriginalLocation());
	//		}
    }

    // Single non-composition 'resourceType' helpers 'CitiContact' does not need helper

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A BusinessUnitDAO object 
     */
    protected BusinessUnitDAO getBusinessunitDAO()
    {
	BusinessUnitDAO dao = (BusinessUnitDAO)getSession().getDAO("BusinessUnit");  
	if(dao == null)
	{
	    dao = new BusinessUnitDAO(getSession());  		
	    getSession().putDAO("BusinessUnit", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A LocationDAO object 
     */
    protected LocationDAO getLocationDAO()
    {
	LocationDAO dao = (LocationDAO)getSession().getDAO("Location");  
	if(dao == null)
	{
	    dao = new LocationDAO(getSession());  		
	    getSession().putDAO("Location", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ResourceTypeDAO object 
     */
    protected ResourceTypeDAO getResourceTypeDAO()
    {
	ResourceTypeDAO dao = (ResourceTypeDAO)getSession().getDAO("ResourceType");  
	if(dao == null)
	{
	    dao = new ResourceTypeDAO(getSession());  		
	    getSession().putDAO("ResourceType", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [FirstName] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByFirstName(String value) throws DatabaseException
    {
	return findByFirstName(value, getSession());
    }

    /**
     * Find by first name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByFirstName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_FIRSTNAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [LastName] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByLastName(String value) throws DatabaseException
    {
	return findByLastName(value, getSession());
    }

    /**
     * Find by last name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByLastName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_LASTNAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RitsId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRitsId(String value) throws DatabaseException
    {
	return findByRitsId(value, getSession());
    }

    /**
     * Find by rits id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRitsId(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_RITSID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Itlc] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByItlc(String value) throws DatabaseException
    {
	return findByItlc(value, getSession());
    }

    /**
     * Find by itlc.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByItlc(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_ITLC + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Organization] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOrganization(String value) throws DatabaseException
    {
	return findByOrganization(value, getSession());
    }

    /**
     * Find by organization.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOrganization(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_ORGANIZATION + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Phone] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByPhone(String value) throws DatabaseException
    {
	return findByPhone(value, getSession());
    }

    /**
     * Find by phone.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByPhone(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_PHONE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Email] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByEmail(String value) throws DatabaseException
    {
	return findByEmail(value, getSession());
    }

    /**
     * Find by email.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByEmail(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_EMAIL + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SsoId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySsoId(String value) throws DatabaseException
    {
	return findBySsoId(value, getSession());
    }

    /**
     * Find by sso id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySsoId(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_SSOID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Businessunit] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByBusinessunit(Long value) throws DatabaseException
    {
	return findByBusinessunit(value, getSession());
    }

    /**
     * Find by businessunit.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByBusinessunit(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_BUSINESSUNIT_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Location] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByLocation(Long value) throws DatabaseException
    {
	return findByLocation(value, getSession());
    }

    /**
     * Find by location.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByLocation(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_LOCATION_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [ResourceType] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByResourceType(Long value) throws DatabaseException
    {
	return findByResourceType(value, getSession());
    }

    /**
     * Find by resource type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByResourceType(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + CitiContactDAO.TABLE + " WHERE " + COLUMN_RESOURCETYPE_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by ResourceType", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(CitiContactEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
