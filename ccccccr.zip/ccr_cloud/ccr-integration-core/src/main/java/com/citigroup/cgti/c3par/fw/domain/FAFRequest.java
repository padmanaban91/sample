/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO;
import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author bs45969
 *
 */
public class FAFRequest {
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
	private Long tiRequest;
	private Long ticketId;
	private Long locationId;
	private List<FafFireflowTicket> fafFireflowTickets;
	private FafFireflowTicket fafFireflowTicket;
	private List<FafFirewallRule> requestedRules;
	//type has to be chaged to Impl
	private List<FafFirewallRuleSuggestion> recommendedRules;

	//pagination related properties. may be included in base class after review
	private boolean paginationRequired;
	private int firstResult;
	private int maxResult;
	private int rowCount;
	
	private int totalPages;
	private int pageNo;
	private int startIndex;
	private int pageLimit;
	private String pageFlow;

	// Filter related properties.
	private String sourceIPAddress;
	private String destinationIPAddress;
	private String portNumber;
	private String sourceZone;
	private String destinationZone;
	private String policyGroup;
	private String policy;
	private String type;
	private Map<Integer, String> versionNumList = new HashMap<Integer, String>();
	private List<FireWallRuleIP> fireWallRuleIPs;
	private List<FireWallRulePort> fireWallRulePorts;
	//con info to be included
	private FAFRequestInfo fafRequestInfo = new FAFRequestInfo();
	private Long ipID;
	private Long portID;
	private Long ruleID;
	private String relationshipType;
	
	private long fafVersionSelected;
	private long currentVersion;
	private long planningVersion;
	
	private List<FAFRequest> exportList = new ArrayList<FAFRequest>();
	// to handle the request from Implementation menu or FAF tab
	private String fromPage;
	
	
	//Object Expandable or not in FAF Page
	private String isObjExpandable;	
	private String isIPReg;
	private String fafString;
	
	private Map<Long, String> faFCycles;
	private Map<String, String> views;
	private Map<String, String> combinationTypes;
	
	private boolean nextRequired;
	private boolean previousRequired;
	private String viewType;
	
	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public Map<Long, String> getFaFCycles() {
		return faFCycles;
	}

	public void setFaFCycles(Map<Long, String> faFCycles) {
		this.faFCycles = faFCycles;
	}

	public Map<String, String> getViews() {
		return views;
	}

	public void setViews(Map<String, String> views) {
		this.views = views;
	}

	public Map<String, String> getCombinationTypes() {
		return combinationTypes;
	}

	public void setCombinationTypes(Map<String, String> combinationTypes) {
		this.combinationTypes = combinationTypes;
	}

	public boolean isNextRequired() {
		return nextRequired;
	}

	public void setNextRequired(boolean nextRequired) {
		this.nextRequired = nextRequired;
	}

	public boolean isPreviousRequired() {
		return previousRequired;
	}

	public void setPreviousRequired(boolean previousRequired) {
		this.previousRequired = previousRequired;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public int getPageLimit() {
		return pageLimit;
	}

	public void setPageLimit(int pageLimit) {
		this.pageLimit = pageLimit;
	}

	public String getPageFlow() {
		return pageFlow;
	}

	public void setPageFlow(String pageFlow) {
		this.pageFlow = pageFlow;
	}

	public List<FAFRequest> getExportList() {
		return exportList;
	}

	public void setExportList(List<FAFRequest> exportList) {
		this.exportList = exportList;
	}

	public String getFromPage() {
		return fromPage;
	}

	public void setFromPage(String fromPage) {
		this.fromPage = fromPage;
	}

	public long getFafVersionSelected() {
		return fafVersionSelected;
	}

	public void setFafVersionSelected(long fafVersionSelected) {
		this.fafVersionSelected = fafVersionSelected;
	}

	public long getCurrentVersion() {
		return currentVersion;
	}

	public void setCurrentVersion(long currentVersion) {
		this.currentVersion = currentVersion;
	}

	public long getPlanningVersion() {
		return planningVersion;
	}

	public void setPlanningVersion(long planningVersion) {
		this.planningVersion = planningVersion;
	}

	public String getIsIPReg() {
		return isIPReg;
	}

	public void setIsIPReg(String isIPReg) {
		this.isIPReg = isIPReg;
	}

	public String getIsObjExpandable() {
		return isObjExpandable;
	}

	public void setIsObjExpandable(String isObjExpandable) {
		this.isObjExpandable = isObjExpandable;
	}

	/**
	 * @return the relationshipType
	 */
	public String getRelationshipType() {
		return relationshipType;
	}

	/**
	 * @param relationshipType the relationshipType to set
	 */
	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

	/**
	 * @return the ipID
	 */
	public Long getIpID() {
		return ipID;
	}

	/**
	 * @param ipID the ipID to set
	 */
	public void setIpID(Long ipID) {
		this.ipID = ipID;
	}

	/**
	 * @return the portID
	 */
	public Long getPortID() {
		return portID;
	}

	/**
	 * @param portID the portID to set
	 */
	public void setPortID(Long portID) {
		this.portID = portID;
	}

	/**
	 * @return the ruleID
	 */
	public Long getRuleID() {
		return ruleID;
	}

	/**
	 * @param ruleID the ruleID to set
	 */
	public void setRuleID(Long ruleID) {
		this.ruleID = ruleID;
	}

	/**
	 * @return the ticketId
	 */
	public Long getTicketId() {
		return ticketId;
	}

	/**
	 * @param ticketId the ticketId to set
	 */
	public void setTicketId(Long ticketId) {
		this.ticketId = ticketId;
	}

	/**
	 * Gets the location id.
	 *
	 * @return the location id
	 */
	public Long getLocationId() {
		return locationId;
	}

	/**
	 * Sets the location id.
	 *
	 * @param locationId the new location id
	 */
	public void setLocationId(Long locationId) {
		this.locationId = locationId;
	}

	/**
	 * @return the fafFireflowTickets
	 */
	public List<FafFireflowTicket> getFafFireflowTickets() {
		return fafFireflowTickets;
	}

	/**
	 * @param fafFireflowTickets the fafFireflowTickets to set
	 */
	public void setFafFireflowTickets(List<FafFireflowTicket> fafFireflowTickets) {
		this.fafFireflowTickets = fafFireflowTickets;
	}

	/**
	 * @return the requestedRules
	 */
	public List<FafFirewallRule> getRequestedRules() {
		return requestedRules;
	}

	/**
	 * @param requestedRules the requestedRules to set
	 */
	public void setRequestedRules(List<FafFirewallRule> requestedRules) {
		this.requestedRules = requestedRules;
	}

	/**
	 * @return the recommendedRules
	 */
	public List<FafFirewallRuleSuggestion> getRecommendedRules() {
		return recommendedRules;
	}

	/**
	 * @param recommendedRules the recommendedRules to set
	 */
	public void setRecommendedRules(
			List<FafFirewallRuleSuggestion> recommendedRules) {
		this.recommendedRules = recommendedRules;
	}

	/**
	 * @return the tiRequest
	 */
	public Long getTiRequest() {
		return tiRequest;
	}

	/**
	 * @param tiRequest the tiRequest to set
	 */
	public void setTiRequest(Long tiRequest) {
		this.tiRequest = tiRequest;
	}

	/**
	 * @return the fafFireflowTicket
	 */
	public FafFireflowTicket getFafFireflowTicket() {
		return fafFireflowTicket;
	}

	/**
	 * @param fafFireflowTicket the fafFireflowTicket to set
	 */
	public void setFafFireflowTicket(FafFireflowTicket fafFireflowTicket) {
		this.fafFireflowTicket = fafFireflowTicket;
	}

	/**
	 * @return the paginationRequired
	 */
	public boolean isPaginationRequired() {
		return paginationRequired;
	}

	/**
	 * @param paginationRequired the paginationRequired to set
	 */
	public void setPaginationRequired(boolean paginationRequired) {
		this.paginationRequired = paginationRequired;
	}

	/**
	 * @return the firstResult
	 */
	public int getFirstResult() {
		return firstResult;
	}

	/**
	 * @param firstResult the firstResult to set
	 */
	public void setFirstResult(int firstResult) {
		this.firstResult = firstResult;
	}

	/**
	 * @return the maxResult
	 */
	public int getMaxResult() {
		return maxResult;
	}

	/**
	 * @param maxResult the maxResult to set
	 */
	public void setMaxResult(int maxResult) {
		this.maxResult = maxResult;
	}

	/**
	 * @return the rowCount
	 */
	public int getRowCount() {
		return rowCount;
	}

	/**
	 * @param rowCount the rowCount to set
	 */
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void generateFAF(Long tiRequestID,String isIPReg) throws Exception {
		ccrBeanFactory.getFireflowRequestPersistable().generateFAF(tiRequestID, isIPReg);

	}

	/**
	 * @return the fafRequestInfo
	 */
	public FAFRequestInfo getFafRequestInfo() {
		return fafRequestInfo;
	}

	/**
	 * @param fafRequestInfo the fafRequestInfo to set
	 */
	public void setFafRequestInfo(FAFRequestInfo fafRequestInfo) {
		this.fafRequestInfo = fafRequestInfo;
	}

	public String getSourceIPAddress() {
		return sourceIPAddress;
	}

	public void setSourceIPAddress(String sourceIPAddress) {
		this.sourceIPAddress = sourceIPAddress;
	}

	public String getDestinationIPAddress() {
		return destinationIPAddress;
	}

	public void setDestinationIPAddress(String destinationIPAddress) {
		this.destinationIPAddress = destinationIPAddress;
	}

	public String getPortNumber() {
		return portNumber;
	}

	public void setPortNumber(String portNumber) {
		this.portNumber = portNumber;
	}

	public String getSourceZone() {
		return sourceZone;
	}

	public void setSourceZone(String sourceZone) {
		this.sourceZone = sourceZone;
	}

	public String getDestinationZone() {
		return destinationZone;
	}

	public void setDestinationZone(String destinationZone) {
		this.destinationZone = destinationZone;
	}

	public String getPolicyGroup() {
		return policyGroup;
	}

	public void setPolicyGroup(String policyGroup) {
		this.policyGroup = policyGroup;
	}

	public String getPolicy() {
		return policy;
	}

	public void setPolicy(String policy) {
		this.policy = policy;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the fireWallRuleIPs
	 */
	public List<FireWallRuleIP> getFireWallRuleIPs() {
		return fireWallRuleIPs;
	}

	/**
	 * @param fireWallRuleIPs the fireWallRuleIPs to set
	 */
	public void setFireWallRuleIPs(List<FireWallRuleIP> fireWallRuleIPs) {
		this.fireWallRuleIPs = fireWallRuleIPs;
	}

	/**
	 * @return the fireWallRulePorts
	 */
	public List<FireWallRulePort> getFireWallRulePorts() {
		return fireWallRulePorts;
	}

	/**
	 * @param fireWallRulePorts the fireWallRulePorts to set
	 */
	public void setFireWallRulePorts(List<FireWallRulePort> fireWallRulePorts) {
		this.fireWallRulePorts = fireWallRulePorts;
	}

	
	public List<FafFireflowTicket> findFafFireflowTickets(String isIpReg) {
		return ccrBeanFactory.getFireflowRequestPersistable().getFafFireflowTickets(this.tiRequest,isIpReg);
	}

	
	public List<FafFireflowTicket> findFafFireflowTicketsByLocationId(
			Long locationId) {
		return ccrBeanFactory.getFireflowRequestPersistable()
				.findFafFireflowTicketsByLocationId(locationId);
	}

	
	public List<FafFireflowTicket> findFafFireflowTicketsByLocationAndTiRequest(
			Long locationId, Long tiRequestId) {
		return ccrBeanFactory.getFireflowRequestPersistable()
				.findFafFireflowTicketsByLocationAndTiRequest(locationId,
						tiRequestId);
	}

	
	public TIRequest getTIRequest(Long tiRequestId) {
		return ccrBeanFactory.getFireflowRequestPersistable().getTIRequest(tiRequestId);
	}

	
	public TIRequest getTIRequest(Long processId, int version) {
		return ccrBeanFactory.getCommonServicePersistable().getTIRequest(processId, version);
	}

	
	public TIRequest getPlanningTIRequest(Long processId) {
		return ccrBeanFactory.getCommonServicePersistable().getPlanningTIRequest(processId);
	}

	
	public List<FafFirewallRule> findRequestedRulesByRequest() {
		return ccrBeanFactory.getFireflowRequestPersistable().findRequestedRulesByRequest(this);
	}

	
	public List<FafFirewallRuleSuggestion> findRecommendedRulesByRequest() {
		return ccrBeanFactory.getFireflowRequestPersistable().findRecommendedRulesByRequest(this);
	}

	/**
	 * Find requested rules by location.
	 *
	 * @return the list
	 */
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	public List<FafFirewallRule> findRequestedRulesByLocation(Long locId, Long tiReqId, String isIPReg, String requestType) {
		return ccrBeanFactory.getFireflowRequestPersistable().findRequestedRulesByLocation(locId, tiReqId, isIPReg, requestType);
	}

	/**
	 * Find recommended rules by location.
	 *
	 * @return the list
	 */
	
	public List<FafFirewallRuleSuggestion> findRecommendedRulesByLocation(Long locId, Long tiReqId, String isIPReg) {
		return ccrBeanFactory.getFireflowRequestPersistable().findRecommendedRulesByLocation(locId,tiReqId,isIPReg);
	}

	@SuppressWarnings("unchecked")
	public void storeRFCRequest() {
		List rfcRequestList = ccrBeanFactory.getRfc().storeRFCRequest(this.tiRequest,
				RFCRequestDTO.RFC_CREATE_TYPE_AUTO);
		String flag = ccrBeanFactory.getRfc().getACLVarianceFlag(this.tiRequest);
		if (flag != null && "N".equalsIgnoreCase(flag)) {
			ccrBeanFactory.getRfc().storeRFCRequestStatus(this.tiRequest, rfcRequestList);
		}
	}

	
	public List<FirewallLocation> findLocationsByRequest(Long tiReqId) {
		return ccrBeanFactory.getFireflowRequestPersistable().findLocationsByRequest(tiReqId);
	}

	
	public FAFRequestInfo populateFAFRequestInfo(FAFRequestInfo fafRequestInfo,String isIPReg) {
		return ccrBeanFactory.getCommonServicePersistable().getConnectionInfo(fafRequestInfo,isIPReg);
	}
	
	public List<Long> getAllTiRequests(Long processId, String isIPReg, String expType) {
    	return ccrBeanFactory.getFireflowRequestPersistable().getAllTiRequests(processId,isIPReg, expType);
    }
	
	public CommonServicePersistable getCommonServicePersistable() {
		return ccrBeanFactory.getCommonServicePersistable();
	}


	
	public Map<Long, String> getAllCyclesAndVersion(long processId,String isIPReg) {

		return ccrBeanFactory.getCommonServicePersistable().getAllCyclesAndVersion(processId,isIPReg);
	}

	
	public FafFirewallRule findRequestedRule(String ticketNumber,
			int ccrRuleEquence) {
		return ccrBeanFactory.getFireflowRequestPersistable().findRequestedRule(ticketNumber,
				ccrRuleEquence);

	}

	
	public boolean isFFTicketsImplemented(Long tiReqId) {
		return ccrBeanFactory.getFireflowRequestPersistable().isFFTicketsImplemented(tiReqId);
	}
	
	
	public boolean isFFTicketsValidated(Long tiReqId) {
		return ccrBeanFactory.getFireflowRequestPersistable().isFFTicketsValidated(tiReqId);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void resetRFCGeneratedStatus(Long tiReqId,String conType) {
		ccrBeanFactory.getFireflowRequestPersistable().resetRFCGeneratedStatus(tiReqId,conType);

	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void deleteRFCFirewallRecords(Long tiReqId, String type) {
		ccrBeanFactory.getFireflowRequestPersistable().deleteRFCFirewallRecords(tiReqId, type);

	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public List<FireWallRulePort> getPortsforTemplateObject(Long ipId, Long ruleId,
			String forFAF, Long tiReqId) {
		return ccrBeanFactory.getFireflowRequestPersistable().getPortsforTemplateObject(ipId, ruleId,
				forFAF,  tiReqId);

	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public List<FireWallRuleIP> getIPsforTemplateObject(Long ipId, Long ruleId,
			String forFAF, Long tiReqId) {
		return ccrBeanFactory.getFireflowRequestPersistable().getIPsforTemplateObject( ipId,  ruleId,
				 forFAF,   tiReqId);

	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	public RFCRequest getRFCDetails(RFCRequest rfcRequest,String sectionName,String conType){
		return ccrBeanFactory.getRfc().getRFCDetails(rfcRequest,sectionName,conType);
	}

	public void setFafString(String fafString) {
		this.fafString = fafString;
	}

	public String getFafString() {
		return fafString;
	}
	
	//Added for 45182 starts
	//Moved to AccessForm text generator
	
	public String getFirewallAccessFormText(Long tireqId, Long processId, Long version, String isObjExpandable) {
		return ccrBeanFactory.getAccessFormText().getFirewallAccessFormText(tireqId, processId, version, isObjExpandable);		
	}
	
	
	public String getIPRegistrationAccessFormText(Long tireqId, Long processId, Long version, String isObjExpandable) {
		return ccrBeanFactory.getAccessFormText().getIPRegistrationAccessFormText(tireqId, processId, version, isObjExpandable);		
	}
	//Added for 45182 ends
	
	
	public String getAllFirewallAccessFormText(Long tireqId, Long processId, String expType, String isObjExpandable) {
		return ccrBeanFactory.getAccessFormText().getAllFirewallAccessFormText(tireqId, processId, expType, isObjExpandable);		
	}
	
	
	public String getAllIPRegistrationAccessFormText(Long tireqId, Long processId, String expType, String isObjExpandable) {
		return ccrBeanFactory.getAccessFormText().getAllIPRegistrationAccessFormText(tireqId, processId, expType, isObjExpandable);		
	}
	
	
	public String getOrigBusJustification(Long connectionRequestId, Long versionID) {
		return ccrBeanFactory.getAccessFormText().getOrigBusJustification(connectionRequestId, versionID);
		
	}
	public TIRequest getTIRequestForGlobalTx(Long tiRequestId) {
		return ccrBeanFactory.getFireflowRequestPersistable().getTIRequestForGlobalTx(tiRequestId);
	}
	
}