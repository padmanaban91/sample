
package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.util.List;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;

/**
 * The Class ConnectionRequest.
 *
 * @author pc79439
 */
@SuppressWarnings("unchecked")
public class VirtualConnReason extends Base implements Serializable{

	private ConnectionRequest conreq;
	
	private GenericLookup genericLookup;

	public ConnectionRequest getConreq() {
		return conreq;
	}

	public void setConreq(ConnectionRequest conreq) {
		this.conreq = conreq;
	}

	public GenericLookup getGenericLookup() {
		return genericLookup;
	}

	public void setGenericLookup(GenericLookup genericLookup) {
		this.genericLookup = genericLookup;
	}

}