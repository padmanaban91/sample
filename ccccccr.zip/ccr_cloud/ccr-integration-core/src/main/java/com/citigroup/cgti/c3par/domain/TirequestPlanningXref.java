/*
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

/**
 * The Class TirequestPlanningXref.
 *
 * @author PC79439
 */
@SuppressWarnings("unchecked")
public class TirequestPlanningXref extends Base implements Serializable{
 
    private TIRequest tirequest;
    
    private Planning planning;

    
    
	public TIRequest getTirequest() {
		return tirequest;
	}

	public void setTirequest(TIRequest tirequest) {
		this.tirequest = tirequest;
	}

	public Planning getPlanning() {
		return planning;
	}

	public void setPlanning(Planning planning) {
		this.planning = planning;
	}

}