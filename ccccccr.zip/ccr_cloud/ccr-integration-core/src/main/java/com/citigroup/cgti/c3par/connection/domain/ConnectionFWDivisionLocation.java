package com.citigroup.cgti.c3par.connection.domain;

import java.util.List;

import com.citigroup.cgti.c3par.domain.Name;


/**
 * The Class ConnectionFWDivisionLocation.
 */
public class ConnectionFWDivisionLocation extends Name {

    /** The location list. */
    private List locationList;

    /** The division code list. */
    private List divisionCodeList;

    /** The location name. */
    private String locationName;

    /** The division code. */
    private String divisionCode;

    /** The location id. */
    private Long locationID;

    /** The division code id. */
    private Long divisionCodeID;

    /**
     * Gets the division code id.
     *
     * @return the division code id
     */
    public Long getDivisionCodeID() {
	return divisionCodeID;
    }

    /**
     * Sets the division code id.
     *
     * @param divisionCodeID the new division code id
     */
    public void setDivisionCodeID(Long divisionCodeID) {
	this.divisionCodeID = divisionCodeID;
    }

    /**
     * Gets the location id.
     *
     * @return the location id
     */
    public Long getLocationID() {
	return locationID;
    }

    /**
     * Sets the location id.
     *
     * @param locationID the new location id
     */
    public void setLocationID(Long locationID) {
	this.locationID = locationID;
    }

    /**
     * Gets the division code.
     *
     * @return the division code
     */
    public String getDivisionCode() {
	return divisionCode;
    }

    /**
     * Sets the division code.
     *
     * @param divisionCode the new division code
     */
    public void setDivisionCode(String divisionCode) {
	this.divisionCode = divisionCode;
    }

    /**
     * Gets the location list.
     *
     * @return the location list
     */
    public List getLocationList() {
	return locationList;
    }

    /**
     * Sets the location list.
     *
     * @param locationList the new location list
     */
    public void setLocationList(List locationList) {
	this.locationList = locationList;
    }

    /**
     * Gets the division code list.
     *
     * @return the division code list
     */
    public List getDivisionCodeList() {
	return divisionCodeList;
    }

    /**
     * Sets the division code list.
     *
     * @param divisionCodeList the new division code list
     */
    public void setDivisionCodeList(List divisionCodeList) {
	this.divisionCodeList = divisionCodeList;
    }

    /**
     * Gets the location name.
     *
     * @return the location name
     */
    public String getLocationName() {
	return locationName;
    }

    /**
     * Sets the location name.
     *
     * @param locationName the new location name
     */
    public void setLocationName(String locationName) {
	this.locationName = locationName;
    }

}