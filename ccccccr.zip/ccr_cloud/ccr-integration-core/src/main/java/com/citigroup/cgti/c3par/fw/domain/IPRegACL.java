package com.citigroup.cgti.c3par.fw.domain;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.citigroup.cgti.c3par.domain.Base;

public class IPRegACL extends Base {

    /**
     * 
     */
    
    private static final long serialVersionUID = 1L;
    @NotEmpty(message = "IP address not avaliable for source/destination IP ")
    private String userType;
    
    private String accessType;

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserType() {
		return userType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public String getAccessType() {
		return accessType;
	}
    
    
}
