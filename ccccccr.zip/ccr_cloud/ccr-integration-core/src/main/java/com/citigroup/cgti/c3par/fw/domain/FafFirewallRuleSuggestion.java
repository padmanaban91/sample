/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author gs71854
 *
 */

public class FafFirewallRuleSuggestion extends Base {

	
	   CCRBeanFactory ccrBeanFactory;
		{
			ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
			if(appContext!=null && appContext.containsBean("cCRBeanFactory")){
				ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
			}else{
				System.out.println("appContext is null");
			}
			
		}
    /**
     * 
     */
    private static final long serialVersionUID = 2831874250009200198L;

    private FafFirewallRule fafFirewallRule;
    private FirewallPolicy policy;
    private String action;
    private String status;
    private FireWallZone sourceZone;
    private FireWallZone destinationZone;
    private ResourceType sourceNetworkZone;
    private ResourceType destinationNetworkZone;
    private Set<FafFirewallRuleSourceIpObj> sourceIPs = new HashSet<FafFirewallRuleSourceIpObj>();
    private Set<FafFirewallRuleDestinationIpObj> destinationIPs = new HashSet<FafFirewallRuleDestinationIpObj>();
    private Set<FafFirewallRulePortObj> ports = new HashSet<FafFirewallRulePortObj>();

    private String ruleNumber;
    private String subTicketNo;
    private String ffPolicyName;
    private String ffDeviceName;
    private String ffComment;
	
    /**
	 * @return the ffDeviceName
	 */
	public String getFfDeviceName() {
		return ffDeviceName;
	}

	/**
	 * @param ffDeviceName the ffDeviceName to set
	 */
	public void setFfDeviceName(String ffDeviceName) {
		this.ffDeviceName = ffDeviceName;
	}

	private String firewallBrand;
    private String subTicketStatus;

    public FafFirewallRuleSuggestion() {
	setCreated_date(new Date());
    }

    public FafFirewallRule getFafFirewallRule() {
	return fafFirewallRule;
    }

    public void setFafFirewallRule(FafFirewallRule fafFirewallRule) {
	this.fafFirewallRule = fafFirewallRule;
    }

    public FirewallPolicy getPolicy() {
	return policy;
    }

    public void setPolicy(FirewallPolicy policy) {
	this.policy = policy;
    }

    public String getAction() {
	return action;
    }

    public void setAction(String action) {
	this.action = action;
    }

    public String getStatus() {
	return status;
    }

    public void setStatus(String status) {
	this.status = status;
    }

    public FireWallZone getSourceZone() {
	return sourceZone;
    }

    public void setSourceZone(FireWallZone sourceZone) {
	this.sourceZone = sourceZone;
    }

    public FireWallZone getDestinationZone() {
	return destinationZone;
    }

    public void setDestinationZone(FireWallZone destinationZone) {
	this.destinationZone = destinationZone;
    }

    public ResourceType getSourceNetworkZone() {
	return sourceNetworkZone;
    }

    public void setSourceNetworkZone(ResourceType sourceNetworkZone) {
	this.sourceNetworkZone = sourceNetworkZone;
    }

    public ResourceType getDestinationNetworkZone() {
	return destinationNetworkZone;
    }

    public void setDestinationNetworkZone(ResourceType destinationNetworkZone) {
	this.destinationNetworkZone = destinationNetworkZone;
    }

    public Set<FafFirewallRuleSourceIpObj> getSourceIPs() {
	return sourceIPs;
    }

    public void setSourceIPs(Set<FafFirewallRuleSourceIpObj> sourceIPs) {
	this.sourceIPs = sourceIPs;
    }

    public Set<FafFirewallRuleDestinationIpObj> getDestinationIPs() {
	return destinationIPs;
    }

    public void setDestinationIPs(
	    Set<FafFirewallRuleDestinationIpObj> destinationIPs) {
	this.destinationIPs = destinationIPs;
    }

    public Set<FafFirewallRulePortObj> getPorts() {
	return ports;
    }

    public void setPorts(Set<FafFirewallRulePortObj> ports) {
	this.ports = ports;
    }
    /**
	 * @return the subTicketStatus
	 */
	public String getSubTicketStatus() {
		return subTicketStatus;
	}

	/**
	 * @param subTicketStatus the subTicketStatus to set
	 */
	public void setSubTicketStatus(String subTicketStatus) {
		this.subTicketStatus = subTicketStatus;
	}

	
    public List<FafFirewallRuleSuggestion> findImplFafFirewallRules() {
	return ccrBeanFactory.getFireflowRequestPersistable().getFafFirewallRuleSuggestions(this);

    }
    
    public FafFirewallRuleSuggestion findFafFirewallRuleSuggestionById() {
	return ccrBeanFactory.getFireflowRequestPersistable()
		.getFafFirewallRuleSuggestionById(this);

    }
    
    public FafFirewallRuleSuggestion findFafFirewallRuleSuggestion(
	    String ticketNo, Long policyId, int ruleSeq) {
	return ccrBeanFactory.getFireflowRequestPersistable().getFafFirewallRuleSuggestion(
		ticketNo, policyId, ruleSeq);
    }
    
	public FafFirewallRuleSuggestion findFafFirewallRuleSuggestion(String ticketNo,
			Long policyId, int ruleSeq, String ffRuleNumber) {
		return ccrBeanFactory.getFireflowRequestPersistable().getFafFirewallRuleSuggestion(
				ticketNo, policyId, ruleSeq,ffRuleNumber);
	}

    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public Long saveFafFirewallRuleSuggestion() {
	return ccrBeanFactory.getFireflowRequestPersistable().saveFafFirewallRuleSuggestion(this);

    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public Long saveFafFirewallSuggestedSourceIpObj() {
	return ccrBeanFactory.getFireflowRequestPersistable()
		.saveFafFirewallSuggestedSourceIpObj(this);

    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public Long saveFafFirewallSuggestedDestIpObj() {
	return ccrBeanFactory.getFireflowRequestPersistable()
		.saveFafFirewallSuggestedDestIpObj(this);

    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public Long saveFafFirewallSuggestedPortObj() {
	return ccrBeanFactory.getFireflowRequestPersistable().saveFafFirewallSuggestedPortObj(this);

    }
    
    @Override
    public boolean equals(Object obj){
        if(obj == null) return false;
        if(!(obj instanceof FafFirewallRuleSuggestion)) return false;

        FafFirewallRuleSuggestion other = (FafFirewallRuleSuggestion) obj;
        if(this.fafFirewallRule.getId() != other.fafFirewallRule.getId())   return false;
        if(this.policy.getId() != other.policy.getId())      return false;

        return true;
      }

    @Override
    public int hashCode(){
        return (int) (31 * this.fafFirewallRule.getId() +  this.policy.getId()) ;
      }

	/**
	 * @return the ruleNumber
	 */
	public String getRuleNumber() {
		return ruleNumber;
	}

	/**
	 * @param ruleNumber the ruleNumber to set
	 */
	public void setRuleNumber(String ruleNumber) {
		this.ruleNumber = ruleNumber;
	}

	/**
	 * @return the subTicketNo
	 */
	public String getSubTicketNo() {
		return subTicketNo;
	}

	/**
	 * @param subTicketNo the subTicketNo to set
	 */
	public void setSubTicketNo(String subTicketNo) {
		this.subTicketNo = subTicketNo;
	}

	/**
	 * @return the ffPolicyName
	 */
	public String getFfPolicyName() {
		return ffPolicyName;
	}

	/**
	 * @param ffPolicyName the ffPolicyName to set
	 */
	public void setFfPolicyName(String ffPolicyName) {
		this.ffPolicyName = ffPolicyName;
	}

	/**
	 * @return the firewallBrand
	 */
	public String getFirewallBrand() {
		return firewallBrand;
	}

	/**
	 * @param firewallBrand the firewallBrand to set
	 */
	public void setFirewallBrand(String firewallBrand) {
		this.firewallBrand = firewallBrand;
	}

	/**
	 * @return the ffComment
	 */
	public String getFfComment() {
		return ffComment;
	}

	/**
	 * @param ffComment the ffComment to set
	 */
	public void setFfComment(String ffComment) {
		this.ffComment = ffComment;
	}

	



}
