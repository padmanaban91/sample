package com.citigroup.cgti.c3par.domain;

import java.util.ArrayList;

import com.citigroup.cgti.c3par.domain.Person;



/**
 * The Class BusinessDetails.
 */
public class BusinessDetails {

    /** The process id. */
    private Long processId;

    /** The request id. */
    private Long requestId;

    /** The requestor. */
    private Person requestor = new Person();

    /** The curr cycle requestor. */
    private Person currCycleRequestor = new Person();

    /** The business contacts. */
    private ArrayList businessContacts = new ArrayList();	

    /** The orig bus justification. */
    private ArrayList origBusJustification = new ArrayList();

    /** The version id. */
    private Long versionId;

    /** The fafqueue reqs. */
    private ArrayList fafqueueReqs = new ArrayList();

    /** The review status. */
    private String reviewStatus;

    /** The min version id. */
    private Long minVersionId;

    /**
     * Gets the min version id.
     *
     * @return the min version id
     */
    public Long getMinVersionId() {
	return minVersionId;
    }

    /**
     * Sets the min version id.
     *
     * @param minVersionId the new min version id
     */
    public void setMinVersionId(Long minVersionId) {
	this.minVersionId = minVersionId;
    }

    /**
     * Gets the review status.
     *
     * @return the review status
     */
    public String getReviewStatus() {
	return reviewStatus;
    }

    /**
     * Sets the review status.
     *
     * @param reviewStatus the new review status
     */
    public void setReviewStatus(String reviewStatus) {
	this.reviewStatus = reviewStatus;
    }

    /**
     * Gets the version id.
     *
     * @return the version id
     */
    public Long getVersionId() {
	return versionId;
    }

    /**
     * Sets the version id.
     *
     * @param versionId the new version id
     */
    public void setVersionId(Long versionId) {
	this.versionId = versionId;
    }

    /**
     * Gets the requestor.
     *
     * @return the requestor
     */
    public Person getRequestor() {
	return requestor;
    }

    /**
     * Sets the requestor.
     *
     * @param requestor the new requestor
     */
    public void setRequestor(Person requestor) {
	this.requestor = requestor;
    }

    /**
     * Gets the fafqueue reqs.
     *
     * @return the fafqueue reqs
     */
    public ArrayList getFafqueueReqs() {
	return fafqueueReqs;
    }

    /**
     * Sets the fafqueue reqs.
     *
     * @param fafqueueReqs the new fafqueue reqs
     */
    public void setFafqueueReqs(ArrayList fafqueueReqs) {
	this.fafqueueReqs = fafqueueReqs;
    }

    /**
     * Gets the curr cycle requestor.
     *
     * @return the curr cycle requestor
     */
    public Person getCurrCycleRequestor() {
	return currCycleRequestor;
    }

    /**
     * Sets the curr cycle requestor.
     *
     * @param currCycleRequestor the new curr cycle requestor
     */
    public void setCurrCycleRequestor(Person currCycleRequestor) {
	this.currCycleRequestor = currCycleRequestor;
    }

    /**
     * Gets the orig bus justification.
     *
     * @return the orig bus justification
     */
    public ArrayList getOrigBusJustification() {
	return origBusJustification;
    }

    /**
     * Sets the orig bus justification.
     *
     * @param origBusJustification the new orig bus justification
     */
    public void setOrigBusJustification(ArrayList origBusJustification) {
	this.origBusJustification = origBusJustification;
    }

    /**
     * Gets the business contacts.
     *
     * @return the business contacts
     */
    public ArrayList getBusinessContacts() {
	return businessContacts;
    }

    /**
     * Sets the business contacts.
     *
     * @param businessContacts the new business contacts
     */
    public void setBusinessContacts(ArrayList businessContacts) {
	this.businessContacts = businessContacts;
    }

    /**
     * Gets the process id.
     *
     * @return the process id
     */
    public Long getProcessId() {
	return processId;
    }

    /**
     * Sets the process id.
     *
     * @param processId the new process id
     */
    public void setProcessId(Long processId) {
	this.processId = processId;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public Long getRequestId() {
	return requestId;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(Long requestId) {
	this.requestId = requestId;
    }	

}