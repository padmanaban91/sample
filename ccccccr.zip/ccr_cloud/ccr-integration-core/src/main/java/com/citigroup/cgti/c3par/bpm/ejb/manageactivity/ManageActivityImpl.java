package com.citigroup.cgti.c3par.bpm.ejb.manageactivity;

import java.rmi.RemoteException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.GregorianCalendar;

import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfPurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentItem;
import net.nsroot.eur.servicesolutions.cate.integration.MessageTypeEnum;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionStatusEnum;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOrder;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOrderDocument;
import net.nsroot.eur.servicesolutions.cate.integration.Status;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.C3parTxSession;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.configuation.DatabaseUtil;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.fw.service.ResolveITQueueSenderImpl;
import com.citigroup.cgti.c3par.oneapproval.OneApprovalPersistable;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;


/**
 * The Class ManageActivityImpl.
 */
@SuppressWarnings( { "static-access", "unused" })
public class ManageActivityImpl implements IManageActivity {

	private static final String ANNUAL_CONNECTIVITY_VERIFICATION = "AnnualConnectivityVerification";
	private static final String VERIFY_SOW = "VerifySOW";

	/** The c3par session. */
	private C3parSession c3parSession;

	/** The c3par tx session. */
	private C3parTxSession c3parTxSession;

	/** The log. */
	Logger log = Logger.getLogger(ManageActivityImpl.class);
	
	private DatabaseUtil databaseUtil;
	
	private OneApprovalPersistable oneApprovalImpl;
	
	public OneApprovalPersistable getOneApprovalImpl() {
		return oneApprovalImpl;
	}

	public void setOneApprovalImpl(OneApprovalPersistable oneApprovalImpl) {
		this.oneApprovalImpl = oneApprovalImpl;
	}
	

	public DatabaseUtil getDatabaseUtil() {
		return databaseUtil;
	}

	public void setDatabaseUtil(DatabaseUtil databaseUtil) {
		this.databaseUtil = databaseUtil;
	}

	/**
	 * Sets the c3par session.
	 *
	 * @param session the new c3par session
	 */
	public void setC3parSession(C3parSession session) {
		c3parSession = session;
	}

	/**
	 * Sets the c3par tx session.
	 *
	 * @param txSession the new c3par tx session
	 */
	public void setC3parTxSession(C3parTxSession txSession) {
		c3parTxSession = txSession;
	}

	// first time insert requestid,phase,status(as required),type,activty mode
	// ,role

	//processPhase defines create/update/terminate/ACV :activityMode can be NEW/REWORK/RECONSILE/activityS
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#logActivity(com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO, long, java.lang.String)
	 */
	public long  logActivity(ActivityDataDTO activityDataDTO ,long tiRequestId,String bpmInstanceId)throws Exception {
		log.info("Ti Request Id:"+tiRequestId+"Bpm Instance Id:"+bpmInstanceId+"Activity Status:"+activityDataDTO.getActivityCode());
		Connection con = null;
		PreparedStatement pStmt = null;
		PreparedStatement pStmt1 = null;
		PreparedStatement pStmt2 = null;
		//Added for updating 
		PreparedStatement pStmt3 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		//ResultSet rs2 = null;
		long activityTrailId=-1;
		PreparedStatement pStmt4 = null;
		//PreparedStatement pStmt5 = null;
		String processMode=ActivityDataDTO.IS_NEW;

		try {
			//validate(activityData, tiRequestId);
			int tiTaskId = getTITaskId(activityDataDTO.getActivityCode());
			
			
			if(tiTaskId == 0){
				throw new Exception("Business Exception : Unknown Task Name "+activityDataDTO.getActivityCode() );
			}
			con = c3parSession.getConnection();
			if(activityDataDTO.getActivityCode().equals("pro_inf") || activityDataDTO.getActivityCode().equals("han_rfc_exc") || activityDataDTO.getActivityCode().equals("ope_imp")){
				StringBuilder updateTiActivityTrial = new StringBuilder();
				updateTiActivityTrial.append("update TI_ACTIVITY_TRAIL set  ACTIVITY_ENDDATE=sysdate,ACTIVITY_STATUS='COMPLETED'  where" );

				updateTiActivityTrial.append(" TI_REQUEST_ID=? and ACTIVITY_ID in ( ");
				updateTiActivityTrial.append(" select  id  from ti_task_type where task_code='otrm_app' ");
				updateTiActivityTrial.append(" )   and  ACTIVITY_ENDDATE is null");
				
				StringBuilder updateTiStatusTrial=new  StringBuilder();
				updateTiStatusTrial.append("update TI_ACTIVITY_TRAIL set ACTIVITY_STATUS='COMPLETED'  where" );

				updateTiStatusTrial.append(" TI_REQUEST_ID=? and ACTIVITY_ID in ( ");
				updateTiStatusTrial.append(" select  id  from ti_task_type where task_code='otrm_app' ");
				updateTiStatusTrial.append(" )   and  ACTIVITY_ENDDATE is not null");
				
				pStmt3 = con.prepareStatement(updateTiActivityTrial.toString());
				pStmt3.setLong(1, tiRequestId);
				int rowsUpdated=pStmt3.executeUpdate();
				pStmt4=con.prepareStatement(updateTiStatusTrial.toString());
				pStmt4.setLong(1, tiRequestId);
				pStmt4.executeUpdate();
				
			}
		 	// storing start process activity in ti_activty_trail- activityphase(meaning datacollection/approval) would be  null,activity type(Approval/Provide Info)- will be null,Activity name will be
			// 'Start Process' and the activitystatus will be 'completed '
			if (activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_START_PROCESS)||
					activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ACTIVE)||
					activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_TERMINATED)||
					activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ABORTED) ||
					activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_MANAGE_USER_CONTACTS_START_PROCESS)) {
				// insert into c3par.ti_activity_trail
				// (id,ti_request_id,activity_id,activity_status,user_role_id,user_id,activity_startdate,activity_enddate,activity_mode)
				// values
			
				StringBuilder instStartProcSQL = new StringBuilder();
				instStartProcSQL.append(" insert into c3par.ti_activity_trail (id,ti_request_id,activity_id,activity_status,user_role_id,user_id,activity_startdate,activity_enddate,activity_mode) values ");
				instStartProcSQL.append(" ( c3par.seq_ti_activity_trail.nextval,?,?,?,(select id from c3par.role where display_name=(select display_name from c3par.security_role where name=?)),(select id from c3par.c3par_users where sso_id like ?),SYSDATE,SYSDATE,?)");
				pStmt = con.prepareStatement(instStartProcSQL.toString());
				pStmt.setLong(1, tiRequestId);
				pStmt.setInt(2, tiTaskId);
				pStmt.setString(3, ActivityData.STATUS_COMPLETED);
				if(activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ACTIVE)||
						activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_TERMINATED)||activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ABORTED))
					pStmt.setString(3, ActivityData.STATUS_END);
				pStmt.setString(4, activityDataDTO.getUserRole());
				pStmt.setString(5, activityDataDTO.getUserID());
				pStmt.setString(6, ActivityDataDTO.IS_NEW);
				pStmt.executeUpdate();
				} else {
				//Only if their is an activity with status as completed or rejected the mode should be set to rework
				// otherwise override the mode to new
				String mode = activityDataDTO.getActivityMode();
				String processActModeSQL=" select process_activity_mode from c3par.ti_process where id=(select process_id from c3par.ti_request where id=?)";

				pStmt = con.prepareStatement(processActModeSQL);
				pStmt.setLong(1, tiRequestId);
				rs=pStmt.executeQuery();
				if (rs != null && rs.next()) {
					processMode = rs.getString(1);
				}

				c3parSession.closeStatement( pStmt );
				c3parSession.closeResultSet(rs);

				if(processMode!=null && !processMode.equalsIgnoreCase(ActivityDataDTO.IS_RECONSILE)){
				String reworkSQL=" select id from c3par.ti_activity_trail where activity_id=? and ti_request_id=? and (activity_status!=? or  activity_status!=?)";
				pStmt = con.prepareStatement(reworkSQL);
				pStmt.setLong(1, tiTaskId);
				pStmt.setLong(2,tiRequestId);
				pStmt.setString(3, ActivityDataDTO.STATUS_UNLOCK);
				pStmt.setString(4, ActivityDataDTO.STATUS_EXTENDED);
				rs=pStmt.executeQuery();
				if (rs != null && rs.next()) {
					processMode=ActivityDataDTO.IS_REWORK;
				}else
					processMode=ActivityDataDTO.IS_NEW;

				}
				if(ActivityDataDTO.TYPE_PROVIDEINFO == activityDataDTO.getActivityType())
					mode=ActivityDataDTO.IS_NEW;
				else
					mode=processMode;
			
				c3parSession.closeStatement( pStmt );
	 
				
				log.debug(" Process Mode set to while logging activity "+processMode);
				log.info(" Process Mode set to while logging activity "+processMode);
				Date lockedTaskStartDate = null;
				/*if(mode.equals(ActivityData.IS_REWORK)){
				  long activityId = getReworkActivity(tiRequestId,tiTaskId);
				  if(activityId == 0){
					  mode=ActivityData.IS_NEW;
				  }
				}
				if(activityData.getId()!=null){
				//	log.info("activity id is "+activityData.getId());
					lockedTaskStartDate=getStartDateForLockedTask(activityData.getId().longValue());
				//	log.info("startDateLo id is "+lockedTaskStartDate);
				}*/


				// to insert
				// requestid,activityphase,activityid,activitytype,activitystatus,userrole,infouserrole,activtymode
				
				
				StringBuilder instActivitySQl = new StringBuilder(" insert into c3par.ti_activity_trail (id,ti_request_id,activity_stage,activity_id,activity_type");

				instActivitySQl.append(",activity_status,user_role_id,infouser_role_id,activity_mode,activity_startdate,bpm_instance_id,pi_requested_activity)");
				instActivitySQl.append(" values (c3par.seq_ti_activity_trail.nextval,?,?,?,?,?,(select id from c3par.role where display_name=(select display_name from c3par.security_role where name=?)),(select id from c3par.role where name=?),?,?,? " +
										" ,(select tat.id from c3par.ti_activity_trail tat,c3par.ti_task_type ttt where tat.ACTIVITY_ID=ttt.id and ttt.TASK_CODE=? and tat.ACTIVITY_STATUS= ? and tat.TI_REQUEST_ID=?))");

				log.debug("insert activity sql = "+instActivitySQl.toString());

				pStmt = con.prepareStatement(instActivitySQl.toString());
				pStmt.setLong(1, tiRequestId);
				pStmt.setString(2, activityDataDTO.getActivityStage());
				pStmt.setInt(3, tiTaskId);
				pStmt.setString(4, activityDataDTO.getActivityType());
				pStmt.setString(5, ActivityDataDTO.STATUS_SCHEDULED);
				pStmt.setString(6, activityDataDTO.getUserRole());
				pStmt.setString(7, activityDataDTO.getInfoUserRole());
				pStmt.setString(8, mode);
				if(lockedTaskStartDate!=null){

					pStmt.setTimestamp(9, new java.sql.Timestamp(lockedTaskStartDate.getTime()));
				}else
					pStmt.setTimestamp(9, new java.sql.Timestamp(new Date().getTime()));
				pStmt.setString(10, bpmInstanceId);
				if(activityDataDTO.getPrInfoActivityDataDTO()!=null){
  				pStmt.setString(11,activityDataDTO.getPrInfoActivityDataDTO().getActivityCode());
				pStmt.setString(12, ActivityDataDTO.STATUS_PROVIDEINFO);
				}
				else{
				pStmt.setString(11,null);
				pStmt.setString(12, null);
				}

				pStmt.setLong(13,tiRequestId);
				pStmt.executeUpdate();
				c3parSession.closeStatement( pStmt );
				
				
				//Added for Communication Module - DK64387
				if(processMode != null && activityDataDTO.getActivityType()!=null && activityDataDTO.getActivityCode() !=null &&
						((processMode.equals(ActivityDataDTO.IS_REWORK) && activityDataDTO.getActivityCode().equalsIgnoreCase("bus_jus"))
						|| (activityDataDTO.getActivityType().equalsIgnoreCase(ActivityDataDTO.TYPE_PROVIDEINFO) 
						&& activityDataDTO.getActivityCode().equalsIgnoreCase("pro_inf")))){
					
					
					String status = getReworkStatus(tiRequestId, tiTaskId);					
								
					if (!(ActivityData.STATUS_UNLOCK.equals(status) 
							|| ActivityData.STATUS_EXTENDED.equals(status))) {						
						Long cmpRequestId= null;
						String query = "select cmp_request_id from resolve_it_notify_log where ti_request_id=?"; 
						pStmt2 = con.prepareStatement(query);
						pStmt2.setLong(1, tiRequestId);						
						rs1 = pStmt2.executeQuery();
						if(rs1!=null){
							while(rs1.next()){
								cmpRequestId = rs1.getLong(1);
								log.debug("cmpRequestId:: "+cmpRequestId);
								if(cmpRequestId != null && cmpRequestId > 0){
								String ecmInstActivitySQL="insert into c3par.ti_activity_trail (id,activity_id,activity_type,activity_status,user_id," +
										"activity_startdate,activity_mode,cmp_id) values " +
										"(c3par.seq_ti_activity_trail.nextval,(select id from c3par.ti_task_type where task_code = 'bus_jus_ecm_start')," +
										"(select task from c3par.ti_task_type where task_code = 'bus_jus_ecm_start'),?,(select id from c3par.c3par_users where sso_id = ?)," +
										"sysdate,?,?)";
								log.debug("insert activity new ecm activity = "+ecmInstActivitySQL.toString());
								pStmt1 = con.prepareStatement(ecmInstActivitySQL.toString());								
								pStmt1.setString(1, ECMConstants.STATUS_STARTED);
								pStmt1.setString(2, ECMConstants.CMP_USER_CREATION);
								pStmt1.setString(3, ActivityDataDTO.IS_NEW);
								pStmt1.setLong(4, cmpRequestId);
								pStmt1.executeUpdate();
								}
								}
							}
						}
					}
				//End of Communication Module - DK64387
				}
			
				 //update process status
			StringBuilder processUpdateSql = new StringBuilder();
					processUpdateSql.append(" update ti_process SET process_activity_mode=? where id =(select process_id from ti_request where id=?)");
					log.debug(" SQL is" + processUpdateSql.toString() );
					log.debug(" Run with values tiRequestID = " + tiRequestId );

					pStmt = con.prepareStatement(processUpdateSql.toString());
					pStmt.setString(1, processMode);
					pStmt.setLong(2, tiRequestId);
					pStmt.executeUpdate();
					String prInfoReqActDTO=null;
					if(activityDataDTO.getPrInfoActivityDataDTO()!=null)
						prInfoReqActDTO=activityDataDTO.getPrInfoActivityDataDTO().getActivityCode();
					activityTrailId=getScheduledActivityTralId(tiRequestId,activityDataDTO.getActivityCode(), prInfoReqActDTO);
					
					
					log.info("Activity code for checking isTemplateAborted:-"+activityDataDTO.getActivityCode());
					
					if(activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ABORTED))
					{
						Long processId = Long.valueOf(databaseUtil.getConnectionId(tiRequestId));
						
						log.info("Connection Id for checking isTemplateAborted:-"+processId);
						
						boolean isTemplateAborted = databaseUtil.isTemplateAborted(processId);
						
						log.info("isTemplateAborted status for checking isTemplateAborted:-"+isTemplateAborted);
						
						if(isTemplateAborted)
						{
							log.info("checking isTemplateAborted started:-"+new Date());
							databaseUtil.revertTemplateRulesToImplementedVersion(processId);
							log.info("checking isTemplateAborted Completed:-"+new Date());
						}
					}
					//Added For U[dating Activity Trail
					
					//ccrToResolveIt(tiRequestId);	


		} catch (Exception e) {
			log.error(e,e);
			throw new RemoteException(e.getMessage());
		} finally {
		
			c3parSession.closeResultSet(rs);
			c3parSession.closeResultSet(rs1);
			c3parSession.closeStatement( pStmt );
			c3parSession.closeStatement( pStmt1 );
			c3parSession.closeStatement( pStmt2 );
			c3parSession.closeStatement( pStmt3);
			c3parSession.closeStatement( pStmt4);
			try {
				 
				if(con!=null){
						c3parSession.releaseConnection();
				}
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		
		log.info("Exiting with Activity Trail id"+activityTrailId);
	return activityTrailId;
	}

 /* (non-Javadoc)
  * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#addActivity(com.citigroup.cgti.c3par.domain.ActivityData, long)
  */
 public long addActivity(ActivityData activityData, long tiRequestId) throws Exception {
		long rowsInserted = -1;
		Connection con = null;
		PreparedStatement pStmt = null;


		try {
			validate(activityData, tiRequestId);
			int tiTaskId = getTITaskId(activityData.getActivityName());
			
			if(tiTaskId == 0){
				throw new Exception("Business Exception : Unknown Task Name "+activityData.getActivityName() );
			}
			con = c3parSession.getConnection();

			// storing start process activity in ti_activty_trail-
			// activityphase(meaning datacollection/approval) would be
			// null,activity
			// type(Approval/Provide Info)- will be null,Activity name will be
			// 'Start Process' and the activitystatus will be 'completed '
			if (activityData.getActivityName().equals(ActivityData.ACTIVITY_START_PROCESS)||activityData.getActivityName().equals(ActivityData.ACTIVITY_ACTIVE)||activityData.getActivityName().equals(ActivityData.ACTIVITY_TERMINATED) ||activityData.getActivityName().equals(ActivityData.ACTIVITY_MANAGE_USER_CONTACTS_START_PROCESS)) {
				// insert into c3par.ti_activity_trail
				// (id,ti_request_id,activity_id,activity_status,user_role_id,user_id,activity_startdate,activity_enddate,activity_mode)
				// values
				StringBuilder instStartProcSQL = new StringBuilder();

				instStartProcSQL
						.append(" insert into c3par.ti_activity_trail (id,ti_request_id,activity_id,activity_status,user_role_id,user_id,activity_startdate,activity_enddate,activity_mode) values ");
				instStartProcSQL
						.append(" ( c3par.seq_ti_activity_trail.nextval,?,?,?,(select id from c3par.role where name=?),(select id from c3par.c3par_users where sso_id like ?),SYSDATE,SYSDATE,?)");
				pStmt = con.prepareStatement(instStartProcSQL.toString());
				pStmt.setLong(1, tiRequestId);
				pStmt.setInt(2, tiTaskId);
				//pStmt.setString(3, ActivityData.STATUS_SCHEDULED);
				pStmt.setString(3, ActivityData.STATUS_COMPLETED);
				if(activityData.getActivityName().equals(ActivityData.ACTIVITY_ACTIVE)||activityData.getActivityName().equals(ActivityData.ACTIVITY_TERMINATED))
					pStmt.setString(3, ActivityData.STATUS_END);
				pStmt.setString(4, activityData.getUserRole());
				pStmt.setString(5, activityData.getUserID());
				pStmt.setString(6, ActivityData.IS_NEW);

				rowsInserted = pStmt.executeUpdate();
				c3parSession.closeStatement( pStmt );
			} else {
				//Only if their is an activity with status as completed or rejected the mode should be set to rework
				// otherwise override the mode to new
				String mode = activityData.getActivityMode();

				Date lockedTaskStartDate=null;
				if(mode.equals(ActivityData.IS_REWORK)){
				  long activityId = getReworkActivity(tiRequestId,tiTaskId);
				  if(activityId == 0){
					  mode=ActivityData.IS_NEW;
				  }
				}
				if(activityData.getId()!=null){
				//	log.info("activity id is "+activityData.getId());
					lockedTaskStartDate=getStartDateForLockedTask(activityData.getId().longValue());
				//	log.info("startDateLo id is "+lockedTaskStartDate);
				}



				// to insert
				// requestid,activityphase,activityid,activitytype,activitystatus,userrole,infouserrole,activtymode
				StringBuilder instActivitySQl = new StringBuilder(
						" insert into c3par.ti_activity_trail (id,ti_request_id,activity_stage,activity_id,activity_type");

				instActivitySQl
						.append(",activity_status,user_role_id,infouser_role_id,activity_mode");
								if(lockedTaskStartDate!=null)
									instActivitySQl.append(",activity_startdate");
								instActivitySQl.append(") values (c3par.seq_ti_activity_trail.nextval,?,?,?,?,?,(select id from c3par.role where name=?),(select id from c3par.role where name=?),?");
								if(lockedTaskStartDate!=null)
									instActivitySQl.append(",?");
									instActivitySQl.append(")");


				log.debug("insert activity sql = "+instActivitySQl.toString());

				pStmt = con.prepareStatement(instActivitySQl.toString());
				pStmt.setLong(1, tiRequestId);
				pStmt.setString(2, activityData.getActivityStage());
				pStmt.setInt(3, tiTaskId);
				pStmt.setString(4, activityData.getActivityType());
				if(ActivityData.STATUS_UNLOCK.equals(activityData.getActivityStatus())||ActivityData.STATUS_UNLOCK.equals(ActivityData.STATUS_EXTENDED))
					pStmt.setString(5, activityData.STATUS_SCHEDULED);
				else
					pStmt.setString(5, activityData.getActivityStatus());
				pStmt.setString(6, activityData.getUserRole());
				pStmt.setString(7, activityData.getInfoUserRole());
				pStmt.setString(8, mode);
				if(lockedTaskStartDate!=null){
					//pStmt.setDate(9, new java.sql.Date(lockedTaskStartDate.getTime()));
					pStmt.setTimestamp(9, new java.sql.Timestamp(lockedTaskStartDate.getTime()));

				}

				rowsInserted = pStmt.executeUpdate();
				

			}
			if (activityData.getActivityName().equals(ActivityData.ACTIVITY_ACTIVE)||activityData.getActivityName().equals(ActivityData.ACTIVITY_TERMINATED) ) {
				
				_notifyResolveIT(activityData.getActivityName(),tiRequestId);
				
			}
				

		} catch (Exception e) {
			log.error(e, e);


			throw new RemoteException(e.getMessage());
		} finally {
			try {
				if (pStmt != null)
					pStmt.close();
				if(con!=null){
						c3parSession.releaseConnection();
				}
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		if (rowsInserted > 0)
			log.info("Sucessfully inserted Activity "
					+ activityData.getActivityName() + " for Request Id "
					+ tiRequestId);
		else
			log.error("Could not Insert Activity "
					+ activityData.getActivityName() + " for Request Id "
					+ tiRequestId);

		return rowsInserted;
	}

	/**
	 * Gets the rework activity.
	 *
	 * @param tiRequestId the ti request id
	 * @param tiTaskId the ti task id
	 * @return the rework activity
	 * @throws Exception the exception
	 */
	private long getReworkActivity(long tiRequestId,int tiTaskId) throws Exception{
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs=null;
		long activityId =0;
		try{
			StringBuffer activitySQL = new StringBuffer();
			activitySQL
					.append(" select max(tat.id) from c3par.ti_activity_trail tat " );
			activitySQL
					.append(" where  tat.ti_request_id=? and  activity_id=? and (activity_status='COMPLETED' or activity_status='REJECTED')");
			activitySQL
				.append(" Group by ti_request_id");

			con = c3parSession.getConnection();
			log.debug ("sql is" + activitySQL.toString());
			ps = con.prepareStatement(activitySQL.toString());
			ps.setLong(1, tiRequestId);
			ps.setInt(2, tiTaskId);
			rs = ps.executeQuery();
			if (rs != null && rs.next()) {
				activityId = rs.getLong(1);
			}
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (con != null) {
					c3parSession.releaseConnection();
				}
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		return activityId;
	}
	
	/**
	 * Gets the rework activity.
	 *
	 * @param tiRequestId the ti request id
	 * @param tiTaskId the ti task id
	 * @return the rework activity
	 * @throws Exception the exception
	 */
	private String getReworkStatus(long tiRequestId,int tiTaskId) throws Exception{
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs=null;
		String activityStatus="";
		try{
			StringBuffer activitySQL = new StringBuffer();
			activitySQL
					.append("select activity_status from c3par.ti_activity_trail where id = (select max(tat.id) from c3par.ti_activity_trail tat  " );
			activitySQL
					.append(" where  tat.ti_request_id=? and activity_id=? and activity_status!='SCHEDULED')");

			con = c3parSession.getConnection();
			log.debug ("sql is" + activitySQL.toString());
			ps = con.prepareStatement(activitySQL.toString());
			ps.setLong(1, tiRequestId);
			ps.setInt(2, tiTaskId);
			rs = ps.executeQuery();
			if (rs != null && rs.next()) {
				activityStatus = rs.getString(1);
			}
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (con != null) {
					c3parSession.releaseConnection();
				}
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		return activityStatus;
	}


	/**
	 * Validate.
	 *
	 * @param activityData the activity data
	 * @param tiRequestId the ti request id
	 * @throws Exception the exception
	 */
	private void validate(ActivityData activityData, long tiRequestId)
			throws Exception {
		StringBuffer errMsg = new StringBuffer();

		if (activityData == null)
			errMsg.append("ActivityData is Null");

		if (tiRequestId <= 0)
			errMsg.append("Invalid Request Id " + tiRequestId);
		if (activityData != null) {
			if (activityData.getActivityName() == null || !isString(activityData.getActivityName())) {
				errMsg.append("ActivityName is Empty");
			}
			// check for remaing activity data validations if activtyname is not
			// begin process
			if (activityData.getActivityName() != null
					&&( !ActivityData.ACTIVITY_START_PROCESS
							.equalsIgnoreCase(activityData.getActivityName())&& !ActivityData.ACTIVITY_ACTIVE
							.equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_TERMINATED
							.equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_ABORTED
							.equalsIgnoreCase(activityData.getActivityName())) && !ActivityData.ACTIVITY_REJECTED
							.equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_ROLLEDBACK
							.equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_MANAGE_USER_CONTACTS
							.equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_MANAGE_USER_CONTACTS_START_PROCESS
							.equalsIgnoreCase(activityData.getActivityName())) {
				if (!isString(activityData.getActivityStage())) {
					errMsg.append("ActivityStage is Empty");
				}
				if (!isString(activityData.getActivityType())) {
					errMsg.append(" ActivityType is Empty");
				}
				if (!isString(activityData.getActivityStatus())) {
					errMsg.append(" ActivityStatus is Empty");
				}

				if (isString(activityData.getActivityType()) && ActivityData.TYPE_APPROVAL.equalsIgnoreCase(activityData
						.getActivityType()) && !isString(activityData.getUserRole())) {
						errMsg.append(" Approval Activties require UserRole to be set. Check data User Role "
										+ activityData.getUserRole());
				}else if (isString(activityData.getActivityType()) && ActivityData.TYPE_PROVIDEINFO
							.equalsIgnoreCase(activityData.getActivityType()) && !isString(activityData.getInfoUserRole())) {
							errMsg
									.append(" Provide Info Activtiy requires InfouserRole to be set. Check data User Role "
											+ activityData.getInfoUserRole());
				}
			} else {
				// For start pser process activity user role is required
				// startProcess = true;
				if (!isString(activityData.getUserRole()))
					errMsg.append(" User Role is Required for Start Process");
			}
		}


		if (errMsg.length() > 0) {
			log.error(errMsg.toString());
			throw new Exception("Business Exception : "
					+ errMsg.toString());
		}
	}

/*	private void validate(ActivityData activityData, long tiRequestId)
	throws Exception {
StringBuffer errMsg = new StringBuffer();

if (activityData == null)
	errMsg.append("ActivityData is Null");

if (tiRequestId <= 0)
	errMsg.append("Invalid Request Id " + tiRequestId);
if (activityData != null) {
	if (activityData.getActivityName() == null || !isString(activityData.getActivityName())) {
		errMsg.append("ActivityName is Empty");
	}
	// check for remaing activity data validations if activtyname is not
	// begin process
	if (activityData.getActivityName() != null
			&&( !ActivityData.ACTIVITY_START_PROCESS
					.equalsIgnoreCase(activityData.getActivityName())&& !ActivityData.ACTIVITY_ACTIVE
					.equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_TERMINATED
					.equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_ABORTED
					.equalsIgnoreCase(activityData.getActivityName()))) {
		if (!isString(activityData.getActivityStage())) {
			errMsg.append("ActivityStage is Empty");
		}
		if (!isString(activityData.getActivityType())) {
			errMsg.append(" ActivityType is Empty");
		}
		if (!isString(activityData.getActivityStatus())) {
			errMsg.append(" ActivityStatus is Empty");
		}

		if (isString(activityData.getActivityType()) && ActivityData.TYPE_APPROVAL.equalsIgnoreCase(activityData
				.getActivityType()) && !isString(activityData.getUserRole())) {
				errMsg.append(" Approval Activties require UserRole to be set. Check data User Role "
								+ activityData.getUserRole());
		}else if (isString(activityData.getActivityType()) && ActivityData.TYPE_PROVIDEINFO
					.equalsIgnoreCase(activityData.getActivityType()) && !isString(activityData.getInfoUserRole())) {
					errMsg
							.append(" Provide Info Activtiy requires InfouserRole to be set. Check data User Role "
									+ activityData.getInfoUserRole());
		}
	} else {
		// For start pser process activity user role is required
		// startProcess = true;
		if (!isString(activityData.getUserRole()))
			errMsg.append(" User Role is Required for Start Process");
	}
}


if (errMsg.length() > 0) {
	log.error(errMsg.toString());
	throw new Exception("Business Exception : "
			+ errMsg.toString());
}
}*/



	/**
 * Gets the tI task id.
 *
 * @param activityName the activity name
 * @return the tI task id
 * @throws Exception the exception
 */
private int getTITaskId(String activityName) throws Exception {
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		int activityId = 0;
		try {
			String taskSQL = "select id from c3par.ti_task_type where task_code= ?";
			con = c3parSession.getConnection();
			pStmt = con.prepareStatement(taskSQL.toString());
			pStmt.setString(1, activityName);
			rs = pStmt.executeQuery();
			if (rs != null) {
				while (rs.next())
					activityId = rs.getInt(1);
			}

			if (activityId == 0) {
				throw new Exception(
						"No Activity Id associated with Activity Name "
								+ activityName);
			}
		} finally {
			try {
				if(rs != null)
					rs.close();
				if (pStmt != null)
					pStmt.close();
				if (con != null) {
					c3parSession.releaseConnection();
				}
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		return activityId;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#scheduleActivity(long, java.lang.String)
	 */
	public long scheduleActivity(long activityID, String bpmInstanceId) throws Exception {
		log.info("Setting status to Scheduled for Activty Id" + activityID);

		long rowsUpdated = -1;
		if (activityID <= 0) {
			log.error("Invalid Activity ID " + activityID);
			throw new RemoteException(
					"Business Exception : Invalid Activity ID ");
		}
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt = null;
		boolean startDateExisits=false;
		try {
			con = c3parSession.getConnection();
			String activityDetailsSQl=" select activity_startdate from c3par.ti_activity_trail where id=?";
			pStmt = con.prepareStatement(activityDetailsSQl.toString());
			pStmt.setLong(1, activityID);
			rs = pStmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					if (rs.getDate(1)!=null)
					startDateExisits=true;
				}
			}

			c3parSession.closeStatement( pStmt );


			StringBuilder schSQL = new StringBuilder("  update c3par.ti_activity_trail set activity_status=? ");
			if(!startDateExisits)
				schSQL.append(",activity_startdate=SYSDATE " );
			schSQL.append(",bpm_instance_id=? where id=? ");

			pStmt = con.prepareStatement(schSQL.toString());
			pStmt.setString(1, ActivityData.STATUS_SCHEDULED);
			pStmt.setString(2, bpmInstanceId);
			pStmt.setLong(3, activityID);
			rowsUpdated = pStmt.executeUpdate();
			notifyResolveIT(activityID, ActivityData.STATUS_SCHEDULED,ActivityData.STATUS_SCHEDULED,ActivityData.STATUS_SCHEDULED);
		} catch (Exception e) {
			log.error(e);
			throw new RemoteException(e.getMessage());
		} finally {
			c3parSession.closeResultSet(rs);
			c3parSession.closeStatement( pStmt );
			try {
				 
				if (con != null)
					c3parSession.releaseConnection();
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		if (rowsUpdated > 0)
			log.info("Sucessfully updates status for Activity ID" + activityID);
		else
			log.error("Could not updates status for Activity ID" + activityID);
		return rowsUpdated;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#lockActivity(long, java.lang.String, boolean)
	 */
	public long lockActivity(long activityTrailId, String lockedBy,boolean isForceUnlock) throws Exception {
		log.info("Setting Locked Details for TIRequestId" + activityTrailId);

		long rowsUpdated = -1;

		if (activityTrailId <= 0 || !isString(lockedBy)) {
			log.error(" TIRequestId and lockedBy are required ");
			throw new RemoteException(
					"Business Exception : TIRequestId ID and lockedBy are required ");
		}
		Connection con = null;
		ResultSet rs=null;
		String prevLockedUser=null;
		boolean isBISO=false;
		PreparedStatement pStmt = null;
		try {
			con= c3parSession.getConnection();
			/*
			 update c3par.ti_activity_trail set lockedby=(select id from c3par.c3par_users where lower(sso_id) like lower('sb47760')) ,
			locked_date=SYSDATE where id=10286
	and lockedby !=(select id from c3par.c3par_users where lower(sso_id) like lower('sb47760'))
			 */
			String lockSQL = new String(
					" update c3par.ti_activity_trail set lockedby=(select id from c3par.c3par_users where lower(sso_id) like lower(?)) ,locked_date=SYSDATE where id=? and  ( lockedby !=(select id from c3par.c3par_users where lower(sso_id) like lower(?)) or lockedby is null) ");
		/*	if(!isForceUnlock){
				pStmt=con.prepareStatement(" select USR.SSO_ID from c3par.ti_activity_trail trail,c3par.c3par_users usr where  trail.LOCKEDBY=usr.ID and trail.id=?");
			pStmt.setLong(1,activityID);
			rs=pStmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					prevLockedUser=rs.getString(1);
				}
			}
		if(prevLockedUser!=null && !prevLockedUser.equalsIgnoreCase(lockedBy)){
				log.error(" Cannot Lock an Already Locked Activity ");
				throw new RemoteException(
						"Business Exception : Cannot Lock an Already Locked Activity by "+prevLockedUser);
						}

			 StringBuffer bisoCheckSQL=new StringBuffer(" select tat.id from c3par.ti_activity_trail tat,c3par.c3par_users users,c3par.role where  ti_request_id=(select ti_request_id from c3par.ti_activity_trail where id=?)");
			 bisoCheckSQL.append(" and tat.USER_ID=users.id and users.SSO_ID=?  and tat.USER_ROLE_ID=(select id from c3par.role where name=?)and tat.ACTIVITY_ID !=(select activity_id from c3par.ti_activity_trail where id=?) ");

			 pStmt=con.prepareStatement(bisoCheckSQL.toString());
			 pStmt.setLong(1,activityID);
			 pStmt.setString(2,lockedBy);
			 pStmt.setString(3,ActivityData.ROLE_ISO);
			 pStmt.setLong(4,activityID);
			 log.debug(" SQL is "+bisoCheckSQL.toString());
			 log.debug(" Run with Activity ID = "+activityID+",lockedBy="+lockedBy);
			 rs=pStmt.executeQuery();
				if(rs!=null){
					while(rs.next()){
						isBISO=true;
					}
				}
				if(isBISO){
					log.error(" Cannot Lock this Task since you worked on "+ActivityData.ACTIVITY_ISO_APP );
						throw new RemoteException(" Business Exception : Cannot Lock  Task since you worked on ISO Approval");
						}
					}
			if(prevLockedUser==null && !isBISO ){*/

				pStmt = con.prepareStatement(lockSQL.toString());
				pStmt.setString(1, lockedBy);
				pStmt.setLong(2, activityTrailId);
				pStmt.setString(3, lockedBy);
				rowsUpdated = pStmt.executeUpdate();
				notifyResolveIT(activityTrailId, lockedBy,"LOCKED","Assigned");
			//}
		} catch (Exception e) {
			log.error(e);
			throw new RemoteException(e.getMessage());
		} finally {
			try {
				if (pStmt != null)
					pStmt.close();
				if (con != null)
					c3parSession.releaseConnection();
				if(rs!=null)
					rs.close();
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		if (rowsUpdated > 0)
			log.info("Sucessfully set locked by details  for Activity ID"
					+ activityTrailId + "as locked by " + lockedBy);
		else
			log.error("Could not  set Locked by Details for Activity ID"
					+ activityTrailId + " as locked by " + lockedBy);
		return rowsUpdated;
	}

	/* public long lockActivity(long activityID, String lockedBy ) throws Exception {
		log.info("Setting Locked Details for Activty Id" + activityID);

		long rowsUpdated = -1;
		if (activityID <= 0 || !isString(lockedBy)) {
			log.error(" Activity ID and lockedBy are required ");
			throw new RemoteException(
					"Business Exception : Activity ID and lockedBy are required ");
		}
		Connection con = null;

		PreparedStatement pStmt = null;
		try {
			con= c3parSession.getConnection();
			String lockSQL = new String(
					"  update c3par.ti_activity_trail set lockedby=(select id from c3par.c3par_users where sso_id like ?) ,locked_date=SYSDATE where id=? ");
			pStmt = con.prepareStatement(lockSQL.toString());
			pStmt.setString(1, lockedBy);
			pStmt.setLong(2, activityID);
			rowsUpdated = pStmt.executeUpdate();
		} catch (Exception e) {
			log.error(e);
			throw new RemoteException(e.getMessage());
		} finally {
			try {
				if (pStmt != null)
					pStmt.close();
				if (con != null)
					c3parSession.releaseConnection();
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		if (rowsUpdated > 0)
			log.info("Sucessfully set locked by details  for Activity ID"
					+ activityID + "as locked by " + lockedBy);
		else
			log.error("Could not  set Locked by Details for Activity ID"
					+ activityID + " as locked by " + lockedBy);
		return rowsUpdated;
	} */
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#completeActivity(long, java.lang.String, java.lang.String)
	 */
	public long completeActivity(long activityTrailId, String completedBy,String status) throws Exception {
		//log.info("Setting Locked Details for Activty Id" + activityID);
		log.info("Status:" + status+"CompletedBy:"+completedBy+"activityTrailId:"+activityTrailId);

		long rowsUpdated = -1;
		
		if(!isString(completedBy))
		{
			completedBy = "system";
		}
		
		if (activityTrailId <= 0 || !isString(completedBy) || !isString(status)) {
			log.error(" Activity ID, Completed By and Status are required -ActivityTrail ID="+activityTrailId+",Completed By="+completedBy+",Status="+status);
			throw new RemoteException(
					"Business Exception : Activity ID, Completed By and Status are required -ActivityTrail ID="+activityTrailId+",Completed By="+completedBy+",Status="+status);
		}
		Connection con = null;
		PreparedStatement pStmt = null;
		PreparedStatement pStmt1 = null;
		PreparedStatement pStmt2 = null;
		PreparedStatement pStmt3 = null;
		
		try {
			con= c3parSession.getConnection();
			StringBuffer completeSQl=null;
			
			if(ActivityData.STATUS_PROVIDEINFO.equals(status)){
			
				completeSQl = new StringBuffer("  update c3par.ti_activity_trail set activity_status=? , user_id=(select id from c3par.c3par_users where lower(sso_id)=lower('"+completedBy+"')) where id=?");
			}else {
				completeSQl = new StringBuffer("  update c3par.ti_activity_trail set user_id=(select id from c3par.c3par_users where lower(sso_id)=lower('"+completedBy+"'))");
				completeSQl.append(" ,activity_enddate=SYSDATE ,activity_status=? where id=? and  ACTIVITY_ENDDATE is null ");
			}
			pStmt = con.prepareStatement(completeSQl.toString());

			pStmt.setString(1, status);
			pStmt.setLong(2, activityTrailId);
			rowsUpdated = pStmt.executeUpdate();
			notifyResolveIT(activityTrailId,completedBy,status,status);
			
			log.debug("NotifyResolveIT completed..");
			
			/*Added for Cancel One Approval By NE36745 - Starts */
			ResultSet rs=null;
		  	String approvalSystem = null;
		  	Long tiRequestId = null;
		  	Long conId = null;
		  	Long version=null;
		  	String bpmInstanceId = null;
		  	String task = null;
		  	try{
		  		log.debug("OneApproval Cancel functionality started..");
		  		String activitySQL="select tat.approval_system, tr.id, tr.process_id, tr.version_number, tat.bpm_instance_id, " +
		  				" (select task_code from c3par.ti_task_type where id = tat.activity_id) as task from c3par.ti_activity_trail tat, ti_request tr where tat.ti_request_id = tr.id and tat.id = ?";
			    pStmt = con.prepareStatement(activitySQL.toString());
			    log.debug(" SQL is "+ activitySQL.toString() );
			    pStmt.setLong(1,activityTrailId);

				rs = pStmt.executeQuery();
				log.debug(" SQL is "+ activitySQL.toString() );
				log.debug(" with  Conditions activityId = " +activityTrailId );
				if(rs!=null){
					while(rs.next()){
						approvalSystem = rs.getString(1);
						tiRequestId = rs.getLong(2);
						conId = rs.getLong(3);
						version = rs.getLong(4);
						bpmInstanceId = rs.getString(5);
						task = rs.getString(6);
						break;
					}
				}
				log.debug("OneApproval Cancel functionality : approvalSystem : "+approvalSystem);
				log.debug("OneApproval Cancel functionality : tiRequestId : "+tiRequestId);
				log.debug("OneApproval Cancel functionality : conId : "+conId);
				log.debug("OneApproval Cancel functionality : version : "+version);
				log.debug("OneApproval Cancel functionality : bpmInstanceId : "+bpmInstanceId);
				log.debug("OneApproval Cancel functionality : task : "+task);
				
				if(task.equals("pro_inf") && status.equals(ActivityData.STATUS_COMPLETED)){
					log.info("Inserting GIS Approval Audit once  Pro_inf is Completed");
					
					String insertSQL= "insert into c3par.ti_activity_trail (id,ti_request_id,activity_id,activity_status, "
							+" user_role_id,user_id,activity_startdate,activity_mode) "
							+" (select seq_ti_activity_trail.nextval,ti_request_id,(select id from c3par.ti_task_type where task_code = 'otrm_app'),?, "
							+" (select id from ROLE where NAME='OTRM'),user_id,sysdate,'REWORK' from ti_activity_trail where id = ?)";
					pStmt3 = con.prepareStatement(insertSQL);
					pStmt3.setString(1, ActivityData.STATUS_PROVIDEINFO);
					//pStmt3.setString(2, "OTRM");
					pStmt3.setLong(2, activityTrailId);
						rowsUpdated = pStmt3.executeUpdate();
						log.info("GIS Approval Record Inserted Successfully "+rowsUpdated);
						
								
					
				}
				if (approvalSystem != null && !(approvalSystem.equalsIgnoreCase(OneApprovalConstants.APPROVAL_SYSTEM_OA) 
						|| approvalSystem.equalsIgnoreCase(OneApprovalConstants.APPROVAL_SYSTEM_OA)) && task != null 
						&& (task.equalsIgnoreCase(ActivityData.ACTIVITY_ISO_APP) 
								|| task.equalsIgnoreCase(ActivityData.ACTIVITY_VERIFY_SOW) || task.contains(ANNUAL_CONNECTIVITY_VERIFICATION) || task.contains(VERIFY_SOW) )) {
					if(task.equalsIgnoreCase(ActivityData.ACTIVITY_VERIFY_SOW) || task.contains(ANNUAL_CONNECTIVITY_VERIFICATION) || task.contains(VERIFY_SOW)) {
						oneApprovalImpl.createOneApproval(conId,tiRequestId,
								bpmInstanceId,version,OneApprovalConstants.ACTIVITY_ACV,true);
					} else {
						
						oneApprovalImpl.createOneApproval(conId,tiRequestId,
								bpmInstanceId,version,null,true);
					}
				} else if (task != null && task.equalsIgnoreCase(ActivityData.ACTIVITY_BUS_JUS) && !ActivityData.STATUS_UNLOCK.equalsIgnoreCase(status)) {					
					String insertSQL= "insert into c3par.ti_activity_trail (id,ti_request_id,activity_id,activity_status, "
						+" user_role_id,user_id,activity_startdate,activity_enddate,activity_mode) "
						+" (select seq_ti_activity_trail.nextval,ti_request_id,(select id from c3par.ti_task_type where task_code = 'tec_arc'),?, "
						+" user_role_id,user_id,activity_startdate,activity_enddate,activity_mode from ti_activity_trail where id = ?)";
					pStmt = con.prepareStatement(insertSQL);

					pStmt.setString(1, status);
					pStmt.setLong(2, activityTrailId);
					rowsUpdated = pStmt.executeUpdate();
					//Added for ECM -DK64387
					Long ecmActTrailId = null;					
					String ecmActivitySQL = "select id from ti_activity_trail where id in (select tat.id from ti_activity_trail tat, resolve_it_notify_log rinl where "
									+" rinl.cmp_request_id=tat.cmp_id  and rinl.TI_REQUEST_ID = ? and tat.ACTIVITY_ENDDATE is null and tat.ACTIVITY_STATUS= ?)";
					pStmt1 = con.prepareStatement(ecmActivitySQL);					 
					pStmt1.setLong(1, tiRequestId);
					pStmt1.setString(2, ActivityData.STATUS_STARTED);
					rs = pStmt1.executeQuery();
					log.debug(" SQL is "+ ecmActivitySQL.toString() +"tiRequestId" +tiRequestId );
					if(rs!=null){
						while(rs.next()){
							ecmActTrailId = rs.getLong(1);
							log.info("ECM Activity Trail Id:: "+ecmActTrailId);
							if(ecmActTrailId != null){
								String updateECMSQL = "update ti_activity_trail set ACTIVITY_STATUS=?,ACTIVITY_ENDDATE =sysdate where id=?";
								pStmt2 = con.prepareStatement(updateECMSQL);
								pStmt2.setString(1, ActivityData.STATUS_COMPLETED);
								pStmt2.setLong(2, ecmActTrailId);
								int count = pStmt2.executeUpdate();
								log.debug("Updated successfully for ecm activity"+count);						
							}							
						}
					}					
					
				String ecmQuery = "select ta.id from ti_activity_trail ta where ta.id in (select tat.id from ti_activity_trail tat,ti_task_type tt where " +
							 "tat.ti_request_id=? and tat.activity_status=? and tat.ACTIVITY_ID = tt.ID and tt.TASK_CODE='bus_jus_ecm_start' and tat.ACTIVITY_ENDDATE is null)";
				pStmt1 = con.prepareStatement(ecmQuery);
				pStmt1.setLong(1, tiRequestId);
				pStmt1.setString(2,ActivityData.STATUS_STARTED);
				rs = pStmt1.executeQuery();
				if(rs!=null){
					while(rs.next()){
						ecmActTrailId = rs.getLong(1);
						log.info("ECM Activity Trail Id:: "+ecmActTrailId);
						if(ecmActTrailId != null){
							String updateECMSQL = "update ti_activity_trail set ACTIVITY_STATUS=?,ACTIVITY_ENDDATE =sysdate where id=?";
							pStmt2 = con.prepareStatement(updateECMSQL);
							pStmt2.setString(1, ActivityData.STATUS_COMPLETED);
							pStmt2.setLong(2, ecmActTrailId);
							int count = pStmt2.executeUpdate();
							log.debug("Updated successfully for ecm activity"+count);						
						}							
					}
				}
				}else if (task != null && task.equalsIgnoreCase(ActivityData.ACTIVITY_PC_PRO_INF) && !ActivityData.STATUS_UNLOCK.equalsIgnoreCase(status)) {
					Long ecmActTrailIdPc = null;					
					String ecmActivitySQLPc = "select id from ti_activity_trail where id in (select tat.id from ti_activity_trail tat, resolve_it_notify_log rinl where "
									+" rinl.cmp_request_id=tat.cmp_id  and rinl.TI_REQUEST_ID = ? and tat.ACTIVITY_ENDDATE is null and tat.ACTIVITY_STATUS= ?)";
					pStmt1 = con.prepareStatement(ecmActivitySQLPc);					 
					pStmt1.setLong(1, tiRequestId);
					pStmt1.setString(2, ActivityData.STATUS_STARTED);
					rs = pStmt1.executeQuery();
					log.debug(" SQL is "+ ecmActivitySQLPc.toString() +"tiRequestId" +tiRequestId );
					if(rs!=null){
						while(rs.next()){
							ecmActTrailIdPc = rs.getLong(1);
							log.info("ECM Activity Trail Id:: "+ecmActTrailIdPc);
							if(ecmActTrailIdPc != null){
								String updateECMSQL = "update ti_activity_trail set ACTIVITY_STATUS=?,ACTIVITY_ENDDATE =sysdate where id=?";
								pStmt2 = con.prepareStatement(updateECMSQL);
								pStmt2.setString(1, ActivityData.STATUS_COMPLETED);
								pStmt2.setLong(2, ecmActTrailIdPc);
								int count = pStmt2.executeUpdate();
								log.debug("Updated successfully for ecm activity : "+count);						
							}							
						}
					}
				}
				
				//End of ECM -DK64387				
				log.debug("OneApproval Cancel functionality ended..");
				
			   } catch (Exception e) {
					log.error(e, e);
				}
				finally{
					if(rs!=null)
		    		rs.close();
					if(pStmt!=null)
						pStmt.close();
					if(pStmt1!=null)
						pStmt1.close();
					if(pStmt2!=null)
						pStmt2.close();
					if(pStmt3!=null)
						pStmt3.close();
					if(con!=null){
		    		  c3parSession.releaseConnection();
		    		}
				}
			
			/*Added for Cancel One Approval By NE36745 - Ends */
			
		} catch (Exception e) {
			log.error(e,e);
			throw new RemoteException(e.getMessage());
		} finally {
			try {
				if (pStmt != null)
					pStmt.close();
				if (con != null)
					c3parSession.releaseConnection();
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		if (rowsUpdated > 0)
			log.info(" Sucessfully set Activity status to "+status+" by user "+completedBy+" for activityTrailId  "+activityTrailId);
		else
			log.error("Could not  setActivity status to "+status+" by user "+completedBy+" for activityTrailId"+activityTrailId);

		return rowsUpdated;
	}
	public void _notifyResolveIT(String activity,long tirequestId) {
		Connection con = null;
		String userID = null;
		String completedBy = null;
		String cmpID = null;
		String[] cmpIDs = null;
		String processID = null;
		String task = null;
		String activityStatusExist = null;
		PreparedStatement pStmt = null;
		PreparedStatement pStmt1 = null;
		PreparedStatement pStmt2 = null;
		PreparedStatement pStmt3 = null;
		PreparedStatement pStmt4 = null;
		PreparedStatement pStmt5 = null;
		PreparedStatement pStmt6 = null;
		PreparedStatement pStmt7 = null;

		String activityStatus = activity + ":" + tirequestId ;
		
		/*20
		18*/
		try {
			log.info("Notify ResolveIT on completing activity:"
					+ activityStatus);
			con = c3parSession.getConnection();

			pStmt5 = con
					.prepareStatement("select Activity_Status from resolve_it_notify_log where Activity_Status=?");
			pStmt5.setString(1, activityStatus);
			ResultSet resultSet4 = pStmt5.executeQuery();
			if (resultSet4.next()) {
				activityStatusExist = resultSet4.getString("Activity_Status");
			}

			if (activityStatusExist == null || "".equals(activityStatusExist)) {

				

				pStmt6 = con
				.prepareStatement("select  u.sso_id from c3par.ti_activity_trail t,c3par_users u where t.ti_request_id=?"+
						 " and t.activity_id=18 and u.id=t.user_id");
				pStmt6.setLong(1, tirequestId);
		ResultSet resultSet6 = pStmt6.executeQuery();
		if (resultSet6.next()) {
			completedBy = resultSet6.getString("sso_id");
		}
				if (completedBy != null) {
					pStmt = con
							.prepareStatement("select geid from citi_contact where upper(sso_id)=?");
					pStmt.setString(1, completedBy.toUpperCase());
					ResultSet resultSet = pStmt.executeQuery();
					if (resultSet.next()) {
						userID = resultSet.getString("geid");
					}
					/*if(userID==null || "".equals(userID)){
						userID=completedBy;
					}*/

				}/*else{
					userID="SYSTEM";
					}*/

				if (userID != null) {

					pStmt3 = con
							.prepareStatement("select cmp_id,process_id from ti_request where id=? ");
					pStmt3.setLong(1, tirequestId);
					ResultSet resultSet3 = pStmt3.executeQuery();
					if (resultSet3.next()) {
						String cmpString=(resultSet3.getString("cmp_id"));
						if(cmpString!=null){
							cmpIDs = cmpString.split(",");
						}
						processID=(resultSet3.getString("process_id"));
					}
					if (cmpIDs !=null) {
						for (int i = 0; i < cmpIDs.length; i++) {
							cmpID = cmpIDs[i];
							pStmt2 = con
									.prepareStatement("select notify_xml from resolve_it_notify_log where cmp_id=? ");
							pStmt2.setString(1, cmpID);
							ResultSet resultSet2 = pStmt2.executeQuery();
							ResolveITQueueSenderImpl resolveITQueueSenderImpl = new ResolveITQueueSenderImpl();
							log
									.debug("completeActivity.sendMesage Resolve IT for cmpID"
											+ tirequestId + ":" + cmpID);
							if (resultSet2.next()) {
								log
										.debug("Notify ResolveIT message parsing object >>");
								Blob data = resultSet2.getBlob("notify_xml");
								;
								String xmlToString = new String(data.getBytes(1L,
										Integer.parseInt("" + data.length())));
								log
										.debug("Notify ResolveIT message parsing object >>"
												+ xmlToString);
								PurchaseOrderDocument purchaseOrderDocument = null;
								purchaseOrderDocument = PurchaseOrderDocument.Factory
										.parse(xmlToString);
								PurchaseOrder purchaseOrder = purchaseOrderDocument
										.getPurchaseOrder();
								ArrayOfPurchaseOptionDescription arrayOfPurchaseOptionDescription = purchaseOrder
										.getPurchaseOptions();
								PurchaseOptionDescription purchaseOptionDescription = arrayOfPurchaseOptionDescription
										.getPurchaseOptionDescriptionArray(0);
								purchaseOptionDescription
										.setMessageType(MessageTypeEnum.UPDATE);
								purchaseOptionDescription
										.setOrderTimeUtc(new GregorianCalendar());
								FulfilmentItem fulfilmentItem = purchaseOptionDescription
										.getFulfilmentItem();

								Status ccrStatus = fulfilmentItem.getStatus();
								
								
								if("Active".equalsIgnoreCase(activity)){
									ccrStatus
									.setStatus(PurchaseOptionStatusEnum.COMPLETED);
									
								}else {
									ccrStatus
									.setStatus(PurchaseOptionStatusEnum.CREATED);
									
								}
								if("Active".equalsIgnoreCase(activity)){
									activity="Activated";
									
								}
								ccrStatus.setComments("CCRId:" + processID
										+ " is " +activity+" by " + completedBy);
								
								//status.setComments("Request received for "+resolveITNotifyQueueReadImpl.getTaskCode()+" and logged in CCR system.");
								ccrStatus.setUpdatedByUserID(userID);
								ccrStatus
										.setUpdatedDateTimeUtc(new GregorianCalendar());
								/*DataFieldUrl url = ccrStatus.addNewUrl();
								ccrStatus.setUrl(url);
								purchaseOptionDescription.setFulfilmentItem(fulfilmentItem);*/
								String toPost = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
										+ purchaseOrderDocument.xmlText();
								resolveITQueueSenderImpl.sendMesage(toPost);
								log
								.debug("Notify ResolveIT to check status"
										+ toPost);

								pStmt4 = con
										.prepareStatement("update resolve_it_notify_log set Activity_Status = ? ,UPDATED_DATE = sysdate where cmp_id=? ");
								pStmt4.setString(1, activityStatus);
								pStmt4.setString(2, cmpID);
								int row = pStmt4.executeUpdate();

							}
							//Added for Communication Module -DK64387							
							pStmt7 = con
									.prepareStatement("update cmp_request set status = ?,CLOSED_DATE = sysdate where order_id=? ");
							pStmt7.setString(1, ActivityDataDTO.STATUS_COMPLETED);
							pStmt7.setString(2, cmpID);
							int count = pStmt7.executeUpdate();
							log.info("count in the active status:: "+count);
								
							//End of Communication Module -DK64387
							}
						}					
					
				}

			}
		} catch (Exception e) {
			log.error("fafRequest.sendMesage" + e.getMessage());
			e.printStackTrace();
		} catch (Throwable e) {
			log.error("fafRequest.sendMesageThrowable" + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (pStmt != null)
					pStmt.close();
				if (pStmt1 != null)
					pStmt1.close();
				if (pStmt2 != null)
					pStmt2.close();
				if (pStmt3 != null)
					pStmt3.close();
				if (pStmt4 != null)
					pStmt4.close();
				if (pStmt5 != null)
					pStmt5.close();
				if (pStmt6 != null)
					pStmt6.close();
				if (pStmt7 != null)
					pStmt7.close();
				if (con != null)
					c3parSession.releaseConnection();
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}

	}
	public void notifyResolveIT(long activityTrailId,String completedBy,String activity,String status) {
		Connection con = null;
		String userID=null;
		String cmpID = null;
		String[] cmpIDs = null;
		String processID = null;
		String task = null;
		String activityStatusExist = null;
		PreparedStatement pStmt = null;
		PreparedStatement pStmt1 = null;
		PreparedStatement pStmt2 = null;
		PreparedStatement pStmt3 = null;
		PreparedStatement pStmt4 = null;
		PreparedStatement pStmt5 = null;
		PreparedStatement pStmt6 = null;
		PreparedStatement pStmt7 = null;
		String activityStatus = null;
		if(activityTrailId != 0 && completedBy != null && activity!= null){
		 activityStatus=activityTrailId+":"+completedBy+":"+activity+":"+status;
		}
		try {
			log.info("Notify ResolveIT on completing activity:"
					+ activityTrailId);
			log.info("Notify ResolveIT activityTrailId:completedBy:activity:status:"
					+ activityTrailId+":"+completedBy+":"+activity+":"+status);
			con = c3parSession.getConnection();
			
			pStmt5 = con.prepareStatement("select Activity_Status from resolve_it_notify_log where Activity_Status=?");
			pStmt5.setString(1, activityStatus);
			ResultSet resultSet4 = pStmt5.executeQuery();
			if (resultSet4.next() ) {
				activityStatusExist = resultSet4.getString("Activity_Status");
			}
			
			if(activityStatusExist == null || "".equals(activityStatusExist)){
			
			if(completedBy!=null){
				pStmt = con.prepareStatement("select geid from citi_contact where upper(sso_id)=?");
				pStmt.setString(1, completedBy.toUpperCase());
				ResultSet resultSet = pStmt.executeQuery();
				if (resultSet.next()) {
					userID = resultSet.getString("geid");
				}
				/*if(userID==null || "".equals(userID)){
					userID=completedBy;
				}*/
				
			}/*else{
				userID="SYSTEM";
			}*/
			
			if(userID!=null){
				pStmt1 = con
						.prepareStatement("select task from ti_task_type where id=(select  activity_id from c3par.ti_activity_trail where id=?)");
				pStmt1.setLong(1, activityTrailId);
				ResultSet resultSet1 = pStmt1.executeQuery();
				if (resultSet1.next()) {
					task = resultSet1.getString("task");
				}
				pStmt3 = con
						.prepareStatement("select cmp_id,process_id from ti_request where id=(select  ti_request_id from c3par.ti_activity_trail where id=?)");
				pStmt3.setLong(1, activityTrailId);
				ResultSet resultSet3 = pStmt3.executeQuery();
				if (resultSet3.next()) {
					String cmpString=(resultSet3.getString("cmp_id"));
					if(cmpString!=null){
						cmpIDs = cmpString.split(",");
					}
					
					processID = resultSet3.getString("process_id");
				}
				if (cmpIDs !=null) {
					for (int i = 0; i < cmpIDs.length; i++) {
						cmpID = cmpIDs[i];
						pStmt2 = con
								.prepareStatement("select notify_xml from resolve_it_notify_log where cmp_id=? ");
						pStmt2.setString(1, cmpID);
						ResultSet resultSet2 = pStmt2.executeQuery();
						ResolveITQueueSenderImpl resolveITQueueSenderImpl = new ResolveITQueueSenderImpl();
						log
								.info("completeActivity.sendMesage Resolve IT for cmpID"
										+ activityTrailId + ":" + cmpID);
						if (resultSet2.next()) {
							log
									.info("Notify ResolveIT message parsing object >>");
							Blob data = resultSet2.getBlob("notify_xml");
							;
							String xmlToString = new String(data.getBytes(1L,
									Integer.parseInt("" + data.length())));
							log
									.info("Notify ResolveIT message parsing object >>"
											+ xmlToString);
							PurchaseOrderDocument purchaseOrderDocument = null;
							purchaseOrderDocument = PurchaseOrderDocument.Factory
									.parse(xmlToString);
							PurchaseOrder purchaseOrder = purchaseOrderDocument
									.getPurchaseOrder();
							ArrayOfPurchaseOptionDescription arrayOfPurchaseOptionDescription = purchaseOrder
									.getPurchaseOptions();
							PurchaseOptionDescription purchaseOptionDescription = arrayOfPurchaseOptionDescription
									.getPurchaseOptionDescriptionArray(0);
							purchaseOptionDescription
									.setMessageType(MessageTypeEnum.UPDATE);
							purchaseOptionDescription
									.setOrderTimeUtc(new GregorianCalendar());
							FulfilmentItem fulfilmentItem = purchaseOptionDescription
									.getFulfilmentItem();

							Status ccrStatus = fulfilmentItem.getStatus();
							if (ActivityData.STATUS_SCHEDULED
									.equalsIgnoreCase(activity)) {
								ccrStatus.setComments(task
										+ " : SCHEDULED, CCRId:" + processID
										+ " by " + completedBy);
							} else if ("END".equalsIgnoreCase(activity)) {
								ccrStatus.setComments(task
										+ " : Completed, CCRId:" + processID
										+ " by " + completedBy);
								
								//, Next Task: ISO Approval ");
							} else if ("LOCKED".equalsIgnoreCase(activity)) {
								ccrStatus.setComments(task
										+ " : Inprogress, CCRId:" + processID
										+ " by " + completedBy);
								//, Next Task: ISO Approval ");
							} else {
								ccrStatus.setComments(task + " : " + status
										+ ", CCRId:" + processID + " by "
										+ completedBy);
							}
							if ("END".equalsIgnoreCase(activity)) {
								ccrStatus.setStatus(PurchaseOptionStatusEnum.COMPLETED);
							} else {
							if ("END".equalsIgnoreCase(activity)) {
								ccrStatus.setStatus(PurchaseOptionStatusEnum.COMPLETED);
							} else {
								ccrStatus
								.setStatus(PurchaseOptionStatusEnum.CREATED);
							}
							
							}
							//status.setComments("Request received for "+resolveITNotifyQueueReadImpl.getTaskCode()+" and logged in CCR system.");
							ccrStatus.setUpdatedByUserID(userID);
							ccrStatus
									.setUpdatedDateTimeUtc(new GregorianCalendar());
							/*DataFieldUrl url = ccrStatus.addNewUrl();
							ccrStatus.setUrl(url);
							purchaseOptionDescription.setFulfilmentItem(fulfilmentItem);*/
							String toPost = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
									+ purchaseOrderDocument.xmlText();
							resolveITQueueSenderImpl.sendMesage(toPost);

							pStmt4 = con
									.prepareStatement("update resolve_it_notify_log set Activity_Status = ?,UPDATED_DATE = sysdate where cmp_id=? ");
							pStmt4.setString(1, activityStatus);
							pStmt4.setString(2, cmpID);
							int row = pStmt4.executeUpdate();
							
							/*if(activity.equalsIgnoreCase("rejected")){
								pStmt6 = con
										.prepareStatement("update cmp_request set status = ?,CLOSED_DATE = sysdate where order_id=? ");
								pStmt6.setString(1, ActivityDataDTO.STATUS_COMPLETED);
								pStmt6.setString(2, cmpID);
								int count = pStmt6.executeUpdate();
								log.info("count:: "+count);
							}*/
							
							if(activity.equalsIgnoreCase("aborted")){
								pStmt7 = con
										.prepareStatement("update cmp_request set ccr_id=null,UPDATED_DATE = sysdate where order_id=? ");								
								pStmt7.setString(1, cmpID);
								int count = pStmt7.executeUpdate();
								log.info("count:: "+count);
							}

						}
					}
				}
			}
			
			}
		} catch (Exception e) {
			log.error("fafRequest.sendMesage" + e.getMessage());
			e.printStackTrace();
		}catch (Throwable e) {
			log.error("fafRequest.sendMesageThrowable" + e.getMessage());
			e.printStackTrace();
		}finally {
			try {
				if (pStmt != null)
					pStmt.close();
				if (pStmt1 != null)
					pStmt1.close();
				if (pStmt2 != null)
					pStmt2.close();
				if (pStmt3 != null)
					pStmt3.close();
				if (pStmt4 != null)
					pStmt4.close();
				if (pStmt5 != null)
					pStmt5.close();
				if (pStmt6 != null)
					pStmt6.close();
				if (pStmt7 != null)
					pStmt7.close();
				if (con != null)
					c3parSession.releaseConnection();
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		
	}
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#completeExceptionActivity(long, java.lang.String, java.lang.String)
	 */
	public long completeExceptionActivity(long tiRequestId, String activityCode,String prInfoActivityCode) throws Exception {
		log.info("CompleteExceptionActivity for tiRequestId " + tiRequestId);
		long rowsUpdated = -1;
		if (tiRequestId >0){
			Connection con = null;
			ResultSet rs=null;

		PreparedStatement pStmt = null;
		try {
			con= c3parSession.getConnection();
			 String scheduledTaskSQl = (" select tat.id,ttt.TASK_CODE from c3par.ti_activity_trail tat,c3par.ti_task_type ttt where tat.activity_status=? and tat.ACTIVITY_ID=ttt.ID and tat.ti_request_id=?");
			pStmt = con.prepareStatement(scheduledTaskSQl);
			pStmt.setString(1, ActivityDataDTO.STATUS_SCHEDULED);
			pStmt.setLong(2, tiRequestId);
			rs = pStmt.executeQuery();

			if(rs!=null){
				while(rs.next()){
					log.info(" Activity Id "+rs.getLong(1)+" with task_code "+rs.getString(2) +" is scheduled and will be updated to  Error status ");
					}
			}
			
			c3parSession.closeStatement( pStmt );
		 
			
			StringBuilder updateErrorStatSQL=new StringBuilder(" update c3par.ti_activity_trail set activity_status=?,activity_enddate=SYSDATE ,user_id=(select id from c3par.c3par_users where lower(sso_id)=lower('system'))" );
			updateErrorStatSQL.append(" where ti_request_id=? and activity_status=? ");

			pStmt = con.prepareStatement(updateErrorStatSQL.toString());

			pStmt.setString(1, ActivityDataDTO.STATUS_ERROR);
			pStmt.setLong(2, tiRequestId);
			pStmt.setString(3, ActivityDataDTO.STATUS_SCHEDULED);

			rowsUpdated = pStmt.executeUpdate();

		} catch (Exception e) {
			log.error(e);
			throw new RemoteException(e.getMessage());
		} finally {
			c3parSession.closeStatement( pStmt );
			c3parSession.closeResultSet(rs);
			try {
			 
				if (con != null)
					c3parSession.releaseConnection();
			} catch (Exception exp) {
				exp.printStackTrace();
			}
		}
		}
		if (rowsUpdated > 0)

			log.info(" Sucessfully Flagged Scheduled  Activity status to "+ActivityDataDTO.STATUS_ERROR + " For TiRequestId "+tiRequestId);
		else
			log.info(" Could not Flag Scheduled  Activity status to "+ActivityDataDTO.STATUS_ERROR + " For TiRequestId "+tiRequestId);

		return rowsUpdated;
	}




		 /**
 		 * Sets the request deadline.
 		 *
 		 * @param date the new request deadline
 		 * @throws Exception the exception
 		 */
 		public void setRequestDeadline(Date date) throws Exception{

	 }
	 //overloaded Lock Method
	 /* (non-Javadoc)
 	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#lockActivity(long, java.lang.String)
 	 */
 	public void lockActivity(long tiRequestID, String lockedBy) throws Exception{
		/* Connection con = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 try{
		    StringBuffer lockSQL=new StringBuffer(" select tac.id, usr.SSO_ID from c3par.ti_activity_trail tac,c3par.c3par_users usr  where tac.ti_request_id=123 and tac.LOCKEDBY=usr.id(+)  and tac.activity_status='SCHEDULED'");
		 	ps = con.prepareStatement(lockSQL.toString());
		 	ps.setLong(1, tiRequestID);
			rs = ps.executeQuery();
			long activityID;
			String alreadyLockedUsr=null;
			if (rs != null) {
				while (rs.next()) {
					activityID=rs.getLong(1);
					alreadyLockedUsr=rs.getString(1);
									}
			}
		 }
		 catch (Exception e) {
				log.error(e);
				throw new Exception(e.getMessage());

			} finally {
				try {
					if (rs != null)
						rs.close();
					if (ps != null)
						ps.close();
					if (con != null) {
						c3parSession.releaseConnection();
					}
				} catch (Exception exp) {
					exp.printStackTrace();
				}
			}*/


	 }

 	/**
 	 * Gets the start date for locked task.
 	 *
 	 * @param activityId the activity id
 	 * @return the start date for locked task
 	 * @throws Exception the exception
 	 */
 	private Date getStartDateForLockedTask(long activityId) throws Exception{
			Connection con=null;
		  	PreparedStatement pStmt=null;
		  	ResultSet rs=null;

		  	Date startDate=null;
		  	try{
		  		String activitySQL="select activity_startdate from c3par.ti_activity_trail where activity_status='UNLOCKED'  and id=?";
		  		con =c3parSession.getConnection();
			    pStmt = con.prepareStatement(activitySQL.toString());
			    pStmt.setLong(1,activityId);

				rs = pStmt.executeQuery();
				log.debug(" SQL is "+ activitySQL.toString() );
				log.debug(" with  Conditions activityId = " +activityId );
				if(rs!=null){
					while(rs.next()){
						startDate=rs.getTimestamp(1);

						break;
					}
				}

			   }
				finally{
					if(rs!=null)
		    		rs.close();
					if(pStmt!=null)
						pStmt.close();
					if(con!=null){
		    		  c3parSession.releaseConnection();
		    		}
				}
			return startDate;


		}
 	
 	/* (non-Javadoc)
 	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#getProvideInfoActivity(long)
 	 */
 	public String getProvideInfoActivity(long tiRequestID) throws Exception{
		 Connection con=null;
		  	PreparedStatement pStmt=null;
		  	ResultSet rs=null;

		  	String provideInfoRequestedCode=null;
		  	try{
		  		String provideInfoSQL=" select ttt.TASK_CODE from c3par.ti_activity_trail tat ,c3par.ti_task_type ttt where ti_request_id=? and activity_status like 'PROVIDEINFO' and tat.ACTIVITY_ID=ttt.id";
		  		con =c3parSession.getConnection();
			    pStmt = con.prepareStatement(provideInfoSQL.toString());
			    pStmt.setLong(1,tiRequestID);

				rs = pStmt.executeQuery();
				log.debug(" SQL is "+ provideInfoSQL.toString() );
				log.debug(" with  Conditions activityId = " +tiRequestID );
				if(rs!=null){
					while(rs.next()){
						provideInfoRequestedCode=rs.getString(1);
						break;
					}
				}

			   }
				finally{
					if(rs!=null)
		    		rs.close();
					if(pStmt!=null)
						pStmt.close();
					if(con!=null){
		    		  c3parSession.releaseConnection();
		    		}
				}
			return provideInfoRequestedCode;

	 }

 	/* (non-Javadoc)
 	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#getCurrentActivityRole(long, java.lang.String)
 	 */
 	public String getCurrentActivityRole(long tiRequestID,String prInfoRequestedActivityCode) throws Exception{
		 	Connection con=null;
		  	PreparedStatement pStmt=null;
		  	ResultSet rs=null;
		  	String role=null;
		  	try{
		   		StringBuffer currRoleSQL=new StringBuffer(" select rl.name from c3par.ti_activity_trail tat ,c3par.ti_request  tir,c3par.role rl,c3par.ti_activity_trail prreq");
		  		currRoleSQL.append(" where tir.id=tat.ti_request_id and tat.activity_status=? and tat.infouser_role_id=rl.id ");
		  		currRoleSQL.append(" and tat.pi_requested_activity=prreq.id and prreq.activity_id=(select id from c3par.ti_task_type where task_code=?) and tir.id=?");
	  			con =c3parSession.getConnection();
			    pStmt = con.prepareStatement(currRoleSQL.toString());
			    pStmt.setString(1,ActivityData.STATUS_SCHEDULED);
			    pStmt.setString(2,prInfoRequestedActivityCode);
			    pStmt.setLong(3,tiRequestID);
				rs = pStmt.executeQuery();
				log.debug(" SQL is "+ currRoleSQL.toString() );
				log.debug(" with  Conditions requestId = " +tiRequestID +" Status "+ActivityData.STATUS_SCHEDULED+" ,prinfoRequestedActivityCode"+prInfoRequestedActivityCode);
				if(rs!=null){
					while(rs.next()){
						role=rs.getString(1);
						break;
					}
				}

			   }
				finally{
					if(rs!=null)
		    		rs.close();
					if(pStmt!=null)
						pStmt.close();
					if(con!=null){
		    		  c3parSession.releaseConnection();
		    		}
				}
			return role;
		  }


	 //activityCode can be null

	 /* (non-Javadoc)
 	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#isCurrentActivityScheduled(long, java.lang.String, java.lang.String)
 	 */
 	public boolean isCurrentActivityScheduled(long tiRequestID,String activityCode, String prInfoRequestedActivityCode) throws Exception{
		 	boolean curActivityScheduled=false;
		 	if (getScheduledActivityTralId(tiRequestID,activityCode,prInfoRequestedActivityCode)>0)
		 	curActivityScheduled=true;
		  	return curActivityScheduled;
		 }

	 /* (non-Javadoc)
 	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#getScheduledActivityTralId(long, java.lang.String, java.lang.String)
 	 */
 	public long getScheduledActivityTralId(long tiRequestID,String activityCode, String prInfoRequestedActivityCode) throws Exception{

		 long activityTrailId=-1;
		 Connection con=null;
		  	PreparedStatement pStmt=null;
		  	ResultSet rs=null;

		  	try{

		  		StringBuffer provideInfoSQL=new StringBuffer(" select tat.id from c3par.ti_activity_trail tat,c3par.ti_task_type ttt ");
		  		 if(isString(prInfoRequestedActivityCode))
		  		provideInfoSQL.append(" ,ti_activity_trail pitat,c3par.ti_task_type pittt ");
		  		provideInfoSQL.append(" where tat.ti_request_id=? and  tat.ACTIVITY_ID=ttt.id and ttt.TASK_CODE=? and tat.ACTIVITY_STATUS=?  ");
		  		if(isString(prInfoRequestedActivityCode))
		  			provideInfoSQL.append("  and tat.PI_REQUESTED_ACTIVITY=pitat.id and pitat.ACTIVITY_ID=pittt.id and pittt.task_code = ? and pitat.ACTIVITY_STATUS=?  and tat.TI_REQUEST_ID=pitat.TI_REQUEST_ID ");
		  		con =c3parSession.getConnection();
			    pStmt = con.prepareStatement(provideInfoSQL.toString());
			    pStmt.setLong(1,tiRequestID);
			    pStmt.setString(2,activityCode);
			    pStmt.setString(3,ActivityDataDTO.STATUS_SCHEDULED);
			    if(isString(prInfoRequestedActivityCode)){
			    	pStmt.setString(4,prInfoRequestedActivityCode);
			    pStmt.setString(5,ActivityDataDTO.STATUS_PROVIDEINFO);
			    }


				rs = pStmt.executeQuery();
				log.debug(" SQL is "+ provideInfoSQL.toString() );
				log.debug(" with  Conditions activityId = " +tiRequestID );
				if(rs!=null){
					while(rs.next()){
						activityTrailId=rs.getLong(1);
						break;
					}
				}

			   }
				finally{
					if(rs!=null)
		    		rs.close();
					if(pStmt!=null)
						pStmt.close();
					if(con!=null){
		    		  c3parSession.releaseConnection();
		    		}
				}
			return activityTrailId;


	 }

 	/* (non-Javadoc)
 	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#getPrInfoRequestedActivityId(long, java.lang.String, java.lang.String)
 	 */
 	public long getPrInfoRequestedActivityId(long tiRequestID,String activityCode, String prInfoRequestedActivityCode) throws Exception{

		 long activityTrailId=-1;
		 Connection con=null;
		  	PreparedStatement pStmt=null;
		  	ResultSet rs=null;
		  	try{
		  		StringBuffer provideInfoSQL=new StringBuffer(" select tat.id from c3par.ti_activity_trail tat,c3par.ti_task_type ttt ");
		  		 if(isString(prInfoRequestedActivityCode))
		  		provideInfoSQL.append(" ,ti_activity_trail pitat,c3par.ti_task_type pittt ");
		  		provideInfoSQL.append(" where tat.ti_request_id=? and  tat.ACTIVITY_ID=ttt.id and ttt.TASK_CODE=? and tat.ACTIVITY_STATUS=?  ");
		  		if(isString(prInfoRequestedActivityCode))
		  			provideInfoSQL.append("  and tat.PI_REQUESTED_ACTIVITY=pitat.id and pitat.ACTIVITY_ID=pittt.id and pittt.task_code = ? and pitat.ACTIVITY_STATUS=?  and tat.TI_REQUEST_ID=pitat.TI_REQUEST_ID ");
		  		con =c3parSession.getConnection();
			    pStmt = con.prepareStatement(provideInfoSQL.toString());
			    pStmt.setLong(1,tiRequestID);
			    pStmt.setString(2,activityCode);
			    pStmt.setString(3,ActivityDataDTO.STATUS_PROVIDEINFO);
			    if(isString(prInfoRequestedActivityCode)){
			    	pStmt.setString(4,prInfoRequestedActivityCode);
			    pStmt.setString(5,ActivityDataDTO.STATUS_PROVIDEINFO);
			    }

				rs = pStmt.executeQuery();
				log.debug(" SQL is "+ provideInfoSQL.toString() );
				log.debug(" with  Conditions activityId = " +tiRequestID );
				if(rs!=null){
					while(rs.next()){
						activityTrailId=rs.getLong(1);
						break;
					}
				}

			   }
				finally{
					if(rs!=null)
		    		rs.close();
					if(pStmt!=null)
						pStmt.close();
					if(con!=null){
		    		  c3parSession.releaseConnection();
		    		}
				}
			return activityTrailId;


	 }

 	/* (non-Javadoc)
 	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#getCurrentActivityStatus(long)
 	 */
 	public String getCurrentActivityStatus(long activityTrailId) throws Exception{
		 	Connection con=null;
		  	PreparedStatement pStmt=null;
		  	ResultSet rs=null;
		  	String status=null;
		  	try{
		  		StringBuffer provideInfoSQL=new StringBuffer(" select activity_status from c3par.ti_activity_trail where id=?");


		  		con =c3parSession.getConnection();
			    pStmt = con.prepareStatement(provideInfoSQL.toString());
			    pStmt.setLong(1,activityTrailId);



				rs = pStmt.executeQuery();
				log.debug(" SQL is "+ provideInfoSQL.toString() );
				log.debug(" with  Conditions activityId = " +activityTrailId);
				if(rs!=null){
					while(rs.next()){
						status=rs.getString(1);
						break;
					}
				}

			   }
				finally{
					if(rs!=null)
		    		rs.close();
					if(pStmt!=null)
						pStmt.close();
					if(con!=null){
		    		  c3parSession.releaseConnection();
		    		}
				}
			return status;
		 }

	 /* (non-Javadoc)
 	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#updateBPMInstanceId(long, java.lang.String)
 	 */
 	public void updateBPMInstanceId(long activityTrailId,String bpmInstanceId) throws Exception{
		 	Connection con=null;
		  	PreparedStatement pStmt=null;
		   	try{
		  		String updBPMInstanceSQL=" update c3par.ti_activity_trail set bpm_instance_id=? ,activity_status=? where id=?";
		  		con =c3parSession.getConnection();
			    pStmt = con.prepareStatement(updBPMInstanceSQL.toString());
			    pStmt.setString(1,bpmInstanceId);
			    pStmt.setString(2,ActivityDataDTO.STATUS_SCHEDULED);
			    pStmt.setLong(3,activityTrailId);

				pStmt.executeUpdate();
			    log.debug(" SQL is "+ updBPMInstanceSQL.toString() );
				log.debug(" with  Conditions activityTrailId = " +activityTrailId +", bpmInstanceId = "+bpmInstanceId);
							   }
				finally{
					if(pStmt!=null)
						pStmt.close();
					if(con!=null){
		    		  c3parSession.releaseConnection();
		    		}
				}
			 }

 	/* (non-Javadoc)
 	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#isPrInfoRequestedActivity(long)
 	 */
 	public boolean isPrInfoRequestedActivity(long activityTrailId) throws Exception{

		 boolean isPrInfoReqActivity=false;
		 Connection con=null;
		  	PreparedStatement pStmt=null;
		  	ResultSet rs=null;

		  	try{

		  		StringBuffer provideInfoActivitySQL=new StringBuffer(" select pi_requested_activity from c3par.ti_activity_trail where pi_requested_activity =?");
		  		con =c3parSession.getConnection();
			    pStmt = con.prepareStatement(provideInfoActivitySQL.toString());
			    pStmt.setLong(1,activityTrailId);
			    rs = pStmt.executeQuery();
				log.debug(" SQL is "+ provideInfoActivitySQL.toString() );
				log.debug(" with  Conditions activityTrailId = " +activityTrailId );
				if(rs!=null){
					while(rs.next()){
						long actTrailId=rs.getLong(1);
						if(actTrailId>0)
						isPrInfoReqActivity=true;
						break;
					}
				}

			   }
				finally{
					if(rs!=null)
		    		rs.close();
					if(pStmt!=null)
						pStmt.close();
					if(con!=null){
		    		  c3parSession.releaseConnection();
		    		}
				}
			return isPrInfoReqActivity;


	 }

	/**
	 * Checks if is string.
	 *
	 * @param val the val
	 * @return true, if is string
	 */
	boolean isString(String val) {
		boolean isString = true;
		if (val == null)
			isString = false;
		if (val != null && val.length() == 0)
			isString = false;
		return isString;
	}

	/*public void ccrToResolveIt(Long tiRequestId) {
		Connection con = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		Map<String,String> commmentMap = new HashMap<String,String>();
		
		try{

			con = c3parSession.getConnection();

			log.info("ManageActivityImpl.logActivity() before calling :::" + tiRequestId );
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT tt.task, ");
			sql.append(" at.activity_status, ");
			sql.append(" at.user_id, ");
			sql.append(" at.activity_startdate, ");
			sql.append(" at.activity_enddate, ");
			sql.append(" usr.First_name, ");
			sql.append(" usr.last_name, ");
			sql.append(" usr.sso_id ");
			sql.append(" FROM c3par.ti_activity_trail at, ");
			sql.append(" c3par.ti_task_type tt, ");
			sql.append(" c3par.c3par_users usr ");
			sql.append(" WHERE tt.id = at.activity_id ");
			sql.append(" AND usr.id = at.user_id ");
			sql.append(" AND at.ti_request_id = ? ");
			sql.append(" ORDER BY activity_startdate DESC");


			pStmt = con.prepareStatement(sql.toString());
			pStmt.setLong(1, tiRequestId);
			rs = pStmt.executeQuery();
			
			while(rs.next()){
				commmentMap.put("Task", rs.getString(1));
				commmentMap.put("Status", rs.getString(2));
				commmentMap.put("Completed By", rs.getString(6)+" "+rs.getString(7)+" "+rs.getString(8));
				break;
			}
		}
		catch (DatabaseException e) {
			log.error(e, e);
		}
		catch (SQLException e) {
			log.error(e, e);
		}
		finally{
			c3parSession.closeResultSet(rs);
			c3parSession.closeStatement(pStmt);
			c3parSession.releaseConnection();
		}
		log.info("ManageActivityImpl.logActivity() before calling starts:::" + commmentMap );

		try{
			ResolveITQueueSender resolveITQueueSender = C3PARBeanFactory.getInstance().getResolveITQueueSender();
			log.info("ManageActivityImpl.logActivity():: calling ResolveITNotifyLog Starts");
			String cmts =" Activity is in "+commmentMap.get("Task")+" and status "+commmentMap.get("Status")+" Completed by "+commmentMap.get("Completed By");
			log.info("Comment ------>"+cmts);
			//new ResolveITcatejmsjnditestSSLQueue(cmts);
			ResolveITNotifyLog resolveITNotifyLog = new ResolveITNotifyLog();
			//String sentMsg = resolveITNotifyLog.getMessageCCRtoRIT(cmts).toString();
			//log.info(sentMsg);
			//resolveITQueueSender.sendMesage(sentMsg);
			log.info("ManageActivityImpl.logActivity():: calling ResolveITNotifyLog Ends");
		}
		catch (Exception e) {
			log.error(e, e);
		}

	}*/
	
}