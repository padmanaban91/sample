package com.citigroup.cgti.c3par.communication.domain;

import com.citigroup.cgti.c3par.domain.Base;

public class EcmQueue extends Base{
	
	private String queueName;
	
	private String displayName;

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
	


}
