/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author ne36745
 *
 */
public class SearchFirewallRuleRequest {
	
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

    //properties used for search
    private long objectId;
    private long tiProcess;
    private long tiRequest;
    private long updatedTIRequest;
    private long deletedTIRequest;
    private String filterText;
    private String filterType;
   
    private int rowCount;
    private int offset;
    private int limit;
    private int pageNo;
    private String field;
    private int totalPages;
    private String ipType;

    private boolean isSelectAll;

    private IPAddress ipAddress;
    
	private PersonalObject personalObject;
	
	private List<PersonalObject> personalObjects;
	
	private int requesterResourceType;
	
	private int targetResourceType;
	
	private String relationshipType;
	
	private List<FireWallRuleIP> firewallRuleIPList;
    
	private List<FireWallRulePort> firewallRulePortList;
	
	private List<IPAddress> ipAddressList;

	private List<GenericLookup> protocolList;
	
	private List<ResourceType> resourceTypes;
	
	private List<GenericLookup> controlMessagesList;
	
	private String description;
	
    private String typeOfTraffic;
    
    private Long controlMsgId;   
   
    private List<IPRegACL> ipRegACLList;
    
    private IPRegACL accessType;
	
	/**
	 * @return the objectId
	 */
	public long getObjectId() {
		return objectId;
	}

	/**
	 * @param objectId the objectId to set
	 */
	public void setObjectId(long objectId) {
		this.objectId = objectId;
	}

	/**
	 * @return the tiProcess
	 */
	public long getTiProcess() {
		return tiProcess;
	}

	/**
	 * @param tiProcess the tiProcess to set
	 */
	public void setTiProcess(long tiProcess) {
		this.tiProcess = tiProcess;
	}

	/**
	 * @return the tiRequest
	 */
	public long getTiRequest() {
		return tiRequest;
	}

	/**
	 * @param tiRequest the tiRequest to set
	 */
	public void setTiRequest(long tiRequest) {
		this.tiRequest = tiRequest;
	}

	/**
	 * @return the updatedTIRequest
	 */
	public long getUpdatedTIRequest() {
		return updatedTIRequest;
	}

	/**
	 * @param updatedTIRequest the updatedTIRequest to set
	 */
	public void setUpdatedTIRequest(long updatedTIRequest) {
		this.updatedTIRequest = updatedTIRequest;
	}

	/**
	 * @return the deletedTIRequest
	 */
	public long getDeletedTIRequest() {
		return deletedTIRequest;
	}

	/**
	 * @param deletedTIRequest the deletedTIRequest to set
	 */
	public void setDeletedTIRequest(long deletedTIRequest) {
		this.deletedTIRequest = deletedTIRequest;
	}

	/**
	 * @return the filterText
	 */
	public String getFilterText() {
		return filterText;
	}

	/**
	 * @param filterText the filterText to set
	 */
	public void setFilterText(String filterText) {
		this.filterText = filterText;
	}

	/**
	 * @return the filterType
	 */
	public String getFilterType() {
		return filterType;
	}

	/**
	 * @param filterType the filterType to set
	 */
	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}

	/**
	 * @return the rowCount
	 */
	public int getRowCount() {
		return rowCount;
	}

	/**
	 * @param rowCount the rowCount to set
	 */
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	/**
	 * @return the offset
	 */
	public int getOffset() {
		return offset;
	}

	/**
	 * @param offset the offset to set
	 */
	public void setOffset(int offset) {
		this.offset = offset;
	}

	/**
	 * @return the limit
	 */
	public int getLimit() {
		return limit;
	}

	/**
	 * @param limit the limit to set
	 */
	public void setLimit(int limit) {
		this.limit = limit;
	}

	/**
	 * @return the pageNo
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * @param pageNo the pageNo to set
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * @return the field
	 */
	public String getField() {
		return field;
	}

	/**
	 * @param field the field to set
	 */
	public void setField(String field) {
		this.field = field;
	}

	/**
	 * @return the totalPages
	 */
	public int getTotalPages() {
		return totalPages;
	}

	/**
	 * @param totalPages the totalPages to set
	 */
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	/**
	 * @return the isSelectAll
	 */
	public boolean isSelectAll() {
		return isSelectAll;
	}

	/**
	 * @param isSelectAll the isSelectAll to set
	 */
	public void setSelectAll(boolean isSelectAll) {
		this.isSelectAll = isSelectAll;
	}

	/**
	 * @return the ipAddress
	 */
	public IPAddress getIpAddress() {
		return ipAddress;
	}

	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(IPAddress ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * @return the ipAddressList
	 */
	public List<IPAddress> getIpAddressList() {
		return ipAddressList;
	}

	/**
	 * @param ipAddressList the ipAddressList to set
	 */
	public void setIpAddressList(List<IPAddress> ipAddressList) {
		this.ipAddressList = ipAddressList;
	}

	/**
	 * @return the personalObject
	 */
	public PersonalObject getPersonalObject() {
		return personalObject;
	}

	/**
	 * @param personalObject the personalObject to set
	 */
	public void setPersonalObject(PersonalObject personalObject) {
		this.personalObject = personalObject;
	}

	/**
	 * @return the personalObjects
	 */
	public List<PersonalObject> getPersonalObjects() {
		return personalObjects;
	}

	/**
	 * @param personalObjects the personalObjects to set
	 */
	public void setPersonalObjects(List<PersonalObject> personalObjects) {
		this.personalObjects = personalObjects;
	}

	/**
	 * @return the requesterResourceType
	 */
	public int getRequesterResourceType() {
		return requesterResourceType;
	}

	/**
	 * @param requesterResourceType the requesterResourceType to set
	 */
	public void setRequesterResourceType(int requesterResourceType) {
		this.requesterResourceType = requesterResourceType;
	}

	/**
	 * @return the targetResourceType
	 */
	public int getTargetResourceType() {
		return targetResourceType;
	}

	/**
	 * @param targetResourceType the targetResourceType to set
	 */
	public void setTargetResourceType(int targetResourceType) {
		this.targetResourceType = targetResourceType;
	}

	/**
	 * @return the firewallRuleIPList
	 */
	public List<FireWallRuleIP> getFirewallRuleIPList() {
		return firewallRuleIPList;
	}

	/**
	 * @param firewallRuleIPList the firewallRuleIPList to set
	 */
	public void setFirewallRuleIPList(List<FireWallRuleIP> firewallRuleIPList) {
		this.firewallRuleIPList = firewallRuleIPList;
	}

	/**
	 * @return the firewallRulePortList
	 */
	public List<FireWallRulePort> getFirewallRulePortList() {
		return firewallRulePortList;
	}

	/**
	 * @param firewallRulePortList the firewallRulePortList to set
	 */
	public void setFirewallRulePortList(List<FireWallRulePort> firewallRulePortList) {
		this.firewallRulePortList = firewallRulePortList;
	}
	
	/**
	 * @return the protocolList
	 */
	public List<GenericLookup> getProtocolList() {
		return protocolList;
	}

	/**
	 * @param protocolList the protocolList to set
	 */
	public void setProtocolList(List<GenericLookup> protocolList) {
		this.protocolList = protocolList;
	}

	/**
	 * @return the resourceTypes
	 */
	public List<ResourceType> getResourceTypes() {
		return resourceTypes;
	}

	/**
	 * @param resourceTypes the resourceTypes to set
	 */
	public void setResourceTypes(List<ResourceType> resourceTypes) {
		this.resourceTypes = resourceTypes;
	}

	/**
	 * @return the controlMessagesList
	 */
	public List<GenericLookup> getControlMessagesList() {
		return controlMessagesList;
	}

	/**
	 * @param controlMessagesList the controlMessagesList to set
	 */
	public void setControlMessagesList(List<GenericLookup> controlMessagesList) {
		this.controlMessagesList = controlMessagesList;
	}
	
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the typeOfTraffic
	 */
	public String getTypeOfTraffic() {
		return typeOfTraffic;
	}

	/**
	 * @param typeOfTraffic the typeOfTraffic to set
	 */
	public void setTypeOfTraffic(String typeOfTraffic) {
		this.typeOfTraffic = typeOfTraffic;
	}

	/**
	 * @return the controlMsgId
	 */
	public Long getControlMsgId() {
		return controlMsgId;
	}

	/**
	 * @param controlMsgId the controlMsgId to set
	 */
	public void setControlMsgId(Long controlMsgId) {
		this.controlMsgId = controlMsgId;
	}
	
	/**
	 * @return the relationshipType
	 */
	public String getRelationshipType() {
		return relationshipType;
	}

	/**
	 * @param relationshipType the relationshipType to set
	 */
	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

	
    public List<IPAddress> getIPAddresses() {
		return ccrBeanFactory.getSearchFirewallRulePersistable().getIPAddresses(this);
    }
	
	
    public List<IPRegACL> getIpRegACL() {
		return  ccrBeanFactory.getSearchFirewallRulePersistable().getIpRegACL(this);
    }
	
	
    public List<FireWallRuleIP> searchTemplateIPObjects() {
    	return  ccrBeanFactory.getSearchFirewallRulePersistable().searchTemplateIPObjects(this);
    }
	
	
	public List<PersonalObject> listPersonalObjectIPs() {
		return  ccrBeanFactory.getSearchFirewallRulePersistable().listPersonalObjectIPs(this);
	}
	
	
	public List<PersonalObject> listPersonalObjectPorts() {
		return  ccrBeanFactory.getSearchFirewallRulePersistable().listPersonalObjectPorts(this);
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void savePersonalObjects() {
		 ccrBeanFactory.getSearchFirewallRulePersistable().savePersonalObjects(this);
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void savePersonalObjectsPort() {
		 ccrBeanFactory.getSearchFirewallRulePersistable().savePersonalObjectsPort(this);
	}
	
	
	public List<FireWallRulePort> searchTemplatePortObjects() {
		return  ccrBeanFactory.getSearchFirewallRulePersistable().searchTemplatePortObjects(this);
	}
	
	
	public PersonalObject findPersonalObject() {
		return  ccrBeanFactory.getSearchFirewallRulePersistable().findPersonalObject(this);
	}
	
	
	public PersonalObject validatePersonalObject(PersonalObject personalObject) {
		return  ccrBeanFactory.getSearchFirewallRulePersistable().validatePersonalObject(personalObject);
	}
	
	
	public PersonalObject validatePersonalObjectPort(PersonalObject personalObject) {
		return  ccrBeanFactory.getSearchFirewallRulePersistable().validatePersonalObjectPort(personalObject);
	}

	public void setIpRegACLList(List<IPRegACL> ipRegACLList) {
		this.ipRegACLList = ipRegACLList;
	}

	public List<IPRegACL> getIpRegACLList() {
		return ipRegACLList;
	}

	public void setAccessType(IPRegACL accessType) {
		this.accessType = accessType;
	}

	public IPRegACL getAccessType() {
		return accessType;
	}

	public void setIpType(String ipType) {
		this.ipType = ipType;
	}

	public String getIpType() {
		return ipType;
	}
}
