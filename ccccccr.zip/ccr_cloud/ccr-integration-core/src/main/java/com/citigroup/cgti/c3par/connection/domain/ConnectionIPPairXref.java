package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerException;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionIPPairXref.
 */
public class ConnectionIPPairXref extends PerformerPagerDO implements
Serializable {

    /** The connection ip pair master. */
    private ConnectionIPPairMaster connectionIPPairMaster;

    /** The connection port xref list. */
    private List connectionPortXrefList = new ArrayList();

    /** The connection fw rule xref list. */
    private List connectionFWRuleXrefList = new ArrayList();

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /** The status. */
    private String status;

    /** The ti request id. */
    private Long tiRequestId ;

    /** The risk pair. */
    private String riskPair;


    /**
     * Instantiates a new connection ip pair xref.
     */
    public ConnectionIPPairXref() {
	// ---------------------
	setTableName(PerformerTypes.CONN_IP_PAIR_XREF_TABEL);
	setSequenceName(PerformerTypes.CONN_IP_PAIR_XREF_SEQ);
	// ---------------------
	addToDBMapping("connectionIPPairMaster", "ip_pair_id",1);
	addToDBMapping("created_date", "created_date",2);
	addToDBMapping("updated_date", "updated_date",3);
	addToDBMapping("status","status",4);
	addToDBMapping("tiRequestId","TI_REQUEST_ID",5);
	addToDBMapping("riskPair","IS_RISK_PAIR",6);
	// ----------------------
	addToNonCompositionList("connectionIPPairMaster");
	// ----------------------
	addToParentsMap(
		"com.citigroup.cgti.c3par.connection.domain.ConnectionProcess",
	"CONNECTION_REQUEST_ID");
	// ----------------------
	addToChildList("connectionPortXrefList",new ConnectionPortXref());
	addToChildList("connectionFWRuleXrefList",new ConnectionFWRuleXref());
    }

    /**
     * Gets the connection ip pair master.
     *
     * @return the connection ip pair master
     */
    public ConnectionIPPairMaster getConnectionIPPairMaster() {
	return connectionIPPairMaster;
    }

    /**
     * Sets the connection ip pair master.
     *
     * @param connectionIPPairMaster the new connection ip pair master
     */
    public void setConnectionIPPairMaster(
	    ConnectionIPPairMaster connectionIPPairMaster) {
	this.connectionIPPairMaster = connectionIPPairMaster;
    }


    /**
     * Gets the connection fw rule xref list.
     *
     * @return Returns the connectionFWRuleXrefList.
     */
    public List getConnectionFWRuleXrefList() {
	return connectionFWRuleXrefList;
    }

    /**
     * Sets the connection fw rule xref list.
     *
     * @param connectionFWRuleXrefList The connectionFWRuleXrefList to set.
     */
    public void setConnectionFWRuleXrefList(List connectionFWRuleXrefList) {
	this.connectionFWRuleXrefList = connectionFWRuleXrefList;
    }

    /**
     * Gets the connection port xref list.
     *
     * @return Returns the connectionPortXrefList.
     */
    public List getConnectionPortXrefList() {
	return connectionPortXrefList;
    }

    /**
     * Sets the connection port xref list.
     *
     * @param connectionPortXrefList The connectionPortXrefList to set.
     */
    public void setConnectionPortXrefList(List connectionPortXrefList) {
	this.connectionPortXrefList = connectionPortXrefList;
    }


    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#next(java.lang.String, int, boolean)
     */
    public List next(String attribute, int pageSize, boolean manageObject)
    throws PerformerException {
	return this.next(attribute, pageSize, null,manageObject);
    }
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#next(java.lang.String, int, java.util.List, boolean)
     */
    public List next(String attribute, int pageSize, List filters,
	    boolean manageObject) throws PerformerException {
	throw new ApplicationException("Please use next method in ConProcess to paginate");
    }
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#next(java.lang.String, int, java.util.List)
     */
    public List next(String attribute, int pageSize, List filters)
    throws PerformerException {
	return this.next(attribute, pageSize, filters,true);
    }
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#next(java.lang.String, int)
     */
    public List next(String attribute, int pageSize) throws PerformerException {
	return this.next(attribute, pageSize, null,true);
    }
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#next(java.lang.String, java.util.Map, int, boolean)
     */
    public List next(String attribute, Map filters, int pageSize,
	    boolean manageObject, boolean isParent) throws PerformerException {
	throw new ApplicationException("Please use next method in ConProcess to paginate");
    }


    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#previous(java.lang.String, int, boolean)
     */
    public List previous(String attribute, int pageSize, boolean manageObject)
    throws PerformerException {
	return previous(attribute, pageSize, null,manageObject);
    }
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#previous(java.lang.String, int, java.util.List, boolean)
     */
    public List previous(String attribute, int pageSize, List filters,
	    boolean manageObject) throws PerformerException {
	throw new ApplicationException("Please use previous method in ConProcess to paginate");
    }
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#previous(java.lang.String, int, java.util.List)
     */
    public List previous(String attribute, int pageSize, List filters)
    throws PerformerException {
	return previous(attribute, pageSize, filters,true);
    }
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#previous(java.lang.String, int)
     */
    public List previous(String attribute, int pageSize)
    throws PerformerException {
	return previous(attribute, pageSize, null,true);
    }
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#previous(java.lang.String, java.util.Map, int, boolean)
     */
    public List previous(String attribute, Map filters, int pageSize,
	    boolean manageObject, boolean isParent) throws PerformerException {
	throw new ApplicationException("Please use previous method in ConProcess to paginate");
    }



    /**
     * Gets the created_date.
     *
     * @return Returns the created_date.
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date The created_date to set.
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return Returns the updated_date.
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date The updated_date to set.
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
	this.status = status;
    }

    /**
     * Gets the ti request id.
     *
     * @return the ti request id
     */
    public Long getTiRequestId() {
	return tiRequestId;
    }

    /**
     * Sets the ti request id.
     *
     * @param tiRequestId the new ti request id
     */
    public void setTiRequestId(Long tiRequestId) {
	this.tiRequestId = tiRequestId;
    }

    /**
     * Gets the risk pair.
     *
     * @return the risk pair
     */
    public String getRiskPair() {
	return riskPair;
    }

    /**
     * Sets the risk pair.
     *
     * @param riskPair the new risk pair
     */
    public void setRiskPair(String riskPair) {
	this.riskPair = riskPair;
    }	

}
