/**
 *
 */
package com.citigroup.cgti.c3par.common.domain;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author nc43495
 * 
 */
public class HistoryContact extends Base{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4552205943275259045L;

	private Long contactId;
	
	private Long roleId;
	
	private Long requestId;
	
	private String primaryContact;
	
	private String notifyContact;
	
	private String systemGenerated;
	
	private Long xrefId;
	
	private String soeId;

	/**
	 * @return the contactId
	 */
	public Long getContactId() {
		return contactId;
	}

	/**
	 * @param contactId the contactId to set
	 */
	public void setContactId(Long contactId) {
		this.contactId = contactId;
	}

	/**
	 * @return the roleId
	 */
	public Long getRoleId() {
		return roleId;
	}

	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	/**
	 * @return the requestId
	 */
	public Long getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the primaryContact
	 */
	public String getPrimaryContact() {
		return primaryContact;
	}

	/**
	 * @param primaryContact the primaryContact to set
	 */
	public void setPrimaryContact(String primaryContact) {
		this.primaryContact = primaryContact;
	}

	/**
	 * @return the notifyContact
	 */
	public String getNotifyContact() {
		return notifyContact;
	}

	/**
	 * @param notifyContact the notifyContact to set
	 */
	public void setNotifyContact(String notifyContact) {
		this.notifyContact = notifyContact;
	}

	/**
	 * @return the systemGenerated
	 */
	public String getSystemGenerated() {
		return systemGenerated;
	}

	/**
	 * @param systemGenerated the systemGenerated to set
	 */
	public void setSystemGenerated(String systemGenerated) {
		this.systemGenerated = systemGenerated;
	}

	/**
	 * @return the xrefId
	 */
	public Long getXrefId() {
		return xrefId;
	}

	/**
	 * @param xrefId the xrefId to set
	 */
	public void setXrefId(Long xrefId) {
		this.xrefId = xrefId;
	}

	/**
	 * @return the soeId
	 */
	public String getSoeId() {
		return soeId;
	}

	/**
	 * @param soeId the soeId to set
	 */
	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}
	
}
