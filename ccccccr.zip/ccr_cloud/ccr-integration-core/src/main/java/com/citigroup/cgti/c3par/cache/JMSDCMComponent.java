/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.cache;

//import com.citigroup.cgti.c3par.C3parSession;
//import com.citigroup.cgti.c3par.dao.lookup.BusinessUnitLookup;
//import com.citigroup.cgti.c3par.dao.lookup.C3parUsersLookup;
//import com.citigroup.cgti.c3par.dao.lookup.GenericLookupLookup;
import com.mentisys.cache.AbstractJMSDCMComponent;
import com.mentisys.cache.CacheManagementEvent;
import com.mentisys.cache.InvalidateCacheEvent;

//import com.mentisys.dao.DatabaseException;

// pkadam: This class was being used to send and receive cache invalidation events
// to other application server instances. The event dispatch mechansim was JMS.
// But since the requirement changed that WLS admin server cannot be used
// to deploy application components, the JMS topic was to be removed.
// As a result the Cache invalidation component could not use this class.
// So the cache invalidation code was commented out but not deleted. 
/**
 * The Class JMSDCMComponent.
 *
 * @author pkadam
 */
public class JMSDCMComponent extends AbstractJMSDCMComponent {

    /** The Constant BU_CACHE_SET. */
    private static final String BU_CACHE_SET = "BusinessUnit" ;

    /** The Constant GENERIC_LOOKUP_CACHE_SET. */
    private static final String GENERIC_LOOKUP_CACHE_SET = "GenericLookup" ;

    /** The Constant C3PAR_USERS_CACHE_SET. */
    private static final String C3PAR_USERS_CACHE_SET = "C3parUsers" ;

    /** The lock for bu. */
    private Object lockForBU = new Object() ;

    /** The lock for generic lookup. */
    private Object lockForGenericLookup = new Object();

    /* (non-Javadoc)
     * @see com.mentisys.cache.CacheManagementEventListener#actionPerformed(com.mentisys.cache.CacheManagementEvent)
     */
    public void actionPerformed(CacheManagementEvent event) {

	if(event instanceof InvalidateCacheEvent) {
	    InvalidateCacheEvent e = (InvalidateCacheEvent) event ;

	    String invalidateCacheSet = e.getCacheSet();

	    //			debug("Request to invalidate " + invalidateCacheSet);

	    if(BU_CACHE_SET.equals(invalidateCacheSet)) {
		//				debug("Invalidating local cache for BU as a result of receving a notification from another component");

		invalidateBusinessUnitCache();
	    } 
	    else if(GENERIC_LOOKUP_CACHE_SET.equals(invalidateCacheSet)) 
	    {
		//				debug("Invalidating local cache for Generic Lookup as a result of receiving a notification from another component");
		invalidateGenericLookupCache();
	    }
	    else {
		if(C3PAR_USERS_CACHE_SET.equals(invalidateCacheSet)) {
		    //					debug("Invalidating local cache for C3par Users as a result of receiving a notification from another component");
		    invalidateC3parUsersCache();
		} else {
		    //					debug("Invalidation for " + invalidateCacheSet + " NOT IMPLEMENTED");
		}
	    }

	    //			debug("Invalidation complete " + invalidateCacheSet);
	}

    }

    // this method could be invoked on receiving a JMS message containing invalidation
    // event or by the cache maangement local component
    /**
     * Invalidate business unit cache.
     */
    private void invalidateBusinessUnitCache() {
	//		synchronized(lockForBU) {
	//			try {
	//				
	//				
	//				BusinessUnitLookup lookup = BusinessUnitLookup.getInstance();
	//				C3parSession dbsession = new C3parSession();
	//				
	//				lookup.reset();
	//				
	//				lookup.initialize(dbsession);
	//			} catch (Exception e) {
	//				
	//			}
	//		}
    }

    // this method could be invoked on receiving a JMS message containing invalidation
    // event or by the cache maangement local component. Hence synchronized	
    /**
     * Invalidate generic lookup cache.
     */
    private void invalidateGenericLookupCache() {
	//		synchronized(lockForGenericLookup = new Object()) {
	//			try {
	//				GenericLookupLookup.getInstance().reset();
	//				GenericLookupLookup.getInstance().initialize(new C3parSession());
	//			} catch (DatabaseException e) {
	//				
	//			}		
	//		}
    }

    /**
     * Invalidate c3par users cache.
     */
    private void invalidateC3parUsersCache() {
	//		synchronized(lockForGenericLookup = new Object()) {
	//			try {
	//				C3parUsersLookup.getInstance().reset();
	//				C3parUsersLookup.getInstance().initialize(new C3parSession());
	//			} catch (DatabaseException e) {
	//				
	//			}		
	//		}
    }
}
