package com.citigroup.cgti.c3par.bpm.ejb.manageprocess;

import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.RFC_REQ_TYPE_FIREWALL;

import java.net.URLEncoder;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.ManageActivityImpl;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.ThirdParty;
import com.citigroup.cgti.c3par.domain.logic.TIProcessService;
 

/**
 * The Class ManageTIProcessImpl.
 */
@SuppressWarnings( { "unchecked", "unused", "deprecation" })
public class ManageTIProcessUtil  {
	
	@Autowired
	private ManageActivityImpl manageActivityImpl;
		 
	private DataSource dataSource;
	
	 
	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	private JdbcTemplate jdbcTemplate;
	
	private CCRQueries ccrQueries;
	
	/**
	 * Sets the c3par session.
	 *
	 * @param session the new c3par session
	 */
	
	 
	public TIProcess getProcessData(long requestID) throws Exception {
		return getProcessData(requestID,null,null);
	}

		
	public List<TIProcess> getProcessData(List requestIDs) throws Exception {
		return getProcessData(requestIDs,null,null);
	}
	
	
	/* public void setC3parSession(C3parSession session) {
	c3parSession = session;
} */

	public List<TIProcess> getProcessData(List<String> requestIDs,String activityCode,String prInfoRequestedActivityCode) throws Exception {

		List<TIProcess> tiProcesses = new ArrayList<TIProcess>();
		TIProcess tiProcess = null;
		 
		log.debug("getProcessData Begin to process RequestID ");
		
		for (String requestId:requestIDs) {
			 tiProcess = getProcessData (Long.parseLong(requestId), activityCode,prInfoRequestedActivityCode);
			if (tiProcess != null &&  tiProcess.getTiRequest().getId() != null)
				tiProcesses.add (tiProcess);
			else
				 log.debug("Could not get TIRequest details for request id: "+ requestId);
		}
		
		log.debug("getProcessData Completed to processing RequestID ");
	
	return tiProcesses;
}
	
	
	
	public TIProcess getProcessData( long requestID, String activityCode, String prInfoRequestedActivityCode) throws Exception { 

		if (requestID <= 0) {
			log.error("Require Request ID for getting process info");
			throw new Exception("RequestId is null");
		}
		
		log.debug("ManageTIProcessImpl.getProcessData: " + requestID + " Activity Code : " + activityCode + " InfoRequestedCode : " + prInfoRequestedActivityCode);
		
		TIProcess tiProcess = null;
		SqlRowSet rs = null;
		Calendar cal = Calendar.getInstance(); 
	
			 		
		if (requestID > 0) {
			
			//Modified query according to new table change (REL_CITI_HIERARCHY_XREF)
			try {
				log.info(" Getting Process Data for tiRequest ID: " + requestID);
				StringBuilder procSQL = new StringBuilder();
				procSQL.append("SELECT DISTINCT tiProc.ID tiProc_ID,");
				procSQL.append("tiproc.PROCESS_NAME tiproc_PROCESS_NAME,");
				procSQL.append("tireq.VERSION_NUMBER tireq_VERSION_NUMBER,");
				procSQL.append("tireqtype.REQUEST_TYPE tireqtype_REQUEST_TYPE,");
				procSQL.append("tiproc.process_activity_mode tiproc_process_activity_mode,");
				procSQL.append("tiproctype.PROCESS_TYPE tiproctype_PROCESS_TYPE,");
				procSQL.append("prior_gl.VALUE1 prior_gl_VALUE1,");
				procSQL.append("(select listagg(rg.NAME,',') within group (order by rg.NAME) ");
				procSQL.append("from region rg, citi_hierarchy_master ch, rel_citi_hierarchy_xref rx, relationship rp ");
				procSQL.append("where rp.id = rx.relationship_id and rx.citi_hierarchy_master_id = ch.id and rg.id = ch.region_id and rp.id = rel.id) reg_NAME,");
				procSQL.append("sec.name sec_name,");
				procSQL.append("bu.BUSINESS_NAME bu_BUSINESS_NAME,");
				procSQL.append("rel.ID rel_ID,");
				procSQL.append("rel.NAME rel_NAME,");
				procSQL.append("tiproc.IS_HIGH_RISK tiproc_IS_HIGH_RISK,");
				procSQL.append("tiproc.IS_BROAD_ACCESS tiproc_IS_BROAD_ACCESS,");
				procSQL.append("usr.SSO_ID usr_SSO_ID,");
				procSQL.append("tireq.request_deadline tireq_request_deadline,");
				procSQL.append("tireq.planned_completion_date tireq_planned_completion_date,");
				procSQL.append("endARes.name endARes_name,");
				procSQL.append("endBRes.name endBRes_name,");
				procSQL.append("tireq.opeimp_scheduled_date tireq_opeimp_scheduled_date,");
				procSQL.append("tireq.opeimp_completed_date tireq_opeimp_completed_date,");
				procSQL.append("rel.relationship_type rel_relationship_type,");
				procSQL.append("tiproc.ACTIVATION_EXP_DATE tiproc_ACTIVATION_EXP_DATE,");
				procSQL.append("tireq.tpwapp_review_date tireq_tpwapp_review_date,");
				procSQL.append("tireq.tpwapp_temp_app_date tireq_tpwapp_temp_app_date,");
				procSQL.append("tat.id tat_id,");
				procSQL.append("ttt.TASK ttt_TASK,");
				procSQL.append("lockedusr.sso_id lockedusr_sso_id,");
				procSQL.append("tat.ACTIVITY_STAGE tat_ACTIVITY_STAGE,");
				procSQL.append("tat.activity_type tat_activity_type,");
				procSQL.append("nvl(userrole.DISPLAY_NAME,'') userrole_DISPLAY_NAME,");
				procSQL.append("userrole.NAME userrole_NAME,");
				procSQL.append("nvl(infrole.DISPLAY_NAME,'') infrole_DISPLAY_NAME,");
				procSQL.append("infrole.NAME infrole_NAME,");
				procSQL.append("ttt.albpm_activity_id ttt_albpm_activity_id ,");
				procSQL.append("tat.bpm_instance_id tat_bpm_instance_id,");
				procSQL.append("ttt.task_code ttt_task_code ,");
				procSQL.append("prtat.id prtat_id,");
				procSQL.append("prtasktype.task_code prtasktype_task_code,");
				procSQL.append("prtasktype.task prtasktype_task,");
				procSQL.append("prtat.activity_status prtat_activity_status,");
				procSQL.append("nvl(prrole.display_name,'') prrole_display_name,");
				procSQL.append("prrole.name prrole_name,");
				procSQL.append("tiProc.temp_approval_flag tiProc_temp_approval_flag,");
				procSQL.append("tireq.APSIMP_SCHEDULED_DATE tireq_APSIMP_SCHEDULED_DATE,");
				procSQL.append("tireq.PRXIMP_SCHEDULED_DATE tireq_PRXIMP_SCHEDULED_DATE,");
				procSQL.append("tireq.INFOMAN_ID tireq_INFOMAN_ID,");
				procSQL.append("tireq.PRX_INFOMAN_ID tireq_PRX_INFOMAN_ID,");
				procSQL.append("tireq.APS_INFOMAN_ID tireq_APS_INFOMAN_ID,");
				procSQL.append("tireq.gnccimp_SCHEDULED_DATE tireq_gnccimp_SCHEDULED_DATE,");
				procSQL.append("tireq.gncc_INFOMAN_ID tireq_gncc_INFOMAN_ID,");
				procSQL.append("tireq.sow_number tireq_sow_number,");
				procSQL.append("to_char(tat.activity_startdate,'MM-DD-YYYY HH24:MI') tat_activity_startdate,");
				procSQL.append("tireq.cmp_id tireq_cmp_id,");
				procSQL.append("tireq.service_now_id tireq_service_now_id ");
				procSQL.append("FROM c3par.ti_process tiproc ,");
				procSQL.append("c3par.ti_request tireq,");
				procSQL.append("c3par.relationship rel,");
				procSQL.append("c3par.REL_CITI_HIERARCHY_XREF relHierarchy,");
				procSQL.append("c3par.CITI_HIERARCHY_MASTER citiHierarchyMaster,");
				procSQL.append("c3par.business_unit bu,");
				procSQL.append("c3par.ti_process_type tiprocType,");
				procSQL.append("c3par.ti_request_type tireqtype,");
				procSQL.append("c3par.region reg,");
				procSQL.append("c3par.resourcetype endARes,");
				procSQL.append("c3par.resourcetype endBRes,");
				procSQL.append("c3par.sector sec,");
				procSQL.append("c3par.generic_lookup prior_gl ,");
				procSQL.append("c3par.c3par_users usr,");
				procSQL.append("c3par.ti_activity_trail tat ,");
				procSQL.append("c3par.role,");
				procSQL.append("c3par.ti_task_type ttt ,");
				procSQL.append("c3par.role userrole,");
				procSQL.append("c3par.role infrole,");
				procSQL.append("c3par.c3par_users lockedusr ,");
				procSQL.append("c3par.ti_activity_trail prtat,");
				procSQL.append("c3par.ti_task_type prtasktype,");
				procSQL.append("c3par.role prrole ");
				procSQL.append("WHERE tiproc.ID                   =tireq.PROCESS_ID ");
				procSQL.append("AND tiproc.RELATIONSHIP_ID        =rel.id ");
				procSQL.append("AND tiproc.PROCESS_TYPE_ID        =tiproctype.ID ");
				procSQL.append("AND tireq.TI_REQUEST_TYPE_ID      =tireqtype.id ");
				procSQL.append("AND RELHIERARCHY.RELATIONSHIP_ID  =REL.ID ");
				procSQL.append("and RELHIERARCHY.CITI_HIERARCHY_MASTER_ID = CITIHIERARCHYMASTER.ID ");
				procSQL.append("and CITIHIERARCHYMASTER.SECTOR_ID = SEC.ID ");
				procSQL.append("and CITIHIERARCHYMASTER.REGION_ID = REG.ID ");
				procSQL.append("and CITIHIERARCHYMASTER.BU_ID = BU.ID ");
				procSQL.append("AND tireq.PRIORITY_ID             =prior_gl.ID(+) ");
				procSQL.append("AND tiproc.VERSION_NUMBER         =tireq.VERSION_NUMBER(+) ");
				procSQL.append("AND tireq.USER_ID                 =usr.id(+) ");
				procSQL.append("AND rel.requester_resource_type_id=endARes.ID(+) ");
				procSQL.append("AND rel.target_resource_type_id   =endBRes.id(+) ");
				procSQL.append("AND tat.LOCKEDBY                  = lockedusr.id(+) ");
				procSQL.append("AND tat.ACTIVITY_ID               =ttt.id(+) ");
				procSQL.append("AND tat.USER_ROLE_ID              =userrole.id(+) ");
				procSQL.append("AND tat.INFOUSER_ROLE_ID          =infrole.ID(+) AND");

				
				if(isString(activityCode) && "Active".equalsIgnoreCase(activityCode) ){
					procSQL.append(" tat.ACTIVITY_STATUS(+)='END' ");
					
				}else{ 
					procSQL.append(" tat.ACTIVITY_STATUS(+)='SCHEDULED' "); 
				}
				procSQL.append(" and tat.PI_REQUESTED_ACTIVITY=prtat.id(+) and prtat.activity_id=prtasktype.id(+) and prtat.user_role_id=prrole.id(+) and tireq.id=tat.ti_request_id(+) " );
				procSQL.append(" and tireq.id=?");
				
				if(isString(activityCode)){
					log.info(" Getting Process Data for activityCode: " + activityCode);
					procSQL	.append(" and tat.ACTIVITY_ID=(select id from c3par.ti_task_type where task_code ='"+activityCode+"')");
				}
				if(isString(prInfoRequestedActivityCode)){
					log.info(" Getting Process Data for prInfoRequestedActivityCode: " + prInfoRequestedActivityCode);
					procSQL	.append("  and prtasktype.TASK_CODE='"+prInfoRequestedActivityCode+"'");
				}
				procSQL	.append("  order by tat.id desc");
				
				log.debug("TI PROCESS DATA:CONNECTION INFORMATION PAGE CHANGES :"+procSQL.toString());
				StringBuilder connSQL = new StringBuilder();
				connSQL.append(" select endARes.name,endBRes.name,cr.FW_TYPE,cfmr.MGT_REGION,pla.PLANNED_ACTIVATE_DATE,cr.IS_ACL_VARIANCE from c3par.resourcetype endARes, c3par.resourcetype endBRes ,c3par.con_fw_mgmt_region cfmr,c3par.con_req cr ");
				connSQL.append(",c3par.planning pla where cr.SOURCE_RESOURCE_TYPE=endARes.ID(+) and cr.TARGET_RESOURCE_TYPE=endBRes.id(+)  and cr.FW_MGMT_REGION_ID=cfmr.ID(+) and cr.id=pla.id and cr.id=?");

				//Ope Imp Infoman Id from RFC Request  -- Starts

				String infomanSQL = " select distinct (rfc_type),rfc_id  from rfc_request where ti_request_id=? and create_type ='AUTO' and rfc_id is not null ";
				log.debug("Infoman SQL is: " + infomanSQL);
				 
				rs = jdbcTemplate.queryForRowSet(infomanSQL, new Object[] {requestID});
				
				String opeInfomanId=null;
				int infomanCount = 0;
				
				while (rs.next()) {
					if (rs.getString(1) != null
							&& rs.getString(1).equals(RFC_REQ_TYPE_FIREWALL)) {
						if (rs.getString(2) != null) {
							if (infomanCount == 0)
								opeInfomanId = rs.getString(2);
							else if (infomanCount > 0) {
								opeInfomanId = opeInfomanId + "," + rs.getString(2);
							}
						}
						infomanCount = infomanCount + 1;
					}
				}
			
				
				//Ope Imp Infoman Id from RFC Request  -- Ends
				log.debug("SQL is: " + procSQL.toString());
				
	    		rs = jdbcTemplate.queryForRowSet(procSQL.toString(), new Object[] {requestID});
	    		tiProcess = new TIProcess();
				
	    		while (rs.next()) {
					tiProcess.setId((rs.getLong("tiProc_ID")));
					tiProcess.setName(rs.getString("tiproc_PROCESS_NAME"));
					tiProcess.setVersionNumber(rs.getInt("tireq_VERSION_NUMBER"));
					tiProcess.getTiRequest().setId(Long.valueOf(requestID));
					tiProcess.getTiRequest().setVersionNumber(tiProcess.getVersionNumber());
					String reqType=rs.getString("tireqtype_REQUEST_TYPE");
					//tiProcess.getTiRequest().getTiRequestType().setName(reqType);
					//log.info(reqType);
				
					if(reqType != null  ){
						if(TIProcessDTO.ACV.equalsIgnoreCase(reqType))
							tiProcess.getTiRequest().getTiRequestType().setName(reqType);
						else
							tiProcess.getTiRequest().getTiRequestType().setName
							(TIProcessService.TIReqType_Create.equalsIgnoreCase(reqType)?TIProcessService.TIProcStat_Planning:
								TIProcessService.TIReqType_Maintain.equalsIgnoreCase(reqType)?TIProcessService.TIProcStat_Maintenance:
									TIProcessService.TIReqType_ManageUserContacts.equalsIgnoreCase(reqType)?TIProcessService.TIReqType_MaintainUserContacts:
										TIProcessService.TIProcStat_Termination);
					}

					//log.info(	"tiProcess.getTiRequest().getTiRequestType().getName()"+tiProcess.getTiRequest().getTiRequestType().getName());
					tiProcess.setProcessActivityMode(rs.getString("tiproc_process_activity_mode"));
					tiProcess.getBusinessCase().getProcessType().setName(rs.getString("tiproctype_PROCESS_TYPE"));
					tiProcess.getTiRequest().getPriority().setValue1(rs.getString("prior_gl_VALUE1"));
					tiProcess.getBusinessCase().setRegionName(rs.getString("reg_NAME"));
					log.debug("Region List in getProcessData"+tiProcess.getBusinessCase().getRegionList());
					tiProcess.getBusinessCase().getSector().setName(rs.getString("sec_name"));
					tiProcess.getBusinessCase().getBusinessUnit().setName(rs.getString("bu_BUSINESS_NAME"));
					tiProcess.getRelationship().setId(Long.valueOf(rs.getLong("rel_ID")));
					tiProcess.getRelationship().setName(rs.getString("rel_NAME"));
					tiProcess.getRelationship().setThirdparty(fetchTPbyRel(tiProcess.getRelationship().getId()));
					tiProcess.setIsHighRisk(rs.getString("tiproc_IS_HIGH_RISK"));
					tiProcess.setIsBroadAccess(rs.getString("tiproc_IS_BROAD_ACCESS"));
					tiProcess.getRequestor().setSoeID(rs.getString("usr_SSO_ID"));
					tiProcess.getTiRequest().setRequestDeadline(rs.getTimestamp("tireq_request_deadline"));
					tiProcess.getTiRequest().setPlannedCompletionDate(rs.getTimestamp("tireq_planned_completion_date"));
					tiProcess.setEndPointAResType(rs.getString("endARes_name"));
					tiProcess.setEndPointBResType(rs.getString("endBRes_name"));
					tiProcess.getTiRequest().setOpeImpScheduledDate(rs.getTimestamp("tireq_opeimp_scheduled_date"));
					tiProcess.getTiRequest().setOpeImpCompletedDate(rs.getTimestamp("tireq_opeimp_completed_date"));
					tiProcess.getRelationship().setRelationshipType(rs.getString("rel_relationship_type"));
					tiProcess.setActivationExpiryDate(rs.getTimestamp("tiproc_ACTIVATION_EXP_DATE"));
					log.debug("Activation exp date: "+ tiProcess.getActivationExpiryDate());
					log.debug("Region/Sector/Business Unit:"+rs.getString("reg_NAME")+"++"+rs.getString("sec_name")+"+++"+rs.getString("bu_BUSINESS_NAME"));
					
					if(tiProcess.getActivationExpiryDate()!= null && tiProcess.getActivationExpiryDate().getTime() > 0){
						 cal.setTime(tiProcess.getActivationExpiryDate());

						//log.info("calender time "+cal.getTime());
						List extendTime = getExtendedTime("ActivationExpDeadline");
						
						if (extendTime != null && extendTime.size() > 0) {
							Integer actExpTime =(Integer)(extendTime.get(0));
							//log.info("   actExpTime"+actExpTime);
							if(actExpTime!=null && actExpTime.intValue()>0){
								cal.add(Calendar.MINUTE,actExpTime.intValue());
								tiProcess.setAcvDeadline(cal.getTime());
								log.debug("ACV Deadlin is "+tiProcess.getAcvDeadline());
							}
						}
					}

					tiProcess.getTiRequest().setTPASWGReviewDate(rs.getTimestamp("tireq_tpwapp_review_date"));
					tiProcess.getTiRequest().setTPASWGTempApprovalDate(rs.getTimestamp("tireq_tpwapp_temp_app_date"));

					ActivityData schActData=new ActivityData();
					schActData.setId(Long.valueOf(rs.getLong("tat_id")));
					schActData.setActivityName(rs.getString("ttt_TASK"));
					schActData.setLockedBy(rs.getString("lockedusr_sso_id"));
					schActData.setActivityStage(rs.getString("tat_ACTIVITY_STAGE"));
					String activityType = rs.getString("tat_activity_type");
					schActData.setActivityType(activityType);
					
					if (!isString(activityType) || (activityType != null && ActivityData.TYPE_APPROVAL.equalsIgnoreCase(activityType))) {
						/*schActData.setDisplayUserRole(rs.getString("userrole_DISPLAY_NAME"));
						schActData.setUserRole(rs.getString("userrole_NAME"));*/
						String displayUserRole = rs.getString("userrole_DISPLAY_NAME");
						log.debug("Display role:"+displayUserRole);
						String userRole = rs.getString("userrole_NAME");
						if(displayUserRole !=null && !displayUserRole.trim().isEmpty()){
							schActData.setDisplayUserRole(displayUserRole);
						}else{
							schActData.setDisplayUserRole("");
						}
						
						schActData.setUserRole(userRole);
						
						if(displayUserRole != null && displayUserRole.trim().equalsIgnoreCase("Security Engineer")){
							schActData.setDisplayUserRole("Global Applied Engineer");
						}
						if(userRole != null && userRole.trim().equalsIgnoreCase("Security Engineer")){
							schActData.setUserRole("Global Applied Engineer");
						}

					} else if (activityType != null && ActivityData.TYPE_PROVIDEINFO.equalsIgnoreCase(activityType)) {
						String displayInfoUserRole = rs.getString("infrole_DISPLAY_NAME");
						String infoUserRole = rs.getString("infrole_NAME");
						String displayUserRole = rs.getString("userrole_DISPLAY_NAME");
						log.debug("Display role:"+displayUserRole +"info:"+displayInfoUserRole);
						
						if(displayInfoUserRole !=null && !displayInfoUserRole.trim().isEmpty()){
						schActData.setDisplayInfoUserRole(displayInfoUserRole);
						}else{
							schActData.setDisplayInfoUserRole("");	
						}
						
						if(displayUserRole !=null && !displayUserRole.trim().isEmpty()){
							schActData.setDisplayUserRole(displayUserRole);
						}else{
							schActData.setDisplayUserRole("");
						}
						
						schActData.setInfoUserRole(infoUserRole);
					
						if(displayInfoUserRole != null && displayInfoUserRole.trim().equalsIgnoreCase("Security Engineer")){
							schActData.setDisplayInfoUserRole("Global Applied Engineer");
						}
						if(infoUserRole != null && infoUserRole.trim().equalsIgnoreCase("Security Engineer")){
							schActData.setInfoUserRole("Global Applied Engineer");
						}
					}
					
					String albpmActivityId=rs.getString("ttt_albpm_activity_id");
					String bpmInstanceId=rs.getString("tat_bpm_instance_id");
					schActData.setAlbpmActivityID(albpmActivityId);
					if(isString(bpmInstanceId) && isString(albpmActivityId)){
						//								bpmInstanceId=bpmInstanceId.replaceAll("0@","1@");
						schActData.setEncodedAlbpmActivity(URLEncoder.encode(bpmInstanceId+"/"+albpmActivityId));
					}
					//activityCode
					schActData.setName(rs.getString("ttt_task_code"));

					schActData.setPrInfoActivityData(new ActivityData());
					if(rs.getString("prtat_id")!=null)
						schActData.getPrInfoActivityData().setId(Long.valueOf(rs.getString("prtat_id")));
					else
						schActData.getPrInfoActivityData().setId(null);
					schActData.getPrInfoActivityData().setName(rs.getString("prtasktype_task_code"));
					schActData.getPrInfoActivityData().setActivityName(rs.getString("prtasktype_task"));
					schActData.getPrInfoActivityData().setActivityStatus(rs.getString("prtat_activity_status"));
					schActData.getPrInfoActivityData().setDisplayUserRole(rs.getString("prrole_display_name"));
					schActData.getPrInfoActivityData().setUserRole(rs.getString("prrole_name"));

					if(isString(activityCode)){
						tiProcess.getTiRequest().setActivityData(schActData);
						tiProcess.setTempApprovalFlag(rs.getString("tiProc_temp_approval_flag"));
						tiProcess.getTiRequest().setApsImpScheduledDate(rs.getTimestamp("tireq_APSIMP_SCHEDULED_DATE"));
						tiProcess.getTiRequest().setPrxImpScheduledDate(rs.getTimestamp("tireq_PRXIMP_SCHEDULED_DATE"));

					}
					tiProcess.getTiRequest().getActivityDataList().add(schActData);
					if(rs.getString("tireq_INFOMAN_ID")!=null && !(rs.getString("tireq_INFOMAN_ID").trim().equalsIgnoreCase("")) &&
							rs.getString("tireq_INFOMAN_ID").trim().equalsIgnoreCase("0")){
						if(opeInfomanId!=null)
							tiProcess.getTiRequest().setNetInfomanId(opeInfomanId);
					}else{
						tiProcess.getTiRequest().setNetInfomanId(rs.getString("tireq_INFOMAN_ID"));
					}
					tiProcess.getTiRequest().setPrxInfomanId(rs.getLong("tireq_PRX_INFOMAN_ID"));
					
					tiProcess.getTiRequest().setApsInfomanId(rs.getLong("tireq_APS_INFOMAN_ID"));

					tiProcess.getTiRequest().setGnccImpScheduledDate(rs.getTimestamp("tireq_gnccimp_SCHEDULED_DATE"));
					tiProcess.getTiRequest().setGnccInfomanId(rs.getLong("tireq_gncc_INFOMAN_ID"));
					tiProcess.getTiRequest().setSowNumber(rs.getString("tireq_sow_number"));
					if (rs.getString("tireq_cmp_id") != null && !rs.getString("tireq_cmp_id").isEmpty()) {
						tiProcess.getTiRequest().setCmpId(rs.getString("tireq_cmp_id"));
					} else {
						tiProcess.getTiRequest().setCmpId(rs.getString("tireq_service_now_id"));
					}
					tiProcess.getTiRequest().setActivityStartDate(rs.getString("tat_activity_startdate"));
				}

				if (TIProcess.CONNECTION.equalsIgnoreCase(tiProcess.getBusinessCase().getProcessType().getName())) {
				 
					rs = jdbcTemplate.queryForRowSet(ccrQueries.getQueryByName(QueryConstants.QUERY_IS_BULK_REQUEST), new Object[] {requestID});
					
					while (rs.next()) {
						tiProcess.setBulkRequest(rs.getString("cr_bulk_request"));
					}

					String tpaFlag = getTPAFlagforIP(requestID);
					String ofacFlag = getOFACFlagforIP(requestID);
					tiProcess.setTpaFlag(tpaFlag==null?"":tpaFlag.equals("Y")?"Yes":"No");
					tiProcess.setOfacFlag(ofacFlag==null?"":ofacFlag.equals("Y")?"Yes":"No");
					tpaFlag = null;
					ofacFlag=null;
				}

				rs = jdbcTemplate.queryForRowSet(ccrQueries.getQueryByName(QueryConstants.QUERY_SOW_PROCESS_DATA), new Object[] {requestID});
			
				while (rs.next()) {
					tiProcess.getTiRequest().setSowNumber(rs.getString("tir_sow_number"));
					break;
				}
				 
				
				String sql_riskflags = "select is_tpa,is_ofac,is_highrisk,is_broadaccess from ti_request_risk_flags WHERE ti_request_id = ? ";
				 
				log.debug("sql_riskflags SQL is " + sql_riskflags);
				 rs = jdbcTemplate.queryForRowSet(sql_riskflags, new Object[] {requestID});
				
				 if (rs.next()) {
					tiProcess.getTiRequest().setTpaFlag(rs.getString("is_tpa"));
					tiProcess.getTiRequest().setIsHighRisk(rs.getString("is_highrisk"));
					tiProcess.getTiRequest().setIsBroadAccess(rs.getString("is_broadaccess"));
					tiProcess.getTiRequest().setOfacFlag(rs.getString("is_ofac"));
					log.debug("OFAC Flag  for  tiRequest ID "+tiProcess.getTiRequest().getOfacFlag());
				}


				String submitterSQL = "select distinct b.name,c.SSO_ID  from c3par.ti_activity_trail a ,c3par.role b,c3par.c3par_users c  where  user_role_id in (select id from c3par.role where name in (?,?))  and  user_role_id=b.id and a.user_id=c.id and a.ti_request_id=? AND a.activity_status <>'UNLOCKED'";
				 
				log.debug("Submitter SQL for tiRequest ID "+submitterSQL +requestID);
				
				rs = jdbcTemplate.queryForRowSet(submitterSQL, new Object[] {ActivityData.ROLE_PC,ActivityData.ROLE_DE,requestID});
				StringBuilder busJusParticipant=new StringBuilder();
				StringBuilder tecArcParticipant=new StringBuilder();
				
				while (rs.next()) {
					if(ActivityData.ROLE_PC.equalsIgnoreCase(rs.getString(1)))
						busJusParticipant.append(rs.getString(2)+";");
					else
						tecArcParticipant.append(rs.getString(2)+";");
				}
				tiProcess.getTiRequest().setBusJusParticipants(busJusParticipant.toString());
				tiProcess.getTiRequest().setTecArcParticipants(tecArcParticipant.toString());
				log.debug("getProcessData.busJusParticipant:"+busJusParticipant);
				log.debug("getProcessData.tecArcParticipant:"+tecArcParticipant);
				
				
				String suppRewRolesSQL ="select reqrole.display_name,rewrole.display_name from c3par.TI_REQ_SUPPLEMENT_REVIEW sup_rew, c3par.role reqrole, c3par.role rewrole  where sup_rew.REVIEWER_ROLE=rewrole.ID and sup_rew.requester_role=reqrole.id and ti_request_id=? ";
				 
				
				log.debug("SUPPReviewRoles  SQL for tiRequest ID "+suppRewRolesSQL  + requestID);
				rs = jdbcTemplate.queryForRowSet(suppRewRolesSQL, new Object[] {requestID});		
			
				while (rs.next()) {
					StringBuilder rewRoles=new StringBuilder();
					rewRoles.append(rs.getString(1));
					rewRoles.append(":"+rs.getString(2));
					tiProcess.getTiRequest().getSuppReviewRoles().add(rewRoles.toString());
				}
				

				if (TIProcess.CONNECTION.equalsIgnoreCase(tiProcess.getBusinessCase().getProcessType().getName())) {
					log.debug("Connection SQL: " + connSQL.toString());
				
					if (tiProcess.getId() != null) { // TODO - To check the parameter
						rs = jdbcTemplate.queryForRowSet(connSQL.toString(), new Object[] { tiProcess.getId()});	
					
						while (rs.next()) {
							// endARes.VALUE1,endBRes.VALUE2,cr.FW_TYPE,cfmr.MGT_REGION,pla.PLANNED_ACTIVATE_DATE,cr.IS_ACL_VARIANCE
							if(isString(rs.getString(1))) 
								tiProcess.setEndPointAResType(rs.getString(1));
							if(isString(rs.getString(2)))
								tiProcess.setEndPointBResType(rs.getString(2));
								tiProcess.getConnectionRequest().setIsACLVariance(rs.getString(6));
						}

						//Get The FireFlow Flag From Ti_Request
						String fireFlowFlag= " select fireflow_flag from ti_request where process_id = ? ";
						 
						log.debug(" Firewall Flag SQL: " + fireFlowFlag);
						String fwFlag="";
						rs = jdbcTemplate.queryForRowSet(fireFlowFlag, new Object[] { tiProcess.getId()});
						
						if (rs.next()) {
								fwFlag=rs.getString(1);
						}
						log.debug("fwFlag::"+fwFlag);
						
						//Set Firewall Location -- Starts
						String  fwLocationSQL = "SELECT DISTINCT cfl.location FROM faf_fireflow_ticket fft,con_fw_group cfg,con_fw_location cfl WHERE fft.ti_request_id = ? AND cfg.id = fft.fw_group AND cfl.id = cfg.fw_location_id ";
						log.debug(" Firewall location SQL: " + fwLocationSQL.toString());
					
						String fwLocation="";
						int count=0;
						
						rs = jdbcTemplate.queryForRowSet(fwLocationSQL, new Object[] { requestID});
						while (rs.next()) {
							if(count>0){
								if(rs.getString(1)!=null || rs.getString(1).trim()!="")
									fwLocation=fwLocation+","+rs.getString(1);
							}else{
								fwLocation=rs.getString(1);
							}
							count++;
						}
						tiProcess.getConnectionRequest().
						setFirewallLocation(fwLocation);
						log.debug("fwLocation::"+fwLocation);
						//Set Firewall Location Ends
						
						if("Y".equalsIgnoreCase(fwFlag)){
							
							//Set Firewall Type -- Starts
							StringBuilder fwTypeSQL=new StringBuilder(" SELECT DISTINCT gl.value1 AS fwtype FROM faf_fireflow_ticket fft,faf_fw_rule ffr, ");
							fwTypeSQL.append(" impl_faf_fw_rule iffr,con_fw_policy cfp,generic_lookup_defs gld,generic_lookup gl ");
							fwTypeSQL.append(" WHERE fft.ti_request_id  = ? AND ffr.fireflow_ticket_id = fft.id ");
							fwTypeSQL.append(" AND iffr.faf_fw_rule_id  = ffr.id AND cfp.id = iffr.policy_id ");
							fwTypeSQL.append(" AND gl.value2 = cfp.fw_type AND gl.definition_id = gld.id ");
							fwTypeSQL.append(" AND gld.name ='Firewall' ");
							
							log.debug(" New Firewall Type SQL added for multiple firewall Types " + fwTypeSQL.toString());
							String fwType="";
							int countType=0;
							rs = jdbcTemplate.queryForRowSet(fwTypeSQL.toString(), new Object[] { requestID});
							
							while (rs.next()) {
								if(countType>0){
									if(rs.getString(1)!=null || rs.getString(1).trim()!="")
										fwType=fwType+","+rs.getString(1);
								}else{
									fwType=rs.getString(1);
								}
								countType++;
							}
							tiProcess.getConnectionRequest().setFirewallType(fwType);
							log.debug("fwType:: "+fwType);
							//Set Firewall Type Ends
							
							
							//Set Firewall Region -- Starts
							String fwRegionSQL =" SELECT DISTINCT cf.region FROM faf_fireflow_ticket fft,  faf_fw_rule ffr,  impl_faf_fw_rule iffr,  con_firewall cf "
							+ " WHERE fft.ti_request_id  = ? AND ffr.fireflow_ticket_id = fft.id AND iffr.faf_fw_rule_id = ffr.id AND cf.policy_id  = iffr.policy_id ";
							
							log.debug(" New fwRegionSQL added for multiple fwRegion " + fwRegionSQL.toString());
							String fwRegion="";
							countType=0;
							rs = jdbcTemplate.queryForRowSet(fwRegionSQL, new Object[] { requestID});
							
							while ( rs.next() ) {
								if( countType > 0 ) {
									if(rs.getString(1)!= null || rs.getString(1).trim() != "")
										fwRegion=fwRegion+","+rs.getString(1);
								} else {
									fwRegion=rs.getString(1);
							  }
								countType++;
							}
							tiProcess.getConnectionRequest().setFirewallRegion(fwRegion);
							log.debug("fwType::"+fwRegion);
							//Set Firewall Region Ends
							
							
							
						}else if("N".equalsIgnoreCase(fwFlag)){
							
							//Set Firewall Type -- Starts
							StringBuilder fwTypeSQL=new StringBuilder(" SELECT DISTINCT gl.value1 AS fwtype FROM ");
							fwTypeSQL.append(" faf_fireflow_ticket fft ");
							fwTypeSQL.append(" JOIN faf_fw_rule ffr ON FFR.fireflow_ticket_id = fft.id ");
							fwTypeSQL.append(" JOIN FAF_FW_RULE_POLICY FFRPC ON FFRPC.FAF_FW_RULE_ID=FFR.ID ");
							fwTypeSQL.append(" JOIN con_fw_policy cfp ON CFP.ID=FFRPC.POLICY_ID ");
							//FW: CCR Development Ticket - BAU: CCR 90378/61467 - Incorrect Firewall Region on Connection Informaiton Page [INC0027567837]
							/*fwTypeSQL.append(" LEFT JOIN impl_faf_fw_rule iffr ON iffr.faf_fw_rule_id = ffr.id AND cfp.id = iffr.policy_id ");
							fwTypeSQL.append(" JOIN generic_lookup_defs gld ON gld.name ='Firewall' ");
							fwTypeSQL.append(" JOIN generic_lookup gl ON gl.value2 = cfp.fw_type ");*/
							//not required below line
							//fwTypeSQL.append(" LEFT JOIN impl_faf_fw_rule iffr ON iffr.faf_fw_rule_id = ffr.id AND cfp.id = iffr.policy_id ");
							fwTypeSQL.append(" JOIN generic_lookup_defs gld ON gld.name ='Firewall' ");
							fwTypeSQL.append(" JOIN generic_lookup gl ON gld.id=gl.definition_id and gl.value2 = cfp.fw_type ");

							
							fwTypeSQL.append(" WHERE FFT.ti_request_id = ? AND FFT.STATUS<>'DELETED' AND (FFT.IP_REG is null OR FFT.IP_REG='N') ");
							
							log.debug(" New Firewall Type SQL added for multiple firewall Types " + fwTypeSQL.toString());
							String fwType="";
							int countType=0;
							rs = jdbcTemplate.queryForRowSet(fwTypeSQL.toString(), new Object[] { requestID});
							while (rs.next()) {
								if(countType>0){
									if(rs.getString(1)!=null || rs.getString(1).trim()!="")
										fwType=fwType+","+rs.getString(1);
								}else{
									fwType=rs.getString(1);
								}
								countType++;
							}
							tiProcess.getConnectionRequest().setFirewallType(fwType);
							log.debug("fwType::"+fwType);
							//Set Firewall Type Ends
							
							//Set Firewall Region -- Starts
							StringBuilder fwRegionSQL=new StringBuilder(" SELECT DISTINCT cf.region FROM ");
							fwRegionSQL.append(" faf_fireflow_ticket fft ");
							fwRegionSQL.append(" JOIN faf_fw_rule ffr ON FFR.fireflow_ticket_id = fft.id ");
							fwRegionSQL.append(" JOIN FAF_FW_RULE_POLICY FFRPC ON FFRPC.FAF_FW_RULE_ID=FFR.ID ");
							fwRegionSQL.append(" JOIN con_firewall cf ON CF.POLICY_ID=FFRPC.POLICY_ID ");
							fwRegionSQL.append(" LEFT JOIN impl_faf_fw_rule iffr ON iffr.faf_fw_rule_id = ffr.id AND CF.POLICY_ID = iffr.policy_id "); 
							fwRegionSQL.append(" WHERE FFT.ti_request_id = ? AND FFT.STATUS<>'DELETED' AND CF.DELETE_FLAG='N' AND (FFT.IP_REG is null OR FFT.IP_REG='N') ");

							log.debug(" New fwRegionSQL SQL added for multiple fwRegion " + fwRegionSQL);
							String fwRegion="";
							countType=0;
							rs = jdbcTemplate.queryForRowSet(fwRegionSQL.toString(), new Object[] { requestID});
							
							while (rs.next()) {
								if(countType>0){
									if(rs.getString(1)!=null || rs.getString(1).trim()!="")
										fwRegion=fwRegion+","+rs.getString(1);
								}else{
									fwRegion=rs.getString(1);
								}
								countType++;
							}
							tiProcess.getConnectionRequest().setFirewallRegion(fwRegion);
							log.debug("fwRegion::"+fwRegion);
							//Set Firewall Region Ends
							
						}

						tiProcess.setFafVersionNumber("0");
						StringBuilder appsenseSQL = new StringBuilder("");
						StringBuilder proxySQL = new StringBuilder("");

							appsenseSQL.append("SELECT LISTAGG(X.APPLICATIONTYPE,',') WITHIN GROUP (ORDER BY X.APPLICATIONTYPE) Y FROM ");
							appsenseSQL.append("(SELECT DISTINCT DECODE(Is_CSI,'Y','CSI',DECODE(IS_BLACKLISTED,'Y','BLACKLISTED','NONCSI')) ");
							appsenseSQL.append(" APPLICATIONTYPE ");
							appsenseSQL.append(" FROM ti_application ");
							appsenseSQL.append("WHERE id IN ");
							appsenseSQL.append("  (SELECT application_id ");
							appsenseSQL.append("  FROM APS_appsense_policy ");
							appsenseSQL.append(" WHERE process_id    = ? ");
							appsenseSQL.append(" AND application_id IS NOT NULL ");
							appsenseSQL.append(" ) ");
							appsenseSQL.append("UNION ");
							appsenseSQL.append("SELECT DISTINCT 'USERS' APPLICATIONTYPE ");
							appsenseSQL.append("FROM APS_appsense_policy ");
							appsenseSQL.append("WHERE process_id    = ? ");
							appsenseSQL.append("AND application_id IS NULL)X");

							proxySQL.append("select listagg(X.REC,',') within group(order by X.REC) region,2  ");
							proxySQL.append("FROM ");
							proxySQL.append("(SELECT DISTINCT pim.region REC,1 Y ");
							proxySQL.append("from  ");
							proxySQL.append("prx_proxy_filter ppf,prx_instance_master pim where ppf.process_id=? and pim.id=ppf.proxy_inst_mst_id ");
							proxySQL.append("UNION ");
							proxySQL.append("SELECT DISTINCT decode(pim.record_type,'BASIC','PROXY_FILTER','FREEURL_ADD','FREEURL_ACCESS',pim.record_type) REC,2 Y ");
							proxySQL.append("from  ");
							proxySQL.append("prx_proxy_filter ppf,prx_instance_master pim where ppf.process_id=? and pim.id=ppf.proxy_inst_mst_id ");
							proxySQL.append(")X GROUP BY X.Y ");
						 

						// Set Appsense Application Type starts
					 
						
						try {
							log.debug(" appsenseSQL " + appsenseSQL.toString());
							rs = jdbcTemplate.queryForRowSet(appsenseSQL.toString(), new Object[] { tiProcess.getId(),tiProcess.getId()});
							
							while (rs.next()) {
								tiProcess.setAppsenseType(rs.getString(1));
							}

							log.debug("tiProcess Appsense::"+tiProcess.getAppsenseType());
						}catch(Exception e)
						{
							log.error(e,e);
						}
						//Set Appsense Application Type ends

						//Set Proxy Region,Type starts

						 
						String proxyRegionValue = "";
						String proxyTypeValue = "";
						
						try {
							log.debug(" proxySQL  " + proxySQL.toString());
							rs = jdbcTemplate.queryForRowSet(proxySQL.toString(), new Object[] { tiProcess.getId(),tiProcess.getId()});
							
							int counter = 0;
							while (rs.next()) {
								if(counter == 0)
								{
									proxyRegionValue = rs.getString(1);
									proxyTypeValue = rs.getString(2);
									counter = 1;
								}else{
									proxyTypeValue = rs.getString(1);
								}
							}
							tiProcess.setProxyRegion(proxyRegionValue);
							tiProcess.setProxyType(proxyTypeValue);
							log.debug("proxyRegion: "+tiProcess.getProxyRegion());
							log.debug("proxyType: "+tiProcess.getProxyType());
						}catch(Exception e)
						{
							log.error(e,e);
						}
						//Set Proxy Region,Type ends

						// Set IPRegistration starts
					 
						String ipRegSQL = "select fafticket.ti_request_id from faf_fireflow_ticket fafticket where fafticket.ti_request_id = ? and fafticket.IP_REG='Y'";

						try {
							log.debug(" ipRegSQL " + ipRegSQL.toString());
							 
							rs = jdbcTemplate.queryForRowSet(ipRegSQL, new Object[] { requestID});
							while (rs.next()) {
								tiProcess.setIpReg("Yes");
							}
							log.debug("tiProcess getIpReg::"+tiProcess.getIpReg());
						}catch(Exception e)
						{
							log.error(e,e);
						}
					}
				}else if(TIProcess.IPREGISTRATION.equalsIgnoreCase(tiProcess.getBusinessCase().getProcessType().getName())){
					String ipRegSQL=" select version_id from c3par.faf_ipreg_history where ti_req_id = ?";
					log.debug(" IPREGFAF VERSION SQL " + ipRegSQL);

					rs = jdbcTemplate.queryForRowSet(ipRegSQL, new Object[] { requestID});
					while (rs.next()) {
						tiProcess.setFafVersionNumber(rs.getString(1));
					}
				}
				if(tiProcess != null && tiProcess.getTiRequest() != null && tiProcess.getTiRequest().getTiRequestType() != null &&
						tiProcess.getTiRequest().getTiRequestType().getName() != null ){
					log.info("Calling affected business for termination phase::: "  + tiProcess.getTiRequest().getTiRequestType().getName());
					if(tiProcess.getTiRequest().getTiRequestType().getName().equals(TIProcessService.TIProcStat_Termination)){
						if(!(isAffectedBusinessDataExists(tiProcess.getTiRequest().getId().longValue()))){
							copyRFCData(tiProcess.getId().longValue(),tiProcess.getTiRequest().getId().longValue());
						}
					}
				}
				log.debug("Completed getProcessData for Requet ID:  "+ requestID );
				
				
				String vendorQuery = "select  nvl(round(sum(a.cr),2),0) from "+
				"(select cfrq.calculated_risk cr "+
				"from third_party thp "+ 
				"join relationship r on thp.id=r.third_party_id "+
				"join ti_process tp on tp.relationship_id=r.id "+
				"join ti_request tr on tp.id=tr.process_id "+
				"join con_fw_rule cfr on cfr.ti_request_id=tr.id "+
				"join con_fw_rule_questionnaire cfrq on cfrq.fw_rule_id=cfr.id "+
				"where cfrq.deleted_ti_request_id is null and cfr.deleted_ti_request_id is null and thp.casp_id=(select casp_id from third_party where id = (select third_party_id from relationship where id= "+tiProcess.getRelationship().getId()+"))) a"; 
				log.debug("vendor Query" +vendorQuery);
				rs  =  jdbcTemplate.queryForRowSet(vendorQuery);
				
				if (rs.next()) {
					tiProcess.setVendorAggregate(rs.getDouble(1));
					log.debug("vendorRisk "+tiProcess.getVendorAggregate());
				}
				
				String connectionQuery = "select  nvl(round(sum(a.cr),2),0) from "+
				"(select cfrq.calculated_risk cr "+
				"from ti_process tp "+ 
				"join ti_request tr on tp.id=tr.process_id "+
				"join con_fw_rule cfr on cfr.ti_request_id=tr.id "+
				"join con_fw_rule_questionnaire cfrq on cfrq.fw_rule_id=cfr.id "+
				"where cfrq.deleted_ti_request_id is null and cfr.deleted_ti_request_id is null and tp.id="+tiProcess.getId()+ ") a ";
				log.debug("connection Query" +connectionQuery);
				rs  =  jdbcTemplate.queryForRowSet(connectionQuery);
				
				if (rs.next()) { 
					tiProcess.setConnAggregate(rs.getDouble(1));
					log.debug("conn Risk Value" +tiProcess.getConnAggregate());
				}
				if(activityCode!=null && (activityCode.equalsIgnoreCase("ope_imp") ||activityCode.equalsIgnoreCase("proxy_imp") || activityCode.equalsIgnoreCase("act_con"))){
				StringBuilder st = new StringBuilder();
				st.append("select distinct rfc_id,INSTALL_BEGIN_DATE,cfl.GREENZONE_START_TIME,cfl.GREENZONE_END_TIME ");
				if(activityCode.equalsIgnoreCase("ope_imp") || activityCode.equalsIgnoreCase("act_con")){
						st.append("from rfc_request,con_fw_location cfl where rfc_type='Firewall' and rfc_request.LOCATION_ID=cfl.id");
				}
				if ( activityCode.equalsIgnoreCase("act_con")){
					st.append(" and ti_request_id= " +requestID + " ");
					st.append(" union select distinct rfc_id,INSTALL_BEGIN_DATE,cfl.GREENZONE_START_TIME,cfl.GREENZONE_END_TIME ");   
				}if(activityCode.equalsIgnoreCase("proxy_imp") || activityCode.equalsIgnoreCase("act_con")){
					st.append(" from rfc_request,con_proxy_location cfl where rfc_type='Proxy' and rfc_request.PROXY_LOCATION_ID=cfl.id ");     
				}
						st.append(" and ti_request_id= " +requestID + "");
						log.debug("st Query" +st.toString());
						rs  =  jdbcTemplate.queryForRowSet(st.toString());
						StringBuilder rfc = new StringBuilder();
						while (rs.next()) { 
							rfc.append(rs.getString(1)+ " - "+ rs.getString(2) +" - " +rs.getString(3) +" - "+ rs.getString(4)+"\n" +"<br>");
						}
						tiProcess.setRfc(rfc.toString());
				}
			}

			catch (Exception e) {
				e.printStackTrace();
				log.error(e,e);
				throw new Exception(e.getMessage());
				
			}
		}
		return tiProcess;
	}

	
	/**
	 * Checks if is string.
	 *
	 * @param val the val
	 * @return true, if is string
	 */
	boolean isString(String val) {
		boolean isString = true;
		if (val == null)
			isString = false;
		if (val != null && val.length() == 0)
			isString = false;
		return isString;
	}
	
	public String getTPAFlagforIP(Long tiReqId) {
		String tpaFlag = "N";
		StringBuilder isTPA = new StringBuilder();
		/*isTPA.append("select 1 from ");
		isTPA.append("faf_history fh, ");
		isTPA.append("con_firewall_rule_master cfrm, ");
		isTPA.append("con_ip_master cip, ");
		isTPA.append("ti_request_planning_xref trpx ");
		isTPA.append("where ");
		isTPA.append("trpx.ti_request_id=? and ");
		isTPA.append("fh.planning_id=trpx.planning_id and ");
		isTPA.append("fh.firewall_rule_id=cfrm.id and ");
		isTPA.append("cfrm.ip_id=cip.id and ");
		isTPA.append("UPPER(cip.is_tpa)='Y' ");*/

		isTPA.append(" select 1 from con_fw_rule rul, con_fw_rule_source_ip sip, ");
		isTPA.append(" con_ip_master ip ");
		isTPA.append(" where ");
		isTPA.append(" rul.id = sip.rule_id and ");
		isTPA.append(" sip.ip_id = ip.id and ip.is_tpa='Y' ");
		isTPA.append(" and rul.ti_request_id= ?");
		isTPA.append(" union ");
		isTPA.append(" select 1 from con_fw_rule rul, con_fw_rule_destination_ip sip, ");
		isTPA.append(" con_ip_master ip ");
		isTPA.append(" where  ");
		isTPA.append(" rul.id = sip.rule_id and ");
		isTPA.append(" sip.ip_id = ip.id and ip.is_tpa='Y' ");
		isTPA.append(" and rul.ti_request_id= ?");

		//changed by eg41091 for removing unwanted log
		log.debug("isTPA.. " + isTPA);
 
		try {
		 
			SqlRowSet isTPARS = jdbcTemplate.queryForRowSet(isTPA.toString(),new Object[] {tiReqId,tiReqId});

			while (isTPARS.next()) {
				tpaFlag = "Y";
				break;
			}
		} catch (Exception e) {
			log.error(e,e);
		}
		return tpaFlag;

	}
	public String getOFACFlagforIP(Long tiReqId) {
		String ofacFlag = "N";
		StringBuilder isOfac = new StringBuilder();
		/*isTPA.append("select 1 from ");
		isTPA.append("faf_history fh, ");
		isTPA.append("con_firewall_rule_master cfrm, ");
		isTPA.append("con_ip_master cip, ");
		isTPA.append("ti_request_planning_xref trpx ");
		isTPA.append("where ");
		isTPA.append("trpx.ti_request_id=? and ");
		isTPA.append("fh.planning_id=trpx.planning_id and ");
		isTPA.append("fh.firewall_rule_id=cfrm.id and ");
		isTPA.append("cfrm.ip_id=cip.id and ");
		isTPA.append("UPPER(cip.is_tpa)='Y' ");*/

		isOfac.append(" select 1 from con_fw_rule rul, con_fw_rule_source_ip sip, ");
		isOfac.append(" con_ip_master ip ");
		isOfac.append(" where ");
		isOfac.append(" rul.id = sip.rule_id and ");
		isOfac.append(" sip.ip_id = ip.id and ip.is_ofac='Y' ");
		isOfac.append(" and rul.ti_request_id= ?");
		isOfac.append(" union ");
		isOfac.append(" select 1 from con_fw_rule rul, con_fw_rule_destination_ip sip, ");
		isOfac.append(" con_ip_master ip ");
		isOfac.append(" where  ");
		isOfac.append(" rul.id = sip.rule_id and ");
		isOfac.append(" sip.ip_id = ip.id and ip.is_ofac='Y' ");
		isOfac.append(" and rul.ti_request_id= ?");

		//changed by eg41091 for removing unwanted log
		log.debug("isOfacQuery Util.. " + isOfac);
 
		try {
		 
			SqlRowSet isTPARS = jdbcTemplate.queryForRowSet(isOfac.toString(),new Object[] {tiReqId,tiReqId});

			while (isTPARS.next()) {
				ofacFlag = "Y";
				break;
			}
		} catch (Exception e) {
			log.error(e,e);
		}
		return ofacFlag;

	}

	/**
	 * Checks if is affected business data exists.
	 *
	 * @param tiRequestId the ti request id
	 * @return true, if is affected business data exists
	 */
	private boolean isAffectedBusinessDataExists(long tiRequestId) {

		StringBuilder sql = new StringBuilder();
	 
		try {
			sql.append("SELECT RDA.ANSWER FROM RFC_DETAIL_ANSWERS RDA, ");
			sql.append(" RFC_DETAIL RD, RFC_LOOKUP RL,RFC_REQUEST RR, TI_REQUEST TR ");
			sql.append(" WHERE TR.ID = RR.TI_REQUEST_ID AND ");
			sql.append(" RR.ID = RD.RFC_REQUEST_ID AND ");
			sql.append(" RD.ID = RDA.RFC_DETAIL_ID AND ");
			sql.append(" RL.ID = RD.RFC_LOOKUP_ID ");
			sql.append(" AND RL.PARAMNAME = 'AFFECTED_BUSINESS' AND TR.ID = ?");
			
			log.debug("Query to be executed for isAffectedBusinessDataExists --- " + sql.toString());
			 
			SqlRowSet result = jdbcTemplate.queryForRowSet(sql.toString(),new Object[] {tiRequestId});
			
			return (result.next());
				
		}
		catch (Exception ex) {
			log.error(ex, ex);
		}
		
		return false;
	}
	
	/** 
	 * Copy rfc data.
	 *
	 * @param processId the process id
	 * @param tiRequestId the ti request id
	 * @throws Exception the exception
	 */
	//TODO - Replace with Spring Callable Statement
	public void copyRFCData(long processId, long tiRequestId) throws Exception{
		Connection con = null;
		CallableStatement stmt = null;
		
		try {
			con =   dataSource.getConnection();
			stmt = con.prepareCall("{call COPY_AFFECTEDBUSINESS(?,?,?)}");
			stmt.setLong(1,processId);
			stmt.setLong(2,tiRequestId);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.execute();
			
			String result = stmt.getString(3);
			
			log.info("Result of copyRFCData is::"+result+":: for tiRequestId-"+tiRequestId);
		} catch(Exception ex){
			log.error(ex,ex);
		}
		
		finally {
			JdbcUtils.closeStatement(stmt);
			JdbcUtils.closeConnection(con);
		}
	}

	
	public List getExtendedTime( String value) throws Exception{
		List extendTimeList = new ArrayList();

		try {
			 
			
			String extendSQL = "select value2 from c3par.generic_lookup where value1 like '" + value + "%'";
			 
			log.debug(" SQL is: " + extendSQL.toString() );

			SqlRowSet result = jdbcTemplate.queryForRowSet( extendSQL );
			
			while(result.next())
				 extendTimeList.add(Integer.valueOf(result.getString(1)));
			 
		}catch(Exception e){
			log.error(e,e);
			throw new RemoteException(e.getMessage());
		}
		
		return extendTimeList;
	}
	
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#getProcessDTO(long, java.lang.String, java.lang.String)
	 */
	public TIProcessDTO getProcessDTO(long requestID,String activityCode,String prInfoRequestedActivityCode) throws Exception {
		log.debug("Entering into getProcessDTO..... ");
		TIProcess tiProcess=getProcessData(requestID,activityCode,prInfoRequestedActivityCode);
		TIProcessDTO tiProcDto=new TIProcessDTO();


		if(tiProcess!=null){
			log.debug("tiProcess IS NOT NULL");
			tiProcDto.setId(tiProcess.getId());
			tiProcDto.setName(tiProcess.getName());
			tiProcDto.setProcessType(tiProcess.getBusinessCase().getProcessType().getName());
			tiProcDto.setRegion(tiProcess.getBusinessCase().getRegionName());
			log.debug("Region List :get ProcessDTO:"+tiProcess.getBusinessCase().getRegionName());
			tiProcDto.setSector(tiProcess.getBusinessCase().getSector().getName());
			tiProcDto.setBusinessUnit(tiProcess.getBusinessCase().getBusinessUnit().getName());
			tiProcDto.setProcessMode(tiProcess.getProcessActivityMode());
			tiProcDto.setVersionNumber(tiProcess.getVersionNumber());

			tiProcDto.setPriority(tiProcess.getTiRequest().getPriority().getValue1());
			tiProcDto.setIsHighRisk(tiProcess.getIsHighRisk());
			tiProcDto.setIsBroadAccess(tiProcess.getIsBroadAccess());
			tiProcDto.setRequestorSOEId(tiProcess.getRequestor().getSoeID());
			tiProcDto.setEndPointAResType(tiProcess.getEndPointAResType());
			tiProcDto.setEndPointBResType(tiProcess.getEndPointBResType());
			tiProcDto.setFirewallType(tiProcess.getConnectionRequest().getFirewallType());
			tiProcDto.setFirewallRegion(tiProcess.getConnectionRequest().getFirewallRegion());
			tiProcDto.setIsACLVariance(tiProcess.getConnectionRequest().getIsACLVariance());
			tiProcDto.setFirewallLocation(tiProcess.getConnectionRequest().getFirewallLocation());
			tiProcDto.setActivationExpiryDate(tiProcess.getActivationExpiryDate());
			tiProcDto.setTPASWGReviewDate(tiProcess.getTiRequest().getTPASWGReviewDate());
			tiProcDto.setTPASWGTempApprovalDate(tiProcess.getTiRequest().getTPASWGTempApprovalDate());
			tiProcDto.setAcvDeadline(tiProcess.getAcvDeadline());
			tiProcDto.setTempApprovalFlag(tiProcess.getTempApprovalFlag());

			//tiRequest Domain obj changes
			tiProcDto.setTiReqType(tiProcess.getTiRequest().getTiRequestType().getName());
			log.debug(" REQUEST TYPE DTO "+tiProcDto.getTiReqType()+ " RequestType domain "+tiProcess.getTiRequest().getTiRequestType().getName());
			/*if (tiProcess.getBusinessCase().getRegionName() != null
					&& !tiProcess.getBusinessCase().getRegionName().isEmpty()) {
				if (tiProcess.getBusinessCase().getRegionName().indexOf(",") != -1) {
					String[] regionList = tiProcess.getBusinessCase().getRegionName().split(",");
					StringBuilder entitlements = new StringBuilder();
					int i = 0;
					for (String region : regionList) {
						if (i > 0) {
							entitlements.append(",");
						}
						entitlements.append(region+"-"+tiProcess.getBusinessCase().getSector().getName());
						i++;
					}
					tiProcDto.setEntitlement(entitlements.toString());
					log.debug("Entitlement :get ProcessDTO:"+entitlements);
				} else {
					tiProcDto.setEntitlement(tiProcess.getBusinessCase().getRegionName()+"-"+tiProcess.getBusinessCase().getSector().getName());
					log.debug("Entitlement :get ProcessDTO:"+tiProcDto.getEntitlement());
				}
				
			}*/
			tiProcDto.setEntitlement(tiProcess.getBusinessCase().getSector().getName());
			tiProcDto.setRequestDeadline(tiProcess.getTiRequest().getRequestDeadline());
			tiProcDto.setPlannedCompletionDate(tiProcess.getTiRequest().getPlannedCompletionDate());



			//log.info(	"tiProcess.getTiRequest().getTiRequestType().getName()"+tiProcess.getTiRequest().getTiRequestType().getName());

			tiProcDto.setRelationshipId(tiProcess.getRelationship().getId());
			tiProcDto.setRelationshipName(tiProcess.getRelationship().getName());
			tiProcDto.setRelationshipType(tiProcess.getRelationship().getRelationshipType());
			tiProcDto.setCaspId(tiProcess.getRelationship().getThirdparty().getCaspId());
			tiProcDto.setCaspDetailId(tiProcess.getRelationship().getThirdparty().getCaspDetailId());
			

			//			activityData Domain obj changes
			List activityDataList =tiProcess.getTiRequest().getActivityDataList();
			if(activityDataList!=null && activityDataList.size()>0){
				Iterator itr=activityDataList.iterator();
				while(itr.hasNext()){
					ActivityData actData=(ActivityData)itr.next();
					ActivityDataDTO actDTO=new ActivityDataDTO();
					actDTO.setId(actData.getId());
					actDTO.setActivityName(actData.getActivityName());
					actDTO.setActivityCode(actData.getName());
					actDTO.setLockedBy(actData.getLockedBy());
					actDTO.setActivityStage(actData.getActivityStage());
					actDTO.setActivityType(actData.getActivityType());
					actDTO.setUserRole(actData.getUserRole());
					actDTO.setDisplayUserRole(actData.getDisplayUserRole());
					actDTO.setInfoUserRole(actData.getInfoUserRole());
					actDTO.setDisplayInfoUserRole(actData.getDisplayInfoUserRole());
					//ProvideInfoActivityDTO prInfoRequestedActCode=new ProvideInfoActivityDTO();
					ActivityDataDTO prInfoRequestedActCode=new ActivityDataDTO();

					prInfoRequestedActCode.setActivityCode(actData.getPrInfoActivityData().getName());
					prInfoRequestedActCode.setActivityName(actData.getPrInfoActivityData().getActivityName());
					prInfoRequestedActCode.setActivityStatus(actData.getPrInfoActivityData().getActivityStatus());
					prInfoRequestedActCode.setUserRole(actData.getPrInfoActivityData().getUserRole());
					prInfoRequestedActCode.setDisplayUserRole(actData.getPrInfoActivityData().getDisplayUserRole());
					actDTO.setPrInfoActivityDataDTO(prInfoRequestedActCode);
					tiProcDto.getActivityDataDTOList().add(actDTO);
				}
				if(isString(activityCode)){
					tiProcDto.setActivityDataDto((ActivityDataDTO)tiProcDto.getActivityDataDTOList().get(0));
				}

			}
			/*tiProcDto.getActivityDataDto().setId(tiProcess.getTiRequest().getActivityData().getId());
			tiProcDto.getActivityDataDto().setActivityName(tiProcess.getTiRequest().getActivityData().getActivityName());
			tiProcDto.getActivityDataDto().setActivityCode(tiProcess.getTiRequest().getActivityData().getName());
			tiProcDto.getActivityDataDto().setLockedBy(tiProcess.getTiRequest().getActivityData().getLockedBy());
			tiProcDto.getActivityDataDto().setActivityStage(tiProcess.getTiRequest().getActivityData().getActivityStage());
			tiProcDto.getActivityDataDto().setActivityType(tiProcess.getTiRequest().getActivityData().getActivityType());
			tiProcDto.getActivityDataDto().setUserRole(tiProcess.getTiRequest().getActivityData().getUserRole());
			tiProcDto.getActivityDataDto().setInfoUserRole(tiProcess.getTiRequest().getActivityData().getInfoUserRole());*/

			tiProcDto.setFafVersionNumber(tiProcess.getFafVersionNumber());
			tiProcDto.setTiRequestId(Long.valueOf(requestID));
			tiProcDto.setBulkRequest(tiProcess.getBulkRequest());
			tiProcDto.setAppsenseType(tiProcess.getAppsenseType());
			tiProcDto.setProxyRegion(tiProcess.getProxyRegion());
			tiProcDto.setProxyType(tiProcess.getProxyType());
			tiProcDto.setTpaFlag(tiProcess.getTpaFlag());
			tiProcDto.setOfacFlag(tiProcess.getOfacFlag());;
			tiProcDto.setIsIPReg(tiProcess.getIpReg());

			log.debug("bulkrequest process::"+tiProcDto.getBulkRequest());
			log.debug("appsenseType process::"+tiProcDto.getAppsenseType());
			log.debug("proxyRegion process::"+tiProcDto.getProxyRegion());
			log.debug("proxyType process::"+tiProcDto.getProxyType());
			log.debug("bulkrequest dto::"+tiProcDto.getBulkRequest());
			log.debug("appsenseType dto::"+tiProcDto.getAppsenseType());
			log.debug("proxyRegion dto::"+tiProcDto.getProxyRegion());
			log.debug("proxyType dto::"+tiProcDto.getProxyType());
			log.debug("IsIPReg dto::"+tiProcDto.getIsIPReg());
			log.debug("Request Ofac Flag::"+tiProcDto.getOfacFlag());

			tiProcDto.setBulkRequest(tiProcess.getBulkRequest()); 
			tiProcDto.setTpaFlagTIReq(tiProcess.getTiRequest().getTpaFlag());
			tiProcDto.setOfacFlagTIReq(tiProcess.getTiRequest().getOfacFlag());
			//tiProcDto.setOfacFlag(tiProcess.getTiRequest().getOfacFlag());
			tiProcDto.setIsHighRiskTIReq(tiProcess.getTiRequest().getIsHighRisk());
			tiProcDto.setIsBroadAccessTIReq(tiProcess.getTiRequest().getIsBroadAccess());
			tiProcDto.setSuppReviewRoles(tiProcess.getTiRequest().getSuppReviewRoles());
			tiProcDto.setBusJusParticipants(tiProcess.getTiRequest().getBusJusParticipants());
			tiProcDto.setTecArcParticipants(tiProcess.getTiRequest().getTecArcParticipants());
			tiProcDto.setVendorAggregate(tiProcess.getVendorAggregate());
			tiProcDto.setConnAggregate(tiProcess.getConnAggregate());
			log.debug("tiProcess.getTiRequest().getBusJusParticipants():"+tiProcess.getTiRequest().getBusJusParticipants());
			log.debug("tiProcess.getTiRequest().getTecArcParticipants():"+tiProcess.getTiRequest().getTecArcParticipants());
		}

		return tiProcDto;
	}

	private ThirdParty fetchTPbyRel(Long relationshipId) {
		ThirdParty tp = new ThirdParty();
		
		ResultSet rs = null;
		Connection con = null; 
		PreparedStatement stmt = null;
		con =    DataSourceUtils.getConnection(dataSource); 
		String sql = "select tp.id TP_ID,casp_id,detail_id from third_party tp, relationship rel where tp.id=rel.third_party_id and rel.id=?";
		try {
			stmt = con.prepareStatement(sql);
			stmt.setLong(1, relationshipId);
			rs = stmt.executeQuery();
			while(rs.next()) {
				tp.setId(new Long(rs.getLong("TP_ID")));
				tp.setCaspId(new Long(rs.getLong(ThirdParty.CASP_ID)));
				tp.setCaspDetailId(new Long(rs.getLong(ThirdParty.DETAIL_ID)));
			}
			
		}catch (Exception e) {
			log.error(e,e);
		}    
			finally {
				JdbcUtils.closeStatement(stmt);
				DataSourceUtils.releaseConnection(con, dataSource);
			}
		return tp;
	}
	
	public String getLastCmpServiceNowID(Long connectionID)throws Exception {
		String cmpIDSNowID = "";
		try {		
			StringBuffer sql = new StringBuffer(" select cmp_id,service_now_id from ti_request where process_id= "+connectionID +
					" and id = (select max(id) from ti_request where process_id="+connectionID+
					" and ti_request_type_id not in(select id from ti_request_type where request_type in ('ACV','ManageContacts')))");	
			
			log.debug("getLastCmpServiceNowID SQL is: " + sql.toString() );
			SqlRowSet result = jdbcTemplate.queryForRowSet(sql.toString());	
			while(result.next()){
				if (result.getString("cmp_id") != null && !result.getString("cmp_id").isEmpty()) {
					cmpIDSNowID = result.getString("cmp_id");
				} else {
					cmpIDSNowID = result.getString("service_now_id");
				}
			}			 
		}catch(Exception e){
			log.error(e,e);
			throw new RemoteException(e.getMessage());
		}
		log.info("ManageTIProcessUtil::getLastCmpServiceNowID ::connectionID-"+connectionID+" ::cmpIDSNowID-"+cmpIDSNowID);		
		return cmpIDSNowID;
	}
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public CCRQueries getCcrQueries() {
		return ccrQueries;
	}

	public void setCcrQueries(CCRQueries ccrQueries) {
		this.ccrQueries = ccrQueries;
	}	
}