/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author bs45969
 * 
 */
public class FafFirewallRule extends Base {
    /**
     * 
     */
    private static final long serialVersionUID = 2831874250009200198L;
    private FafFireflowTicket fafFireFlowTicket;
    private FirewallPolicy policy;
    private FireWallZone sourceZone;
    private FireWallZone destinationZone;
    private ResourceType sourceNetworkZone;
    private ResourceType destinationNetworkZone;
    private List<FafFirewallRuleSourceIP> sourceIPs;
    private List<FafFirewallRuleDestinationIP> destinationIPs;
    private List<FafFirewallRulePort> ports;
    private List<FafFirewallRulePolicy> policies;
    private List<FafFirewallRuleSuggestion> recommendedRules;
    private TIRequest tiRequest;
    private TIRequest updatedTIRequest;
    private FireWallRule fireWallRule;
    private int ruleSequence;
    private String deleted;
    private String ruleType;


    public FafFirewallRule() {
	setCreated_date(new Date());
    }

    /**
     * @return the fafFireFlowTicket
     */
    public FafFireflowTicket getFafFireFlowTicket() {
	return fafFireFlowTicket;
    }

    /**
     * @param fafFireFlowTicket
     *            the fafFireFlowTicket to set
     */
    public void setFafFireFlowTicket(FafFireflowTicket fafFireFlowTicket) {
	this.fafFireFlowTicket = fafFireFlowTicket;
    }

    /**
     * @return the policy
     */
    public FirewallPolicy getPolicy() {
	return policy;
    }

    /**
     * @param policy
     *            the policy to set
     */
    public void setPolicy(FirewallPolicy policy) {
	this.policy = policy;
    }

    /**
     * @return the sourceZone
     */
    public FireWallZone getSourceZone() {
	return sourceZone;
    }

    /**
     * @param sourceZone
     *            the sourceZone to set
     */
    public void setSourceZone(FireWallZone sourceZone) {
	this.sourceZone = sourceZone;
    }

    /**
     * @return the destinationZone
     */
    public FireWallZone getDestinationZone() {
	return destinationZone;
    }

    /**
     * @param destinationZone
     *            the destinationZone to set
     */
    public void setDestinationZone(FireWallZone destinationZone) {
	this.destinationZone = destinationZone;
    }

    /**
     * @return the sourceNetworkZone
     */
    public ResourceType getSourceNetworkZone() {
	return sourceNetworkZone;
    }

    /**
     * @param sourceNetworkZone
     *            the sourceNetworkZone to set
     */
    public void setSourceNetworkZone(ResourceType sourceNetworkZone) {
	this.sourceNetworkZone = sourceNetworkZone;
    }

    /**
     * @return the destinationNetworkZone
     */
    public ResourceType getDestinationNetworkZone() {
	return destinationNetworkZone;
    }

    /**
     * @param destinationNetworkZone
     *            the destinationNetworkZone to set
     */
    public void setDestinationNetworkZone(ResourceType destinationNetworkZone) {
	this.destinationNetworkZone = destinationNetworkZone;
    }

    /**
     * @return the sourceIPs
     */
    public List<FafFirewallRuleSourceIP> getSourceIPs() {
	return sourceIPs;
    }

    /**
     * @param sourceIPs
     *            the sourceIPs to set
     */
    public void setSourceIPs(List<FafFirewallRuleSourceIP> sourceIPs) {
	this.sourceIPs = sourceIPs;
    }

    /**
     * @return the destinationIPs
     */
    public List<FafFirewallRuleDestinationIP> getDestinationIPs() {
	return destinationIPs;
    }

    /**
     * @param destinationIPs
     *            the destinationIPs to set
     */
    public void setDestinationIPs(
	    List<FafFirewallRuleDestinationIP> destinationIPs) {
	this.destinationIPs = destinationIPs;
    }

    /**
     * @return the ports
     */
    public List<FafFirewallRulePort> getPorts() {
	return ports;
    }

    /**
     * @param ports
     *            the ports to set
     */
    public void setPorts(List<FafFirewallRulePort> ports) {
	this.ports = ports;
    }

    /**
     * @return the ruleSequence
     */
    public int getRuleSequence() {
	return ruleSequence;
    }

    /**
     * @param ruleSequence
     *            the ruleSequence to set
     */
    public void setRuleSequence(int ruleSequence) {
	this.ruleSequence = ruleSequence;
    }

    /**
     * @return the recommendedRules
     */
    public List<FafFirewallRuleSuggestion> getRecommendedRules() {
	return recommendedRules;
    }

    /**
     * @param recommendedRules
     *            the recommendedRules to set
     */
    public void setRecommendedRules(
	    List<FafFirewallRuleSuggestion> recommendedRules) {
	this.recommendedRules = recommendedRules;
    }

    /**
     * @return the fireWallRule
     */
    public FireWallRule getFireWallRule() {
	return fireWallRule;
    }

    /**
     * @param fireWallRule
     *            the fireWallRule to set
     */
    public void setFireWallRule(FireWallRule fireWallRule) {
	this.fireWallRule = fireWallRule;
    }

    /**
     * @return the deleted
     */
    public String getDeleted() {
	return deleted;
    }

    /**
     * @param deleted
     *            the deleted to set
     */
    public void setDeleted(String deleted) {
	this.deleted = deleted;
    }
    
    @Override
    public String toString() {

	StringBuilder result = new StringBuilder();
	int sourceCount = 0;
	int destinationCount = 0;
	int portCount = 0;

	// FAF_FireWallRuleSourceIP [] sourceIPString = sourceIPs.toArray(new
	// FAF_FireWallRuleSourceIP[sourceIPs.size()]);
	// FAF_FireWallRuleDestinationIP [] destinationIPString =
	// destinationIPs.toArray(new
	// FAF_FireWallRuleDestinationIP[destinationIPs.size()]);
	for (FafFirewallRuleSourceIP fafFireWallRuleSourceIP : sourceIPs) {
	    sourceCount++;
	    result.append(fafFireWallRuleSourceIP);
	    if (sourceCount < sourceIPs.size()) {
		result.append(",");
	    }

	}

	result.append(";");

	for (FafFirewallRuleDestinationIP fafFireWallRuleDestIP : destinationIPs) {
	    destinationCount++;
	    result.append(fafFireWallRuleDestIP);
	    if (destinationCount < destinationIPs.size()) {
		result.append(",");
	    }

	}

	result.append(";");

	for (FafFirewallRulePort fafFireWallRulePort : ports) {
	    portCount++;
	    result.append(fafFireWallRulePort);
	    if (portCount < ports.size()) {
		result.append(",");
	    }

	}
	
	if (fafFireFlowTicket.getType() == 'A'){
		result.append(";Allow");	
	} else if (fafFireFlowTicket.getType() == 'D'){
		result.append(";Drop");
	}
	

	return result.toString();
    }

	/**
	 * @return the tiRequest
	 */
	public TIRequest getTiRequest() {
		return tiRequest;
	}

	/**
	 * @param tiRequest the tiRequest to set
	 */
	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	/**
	 * @return the updatedTIRequest
	 */
	public TIRequest getUpdatedTIRequest() {
		return updatedTIRequest;
	}

	/**
	 * @param updatedTIRequest the updatedTIRequest to set
	 */
	public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
		this.updatedTIRequest = updatedTIRequest;
	}

	/**
	 * @return the policies
	 */
	public List<FafFirewallRulePolicy> getPolicies() {
		return policies;
	}

	/**
	 * @param policies the policies to set
	 */
	public void setPolicies(List<FafFirewallRulePolicy> policies) {
		this.policies = policies;
	}
	
	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}


}
