package com.citigroup.cgti.c3par.ext.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.citigroup.cgti.c3par.dao.C3parUsersDAO;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;


/**
 * The Class C3parUsersExtDAO.
 */
public class C3parUsersExtDAO extends C3parUsersDAO implements Serializable {

    //private static final String queryString = "SELECT   distinct  c.ID ID, c.DISPLAY_NAME DISPLAY_NAME, c.DISPLAY_POSITION DISPLAY_POSITION, c.PATH PATH, c.PARENT_FUNCTION PARENT_FUNCTION, c.IMAGE_PATH IMAGE_PATH, LEVEL FUNCTION_LEVEL FROM c3par_user_role_xref a, c3par_role_function b, c3par_function c WHERE a.user_id = ? AND a.role_id = b.role_id AND b.function_id = c.id START WITH c.parent_function IS NULL CONNECT BY PRIOR c.id = c.parent_function";


    /** The Constant queryString. */
    private static final String queryString =  "SELECT " +
    " c.ID ID," +
    " c.DISPLAY_NAME DISPLAY_NAME," +
    " c.DISPLAY_POSITION DISPLAY_POSITION," +
    " c.DISPLAY_CONDITION DISPLAY_CONDITION," +
    " c.PATH PATH,	" +
    " c.PARENT_FUNCTION PARENT_FUNCTION, c.IMAGE_PATH IMAGE_PATH," +
    " LEVEL FUNCTION_LEVEL" +
    " FROM c3par_role_function b, c3par_function c," +
    " (select  function_id ,max(b.id) id from c3par_user_role_xref a, c3par_role_function b" +
    " WHERE a.user_id = ? " +
    " AND a.role_id = b.role_id" +
    " group by function_id) a" +
    " WHERE a.id  = b.id" +
    " AND b.function_id = c.id" +
    " START WITH c.parent_function" +
    " IS NULL CONNECT BY PRIOR c.id = c.parent_function" +
    " order by function_level,DISPLAY_POSITION ";


    //	======================================================================
    /**
     * Gets the function.
     *
     * @param session the session
     * @param user_id the user_id
     * @return the function
     * @throws DatabaseException the database exception
     */
    public ArrayList getFunction(DatabaseSession session, Long user_id) throws DatabaseException
    {
	Long id_to_get = user_id;
	ArrayList functionList = new ArrayList();
	//C3parUsersExtEntity obj = entity;

	if(id_to_get != null)
	{
	    //id_to_get = obj.getId();
	    //			DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		st = connection.prepareStatement(queryString);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		while (rs.next()) {
		    HashMap functionMap = new HashMap();
		    functionMap.put("function_id",rs.getString("ID"));
		    functionMap.put("function_name",rs.getString("DISPLAY_NAME"));
		    functionMap.put("function_display_position", rs.getString("DISPLAY_POSITION"));
		    functionMap.put("function_display_condition", rs.getString("DISPLAY_CONDITION"));
		    functionMap.put("function_path", rs.getString("PATH"));
		    functionMap.put("function_parent", rs.getString("PARENT_FUNCTION"));
		    functionMap.put("function_image_path", rs.getString("IMAGE_PATH"));
		    functionMap.put("function_status", "false");

		    functionList.add(functionMap);
		    //					obj = (C3parUsersEntity) createEntity(rs);
		}
		//obj.setFunction(functionList);

	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + C3parUsersDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}



	return functionList;
    }

    //	======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the c3par users dao
     */
    public static C3parUsersDAO createInstance(DatabaseSession session)
    {
	return new C3parUsersExtDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new c3par users ext dao.
     *
     * @param session the session
     */
    public C3parUsersExtDAO(DatabaseSession session)
    {
	super(session);
	//		superInstance =dao;
    }
}
