package com.citigroup.cgti.c3par.bpm.ejb.rel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.bpm.ejb.domain.LookupDTO;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipSearchAttributesDTO;
import com.citigroup.cgti.c3par.dashboard.webtier.helper.RelationshipSearchAttributes;
import com.citigroup.cgti.c3par.dashboard.webtier.helper.SearchRelationship;
import com.citigroup.cgti.c3par.domain.helper.RelSrchAttrDTOToRelSrchAttrMapper;
import com.citigroup.cgti.c3par.domain.helper.RelationshipEntityToRelationshipMapper;
import com.citigroup.cgti.c3par.model.RelationshipEntity;
import com.mentisys.dao.DatabaseException;


/**
 * The Class SearchRelationshipImpl.
 */
@SuppressWarnings( { "unchecked", "unused" })
public class SearchRelationshipImpl  implements ISearchRelationship {
	/** The log. */
	private Logger log = Logger.getLogger(SearchRelationshipImpl.class);

    private static final List<LookupDTO> LOOKUPDTO = Arrays.asList (new LookupDTO("Other"),new LookupDTO("Help Desk/Call Center"),new LookupDTO( "Infrastructure Support"),new LookupDTO("Loan Operations"),new LookupDTO("Software Development & Maintenance")); 

    private static final String ENDPOINTRESOURCETYPESQL = "Select ID,Name from c3par.RESOURCETYPE where status='Active' order by id";
    private static final String DATACLASSIFICATIONSQL = "select id,value1 from c3par.generic_lookup where definition_id =(select id from c3par.generic_lookup_defs where upper(name) = upper('Classification')) and deleted='N'";
    private static final String PRIORITYSQL = "select id,value1 from c3par.generic_lookup where definition_id =(select id from c3par.generic_lookup_defs where upper(name) = upper('Process Priority')) and deleted='N'";
    private static final String TASKLISTSQL = "select id,task from c3par.ti_task_type where ALBPM_ACTIVITY_ID is not null and process='Connection' order by task";
    private static final String REGIONSQL = "select id,name from c3par.region where IS_ACTIVE!='N'";
    private static final String ROLESQL = "select id,name from c3par.role order by name";
    private JdbcTemplate jdbcTemplate;


	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getEnpointResourceType()
	 */
	public List getEnpointResourceType() throws Exception {
		return getFromLookup( ENDPOINTRESOURCETYPESQL );
	}
	 
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getDataClassification()
	 */
	public List getDataClassification() throws Exception {
	 	return getFromLookup( DATACLASSIFICATIONSQL );
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getPriority()
	 */
	public List getPriority() throws Exception{
		return getFromLookup( PRIORITYSQL );
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getTaskList()
	 */
	public List getTaskList() throws Exception{
		return getFromLookup( TASKLISTSQL );
	}
	
	 
	public List getRolesList() throws Exception{
		return getFromLookup( ROLESQL );
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getRegion()
	 */
	public List getRegion() throws Exception{
		return getFromLookup( REGIONSQL );
	}
	
	
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getServiceType()
	 */
	public List getServiceType(){
		 return LOOKUPDTO;
	}
	
	
	
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getThirdParty(java.lang.String)
	 */
	public List getThirdParty(String filterCond) throws Exception{
		final StringBuffer sql=new StringBuffer("Select distinct Name, Name from c3par.third_party  ");
	
		if(filterCond!=null && !filterCond.trim().equals(""))
			sql.append("where upper(name) like upper('%"+filterCond+"%') ");
		
		sql.append("order by 1");
	 
		return getFromLookupValues(sql.toString());
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getBusinessUnit(java.lang.String)
	 */
	public List getBusinessUnit(String filterCond) throws Exception{
		final StringBuffer sql=new StringBuffer("Select distinct business_name, business_name from c3par.BUSINESS_UNIT where is_active='Y' ");
	
		if(filterCond!=null && !filterCond.trim().equals(""))
			sql.append("and upper(business_name) like upper('%"+filterCond+"%') ");
		
		sql.append("order by 1");
		 
		return getFromLookupValues(sql.toString()); 
	}

	

	

	/* (non-Javadoc
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getSector(java.lang.Long)
	 */
	public List getSector(Long regionId) throws Exception{
		List objList = null;
		StringBuffer sql= null;
		if(regionId!=null && regionId.longValue()>0){
			sql = new StringBuffer("SELECT DISTINCT S.ID,S.NAME FROM CITI_HIERARCHY_MASTER CM,SECTOR S,REGION R WHERE ");
					sql.append(" S.IS_ACTIVE!='N' AND CM.REGION_ID  = "+regionId.longValue()+" ORDER BY S.NAME ");
         
			objList=getFromLookup(sql.toString());
			log.debug("SectorList:"+sql.toString());
		}
		return objList;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getTPASWGReviewType()
	 */
	public List getTPASWGReviewType() throws Exception {
		StringBuffer sql=new StringBuffer("select VALUE1,VALUE2 from ");
	  	sql.append("c3par.GENERIC_LOOKUP");
	  	sql.append(" WHERE DEFINITION_ID IN ");
	  	sql.append(" (select id from c3par.GENERIC_LOOKUP_DEFS where name='TPASWG REVIEW TYPE') ");
	 
		return getFromLookupValues(sql.toString());
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getTPASWGReviewStatus()
	 */
	public List getTPASWGReviewStatus() throws Exception {
		StringBuffer sql=new StringBuffer("select VALUE1,VALUE2 from ");
	  	sql.append("c3par.GENERIC_LOOKUP");
	  	sql.append(" WHERE DEFINITION_ID IN ");
	  	sql.append(" (select id from c3par.GENERIC_LOOKUP_DEFS where name='TPASWG REVIEW STATUS') ");
	
		return getFromLookupValues(sql.toString());
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getRelationship(java.lang.String, com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipSearchAttributesDTO, int, int)
	 */
	public List getRelationship(String Type,RelationshipSearchAttributesDTO attrs,int pageSize,  int pageNum) throws Exception{
		List objList = new ArrayList();
		List relationshipList = new ArrayList();
		RelationshipEntity relEntity;
		RelationshipDTO relationship;
		RelationshipSearchAttributes relSrchAttr = new RelationshipSearchAttributes();
		RelSrchAttrDTOToRelSrchAttrMapper.transformToRelSearchAttributes(attrs,relSrchAttr);
		// Refactored for connection leak
		SearchRelationship searchRel = new SearchRelationship(new C3parSession(), relSrchAttr);
		objList = searchRel.runQuery(pageNum,  pageSize);
		for(int i=0;i<objList.size();i++){
			relEntity = (RelationshipEntity)objList.get(i);
			relationship = new RelationshipDTO();
			RelationshipEntityToRelationshipMapper.transformToRelationshipForSearch(relEntity, relationship);
			relationshipList.add(relationship);
		}
		
		return relationshipList;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.rel.ISearchRelationship#getCount(java.lang.String, com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipSearchAttributesDTO)
	 */
	public int getCount(String Type,RelationshipSearchAttributesDTO attrs) throws Exception{
		RelationshipSearchAttributes relSrchAttr = new RelationshipSearchAttributes();
		RelSrchAttrDTOToRelSrchAttrMapper.transformToRelSearchAttributes(attrs,relSrchAttr);
		// Refactored for connection leak
		SearchRelationship searchRel = new SearchRelationship(new C3parSession(), relSrchAttr);
		int resultCount = searchRel.getCount();
		return resultCount;
	}



	/**
	 * Gets the from lookup.
	 *
	 * @param sql the sql
	 * @return the from lookup
	 * @throws Exception the exception
	 */
	public ArrayList getFromLookup(String sql) throws Exception {
		LookupDTO obj = null;
		ArrayList<LookupDTO> objList = new ArrayList<LookupDTO>();
		
	  	
		try {
			 log.debug("Inside the lookup : "+ sql);
			 SqlRowSet rs = jdbcTemplate.queryForRowSet(sql);

			    while(rs.next()) {
		    		obj = new LookupDTO(rs.getLong(1),rs.getString(2),null);
		    		objList.add( obj );
			       }
			   }
	  	 catch (Exception e) {
				throw new DatabaseException("Could not load ", e);
			}
	 
		log.debug("Size of Value Object List is "+ objList.size());

		return objList;

	}

	/**
	 * Gets the from lookup values.
	 *
	 * @param sql the sql
	 * @return the from lookup values
	 * @throws Exception the exception
	 */
	public List getFromLookupValues(String sql) throws Exception {
		LookupDTO obj = null;
	    ArrayList<LookupDTO> objList = new ArrayList<LookupDTO>();
	    long temp = 0L;
	  	
	    try {
	    	 log.debug("Inside the lookup : "+ sql);   
	    	 SqlRowSet rs = jdbcTemplate.queryForRowSet(sql);
			   
			 while(rs.next()) {
				 obj = new LookupDTO (temp,rs.getString(1),rs.getString(2));
			  	 objList.add( obj );  // obj.setName(rs.getString(1)); obj.setStatus(rs.getString(2));
             }
	   	}
	  	 catch (Exception e) {
				throw new DatabaseException("Could not load ", e);
			}
		return objList;
	} 
	
 
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	 
}
