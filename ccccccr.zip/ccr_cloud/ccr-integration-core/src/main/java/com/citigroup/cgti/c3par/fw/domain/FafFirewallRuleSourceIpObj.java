/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

/**
 * @author bs45969
 *
 */
public class FafFirewallRuleSourceIpObj extends FafFirewallRuleIpObj {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public FafFirewallRuleSourceIpObj() {
	setCreated_date(new Date());
    }

}
