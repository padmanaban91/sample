package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.communication.domain.AgentViewProcess;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CmpConnectionDetail;
import com.citigroup.cgti.c3par.persistance.Persistable;


public interface AgentViewPersistable extends Persistable{

	
	public List<CMPRequest> getCmpReqData(AgentViewProcess agentViewProcess);
 
	public List<CmpConnectionDetail> getProcessList(String ccrId);
	
	public int updateCCRId(String cmpOrderId, Long tireqId);
	
	public int updateCmpId(String cmpOrderId ,Long tireqId);
	
	}
