package com.citigroup.cgti.c3par.fw.domain;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.Person;
import com.citigroup.cgti.c3par.domain.accessform.FafAccessForm;

@XmlRootElement
public class FirewallRulesExport {

	private static final long serialVersionUID = 1L;

	private Long conID;
	
	private Long version;
	
	private String conName;
	
	private RelationshipDTO relDTO;
	
	/** The requestor. */
    private Person requestor = new Person();

    /** The curr cycle requestor. */
    private Person currCycleRequestor = new Person();

	private ArrayList<Application> applicationDetails;
	
	private String originalBusJus;
	
	/** The business contacts. */
    private ArrayList<Person> businessContacts = new ArrayList();

    /** The application list. */
    private ArrayList applicationList = new ArrayList();

	private String currentBusJus;
	
	private String systemID;
	
	private String SOW;
	
	private String specialInstructions;
	
	private String completionDate;
	
	private String changeNumber;
	
	private Long infomanID;
	
	private String implStatus;
	
	private String cabApprovers;

	private String riskInformation;
	
	private List<FafAccessForm> fwImplDetails;
	
	private List<String> docDetails;
	
	@XmlElement
	public Long getConID() {
		return conID;
	}

	public void setConID(Long conID) {
		this.conID = conID;
	}
	@XmlElement
	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}
	@XmlElement
	public String getConName() {
		return conName;
	}

	public void setConName(String conName) {
		this.conName = conName;
	}

	@XmlElement
	public ArrayList<Application> getApplicationDetails() {
		return applicationDetails;
	}

	public void setApplicationDetails(ArrayList<Application> applicationDetails) {
		this.applicationDetails = applicationDetails;
	}

	
	@XmlElement
	public String getOriginalBusJus() {
		return originalBusJus;
	}

	public void setOriginalBusJus(String originalBusJus) {
		this.originalBusJus = originalBusJus;
	}

	@XmlElement
	public String getCurrentBusJus() {
		return currentBusJus;
	}

	
	public void setCurrentBusJus(String currentBusJus) {
		this.currentBusJus = currentBusJus;
	}
	@XmlElement
	public String getSystemID() {
		return systemID;
	}

	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}
	@XmlElement
	public String getSOW() {
		return SOW;
	}

	public void setSOW(String sOW) {
		SOW = sOW;
	}

	@XmlElement
	public String getSpecialInstructions() {
		return specialInstructions;
	}

	public void setSpecialInstructions(String specialInstructions) {
		this.specialInstructions = specialInstructions;
	}
	@XmlElement
	public String getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(String completionDate) {
		this.completionDate = completionDate;
	}
	@XmlElement
	public String getChangeNumber() {
		return changeNumber;
	}

	public void setChangeNumber(String changeNumber) {
		this.changeNumber = changeNumber;
	}
	@XmlElement
	public Long getInfomanID() {
		return infomanID;
	}

	public void setInfomanID(Long infomanID) {
		this.infomanID = infomanID;
	}
	@XmlElement
	public String getCabApprovers() {
		return cabApprovers;
	}

	public void setCabApprovers(String cabApprovers) {
		this.cabApprovers = cabApprovers;
	}
	@XmlElement
	public String getImplStatus() {
		return implStatus;
	}

	public void setImplStatus(String implStatus) {
		this.implStatus = implStatus;
	}
	@XmlElement
	public String getRiskInformation() {
		return riskInformation;
	}

	public void setRiskInformation(String riskInformation) {
		this.riskInformation = riskInformation;
	}


	@XmlElement	
	public List<FafAccessForm> getFwImplDetails() {
		return fwImplDetails;
	}

	public void setFwImplDetails(List<FafAccessForm> fwImplDetails) {
		this.fwImplDetails = fwImplDetails;
	}

	@XmlElement
	public Person getRequestor() {
		return requestor;
	}

	public void setRequestor(Person requestor) {
		this.requestor = requestor;
	}
	@XmlElement
	public Person getCurrCycleRequestor() {
		return currCycleRequestor;
	}

	public void setCurrCycleRequestor(Person currCycleRequestor) {
		this.currCycleRequestor = currCycleRequestor;
	}
	
	@XmlElement
	public ArrayList<Person> getBusinessContacts() {
		return businessContacts;
	}

	public void setBusinessContacts(ArrayList<Person> businessContacts) {
		this.businessContacts = businessContacts;
	}
	@XmlElement
	public ArrayList getApplicationList() {
		return applicationList;
	}

	public void setApplicationList(ArrayList applicationList) {
		this.applicationList = applicationList;
	}
	

	@XmlElement
	public RelationshipDTO getRelDTO() {
		return relDTO;
	}

	public void setRelDTO(RelationshipDTO relDTO) {
		this.relDTO = relDTO;
	}

	public void setDocDetails(List<String> docDetails) {
		this.docDetails = docDetails;
	}

	@XmlElement
	public List<String> getDocDetails() {
		return docDetails;
	}

	@Override
	public String toString() {
		return "FirewallRulesExport [conID=" + conID + ", version=" + version
				+ ", conName=" + conName + ", relDTO=" + relDTO
				+ ", requestor=" + requestor + ", currCycleRequestor="
				+ currCycleRequestor + ", applicationDetails="
				+ applicationDetails + ", originalBusJus=" + originalBusJus
				+ ", businessContacts=" + businessContacts
				+ ", applicationList=" + applicationList + ", currentBusJus="
				+ currentBusJus + ", systemID=" + systemID + ", SOW=" + SOW
				+ ", specialInstructions=" + specialInstructions
				+ ", completionDate=" + completionDate + ", changeNumber="
				+ changeNumber + ", infomanID=" + infomanID + ", implStatus="
				+ implStatus + ", cabApprovers=" + cabApprovers
				+ ", riskInformation=" + riskInformation + ", fwImplDetails="
				+ fwImplDetails + ", docDetails=" + docDetails + "]";
	}

	
}
