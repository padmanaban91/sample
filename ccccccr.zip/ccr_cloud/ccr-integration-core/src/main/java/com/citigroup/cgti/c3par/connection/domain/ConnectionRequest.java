package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class ConnectionRequest.
 */
public class ConnectionRequest extends Base implements Serializable {

    /** The end point a res type. */
    private String endPointAResType;

    /** The end point b res type. */
    private String endPointBResType;

    /** The firewall type. */
    private String firewallType;

    /** The firewall region. */
    private String firewallRegion;

    /** The firewall location. */
    private String firewallLocation;

    /** The activation date. */
    private String activationDate;

    /** The is acl variance. */
    private String isACLVariance;

    /**
     * Gets the activation date.
     *
     * @return the activation date
     */
    public String getActivationDate() {
	return activationDate;
    }

    /**
     * Sets the activation date.
     *
     * @param activationDate the new activation date
     */
    public void setActivationDate(String activationDate) {
	this.activationDate = activationDate;
    }

    /**
     * Gets the end point a res type.
     *
     * @return the end point a res type
     */
    public String getEndPointAResType() {
	return endPointAResType;
    }

    /**
     * Sets the end point a res type.
     *
     * @param endPointAResType the new end point a res type
     */
    public void setEndPointAResType(String endPointAResType) {
	this.endPointAResType = endPointAResType;
    }

    /**
     * Gets the end point b res type.
     *
     * @return the end point b res type
     */
    public String getEndPointBResType() {
	return endPointBResType;
    }

    /**
     * Sets the end point b res type.
     *
     * @param endPointBResType the new end point b res type
     */
    public void setEndPointBResType(String endPointBResType) {
	this.endPointBResType = endPointBResType;
    }

    /**
     * Gets the firewall region.
     *
     * @return the firewall region
     */
    public String getFirewallRegion() {
	return firewallRegion;
    }

    /**
     * Sets the firewall region.
     *
     * @param firewallRegion the new firewall region
     */
    public void setFirewallRegion(String firewallRegion) {
	this.firewallRegion = firewallRegion;
    }

    /**
     * Gets the firewall type.
     *
     * @return the firewall type
     */
    public String getFirewallType() {
	return firewallType;
    }

    /**
     * Sets the firewall type.
     *
     * @param firewallType the new firewall type
     */
    public void setFirewallType(String firewallType) {
	this.firewallType = firewallType;
    }

    /**
     * Gets the checks if is acl variance.
     *
     * @return the checks if is acl variance
     */
    public String getIsACLVariance() {
	return isACLVariance;
    }

    /**
     * Sets the checks if is acl variance.
     *
     * @param isACLVariance the new checks if is acl variance
     */
    public void setIsACLVariance(String isACLVariance) {
	this.isACLVariance = isACLVariance;
    }

    /**
     * Gets the firewall location.
     *
     * @return the firewall location
     */
    public String getFirewallLocation() {
	return firewallLocation;
    }

    /**
     * Sets the firewall location.
     *
     * @param firewallLocation the new firewall location
     */
    public void setFirewallLocation(String firewallLocation) {
	this.firewallLocation = firewallLocation;
    }


}
