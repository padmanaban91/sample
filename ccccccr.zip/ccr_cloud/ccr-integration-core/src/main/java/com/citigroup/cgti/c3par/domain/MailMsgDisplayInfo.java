package com.citigroup.cgti.c3par.domain;

import javax.xml.bind.annotation.XmlElement;


/**
 * The Class MailMsgDisplayInfo.
 */
public class MailMsgDisplayInfo {

    /** The label. */
    private String label;

    /** The value. */
    private String value;

    /**
     * Gets the label.
     *
     * @return the label
     */
    @XmlElement
    public String getLabel() {
	return label;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
	this.label = label;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    @XmlElement
    public String getValue() {
	return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
	this.value = value;
    }

}
