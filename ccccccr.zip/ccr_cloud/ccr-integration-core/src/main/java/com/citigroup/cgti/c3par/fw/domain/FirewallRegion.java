package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class FirewallLocation.
 */
public class FirewallRegion extends Base {

/**
 * 
 */
private String region;

/**
 * 
 */
private String operationAnalystEmail;

/**
 * 
 */
private String reviewFlag;

/**
 * @return the region
 */
public String getRegion() {
	return region;
}

/**
 * @param region the region to set
 */
public void setRegion(String region) {
	this.region = region;
}

/**
 * @return the operationAnalystEmail
 */
public String getOperationAnalystEmail() {
	return operationAnalystEmail;
}

/**
 * @param operationAnalystEmail the operationAnalystEmail to set
 */
public void setOperationAnalystEmail(String operationAnalystEmail) {
	this.operationAnalystEmail = operationAnalystEmail;
}

/**
 * @return the reviewFlag
 */
public String getReviewFlag() {
	return reviewFlag;
}

/**
 * @param reviewFlag the reviewFlag to set
 */
public void setReviewFlag(String reviewFlag) {
	this.reviewFlag = reviewFlag;
}


}
