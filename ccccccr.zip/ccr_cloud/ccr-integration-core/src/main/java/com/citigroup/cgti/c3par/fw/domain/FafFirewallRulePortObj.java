/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * @author bs45969
 *
 */
public class FafFirewallRulePortObj extends Base {
    /**
     * 
     */
	public static final String YES="Y";
	public static final String NO="N";
    private static final long serialVersionUID = 1L;
    private FafFirewallRuleSuggestion implFafFirewallRule;
    private PortObject port;
    private String description;
    private String serviceName;
    private String defaultService;
    private String typeOfTraffic;
    private String currentValueFlag=NO;

    public FafFirewallRulePortObj() {
	setCreated_date(new Date());
    }

    /**
     * @return the fafFireWallRule
     */
    public FafFirewallRuleSuggestion getImplFafFirewallRule() {
	return implFafFirewallRule;
    }

    /**
     * @param fafFireWallRule the fafFireWallRule to set
     */
    public void setImplFafFirewallRule(FafFirewallRuleSuggestion implFafFirewallRule) {
	this.implFafFirewallRule = implFafFirewallRule;
    }

    /**
     * @return the port
     */
    public PortObject getPort() {
	return port;
    }

    /**
     * @param port the port to set
     */
    public void setPort(PortObject port) {
	this.port = port;
    }
    
    @Override
    public String toString(){
    	return port.toString();    	
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getDefaultService() {
		return defaultService;
	}

	public void setDefaultService(String defaultService) {
		this.defaultService = defaultService;
	}

	public String getTypeOfTraffic() {
		return typeOfTraffic;
	}

	public void setTypeOfTraffic(String typeOfTraffic) {
		this.typeOfTraffic = typeOfTraffic;
	}

	/**
	 * @return the currentValueFlag
	 */
	public String getCurrentValueFlag() {
		return currentValueFlag;
	}

	/**
	 * @param currentValueFlag the currentValueFlag to set
	 */
	public void setCurrentValueFlag(String currentValueFlag) {
		this.currentValueFlag = currentValueFlag;
	}
    
}
