package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * 
 * @author ne36745
 *
 */
public class OstiaQuestionnaire extends Base {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String code;
	
	private String type;
	
	private String description;
	
	private String baselineName;
	
	private String baselineReportUrl;
	
	private List<RiskDefinition> riskDefinitions;
	
	private Date notificationSentDate;
	
	private String notificationSent;

	public OstiaQuestionnaire() {
		setCreated_date(new Date());
	}
	
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the riskDefinitions
	 */
	public List<RiskDefinition> getRiskDefinitions() {
		return riskDefinitions;
	}

	/**
	 * @param riskDefinitions the riskDefinitions to set
	 */
	public void setRiskDefinitions(List<RiskDefinition> riskDefinitions) {
		this.riskDefinitions = riskDefinitions;
	}

	/**
	 * @return the baselineName
	 */
	public String getBaselineName() {
		return baselineName;
	}

	/**
	 * @param baselineName the baselineName to set
	 */
	public void setBaselineName(String baselineName) {
		this.baselineName = baselineName;
	}

	/**
	 * @return the baselineReportUrl
	 */
	public String getBaselineReportUrl() {
		return baselineReportUrl;
	}

	/**
	 * @param baselineReportUrl the baselineReportUrl to set
	 */
	public void setBaselineReportUrl(String baselineReportUrl) {
		this.baselineReportUrl = baselineReportUrl;
	}

	/**
	 * @return the notificationSentDate
	 */
	public Date getNotificationSentDate() {
		return notificationSentDate;
	}

	/**
	 * @param notificationSentDate the notificationSentDate to set
	 */
	public void setNotificationSentDate(Date notificationSentDate) {
		this.notificationSentDate = notificationSentDate;
	}

	/**
	 * @return the notificationSent
	 */
	public String getNotificationSent() {
		return notificationSent;
	}

	/**
	 * @param notificationSent the notificationSent to set
	 */
	public void setNotificationSent(String notificationSent) {
		this.notificationSent = notificationSent;
	}
	
}
