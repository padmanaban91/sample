/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author bs45969
 *
 */
public class FafFirewallRulePort extends Base implements Comparable<FafFirewallRulePort>{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private FafFirewallRule fafFireWallRule;
    private Port port;
    private String description;
    private String serviceName;
    private String defaultService;
    private String typeOfTraffic;
    private TIRequest tiRequest;
    private TIRequest updatedTIRequest;
    private Long objRuleID;
    private String controlMessage;
    /**
	 * @return the objRuleID
	 */
	public Long getObjRuleID() {
		return objRuleID;
	}

	/**
	 * @param objRuleID the objRuleID to set
	 */
	public void setObjRuleID(Long objRuleID) {
		this.objRuleID = objRuleID;
	}

	public FafFirewallRulePort() {
	setCreated_date(new Date());
    }

    /**
     * @return the fafFireWallRule
     */
    public FafFirewallRule getFafFireWallRule() {
	return fafFireWallRule;
    }

    /**
     * @param fafFireWallRule the fafFireWallRule to set
     */
    public void setFafFireWallRule(FafFirewallRule fafFireWallRule) {
	this.fafFireWallRule = fafFireWallRule;
    }

    /**
     * @return the port
     */
    public Port getPort() {
	return port;
    }

    /**
     * @param port the port to set
     */
    public void setPort(Port port) {
	this.port = port;
    }
    
    @Override
    public String toString(){
    	if(objRuleID!=null && objRuleID.longValue()>0){
    		return port.getAFAObjectName();
    	}else{
    		return port.toString();
    	}  	
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getDefaultService() {
		return defaultService;
	}

	public void setDefaultService(String defaultService) {
		this.defaultService = defaultService;
	}

	public String getTypeOfTraffic() {
		return typeOfTraffic;
	}

	public void setTypeOfTraffic(String typeOfTraffic) {
		this.typeOfTraffic = typeOfTraffic;
	}

	/**
	 * @return the tiRequest
	 */
	public TIRequest getTiRequest() {
		return tiRequest;
	}

	/**
	 * @param tiRequest the tiRequest to set
	 */
	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	/**
	 * @return the updatedTIRequest
	 */
	public TIRequest getUpdatedTIRequest() {
		return updatedTIRequest;
	}

	/**
	 * @param updatedTIRequest the updatedTIRequest to set
	 */
	public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
		this.updatedTIRequest = updatedTIRequest;
	}

	public String getControlMessage() {
		return controlMessage;
	}

	public void setControlMessage(String controlMessage) {
		this.controlMessage = controlMessage;
	}
	@Override
	public int compareTo(FafFirewallRulePort obj) {
		int result=0;
		Port currentAddress=this.port;
		Port againstAddress=obj.getPort();
        result = currentAddress.getProtocol().compareTo(againstAddress.getProtocol() );
        if ( result == 0 && (currentAddress.getPortNumber()!=null && againstAddress.getPortNumber() !=null)) {
            result = currentAddress.getPortNumber().compareTo(againstAddress.getPortNumber() );
        }
        return result;
  
	}
	
	
    
}
