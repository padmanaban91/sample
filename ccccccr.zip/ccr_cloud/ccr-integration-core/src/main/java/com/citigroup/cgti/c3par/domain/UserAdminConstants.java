package com.citigroup.cgti.c3par.domain;


/**
 * The Class UserAdminConstants.
 */
public class UserAdminConstants {
    /*	NAME					DISPLAY_NAME 				FROM SECURITY_ROLE
     * 	Support Agent          	Support Agent
		Entitlement Requester  	Entitlement Requester
		Security Engineer      	Security Engineer
		ISTG_Chair             	ACL Variance Approver
		Developer              	Developer
		Operational_Analyst    	Operation Analyst
		WWDS                   	WWDS
		Remote_Access_Engineer 	Remote Access Engineer
		Manager                	Business Manager
		Internal_Audit         	Internal Audit
		Regulatory             	Regulatory
		Privacy                	Privacy
		Legal                  	Legal
		TPASWG                 	TPASWG
		Design_Engineer        	Technical Coordinator
		BISO                   	ISO
		Project_Coordinator    	Project Coordinator
		C3PARSYSTEMADMIN       	System Administrator
		ISS                    	ISS
		C3PARUSER              	C3par User
		C3PARSECURITYADMIN     	ISA

     */
    /** The Constant ROLE_DE. */
    public static final String ROLE_DE = "Design_Engineer";

    /** The Constant ROLE_PC. */
    public static final String ROLE_PC = "Project_Coordinator";

    /** The Constant ROLE_BISO. */
    public static final String ROLE_BISO = "BISO";

    /** The Constant ROLE_ISA. */
    public static final String ROLE_ISA = "C3PARSECURITYADMIN";

    /** The Constant ROLE_ISTG. */
    public static final String ROLE_ISTG = "ISTG_Chair";

    /** The Constant ROLE_OA. */
    public static final String ROLE_OA = "Operational_Analyst";

    /** The Constant ROLE_SA. */
    public static final String ROLE_SA = "C3PARSYSTEMADMIN";

    /** The Constant ROLE_TPASWG. */
    public static final String ROLE_TPASWG = "TPASWG";

    /** The Constant ROLE_SE. */
    public static final String ROLE_SE = "Security Engineer";

    /** The Constant ROLE_SUPPORT. */
    public static final String ROLE_SUPPORT = "Support Agent";

    /** The Constant ROLE_C3PARUSER. */
    public static final String ROLE_C3PARUSER = "C3PARUSER";

    /** The Constant ROLE_ENTREQUESTER. */
    public static final String ROLE_ENTREQUESTER = "Entitlement Requester";

    /** The Constant ROLE_Manager. */
    public static final String ROLE_Manager = "Manager";
}
