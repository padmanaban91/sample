package com.citigroup.cgti.c3par.bpm.ejb.domain;

import java.io.Serializable;
import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

// TODO: Auto-generated Javadoc
/**
 * The Class FireFlowDTO.
 */
public class FireFlowDTO implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -2106830829533456983L;

    /** The id. */
    private Long id;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    public Long getId() {
	return id;
    }

    public void setId(Long id) {
	this.id = id;
    }

    public Date getCreated_date() {
	return created_date;
    }

    public void setCreated_date(Date createdDate) {
	created_date = createdDate;
    }

    public Date getUpdated_date() {
	return updated_date;
    }

    public void setUpdated_date(Date updatedDate) {
	updated_date = updatedDate;
    }

    /** The fire flow id. */
    private String fireFlowId;

    /** The status. */
    private String status;

    /** The afa category id. */
    private long afaCategoryId;

    /** The requester. */
    private String requester;

    /** The ti_req_version_number. */
    private long ti_req_version_number;

    /**
     * Gets the ti_req_version_number.
     *
     * @return the ti_req_version_number
     */
    public long getTi_req_version_number() {
	return ti_req_version_number;
    }

    private String categoryName;

    private String ticketNumber;

    public String getTicketNumber() {
	return ticketNumber;
    }

    public void setTicketNumber(String ticketNumber) {
	this.ticketNumber = ticketNumber;
    }

    public String getCategoryName() {
	return categoryName;
    }

    public void setCategoryName(String categoryName) {
	this.categoryName = categoryName;
    }

    /**
     * Sets the ti_req_version_number.
     *
     * @param tiReqVersionNumber the new ti_req_version_number
     */
    public void setTi_req_version_number(long tiReqVersionNumber) {
	ti_req_version_number = tiReqVersionNumber;
    }

    /**
     * Gets the fire flow id.
     *
     * @return the fire flow id
     */
    public String getFireFlowId() {
	return fireFlowId;
    }

    /**
     * Sets the fire flow id.
     *
     * @param fireFlowId the new fire flow id
     */
    public void setFireFlowId(String fireFlowId) {
	this.fireFlowId = fireFlowId;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
	this.status = status;
    }

    /**
     * Gets the afa category id.
     *
     * @return the afa category id
     */
    public long getAfaCategoryId() {
	return afaCategoryId;
    }

    /**
     * Sets the afa category id.
     *
     * @param afaCategoryId the new afa category id
     */
    public void setAfaCategoryId(long afaCategoryId) {
	this.afaCategoryId = afaCategoryId;
    }

    /**
     * Gets the requester.
     *
     * @return the requester
     */
    public String getRequester() {
	return requester;
    }

    /**
     * Sets the requester.
     *
     * @param requester the new requester
     */
    public void setRequester(String requester) {
	this.requester = requester;
    }

    /**
     * Gets the ti request.
     *
     * @return the ti request
     */
    public TIRequest getTiRequest() {
	return tiRequest;
    }

    /**
     * Sets the ti request.
     *
     * @param tiRequest the new ti request
     */
    public void setTiRequest(TIRequest tiRequest) {
	this.tiRequest = tiRequest;
    }

    /** The ti request. */
    private TIRequest tiRequest = new TIRequest();

}
