

/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright ? 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.dao.lookup;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;


/**
 * The Class GenericLookupDefsLookup.
 */
public class GenericLookupDefsLookup
{

    /** The initialized. */
    private boolean		initialized = false;

    /** The ordered list. */
    private ArrayList 	orderedList = new ArrayList();

    /** The values by id. */
    private HashMap		valuesById = new HashMap();

    /** The values by name. */
    private HashMap		valuesByName = new HashMap();

    /** The values by label1. */
    private HashMap		valuesByLabel1 = new HashMap();

    /** The values by label2. */
    private HashMap		valuesByLabel2 = new HashMap();

    /** The instance. */
    static private GenericLookupDefsLookup instance = null;

    //======================================================================
    /**
     * Gets the single instance of GenericLookupDefsLookup.
     *
     * @return single instance of GenericLookupDefsLookup
     */
    synchronized static public GenericLookupDefsLookup getInstance()
    {
	if (instance == null)
	{
	    instance = new GenericLookupDefsLookup();
	}
	return instance;
    }

    //======================================================================
    /**
     * Gets the single instance of GenericLookupDefsLookup.
     *
     * @param session the session
     * @return single instance of GenericLookupDefsLookup
     * @throws DatabaseException the database exception
     */
    synchronized static public GenericLookupDefsLookup getInstance(DatabaseSession session) throws DatabaseException
    {
	if (instance == null)
	{
	    instance = new GenericLookupDefsLookup();
	    instance.initialize(session);	
	}
	else if(!instance.isInitialized())
	{
	    instance.initialize(session);	
	}
	return instance;
    }

    //======================================================================
    /**
     * Instantiates a new generic lookup defs lookup.
     */
    private GenericLookupDefsLookup()
    {
	super();
	initialized = false;
    }

    //======================================================================
    /**
     * Initialize.
     *
     * @param session the session
     * @throws DatabaseException the database exception
     */
    synchronized public void initialize(DatabaseSession session) throws DatabaseException
    {
	if (!initialized)
	{
	    GenericLookupDefsDAO dao = new GenericLookupDefsDAO(session);
	    GenericLookupDefsEntity entity = null;
	    Condition condition = new Condition();
	    condition.addOrderByField(GenericLookupDefsDAO.COLUMN_NAME);
	    try
	    {
		List list = dao.query(condition, false);
		Iterator it = list.iterator();

		while (it.hasNext())
		{
		    entity = (GenericLookupDefsEntity) it.next();
		    valuesById.put(entity.getId(), entity);
		    valuesByName.put(entity.getName(), entity);
		    valuesByLabel1.put(entity.getLabel1(), entity);
		    valuesByLabel2.put(entity.getLabel2(), entity);
		    orderedList.add(entity);
		}
		initialized = true;

		it = list.iterator();
		while (it.hasNext())
		{
		    entity = (GenericLookupDefsEntity) it.next();
		    dao.loadReferences((GenericLookupDefsEntity)entity);
		}
	    }
	    catch (DatabaseException e)
	    {
		throw e;
	    }
	}
    }

    //======================================================================
    /**
     * Reset.
     */
    synchronized public void reset()
    {
	valuesById = new HashMap();
	orderedList = new ArrayList();
	initialized = false;
	valuesByName = new HashMap();
	valuesByLabel1 = new HashMap();
	valuesByLabel2 = new HashMap();
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param id the id
     * @return the by id
     */
    synchronized public GenericLookupDefsEntity getById(Long id)
    {
	return (GenericLookupDefsEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param session the session
     * @param id the id
     * @return the by id
     * @throws DatabaseException the database exception
     */
    synchronized public GenericLookupDefsEntity getById(DatabaseSession session, Long id) throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (GenericLookupDefsEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by name.
     *
     * @param v the v
     * @return the by name
     */
    synchronized public GenericLookupDefsEntity getByName(String v)
    {
	return (GenericLookupDefsEntity) valuesByName.get(v);
    }

    //======================================================================
    /**
     * Gets the by name.
     *
     * @param session the session
     * @param v the v
     * @return the by name
     * @throws DatabaseException the database exception
     */
    synchronized public GenericLookupDefsEntity getByName(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (GenericLookupDefsEntity) valuesByName.get(v);
    }
    //======================================================================
    /**
     * Gets the by label1.
     *
     * @param v the v
     * @return the by label1
     */
    synchronized public GenericLookupDefsEntity getByLabel1(String v)
    {
	return (GenericLookupDefsEntity) valuesByLabel1.get(v);
    }

    //======================================================================
    /**
     * Gets the by label1.
     *
     * @param session the session
     * @param v the v
     * @return the by label1
     * @throws DatabaseException the database exception
     */
    synchronized public GenericLookupDefsEntity getByLabel1(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (GenericLookupDefsEntity) valuesByLabel1.get(v);
    }
    //======================================================================
    /**
     * Gets the by label2.
     *
     * @param v the v
     * @return the by label2
     */
    synchronized public GenericLookupDefsEntity getByLabel2(String v)
    {
	return (GenericLookupDefsEntity) valuesByLabel2.get(v);
    }

    //======================================================================
    /**
     * Gets the by label2.
     *
     * @param session the session
     * @param v the v
     * @return the by label2
     * @throws DatabaseException the database exception
     */
    synchronized public GenericLookupDefsEntity getByLabel2(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (GenericLookupDefsEntity) valuesByLabel2.get(v);
    }

    //======================================================================
    /**
     * Gets the all.
     *
     * @return the all
     */
    synchronized public ArrayList getAll()
    {
	return orderedList;
    }

    //======================================================================
    /**
     * Checks if is initialized.
     *
     * @return true, if is initialized
     */
    synchronized public boolean isInitialized()
    {
	return initialized;
    }
}
