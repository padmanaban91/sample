


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = RelCitiHierXrefDAO
// Table name = RelCitiHierXrefDAO
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class RelationshipDAO.
 */
public class UserCitiHierXrefDAO
extends DatabaseAccessObject
implements Serializable
{

    public UserCitiHierXrefDAO(DatabaseSession session) {
		super(session);
		// TODO Auto-generated constructor stub
	}

	/** The Constant TABLE. */
    public static final String	TABLE = "USER_CITI_HIERARCHY_XREF";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(UserCitiHierXrefDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "UserCitiHierXref";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_USER_ID. */
    public static final String	COLUMN_USER_ID = "USER_ID";

    /** The Constant COLUMN_CITI_HIERARCHY_MASTER_ID. */
    public static final String	COLUMN_CITI_HIERARCHY_MASTER_ID = "CITI_HIERARCHY_MASTER_ID";
    
    /** The Constant COLUMN_PERMISSIONS. */
    public static final String	COLUMN_PERMISSIONS = "PERMISSIONS";
    
    /** The Constant COLUMN_INACTIVE. */
    public static final String	COLUMN_INACTIVE = "INACTIVE";

	@Override
	protected void buildEntity(ResultSet arg0, Entity arg1)
			throws DatabaseException {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected Entity createEntity(ResultSet arg0) throws DatabaseException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void loadReferences(Entity arg0) throws DatabaseException {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected int updateReferences(PreparedStatement arg0, Entity arg1, int arg2)
			throws DatabaseException, SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	protected String getQuerySelectString() {
		// TODO Auto-generated method stub
		return null;
	}

   
}
