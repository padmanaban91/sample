package com.citigroup.cgti.c3par.bpm.ejb.mailmodule;


/**
 * The Class MailModuleConstants.
 */
public interface MailModuleConstants {
	
	public static String TEMPLATE_FILE_LOC = "installedApps/cloudappCell/ccr-ear.ear/ccr.war";

	
	/** The TEMPLAT e_ fil e_ loc. *//*
	public static String TEMPLATE_FILE_LOC = System.getProperty("c3par.root");*/
	
	/** The TEMPLAT e_ xm l_ fil e_ name. */
	public static String TEMPLATE_XML_FILE_NAME = "MailTemplates.xml";
//	public static String TEMPLATE_XSL_FILE_NAME = "MailTemplate.xsl";
	
	/** The TEMPLAT e_ va r_ patter n_ regex. */
	public static String TEMPLATE_VAR_PATTERN_REGEX = "#@[a-zA-Z0-9.]*@#";
	
	/** The EMAI l_ addres s_ seperator. */
	public static String  EMAIL_ADDRESS_SEPERATOR = ";";
	
	/** The ELEMEN t_ sqlparam. */
	public static String ELEMENT_SQLPARAM = "SQLPARAM";
	
	/** The TEMPLAT e_ root. */
	public static String TEMPLATE_ROOT = "TEMPLATE";
	
	/** The ELEMEN t_ from. */
	public static String ELEMENT_FROM = "FROM";
	
	/** The ELEMEN t_ t o_ use r_ role. */
	public static String ELEMENT_TO_USER_ROLE = "TO_USER_ROLE";
	
	/** The ELEMEN t_ t o_ use r. */
	public static String ELEMENT_TO_USER = "TO_USER";

	/** The ELEMEN t_ t o_ owner. */
	public static String ELEMENT_TO_OWNER = "TO_OWNER";
	
	/** The ELEMEN t_ t o_ role. */
	public static String ELEMENT_TO_ROLE = "TO_ROLE";
	
	/** The ELEMEN t_ cc. */
	public static String ELEMENT_CC = "CC";
	
	/** The ELEMEN t_ c c_ use r_ role. */
	public static String ELEMENT_CC_USER_ROLE = "CC_USER_ROLE";
	
	/** The ELEMEN t_ c c_ owner. */
	public static String ELEMENT_CC_OWNER = "CC_OWNER";
	
	/** The ELEMEN t_ c c_ role. */
	public static String ELEMENT_CC_ROLE = "CC_ROLE";	
	
	/** The ELEMEN t_ bcc. */
	public static String ELEMENT_BCC = "BCC";
	
	/** The ELEMEN t_ subject. */
	public static String ELEMENT_SUBJECT = "SUBJECT";
	
	/** The ELEMEN t_ body. */
	public static String ELEMENT_BODY = "BODY_CONTENT";
	
	/** The ELEMEN t_footnote. */
	public static String FOOT_NOTE = "FOOT_NOTE";
	
	/** The ELEMEN t_ info. */
	public static String ELEMENT_INFO = "INFO";
	
	/** The ELEMEN t_ row. */
	public static String ELEMENT_ROW = "ROW";
	
	/** The ELEMEN t_ xslfilename. */
	public static String ELEMENT_XSLFILENAME = "XSLFILENAME";
	
	/** The ATT r_ templat e_ id. */
	public static String ATTR_TEMPLATE_ID = "id";
	
	//Activity Names for Work Item Notification
	/** The BUSINES s_ justification. */
	public static String BUSINESS_JUSTIFICATION = "bus_jus";
	
	/** The I p_ detail. */
	public static String IP_DETAIL = "ip_det";
	
	/** The TECHNICA l_ architecture. */
	public static String TECHNICAL_ARCHITECTURE = "tec_arc";
	
	/** The IS o_ approval. */
	public static String ISO_APPROVAL = "iso_app";
	
	/** The SE c_ en g_ approval. */
	public static String SEC_ENG_APPROVAL = "se_app";
	
	/** The TPW g_ approval. */
	public static String TPWG_APPROVAL = "tpw_app";
	
	/** The IST g_ approval. */
	public static String ISTG_APPROVAL = "ist_app";
	
	/** The MANAGE r_ approval. */
	public static String MANAGER_APPROVAL = "bu_mgr_app";
	
	/** The IS a_ approval. */
	public static String ISA_APPROVAL = "isa_app";
	
	/** The IS a_ rejection. */
	public static String ISA_REJECTION = "isa_reject";
	
	/** The SYSADMI n_ rejection. */
	public static String SYSADMIN_REJECTION = "sysadmin_reject";
	
	/** The REQUES t_ validation. */
	public static String REQUEST_VALIDATION = "act_con";
	
	/** The OPERATIONA l_ implementation. */
	public static String OPERATIONAL_IMPLEMENTATION = "ope_imp";
	
	/** The MANAGE r_ review. */
	public static String  MANAGER_REVIEW = "mgr_review";
	
	/** The MANAGE r_ rejection. */
	public static String  MANAGER_REJECTION = "mgr_reject";
	
	/** The MANAGE r_ en t_ notification. */
	public static String  MANAGER_ENT_NOTIFICATION = "mgr_ent_notification";
	
	/** The IS a_ en t_ notification. */
	public static String  ISA_ENT_NOTIFICATION = "isa_ent_notification";
	
	/** The SYSADMI n_ en t_ notification. */
	public static String  SYSADMIN_ENT_NOTIFICATION = "sysadmin_ent_notification";
	//new activities introduced in 4.1
	/** The FI x_ connectivity. */
	public static String  FIX_CONNECTIVITY="fix_con";
	
	/** The TPW g_ retr o_ app. */
	public static String  TPWG_RETRO_APP="tpw_ret_app";
	
	/** The MA d_ retr o_ app. */
	public static String  MAD_RETRO_APP="mad_ret_app";
	
	/** The OTR m_ retr o_ app. */
	public static String  OTRM_RETRO_APP="otrm_ret_app";
	
	/** The MA d_ approval. */
	public static String  MAD_APPROVAL="mad_app";
	
	/** The OTR m_ approval. */
	public static String  OTRM_APPROVAL="otrm_app";
	
	/** The VERIF y_ sow. */
	public static String  VERIFY_SOW="ver_sow";
	
	/** The ROLLBAC k_ f w_ implementation. */
	public static String  ROLLBACK_FW_IMPLEMENTATION="rol_fw_imp";
	
	/** The TPW g_ revie w_ use r_ notification. */
	public static String  TPWG_REVIEW_USER_NOTIFICATION="tpw_review_user_notification";
	
	/** The O a_ schedul e_ use r_ notification. */
	public static String  OA_SCHEDULE_USER_NOTIFICATION="oa_schedule_user_notification";
	
	/** The APS e_ schedul e_ use r_ notification. */
	public static String  APSE_SCHEDULE_USER_NOTIFICATION="apsimpl_schedule_user_notification";
	
	/** The PRX y_ schedul e_ use r_ notification. */
	public static String  PRXY_SCHEDULE_USER_NOTIFICATION="prximpl_schedule_user_notification";
	
	//ACL Related Changes--Start
	/** The GNC c_ schedul e_ use r_ notification. */
	public static String  GNCC_SCHEDULE_USER_NOTIFICATION="acl_schedule_user_notification";
	
	/** The PROVIDEINF o10_ gncc. */
	public static String  PROVIDEINFO10_GNCC = "pro_inf10";
	
	/** The GNC c_ approval. */
	public static String  GNCC_APPROVAL="gncc_imp";
	//ACL Related Changes--End	
	
	/** The OSTI a_ update. */
	public static String  OSTIA_UPDATE="ost_upd";
	
	/** The APPSENS e_ approval. */
	public static String  APPSENSE_APPROVAL="appsense_imp";
	public static final String ACTIVITY_UAT_APPSENSE_IMP = "uat_appsense_imp";
    public static final String ACTIVITY_UAT_APPSNSE_PRO_INF = "uat_appsense_provide_info";
    public static final String ACTIVITY_UAT_REQUEST_VALIDATION = "uat_request_validation";
	
	/** The PROX y_ approval. */
	public static String  PROXY_APPROVAL="proxy_imp";
	
	/** The PR o_ inf. */
	public static String  PRO_INF = "pro_inf";
	
	/** The PROVIDEINF o1_ de. */
	public static String  PROVIDEINFO1_DE = "pro_inf1";
	
	/** The PROVIDEINF o2_ iso. */
	public static String  PROVIDEINFO2_ISO = "pro_inf2";
	
	/** The PROVIDEINF o3_ tpw. */
	public static String  PROVIDEINFO3_TPW = "pro_inf3";
	
	/** The PROVIDEINF o4_ ist. */
	public static String  PROVIDEINFO4_IST = "pro_inf4";
	
	/** The PROVIDEINF o5_ ope. */
	public static String  PROVIDEINFO5_OPE = "pro_inf5";
	
	/** The PROVIDEINF o6_ se. */
	public static String  PROVIDEINFO6_SE = "pro_inf6";
	
	/** The PROVIDEINF o7_ bumgr. */
	public static String  PROVIDEINFO7_BUMGR = "pro_inf7";   
	
	/** The PROVIDEINF o8_ apse. */
	public static String  PROVIDEINFO8_APSE = "pro_inf8";
	
	/** The PROVIDEINF o9_ prxy. */
	public static String  PROVIDEINFO9_PRXY = "pro_inf9";
	
	/** The PROVIDEIN f_ otrm. */
	public static String  PROVIDEINF_OTRM = "otrm_pro_inf";
	
	/** The PROVIDEIN f_ mad. */
	public static String  PROVIDEINF_MAD = "mad_pro_inf";
	
	/** The PROVID e_ info. */
	public static String  PROVIDE_INFO = "PROVIDEINFO";	
	
	/** The APPROVA l_ expiration. */
	public static String  APPROVAL_EXPIRATION = "app_exp";
	
	/** The IMPLEMENTATIO n_ expiration. */
	public static String  IMPLEMENTATION_EXPIRATION = "impl_exp";
	
	/** The INCOMPLET e_ expiration. */
	public static String  INCOMPLETE_EXPIRATION = "inc_exp";
	
	/** The AC v_ expiration. */
	public static String  ACV_EXPIRATION = "acv_exp";
	
	/** The RECONCIL e_ expiration. */
	public static String  RECONCILE_EXPIRATION = "rec_exp";
	
	/** The TEMPAPPROVA l_ expiration. */
	public static String  TEMPAPPROVAL_EXPIRATION = "tmp_exp";
	
	/** The ACTIVATIO n_ expiration. */
	public static String  ACTIVATION_EXPIRATION = "act_exp";
	
	/** The SYSADMI n_ expire d_ email. */
	public static String  SYSADMIN_EXPIRED_EMAIL = "sysadmin_expired_email";
	
	/** The OTR m_ expire d_ email. */
	public static String  OTRM_EXPIRED_EMAIL = "otrm_expired_email";
	
	public static String  DL_IS_GLOBAL_CCR  = "dl.is.global.ccr@imcnam.ssmb.com";
	   
		
	/** The REDIRECTIO n_ email. */
	public static String REDIRECTION_EMAIL = "REDIRECTION_EMAIL";
	
	/** The SCHEDULE d_ email. */
	public static String SCHEDULED_EMAIL = "SCHEDULED_EMAIL";
	public static String SCHEDULED_EXPIRATION_EMAIL = "SCHEDULED_EXPIRATION_EMAIL";
	
	/** The ACTIVATIO n_ expiratio n_ reminder. */
	public static String ACTIVATION_EXPIRATION_REMINDER_7DAYS = "ACTIVATION_EXPIRATION_REMINDER_7DAYS";
	public static String ACTIVATION_EXPIRATION_REMINDER_30DAYS = "ACTIVATION_EXPIRATION_REMINDER_30DAYS";
//	public static String REMINDER_NOTIFICATION = "REMINDER_NOTIFICATION";
//	public static String PROVIDEINFO_NOTIFICATION = "PROVIDEINFO_NOTIFICATION";
//	public static String INFO_UPDATED_NOTIFICATION = "INFO_UPDATED_NOTIFICATION";
	//roles introduced in 4.1	
	/** The Constant ROLE_PC. */
public static final String ROLE_PC = "PROJECT COORDINATOR";
	
	/** The Constant ROLE_SA. */
	public static final String ROLE_SA = "C3PARSYSTEMADMIN";
	
	/** The Constant ROLE_TPWG. */
	public static final String ROLE_TPWG = "TPASWG";
	
	/** The Constant ROLE_OA. */
	public static final String ROLE_OA = "Operational_Analyst";
	
	/** The Constant ROLE_ISO. */
	public static final String ROLE_ISO = "BISO";
	
	/** The Constant ROLE_DE. */
	public static final String ROLE_DE = "DESIGN ENGINEER";
	
	/** The Constant ROLE_ISTG. */
	public static final String ROLE_ISTG = "ISTG_Chair";
	
	/** The Constant ROLE_SE. */
	public static final String ROLE_SE = "Security Engineer";
	
	/** The Constant ROLE_MGR. */
	public static final String ROLE_MGR = "Manager";
	
	/** The Constant ROLE_SAG. */
	public static final String ROLE_SAG = "Support Agent";
	
	/** The Constant ROLE_OTRM. */
	public static final String ROLE_OTRM = "OTRM";
	
	/** The Constant ROLE_MAD. */
	public static final String ROLE_MAD = "MAD";
	
	/** The Constant ROLE_BUS_OWNER. */
	public static final String ROLE_BUS_OWNER = "Business_Owner";
	
	//EMER- BUSCRIT Questions Starts
	
	/** The Constant EMER_DESC_BUS_PERSPECTIVE. */
	public static final String EMER_DESC_BUS_PERSPECTIVE = "desc_business_perspective";
	
	/** The Constant EMER_MGR_NAME. */
	public static final String EMER_MGR_NAME = "manager_name";
	
	/** The Constant EMER_GRP_RAISING_RFC. */
	public static final String EMER_GRP_RAISING_RFC = "group_raising_rfc";
	
	/** The Constant EMER_IMPL_BAU_TIMELINES. */
	public static final String EMER_IMPL_BAU_TIMELINES = "implemented_bau_timelines";
	
	/** The Constant EMER_STD_CHANGE_CYCLE. */
	public static final String EMER_STD_CHANGE_CYCLE = "standard_change_cycle";
	
	/** The Constant EMER_DPT_OWNER_PROCESS. */
	public static final String EMER_DPT_OWNER_PROCESS = "department_owner_process";
	
	/** The Constant EMER_CLASH_REQUEST. */
	public static final String EMER_CLASH_REQUEST = "clash_request";
	
	/** The Constant EMER_RISK_UNPLANNED_CHANGE. */
	public static final String EMER_RISK_UNPLANNED_CHANGE = "risk_unplanned_change";
	
	/** The Constant EMER_ADD_BUS_TESTING. */
	public static final String EMER_ADD_BUS_TESTING = "additional_business_testing";
	
	/** The Constant EMER_TESTING_PLAN_CONT_PERSON. */
	public static final String EMER_TESTING_PLAN_CONT_PERSON = "testing_plan_contact_person";
			
	//EMER- BUSCRIT Questions Starts
	
	/** The Constant EMER_MAIl_TEMPLATE_FILE_NAME. */
	public static final String EMER_MAIl_TEMPLATE_FILE_NAME = "EmerMailTemplate.xsl";
	
	//Handle RFC exception
	
	/** The Constant HANDLE_RFC_EXC. */
	public static final String HANDLE_RFC_EXC = "han_rfc_exc";
	
	//Director Approval Mail constats.	
	
	/** The Constant DIR_MAIL_INFO. */
	public static final String DIR_MAIL_INFO = "director_mail_info";
	
	public static final String NOTIFY_CONTACT_REPLACED = "NOTIFY_CONTACT_REPLACED";
	
	/** TEMPLATE_MAIL_B4_FW_IMPL */
	public static final String TEMPLATE_MAIL_B4_FW_IMPL = "template_act_con";
	
	/** TEMPLATE_MAIL_B4_MANITENENCE */
	public static final String 	TEMPLATE_MAIL_B4_MANITENENCE = "template_maintenance_con";
	
	/** TEMPLT_UING_CONN_MAIL_B4_TECH */
	public static final String 	TEMPLT_UING_CONN_MAIL_B4_TECH = "template_using_con_after_tech";
	public static final String 	TEMPLT_UING_CONN_MAIL_B4_TECH_TWO = "template_using_con_after_tech_two";
	
	/** Used in for to compare relationship type*/
	
	public static final String TEMPLATE = "template";
	
	public static final String IP_TEMPLATE = "ip_template";
	
	public static final String PORT_TEMPLATE = "port_template";
	
	public static final String SEND_EMAIL_TO_TARGET_CONTACT = "SEND_EMAIL_TO_TARGET_CONTACT";
	
	public static final String REQUEST_ENTITLEMENT_BY_SYSTEM = "REQUEST_ENTITLEMENT_BY_SYSTEM";
		
	public static final String NOTIFY_CONNECTION_CONTACT = "NOTIFY_CONNECTION_CONTACT";

	public static final String NOTIFY_CONTACT_REJECT = "NOTIFY_CONTACT_REJECT";
	
	public static final String NOTIFY_ACK = "NOTIFY_ACK";
	public static final String NOTIFY_NON_TP_ACV_SUMMARY = "NOTIFY_NON_TP_ACV_SUMMARY";
	public static final String NOTIFY_RISK_BASELINE_CHANGE = "NOTIFY_RISK_BASELINE_CHANGE";
	public static final String NOTIFY_CONNECTION_APPLICATION_OWNER = "NOTIFY_CONNECTION_APPLICATION_OWNER";
	public static final String NOTIFY_DONOTSENDLIST = "NOTIFY_DONOTSENDLIST";
	public static final String NOTIFICATION_UAT_APPSENSE_IMPLEMETER = "uat_appsense_imp";
	
	public static final String NOTIFICATION_CSI_APPLICATION_DECOMMISSIONED = "CSI_APPLICATION_DECOMMISSIONED";
	
	public static final String SEND_EMAIL_TO_ECM_AGENT_ON_REQUEST_ASSIGNED = "REQ_ASSIGNED_TO_ECM_AGENT";
	
	public static final String RISO_APPROVAL_MAIL="RISO_APPROVAL_MAIL";
	public static final String PROXY_CONNECTION_DL="dl.cti.global.cybersecops.proxy.service.delivery@imcnam.ssmb.com";
	
	public static final String TIPROCESS="TI Process";
	public static final String REGION="Region";
	public static final String MODE="Mode";
	public static final String SECTOR="Sector";
	public static final String TYPE="Type";
	public static final String BUS_UNIT="Business Unit";
	public static final String REL_ID="Relationship ID";
	public static final String REL_NAME="Relationship Name";
	public static final String ID="ID";
	public static final String DESCRIPTION="Description";
	public static final String ENDPOINT_A="Endpoint A Resource Type";
	public static final String ENDPOINT_B="Endpoint B Resource Type";
	public static final String FIREWALL_TYPE="Firewall Type";
	public static final String FIREWALL_REGION="Firewall Region";
	public static final String HIGH_RISK="High Risk";
	public static final String PRIORITY="Priority";
	public static final String REQUESTER="Requester";
	public static final String ACTIVIATION_DATE="Requested Activation Date";
	public static final String APPENSE_SCHE_DATE="Appsense Scheduled Date";
	public static final String PROXY_SCHE_DATE="Proxy Scheduled Date";
	public static final String FW_OPS_SCHE_DATE="FW OPS Scheduled Date";
	public static final String EXPIRATION_DATE="Expiration Date";
	public static final String GNO_SCHE_DATE="GNO Scheduled Date";
	public static final String SYSTEM_ID="System ID";
	public static final String ROLE="Role";
	public static final String ACTIVITY_DESCRIPTION="Activity Description";
	public static final String LAST_SUBMITTED_BY="Last Submitted by";
	public static final String COMMENT="Comment";
	public static final String SSO_ID="SSO Id";
	public static final String EMAIL="Email";
	public static final String FIRST_NAME="First Name";
	public static final String LAST_NAME="Last Name";
	public static final String DISPLAY_NAME="Display Name";
	public static final String REQUESTED_BY="Requested By";
	public static final String ENTITLEMENTS="Entitlements";
	public static final String MANAGERAPPROVAL="Manager Approver";
	public static final String MANAGER_REV_DATE="Manager Review Date";
	public static final String SYS_ADMIN_APPROVER="System Admin Approver";
	public static final String SYS_ADMIN_REV_DATE="System Admin Review Date";
	public static final String EMPTY_VAL="";
}