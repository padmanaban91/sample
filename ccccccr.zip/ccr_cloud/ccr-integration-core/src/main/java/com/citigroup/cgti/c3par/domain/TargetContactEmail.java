package com.citigroup.cgti.c3par.domain;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



/**
 * The Class BaseMailVO.
 */
@XmlRootElement
public class TargetContactEmail extends C3PARMailMessage {

	
    private String managerName;
    
    private String connRoles;
    
    private Long ccr_id;
    
    private String url;
    
    private String status;
    
    private String action;
    
    private String region;
    
    private String sector;
    
    private String priority;
    
    private String cmpId;
    
    private String justification;
    
    private String requestor;
    
    private String busUnit;
    
    private String desc;
    
    private String connName;
    
    private String projectCoor;
    
    private String distributionList;

    private String change_Text;
    
    private String emailAddress;
    
    private String rejectUserName;
    
    //private String appInfo;
    
    private AppInfo[] appInfo;
    
    private String subject;
    
    private String primaryAppOwner;

    private String secAppOwner;
    
    private String iso;
    
    private String additionalInformation;
    
    
    public String getRejectUserName() {
		return rejectUserName;
	}

	public void setRejectUserName(String rejectUserName) {
		this.rejectUserName = rejectUserName;
	}

	public static class AppInfo {
    	   
        	private String type;
    	  
    		@XmlElement
    		public String getType() {
    			return type;
    		}
    		public void setType(String type) {
    			this.type = type;
    		}
        	
        	
        }

   @XmlElement
	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public void setConnRoles(String connRoles) {
		this.connRoles = connRoles;
	}
	@XmlElement
	public String getConnRoles() {
		return connRoles;
	}

	public void setCcr_id(Long ccr_id) {
		this.ccr_id = ccr_id;
	}
	@XmlElement
	public Long getCcr_id() {
		return ccr_id;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	@XmlElement
	public String getUrl() {
		return url;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAction() {
		return action;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getCmpId() {
		return cmpId;
	}

	public void setCmpId(String cmpId) {
		this.cmpId = cmpId;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getBusUnit() {
		return busUnit;
	}

	public void setBusUnit(String busUnit) {
		this.busUnit = busUnit;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setJustification(String justification) {
		this.justification = justification;
	}

	public String getJustification() {
		return justification;
	}

	public String getConnName() {
		return connName;
	}

	public void setConnName(String connName) {
		this.connName = connName;
	}

	public String getProjectCoor() {
		return projectCoor;
	}

	public void setProjectCoor(String projectCoor) {
		this.projectCoor = projectCoor;
	}

	public String getDistributionList() {
		return distributionList;
	}

	public void setDistributionList(String distributionList) {
		this.distributionList = distributionList;
	}

	public String getChange_Text() {
		return change_Text;
	}

	public void setChange_Text(String changeText) {
		change_Text = changeText;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public void setAppInfo(AppInfo[] appInfo) {
		this.appInfo = appInfo;
	}

	public AppInfo[] getAppInfo() {
		return appInfo;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	@XmlElement
	public String getPrimaryAppOwner() {
		return primaryAppOwner;
	}

	public void setPrimaryAppOwner(String primaryAppOwner) {
		this.primaryAppOwner = primaryAppOwner;
	}

	@XmlElement
	public String getSecAppOwner() {
		return secAppOwner;
	}

	public void setSecAppOwner(String secAppOwner) {
		this.secAppOwner = secAppOwner;
	}

	@XmlElement
	public String getIso() {
		return iso;
	}

	public void setIso(String iso) {
		this.iso = iso;
	}
	
	@XmlElement
	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	/*public String getAppInfo() {
		return appInfo;
	}

	public void setAppInfo(String appInfo) {
		this.appInfo = appInfo;
	}*/

}
