package com.citigroup.cgti.c3par.admin.domain;

import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.fw.domain.PortServiceMapping;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;



/**
 * The Class PortServiceTypeForm.
 *
 * @author Gerald Robinson
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

@SuppressWarnings( { "unchecked", "unused" })
public class  PortServiceTypeProcess {
	
	
	
	private static Logger log = Logger
			.getLogger(PortServiceTypeProcess.class);

    /** The port id. */
    private Long portId ;
    private String portIdString;

	/** The service. */
    private String service;

    /** The description. */
    private String description;

    /** The search port id. */
    private Long searchPortId;
    private String searchPortIdString;

    /** The search service. */
    private String searchService;

    /** The search description. */
    private String searchDescription;

    /** The port list. */
    private Collection portList;

    /** The service list. */
    private Collection serviceList;

    /** The update port. */
    private Long updatePort;

    /** The update service. */
    private String updateService;

    /** The update description. */
    private String updateDescription;

    /** The update id. */
    private Long updateID;

    /** The record id. */
    private Long recordId;

    private List searchResults;

CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

    /**
     * Gets the record id.
     *
     * @return Returns the recordId.
     */
    public Long getRecordId() {
	return recordId;
    }

    /**
     * Sets the record id.
     *
     * @param recordId The recordId to set.
     */
    public void setRecordId(Long recordId) {
	this.recordId = recordId;
    }

    /**
     * Gets the port id.
     *
     * @return Returns the portId.
     */
    public Long getPortId() {
	return portId;
    }

    /**
     * Sets the port id.
     *
     * @param portId The portId to set.
     */
    public void setPortId(Long portId) {
	this.portId = portId;
    }

    /**
     * Gets the service.
     *
     * @return Returns the service.
     */
    public String getService() {
	return service;
    }

    /**
     * Sets the service.
     *
     * @param service The service to set.
     */
    public void setService(String service) {
	this.service = service;
    }

    /**
     * Gets the description.
     *
     * @return Returns the description.
     */
    public String getDescription() {
	return description;
    }

    /**
     * Sets the description.
     *
     * @param description The description to set.
     */
    public void setDescription(String description) {
	this.description = description;
    }


    /**
     * Gets the search port id.
     *
     * @return Returns the searchPortId.
     */
    public Long getSearchPortId() {
	return searchPortId;
    }

    /**
     * Sets the search port id.
     *
     * @param searchPortId The searchPortId to set.
     */
    public void setSearchPortId(Long searchPortId) {
	this.searchPortId = searchPortId;
    }

    /**
     * Gets the search service.
     *
     * @return Returns the searchService.
     */
    public String getSearchService() {
	return searchService;
    }

    /**
     * Sets the search service.
     *
     * @param searchService The searchService to set.
     */
    public void setSearchService(String searchService) {
	this.searchService = searchService;
    }


    /**
     * Gets the search description.
     *
     * @return Returns the searchDescription.
     */
    public String getSearchDescription() {
	return searchDescription;
    }

    /**
     * Sets the search description.
     *
     * @param searchDescription The searchDescription to set.
     */
    public void setSearchDescription(String searchDescription) {
	this.searchDescription = searchDescription;
    }


    /**
     * Gets the port list.
     *
     * @return Returns the portList.
     */
    public Collection getPortList() {
	return portList;
    }

    /**
     * Sets the port list.
     *
     * @param portList The portList to set.
     */
    public void setPortList(Collection portList) {
	this.portList = portList;
    }



    /**
     * Gets the service list.
     *
     * @return Returns the serviceList.
     */
    public Collection getServiceList() {
	return serviceList;
    }

    /**
     * Sets the service list.
     *
     * @param serviceList The serviceList to set.
     */
    public void setServiceList(Collection serviceList) {
	this.serviceList = serviceList;
    }



    /**
     * Gets the update port.
     *
     * @return Returns the updatePort.
     */
    public Long getUpdatePort() {
	return updatePort;
    }

    /**
     * Sets the update port.
     *
     * @param updatePort The updatePort to set.
     */
    public void setUpdatePort(Long updatePort) {
	this.updatePort = updatePort;
    }

    /**
     * Gets the update service.
     *
     * @return Returns the updateService.
     */
    public String getUpdateService() {
	return updateService;
    }

    /**
     * Sets the update service.
     *
     * @param updateService The updateService to set.
     */
    public void setUpdateService(String updateService) {
	this.updateService = updateService;
    }

    /**
     * Gets the update description.
     *
     * @return Returns the updateDescription.
     */
    public String getUpdateDescription() {
	return updateDescription;
    }

    /**
     * Sets the update description.
     *
     * @param updateDescription The updateDescription to set.
     */
    public void setUpdateDescription(String updateDescription) {
	this.updateDescription = updateDescription;
    }

    /**
     * Gets the update id.
     *
     * @return Returns the updateID.
     */
    public Long getUpdateID() {
	return updateID;
    }

    /**
     * Sets the update id.
     *
     * @param updateID The updateID to set.
     */
    public void setUpdateID(Long updateID) {
	this.updateID = updateID;
    }


    /**
     * Reset.
     */
    public void reset(){
	portId  = null;
	service = null;
	description = null;
	searchPortId = null ;
	searchService = null;
	searchDescription = null;
	portList = null;
	serviceList = null;
	updatePort = null;
	updateService = null;
	updateID = null;
	recordId = null;

    }

	public List getSearchResults() {
		return searchResults;
	}

	public void setSearchResults(List searchResults) {
		this.searchResults = searchResults;
	}

	public String getPortIdString() {
		return portIdString;
	}

	public void setPortIdString(String portIdString) {
		this.portIdString = portIdString;
	}

	public String getSearchPortIdString() {
		return searchPortIdString;
	}

	public void setSearchPortIdString(String searchPortIdString) {
		this.searchPortIdString = searchPortIdString;
	}

	
	public boolean existPortServiceMapping(Long portId) throws Exception{
		PortServiceMapping portServiceMapping = ccrBeanFactory.getPortServiceTypePersistable().existPortServiceMapping(portId);
		if(portServiceMapping!=null)
			{
			return true;
			}
		return false;
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void insertPortServiceMapping(PortServiceMapping portServiceMapping) throws Exception{
	try{
		ccrBeanFactory.getPortServiceTypePersistable().insertPortServiceMapping(portServiceMapping);
	}catch (Exception e){
		throw new Exception("Exception Occured, add failed.");
	}
		
	}

	
	public List<PortServiceMapping> findByPortId(Long portId) throws Exception{
		try{
		List<PortServiceMapping> portServiceMappinglist = ccrBeanFactory.getPortServiceTypePersistable().findByPortId(portId.toString());
		return portServiceMappinglist;
		}catch (Exception e){
			throw new Exception("Exception Occured, search failed.");
		}
		
	}

	
	public List<PortServiceMapping> findByServiceType(String type) throws Exception{
		try{
		List<PortServiceMapping> portServiceMappinglist = ccrBeanFactory.getPortServiceTypePersistable().findByServiceType(type);
		return portServiceMappinglist;
		}catch (Exception e){
		throw new Exception("Exception Occured, search failed.");
		}
	}

	
	public PortServiceMapping getPortServiceMapping(Long iD) throws Exception{
		PortServiceMapping portServiceMapping = ccrBeanFactory.getPortServiceTypePersistable().getPortServiceMapping(iD.toString());
		return portServiceMapping;
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updatePortServiceMapping(PortServiceMapping portServiceMapping) throws Exception{
		try{
			ccrBeanFactory.getPortServiceTypePersistable().updatePortServiceMapping(portServiceMapping);
		}catch (Exception e){
			throw new Exception("Exception Occured, update failed.");
		}
		
	}
	
	
	public List getConnections(Long actualPortId) throws Exception{
		List connections = ccrBeanFactory.getPortServiceTypePersistable().getConnections(actualPortId);
		if(connections!=null && connections.size()==0){
			return null;
		}
		return connections;
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deletePortServiceMapping(PortServiceMapping deletePortServiceMapping) throws Exception {
		try{
			ccrBeanFactory.getPortServiceTypePersistable().deletePortServiceMapping(deletePortServiceMapping);
		}catch (Exception e){
			throw new Exception("Exception Occured, delete failed.");
		}
	}

	public void validate(String message) throws Exception {
		throw new Exception(message);
	}
	
	
}
			    
