


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = TerminationDAO
// Table name = TERM
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class TerminationDAO.
 */
public class TerminationDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "TERM";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(TerminationDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "Termination";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_INFOMANID. */
    public static final String	COLUMN_INFOMANID = "INFOMAN_ID";

    /** The Constant COLUMN_REQUESTCOMMENT. */
    public static final String	COLUMN_REQUESTCOMMENT = "REQUEST_COMMENT";

    /** The Constant COLUMN_REQUESTCOMMENT_LEN. */
    public static final int		COLUMN_REQUESTCOMMENT_LEN = 4000;

    /** The Constant COLUMN_REQUESTERID. */
    public static final String	COLUMN_REQUESTERID = "REQUESTER_ID";

    /** The Constant COLUMN_REQUESTERID_LEN. */
    public static final int		COLUMN_REQUESTERID_LEN = 100;

    /** The Constant COLUMN_REVIEWCOMMENT. */
    public static final String	COLUMN_REVIEWCOMMENT = "REVIEW_COMMENT";

    /** The Constant COLUMN_REVIEWCOMMENT_LEN. */
    public static final int		COLUMN_REVIEWCOMMENT_LEN = 4000;

    /** The Constant COLUMN_TERMINATECOMMENT. */
    public static final String	COLUMN_TERMINATECOMMENT = "TERMINATE_COMMENT";

    /** The Constant COLUMN_TERMINATECOMMENT_LEN. */
    public static final int		COLUMN_TERMINATECOMMENT_LEN = 4000;

    /** The Constant COLUMN_STATUS. */
    public static final String	COLUMN_STATUS = "STATUS";

    /** The Constant COLUMN_STATUS_LEN. */
    public static final int		COLUMN_STATUS_LEN = 100;

    /** The Constant COLUMN_TERMINATIONDATE. */
    public static final String	COLUMN_TERMINATIONDATE = "TERMINATION_DATE";

    /** The Constant COLUMN_SYSTEMADMINCOMMENTS. */
    public static final String	COLUMN_SYSTEMADMINCOMMENTS = "SYSTEM_ADMIN_COMMENTS";

    /** The Constant COLUMN_SYSTEMADMINCOMMENTS_LEN. */
    public static final int		COLUMN_SYSTEMADMINCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_OPANALYSTSCHEDULEDATE. */
    public static final String	COLUMN_OPANALYSTSCHEDULEDATE = "OP_ANALYST_SCHEDULE_DATE";

    /** The Constant COLUMN_OPANALYSTCOMPLETEDDATE. */
    public static final String	COLUMN_OPANALYSTCOMPLETEDDATE = "OP_ANALYST_COMPLETED_DATE";

    /** The Constant COLUMN_OPERATIONALANALYSTCOMMENTS. */
    public static final String	COLUMN_OPERATIONALANALYSTCOMMENTS = "OPERATIONAL_ANALYST_COMMENTS";

    /** The Constant COLUMN_OPERATIONALANALYSTCOMMENTS_LEN. */
    public static final int		COLUMN_OPERATIONALANALYSTCOMMENTS_LEN = 4000;

    /** The Constant COLUMN_PROJECTCOORDINATORCOMMENTS. */
    public static final String	COLUMN_PROJECTCOORDINATORCOMMENTS = "PROJECT_COORDINATOR_COMMENTS";

    /** The Constant COLUMN_PROJECTCOORDINATORCOMMENTS_LEN. */
    public static final int		COLUMN_PROJECTCOORDINATORCOMMENTS_LEN = 4000;
    // Column names of references
    /** The Constant COLUMN_CONNECTION_ID. */
    public static final String	COLUMN_CONNECTION_ID = "CONNECTION_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + TerminationDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_INFOMANID
    + ", " + COLUMN_REQUESTCOMMENT
    + ", " + COLUMN_REQUESTERID
    + ", " + COLUMN_REVIEWCOMMENT
    + ", " + COLUMN_TERMINATECOMMENT
    + ", " + COLUMN_STATUS
    + ", " + COLUMN_TERMINATIONDATE
    + ", " + COLUMN_SYSTEMADMINCOMMENTS
    + ", " + COLUMN_OPANALYSTSCHEDULEDATE
    + ", " + COLUMN_OPANALYSTCOMPLETEDDATE
    + ", " + COLUMN_OPERATIONALANALYSTCOMMENTS
    + ", " + COLUMN_PROJECTCOORDINATORCOMMENTS
    + ", " + COLUMN_CONNECTION_ID
    + " FROM " + TerminationDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = TerminationDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + TerminationDAO.TABLE + " SET "
    + COLUMN_INFOMANID + " = ? "
    + ", " + COLUMN_REQUESTCOMMENT + " = ? "
    + ", " + COLUMN_REQUESTERID + " = ? "
    + ", " + COLUMN_REVIEWCOMMENT + " = ? "
    + ", " + COLUMN_TERMINATECOMMENT + " = ? "
    + ", " + COLUMN_STATUS + " = ? "
    + ", " + COLUMN_TERMINATIONDATE + " = ? "
    + ", " + COLUMN_SYSTEMADMINCOMMENTS + " = ? "
    + ", " + COLUMN_OPANALYSTSCHEDULEDATE + " = ? "
    + ", " + COLUMN_OPANALYSTCOMPLETEDDATE + " = ? "
    + ", " + COLUMN_OPERATIONALANALYSTCOMMENTS + " = ? "
    + ", " + COLUMN_PROJECTCOORDINATORCOMMENTS + " = ? "
    + ", " + COLUMN_CONNECTION_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + TerminationDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_INFOMANID 
    + ", " + COLUMN_REQUESTCOMMENT 
    + ", " + COLUMN_REQUESTERID 
    + ", " + COLUMN_REVIEWCOMMENT 
    + ", " + COLUMN_TERMINATECOMMENT 
    + ", " + COLUMN_STATUS 
    + ", " + COLUMN_TERMINATIONDATE 
    + ", " + COLUMN_SYSTEMADMINCOMMENTS 
    + ", " + COLUMN_OPANALYSTSCHEDULEDATE 
    + ", " + COLUMN_OPANALYSTCOMPLETEDDATE 
    + ", " + COLUMN_OPERATIONALANALYSTCOMMENTS 
    + ", " + COLUMN_PROJECTCOORDINATORCOMMENTS 
    + ", " + COLUMN_CONNECTION_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + TerminationDAO.TABLE + " WHERE ID = ?";

    /** The Constant SELECT_REGIONSIMPACTED_REFERENCE_IDS_STMT. */
    private static final String SELECT_REGIONSIMPACTED_REFERENCE_IDS_STMT = "SELECT " + RegionsImpactedXrefDAO.COLUMN_ID + " FROM " + RegionsImpactedXrefDAO.TABLE + " WHERE " + RegionsImpactedXrefDAO.COLUMN_TERMINATIONREQUEST_ID + " = ?";

    /** The Constant SELECT_JUSTIFICATIONS_REFERENCE_IDS_STMT. */
    private static final String SELECT_JUSTIFICATIONS_REFERENCE_IDS_STMT = "SELECT " + TerminationJustificationXrefDAO.COLUMN_ID + " FROM " + TerminationJustificationXrefDAO.TABLE + " WHERE " + TerminationJustificationXrefDAO.COLUMN_TERMINATIONREQUEST_ID + " = ?";


    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the termination dao
     */
    public static TerminationDAO createInstance(DatabaseSession session)
    {
	return new TerminationDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new termination dao.
     *
     * @param session the session
     */
    public TerminationDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating TerminationDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The TerminationEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(TerminationEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(TerminationEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The TerminationEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(TerminationEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(TerminationEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting TerminationEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + TerminationDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
			connection = session.getConnection();
			// Update FOREIGN_KEY references for which we are the OWNER

			// Generate a new id
			long id = -1;
			if (customSequence != null) {
				id = KeyGenerator.getInstance().getNextKey(session, customSequence);
			} else if (databaseSequence != null) {
				try {
					st = connection.prepareStatement("Select " + databaseSequence + ".nextval from dual");
					rs = st.executeQuery();
					if (rs.next()) {
						id = rs.getLong(1);
					}
				} finally {
					try {
						if (rs != null)
							rs.close();
						if (st != null)
							st.close();
					} catch (Exception xe) {
					}

				}
			} else {
				id = KeyGenerator.getInstance().getNextKey(session, TerminationDAO.ENTITY_NAME);
			}
			entity.setId(Long.valueOf(id));
			int position = 1;
			st = connection.prepareStatement(INSERT_STMT);
			setLongToStatement(st, position++, entity.getId());

			// Attributes
			position = setLongToStatement(st, position, entity.getInfomanId());
			position = setStringToStatement(st, position, entity.getRequestComment(), COLUMN_REQUESTCOMMENT_LEN);
			position = setStringToStatement(st, position, entity.getRequesterId(), COLUMN_REQUESTERID_LEN);
			position = setStringToStatement(st, position, entity.getReviewComment(), COLUMN_REVIEWCOMMENT_LEN);
			position = setStringToStatement(st, position, entity.getTerminateComment(), COLUMN_TERMINATECOMMENT_LEN);
			position = setStringToStatement(st, position, entity.getStatus(), COLUMN_STATUS_LEN);
			position = setDateToStatement(st, position, entity.getTerminationDate());
			position = setStringToStatement(st, position, entity.getSystemAdminComments(),
					COLUMN_SYSTEMADMINCOMMENTS_LEN);
			position = setDateToStatement(st, position, entity.getOpAnalystScheduleDate());
			position = setDateToStatement(st, position, entity.getOpAnalystCompletedDate());
			position = setStringToStatement(st, position, entity.getOperationalAnalystComments(),
					COLUMN_OPERATIONALANALYSTCOMMENTS_LEN);
			position = setStringToStatement(st, position, entity.getProjectCoordinatorComments(),
					COLUMN_PROJECTCOORDINATORCOMMENTS_LEN);

			// Association references
			position = updateReferences(st, entity, position);

			st.executeUpdate();
			entity.setPrimaryKey(Long.valueOf(id));

			// Update FOREIGN_KEY references for which we are the OWNER
			updateRegionsImpactedReferences((TerminationEntity) entity);
			updateJustificationsReferences((TerminationEntity) entity);
			if (archiver != null) {
				archiver.storeSnapshotAuditLogForEntity(entity, "create");
			}
		}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + TerminationDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The TerminationEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(TerminationEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(TerminationEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The TerminationEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(TerminationEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(TerminationEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating TerminationEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + TerminationDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setLongToStatement(st, position, entity.getInfomanId());
	    position = setStringToStatement(st, position, entity.getRequestComment(), COLUMN_REQUESTCOMMENT_LEN);
	    position = setStringToStatement(st, position, entity.getRequesterId(), COLUMN_REQUESTERID_LEN);
	    position = setStringToStatement(st, position, entity.getReviewComment(), COLUMN_REVIEWCOMMENT_LEN);
	    position = setStringToStatement(st, position, entity.getTerminateComment(), COLUMN_TERMINATECOMMENT_LEN);
	    position = setStringToStatement(st, position, entity.getStatus(), COLUMN_STATUS_LEN);
	    position = setDateToStatement(st, position, entity.getTerminationDate());
	    position = setStringToStatement(st, position, entity.getSystemAdminComments(), COLUMN_SYSTEMADMINCOMMENTS_LEN);
	    position = setDateToStatement(st, position, entity.getOpAnalystScheduleDate());
	    position = setDateToStatement(st, position, entity.getOpAnalystCompletedDate());
	    position = setStringToStatement(st, position, entity.getOperationalAnalystComments(), COLUMN_OPERATIONALANALYSTCOMMENTS_LEN);
	    position = setStringToStatement(st, position, entity.getProjectCoordinatorComments(), COLUMN_PROJECTCOORDINATORCOMMENTS_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateRegionsImpactedReferences((TerminationEntity) entity);
	    updateJustificationsReferences((TerminationEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + TerminationDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public TerminationEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public TerminationEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	TerminationEntity obj = (TerminationEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting TerminationEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> TerminationEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (TerminationEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + TerminationDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + TerminationDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting TerminationEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    TerminationEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (TerminationEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (TerminationEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + TerminationDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type TerminationEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		TerminationEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM TERM";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (TerminationEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + TerminationDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type TerminationEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + TerminationDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    TerminationEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    TerminationEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(TerminationEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(TerminationEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + TerminationDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(TerminationEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();

	    // Go through the many association list and delete any entities that exist in it.
	    RegionsImpactedXrefDAO regionsImpactedDAO = getRegionsImpactedDAO();
	    List original_regionsImpacted_ids = entity.getOriginalRegionsImpactedIds();
	    Iterator regionsImpactedIt = entity.getRegionsImpacted().getDeletedList().iterator();
	    while (regionsImpactedIt.hasNext())
	    {
		RegionsImpactedXrefEntity o = (RegionsImpactedXrefEntity)regionsImpactedIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_regionsImpacted_ids.remove(id);
		}
		regionsImpactedDAO.delete(o);
	    }

	    regionsImpactedIt = entity.getRegionsImpacted().iterator();
	    while (regionsImpactedIt.hasNext())
	    {
		RegionsImpactedXrefEntity o = (RegionsImpactedXrefEntity)regionsImpactedIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_regionsImpacted_ids.remove(id);
		}
		regionsImpactedDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    regionsImpactedDAO.delete(original_regionsImpacted_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    TerminationJustificationXrefDAO justificationsDAO = getJustificationsDAO();
	    List original_justifications_ids = entity.getOriginalJustificationsIds();
	    Iterator justificationsIt = entity.getJustifications().getDeletedList().iterator();
	    while (justificationsIt.hasNext())
	    {
		TerminationJustificationXrefEntity o = (TerminationJustificationXrefEntity)justificationsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_justifications_ids.remove(id);
		}
		justificationsDAO.delete(o);
	    }

	    justificationsIt = entity.getJustifications().iterator();
	    while (justificationsIt.hasNext())
	    {
		TerminationJustificationXrefEntity o = (TerminationJustificationXrefEntity)justificationsIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_justifications_ids.remove(id);
		}
		justificationsDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    justificationsDAO.delete(original_justifications_ids);
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + TerminationDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	TerminationEntity entity = (TerminationEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setInfomanId(getLongFromResultSet(rs, COLUMN_INFOMANID));
	    entity.setInfomanId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalInfomanId(entity.getInfomanId());
	    //			entity.setRequestComment(getStringFromResultSet(rs, COLUMN_REQUESTCOMMENT));
	    entity.setRequestComment(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequestComment(entity.getRequestComment());
	    //			entity.setRequesterId(getStringFromResultSet(rs, COLUMN_REQUESTERID));
	    entity.setRequesterId(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequesterId(entity.getRequesterId());
	    //			entity.setReviewComment(getStringFromResultSet(rs, COLUMN_REVIEWCOMMENT));
	    entity.setReviewComment(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalReviewComment(entity.getReviewComment());
	    //			entity.setTerminateComment(getStringFromResultSet(rs, COLUMN_TERMINATECOMMENT));
	    entity.setTerminateComment(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalTerminateComment(entity.getTerminateComment());
	    //			entity.setStatus(getStringFromResultSet(rs, COLUMN_STATUS));
	    entity.setStatus(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalStatus(entity.getStatus());
	    //			entity.setTerminationDate(getDateFromResultSet(rs, COLUMN_TERMINATIONDATE));
	    entity.setTerminationDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalTerminationDate(entity.getTerminationDate());
	    //			entity.setSystemAdminComments(getStringFromResultSet(rs, COLUMN_SYSTEMADMINCOMMENTS));
	    entity.setSystemAdminComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalSystemAdminComments(entity.getSystemAdminComments());
	    //			entity.setOpAnalystScheduleDate(getDateFromResultSet(rs, COLUMN_OPANALYSTSCHEDULEDATE));
	    entity.setOpAnalystScheduleDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOpAnalystScheduleDate(entity.getOpAnalystScheduleDate());
	    //			entity.setOpAnalystCompletedDate(getDateFromResultSet(rs, COLUMN_OPANALYSTCOMPLETEDDATE));
	    entity.setOpAnalystCompletedDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOpAnalystCompletedDate(entity.getOpAnalystCompletedDate());
	    //			entity.setOperationalAnalystComments(getStringFromResultSet(rs, COLUMN_OPERATIONALANALYSTCOMMENTS));
	    entity.setOperationalAnalystComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOperationalAnalystComments(entity.getOperationalAnalystComments());
	    //			entity.setProjectCoordinatorComments(getStringFromResultSet(rs, COLUMN_PROJECTCOORDINATORCOMMENTS));
	    entity.setProjectCoordinatorComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProjectCoordinatorComments(entity.getProjectCoordinatorComments());

	    // Single References
	    //			entity.setConnectionId(getLongFromResultSet(rs, COLUMN_CONNECTION_ID));
	    entity.setConnectionId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalConnectionId(entity.getConnectionId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	TerminationEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (TerminationEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new TerminationEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	TerminationEntity entity = (TerminationEntity)obj;
	loadRegionsImpactedReferenceIds(entity);
	loadJustificationsReferenceIds(entity);
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("TerminationJustificationXrefDAO.loadReferences(): References for TerminationEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("TerminationJustificationXrefDAO.loadReferences(): Loading references for TerminationEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    TerminationEntity entity = (TerminationEntity)obj;

	    loadRegionsImpactedReferences(entity);

	    Long connectionId = entity.getConnectionId();
	    if (connectionId != null)
	    {
		//			ConnectionDAO connectionDAO = new ConnectionDAO(getSession());
		ConnectionDAO connectionDAO = getConnectionDAO();
		entity.setConnection((ConnectionEntity)connectionDAO.get(connectionId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalConnection(entity.getConnection());
	    }

	    loadJustificationsReferences(entity);

	}
	catch(Exception e)
	{
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for TerminationEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load connection with id.
     *
     * @param id the id
     * @return the connection entity
     * @throws DatabaseException the database exception
     */
    public ConnectionEntity loadConnectionWithId(Long id) throws DatabaseException
    {
	ConnectionEntity entity = null;
	if (id != null)
	{
	    //			ConnectionDAO connectionDAO = new ConnectionDAO(getSession());
	    ConnectionDAO connectionDAO = getConnectionDAO();
	    entity = (ConnectionEntity)connectionDAO.get(id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	TerminationEntity entity = (TerminationEntity) obj;

	setLongToStatement(st, position++, entity.getConnection() != null ? entity.getConnection().getId() : entity.getConnectionId());

	return position;
    }

    // Many Composition 'regionsImpacted' helpers 'terminationRequest'
    //======================================================================
    /**
     * Loads all the RegionsImpactedXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadRegionsImpactedReferences(TerminationEntity entity) throws DatabaseException
    {
	loadRegionsImpactedReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RegionsImpactedXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadRegionsImpactedReferences(TerminationEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading RegionsImpacted references for TerminationEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getRegionsImpacted();
	    List id_list = entity.getOriginalRegionsImpactedIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RegionsImpactedXrefDAO dao = getRegionsImpactedDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RegionsImpactedXrefDAO dao = getRegionsImpactedDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading RegionsImpacted references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load RegionsImpacted References for TerminationEntity [" + entity.getId() + "].", e);
	}


	//		entity.setRegionsImpacted(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the RegionsImpacted references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadRegionsImpactedReferenceIds(TerminationEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_REGIONSIMPACTED_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalRegionsImpactedIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load RegionsImpacted Reference IDs from TerminationEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update regions impacted references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateRegionsImpactedReferences(TerminationEntity entity) throws DatabaseException
    {
	ManyAssociationList regionsImpacted = entity.getRegionsImpacted();
	RegionsImpactedXrefDAO dao = getRegionsImpactedDAO();

	Iterator itDeleted = regionsImpacted.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RegionsImpactedXrefEntity e = (RegionsImpactedXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = regionsImpacted.iterator();
	while (it.hasNext())
	{
	    RegionsImpactedXrefEntity e = (RegionsImpactedXrefEntity) it.next();
	    e.setTerminationRequest(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'connection' helpers 'Termination' does not need helper
    // Many Composition 'justifications' helpers 'terminationRequest'
    //======================================================================
    /**
     * Loads all the TerminationJustificationXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadJustificationsReferences(TerminationEntity entity) throws DatabaseException
    {
	loadJustificationsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the TerminationJustificationXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadJustificationsReferences(TerminationEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Justifications references for TerminationEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getJustifications();
	    List id_list = entity.getOriginalJustificationsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		TerminationJustificationXrefDAO dao = getJustificationsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		TerminationJustificationXrefDAO dao = getJustificationsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Justifications references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Justifications References for TerminationEntity [" + entity.getId() + "].", e);
	}


	//		entity.setJustifications(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Justifications references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadJustificationsReferenceIds(TerminationEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_JUSTIFICATIONS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalJustificationsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Justifications Reference IDs from TerminationEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update justifications references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateJustificationsReferences(TerminationEntity entity) throws DatabaseException
    {
	ManyAssociationList justifications = entity.getJustifications();
	TerminationJustificationXrefDAO dao = getJustificationsDAO();

	Iterator itDeleted = justifications.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    TerminationJustificationXrefEntity e = (TerminationJustificationXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = justifications.iterator();
	while (it.hasNext())
	{
	    TerminationJustificationXrefEntity e = (TerminationJustificationXrefEntity) it.next();
	    e.setTerminationRequest(entity);
	    dao.update(e, false);
	}
    }

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RegionsImpactedXrefDAO object 
     */
    protected RegionsImpactedXrefDAO getRegionsImpactedDAO()
    {
	RegionsImpactedXrefDAO dao = (RegionsImpactedXrefDAO)getSession().getDAO("RegionsImpactedXref");  
	if(dao == null)
	{
	    dao = new RegionsImpactedXrefDAO(getSession());  		
	    getSession().putDAO("RegionsImpactedXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionDAO object 
     */
    protected ConnectionDAO getConnectionDAO()
    {
	ConnectionDAO dao = (ConnectionDAO)getSession().getDAO("Connection");  
	if(dao == null)
	{
	    dao = new ConnectionDAO(getSession());  		
	    getSession().putDAO("Connection", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A TerminationJustificationXrefDAO object 
     */
    protected TerminationJustificationXrefDAO getJustificationsDAO()
    {
	TerminationJustificationXrefDAO dao = (TerminationJustificationXrefDAO)getSession().getDAO("TerminationJustificationXref");  
	if(dao == null)
	{
	    dao = new TerminationJustificationXrefDAO(getSession());  		
	    getSession().putDAO("TerminationJustificationXref", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [InfomanId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByInfomanId(Long value) throws DatabaseException
    {
	return findByInfomanId(value, getSession());
    }

    /**
     * Find by infoman id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByInfomanId(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_INFOMANID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RequestComment] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequestComment(String value) throws DatabaseException
    {
	return findByRequestComment(value, getSession());
    }

    /**
     * Find by request comment.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequestComment(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_REQUESTCOMMENT + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RequesterId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequesterId(String value) throws DatabaseException
    {
	return findByRequesterId(value, getSession());
    }

    /**
     * Find by requester id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequesterId(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_REQUESTERID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ReviewComment] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByReviewComment(String value) throws DatabaseException
    {
	return findByReviewComment(value, getSession());
    }

    /**
     * Find by review comment.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByReviewComment(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_REVIEWCOMMENT + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [TerminateComment] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByTerminateComment(String value) throws DatabaseException
    {
	return findByTerminateComment(value, getSession());
    }

    /**
     * Find by terminate comment.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByTerminateComment(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_TERMINATECOMMENT + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Status] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByStatus(String value) throws DatabaseException
    {
	return findByStatus(value, getSession());
    }

    /**
     * Find by status.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByStatus(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_STATUS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [TerminationDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByTerminationDate(Date value) throws DatabaseException
    {
	return findByTerminationDate(value, getSession());
    }

    /**
     * Find by termination date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByTerminationDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_TERMINATIONDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [SystemAdminComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findBySystemAdminComments(String value) throws DatabaseException
    {
	return findBySystemAdminComments(value, getSession());
    }

    /**
     * Find by system admin comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findBySystemAdminComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_SYSTEMADMINCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OpAnalystScheduleDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOpAnalystScheduleDate(Date value) throws DatabaseException
    {
	return findByOpAnalystScheduleDate(value, getSession());
    }

    /**
     * Find by op analyst schedule date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOpAnalystScheduleDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_OPANALYSTSCHEDULEDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OpAnalystCompletedDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOpAnalystCompletedDate(Date value) throws DatabaseException
    {
	return findByOpAnalystCompletedDate(value, getSession());
    }

    /**
     * Find by op analyst completed date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOpAnalystCompletedDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_OPANALYSTCOMPLETEDDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OperationalAnalystComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOperationalAnalystComments(String value) throws DatabaseException
    {
	return findByOperationalAnalystComments(value, getSession());
    }

    /**
     * Find by operational analyst comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOperationalAnalystComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_OPERATIONALANALYSTCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ProjectCoordinatorComments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProjectCoordinatorComments(String value) throws DatabaseException
    {
	return findByProjectCoordinatorComments(value, getSession());
    }

    /**
     * Find by project coordinator comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProjectCoordinatorComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_PROJECTCOORDINATORCOMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Connection] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByConnection(Long value) throws DatabaseException
    {
	return findByConnection(value, getSession());
    }

    /**
     * Find by connection.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByConnection(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TerminationDAO.TABLE + " WHERE " + COLUMN_CONNECTION_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by Connection", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(TerminationEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
