package com.citigroup.cgti.c3par.connection.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.performer.dao.PerformerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionFWRuleFirewallXref.
 */
public class ConnectionFWRuleFirewallXref extends PerformerDO {

    /** The connection firewall mst. */
    ConnectionFirewallMaster connectionFirewallMst;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;


    /**
     * Instantiates a new connection fw rule firewall xref.
     */
    public ConnectionFWRuleFirewallXref() {
	//---------------------
	setTableName(PerformerTypes.CON_FW_RULE_FIREWALL_XREF_TABLE);
	setSequenceName(PerformerTypes.CON_FW_RULE_FIREWALL_XREF_SEQ);
	// ---------------------
	addToDBMapping("connectionFirewallMst", "FIREWALL_ID",1);
	addToDBMapping("created_date", "created_date",2);
	addToDBMapping("updated_date", "updated_date",3);
	// ----------------------
	addToNonCompositionList("connectionFirewallMst");
	// ----------------------
	addToParentsMap(
		"com.citigroup.cgti.c3par.connection.domain.ConnectionFWRuleMaster",
	"FIREWALL_RULE_ID");
	// ----------------------
    }

    /**
     * Gets the connection firewall mst.
     *
     * @return the connection firewall mst
     */
    public ConnectionFirewallMaster getConnectionFirewallMst() {
	return connectionFirewallMst;
    }

    /**
     * Sets the connection firewall mst.
     *
     * @param connectionFirewallMst the new connection firewall mst
     */
    public void setConnectionFirewallMst(
	    ConnectionFirewallMaster connectionFirewallMst) {
	this.connectionFirewallMst = connectionFirewallMst;
    }

    /**
     * Gets the created_date.
     *
     * @return Returns the created_date.
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date The created_date to set.
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return Returns the updated_date.
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date The updated_date to set.
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }
}
