package com.citigroup.cgti.c3par.domain;

import java.util.HashMap;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class C3PARMailMessage.
 */
@XmlRootElement
public class C3PARMailMessage {

    private String xslFileName;

    private String c3parBaseUrl;

    private String toAddresses;

    private String fromAddress;

    private String ccAddresses;

    private String bccAddresses;

    private String msgSubject;

    private String msgContent;

	private String msgContentFootNote;
	
	private List<MailMsgDisplayRow> rowList;

    private MailMsgDisplayRow [] row;
    
    private MailMsgDisplayRow [] questRow;
    
    private String templateID;
    
    private Long tiRequestID;
    
    private String referenceNo;
    
    private HashMap<String, String> attachments;
    
    private String doNotSendList;
    
    private Long cmpRequestId;

    private HashMap<String, byte[]> fileAttachments;
    
    private String serviceNowID;
    
    private String cmpID;
    
    private String ccrID;
    
    private String displayUserRole;
    private String displayInfoUserRole;

	private String workItemUrl;
	private String approveURL;
	private String rejectURL;

	private String name;
	private String ssoId;
	private String firstName;
	private String lastName;
	
	private String implementationResults;
	private String rfc;
	
	private String prxImpScheduledDate;
    private String prxInfomanId;
    
    private String apsImpScheduledDate;
    private String apsInfomanId;
    
    private String activationExpiryDate;
    private String TPASWGReviewDate;
    private String opeImpScheduledDate;
    private String activityStartDate;

    /*Anant Code changes start*/
    private String templateOwners;
    private String templateAppNames;
    private String activityName;
    private String conName;
    private String soeID;
    private String templateConNames;
    private String templateConIds;
    private String projectCoordinatorNames;
    private String businessOwnerNames;
    private String businessManagerNames;
    private String requestorNames;
    private String isoNames;
    private String netInfomanId;
    private String daysRemaining;
   
    /*Anant Code changes end*/ 
    
   private int versionNo;
   private String businessJustification;
   private String projCoordInfo;
   
   private String tiProcessName;
   @XmlElement
public int getVersionNo() {
	return versionNo;
}

public void setVersionNo(int versionNo) {
	this.versionNo = versionNo;
}

@XmlElement
public String getBusinessJustification() {
	return businessJustification;
}

public void setBusinessJustification(String businessJustification) {
	this.businessJustification = businessJustification;
}
@XmlElement
public String getProjCoordInfo() {
	return projCoordInfo;
}

public void setProjCoordInfo(String projCoordInfo) {
	this.projCoordInfo = projCoordInfo;
}
@XmlElement
public String getTiProcessName() {
	return tiProcessName;
}

public void setTiProcessName(String tiProcessName) {
	this.tiProcessName = tiProcessName;
}

	@XmlElement
	public String getTemplateOwners() {
		return templateOwners;
	}

	public void setTemplateOwners(String templateOwners) {
		this.templateOwners = templateOwners;
	}
	@XmlElement
	public String getTemplateAppNames() {
		return templateAppNames;
	}

	public void setTemplateAppNames(String templateAppNames) {
		this.templateAppNames = templateAppNames;
	}
	@XmlElement
	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	@XmlElement
	public String getConName() {
		return conName;
	}

	public void setConName(String conName) {
		this.conName = conName;
	}
	@XmlElement
	public String getSoeID() {
		return soeID;
	}

	public void setSoeID(String soeID) {
		this.soeID = soeID;
	}
	@XmlElement
	public String getTemplateConNames() {
		return templateConNames;
	}

	public void setTemplateConNames(String templateConNames) {
		this.templateConNames = templateConNames;
	}
	@XmlElement
	public String getTemplateConIds() {
		return templateConIds;
	}

	public void setTemplateConIds(String templateConIds) {
		this.templateConIds = templateConIds;
	}
	@XmlElement
	public String getProjectCoordinatorNames() {
		return projectCoordinatorNames;
	}

	public void setProjectCoordinatorNames(String projectCoordinatorNames) {
		this.projectCoordinatorNames = projectCoordinatorNames;
	}
	@XmlElement
	public String getBusinessOwnerNames() {
		return businessOwnerNames;
	}

	public void setBusinessOwnerNames(String businessOwnerNames) {
		this.businessOwnerNames = businessOwnerNames;
	}
	@XmlElement
	public String getBusinessManagerNames() {
		return businessManagerNames;
	}

	public void setBusinessManagerNames(String businessManagerNames) {
		this.businessManagerNames = businessManagerNames;
	}
	@XmlElement
	public String getRequestorNames() {
		return requestorNames;
	}

	public void setRequestorNames(String requestorNames) {
		this.requestorNames = requestorNames;
	}
	@XmlElement
	public String getIsoNames() {
		return isoNames;
	}

	public void setIsoNames(String isoNames) {
		this.isoNames = isoNames;
	}
	@XmlElement
	public String getNetInfomanId() {
		return netInfomanId;
	}

	public void setNetInfomanId(String netInfomanId) {
		this.netInfomanId = netInfomanId;
	}
	@XmlElement
	public String getDaysRemaining() {
		return daysRemaining;
	}

	public void setDaysRemaining(String daysRemaining) {
		this.daysRemaining = daysRemaining;
	}

	@XmlElement
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@XmlElement
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@XmlElement
	public String getSsoId() {
		return ssoId;
	}

	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}
	@XmlElement
	public String getTPASWGReviewDate() {
		return TPASWGReviewDate;
	}

	public void setTPASWGReviewDate(String tPASWGReviewDate) {
		TPASWGReviewDate = tPASWGReviewDate;
	}

	@XmlElement
	public String getOpeImpScheduledDate() {
		return opeImpScheduledDate;
	}

	public void setOpeImpScheduledDate(String opeImpScheduledDate) {
		this.opeImpScheduledDate = opeImpScheduledDate;
	}

	@XmlElement
    public String getActivationExpiryDate() {
              return activationExpiryDate;
       }

       public void setActivationExpiryDate(String activationExpiryDate) {
              this.activationExpiryDate = activationExpiryDate;
       }

       @XmlElement
    public String getPrxImpScheduledDate() {
              return prxImpScheduledDate;
       }

       public void setPrxImpScheduledDate(String prxImpScheduledDate) {
              this.prxImpScheduledDate = prxImpScheduledDate;
       }

       @XmlElement
    public String getPrxInfomanId() {
              return prxInfomanId;
       }

       public void setPrxInfomanId(String prxInfomanId) {
              this.prxInfomanId = prxInfomanId;
       }


	
	
       @XmlElement
	public String getApsImpScheduledDate() {
		return apsImpScheduledDate;
	}

	public void setApsImpScheduledDate(String apsImpScheduledDate) {
		this.apsImpScheduledDate = apsImpScheduledDate;
	}
	@XmlElement
	public String getApsInfomanId() {
		return apsInfomanId;
	}

	public void setApsInfomanId(String apsInfomanId) {
		this.apsInfomanId = apsInfomanId;
	}

	@XmlElement
	public String getRfc() {
		return rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	@XmlElement
	
	public String getImplementationResults() {
		return implementationResults;
	}

	public void setImplementationResults(String implementationResults) {
		this.implementationResults = implementationResults;
	}

	@XmlElement
	public String getDisplayInfoUserRole() {
		return displayInfoUserRole;
	}

	public void setDisplayInfoUserRole(String displayInfoUserRole) {
		this.displayInfoUserRole = displayInfoUserRole;
	}

	@XmlElement
	public String getApproveURL() {
		return approveURL;
	}

	public void setApproveURL(String approveURL) {
		this.approveURL = approveURL;
	}
	@XmlElement
	public String getRejectURL() {
		return rejectURL;
	}

	public void setRejectURL(String rejectURL) {
		this.rejectURL = rejectURL;
	}

	@XmlElement
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@XmlElement
	public String getWorkItemUrl() {
		return workItemUrl;
	}

	public void setWorkItemUrl(String workItemUrl) {
		this.workItemUrl = workItemUrl;
	}

	@XmlElement
	public String getDisplayUserRole() {
		return displayUserRole;
	}

	public void setDisplayUserRole(String displayUserRole) {
		this.displayUserRole = displayUserRole;
	}
    
    @XmlElement
    public Long getCmpRequestId() {
		return cmpRequestId;
	}

	public void setCmpRequestId(Long cmpRequestId) {
		this.cmpRequestId = cmpRequestId;
	}
    
    public MailMsgDisplayRow[] getQuestRow() {
		return questRow;
	}

	public void setQuestRow(MailMsgDisplayRow[] questRow) {
		this.questRow = questRow;
	}
	
	 public String getCcrID() {
			return ccrID;
		}

		public void setCcrID(String ccrID) {
			this.ccrID = ccrID;
		}

	@XmlElement
    public String getToAddresses() {
		return toAddresses;
    }

    public void setToAddresses(String toAddresses) {
    	this.toAddresses = toAddresses;
    }

    @XmlElement
    public String getFromAddress() {
    	return fromAddress;
    }

    public void setFromAddress(String fromAddress) {
    	this.fromAddress = fromAddress;
    }

    @XmlElement
    public String getCcAddresses() {
    	return ccAddresses;
    }

    public void setCcAddresses(String ccAddresses) {
    	this.ccAddresses = ccAddresses;
    }

    public String getBccAddresses() {
    	return bccAddresses;
    }

    public void setBccAddresses(String bccAddresses) {
    	this.bccAddresses = bccAddresses;
    }
    
    public String getMsgSubject() {
    	return msgSubject;
    }

    public void setMsgSubject(String msgSubject) {
    	this.msgSubject = msgSubject;
    }

    public String getMsgContent() {
    	return msgContent;
    }

    public void setMsgContent(String msgContent) {
    	this.msgContent = msgContent;
    }

    
    @XmlElement
    public List<MailMsgDisplayRow> getRowList() {
		return rowList;
	}

	public void setRowList(List<MailMsgDisplayRow> rowList) {
		this.rowList = rowList;
	}

	@XmlElement
    public MailMsgDisplayRow[] getRow() {
    	return row;
    }

    public void setRow(MailMsgDisplayRow[] row) {
    	this.row = row;
    }

    @XmlElement
    public String getMsgContentFootNote() {
    	return msgContentFootNote;
    }

    public void setMsgContentFootNote(String msgContentFootNote) {
    	this.msgContentFootNote = msgContentFootNote;
    }

    public String getXslFileName() {
    	return xslFileName;
    }

    public void setXslFileName(String xslFileName) {
    	this.xslFileName = xslFileName;
    }

    @XmlElement
    public String getC3parBaseUrl() {
    	return c3parBaseUrl;
    }

    public void setC3parBaseUrl(String baseUrl) {
    	c3parBaseUrl = baseUrl;
    }

	public String getTemplateID() {
		return templateID;
	}

	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}

	public Long getTiRequestID() {
		return tiRequestID;
	}

	public void setTiRequestID(Long tiRequestID) {
		this.tiRequestID = tiRequestID;
	}
	
	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public HashMap<String, String> getAttachments() {
		return attachments;
	}

	public void setAttachments(HashMap<String, String> attachments) {
		this.attachments = attachments;
	}

	public String getDoNotSendList() {
		return doNotSendList;
	}

	public void setDoNotSendList(String doNotSendList) {
		this.doNotSendList = doNotSendList;
	}

	public HashMap<String, byte[]> getFileAttachments() {
		return fileAttachments;
	}

	public void setFileAttachments(HashMap<String, byte[]> fileAttachments) {
		this.fileAttachments = fileAttachments;
	}

	public String getServiceNowID() {
		return serviceNowID;
	}

	public void setServiceNowID(String serviceNowID) {
		this.serviceNowID = serviceNowID;
	}

	public String getCmpID() {
		return cmpID;
	}

	public void setCmpID(String cmpID) {
		this.cmpID = cmpID;
	}

	@XmlElement
	public String getActivityStartDate() {
		return activityStartDate;
	}

	public void setActivityStartDate(String activityStartDate) {
		this.activityStartDate = activityStartDate;
	}
	
	

}
