package com.citigroup.cgti.c3par;

import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
//import org.apache.poi.hssf.usermodel.HSSFCellStyle;
//import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.citigroup.cgti.c3par.appsense.domain.AppsenseApplication;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseUser;
import com.citigroup.cgti.c3par.proxy.domain.ProxyFilter;
//import com.sun.xml.ws.developer.servlet.HttpSessionScopeFeature;



/**
 * The Class POIExcelWriter.
 */
@SuppressWarnings("unchecked")
public class POIExcelWriter {

    /**
     * Instantiates a new pOI excel writer.
     */
    public POIExcelWriter() {
    }

    /**
     * Parses the sheet.
     *
     * @param workbook the workbook
     * @param sheetName the sheet name
     * @param writeExcelList the write excel list
     * @param selectedTab the selected tab
     */
    public void parseSheet(HSSFWorkbook workbook, HSSFSheet sheetName,List writeExcelList,String selectedTab) {
	System.out.println("POIExcelWriter.parseSheet() :: Starts");
	System.out.println("sheet:: "+sheetName);
	if (sheetName != null) {
	    HSSFRow row = sheetName.createRow((short)0);
	    if(selectedTab != null && selectedTab.equals("manageProxy")){
		//row.createCell((short)0).setCellValue("Instance Name");
		//row.createCell((short)0).setCellValue("Application Name");
		row.createCell((short)0).setCellValue("URL");
		row.createCell((short)1).setCellValue("Action");
		row.createCell((short)2).setCellValue("Status");
	    }else if(selectedTab != null && selectedTab.equals("managePacFile")){
		row.createCell((short)0).setCellValue("Statement");
		row.createCell((short)1).setCellValue("Redirect To");
		row.createCell((short)2).setCellValue("Domain Name or Application URL");
		//row.createCell((short)2).setCellValue("Application Name");
		//row.createCell((short)3).setCellValue("URL");
		row.createCell((short)3).setCellValue("Action");
		row.createCell((short)4).setCellValue("Status");
	    }else if(selectedTab != null && selectedTab.equals("proxy")){
		//row.createCell((short)0).setCellValue("Application Name");
		row.createCell((short)0).setCellValue("URL");
		row.createCell((short)1).setCellValue("Status");
	    }else if(selectedTab != null && selectedTab.equals("manageUser")){
		row.createCell((short)0).setCellValue("SOE ID");
		row.createCell((short)1).setCellValue("Dev Access");
		row.createCell((short)2).setCellValue("Prd Access");
		row.createCell((short)3).setCellValue("Dev Admin");
		row.createCell((short)4).setCellValue("Prod Admin");
		row.createCell((short)5).setCellValue("Cross Environment Access");
		row.createCell((short)6).setCellValue("Local Folder Access");
		row.createCell((short)7).setCellValue("Status");
	    }else if(selectedTab != null && selectedTab.equals("manageSocks")){
	    	
	    	row.createCell((short)0).setCellValue("Is Source FQDN");
	    	row.createCell((short)1).setCellValue("Source IP");
	    	row.createCell((short)2).setCellValue("Is Destination FQDN");
			row.createCell((short)3).setCellValue("External IP");
			row.createCell((short)4).setCellValue("Protocol");
			row.createCell((short)5).setCellValue("Port");
			row.createCell((short)6).setCellValue("File Transfer Required");
			row.createCell((short)7).setCellValue("Frequency");
			row.createCell((short)8).setCellValue("File Size");
			row.createCell((short)9).setCellValue("Action");
			row.createCell((short)10).setCellValue("Status");
		    }
	    else if(selectedTab != null && selectedTab.equals("managePlug")){
	    	row.createCell((short)0).setCellValue("Request Type");
	    	row.createCell((short)1).setCellValue("Is Source FQDN");
	    	row.createCell((short)2).setCellValue("Source IP");
	    	row.createCell((short)3).setCellValue("Is Destination FQDN");
			row.createCell((short)4).setCellValue("External IP");
			row.createCell((short)5).setCellValue("Protocol");
			row.createCell((short)6).setCellValue("Port");
			row.createCell((short)7).setCellValue("Action");
			row.createCell((short)8).setCellValue("Status");
		    }
	    int rowcount = 1;
	    int noOfColumns = row.getPhysicalNumberOfCells();
	    System.out.println("noOfColumns:: "+noOfColumns);
	    System.out.println("Size of writeExcelList::: "+writeExcelList.size());
	    if(selectedTab != null && !selectedTab.equals("manageUser")){
		for(int i=0; i<writeExcelList.size();i++){
		    row = sheetName.createRow((short)(rowcount+i));
		    //row.setRowNum(rowcount+i);
		    ProxyFilter	proxyFilter = (ProxyFilter) writeExcelList.get(i);
		    if(selectedTab != null && selectedTab.equals("manageProxy")){
			//row.createCell((short)0).setCellValue(proxyFilter.getProxyInstance().getName());
			//row.createCell((short)0).setCellValue(proxyFilter.getAppame());
			row.createCell((short)0).setCellValue(proxyFilter.getUrl());
			row.createCell((short)1).setCellValue(proxyFilter.getAction());
			row.createCell((short)2).setCellValue(proxyFilter.getStatus());
		    }else if(selectedTab != null && selectedTab.equals("managePacFile")){
			row.createCell((short)0).setCellValue(proxyFilter.getStatement());
			row.createCell((short)1).setCellValue(proxyFilter.getStatementRedirect());
			row.createCell((short)2).setCellValue(proxyFilter.getDomainName());
			//row.createCell((short)2).setCellValue(proxyFilter.getAppame());
			//row.createCell((short)3).setCellValue(proxyFilter.getUrl());
			row.createCell((short)3).setCellValue(proxyFilter.getAction());
			row.createCell((short)4).setCellValue(proxyFilter.getStatus());
		    }else if(selectedTab != null && selectedTab.equals("proxy")){
			//row.createCell((short)0).setCellValue(proxyFilter.getAppame());
			row.createCell((short)0).setCellValue(proxyFilter.getUrl());
			row.createCell((short)1).setCellValue(proxyFilter.getStatus());
		    }else if(selectedTab != null && selectedTab.equals("manageSocks")){	    	

		    	row.createCell((short)0).setCellValue(proxyFilter.getIsSrcFQDN());
		    	row.createCell((short)1).setCellValue(proxyFilter.getSourceIp());
		    	row.createCell((short)2).setCellValue(proxyFilter.getIsDesFQDN());
				row.createCell((short)3).setCellValue(proxyFilter.getExternalIp());
				if (proxyFilter.getPort() != null) {
					row.createCell((short) 4).setCellValue(
							proxyFilter.getPort().substring(0,
									proxyFilter.getPort().indexOf("/")));
					row.createCell((short) 5).setCellValue(
							proxyFilter.getPort().substring(
									proxyFilter.getPort().indexOf("/")+1,
									proxyFilter.getPort().length()));
				}				
				if("Y".equalsIgnoreCase(proxyFilter.getIsFTReqd())){
					proxyFilter.setIsFTReqd("Yes");
					if(proxyFilter.getFrequency() != null)
					row.createCell((short)7).setCellValue(proxyFilter.getFrequency().getValue1());
					if(proxyFilter.getFileSize() != null)
					row.createCell((short)8).setCellValue(proxyFilter.getFileSize().getValue1());
				}if("N".equalsIgnoreCase(proxyFilter.getIsFTReqd())){
					proxyFilter.setIsFTReqd("No");
				}
				row.createCell((short)6).setCellValue(proxyFilter.getIsFTReqd());
				row.createCell((short)9).setCellValue(proxyFilter.getAction());
				row.createCell((short)10).setCellValue(proxyFilter.getStatus());
			    }
		    else if(selectedTab != null && selectedTab.equals("managePlug")){
		    	row.createCell((short)0).setCellValue(proxyFilter.getRequestType());
		    	row.createCell((short)1).setCellValue(proxyFilter.getIsSrcFQDN());
		    	row.createCell((short)2).setCellValue(proxyFilter.getSourceIp());
		    	row.createCell((short)3).setCellValue(proxyFilter.getIsDesFQDN());
				row.createCell((short)4).setCellValue(proxyFilter.getExternalIp());
				if (proxyFilter.getPort() != null) {
					row.createCell((short) 5).setCellValue(
							proxyFilter.getPort().substring(0,
									proxyFilter.getPort().indexOf("/")));
					row.createCell((short) 6).setCellValue(
							proxyFilter.getPort().substring(
									proxyFilter.getPort().indexOf("/")+1,
									proxyFilter.getPort().length()));
				}
				row.createCell((short)7).setCellValue(proxyFilter.getAction());
				row.createCell((short)8).setCellValue(proxyFilter.getStatus());
			    }
		}
	    }if(selectedTab != null && selectedTab.equals("manageUser")){
		for(int i=0; i<writeExcelList.size();i++){
		    row = sheetName.createRow((short)(rowcount+i));
		    //row.setRowNum(rowcount+i);
		    AppsenseUser appsenseUser = (AppsenseUser)writeExcelList.get(i);
		    row.createCell((short)0).setCellValue(appsenseUser.getCitiContact().getSsoId());
		    String devAccess = (String)appsenseUser.getDevAccess();
		    String prdAccess = (String)appsenseUser.getPrdAccess();
		    String crossEnvironmentAccess = (String)appsenseUser.getCrossEnvironmentAccess();
		    String localFolderAccess = (String)appsenseUser.getLocalFolderAccess();
		    if (appsenseUser.getStatus() == null || (appsenseUser.getStatus().trim().equals("") || appsenseUser.getStatus().trim().equalsIgnoreCase("failure")) ||(appsenseUser.getStatus().trim().equals("") || appsenseUser.getStatus().trim().equalsIgnoreCase("SUCCESS"))) {
			if (devAccess != null
				&& devAccess.trim().equalsIgnoreCase("A")) {
			    appsenseUser.setDevAccess("Yes");
			    appsenseUser.setDevAdminAccess("Yes");
			} else if (devAccess != null
				&& devAccess.trim().equalsIgnoreCase("U")) {
			    appsenseUser.setDevAccess("Yes");
			    appsenseUser.setDevAdminAccess("No");
			} else {
			    appsenseUser.setDevAccess("No");
			    appsenseUser.setDevAdminAccess("No");
			}
			if (prdAccess != null
				&& prdAccess.trim().equalsIgnoreCase("A")) {
			    appsenseUser.setPrdAccess("Yes");
			    appsenseUser.setPrdAdminAccess("Yes");
			} else if (prdAccess != null
				&& prdAccess.trim().equalsIgnoreCase("U")) {
			    appsenseUser.setPrdAccess("Yes");
			    appsenseUser.setPrdAdminAccess("No");
			} else {
			    appsenseUser.setPrdAccess("No");
			    appsenseUser.setPrdAdminAccess("No");
			}
			if (crossEnvironmentAccess != null
				&& crossEnvironmentAccess.trim().equalsIgnoreCase(
					"Y")) {
			    appsenseUser.setCrossEnvironmentAccess("Yes");
			} else if (crossEnvironmentAccess != null
				&& crossEnvironmentAccess.trim().equalsIgnoreCase(
					"N")) {
			    appsenseUser.setCrossEnvironmentAccess("No");
			} else {
			    appsenseUser.setCrossEnvironmentAccess(" ");
			}
			if (localFolderAccess != null
				&& localFolderAccess.trim().equalsIgnoreCase("Y")) {
			    appsenseUser.setLocalFolderAccess("Yes");
			} else if (localFolderAccess != null
				&& localFolderAccess.trim().equalsIgnoreCase("N")) {
			    appsenseUser.setLocalFolderAccess("No");
			} else {
			    appsenseUser.setLocalFolderAccess(" ");
			}
		    }
		    row.createCell((short)1).setCellValue(appsenseUser.getDevAccess());
		    row.createCell((short)2).setCellValue(appsenseUser.getPrdAccess());
		    row.createCell((short)3).setCellValue(appsenseUser.getDevAdminAccess());
		    row.createCell((short)4).setCellValue(appsenseUser.getPrdAdminAccess());
		    row.createCell((short)5).setCellValue(appsenseUser.getCrossEnvironmentAccess());
		    row.createCell((short)6).setCellValue(appsenseUser.getLocalFolderAccess());
		    row.createCell((short)7).setCellValue(appsenseUser.getStatus());
		}
	    }
	}else{
	    System.out.println("Sheet name is null");
	}
	System.out.println("POIExcelWriter.parseSheet() :: Ends");
    }

    /**
     * Parses the appsense sheet.
     *
     * @param workbook the workbook
     * @param sheetName the sheet name
     * @param writeExcelList the write excel list
     * @param selectedTab the selected tab
     */
    @SuppressWarnings("deprecation")
    public void parseAppsenseSheet(HSSFWorkbook workbook, HSSFSheet sheetName,List writeExcelList,String selectedTab) {
	try{
	    System.out.println("POIExcelWriter.parseSheet() :: Starts");
	    System.out.println("sheet:: "+sheetName);
	    if (sheetName != null) {
		HSSFRow row = sheetName.createRow((short)0);
		if(selectedTab != null /*&& selectedTab.equals("aps")*/){
		    //row.createCell((short)0).setCellValue("Instance Name");
		    //row.createCell((short)0).setCellValue("Application Name");
		    row.createCell((short)0).setCellValue("Ports");
		    row.createCell((short)1).setCellValue("IP/Subnets");
		    row.createCell((short)2).setCellValue("Application Type");
		    row.createCell((short)3).setCellValue("Blacklisted App");
		    row.createCell((short)4).setCellValue("Application ID");
		    row.createCell((short)5).setCellValue("Application Name");
		    row.createCell((short)6).setCellValue("Application Function");
		    row.createCell((short)7).setCellValue("Owner Name");
		    row.createCell((short)8).setCellValue("Owner GEID");
		    row.createCell((short)9).setCellValue("Non CSI Executable Name");
		    row.createCell((short)10).setCellValue("Status");
		    int rowcount = 1;
		    int noOfColumns = row.getPhysicalNumberOfCells();
		    System.out.println("noOfColumns:: "+noOfColumns);
		    String ipSubnet = "";
		    System.out.println("Size of writeExcelList::: "+writeExcelList.size());
		    for(int i=0; i<writeExcelList.size();i++){
			ipSubnet = "";
			//row.setRowNum(rowcount+i);
			row = sheetName.createRow((short)(rowcount+i));
			AppsenseApplication	appsenseApplication = (AppsenseApplication) writeExcelList.get(i);
			if(selectedTab != null /*&& selectedTab.equals("manageProxy")*/){
			    String applicationType = null;
			    if("N".equalsIgnoreCase(appsenseApplication.getApplication().getIsBlackListed())
				    && "N".equalsIgnoreCase(appsenseApplication.getApplication().getIsCSI()))
			    {
				applicationType="Non CSI";
			    }else if("Y".equalsIgnoreCase(appsenseApplication.getApplication().getIsBlackListed()))
			    {
				applicationType="Black Listed";
			    }else if("Y".equalsIgnoreCase(appsenseApplication.getApplication().getIsCSI())){
				applicationType="CSI";
			    }

			    if((appsenseApplication.getApsPortMaster() != null && appsenseApplication.getApsPortMaster().getPortLookUp() != null) && appsenseApplication.getApsPortMaster().getPortLookUp().getPortNumber() != null)
				row.createCell((short)0).setCellValue(appsenseApplication.getApsPortMaster().getPortLookUp().getProtocol()+"/"+appsenseApplication.getApsPortMaster().getPortLookUp().getPortNumber());

			    if((appsenseApplication.getApsPortMaster() != null && appsenseApplication.getApsPortMaster().getConnectionIPMaster() != null) && appsenseApplication.getApsPortMaster().getConnectionIPMaster().getIpAddress() != null)
				ipSubnet = appsenseApplication.getApsPortMaster().getConnectionIPMaster().getIpAddress();
			    if((appsenseApplication.getApsPortMaster() != null && appsenseApplication.getApsPortMaster().getConnectionIPMaster() != null) && appsenseApplication.getApsPortMaster().getConnectionIPMaster().getSubnet() != null)
				if(!"".equals(appsenseApplication.getApsPortMaster().getConnectionIPMaster().getSubnet()))
				    ipSubnet = ipSubnet+"/"+ appsenseApplication.getApsPortMaster().getConnectionIPMaster().getSubnet();
			    if(ipSubnet != null){
				row.createCell((short)1).setCellValue(ipSubnet);
			    }
			    Application appsData = appsenseApplication.getApplication();
			    if(appsData!=null)
			    {
				if(applicationType!=null)
				{
				    row.createCell((short)2).setCellValue(applicationType);
				}
				if(appsData.getExeFileName()!=null)
				{
				    if(applicationType == null || "Black Listed".equals(applicationType))
					row.createCell((short)3).setCellValue(appsData.getExeFileName());
				}
				if(appsData.getApplicationID()!=null)
				{
				    HSSFCell cell =  row.createCell((short)4);
				    cell.setCellValue(appsData.getApplicationID());
				}
				if(appsData.getApplicationName()!=null)
				{
				    if(applicationType == null || !"Black Listed".equals(applicationType))
					row.createCell((short)5).setCellValue(appsData.getApplicationName());
				}
				if(appsData.getFunction()!=null)
				{
				    if(applicationType == null || !"Black Listed".equals(applicationType))
					row.createCell((short)6).setCellValue(appsData.getFunction());
				}
				if(appsData.getAppOwnerFullName()!=null)
				{
				    row.createCell((short)7).setCellValue(appsData.getAppOwnerFullName());
				}
				if(appsData.getAppOwnerGEID()!=null)
				{
				    HSSFCell cell =  row.createCell((short)8);
				    cell.setCellValue(appsData.getAppOwnerGEID());
				}
				if(appsData.getExeFileNameNonCSI()!=null)
				{
				    if(applicationType == null || !"Black Listed".equals(applicationType))
					row.createCell((short)9).setCellValue(appsData.getExeFileNameNonCSI());
				}
				if(appsenseApplication.getStatus()!=null)
				{
				    row.createCell((short)10).setCellValue(appsenseApplication.getStatus());
				}


			    }

			}
		    }
		}else{
		    System.out.println("Sheet name is null");
		}
	    }
	}catch(Exception ex)
	{
	    System.out.println("Error in downloading the file..");
	}
    }
}
