/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.sql.Blob;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * @author pr265503
 *
 */
public class TIUploadedDocs extends Base {
    /**
	 * 
	 */
	private static final long serialVersionUID = 947123012774213004L;
	private Long tiRequestId;
	private Integer version;
    private String docType;
    private String contentType;
    private String docName;
    private Timestamp createDate;
    private String createDateDisplay;
    private Blob content;
        
    public TIUploadedDocs() {
    	setCreated_date(new Date());
    }

	public Long getTiRequestId() {
		return tiRequestId;
	}

	public void setTiRequestId(Long tiRequestId) {
		this.tiRequestId = tiRequestId;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public Blob getContent() {
		return content;
	}

	public void setContent(Blob content) {
		this.content = content;
	}

	public Timestamp getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public String getCreateDateDisplay() {
		if(getCreated_date() != null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			return dateformat.format(getCreated_date());
		}
		return createDateDisplay;
	}

	public void setCreateDateDisplay(String createDateDisplay) {
		this.createDateDisplay = createDateDisplay;
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
}
