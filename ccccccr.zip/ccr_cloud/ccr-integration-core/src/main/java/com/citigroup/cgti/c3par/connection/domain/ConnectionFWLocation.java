package com.citigroup.cgti.c3par.connection.domain;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionFWLocation.
 */
public class ConnectionFWLocation extends PerformerPagerDO {

    /** The fw location. */
    private String fwLocation;


    /**
     * Instantiates a new connection fw location.
     */
    public ConnectionFWLocation() {
	setTableName(PerformerTypes.CON_FW_LOCATION);
	addToDBMapping("fwLocation","LOCATION",1);
    }



    /**
     * Gets the fw location.
     *
     * @return the fw location
     */
    public String getFwLocation() {
	return fwLocation;
    }

    /**
     * Sets the fw location.
     *
     * @param fwLocation the new fw location
     */
    public void setFwLocation(String fwLocation) {
	this.fwLocation = fwLocation;
    }




}
