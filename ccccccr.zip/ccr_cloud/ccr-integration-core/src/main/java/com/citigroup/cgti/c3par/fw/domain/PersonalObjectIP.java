/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * 
 * @author ne36745
 *
 */
public class PersonalObjectIP extends Base {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private PersonalObject personalObject;
    
    private IPAddress ipAddress;
    
    private String NAT;
    
    private String isDeleted;
    
  //UI Level Attributes and Flags
    private boolean deleted;


    public PersonalObjectIP() {
		setCreated_date(new Date());
	}
    
    /**
	 * @return the personalObject
	 */
	public PersonalObject getPersonalObject() {
		return personalObject;
	}

	/**
	 * @param personalObject the personalObject to set
	 */
	public void setPersonalObject(PersonalObject personalObject) {
		this.personalObject = personalObject;
	}

	/**
	 * @return the ipAddress
	 */
	public IPAddress getIpAddress() {
		return ipAddress;
	}

	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(IPAddress ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * @return the nAT
	 */
	public String getNAT() {
		return NAT;
	}

	/**
	 * @param nAT the nAT to set
	 */
	public void setNAT(String nAT) {
		NAT = nAT;
	}

	/**
	 * @return the isDeleted
	 */
	public String getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the deleted
	 */
	public boolean isDeleted() {
		return deleted;
	}

	/**
	 * @param deleted the deleted to set
	 */
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
    
}
