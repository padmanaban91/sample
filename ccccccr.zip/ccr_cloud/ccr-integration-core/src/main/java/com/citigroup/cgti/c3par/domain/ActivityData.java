package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;


/**
 * The Class ActivityData.
 */
public class ActivityData extends Name implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;
    // Activty Mode values
    /** The Constant IS_NEW. */
    public static final String IS_NEW = "NEW";

    /** The Constant IS_REWORK. */
    public static final String IS_REWORK = "REWORK";

    /** The Constant IS_RECONSILE. */
    public static final String IS_RECONSILE = "RECONCILE";

    // Activity Type
    /** The Constant TYPE_APPROVAL. */
    public static final String TYPE_APPROVAL = "APPROVAL";

    /** The Constant TYPE_PROVIDEINFO. */
    public static final String TYPE_PROVIDEINFO = "PROVIDEINFO";

    // Activity Names
    /** The Constant ACTIVITY_START_PROCESS. */
    public static final String ACTIVITY_START_PROCESS = "start_process";

    /** The Constant ACTIVITY_BUS_JUS. */
    public static final String ACTIVITY_BUS_JUS = "bus_jus";

    /** The Constant ACTIVITY_TEC_ARC. */
    public static final String ACTIVITY_TEC_ARC = "tec_arc";

    /** The Constant ACTIVITY_ISO_APP. */
    public static final String ACTIVITY_ISO_APP = "iso_app";

    /** The Constant ACTIVITY_SE_APP. */
    public static final String ACTIVITY_SE_APP = "se_app";

    /** The Constant ACTIVITY_TPW_APP. */
    public static final String ACTIVITY_TPW_APP = "tpw_app";

    /** The Constant ACTIVITY_IST_APP. */
    public static final String ACTIVITY_IST_APP = "ist_app";

    /** The Constant ACTIVITY_MGR_APP. */
    public static final String ACTIVITY_MGR_APP = "bu_mgr_app";

    /** The Constant ACTIVITY_OPE_IMP. */
    public static final String ACTIVITY_OPE_IMP = "ope_imp";

    /** The Constant ACTIVITY_ACT_CON. */
    public static final String ACTIVITY_ACT_CON = "act_con";

    /** The Constant ACTIVITY_IP_DET. */
    public static final String ACTIVITY_IP_DET = "ip_det";

    /** The Constant ACTIVITY_MANAGE_USER_CONTACTS. */
    public static final String ACTIVITY_MANAGE_USER_CONTACTS = "business_user";

    /** The Constant ACTIVITY_PC_PRO_INF. */
    public static final String ACTIVITY_PC_PRO_INF = "pro_inf";

    /** The Constant ACTIVITY_DE_PRO_INF. */
    public static final String ACTIVITY_DE_PRO_INF = "pro_inf1";

    /** The Constant ACTIVITY_BISO_PRO_INF. */
    public static final String ACTIVITY_BISO_PRO_INF = "pro_inf2";

    /** The Constant ACTIVITY_SE_PRO_INF. */
    public static final String ACTIVITY_SE_PRO_INF = "pro_inf6";

    /** The Constant ACTIVITY_TPAWG_PRO_INF. */
    public static final String ACTIVITY_TPAWG_PRO_INF = "pro_inf3";

    /** The Constant ACTIVITY_ISTG_PRO_INF. */
    public static final String ACTIVITY_ISTG_PRO_INF = "pro_inf4";

    /** The Constant ACTIVITY_OA_PRO_INF. */
    public static final String ACTIVITY_OA_PRO_INF = "pro_inf5";

    /** The Constant ACTIVITY_MGR_PRO_INF. */
    public static final String ACTIVITY_MGR_PRO_INF = "pro_inf7";
    //public static final String Activity_RFI="Rollback FW Implementation";
    /** The Constant Activity_ROL_FW_IMP. */
    public static final String Activity_ROL_FW_IMP="rol_fw_imp";
    //these 3 statuses are used onlt in Tiprocess when a process is ended  

    //end status
    /** The Constant ACTIVITY_ACTIVE. */
    public static final String ACTIVITY_ACTIVE = "Active";

    /** The Constant ACTIVITY_TERMINATED. */
    public static final String ACTIVITY_TERMINATED = "Terminated";

    /** The Constant ACTIVITY_ABORTED. */
    public static final String ACTIVITY_ABORTED = "Aborted";

    /** The Constant ACTIVITY_REJECTED. */
    public static final String ACTIVITY_REJECTED = "Rejected";

    /** The Constant ACTIVITY_ROLLEDBACK. */
    public static final String ACTIVITY_ROLLEDBACK = "Rolledback";

    /** The Constant ACTIVITY_VERIFY_SOW. */
    public static final String ACTIVITY_VERIFY_SOW = "ver_sow";


    // Activty Status

    /** The Constant STATUS_COMPLETED. */
    public static final String STATUS_COMPLETED = "COMPLETED";
    
    /** The Constant STATUS_COMPLETED. */
    public static final String STATUS_STARTED = "STARTED";

    /** The Constant STATUS_REJECTED. */
    public static final String STATUS_REJECTED = "REJECTED";

    /** The Constant STATUS_REQUIRED. */
    public static final String STATUS_REQUIRED = "REQUIRED";
    // activity currently being worked upon will have status scheduled.There can
    // be only one activity with scheduled status
    /** The Constant STATUS_SCHEDULED. */
    public static final String STATUS_SCHEDULED = "SCHEDULED";
    // Activity which spawned a new provide info activity will have the status
    // provideinfo.
    /** The Constant STATUS_MOVED. */
    public static final String STATUS_MOVED = "MOVED";
    
    /**
     * 
     */
    public static final String STATUS_MOVED_TO_HQUEUE = "MOVED_TO_LOG_QUEUE";

    /** The Constant STATUS_PROVIDEINFO. */
    public static final String STATUS_PROVIDEINFO = "PROVIDEINFO";

    /** The Constant STATUS_UNLOCK. */
    public static final String STATUS_UNLOCK = "UNLOCKED";

    /** The Constant STATUS_ABORTED. */
    public static final String STATUS_ABORTED = "ABORTED";

    /** The Constant STATUS_EXTENDED. */
    public static final String STATUS_EXTENDED = "EXTENDED";

    /** The Constant STATUS_ROLLEDBACK. */
    public static final String STATUS_ROLLEDBACK = "ROLLEDBACK";

    /** The Constant STATUS_END. */
    public static final String STATUS_END = "END";

    /** The Constant STATUS_UNLOCK_TEXT. */
    public static final String STATUS_UNLOCK_TEXT = "Unlock Task";



    // Roles
    /** The Constant ROLE_PC. */
    public static final String ROLE_PC = "PROJECT COORDINATOR";

    /** The Constant ROLE_SA. */
    public static final String ROLE_SA = "C3PARSYSTEMADMIN";

    /** The Constant ROLE_TPWG. */
    public static final String ROLE_TPWG = "TPASWG";

    /**The Constant ROLE_SEA.*/

        public static final String ROLE_SEA = "C3PARSECURITYADMIN";

    /** The Constant ROLE_OA. */
    public static final String ROLE_OA = "Operational_Analyst";

    /** The Constant ROLE_ISO. */
    public static final String ROLE_ISO = "BISO";

    /** The Constant ROLE_DE. */
    public static final String ROLE_DE = "DESIGN ENGINEER";

    /** The Constant ROLE_ISTG. */
    public static final String ROLE_ISTG = "ISTG_Chair";

    /** The Constant ROLE_SE. */
    public static final String ROLE_SE = "Security Engineer";

    /** The Constant ROLE_MGR. */
    public static final String ROLE_MGR = "Business Manager";

    /** The Constant ROLE_SAG. */
    public static final String ROLE_SAG = "Support Agent";
    //Added for SE Approval Remodel - Task 3927
    /** The Constant ROLE_ECM. */
    public static final String ROLE_ECM = "ECM";

    /** The Constant ROLE_APPSENSE_IMPL. */
    public static final String ROLE_APPSENSE_IMPL = "Appsense_Implementer";

    /** The Constant ROLE_PROXY_IMPL. */
    public static final String ROLE_PROXY_IMPL = "Proxy_Implementer";

    /** The Constant ROLE_OTRM. */
    public static final String ROLE_OTRM = "OTRM";

    /** The Constant ROLE_MAD. */
    public static final String ROLE_MAD = "MAD";

    /** The Constant ROLE_BUSINESS_USER. */
    public static final String ROLE_BUSINESS_USER = "Business User";

    /** The Constant ROLE_GNCC. */
    public static final String ROLE_GNCC = "GNCC";
    
    /** The Constant ROLE_GNCC. */
    public static final String ROLE_ENT_REQ = "Entitlement Requester";


    //Special Instruction
    /** The Constant SPLINSTR_APPSENSE. */
    public static final String SPLINSTR_APPSENSE = "Appsense";

    /** The Constant SPLINSTR_PROXY. */
    public static final String SPLINSTR_PROXY = "Proxy";

    /** The Constant SPLINSTR_FIREWALL. */
    public static final String SPLINSTR_FIREWALL = "Firewall";

    //Business Unit NAme
    /** The Constant BUSINESS_UNIT_MAD. */
    public static final String BUSINESS_UNIT_MAD = "MA&D";

    // Stage DATACOLLECTION,APPROVAL,IMPLEMENTATION,VERIFICATION
    /** The Constant STAGE_DATACOLLECTION. */
    public static final String STAGE_DATACOLLECTION = "DC";

    /** The Constant STAGE_APPROVAL. */
    public static final String STAGE_APPROVAL = "AP";

    /** The Constant STAGE_IMPLEMENTAION. */
    public static final String STAGE_IMPLEMENTAION = "IM";

    /** The Constant STAGE_VALIDATION. */
    public static final String STAGE_VALIDATION = "VA";

    /** The Constant ACTIVITY_APPSENSE_IMP. */
    public static final String ACTIVITY_APPSENSE_IMP = "appsense_imp";

    /** The Constant ACL_VARIANCE_IMP. */
    public static final String ACL_VARIANCE_IMP = "gncc_imp";

    /** The Constant ACTIVITY_PROXY_IMP. */
    public static final String ACTIVITY_PROXY_IMP = "proxy_imp";

    /** The Constant ACTIVITY_OTRM. */
    public static final String ACTIVITY_OTRM="otrm_app";

    /** The Constant ACTIVITY_OTRM_RET. */
    public static final String ACTIVITY_OTRM_RET="otrm_ret_app";
    
    /**  The Constant ACTIVITY_TEMP_APP_EXP    */
    public static final String ACTIVITY_TEMP_APP_EXP = "tmp_exp";
    
    public static final String ACTIVITY_OTRM_RECONCILE_EXP = "rec_exp";
    

    //EMER/BUSCRIT Questiona and Answers Count
    /** The Constant EMER_BUSCRIT_QUESANDANS. */
    public static final int EMER_BUSCRIT_QUESANDANS=10;

    /** The Constant ACTIVITY_MANAGE_USER_CONTACTS_START_PROCESS. */
    public static final String ACTIVITY_MANAGE_USER_CONTACTS_START_PROCESS = "start_process_business_user";
    
    //Added for ECM Manager,Lead and Agent roles
    
    public static final String ROLE_ECM_Manager = "ECM Manager";
    
    public static final String ROLE_ECM_Lead = "ECM Lead";
    
    public static final String ROLE_ECM_Agent = "ECM Agent";
    
    public static final String STATUS_CREATE_SERVICNOW_TICKET = "CREATE_SERVICNOW_TICKET";
    
    private String tiRequestId;

    // could be AP for Approval and PI for Process Info Mode
    /** The activity type. */
    String activityType = "";

    // Represents Logical work group
    // -DataCollection,Approval,Implementation,Validation
    /** The activity stage. */
    String activityStage = "";

    /** The activity name. */
    String activityName = "";

    /** The activity status. */
    String activityStatus = "";

    // PC/DE/ISTG
    /** The user role. */
    String userRole = " ";

    /** The display user role. */
    String displayUserRole = " ";
    // SSO ID of the user who worked on it
    /** The user id. */
    String userID = "";

    // if infoMode is true infoUserRole represents the role form whom the
    // information is requested
    /** The info user role. */
    String infoUserRole = " ";

    /** The display info user role. */
    String displayInfoUserRole = " ";
    // Could be New Rework or Reconsile
    /** The activity mode. */
    String activityMode = "";

    /** The activity start date. */
    String activityStartDate = "";

    /** The activity end date. */
    String activityEndDate = "";

    /** The locked by. */
    String lockedBy = "";

    /** The locked date. */
    String lockedDate = "";

    /** The albpm activity id. */
    String albpmActivityID="";

    /** The display role. */
    String displayRole = " ";

    /** The encoded albpm activity. */
    String encodedAlbpmActivity="";
    
    String bpmInstanceId = "";

	//ActivityData prInfoActivityData=new ActivityData();
    /** The pr info activity data. */
    ActivityData prInfoActivityData;
    
    String baselineName;
    
    String tupleList;
    
    String approvalSystem;

    /**
     * Gets the albpm activity id.
     *
     * @return the albpm activity id
     */
    public String getAlbpmActivityID() {
	return albpmActivityID;
    }

    /**
     * Sets the albpm activity id.
     *
     * @param albpmActivityID the new albpm activity id
     */
    public void setAlbpmActivityID(String albpmActivityID) {
	this.albpmActivityID = albpmActivityID;
    }

    /**
     * Gettting BPM Instance ID
     * @return
     */
    public String getBpmInstanceId() {
		return bpmInstanceId;
	}

    /**
     * Setting BPM Instance ID
     * @param bpmInstanceId
     */
	public void setBpmInstanceId(String bpmInstanceId) {
		this.bpmInstanceId = bpmInstanceId;
	}
    
    
    /**
     * Gets the activity end date.
     *
     * @return the activity end date
     */
    public String getActivityEndDate() {
	return activityEndDate;
    }

    /**
     * Sets the activity end date.
     *
     * @param activityEndDate the new activity end date
     */
    public void setActivityEndDate(String activityEndDate) {
	this.activityEndDate = activityEndDate;
    }

    /**
     * Gets the activity mode.
     *
     * @return the activity mode
     */
    public String getActivityMode() {
	return activityMode;
    }

    /**
     * Sets the activity mode.
     *
     * @param activityMode the new activity mode
     */
    public void setActivityMode(String activityMode) {
	this.activityMode = activityMode;
    }

    /**
     * Gets the activity name.
     *
     * @return the activity name
     */
    public String getActivityName() {
	return activityName;
    }

    /**
     * Sets the activity name.
     *
     * @param activityName the new activity name
     */
    public void setActivityName(String activityName) {
	this.activityName = activityName;
    }

    /**
     * Gets the activity stage.
     *
     * @return the activity stage
     */
    public String getActivityStage() {
	return activityStage;
    }

    /**
     * Sets the activity stage.
     *
     * @param activityStage the new activity stage
     */
    public void setActivityStage(String activityStage) {
	this.activityStage = activityStage;
    }

    /**
     * Gets the activity start date.
     *
     * @return the activity start date
     */
    public String getActivityStartDate() {
	return activityStartDate;
    }

    /**
     * Sets the activity start date.
     *
     * @param activityStartDate the new activity start date
     */
    public void setActivityStartDate(String activityStartDate) {
	this.activityStartDate = activityStartDate;
    }

    /**
     * Gets the activity status.
     *
     * @return the activity status
     */
    public String getActivityStatus() {
	return activityStatus;
    }

    /**
     * Sets the activity status.
     *
     * @param activityStatus the new activity status
     */
    public void setActivityStatus(String activityStatus) {
	this.activityStatus = activityStatus;
    }

    /**
     * Gets the info user role.
     *
     * @return the info user role
     */
    public String getInfoUserRole() {
	return infoUserRole;
    }

    /**
     * Sets the info user role.
     *
     * @param infoUserRole the new info user role
     */
    public void setInfoUserRole(String infoUserRole) {
	this.infoUserRole = infoUserRole;
    }


    /**
     * Gets the locked by.
     *
     * @return the locked by
     */
    public String getLockedBy() {
	return lockedBy;
    }

    /**
     * Sets the locked by.
     *
     * @param lockedBy the new locked by
     */
    public void setLockedBy(String lockedBy) {
	this.lockedBy = lockedBy;
    }

    /**
     * Gets the user id.
     *
     * @return the user id
     */
    public String getUserID() {
	return userID;
    }

    /**
     * Sets the user id.
     *
     * @param userID the new user id
     */
    public void setUserID(String userID) {
	this.userID = userID;
    }

    /**
     * Gets the user role.
     *
     * @return the user role
     */
    public String getUserRole() {
	return userRole;
    }

    /**
     * Sets the user role.
     *
     * @param userRole the new user role
     */
    public void setUserRole(String userRole) {
	this.userRole = userRole;
    }

    /**
     * Gets the activity type.
     *
     * @return the activity type
     */
    public String getActivityType() {
	return activityType;
    }

    /**
     * Sets the activity type.
     *
     * @param activityType the new activity type
     */
    public void setActivityType(String activityType) {
	this.activityType = activityType;
    }

    /**
     * Gets the locked date.
     *
     * @return the locked date
     */
    public String getLockedDate() {


	return lockedDate;
    }

    /**
     * Sets the locked date.
     *
     * @param lockedDate the new locked date
     */
    public void setLockedDate(String lockedDate) {
	this.lockedDate = lockedDate;
    }

    /**
     * Gets the all status.
     *
     * @return the all status
     */
    public String getAllStatus(){
	return STATUS_COMPLETED+"~"+STATUS_REJECTED+"~"+STATUS_REQUIRED+"~"+STATUS_SCHEDULED+"~"+STATUS_PROVIDEINFO;
    }

    /**
     * Gets the display role.
     *
     * @return the display role
     */
    public String getDisplayRole() {
	return displayRole;
    }

    /**
     * Sets the display role.
     *
     * @param displayRole the new display role
     */
    public void setDisplayRole(String displayRole) {
	this.displayRole = displayRole;
    }

    /**
     * Gets the encoded albpm activity.
     *
     * @return the encoded albpm activity
     */
    public String getEncodedAlbpmActivity() {
	return encodedAlbpmActivity;
    }

    /**
     * Sets the encoded albpm activity.
     *
     * @param encodedAlbpmActivity the new encoded albpm activity
     */
    public void setEncodedAlbpmActivity(String encodedAlbpmActivity) {
	this.encodedAlbpmActivity = encodedAlbpmActivity;
    }

    /**
     * Gets the pr info activity data.
     *
     * @return the pr info activity data
     */
    public ActivityData getPrInfoActivityData() {
	return prInfoActivityData;
    }

    /**
     * Sets the pr info activity data.
     *
     * @param prInfoActivityData the new pr info activity data
     */
    public void setPrInfoActivityData(ActivityData prInfoActivityData) {
	this.prInfoActivityData = prInfoActivityData;
    }

    /**
     * Gets the display info user role.
     *
     * @return the display info user role
     */
    public String getDisplayInfoUserRole() {
	return displayInfoUserRole;
    }

    /**
     * Sets the display info user role.
     *
     * @param displayInfoUserRole the new display info user role
     */
    public void setDisplayInfoUserRole(String displayInfoUserRole) {
	this.displayInfoUserRole = displayInfoUserRole;
    }

    /**
     * Gets the display user role.
     *
     * @return the display user role
     */
    public String getDisplayUserRole() {
	return displayUserRole;
    }

    /**
     * Sets the display user role.
     *
     * @param displayUserRole the new display user role
     */
    public void setDisplayUserRole(String displayUserRole) {
	this.displayUserRole = displayUserRole;
    }

	/**
	 * @return the baselineName
	 */
	public String getBaselineName() {
		return baselineName;
	}

	/**
	 * @param baselineName the baselineName to set
	 */
	public void setBaselineName(String baselineName) {
		this.baselineName = baselineName;
	}

	/**
	 * @return the tupleList
	 */
	public String getTupleList() {
		return tupleList;
	}

	/**
	 * @param tupleList the tupleList to set
	 */
	public void setTupleList(String tupleList) {
		this.tupleList = tupleList;
	}

	/**
	 * @return the approvalSystem
	 */
	public String getApprovalSystem() {
		return approvalSystem;
	}

	/**
	 * @param approvalSystem the approvalSystem to set
	 */
	public void setApprovalSystem(String approvalSystem) {
		this.approvalSystem = approvalSystem;
	}

    /**
     * @return the tiRequestId
     */
    public String getTiRequestId() {
        return tiRequestId;
    }

    /**
     * @param tiRequestId the tiRequestId to set
     */
    public void setTiRequestId(String tiRequestId) {
        this.tiRequestId = tiRequestId;
    }
	
    
}
