package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

public class FafFirewallRulePolicy extends Base{
	private FafFirewallRule fafFireWallRule;
	private FirewallPolicy firewallPolicy;
	private TIRequest tiRequest;
	private TIRequest updatedTIRequest;
	/**
	 * @return the fafFireWallRule
	 */
	public FafFirewallRule getFafFireWallRule() {
		return fafFireWallRule;
	}
	/**
	 * @param fafFireWallRule the fafFireWallRule to set
	 */
	public void setFafFireWallRule(FafFirewallRule fafFireWallRule) {
		this.fafFireWallRule = fafFireWallRule;
	}
	/**
	 * @return the firewallPolicy
	 */
	public FirewallPolicy getFirewallPolicy() {
		return firewallPolicy;
	}
	/**
	 * @param firewallPolicy the firewallPolicy to set
	 */
	public void setFirewallPolicy(FirewallPolicy firewallPolicy) {
		this.firewallPolicy = firewallPolicy;
	}
	/**
	 * @return the tiRequest
	 */
	public TIRequest getTiRequest() {
		return tiRequest;
	}
	/**
	 * @param tiRequest the tiRequest to set
	 */
	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}
	/**
	 * @return the updatedTIRequest
	 */
	public TIRequest getUpdatedTIRequest() {
		return updatedTIRequest;
	}
	/**
	 * @param updatedTIRequest the updatedTIRequest to set
	 */
	public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
		this.updatedTIRequest = updatedTIRequest;
	}
	
}
