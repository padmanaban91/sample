package com.citigroup.cgti.c3par.domain;

import java.util.ArrayList;
import java.util.HashMap;

import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.Person;


/**
 * The Class FAFReviewForm.
 */
public class FAFReviewForm {

    /** The connection request id. */
    private Long connectionRequestId;

    /** The firewall id. */
    private Long []firewallID;

    /** The requestor. */
    private Person requestor = new Person();

    /** The curr cycle requestor. */
    private Person currCycleRequestor = new Person();

    /** The business contacts. */
    private ArrayList businessContacts = new ArrayList();

    /** The application list. */
    private ArrayList applicationList = new ArrayList();

    /** The application. */
    private Application application = new Application();

    /** The firewall map. */
    private HashMap firewallMap = new HashMap();

    /** The firewall list. */
    private ArrayList firewallList = new ArrayList();

    /** The combination list. */
    private ArrayList combinationList = new ArrayList();

    /** The review status. */
    private String reviewStatus;

    /** The orig bus justification. */
    private ArrayList origBusJustification = new ArrayList();

    /** The version id. */
    private Long versionId;

    /** The fafqueue reqs. */
    private ArrayList fafqueueReqs = new ArrayList();

    /** The faf spl instruction. */
    private String fafSplInstruction;

    /** The faf completion date. */
    private String fafCompletionDate;

    /** The faf infoman id. */
    private Long fafInfomanId;

    /**
     * Gets the review status.
     *
     * @return the review status
     */
    public String getReviewStatus() {
	return reviewStatus;
    }

    /**
     * Sets the review status.
     *
     * @param reviewStatus the new review status
     */
    public void setReviewStatus(String reviewStatus) {
	this.reviewStatus = reviewStatus;
    }

    /**
     * Gets the version id.
     *
     * @return the version id
     */
    public Long getVersionId() {
	return versionId;
    }

    /**
     * Sets the version id.
     *
     * @param versionId the new version id
     */
    public void setVersionId(Long versionId) {
	this.versionId = versionId;
    }

    /**
     * Gets the combination list.
     *
     * @return the combination list
     */
    public ArrayList getCombinationList() {
	return combinationList;
    }

    /**
     * Sets the combination list.
     *
     * @param combinationList the new combination list
     */
    public void setCombinationList(ArrayList combinationList) {
	this.combinationList = combinationList;
    }

    /**
     * Gets the application.
     *
     * @return the application
     */
    public Application getApplication() {
	return application;
    }

    /**
     * Sets the application.
     *
     * @param application the new application
     */
    public void setApplication(Application application) {
	this.application = application;
    }

    /**
     * Gets the application list.
     *
     * @return the application list
     */
    public ArrayList getApplicationList() {
	return applicationList;
    }

    /**
     * Sets the application list.
     *
     * @param applicationList the new application list
     */
    public void setApplicationList(ArrayList applicationList) {
	this.applicationList = applicationList;
    }

    /**
     * Gets the connection request id.
     *
     * @return the connection request id
     */
    public Long getConnectionRequestId() {
	return connectionRequestId;
    }

    /**
     * Sets the connection request id.
     *
     * @param connectionRequestId the new connection request id
     */
    public void setConnectionRequestId(Long connectionRequestId) {
	this.connectionRequestId = connectionRequestId;
    }

    /**
     * Gets the firewall list.
     *
     * @return the firewall list
     */
    public ArrayList getFirewallList() {
	return firewallList;
    }

    /**
     * Sets the firewall list.
     *
     * @param ipDetailListForComb1 the new firewall list
     */
    public void setFirewallList(ArrayList ipDetailListForComb1) {
	this.firewallList = ipDetailListForComb1;
    }

    /**
     * Gets the requestor.
     *
     * @return the requestor
     */
    public Person getRequestor() {
	return requestor;
    }

    /**
     * Sets the requestor.
     *
     * @param requestor the new requestor
     */
    public void setRequestor(Person requestor) {
	this.requestor = requestor;
    }

    /**
     * Gets the firewall map.
     *
     * @return the firewall map
     */
    public HashMap getFirewallMap() {
	return firewallMap;
    }

    /**
     * Sets the firewall map.
     *
     * @param firewallMap the new firewall map
     */
    public void setFirewallMap(HashMap firewallMap) {
	this.firewallMap = firewallMap;
    }

    /**
     * Gets the firewall id.
     *
     * @return the firewall id
     */
    public Long[] getFirewallID() {
	return firewallID;
    }

    /**
     * Sets the firewall id.
     *
     * @param firewallID the new firewall id
     */
    public void setFirewallID(Long[] firewallID) {
	this.firewallID = firewallID;
    }

    /**
     * Gets the fafqueue reqs.
     *
     * @return the fafqueue reqs
     */
    public ArrayList getFafqueueReqs() {
	return fafqueueReqs;
    }

    /**
     * Sets the fafqueue reqs.
     *
     * @param fafqueueReqs the new fafqueue reqs
     */
    public void setFafqueueReqs(ArrayList fafqueueReqs) {
	this.fafqueueReqs = fafqueueReqs;
    }

    /**
     * Gets the curr cycle requestor.
     *
     * @return the curr cycle requestor
     */
    public Person getCurrCycleRequestor() {
	return currCycleRequestor;
    }

    /**
     * Sets the curr cycle requestor.
     *
     * @param currCycleRequestor the new curr cycle requestor
     */
    public void setCurrCycleRequestor(Person currCycleRequestor) {
	this.currCycleRequestor = currCycleRequestor;
    }

    /**
     * Gets the orig bus justification.
     *
     * @return the orig bus justification
     */
    public ArrayList getOrigBusJustification() {
	return origBusJustification;
    }

    /**
     * Sets the orig bus justification.
     *
     * @param origBusJustification the new orig bus justification
     */
    public void setOrigBusJustification(ArrayList origBusJustification) {
	this.origBusJustification = origBusJustification;
    }

    /**
     * Gets the business contacts.
     *
     * @return the business contacts
     */
    public ArrayList getBusinessContacts() {
	return businessContacts;
    }

    /**
     * Sets the business contacts.
     *
     * @param businessContacts the new business contacts
     */
    public void setBusinessContacts(ArrayList businessContacts) {
	this.businessContacts = businessContacts;
    }

    /**
     * Gets the faf spl instruction.
     *
     * @return the faf spl instruction
     */
    public String getFafSplInstruction() {
	return fafSplInstruction;
    }

    /**
     * Sets the faf spl instruction.
     *
     * @param fafSplInstruction the new faf spl instruction
     */
    public void setFafSplInstruction(String fafSplInstruction) {
	this.fafSplInstruction = fafSplInstruction;
    }

    /**
     * Gets the faf completion date.
     *
     * @return the faf completion date
     */
    public String getFafCompletionDate() {
	return fafCompletionDate;
    }

    /**
     * Sets the faf completion date.
     *
     * @param fafCompletionDate the new faf completion date
     */
    public void setFafCompletionDate(String fafCompletionDate) {
	this.fafCompletionDate = fafCompletionDate;
    }

    /**
     * Gets the faf infoman id.
     *
     * @return the faf infoman id
     */
    public Long getFafInfomanId() {
	return fafInfomanId;
    }

    /**
     * Sets the faf infoman id.
     *
     * @param fafInfomanId the new faf infoman id
     */
    public void setFafInfomanId(Long fafInfomanId) {
	this.fafInfomanId = fafInfomanId;
    }


}
