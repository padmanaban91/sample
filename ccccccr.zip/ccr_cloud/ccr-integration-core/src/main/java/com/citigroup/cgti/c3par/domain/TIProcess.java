/*
 * Created on Aug 3, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.connection.domain.ConnectionRequest;

// TODO: Auto-generated Javadoc
/**
 * The Class TIProcess.
 * 
 * @author dr97938
 * 
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class TIProcess extends Name implements Serializable {

	private static final long serialVersionUID = 9176260606024580550L;

	public static final String ACL_FLAG = "isAcl";

	public static final String HIGH_RISK_FLAG = "isHighRisk";
	
	public static final String DENY_FLAG = "isDeny";

	public static final String BROAD_ACCESS_FLAG = "isBroadAccess";

	public static final String SEC_ENGG_FLAG = "isSecEngg";

	public static final String TPA_FLAG = "isTPA";
	
	public static final String OFAC_FLAG = "isOFAC";

	public static final String CONNECTION = "Connection";

	public static final String IPREGISTRATION = "IP";

	public static long BROAD_ACCESS_IP_COUNT = 64000;

	private BusinessCase businessCase = new BusinessCase();

	private Person requestor = new Person();

	private Status tiProcessStatus = new Status();

	private TIRequest tiRequest = new TIRequest();

	private List processUsers = new ArrayList();

	private ApprovalVO approvalVO = new ApprovalVO();

	private Relationship relationship = new Relationship();

	private List approvalList = new ArrayList();

	private List tiRequestList = new ArrayList();

	private ConnectionRequest connectionRequest = new ConnectionRequest();

	//Hibernate properties
	private TIProcessType tiprocessType;

	private Long entinstanceId;
	
	private com.citigroup.cgti.c3par.relationship.domain.Relationship relationshipId;

    private String processName;

    private Date created_date;

    private Date updated_date;

    private String processTerminateReason;

    private String processUpdateReason;

    private Long versionNo;

    private String isboradAccess;

    private String isdeleted;

    private Long processStatusId;

    private String autopush;

    private Long rel40processStatusId;

    private String tempexpiryGenFlag;

    //other than TI_PROCESS table fields
	private Date acvDeadline;

	private Date activationExpiryDate;

	private int versionNumber;

	private String processActivityMode;

	private String isHighRisk;

	private String isBroadAccess;

	private String endPointAResType;

	private String endPointBResType;

	private String fafVersionNumber;

	private String tempApprovalFlag;

	private String bulkRequest;

	private String appsenseType;

	private String proxyRegion;

	private String proxyType;

	private String tpaFlag;

	private String ipReg;

	private String templateConIds;

	private String templateConNames;

	private String templateOwners;

	private String templateAppNames;

	private Double connAggregate;

	private Double vendorAggregate;
	
	private String rfc  ;
	private String ofacFlag;
	
	
	public String getOfacFlag() {
		return ofacFlag;
	}

	public void setOfacFlag(String ofacFlag) {
		this.ofacFlag = ofacFlag;
	}

	public String getTemplateAppNames() {
		return templateAppNames;
	}

	public void setTemplateAppNames(String templateAppNames) {
		this.templateAppNames = templateAppNames;
	}

	public String getTemplateOwners() {
		return templateOwners;
	}

	public void setTemplateOwners(String templateOwners) {
		this.templateOwners = templateOwners;
	}

	public String getTemplateConIds() {
		return templateConIds;
	}

	public void setTemplateConIds(String templateConIds) {
		this.templateConIds = templateConIds;
	}

	public String getTemplateConNames() {
		return templateConNames;
	}

	public void setTemplateConNames(String templateConNames) {
		this.templateConNames = templateConNames;
	}

	public String getAppsenseType() {
		return appsenseType;
	}

	public void setAppsenseType(String appsenseType) {
		this.appsenseType = appsenseType;
	}

	public String getProxyRegion() {
		return proxyRegion;
	}

	public void setProxyRegion(String proxyRegion) {
		this.proxyRegion = proxyRegion;
	}

	public String getProxyType() {
		return proxyType;
	}

	public void setProxyType(String proxyType) {
		this.proxyType = proxyType;
	}

	public String getBulkRequest() {
		return bulkRequest;
	}

	public void setBulkRequest(String bulkRequest) {
		this.bulkRequest = bulkRequest;
	}

	public Relationship getRelationship() {
		return this.relationship;
	}

	public void setRelationship(Relationship relationship) {
		this.relationship = relationship;
	}

	public Status getTiProcessStatus() {
		return this.tiProcessStatus;
	}

	public void setTiProcessStatus(Status tiProcessStatus) {
		this.tiProcessStatus = tiProcessStatus;
	}
	
	public BusinessCase getBusinessCase() {
		return this.businessCase;
	}

	public void setBusinessCase(BusinessCase businessCase) {
		this.businessCase = businessCase;
	}

	public Person getRequestor() {
		return this.requestor;
	}

	public void setRequestor(Person requestor) {
		this.requestor = requestor;
	}

	public TIRequest getTiRequest() {
		return this.tiRequest;
	}

	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	public List getProcessUsers() {
		Collections.sort(this.processUsers, new CitiContactComparator());
		return this.processUsers;
	}

	public void setProcessUsers(List processUsers) {
		this.processUsers = processUsers;
	}

	public ApprovalVO getApprovalVO() {
		return this.approvalVO;
	}

	public void setApprovalVO(ApprovalVO approvalVO) {
		this.approvalVO = approvalVO;
	}

	public List getApprovalList() {
		return this.approvalList;
	}

	public void setApprovalList(List approvalList) {
		this.approvalList = approvalList;
	}

	public class CitiContactComparator implements Comparator {

		public int compare(Object object1, Object object2) {
			Person cont1 = (Person) object1;
			Person cont2 = (Person) object2;
			String contactName1 = cont1.getFirstName() + " "
					+ cont1.getLastName();
			String contactName2 = cont2.getFirstName() + " "
					+ cont2.getLastName();
			return contactName1.compareToIgnoreCase(contactName2);
		}
	}

	public ConnectionRequest getConnectionRequest() {
		return this.connectionRequest;
	}

	public void setConnectionRequest(ConnectionRequest connectionRequest) {
		this.connectionRequest = connectionRequest;
	}

	public String getIsHighRisk() {
		return this.isHighRisk;
	}

	public void setIsHighRisk(String isHighRisk) {
		this.isHighRisk = isHighRisk;
	}

	public String getProcessActivityMode() {
		return this.processActivityMode;
	}

	public void setProcessActivityMode(String processMode) {
		this.processActivityMode = processMode;
	}

	public int getVersionNumber() {
		return this.versionNumber;
	}

	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}

	public String getIsBroadAccess() {
		return this.isBroadAccess;
	}

	public void setIsBroadAccess(String isBroadAccess) {
		this.isBroadAccess = isBroadAccess;
	}

	public List getTiRequestList() {
		return tiRequestList;
	}

	
	public void setTiRequestList(List tiRequestList) {
		this.tiRequestList = tiRequestList;
	}

	public String getEndPointAResType() {
		return endPointAResType;
	}

	public void setEndPointAResType(String endPointAResType) {
		this.endPointAResType = endPointAResType;
	}

	
	public String getEndPointBResType() {
		return endPointBResType;
	}

	
	public void setEndPointBResType(String endPointBResType) {
		this.endPointBResType = endPointBResType;
	}

	public String getFafVersionNumber() {
		return fafVersionNumber;
	}

	
	public void setFafVersionNumber(String fafVersionNumber) {
		this.fafVersionNumber = fafVersionNumber;
	}

	public Date getAcvDeadline() {
		return acvDeadline;
	}

	public void setAcvDeadline(Date acvDeadline) {
		this.acvDeadline = acvDeadline;
	}

	public Date getActivationExpiryDate() {
		return activationExpiryDate;
	}

	public void setActivationExpiryDate(Date activationExpiryDate) {
		this.activationExpiryDate = activationExpiryDate;
	}
	
	public String getTempApprovalFlag() {
		return tempApprovalFlag;
	}

	public void setTempApprovalFlag(String tempApprovalFlag) {
		this.tempApprovalFlag = tempApprovalFlag;
	}

	public String getTpaFlag() {
		return tpaFlag;
	}

	public void setTpaFlag(String tpaFlag) {
		this.tpaFlag = tpaFlag;
	}

	public String getIpReg() {
		return ipReg;
	}
	
	public void setIpReg(String ipReg) {
		this.ipReg = ipReg;
	}

	public void setConnAggregate(Double connAggregate) {
		this.connAggregate = connAggregate;
	}

	public Double getConnAggregate() {
		return connAggregate;
	}

	public void setVendorAggregate(Double vendorAggregate) {
		this.vendorAggregate = vendorAggregate;
	}

	public Double getVendorAggregate() {
		return vendorAggregate;
	}

	public TIProcessType getTiprocessType() {
		return tiprocessType;
	}

	public void setTiprocessType(TIProcessType tiprocessType) {
		this.tiprocessType = tiprocessType;
	}

	public Long getEntinstanceId() {
		return entinstanceId;
	}

	public void setEntinstanceId(Long entinstanceId) {
		this.entinstanceId = entinstanceId;
	}

	public com.citigroup.cgti.c3par.relationship.domain.Relationship getRelationshipId() {
		return relationshipId;
	}

	public void setRelationshipId(
			com.citigroup.cgti.c3par.relationship.domain.Relationship relationshipId) {
		this.relationshipId = relationshipId;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public Date getUpdated_date() {
		return updated_date;
	}

	public void setUpdated_date(Date updated_date) {
		this.updated_date = updated_date;
	}

	public String getProcessTerminateReason() {
		return processTerminateReason;
	}

	public void setProcessTerminateReason(String processTerminateReason) {
		this.processTerminateReason = processTerminateReason;
	}

	public String getProcessUpdateReason() {
		return processUpdateReason;
	}

	public void setProcessUpdateReason(String processUpdateReason) {
		this.processUpdateReason = processUpdateReason;
	}

	public Long getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(Long versionNo) {
		this.versionNo = versionNo;
	}

	public String getIsboradAccess() {
		return isboradAccess;
	}

	public void setIsboradAccess(String isboradAccess) {
		this.isboradAccess = isboradAccess;
	}

	public String getIsdeleted() {
		return isdeleted;
	}

	public void setIsdeleted(String isdeleted) {
		this.isdeleted = isdeleted;
	}

	public Long getProcessStatusId() {
		return processStatusId;
	}

	public void setProcessStatusId(Long processStatusId) {
		this.processStatusId = processStatusId;
	}

	public String getAutopush() {
		return autopush;
	}

	public void setAutopush(String autopush) {
		this.autopush = autopush;
	}

	public Long getRel40processStatusId() {
		return rel40processStatusId;
	}

	public void setRel40processStatusId(Long rel40processStatusId) {
		this.rel40processStatusId = rel40processStatusId;
	}

	public String getTempexpiryGenFlag() {
		return tempexpiryGenFlag;
	}

	public void setTempexpiryGenFlag(String tempexpiryGenFlag) {
		this.tempexpiryGenFlag = tempexpiryGenFlag;
	}

	public String getRfc() {
		return rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}


}
