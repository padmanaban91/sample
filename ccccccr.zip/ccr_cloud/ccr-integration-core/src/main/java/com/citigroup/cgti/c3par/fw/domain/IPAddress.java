package com.citigroup.cgti.c3par.fw.domain;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.citigroup.cgti.c3par.domain.Base;

public class IPAddress extends Base {

    /**
     * 
     */
    
    private static final long serialVersionUID = 1L;
    @NotEmpty(message = "IP address not avaliable for source/destination IP ")
    private String ipAddress;
    
    private String formattedIP;
    
    private String startIP;
    
    private String formattedStartIP;
    
    private String endIP;
    
    private String formattedEndIP;
    
    private String subnet;   
    
    private Integer noOfHost;                     

    private String broadCastAddress;    
    
    private Integer resourceType;
    
    private String templateFlag;
    
    private String tpaFlag;
    private String ofacFlag;
    
    private String anyIP;
    private String AFAObjectName;
    
    /**
	 * @return the ofacFlag
	 */
    public String getOfacFlag() {
		return ofacFlag;
	}
    /**
	 * @param ofacFlag the ofacFlag to set
	 */
	public void setOfacFlag(String ofacFlag) {
		this.ofacFlag = ofacFlag;
	}

	/**
	 * @return the aFAObjectName
	 */
	public String getAFAObjectName() {
		return AFAObjectName;
	}

	/**
	 * @param aFAObjectName the aFAObjectName to set
	 */
	public void setAFAObjectName(String aFAObjectName) {
		AFAObjectName = aFAObjectName;
	}

	private List<FireWallRuleIP> fireWallRuleIPs;

    /**
     * @return the ipAddress
     */
    
    public String getIpAddress() {
	return ipAddress;
    }

    /**
     * @param ipAddress the ipAddress to set
     */
    public void setIpAddress(String ipAddress) {
	this.ipAddress = ipAddress;
    }
    //Will be used while listing IPAddress bean validation messages
    public String toString() {
	return ipAddress;
    }

	/**
	 * @return the formattedIP
	 */
	public String getFormattedIP() {
		return formattedIP;
	}

	/**
	 * @param formattedIP the formattedIP to set
	 */
	public void setFormattedIP(String formattedIP) {
		this.formattedIP = formattedIP;
	}

	/**
	 * @return the startIP
	 */
	public String getStartIP() {
		return startIP;
	}

	/**
	 * @param startIP the startIP to set
	 */
	public void setStartIP(String startIP) {
		this.startIP = startIP;
	}

	/**
	 * @return the formattedStartIP
	 */
	public String getFormattedStartIP() {
		return formattedStartIP;
	}

	/**
	 * @param formattedStartIP the formattedStartIP to set
	 */
	public void setFormattedStartIP(String formattedStartIP) {
		this.formattedStartIP = formattedStartIP;
	}

	/**
	 * @return the endIP
	 */
	public String getEndIP() {
		return endIP;
	}

	/**
	 * @param endIP the endIP to set
	 */
	public void setEndIP(String endIP) {
		this.endIP = endIP;
	}

	/**
	 * @return the formattedEndIP
	 */
	public String getFormattedEndIP() {
		return formattedEndIP;
	}

	/**
	 * @param formattedEndIP the formattedEndIP to set
	 */
	public void setFormattedEndIP(String formattedEndIP) {
		this.formattedEndIP = formattedEndIP;
	}

	/**
	 * @return the subnet
	 */
	public String getSubnet() {
		return subnet;
	}

	/**
	 * @param subnet the subnet to set
	 */
	public void setSubnet(String subnet) {
		this.subnet = subnet;
	}

	/**
	 * @return the noOfHost
	 */
	public Integer getNoOfHost() {
		return noOfHost;
	}

	/**
	 * @param noOfHost the noOfHost to set
	 */
	public void setNoOfHost(Integer noOfHost) {
		this.noOfHost = noOfHost;
	}

	/**
	 * @return the broadCastAddress
	 */
	public String getBroadCastAddress() {
		return broadCastAddress;
	}

	/**
	 * @param broadCastAddress the broadCastAddress to set
	 */
	public void setBroadCastAddress(String broadCastAddress) {
		this.broadCastAddress = broadCastAddress;
	}

	/**
	 * @return the resourceType
	 */
	public Integer getResourceType() {
		return resourceType;
	}

	/**
	 * @param resourceType the resourceType to set
	 */
	public void setResourceType(Integer resourceType) {
		this.resourceType = resourceType;
	}

	/**
	 * @return the templateFlag
	 */
	public String getTemplateFlag() {
		return templateFlag;
	}

	/**
	 * @param templateFlag the templateFlag to set
	 */
	public void setTemplateFlag(String templateFlag) {
		this.templateFlag = templateFlag;
	}

	/**
	 * @return the tpaFlag
	 */
	public String getTpaFlag() {
		return tpaFlag;
	}

	/**
	 * @param tpaFlag the tpaFlag to set
	 */
	public void setTpaFlag(String tpaFlag) {
		this.tpaFlag = tpaFlag;
	}

	/**
	 * @return the anyIP
	 */
	public String getAnyIP() {
		return anyIP;
	}

	/**
	 * @param anyIP the anyIP to set
	 */
	public void setAnyIP(String anyIP) {
		this.anyIP = anyIP;
	}

	/**
	 * @return the fireWallRuleIPs
	 */
	public List<FireWallRuleIP> getFireWallRuleIPs() {
		return fireWallRuleIPs;
	}

	/**
	 * @param fireWallRuleIPs the fireWallRuleIPs to set
	 */
	public void setFireWallRuleIPs(List<FireWallRuleIP> fireWallRuleIPs) {
		this.fireWallRuleIPs = fireWallRuleIPs;
	}
}
