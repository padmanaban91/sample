/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.List;

import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * 
 * @author ne36745
 *
 */
public class HistoryFireWallRule extends Base {
	
    private static final long serialVersionUID = 1L;
    public static final String ADD = "ADD";
    public static final String EDIT = "EDIT";
    public static final String EDITorDELETE = "EDORDEL";
    public static final String DELETE = "DELETE";
    private Integer ruleNumber;
    private TIRequest tiRequest;
    private TIRequest updatedTIRequest;
    private TIRequest deletedTIRequest;
    private FireWallPolicyGroup policyGroup;
    private FirewallPolicy policy;
    private List<HistoryFireWallRuleSourceIP> sourceIPs;
    private List<HistoryFireWallRuleDestinationIP> destinationIPs;
    private List<HistoryFireWallRulePort> ports;
    private List<HistoryFirewallRulePolicy> policies;
    private FireWallZone sourceZone;
	private FireWallZone destinationZone;
    private ResourceType sourceNetworkZone;
    private ResourceType destinationNetworkZone;
    private String FAFGenerated;
    private String status;
    private String bidirectional;
    
    private IPAddress sourceObject;
    private IPAddress destinationObject;
    private Port portObject;
    private Long templateID;
    private String templateConnectionName;
    private String isIpReg;
    
    private Long ruleId;
    private String ruleType;
    
	/**
	 * @return the ruleId
	 */
	public Long getRuleId() {
		return ruleId;
	}

	/**
	 * @param ruleId the ruleId to set
	 */
	public void setRuleId(Long ruleId) {
		this.ruleId = ruleId;
	}

	public ResourceType getSourceNetworkZone() {
		return sourceNetworkZone;
	}

	public ResourceType getDestinationNetworkZone() {
		return destinationNetworkZone;
	}
    public void setSourceNetworkZone(ResourceType sourceNetworkZone) {
		this.sourceNetworkZone = sourceNetworkZone;
	}

	public void setDestinationNetworkZone(ResourceType destinationNetworkZone) {
		this.destinationNetworkZone = destinationNetworkZone;
	}

    public HistoryFireWallRule() {

    }

    /**
     * @return the ruleNumber
     */
    public Integer getRuleNumber() {
	return ruleNumber;
    }

    /**
     * @param ruleNumber the ruleNumber to set
     */
    public void setRuleNumber(Integer ruleNumber) {
	this.ruleNumber = ruleNumber;
    }

    /**
     * @return the updatedTIRequest
     */
    public TIRequest getUpdatedTIRequest() {
	return updatedTIRequest;
    }

    /**
     * @param updatedTIRequest the updatedTIRequest to set
     */
    public void setUpdatedTIRequest(TIRequest updatedTIRequest) {
	this.updatedTIRequest = updatedTIRequest;
    }

    /**
     * @return the deletedTIRequest
     */
    public TIRequest getDeletedTIRequest() {
	return deletedTIRequest;
    }

    /**
     * @param deletedTIRequest the deletedTIRequest to set
     */
    public void setDeletedTIRequest(TIRequest deletedTIRequest) {
	this.deletedTIRequest = deletedTIRequest;
    }

    /**
     * @return the policyGroup
     */
    public FireWallPolicyGroup getPolicyGroup() {
	return policyGroup;
    }

    /**
     * @param policyGroup the policyGroup to set
     */
    public void setPolicyGroup(FireWallPolicyGroup policyGroup) {
	this.policyGroup = policyGroup;
    }

    /**
     * @return the policy
     */
    public FirewallPolicy getPolicy() {
	return policy;
    }

    /**
     * @param policy the policy to set
     */
    public void setPolicy(FirewallPolicy policy) {
	this.policy = policy;
    }

    /**
     * @return the sourceIPs
     */
    public List<HistoryFireWallRuleSourceIP> getSourceIPs() {
	return sourceIPs;
    }

    /**
     * @param sourceIPs the sourceIPs to set
     */
    public void setSourceIPs(List<HistoryFireWallRuleSourceIP> sourceIPs) {
	this.sourceIPs = sourceIPs;
    }

    /**
     * @return the destinationIPs
     */
    public List<HistoryFireWallRuleDestinationIP> getDestinationIPs() {
	return destinationIPs;
    }

    /**
     * @param destinationIPs the destinationIPs to set
     */
    public void setDestinationIPs(List<HistoryFireWallRuleDestinationIP> destinationIPs) {
	this.destinationIPs = destinationIPs;
    }

    /**
     * @return the ports
     */
    public List<HistoryFireWallRulePort> getPorts() {
	return ports;
    }

    /**
     * @param ports the ports to set
     */
    public void setPorts(List<HistoryFireWallRulePort> ports) {
	this.ports = ports;
    }

    /**
     * @return the sourceZone
     */
    public FireWallZone getSourceZone() {
	return sourceZone;
    }

    /**
     * @param sourceZone the sourceZone to set
     */
    public void setSourceZone(FireWallZone sourceZone) {
	this.sourceZone = sourceZone;
    }

    /**
     * @return the destinationZone
     */
    public FireWallZone getDestinationZone() {
	return destinationZone;
    }

    /**
     * @param destinationZone the destinationZone to set
     */
    public void setDestinationZone(FireWallZone destinationZone) {
	this.destinationZone = destinationZone;
    }

    //Will be used while listing FireWallRule bean validation messages
    public String toString() {
	return "FW Rule :" + ruleNumber;
    }

    /**
     * @return the fAFGenerated
     */
    public String getFAFGenerated() {
	return FAFGenerated;
    }

    /**
     * @param fAFGenerated the fAFGenerated to set
     */
    public void setFAFGenerated(String fAFGenerated) {
	FAFGenerated = fAFGenerated;
    }

    /**
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
	this.status = status;
    }

	/**
	 * @return the tiRequest
	 */
	public TIRequest getTiRequest() {
		return tiRequest;
	}

	/**
	 * @param tiRequest the tiRequest to set
	 */
	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}
	
	public String getBidirectional() {
		return bidirectional;
	}

	public void setBidirectional(String bidirectional) {
		this.bidirectional = bidirectional;
	}

	/**
	 * @return the sourceObject
	 */
	public IPAddress getSourceObject() {
		return sourceObject;
	}

	/**
	 * @param sourceObject the sourceObject to set
	 */
	public void setSourceObject(IPAddress sourceObject) {
		this.sourceObject = sourceObject;
	}

	/**
	 * @return the destinationObject
	 */
	public IPAddress getDestinationObject() {
		return destinationObject;
	}

	/**
	 * @param destinationObject the destinationObject to set
	 */
	public void setDestinationObject(IPAddress destinationObject) {
		this.destinationObject = destinationObject;
	}

	/**
	 * @return the portObject
	 */
	public Port getPortObject() {
		return portObject;
	}

	/**
	 * @param portObject the portObject to set
	 */
	public void setPortObject(Port portObject) {
		this.portObject = portObject;
	}

	public Long getTemplateID() {
		return templateID;
	}

	public void setTemplateID(Long templateID) {
		this.templateID = templateID;
	}

    public String getTemplateConnectionName() {
		return templateConnectionName;
	}

	public void setTemplateConnectionName(String templateConnectionName) {
		this.templateConnectionName = templateConnectionName;
	}

	/**
	 * @return the policies
	 */
	public List<HistoryFirewallRulePolicy> getPolicies() {
		return policies;
	}

	/**
	 * @param policies the policies to set
	 */
	public void setPolicies(List<HistoryFirewallRulePolicy> policies) {
		this.policies = policies;
	}

	public String getIsIpReg() {
		return isIpReg;
	}

	public void setIsIpReg(String isIpReg) {
		this.isIpReg = isIpReg;
	}

	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}
	

}
