package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * 
 * @author ne36745
 *
 */
public class RiskDefinition extends Base {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String riskCode;
	
	private String riskDescription;
	
	private OstiaQuestionnaire questionnaire;
	
	private List<OstiaQuestion> ostiaQuestions;
	
	private Double riskRating;
	
	public RiskDefinition() {
		setCreated_date(new Date());
	}
	
	/**
	 * @return the riskCode
	 */
	public String getRiskCode() {
		return riskCode;
	}

	/**
	 * @param riskCode the riskCode to set
	 */
	public void setRiskCode(String riskCode) {
		this.riskCode = riskCode;
	}

	/**
	 * @return the riskDescription
	 */
	public String getRiskDescription() {
		return riskDescription;
	}

	/**
	 * @param riskDescription the riskDescription to set
	 */
	public void setRiskDescription(String riskDescription) {
		this.riskDescription = riskDescription;
	}

	/**
	 * @return the questionnaire
	 */
	public OstiaQuestionnaire getQuestionnaire() {
		return questionnaire;
	}

	/**
	 * @param questionnaire the questionnaire to set
	 */
	public void setQuestionnaire(OstiaQuestionnaire questionnaire) {
		this.questionnaire = questionnaire;
	}

	/**
	 * @return the ostiaQuestions
	 */
	public List<OstiaQuestion> getOstiaQuestions() {
		return ostiaQuestions;
	}

	/**
	 * @param ostiaQuestions the ostiaQuestions to set
	 */
	public void setOstiaQuestions(List<OstiaQuestion> ostiaQuestions) {
		this.ostiaQuestions = ostiaQuestions;
	}

	public void setRiskRating(Double riskRating) {
		this.riskRating = riskRating;
	}

	public Double getRiskRating() {
		return riskRating;
	}

}
