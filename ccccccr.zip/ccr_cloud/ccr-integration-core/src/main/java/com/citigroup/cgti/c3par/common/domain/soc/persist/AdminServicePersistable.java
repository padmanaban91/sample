/**
 * 
 */
package com.citigroup.cgti.c3par.common.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.admin.domain.ManageISOContactProcess;
import com.citigroup.cgti.c3par.audit.domain.AuditC3parUsersData;
import com.citigroup.cgti.c3par.common.domain.AdminProcess;
import com.citigroup.cgti.c3par.common.domain.ISOContacts;
import com.citigroup.cgti.c3par.common.domain.TITaskType;
import com.citigroup.cgti.c3par.persistance.Persistable;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyLocationXref;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.user.domain.C3parUserHierarchyXref;
import com.citigroup.cgti.c3par.user.domain.C3parUserRoleXref;
import com.citigroup.cgti.c3par.user.domain.SecurityRole;

/**
 * @author pc79439
 * 
 */
public interface AdminServicePersistable extends Persistable {
	
	public List<ISOContacts> getManageISOContactList(ManageISOContactProcess manageISOContactProcess);
	public void saveManageISOContactList(String soeID);
	public void deleteManageISOContactList(List<String> soeIdList);
	public List<TITaskType> getActivityNameList();	
	
	List<SecurityRole> getSecurityRoles();
	
	Long saveUser(C3parUser c3parUser);
	
	C3parUser retrieveC3parUser(Long Id);
	
	C3parUser retrieveC3parUser(String ssoId);
	
	C3parUser validateC3parUser(C3parUser c3parUser);
	
	List<C3parUser> listC3ParUsers(AdminProcess adminProcess);
	
	public List<CitiHierarchyMaster> getConnectionRegSecBU(Long conId);
	
	Long getUserId(String ssoId);
	
	int saveAuditUsersDate(AuditC3parUsersData auditC3parUsersData);
	
	public ThirdPartyLocationXref loadThirdPartyLocation(Long thirdpartyId);
	
	AuditC3parUsersData getLastAuditUsersData(Long userId);
	
	List<C3parUserRoleXref> getC3parUserRoleXref(Long userId) throws Exception;
	List<C3parUserHierarchyXref> getC3parUserHierarchyXref(Long userId) throws Exception;
	
}
