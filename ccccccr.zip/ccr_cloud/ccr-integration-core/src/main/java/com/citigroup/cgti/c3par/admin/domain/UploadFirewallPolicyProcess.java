package com.citigroup.cgti.c3par.admin.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;



public class UploadFirewallPolicyProcess {
	

	private static Logger log = Logger.getLogger(UploadFirewallPolicyProcess.class);
	
	
	private CommonsMultipartFile policyFile ;
	private String policyFileString ;
	private String fireWallName;
	private String managementRegion;
	private String fireWallType;
	
	private String message;
	private String messageFlag;
	private List<FirewallPolicy> searchResult = new ArrayList<FirewallPolicy>();
	private Map<String, String> fireWallTypeMap = new HashMap<String, String>();
CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
	
	public String getPolicyFileString() {
		return policyFileString;
	}
	public void setPolicyFileString(String policyFileString) {
		this.policyFileString = policyFileString;
	}
	
	public CommonsMultipartFile getPolicyFile() {
		return policyFile;
	}
	public void setPolicyFile(CommonsMultipartFile policyFile) {
		this.policyFile = policyFile;
	}
	
	public Map<String, String> getFireWallTypeMap() {
		fireWallTypeMap.put("CP", "CheckPoint");
		fireWallTypeMap.put("CG", "CyberGaurd");
		fireWallTypeMap.put("JP", "Juniper");
		fireWallTypeMap.put("PA", "Palo Alto");
		fireWallTypeMap.put("TP", "Template Firewall");
		return fireWallTypeMap;
	}
	public void setFireWallTypeMap(Map<String, String> fireWallTypeMap) {
		this.fireWallTypeMap = fireWallTypeMap;
	}
	public String getFireWallName() {
		return fireWallName;
	}
	public void setFireWallName(String fireWallName) {
		this.fireWallName = fireWallName;
	}
	public String getManagementRegion() {
		return managementRegion;
	}
	public void setManagementRegion(String managementRegion) {
		this.managementRegion = managementRegion;
	}
	public String getFireWallType() {
		return fireWallType;
	}
	public void setFireWallType(String fireWallType) {
		this.fireWallType = fireWallType;
	}
		
	public List<FirewallPolicy> getSearchResult() {
		return searchResult;
	}
	public void setSearchResult(List<FirewallPolicy> searchResult) {
		this.searchResult = searchResult;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMessageFlag() {
		return messageFlag;
	}
	public void setMessageFlag(String messageFlag) {
		this.messageFlag = messageFlag;
	}
	
	
	public List<FirewallPolicy> searchFireWall(String fireWallNameSearch, String fireWallTypeSearch, String managementRegionSearch) {

		List<FirewallPolicy> fwPolicyList = ccrBeanFactory.getUploadFirewallPolicyPersistable().searchFireWall( fireWallNameSearch, fireWallTypeSearch, managementRegionSearch);
		return fwPolicyList;		
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List executeSQLs(String sql) {
		List result = ccrBeanFactory.getUploadFirewallPolicyPersistable().executeSQL(sql);
		return result;
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void uploadFirewallStageData(ArrayList resultList) {
		ccrBeanFactory.getUploadFirewallPolicyPersistable().uploadFirewallStageData(resultList);
	}
}
