package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.domain.Base;

public class PortServiceMapping extends Base {

	 /** The port id. */
    private Long portId;

    /** The service type. */
    private String serviceType;

    /** The description. */
    private String description;

	/**
	 * @return the portId
	 */
	public Long getPortId() {
		return portId;
	}

	/**
	 * @param portId the portId to set
	 */
	public void setPortId(Long portId) {
		this.portId = portId;
	}

	/**
	 * @return the serviceType
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * @param serviceType the serviceType to set
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
    
    

}
