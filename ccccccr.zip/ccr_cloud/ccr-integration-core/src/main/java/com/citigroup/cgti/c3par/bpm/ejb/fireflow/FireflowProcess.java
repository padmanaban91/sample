package com.citigroup.cgti.c3par.bpm.ejb.fireflow;

import java.util.List;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;

/**
 * The Interface FireflowProcess.
 */
public  interface FireflowProcess {

	/**
	 * Creates the fire flow ticket.
	 *
	 * @param category the category
	 * @param tiRequestId the ti request id
	 * @return the string
	 */
	public String createFireFlowTicket (String category, long tiRequestId);

	/**
	 * Gets the notification status.
	 *
	 * @param tiRequestId the ti request id
	 * @return the notification status
	 */
	public boolean notifyFireflowProcess(long tiRequestId);
	
	/**
	 * Gets the fAF firewall categories.
	 *
	 * @param tiRequestId the ti request id
	 * @return the fAF firewall categories
	 */
	public List<String> getFAFFirewallCategories (long tiRequestId);
	
	/**
	 * Resolve fire flow ticket.
	 *
	 * @param category the category
	 * @param tiRequestId the ti request id
	 * @return the string
	 */
	public String resolveFireFlowTicket (String category, long tiRequestId);
}
