package com.citigroup.cgti.c3par.admin.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.admin.domain.ManageTpaMasterDTO;
import com.citigroup.cgti.c3par.admin.service.ManageTpaMasterService;
import com.citigroup.cgti.c3par.appsense.domain.TpaSubnetMaster;
import com.citigroup.cgti.c3par.configuation.QueryConstants;

@Service
public class ManageTpaMasterServiceImpl implements ManageTpaMasterService {

	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	@Override
	public void saveManageTpaMasterList(ManageTpaMasterDTO manageTpaMasterDTO) {
		
		Session session = sessionFactory.getCurrentSession();
		TpaSubnetMaster tpaSubnetMaster = new TpaSubnetMaster();

		tpaSubnetMaster.setIpAddress(manageTpaMasterDTO.getIpAddress());
		tpaSubnetMaster.setStartIPAddress(manageTpaMasterDTO.getStartIPAddress());
		tpaSubnetMaster.setEndIPAddress(manageTpaMasterDTO.getEndIPAddress());
		tpaSubnetMaster.setSubnet(manageTpaMasterDTO.getSubnet());
		tpaSubnetMaster.setNoOfHost(manageTpaMasterDTO.getNoOfHost());
		tpaSubnetMaster.setBroadCastAddress(manageTpaMasterDTO.getBroadCastAddress());
		tpaSubnetMaster.setBroadCastAddress(manageTpaMasterDTO.getBroadCastAddress());
		tpaSubnetMaster.setCreatedBy(manageTpaMasterDTO.getCreatedBy());
		tpaSubnetMaster.setCreated_date(new Date());
		tpaSubnetMaster.setIsActive("Y");
		
		session.saveOrUpdate(tpaSubnetMaster);
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly=true)
	@Override
	public List<TpaSubnetMaster> getIpDetails(String ipAddress) {
		log.info("Entering with ipAddress : "+ipAddress);
		Session session = sessionFactory.getCurrentSession();
		List<TpaSubnetMaster> list= new ArrayList<TpaSubnetMaster>();
		try
		{
			if(QueryConstants.WILDCARD_CHARACTER.equals(ipAddress)){
				Criteria criteria = session.createCriteria(TpaSubnetMaster.class);
				criteria.add(Restrictions.eq("isActive", "Y"));
				list=criteria.list();
			}
			else{
				Criteria criteria = session.createCriteria(TpaSubnetMaster.class);
				criteria.add(Restrictions.ilike("ipAddress",ipAddress,MatchMode.START));
				criteria.add(Restrictions.eq("isActive", "Y"));
				list=criteria.list();
			}
		} catch(Exception e) {
			e.printStackTrace();
			log.info("Exception "+e.getMessage());
		}
		return list;
	}
	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly=true)
	@Override
	public List<TpaSubnetMaster> getExactIpDetails(String ipAddress) {
		log.info("Entering with ipAddress : "+ipAddress);
		Session session = sessionFactory.getCurrentSession();
		List<TpaSubnetMaster> list= new ArrayList<TpaSubnetMaster>();
		try
		{
		Criteria criteria = session.createCriteria(TpaSubnetMaster.class);
		criteria.add(Restrictions.eq("ipAddress",ipAddress));
		criteria.add(Restrictions.eq("isActive", "Y"));
		list=criteria.list();
		log.info("list from DB : "+list);
		} catch(Exception e) {
			log.error("Exception "+e.getMessage());
			log.error(e.toString(), e);
		}
		return list;
	}

	@Transactional
	@Override
	public void deleteManageTpaMasterList(String ipAddress, String updatedUser) {
		log.info("Inside Delete Service Impl.........."+updatedUser);
		try{
			
		
		Session session = sessionFactory.getCurrentSession();
		
		SQLQuery sqlQuery = session.createSQLQuery("UPDATE TI_TPA_SUBNET_MASTER SET IS_ACTIVE = 'N' ,  UPDATED_DATE= sysdate , UPDATED_BY= UPPER('"+updatedUser+"') WHERE IP_ADDRESS = '"+ipAddress+"'");
		sqlQuery.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
			log.info("Exception "+e.getMessage());
			
		}
		
	}

}
