package com.citigroup.cgti.c3par.communication.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class CmpReqIdSearchProcess {
	
	private String cmpreqID;
	List<CMPRequest> cmpReqList;
	
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
	public String getCmpreqID() {
		return cmpreqID;
	}

	public void setCmpreqID(String cmpreqID) {
		this.cmpreqID = cmpreqID;
	}

	public List<CMPRequest> getCmpReqList() {
		return cmpReqList;
	}

	public void setCmpReqList(List<CMPRequest> cmpReqList) {
		this.cmpReqList = cmpReqList;
	}

	
	public List<CMPRequest> getCmpReqIdsList(String assignedUser, String cmpReqId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getCmpReqIdsList(assignedUser, cmpReqId);
	}
	

	public List<CMPRequest> getCmpReqIdSearchList(String cmpReqId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getCmpReqIdSearchList(cmpReqId);
	}
	
	public C3parUser getLoginAssignedUser(String ssoId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getLoginAssignedUser(ssoId); 
	}	
}
