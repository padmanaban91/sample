/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetail;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCLookup;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author ne36745
 *
 */
public class FirewallChangeProcess {
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}    
    private long tiProcessId;
    private long tiRequestId;
    private TIRequest tiRequest;

    private int rowCount;
    private int offset;
    private int limit;
    private int pageNo;
    private String field;
    private int totalPages;
    private boolean isSelectAll;
    private String isIpReg;
    private String fromPage;
    private String fafInfo;
    
    private RFCRequest rfcRequest;

    private List<RFCRequest> rfcRequests;
    
    private List<ServiceNowMessageError> serviceNowMessageErrors;
    
    
	public String getFafInfo() {
		return fafInfo;
	}

	public void setFafInfo(String fafInfo) {
		this.fafInfo = fafInfo;
	}

	public RFCRequest getRfcRequest() {
		return rfcRequest;
	}

	public void setRfcRequest(RFCRequest rfcRequest) {
		this.rfcRequest = rfcRequest;
	}

	public String getFromPage() {
		return fromPage;
	}

	public void setFromPage(String fromPage) {
		this.fromPage = fromPage;
	}

	public long getTiProcessId() {
		return tiProcessId;
	}

	public void setTiProcessId(long tiProcessId) {
		this.tiProcessId = tiProcessId;
	}

	public long getTiRequestId() {
		return tiRequestId;
	}

	public void setTiRequestId(long tiRequestId) {
		this.tiRequestId = tiRequestId;
	}

	public TIRequest getTiRequest() {
		return tiRequest;
	}

	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public boolean isSelectAll() {
		return isSelectAll;
	}

	public void setSelectAll(boolean isSelectAll) {
		this.isSelectAll = isSelectAll;
	}

	public String getIsIpReg() {
		return isIpReg;
	}

	public void setIsIpReg(String isIpReg) {
		this.isIpReg = isIpReg;
	}

	public List<RFCRequest> getRfcRequests() {
		return rfcRequests;
	}

	public void setRfcRequests(List<RFCRequest> rfcRequests) {
		this.rfcRequests = rfcRequests;
	}
	
	public List<ServiceNowMessageError> getServiceNowMessageErrors() {
		return serviceNowMessageErrors;
	}

	public void setServiceNowMessageErrors(
			List<ServiceNowMessageError> serviceNowMessageErrors) {
		this.serviceNowMessageErrors = serviceNowMessageErrors;
	}

	
	public List<RFCRequest> getRFCRequestList(TIRequest tiRequest, String con_type) {
		return ccrBeanFactory.getRfc().getRFCRequestList(tiRequest, con_type);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public String storeRfc(Long tiRequestId,String conType) {
		return ccrBeanFactory.getRfc().storeRfc(tiRequestId, conType);
	}
	
	
	public List<RFCRequest> getRFCRequestList(Long processId, String con_type) {
		return ccrBeanFactory.getRfc().getRFCRequestList(processId, con_type);
	}
	
	
	public String getSnUrl() {
		return ccrBeanFactory.getRfc().getSnUrl();
	}

	
	public boolean hasSNOWErrorMsg(Long rfcID) {
		return ccrBeanFactory.getRfc().hasSNOWErrorMsg(rfcID);
	}
	
	
	public RFCRequest getRFCDetails(RFCRequest rfcRequest,String sectionName, String conType) {
		 return ccrBeanFactory.getRfc().getRFCDetails(rfcRequest, sectionName, conType);
	}
	
	
	public String getFirewallAccessFormTextByRFC(RFCRequest rfcRequest) {
		return ccrBeanFactory.getAccessFormText().getFirewallAccessFormTextByRFC(rfcRequest);		
	}
	
	
	public String getProxyAccessFormTextByRFC(RFCRequest rfcRequest) {
		return ccrBeanFactory.getAccessFormText().getProxyAccessFormTextByRFC(rfcRequest);		
	}
	
	
	public List<ServiceNowMessageError> getSNOWErrorMsg(Long rfcID) {
		return ccrBeanFactory.getRfc().getSNOWErrorMsg(rfcID);		
	}
	
    
	
    public Map<String,String> getDivisionCodeMap(Long rfcRequest) {
		return ccrBeanFactory.getRfc().getDivisionCodeMap(rfcRequest);
	}
    
	
    public Map<String,String> getLocation() {
		return ccrBeanFactory.getRfc().getLocation();
	}
   
	
    public Map<String,String> getRequestRuleType() {
		return ccrBeanFactory.getRfc().getRequestRuleType();
	}
    
	
    public Integer storeRFCStatus(String flag,Long tiReqId,String conType) {
		return ccrBeanFactory.getRfc().storeRFCStatus(flag, tiReqId, conType);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public long  storeManualChangeRecord(RFCRequestDTO rfcRequestDTO) throws Exception {
		return ccrBeanFactory.getRfc().storeManualChangeRecord(rfcRequestDTO);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void cancelChange(Long chgNum) {
		ccrBeanFactory.getRfc().cancelChange(chgNum);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void rescheduleChangeRecord(RFCRequest rfcRequest) {
		ccrBeanFactory.getRfc().rescheduleChangeRecord(rfcRequest);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public Long addRFCDetail(RFCDetail rfcDetail) {
		return ccrBeanFactory.getRfc().addRFCDetail(rfcDetail);
	}
	
	
	public RFCLookup getRFCLookup(String paramName) {
		return ccrBeanFactory.getRfc().getRFCLookup(paramName);
	}
	
	
	public RFCDetail getRFCDetail(long rfcRequestID,String sectionName) {
		return ccrBeanFactory.getRfc().getRFCDetail(rfcRequestID, sectionName);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateRFCDetail(RFCDetail rfcDetail) {
		ccrBeanFactory.getRfc().updateRFCDetail(rfcDetail);
	}
}
