package com.citigroup.cgti.c3par.appsense.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * The Class AppsenseADGroup.
 */
public class AppsenseADGroup extends Base implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /** The name. */
    private String name;

    /** The is new. */
    private String isNew="Y";

    /** The policy name. */
    private String policyName;

    /** The policy id. */
    private String policyID;

    /**
     * Gets the name.
     * 
     * @return the name
     */
    public String getName() {
	return name;
    }

    /**
     * Sets the name.
     * 
     * @param name
     *            the new name
     */
    public void setName(String name) {
	this.name = name;
    }

    /**
     * Gets the checks if is new.
     * 
     * @return the checks if is new
     */
    public String getIsNew() {
	return isNew;
    }

    /**
     * Sets the checks if is new.
     * 
     * @param isNew
     *            the new checks if is new
     */
    public void setIsNew(String isNew) {
	this.isNew = isNew;
    }

    /**
     * Gets the policy name.
     * 
     * @return the policy name
     */
    public String getPolicyName() {
	return policyName;
    }

    /**
     * Sets the policy name.
     * 
     * @param policyName
     *            the new policy name
     */
    public void setPolicyName(String policyName) {
	this.policyName = policyName;
    }

    /**
     * Gets the policy id.
     * 
     * @return the policy id
     */
    public String getPolicyID() {
	return policyID;
    }

    /**
     * Sets the policy id.
     * 
     * @param policyID
     *            the new policy id
     */
    public void setPolicyID(String policyID) {
	this.policyID = policyID;
    }

}
