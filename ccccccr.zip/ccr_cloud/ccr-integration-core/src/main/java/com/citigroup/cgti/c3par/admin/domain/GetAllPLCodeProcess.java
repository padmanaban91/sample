package com.citigroup.cgti.c3par.admin.domain;

import java.util.ArrayList;
import java.util.List;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * The Class GetAllPLCodeForm.
 */
public class GetAllPLCodeProcess extends Base
{

    /** The plcode. */
    private String plcode;

    /** The description. */
    private String description;

    /** The business unit. */
    private String businessUnit;
    
    private String display;
    
    private List plCodesList = new ArrayList();

    public List getPlCodesList() {
		return plCodesList;
	}

	public void setPlCodesList(List plCodesList) {
		this.plCodesList = plCodesList;
	}

	/**
     * Gets the business unit.
     *
     * @return the business unit
     */
    public String getBusinessUnit() {
	return businessUnit;
    }

    /**
     * Sets the business unit.
     *
     * @param businessUnit the new business unit
     */
    public void setBusinessUnit(String businessUnit) {
	this.businessUnit = businessUnit;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
	return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
	this.description = description;
    }

    /**
     * Gets the plcode.
     *
     * @return the plcode
     */
    public String getPlcode() {
	return plcode;
    }

    /**
     * Sets the plcode.
     *
     * @param plcode the new plcode
     */
    public void setPlcode(String plcode) {
	this.plcode = plcode;
    }

	public String getDisplay() {
		return display;
	}

	public void setDisplay(String display) {
		this.display = display;
	}
}