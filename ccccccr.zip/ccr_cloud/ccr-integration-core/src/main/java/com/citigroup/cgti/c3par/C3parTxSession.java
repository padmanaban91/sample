package com.citigroup.cgti.c3par;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.datasource.DataSourceUtils;

import com.citigroup.cgti.c3par.util.C3parProperties;



/**
 * The Class C3parTxSession.
 */
public class C3parTxSession extends C3parSession {

    /** The m_data source. */
    private DataSource m_dataSource =null;

    /** The log. */
    private final Logger log = Logger.getLogger(getClass().getName());


    //	==================================================================================
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.C3parSession#obtainConnection()
     */
    protected Connection obtainConnection() 
    throws SQLException
    {
	Connection connection = null;
	try {
	    if (null != m_dataSource) {
		connection = DataSourceUtils.getConnection(m_dataSource);
	    }else{
		InitialContext ctx = new InitialContext();
		DataSource source = (DataSource) ctx.lookup(C3parProperties.JDBC_DS);
		if (null != source) {
		    connection = source.getConnection();
		}	
	    }
	    if(connection == null)
		throw new Exception ("Failed to obtain a database connection");
	} catch (Exception e) {
	    log.error(e.getMessage(),e);
	}
	return connection;
    }



    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.C3parSession#setDataSource(javax.sql.DataSource)
     */
    public void setDataSource(DataSource dataSource) {
	m_dataSource = dataSource;
    }

}
