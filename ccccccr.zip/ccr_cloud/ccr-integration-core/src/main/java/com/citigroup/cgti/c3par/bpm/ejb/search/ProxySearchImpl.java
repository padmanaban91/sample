  package com.citigroup.cgti.c3par.bpm.ejb.search;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.bpm.ejb.domain.LookupDTO;
import com.citigroup.cgti.c3par.webtier.helper.LookupNameHelper;
import com.mentisys.dao.DatabaseException;


/**
 * The Class ProxySearchImpl.
 */
public class ProxySearchImpl implements ISearchProxy {

	private JdbcTemplate jdbcTemplate;
	
	 
	/** The log. */
	private Logger log = Logger.getLogger(ProxySearchImpl.class);

	 private static final String RIGHTPLACEMENTSQL = "select id from generic_lookup where upper(value1)=upper('"+LookupNameHelper.RIGHT_PLACEMENT+"')";
	 
	/**
	 * Right placement id.
	 *
	 * @return the long
	 * @throws DatabaseException the database exception
	 */
	private Long rightPlacementId() throws DatabaseException{
		
		Long lookupId = null;
		 
			
		try {
			SqlRowSet rs = jdbcTemplate.queryForRowSet( RIGHTPLACEMENTSQL );
		
			while(rs.next())
				lookupId = Long.valueOf(rs.getLong(1));
				
		
		} catch (Exception e) {
			log.error("Exception during query :- " ,e);
			throw new DatabaseException("Could not run query = "+ RIGHTPLACEMENTSQL, e);
		} 

		return lookupId;
		
	}
	
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.search.ISearchProxy#getProxyInstance()
	 */
	
	public List getProxyInstance()throws Exception{
		log.info("get Proxy Instance");
	    Long lookUpId = rightPlacementId();
	
	    final  String sql="select id,name from prx_instance_master where is_RightPlacement='" + lookUpId +"' and Record_Type='BASIC' order by name";;
		
		 
		return getFromLookup(sql.toString());
	
	}
	
	/**
	 * Gets the from lookup.
	 *
	 * @param sql the sql
	 * @return the from lookup
	 * @throws Exception the exception
	 */
	private ArrayList getFromLookup(String sql) throws Exception {
	 
		ArrayList<LookupDTO> objList = new ArrayList<LookupDTO>();

		try {
			log.debug("Inside the lookup"+ sql);
			   
			  	SqlRowSet rs = jdbcTemplate.queryForRowSet(sql);
			    
			  	while(rs.next()) 
			    	objList.add( new LookupDTO(rs.getLong(1),rs.getString(2),null) );
		 	      // obj.setValue(rs.getLong(1));; obj.setName(rs.getString(2));
			      
	   	}//end of try
	  	 catch (Exception e)
			{
	  		    log.error("Could not load ", e);
				throw new DatabaseException("Could not load ", e);
			}
		log.debug("Size of Value Object List is "+ objList.size());
		return objList;

	}

	
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.search.ISearchProxy#getProxyRegion(java.lang.String)
	 */
	public List getProxyRegion(String recordType) throws Exception {
		List<String> regionList = new ArrayList<String>();
		final String sql="select distinct region from prx_instance_master where record_type='"+recordType+"'";
		 			
		try {
			SqlRowSet rs = jdbcTemplate.queryForRowSet(sql);
			
			while(rs.next())
				regionList.add(rs.getString(1));
				
			 
		} catch (Exception e) {
			log.error("Exception during query :- ", e);
			throw new DatabaseException("Could not run query = "+ sql, e);
		}  

		return regionList;
	}

	
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.search.ISearchProxy#getPrxInstanceNameList(java.lang.String, java.lang.String)
	 */
	public List getPrxInstanceNameList(String recordType, String region) throws Exception {
		log.info("get Proxy Instance");
		final String sql="select id,name from prx_instance_master where region='" + region +"' and Record_Type='"+ recordType + "' order by name";;
		return  ( getFromLookup(sql) );
	}

	 

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	 
}
