package com.citigroup.cgti.c3par.domain;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Date;


/**
 * The Class Base.
 */
public class Base implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The id. */
    private Long id;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /** The is selected. */
    private boolean isSelected;

    /** The is select all. */
    private boolean isSelectAll;
    
    private String isNew;
    
    private boolean disabled;
    
    private Long userId;

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
	this.id = id;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
	return id;
    }

    /**
     * Checks if is new.
     *
     * @return true, if is new
     */
    public boolean isNew() {
	return (this.id == null);
    }


    /* (non-Javadoc)
     * @see java.lang.Object#clone()
     */
    public Object clone(){

	try {
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    ObjectOutputStream oos = new ObjectOutputStream(baos);
	    oos.writeObject(this);
	    ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
	    ObjectInputStream ois = new ObjectInputStream(bais);
	    Object deepCopy = ois.readObject();
	    return deepCopy;
	} catch (Exception e) {
	    // TODO Auto-generated catch block
	    throw new RuntimeException (e);
	} 
    }

    /**
     * Gets the created_date.
     *
     * @return the created_date
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date the new created_date
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return the updated_date
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date the new updated_date
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }

    /**
     * Checks if is selected.
     *
     * @return true, if is selected
     */
    public boolean isSelected() {
	return isSelected;
    }

    /**
     * Sets the selected.
     *
     * @param isSelected the new selected
     */
    public void setSelected(boolean isSelected) {
	this.isSelected = isSelected;
    }



    /**
     * Checks if is select all.
     *
     * @return Returns the isSelectAll.
     */
    public boolean isSelectAll() {
	return isSelectAll;
    }

    /**
     * Sets the select all.
     *
     * @param isSelectAll The isSelectAll to set.
     */
    public void setSelectAll(boolean isSelectAll) {
	this.isSelectAll = isSelectAll;
    }

    /**
     * @return the isNew
     */
    public String getIsNew() {
        return isNew;
    }

    /**
     * @param isNew the isNew to set
     */
    public void setIsNew(String isNew) {
        this.isNew = isNew;
    }

	/**
	 * @return the disabled
	 */
	public boolean isDisabled() {
		return disabled;
	}

	/**
	 * @param disabled the disabled to set
	 */
	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}
    
	
    
}
