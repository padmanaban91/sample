package com.citigroup.cgti.c3par.domain.logic;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.dao.C3parProcessRoleXrefDAO;
import com.citigroup.cgti.c3par.dao.CitiContactDAO;
import com.citigroup.cgti.c3par.dao.SecurityRoleDAO;
import com.citigroup.cgti.c3par.dao.TIProcessDAO;
import com.citigroup.cgti.c3par.dao.TIProcessStatusDAO;
import com.citigroup.cgti.c3par.dao.TIProcessTypeDAO;
import com.citigroup.cgti.c3par.dao.TIRequestDAO;
import com.citigroup.cgti.c3par.dao.TIRequestStatusDAO;
import com.citigroup.cgti.c3par.dao.TIRequestTaskDAO;
import com.citigroup.cgti.c3par.dao.TIRequestTypeDAO;
import com.citigroup.cgti.c3par.dao.TIStatusTypeDAO;
import com.citigroup.cgti.c3par.dao.TITaskTypeDAO;
import com.citigroup.cgti.c3par.dao.ThirdPartyContactDAO;
import com.citigroup.cgti.c3par.dao.lookup.RoleLookup;
import com.citigroup.cgti.c3par.domain.ApprovalVO;
import com.citigroup.cgti.c3par.domain.BusinessCase;
import com.citigroup.cgti.c3par.domain.BusinessUnit;
import com.citigroup.cgti.c3par.domain.Person;
import com.citigroup.cgti.c3par.domain.Region;
import com.citigroup.cgti.c3par.domain.Sector;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.domain.WorkflowTask;
import com.citigroup.cgti.c3par.lookup.TIProcessSQL;
import com.citigroup.cgti.c3par.model.C3parProcessRoleXrefEntity;
import com.citigroup.cgti.c3par.model.CitiContactEntity;
import com.citigroup.cgti.c3par.model.RoleEntity;
import com.citigroup.cgti.c3par.model.TIProcessEntity;
import com.citigroup.cgti.c3par.model.TIProcessStatusEntity;
import com.citigroup.cgti.c3par.model.TIRequestEntity;
import com.citigroup.cgti.c3par.model.TIRequestStatusEntity;
import com.citigroup.cgti.c3par.model.TIRequestTaskEntity;
import com.citigroup.cgti.c3par.model.TIRequestTypeEntity;
import com.citigroup.cgti.c3par.model.TIStatusTypeEntity;
import com.citigroup.cgti.c3par.model.ThirdPartyContactEntity;
import com.citigroup.cgti.c3par.util.C3parStaticNames;


//import com.citigroup.cgti.c3par.dao

/**
 * The Class TIProcessService.
 */
public class TIProcessService {

    /** The ti process dao. */
    private TIProcessDAO tiProcessDao;    

    /** The process type dao. */
    private TIProcessTypeDAO processTypeDao;

    /** The ti process status dao. */
    protected TIProcessStatusDAO tiProcessStatusDao;

    /** The ti status type dao. */
    protected TIStatusTypeDAO tiStatusTypeDao;

    /** The ti request dao. */
    private TIRequestDAO tiRequestDao;

    /** The ti request status dao. */
    private TIRequestStatusDAO tiRequestStatusDao;

    /** The security role dao. */
    private SecurityRoleDAO securityRoleDao;

    /** The ti process sql. */
    protected TIProcessSQL tiProcessSQL;

    /** The process role xref dao. */
    private C3parProcessRoleXrefDAO processRoleXrefDao;

    /** The ti request task dao. */
    private TIRequestTaskDAO tiRequestTaskDao;

    /** The ti task type dao. */
    private TITaskTypeDAO tiTaskTypeDao;

    /** The citi contact dao. */
    private CitiContactDAO citiContactDao;

    /** The third party contact dao. */
    private ThirdPartyContactDAO thirdPartyContactDao;

    /** The ti request type dao. */
    private TIRequestTypeDAO tiRequestTypeDao;

    /** The ti process status map. */
    protected Map tiProcessStatusMap=new HashMap();

    /** The mail sender. */
    protected MailSender mailSender;

    /** The template message. */
    protected SimpleMailMessage templateMessage;

    /**
     * Sets the mail sender.
     *
     * @param mailSender the new mail sender
     */
    public void setMailSender(MailSender mailSender) {
	this.mailSender = mailSender;
    }

    /**
     * Sets the template message.
     *
     * @param templateMessage the new template message
     */
    public void setTemplateMessage(SimpleMailMessage templateMessage) {
	this.templateMessage = templateMessage;
    }



    /** The log. */
    private Logger log = Logger.getLogger(this.getClass().getName());


    /** The Constant ACL. */
    public static final String ACL = "ACL Access";

    //these status match the status in ti_request_type,ti_status_type tables
    /** The Constant TIReqType_Create. */
    public static final String TIReqType_Create = "Create";

    /** The Constant TIReqType_Maintain. */
    public static final String TIReqType_Maintain = "Maintain";

    /** The Constant TIReqStat_Progress. */
    public static final String TIReqStat_Progress = "InProgress";

    /** The Constant TIProcStat_Planning. */
    public static final String TIProcStat_Planning = "Planning";

    /** The Constant TIReqStat_Complete. */
    public static final String TIReqStat_Complete = "Completed";

    /** The Constant TIProcStat_Termination. */
    public static final String TIProcStat_Termination = "Termination";

    /** The Constant TIProcStat_Active. */
    public static final String TIProcStat_Active = "Active";

    /** The Constant TIProcStat_Maintenance. */
    public static final String TIProcStat_Maintenance = "Maintenance";

    /** The Constant TIProcStat_Terminated. */
    public static final String TIProcStat_Terminated = "Terminated";

    /** The Constant TIReqType_Terminate. */
    public static final String TIReqType_Terminate = "Terminate";

    /** The Constant TIReqType_ACV. */
    public static final String TIReqType_ACV = "ACV";

    /** The Constant TIReqType_ManageUserContacts. */
    public static final String TIReqType_ManageUserContacts = "ManageContacts";


    /** The Constant TIReqType_MaintainUserContacts. */
    public static final String TIReqType_MaintainUserContacts = "Maintain Contacts";


    /**
     * Sets the ti request task dao.
     *
     * @param tiRequestTaskDao the new ti request task dao
     */
    public void setTiRequestTaskDao(TIRequestTaskDAO tiRequestTaskDao) {
	this.tiRequestTaskDao = tiRequestTaskDao;
    }

    /**
     * Sets the ti task type dao.
     *
     * @param tiTaskTypeDao the new ti task type dao
     */
    public void setTiTaskTypeDao(TITaskTypeDAO tiTaskTypeDao) {
	this.tiTaskTypeDao = tiTaskTypeDao;
    }

    /**
     * Sets the ti request type dao.
     *
     * @param tiRequestTypeDao the new ti request type dao
     */
    public void setTiRequestTypeDao(TIRequestTypeDAO tiRequestTypeDao) {
	this.tiRequestTypeDao = tiRequestTypeDao;
    }

    /**
     * Sets the ti process status dao.
     *
     * @param tiProcessStatusDao the new ti process status dao
     */
    public void setTiProcessStatusDao(TIProcessStatusDAO tiProcessStatusDao) {
	this.tiProcessStatusDao = tiProcessStatusDao;
    }

    /**
     * Sets the ti status type dao.
     *
     * @param tiStatusTypeDao the new ti status type dao
     */
    public void setTiStatusTypeDao(TIStatusTypeDAO tiStatusTypeDao) {
	this.tiStatusTypeDao = tiStatusTypeDao;
    }

    /**
     * Sets the ti process dao.
     *
     * @param tiProcessDao the new ti process dao
     */
    public void setTiProcessDao(TIProcessDAO tiProcessDao) {
	this.tiProcessDao = tiProcessDao;
    }

    /**
     * Sets the process type dao.
     *
     * @param processTypeDao the new process type dao
     */
    public void setProcessTypeDao(TIProcessTypeDAO processTypeDao) {
	this.processTypeDao = processTypeDao;
    }

    /**
     * Sets the security role dao.
     *
     * @param securityRoleDao the new security role dao
     */
    public void setSecurityRoleDao(SecurityRoleDAO securityRoleDao) {
	this.securityRoleDao = securityRoleDao;
    }

    /**
     * Sets the ti request dao.
     *
     * @param tiRequestDao the new ti request dao
     */
    public void setTiRequestDao(TIRequestDAO tiRequestDao) {
	this.tiRequestDao = tiRequestDao;
    }

    /**
     * Sets the ti request status dao.
     *
     * @param tiRequestStatusDao the new ti request status dao
     */
    public void setTiRequestStatusDao(TIRequestStatusDAO tiRequestStatusDao) {
	this.tiRequestStatusDao = tiRequestStatusDao;
    }

    /**
     * Sets the ti process sql.
     *
     * @param tiProcessSQL the new ti process sql
     */
    public void setTiProcessSQL(TIProcessSQL tiProcessSQL) {
	this.tiProcessSQL = tiProcessSQL;
    }


    /**
     * Sets the process role xref dao.
     *
     * @param processRoleXrefDao the new process role xref dao
     */
    public void setProcessRoleXrefDao(C3parProcessRoleXrefDAO processRoleXrefDao) {
	this.processRoleXrefDao = processRoleXrefDao;
    }

    /**
     * Sets the citi contact dao.
     *
     * @param citiContactDao the new citi contact dao
     */
    public void setCitiContactDao(CitiContactDAO citiContactDao) {
	this.citiContactDao = citiContactDao;
    }

    /**
     * Sets the third party contact dao.
     *
     * @param thirdPartyContactDao the new third party contact dao
     */
    public void setThirdPartyContactDao(ThirdPartyContactDAO thirdPartyContactDao) {
	this.thirdPartyContactDao = thirdPartyContactDao;
    }
    //this method sets tiprocessid and applicationid in iprequest object
    /**
     * Creates the business case.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void createBusinessCase(TIProcess tiProcess) throws Exception {
	//BPM INTEGRATION CHANGE
	/*TIProcessEntity tiProcEntity = createTIProcessEntity(tiProcess);
		tiProcessDao.update(tiProcEntity);
		tiProcess.setId(tiProcEntity.getId());
		log.info(" INFO >> IPPROCESS  CREATED WITH ID "+tiProcEntity.getId()+" FOR REQUESTOR "+tiProcess.getRequestor().getSoeID());
		//set tirequest
		createTIRequest(tiProcess); */
	List relContactList=null;

	//		assign thirdparty,citigroupcontacts on a relationship as contacts on ipregistration request.
	Long relationshipID=tiProcess.getRelationship().getId();
	//if(C3parStaticNames.)
	//id relationship is nonciti send false and if citi send true
	if(C3parStaticNames.THIRD_PARTY.equalsIgnoreCase(tiProcess.getRelationship().getRelationshipType()) ||
		C3parStaticNames.U_TURN.equalsIgnoreCase(tiProcess.getRelationship().getRelationshipType()))
	    relContactList=tiProcessSQL.getRelationshipContacts(relationshipID,false);
	else
	    relContactList=tiProcessSQL.getRelationshipContacts(relationshipID,true); 
	if(relContactList!=null && relContactList.size()>0){
	    // isActive filed false so get all ipprocess contacts which are active(assigned) and inactive(unassigned)
	    //if  relationshipcontacts has been assigned(isActive field is 'Y') as ipprocesscontact dont add them else add them 
	    //if relationshipcontacts has been unassigned(isActive field is 'N') as ipprocesscontact dont add them. 
	    List processContactList=tiProcessSQL.getProcessContacts(tiProcess.getId(), false);


	    Iterator relContactItr=relContactList.iterator();
	    while(relContactItr.hasNext()){
		boolean contactExists=false;
		Person relContact=(Person)relContactItr.next();
		Iterator procContactItr=processContactList.iterator();
		if(procContactItr!=null){
		    while(procContactItr.hasNext()){
			Person procContact=(Person)procContactItr.next();
			if(procContact.getContactID().equals(relContact.getContactID())&& procContact.isCitiEmployee()==relContact.isCitiEmployee()){
			    contactExists=true;
			    break;
			}
		    }
		}
		if(!contactExists)
		    assignContactsToProcess(tiProcess,relContact);
	    }
	}
    }
    //set tiprocess
    /**
     * Creates the ti process entity.
     *
     * @param tiProcess the ti process
     * @return the tI process entity
     * @throws Exception the exception
     */
    protected TIProcessEntity createTIProcessEntity(TIProcess tiProcess)	throws Exception {
	log.debug("TIPROC createTIProcessEntity");
	//TIProcessSQL tpProcSQL = new TIProcessSQL();
	BusinessCase businessCase=tiProcess.getBusinessCase();
	Long tiProcRequestID=tiProcess.getId();
	TIProcessEntity tiProcEntity = new TIProcessEntity();
	if (!tiProcess.isNew()) {
	    tiProcEntity = tiProcessDao.get(tiProcRequestID,false);
	    chkTIProcessEntityIsNull(tiProcEntity,tiProcess);
	    //if in maintenance businesscase page will have an extra maintenance comments filed 
	    /*if(TIReqType_Maintain.equals(tiProcess.getTiRequest().getTiRequestType().getName()))
				tiProcEntity.setProcessUpdateReason(tiProcess.getBusinessCase().getUpdateComments()); */
	}
	else{
	    //When creating tiprocess first time its version is by default set to 1
	    tiProcEntity.setVersionNumber(Integer.valueOf(1));
	    tiProcEntity.setCreateDate(new Date());

	}

	List<Region> regionID =  new ArrayList<Region>();
	Long sectorID = null;
	Long buID = null;
	if (businessCase.getRegionList() != null)
	    regionID = businessCase.getRegionList();
		log.debug("RegionList:createTiProcessEntity:"+regionID.size());
	if (businessCase.getSector() != null)
	    sectorID = businessCase.getSector().getId();
	if (businessCase.getBusinessUnit() != null)
	    buID = businessCase.getBusinessUnit().getId();
	//set citihierarchymaster only if all combinations are given.
	if (regionID != null && sectorID != null && buID != null) {
	    List<Long> citiHierarchyMasterID = tiProcessSQL.getCitiHerarchyMasterID(businessCase.getRegionList(), businessCase.getSector().getId(),
		    businessCase.getBusinessUnit().getId());
	    if (citiHierarchyMasterID == null)
		throw new BusinessException(
		"No Entitlement id is Associated With given Region-Sector-BusinessUnit Combination ");
	    tiProcEntity.setCitiHierarchyMasterID(citiHierarchyMasterID);
	}

	tiProcEntity.setProcessName(tiProcess.getName());
	if (tiProcRequestID == null) {
	    tiProcEntity.setProcessTypeId(businessCase.getProcessType().getId());
	    /*	tiProcEntity.setCreateDate(new Date());
			if(tiProcess.getRequestor().getSoeID()!=null){
			Long userID = tiProcessSQL.getCurrentUserId(tiProcess.getRequestor().getSoeID());
			tiProcEntity.setUserId(userID);
			}*/
	    tiProcEntity.setRelationshipId(tiProcess.getRelationship().getId());
	}
	tiProcEntity.setProcessActivityMode("NEW");
	tiProcEntity.setIsDeleted("N");
	return tiProcEntity;
    }
    //create tirequest and tirequeststatus
    /**
     * Creates the ti request.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void createTIRequest(TIProcess tiProcess) throws Exception{
	if(tiProcess.getId()==null)
	    throw new ApplicationException(" ProcessID is null");
	Long tiReqID=tiProcess.getTiRequest().getId();
	TIRequestEntity tiReqEntity;
	/*	if(tiProcess.getId()!=null)
	 		throw new Exception("Process id not null "); */
	if(tiReqID==null){
	    tiReqEntity=new TIRequestEntity();
	    tiReqEntity.setProcessId(tiProcess.getId());

	    if(tiProcess.getRequestor().getSoeID()!=null){				
		Long userID = tiProcessSQL.getCurrentUserId(tiProcess.getRequestor().getSoeID());
		tiReqEntity.setUserId(userID);
	    }
	    tiReqEntity.setCreateDate(new Date());

	    tiReqEntity.setTiRequestTypeId(getTIRequestTypeID(tiProcess));
	    //if requesttype is create --implies first version of tirequest
	    if( TIProcessService.TIReqType_Create.equalsIgnoreCase(tiProcess.getTiRequest().getTiRequestType().getName()))
		tiReqEntity.setVersionNumber(Integer.valueOf(1));
	    else{
		tiReqEntity.setVersionNumber(Integer.valueOf(tiProcess.getTiRequest().getVersionNumber()));
		Calendar c1 = Calendar.getInstance();
		c1.setTime(new Date());
		c1.add(Calendar.DATE,14);
		tiReqEntity.setPlannedCompletionDate(new Date(c1.getTimeInMillis()));
		tiProcess.getTiRequest().setPlannedCompletionDate(tiReqEntity.getPlannedCompletionDate());
	    }
	    tiReqEntity.setIsDeleted("N");
	    //			By defalut set the Priority to BAU

	    if(tiProcess.getTiRequest().getPriority().getValue1()==null)
		tiProcess.getTiRequest().getPriority().setValue1(TIRequest.BAU);

	    tiReqEntity.setPriorityId(tiProcessSQL.getGenericLookupID(tiProcess.getTiRequest().getPriority().getValue1()));
	    String deadline=null;
	    if(TIRequest.ACV.equalsIgnoreCase(tiProcess.getTiRequest().getTiRequestType().getName()))
		deadline=tiProcessSQL.getGenericLookupValue(tiProcess.getTiRequest().getTiRequestType().getName()+"Deadline");
	    else
		deadline=tiProcessSQL.getGenericLookupValue(tiProcess.getTiRequest().getPriority().getValue1()+"Deadline");

	    if(chkIsNull(deadline))
		throw new Exception(" Request Deadline value is null for ProcessId "+tiProcess.getId());

	    Calendar cal=Calendar.getInstance();

	    cal.setTime(tiReqEntity.getCreateDate());

	    //System.out.println(" time before trunc "+cal.getTime());
	    cal.set(Calendar.HOUR_OF_DAY, 0);
	    cal.set(Calendar.MINUTE, 0);
	    cal.set(Calendar.SECOND, 0);
	    cal.set(Calendar.MILLISECOND, 0);

	    //System.out.println(" time after trunc "+cal.getTime());
	    cal.add(Calendar.HOUR,19);
	    cal.add(Calendar.MINUTE,Integer.valueOf(deadline).intValue());
	    tiReqEntity.setRequestDeadline(cal.getTime());

	    tiRequestDao.update(tiReqEntity);
	    tiProcess.getTiRequest().setId(tiReqEntity.getId());
	    log.info(" INFO >> IPREQUEST CREATED WITH ID "+tiReqEntity.getId()+" FOR IPPROCESS ID "+tiProcess.getId());
	    //createTIRequestStatus(tiProcess,TIProcessService.TIReqStat_Progress);
	    //createTIProcessStatus(tiProcess);
	}
	/*	else
	 		updateTIRequestCreateDate(tiProcess);*/

    }

    /**
     * Gets the tI request type id.
     *
     * @param tiProcess the ti process
     * @return the tI request type id
     * @throws Exception the exception
     */
    Long getTIRequestTypeID (TIProcess tiProcess) throws Exception{
	String reqStatus=tiProcess.getTiRequest().getTiRequestType().getName();
	if(reqStatus==null)
	    reqStatus=TIProcessService.TIReqType_Create;
	List tiStatusTypeID=tiRequestTypeDao.findByRequestType(reqStatus);
	if(tiStatusTypeID==null||(tiStatusTypeID!=null && tiStatusTypeID.size()==0))
	    throw new ApplicationException("No ID is Associated with TIRequestType "+reqStatus);
	tiProcess.getTiRequest().getTiRequestType().setName(reqStatus);
	return (Long)tiStatusTypeID.get(0);

    }

    /**
     * Creates the ti request status.
     *
     * @param tiProcess the ti process
     * @param status the status
     * @throws Exception the exception
     */
    void createTIRequestStatus(TIProcess tiProcess,String status) throws Exception{
	if(status == null)
	    throw new ApplicationException("Status is null when creating tirequest status ");
	Long statusID=findTIStatusID(status);
	TIRequestStatusEntity tiReqStatEntity=new TIRequestStatusEntity();
	tiReqStatEntity.setStatusId(statusID);
	chkTIRequestIDIsNull(tiProcess);
	tiReqStatEntity.setRequestId(tiProcess.getTiRequest().getId());
	tiReqStatEntity.setStatusDate(new Date());
	tiRequestStatusDao.update(tiReqStatEntity);
	tiProcess.getTiRequest().getTiRequestStatus().setName(status);
	log.info(" INFO >> IPREQUESTSTATUS  CREATED WITH ID "+tiReqStatEntity.getId()+" FOR IPREQUEST ID "+tiProcess.getTiRequest().getId()+" with status "+status);
    }

    /**
     * Creates the ti process status.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    void createTIProcessStatus(TIProcess tiProcess) throws Exception{
	String reqStatus=tiProcess.getTiRequest().getTiRequestType().getName();
	if(reqStatus==null)
	    reqStatus=TIProcessService.TIReqType_Create;
	Map reqToProcStatMap=new HashMap();
	reqToProcStatMap.put("Create","Planning");
	reqToProcStatMap.put("Maintain","Maintenance");
	reqToProcStatMap.put("Terminate","Termination");
	String mapProcStat=(String)reqToProcStatMap.get(reqStatus);
	createTIProcessStatusEntity(tiProcess,mapProcStat);
	/*Long statusID=findTIStatusID( mapProcStat);
			TIProcessStatusEntity statProcEntit=new TIProcessStatusEntity();
         	statProcEntit.setProcessId(tiProcess.getId());
         	statProcEntit.setStatusId(statusID);
         	statProcEntit.setStatusDate(new Date());
         	tiProcessStatusDao.update(statProcEntit);
         	log.info(" INFO >> IPPROCESS STATUS  CREATED WITH ID "+statProcEntit.getId()+" FOR IPPROCESS ID "+tiProcess.getId());*/
    }

    /**
     * Creates the ti process status entity.
     *
     * @param tiProcess the ti process
     * @param status the status
     * @throws Exception the exception
     */
    void createTIProcessStatusEntity(TIProcess tiProcess, String status) throws Exception{
	if(status==null)
	    throw new ApplicationException(" Status is null when creating TIProcessStatus");
	Long statusID=findTIStatusID(status);
	TIProcessStatusEntity statProcEntit=new TIProcessStatusEntity();
	statProcEntit.setProcessId(tiProcess.getId());
	statProcEntit.setStatusId(statusID);
	statProcEntit.setStatusDate(new Date());
	tiProcessStatusDao.update(statProcEntit);
	log.info(" INFO >> IPPROCESSSTATUS  CREATED WITH ID "+statProcEntit.getId()+" FOR IPPROCESS ID "+tiProcess.getId()+ " for status "+status);
    }

    /**
     * Sets the process type.
     *
     * @param businessCase the business case
     * @param processType the process type
     * @throws Exception the exception
     */
    protected void setProcessType(BusinessCase businessCase, String processType)
    throws Exception {
	List list = processTypeDao.findByProcessType(processType);
	if (list != null && list.size() > 0) {
	    businessCase.getProcessType().setName(processType);
	    businessCase.getProcessType().setId((Long) list.get(0));
	} else {
	    throw new BusinessException("Unknown TI Process with name " + processType);
	}  
    }

    /**
     * Gets the tI process.
     *
     * @param tiProcess the ti process
     * @return the tI process
     * @throws Exception the exception
     */
    protected TIProcess getTIProcess(TIProcess tiProcess) throws Exception{
	BusinessCase busCase=tiProcess.getBusinessCase();
	TIProcessEntity tiProcEntity=tiProcessDao.get(tiProcess.getId());
	chkTIProcessEntityIsNull(tiProcEntity,tiProcess);
	//get TIRequest information
	tiProcess.setName(tiProcEntity.getProcessName());
	List tiRequestList=tiProcEntity.getTIRequest();
	//if(tiRequestList==null || (tiRequestList!=null && tiRequestList.size()==0)
	TIRequest tiReqDom=tiProcess.getTiRequest();
	if(tiRequestList!=null){
	    Iterator tiRequestItr1=tiRequestList.iterator();

	    SortedMap map = new TreeMap();
	    while(tiRequestItr1.hasNext()){
		TIRequestEntity tiReqEntity=(TIRequestEntity)tiRequestItr1.next();
		map.put(tiReqEntity.getId(),tiReqEntity);	 
	    }
	    tiReqDom.setId((Long)map.lastKey());
	    TIRequestEntity tiReqEntity= (TIRequestEntity)map.get(map.lastKey());
	    tiReqDom.getTiRequestType().setId(tiReqEntity.getTiRequestTypeId());

	    //tiReqDom.setPriorityId(tiReqEntity.getPriorityId());
	    tiReqDom.setPlannedCompletionDate(tiReqEntity.getPlannedCompletionDate());
	    tiReqDom.setEmerBuscritJustification(tiReqEntity.getEmerBuscritJustification());
	    tiReqDom.setAltBussMethods(tiReqEntity.getAltBussMethods());
	    tiReqDom.setReqNewAccess(tiReqEntity.getReqNewAccess());
	    tiReqDom.setVtTicketNo(tiReqEntity.getVtTicketNo());

	    /*List tiReqStat=tiRequestStatusDao.findByRequest(tiReqDom.getId());
			chkTIReqStatIDListIsNull(tiReqStat,tiProcess);
			Iterator itr=tiReqStat.iterator();
			Long tiReqStatID=((Long)tiReqStat.get(0));
			while(itr.hasNext()){
				Long id=(Long)itr.next();
				if(id.longValue()>tiReqStatID.longValue())
					tiReqStatID=id;
			}*/

	    chkTIRequestTypeIDIsNull(tiProcess);
	    TIRequestTypeEntity tiReqTypeEntity=tiRequestTypeDao.get(tiReqDom.getTiRequestType().getId());
	    tiReqDom.getTiRequestType().setName(tiReqTypeEntity.getRequestType());

	    /* TIRequestStatusEntity tiReqStatEntity=tiRequestStatusDao.get(tiReqStatID);
			 chkTIReqStatEntityIsNull(tiReqStatEntity,(Long)tiReqStat.get(0));
			 chkTIStatusTypeEntityIsNull(tiReqStatEntity.getStatus(),(Long)tiReqStat.get(0));
			 String tiRequestStat=tiReqStatEntity.getStatus().getStatus(); 

			 if(tiRequestStat==null || tiRequestStat!=null && tiRequestStat.equals("null"))
				 throw new ApplicationException("No Status is associated with the TIRequestID "+tiReqDom.getId());
			  tiReqDom.getTiRequestStatus().setName(tiRequestStat); */

	}

	//		getRelationshipInfo
	tiProcess.getRelationship().setId(tiProcEntity.getRelationship().getId());
	tiProcess.getRelationship().setName(tiProcEntity.getRelationship().getName());
	if(tiProcEntity.getRelationship().getThirdParty()!=null){
	    tiProcess.getRelationship().getThirdparty().setId(tiProcEntity.getRelationship().getThirdParty().getId());
	    tiProcess.getRelationship().getThirdparty().setName(tiProcEntity.getRelationship().getThirdParty().getName());
	}
	tiProcess.getRelationship().setRelationshipType(tiProcEntity.getRelationship().getRelationshipType());
	tiProcess.getRelationship().getRequesterResourceType().setResourceTypeName(tiProcEntity.getRelationship().getRequesterResourceType().getName());
	if(tiProcEntity.getRelationship().getTargetResourceType()!=null)
	    tiProcess.getRelationship().getTargetResourceType().setResourceTypeName(tiProcEntity.getRelationship().getTargetResourceType().getName());
	else
	    tiProcess.getRelationship().getTargetResourceType().setResourceTypeName(" ");
	tiProcess.getRelationship().setStatus(tiProcEntity.getRelationship().getStatus());
	// get Entitlement Information   
	List<Long> citiHierarchyMasterID=tiProcEntity.getCitiHierarchyMasterID();
	List<Region> region= tiProcessSQL.getRegionForEntitlement(citiHierarchyMasterID);
	Sector sector= tiProcessSQL.getSectorForEntitlement(citiHierarchyMasterID);
	BusinessUnit bu= tiProcessSQL.getBUForEntitlement(citiHierarchyMasterID);
	busCase.setRegionList(region);
	busCase.setSector(sector);
	busCase.setBusinessUnit(bu);
	busCase.getApCostCenter().setPLCode(bu.getCostCenter().getPLCode());
	//busCase.setUpdateComments(tiProcEntity.getProcessUpdateReason());
	//busCase.setTerminationComments(tiProcEntity.getProcessTerminateReason());

	return tiProcess;
    }

    /**
     * Assign contact.
     *
     * @param tiProcess the ti process
     * @param person the person
     * @throws Exception the exception
     */
    protected void assignContact(TIProcess tiProcess,Person person) throws Exception{
	//C3parProcessRoleXrefEntity c3parProcContactEnt=new C3parProcessRoleXrefEntity();
	//validations
	if(tiProcess.getId() == null)
	    throw new ApplicationException(" DEBUG >> TIProcess ID IS NULL");
	if(person!=null && (person.getContactID()==null || person.getRole().getId()==null))
	    throw new ApplicationException("Please check Contact Information ");
	if(tiProcess.getProcessUsers()==null)
	    throw new ApplicationException("Process Users Object should be instantaited");
	if(tiProcessSQL.chkContactExistsForProcess(tiProcess.getId(),person))
	    throw new BusinessException("Role already exists for a contact");
	tiProcess.getProcessUsers().add(assignContactsToProcess(tiProcess,person));
	/* c3parProcContactEnt.setProcessId(tiProcess.getId());
		 c3parProcContactEnt.setRoleId(person.getRole().getId());
		 SecurityRoleEntity secRoleEnt=securityRoleDao.get(person.getRole().getId());
		 chkSecurityRoleEntityIsNull(secRoleEnt,person.getRole().getId());
		 person.getRole().setName(secRoleEnt.getName());
		if(person.isCitiEmployee()){
			 c3parProcContactEnt.setCitiContactId(person.getContactID());
			 CitiContactEntity citiContactEntity=citiContactDao.get(person.getContactID(),false);
			 person.setFirstName(citiContactEntity.getFirstName());
			 person.setLastName(citiContactEntity.getLastName());
			 person.setEmailAddress(citiContactEntity.getEmail());
			 person.setTelephone(citiContactEntity.getPhone());
		}
		else{
			 c3parProcContactEnt.setThirdPartyContactId(person.getContactID());
			 ThirdPartyContactEntity tpContactEntity=thirdPartyContactDao.get(person.getContactID(),false);
			 person.setFirstName(tpContactEntity.getFirstName());
			 person.setLastName(tpContactEntity.getLastName());
			 person.setEmailAddress(tpContactEntity.getEmail());
			 person.setTelephone(tpContactEntity.getPhone());
		}

		processRoleXrefDao.update( c3parProcContactEnt);
		person.setId( c3parProcContactEnt.getId());

		log.info(" INFO >> PROCESSROLEXREF CREATED WITH ID "+c3parProcContactEnt.getId()+" FOR IPPROCESS ID "+tiProcess.getId());
		 tiProcess.getProcessUsers().add(person);*/

    }

    /**
     * Assign contacts to process.
     *
     * @param tiProcess the ti process
     * @param person the person
     * @return the person
     * @throws Exception the exception
     */
    protected Person assignContactsToProcess(TIProcess tiProcess,Person person) throws Exception{
	C3parProcessRoleXrefEntity c3parProcContactEnt=new C3parProcessRoleXrefEntity();
	c3parProcContactEnt.setProcessId(tiProcess.getId());
	c3parProcContactEnt.setRoleId(person.getRole().getId());
	//SecurityRoleEntity secRoleEnt=securityRoleDao.get(person.getRole().getId());
	RoleEntity roleEnt =RoleLookup.getInstance().getById(person.getRole().getId());
	/* chkSecurityRoleEntityIsNull(secRoleEnt,person.getRole().getId());
		 person.getRole().setName(secRoleEnt.getName());*/
	chkSecurityRoleEntityIsNull(roleEnt,person.getRole().getId());
	person.getRole().setName(roleEnt.getDisplayName());
	c3parProcContactEnt.setIsActive("Y");

	if(person.isCitiEmployee()){
	    c3parProcContactEnt.setCitiContactId(person.getContactID());
	    CitiContactEntity citiContactEntity=citiContactDao.get(person.getContactID(),false);
	    person.setFirstName(citiContactEntity.getFirstName());
	    person.setLastName(citiContactEntity.getLastName());
	    person.setEmailAddress(citiContactEntity.getEmail());
	    person.setTelephone(citiContactEntity.getPhone());
	}
	else{
	    c3parProcContactEnt.setThirdPartyContactId(person.getContactID());
	    ThirdPartyContactEntity tpContactEntity=thirdPartyContactDao.get(person.getContactID(),false);
	    person.setFirstName(tpContactEntity.getFirstName());
	    person.setLastName(tpContactEntity.getLastName());
	    person.setEmailAddress(tpContactEntity.getEmail());
	    person.setTelephone(tpContactEntity.getPhone());
	}

	processRoleXrefDao.update( c3parProcContactEnt);
	person.setId( c3parProcContactEnt.getId());
	log.info(" INFO >> PROCESSROLEXREF CREATED WITH ID "+c3parProcContactEnt.getId()+" FOR IPPROCESS ID "+tiProcess.getId());
	return person;


    }

    /**
     * Un assign contact.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void unAssignContact(TIProcess tiProcess) throws Exception{
	List userList=tiProcess.getProcessUsers();
	if(userList==null)
	    throw new ApplicationException("Process Users Object Is Null");

	//get selected contact ids to send to the daos delete method
	List idToBeRemoved=new ArrayList();
	//get selected contact objects to be removed from process users list after successfully deleting from database

	List userObjsToBeRemoved=new ArrayList();

	if(userList!=null && userList.size()>0){
	    Iterator itr=userList.iterator();
	    while(itr.hasNext()){
		Person person=(Person)itr.next();
		if(person.isSelected()){
		    idToBeRemoved.add(person.getId());
		    userObjsToBeRemoved.add(person);
		}
	    }
	    if(idToBeRemoved!=null && idToBeRemoved.size()==0)
		throw new BusinessException(" Please select a contact to Unassign ");
	    //when unassigning a contact do not delete the contact instead make it inactive.
	    //processRoleXrefDao.delete(idToBeRemoved);
	    int updateCount=tiProcessSQL.unassignContactList(idToBeRemoved);
	    itr=userObjsToBeRemoved.iterator();

	    while(itr.hasNext()){
		Person contact=(Person)itr.next();
		userList.remove(contact);
		log.info(" INFO >> DELETED PROCESSROLEXREF ID "+contact.getId()+" FOR IPPROCESS ID "+tiProcess.getId());
	    }
	}else
	    throw new BusinessException(" Please select a contact to Unassign  ");
    }

    /**
     * Find ti status id.
     *
     * @param status the status
     * @return the long
     * @throws Exception the exception
     */
    Long findTIStatusID(String status) throws Exception{
	List tiProcessStatusTypeIDLst=tiStatusTypeDao.findByStatus(status);
	if(tiProcessStatusTypeIDLst==null||(tiProcessStatusTypeIDLst!=null && tiProcessStatusTypeIDLst.size()==0))
	    throw new ApplicationException("No ID is Associated with TIProcessStatus "+status);
	return (Long)tiProcessStatusTypeIDLst.get(0);
    }
    //validation methods checking for nullpointer
    /**
     * Update ti request create date.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void updateTIRequestCreateDate(TIProcess tiProcess) throws Exception{
	chkTIRequestIDIsNull(tiProcess);
	TIRequestEntity tiReqEntity=tiRequestDao.get(tiProcess.getTiRequest().getId(),false);
	chkTIRequestEntityIsNull(tiReqEntity,tiProcess);
	tiReqEntity.setCreateDate(new Date());
	tiRequestDao.update(tiReqEntity);
	log.info(" INFO >> IPREQUEST UPDATED WITH ID "+tiReqEntity.getId()+" FOR IPPROCESS ID "+tiProcess.getId());
    }

    /**
     * Submit approval comments.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void submitApprovalComments(TIProcess tiProcess) throws Exception{

	validateApprovalComments(tiProcess);
	ApprovalVO approval=tiProcess.getApprovalVO();
	C3parProcessRoleXrefEntity processRoleXrefEntity=processRoleXrefDao.get(approval.getApproverID());
	processRoleXrefEntity.setApproval(approval.getApproval());
	processRoleXrefEntity.setComments(approval.getComments());
	processRoleXrefDao.update(processRoleXrefEntity);
	log.info("INFO >> Approval comments Updated for C3parProcessRoleXref ID "+processRoleXrefEntity.getId()+ " for TIProcessID "+tiProcess.getId());

    }

    /**
     * Submit start work flow task.
     *
     * @param tiProcess the ti process
     * @param activityName the activity name
     * @throws Exception the exception
     */
    protected void submitStartWorkFlowTask(TIProcess tiProcess, String activityName) throws Exception {
	Long id=getTaskIDForActivityName(activityName);
	TIRequestTaskEntity tiReqTaskEnt=fillTITequestTaskEntity(tiProcess,id);
	//tiReqTaskEnt.setTaskEndDate(new Date());
	tiReqTaskEnt.setTaskStartDate(tiReqTaskEnt.getTaskEndDate());
	tiRequestTaskDao.update(tiReqTaskEnt);  
	log.info("INFO>> TIRequestTask ID "+tiReqTaskEnt.getId()+" created for  TIRequestID "+tiProcess.getTiRequest().getId()+" for taskcode "+activityName);

    }

    /**
     * Submit work flow task.
     *
     * @param tiProcess the ti process
     * @param activityName the activity name
     * @throws Exception the exception
     */
    protected void submitWorkFlowTask(TIProcess tiProcess, String activityName) throws Exception {
	//Name taskCode=tiProcessSQL.getTIRequestTaskIDForRequestID(tiProcess.getTiRequest().getId());
	Date currentTaskEndDate=tiProcessSQL.getTIRequestTaskIDForRequestID(tiProcess.getTiRequest().getId());
	/* (if(taskCode.getId()==null || taskCode.getName()==null||(taskCode.getId()!=null && taskCode.getId().longValue()==0))
			throw new ApplicationException(" No task information for TIRequestID "+tiProcess.getTiRequest().getId());*/
	//if the current tirequesttask is in "Start_workflow" task.its not required to update the taskendtime only on other tasks taskendtime needs to be updated.
	/*	if(currentTaskEndDate==null)
			throw new ApplicationException(" TIRequestTask TaskEndDate is null for the current task "+activityName+" and for TIRequestID "+tiProcess.getTiRequest().getId()); */
	/*if(!taskCode.equals(WorkflowTask.Start_IP_Registration_Process)){

			TIRequestTaskEntity tiReqTaskEntCurrent=tiRequestTaskDao.get(taskCode.getId());
			chkTIRequestTaskEntityIsNull(tiReqTaskEntCurrent,taskCode.getId());
			tiReqTaskEntCurrent.setTaskEndDate(new Date());
			tiRequestTaskDao.update(tiReqTaskEntCurrent);
		}*/
	//create a new tirequesttask when a task is completed and set only its taskstartdate.On the submission of the task next task then update the current tasks taskenddate
	Long taskID=getTaskIDForActivityName(activityName);
	TIRequestTaskEntity tiReqTaskEntNew=fillTITequestTaskEntity(tiProcess,taskID);
	if(currentTaskEndDate==null)
	    tiReqTaskEntNew.setTaskStartDate(new Date());
	else
	    tiReqTaskEntNew.setTaskStartDate(currentTaskEndDate);
	tiRequestTaskDao.update(tiReqTaskEntNew);
	log.info("INFO>> TIRequestTask ID "+tiReqTaskEntNew.getId()+" created for  TIRequestID "+tiProcess.getTiRequest().getId()+" for taskcode "+activityName);
    }

    /**
     * Gets the task contact.
     *
     * @param tiProcess the ti process
     * @return the task contact
     * @throws Exception the exception
     */
    protected void getTaskContact(TIProcess tiProcess) throws Exception{

	ApprovalVO approval=tiProcess.getApprovalVO();
	Long buID=tiProcess.getBusinessCase().getBusinessUnit().getId();

	String createType=" Created ";
	//chk if  citicontactid which exists for a given businessunit id .if not select firstname,lastname from c3par_users table and insert into citi_contact table
	Long citiContactID=tiProcessSQL.getCitiContactID(approval.getSoeID(),buID);
	boolean newContact=false;
	if(citiContactID==null||(citiContactID!=null && citiContactID.longValue()==0)){
	    Person person =tiProcessSQL.getC3parUserInfo(approval.getSoeID());
	    if(person==null ||(person!=null && (person.getFirstName()==null || person.getLastName()==null)) )
		throw new ApplicationException(" No user with the matching SOE id "+approval.getSoeID());
	    CitiContactEntity contactEntity=new CitiContactEntity();
	    contactEntity.setFirstName(person.getFirstName());
	    contactEntity.setLastName(person.getLastName());
	    contactEntity.setEmail(person.getEmailAddress());
	    contactEntity.setBusinessunitId(buID);
	    citiContactDao.update(contactEntity);
	    citiContactID=contactEntity.getId();
	    newContact=true;
	    log.info("INFO >> ContactID "+contactEntity.getId()+" created   for "+" TIProcessID  "+tiProcess.getId()+" for role id "+ approval.getRole().getId());
	}
	Long processRoleID=null;
	if(!newContact){
	    processRoleID=tiProcessSQL.getProcessUserID(tiProcess.getId(),approval.getRole().getId(),citiContactID);
	}
	C3parProcessRoleXrefEntity processRoleXrefEntity=null;
	if(processRoleID!=null && processRoleID.longValue()!=0){
	    createType=" Updated ";
	    approval.setApproverID(processRoleID);
	}
	else{
	    processRoleXrefEntity=new C3parProcessRoleXrefEntity();
	    processRoleXrefEntity.setProcessId(tiProcess.getId());
	    processRoleXrefEntity.setRoleId(approval.getRole().getId());    
	    processRoleXrefEntity.setCitiContactId(citiContactID);
	    processRoleXrefEntity.setIsActive("Y");
	    processRoleXrefDao.update(processRoleXrefEntity);
	    approval.setApproverID(processRoleXrefEntity.getId());
	}

	log.info("INFO >> Task contact "+createType+" for C3parProcessRoleXref ID "+approval.getApproverID()+ " for TIProcessID "+tiProcess.getId());
    }

    /**
     * Gets the task id for activity name.
     *
     * @param activityName the activity name
     * @return the task id for activity name
     * @throws Exception the exception
     */
    public Long getTaskIDForActivityName(String activityName) throws Exception {
	List idList= tiTaskTypeDao.findByTaskCode(activityName);
	if(idList==null || (idList!=null && idList.size()==0))
	    throw new ApplicationException("No task id for the taskcode "+activityName);
	return (Long)idList.get(0);

    }

    /**
     * Fill ti tequest task entity.
     *
     * @param tiProcess the ti process
     * @param taskID the task id
     * @return the tI request task entity
     * @throws Exception the exception
     */
    public TIRequestTaskEntity fillTITequestTaskEntity(TIProcess tiProcess, Long taskID) throws Exception {
	TIRequestTaskEntity tiReqTaskEntity=new TIRequestTaskEntity();
	tiReqTaskEntity.setRequestId(tiProcess.getTiRequest().getId());
	tiReqTaskEntity.setTaskId(taskID);
	tiReqTaskEntity.setTaskContactId(tiProcess.getApprovalVO().getApproverID());     
	// tiReqTaskEntity.setTaskStartDate(new Date());
	tiReqTaskEntity.setTaskEndDate(new Date());
	return tiReqTaskEntity;
    }

    /**
     * Sets the process active.
     *
     * @param tiProcess the ti process
     * @param processName the process name
     * @param approval the approval
     * @throws Exception the exception
     */
    protected void setProcessActive(TIProcess tiProcess,String processName,String approval) throws Exception{
	TIProcessEntity tiProcEnt=tiProcessDao.get(tiProcess.getId(),false);
	chkTIProcessEntityIsNull(tiProcEnt,tiProcess);
	if(tiProcEnt.getCreateDate()==null)
	    tiProcEnt.setCreateDate(new Date());
	else
	    tiProcEnt.setUpdateDate(new Date());
	tiProcessDao.update(tiProcEnt);
	log.info("INFO>> TIProcess ID "+tiProcEnt.getId()+" updated with create/update Active date ");
	//create tiprocess status to Active/terminated based on process name
	if(processName.equals(WorkflowTask.IP_Registration)||processName.equals(WorkflowTask.IP_Maintenance)){
	    createTIProcessStatusEntity(tiProcess,TIProcessService.TIProcStat_Active);
	}else if(processName.equals(WorkflowTask.IP_Termination)){
	    //			In termination if operational analyst rejects then the process  status needs to set as Active instead of Reject.
	    if("Reject".equals(approval))
		createTIProcessStatusEntity(tiProcess,TIProcessService.TIProcStat_Active);
	    else
		createTIProcessStatusEntity(tiProcess,TIProcessService.TIProcStat_Terminated);
	}
	//set tirequeststaus to completed
	createTIRequestStatus(tiProcess,TIProcessService.TIReqStat_Complete);
    }

    /**
     * Submit termination comments.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void submitTerminationComments(TIProcess tiProcess) throws Exception{
	if(chkIsNull(tiProcess.getBusinessCase().getTerminationComments()))
	    throw new ApplicationException(" Termination Comments are empty ");
	TIProcessEntity tiProcEntity=tiProcessDao.get(tiProcess.getId(),false);
	tiProcEntity.setProcessTerminateReason(tiProcess.getBusinessCase().getTerminationComments());
	tiProcessDao.update(tiProcEntity);
    }

    /**
     * Gets the active ip registration list.
     *
     * @param requestor the requestor
     * @param isAdmin the is admin
     * @param ipName the ip name
     * @return the active ip registration list
     * @throws Exception the exception
     */
    protected List getActiveIPRegistrationList(String requestor,boolean isAdmin,String ipName) throws Exception{
	chkRequestorISNull(requestor," getActiveIPList ");
	return (tiProcessSQL.getActiveIPList(requestor,isAdmin,ipName));

    }

    /**
     * Chk is null.
     *
     * @param str the str
     * @return true, if successful
     */
    protected boolean chkIsNull(String str) {
	boolean isNull=false;
	if(str==null)
	    isNull=true;
	else if(str.length()==0)
	    isNull=true;
	return isNull;
    }

    /**
     * Chk is zero.
     *
     * @param id the id
     * @return true, if successful
     */
    protected boolean chkIsZero(Long id) {
	boolean isZero=false;
	if(id==null)
	    isZero=true;
	else if(id.longValue()==0)
	    isZero=true;
	return isZero;

    }
    
    private boolean checkRegionList(List<Region> regionList){
    	if (regionList == null || regionList.isEmpty()){
    		return false;
    	} else {
    		for (Region region : regionList) {
    			if (region == null || !chkIsZero(region.getId()) || !chkIsNull(region.getName())) {
    				return false;
    			}
    		}
    	}
    	return true;
    }

    /**
     * Convert string to date.
     *
     * @param dateString the date string
     * @return the date
     * @throws Exception the exception
     */
    protected Date convertStringToDate(String dateString) throws Exception{
	Date date=null;
	try{
	    SimpleDateFormat dt=new SimpleDateFormat("MM/dd/yyyy");
	    date=dt.parse(dateString);
	    if(date == null)
		throw new Exception();
	}
	catch(Exception e){
	    throw new ApplicationException("Check the date Format "+dateString);
	}
	return date;
    }
    /*	protected void chkComments(TIProcess tiProcess)throws Exception{
		if(chkIsNull(tiProcess.getApprovalVO().getComments()))
			throw new ApplicationException(" Comments are empty ");

	}*/
    /*protected void  chkTerminationComments(TIProcess tiProcess)throws Exception{
		if(chkIsNull(tiProcess.getBusinessCase().getTerminationComments()))
			throw new ApplicationException(" Termination Comments are empty ");

	}*/
    /**
     * Gets the relationship info.
     *
     * @param tiProcess the ti process
     * @return the relationship info
     * @throws Exception the exception
     */
    protected TIProcess getRelationshipInfo(TIProcess tiProcess) throws Exception{
	chkRelationshipIDIsNull(tiProcess);
	Map dataMap =tiProcessSQL.getRelationshipInfo(tiProcess.getRelationship().getId());
	if(dataMap==null || (dataMap!=null && dataMap.size() == 0))
	    throw new ApplicationException(" Relationship Information is empty for relationshipID "+tiProcess.getRelationship().getId());
	String relationship=(String) dataMap.get("relationshipName");
	 List<Region> regionList = (List<Region>)dataMap.get("regionList");
	Long sectorID=(Long) dataMap.get("sectorID");
	String sector=(String) dataMap.get("sectorName");
	Long buID=(Long) dataMap.get("buID");
	String bu=(String) dataMap.get("buName");
	Long tpID=(Long) dataMap.get("tpID");
	String tpName=(String) dataMap.get("tpName");
	String targetResourceType=(String) dataMap.get("targetResourceType");
	String requesterResourceType=(String) dataMap.get("requesterResourceType");
	String relationshipType=(String) dataMap.get("relationshipType");

	if(chkIsNull(relationship))
	    throw new ApplicationException(" Relationship name is null for relationshipID "+tiProcess.getRelationship().getId());
	else
	    tiProcess.getRelationship().setName(relationship);
	if(checkRegionList(regionList))
		throw new ApplicationException(" Entitled Region List is null for relationshipID "+tiProcess.getRelationship().getId());
	else tiProcess.getBusinessCase().setRegionList(regionList);
	if(chkIsZero(sectorID))
	    throw new ApplicationException(" Entitled SectorID is null for relationshipID "+tiProcess.getRelationship().getId());
	else tiProcess.getBusinessCase().getSector().setId(sectorID);
	if(chkIsNull(sector))
	    throw new ApplicationException("Entitled Sector is null for relationshipID "+tiProcess.getRelationship().getId());
	tiProcess.getBusinessCase().getSector().setName(sector);

	if(chkIsZero(buID))
	    throw new ApplicationException(" Entitled BusinessUnitID is null for relationshipID "+tiProcess.getRelationship().getId());
	else tiProcess.getBusinessCase().getBusinessUnit().setId(buID);
	if(chkIsNull(bu))
	    throw new ApplicationException("Entitled BusinessUnit is null for relationshipID "+tiProcess.getRelationship().getId());
	tiProcess.getBusinessCase().getBusinessUnit().setName(bu);

	tiProcess.getBusinessCase().getBusinessUnit().getCostCenter().setPLCode((String) dataMap.get("costCenter"));

	if(chkIsZero(tpID))
	    //				throw new ApplicationException(" Entitled ThirdPartyID is null for relationshipID "+tiProcess.getRelationship().getId());
	    log.info("Third Party ID is null for relationshipID "+tiProcess.getRelationship().getId());
	else tiProcess.getRelationship().getThirdparty().setId(tpID);
	if(chkIsNull(tpName))
	    //				throw new ApplicationException("Entitled ThirdParty is null for relationshipID "+tiProcess.getRelationship().getId());
	    log.info("Third Party Name is null for relationshipID "+tiProcess.getRelationship().getId());
	else tiProcess.getRelationship().getThirdparty().setName(tpName);

	if(chkIsNull(requesterResourceType))
	    throw new ApplicationException(" Requester Resource Type is null for relationshipID "+tiProcess.getRelationship().getId());
	else tiProcess.getRelationship().getRequesterResourceType().setResourceTypeName(requesterResourceType);

	if(chkIsNull(targetResourceType)){
	    log.info("Target Resource Type is null for relationshipID "+tiProcess.getRelationship().getId());
	    tiProcess.getRelationship().getTargetResourceType().setResourceTypeName(" ");
	}
	else tiProcess.getRelationship().getTargetResourceType().setResourceTypeName(targetResourceType);

	if(chkIsNull(relationshipType)){
	    log.info("Relationship Type  is null for relationshipID "+tiProcess.getRelationship().getId());
	}
	tiProcess.getRelationship().setRelationshipType(relationshipType);
	return tiProcess;

    }

    /**
     * Sets the tI request to termination.
     *
     * @param tiProcess the new tI request to termination
     * @throws Exception the exception
     */
    protected void setTIRequestToTermination(TIProcess tiProcess) throws Exception{
	//set tirequestid to null and set tirequesttype to  "Terminate"
	tiProcess.getTiRequest().setId(null);
	tiProcess.getTiRequest().getTiRequestType().setName(TIProcessService.TIReqType_Terminate);
	createTIRequest(tiProcess);

    }

    /**
     * Chk ti process is null.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void chkTIProcessIsNull(TIProcess tiProcess) throws Exception{
	if(tiProcess==null)
	    throw new ApplicationException("TIProcess is Null");
    }

    /**
     * Find role id.
     *
     * @param roleName the role name
     * @return the long
     * @throws Exception the exception
     */
    protected Long findRoleID(String roleName) throws Exception{
	List roleIDList=securityRoleDao.findByName(roleName);
	if(roleIDList==null || (roleIDList!=null && roleIDList.size()==0))
	    throw new ApplicationException(" NO role mathches "+roleName);
	return (Long)roleIDList.get(0);
    }

    /**
     * Chk ti process entity is null.
     *
     * @param tiProcEntity the ti proc entity
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void chkTIProcessEntityIsNull(TIProcessEntity tiProcEntity,TIProcess tiProcess) throws Exception{
	if(tiProcEntity==null)
	    throw new ApplicationException(" TIProcessEntity for id  "+tiProcess.getId()+" is NULL");
    }

    /**
     * Chk ti request entity is null.
     *
     * @param tiProcEntity the ti proc entity
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void chkTIRequestEntityIsNull(TIRequestEntity tiProcEntity,TIProcess tiProcess)throws Exception{
	if(tiProcEntity==null)
	    throw new ApplicationException(" TIRequestEntity for id  "+tiProcess.getTiRequest().getId()+" is NULL");
    }

    /**
     * Chk ti process id is null.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void chkTIProcessIDIsNull(TIProcess tiProcess)throws Exception{
	if(chkIsZero(tiProcess.getId()))
	    throw new ApplicationException(" TIProcess id is Null");
    }

    /**
     * Chk ti req stat id list is null.
     *
     * @param tiReqStatList the ti req stat list
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void chkTIReqStatIDListIsNull(List tiReqStatList,TIProcess tiProcess)throws Exception{
	if(tiReqStatList==null || (tiReqStatList!=null && tiReqStatList.size()==0))
	    throw new ApplicationException(" TIRequestStatus ID is Null for TiRequest id "+tiProcess.getTiRequest().getId());
    }

    /**
     * Chk ti request id is null.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void chkTIRequestIDIsNull(TIProcess tiProcess) throws Exception{
	if(chkIsZero(tiProcess.getTiRequest().getId()))
	    throw new ApplicationException("TIRequest ID is Null  for tiProcess id "+tiProcess.getId());
    }

    /**
     * Chk ti req stat entity is null.
     *
     * @param tiReqStatEntity the ti req stat entity
     * @param id the id
     * @throws Exception the exception
     */
    protected void chkTIReqStatEntityIsNull(TIRequestStatusEntity tiReqStatEntity ,Long id) throws Exception{
	if(tiReqStatEntity==null)
	    throw new ApplicationException(" TIRequestStatusEntity is Null for ID "+id);
    }

    /**
     * Chk ti status type entity is null.
     *
     * @param tiStatTypeEnt the ti stat type ent
     * @param id the id
     * @throws Exception the exception
     */
    protected void chkTIStatusTypeEntityIsNull(TIStatusTypeEntity tiStatTypeEnt,Long id)  throws Exception{
	if(tiStatTypeEnt==null)
	    throw new ApplicationException(" TIStatusTypeEntity is Null for  TIRequestStatusID "+id);
    }

    /**
     * Chk approval vo is null.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void chkApprovalVOIsNull(TIProcess tiProcess) throws Exception{
	if(tiProcess.getApprovalVO()==null)
	    throw new ApplicationException(" Approval information is Null for TIProcess ID "+tiProcess.getId());
    }

    /**
     * Chk ti request type id is null.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void chkTIRequestTypeIDIsNull(TIProcess tiProcess) throws Exception{
	if(chkIsZero(tiProcess.getTiRequest().getTiRequestType().getId()))
	    throw new ApplicationException(" TIRequestTypeID is null for TIRequest ID "+tiProcess.getTiRequest().getId()+" for TIProcess id "+tiProcess.getId());
    }

    /**
     * Validate approval comments.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void validateApprovalComments(TIProcess tiProcess) throws Exception{
	ApprovalVO approval =tiProcess.getApprovalVO();
	//chkApproverRoleIDIsNull( tiProcess );
	chkApproverRoleIsNull( tiProcess );
	if(approval.getSoeID()==null)
	    throw new ApplicationException("Approvers SOEID for the TIProcess ID "+tiProcess.getId()+" is Null");
	if(approval.getComments()==null)
	    throw new ApplicationException("Approvers Comments for the TIProcess ID "+tiProcess.getId()+" is Null");
	if(approval.getApproval()==null)
	    throw new ApplicationException("Approvers Approval for the TIProcess ID "+tiProcess.getId()+" is Null");
	if(tiProcess.getBusinessCase().getBusinessUnit().getId()==null)
	    throw new ApplicationException("BuisnessUnit ID  for the TIProcess ID "+tiProcess.getId()+" is Null");
    }

    /**
     * Chk approver role is null.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void chkApproverRoleIsNull(TIProcess tiProcess ) throws Exception{
	ApprovalVO approval =tiProcess.getApprovalVO();
	if(approval.getRole()==null )
	    throw new ApplicationException(" Approvers ROLE for the TIProcess ID "+tiProcess.getId()+" is Null");
	if(approval.getRole().getName()==null)
	    throw new ApplicationException(" Approvers ROLE Name for the TIProcess ID "+tiProcess.getId()+" is Null");
    }

    /**
     * Chk ti request task entity is null.
     *
     * @param tiReqTaskEnt the ti req task ent
     * @param tirequestTaskID the tirequest task id
     * @throws Exception the exception
     */
    protected void chkTIRequestTaskEntityIsNull(TIRequestTaskEntity tiReqTaskEnt,Long tirequestTaskID) throws Exception{
	if(tiReqTaskEnt==null)
	    throw new ApplicationException("TIRequestTaskEntity is null for TIRequestTaskID "+tirequestTaskID);
    }

    /**
     * Chk security role entity is null.
     *
     * @param roleEnt the role ent
     * @param roleID the role id
     * @throws Exception the exception
     */
    protected void chkSecurityRoleEntityIsNull(RoleEntity roleEnt,Long roleID )throws Exception{
	if(roleEnt==null)
	    throw new ApplicationException(" RoleEntity is Null for RoleID "+roleID);
    }

    /**
     * Chk requestor is null.
     *
     * @param requestor the requestor
     * @param action the action
     * @throws Exception the exception
     */
    protected void 	chkRequestorISNull(String requestor,String action) throws Exception{
	if(requestor==null)
	    throw new ApplicationException("Cannot perform action "+action+" since user SOE ID IS NULL ");
    }

    /**
     * Chk relationship id is null.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void chkRelationshipIDIsNull(TIProcess tiProcess) throws Exception{
	if(tiProcess.getRelationship()==null)
	    throw new ApplicationException("Relationship object is null");
	if(chkIsZero(tiProcess.getRelationship().getId()))
	    throw new ApplicationException(" Relationship ID is NULL");
    }  
    //A request is in maintenenace when its (present )request type is maintain and its requeststatus(i.e pulled from previous request ) should be complete
    /**
     * Checks if is tI process in maintenance.
     *
     * @param tiProcess the ti process
     * @return true, if is tI process in maintenance
     * @throws Exception the exception
     */
    protected boolean isTIProcessInMaintenance(TIProcess tiProcess ) throws Exception{
	if(TIReqType_Maintain.equals(tiProcess.getTiRequest().getTiRequestType().getName())  && 
		TIReqStat_Complete.equals(tiProcess.getTiRequest().getTiRequestStatus().getName()))
	    return true;
	else
	    return false;

    }

    /**
     * Chk process name.
     *
     * @param processName the process name
     * @throws Exception the exception
     */
    protected void chkProcessName(String processName) throws Exception{
	if(processName==null)
	    throw new ApplicationException("Please provide ProcessName when submitting Approvals/Comments");
	if(!processName.equals(WorkflowTask.IP_Registration)&& !processName.equals(WorkflowTask.IP_Maintenance)&& !processName.equals(WorkflowTask.IP_Termination))
	    throw new ApplicationException("Unknown Process name "+processName);
    }

    //give a processcontactid(i.e on table level its c3parprocesscontactxref)
    /**
     * Chk contact exists in list.
     *
     * @param contactID the contact id
     * @param isCitiEmployee the is citi employee
     * @param contactList the contact list
     * @return true, if successful
     * @throws Exception the exception
     */
    protected boolean chkContactExistsInList(Long contactID, boolean isCitiEmployee, List contactList) throws Exception {
	boolean exists=false;
	Iterator contactListItr=contactList.iterator();
	while(contactListItr.hasNext()){
	    Person contact =(Person)contactListItr.next();
	    if(contactID.equals(contact.getId())&& isCitiEmployee==contact.isCitiEmployee()){
		exists=true;   
		break;
	    }
	}

	return exists;
    }

    /**
     * Update ti request data.
     *
     * @param tiProcess the ti process
     * @throws Exception the exception
     */
    protected void updateTIRequestData(TIProcess tiProcess) throws Exception{
	chkTIRequestIDIsNull(tiProcess);
	TIRequestEntity tiReqEntity=tiRequestDao.get(tiProcess.getTiRequest().getId(),false);
	chkTIRequestEntityIsNull(tiReqEntity,tiProcess);
	//tiReqEntity.setCreateDate(new Date());

	tiReqEntity.setPriorityId(tiProcess.getTiRequest().getPriority().getId());
	tiReqEntity.setPlannedCompletionDate(tiProcess.getTiRequest().getPlannedCompletionDate());
	tiReqEntity.setAltBussMethods(tiProcess.getTiRequest().getAltBussMethods());
	tiReqEntity.setEmerBuscritJustification(tiProcess.getTiRequest().getEmerBuscritJustification());
	tiReqEntity.setReqNewAccess(tiProcess.getTiRequest().getReqNewAccess());
	tiReqEntity.setVtTicketNo(tiProcess.getTiRequest().getVtTicketNo());

	tiRequestDao.update(tiReqEntity);
	log.info(" INFO >> IPREQUEST UPDATED WITH ID "+tiReqEntity.getId()+" FOR IPPROCESS ID "+tiProcess.getId());
    }

}