package com.citigroup.cgti.c3par.connection.domain;

import java.util.List;

import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class IPPairRequest.
 */
public class IPPairRequest {


    /** The is start point select all. */
    private boolean isStartPointSelectAll;

    /** The is end point select all. */
    private boolean isEndPointSelectAll;

    /** The start point ip master list. */
    private List startPointIPMasterList;

    /** The end point ip master list. */
    private List endPointIPMasterList;

    /** The application. */
    private Application application = null;

    /** The tunnel. */
    private ConnectionIpsecTunnelMaster tunnel;

    /** The start resource type. */
    private Long startResourceType;

    /** The end resource type. */
    private Long endResourceType;


    /**
     * Gets the tunnel.
     *
     * @return Returns the tunnel.
     */
    public ConnectionIpsecTunnelMaster getTunnel() {
	return tunnel;
    }

    /**
     * Sets the tunnel.
     *
     * @param tunnel The tunnel to set.
     */
    public void setTunnel(ConnectionIpsecTunnelMaster tunnel) {
	this.tunnel = tunnel;
    }

    /**
     * Gets the end point ip master list.
     *
     * @return the end point ip master list
     */
    public List getEndPointIPMasterList() {
	return endPointIPMasterList;
    }

    /**
     * Sets the end point ip master list.
     *
     * @param endPointIPMasterList the new end point ip master list
     */
    public void setEndPointIPMasterList(List endPointIPMasterList) {
	this.endPointIPMasterList = endPointIPMasterList;
    }

    /**
     * Checks if is end point select all.
     *
     * @return true, if is end point select all
     */
    public boolean isEndPointSelectAll() {
	return isEndPointSelectAll;
    }

    /**
     * Sets the end point select all.
     *
     * @param isEndPointSelectAll the new end point select all
     */
    public void setEndPointSelectAll(boolean isEndPointSelectAll) {
	this.isEndPointSelectAll = isEndPointSelectAll;
    }

    /**
     * Checks if is start point select all.
     *
     * @return true, if is start point select all
     */
    public boolean isStartPointSelectAll() {
	return isStartPointSelectAll;
    }

    /**
     * Sets the start point select all.
     *
     * @param isStartPointSelectAll the new start point select all
     */
    public void setStartPointSelectAll(boolean isStartPointSelectAll) {
	this.isStartPointSelectAll = isStartPointSelectAll;
    }

    /**
     * Gets the start point ip master list.
     *
     * @return the start point ip master list
     */
    public List getStartPointIPMasterList() {
	return startPointIPMasterList;
    }

    /**
     * Sets the start point ip master list.
     *
     * @param startPointIPMasterList the new start point ip master list
     */
    public void setStartPointIPMasterList(List startPointIPMasterList) {
	this.startPointIPMasterList = startPointIPMasterList;
    }

    /**
     * Gets the application.
     *
     * @return the application
     */
    public Application getApplication() {
	return application;
    }

    /**
     * Sets the application.
     *
     * @param application the new application
     */
    public void setApplication(Application application) {
	this.application = application;
    }



    /**
     * Gets the end resource type.
     *
     * @return Returns the endResourceType.
     */
    public Long getEndResourceType() {
	return endResourceType;
    }

    /**
     * Sets the end resource type.
     *
     * @param endResourceType The endResourceType to set.
     */
    public void setEndResourceType(Long endResourceType) {
	this.endResourceType = endResourceType;
    }

    /**
     * Gets the start resource type.
     *
     * @return Returns the startResourceType.
     */
    public Long getStartResourceType() {
	return startResourceType;
    }

    /**
     * Sets the start resource type.
     *
     * @param startResourceType The startResourceType to set.
     */
    public void setStartResourceType(Long startResourceType) {
	this.startResourceType = startResourceType;
    }
}
