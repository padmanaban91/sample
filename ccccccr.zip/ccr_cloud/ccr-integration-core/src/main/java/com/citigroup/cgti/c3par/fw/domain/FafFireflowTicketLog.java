/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author bs45969
 *
 */
public class FafFireflowTicketLog extends Base {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private long fafFireflowTicketID;
    private String notificationType;
    private byte[] notificationXML;
    
    private String ffId;
    private String ffType;
    private String ffTicketId;
    private String ffSubTicketId;
    private String ffMessage;
    private String ffConnectionId;
    private String ffRequestId;
    /**
	 * @return the parsingStatus
	 */
	public String getParsingStatus() {
		return parsingStatus;
	}
	
	   CCRBeanFactory ccrBeanFactory;
		{
			ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
			if(appContext!=null && appContext.containsBean("cCRBeanFactory")){
				ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
			}else{
				System.out.println("appContext is null");
			}
			
		}
	/**
	 * @param parsingStatus the parsingStatus to set
	 */
	public void setParsingStatus(String parsingStatus) {
		this.parsingStatus = parsingStatus;
	}
	private byte[] initialPlans;
    private String  parsingStatus;
    /**
	 * @return the initialPlans
	 */
	public byte[] getInitialPlans() {
		return initialPlans;
	}

	/**
	 * @param initialPlans the initialPlans to set
	 */
	public void setInitialPlans(byte[] initialPlans) {
		this.initialPlans = initialPlans;
	}

	/**
	 * @return the workOrders
	 */
	public byte[] getWorkOrders() {
		return workOrders;
	}

	/**
	 * @param workOrders the workOrders to set
	 */
	public void setWorkOrders(byte[] workOrders) {
		this.workOrders = workOrders;
	}
	private byte[] workOrders;

    public FafFireflowTicketLog() {
	setCreated_date(new Date());
    }

    /**
     * @return the fafFireflowTicket
     */
    public long getFafFireflowTicketID() {
        return fafFireflowTicketID;
    }

    /**
     * @param fafFireflowTicket the fafFireflowTicket to set
     */
    public void setFafFireflowTicketID(long fafFireflowTicketID) {
        this.fafFireflowTicketID = fafFireflowTicketID;
    }

    /**
     * @return the notificationType
     */
    public String getNotificationType() {
        return notificationType;
    }

    /**
     * @param notificationType the notificationType to set
     */
    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    /**
     * @return the notificationXML
     */
    public byte[] getNotificationXML() {
        return notificationXML;
    }

    /**
     * @param notificationXML the notificationXML to set
     */
    public void setNotificationXML(byte[] notificationXML) {
        this.notificationXML = notificationXML;
    }
    /**
	 * @return the ffId
	 */
	public String getFfId() {
		return ffId;
	}

	/**
	 * @param ffId the ffId to set
	 */
	public void setFfId(String ffId) {
		this.ffId = ffId;
	}

	/**
	 * @return the ffType
	 */
	public String getFfType() {
		return ffType;
	}

	/**
	 * @param ffType the ffType to set
	 */
	public void setFfType(String ffType) {
		this.ffType = ffType;
	}

	/**
	 * @return the ffTicketId
	 */
	public String getFfTicketId() {
		return ffTicketId;
	}

	/**
	 * @param ffTicketId the ffTicketId to set
	 */
	public void setFfTicketId(String ffTicketId) {
		this.ffTicketId = ffTicketId;
	}

	/**
	 * @return the ffSubTicketId
	 */
	public String getFfSubTicketId() {
		return ffSubTicketId;
	}

	/**
	 * @param ffSubTicketId the ffSubTicketId to set
	 */
	public void setFfSubTicketId(String ffSubTicketId) {
		this.ffSubTicketId = ffSubTicketId;
	}

	/**
	 * @return the ffMessage
	 */
	public String getFfMessage() {
		return ffMessage;
	}

	/**
	 * @param ffMessage the ffMessage to set
	 */
	public void setFfMessage(String ffMessage) {
		this.ffMessage = ffMessage;
	}

	/**
	 * @return the ffConnectionId
	 */
	public String getFfConnectionId() {
		return ffConnectionId;
	}

	/**
	 * @param ffConnectionId the ffConnectionId to set
	 */
	public void setFfConnectionId(String ffConnectionId) {
		this.ffConnectionId = ffConnectionId;
	}

	/**
	 * @return the ffRequestId
	 */
	public String getFfRequestId() {
		return ffRequestId;
	}

	/**
	 * @param ffRequestId the ffRequestId to set
	 */
	public void setFfRequestId(String ffRequestId) {
		this.ffRequestId = ffRequestId;
	}

	@Transactional
    public void save(){
		ccrBeanFactory.getFireflowRequestPersistable().saveFafFireflowTicketLog(this);
    }
    @Transactional
    public FafFireflowTicketLog findTicketLog() {
	return ccrBeanFactory.getFireflowRequestPersistable().findTicketLog(this.getId());
    }
}
