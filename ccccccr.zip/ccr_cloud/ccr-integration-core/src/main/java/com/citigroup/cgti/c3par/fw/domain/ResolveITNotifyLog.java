/**
 * 
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.jms.TextMessage;

import net.nsroot.eur.servicesolutions.cate.integration.Approval;
import net.nsroot.eur.servicesolutions.cate.integration.ApprovalBlueCost;
import net.nsroot.eur.servicesolutions.cate.integration.ApprovalCurrency;
import net.nsroot.eur.servicesolutions.cate.integration.ApprovalItem;
import net.nsroot.eur.servicesolutions.cate.integration.ApprovalSystem;
import net.nsroot.eur.servicesolutions.cate.integration.ApprovalsGreenCost;
import net.nsroot.eur.servicesolutions.cate.integration.ApprovalsNoCost;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfApproval;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfApprovalItem;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfDataFieldNameValue;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfFulfilmentWorkstream;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfPurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.Customer;
import net.nsroot.eur.servicesolutions.cate.integration.DataFieldNameValue;
import net.nsroot.eur.servicesolutions.cate.integration.DataFieldUrl;
import net.nsroot.eur.servicesolutions.cate.integration.DataForm;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentItem;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentSystem;
import net.nsroot.eur.servicesolutions.cate.integration.MessageTypeEnum;
import net.nsroot.eur.servicesolutions.cate.integration.OrderSystem;
import net.nsroot.eur.servicesolutions.cate.integration.PodSystemElementEnum;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionStatusEnum;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOrder;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOrderDocument;
import net.nsroot.eur.servicesolutions.cate.integration.Status;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.fw.service.ResolveITQueueSenderImpl;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;


/**
 * @author bs45969
 *
 */
public class ResolveITNotifyLog extends Base {
	Logger log = Logger.getLogger(ResolveITNotifyLog.class);

	
	   CCRBeanFactory ccrBeanFactory;
		{
			ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
			if(appContext!=null && appContext.containsBean("cCRBeanFactory")){
				ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
			}else{
				System.out.println("appContext is null");
			}
			
		}
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private String cmpID;
    private Long tiRequestID;    
    private byte[] notificationXML;
    private String approvedBy;
    private Date approvedDate;
    private String approverName;
    private Long cmpRequestId;
    
    public ResolveITNotifyLog() {
	setCreated_date(new Date());
    }
   


	public String getCmpID() {
		return cmpID;
	}

	public void setCmpID(String cmpId2) {
		this.cmpID = cmpId2;
	}

    public Long getTiRequestID() {
		return tiRequestID;
	}

	public void setTiRequestID(Long tiRequestID) {
		this.tiRequestID = tiRequestID;
	}

	public byte[] getNotificationXML() {
        return notificationXML;
    }

    public void setNotificationXML(byte[] notificationXML) {
        this.notificationXML = notificationXML;
    }
    
        
    public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}
	
	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}

	public Long getCmpRequestId() {
		return cmpRequestId;
	}

	public void setCmpRequestId(Long cmpRequestId) {
		this.cmpRequestId = cmpRequestId;
	}

	@Transactional
    public void save(){
		ccrBeanFactory.getResolveitRequestPersistable().saveResolveITNotifyLog(this);
    }
    
    @Transactional
    public void update(){
    	ccrBeanFactory.getResolveitRequestPersistable().updateResolveITNotifyLog(this);
    }
    
    @Transactional
    public ResolveITNotifyLog findTicketLog() {
    	return ccrBeanFactory.getResolveitRequestPersistable().findTicketLog(this.getId());
    }
    
    @Transactional
    public ResolveITNotifyLog findTicketLogByCMPID(String CMPID) {
    	return ccrBeanFactory.getResolveitRequestPersistable().findTicketLogByCMPID(CMPID);
    }
    
    @Transactional
    public ResolveITNotifyLog findTicketLogByTiReqId(Long tiRequestId) {
    	return ccrBeanFactory.getResolveitRequestPersistable().findTicketLogByTiReqId(tiRequestId);
    }
    
    @Transactional
    public void deleteUploadedDocument(String tiRequestId,String docType) {
    	 ccrBeanFactory.getResolveitRequestPersistable().deleteUploadedDocument(tiRequestId,docType);
    }
    
    @Transactional
    public void updateTiRequestCMP(String tiRequestId,String cmpId) {
    	 ccrBeanFactory.getResolveitRequestPersistable().updateTiRequestCMP(cmpId,tiRequestId);
    }
    
    @Transactional
    public List<ResolveITNotifyLog> getCMPDetails(String searchString) {
    	return ccrBeanFactory.getResolveitRequestPersistable().getCMPDetails(searchString);
    }
    
   public byte[]  getxmlFromMessage(TextMessage msg){
	   return null;
   }

   public void parseInputStream(String ritToccr) throws Exception
	{
		PurchaseOrderDocument purchaseOrderDocument = null;
		
		try{
			purchaseOrderDocument = PurchaseOrderDocument.Factory.parse(ritToccr);
//			System.out.println(purchaseOrderDocument);
			PurchaseOrder purchaseOrder = purchaseOrderDocument.getPurchaseOrder();
			ArrayOfPurchaseOptionDescription arrayOfPurchaseOptionDescription =purchaseOrder.getPurchaseOptions();
			PurchaseOptionDescription purchaseOptionDescription = arrayOfPurchaseOptionDescription.getPurchaseOptionDescriptionArray(0);
			System.out.println();
			System.out.println("OrderTimeUtc--------"+purchaseOptionDescription.getOrderTimeUtc());
			System.out.println(purchaseOptionDescription.getGlobalMappingReference());
			System.out.println(purchaseOptionDescription.getQuantity());
			System.out.println(purchaseOptionDescription.getHasQuantity());
			System.out.println(purchaseOptionDescription.getSenderPodElement());
			System.out.println(purchaseOptionDescription.getMessageType());
			
			OrderSystem orderSystem = purchaseOptionDescription.getOrderSystem();
			System.out.println(orderSystem.getSystemID());
			System.out.println(orderSystem.getMappingReference());
			System.out.println(orderSystem.getSystemName());
			System.out.println(orderSystem.getSystemDescription());
			System.out.println(orderSystem.getOrderID());
			this.cmpID = orderSystem.getOrderID(); //fetch cMP Id
			System.out.println(orderSystem.getOrderItemID());
			
			Customer customer = orderSystem.getOrderForUser();
			System.out.println(customer.getGeid());
			System.out.println(customer.getFullname());
			System.out.println(customer.getDepartmentCode());
			
			ArrayOfDataFieldNameValue arrayOfDataFieldNameValue = customer.getAttributes();
			DataFieldNameValue dataFieldNameValue = arrayOfDataFieldNameValue.getAttributeArray(0);
			System.out.println(dataFieldNameValue.getName());
			System.out.println(dataFieldNameValue.getValue());
			DataFieldNameValue dataFieldNameValue2 = arrayOfDataFieldNameValue.getAttributeArray(1);
			System.out.println(dataFieldNameValue2.getName());
			System.out.println(dataFieldNameValue2.getValue());
			
			Customer customer2 = orderSystem.getOrderByUser();
			System.out.println(customer2.getGeid());
			System.out.println(customer2.getFullname());
			System.out.println(customer2.getDepartmentCode());
			
			FulfilmentSystem fulfilmentSystem = purchaseOptionDescription.getFulfilmentSystem();
			System.out.println(fulfilmentSystem.getSystemID());
			System.out.println(fulfilmentSystem.getMappingReference());
			System.out.println(fulfilmentSystem.getSystemName());
			System.out.println(fulfilmentSystem.getSystemDescription());
			
			ApprovalSystem approvalSystem = purchaseOptionDescription.getApprovalSystem();
			System.out.println(approvalSystem.getSystemID());
			System.out.println(approvalSystem.getMappingReference());
			System.out.println(approvalSystem.getSystemName());
			System.out.println(approvalSystem.getSystemDescription());
			
			FulfilmentItem fulfilmentItem = purchaseOptionDescription.getFulfilmentItem();
			System.out.println(fulfilmentItem.getFulfilmentItemId());
			System.out.println(fulfilmentItem.getFulfilmentItemName());
			System.out.println(fulfilmentItem.getMaxOrderQuantity());

			ArrayOfApprovalItem arrayOfApprovalItem = fulfilmentItem.getFulfilmentItemApprovals();
			ApprovalItem approvalItem = arrayOfApprovalItem.getApprovalItemArray(0);
			System.out.println(approvalItem.getCatalogItemStartDate());
			System.out.println(approvalItem.getCatalogItemEndDate());
			System.out.println(approvalItem.getItemIsInventory());
			
			
			ApprovalsNoCost approvalsNoCost = approvalItem.getApprovalsNoCost();
			ArrayOfApproval arrayOfApproval = approvalsNoCost.getApprovals();
			Approval approval = arrayOfApproval.getApprovalArray(0);
			// added 2 new fields in CMP -Approved by and Approved Date
			this.approvedBy = approval.getApproverGeid();
			this.approvedDate = approval.getApprovedDateTimeUtc().getTime();
			this.approverName = approval.getApproverFullName();
			log.debug("Approved Date"+this.approvedDate);
			log.debug("Approved by"+this.approvedBy);
			log.debug("Approver Name"+this.approverName);
			
			System.out.println(approval.getApproverGeid());
			System.out.println(approval.getApproverFullName());
			System.out.println(approval.getHasApproved());
			System.out.println(approval.getApprovedDateTimeUtc());
			System.out.println(approval.getApprovalModelID());
			System.out.println(approval.getApproverComments());
			
			ApprovalBlueCost approvalBlueCost = approvalItem.getApprovalsBlueCost();
			System.out.println(approvalBlueCost.getBlueOneOffCostUsd());
			System.out.println(approvalBlueCost.getBlueMonthlyCostUsd());
			System.out.println(approvalBlueCost.getBlueCommodityCode());
			
			ArrayOfApproval aArrayOfApproval = approvalBlueCost.getApprovals();
			
			ApprovalsGreenCost approvalsGreenCost = approvalItem.getApprovalsGreenCost();
			ApprovalCurrency greenCostCurrency = approvalsGreenCost.getGreenCostCurrency();
			
			System.out.println(greenCostCurrency.getCurrencyCode());
			System.out.println(greenCostCurrency.getCurrencyName());
			System.out.println(approvalsGreenCost.getGreenCostCurrency());
			System.out.println(approvalsGreenCost.getGreenOneOffCost());
			System.out.println(approvalsGreenCost.getGreenMonthlyCost());
			System.out.println(approvalsGreenCost.getGreenCommodityCode());
			System.out.println(approvalsGreenCost.getGreenCountryCode());
			
			ArrayOfApproval approvalsGreen = approvalsGreenCost.getApprovals();
			
			Status status = fulfilmentItem.getStatus();
			System.out.println(status.getStatus());
			System.out.println(status.getUpdatedDateTimeUtc());

			DataFieldUrl url = status.getUrl();
			System.out.println(status.getUrl());

			DataForm dataForm = fulfilmentItem.getDataForm();
			System.out.println(dataForm.getVersion());
			System.out.println(dataForm.getIsDetached());
			System.out.println(dataForm.getDataKey());
			System.out.println(dataForm.getLocalizationCultureName());
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
   @Transactional
	public List<ResolveITNotifyLog> getResolveITNotifyLogList() {
		return ccrBeanFactory.getResolveitRequestPersistable().getResolveITNotifyLogList();
	}
   
   @Transactional
	public List<ResolveITNotifyLog> getResolveITNotifyLogList(String searchString) {
		return ccrBeanFactory.getResolveitRequestPersistable().getResolveITNotifyLogList(searchString);
	}
	
	public String getComments(Long tiReqId){
		return ccrBeanFactory.getResolveitRequestPersistable().getComments(tiReqId);
	}
	
	public PurchaseOrderDocument getMessageCCRtoRIT(String msg) {
		PurchaseOrderDocument purchaseOrderDocument = null;
		try{
			purchaseOrderDocument = PurchaseOrderDocument.Factory.newInstance();
			PurchaseOrder purchaseOrder = purchaseOrderDocument.addNewPurchaseOrder();
			ArrayOfPurchaseOptionDescription arrayOfPurchaseOptionDescription =purchaseOrder.addNewPurchaseOptions();
			PurchaseOptionDescription purchaseOptionDescription = arrayOfPurchaseOptionDescription.addNewPurchaseOptionDescription();
			purchaseOptionDescription.setOrderTimeUtc(new GregorianCalendar());
			purchaseOptionDescription.setGlobalMappingReference("FB52AC89-FD66-E211-AA6B-0050569B328B");
			purchaseOptionDescription.setQuantity(1);
			purchaseOptionDescription.setHasQuantity(false);
			purchaseOptionDescription.setSenderPodElement(PodSystemElementEnum.ORDER_SYSTEM);
			purchaseOptionDescription.setMessageType(MessageTypeEnum.UPDATE);
			OrderSystem orderSystem = purchaseOptionDescription.addNewOrderSystem();
			orderSystem.setSystemID("RIT");
			orderSystem.setSystemName("ResolveIT");
			orderSystem.setSystemDescription("ResolveIT Orders");
			orderSystem.setOrderID("WS135866");
			orderSystem.setOrderItemID("WS135866-00001");
			Customer customer = orderSystem.addNewOrderForUser();
			customer.setGeid("0000000000");
			customer.setFullname("Thomas Redmond");
			customer.setDepartmentCode("CB00205833");
			customer.addNewAttributes();
			Customer customer2 = orderSystem.addNewOrderByUser();
			customer2.setGeid("0000000000");
			customer2.setFullname("Thomas Redmond");
			customer2.setDepartmentCode("CB00205833");
			customer2.addNewAttributes();
			purchaseOptionDescription.setOrderSystem(orderSystem);
			FulfilmentSystem fulfilmentSystem = purchaseOptionDescription.addNewFulfilmentSystem();
			fulfilmentSystem.setSystemID("RIT");
			purchaseOptionDescription.setFulfilmentSystem(fulfilmentSystem);
			
			ApprovalSystem approvalSystem = purchaseOptionDescription.addNewApprovalSystem();
			approvalSystem.setSystemID("OA");
			approvalSystem.setMappingReference("");
			approvalSystem.setSystemName("OneApproval");
			approvalSystem.setSystemDescription("OneApproval BPM Approvals Solution");
			approvalSystem.addNewApprovalModels();
			purchaseOptionDescription.setApprovalSystem(approvalSystem);
			
			FulfilmentItem fulfilmentItem = purchaseOptionDescription.addNewFulfilmentItem();
			fulfilmentItem.setFulfilmentItemId("");
			fulfilmentItem.setFulfilmentItemName("");
			fulfilmentItem.setMaxOrderQuantity(0);
			fulfilmentItem.addNewFulfilmentItemApprovals();
			Status status = fulfilmentItem.addNewStatus();
			status.setStatus(PurchaseOptionStatusEnum.CREATED);
			//status.setComments("Request received for TechnicalArchitecture and logged in CCR system.");
			status.setComments(msg);
			status.setUpdatedByUserID("HB26743");
			status.setUpdatedDateTimeUtc(new GregorianCalendar());
			DataFieldUrl url = status.addNewUrl();
			status.setUrl(url);			
			DataForm dataForm = fulfilmentItem.addNewDataForm();
			dataForm.setDataKey(0);
			dataForm.setLocalizationCultureName("");
			
			fulfilmentItem.setDataForm(dataForm);
			fulfilmentItem.setFulfilmentSlaDays(0);
			ArrayOfFulfilmentWorkstream arrayOfFulfilmentWorkstream = fulfilmentItem.addNewFulfilmentWorkStreams();
			fulfilmentItem.setFulfilmentWorkStreams(arrayOfFulfilmentWorkstream);
			purchaseOptionDescription.setFulfilmentItem(fulfilmentItem);			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return purchaseOrderDocument;
	}

	public void sendMesage(String string) throws XmlException {
		ResolveITQueueSenderImpl  resolveITQueueSenderImpl= new ResolveITQueueSenderImpl();
		ResolveITNotifyLog itNotifyLog=findTicketLogByCMPID(string);
		String xmlToString = new String(itNotifyLog.getNotificationXML());
		PurchaseOrderDocument purchaseOrderDocument = null;
		purchaseOrderDocument = PurchaseOrderDocument.Factory
				.parse(xmlToString);				
		PurchaseOrder purchaseOrder = purchaseOrderDocument
				.getPurchaseOrder();
		ArrayOfPurchaseOptionDescription arrayOfPurchaseOptionDescription = purchaseOrder
				.getPurchaseOptions();
		PurchaseOptionDescription purchaseOptionDescription = arrayOfPurchaseOptionDescription
				.getPurchaseOptionDescriptionArray(0);
		purchaseOptionDescription.setMessageType(MessageTypeEnum.UPDATE);
		purchaseOptionDescription
				.setOrderTimeUtc(new GregorianCalendar());
		FulfilmentItem fulfilmentItem = purchaseOptionDescription.getFulfilmentItem()
				;

		Status ccrStatus = fulfilmentItem.getStatus();

		ccrStatus.setComments("Posting message for activityTrailId"
				+ "BS45969" + " and logged in CCR system.");

		ccrStatus.setStatus(PurchaseOptionStatusEnum.CREATED);
		//status.setComments("Request received for "+resolveITNotifyQueueReadImpl.getTaskCode()+" and logged in CCR system.");
		ccrStatus.setUpdatedByUserID("BS45969");
		ccrStatus.setUpdatedDateTimeUtc(new GregorianCalendar());
		/*DataFieldUrl url = ccrStatus.addNewUrl();
		ccrStatus.setUrl(url);
		purchaseOptionDescription.setFulfilmentItem(fulfilmentItem);*/
		System.out.println("purchaseOrderDocument"+purchaseOrderDocument.xmlText());
		String toPost="<?xml version=\"1.0\" encoding=\"utf-8\" ?>"+purchaseOrderDocument.xmlText();
		System.out.println("toPost"+toPost);
		resolveITQueueSenderImpl.sendMesage(toPost);

	}
	

	
}
