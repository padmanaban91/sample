package com.citigroup.cgti.c3par;


/**
 * The Class ScenarioNames.
 */
public class ScenarioNames
{

    /** The Constant ATTRIBUTE_NAME. */
    static public final String ATTRIBUTE_NAME = "CURRENT_SCENARIO";

    /** The Constant HOMEPAGE. */
    static public final String HOMEPAGE = "Homepage";

    /** The Constant CREATE_CONNECTION. */
    static public final String CREATE_CONNECTION = "Create Connection";

    /** The Constant TERMINATE_CONNECTION. */
    static public final String TERMINATE_CONNECTION = "Terminate Connection";

    /** The Constant UPDATE_CONNECTION. */
    static public final String UPDATE_CONNECTION = "Update Connection";

    /** The Constant REPORT_MODULE. */
    static public final String REPORT_MODULE = "Reports";

    /** The Constant NEW_ID_STRING. */
    static public final String NEW_ID_STRING = "NEW";

    /** The Constant CONNECTION_REQUEST_STATUS. */
    static public final String CONNECTION_REQUEST_STATUS = "status";

    /** The Constant PROCESS_CONTEXT. */
    static public final String PROCESS_CONTEXT = "PROCESS_CONTEXT";

    /** The Constant PROCESS_TYPE. */
    static public final String PROCESS_TYPE = "PROCESS_TYPE";

    /** The Constant PROCESS_TYPE_CONNECTION. */
    static public final String PROCESS_TYPE_CONNECTION = "Connection";

    /** The Constant PROCESS_TYPE_IP. */
    static public final String PROCESS_TYPE_IP = "IP";

    /** The Constant MAINTENANCE. */
    static public final String MAINTENANCE = "Maintenance";

    /** The Constant TERMINATION. */
    static public final String TERMINATION = "Termination";

    /** The Constant PLANNING. */
    static public final String PLANNING = "Planning";

    /** The Constant ACTIVATION. */
    static public final String ACTIVATION = "Activation";

    /** The Constant CREATE_IP. */
    static public final String CREATE_IP = "Create IP";

    /** The Constant UPDATE_IP. */
    static public final String UPDATE_IP = "Update IP";

    /** The Constant TERMINATE_IP. */
    static public final String TERMINATE_IP = "Terminate IP";





}
