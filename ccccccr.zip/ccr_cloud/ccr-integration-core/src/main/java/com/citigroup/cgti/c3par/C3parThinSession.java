package com.citigroup.cgti.c3par;

/*
 * CONFIDENTIAL  AND PROPRIETARY
 */

import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.Properties;

import com.citigroup.cgti.c3par.util.C3parProperties;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.util.databaserealm.RealmProperties;
import com.mentisys.util.logging.Logger;


/**
 * The Class C3parThinSession.
 */
public class C3parThinSession extends DatabaseSession {

    /** The Constant log. */
    static private final Logger log = Logger.getLogger("common", C3parSession.class);

    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseSession#obtainConnection()
     */
    protected Connection obtainConnection() throws SQLException {

	Connection connection = null;

	try {
	    RealmProperties.encryptDatabasePassword();
	    Properties prop = new Properties();
	    prop.put("user", RealmProperties.DATABASE_USER);
	    prop.put("password", RealmProperties.getPassword());
	    Driver driver = (Driver)Class.forName(C3parProperties.DATABASE_JDBC_DRIVER).newInstance();
	    connection = driver.connect(C3parProperties.DATABASE_URL, prop);
	} catch (Exception e) {
	    log.error("Failed to obtain a database connection to '{0}'", new Object[]{C3parProperties.JDBC_DS}, e);
	}
	return connection;
    }
}