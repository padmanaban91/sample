package com.citigroup.cgti.c3par.domain.accessform;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
@XmlRootElement
public class FafAccessForm {
	
	private int combination;
	
	private int tupleNo;
	
	private String reqType;
	
	private String fwType;
	
	private String fwPolicyName;
	
	private String ostiaRisk;
	
	private String srcZone;
	
	private String srcIP;
	
	private String destZone;
	
	private String destIP;
	
	private String ports;

	private String ruleType;
	@XmlElement
	public int getCombination() {
		return combination;
	}

	public void setCombination(int combination) {
		this.combination = combination;
	}
	@XmlElement
	public int getTupleNo() {
		return tupleNo;
	}

	public void setTupleNo(int tupleNo) {
		this.tupleNo = tupleNo;
	}

	@XmlElement
	public String getFwPolicyName() {
		return fwPolicyName;
	}

	public void setFwPolicyName(String fwPolicyName) {
		this.fwPolicyName = fwPolicyName;
	}
	@XmlElement
	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}
	@XmlElement
	public String getFwType() {
		return fwType;
	}

	public void setFwType(String fwType) {
		this.fwType = fwType;
	}

	@XmlElement

	public String getOstiaRisk() {
		return ostiaRisk;
	}

	public void setOstiaRisk(String ostiaRisk) {
		this.ostiaRisk = ostiaRisk;
	}
	@XmlElement
	public String getSrcZone() {
		return srcZone;
	}

	public void setSrcZone(String srcZone) {
		this.srcZone = srcZone;
	}

	
	@XmlElement
	public String getDestZone() {
		return destZone;
	}

	public void setDestZone(String destZone) {
		this.destZone = destZone;
	}
	@XmlElement
	public String getSrcIP() {
		return srcIP;
	}

	public void setSrcIP(String srcIP) {
		this.srcIP = srcIP;
	}
	@XmlElement
	public String getDestIP() {
		return destIP;
	}

	public void setDestIP(String destIP) {
		this.destIP = destIP;
	}
	@XmlElement
	public String getPorts() {
		return ports;
	}

	public void setPorts(String ports) {
		this.ports = ports;
	}
	
	@XmlElement
	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}
	
}
