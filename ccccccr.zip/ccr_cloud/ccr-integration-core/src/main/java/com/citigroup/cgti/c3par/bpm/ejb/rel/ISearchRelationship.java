package com.citigroup.cgti.c3par.bpm.ejb.rel;

import java.util.List;

import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipSearchAttributesDTO;
import com.citigroup.cgti.c3par.domain.logic.C3parServiceFacade;


/**
 * The Interface ISearchRelationship.
 */
public interface ISearchRelationship  extends C3parServiceFacade  {
	
	/**
	 * Gets the data classification.
	 *
	 * @return the data classification
	 * @throws Exception the exception
	 */
	public List getDataClassification()  throws Exception;
	
	/**
	 * Gets the business unit.
	 *
	 * @param filterCond the filter cond
	 * @return the business unit
	 * @throws Exception the exception
	 */
	public List getBusinessUnit(String filterCond) throws Exception;
	
	/**
	 * Gets the third party.
	 *
	 * @param filterCond the filter cond
	 * @return the third party
	 * @throws Exception the exception
	 */
	public List getThirdParty(String filterCond) throws Exception;
	
	/**
	 * Gets the enpoint resource type.
	 *
	 * @return the enpoint resource type
	 * @throws Exception the exception
	 */
	public List getEnpointResourceType() throws Exception;
	
	/**
	 * Gets the service type.
	 *
	 * @return the service type
	 */
	public List getServiceType();
	
	/**
	 * Gets the relationship.
	 *
	 * @param Type the type
	 * @param attrs the attrs
	 * @param pageSize the page size
	 * @param pageNum the page num
	 * @return the relationship
	 * @throws Exception the exception
	 */
	public List getRelationship(String Type,RelationshipSearchAttributesDTO attrs,int pageSize,  int pageNum) throws Exception;
	
	/**
	 * Gets the count.
	 *
	 * @param Type the type
	 * @param attrs the attrs
	 * @return the count
	 * @throws Exception the exception
	 */
	public int getCount(String Type,RelationshipSearchAttributesDTO attrs) throws Exception;
	
	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 * @throws Exception the exception
	 */
	public List getPriority()  throws Exception;
	
	/**
	 * Gets the task list.
	 *
	 * @return the task list
	 * @throws Exception the exception
	 */
	public List getTaskList() throws Exception;
	
	/**
	 * Gets the region.
	 *
	 * @return the region
	 * @throws Exception the exception
	 */
	public List getRegion() throws Exception;
	
	/**
	 * Gets the sector.
	 *
	 * @param regionId the region id
	 * @return the sector
	 * @throws Exception the exception
	 */
	public List getSector(Long regionId) throws Exception;
	
	/**
	 * Gets the tPASWG review type.
	 *
	 * @return the tPASWG review type
	 * @throws Exception the exception
	 */
	public List getTPASWGReviewType() throws Exception;
	
	/**
	 * Gets the tPASWG review status.
	 *
	 * @return the tPASWG review status
	 * @throws Exception the exception
	 */
	public List getTPASWGReviewStatus() throws Exception;
}
