/**
 * 
 */
package com.citigroup.cgti.c3par.businessjustification.domain.soc.persist;

import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface EmerBuscritServicePersistable extends Persistable {
	 	 
	 public Long getPlanningIdForTiRequestId(Long tirequestid); 
	 
	 public Long updatePlanningPart(Planning planning);
	 
	 public void loadPlanningPart(Planning planning);
	 
	 public boolean isDirectorPresent(Long planningId);
	 
	 public String getRelationshipType(Long conReqId);	
	 
	 public String getPriority(Long priorityId);

}
