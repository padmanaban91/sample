package com.citigroup.cgti.c3par.fw.domain;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class Port extends Base {
    /**
     * 
     */
	   CCRBeanFactory ccrBeanFactory;
		{
			ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
			if(appContext!=null && appContext.containsBean("cCRBeanFactory")){
				ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
			}else{
				System.out.println("appContext is null");
			}
			
		}
	private static final long serialVersionUID = 1L;
    @NotEmpty(message = "Port number not avaliable")
    private String portNumber;
    @NotEmpty(message = "Protocol is missing")
    private String protocol;
    private String userEntryType;
    private Long controlMsgId;
    private String isRiskport;
    private String biDirectional;
    private String flowOfData;
    private String templateFlag;
    private String AFAObjectName;
    private Long portCount;
    private String dceProtocol;
    private String portNumber2;
    
    
    public String getPortNumber2() {
		return portNumber2;
	}

	public void setPortNumber2(String portNumber2) {
		this.portNumber2 = portNumber2;
	}

	/**
	 * @return the aFAObjectName
	 */
	public String getAFAObjectName() {
		return AFAObjectName;
	}

	/**
	 * @param aFAObjectName the aFAObjectName to set
	 */
	public void setAFAObjectName(String aFAObjectName) {
		AFAObjectName = aFAObjectName;
	}
	private List<FireWallRulePort> fireWallRulePorts;

    /**
     * @return the portNumber
     */
    public String getPortNumber() {
	return portNumber;
    }

    /**
     * @param portNumber the portNumber to set
     */
    public void setPortNumber(String portNumber) {
	this.portNumber = portNumber;
    }

    /**
     * @return the protocol
     */
    public String getProtocol() {
	return protocol;
    }

    /**
     * @param protocol the protocol to set
     */
    public void setProtocol(String protocol) {
	this.protocol = protocol;
    }

    /**
     * @return the userEntryType
     */
    public String getUserEntryType() {
	return userEntryType;
    }

    /**
     * @param userEntryType the userEntryType to set
     */
    public void setUserEntryType(String userEntryType) {
	this.userEntryType = userEntryType;
    }

    /**
     * @return the controlMsgId
     */
    public Long getControlMsgId() {
	return controlMsgId;
    }

    /**
     * @param controlMsgId the controlMsgId to set
     */
    public void setControlMsgId(Long controlMsgId) {
	this.controlMsgId = controlMsgId;
    }

    /**
     * @return the isRiskport
     */
    public String getIsRiskport() {
	return isRiskport;
    }

    /**
     * @param isRiskport the isRiskport to set
     */
    public void setIsRiskport(String isRiskport) {
	this.isRiskport = isRiskport;
    }

    /**
     * @return the biDirectional
     */
    public String getBiDirectional() {
	return biDirectional;
    }

    /**
     * @param biDirectional the biDirectional to set
     */
    public void setBiDirectional(String biDirectional) {
	this.biDirectional = biDirectional;
    }

    /**
     * @return the flowOfData
     */
    public String getFlowOfData() {
	return flowOfData;
    }

    /**
     * @param flowOfData the flowOfData to set
     */
    public void setFlowOfData(String flowOfData) {
	this.flowOfData = flowOfData;
    }
    //Will be used while listing Port bean validation messages
    public String toString() {
    	String returnValue ="";
    	if("TCP".equalsIgnoreCase(protocol) || "UDP".equalsIgnoreCase(protocol)){
    		returnValue=protocol+"\t"+"|"+"\t"+portNumber;
    	}else if("ICMP".equalsIgnoreCase(protocol)){
    		returnValue=protocol+"\t"+"|"+"\t"+getControlMessage().getValue2();
    	}else{
    		returnValue=protocol+"\t"+"|"+"\t"+portNumber;
    		
    	}
	 return returnValue;
    }

	/**
	 * @return the templateFlag
	 */
	public String getTemplateFlag() {
		return templateFlag;
	}

	/**
	 * @param templateFlag the templateFlag to set
	 */
	public void setTemplateFlag(String templateFlag) {
		this.templateFlag = templateFlag;
	}

	/**
	 * @return the fireWallRulePorts
	 */
	public List<FireWallRulePort> getFireWallRulePorts() {
		return fireWallRulePorts;
	}

	/**
	 * @param fireWallRulePorts the fireWallRulePorts to set
	 */
	public void setFireWallRulePorts(List<FireWallRulePort> fireWallRulePorts) {
		this.fireWallRulePorts = fireWallRulePorts;
	}

	
	public GenericLookup getControlMessage() {
		return ccrBeanFactory.getCommonServicePersistable().getControlMessage(this.controlMsgId);
	}

	/**
	 * @return the portCount
	 */
	public Long getPortCount() {
		return portCount;
	}

	/**
	 * @param portCount the portCount to set
	 */
	public void setPortCount(Long portCount) {
		this.portCount = portCount;
	}

	public String getDceProtocol() {
		return dceProtocol;
	}

	public void setDceProtocol(String dceProtocol) {
		this.dceProtocol = dceProtocol;
	}
	
    
}
