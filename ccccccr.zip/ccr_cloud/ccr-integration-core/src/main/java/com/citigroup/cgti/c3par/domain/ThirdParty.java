package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

/**
 * The Class ThirdParty.
 */
@XmlType(name="ThirdPartyEntity")
public class ThirdParty extends Name implements Serializable{

	public static String ID = "ID";
	public static String CASP_ID = "CASP_ID";
	public static String DETAIL_ID = "DETAIL_ID";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private Long caspId;
	/**
	 * 
	 */
	private Long caspDetailId;
	
	
	public Long getCaspDetailId() {
		return caspDetailId;
	}
	public void setCaspDetailId(Long caspDetailId) {
		this.caspDetailId = caspDetailId;
	}
	public Long getCaspId() {
		return caspId;
	}
	public void setCaspId(Long caspId) {
		this.caspId = caspId;
	}
	
}
