package com.citigroup.cgti.c3par.domain.logic;

/**
 * The Interface C3parServiceFacade.
 */
public interface C3parServiceFacade {

}
