/*
 * Created on Mar 15, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par;

import java.sql.Connection;
import java.util.List;

import org.apache.log4j.Logger;



import com.citigroup.cgti.c3par.performer.dao.PerformerUtil;
import com.citigroup.cgti.c3par.performer.util.PerformerKeyGenerator;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;
import com.mentisys.dao.KeyGenerator;


/**
 * The Class C3parPerformerKeyGenerator.
 *
 * @author gr61093
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class C3parPerformerKeyGenerator implements PerformerKeyGenerator {

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.util.PerformerKeyGenerator#getNextKey()
     */

    /** The attribute. */
    private String attribute;

    /** The log. */
    private transient Logger log = Logger.getLogger(this.getClass().getName());


    /**
     * Instantiates a new c3par performer key generator.
     *
     * @param attribute the attribute
     */
    public C3parPerformerKeyGenerator(String attribute) {
	super();
	this.attribute = attribute;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.util.PerformerKeyGenerator#getNextKey()
     */
    public long getNextKey() {
	long nextKey = 0;
	//		String selectSql = "SELECT NEXTKEY FROM KEY_GENERATOR WHERE ENTITY = '"+ this.attribute+"'"; 
	try{
	    nextKey = KeyGenerator.getInstance().getNextKey((C3parSessionFactory.getC3parSession()), this.attribute);
	    //			C3parPerformerConnection c3parPerformerConnection = new C3parPerformerConnection();
	    //			Connection conn = c3parPerformerConnection.obtainConnection();
	    //			List data = PerformerUtil.executeQuery(selectSql,PerformerTypes.SELECT,conn,true,0);
	    //			nextKey = Long.valueOf(((List)data.get(1)).get(0).toString()).longValue()+1; 
	    //			String insertSql = "UPDATE KEY_GENERATOR SET NEXTKEY = "+ nextKey +" WHERE ENTITY = '"+ this.attribute+"'";
	    //			PerformerUtil.executeQuery(insertSql,PerformerTypes.DML,conn,false,0);
	    //			conn.commit();
	}catch(Exception e){

	    log.error(e);
	}
	return nextKey;
    }

}
