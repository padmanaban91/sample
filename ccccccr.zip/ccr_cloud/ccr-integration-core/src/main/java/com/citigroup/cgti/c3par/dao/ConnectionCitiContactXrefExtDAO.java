package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.CitiContactXrefEntity;
import com.citigroup.cgti.c3par.model.CitiContactXrefExtEntity;
import com.citigroup.cgti.c3par.model.CitiReqContactXrefEntity;
import com.citigroup.cgti.c3par.model.CitiReqContactXrefExtEntity;
import com.citigroup.cgti.c3par.model.ConnectionCitiContactXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionCitiContactXrefExtEntity;
import com.citigroup.cgti.c3par.model.ConnectionCitiReqContactXrefExtEntity;
import com.citigroup.cgti.c3par.model.ConnectionRequestEntity;
import com.citigroup.cgti.c3par.model.ConnectionRequestExtEntity;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.dao.audit.AuditArchiver;
import com.mentisys.model.ManyAssociationList;


/**
 * The Class ConnectionCitiContactXrefExtDAO.
 *
 * @author NE36745
 */
public class ConnectionCitiContactXrefExtDAO
extends ConnectionCitiContactXrefDAO {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** New Fields - SOWNO and CMPID. */
    public static final String	TABLE = "CON_CITI_CON_XREF";

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "ConnectionCitiContactXref";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_NOTIFYCONTACT. */
    public static final String	COLUMN_NOTIFYCONTACT = "NOTIFY_CONTACT";

    // DAO Queries
    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT " + COLUMN_NOTIFYCONTACT
    + " FROM " + ConnectionCitiContactXrefExtDAO.TABLE;

    /** The SELEC t_ stm t1. */
    private static String SELECT_STMT1 = "SELECT " + COLUMN_ID + "," + COLUMN_NOTIFYCONTACT
    + " FROM " + ConnectionCitiContactXrefExtDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = ConnectionCitiContactXrefExtDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + ConnectionCitiContactXrefExtDAO.TABLE + " SET "
    + COLUMN_NOTIFYCONTACT + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";


    /** The log. */
    private static Logger log = Logger.getLogger(ConnectionCitiContactXrefExtDAO.class);

    /**
     * Instantiates a new connection citi contact xref ext dao.
     *
     * @param session the session
     */
    public ConnectionCitiContactXrefExtDAO(DatabaseSession session) {
	super(session);
	// TODO Auto-generated constructor stub
    }

    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionRequestEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionCitiContactXrefEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionCitiContactXrefEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionRequestEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionCitiContactXrefEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.dao.ConnectionCitiContactXrefDAO#update(com.citigroup.cgti.c3par.model.ConnectionCitiContactXrefEntity, com.mentisys.dao.audit.AuditArchiver, boolean)
     */
    public Long update(ConnectionCitiContactXrefEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Updating CitiContactXrefExtEntity [" + entity.getId() + "]");
	Long primaryId  = super.update(entity, archiver, true);

	if (entity instanceof ConnectionCitiContactXrefExtEntity) {
	    ConnectionCitiContactXrefExtEntity extEntity = (ConnectionCitiContactXrefExtEntity) entity;

	    if (extEntity != null && extEntity.getNotifyContact() != null) {
	    log.debug("CitiContactXrefExtEntity.update() :: updating NOTIFY_CONTACT");
	    DatabaseSession session = getSession();

	    if(primaryId.longValue() == 0)
		throw new DatabaseException("Could not insert '" + ConnectionCitiContactXrefExtDAO.ENTITY_NAME + "' with id = " + primaryId + " due to unique key constraint violation", null);

	    Connection connection = null;
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    log.debug("CitiContactXrefExtEntity.update() :- " + primaryId);
	    try
	    {
		connection = session.getConnection();
		st = connection.prepareStatement(UPDATE_BY_ID_STMT);
		st.setString(1, extEntity.getNotifyContact());
		st.setLong(2, primaryId.longValue());
		st.executeUpdate();
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not insert '" + ConnectionCitiContactXrefExtDAO.ENTITY_NAME + "' with id = "
			+ primaryId, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	    }
	}
	log.debug("CitiContactXrefExtEntity.update() :: End");
	return primaryId;
    }


    /**
     * Gets the notify contact.
     *
     * @param id_to_get the id_to_get
     * @return the notify contact
     * @throws DatabaseException the database exception
     */
    public ConnectionCitiContactXrefExtEntity getNotifyContact(Long id_to_get) throws DatabaseException
    {
	ConnectionCitiContactXrefExtEntity extEntity = new ConnectionCitiContactXrefExtEntity();;

	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    setLongToStatement(st, 1, id_to_get);
	    rs = st.executeQuery();

	    if (rs.next())
	    {
		extEntity.setNotifyContact(rs.getString(1));
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not load " + ConnectionCitiContactXrefExtDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	log.debug("DONE Getting CitiContactXrefExtEntity with id = " + id_to_get); 

	return extEntity;
    }

    /**
     * Gets the notify list.
     *
     * @param id_list the id_list
     * @param load_refs the load_refs
     * @return the notify list
     * @throws DatabaseException the database exception
     */
    public HashMap<Long, ConnectionCitiContactXrefExtEntity> getNotifyList(List id_list, boolean load_refs) throws DatabaseException
    {
	HashMap<Long, ConnectionCitiContactXrefExtEntity> 	entity_list = new HashMap<Long, ConnectionCitiContactXrefExtEntity>();

	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    ConnectionCitiContactXrefExtEntity 	entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT1 + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    if(count++ > 0)
		    {
			statement.append(",");					
		    }
		    statement.append(id.toString());					
		    only = id;
		}

		if(count == 1)
		{
		    entity_list.put(only, getNotifyContact(only));					
		}
		else if(count > 1)
		{
		    statement.append(")");					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = new ConnectionCitiContactXrefExtEntity();
			entity.setNotifyContact(rs.getString(2));
			entity_list.put(rs.getLong(1),entity);
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + ConnectionCitiContactXrefDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }
}
