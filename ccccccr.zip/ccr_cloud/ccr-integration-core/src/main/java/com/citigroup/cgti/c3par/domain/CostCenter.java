package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;


/**
 * The Class CostCenter.
 */
public class CostCenter extends Name implements Serializable {

    /** The PL code. */
    private String PLCode;

    /**
     * Gets the pL code.
     *
     * @return the pL code
     */
    public String getPLCode() {
	return PLCode;
    }

    /**
     * Sets the pL code.
     *
     * @param code the new pL code
     */
    public void setPLCode(String code) {
	PLCode = code;
    }

}
