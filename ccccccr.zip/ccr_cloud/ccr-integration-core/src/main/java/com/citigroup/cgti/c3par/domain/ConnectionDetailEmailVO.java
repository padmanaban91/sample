package com.citigroup.cgti.c3par.domain;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ConnectionDetailEmailVO extends C3PARMailMessage {

	private String connectionType;
	private Long processId;
	private String region;
	private String sector;
	private String mode;
	private String businessUnit;
	private Long relationshipId;
	private String relationshipName;
	private String connectionName;
	private String sourceResourceName;
	private String destnResourceName;
	private String priority;
	private String lastSubmittedByRole;
	private String currentActivity;
	private String comment;
	private String requester;
	private String risk;
	private String systemId;
	private Long versionNumber;
	private String implReault;
	private String tempDate;
	private String tempReason;

	private String gisComments;
	private String businessOwner;
	private String businessRequestor;
	private String isoName;
	private String risoApprover;

	private FirewallDetailEmailVO firewallDetailEmailVO;
	private DateDetailEmailVO dateDetailEmailVO;
	private AuditTrailDetailEmailVO auditTrailDetailEmailVO;

	private String activityRole;
	private String activityName;
	private String extDate;

	private String applicationName;
	private Long applicationId;
	private String appOwnerFullName;
	private String function;
	private String secClassification;
	private String perDataIndicator;

	public Long getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(Long versionNumber) {
		this.versionNumber = versionNumber;
	}

	@XmlElement
	public String getBusinessOwner() {
		return businessOwner;
	}

	public void setBusinessOwner(String businessOwner) {
		this.businessOwner = businessOwner;
	}

	@XmlElement
	public String getRisoApprover() {
		return risoApprover;
	}

	public void setRisoApprover(String risoApprover) {
		this.risoApprover = risoApprover;
	}

	@XmlElement
	public String getGisComments() {
		return gisComments;
	}

	public void setGisComments(String gisComments) {
		this.gisComments = gisComments;
	}

	@XmlElement
	public FirewallDetailEmailVO getFirewallDetailEmailVO() {
		return firewallDetailEmailVO;
	}

	public void setFirewallDetailEmailVO(FirewallDetailEmailVO firewallDetailEmailVO) {
		this.firewallDetailEmailVO = firewallDetailEmailVO;
	}

	@XmlElement
	public DateDetailEmailVO getDateDetailEmailVO() {
		return dateDetailEmailVO;
	}

	public void setDateDetailEmailVO(DateDetailEmailVO dateDetailEmailVO) {
		this.dateDetailEmailVO = dateDetailEmailVO;
	}

	@XmlElement
	public AuditTrailDetailEmailVO getAuditTrailDetailEmailVO() {
		return auditTrailDetailEmailVO;
	}

	public void setAuditTrailDetailEmailVO(AuditTrailDetailEmailVO auditTrailDetailEmailVO) {
		this.auditTrailDetailEmailVO = auditTrailDetailEmailVO;
	}

	@XmlElement
	public String getActivityRole() {
		return activityRole;
	}

	public void setActivityRole(String activityRole) {
		this.activityRole = activityRole;
	}

	@XmlElement
	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	@XmlElement
	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	@XmlElement
	public String getRisk() {
		return risk;
	}

	public void setRisk(String risk) {
		this.risk = risk;
	}

	@XmlElement
	public String getRequester() {
		return requester;
	}

	public void setRequester(String requester) {
		this.requester = requester;
	}

	@XmlElement
	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	@XmlElement
	public String getConnectionType() {
		return connectionType;
	}

	public void setConnectionType(String connectionType) {
		this.connectionType = connectionType;
	}

	@XmlElement
	public Long getProcessId() {
		return processId;
	}

	public void setProcessId(Long processId) {
		this.processId = processId;
	}

	@XmlElement
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	@XmlElement
	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	@XmlElement
	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	@XmlElement
	public Long getRelationshipId() {
		return relationshipId;
	}

	public void setRelationshipId(Long relationshipId) {
		this.relationshipId = relationshipId;
	}

	@XmlElement
	public String getRelationshipName() {
		return relationshipName;
	}

	public void setRelationshipName(String relationshipName) {
		this.relationshipName = relationshipName;
	}

	@XmlElement
	public String getConnectionName() {
		return connectionName;
	}

	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}

	@XmlElement
	public String getSourceResourceName() {
		return sourceResourceName;
	}

	public void setSourceResourceName(String sourceResourceName) {
		this.sourceResourceName = sourceResourceName;
	}

	@XmlElement
	public String getDestnResourceName() {
		return destnResourceName;
	}

	public void setDestnResourceName(String destnResourceName) {
		this.destnResourceName = destnResourceName;
	}

	@XmlElement
	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	@XmlElement
	public String getLastSubmittedByRole() {
		return lastSubmittedByRole;
	}

	public void setLastSubmittedByRole(String lastSubmittedByRole) {
		this.lastSubmittedByRole = lastSubmittedByRole;
	}

	@XmlElement
	public String getCurrentActivity() {
		return currentActivity;
	}

	public void setCurrentActivity(String currentActivity) {
		this.currentActivity = currentActivity;
	}

	@XmlElement
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	@XmlElement
	public String getExtDate() {
		return extDate;
	}

	public void setExtDate(String extDate) {
		this.extDate = extDate;
	}

	public void setImplReault(String implReault) {
		this.implReault = implReault;
	}

	public String getImplReault() {
		return implReault;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public String getTempDate() {
		return tempDate;
	}

	public void setTempDate(String tempDate) {
		this.tempDate = tempDate;
	}

	public String getIsoName() {
		return isoName;
	}

	public void setIsoName(String isoName) {
		this.isoName = isoName;
	}

	public String getTempReason() {
		return tempReason;
	}

	public void setTempReason(String tempReason) {
		this.tempReason = tempReason;
	}

	public String getBusinessRequestor() {
		return businessRequestor;
	}

	public void setBusinessRequestor(String businessRequestor) {
		this.businessRequestor = businessRequestor;
	}

	public String getAppOwnerFullName() {
		return appOwnerFullName;
	}

	public void setAppOwnerFullName(String appOwnerFullName) {
		this.appOwnerFullName = appOwnerFullName;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getSecClassification() {
		return secClassification;
	}

	public void setSecClassification(String secClassification) {
		this.secClassification = secClassification;
	}

	public String getPerDataIndicator() {
		return perDataIndicator;
	}

	public void setPerDataIndicator(String perDataIndicator) {
		this.perDataIndicator = perDataIndicator;
	}

}
