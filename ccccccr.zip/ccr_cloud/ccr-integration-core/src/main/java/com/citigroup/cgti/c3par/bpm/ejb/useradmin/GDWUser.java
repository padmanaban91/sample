package com.citigroup.cgti.c3par.bpm.ejb.useradmin;

import java.util.Date;

public class GDWUser {
	
	private String geid;
	private String employee_class;
	private String employee_class_desc;
	private String employee_status;
	private String employee_status_desc;
	private String firstname;
	private String middlename;
	private String lastname;
	private String name_prefix;
	private String location_code;
	private String expense_code;
	private String phone;
	private String fax;
	private String department_code;
	private String department_name;
	private String dept_mgr_geid;
	private String email;
	private String job_code;
	private String job_ttl;
	private String rits_id;
	private String primary_loginid;
	private String soeid;
	private String terminationdate;
	private String lastupdatetm;
	private String effdate;
	private String pending_hire_indicator;
	private String hrgen_geid;
	private String ssid;
	private String officer_title_cd;
	private String building;
	private String bldg_floor;
	private String bldg_zone;
	private String pager;
	private String rits_empl_type_code;
	private String rits_empl_type_code_desc;
	private String rits_empl_status_code;
	private String rits_empl_status_code_desc;
	private String suffix;
	private String country;
	private String street;
	private String street2;
	private String city;
	private String state;
	private String zipcode;
	private String off_ttl;
	private String fciid_1;
	private String fciid_2;
	private String fciid_3;
	private String fciid_4;
	private String fciid_5;
	private String fciid_6;
	private String fciid_7;
	private String fciid_8;
	private String phone2;
	private String deptcompany_abb;
	private String startdate;
	private String datasource;
	private String company_name;
	private String dataowner_ritsid;
	private String dm1;
	private String goc_code;
	private String tsa_indicator;
	private String direct_manager1_name;
	private String supervisor_name;
	private String hrgen_name;
	private String src_created_on;
	private String src_created_by_soeid;
	private String src_created_by_name;
	private String src_updated_on;
	private String src_updated_by_soeid;
	private String src_updated_by_name;
	private String bo_created_by;
	private String bo_created_on;
	private String bo_updated_by;
	private String bo_updated_on;
	private Date bo_emp_term_date;
	private String direct_manager1_geid;
	private String supervisor_geid;
	private String company_code;
	private String country_name;
	private String full_name;
	private String supervisor_firstname;
	private String supervisor_lastname;
	private String supervisor_email;
	private String latest_supervisor_geid;
	
	private String manSegmentId;
    private String dsmtRegionId;
    private String dsmtRegionName;
    private String dsmtSectorId;
    private String dsmtSectorName;
    private String dsmtBusinessUnitId;
    private String dsmtBusinessUnitName;
    
	public String getGeid() {
		return geid;
	}
	public void setGeid(String geid) {
		this.geid = geid;
	}
	public String getEmployee_class() {
		return employee_class;
	}
	public void setEmployee_class(String employeeClass) {
		employee_class = employeeClass;
	}
	public String getEmployee_class_desc() {
		return employee_class_desc;
	}
	public void setEmployee_class_desc(String employeeClassDesc) {
		employee_class_desc = employeeClassDesc;
	}
	public String getEmployee_status() {
		return employee_status;
	}
	public void setEmployee_status(String employeeStatus) {
		employee_status = employeeStatus;
	}
	public String getEmployee_status_desc() {
		return employee_status_desc;
	}
	public void setEmployee_status_desc(String employeeStatusDesc) {
		employee_status_desc = employeeStatusDesc;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getMiddlename() {
		return middlename;
	}
	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getName_prefix() {
		return name_prefix;
	}
	public void setName_prefix(String namePrefix) {
		name_prefix = namePrefix;
	}
	public String getLocation_code() {
		return location_code;
	}
	public void setLocation_code(String locationCode) {
		location_code = locationCode;
	}
	public String getExpense_code() {
		return expense_code;
	}
	public void setExpense_code(String expenseCode) {
		expense_code = expenseCode;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getDepartment_code() {
		return department_code;
	}
	public void setDepartment_code(String departmentCode) {
		department_code = departmentCode;
	}
	public String getDepartment_name() {
		return department_name;
	}
	public void setDepartment_name(String departmentName) {
		department_name = departmentName;
	}
	public String getDept_mgr_geid() {
		return dept_mgr_geid;
	}
	public void setDept_mgr_geid(String deptMgrGeid) {
		dept_mgr_geid = deptMgrGeid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getJob_code() {
		return job_code;
	}
	public void setJob_code(String jobCode) {
		job_code = jobCode;
	}
	public String getJob_ttl() {
		return job_ttl;
	}
	public void setJob_ttl(String jobTtl) {
		job_ttl = jobTtl;
	}
	public String getRits_id() {
		return rits_id;
	}
	public void setRits_id(String ritsId) {
		rits_id = ritsId;
	}
	public String getPrimary_loginid() {
		return primary_loginid;
	}
	public void setPrimary_loginid(String primaryLoginid) {
		primary_loginid = primaryLoginid;
	}
	public String getSoeid() {
		return soeid;
	}
	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}
	public String getTerminationdate() {
		return terminationdate;
	}
	public void setTerminationdate(String terminationdate) {
		this.terminationdate = terminationdate;
	}
	public String getLastupdatetm() {
		return lastupdatetm;
	}
	public void setLastupdatetm(String lastupdatetm) {
		this.lastupdatetm = lastupdatetm;
	}
	public String getEffdate() {
		return effdate;
	}
	public void setEffdate(String effdate) {
		this.effdate = effdate;
	}
	public String getPending_hire_indicator() {
		return pending_hire_indicator;
	}
	public void setPending_hire_indicator(String pendingHireIndicator) {
		pending_hire_indicator = pendingHireIndicator;
	}
	public String getHrgen_geid() {
		return hrgen_geid;
	}
	public void setHrgen_geid(String hrgenGeid) {
		hrgen_geid = hrgenGeid;
	}
	public String getSsid() {
		return ssid;
	}
	public void setSsid(String ssid) {
		this.ssid = ssid;
	}
	public String getOfficer_title_cd() {
		return officer_title_cd;
	}
	public void setOfficer_title_cd(String officerTitleCd) {
		officer_title_cd = officerTitleCd;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getBldg_floor() {
		return bldg_floor;
	}
	public void setBldg_floor(String bldgFloor) {
		bldg_floor = bldgFloor;
	}
	public String getBldg_zone() {
		return bldg_zone;
	}
	public void setBldg_zone(String bldgZone) {
		bldg_zone = bldgZone;
	}
	public String getPager() {
		return pager;
	}
	public void setPager(String pager) {
		this.pager = pager;
	}
	public String getRits_empl_type_code() {
		return rits_empl_type_code;
	}
	public void setRits_empl_type_code(String ritsEmplTypeCode) {
		rits_empl_type_code = ritsEmplTypeCode;
	}
	public String getRits_empl_type_code_desc() {
		return rits_empl_type_code_desc;
	}
	public void setRits_empl_type_code_desc(String ritsEmplTypeCodeDesc) {
		rits_empl_type_code_desc = ritsEmplTypeCodeDesc;
	}
	public String getRits_empl_status_code() {
		return rits_empl_status_code;
	}
	public void setRits_empl_status_code(String ritsEmplStatusCode) {
		rits_empl_status_code = ritsEmplStatusCode;
	}
	public String getRits_empl_status_code_desc() {
		return rits_empl_status_code_desc;
	}
	public void setRits_empl_status_code_desc(String ritsEmplStatusCodeDesc) {
		rits_empl_status_code_desc = ritsEmplStatusCodeDesc;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getStreet2() {
		return street2;
	}
	public void setStreet2(String street2) {
		this.street2 = street2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getOff_ttl() {
		return off_ttl;
	}
	public void setOff_ttl(String offTtl) {
		off_ttl = offTtl;
	}
	public String getFciid_1() {
		return fciid_1;
	}
	public void setFciid_1(String fciid_1) {
		this.fciid_1 = fciid_1;
	}
	public String getFciid_2() {
		return fciid_2;
	}
	public void setFciid_2(String fciid_2) {
		this.fciid_2 = fciid_2;
	}
	public String getFciid_3() {
		return fciid_3;
	}
	public void setFciid_3(String fciid_3) {
		this.fciid_3 = fciid_3;
	}
	public String getFciid_4() {
		return fciid_4;
	}
	public void setFciid_4(String fciid_4) {
		this.fciid_4 = fciid_4;
	}
	public String getFciid_5() {
		return fciid_5;
	}
	public void setFciid_5(String fciid_5) {
		this.fciid_5 = fciid_5;
	}
	public String getFciid_6() {
		return fciid_6;
	}
	public void setFciid_6(String fciid_6) {
		this.fciid_6 = fciid_6;
	}
	public String getFciid_7() {
		return fciid_7;
	}
	public void setFciid_7(String fciid_7) {
		this.fciid_7 = fciid_7;
	}
	public String getFciid_8() {
		return fciid_8;
	}
	public void setFciid_8(String fciid_8) {
		this.fciid_8 = fciid_8;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public String getDeptcompany_abb() {
		return deptcompany_abb;
	}
	public void setDeptcompany_abb(String deptcompanyAbb) {
		deptcompany_abb = deptcompanyAbb;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getDatasource() {
		return datasource;
	}
	public void setDatasource(String datasource) {
		this.datasource = datasource;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String companyName) {
		company_name = companyName;
	}
	public String getDataowner_ritsid() {
		return dataowner_ritsid;
	}
	public void setDataowner_ritsid(String dataownerRitsid) {
		dataowner_ritsid = dataownerRitsid;
	}
	public String getDm1() {
		return dm1;
	}
	public void setDm1(String dm1) {
		this.dm1 = dm1;
	}
	public String getGoc_code() {
		return goc_code;
	}
	public void setGoc_code(String gocCode) {
		goc_code = gocCode;
	}
	public String getTsa_indicator() {
		return tsa_indicator;
	}
	public void setTsa_indicator(String tsaIndicator) {
		tsa_indicator = tsaIndicator;
	}
	public String getDirect_manager1_name() {
		return direct_manager1_name;
	}
	public void setDirect_manager1_name(String directManager1Name) {
		direct_manager1_name = directManager1Name;
	}
	public String getSupervisor_name() {
		return supervisor_name;
	}
	public void setSupervisor_name(String supervisorName) {
		supervisor_name = supervisorName;
	}
	public String getHrgen_name() {
		return hrgen_name;
	}
	public void setHrgen_name(String hrgenName) {
		hrgen_name = hrgenName;
	}
	public String getSrc_created_on() {
		return src_created_on;
	}
	public void setSrc_created_on(String srcCreatedOn) {
		src_created_on = srcCreatedOn;
	}
	public String getSrc_created_by_soeid() {
		return src_created_by_soeid;
	}
	public void setSrc_created_by_soeid(String srcCreatedBySoeid) {
		src_created_by_soeid = srcCreatedBySoeid;
	}
	public String getSrc_created_by_name() {
		return src_created_by_name;
	}
	public void setSrc_created_by_name(String srcCreatedByName) {
		src_created_by_name = srcCreatedByName;
	}
	public String getSrc_updated_on() {
		return src_updated_on;
	}
	public void setSrc_updated_on(String srcUpdatedOn) {
		src_updated_on = srcUpdatedOn;
	}
	public String getSrc_updated_by_soeid() {
		return src_updated_by_soeid;
	}
	public void setSrc_updated_by_soeid(String srcUpdatedBySoeid) {
		src_updated_by_soeid = srcUpdatedBySoeid;
	}
	public String getSrc_updated_by_name() {
		return src_updated_by_name;
	}
	public void setSrc_updated_by_name(String srcUpdatedByName) {
		src_updated_by_name = srcUpdatedByName;
	}
	public String getBo_created_by() {
		return bo_created_by;
	}
	public void setBo_created_by(String boCreatedBy) {
		bo_created_by = boCreatedBy;
	}
	public String getBo_created_on() {
		return bo_created_on;
	}
	public void setBo_created_on(String boCreatedOn) {
		bo_created_on = boCreatedOn;
	}
	public String getBo_updated_by() {
		return bo_updated_by;
	}
	public void setBo_updated_by(String boUpdatedBy) {
		bo_updated_by = boUpdatedBy;
	}
	public String getBo_updated_on() {
		return bo_updated_on;
	}
	public void setBo_updated_on(String boUpdatedOn) {
		bo_updated_on = boUpdatedOn;
	}
	public Date getBo_emp_term_date() {
		return bo_emp_term_date;
	}
	public void setBo_emp_term_date(Date boEmpTermDate) {
		bo_emp_term_date = boEmpTermDate;
	}
	public String getDirect_manager1_geid() {
		return direct_manager1_geid;
	}
	public void setDirect_manager1_geid(String directManager1Geid) {
		direct_manager1_geid = directManager1Geid;
	}
	public String getSupervisor_geid() {
		return supervisor_geid;
	}
	public void setSupervisor_geid(String supervisorGeid) {
		supervisor_geid = supervisorGeid;
	}
	public String getCompany_code() {
		return company_code;
	}
	public void setCompany_code(String companyCode) {
		company_code = companyCode;
	}
	public String getCountry_name() {
		return country_name;
	}
	public void setCountry_name(String countryName) {
		country_name = countryName;
	}
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String fullName) {
		full_name = fullName;
	}
	public String getSupervisor_lastname() {
		return supervisor_lastname;
	}
	public void setSupervisor_lastname(String supervisorLastname) {
		supervisor_lastname = supervisorLastname;
	}
	public String getSupervisor_firstname() {
		return supervisor_firstname;
	}
	public void setSupervisor_firstname(String supervisorFirstname) {
		supervisor_firstname = supervisorFirstname;
	}
	public String getSupervisor_email() {
		return supervisor_email;
	}
	public void setSupervisor_email(String supervisorEmail) {
		supervisor_email = supervisorEmail;
	}
	public String getLatest_supervisor_geid() {
		return latest_supervisor_geid;
	}
	public void setLatest_supervisor_geid(String latestSupervisor) {
		latest_supervisor_geid = latestSupervisor;
	}
	public String getManSegmentId() {
		return manSegmentId;
	}
	public void setManSegmentId(String manSegmentId) {
		this.manSegmentId = manSegmentId;
	}
	public String getDsmtRegionId() {
		return dsmtRegionId;
	}
	public void setDsmtRegionId(String dsmtRegionId) {
		this.dsmtRegionId = dsmtRegionId;
	}
	public String getDsmtRegionName() {
		return dsmtRegionName;
	}
	public void setDsmtRegionName(String dsmtRegionName) {
		this.dsmtRegionName = dsmtRegionName;
	}
	public String getDsmtSectorId() {
		return dsmtSectorId;
	}
	public void setDsmtSectorId(String dsmtSectorId) {
		this.dsmtSectorId = dsmtSectorId;
	}
	public String getDsmtSectorName() {
		return dsmtSectorName;
	}
	public void setDsmtSectorName(String dsmtSectorName) {
		this.dsmtSectorName = dsmtSectorName;
	}
	public String getDsmtBusinessUnitId() {
		return dsmtBusinessUnitId;
	}
	public void setDsmtBusinessUnitId(String dsmtBusinessUnitId) {
		this.dsmtBusinessUnitId = dsmtBusinessUnitId;
	}
	public String getDsmtBusinessUnitName() {
		return dsmtBusinessUnitName;
	}
	public void setDsmtBusinessUnitName(String dsmtBusinessUnitName) {
		this.dsmtBusinessUnitName = dsmtBusinessUnitName;
	}
	
	
	
	

}
