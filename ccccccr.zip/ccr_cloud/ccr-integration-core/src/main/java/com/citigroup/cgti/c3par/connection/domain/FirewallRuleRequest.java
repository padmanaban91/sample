package com.citigroup.cgti.c3par.connection.domain;

import java.util.List;


/**
 * The Class FirewallRuleRequest.
 */
public class FirewallRuleRequest {

    /** The is start point rip selected. */
    private boolean isStartPointRIPSelected;

    /** The is start point rip natted. */
    private boolean isStartPointRIPNatted;

    /** The is end point rip selected. */
    private boolean isEndPointRIPSelected;

    /** The is end point rip natted. */
    private boolean isEndPointRIPNatted;

    /** The is start point vip selected. */
    private boolean isStartPointVIPSelected;

    /** The is start point vip natted. */
    private boolean isStartPointVIPNatted;

    /** The is endpoint vip selected. */
    private boolean isEndpointVIPSelected;

    /** The is endpoint vip natted. */
    private boolean isEndpointVIPNatted;

    /** The start point rip. */
    private String startPointRIP;

    /** The end point rip. */
    private String endPointRIP;

    /** The start point vip. */
    private String startPointVIP;

    /** The end point vip. */
    private String endPointVIP;

    //Added for Firewall Multizone - Task 9628  - Starts
    /** The from zone. */
    private Long fromZone;

    /** The to zone. */
    private Long toZone;

    /** The mid point zone. */
    private Long midPointZone;

    /** The is zoned. */
    private boolean isZoned;

    /** The from zone list. */
    private List fromZoneList;

    /** The to zone list. */
    private List toZoneList;

    /** The mid point zone list. */
    private List midPointZoneList;
    //Added for Firewall Multizone - Task 9628  - Ends

    /** The Connection firewall list. */
    private List ConnectionFirewallList;

    /** The acl variance list. */
    private List aclVarianceList;

    private boolean disableFrom;

    private boolean disableTo;

    private boolean disableMid;

    /**
     * Gets the connection firewall list.
     *
     * @return the connection firewall list
     */
    public List getConnectionFirewallList() {
	return ConnectionFirewallList;
    }

    /**
     * Sets the connection firewall list.
     *
     * @param connectionFirewallList the new connection firewall list
     */
    public void setConnectionFirewallList(List connectionFirewallList) {
	ConnectionFirewallList = connectionFirewallList;
    }

    /**
     * Checks if is end point rip natted.
     *
     * @return true, if is end point rip natted
     */
    public boolean isEndPointRIPNatted() {
	return isEndPointRIPNatted;
    }

    /**
     * Sets the end point rip natted.
     *
     * @param isEndPointRIPNatted the new end point rip natted
     */
    public void setEndPointRIPNatted(boolean isEndPointRIPNatted) {
	this.isEndPointRIPNatted = isEndPointRIPNatted;
    }

    /**
     * Checks if is end point rip selected.
     *
     * @return true, if is end point rip selected
     */
    public boolean isEndPointRIPSelected() {
	return isEndPointRIPSelected;
    }

    /**
     * Sets the end point rip selected.
     *
     * @param isEndPointRIPSelected the new end point rip selected
     */
    public void setEndPointRIPSelected(boolean isEndPointRIPSelected) {
	this.isEndPointRIPSelected = isEndPointRIPSelected;
    }

    /**
     * Checks if is endpoint vip natted.
     *
     * @return true, if is endpoint vip natted
     */
    public boolean isEndpointVIPNatted() {
	return isEndpointVIPNatted;
    }

    /**
     * Sets the endpoint vip natted.
     *
     * @param isEndpointVIPNatted the new endpoint vip natted
     */
    public void setEndpointVIPNatted(boolean isEndpointVIPNatted) {
	this.isEndpointVIPNatted = isEndpointVIPNatted;
    }

    /**
     * Checks if is endpoint vip selected.
     *
     * @return true, if is endpoint vip selected
     */
    public boolean isEndpointVIPSelected() {
	return isEndpointVIPSelected;
    }

    /**
     * Sets the endpoint vip selected.
     *
     * @param isEndpointVIPSelected the new endpoint vip selected
     */
    public void setEndpointVIPSelected(boolean isEndpointVIPSelected) {
	this.isEndpointVIPSelected = isEndpointVIPSelected;
    }

    /**
     * Checks if is start point rip natted.
     *
     * @return true, if is start point rip natted
     */
    public boolean isStartPointRIPNatted() {
	return isStartPointRIPNatted;
    }

    /**
     * Sets the start point rip natted.
     *
     * @param isStartPointRIPNatted the new start point rip natted
     */
    public void setStartPointRIPNatted(boolean isStartPointRIPNatted) {
	this.isStartPointRIPNatted = isStartPointRIPNatted;
    }

    /**
     * Checks if is start point rip selected.
     *
     * @return true, if is start point rip selected
     */
    public boolean isStartPointRIPSelected() {
	return isStartPointRIPSelected;
    }

    /**
     * Sets the start point rip selected.
     *
     * @param isStartPointRIPSelected the new start point rip selected
     */
    public void setStartPointRIPSelected(boolean isStartPointRIPSelected) {
	this.isStartPointRIPSelected = isStartPointRIPSelected;
    }

    /**
     * Checks if is start point vip natted.
     *
     * @return true, if is start point vip natted
     */
    public boolean isStartPointVIPNatted() {
	return isStartPointVIPNatted;
    }

    /**
     * Sets the start point vip natted.
     *
     * @param isStartPointVIPNatted the new start point vip natted
     */
    public void setStartPointVIPNatted(boolean isStartPointVIPNatted) {
	this.isStartPointVIPNatted = isStartPointVIPNatted;
    }

    /**
     * Checks if is start point vip selected.
     *
     * @return true, if is start point vip selected
     */
    public boolean isStartPointVIPSelected() {
	return isStartPointVIPSelected;
    }

    /**
     * Sets the start point vip selected.
     *
     * @param isStartPointVIPSelected the new start point vip selected
     */
    public void setStartPointVIPSelected(boolean isStartPointVIPSelected) {
	this.isStartPointVIPSelected = isStartPointVIPSelected;
    }

    /**
     * Gets the acl variance list.
     *
     * @return the acl variance list
     */
    public List getAclVarianceList() {
	return aclVarianceList;
    }

    /**
     * Sets the acl variance list.
     *
     * @param aclVarianceList the new acl variance list
     */
    public void setAclVarianceList(List aclVarianceList) {
	this.aclVarianceList = aclVarianceList;
    }

    /**
     * Gets the end point rip.
     *
     * @return the end point rip
     */
    public String getEndPointRIP() {
	return endPointRIP;
    }

    /**
     * Sets the end point rip.
     *
     * @param endPointRIP the new end point rip
     */
    public void setEndPointRIP(String endPointRIP) {
	this.endPointRIP = endPointRIP;
    }

    /**
     * Gets the end point vip.
     *
     * @return the end point vip
     */
    public String getEndPointVIP() {
	return endPointVIP;
    }

    /**
     * Sets the end point vip.
     *
     * @param endPointVIP the new end point vip
     */
    public void setEndPointVIP(String endPointVIP) {
	this.endPointVIP = endPointVIP;
    }

    /**
     * Gets the start point rip.
     *
     * @return the start point rip
     */
    public String getStartPointRIP() {
	return startPointRIP;
    }

    /**
     * Sets the start point rip.
     *
     * @param startPointRIP the new start point rip
     */
    public void setStartPointRIP(String startPointRIP) {
	this.startPointRIP = startPointRIP;
    }

    /**
     * Gets the start point vip.
     *
     * @return the start point vip
     */
    public String getStartPointVIP() {
	return startPointVIP;
    }

    /**
     * Sets the start point vip.
     *
     * @param startPointVIP the new start point vip
     */
    public void setStartPointVIP(String startPointVIP) {
	this.startPointVIP = startPointVIP;
    }

    /**
     * Gets the from zone.
     *
     * @return the from zone
     */
    public Long getFromZone() {
	return fromZone;
    }

    /**
     * Sets the from zone.
     *
     * @param fromZone the new from zone
     */
    public void setFromZone(Long fromZone) {
	this.fromZone = fromZone;
    }

    /**
     * Gets the to zone.
     *
     * @return the to zone
     */
    public Long getToZone() {
	return toZone;
    }

    /**
     * Sets the to zone.
     *
     * @param toZone the new to zone
     */
    public void setToZone(Long toZone) {
	this.toZone = toZone;
    }

    /**
     * Gets the mid point zone.
     *
     * @return the mid point zone
     */
    public Long getMidPointZone() {
	return midPointZone;
    }

    /**
     * Sets the mid point zone.
     *
     * @param midPointZone the new mid point zone
     */
    public void setMidPointZone(Long midPointZone) {
	this.midPointZone = midPointZone;
    }

    /**
     * Checks if is zoned.
     *
     * @return true, if is zoned
     */
    public boolean isZoned() {
	return isZoned;
    }

    /**
     * Sets the zoned.
     *
     * @param isZoned the new zoned
     */
    public void setZoned(boolean isZoned) {
	this.isZoned = isZoned;
    }

    /**
     * Gets the from zone list.
     *
     * @return the from zone list
     */
    public List getFromZoneList() {
	return fromZoneList;
    }

    /**
     * Sets the from zone list.
     *
     * @param fromZoneList the new from zone list
     */
    public void setFromZoneList(List fromZoneList) {
	this.fromZoneList = fromZoneList;
    }

    /**
     * Gets the to zone list.
     *
     * @return the to zone list
     */
    public List getToZoneList() {
	return toZoneList;
    }

    /**
     * Sets the to zone list.
     *
     * @param toZoneList the new to zone list
     */
    public void setToZoneList(List toZoneList) {
	this.toZoneList = toZoneList;
    }

    /**
     * Gets the mid point zone list.
     *
     * @return the mid point zone list
     */
    public List getMidPointZoneList() {
	return midPointZoneList;
    }

    /**
     * Sets the mid point zone list.
     *
     * @param midPointZoneList the new mid point zone list
     */
    public void setMidPointZoneList(List midPointZoneList) {
	this.midPointZoneList = midPointZoneList;
    }

    public boolean isDisableFrom() {
	return disableFrom;
    }

    public void setDisableFrom(boolean disableFrom) {
	this.disableFrom = disableFrom;
    }

    public boolean isDisableTo() {
	return disableTo;
    }

    public void setDisableTo(boolean disableTo) {
	this.disableTo = disableTo;
    }

    public boolean isDisableMid() {
	return disableMid;
    }

    public void setDisableMid(boolean disableMid) {
	this.disableMid = disableMid;
    }


}
