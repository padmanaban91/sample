/**
 *
 */
package com.citigroup.cgti.c3par.fw.domain;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.decisionservice.DecisionServiceSoapFault;
import com.citigroup.cgti.c3par.decisionservice.TiRequestDTO;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author bs45969
 *
 */
public class FireWallRuleProcess {
    
    /** The log. */
    private static Logger log = Logger.getLogger(FireWallRuleProcess.class);

    //properties used for search
    private long ruleId;
    private Long cloneFromRuleID;
    private long tiProcess;
    private long tiRequest;
    private long updatedTIRequest;
    private long deletedTIRequest;
    private String sourceIPAddress;
    private String destinationIPAddress;
    private String portNumber;
    private String sourceZone;
    private String destinationZone;
    //for filter in ostia
    private String status;
    private String riskCode;
   
    private String policyGroup;
    private String filterText;
    private String bidirectionalStatus;
    
	private String location;
    private String connectivityType;
    private String fwName;
    private String fwType;
    private String policy;
    private String firewallGroup;
    
	private CommonsMultipartFile uploadedFile;
    private String downloadType;
    
    //properties used for returning result
    //@Valid
    private FireWallRule fireWallRule;
    private List<FireWallRule> fireWallRules;
    //properties used for pagination
    private int rowCount;
    private int offset;
    private int limit;
    private int pageNo;
    private int totalPages;
    private String isIpReg;
   
	private String field;
    private int collectionLimit;
    private List<IPAddress> ipAddressList;
    private List<FireWallZone> firewallZones;
    private List<GenericLookup> controlMessagesList;
    private List<FireWallPolicyGroup> firewallGroupList;
    private List<FirewallPolicy> firewallPolicyList;
    private List<FafFireflowTicket> fafFireflowTicketList;

    private List<FirewallLocation> fwLocations;
    private List<GenericLookup> connectivityTypes;
    private List<GenericLookup> protocolList;
    private List<GenericLookup> firewallTypes;
    private List<ResourceType> resourceTypes;
    private List<ResourceType> ipResourceTypes;
    
	private List<TIUploadedDocs> bulkUploadFiles; 
    private String bulkUploadFileName;
    private String bulkUploadFilePath;
    private TIUploadedDocs firewallRuleFile;
    
    private String description;
    private String typeOfTraffic;
    private Long controlMsgId;     
    private boolean isClone;
    
    private List<Port> portObjectsList;
    
    private String relationshipType;
    private int requesterResourceType;
    private int targetResourceType;
    private int templateResourceType;
    private String objectNamePrefix;

	private List<FireWallRuleIP> firewallRuleIPList;
    private List<FireWallRulePort> firewallRulePortList;
    private List<TemplateConnection> templateConnectionList;
    private Long templateID;
    //ostia properties
    private List<RiskDefinition> riskDefinitions;
    private List<FirewallRuleQuestionnaire> firewallRuleQuestionnaires;
    private List<OstiaQuestion> ostiaQuestions;
	private List<FirewallRuleOstiaQuestion> firewallRuleOstiaQuestions;
 
	private HashMap<String, List<FirewallRuleOstiaQuestion>> firewallRuleOstiaMapAnswers;
	private FireWallRule ostiaFireWallRule;
	private FirewallRuleQuestionnaire firewallRuleQuestionnaire;
	//pagination related properties. may be included in base class after review
	private boolean paginationRequired;
	private int firstResult;
	private int maxResult;
	
	private boolean portNotEditable;
	private boolean sipNotEditable;
	private boolean dipNotEditable;
	
	private boolean incompleteRules;
	private Double aggregate;
	private Double cycleAggregate;
	private Long ipCount;
	private long validConnectionID;
	
	private String fromPage;
	private String tab;
	private Long cloneFrom;
	private List<Long> cloneTo;
	private String userQuestionnaireName;
	private String pageFlow;
	
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	//Added for task 42665
	private List<HistoryFireWallRule> historyFireWallRules;

	public long getValidConnectionID() {
		try {
			if(filterText!=null){filterText=filterText.trim();}
			validConnectionID = Long.parseLong(filterText);
		} catch (Exception e) {
			validConnectionID = 0;
		}
		return validConnectionID;
	}

	public void setValidConnectionID(long validConnectionID) {
		this.validConnectionID = validConnectionID;
	}

	private String validConnectionName;

	public String getValidConnectionName() {
		return validString(validConnectionName);
	}

	public void setValidConnectionName(String validConnectionName) {
		this.validConnectionName = validConnectionName;
	}

	protected String validString(String filterText) {
		StringBuffer sbf = new StringBuffer();
		String retStr = null;
		if ((filterText == null) || (filterText.trim().equals(""))
				|| (filterText.trim().equals("*"))) {
			retStr = null;
		} else if (filterText.indexOf("*") > -1) {
			sbf.append(filterText.replaceAll("\\*", "%"));
			retStr = sbf.toString();
		} else {
			sbf.append(filterText);
			retStr = sbf.toString();
		}
		return retStr;

	}
	
    public String getPageFlow() {
		return pageFlow;
	}

	public void setPageFlow(String pageFlow) {
		this.pageFlow = pageFlow;
	}

	public String getFromPage() {
		return fromPage;
	}

	public void setFromPage(String fromPage) {
		this.fromPage = fromPage;
	}

	public String getTab() {
		return tab;
	}

	public void setTab(String tab) {
		this.tab = tab;
	}

	public Long getCloneFrom() {
		return cloneFrom;
	}

	public void setCloneFrom(Long cloneFrom) {
		this.cloneFrom = cloneFrom;
	}

	public List<Long> getCloneTo() {
		return cloneTo;
	}

	public void setCloneTo(List<Long> cloneTo) {
		this.cloneTo = cloneTo;
	}

	public String getUserQuestionnaireName() {
		return userQuestionnaireName;
	}

	public void setUserQuestionnaireName(String userQuestionnaireName) {
		this.userQuestionnaireName = userQuestionnaireName;
	}

	/**
	 * @return the riskDefinitions
	 */
	public List<RiskDefinition> getRiskDefinitions() {
		return riskDefinitions;
	}

	/**
	 * @param riskDefinitions the riskDefinitions to set
	 */
	public void setRiskDefinitions(List<RiskDefinition> riskDefinitions) {
		this.riskDefinitions = riskDefinitions;
	}

	/**
	 * @return the firewallRuleQuestionnaires
	 */
	public List<FirewallRuleQuestionnaire> getFirewallRuleQuestionnaires() {
		return firewallRuleQuestionnaires;
	}

	/**
	 * @param firewallRuleQuestionnaires the firewallRuleQuestionnaires to set
	 */
	public void setFirewallRuleQuestionnaires(
			List<FirewallRuleQuestionnaire> firewallRuleQuestionnaires) {
		this.firewallRuleQuestionnaires = firewallRuleQuestionnaires;
	}

	/**
	 * @return the ostiaQuestions
	 */
	public List<OstiaQuestion> getOstiaQuestions() {
		return ostiaQuestions;
	}

	/**
	 * @param ostiaQuestions the ostiaQuestions to set
	 */
	public void setOstiaQuestions(List<OstiaQuestion> ostiaQuestions) {
		this.ostiaQuestions = ostiaQuestions;
	}

	/**
	 * @return the firewallRuleOstiaQuestions
	 */
	public List<FirewallRuleOstiaQuestion> getFirewallRuleOstiaAnswers() {
		return firewallRuleOstiaQuestions;
	}

	/**
	 * @param firewallRuleOstiaQuestions the firewallRuleOstiaQuestions to set
	 */
	public void setFirewallRuleOstiaAnswers(
			List<FirewallRuleOstiaQuestion> firewallRuleOstiaQuestions) {
		this.firewallRuleOstiaQuestions = firewallRuleOstiaQuestions;
	}

	
	
	/**
	 * @return the ostiaFireWallRule
	 */
	public FireWallRule getOstiaFireWallRule() {
		return ostiaFireWallRule;
	}

	/**
	 * @param ostiaFireWallRule the ostiaFireWallRule to set
	 */
	public void setOstiaFireWallRule(FireWallRule ostiaFireWallRule) {
		this.ostiaFireWallRule = ostiaFireWallRule;
	}

	
     
    public List<ResourceType> getResourceTypes() {
		return resourceTypes;
	}

	public void setResourceTypes(List<ResourceType> resourceTypes) {
		this.resourceTypes = resourceTypes;
	}

	private List<Firewall> firewalls;

    public String getBidirectionalStatus() {
		return bidirectionalStatus;
	}

	public void setBidirectionalStatus(String bidirectionalStatus) {
		this.bidirectionalStatus = bidirectionalStatus;
	}

	/**
     * @return the ruleId
     */
    public long getRuleId() {
	return ruleId;
    }

    /**
     * @param ruleId the ruleId to set
     */
    public void setRuleId(long ruleId) {
	this.ruleId = ruleId;
    }


	
    /**
     * @return the tiProcess
     */
    public long getTiProcess() {
	return tiProcess;
    }

    /**
     * @param tiProcess the tiProcess to set
     */
    public void setTiProcess(long tiProcess) {
	this.tiProcess = tiProcess;
    }

    /**
     * @return the tiRequest
     */
    public long getTiRequest() {
	return tiRequest;
    }

    /**
     * @param tiRequest the tiRequest to set
     */
    public void setTiRequest(long tiRequest) {
	this.tiRequest = tiRequest;
    }

    /**
     * @return the updatedTIRequest
     */
    public long getUpdatedTIRequest() {
	return updatedTIRequest;
    }

    /**
     * @param updatedTIRequest the updatedTIRequest to set
     */
    public void setUpdatedTIRequest(long updatedTIRequest) {
	this.updatedTIRequest = updatedTIRequest;
    }

    /**
     * @return the deletedTIRequest
     */
    public long getDeletedTIRequest() {
	return deletedTIRequest;
    }

    /**
     * @param deletedTIRequest the deletedTIRequest to set
     */
    public void setDeletedTIRequest(long deletedTIRequest) {
	this.deletedTIRequest = deletedTIRequest;
    }

    /**
     * @return the sourceIPAddress
     */
    public String getSourceIPAddress() {
	return sourceIPAddress;
    }

    /**
     * @param sourceIPAddress the sourceIPAddress to set
     */
    public void setSourceIPAddress(String sourceIPAddress) {
	this.sourceIPAddress = sourceIPAddress;
    }

    /**
     * @return the destinationIPAddress
     */
    public String getDestinationIPAddress() {
	return destinationIPAddress;
    }

    /**
     * @param destinationIPAddress the destinationIPAddress to set
     */
    public void setDestinationIPAddress(String destinationIPAddress) {
	this.destinationIPAddress = destinationIPAddress;
    }

    /**
     * @return the portNumber
     */
    public String getPortNumber() {
	return portNumber;
    }

    /**
     * @param portNumber the portNumber to set
     */
    public void setPortNumber(String portNumber) {
	this.portNumber = portNumber;
    }

    /**
     * @return the sourceZone
     */
    public String getSourceZone() {
	return sourceZone;
    }

    /**
     * @param sourceZone the sourceZone to set
     */
    public void setSourceZone(String sourceZone) {
	this.sourceZone = sourceZone;
    }

    /**
     * @return the destinationZone
     */
    public String getDestinationZone() {
	return destinationZone;
    }

    /**
     * @param destinationZone the destinationZone to set
     */
    public void setDestinationZone(String destinationZone) {
	this.destinationZone = destinationZone;
    }

    
       /**
     * @return the policyGroup
     */
    public String getPolicyGroup() {
	return policyGroup;
    }

    /**
     * @param policyGroup the policyGroup to set
     */
    public void setPolicyGroup(String policyGroup) {
	this.policyGroup = policyGroup;
    }

    /**
     * @return the policy
     */
    public String getPolicy() {
	return policy;
    }

    /**
     * @param policy the policy to set
     */
    public void setPolicy(String policy) {
	this.policy = policy;
    }

    /**
     * @return the fireWallRule
     */
    public FireWallRule getFireWallRule() {
	return fireWallRule;
    }

    /**
     * @param fireWallRule the fireWallRule to set
     */
    public void setFireWallRule(FireWallRule fireWallRule) {
	this.fireWallRule = fireWallRule;
    }

    /**
     * @return the fireWallRules
     */
    public List<FireWallRule> getFireWallRules() {
	return fireWallRules;
    }

    /**
     * @param fireWallRules the fireWallRules to set
     */
    public void setFireWallRules(List<FireWallRule> fireWallRules) {
	this.fireWallRules = fireWallRules;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
	return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
	this.rowCount = rowCount;
    }

    /**
     * @return the offset
     */
    public int getOffset() {
	return offset;
    }

    /**
     * @param offset the offset to set
     */
    public void setOffset(int offset) {
	this.offset = offset;
    }

    /**
     * @return the limit
     */
    public int getLimit() {
	return limit;
    }

    /**
     * @param limit the limit to set
     */
    public void setLimit(int limit) {
	this.limit = limit;
    }
    
    
   

    /**
     * @return the firewallZones
     */
    public List<FireWallZone> getFirewallZones() {
	return firewallZones;
    }

    /**
     * @param firewallZones the firewallZones to set
     */
    public void setFirewallZones(List<FireWallZone> firewallZones) {
	this.firewallZones = firewallZones;
    }

    /**
     * @return the controlMessagesList
     */
    public List<GenericLookup> getControlMessagesList() {
	return controlMessagesList;
    }

    /**
     * @param controlMessagesList the controlMessagesList to set
     */
    public void setControlMessagesList(List<GenericLookup> controlMessagesList) {
	this.controlMessagesList = controlMessagesList;
    }

    /**
     * @return the firewallGroupList
     */
    public List<FireWallPolicyGroup> getFirewallGroupList() {
	return firewallGroupList;
    }

    /**
     * @param firewallGroupList the firewallGroupList to set
     */
    public void setFirewallGroupList(List<FireWallPolicyGroup> firewallGroupList) {
	this.firewallGroupList = firewallGroupList;
    }

    /**
     * @return the firewallPolicyList
     */
    public List<FirewallPolicy> getFirewallPolicyList() {
	return firewallPolicyList;
    }

    /**
     * @param firewallPolicyList the firewallPolicyList to set
     */
    public void setFirewallPolicyList(List<FirewallPolicy> firewallPolicyList) {
	this.firewallPolicyList = firewallPolicyList;
    }

    /**
     * @return the filterText
     */
    public String getFilterText() {
	return filterText;
    }

    /**
     * @param filterText the filterText to set
     */
    public void setFilterText(String filterText) {
	this.filterText = filterText;
    }

    /**
     * @return the fwLocations
     */
    public List<FirewallLocation> getFwLocations() {
	return fwLocations;
    }

    /**
     * @param fwLocations the fwLocations to set
     */
    public void setFwLocations(List<FirewallLocation> fwLocations) {
	this.fwLocations = fwLocations;
    }

    /**
     * @return the connectivityTypes
     */
    public List<GenericLookup> getConnectivityTypes() {
	return connectivityTypes;
    }

    /**
     * @param connectivityTypes the connectivityTypes to set
     */
    public void setConnectivityTypes(List<GenericLookup> connectivityTypes) {
	this.connectivityTypes = connectivityTypes;
    }

    /**
     * @return the fwType
     */
    public String getFwType() {
	return fwType;
    }

    /**
     * @param fwType the fwType to set
     */
    public void setFwType(String fwType) {
	this.fwType = fwType;
    }

    /**
     * @return the fafFireflowTicketList
     */
    public List<FafFireflowTicket> getFafFireflowTicketList() {
	return fafFireflowTicketList;
    }

    /**
     * @param fafFireflowTicketList the fafFireflowTicketList to set
     */
    public void setFafFireflowTicketList(
	    List<FafFireflowTicket> fafFireflowTicketList) {
	this.fafFireflowTicketList = fafFireflowTicketList;
    }

    /**
     * @return the ipAddressList
     */
    public List<IPAddress> getIpAddressList() {
	return ipAddressList;
    }

    /**
     * @param ipAddressList the ipAddressList to set
     */
    public void setIpAddressList(List<IPAddress> ipAddressList) {
	this.ipAddressList = ipAddressList;
    }

    /**
     * @return the field
     */
    public String getField() {
	return field;
    }

    /**
     * @param field the field to set
     */
    public void setField(String field) {
	this.field = field;
    }

    /**
     * @return the firewalls
     */
    public List<Firewall> getFirewalls() {
	return firewalls;
    }

    /**
     * @param firewalls the firewalls to set
     */
    public void setFirewalls(List<Firewall> firewalls) {
	this.firewalls = firewalls;
    }
    
    /**
	 * @return the pageNo
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * @param pageNo the pageNo to set
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * @return the totalPages
	 */
	public int getTotalPages() {
		return totalPages;
	}

	/**
	 * @param totalPages the totalPages to set
	 */
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the typeOfTraffic
	 */
	public String getTypeOfTraffic() {
		return typeOfTraffic;
	}

	/**
	 * @param typeOfTraffic the typeOfTraffic to set
	 */
	public void setTypeOfTraffic(String typeOfTraffic) {
		this.typeOfTraffic = typeOfTraffic;
	}

	/**
	 * @return the controlMsgId
	 */
	public Long getControlMsgId() {
		return controlMsgId;
	}

	/**
	 * @param controlMsgId the controlMsgId to set
	 */
	public void setControlMsgId(Long controlMsgId) {
		this.controlMsgId = controlMsgId;
	}
	
	/**
	 * @return the collectionLimit
	 */
	public int getCollectionLimit() {
	    return collectionLimit;
	}

	/**
	 * @param collectionLimit the collectionLimit to set
	 */
	public void setCollectionLimit(int collectionLimit) {
	    this.collectionLimit = collectionLimit;
	}
	
	/**
	 * @return the isClone
	 */
	public boolean isClone() {
		return isClone;
	}

	/**
	 * @param isClone the isClone to set
	 */
	public void setClone(boolean isClone) {
		this.isClone = isClone;
	}

	
	public CommonsMultipartFile getUploadedFile() {
		return uploadedFile;
	}

	public void setUploadedFile(CommonsMultipartFile uploadedFile) {
		this.uploadedFile = uploadedFile;
	}

	/**
	 * @return the protocolList
	 */
	public List<GenericLookup> getProtocolList() {
		return protocolList;
	}

	/**
	 * @param protocolList the protocolList to set
	 */
	public void setProtocolList(List<GenericLookup> protocolList) {
		this.protocolList = protocolList;
	}

	/**
	 * @return the firewallTypes
	 */
	public List<GenericLookup> getFirewallTypes() {
		return firewallTypes;
	}

	/**
	 * @param firewallTypes the firewallTypes to set
	 */
	public void setFirewallTypes(List<GenericLookup> firewallTypes) {
		this.firewallTypes = firewallTypes;
	}

	/**
	 * @return the downloadType
	 */
	public String getDownloadType() {
		return downloadType;
	}

	/**
	 * @param downloadType the downloadType to set
	 */
	public void setDownloadType(String downloadType) {
		this.downloadType = downloadType;
	}
	
	/**
	 * @return the portObjectsList
	 */
	public List<Port> getPortObjectsList() {
		return portObjectsList;
	}

	/**
	 * @param portObjectsList the portObjectsList to set
	 */
	public void setPortObjectsList(List<Port> portObjectsList) {
		this.portObjectsList = portObjectsList;
	}
	
    //###################### Logic in Domain class starts###################//

	/*@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public Long saveFireWallRule()  throws BusinessException {
	long id = firewallRuleProcessPersistable
		.saveFireWallRule(this.fireWallRule);
	firewallRuleProcessPersistable.resetFAFGeneratedStatus(
		this.fireWallRule.getUpdatedTIRequest().getId(),
		this.fireWallRule.getPolicyGroup().getId());
	return id;

    }*/
	

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void resetFAFGeneratedStatus() {
		long policyGroup = 0, ObjRuleID = 0;
		if(this.fireWallRule.getPolicyGroup() != null){
			policyGroup = this.fireWallRule.getPolicyGroup().getId();
		}
		ObjRuleID = this.fireWallRule.getId();
		ccrBeanFactory.getFirewallRuleProcessPersistable().resetFAFGeneratedStatus(this.getTiRequest(),policyGroup, ObjRuleID,this.fireWallRule.getIsIpReg());				
	}

    
    public List<FireWallZone> findFirewallZones(Long firewallGroup,
	    Long firewallPolicy) {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallZones(firewallGroup,
		firewallPolicy);
    }

    
    public int getFirewallRulesRowCount(FireWallRuleProcess fwRuleProcess) {
	return ccrBeanFactory.getFirewallRuleProcessPersistable()
		.getFirewallRulesRowCount(fwRuleProcess);
    }

    
    public String getServiceName(Long portNumber) throws BusinessException {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getServiceName(portNumber);
    }

    
    public List<FireWallPolicyGroup> findFirewallGroups(Long fwLocation,
	    Long connectivityType) {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallGroups(fwLocation,
		connectivityType);
    }

    
    public List<FirewallPolicy> getFirewallPolicies() {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallPolicies(this);
    }

    
    public List<FirewallLocation> getFirewallLocations() {
	return ccrBeanFactory.getCommonServicePersistable().getFirewallLocations();
    }

    
    public List<GenericLookup> getConnectivityTypeList() {
	return ccrBeanFactory.getCommonServicePersistable().getConnectivityTypes();
    }
    
    public List<ResourceType> getResourceTypeList(Long processId) {
	return ccrBeanFactory.getCommonServicePersistable().getResourceTypes(processId);
    }
    
    public List<ResourceType> getInternalResourceTypeList(Long processId) {
	return ccrBeanFactory.getCommonServicePersistable().getInternalResourceTypes(processId);
    }
    
    
    public List<ResourceType> getResourceTypeListIP(Long processId) {
	return ccrBeanFactory.getCommonServicePersistable().getIPConnResourceTypes(processId);
    }
    
    
    
    public List<GenericLookup> getControlMessages() {
	return ccrBeanFactory.getCommonServicePersistable().getControlMessagesList();
    }

    
    public FirewallPolicy getFirewallPolicy() {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallPolicy(this);
    }

    
    public List<FireWallRuleSourceIP> getIPRegSoureIp(long connID,long tiReqID) {
    	return ccrBeanFactory.getFirewallRuleProcessPersistable().getIPRegSoureIp(connID,tiReqID);
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void deleteFirewallRule() {
    	ccrBeanFactory.getFirewallRuleProcessPersistable().deleteFirewallRule(this.getRuleId(),	this.getTiRequest());
    }
    
   
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void toggleBidirectional() {
    	ccrBeanFactory.getFirewallRuleProcessPersistable().toggleBidirectionalRule(this.getRuleId());
		
    }

    /**
     * Gets the tI request.
     *
     * @param tiRequestId the ti request id
     * @return the tI request
     */
    
    public TIRequest getTIRequest(Long tiRequestId) {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getTIRequest(tiRequestId);
    } 

    
    public List<FireWallRule> findFirewallRules() {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallRules(this);

    }
    
    
    public Long getPreviousVersionTIRequest(Long processID) {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getPreviousVersionTIRequest(processID);

    }

    
    public FireWallRule findFirewallRule() {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallRule(this.ruleId);

    }
    
    
    public FireWallRule findFirewallRuleForRisk() {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallRuleForRisk(this.ruleId);

    }

    
    public HashMap<Long, Integer> applicationCountForIPs() {
    return ccrBeanFactory.getFirewallRuleProcessPersistable().applicationCountForIPs(this);
    }

    
    public FireWallPolicyGroup getFirewallGroupByName(String name) {
    return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallGroupByName(name);
    }
    /*
    @Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
    public FireWallZone getFirewallZone(String name){
    return commonServicePersistable.getFirewallZone(name);
    }
    */
    
    
    public ResourceType getNetworkZone(String name){
    return ccrBeanFactory.getCommonServicePersistable().getNetworkZone(name);
    }
    
    
    public GenericLookup getControlMessage(String name){
    return ccrBeanFactory.getCommonServicePersistable().getControlMessage(name);
    }
    
    public boolean isFireWallRulesHasChanged(Long tiRequestId, String type) {
		return ccrBeanFactory.getFirewallRuleProcessPersistable().isFireWallRulesHasChanged(tiRequestId, type); 
	}
    
    
    public List<GenericLookup> getProtocols() {
	return ccrBeanFactory.getCommonServicePersistable().getProtocols();
    }
    
    
    public List<GenericLookup> getFirewallTypeList() {
	return ccrBeanFactory.getCommonServicePersistable().getFirewallTypes();
    }
    
    
    public boolean completeCheckIPDetails(FireWallRuleProcess fwRuleProcess,String con_type) {
    	return ccrBeanFactory.getFirewallRuleProcessPersistable().completeCheckIPDetails(fwRuleProcess,con_type);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void saveFireWallRuleBulkUpload(Long tiRequestID, String docType, String contentType, String docName, byte[] fileContent) {
    	ccrBeanFactory.getFirewallRuleProcessPersistable().saveFireWallRuleBulkUpload(tiRequestID, docType, contentType, docName, fileContent);
	}
    
    
    public List<TIUploadedDocs> getFireWallRuleBulkUploadFileList(Long tiRequestID, String docType) {
    	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFireWallRuleBulkUploadFileList(tiRequestID, docType);
    }

    
    public TIUploadedDocs getFireWallRuleDownloadFile(Long id) {
    	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFireWallRuleDownloadFile(id);
    }

	public String getBulkUploadFileName() {
		return bulkUploadFileName;
	}

	public void setBulkUploadFileName(String bulkUploadFileName) {
		this.bulkUploadFileName = bulkUploadFileName;
	}

	public TIUploadedDocs getFirewallRuleFile() {
		return firewallRuleFile;
	}

	public void setFirewallRuleFile(TIUploadedDocs firewallRuleFile) {
		this.firewallRuleFile = firewallRuleFile;
	}

	/**
	 * @return the bulkUploadFilePath
	 */
	public String getBulkUploadFilePath() {
		return bulkUploadFilePath;
	}

	/**
	 * @param bulkUploadFilePath the bulkUploadFilePath to set
	 */
	public void setBulkUploadFilePath(String bulkUploadFilePath) {
		this.bulkUploadFilePath = bulkUploadFilePath;
	}

	public List<TIUploadedDocs> getBulkUploadFiles() {
		return bulkUploadFiles;
	}

	public void setBulkUploadFiles(List<TIUploadedDocs> bulkUploadFiles) {
		this.bulkUploadFiles = bulkUploadFiles;
	}

	
	
	public List<FirewallPolicy> getFirewallCircuitPolicyList() {
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallCircuitPolicyList(this);
	}

	
	public List<FireWallPolicyGroup> getFirewallCircuitGroupList() {
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallCircuitGroupList(this);
	}
	
	
	public boolean getFirewallCircuitDetailsCheck(Long tiRequestid) {
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallCircuitDetailsCheck(tiRequestid);
	}
	
	public String getRelationshipType() {
		return relationshipType;
	}

	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

    
    public List getTIReqeustRelationshipDetails(Long tiRequestid) {
    	return ccrBeanFactory.getFirewallRuleProcessPersistable().getTIReqeustRelationshipDetails(tiRequestid);
    }

	public int getRequesterResourceType() {
		return requesterResourceType;
	}

	public void setRequesterResourceType(int requesterResourceType) {
		this.requesterResourceType = requesterResourceType;
	}

	public int getTargetResourceType() {
		return targetResourceType;
	}

	public void setTargetResourceType(int targetResourceType) {
		this.targetResourceType = targetResourceType;
	}

	public List<FireWallRuleIP> getFirewallRuleIPList() {
		return firewallRuleIPList;
	}

	public void setFirewallRuleIPList(List<FireWallRuleIP> firewallRuleIPList) {
		this.firewallRuleIPList = firewallRuleIPList;
	}

	public List<FireWallRulePort> getFirewallRulePortList() {
		return firewallRulePortList;
	}

	public void setFirewallRulePortList(List<FireWallRulePort> firewallRulePortList) {
		this.firewallRulePortList = firewallRulePortList;
	}

    
    public List<TemplateConnection> getViewTemplate() {
    	return ccrBeanFactory.getFirewallRuleProcessPersistable().getViewTemplate(this);
    }

	public List<TemplateConnection> getTemplateConnectionList() {
		return templateConnectionList;
	}

	public void setTemplateConnectionList(
			List<TemplateConnection> templateConnectionList) {
		this.templateConnectionList = templateConnectionList;
	}
	
	//Modified for task 42665-starts
    
    public List<HistoryFireWallRule> getTemplateFirewallRules() {
    	return ccrBeanFactory.getFirewallRuleProcessPersistable().getTemplateFirewallRules(this);
    }
    //Modified for task 42665-ends

    
    public void deleteTemplateFirewallRules() {
    	ccrBeanFactory.getFirewallRuleProcessPersistable().deleteTemplateFirewallRules(this);
    }
    
    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void saveTemplateFireWallRules(List<FireWallRule> firewallrules) {
    	ccrBeanFactory.getFirewallRuleProcessPersistable().saveTemplateFireWallRules(firewallrules);
	}

	
	public Long getFirewallGroupID(String firewallGroupName) throws BusinessException{
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallGroupID(firewallGroupName);
	}
	
    
	public List<RiskDefinition> findRiskDefinitions() {

		return ccrBeanFactory.getOstiaRiskPersistable().findRiskDefinitions(this);
	}
    
	public List<FirewallRuleQuestionnaire> findFirewallRuleQuestionnaires() {

		return ccrBeanFactory.getOstiaRiskPersistable().findFirewallRuleQuestionnaires(this);
	}
    
    
	public List<FirewallRuleOstiaQuestion> findFirewallRuleOstiaAnswers() {

		return ccrBeanFactory.getOstiaRiskPersistable().findFirewallRuleOstiaAnswers(this);
	}
    
	public HashMap<String, List<FirewallRuleOstiaQuestion>> findFirewallRuleOstiaMapAnswers() {

		return ccrBeanFactory.getOstiaRiskPersistable().findFirewallRuleOstiaMapAnswers(this);
	}
    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateAnswer() {
    	ccrBeanFactory.getOstiaRiskPersistable().updateAnswer(this);
		
	}
	/**
	 * @return the paginationRequired
	 */
	public boolean isPaginationRequired() {
		return paginationRequired;
	}

	/**
	 * @param paginationRequired the paginationRequired to set
	 */
	public void setPaginationRequired(boolean paginationRequired) {
		this.paginationRequired = paginationRequired;
	}

	/**
	 * @return the firstResult
	 */
	public int getFirstResult() {
		return firstResult;
	}

	/**
	 * @param firstResult the firstResult to set
	 */
	public void setFirstResult(int firstResult) {
		this.firstResult = firstResult;
	}

	/**
	 * @return the maxResult
	 */
	public int getMaxResult() {
		return maxResult;
	}

	/**
	 * @param maxResult the maxResult to set
	 */
	public void setMaxResult(int maxResult) {
		this.maxResult = maxResult;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the riskCode
	 */
	public String getRiskCode() {
		return riskCode;
	}

	/**
	 * @param riskCode the riskCode to set
	 */
	public void setRiskCode(String riskCode) {
		this.riskCode = riskCode;
	}

	/**
	 * @return the firewallRuleQuestionnaire
	 */
	public FirewallRuleQuestionnaire getFirewallRuleQuestionnaire() {
		return firewallRuleQuestionnaire;
	}

	/**
	 * @param firewallRuleQuestionnaire the firewallRuleQuestionnaire to set
	 */
	public void setFirewallRuleQuestionnaire(
			FirewallRuleQuestionnaire firewallRuleQuestionnaire) {
		this.firewallRuleQuestionnaire = firewallRuleQuestionnaire;
	}

	public Long getTemplateID() {
		return templateID;
	}

	public void setTemplateID(Long templateID) {
		this.templateID = templateID;
	}
	
	
	/**
	 * @return the portNotEditable
	 */
	public boolean isPortNotEditable() {
		return portNotEditable;
	}

	/**
	 * @param portNotEditable the portNotEditable to set
	 */
	public void setPortNotEditable(boolean portNotEditable) {
		this.portNotEditable = portNotEditable;
	}

	/**
	 * @return the sipNotEditable
	 */
	public boolean isSipNotEditable() {
		return sipNotEditable;
	}

	/**
	 * @param sipNotEditable the sipNotEditable to set
	 */
	public void setSipNotEditable(boolean sipNotEditable) {
		this.sipNotEditable = sipNotEditable;
	}

	/**
	 * @return the dipNotEditable
	 */
	public boolean isDipNotEditable() {
		return dipNotEditable;
	}

	/**
	 * @param dipNotEditable the dipNotEditable to set
	 */
	public void setDipNotEditable(boolean dipNotEditable) {
		this.dipNotEditable = dipNotEditable;
	}
	
	/**
	 * @return the incompleteRules
	 */
	public boolean isIncompleteRules() {
		return incompleteRules;
	}

	/**
	 * @param incompleteRules the incompleteRules to set
	 */
	public void setIncompleteRules(boolean incompleteRules) {
		this.incompleteRules = incompleteRules;
	}
	
	/**
	 * @return the cloneFromRuleID
	 */
	public Long getCloneFromRuleID() {
		return cloneFromRuleID;
	}

	/**
	 * @param cloneFromRuleID the cloneFromRuleID to set
	 */
	public void setCloneFromRuleID(Long cloneFromRuleID) {
		this.cloneFromRuleID = cloneFromRuleID;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void executeRiskRules(Long ruleId, TIRequest tiRequest, TiRequestDTO tiRequestDTO, boolean deleteFlag, String userId) throws DecisionServiceSoapFault {
		this.setRuleId(ruleId);
		FireWallRule rule = null;
		if (!deleteFlag) {
			rule = findFirewallRuleForRisk();
		}
		HashMap<String, OstiaQuestionnaire> ostiaQuestionnaireMap = null;
		try {
			ostiaQuestionnaireMap =ccrBeanFactory.getRiskReviewExternalizable().executeRiskRules(rule, tiRequestDTO, tiRequest.getId());
			if (deleteFlag) {
				rule = new FireWallRule();
				rule.setId(ruleId);
				rule.setTiRequest(tiRequest);
			}
			String baselineName = "";
			baselineName = ccrBeanFactory.getOstiaRiskPersistable().saveOstiaQuestionnaire(rule, ostiaQuestionnaireMap.get("FWRULE"), tiRequest, deleteFlag);
			ccrBeanFactory.getOstiaRiskPersistable().saveRequestOstiaQuestionnaire(ostiaQuestionnaireMap.get("REQUEST"), tiRequest);
			if (!deleteFlag) {
				ccrBeanFactory.getOstiaRiskPersistable().riskExecutionHistory(tiRequest.getId(), userId, baselineName, ruleId,this.getIsIpReg());
			}
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - "+e.getMessage());
			ccrBeanFactory.getFirewallRuleProcessPersistable().updateFirewallRuleQuestionnaires(rule, deleteFlag);
		}
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void cloneFirewallRuleOstiaAnswers(Long cloneFrom, List<Long> cloneTo) {
		ccrBeanFactory.getOstiaRiskPersistable().cloneFirewallRuleOstiaAnswers(cloneFrom,cloneTo);		
	}
	
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public Long addUserFirewallRuleQuestionnaire(FirewallRuleQuestionnaire firewallRuleQuestionnaire) {
		return ccrBeanFactory.getOstiaRiskPersistable().addUserFirewallRuleQuestionnaire(firewallRuleQuestionnaire);
	}
	
	
	public FirewallRuleQuestionnaire findFirewallRuleQuestionnaire() {
		return ccrBeanFactory.getOstiaRiskPersistable().findFirewallRuleQuestionnaire(this.getFirewallRuleQuestionnaire().getId());		
	}
	
	
	public FirewallRuleQuestionnaire findFirewallRuleQuestionnaire(long id) {
		return ccrBeanFactory.getOstiaRiskPersistable().findFirewallRuleQuestionnaire(id);		
	}
	
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public void updateFirewallRuleQuestionnaire(
			long fwQuestionnaireId,String status) {
		ccrBeanFactory.getOstiaRiskPersistable().updateFirewallRuleQuestionnaire(fwQuestionnaireId,status);		
	}
	public int getTemplateResourceType() {
		return templateResourceType;
	}
	public void setTemplateResourceType(int templateResourceType) {
		this.templateResourceType = templateResourceType;
	}
	public void sortAnswersByRisk(){
		
	}
	
	
    public List<FireWallRuleIP> getTemplateObjects() {
    	return ccrBeanFactory.getFirewallRuleProcessPersistable().getTemplateObjects();
    }
	
	
    public boolean completeCheckFireWallRules(FireWallRuleProcess fwRuleProcess,String con_type) {
    	return ccrBeanFactory.getFirewallRuleProcessPersistable().completeCheckFireWallRules(fwRuleProcess,con_type);
    }

    public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getConnectivityType() {
		return connectivityType;
	}

	public void setConnectivityType(String connectivityType) {
		this.connectivityType = connectivityType;
	}

	public String getFirewallGroup() {
		return firewallGroup;
	}

	public void setFirewallGroup(String firewallGroup) {
		this.firewallGroup = firewallGroup;
	}

    public String getFwName() {
		return fwName;
	}

	public void setFwName(String fwName) {
		this.fwName = fwName;
	}


	public List<ResourceType> getIpResourceTypes() {
		return ipResourceTypes;
	}

	public void setIpResourceTypes(List<ResourceType> ipResourceTypes) {
		this.ipResourceTypes = ipResourceTypes;
	}

	
    public List<FireWallPolicyGroup> getSearchFirewallGroups() {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getSearchFirewallGroups(this);
    }

	
	public FireWallPolicyGroup getFirewallPolicyGroup(Long groupid) throws BusinessException{
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallPolicyGroup(groupid);
	}
	
	
	public FirewallPolicy getFirewallPolicyForIPReg() throws BusinessException{
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallPolicyForIPReg();
	}
	
	
	public String getIpRegSourceIP(IPAddress ipAddress, String relatipnshipType) throws BusinessException{
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getIpRegSourceIP(ipAddress, relationshipType);
	} 
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateAnswer(FirewallRuleQuestionnaire firewallRuleQuestionnaire) {
		ccrBeanFactory.getOstiaRiskPersistable().updateAnswer(firewallRuleQuestionnaire);
		
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateAnswer(List<Long> cloneTo) {
		ccrBeanFactory.getOstiaRiskPersistable().updateAnswer(cloneTo);
		
	}
		public HashMap<String, List<FirewallRuleOstiaQuestion>> getFirewallRuleOstiaMapAnswers() {
		return firewallRuleOstiaMapAnswers;
	}
		
	public void setFirewallRuleOstiaMapAnswers(
			HashMap<String, List<FirewallRuleOstiaQuestion>> firewallRuleOstiaMapAnswers) {
		this.firewallRuleOstiaMapAnswers = firewallRuleOstiaMapAnswers;
	}
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void cloneFirewallRuleQuestionnaire(
			List<FirewallRuleQuestionnaire> list) {
		ccrBeanFactory.getOstiaRiskPersistable().cloneFirewallRuleQuestionnaire(list);
		
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateFirewallRuleQuestionnaire(
			FirewallRuleQuestionnaire firewallRuleQuestionnaire){
		ccrBeanFactory.getOstiaRiskPersistable().updateFirewallRuleQuestionnaire(firewallRuleQuestionnaire);
	}
    public String getObjectNamePrefix() {
		return objectNamePrefix;
	}

	public void setObjectNamePrefix(String objectNamePrefix) {
		this.objectNamePrefix = objectNamePrefix;
	}

	
	public FirewallRuleQuestionnaire findFWQuestionnaireByRuleId(
			Long ruleId) {
		return ccrBeanFactory.getOstiaRiskPersistable().findFWQuestionnaireByRuleId(ruleId);
	}
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public int copyTemplateOstiaAnswers(long templFWRuleID,long fwRuleID) {
		return ccrBeanFactory.getFirewallRuleProcessPersistable().copyTemplateOstiaAnswers(templFWRuleID,fwRuleID);
	}
	
	public List<IPAddress> getObjectIPList(Long tiReqId, String conType) {
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getObjectIPList(tiReqId, conType);
	}
	
	public List<Port> getObjectPortList(Long tiReqId, String conType) {
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getObjectPortList(tiReqId, conType);
	}
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updatePortObjectNames(List<Port> ports) {
		ccrBeanFactory.getFirewallRuleProcessPersistable().updatePortObjectNames(ports);
	}
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateIPObjectNames(List<IPAddress> ipAddresses) {
		ccrBeanFactory.getFirewallRuleProcessPersistable().updateIPObjectNames(ipAddresses);
	}
	
	public FirewallPolicy getFirewallPolicyByName(String name) {
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallPoliyByName(name);
	}
	
	
    public List<FirewallRuleApplication> getFirewallRuleApplications(IPDetailsRequest ipDetailsRequest) {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallRuleApplications(ipDetailsRequest);
    }
	
	
	public List<Long> rulesExistsWithOlderBaseline(Long tiRequestId,String isIpReg) {
		return ccrBeanFactory.getOstiaRiskPersistable().rulesExistsWithOlderBaseline(tiRequestId,isIpReg);
	}
	
	
	public List<Long> getTIRequestsinRiskExecutionQueue() {
		return ccrBeanFactory.getOstiaRiskPersistable().getTIRequestsinRiskExecutionQueue();
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateRiskExecutionStatus(Long tiRequestId, String status, String userId,String ruleType) {
		ccrBeanFactory.getOstiaRiskPersistable().updateRiskExecutionStatus(tiRequestId, status, userId,ruleType);
	}
	
	
	public boolean isRiskExecutionInProgress(Long tiRequestId) {
		return ccrBeanFactory.getOstiaRiskPersistable().isRiskExecutionInProgress(tiRequestId);
	}

	public void setIsIpReg(String isIpReg) {
		this.isIpReg = isIpReg;
	}

	public String getIsIpReg() {
		return isIpReg;
	}

	public void setAggregate(Double aggregate) {
		this.aggregate = aggregate;
	}

	public Double getAggregate() {
		return aggregate;
	}
	
	
	public Double getRiskForCurrentCycle(Long tiRequestId, String conType) {
		return ccrBeanFactory.getOstiaRiskPersistable().getRiskForCurrentCycle(tiRequestId,conType);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateFirewallRuleQuestionnaire(Long fireWallRuleId) {
		ccrBeanFactory.getOstiaRiskPersistable().updateFirewallRuleQuestionnaire(fireWallRuleId);
		
	}

	public void setCycleAggregate(Double cycleAggregate) {
		this.cycleAggregate = cycleAggregate;
	}

	public Double getCycleAggregate() {
		return cycleAggregate;
	}

	
	public Double getRiskForConn(long tiProcessId, String conType) {
		return ccrBeanFactory.getOstiaRiskPersistable().getRiskForConn(tiProcessId,conType);
		
	}

	public void setIpCount(Long ipCount) {
		this.ipCount = ipCount;
	}

	public Long getIpCount() {
		return ipCount;
	}

	
	public Long getIPForConn(long tiProcessId, String conType) {
		return ccrBeanFactory.getOstiaRiskPersistable().getIPForConn(tiProcessId,conType);
	}
	
	//Added for task 42665-starts
	
	public Long getPreviousVersionTIRequestForTemplate(Long processID) {
		return ccrBeanFactory.getFirewallRuleProcessPersistable().getPreviousVersionTIRequestForTemplate(processID);
	}
	
    
    public List<HistoryFireWallRule> findFirewallRulesForTemplate() {
	return ccrBeanFactory.getFirewallRuleProcessPersistable().getFirewallRulesForTemplate(this);  

    }

	public void setHistoryFireWallRules(List<HistoryFireWallRule> historyFireWallRules) {
		this.historyFireWallRules = historyFireWallRules;
	}

	public List<HistoryFireWallRule> getHistoryFireWallRules() {
		return historyFireWallRules;
	}
	//Added for task 42665-ends
}
