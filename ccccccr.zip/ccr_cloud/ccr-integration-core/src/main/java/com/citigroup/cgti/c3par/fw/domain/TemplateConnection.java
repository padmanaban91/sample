package com.citigroup.cgti.c3par.fw.domain;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * @author pr265503
 *
 */
public class TemplateConnection extends Base {
    /**
	 * 
	 */
	private static final long serialVersionUID = 4370223274177714775L;
	
	private Long processID;
	private Long tiRequestID;
	private String connectionName;
	private String sourceNWZone;
	private String destinationNWZone;
	private String isTempUsed;
	private Integer temCount;
	
	public String getConnectionName() {
		return connectionName;
	}
	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}
	public String getSourceNWZone() {
		return sourceNWZone;
	}
	public void setSourceNWZone(String sourceNWZone) {
		this.sourceNWZone = sourceNWZone;
	}
	public String getDestinationNWZone() {
		return destinationNWZone;
	}
	public void setDestinationNWZone(String destinationNWZone) {
		this.destinationNWZone = destinationNWZone;
	}
	public Long getProcessID() {
		return processID;
	}
	public void setProcessID(Long processID) {
		this.processID = processID;
	}
	public Long getTiRequestID() {
		return tiRequestID;
	}
	public void setTiRequestID(Long tiRequestID) {
		this.tiRequestID = tiRequestID;
	}
	public String getIsTempUsed() {
		return isTempUsed;
	}
	public void setIsTempUsed(String isTempUsed) {
		this.isTempUsed = isTempUsed;
	}
	public Integer getTemCount() {
		return temCount;
	}
	public void setTemCount(Integer temCount) {
		this.temCount = temCount;
	}	
}
