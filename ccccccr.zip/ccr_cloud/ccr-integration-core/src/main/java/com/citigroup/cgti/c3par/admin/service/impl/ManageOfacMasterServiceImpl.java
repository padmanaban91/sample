package com.citigroup.cgti.c3par.admin.service.impl;


import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.admin.domain.ManageOfacMasterDTO;
import com.citigroup.cgti.c3par.admin.service.ManageOfacMasterService;
import com.citigroup.cgti.c3par.appsense.domain.OfacSubnetMaster;
import com.citigroup.cgti.c3par.configuation.QueryConstants;

@Service
public class ManageOfacMasterServiceImpl  implements ManageOfacMasterService {

    private Logger log = Logger.getLogger(this.getClass().getName());
    
	@Autowired
	private SessionFactory sessionFactory;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	@Transactional
	@Override
	public void saveManageOfacMasterList(ManageOfacMasterDTO manageOfacMasterDTO) {
		
		Session session = sessionFactory.getCurrentSession();
		OfacSubnetMaster ofacSubnetMaster = new OfacSubnetMaster();

		ofacSubnetMaster.setIpAddress(manageOfacMasterDTO.getIpAddress());
		ofacSubnetMaster.setStartIPAddress(manageOfacMasterDTO.getStartIPAddress());
		ofacSubnetMaster.setEndIPAddress(manageOfacMasterDTO.getEndIPAddress());
		ofacSubnetMaster.setSubnet(manageOfacMasterDTO.getSubnet());
		ofacSubnetMaster.setNoOfHost(manageOfacMasterDTO.getNoOfHost());
		ofacSubnetMaster.setBroadCastAddress(manageOfacMasterDTO.getBroadCastAddress());
		ofacSubnetMaster.setCreatedBy(manageOfacMasterDTO.getCreatedBy());
		ofacSubnetMaster.setCreated_date(new Date());
		ofacSubnetMaster.setIsActive("Y");
		
		session.saveOrUpdate(ofacSubnetMaster);
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly=true)
	@Override
	public List<OfacSubnetMaster> getIpDetails(String ipAddress) {
		log.info("Entering with ipAddress : "+ipAddress);
		Session session = sessionFactory.getCurrentSession();
		List<OfacSubnetMaster> ipDetailList= null;
		try{
			if(QueryConstants.WILDCARD_CHARACTER.equals(ipAddress)){
				Criteria criteria = session.createCriteria(OfacSubnetMaster.class);
		        criteria.add(Restrictions.eq("isActive", "Y"));
		        ipDetailList=criteria.list();
			}
			else{
				Criteria criteria = session.createCriteria(OfacSubnetMaster.class);
		        criteria.add(Restrictions.ilike("ipAddress",ipAddress,MatchMode.START));
		        criteria.add(Restrictions.eq("isActive", "Y"));
		        ipDetailList=criteria.list();
			}
	        log.info("ipDetailList size value:: "+ipDetailList);
		}catch(Exception e){
		    log.error("Exception occurred while getting the getIpDetails : "+e.toString());
		}
		
		log.info("Exiting ");
		return ipDetailList;
	}
	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly=true)
	@Override
	public List<OfacSubnetMaster> getExactIpDetails(String ipAddress) {
		log.info("Entering with ipAddress : "+ipAddress);
		List<OfacSubnetMaster> ipDetailList= null;
		try{
		    Session session = sessionFactory.getCurrentSession();
	        Criteria criteria = session.createCriteria(OfacSubnetMaster.class);
	        criteria.add(Restrictions.eq("ipAddress",ipAddress));
	        criteria.add(Restrictions.eq("isActive", "Y"));
	        ipDetailList=criteria.list();
	        log.info("ipDetailList size value:: "+ipDetailList);
		}catch(Exception e){
		    log.error("Exception occurred while getting the getIpDetails : "+e.toString());
		}
		
		log.info("Exiting ");
		return ipDetailList;
	}

	@Transactional
	@Override
	public void deleteManageOfacMasterList(String ipAddress, String updatedUser) {
		log.info("Inside Delete Service Impl.........."+updatedUser);
		Session session = sessionFactory.getCurrentSession();
		
		SQLQuery sqlQuery = session.createSQLQuery("UPDATE TI_OFAC_SUBNET_MASTER SET IS_ACTIVE = 'N' , UPDATED_DATE= sysdate , UPDATED_BY= UPPER('"+updatedUser+"') WHERE IP_ADDRESS = '"+ipAddress+"'");
		sqlQuery.executeUpdate();
		
	}
	
	
	

}


