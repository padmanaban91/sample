/**
 *
 */
package com.citigroup.cgti.c3par.businessjustification.domain;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.businessjustification.domain.soc.persist.EmerBuscritServicePersistable;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;

public class EmerBuscritProcess {

	RFCRequest rfcRequest;
	
	Map<String, String> questionAnswerMap;
	
	@Autowired
	EmerBuscritServicePersistable emerBuscritServicePersistable;

	
	public TIRequest getTIRequestDetails(Long tiRequestId){		
		return getEmerBuscritServicePersistable().getTIRequest(tiRequestId);
	}
	
	
	public Long getPlanningId(Long tirequestid) {
		return getEmerBuscritServicePersistable().getPlanningIdForTiRequestId(tirequestid); 
	}
	
	
	 public TIRequest getTIRequest(long tiRequestId){
		 
		 return getEmerBuscritServicePersistable().getTIRequest(tiRequestId);
	 }
	
	 public Long getPlanningIdForTiRequestId(Long tirequestid){
		 
		 return getEmerBuscritServicePersistable().getPlanningIdForTiRequestId(tirequestid);
	 }
	
	 public Planning getPlanningDetails(Long planningid){
		 
		 return getEmerBuscritServicePersistable().getPlanningDetails(planningid);
	 }
	
	 public Long updatePlanningPart(Planning planning){
		 
		 return getEmerBuscritServicePersistable().updatePlanningPart(planning);
	 }
	
	 public void loadPlanningPart(Planning planning){
		 
		 getEmerBuscritServicePersistable().loadPlanningPart(planning);
	 }
	
	 public boolean isDirectorPresent(Long planningId){
		 
		 return getEmerBuscritServicePersistable().isDirectorPresent(planningId);
	 }
	
	 public String getRelationshipType(Long conReqId){
		 
		 return getEmerBuscritServicePersistable().getRelationshipType(conReqId);
	 }
	
	
	public String getPriority(Long priorityId){
		 
		 return getEmerBuscritServicePersistable().getPriority(priorityId);
	 }

	public Map<String, String> getQuestionAnswerMap() {
		return questionAnswerMap;
	}

	public void setQuestionAnswerMap(Map<String, String> questionAnswerMap) {
		this.questionAnswerMap = questionAnswerMap;
	}

	public RFCRequest getRfcRequest() {
		return rfcRequest;
	}

	public void setRfcRequest(RFCRequest rfcRequest) {
		this.rfcRequest = rfcRequest;
	}
	
	public EmerBuscritServicePersistable getEmerBuscritServicePersistable() {
		return emerBuscritServicePersistable;
	}

	public void setEmerBuscritServicePersistable(
			EmerBuscritServicePersistable emerBuscritServicePersistable) {
		this.emerBuscritServicePersistable = emerBuscritServicePersistable;
	}

}
