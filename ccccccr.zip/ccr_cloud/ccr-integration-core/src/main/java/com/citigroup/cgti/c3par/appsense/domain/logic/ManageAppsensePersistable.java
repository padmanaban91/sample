package com.citigroup.cgti.c3par.appsense.domain.logic;

import java.util.List;

import com.citigroup.cgti.c3par.appsense.domain.AppsenseAAFCombination;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseApplication;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseDTO;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseUser;
import com.citigroup.cgti.c3par.appsense.domain.ConnectionOstiaGroup;
import com.citigroup.cgti.c3par.appsense.domain.ManageAppsenseProcess;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.persistance.Persistable;


/**
 * The Interface AppsensePersistable.
 */
@SuppressWarnings("unchecked")
public interface ManageAppsensePersistable extends Persistable{
    //Added only for testing purposes
    /*
	public Application findApplicationByCsiId(long csiId);
	public void storeAppsenseObject(Base base);
	public Application findBlackListedApplicationByName(String appName);
	public CitiContact storeCitiContact(CitiContact cc);
	public Application storeApplication(Application app);
	public ConnectionPortLookUp findPortLookup(String portNumber,String protocol,String flowOfData);
	public ConnectionPortLookUp storePortLookup(ConnectionPortLookUp portLookup);
	public ConnectionIPMaster storeIPMaster(ConnectionIPMaster ipMaster);
     */
    //Real Methods
    /**
     * Gets the appsense process.
     *
     * @param processId the process id
     * @return the appsense process
     */
    public AppsenseDTO getAppsenseProcess(long processId);
    //To load Appsense Applications
    /**
     * Load appsense applications.
     *
     * @param apsProcess the aps process
     * @param pageSize the page size
     * @return the list
     */
    public List<AppsenseApplication> loadAppsenseApplications(AppsenseDTO apsProcess, ManageAppsenseProcess manageAppsenseProcess);

    /**
     * Load appsense users.
     *
     * @param apsProcess the aps process
     * @param pageSize the page size
     * @return the list
     */
    public List<AppsenseUser> loadAppsenseUsers(AppsenseDTO apsProcess, ManageAppsenseProcess manageAppsenseProcess);


    /**
     * Load appsense applications.
     *
     * @param apsProcess the aps process
     * @param pageNum the page num
     * @param pageSize the page size
     * @return the list
     */
    public List<AppsenseApplication> loadAppsenseApplications(AppsenseDTO apsProcess,int pageNum,int pageSize);

    /**
     * Load appsense ostia applications.
     *
     * @param apsProcess the aps process
     * @param pageNum the page num
     * @param pageSize the page size
     * @return the list
     */
    public List<AppsenseApplication> loadAppsenseOstiaApplications(AppsenseDTO apsProcess, ManageAppsenseProcess manageAppsenseProcess);

    /**
     * Gets the appsense ostia port list.
     *
     * @param apsProcess the aps process
     * @return the appsense ostia port list
     */
    public List<AppsenseApplication> getAppsenseOstiaPortList(AppsenseDTO apsProcess);

    /**
     * Store appsense application.
     *
     * @param appsenseApplication the appsense application
     */
    public void storeAppsenseApplication(AppsenseApplication appsenseApplication);

    /**
     * Store appsense user.
     *
     * @param appsenseUser the appsense user
     */
    public void storeAppsenseUser(AppsenseUser appsenseUser);

    /**
     * Delete appsense application.
     *
     * @param apsProcess the aps process
     */
    public void deleteAppsenseApplication(AppsenseDTO apsProcess);

    /**
     * Delete appsense user.
     *
     * @param apsProcess the aps process
     */
    public void deleteAppsenseUser(AppsenseDTO apsProcess);


    /**
     * Gets the aps non network combination.
     *
     * @param processID the process id
     * @param versionID the version id
     * @param combType the comb type
     * @param fafType the faf type
     * @return the aps non network combination
     */
    public AppsenseAAFCombination getApsNonNetworkCombination(Long processID,Long versionID,Long combType,Long fafType);

    /**
     * Gets the aps network comb filter.
     *
     * @param processID the process id
     * @param versionID the version id
     * @param combType the comb type
     * @param fafType the faf type
     * @return the aps network comb filter
     */
    public List getApsNetworkCombFilter(Long processID,Long versionID,Long combType,Long fafType);

    /**
     * Gets the aps user combination.
     *
     * @param processID the process id
     * @param versionID the version id
     * @param combType the comb type
     * @param fafType the faf type
     * @return the aps user combination
     */
    public AppsenseAAFCombination getApsUserCombination(Long processID,Long versionID,Long combType,Long fafType);

    /**
     * Store apps ad group.
     *
     * @param appsenseADGroup the appsense ad group
     * @return the appsense ad group
     */
    public AppsenseADGroup storeAppsADGroup(AppsenseADGroup appsenseADGroup);

    /**
     * Update apps ad group.
     *
     * @param appsenseADGroup the appsense ad group
     * @return the appsense ad group
     */
    public AppsenseADGroup updateAppsADGroup(AppsenseADGroup appsenseADGroup);
    
    public AppsenseDTO addOstiaAnswers(AppsenseDTO apsProcess, Long groupId);
    
    public ConnectionOstiaGroup getOstiaGroup(Long ostiaGroupId);
    
    public AppsenseDTO updateOstiaGroup(AppsenseDTO appsenseProcess,ConnectionOstiaGroup conOstiaGroup);
    
    public List<GenericLookup> getDeviceTypes();
    
    public Long saveConOstiaGroup(ConnectionOstiaGroup conOstiaGroup);

   
}
