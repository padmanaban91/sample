package com.citigroup.cgti.c3par.bpm.ejb.domain;

import java.io.Serializable;


/**
 * The Class RFCRequestDTO.
 */
public class RFCRequestDTO implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 3822287476082902643L;
    //in case IF RFC ID IS not present then status is notApplicable,in case all rfc requests have rfc ids and their status is in design the final status is posted,in case if one of the rfc is generated then final status is generated.

    /** The Constant STATUS_EXCEPTION. */
    public static final String STATUS_EXCEPTION = "EXCEPTION";
    //public static final String STATUS_POSTED = "POSTED";
    /** The Constant STATUS_GENERATED. */
    public static final String STATUS_GENERATED = "GENERATED";
    
    public static final String STATUS_CANCELLED = "CANCELLED";

    /** The Constant RFC_REQ_STATUS_FAIL. */
    public static final String RFC_REQ_STATUS_FAIL="failure";
    //public static final String STATUS_NOTAPPLICABLE = "NOTAPPLICABLE";
    /** The Constant ERRORCODE_POST_PREPARE. */
    public static final String ERRORCODE_POST_PREPARE = "EC_POST_PREPARE";

    /** The Constant ERRORCODE_POST_WEBSERVICE. */
    public static final String ERRORCODE_POST_WEBSERVICE = "EC_POST_WEBSERVICE";

    /** The Constant ERRORCODE_GENERATE. */
    public static final String ERRORCODE_GENERATE="EC_GENERATE";

    /** The Constant ERRORMSG_GENERATE. */
    public static final String ERRORMSG_GENERATE="Error occurred while generating";

    /** The Constant ERRORMSG_POST_PREPARE. */
    public static final String ERRORMSG_POST_PREPARE = "EC_POST_PREPARE";

    /** The Constant ERRORMSG_POST_WEBSERVICE. */
    public static final String ERRORMSG_POST_WEBSERVICE = "EC_POST_WEBSERVICE";

    /** The Constant RFC_REQ_TYPE_GENERIC. */
    public static final String RFC_REQ_TYPE_GENERIC="Generic";

    /** The Constant RFC_REQ_TYPE_GENERIC. */
    public static final String RFC_REQ_TYPE_PROXY="Proxy";
    
    /** The Constant RFC_REQ_TYPE_GENERIC. */
    public static final String RFC_REQ_TYPE_FIEWALL="Firewall";

    /** The Constant ERRORCODE_POST_BULK. */
    public static final String ERRORCODE_POST_BULK = "EC_POST_BULK";

    /** The Constant ERRORCODE_POST_ACL. */
    public static final String ERRORCODE_POST_ACL = "EC_POST_ACL";

    /** The Constant ERRORCODE_POST_DATACOMPLETION. */
    public static final String ERRORCODE_POST_DATACOMPLETION ="EC_POST_DATACOMPLETION";

    /** The Constant ERRORMSG_POST_BULK. */
    public static final String ERRORMSG_POST_BULK = "This request is a Bulk request.";

    /** The Constant ERRORMSG_POST_ACL. */
    public static final String ERRORMSG_POST_ACL = "This request is of Firewall type ACL.";

    /** The Constant ERRORCODE_POST_NOTAPPLICABLE. */
    public static final String ERRORCODE_POST_NOTAPPLICABLE = "EC_POST_NOTAPPLICABLE";

    /** The Constant RFC_CREATE_TYPE_AUTO. */
    public static final String RFC_CREATE_TYPE_AUTO="AUTO";

    /** The Constant RFC_CREATE_TYPE_MANUAL. */
    public static final String RFC_CREATE_TYPE_MANUAL="MANUAL";

    /** The Constant ERRORCODE_POST_JAPAN. */
    public static final String ERRORCODE_POST_JAPAN = "EC_POST_JAPAN";

    /** The Constant ERRORMSG_POST_JAPAN. */
    public static final String ERRORMSG_POST_JAPAN = "This request is from location Japan.";

    /** The Constant ERRORCODE_POST_NOTVALID. */
    public static final String ERRORCODE_POST_NOTVALID = "EC_NOTVALID_POST";

    public static final String EC_POST_SERVICENOW = "EC_POST_SERVICENOW";

    /** The id. */
    private Long id;

    /** The short description. */
    private String shortDescription;

    /** The rfc id. */
    private String rfcId;

    /** The rfc status. */
    private String rfcStatus;

    /** The error code. */
    private String errorCode;

    /** The error message. */
    private String errorMessage;

    /** The ti request id. */
    private Long tiRequestId;

    /** The create type. */
    private String createType;
    
    private Long location;
    
    private String installDate;

    private String isIpReg;
    
    private String requestType;
    
    private String rfcType;
    
    

    /**
     * Gets the creates the type.
     *
     * @return the creates the type
     */
    public String getCreateType() {
	return createType;
    }

    /**
     * Sets the creates the type.
     *
     * @param createType the new creates the type
     */
    public void setCreateType(String createType) {
	this.createType = createType;
    }

    /**
     * Gets the error code.
     *
     * @return the error code
     */
    public String getErrorCode() {
	return errorCode;
    }

    /**
     * Sets the error code.
     *
     * @param errorCode the new error code
     */
    public void setErrorCode(String errorCode) {
	this.errorCode = errorCode;
    }

    /**
     * Gets the error message.
     *
     * @return the error message
     */
    public String getErrorMessage() {
	return errorMessage;
    }

    /**
     * Sets the error message.
     *
     * @param errorMessage the new error message
     */
    public void setErrorMessage(String errorMessage) {
	this.errorMessage = errorMessage;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
	return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
	this.id = id;
    }

    /**
     * Gets the short description.
     *
     * @return the short description
     */
    public String getShortDescription() {
	return shortDescription;
    }

    /**
     * Sets the short description.
     *
     * @param shortDescription the new short description
     */
    public void setShortDescription(String shortDescription) {
	this.shortDescription = shortDescription;
    }

    /**
     * Gets the rfc id.
     *
     * @return the rfc id
     */
    public String getRfcId() {
	return rfcId;
    }

    /**
     * Sets the rfc id.
     *
     * @param rfcId the new rfc id
     */
    public void setRfcId(String rfcId) {
	this.rfcId = rfcId;
    }

    /**
     * Gets the rfc status.
     *
     * @return the rfc status
     */
    public String getRfcStatus() {
	return rfcStatus;
    }

    /**
     * Sets the rfc status.
     *
     * @param rfcStatus the new rfc status
     */
    public void setRfcStatus(String rfcStatus) {
	this.rfcStatus = rfcStatus;
    }

    /**
     * Gets the ti request id.
     *
     * @return the ti request id
     */
    public Long getTiRequestId() {
	return tiRequestId;
    }

    /**
     * Sets the ti request id.
     *
     * @param tiRequestId the new ti request id
     */
    public void setTiRequestId(Long tiRequestId) {
	this.tiRequestId = tiRequestId;
    }

	public void setLocation(Long location) {
		this.location = location;
	}

	public Long getLocation() {
		return location;
	}

	public void setInstallDate(String installDate) {
		this.installDate = installDate;
	}

	public String getInstallDate() {
		return installDate;
	}

	public void setIsIpReg(String isIpReg) {
		this.isIpReg = isIpReg;
	}

	public String getIsIpReg() {
		return isIpReg;
	}

	public String getRfcType() {
		return rfcType;
	}

	public void setRfcType(String rfcType) {
		this.rfcType = rfcType;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
}
