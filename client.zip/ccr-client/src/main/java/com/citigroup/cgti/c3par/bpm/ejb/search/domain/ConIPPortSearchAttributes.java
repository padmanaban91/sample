package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class ConIPPortSearchAttributes.
 */
public class ConIPPortSearchAttributes extends BaseSearchAttributes implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 2625417524477277L;

    /** The ip pair. */
    private String ipPair=null;

    /** The port. */
    private String port=null;

    /** The protocol. */
    private String protocol=null;

    /**
     * Gets the ip pair.
     *
     * @return the ip pair
     */
    public String getIpPair() {
	return ipPair;
    }

    public String getIpPairForQuery() {
	return validString(ipPair);
    }

    /**
     * Sets the ip pair.
     *
     * @param ipPair the new ip pair
     */
    public void setIpPair(String ipPair) {
	this.ipPair = ipPair;
    }

    /**
     * Gets the port.
     *
     * @return the port
     */
    public String getPort() {
	return port;
    }

    public String getPortForQuery() {
	return validString(port);
    }

    /**
     * Sets the port.
     *
     * @param port the new port
     */
    public void setPort(String port) {
	this.port = port;
    }

    /**
     * Gets the protocol.
     *
     * @return the protocol
     */
    public String getProtocol() {
	return protocol;
    }

    public String getProtocolForQuery() {
	return validString(protocol);
    }

    /**
     * Sets the protocol.
     *
     * @param protocol the new protocol
     */
    public void setProtocol(String protocol) {
	this.protocol = protocol;
    }

}
