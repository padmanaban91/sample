package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class ApplicationSearchAttributes.
 */
public class ApplicationSearchAttributes  extends BaseSearchAttributes implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -2619455578293777020L;

    /** The csi id. */
    private String csiId = null;

    /** The application name. */
    private String applicationName =null;

    /** The device model. */
    private String deviceModel = null;

    /**
     * Gets the application name.
     *
     * @return the application name
     */
    public String getApplicationName() {
	return applicationName;
    }

    public String getApplicationNameForQuery(){
    	return validString(this.applicationName);
    }
    /**
     * Sets the application name.
     *
     * @param applicationName the new application name
     */
    public void setApplicationName(String applicationName) {
	this.applicationName = applicationName;
    }

    /**
     * Gets the csi id.
     *
     * @return the csi id
     */
    public String getCsiId() {
	return csiId;
    }

    public String getCsiIdForQuery() {
	return validLongAsString(csiId);
    }

    /**
     * Sets the csi id.
     *
     * @param csiId the new csi id
     */
    public void setCsiId(String csiId) {
	this.csiId = csiId;
    }

    /**
     * Gets the device model.
     *
     * @return the device model
     */
    public String getDeviceModel() {
	return deviceModel;
    }

    public String getDeviceModelForQuery() {
	return validString(deviceModel);
    }
    /**
     * Sets the device model.
     *
     * @param deviceModel the new device model
     */
    public void setDeviceModel(String deviceModel) {
	this.deviceModel = deviceModel;
    }


}
