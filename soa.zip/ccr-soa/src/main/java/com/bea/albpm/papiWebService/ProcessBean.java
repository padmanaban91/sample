/*
 * XML Type:  processBean
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.ProcessBean
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML processBean(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface ProcessBean extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ProcessBean.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("processbean9d8ctype");
    
    /**
     * Gets array of all "activities" elements
     */
    com.bea.albpm.papiWebService.ActivityBean[] getActivitiesArray();
    
    /**
     * Gets ith "activities" element
     */
    com.bea.albpm.papiWebService.ActivityBean getActivitiesArray(int i);
    
    /**
     * Tests for nil ith "activities" element
     */
    boolean isNilActivitiesArray(int i);
    
    /**
     * Returns number of "activities" element
     */
    int sizeOfActivitiesArray();
    
    /**
     * Sets array of all "activities" element
     */
    void setActivitiesArray(com.bea.albpm.papiWebService.ActivityBean[] activitiesArray);
    
    /**
     * Sets ith "activities" element
     */
    void setActivitiesArray(int i, com.bea.albpm.papiWebService.ActivityBean activities);
    
    /**
     * Nils the ith "activities" element
     */
    void setNilActivitiesArray(int i);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "activities" element
     */
    com.bea.albpm.papiWebService.ActivityBean insertNewActivities(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "activities" element
     */
    com.bea.albpm.papiWebService.ActivityBean addNewActivities();
    
    /**
     * Removes the ith "activities" element
     */
    void removeActivities(int i);
    
    /**
     * Gets array of all "applicationRoles" elements
     */
    java.lang.String[] getApplicationRolesArray();
    
    /**
     * Gets ith "applicationRoles" element
     */
    java.lang.String getApplicationRolesArray(int i);
    
    /**
     * Gets (as xml) array of all "applicationRoles" elements
     */
    org.apache.xmlbeans.XmlString[] xgetApplicationRolesArray();
    
    /**
     * Gets (as xml) ith "applicationRoles" element
     */
    org.apache.xmlbeans.XmlString xgetApplicationRolesArray(int i);
    
    /**
     * Tests for nil ith "applicationRoles" element
     */
    boolean isNilApplicationRolesArray(int i);
    
    /**
     * Returns number of "applicationRoles" element
     */
    int sizeOfApplicationRolesArray();
    
    /**
     * Sets array of all "applicationRoles" element
     */
    void setApplicationRolesArray(java.lang.String[] applicationRolesArray);
    
    /**
     * Sets ith "applicationRoles" element
     */
    void setApplicationRolesArray(int i, java.lang.String applicationRoles);
    
    /**
     * Sets (as xml) array of all "applicationRoles" element
     */
    void xsetApplicationRolesArray(org.apache.xmlbeans.XmlString[] applicationRolesArray);
    
    /**
     * Sets (as xml) ith "applicationRoles" element
     */
    void xsetApplicationRolesArray(int i, org.apache.xmlbeans.XmlString applicationRoles);
    
    /**
     * Nils the ith "applicationRoles" element
     */
    void setNilApplicationRolesArray(int i);
    
    /**
     * Inserts the value as the ith "applicationRoles" element
     */
    void insertApplicationRoles(int i, java.lang.String applicationRoles);
    
    /**
     * Appends the value as the last "applicationRoles" element
     */
    void addApplicationRoles(java.lang.String applicationRoles);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "applicationRoles" element
     */
    org.apache.xmlbeans.XmlString insertNewApplicationRoles(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "applicationRoles" element
     */
    org.apache.xmlbeans.XmlString addNewApplicationRoles();
    
    /**
     * Removes the ith "applicationRoles" element
     */
    void removeApplicationRoles(int i);
    
    /**
     * Gets array of all "beginArgumentSets" elements
     */
    com.bea.albpm.papiWebService.ArgumentSetBean[] getBeginArgumentSetsArray();
    
    /**
     * Gets ith "beginArgumentSets" element
     */
    com.bea.albpm.papiWebService.ArgumentSetBean getBeginArgumentSetsArray(int i);
    
    /**
     * Tests for nil ith "beginArgumentSets" element
     */
    boolean isNilBeginArgumentSetsArray(int i);
    
    /**
     * Returns number of "beginArgumentSets" element
     */
    int sizeOfBeginArgumentSetsArray();
    
    /**
     * Sets array of all "beginArgumentSets" element
     */
    void setBeginArgumentSetsArray(com.bea.albpm.papiWebService.ArgumentSetBean[] beginArgumentSetsArray);
    
    /**
     * Sets ith "beginArgumentSets" element
     */
    void setBeginArgumentSetsArray(int i, com.bea.albpm.papiWebService.ArgumentSetBean beginArgumentSets);
    
    /**
     * Nils the ith "beginArgumentSets" element
     */
    void setNilBeginArgumentSetsArray(int i);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "beginArgumentSets" element
     */
    com.bea.albpm.papiWebService.ArgumentSetBean insertNewBeginArgumentSets(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "beginArgumentSets" element
     */
    com.bea.albpm.papiWebService.ArgumentSetBean addNewBeginArgumentSets();
    
    /**
     * Removes the ith "beginArgumentSets" element
     */
    void removeBeginArgumentSets(int i);
    
    /**
     * Gets the "consolidatedId" element
     */
    java.lang.String getConsolidatedId();
    
    /**
     * Gets (as xml) the "consolidatedId" element
     */
    org.apache.xmlbeans.XmlString xgetConsolidatedId();
    
    /**
     * True if has "consolidatedId" element
     */
    boolean isSetConsolidatedId();
    
    /**
     * Sets the "consolidatedId" element
     */
    void setConsolidatedId(java.lang.String consolidatedId);
    
    /**
     * Sets (as xml) the "consolidatedId" element
     */
    void xsetConsolidatedId(org.apache.xmlbeans.XmlString consolidatedId);
    
    /**
     * Unsets the "consolidatedId" element
     */
    void unsetConsolidatedId();
    
    /**
     * Gets the "deployedEngine" element
     */
    java.lang.String getDeployedEngine();
    
    /**
     * Gets (as xml) the "deployedEngine" element
     */
    org.apache.xmlbeans.XmlString xgetDeployedEngine();
    
    /**
     * True if has "deployedEngine" element
     */
    boolean isSetDeployedEngine();
    
    /**
     * Sets the "deployedEngine" element
     */
    void setDeployedEngine(java.lang.String deployedEngine);
    
    /**
     * Sets (as xml) the "deployedEngine" element
     */
    void xsetDeployedEngine(org.apache.xmlbeans.XmlString deployedEngine);
    
    /**
     * Unsets the "deployedEngine" element
     */
    void unsetDeployedEngine();
    
    /**
     * Gets the "id" element
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "id" element
     */
    org.apache.xmlbeans.XmlString xgetId();
    
    /**
     * True if has "id" element
     */
    boolean isSetId();
    
    /**
     * Sets the "id" element
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "id" element
     */
    void xsetId(org.apache.xmlbeans.XmlString id);
    
    /**
     * Unsets the "id" element
     */
    void unsetId();
    
    /**
     * Gets the "isActive" element
     */
    boolean getIsActive();
    
    /**
     * Gets (as xml) the "isActive" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsActive();
    
    /**
     * Sets the "isActive" element
     */
    void setIsActive(boolean isActive);
    
    /**
     * Sets (as xml) the "isActive" element
     */
    void xsetIsActive(org.apache.xmlbeans.XmlBoolean isActive);
    
    /**
     * Gets the "isAutomatic" element
     */
    boolean getIsAutomatic();
    
    /**
     * Gets (as xml) the "isAutomatic" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsAutomatic();
    
    /**
     * Sets the "isAutomatic" element
     */
    void setIsAutomatic(boolean isAutomatic);
    
    /**
     * Sets (as xml) the "isAutomatic" element
     */
    void xsetIsAutomatic(org.apache.xmlbeans.XmlBoolean isAutomatic);
    
    /**
     * Gets the "isOnline" element
     */
    boolean getIsOnline();
    
    /**
     * Gets (as xml) the "isOnline" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsOnline();
    
    /**
     * Sets the "isOnline" element
     */
    void setIsOnline(boolean isOnline);
    
    /**
     * Sets (as xml) the "isOnline" element
     */
    void xsetIsOnline(org.apache.xmlbeans.XmlBoolean isOnline);
    
    /**
     * Gets the "labels" element
     */
    com.bea.albpm.papiWebService.LocaleStringMapBean getLabels();
    
    /**
     * True if has "labels" element
     */
    boolean isSetLabels();
    
    /**
     * Sets the "labels" element
     */
    void setLabels(com.bea.albpm.papiWebService.LocaleStringMapBean labels);
    
    /**
     * Appends and returns a new empty "labels" element
     */
    com.bea.albpm.papiWebService.LocaleStringMapBean addNewLabels();
    
    /**
     * Unsets the "labels" element
     */
    void unsetLabels();
    
    /**
     * Gets array of all "measurements" elements
     */
    com.bea.albpm.papiWebService.ActivityBean[] getMeasurementsArray();
    
    /**
     * Gets ith "measurements" element
     */
    com.bea.albpm.papiWebService.ActivityBean getMeasurementsArray(int i);
    
    /**
     * Tests for nil ith "measurements" element
     */
    boolean isNilMeasurementsArray(int i);
    
    /**
     * Returns number of "measurements" element
     */
    int sizeOfMeasurementsArray();
    
    /**
     * Sets array of all "measurements" element
     */
    void setMeasurementsArray(com.bea.albpm.papiWebService.ActivityBean[] measurementsArray);
    
    /**
     * Sets ith "measurements" element
     */
    void setMeasurementsArray(int i, com.bea.albpm.papiWebService.ActivityBean measurements);
    
    /**
     * Nils the ith "measurements" element
     */
    void setNilMeasurementsArray(int i);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "measurements" element
     */
    com.bea.albpm.papiWebService.ActivityBean insertNewMeasurements(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "measurements" element
     */
    com.bea.albpm.papiWebService.ActivityBean addNewMeasurements();
    
    /**
     * Removes the ith "measurements" element
     */
    void removeMeasurements(int i);
    
    /**
     * Gets the "name" element
     */
    java.lang.String getName();
    
    /**
     * Gets (as xml) the "name" element
     */
    org.apache.xmlbeans.XmlString xgetName();
    
    /**
     * True if has "name" element
     */
    boolean isSetName();
    
    /**
     * Sets the "name" element
     */
    void setName(java.lang.String name);
    
    /**
     * Sets (as xml) the "name" element
     */
    void xsetName(org.apache.xmlbeans.XmlString name);
    
    /**
     * Unsets the "name" element
     */
    void unsetName();
    
    /**
     * Gets the "organizationUnit" element
     */
    java.lang.String getOrganizationUnit();
    
    /**
     * Gets (as xml) the "organizationUnit" element
     */
    org.apache.xmlbeans.XmlString xgetOrganizationUnit();
    
    /**
     * True if has "organizationUnit" element
     */
    boolean isSetOrganizationUnit();
    
    /**
     * Sets the "organizationUnit" element
     */
    void setOrganizationUnit(java.lang.String organizationUnit);
    
    /**
     * Sets (as xml) the "organizationUnit" element
     */
    void xsetOrganizationUnit(org.apache.xmlbeans.XmlString organizationUnit);
    
    /**
     * Unsets the "organizationUnit" element
     */
    void unsetOrganizationUnit();
    
    /**
     * Gets the "projectName" element
     */
    java.lang.String getProjectName();
    
    /**
     * Gets (as xml) the "projectName" element
     */
    org.apache.xmlbeans.XmlString xgetProjectName();
    
    /**
     * True if has "projectName" element
     */
    boolean isSetProjectName();
    
    /**
     * Sets the "projectName" element
     */
    void setProjectName(java.lang.String projectName);
    
    /**
     * Sets (as xml) the "projectName" element
     */
    void xsetProjectName(org.apache.xmlbeans.XmlString projectName);
    
    /**
     * Unsets the "projectName" element
     */
    void unsetProjectName();
    
    /**
     * Gets array of all "roles" elements
     */
    java.lang.String[] getRolesArray();
    
    /**
     * Gets ith "roles" element
     */
    java.lang.String getRolesArray(int i);
    
    /**
     * Gets (as xml) array of all "roles" elements
     */
    org.apache.xmlbeans.XmlString[] xgetRolesArray();
    
    /**
     * Gets (as xml) ith "roles" element
     */
    org.apache.xmlbeans.XmlString xgetRolesArray(int i);
    
    /**
     * Tests for nil ith "roles" element
     */
    boolean isNilRolesArray(int i);
    
    /**
     * Returns number of "roles" element
     */
    int sizeOfRolesArray();
    
    /**
     * Sets array of all "roles" element
     */
    void setRolesArray(java.lang.String[] rolesArray);
    
    /**
     * Sets ith "roles" element
     */
    void setRolesArray(int i, java.lang.String roles);
    
    /**
     * Sets (as xml) array of all "roles" element
     */
    void xsetRolesArray(org.apache.xmlbeans.XmlString[] rolesArray);
    
    /**
     * Sets (as xml) ith "roles" element
     */
    void xsetRolesArray(int i, org.apache.xmlbeans.XmlString roles);
    
    /**
     * Nils the ith "roles" element
     */
    void setNilRolesArray(int i);
    
    /**
     * Inserts the value as the ith "roles" element
     */
    void insertRoles(int i, java.lang.String roles);
    
    /**
     * Appends the value as the last "roles" element
     */
    void addRoles(java.lang.String roles);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "roles" element
     */
    org.apache.xmlbeans.XmlString insertNewRoles(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "roles" element
     */
    org.apache.xmlbeans.XmlString addNewRoles();
    
    /**
     * Removes the ith "roles" element
     */
    void removeRoles(int i);
    
    /**
     * Gets array of all "variables" elements
     */
    com.bea.albpm.papiWebService.VarDefinitionBean[] getVariablesArray();
    
    /**
     * Gets ith "variables" element
     */
    com.bea.albpm.papiWebService.VarDefinitionBean getVariablesArray(int i);
    
    /**
     * Tests for nil ith "variables" element
     */
    boolean isNilVariablesArray(int i);
    
    /**
     * Returns number of "variables" element
     */
    int sizeOfVariablesArray();
    
    /**
     * Sets array of all "variables" element
     */
    void setVariablesArray(com.bea.albpm.papiWebService.VarDefinitionBean[] variablesArray);
    
    /**
     * Sets ith "variables" element
     */
    void setVariablesArray(int i, com.bea.albpm.papiWebService.VarDefinitionBean variables);
    
    /**
     * Nils the ith "variables" element
     */
    void setNilVariablesArray(int i);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "variables" element
     */
    com.bea.albpm.papiWebService.VarDefinitionBean insertNewVariables(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "variables" element
     */
    com.bea.albpm.papiWebService.VarDefinitionBean addNewVariables();
    
    /**
     * Removes the ith "variables" element
     */
    void removeVariables(int i);
    
    /**
     * Gets the "version" element
     */
    java.lang.String getVersion();
    
    /**
     * Gets (as xml) the "version" element
     */
    org.apache.xmlbeans.XmlString xgetVersion();
    
    /**
     * True if has "version" element
     */
    boolean isSetVersion();
    
    /**
     * Sets the "version" element
     */
    void setVersion(java.lang.String version);
    
    /**
     * Sets (as xml) the "version" element
     */
    void xsetVersion(org.apache.xmlbeans.XmlString version);
    
    /**
     * Unsets the "version" element
     */
    void unsetVersion();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.ProcessBean newInstance() {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.ProcessBean parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.ProcessBean parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessBean parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ProcessBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ProcessBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ProcessBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
