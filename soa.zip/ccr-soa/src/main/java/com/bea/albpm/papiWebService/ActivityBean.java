/*
 * XML Type:  activityBean
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.ActivityBean
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML activityBean(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface ActivityBean extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ActivityBean.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("activitybean6c1etype");
    
    /**
     * Gets array of all "argumentSets" elements
     */
    com.bea.albpm.papiWebService.ArgumentSetBean[] getArgumentSetsArray();
    
    /**
     * Gets ith "argumentSets" element
     */
    com.bea.albpm.papiWebService.ArgumentSetBean getArgumentSetsArray(int i);
    
    /**
     * Tests for nil ith "argumentSets" element
     */
    boolean isNilArgumentSetsArray(int i);
    
    /**
     * Returns number of "argumentSets" element
     */
    int sizeOfArgumentSetsArray();
    
    /**
     * Sets array of all "argumentSets" element
     */
    void setArgumentSetsArray(com.bea.albpm.papiWebService.ArgumentSetBean[] argumentSetsArray);
    
    /**
     * Sets ith "argumentSets" element
     */
    void setArgumentSetsArray(int i, com.bea.albpm.papiWebService.ArgumentSetBean argumentSets);
    
    /**
     * Nils the ith "argumentSets" element
     */
    void setNilArgumentSetsArray(int i);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "argumentSets" element
     */
    com.bea.albpm.papiWebService.ArgumentSetBean insertNewArgumentSets(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "argumentSets" element
     */
    com.bea.albpm.papiWebService.ArgumentSetBean addNewArgumentSets();
    
    /**
     * Removes the ith "argumentSets" element
     */
    void removeArgumentSets(int i);
    
    /**
     * Gets the "hasInstanceAccess" element
     */
    boolean getHasInstanceAccess();
    
    /**
     * Gets (as xml) the "hasInstanceAccess" element
     */
    org.apache.xmlbeans.XmlBoolean xgetHasInstanceAccess();
    
    /**
     * Sets the "hasInstanceAccess" element
     */
    void setHasInstanceAccess(boolean hasInstanceAccess);
    
    /**
     * Sets (as xml) the "hasInstanceAccess" element
     */
    void xsetHasInstanceAccess(org.apache.xmlbeans.XmlBoolean hasInstanceAccess);
    
    /**
     * Gets the "hasOutgoingTransitions" element
     */
    boolean getHasOutgoingTransitions();
    
    /**
     * Gets (as xml) the "hasOutgoingTransitions" element
     */
    org.apache.xmlbeans.XmlBoolean xgetHasOutgoingTransitions();
    
    /**
     * Sets the "hasOutgoingTransitions" element
     */
    void setHasOutgoingTransitions(boolean hasOutgoingTransitions);
    
    /**
     * Sets (as xml) the "hasOutgoingTransitions" element
     */
    void xsetHasOutgoingTransitions(org.apache.xmlbeans.XmlBoolean hasOutgoingTransitions);
    
    /**
     * Gets the "hasTransitionsToInteractiveActivities" element
     */
    boolean getHasTransitionsToInteractiveActivities();
    
    /**
     * Gets (as xml) the "hasTransitionsToInteractiveActivities" element
     */
    org.apache.xmlbeans.XmlBoolean xgetHasTransitionsToInteractiveActivities();
    
    /**
     * Sets the "hasTransitionsToInteractiveActivities" element
     */
    void setHasTransitionsToInteractiveActivities(boolean hasTransitionsToInteractiveActivities);
    
    /**
     * Sets (as xml) the "hasTransitionsToInteractiveActivities" element
     */
    void xsetHasTransitionsToInteractiveActivities(org.apache.xmlbeans.XmlBoolean hasTransitionsToInteractiveActivities);
    
    /**
     * Gets the "id" element
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "id" element
     */
    org.apache.xmlbeans.XmlString xgetId();
    
    /**
     * True if has "id" element
     */
    boolean isSetId();
    
    /**
     * Sets the "id" element
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "id" element
     */
    void xsetId(org.apache.xmlbeans.XmlString id);
    
    /**
     * Unsets the "id" element
     */
    void unsetId();
    
    /**
     * Gets the "isAbortEnable" element
     */
    boolean getIsAbortEnable();
    
    /**
     * Gets (as xml) the "isAbortEnable" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsAbortEnable();
    
    /**
     * Sets the "isAbortEnable" element
     */
    void setIsAbortEnable(boolean isAbortEnable);
    
    /**
     * Sets (as xml) the "isAbortEnable" element
     */
    void xsetIsAbortEnable(org.apache.xmlbeans.XmlBoolean isAbortEnable);
    
    /**
     * Gets the "isActive" element
     */
    boolean getIsActive();
    
    /**
     * Gets (as xml) the "isActive" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsActive();
    
    /**
     * Sets the "isActive" element
     */
    void setIsActive(boolean isActive);
    
    /**
     * Sets (as xml) the "isActive" element
     */
    void xsetIsActive(org.apache.xmlbeans.XmlBoolean isActive);
    
    /**
     * Gets the "isAutoCompleteEnable" element
     */
    boolean getIsAutoCompleteEnable();
    
    /**
     * Gets (as xml) the "isAutoCompleteEnable" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsAutoCompleteEnable();
    
    /**
     * Sets the "isAutoCompleteEnable" element
     */
    void setIsAutoCompleteEnable(boolean isAutoCompleteEnable);
    
    /**
     * Sets (as xml) the "isAutoCompleteEnable" element
     */
    void xsetIsAutoCompleteEnable(org.apache.xmlbeans.XmlBoolean isAutoCompleteEnable);
    
    /**
     * Gets the "isInstancePresentation" element
     */
    boolean getIsInstancePresentation();
    
    /**
     * Gets (as xml) the "isInstancePresentation" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsInstancePresentation();
    
    /**
     * Sets the "isInstancePresentation" element
     */
    void setIsInstancePresentation(boolean isInstancePresentation);
    
    /**
     * Sets (as xml) the "isInstancePresentation" element
     */
    void xsetIsInstancePresentation(org.apache.xmlbeans.XmlBoolean isInstancePresentation);
    
    /**
     * Gets the "isLoopActivity" element
     */
    boolean getIsLoopActivity();
    
    /**
     * Gets (as xml) the "isLoopActivity" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsLoopActivity();
    
    /**
     * Sets the "isLoopActivity" element
     */
    void setIsLoopActivity(boolean isLoopActivity);
    
    /**
     * Sets (as xml) the "isLoopActivity" element
     */
    void xsetIsLoopActivity(org.apache.xmlbeans.XmlBoolean isLoopActivity);
    
    /**
     * Gets the "isOnline" element
     */
    boolean getIsOnline();
    
    /**
     * Gets (as xml) the "isOnline" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsOnline();
    
    /**
     * Sets the "isOnline" element
     */
    void setIsOnline(boolean isOnline);
    
    /**
     * Sets (as xml) the "isOnline" element
     */
    void xsetIsOnline(org.apache.xmlbeans.XmlBoolean isOnline);
    
    /**
     * Gets the "isReassignEnable" element
     */
    boolean getIsReassignEnable();
    
    /**
     * Gets (as xml) the "isReassignEnable" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsReassignEnable();
    
    /**
     * Sets the "isReassignEnable" element
     */
    void setIsReassignEnable(boolean isReassignEnable);
    
    /**
     * Sets (as xml) the "isReassignEnable" element
     */
    void xsetIsReassignEnable(org.apache.xmlbeans.XmlBoolean isReassignEnable);
    
    /**
     * Gets the "isSelectEnabled" element
     */
    boolean getIsSelectEnabled();
    
    /**
     * Gets (as xml) the "isSelectEnabled" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsSelectEnabled();
    
    /**
     * Sets the "isSelectEnabled" element
     */
    void setIsSelectEnabled(boolean isSelectEnabled);
    
    /**
     * Sets (as xml) the "isSelectEnabled" element
     */
    void xsetIsSelectEnabled(org.apache.xmlbeans.XmlBoolean isSelectEnabled);
    
    /**
     * Gets the "isSuspendEnabled" element
     */
    boolean getIsSuspendEnabled();
    
    /**
     * Gets (as xml) the "isSuspendEnabled" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsSuspendEnabled();
    
    /**
     * Sets the "isSuspendEnabled" element
     */
    void setIsSuspendEnabled(boolean isSuspendEnabled);
    
    /**
     * Sets (as xml) the "isSuspendEnabled" element
     */
    void xsetIsSuspendEnabled(org.apache.xmlbeans.XmlBoolean isSuspendEnabled);
    
    /**
     * Gets the "isUserSelectsTransitionEnabled" element
     */
    boolean getIsUserSelectsTransitionEnabled();
    
    /**
     * Gets (as xml) the "isUserSelectsTransitionEnabled" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsUserSelectsTransitionEnabled();
    
    /**
     * Sets the "isUserSelectsTransitionEnabled" element
     */
    void setIsUserSelectsTransitionEnabled(boolean isUserSelectsTransitionEnabled);
    
    /**
     * Sets (as xml) the "isUserSelectsTransitionEnabled" element
     */
    void xsetIsUserSelectsTransitionEnabled(org.apache.xmlbeans.XmlBoolean isUserSelectsTransitionEnabled);
    
    /**
     * Gets the "labels" element
     */
    com.bea.albpm.papiWebService.LocaleStringMapBean getLabels();
    
    /**
     * True if has "labels" element
     */
    boolean isSetLabels();
    
    /**
     * Sets the "labels" element
     */
    void setLabels(com.bea.albpm.papiWebService.LocaleStringMapBean labels);
    
    /**
     * Appends and returns a new empty "labels" element
     */
    com.bea.albpm.papiWebService.LocaleStringMapBean addNewLabels();
    
    /**
     * Unsets the "labels" element
     */
    void unsetLabels();
    
    /**
     * Gets the "name" element
     */
    java.lang.String getName();
    
    /**
     * Gets (as xml) the "name" element
     */
    org.apache.xmlbeans.XmlString xgetName();
    
    /**
     * True if has "name" element
     */
    boolean isSetName();
    
    /**
     * Sets the "name" element
     */
    void setName(java.lang.String name);
    
    /**
     * Sets (as xml) the "name" element
     */
    void xsetName(org.apache.xmlbeans.XmlString name);
    
    /**
     * Unsets the "name" element
     */
    void unsetName();
    
    /**
     * Gets the "processId" element
     */
    java.lang.String getProcessId();
    
    /**
     * Gets (as xml) the "processId" element
     */
    org.apache.xmlbeans.XmlString xgetProcessId();
    
    /**
     * True if has "processId" element
     */
    boolean isSetProcessId();
    
    /**
     * Sets the "processId" element
     */
    void setProcessId(java.lang.String processId);
    
    /**
     * Sets (as xml) the "processId" element
     */
    void xsetProcessId(org.apache.xmlbeans.XmlString processId);
    
    /**
     * Unsets the "processId" element
     */
    void unsetProcessId();
    
    /**
     * Gets the "role" element
     */
    java.lang.String getRole();
    
    /**
     * Gets (as xml) the "role" element
     */
    org.apache.xmlbeans.XmlString xgetRole();
    
    /**
     * True if has "role" element
     */
    boolean isSetRole();
    
    /**
     * Sets the "role" element
     */
    void setRole(java.lang.String role);
    
    /**
     * Sets (as xml) the "role" element
     */
    void xsetRole(org.apache.xmlbeans.XmlString role);
    
    /**
     * Unsets the "role" element
     */
    void unsetRole();
    
    /**
     * Gets array of all "sourceActivitiesForGrab" elements
     */
    com.bea.albpm.papiWebService.ActivityBean[] getSourceActivitiesForGrabArray();
    
    /**
     * Gets ith "sourceActivitiesForGrab" element
     */
    com.bea.albpm.papiWebService.ActivityBean getSourceActivitiesForGrabArray(int i);
    
    /**
     * Tests for nil ith "sourceActivitiesForGrab" element
     */
    boolean isNilSourceActivitiesForGrabArray(int i);
    
    /**
     * Returns number of "sourceActivitiesForGrab" element
     */
    int sizeOfSourceActivitiesForGrabArray();
    
    /**
     * Sets array of all "sourceActivitiesForGrab" element
     */
    void setSourceActivitiesForGrabArray(com.bea.albpm.papiWebService.ActivityBean[] sourceActivitiesForGrabArray);
    
    /**
     * Sets ith "sourceActivitiesForGrab" element
     */
    void setSourceActivitiesForGrabArray(int i, com.bea.albpm.papiWebService.ActivityBean sourceActivitiesForGrab);
    
    /**
     * Nils the ith "sourceActivitiesForGrab" element
     */
    void setNilSourceActivitiesForGrabArray(int i);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "sourceActivitiesForGrab" element
     */
    com.bea.albpm.papiWebService.ActivityBean insertNewSourceActivitiesForGrab(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "sourceActivitiesForGrab" element
     */
    com.bea.albpm.papiWebService.ActivityBean addNewSourceActivitiesForGrab();
    
    /**
     * Removes the ith "sourceActivitiesForGrab" element
     */
    void removeSourceActivitiesForGrab(int i);
    
    /**
     * Gets array of all "tasks" elements
     */
    com.bea.albpm.papiWebService.TaskBean[] getTasksArray();
    
    /**
     * Gets ith "tasks" element
     */
    com.bea.albpm.papiWebService.TaskBean getTasksArray(int i);
    
    /**
     * Tests for nil ith "tasks" element
     */
    boolean isNilTasksArray(int i);
    
    /**
     * Returns number of "tasks" element
     */
    int sizeOfTasksArray();
    
    /**
     * Sets array of all "tasks" element
     */
    void setTasksArray(com.bea.albpm.papiWebService.TaskBean[] tasksArray);
    
    /**
     * Sets ith "tasks" element
     */
    void setTasksArray(int i, com.bea.albpm.papiWebService.TaskBean tasks);
    
    /**
     * Nils the ith "tasks" element
     */
    void setNilTasksArray(int i);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "tasks" element
     */
    com.bea.albpm.papiWebService.TaskBean insertNewTasks(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "tasks" element
     */
    com.bea.albpm.papiWebService.TaskBean addNewTasks();
    
    /**
     * Removes the ith "tasks" element
     */
    void removeTasks(int i);
    
    /**
     * Gets the "type" element
     */
    com.bea.albpm.papiWebService.ActivityType.Enum getType();
    
    /**
     * Gets (as xml) the "type" element
     */
    com.bea.albpm.papiWebService.ActivityType xgetType();
    
    /**
     * True if has "type" element
     */
    boolean isSetType();
    
    /**
     * Sets the "type" element
     */
    void setType(com.bea.albpm.papiWebService.ActivityType.Enum type);
    
    /**
     * Sets (as xml) the "type" element
     */
    void xsetType(com.bea.albpm.papiWebService.ActivityType type);
    
    /**
     * Unsets the "type" element
     */
    void unsetType();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.ActivityBean newInstance() {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.ActivityBean parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.ActivityBean parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityBean parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ActivityBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ActivityBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ActivityBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
