/*
 * XML Type:  filterAttributeBean
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.FilterAttributeBean
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML filterAttributeBean(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface FilterAttributeBean extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(FilterAttributeBean.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("filterattributebean8521type");
    
    /**
     * Gets the "comparison" element
     */
    com.bea.albpm.papiWebService.Comparison.Enum getComparison();
    
    /**
     * Gets (as xml) the "comparison" element
     */
    com.bea.albpm.papiWebService.Comparison xgetComparison();
    
    /**
     * True if has "comparison" element
     */
    boolean isSetComparison();
    
    /**
     * Sets the "comparison" element
     */
    void setComparison(com.bea.albpm.papiWebService.Comparison.Enum comparison);
    
    /**
     * Sets (as xml) the "comparison" element
     */
    void xsetComparison(com.bea.albpm.papiWebService.Comparison comparison);
    
    /**
     * Unsets the "comparison" element
     */
    void unsetComparison();
    
    /**
     * Gets the "isParametric" element
     */
    boolean getIsParametric();
    
    /**
     * Gets (as xml) the "isParametric" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsParametric();
    
    /**
     * Sets the "isParametric" element
     */
    void setIsParametric(boolean isParametric);
    
    /**
     * Sets (as xml) the "isParametric" element
     */
    void xsetIsParametric(org.apache.xmlbeans.XmlBoolean isParametric);
    
    /**
     * Gets the "kind" element
     */
    int getKind();
    
    /**
     * Gets (as xml) the "kind" element
     */
    org.apache.xmlbeans.XmlInt xgetKind();
    
    /**
     * Sets the "kind" element
     */
    void setKind(int kind);
    
    /**
     * Sets (as xml) the "kind" element
     */
    void xsetKind(org.apache.xmlbeans.XmlInt kind);
    
    /**
     * Gets the "value" element
     */
    java.lang.String getValue();
    
    /**
     * Gets (as xml) the "value" element
     */
    org.apache.xmlbeans.XmlString xgetValue();
    
    /**
     * True if has "value" element
     */
    boolean isSetValue();
    
    /**
     * Sets the "value" element
     */
    void setValue(java.lang.String value);
    
    /**
     * Sets (as xml) the "value" element
     */
    void xsetValue(org.apache.xmlbeans.XmlString value);
    
    /**
     * Unsets the "value" element
     */
    void unsetValue();
    
    /**
     * Gets the "variableId" element
     */
    java.lang.String getVariableId();
    
    /**
     * Gets (as xml) the "variableId" element
     */
    org.apache.xmlbeans.XmlString xgetVariableId();
    
    /**
     * True if has "variableId" element
     */
    boolean isSetVariableId();
    
    /**
     * Sets the "variableId" element
     */
    void setVariableId(java.lang.String variableId);
    
    /**
     * Sets (as xml) the "variableId" element
     */
    void xsetVariableId(org.apache.xmlbeans.XmlString variableId);
    
    /**
     * Unsets the "variableId" element
     */
    void unsetVariableId();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.FilterAttributeBean newInstance() {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.FilterAttributeBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.FilterAttributeBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
