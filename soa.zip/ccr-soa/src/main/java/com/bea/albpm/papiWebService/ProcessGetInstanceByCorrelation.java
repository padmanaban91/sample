/*
 * XML Type:  processGetInstanceByCorrelation
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML processGetInstanceByCorrelation(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface ProcessGetInstanceByCorrelation extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ProcessGetInstanceByCorrelation.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("processgetinstancebycorrelationdf3ctype");
    
    /**
     * Gets the "processId" element
     */
    java.lang.String getProcessId();
    
    /**
     * Gets (as xml) the "processId" element
     */
    org.apache.xmlbeans.XmlString xgetProcessId();
    
    /**
     * True if has "processId" element
     */
    boolean isSetProcessId();
    
    /**
     * Sets the "processId" element
     */
    void setProcessId(java.lang.String processId);
    
    /**
     * Sets (as xml) the "processId" element
     */
    void xsetProcessId(org.apache.xmlbeans.XmlString processId);
    
    /**
     * Unsets the "processId" element
     */
    void unsetProcessId();
    
    /**
     * Gets the "correlationName" element
     */
    java.lang.String getCorrelationName();
    
    /**
     * Gets (as xml) the "correlationName" element
     */
    org.apache.xmlbeans.XmlString xgetCorrelationName();
    
    /**
     * True if has "correlationName" element
     */
    boolean isSetCorrelationName();
    
    /**
     * Sets the "correlationName" element
     */
    void setCorrelationName(java.lang.String correlationName);
    
    /**
     * Sets (as xml) the "correlationName" element
     */
    void xsetCorrelationName(org.apache.xmlbeans.XmlString correlationName);
    
    /**
     * Unsets the "correlationName" element
     */
    void unsetCorrelationName();
    
    /**
     * Gets array of all "correlationValues" elements
     */
    java.lang.String[] getCorrelationValuesArray();
    
    /**
     * Gets ith "correlationValues" element
     */
    java.lang.String getCorrelationValuesArray(int i);
    
    /**
     * Gets (as xml) array of all "correlationValues" elements
     */
    org.apache.xmlbeans.XmlString[] xgetCorrelationValuesArray();
    
    /**
     * Gets (as xml) ith "correlationValues" element
     */
    org.apache.xmlbeans.XmlString xgetCorrelationValuesArray(int i);
    
    /**
     * Tests for nil ith "correlationValues" element
     */
    boolean isNilCorrelationValuesArray(int i);
    
    /**
     * Returns number of "correlationValues" element
     */
    int sizeOfCorrelationValuesArray();
    
    /**
     * Sets array of all "correlationValues" element
     */
    void setCorrelationValuesArray(java.lang.String[] correlationValuesArray);
    
    /**
     * Sets ith "correlationValues" element
     */
    void setCorrelationValuesArray(int i, java.lang.String correlationValues);
    
    /**
     * Sets (as xml) array of all "correlationValues" element
     */
    void xsetCorrelationValuesArray(org.apache.xmlbeans.XmlString[] correlationValuesArray);
    
    /**
     * Sets (as xml) ith "correlationValues" element
     */
    void xsetCorrelationValuesArray(int i, org.apache.xmlbeans.XmlString correlationValues);
    
    /**
     * Nils the ith "correlationValues" element
     */
    void setNilCorrelationValuesArray(int i);
    
    /**
     * Inserts the value as the ith "correlationValues" element
     */
    void insertCorrelationValues(int i, java.lang.String correlationValues);
    
    /**
     * Appends the value as the last "correlationValues" element
     */
    void addCorrelationValues(java.lang.String correlationValues);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "correlationValues" element
     */
    org.apache.xmlbeans.XmlString insertNewCorrelationValues(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "correlationValues" element
     */
    org.apache.xmlbeans.XmlString addNewCorrelationValues();
    
    /**
     * Removes the ith "correlationValues" element
     */
    void removeCorrelationValues(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation newInstance() {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ProcessGetInstanceByCorrelation) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
