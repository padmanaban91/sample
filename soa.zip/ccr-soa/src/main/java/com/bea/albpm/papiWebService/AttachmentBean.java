/*
 * XML Type:  attachmentBean
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.AttachmentBean
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML attachmentBean(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface AttachmentBean extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AttachmentBean.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("attachmentbeanb7f2type");
    
    /**
     * Gets the "contentSize" element
     */
    long getContentSize();
    
    /**
     * Gets (as xml) the "contentSize" element
     */
    org.apache.xmlbeans.XmlLong xgetContentSize();
    
    /**
     * Sets the "contentSize" element
     */
    void setContentSize(long contentSize);
    
    /**
     * Sets (as xml) the "contentSize" element
     */
    void xsetContentSize(org.apache.xmlbeans.XmlLong contentSize);
    
    /**
     * Gets the "contentType" element
     */
    java.lang.String getContentType();
    
    /**
     * Gets (as xml) the "contentType" element
     */
    org.apache.xmlbeans.XmlString xgetContentType();
    
    /**
     * True if has "contentType" element
     */
    boolean isSetContentType();
    
    /**
     * Sets the "contentType" element
     */
    void setContentType(java.lang.String contentType);
    
    /**
     * Sets (as xml) the "contentType" element
     */
    void xsetContentType(org.apache.xmlbeans.XmlString contentType);
    
    /**
     * Unsets the "contentType" element
     */
    void unsetContentType();
    
    /**
     * Gets the "creationTime" element
     */
    java.util.Calendar getCreationTime();
    
    /**
     * Gets (as xml) the "creationTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetCreationTime();
    
    /**
     * True if has "creationTime" element
     */
    boolean isSetCreationTime();
    
    /**
     * Sets the "creationTime" element
     */
    void setCreationTime(java.util.Calendar creationTime);
    
    /**
     * Sets (as xml) the "creationTime" element
     */
    void xsetCreationTime(org.apache.xmlbeans.XmlDateTime creationTime);
    
    /**
     * Unsets the "creationTime" element
     */
    void unsetCreationTime();
    
    /**
     * Gets the "description" element
     */
    java.lang.String getDescription();
    
    /**
     * Gets (as xml) the "description" element
     */
    org.apache.xmlbeans.XmlString xgetDescription();
    
    /**
     * True if has "description" element
     */
    boolean isSetDescription();
    
    /**
     * Sets the "description" element
     */
    void setDescription(java.lang.String description);
    
    /**
     * Sets (as xml) the "description" element
     */
    void xsetDescription(org.apache.xmlbeans.XmlString description);
    
    /**
     * Unsets the "description" element
     */
    void unsetDescription();
    
    /**
     * Gets the "editionTime" element
     */
    java.util.Calendar getEditionTime();
    
    /**
     * Gets (as xml) the "editionTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetEditionTime();
    
    /**
     * True if has "editionTime" element
     */
    boolean isSetEditionTime();
    
    /**
     * Sets the "editionTime" element
     */
    void setEditionTime(java.util.Calendar editionTime);
    
    /**
     * Sets (as xml) the "editionTime" element
     */
    void xsetEditionTime(org.apache.xmlbeans.XmlDateTime editionTime);
    
    /**
     * Unsets the "editionTime" element
     */
    void unsetEditionTime();
    
    /**
     * Gets the "externalDownloadUrl" element
     */
    java.lang.String getExternalDownloadUrl();
    
    /**
     * Gets (as xml) the "externalDownloadUrl" element
     */
    org.apache.xmlbeans.XmlString xgetExternalDownloadUrl();
    
    /**
     * True if has "externalDownloadUrl" element
     */
    boolean isSetExternalDownloadUrl();
    
    /**
     * Sets the "externalDownloadUrl" element
     */
    void setExternalDownloadUrl(java.lang.String externalDownloadUrl);
    
    /**
     * Sets (as xml) the "externalDownloadUrl" element
     */
    void xsetExternalDownloadUrl(org.apache.xmlbeans.XmlString externalDownloadUrl);
    
    /**
     * Unsets the "externalDownloadUrl" element
     */
    void unsetExternalDownloadUrl();
    
    /**
     * Gets the "externalId" element
     */
    java.lang.String getExternalId();
    
    /**
     * Gets (as xml) the "externalId" element
     */
    org.apache.xmlbeans.XmlString xgetExternalId();
    
    /**
     * True if has "externalId" element
     */
    boolean isSetExternalId();
    
    /**
     * Sets the "externalId" element
     */
    void setExternalId(java.lang.String externalId);
    
    /**
     * Sets (as xml) the "externalId" element
     */
    void xsetExternalId(org.apache.xmlbeans.XmlString externalId);
    
    /**
     * Unsets the "externalId" element
     */
    void unsetExternalId();
    
    /**
     * Gets the "externalUrl" element
     */
    java.lang.String getExternalUrl();
    
    /**
     * Gets (as xml) the "externalUrl" element
     */
    org.apache.xmlbeans.XmlString xgetExternalUrl();
    
    /**
     * True if has "externalUrl" element
     */
    boolean isSetExternalUrl();
    
    /**
     * Sets the "externalUrl" element
     */
    void setExternalUrl(java.lang.String externalUrl);
    
    /**
     * Sets (as xml) the "externalUrl" element
     */
    void xsetExternalUrl(org.apache.xmlbeans.XmlString externalUrl);
    
    /**
     * Unsets the "externalUrl" element
     */
    void unsetExternalUrl();
    
    /**
     * Gets the "fileExtension" element
     */
    java.lang.String getFileExtension();
    
    /**
     * Gets (as xml) the "fileExtension" element
     */
    org.apache.xmlbeans.XmlString xgetFileExtension();
    
    /**
     * True if has "fileExtension" element
     */
    boolean isSetFileExtension();
    
    /**
     * Sets the "fileExtension" element
     */
    void setFileExtension(java.lang.String fileExtension);
    
    /**
     * Sets (as xml) the "fileExtension" element
     */
    void xsetFileExtension(org.apache.xmlbeans.XmlString fileExtension);
    
    /**
     * Unsets the "fileExtension" element
     */
    void unsetFileExtension();
    
    /**
     * Gets the "id" element
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "id" element
     */
    org.apache.xmlbeans.XmlString xgetId();
    
    /**
     * True if has "id" element
     */
    boolean isSetId();
    
    /**
     * Sets the "id" element
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "id" element
     */
    void xsetId(org.apache.xmlbeans.XmlString id);
    
    /**
     * Unsets the "id" element
     */
    void unsetId();
    
    /**
     * Gets the "instanceId" element
     */
    java.lang.String getInstanceId();
    
    /**
     * Gets (as xml) the "instanceId" element
     */
    org.apache.xmlbeans.XmlString xgetInstanceId();
    
    /**
     * True if has "instanceId" element
     */
    boolean isSetInstanceId();
    
    /**
     * Sets the "instanceId" element
     */
    void setInstanceId(java.lang.String instanceId);
    
    /**
     * Sets (as xml) the "instanceId" element
     */
    void xsetInstanceId(org.apache.xmlbeans.XmlString instanceId);
    
    /**
     * Unsets the "instanceId" element
     */
    void unsetInstanceId();
    
    /**
     * Gets the "locale" element
     */
    com.bea.albpm.papiWebService.LocaleBean getLocale();
    
    /**
     * True if has "locale" element
     */
    boolean isSetLocale();
    
    /**
     * Sets the "locale" element
     */
    void setLocale(com.bea.albpm.papiWebService.LocaleBean locale);
    
    /**
     * Appends and returns a new empty "locale" element
     */
    com.bea.albpm.papiWebService.LocaleBean addNewLocale();
    
    /**
     * Unsets the "locale" element
     */
    void unsetLocale();
    
    /**
     * Gets the "locked" element
     */
    boolean getLocked();
    
    /**
     * Gets (as xml) the "locked" element
     */
    org.apache.xmlbeans.XmlBoolean xgetLocked();
    
    /**
     * Sets the "locked" element
     */
    void setLocked(boolean locked);
    
    /**
     * Sets (as xml) the "locked" element
     */
    void xsetLocked(org.apache.xmlbeans.XmlBoolean locked);
    
    /**
     * Gets the "lockerName" element
     */
    java.lang.String getLockerName();
    
    /**
     * Gets (as xml) the "lockerName" element
     */
    org.apache.xmlbeans.XmlString xgetLockerName();
    
    /**
     * True if has "lockerName" element
     */
    boolean isSetLockerName();
    
    /**
     * Sets the "lockerName" element
     */
    void setLockerName(java.lang.String lockerName);
    
    /**
     * Sets (as xml) the "lockerName" element
     */
    void xsetLockerName(org.apache.xmlbeans.XmlString lockerName);
    
    /**
     * Unsets the "lockerName" element
     */
    void unsetLockerName();
    
    /**
     * Gets the "name" element
     */
    java.lang.String getName();
    
    /**
     * Gets (as xml) the "name" element
     */
    org.apache.xmlbeans.XmlString xgetName();
    
    /**
     * True if has "name" element
     */
    boolean isSetName();
    
    /**
     * Sets the "name" element
     */
    void setName(java.lang.String name);
    
    /**
     * Sets (as xml) the "name" element
     */
    void xsetName(org.apache.xmlbeans.XmlString name);
    
    /**
     * Unsets the "name" element
     */
    void unsetName();
    
    /**
     * Gets the "processId" element
     */
    java.lang.String getProcessId();
    
    /**
     * Gets (as xml) the "processId" element
     */
    org.apache.xmlbeans.XmlString xgetProcessId();
    
    /**
     * True if has "processId" element
     */
    boolean isSetProcessId();
    
    /**
     * Sets the "processId" element
     */
    void setProcessId(java.lang.String processId);
    
    /**
     * Sets (as xml) the "processId" element
     */
    void xsetProcessId(org.apache.xmlbeans.XmlString processId);
    
    /**
     * Unsets the "processId" element
     */
    void unsetProcessId();
    
    /**
     * Gets the "remarks" element
     */
    java.lang.String getRemarks();
    
    /**
     * Gets (as xml) the "remarks" element
     */
    org.apache.xmlbeans.XmlString xgetRemarks();
    
    /**
     * True if has "remarks" element
     */
    boolean isSetRemarks();
    
    /**
     * Sets the "remarks" element
     */
    void setRemarks(java.lang.String remarks);
    
    /**
     * Sets (as xml) the "remarks" element
     */
    void xsetRemarks(org.apache.xmlbeans.XmlString remarks);
    
    /**
     * Unsets the "remarks" element
     */
    void unsetRemarks();
    
    /**
     * Gets the "storageType" element
     */
    com.bea.albpm.papiWebService.AttachmentStorageType.Enum getStorageType();
    
    /**
     * Gets (as xml) the "storageType" element
     */
    com.bea.albpm.papiWebService.AttachmentStorageType xgetStorageType();
    
    /**
     * True if has "storageType" element
     */
    boolean isSetStorageType();
    
    /**
     * Sets the "storageType" element
     */
    void setStorageType(com.bea.albpm.papiWebService.AttachmentStorageType.Enum storageType);
    
    /**
     * Sets (as xml) the "storageType" element
     */
    void xsetStorageType(com.bea.albpm.papiWebService.AttachmentStorageType storageType);
    
    /**
     * Unsets the "storageType" element
     */
    void unsetStorageType();
    
    /**
     * Gets the "version" element
     */
    int getVersion();
    
    /**
     * Gets (as xml) the "version" element
     */
    org.apache.xmlbeans.XmlInt xgetVersion();
    
    /**
     * Sets the "version" element
     */
    void setVersion(int version);
    
    /**
     * Sets (as xml) the "version" element
     */
    void xsetVersion(org.apache.xmlbeans.XmlInt version);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.AttachmentBean newInstance() {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.AttachmentBean parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.AttachmentBean parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.AttachmentBean parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.AttachmentBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.AttachmentBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.AttachmentBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
