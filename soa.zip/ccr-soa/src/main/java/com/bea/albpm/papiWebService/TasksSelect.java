/*
 * XML Type:  tasksSelect
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.TasksSelect
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML tasksSelect(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface TasksSelect extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TasksSelect.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("tasksselecte777type");
    
    /**
     * Gets array of all "taskNumbers" elements
     */
    int[] getTaskNumbersArray();
    
    /**
     * Gets ith "taskNumbers" element
     */
    int getTaskNumbersArray(int i);
    
    /**
     * Gets (as xml) array of all "taskNumbers" elements
     */
    org.apache.xmlbeans.XmlInt[] xgetTaskNumbersArray();
    
    /**
     * Gets (as xml) ith "taskNumbers" element
     */
    org.apache.xmlbeans.XmlInt xgetTaskNumbersArray(int i);
    
    /**
     * Tests for nil ith "taskNumbers" element
     */
    boolean isNilTaskNumbersArray(int i);
    
    /**
     * Returns number of "taskNumbers" element
     */
    int sizeOfTaskNumbersArray();
    
    /**
     * Sets array of all "taskNumbers" element
     */
    void setTaskNumbersArray(int[] taskNumbersArray);
    
    /**
     * Sets ith "taskNumbers" element
     */
    void setTaskNumbersArray(int i, int taskNumbers);
    
    /**
     * Sets (as xml) array of all "taskNumbers" element
     */
    void xsetTaskNumbersArray(org.apache.xmlbeans.XmlInt[] taskNumbersArray);
    
    /**
     * Sets (as xml) ith "taskNumbers" element
     */
    void xsetTaskNumbersArray(int i, org.apache.xmlbeans.XmlInt taskNumbers);
    
    /**
     * Nils the ith "taskNumbers" element
     */
    void setNilTaskNumbersArray(int i);
    
    /**
     * Inserts the value as the ith "taskNumbers" element
     */
    void insertTaskNumbers(int i, int taskNumbers);
    
    /**
     * Appends the value as the last "taskNumbers" element
     */
    void addTaskNumbers(int taskNumbers);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "taskNumbers" element
     */
    org.apache.xmlbeans.XmlInt insertNewTaskNumbers(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "taskNumbers" element
     */
    org.apache.xmlbeans.XmlInt addNewTaskNumbers();
    
    /**
     * Removes the ith "taskNumbers" element
     */
    void removeTaskNumbers(int i);
    
    /**
     * Gets the "activityName" element
     */
    java.lang.String getActivityName();
    
    /**
     * Gets (as xml) the "activityName" element
     */
    org.apache.xmlbeans.XmlString xgetActivityName();
    
    /**
     * True if has "activityName" element
     */
    boolean isSetActivityName();
    
    /**
     * Sets the "activityName" element
     */
    void setActivityName(java.lang.String activityName);
    
    /**
     * Sets (as xml) the "activityName" element
     */
    void xsetActivityName(org.apache.xmlbeans.XmlString activityName);
    
    /**
     * Unsets the "activityName" element
     */
    void unsetActivityName();
    
    /**
     * Gets the "instanceId" element
     */
    java.lang.String getInstanceId();
    
    /**
     * Gets (as xml) the "instanceId" element
     */
    org.apache.xmlbeans.XmlString xgetInstanceId();
    
    /**
     * True if has "instanceId" element
     */
    boolean isSetInstanceId();
    
    /**
     * Sets the "instanceId" element
     */
    void setInstanceId(java.lang.String instanceId);
    
    /**
     * Sets (as xml) the "instanceId" element
     */
    void xsetInstanceId(org.apache.xmlbeans.XmlString instanceId);
    
    /**
     * Unsets the "instanceId" element
     */
    void unsetInstanceId();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.TasksSelect newInstance() {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.TasksSelect parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.TasksSelect parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.TasksSelect parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.TasksSelect parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.TasksSelect parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.TasksSelect) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
