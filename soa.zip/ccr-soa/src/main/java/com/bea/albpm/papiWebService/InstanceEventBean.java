/*
 * XML Type:  instanceEventBean
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.InstanceEventBean
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML instanceEventBean(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface InstanceEventBean extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(InstanceEventBean.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("instanceeventbean3ee2type");
    
    /**
     * Gets the "activationTime" element
     */
    java.util.Calendar getActivationTime();
    
    /**
     * Gets (as xml) the "activationTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetActivationTime();
    
    /**
     * True if has "activationTime" element
     */
    boolean isSetActivationTime();
    
    /**
     * Sets the "activationTime" element
     */
    void setActivationTime(java.util.Calendar activationTime);
    
    /**
     * Sets (as xml) the "activationTime" element
     */
    void xsetActivationTime(org.apache.xmlbeans.XmlDateTime activationTime);
    
    /**
     * Unsets the "activationTime" element
     */
    void unsetActivationTime();
    
    /**
     * Gets the "activity" element
     */
    java.lang.String getActivity();
    
    /**
     * Gets (as xml) the "activity" element
     */
    org.apache.xmlbeans.XmlString xgetActivity();
    
    /**
     * True if has "activity" element
     */
    boolean isSetActivity();
    
    /**
     * Sets the "activity" element
     */
    void setActivity(java.lang.String activity);
    
    /**
     * Sets (as xml) the "activity" element
     */
    void xsetActivity(org.apache.xmlbeans.XmlString activity);
    
    /**
     * Unsets the "activity" element
     */
    void unsetActivity();
    
    /**
     * Gets array of all "businessVariablesIds" elements
     */
    java.lang.String[] getBusinessVariablesIdsArray();
    
    /**
     * Gets ith "businessVariablesIds" element
     */
    java.lang.String getBusinessVariablesIdsArray(int i);
    
    /**
     * Gets (as xml) array of all "businessVariablesIds" elements
     */
    org.apache.xmlbeans.XmlString[] xgetBusinessVariablesIdsArray();
    
    /**
     * Gets (as xml) ith "businessVariablesIds" element
     */
    org.apache.xmlbeans.XmlString xgetBusinessVariablesIdsArray(int i);
    
    /**
     * Tests for nil ith "businessVariablesIds" element
     */
    boolean isNilBusinessVariablesIdsArray(int i);
    
    /**
     * Returns number of "businessVariablesIds" element
     */
    int sizeOfBusinessVariablesIdsArray();
    
    /**
     * Sets array of all "businessVariablesIds" element
     */
    void setBusinessVariablesIdsArray(java.lang.String[] businessVariablesIdsArray);
    
    /**
     * Sets ith "businessVariablesIds" element
     */
    void setBusinessVariablesIdsArray(int i, java.lang.String businessVariablesIds);
    
    /**
     * Sets (as xml) array of all "businessVariablesIds" element
     */
    void xsetBusinessVariablesIdsArray(org.apache.xmlbeans.XmlString[] businessVariablesIdsArray);
    
    /**
     * Sets (as xml) ith "businessVariablesIds" element
     */
    void xsetBusinessVariablesIdsArray(int i, org.apache.xmlbeans.XmlString businessVariablesIds);
    
    /**
     * Nils the ith "businessVariablesIds" element
     */
    void setNilBusinessVariablesIdsArray(int i);
    
    /**
     * Inserts the value as the ith "businessVariablesIds" element
     */
    void insertBusinessVariablesIds(int i, java.lang.String businessVariablesIds);
    
    /**
     * Appends the value as the last "businessVariablesIds" element
     */
    void addBusinessVariablesIds(java.lang.String businessVariablesIds);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "businessVariablesIds" element
     */
    org.apache.xmlbeans.XmlString insertNewBusinessVariablesIds(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "businessVariablesIds" element
     */
    org.apache.xmlbeans.XmlString addNewBusinessVariablesIds();
    
    /**
     * Removes the ith "businessVariablesIds" element
     */
    void removeBusinessVariablesIds(int i);
    
    /**
     * Gets array of all "businessVariablesValues" elements
     */
    java.lang.String[] getBusinessVariablesValuesArray();
    
    /**
     * Gets ith "businessVariablesValues" element
     */
    java.lang.String getBusinessVariablesValuesArray(int i);
    
    /**
     * Gets (as xml) array of all "businessVariablesValues" elements
     */
    org.apache.xmlbeans.XmlString[] xgetBusinessVariablesValuesArray();
    
    /**
     * Gets (as xml) ith "businessVariablesValues" element
     */
    org.apache.xmlbeans.XmlString xgetBusinessVariablesValuesArray(int i);
    
    /**
     * Tests for nil ith "businessVariablesValues" element
     */
    boolean isNilBusinessVariablesValuesArray(int i);
    
    /**
     * Returns number of "businessVariablesValues" element
     */
    int sizeOfBusinessVariablesValuesArray();
    
    /**
     * Sets array of all "businessVariablesValues" element
     */
    void setBusinessVariablesValuesArray(java.lang.String[] businessVariablesValuesArray);
    
    /**
     * Sets ith "businessVariablesValues" element
     */
    void setBusinessVariablesValuesArray(int i, java.lang.String businessVariablesValues);
    
    /**
     * Sets (as xml) array of all "businessVariablesValues" element
     */
    void xsetBusinessVariablesValuesArray(org.apache.xmlbeans.XmlString[] businessVariablesValuesArray);
    
    /**
     * Sets (as xml) ith "businessVariablesValues" element
     */
    void xsetBusinessVariablesValuesArray(int i, org.apache.xmlbeans.XmlString businessVariablesValues);
    
    /**
     * Nils the ith "businessVariablesValues" element
     */
    void setNilBusinessVariablesValuesArray(int i);
    
    /**
     * Inserts the value as the ith "businessVariablesValues" element
     */
    void insertBusinessVariablesValues(int i, java.lang.String businessVariablesValues);
    
    /**
     * Appends the value as the last "businessVariablesValues" element
     */
    void addBusinessVariablesValues(java.lang.String businessVariablesValues);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "businessVariablesValues" element
     */
    org.apache.xmlbeans.XmlString insertNewBusinessVariablesValues(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "businessVariablesValues" element
     */
    org.apache.xmlbeans.XmlString addNewBusinessVariablesValues();
    
    /**
     * Removes the ith "businessVariablesValues" element
     */
    void removeBusinessVariablesValues(int i);
    
    /**
     * Gets the "category" element
     */
    int getCategory();
    
    /**
     * Gets (as xml) the "category" element
     */
    org.apache.xmlbeans.XmlInt xgetCategory();
    
    /**
     * Sets the "category" element
     */
    void setCategory(int category);
    
    /**
     * Sets (as xml) the "category" element
     */
    void xsetCategory(org.apache.xmlbeans.XmlInt category);
    
    /**
     * Gets the "data" element
     */
    java.lang.String getData();
    
    /**
     * Gets (as xml) the "data" element
     */
    org.apache.xmlbeans.XmlString xgetData();
    
    /**
     * True if has "data" element
     */
    boolean isSetData();
    
    /**
     * Sets the "data" element
     */
    void setData(java.lang.String data);
    
    /**
     * Sets (as xml) the "data" element
     */
    void xsetData(org.apache.xmlbeans.XmlString data);
    
    /**
     * Unsets the "data" element
     */
    void unsetData();
    
    /**
     * Gets the "id" element
     */
    int getId();
    
    /**
     * Gets (as xml) the "id" element
     */
    org.apache.xmlbeans.XmlInt xgetId();
    
    /**
     * Sets the "id" element
     */
    void setId(int id);
    
    /**
     * Sets (as xml) the "id" element
     */
    void xsetId(org.apache.xmlbeans.XmlInt id);
    
    /**
     * Gets the "instanceId" element
     */
    java.lang.String getInstanceId();
    
    /**
     * Gets (as xml) the "instanceId" element
     */
    org.apache.xmlbeans.XmlString xgetInstanceId();
    
    /**
     * True if has "instanceId" element
     */
    boolean isSetInstanceId();
    
    /**
     * Sets the "instanceId" element
     */
    void setInstanceId(java.lang.String instanceId);
    
    /**
     * Sets (as xml) the "instanceId" element
     */
    void xsetInstanceId(org.apache.xmlbeans.XmlString instanceId);
    
    /**
     * Unsets the "instanceId" element
     */
    void unsetInstanceId();
    
    /**
     * Gets the "instanceIn" element
     */
    int getInstanceIn();
    
    /**
     * Gets (as xml) the "instanceIn" element
     */
    org.apache.xmlbeans.XmlInt xgetInstanceIn();
    
    /**
     * Sets the "instanceIn" element
     */
    void setInstanceIn(int instanceIn);
    
    /**
     * Sets (as xml) the "instanceIn" element
     */
    void xsetInstanceIn(org.apache.xmlbeans.XmlInt instanceIn);
    
    /**
     * Gets the "participant" element
     */
    java.lang.String getParticipant();
    
    /**
     * Gets (as xml) the "participant" element
     */
    org.apache.xmlbeans.XmlString xgetParticipant();
    
    /**
     * True if has "participant" element
     */
    boolean isSetParticipant();
    
    /**
     * Sets the "participant" element
     */
    void setParticipant(java.lang.String participant);
    
    /**
     * Sets (as xml) the "participant" element
     */
    void xsetParticipant(org.apache.xmlbeans.XmlString participant);
    
    /**
     * Unsets the "participant" element
     */
    void unsetParticipant();
    
    /**
     * Gets the "processId" element
     */
    java.lang.String getProcessId();
    
    /**
     * Gets (as xml) the "processId" element
     */
    org.apache.xmlbeans.XmlString xgetProcessId();
    
    /**
     * True if has "processId" element
     */
    boolean isSetProcessId();
    
    /**
     * Sets the "processId" element
     */
    void setProcessId(java.lang.String processId);
    
    /**
     * Sets (as xml) the "processId" element
     */
    void xsetProcessId(org.apache.xmlbeans.XmlString processId);
    
    /**
     * Unsets the "processId" element
     */
    void unsetProcessId();
    
    /**
     * Gets the "processIn" element
     */
    int getProcessIn();
    
    /**
     * Gets (as xml) the "processIn" element
     */
    org.apache.xmlbeans.XmlInt xgetProcessIn();
    
    /**
     * Sets the "processIn" element
     */
    void setProcessIn(int processIn);
    
    /**
     * Sets (as xml) the "processIn" element
     */
    void xsetProcessIn(org.apache.xmlbeans.XmlInt processIn);
    
    /**
     * Gets the "receiveTime" element
     */
    java.util.Calendar getReceiveTime();
    
    /**
     * Gets (as xml) the "receiveTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetReceiveTime();
    
    /**
     * True if has "receiveTime" element
     */
    boolean isSetReceiveTime();
    
    /**
     * Sets the "receiveTime" element
     */
    void setReceiveTime(java.util.Calendar receiveTime);
    
    /**
     * Sets (as xml) the "receiveTime" element
     */
    void xsetReceiveTime(org.apache.xmlbeans.XmlDateTime receiveTime);
    
    /**
     * Unsets the "receiveTime" element
     */
    void unsetReceiveTime();
    
    /**
     * Gets the "threadIn" element
     */
    int getThreadIn();
    
    /**
     * Gets (as xml) the "threadIn" element
     */
    org.apache.xmlbeans.XmlInt xgetThreadIn();
    
    /**
     * Sets the "threadIn" element
     */
    void setThreadIn(int threadIn);
    
    /**
     * Sets (as xml) the "threadIn" element
     */
    void xsetThreadIn(org.apache.xmlbeans.XmlInt threadIn);
    
    /**
     * Gets the "timeStamp" element
     */
    java.util.Calendar getTimeStamp();
    
    /**
     * Gets (as xml) the "timeStamp" element
     */
    org.apache.xmlbeans.XmlDateTime xgetTimeStamp();
    
    /**
     * True if has "timeStamp" element
     */
    boolean isSetTimeStamp();
    
    /**
     * Sets the "timeStamp" element
     */
    void setTimeStamp(java.util.Calendar timeStamp);
    
    /**
     * Sets (as xml) the "timeStamp" element
     */
    void xsetTimeStamp(org.apache.xmlbeans.XmlDateTime timeStamp);
    
    /**
     * Unsets the "timeStamp" element
     */
    void unsetTimeStamp();
    
    /**
     * Gets the "type" element
     */
    int getType();
    
    /**
     * Gets (as xml) the "type" element
     */
    org.apache.xmlbeans.XmlInt xgetType();
    
    /**
     * Sets the "type" element
     */
    void setType(int type);
    
    /**
     * Sets (as xml) the "type" element
     */
    void xsetType(org.apache.xmlbeans.XmlInt type);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.InstanceEventBean newInstance() {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.InstanceEventBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.InstanceEventBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
