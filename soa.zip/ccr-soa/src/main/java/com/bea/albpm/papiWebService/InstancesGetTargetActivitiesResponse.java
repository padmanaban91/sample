/*
 * XML Type:  instancesGetTargetActivitiesResponse
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML instancesGetTargetActivitiesResponse(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface InstancesGetTargetActivitiesResponse extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(InstancesGetTargetActivitiesResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("instancesgettargetactivitiesresponse6896type");
    
    /**
     * Gets array of all "activities" elements
     */
    java.lang.String[] getActivitiesArray();
    
    /**
     * Gets ith "activities" element
     */
    java.lang.String getActivitiesArray(int i);
    
    /**
     * Gets (as xml) array of all "activities" elements
     */
    org.apache.xmlbeans.XmlString[] xgetActivitiesArray();
    
    /**
     * Gets (as xml) ith "activities" element
     */
    org.apache.xmlbeans.XmlString xgetActivitiesArray(int i);
    
    /**
     * Returns number of "activities" element
     */
    int sizeOfActivitiesArray();
    
    /**
     * Sets array of all "activities" element
     */
    void setActivitiesArray(java.lang.String[] activitiesArray);
    
    /**
     * Sets ith "activities" element
     */
    void setActivitiesArray(int i, java.lang.String activities);
    
    /**
     * Sets (as xml) array of all "activities" element
     */
    void xsetActivitiesArray(org.apache.xmlbeans.XmlString[] activitiesArray);
    
    /**
     * Sets (as xml) ith "activities" element
     */
    void xsetActivitiesArray(int i, org.apache.xmlbeans.XmlString activities);
    
    /**
     * Inserts the value as the ith "activities" element
     */
    void insertActivities(int i, java.lang.String activities);
    
    /**
     * Appends the value as the last "activities" element
     */
    void addActivities(java.lang.String activities);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "activities" element
     */
    org.apache.xmlbeans.XmlString insertNewActivities(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "activities" element
     */
    org.apache.xmlbeans.XmlString addNewActivities();
    
    /**
     * Removes the ith "activities" element
     */
    void removeActivities(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse newInstance() {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetActivitiesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
