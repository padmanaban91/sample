/*
 * XML Type:  instanceInfoBean
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.InstanceInfoBean
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML instanceInfoBean(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface InstanceInfoBean extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(InstanceInfoBean.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("instanceinfobeand372type");
    
    /**
     * Gets the "activityDeadline" element
     */
    java.util.Calendar getActivityDeadline();
    
    /**
     * Gets (as xml) the "activityDeadline" element
     */
    org.apache.xmlbeans.XmlDateTime xgetActivityDeadline();
    
    /**
     * True if has "activityDeadline" element
     */
    boolean isSetActivityDeadline();
    
    /**
     * Sets the "activityDeadline" element
     */
    void setActivityDeadline(java.util.Calendar activityDeadline);
    
    /**
     * Sets (as xml) the "activityDeadline" element
     */
    void xsetActivityDeadline(org.apache.xmlbeans.XmlDateTime activityDeadline);
    
    /**
     * Unsets the "activityDeadline" element
     */
    void unsetActivityDeadline();
    
    /**
     * Gets the "activityName" element
     */
    java.lang.String getActivityName();
    
    /**
     * Gets (as xml) the "activityName" element
     */
    org.apache.xmlbeans.XmlString xgetActivityName();
    
    /**
     * True if has "activityName" element
     */
    boolean isSetActivityName();
    
    /**
     * Sets the "activityName" element
     */
    void setActivityName(java.lang.String activityName);
    
    /**
     * Sets (as xml) the "activityName" element
     */
    void xsetActivityName(org.apache.xmlbeans.XmlString activityName);
    
    /**
     * Unsets the "activityName" element
     */
    void unsetActivityName();
    
    /**
     * Gets the "author" element
     */
    java.lang.String getAuthor();
    
    /**
     * Gets (as xml) the "author" element
     */
    org.apache.xmlbeans.XmlString xgetAuthor();
    
    /**
     * True if has "author" element
     */
    boolean isSetAuthor();
    
    /**
     * Sets the "author" element
     */
    void setAuthor(java.lang.String author);
    
    /**
     * Sets (as xml) the "author" element
     */
    void xsetAuthor(org.apache.xmlbeans.XmlString author);
    
    /**
     * Unsets the "author" element
     */
    void unsetAuthor();
    
    /**
     * Gets the "creationTime" element
     */
    java.util.Calendar getCreationTime();
    
    /**
     * Gets (as xml) the "creationTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetCreationTime();
    
    /**
     * True if has "creationTime" element
     */
    boolean isSetCreationTime();
    
    /**
     * Sets the "creationTime" element
     */
    void setCreationTime(java.util.Calendar creationTime);
    
    /**
     * Sets (as xml) the "creationTime" element
     */
    void xsetCreationTime(org.apache.xmlbeans.XmlDateTime creationTime);
    
    /**
     * Unsets the "creationTime" element
     */
    void unsetCreationTime();
    
    /**
     * Gets the "description" element
     */
    java.lang.String getDescription();
    
    /**
     * Gets (as xml) the "description" element
     */
    org.apache.xmlbeans.XmlString xgetDescription();
    
    /**
     * True if has "description" element
     */
    boolean isSetDescription();
    
    /**
     * Sets the "description" element
     */
    void setDescription(java.lang.String description);
    
    /**
     * Sets (as xml) the "description" element
     */
    void xsetDescription(org.apache.xmlbeans.XmlString description);
    
    /**
     * Unsets the "description" element
     */
    void unsetDescription();
    
    /**
     * Gets the "id" element
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "id" element
     */
    org.apache.xmlbeans.XmlString xgetId();
    
    /**
     * True if has "id" element
     */
    boolean isSetId();
    
    /**
     * Sets the "id" element
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "id" element
     */
    void xsetId(org.apache.xmlbeans.XmlString id);
    
    /**
     * Unsets the "id" element
     */
    void unsetId();
    
    /**
     * Gets the "numberOfThreads" element
     */
    int getNumberOfThreads();
    
    /**
     * Gets (as xml) the "numberOfThreads" element
     */
    org.apache.xmlbeans.XmlInt xgetNumberOfThreads();
    
    /**
     * Sets the "numberOfThreads" element
     */
    void setNumberOfThreads(int numberOfThreads);
    
    /**
     * Sets (as xml) the "numberOfThreads" element
     */
    void xsetNumberOfThreads(org.apache.xmlbeans.XmlInt numberOfThreads);
    
    /**
     * Gets the "parentThread" element
     */
    int getParentThread();
    
    /**
     * Gets (as xml) the "parentThread" element
     */
    org.apache.xmlbeans.XmlInt xgetParentThread();
    
    /**
     * Sets the "parentThread" element
     */
    void setParentThread(int parentThread);
    
    /**
     * Sets (as xml) the "parentThread" element
     */
    void xsetParentThread(org.apache.xmlbeans.XmlInt parentThread);
    
    /**
     * Gets the "participant" element
     */
    java.lang.String getParticipant();
    
    /**
     * Gets (as xml) the "participant" element
     */
    org.apache.xmlbeans.XmlString xgetParticipant();
    
    /**
     * True if has "participant" element
     */
    boolean isSetParticipant();
    
    /**
     * Sets the "participant" element
     */
    void setParticipant(java.lang.String participant);
    
    /**
     * Sets (as xml) the "participant" element
     */
    void xsetParticipant(org.apache.xmlbeans.XmlString participant);
    
    /**
     * Unsets the "participant" element
     */
    void unsetParticipant();
    
    /**
     * Gets the "priority" element
     */
    int getPriority();
    
    /**
     * Gets (as xml) the "priority" element
     */
    org.apache.xmlbeans.XmlInt xgetPriority();
    
    /**
     * Sets the "priority" element
     */
    void setPriority(int priority);
    
    /**
     * Sets (as xml) the "priority" element
     */
    void xsetPriority(org.apache.xmlbeans.XmlInt priority);
    
    /**
     * Gets the "process" element
     */
    java.lang.String getProcess();
    
    /**
     * Gets (as xml) the "process" element
     */
    org.apache.xmlbeans.XmlString xgetProcess();
    
    /**
     * True if has "process" element
     */
    boolean isSetProcess();
    
    /**
     * Sets the "process" element
     */
    void setProcess(java.lang.String process);
    
    /**
     * Sets (as xml) the "process" element
     */
    void xsetProcess(org.apache.xmlbeans.XmlString process);
    
    /**
     * Unsets the "process" element
     */
    void unsetProcess();
    
    /**
     * Gets the "processDeadline" element
     */
    java.util.Calendar getProcessDeadline();
    
    /**
     * Gets (as xml) the "processDeadline" element
     */
    org.apache.xmlbeans.XmlDateTime xgetProcessDeadline();
    
    /**
     * True if has "processDeadline" element
     */
    boolean isSetProcessDeadline();
    
    /**
     * Sets the "processDeadline" element
     */
    void setProcessDeadline(java.util.Calendar processDeadline);
    
    /**
     * Sets (as xml) the "processDeadline" element
     */
    void xsetProcessDeadline(org.apache.xmlbeans.XmlDateTime processDeadline);
    
    /**
     * Unsets the "processDeadline" element
     */
    void unsetProcessDeadline();
    
    /**
     * Gets the "receptionTime" element
     */
    java.util.Calendar getReceptionTime();
    
    /**
     * Gets (as xml) the "receptionTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetReceptionTime();
    
    /**
     * True if has "receptionTime" element
     */
    boolean isSetReceptionTime();
    
    /**
     * Sets the "receptionTime" element
     */
    void setReceptionTime(java.util.Calendar receptionTime);
    
    /**
     * Sets (as xml) the "receptionTime" element
     */
    void xsetReceptionTime(org.apache.xmlbeans.XmlDateTime receptionTime);
    
    /**
     * Unsets the "receptionTime" element
     */
    void unsetReceptionTime();
    
    /**
     * Gets the "role" element
     */
    java.lang.String getRole();
    
    /**
     * Gets (as xml) the "role" element
     */
    org.apache.xmlbeans.XmlString xgetRole();
    
    /**
     * True if has "role" element
     */
    boolean isSetRole();
    
    /**
     * Sets the "role" element
     */
    void setRole(java.lang.String role);
    
    /**
     * Sets (as xml) the "role" element
     */
    void xsetRole(org.apache.xmlbeans.XmlString role);
    
    /**
     * Unsets the "role" element
     */
    void unsetRole();
    
    /**
     * Gets the "state" element
     */
    int getState();
    
    /**
     * Gets (as xml) the "state" element
     */
    org.apache.xmlbeans.XmlInt xgetState();
    
    /**
     * Sets the "state" element
     */
    void setState(int state);
    
    /**
     * Sets (as xml) the "state" element
     */
    void xsetState(org.apache.xmlbeans.XmlInt state);
    
    /**
     * Gets the "taskCount" element
     */
    int getTaskCount();
    
    /**
     * Gets (as xml) the "taskCount" element
     */
    org.apache.xmlbeans.XmlInt xgetTaskCount();
    
    /**
     * Sets the "taskCount" element
     */
    void setTaskCount(int taskCount);
    
    /**
     * Sets (as xml) the "taskCount" element
     */
    void xsetTaskCount(org.apache.xmlbeans.XmlInt taskCount);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.InstanceInfoBean newInstance() {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.InstanceInfoBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.InstanceInfoBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
