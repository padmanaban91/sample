/*
 * XML Type:  presentationBean
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.PresentationBean
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML presentationBean(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface PresentationBean extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PresentationBean.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("presentationbeanf4a9type");
    
    /**
     * Gets array of all "columns" elements
     */
    com.bea.albpm.papiWebService.ColumnBean[] getColumnsArray();
    
    /**
     * Gets ith "columns" element
     */
    com.bea.albpm.papiWebService.ColumnBean getColumnsArray(int i);
    
    /**
     * Tests for nil ith "columns" element
     */
    boolean isNilColumnsArray(int i);
    
    /**
     * Returns number of "columns" element
     */
    int sizeOfColumnsArray();
    
    /**
     * Sets array of all "columns" element
     */
    void setColumnsArray(com.bea.albpm.papiWebService.ColumnBean[] columnsArray);
    
    /**
     * Sets ith "columns" element
     */
    void setColumnsArray(int i, com.bea.albpm.papiWebService.ColumnBean columns);
    
    /**
     * Nils the ith "columns" element
     */
    void setNilColumnsArray(int i);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "columns" element
     */
    com.bea.albpm.papiWebService.ColumnBean insertNewColumns(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "columns" element
     */
    com.bea.albpm.papiWebService.ColumnBean addNewColumns();
    
    /**
     * Removes the ith "columns" element
     */
    void removeColumns(int i);
    
    /**
     * Gets the "id" element
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "id" element
     */
    org.apache.xmlbeans.XmlString xgetId();
    
    /**
     * True if has "id" element
     */
    boolean isSetId();
    
    /**
     * Sets the "id" element
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "id" element
     */
    void xsetId(org.apache.xmlbeans.XmlString id);
    
    /**
     * Unsets the "id" element
     */
    void unsetId();
    
    /**
     * Gets the "isReadOnly" element
     */
    boolean getIsReadOnly();
    
    /**
     * Gets (as xml) the "isReadOnly" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsReadOnly();
    
    /**
     * Sets the "isReadOnly" element
     */
    void setIsReadOnly(boolean isReadOnly);
    
    /**
     * Sets (as xml) the "isReadOnly" element
     */
    void xsetIsReadOnly(org.apache.xmlbeans.XmlBoolean isReadOnly);
    
    /**
     * Gets the "ordering" element
     */
    com.bea.albpm.papiWebService.OrderingBean getOrdering();
    
    /**
     * True if has "ordering" element
     */
    boolean isSetOrdering();
    
    /**
     * Sets the "ordering" element
     */
    void setOrdering(com.bea.albpm.papiWebService.OrderingBean ordering);
    
    /**
     * Appends and returns a new empty "ordering" element
     */
    com.bea.albpm.papiWebService.OrderingBean addNewOrdering();
    
    /**
     * Unsets the "ordering" element
     */
    void unsetOrdering();
    
    /**
     * Gets the "owner" element
     */
    java.lang.String getOwner();
    
    /**
     * Gets (as xml) the "owner" element
     */
    org.apache.xmlbeans.XmlString xgetOwner();
    
    /**
     * True if has "owner" element
     */
    boolean isSetOwner();
    
    /**
     * Sets the "owner" element
     */
    void setOwner(java.lang.String owner);
    
    /**
     * Sets (as xml) the "owner" element
     */
    void xsetOwner(org.apache.xmlbeans.XmlString owner);
    
    /**
     * Unsets the "owner" element
     */
    void unsetOwner();
    
    /**
     * Gets the "type" element
     */
    com.bea.albpm.papiWebService.PresentationType.Enum getType();
    
    /**
     * Gets (as xml) the "type" element
     */
    com.bea.albpm.papiWebService.PresentationType xgetType();
    
    /**
     * True if has "type" element
     */
    boolean isSetType();
    
    /**
     * Sets the "type" element
     */
    void setType(com.bea.albpm.papiWebService.PresentationType.Enum type);
    
    /**
     * Sets (as xml) the "type" element
     */
    void xsetType(com.bea.albpm.papiWebService.PresentationType type);
    
    /**
     * Unsets the "type" element
     */
    void unsetType();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.PresentationBean newInstance() {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.PresentationBean parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.PresentationBean parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.PresentationBean parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.PresentationBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.PresentationBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.PresentationBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
