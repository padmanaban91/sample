/*
 * XML Type:  participantBean
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.ParticipantBean
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML participantBean(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface ParticipantBean extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ParticipantBean.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("participantbean46d0type");
    
    /**
     * Gets the "firstName" element
     */
    java.lang.String getFirstName();
    
    /**
     * Gets (as xml) the "firstName" element
     */
    org.apache.xmlbeans.XmlString xgetFirstName();
    
    /**
     * True if has "firstName" element
     */
    boolean isSetFirstName();
    
    /**
     * Sets the "firstName" element
     */
    void setFirstName(java.lang.String firstName);
    
    /**
     * Sets (as xml) the "firstName" element
     */
    void xsetFirstName(org.apache.xmlbeans.XmlString firstName);
    
    /**
     * Unsets the "firstName" element
     */
    void unsetFirstName();
    
    /**
     * Gets the "id" element
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "id" element
     */
    org.apache.xmlbeans.XmlString xgetId();
    
    /**
     * True if has "id" element
     */
    boolean isSetId();
    
    /**
     * Sets the "id" element
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "id" element
     */
    void xsetId(org.apache.xmlbeans.XmlString id);
    
    /**
     * Unsets the "id" element
     */
    void unsetId();
    
    /**
     * Gets the "lastName" element
     */
    java.lang.String getLastName();
    
    /**
     * Gets (as xml) the "lastName" element
     */
    org.apache.xmlbeans.XmlString xgetLastName();
    
    /**
     * True if has "lastName" element
     */
    boolean isSetLastName();
    
    /**
     * Sets the "lastName" element
     */
    void setLastName(java.lang.String lastName);
    
    /**
     * Sets (as xml) the "lastName" element
     */
    void xsetLastName(org.apache.xmlbeans.XmlString lastName);
    
    /**
     * Unsets the "lastName" element
     */
    void unsetLastName();
    
    /**
     * Gets the "mail" element
     */
    java.lang.String getMail();
    
    /**
     * Gets (as xml) the "mail" element
     */
    org.apache.xmlbeans.XmlString xgetMail();
    
    /**
     * True if has "mail" element
     */
    boolean isSetMail();
    
    /**
     * Sets the "mail" element
     */
    void setMail(java.lang.String mail);
    
    /**
     * Sets (as xml) the "mail" element
     */
    void xsetMail(org.apache.xmlbeans.XmlString mail);
    
    /**
     * Unsets the "mail" element
     */
    void unsetMail();
    
    /**
     * Gets the "name" element
     */
    java.lang.String getName();
    
    /**
     * Gets (as xml) the "name" element
     */
    org.apache.xmlbeans.XmlString xgetName();
    
    /**
     * True if has "name" element
     */
    boolean isSetName();
    
    /**
     * Sets the "name" element
     */
    void setName(java.lang.String name);
    
    /**
     * Sets (as xml) the "name" element
     */
    void xsetName(org.apache.xmlbeans.XmlString name);
    
    /**
     * Unsets the "name" element
     */
    void unsetName();
    
    /**
     * Gets the "organizationalUnit" element
     */
    java.lang.String getOrganizationalUnit();
    
    /**
     * Gets (as xml) the "organizationalUnit" element
     */
    org.apache.xmlbeans.XmlString xgetOrganizationalUnit();
    
    /**
     * True if has "organizationalUnit" element
     */
    boolean isSetOrganizationalUnit();
    
    /**
     * Sets the "organizationalUnit" element
     */
    void setOrganizationalUnit(java.lang.String organizationalUnit);
    
    /**
     * Sets (as xml) the "organizationalUnit" element
     */
    void xsetOrganizationalUnit(org.apache.xmlbeans.XmlString organizationalUnit);
    
    /**
     * Unsets the "organizationalUnit" element
     */
    void unsetOrganizationalUnit();
    
    /**
     * Gets array of all "organizationalUnits" elements
     */
    java.lang.String[] getOrganizationalUnitsArray();
    
    /**
     * Gets ith "organizationalUnits" element
     */
    java.lang.String getOrganizationalUnitsArray(int i);
    
    /**
     * Gets (as xml) array of all "organizationalUnits" elements
     */
    org.apache.xmlbeans.XmlString[] xgetOrganizationalUnitsArray();
    
    /**
     * Gets (as xml) ith "organizationalUnits" element
     */
    org.apache.xmlbeans.XmlString xgetOrganizationalUnitsArray(int i);
    
    /**
     * Tests for nil ith "organizationalUnits" element
     */
    boolean isNilOrganizationalUnitsArray(int i);
    
    /**
     * Returns number of "organizationalUnits" element
     */
    int sizeOfOrganizationalUnitsArray();
    
    /**
     * Sets array of all "organizationalUnits" element
     */
    void setOrganizationalUnitsArray(java.lang.String[] organizationalUnitsArray);
    
    /**
     * Sets ith "organizationalUnits" element
     */
    void setOrganizationalUnitsArray(int i, java.lang.String organizationalUnits);
    
    /**
     * Sets (as xml) array of all "organizationalUnits" element
     */
    void xsetOrganizationalUnitsArray(org.apache.xmlbeans.XmlString[] organizationalUnitsArray);
    
    /**
     * Sets (as xml) ith "organizationalUnits" element
     */
    void xsetOrganizationalUnitsArray(int i, org.apache.xmlbeans.XmlString organizationalUnits);
    
    /**
     * Nils the ith "organizationalUnits" element
     */
    void setNilOrganizationalUnitsArray(int i);
    
    /**
     * Inserts the value as the ith "organizationalUnits" element
     */
    void insertOrganizationalUnits(int i, java.lang.String organizationalUnits);
    
    /**
     * Appends the value as the last "organizationalUnits" element
     */
    void addOrganizationalUnits(java.lang.String organizationalUnits);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "organizationalUnits" element
     */
    org.apache.xmlbeans.XmlString insertNewOrganizationalUnits(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "organizationalUnits" element
     */
    org.apache.xmlbeans.XmlString addNewOrganizationalUnits();
    
    /**
     * Removes the ith "organizationalUnits" element
     */
    void removeOrganizationalUnits(int i);
    
    /**
     * Gets array of all "roles" elements
     */
    java.lang.String[] getRolesArray();
    
    /**
     * Gets ith "roles" element
     */
    java.lang.String getRolesArray(int i);
    
    /**
     * Gets (as xml) array of all "roles" elements
     */
    org.apache.xmlbeans.XmlString[] xgetRolesArray();
    
    /**
     * Gets (as xml) ith "roles" element
     */
    org.apache.xmlbeans.XmlString xgetRolesArray(int i);
    
    /**
     * Tests for nil ith "roles" element
     */
    boolean isNilRolesArray(int i);
    
    /**
     * Returns number of "roles" element
     */
    int sizeOfRolesArray();
    
    /**
     * Sets array of all "roles" element
     */
    void setRolesArray(java.lang.String[] rolesArray);
    
    /**
     * Sets ith "roles" element
     */
    void setRolesArray(int i, java.lang.String roles);
    
    /**
     * Sets (as xml) array of all "roles" element
     */
    void xsetRolesArray(org.apache.xmlbeans.XmlString[] rolesArray);
    
    /**
     * Sets (as xml) ith "roles" element
     */
    void xsetRolesArray(int i, org.apache.xmlbeans.XmlString roles);
    
    /**
     * Nils the ith "roles" element
     */
    void setNilRolesArray(int i);
    
    /**
     * Inserts the value as the ith "roles" element
     */
    void insertRoles(int i, java.lang.String roles);
    
    /**
     * Appends the value as the last "roles" element
     */
    void addRoles(java.lang.String roles);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "roles" element
     */
    org.apache.xmlbeans.XmlString insertNewRoles(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "roles" element
     */
    org.apache.xmlbeans.XmlString addNewRoles();
    
    /**
     * Removes the ith "roles" element
     */
    void removeRoles(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.ParticipantBean newInstance() {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.ParticipantBean parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.ParticipantBean parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.ParticipantBean parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ParticipantBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ParticipantBean parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ParticipantBean) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
