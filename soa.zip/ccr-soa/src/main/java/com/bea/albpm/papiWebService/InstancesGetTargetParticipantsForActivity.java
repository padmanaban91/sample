/*
 * XML Type:  instancesGetTargetParticipantsForActivity
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML instancesGetTargetParticipantsForActivity(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface InstancesGetTargetParticipantsForActivity extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(InstancesGetTargetParticipantsForActivity.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("instancesgettargetparticipantsforactivityb1dctype");
    
    /**
     * Gets the "instanceActivityPairs" element
     */
    com.bea.albpm.papiWebService.InstanceActivityPairSetBean getInstanceActivityPairs();
    
    /**
     * True if has "instanceActivityPairs" element
     */
    boolean isSetInstanceActivityPairs();
    
    /**
     * Sets the "instanceActivityPairs" element
     */
    void setInstanceActivityPairs(com.bea.albpm.papiWebService.InstanceActivityPairSetBean instanceActivityPairs);
    
    /**
     * Appends and returns a new empty "instanceActivityPairs" element
     */
    com.bea.albpm.papiWebService.InstanceActivityPairSetBean addNewInstanceActivityPairs();
    
    /**
     * Unsets the "instanceActivityPairs" element
     */
    void unsetInstanceActivityPairs();
    
    /**
     * Gets the "activityName" element
     */
    java.lang.String getActivityName();
    
    /**
     * Gets (as xml) the "activityName" element
     */
    org.apache.xmlbeans.XmlString xgetActivityName();
    
    /**
     * True if has "activityName" element
     */
    boolean isSetActivityName();
    
    /**
     * Sets the "activityName" element
     */
    void setActivityName(java.lang.String activityName);
    
    /**
     * Sets (as xml) the "activityName" element
     */
    void xsetActivityName(org.apache.xmlbeans.XmlString activityName);
    
    /**
     * Unsets the "activityName" element
     */
    void unsetActivityName();
    
    /**
     * Gets the "filter" element
     */
    java.lang.String getFilter();
    
    /**
     * Gets (as xml) the "filter" element
     */
    org.apache.xmlbeans.XmlString xgetFilter();
    
    /**
     * True if has "filter" element
     */
    boolean isSetFilter();
    
    /**
     * Sets the "filter" element
     */
    void setFilter(java.lang.String filter);
    
    /**
     * Sets (as xml) the "filter" element
     */
    void xsetFilter(org.apache.xmlbeans.XmlString filter);
    
    /**
     * Unsets the "filter" element
     */
    void unsetFilter();
    
    /**
     * Gets the "max" element
     */
    int getMax();
    
    /**
     * Gets (as xml) the "max" element
     */
    org.apache.xmlbeans.XmlInt xgetMax();
    
    /**
     * Sets the "max" element
     */
    void setMax(int max);
    
    /**
     * Sets (as xml) the "max" element
     */
    void xsetMax(org.apache.xmlbeans.XmlInt max);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity newInstance() {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.InstancesGetTargetParticipantsForActivity) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
