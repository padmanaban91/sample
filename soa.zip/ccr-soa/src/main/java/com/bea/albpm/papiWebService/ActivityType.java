/*
 * XML Type:  activityType
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.ActivityType
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML activityType(@http://bea.com/albpm/PapiWebService).
 *
 * This is an atomic type that is a restriction of com.bea.albpm.papiWebService.ActivityType.
 */
public interface ActivityType extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ActivityType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("activitytype6aa8type");
    
    org.apache.xmlbeans.StringEnumAbstractBase enumValue();
    void set(org.apache.xmlbeans.StringEnumAbstractBase e);
    
    static final Enum AUTOMATIC = Enum.forString("AUTOMATIC");
    static final Enum INTERACTIVE = Enum.forString("INTERACTIVE");
    static final Enum GLOBAL = Enum.forString("GLOBAL");
    static final Enum CREATION = Enum.forString("CREATION");
    static final Enum GRAB = Enum.forString("GRAB");
    static final Enum BEGIN = Enum.forString("BEGIN");
    static final Enum END = Enum.forString("END");
    static final Enum SPLIT = Enum.forString("SPLIT");
    static final Enum SPLIT_N = Enum.forString("SPLIT_N");
    static final Enum JOIN = Enum.forString("JOIN");
    static final Enum SUBPROCESS = Enum.forString("SUBPROCESS");
    static final Enum PROCESS_CREATION = Enum.forString("PROCESS_CREATION");
    static final Enum TERMINATION_WAIT = Enum.forString("TERMINATION_WAIT");
    static final Enum PROCESS_NOTIFICATION = Enum.forString("PROCESS_NOTIFICATION");
    static final Enum NOTIFICATION_WAIT = Enum.forString("NOTIFICATION_WAIT");
    static final Enum SUBFLOW = Enum.forString("SUBFLOW");
    static final Enum GROUP = Enum.forString("GROUP");
    static final Enum INTERACTIVE_COMPONENT_CALL = Enum.forString("INTERACTIVE_COMPONENT_CALL");
    static final Enum CONDITIONAL = Enum.forString("CONDITIONAL");
    static final Enum COMPENSATE = Enum.forString("COMPENSATE");
    static final Enum GLOBAL_AUTOMATIC = Enum.forString("GLOBAL_AUTOMATIC");
    static final Enum GLOBAL_CREATION = Enum.forString("GLOBAL_CREATION");
    static final Enum INTERACTIVE_GRAB = Enum.forString("INTERACTIVE_GRAB");
    static final Enum DECISION = Enum.forString("DECISION");
    static final Enum TIMER = Enum.forString("TIMER");
    static final Enum OR_SPLIT = Enum.forString("OR_SPLIT");
    static final Enum OR_JOIN = Enum.forString("OR_JOIN");
    
    static final int INT_AUTOMATIC = Enum.INT_AUTOMATIC;
    static final int INT_INTERACTIVE = Enum.INT_INTERACTIVE;
    static final int INT_GLOBAL = Enum.INT_GLOBAL;
    static final int INT_CREATION = Enum.INT_CREATION;
    static final int INT_GRAB = Enum.INT_GRAB;
    static final int INT_BEGIN = Enum.INT_BEGIN;
    static final int INT_END = Enum.INT_END;
    static final int INT_SPLIT = Enum.INT_SPLIT;
    static final int INT_SPLIT_N = Enum.INT_SPLIT_N;
    static final int INT_JOIN = Enum.INT_JOIN;
    static final int INT_SUBPROCESS = Enum.INT_SUBPROCESS;
    static final int INT_PROCESS_CREATION = Enum.INT_PROCESS_CREATION;
    static final int INT_TERMINATION_WAIT = Enum.INT_TERMINATION_WAIT;
    static final int INT_PROCESS_NOTIFICATION = Enum.INT_PROCESS_NOTIFICATION;
    static final int INT_NOTIFICATION_WAIT = Enum.INT_NOTIFICATION_WAIT;
    static final int INT_SUBFLOW = Enum.INT_SUBFLOW;
    static final int INT_GROUP = Enum.INT_GROUP;
    static final int INT_INTERACTIVE_COMPONENT_CALL = Enum.INT_INTERACTIVE_COMPONENT_CALL;
    static final int INT_CONDITIONAL = Enum.INT_CONDITIONAL;
    static final int INT_COMPENSATE = Enum.INT_COMPENSATE;
    static final int INT_GLOBAL_AUTOMATIC = Enum.INT_GLOBAL_AUTOMATIC;
    static final int INT_GLOBAL_CREATION = Enum.INT_GLOBAL_CREATION;
    static final int INT_INTERACTIVE_GRAB = Enum.INT_INTERACTIVE_GRAB;
    static final int INT_DECISION = Enum.INT_DECISION;
    static final int INT_TIMER = Enum.INT_TIMER;
    static final int INT_OR_SPLIT = Enum.INT_OR_SPLIT;
    static final int INT_OR_JOIN = Enum.INT_OR_JOIN;
    
    /**
     * Enumeration value class for com.bea.albpm.papiWebService.ActivityType.
     * These enum values can be used as follows:
     * <pre>
     * enum.toString(); // returns the string value of the enum
     * enum.intValue(); // returns an int value, useful for switches
     * // e.g., case Enum.INT_AUTOMATIC
     * Enum.forString(s); // returns the enum value for a string
     * Enum.forInt(i); // returns the enum value for an int
     * </pre>
     * Enumeration objects are immutable singleton objects that
     * can be compared using == object equality. They have no
     * public constructor. See the constants defined within this
     * class for all the valid values.
     */
    static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
    {
        /**
         * Returns the enum value for a string, or null if none.
         */
        public static Enum forString(java.lang.String s)
            { return (Enum)table.forString(s); }
        /**
         * Returns the enum value corresponding to an int, or null if none.
         */
        public static Enum forInt(int i)
            { return (Enum)table.forInt(i); }
        
        private Enum(java.lang.String s, int i)
            { super(s, i); }
        
        static final int INT_AUTOMATIC = 1;
        static final int INT_INTERACTIVE = 2;
        static final int INT_GLOBAL = 3;
        static final int INT_CREATION = 4;
        static final int INT_GRAB = 5;
        static final int INT_BEGIN = 6;
        static final int INT_END = 7;
        static final int INT_SPLIT = 8;
        static final int INT_SPLIT_N = 9;
        static final int INT_JOIN = 10;
        static final int INT_SUBPROCESS = 11;
        static final int INT_PROCESS_CREATION = 12;
        static final int INT_TERMINATION_WAIT = 13;
        static final int INT_PROCESS_NOTIFICATION = 14;
        static final int INT_NOTIFICATION_WAIT = 15;
        static final int INT_SUBFLOW = 16;
        static final int INT_GROUP = 17;
        static final int INT_INTERACTIVE_COMPONENT_CALL = 18;
        static final int INT_CONDITIONAL = 19;
        static final int INT_COMPENSATE = 20;
        static final int INT_GLOBAL_AUTOMATIC = 21;
        static final int INT_GLOBAL_CREATION = 22;
        static final int INT_INTERACTIVE_GRAB = 23;
        static final int INT_DECISION = 24;
        static final int INT_TIMER = 25;
        static final int INT_OR_SPLIT = 26;
        static final int INT_OR_JOIN = 27;
        
        public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
            new org.apache.xmlbeans.StringEnumAbstractBase.Table
        (
            new Enum[]
            {
                new Enum("AUTOMATIC", INT_AUTOMATIC),
                new Enum("INTERACTIVE", INT_INTERACTIVE),
                new Enum("GLOBAL", INT_GLOBAL),
                new Enum("CREATION", INT_CREATION),
                new Enum("GRAB", INT_GRAB),
                new Enum("BEGIN", INT_BEGIN),
                new Enum("END", INT_END),
                new Enum("SPLIT", INT_SPLIT),
                new Enum("SPLIT_N", INT_SPLIT_N),
                new Enum("JOIN", INT_JOIN),
                new Enum("SUBPROCESS", INT_SUBPROCESS),
                new Enum("PROCESS_CREATION", INT_PROCESS_CREATION),
                new Enum("TERMINATION_WAIT", INT_TERMINATION_WAIT),
                new Enum("PROCESS_NOTIFICATION", INT_PROCESS_NOTIFICATION),
                new Enum("NOTIFICATION_WAIT", INT_NOTIFICATION_WAIT),
                new Enum("SUBFLOW", INT_SUBFLOW),
                new Enum("GROUP", INT_GROUP),
                new Enum("INTERACTIVE_COMPONENT_CALL", INT_INTERACTIVE_COMPONENT_CALL),
                new Enum("CONDITIONAL", INT_CONDITIONAL),
                new Enum("COMPENSATE", INT_COMPENSATE),
                new Enum("GLOBAL_AUTOMATIC", INT_GLOBAL_AUTOMATIC),
                new Enum("GLOBAL_CREATION", INT_GLOBAL_CREATION),
                new Enum("INTERACTIVE_GRAB", INT_INTERACTIVE_GRAB),
                new Enum("DECISION", INT_DECISION),
                new Enum("TIMER", INT_TIMER),
                new Enum("OR_SPLIT", INT_OR_SPLIT),
                new Enum("OR_JOIN", INT_OR_JOIN),
            }
        );
        private static final long serialVersionUID = 1L;
        private java.lang.Object readResolve() { return forInt(intValue()); } 
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.ActivityType newValue(java.lang.Object obj) {
          return (com.bea.albpm.papiWebService.ActivityType) type.newValue( obj ); }
        
        public static com.bea.albpm.papiWebService.ActivityType newInstance() {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.ActivityType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.ActivityType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.ActivityType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ActivityType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ActivityType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ActivityType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
