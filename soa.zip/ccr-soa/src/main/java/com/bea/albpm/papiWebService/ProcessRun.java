/*
 * XML Type:  processRun
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.ProcessRun
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML processRun(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface ProcessRun extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ProcessRun.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("processrun561btype");
    
    /**
     * Gets the "targetProcessId" element
     */
    java.lang.String getTargetProcessId();
    
    /**
     * Gets (as xml) the "targetProcessId" element
     */
    org.apache.xmlbeans.XmlString xgetTargetProcessId();
    
    /**
     * True if has "targetProcessId" element
     */
    boolean isSetTargetProcessId();
    
    /**
     * Sets the "targetProcessId" element
     */
    void setTargetProcessId(java.lang.String targetProcessId);
    
    /**
     * Sets (as xml) the "targetProcessId" element
     */
    void xsetTargetProcessId(org.apache.xmlbeans.XmlString targetProcessId);
    
    /**
     * Unsets the "targetProcessId" element
     */
    void unsetTargetProcessId();
    
    /**
     * Gets the "argumentsSetName" element
     */
    java.lang.String getArgumentsSetName();
    
    /**
     * Gets (as xml) the "argumentsSetName" element
     */
    org.apache.xmlbeans.XmlString xgetArgumentsSetName();
    
    /**
     * True if has "argumentsSetName" element
     */
    boolean isSetArgumentsSetName();
    
    /**
     * Sets the "argumentsSetName" element
     */
    void setArgumentsSetName(java.lang.String argumentsSetName);
    
    /**
     * Sets (as xml) the "argumentsSetName" element
     */
    void xsetArgumentsSetName(org.apache.xmlbeans.XmlString argumentsSetName);
    
    /**
     * Unsets the "argumentsSetName" element
     */
    void unsetArgumentsSetName();
    
    /**
     * Gets the "arguments" element
     */
    com.bea.albpm.papiWebService.ArgumentsBean getArguments();
    
    /**
     * True if has "arguments" element
     */
    boolean isSetArguments();
    
    /**
     * Sets the "arguments" element
     */
    void setArguments(com.bea.albpm.papiWebService.ArgumentsBean arguments);
    
    /**
     * Appends and returns a new empty "arguments" element
     */
    com.bea.albpm.papiWebService.ArgumentsBean addNewArguments();
    
    /**
     * Unsets the "arguments" element
     */
    void unsetArguments();
    
    /**
     * Gets the "timeout" element
     */
    long getTimeout();
    
    /**
     * Gets (as xml) the "timeout" element
     */
    org.apache.xmlbeans.XmlLong xgetTimeout();
    
    /**
     * Sets the "timeout" element
     */
    void setTimeout(long timeout);
    
    /**
     * Sets (as xml) the "timeout" element
     */
    void xsetTimeout(org.apache.xmlbeans.XmlLong timeout);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.ProcessRun newInstance() {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.ProcessRun parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.ProcessRun parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessRun parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ProcessRun parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ProcessRun parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ProcessRun) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
