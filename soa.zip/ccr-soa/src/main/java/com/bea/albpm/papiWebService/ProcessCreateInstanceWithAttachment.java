/*
 * XML Type:  processCreateInstanceWithAttachment
 * Namespace: http://bea.com/albpm/PapiWebService
 * Java type: com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment
 *
 * Automatically generated - do not modify.
 */
package com.bea.albpm.papiWebService;


/**
 * An XML processCreateInstanceWithAttachment(@http://bea.com/albpm/PapiWebService).
 *
 * This is a complex type.
 */
public interface ProcessCreateInstanceWithAttachment extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ProcessCreateInstanceWithAttachment.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFD2C49C163F1AC2B2860CD7300CC0D33").resolveHandle("processcreateinstancewithattachment3176type");
    
    /**
     * Gets the "targetProcessId" element
     */
    java.lang.String getTargetProcessId();
    
    /**
     * Gets (as xml) the "targetProcessId" element
     */
    org.apache.xmlbeans.XmlString xgetTargetProcessId();
    
    /**
     * True if has "targetProcessId" element
     */
    boolean isSetTargetProcessId();
    
    /**
     * Sets the "targetProcessId" element
     */
    void setTargetProcessId(java.lang.String targetProcessId);
    
    /**
     * Sets (as xml) the "targetProcessId" element
     */
    void xsetTargetProcessId(org.apache.xmlbeans.XmlString targetProcessId);
    
    /**
     * Unsets the "targetProcessId" element
     */
    void unsetTargetProcessId();
    
    /**
     * Gets the "argumentsSetName" element
     */
    java.lang.String getArgumentsSetName();
    
    /**
     * Gets (as xml) the "argumentsSetName" element
     */
    org.apache.xmlbeans.XmlString xgetArgumentsSetName();
    
    /**
     * True if has "argumentsSetName" element
     */
    boolean isSetArgumentsSetName();
    
    /**
     * Sets the "argumentsSetName" element
     */
    void setArgumentsSetName(java.lang.String argumentsSetName);
    
    /**
     * Sets (as xml) the "argumentsSetName" element
     */
    void xsetArgumentsSetName(org.apache.xmlbeans.XmlString argumentsSetName);
    
    /**
     * Unsets the "argumentsSetName" element
     */
    void unsetArgumentsSetName();
    
    /**
     * Gets the "arguments" element
     */
    com.bea.albpm.papiWebService.ArgumentsBean getArguments();
    
    /**
     * True if has "arguments" element
     */
    boolean isSetArguments();
    
    /**
     * Sets the "arguments" element
     */
    void setArguments(com.bea.albpm.papiWebService.ArgumentsBean arguments);
    
    /**
     * Appends and returns a new empty "arguments" element
     */
    com.bea.albpm.papiWebService.ArgumentsBean addNewArguments();
    
    /**
     * Unsets the "arguments" element
     */
    void unsetArguments();
    
    /**
     * Gets the "name" element
     */
    java.lang.String getName();
    
    /**
     * Gets (as xml) the "name" element
     */
    org.apache.xmlbeans.XmlString xgetName();
    
    /**
     * True if has "name" element
     */
    boolean isSetName();
    
    /**
     * Sets the "name" element
     */
    void setName(java.lang.String name);
    
    /**
     * Sets (as xml) the "name" element
     */
    void xsetName(org.apache.xmlbeans.XmlString name);
    
    /**
     * Unsets the "name" element
     */
    void unsetName();
    
    /**
     * Gets the "description" element
     */
    java.lang.String getDescription();
    
    /**
     * Gets (as xml) the "description" element
     */
    org.apache.xmlbeans.XmlString xgetDescription();
    
    /**
     * True if has "description" element
     */
    boolean isSetDescription();
    
    /**
     * Sets the "description" element
     */
    void setDescription(java.lang.String description);
    
    /**
     * Sets (as xml) the "description" element
     */
    void xsetDescription(org.apache.xmlbeans.XmlString description);
    
    /**
     * Unsets the "description" element
     */
    void unsetDescription();
    
    /**
     * Gets the "remarks" element
     */
    java.lang.String getRemarks();
    
    /**
     * Gets (as xml) the "remarks" element
     */
    org.apache.xmlbeans.XmlString xgetRemarks();
    
    /**
     * True if has "remarks" element
     */
    boolean isSetRemarks();
    
    /**
     * Sets the "remarks" element
     */
    void setRemarks(java.lang.String remarks);
    
    /**
     * Sets (as xml) the "remarks" element
     */
    void xsetRemarks(org.apache.xmlbeans.XmlString remarks);
    
    /**
     * Unsets the "remarks" element
     */
    void unsetRemarks();
    
    /**
     * Gets the "content" element
     */
    byte[] getContent();
    
    /**
     * Gets (as xml) the "content" element
     */
    org.apache.xmlbeans.XmlBase64Binary xgetContent();
    
    /**
     * True if has "content" element
     */
    boolean isSetContent();
    
    /**
     * Sets the "content" element
     */
    void setContent(byte[] content);
    
    /**
     * Sets (as xml) the "content" element
     */
    void xsetContent(org.apache.xmlbeans.XmlBase64Binary content);
    
    /**
     * Unsets the "content" element
     */
    void unsetContent();
    
    /**
     * Gets the "contentType" element
     */
    java.lang.String getContentType();
    
    /**
     * Gets (as xml) the "contentType" element
     */
    org.apache.xmlbeans.XmlString xgetContentType();
    
    /**
     * True if has "contentType" element
     */
    boolean isSetContentType();
    
    /**
     * Sets the "contentType" element
     */
    void setContentType(java.lang.String contentType);
    
    /**
     * Sets (as xml) the "contentType" element
     */
    void xsetContentType(org.apache.xmlbeans.XmlString contentType);
    
    /**
     * Unsets the "contentType" element
     */
    void unsetContentType();
    
    /**
     * Gets the "locale" element
     */
    com.bea.albpm.papiWebService.LocaleBean getLocale();
    
    /**
     * True if has "locale" element
     */
    boolean isSetLocale();
    
    /**
     * Sets the "locale" element
     */
    void setLocale(com.bea.albpm.papiWebService.LocaleBean locale);
    
    /**
     * Appends and returns a new empty "locale" element
     */
    com.bea.albpm.papiWebService.LocaleBean addNewLocale();
    
    /**
     * Unsets the "locale" element
     */
    void unsetLocale();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment newInstance() {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (com.bea.albpm.papiWebService.ProcessCreateInstanceWithAttachment) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
