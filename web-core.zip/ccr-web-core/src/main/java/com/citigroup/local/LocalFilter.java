package com.citigroup.local;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.citigroup.local.CustomHeadersRequest;
 
/**
 * A simple filter used to create an additional header.
 * 
 *
 */
public class LocalFilter implements Filter {
 
    public void destroy() {
                 
    }
 
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
            FilterChain filterChain) throws IOException, ServletException {
        //if the ServletRequest is an instance of HttpServletRequest
        if(servletRequest instanceof HttpServletRequest) {
            //cast the object
            HttpServletRequest httpServletRequest = (HttpServletRequest)servletRequest;
            //create the FakeHeadersRequest object to wrap the HttpServletRequest
            CustomHeadersRequest request = new CustomHeadersRequest(httpServletRequest);
            //continue on in the filter chain with the FakeHeaderRequest and ServletResponse objects
            filterChain.doFilter(request, servletResponse);
        } else {
            //otherwise, continue on in the chain with the ServletRequest and ServletResponse objects
            filterChain.doFilter(servletRequest, servletResponse);
        }       
         
        return;
    }
 
    public void init(FilterConfig filterConfig) throws ServletException {
         
    }
 
}