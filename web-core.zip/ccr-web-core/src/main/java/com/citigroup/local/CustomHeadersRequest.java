package com.citigroup.local;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
 
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
 
/**
 * Fake headers request object. Adds a request header
 * with the name "username". The value of this request header
 * will be taken from a cookie (also with the name, "username").
 * 
 * @author Jee Vang
 *
 */
public class CustomHeadersRequest extends HttpServletRequestWrapper {
 
    /**
     * Constructor. 
     * 
     * @param request HttpServletRequest.
     */
    public CustomHeadersRequest(HttpServletRequest request) {
        super(request);
    }
     
    public String getHeader(String name) {
        //get the request object and cast it
        HttpServletRequest request = (HttpServletRequest)getRequest();
         
        //if we are looking for the "username" request header
        if("SM_USER".equals(name)) {
            //loop through the cookies
            Cookie[] cookies = request.getCookies();
             
            //if cookies are null, then return null
            if(null == cookies) {
                return null;
            }
             
            for(int i=0; i < cookies.length; i++) {
                //if the cookie's name is "username"
                if("SM_USER".equals(cookies[i].getName())) {
                    //get its value and return it
                    String val = cookies[i].getValue();
                    return val;
                }
            }
        }
         
        //otherwise fall through to wrapped request object
        return request.getHeader(name);
    }
     
    public Enumeration getHeaderNames() {
        //create an enumeration of the request headers
        //additionally, add the "username" request header
         
        //create a list
        List list = new ArrayList();
         
        //loop over request headers from wrapped request object
        HttpServletRequest request = (HttpServletRequest)getRequest();
        Enumeration e = request.getHeaderNames();
        while(e.hasMoreElements()) {
            //add the names of the request headers into the list
            String n = (String)e.nextElement();
            list.add(n);
        }
         
        //additionally, add the "username" to the list of request header names
        list.add("SM_USER");
         
        //create an enumeration from the list and return
        Enumeration en = Collections.enumeration(list);
        return en;
    }
 
}