package com.citigroup.ets.ccr.login.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.citigroup.ets.ccr.CCR_Constants;
import com.citigroup.ets.ccr.login.service.CitiUserService;
import com.citigroup.ets.ccr.login.service.Menu;

/**
 * @author cx80758 This class authorize user based on their Entitlements
 *
 */
@Controller
public class UserEntitlementsController {

	private static Logger log = Logger.getLogger(UserEntitlementsController.class);

	@Autowired
	CitiUserService citiUserService;
	/**
	 * @param request
	 *            This method authorize the Citi User details to check admin or
	 *            guest
	 * @return forward
	 */
	@RequestMapping(value = "/logon.act")
	public String logon(HttpServletRequest request) {

		log.info("LoginController starts here..");
		Menu menu = new Menu();
		HttpSession session = request.getSession();
		String Username = request.getHeader("SM_USER");
		menu = populateMenuAttributes(session, request, menu);
		String forward = menu.getForward();
		String bpmForward = menu.getBpmForward();

		if (menu.getUserInfo() != null && !"".equals(menu.getUserInfo())) {
			forward = citiUserService.getForwardToBpm(menu);
		}

		else {
			// Admin login here
			System.out.println("*******Inside Admin Else part:"+menu.getC3parUser());
			if (menu.getC3parUser() != null || "Y".equalsIgnoreCase(menu.getC3parUser().getActive())) {
				forward = citiUserService.getUserEntitlements(menu);

				log.debug("Admin login starts here..forward " + forward);
				// set isAdmin boolean object in session attribute for admin
				// user
				session.setAttribute(CCR_Constants.IS_ADMIN, menu.getIsAdmin());
				// set user roles in session attribute for admin user
				session.setAttribute(CCR_Constants.ROLE, menu.getSessionRole());
				// set isAdminReadOnly boolean object in session attribute for
				// admin
				// user
				session.setAttribute(CCR_Constants.READ_ONLY, menu.getIsAdminReadOnly());
				// set userName String object in session attribute for admin
				// user
				session.setAttribute(CCR_Constants.USER_NAME,
						menu.getC3parUser().getLastName() + ", " + menu.getC3parUser().getFirstName());

				if (menu.getIsBpm()) {
					if (session != null && session.getAttribute("called_function") != null) {
						session.removeAttribute("called_function");
					}
				}
			} else
			// Guest User login here
			{
				log.debug("Guest User coming here for entitlements (manager review or request/update entitlements)");
				Set<String> guestRole = new HashSet<String>();
				guestRole.add(CCR_Constants.GUEST_ROLE);
				List<String> roleList = new ArrayList<String>();
				roleList.add(CCR_Constants.GUEST_ROLE);
				// set isAdmin boolean object in session attribute for guest
				// user
				session.setAttribute(CCR_Constants.IS_ADMIN, Boolean.FALSE);
				// set user roles in session attribute for guest user
				session.setAttribute(CCR_Constants.ROLE, guestRole);
				// set isAdminReadOnly boolean object in session attribute for
				// guest
				// user
				session.setAttribute(CCR_Constants.READ_ONLY, Boolean.FALSE);
				// set userName String object in session attribute for guest
				// user
				session.setAttribute(CCR_Constants.USER_NAME, "Guest: " + Username);

				if (bpmForward != null && !"".equals(bpmForward)) {
					forward = CCR_Constants.BPM_FORWARD;
				}
			}
			session.setAttribute("LOADED_USER_INFO", CCR_Constants.LOADED_USER_INFO);
		}
		return forward;
	}

	/**
	 * This method Create menu object and set attributes from session or request
	 * scope
	 * 
	 * @param session
	 * @param request
	 * @return menu
	 */
	private Menu populateMenuAttributes(HttpSession session, HttpServletRequest request, Menu menu) {

		String userInfo = (String) session.getAttribute(CCR_Constants.LOADED_USER_INFO);
		String smUser = request.getHeader("SM_USER").toLowerCase();
		String smUserHeader = request.getHeader("SM_USER");
		String bpmForward = request.getParameter(CCR_Constants.FORWARD);
		String forward = CCR_Constants.DEACTIVATED_USER_MESSAGE_PATH;
		String forward_To = request.getParameter(CCR_Constants.FORWARD_TO);
		String forward_To_Bc = (String) session.getAttribute(CCR_Constants.FORWARD_TO_BC);
		menu.setSmUser(smUser);
		menu.setUserInfo(userInfo);
		menu.setSmUserHeader(smUserHeader);
		menu.setC3parUser(citiUserService.getC3parUser(menu.getSmUser()));
		menu.setBpmForward(bpmForward);

		menu.setForward_To(forward_To);
		menu.setForward_To_Bc(forward_To_Bc);
		menu.setForward(forward);
		return menu;

	}
}
