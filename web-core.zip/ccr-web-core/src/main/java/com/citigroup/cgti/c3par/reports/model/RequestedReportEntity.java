/*
 * Created on Jun 5, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.reports.model;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;





/**
 * The Class RequestedReportEntity.
 *
 * @author MphasiS
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RequestedReportEntity implements Serializable {

    /** The column list. */
    private List columnList = new ArrayList(0);

    /** The sort order. */
    private List sortOrder = new ArrayList(0);

    /** The group by. */
    private List groupBy;

    /** The inputs. */
    private Map inputs = new HashMap(0);

    /** The next data. */
    private boolean nextData;

    /** The table name. */
    private String tableName;

    /** The current page. */
    private long currentPage;

    /** The batch size. */
    private int batchSize = 50;

    /** The source data. */
    private String sourceData;

    /** The jndi name. */
    private String jndiName;

    /** The ds entity. */
    private DataSourceEntity dsEntity;

    /** The report filter entity. */
    private ReportFilterEntity reportFilterEntity;

    /** The Report inner filter entity. */
    private ReportInnerFilterEntity ReportInnerFilterEntity;

    /** The report index. */
    private Map reportIndex = new HashMap();

    /** The filter string. */
    private String filterString;

    /** The total pages. */
    private long totalPages;

    /** The descending order. */
    private boolean descendingOrder = false ;

    /** The suppress duplicate data. */
    private boolean suppressDuplicateData = true ;

    /** The suppress column list. */
    private List suppressColumnList = new ArrayList(0);

    /** The link column list. */
    private Map linkColumnList = new HashMap();

    /** The url. */
    private String url;

    /** The lookup column list. */
    private List lookupColumnList = new ArrayList(0);

    /** The report meta entity. */
    private ReportMetaEntity reportMetaEntity;

    /** The driver collection filter. */
    private String driverCollectionFilter;

    /** The collection driver table name. */
    private String collectionDriverTableName;

    /** The driver ds entity. */
    private DataSourceEntity driverDsEntity;





    /**
     * Gets the driver ds entity.
     *
     * @return Returns the driverDsEntity.
     */
    public DataSourceEntity getDriverDsEntity() {
	return driverDsEntity;
    }

    /**
     * Sets the driver ds entity.
     *
     * @param driverDsEntity The driverDsEntity to set.
     */
    public void setDriverDsEntity(DataSourceEntity driverDsEntity) {
	this.driverDsEntity = driverDsEntity;
    }

    /**
     * Gets the collection driver table name.
     *
     * @return Returns the collectionDriverTableName.
     */
    public String getCollectionDriverTableName() {
	return collectionDriverTableName;
    }

    /**
     * Sets the collection driver table name.
     *
     * @param collectionDriverTableName The collectionDriverTableName to set.
     */
    public void setCollectionDriverTableName(String collectionDriverTableName) {
	this.collectionDriverTableName = collectionDriverTableName;
    }

    /**
     * Gets the driver collection filter.
     *
     * @return Returns the collectionFilter.
     */
    public String getDriverCollectionFilter() {
	return driverCollectionFilter;
    }

    /**
     * Sets the driver collection filter.
     *
     * @param collectionFilter The collectionFilter to set.
     */
    public void setDriverCollectionFilter(String collectionFilter) {
	this.driverCollectionFilter = collectionFilter;
    }

    /**
     * Gets the report meta entity.
     *
     * @return Returns the reportMetaEntity.
     */
    public ReportMetaEntity getReportMetaEntity() {
	return reportMetaEntity;
    }

    /**
     * Sets the report meta entity.
     *
     * @param reportMetaEntity The reportMetaEntity to set.
     */
    public void setReportMetaEntity(ReportMetaEntity reportMetaEntity) {
	this.reportMetaEntity = reportMetaEntity;
    }

    /**
     * Gets the lookup column list.
     *
     * @return Returns the lookupColumnList.
     */
    public List getLookupColumnList() {
	return lookupColumnList;
    }

    /**
     * Sets the lookup column list.
     *
     * @param lookupColumnList The lookupColumnList to set.
     */
    public void setLookupColumnList(List lookupColumnList) {
	this.lookupColumnList = lookupColumnList;
    }

    /**
     * Gets the url.
     *
     * @return the url
     */
    public String getUrl() {
	return url;
    }

    /**
     * Sets the url.
     *
     * @param url the new url
     */
    public void setUrl(String url) {
	this.url = url;
    }

    /**
     * Gets the link column list.
     *
     * @return the link column list
     */
    public Map getLinkColumnList() {
	return linkColumnList;
    }

    /**
     * Sets the link column list.
     *
     * @param linkColumnList the new link column list
     */
    public void setLinkColumnList(Map linkColumnList) {
	this.linkColumnList = linkColumnList;
    }


    /**
     * Gets the suppress column list.
     *
     * @return the suppress column list
     */
    public List getSuppressColumnList() {
	return suppressColumnList;
    }

    /**
     * Sets the suppress column list.
     *
     * @param suppressColumnList the new suppress column list
     */
    public void setSuppressColumnList(List suppressColumnList) {
	this.suppressColumnList = suppressColumnList;
    }


    /**
     * Checks if is suppress duplicate data.
     *
     * @return true, if is suppress duplicate data
     */
    public boolean isSuppressDuplicateData() {
	return suppressDuplicateData;
    }

    /**
     * Sets the suppress duplicate data.
     *
     * @param suppressDuplicateData the new suppress duplicate data
     */
    public void setSuppressDuplicateData(boolean suppressDuplicateData) {

	this.suppressDuplicateData = suppressDuplicateData;
    }

    /**
     * Checks if is descending order.
     *
     * @return true, if is descending order
     */
    public boolean isDescendingOrder() {
	return descendingOrder;
    }

    /**
     * Sets the descending order.
     *
     * @param descendingOrder the new descending order
     */
    public void setDescendingOrder(boolean descendingOrder) {

	this.descendingOrder = descendingOrder;
    }

    /**
     * Gets the filter string.
     *
     * @return Returns the filterString.
     */
    public String getFilterString() {
	return filterString;
    }

    /**
     * Sets the filter string.
     *
     * @param filterString The filterString to set.
     */
    public void setFilterString(String filterString) {
	this.filterString = filterString;
    }

    /**
     * Gets the report index.
     *
     * @return Returns the reportIndex.
     */
    public Map getReportIndex() {
	return reportIndex;
    }

    /**
     * Sets the report index.
     *
     * @param reportIndex The reportIndex to set.
     */
    public void setReportIndex(Map reportIndex) {
	this.reportIndex = reportIndex;
    }

    /**
     * Gets the group by.
     *
     * @return Returns the groupBy.
     */
    public List getGroupBy() {
	return groupBy;
    }

    /**
     * Sets the group by.
     *
     * @param groupBy The groupBy to set.
     */
    public void setGroupBy(List groupBy) {
	this.groupBy = groupBy;
    }

    /**
     * Gets the report inner filter entity.
     *
     * @return Returns the reportInnerFilterEntity.
     */
    public ReportInnerFilterEntity getReportInnerFilterEntity() {
	return ReportInnerFilterEntity;
    }

    /**
     * Sets the report inner filter entity.
     *
     * @param reportInnerFilterEntity The reportInnerFilterEntity to set.
     */
    public void setReportInnerFilterEntity(
	    ReportInnerFilterEntity reportInnerFilterEntity) {
	ReportInnerFilterEntity = reportInnerFilterEntity;
    }

    /**
     * Gets the report filter entity.
     *
     * @return Returns the reportFilter.
     */
    public ReportFilterEntity getReportFilterEntity() {
	return reportFilterEntity;
    }

    /**
     * Sets the report filter entity.
     *
     * @param reportFilterEntity the new report filter entity
     */
    public void setReportFilterEntity(ReportFilterEntity reportFilterEntity) {
	this.reportFilterEntity = reportFilterEntity;
    }

    /**
     * Gets the report inner filter.
     *
     * @return Returns the reportInnerFilter.
     */
    public ReportInnerFilterEntity getReportInnerFilter() {
	return ReportInnerFilterEntity;
    }

    /**
     * Sets the report inner filter.
     *
     * @param reportInnerFilterEntity the new report inner filter
     */
    public void setReportInnerFilter(ReportInnerFilterEntity reportInnerFilterEntity) {
	ReportInnerFilterEntity = reportInnerFilterEntity;
    }

    /**
     * Gets the ds entity.
     *
     * @return Returns the dsEntity.
     */
    public DataSourceEntity getDsEntity() {
	return dsEntity;
    }

    /**
     * Sets the ds entity.
     *
     * @param dsEntity The dsEntity to set.
     */
    public void setDsEntity(DataSourceEntity dsEntity) {
	this.dsEntity = dsEntity;
    }

    /**
     * Gets the jndi name.
     *
     * @return Returns the jndiName.
     */
    public String getJndiName() {
	return jndiName;
    }

    /**
     * Sets the jndi name.
     *
     * @param jndiName The jndiName to set.
     */
    public void setJndiName(String jndiName) {
	this.jndiName = jndiName;
    }

    /**
     * Gets the source data.
     *
     * @return Returns the sourceData.
     */
    public String getSourceData() {
	return sourceData;
    }

    /**
     * Sets the source data.
     *
     * @param sourceData The sourceData to set.
     */
    public void setSourceData(String sourceData) {
	this.sourceData = sourceData;
    }

    /**
     * Gets the batch size.
     *
     * @return Returns the batchSize.
     */
    public int getBatchSize() {
	return batchSize;
    }

    /**
     * Sets the batch size.
     *
     * @param batchSize The batchSize to set.
     */
    public void setBatchSize(int batchSize) {
	this.batchSize = batchSize;
    }

    /**
     * Gets the column list.
     *
     * @return Returns the columnList.
     */
    public List getColumnList() {
	return columnList;
    }

    /**
     * Sets the column list.
     *
     * @param columnList The columnList to set.
     */
    public void setColumnList(List columnList) {
	this.columnList = columnList;
    }

    /**
     * Gets the current page.
     *
     * @return Returns the currentPage.
     */
    public long getCurrentPage() {
	return currentPage;
    }

    /**
     * Sets the current page.
     *
     * @param currentPage The currentPage to set.
     */
    public void setCurrentPage(long currentPage) {
	this.currentPage = currentPage;
    }

    /**
     * Gets the inputs.
     *
     * @return Returns the inputs.
     */
    public Map getInputs() {
	return inputs;
    }

    /**
     * Sets the inputs.
     *
     * @param inputs The inputs to set.
     */
    public void setInputs(Map inputs) {
	this.inputs = inputs;
    }

    /**
     * Checks if is next data.
     *
     * @return Returns the nextData.
     */
    public boolean isNextData() {
	return nextData;
    }

    /**
     * Sets the next data.
     *
     * @param nextData The nextData to set.
     */
    public void setNextData(boolean nextData) {
	this.nextData = nextData;
    }

    /**
     * Gets the sort order.
     *
     * @return Returns the sortOrder.
     */
    public List getSortOrder() {
	return sortOrder;
    }

    /**
     * Sets the sort order.
     *
     * @param sortOrder The sortOrder to set.
     */
    public void setSortOrder(List sortOrder) {
	this.sortOrder = sortOrder;
    }

    /**
     * Gets the table name.
     *
     * @return Returns the tableName.
     */
    public String getTableName() {
	return tableName;
    }

    /**
     * Sets the table name.
     *
     * @param tableName The tableName to set.
     */
    public void setTableName(String tableName) {
	this.tableName = tableName;
    }

    /**
     * Gets the total pages.
     *
     * @return Returns the totalPages.
     */
    public long getTotalPages() {
	return totalPages;
    }

    /**
     * Sets the total pages.
     *
     * @param totalPages The totalPages to set.
     */
    public void setTotalPages(long totalPages) {
	this.totalPages = totalPages;
    }
}
