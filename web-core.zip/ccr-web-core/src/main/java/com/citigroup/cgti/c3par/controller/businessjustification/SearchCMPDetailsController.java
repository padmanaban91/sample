package com.citigroup.cgti.c3par.controller.businessjustification;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.fw.domain.ResolveITNotifyLog;

@Controller
public class SearchCMPDetailsController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@RequestMapping(value = "/getCmpIdList.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String getCmpIdList(HttpServletRequest request, @ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess, ModelMap model){
		String action = request.getParameter("action");
        log.info("SearchCMPDetailsController :: getCmpIdList :: starts "+action);

		busjusProcess = new BusinessJustificationProcess();	
		
		if(action != null && action.equalsIgnoreCase("search")){
			String cmpID = request.getParameter("cmpID");
			List<ResolveITNotifyLog> list = null;
	
			try {
				if (cmpID != null && cmpID.length() != 0) {
					list = busjusProcess.getResolveITNotifyLogList(cmpID.toUpperCase().trim());
				} else {
					list = busjusProcess.getResolveITNotifyLogList();
				}
	
				if (list != null ) {		
					busjusProcess.setResolveITNotifyLogLst(list);					
				} else {				
					request.setAttribute("resolveITNotifyLogList_ErrMsg", "No Records Found");
				}
			}
			catch(Exception e){
				log.error(e,e); 
				//addActionError(e.toString());
			}
		}
		model.addAttribute("busjusProcess",busjusProcess);
		return "pages/businessjustification/SearchCMPDetails";
	}

	@RequestMapping(value = "/selectCmpId.act", method = { RequestMethod.GET, RequestMethod.POST})
	 public String selectCmpId(HttpServletRequest request,ModelMap model){
		 try{
	        String cmpID = request.getParameter("selectedCmpId");
	        request.getSession().removeAttribute("CMP_ID");
	        log.debug("SearchCMPDetailsController :: selectCmpId :: selectedCMPId - "+cmpID);
	        request.getSession().setAttribute("CMP_ID", cmpID);	    
		 }
		 catch(Exception e){
			log.error(e,e); 
			//addActionError(e.toString());
		 }
	    
		 return "pages/common/SearchPopupCloser";
	 }

	@RequestMapping(value = "/showCmpIdDetails.act", method = { RequestMethod.GET, RequestMethod.POST})
	 public String showCmpIdDetails(HttpServletRequest request,ModelMap model){
		 log.info("SearchCMPDetailsController :: showCmpIdDetails :: methods starts here....");
		
		 List<ResolveITNotifyLog> list = new ArrayList<ResolveITNotifyLog>();
		
		 String cmpID = request.getParameter("cmpID");
		 cmpID=cmpID.replace(",","','");

			BusinessJustificationProcess busjusProcess = new BusinessJustificationProcess();	
			//Retrieving CMP ID
			try {
				if (cmpID != null && cmpID.length() != 0) {
					list = busjusProcess.getCMPDetails("'"+cmpID.toUpperCase().trim()+"'");
					log.debug("SearchCMPDetailsController :: showCmpIdDetails :: list"+list);
				} 

				if (list != null ) {				
					busjusProcess.setResolveITNotifyLogLst(list);		
				} else {				
					request.setAttribute("resolveITNotifyLogList_ErrMsg", "No Records Found");
				}
			}
			catch(Exception e){
				log.error(e,e); 
				//addActionError(e.toString());
			}
			model.addAttribute("busjusProcess",busjusProcess);
			log.info("SearchCMPDetailsController :: showCmpIdDetails :: methods ends here....");
			return "pages/businessjustification/ShowCMPDetails"; 
	 }
    
}
