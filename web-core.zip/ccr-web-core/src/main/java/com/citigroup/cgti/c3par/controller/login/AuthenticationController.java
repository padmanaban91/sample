package com.citigroup.cgti.c3par.controller.login;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/*import weblogic.servlet.security.ServletAuthentication;*/

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.audit.domain.AuditC3parUsersData;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.AdminProcess;
import com.citigroup.cgti.c3par.dao.C3PARAccessInfoDAO;
import com.citigroup.cgti.c3par.gdw.CitiContactUpdate;
import com.citigroup.cgti.c3par.model.C3PARAccessInfoEntity;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.soa.model.ProfileEntity;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.user.domain.C3parUserHierarchyXref;
import com.citigroup.cgti.c3par.user.domain.C3parUserRoleXref;
import com.citigroup.cgti.c3par.user.domain.SecurityRole;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;
import com.citigroup.cgti.c3par.webtier.helper.UserEntitlementHelper;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.mentisys.dao.DatabaseException;
import com.mentisys.util.databaserealm.PasswordEncryption;

@Controller
public class AuthenticationController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(AuthenticationController.class);
	
	private WebApplicationContext ctx = null;
	
	CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
	@RequestMapping(value = "/authenticate.act")
	public String authenticate(HttpServletRequest request, HttpServletResponse response){
		log.info("AuthenticationController starts here..");
		log.debug("AuthenticateAction::execute methods starts...");
		String forward = "login/login";

		String userId = request.getHeader("SM_USER");
		//AdminProcess adminProcess = new AdminProcess();
		C3parUser c3parUser = null;
		AdminProcess adminProcess = new AdminProcess();
		if(userId!=null && userId.length()>5 && ! userId.substring(0,6).equalsIgnoreCase("Guest_"))
			c3parUser = adminProcess.retrieveC3parUser(request.getHeader("SM_USER").toLowerCase());
		if(request.getHeader("referer") !=null && !request.getHeader("referer").isEmpty()){
		if(request.getHeader("referer").contains("businessUserComments")){
			String e1 ="";
			try {    
				log.debug("val" +URLDecoder.decode(request.getHeader("referer"), "UTF-8"));
				e1 = URLDecoder.decode(request.getHeader("referer"), "UTF-8");
				e1=e1.substring(e1.indexOf("businessUserComments")).replace("--", "-");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(userId != null && c3parUser != null ){
			log.debug("inside if blosck" +userId);
			}
			else{
				log.debug("no entitlment");
				requestEntitlementForCMP(userId, request);
				c3parUser = adminProcess.retrieveC3parUser(request.getHeader("SM_USER").toLowerCase());
			}
			request.getSession().setAttribute("USER_NAME", c3parUser.getLastName() + ", " + c3parUser.getFirstName());
			
			forward = "forward:/"+ e1;
			request.getSession().setAttribute("forwardToBC", forward);
			log.debug("fwd value" +forward);
		}
		}
		if (null != userId) {
		    userId = userId.toLowerCase();
		    log.debug("Detected user who was authenticated elsewhere (SiteMinder?)");
		    log.debug("Logging in as " + userId);
		    String passwd = userId + "!!";
		    if (!login(userId, passwd, request, response)) {
			log.debug("User " + userId + " not recognized by WebLogic. Failed to login");
			forward = "norole";
			audit(request, userId);
		    }
		    else if(isGuestUser(request)){
			log.debug("User " + userId + " ");
			forward = "pages/jsp/Administration/DeactivatedUserMessage";
			audit(request,userId);
		    }
		    // sending user
		    else if (!findUserRole(userId, request,c3parUser))
		    {
			log.debug("User " + userId + " does not have a proper ROLE.  Failed to authorize");
			forward = "pages/jsp/Administration/DeactivatedUserMessage";
			audit(request,userId);
		    } else
		    {
			log.debug("Login successful.  Adding user and session to database");


			String path = getRelativeTarget(request);

			log.debug("C3PAR SSO ...Forwarding to the link " + path);
			String bpmForward = request.getParameter("forward");
			log.debug("bpmForward " + bpmForward);
			if (bpmForward != null && !"".equals(bpmForward)) {
			    String instanceId = request.getParameter("instanceId");
			    String activityId= request.getParameter("activityId");
			    String tiRequestId= request.getParameter("tiRequestId");
			    String activity= request.getParameter("activity");
			    if(instanceId!=null  && tiRequestId!=null ){
				if(!"".equals(instanceId)&& !"".equals(tiRequestId) ){
					/*try{
				    System.out.println("Inside id with values "+instanceId+" , "+activityId+" , "+tiRequestId);
					IManageActivity activityImpl = ccrBeanFactory.getManageActivityImpl();
					if(activityId!=null && activityId.length()>0)
					    activityImpl.lockActivity(Long.valueOf(activityId).longValue(), userId, false);
				    }catch(Exception xe){
					log.error(xe, xe);
				    }*/
				}
				
				if("ver_sow".equals(bpmForward) || "oa_log".equals(bpmForward))
				{
					//Util util_helper = (Util) getBean(request,"util_helper");
					ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
					Util util_helper=(Util)appContext.getBean("util_helper");
					String roleName=util_helper.getRoleName(activity);
					util_helper.updateRoleId(Long.valueOf(activityId), roleName);
				}
				
			    }

			    return "forward:/logon.act";
			} else if(null != path && !path.trim().equals("") && path.contains("disclaimer.act"))
			{
				log.debug("C3PAR SSO ...Forwarding to the link " + path);
				return path;
			}else{
			    log.debug(" inside else forward to session_timeout");
			    return "forward:/timeout.act";
			}
		    }
		}
		log.debug(" Forward to :-" + forward);
		log.debug("AuthenticateAction::execute methods ends...");
		return forward;
	}
	
    /**
	 * Gets the context.
	 *
	 * @param servletContext the servlet context
	 * @return the context
	 */
	protected WebApplicationContext getContext(ServletContext servletContext) {
		log.debug("getContext(): Start");
		if (ctx == null) {
			log.debug("Getting Spring  Context ....");
			ctx = WebApplicationContextUtils.getWebApplicationContext(servletContext);
			log.debug("Getting Spring  Context ....");
		}
		log.debug("getContext(): End");
		return ctx;
	}

	/**
	 * Gets the bean.
	 *
	 * @param request the request
	 * @param strManager the str manager
	 * @return the bean
	 */
	protected Object getBean(HttpServletRequest request, String strManager) {
		log.debug("getService(): Start");
		Object mgr = ((getContext(request.getSession().getServletContext())).getBean(strManager));
		log.debug("getService(): End");
		return mgr;
	}
	
	 /**
     * Checks if is guest user.
     *
     * @param request the request
     * @return true, if is guest user
     */
    private boolean isGuestUser( HttpServletRequest request) {
	boolean isGuestUser = false;
	try{
	    Principal userPrincipal= request.getUserPrincipal();
	    log.debug("userPrincipal::"+userPrincipal);
	    if(userPrincipal != null && userPrincipal.toString().length()>5 && userPrincipal.toString().substring(0,6).equalsIgnoreCase("Guest_"))
		isGuestUser=true;
	    else{
		String remoteUser = request.getHeader("SM_USER");
		if(remoteUser != null && remoteUser.length()>5 && remoteUser.substring(0,6).equalsIgnoreCase("Guest_") ){
		    isGuestUser=true;
		}
	    }
	}catch(Exception xe){
	    isGuestUser=true;
	    log.error(xe, xe);
	}
	return isGuestUser;
    }


    /**
     * Gets the relative target.
     *
     * @param request the request
     * @return the relative target
     */
    private String getRelativeTarget(HttpServletRequest request) {
	URL url = null;
	try
	{
	    String strURL = (String) request.getSession().getAttribute("j_target_url");

	    if(null == strURL || "".equals(strURL)) {

		//return null;
		log.debug("returning disclaimer.do as j_target_url is null ");
		return "forward:/disclaimer.act";
	    }

	    log.debug("j_target_url = " + strURL);
	    url = new URL(strURL);
	}
	catch(MalformedURLException e)
	{
	    log.error("Failed to get j_target_url",e);
	    return null;
	}
	if (null != url)
	{
	    String path = url.getFile();
	    if (null != path && !"".equals(path)) {
		//Strip off the application name
		String contextPath = request.getContextPath();
		if (0 == path.indexOf(contextPath))
		    path = path.substring(contextPath.length());
		path = path.substring(path.indexOf('/') + 1);
	    }
	    return path;
	}

	return null;
    }

    /**
     * Find user role.
     *
     * @param user the user
     * @param request the request
     * @param entity the entity
     * @return true, if successful
     * @throws ServletException the servlet exception
     */
    private boolean findUserRole(String user, HttpServletRequest request, C3parUser c3parUser)
    {
	HttpSession session = request.getSession();

	boolean admin = false;
	boolean readonly = false;
	Set sessionRole = new HashSet();

	List<C3parUserRoleXref> extUserRoleList = null;
	
	extUserRoleList = c3parUser.getUserRoleList();
	
	if (extUserRoleList != null && !extUserRoleList.isEmpty()) {
		for (C3parUserRoleXref c3parUserRoleXrefExt : extUserRoleList) {
			if ( c3parUserRoleXrefExt.getSecurityRole()!= null) {
				String roleId = c3parUserRoleXrefExt.getSecurityRole().getName();
			    log.debug("roleId::" + sessionRole);
			    sessionRole.add(roleId);
			    if(roleId.equalsIgnoreCase("C3PARSYSTEMADMIN"))
				admin = true;
			    if(roleId.equalsIgnoreCase("ISS"))
			    {
				admin = true;
				readonly = true;
			    }
			}
		}
	}

	boolean roleExists = false;
	if(sessionRole.size() >= 1)
	{
	    session.setAttribute("IS_ADMIN", Boolean.valueOf(admin));
	    session.setAttribute("MAIN_ROLE", sessionRole);
	    session.setAttribute("ROLE", sessionRole);
	    session.setAttribute("READ_ONLY", Boolean.valueOf(readonly));

	    roleExists = true;
	}

	return roleExists;
    }

    /**
     * Audit.
     *
     * @param request the request
     * @param userId the user id
     */
    private void audit(HttpServletRequest request, String userId)
    {
	C3parSession dbsession = new C3parSession();
	C3PARAccessInfoDAO dao = new C3PARAccessInfoDAO(dbsession);

	try {
	    C3PARAccessInfoEntity info = new C3PARAccessInfoEntity();
	    info.setUserId(userId);
	    info.setActionPerformed("Unauthorized Access");
	    info.setActionTime(new Date());

	    dao.insert(info);
	} catch (DatabaseException e) {
	    log.error("Error occurred while logging user access to C3PAR application. [User, Action] = [" + userId + ", Unauthorized Access]");
	    log.error(e);
	} finally {
	}
    }
    
    
    private boolean login(
    	    String userId,
    	    String passwd,
    	    HttpServletRequest request,
    	    HttpServletResponse response) {
    /*return ServletAuthentication.FAILED_AUTHENTICATION
    	!= ServletAuthentication.weak(userId, passwd, request, response);*/
    	return true;
        }
    
    private void requestEntitlementForCMP(String userId, HttpServletRequest request) {
    	
    	 UserEntitlementHelper usrEntHelper = new UserEntitlementHelper();
			String forwardTo = "";
			String loginSSOID = "hb26743";
			AdminProcess adminprocess = new AdminProcess();
			StringBuffer selectedRoleNames = new StringBuffer();
			StringBuffer existingRoleNames = new StringBuffer();
			String rolesToAudit="";
			String existingRoles="";
			Long c3parUserId = null;
			C3parUser extRecord = null;
			C3parUser newUser = null;
			boolean update = false;
			log.debug("sso id value" +loginSSOID);
			try{
				CitiContactUpdate ccu = (CitiContactUpdate)((WebApplicationContextUtils.getWebApplicationContext(
		    		request.getSession().getServletContext())).getBean("citiContactRefreshScheduler"));


		    SOADataComponent soaDataComponent = new SOADataComponent();
		    ProfileInfoFactory profileInfoFactory =
			(ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");

		    ProfileEntity profileEntity = new ProfileEntity();
		    if(userId != null && !userId.equals("")){
			profileEntity.setSoeId(userId);
		    }

		    List<CitiContact> citiContactList =
			profileInfoFactory.getRitzService().getProfile(profileEntity, request.getHeader("SM_USER"));
		    log.debug("size" +citiContactList.size());
		    
			Map<Long,String> securityRolesMap = new HashMap<Long, String>();
			for(SecurityRole role: adminprocess.getSecurityRoles()){
				securityRolesMap.put(role.getId(),role.getName());
			}

			for (CitiContact cc : citiContactList) {

				try {
						// if user not exists in CCR System
						 newUser = new C3parUser();
						 log.debug("enter target contacts:");
						log.debug("requestUserEntitlement :: new requestUserEntitlement::userNotExists");
						newUser.setFirstName(cc.getFirstName().trim());
						newUser.setLastName(cc.getLastName().trim());
						newUser.setEmail(cc.getEmail().trim());
						newUser.setSsoId(cc.getSsoId().trim().toLowerCase());

						String password = cc.getSsoId().trim()
								.toLowerCase()
								+ "!!";
						password = PasswordEncryption.getInstance().encrypt(
								password);
						newUser.setPassword(password);

						newUser.setCreated_date(new Date());
						newUser.setActive("Y");
						newUser.setWfStatus("system_new_user");
						newUser.setRequestedBy("initialize_migration");
						newUser.setRequestedDate(new Date());

						// Adding roles for the user
						List<C3parUserRoleXref> userRoleList = new ArrayList<C3parUserRoleXref>();
						C3parUserRoleXref c3parUserRoleXref = null;
						SecurityRole securityRole = null;

						List<Long> roles = new ArrayList<Long>();
						roles.addAll(usrEntHelper.getSecurityRoleIDs("C3PARUSER"));

						for (Long roleId : roles) {
							log.debug("AssignCitiContactsAction :: new UserEntitlement::roleId-"
									+ roleId);
							selectedRoleNames.append(securityRolesMap.get(roleId)).append(",");
							securityRole = new SecurityRole();
							c3parUserRoleXref = new C3parUserRoleXref();
							securityRole.setId(roleId);
							c3parUserRoleXref.setC3parUser(newUser);
							c3parUserRoleXref.setSecurityRole(securityRole);
							c3parUserRoleXref.setUpdated_date(new Date());
							userRoleList.add(c3parUserRoleXref);
						}
						newUser.setUserRoleList(userRoleList);
						
						newUser.setCreatedUser(loginSSOID);
						// save the user
						adminprocess.setC3parUser(newUser);
						c3parUserId=adminprocess.saveC3parUser();
						log.debug("User Saved If Block");
						}
						catch(Exception e){
				    		log.error(e,e);
				    	}
					
			}
			try {
				AuditC3parUsersData auditC3parUsersData = createAuditUsersData(c3parUserId,adminprocess,loginSSOID);
				String status=auditC3parUsersData.getIsActiveCurrent();
				if(status!=null){
					status = status.equals("Y") ? "ACTIVE" : status.equals("N") ? "IN-ACTIVE" : status.equals("P") ? "PENDING" : "";
				}
				if(update){
					auditC3parUsersData.setAction("UPDATE");
					if(existingRoleNames.toString().endsWith(",")) {
						existingRoles = existingRoleNames.deleteCharAt(existingRoleNames.length()-1).toString();
					}
					log.debug("Existing Roles: "+existingRoles);
					auditC3parUsersData.setRoleStrPrev(existingRoles);
					auditC3parUsersData.setIsActivePrev(extRecord.getActive());
					auditC3parUsersData.setEntStrPrev(getEntitlements(extRecord));
					auditC3parUsersData.setEventDescription("User "+extRecord.getSsoId()+" Updated and Status is "+status);
				}else {
					auditC3parUsersData.setAction("CREATE");
					auditC3parUsersData.setEventDescription("User "+newUser.getSsoId()+" Created and Status is "+status);
				}
				if(selectedRoleNames.toString().endsWith(",")) {
					rolesToAudit = selectedRoleNames.deleteCharAt(selectedRoleNames.length()-1).toString();
				}
				log.debug("Selected Roles in User: "+rolesToAudit);
				auditC3parUsersData.setRoleStrCurrent(rolesToAudit);
				String deviceHostName = request.getServerName().substring(0, request.getServerName().indexOf("."));
				auditC3parUsersData.setHostName(deviceHostName);
				auditC3parUsersData.setHostNameAddress(request.getServerName());
				log.debug("Before auditC3parUsersData Save "+auditC3parUsersData.toString());
				adminprocess.saveAuditUsersData();
			} catch (Exception e) {
				log.error("Error in Audit Logging User Data: ",e);
			}
			}
    	catch(Exception e){
    		log.error(e,e);
    	}
		    		
    }
    
    private AuditC3parUsersData createAuditUsersData(Long userId, AdminProcess adminProcess, String loginSSOId){
		log.info("Entering TargetContactsController createAuditUsersData.");
		AuditC3parUsersData auditC3parUsersData = new AuditC3parUsersData();
		C3parUser c3parUser = adminProcess.getC3parUser();
		auditC3parUsersData.setUserId(userId);
		auditC3parUsersData.setUpdatedByUser(loginSSOId);
		auditC3parUsersData.setUpdated_date(new Date());
		auditC3parUsersData.setMgrApprover("");
		auditC3parUsersData.setMgrApprovedDate(null);
		auditC3parUsersData.setIsaApprover("");
		auditC3parUsersData.setIsaApprovedDate(null);
		auditC3parUsersData.setIsActiveCurrent(c3parUser.getActive());
		auditC3parUsersData.setEntStrCurrent(getEntitlements(c3parUser));
		auditC3parUsersData.setAuditLogInsertedDate(new Date());
		auditC3parUsersData.setSysadminApprover("");
		auditC3parUsersData.setSysadminReviewedDate(null);
		auditC3parUsersData.setLogDateTime(getDateTimeInUTC());
		auditC3parUsersData.setAffectedUser(c3parUser.getSsoId());
		adminProcess.setAuditC3parUsersData(auditC3parUsersData);
		log.info("Exiting TargetContactsController createAuditUsersData.");
		return auditC3parUsersData;			
	}
    
    private String getEntitlements(C3parUser c3parUser){
		log.info("Entering TargetContactsController getEntitlements.");
		StringBuilder entitlements = new StringBuilder("");
		List<C3parUserHierarchyXref> c3parUserHierarchyXrefList = c3parUser.getUserHierarchyList();
		if(c3parUserHierarchyXrefList!=null && c3parUserHierarchyXrefList.size()>0){
			for(C3parUserHierarchyXref c3parUserHierarchyXref : c3parUserHierarchyXrefList ){
				CitiHierarchyMaster citiHierarchyMaster = c3parUserHierarchyXref.getCitiHierarchyMaster();
				if(citiHierarchyMaster!=null){
					log.debug("ID: "+citiHierarchyMaster.getRegion().getName() + " - Name "+ citiHierarchyMaster.getSector().getName());
					entitlements.append(citiHierarchyMaster.getRegion().getName())
							.append("-").append(citiHierarchyMaster.getSector().getName())
							.append(",");
				}
			}
			if(!entitlements.equals("")){
				entitlements.deleteCharAt(entitlements.length()-1);
			}
			log.debug("Formated Entitlements with Region:"+entitlements.toString());
		}
		log.info("Exiting TargetContactsController getEntitlements.");
		return entitlements.toString();
	}
    
    private Calendar getDateTimeInUTC(){
		TimeZone timeZone = TimeZone.getTimeZone("UTC");
		Calendar calendar = Calendar.getInstance(timeZone);
		return calendar;
	}

}
