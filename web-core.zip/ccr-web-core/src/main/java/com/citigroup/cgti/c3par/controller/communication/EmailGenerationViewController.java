package com.citigroup.cgti.c3par.controller.communication;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.sql.Clob;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestContactXref;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestNotes;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.communication.domain.EmailGenerationViewProcess;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.reports.util.Util;
import com.citigroup.cgti.c3par.util.CmpUtil;
import com.citigroup.cgti.c3par.validator.relationship.RoleInfoValidator;

@Controller
public class EmailGenerationViewController {

	private static Logger log = Logger
			.getLogger(EmailGenerationViewController.class);

	@RequestMapping(value = "/loadEmailGenerationView.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadEmailGenerationView(
			ModelMap model,
			@ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess,
			HttpServletRequest request) throws SQLException {
		log.debug("EmailGenerationViewController :: loadEmailGenerationView :: Start .........");

		emailGenerationViewProcess = new EmailGenerationViewProcess();
		String cmpReqId = null;
		
		

		// user navigated from LeadView page
		if (request.getParameter("cmpReqId") != null) {
			cmpReqId = request.getParameter("cmpReqId");
			log.info("EmailGenerationViewController :: loadEmailGenerationView :: user navigated from Lead/Agent View page :: cmpid - "
					+ cmpReqId);
		}
		// CMPRequestID selected from Popup
		if ((cmpReqId == null || cmpReqId.isEmpty())
				&& (request.getSession().getAttribute("selectedCmpReqId") != null)) {
			cmpReqId = (String) request.getSession().getAttribute(
					"selectedCmpReqId");
			request.getSession().removeAttribute("selectedCmpReqId");
			log.info("EmailGenerationViewController :: loadEmailGenerationView :: CMPRequestID selected from Popup :: cmpid - "
					+ cmpReqId); 
		}

		CMPRequest cmpRequest = null;

		emailGenerationViewProcess.setRegionList(emailGenerationViewProcess.loadRegionList());
		emailGenerationViewProcess.setUrgencyList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.GENERIC_LOOKUP_PROCESS_PRIORITY));
		emailGenerationViewProcess.setDsmtSegmentSectorList(emailGenerationViewProcess.getDsmtSgmntSectorList());
		//Added For Project Sector Drop drown
		
		emailGenerationViewProcess.setRequestTypeList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.CMP_REQUEST_TYPE));
		emailGenerationViewProcess.setTypeOfConnectivityList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.GENERIC_LOOKUP_TYPE_OF_CONNECTIVITY_INVOLVED));
		emailGenerationViewProcess.setAffectedBusinessList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.GENERIC_LOOKUP_AFFECTED_BUSINESS));
		emailGenerationViewProcess.setCmprolesList(emailGenerationViewProcess.loadCMPRoles());
		emailGenerationViewProcess.setEmailTemplateList(emailGenerationViewProcess.loadEmailTemplatesByName(ECMConstants.EMAIL_TEMPLATE_NAME));
		emailGenerationViewProcess.setSlodaysList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.SLO_DAYS));
	
		
		if (cmpReqId != null && !cmpReqId.isEmpty()) {
			cmpRequest = emailGenerationViewProcess
					.getCMPRequestDetails(cmpReqId);
			log.info("EcmpRequest.getEcmTimer() cmpid - "
					+ cmpRequest.getEcmTimer()); 
			emailGenerationViewProcess.checkColourstatus(cmpRequest);
			 
			log.debug(""+cmpRequest.getCheckTiId());
			if (cmpRequest.getCcrId() != null
					&& !cmpRequest.getCcrId().isEmpty()) {
				if(cmpRequest.getCcrId().indexOf(".") > 0){
					cmpRequest.setCcrId(cmpRequest.getCcrId().substring(0, cmpRequest.getCcrId().indexOf(".")));
				}
				
				cmpRequest.setChangeRequestDetails(emailGenerationViewProcess
						.getChangeRequestDetails(Long.valueOf(cmpRequest
								.getCcrId().trim()),cmpRequest.getOrderId()));
			}
			
		


			if (cmpRequest != null) {
				if (cmpRequest.getRegion() != null
						&& !cmpRequest.getRegion().isEmpty()) {
					emailGenerationViewProcess
							.setSectorList(emailGenerationViewProcess
									.loadSectorList(cmpRequest.getRegion()));
				}
				if (cmpRequest.getRegion() != null
						&& !cmpRequest.getRegion().isEmpty()
						&& cmpRequest.getEcmSector() != null
						&& !cmpRequest.getEcmSector().isEmpty()) {
					emailGenerationViewProcess
							.setBusinessUnitList(emailGenerationViewProcess
									.loadBusinessUnitList(
											cmpRequest.getRegion(),
											cmpRequest.getEcmSector()));
				}
			}
		}
		if(cmpRequest!=null && cmpRequest.getCmpRequestNotes()!=null){	
		for(CMPRequestNotes cmpNote :  cmpRequest.getCmpRequestNotes() ){
			if(cmpNote!=null && cmpNote.getNewNotes()!=null){
				Clob clob = cmpNote.getNewNotes();
				try
				{
					String notes = clobToString(clob);
					String wholeClob = clob.getSubString(1, (int) clob.length());
					cmpNote.setNotes(wholeClob);
					
				}catch(Exception e )
				{
					log.error("Exception orrcured....3"+e);
				}
				
			}
		}
		}
		
		if (cmpRequest != null && cmpRequest.getCmpRequestContactXrefs() != null && cmpRequest.getOrderBySoeID() != null) {
			List<CMPRequestContactXref> reqContacts = cmpRequest.getCmpRequestContactXrefs();
			Boolean reqflag = true;
			for (CMPRequestContactXref cmpRequestContactXref : reqContacts) {
				if (cmpRequestContactXref.getRole().getName().equals("Requestor")) {
					if (cmpRequest.getOrderBySoeID().equalsIgnoreCase(cmpRequestContactXref.getCiticontact().getGeId())) {
						reqflag = false;
					}
				}
			}
			if (reqflag) {
				for (CMPRequestContactXref cmpRequestContactXref : reqContacts) {
					if (cmpRequestContactXref.getRole().getName().equals("Requestor")) {
						if (!cmpRequest.getOrderBySoeID().equalsIgnoreCase(cmpRequestContactXref.getCiticontact().getGeId())) {
							CMPRequestContactXref newContactXref = new CMPRequestContactXref(); 
							log.debug("Requestor  and Order by User are different. Requestor: " + cmpRequestContactXref.getCiticontact().getFirstName() + cmpRequestContactXref.getCiticontact().getLastName() +
									" Order by User: " + cmpRequest.getOrderByUser());
							newContactXref.setRole(cmpRequestContactXref.getRole());
							newContactXref.setCmpId(cmpRequestContactXref.getCmpId());
							newContactXref.setDisabled(cmpRequestContactXref.isDisabled());
							newContactXref.setIsNew(cmpRequestContactXref.getIsNew());
							newContactXref.setSelectAll(cmpRequestContactXref.isSelectAll());
							newContactXref.setSelected(cmpRequestContactXref.isSelected());
							newContactXref.setUpdated_date(cmpRequestContactXref.getUpdated_date());
							newContactXref.setCiticontact(emailGenerationViewProcess.getCitiContactByGEId(cmpRequest.getOrderBySoeID()));
							reqContacts.add(newContactXref);
							break;
						}
					}
				}
			}
		}
		emailGenerationViewProcess.setCmpRequest(cmpRequest);

		List<String> urlKey = new ArrayList<String>();
		urlKey.add("CASP_URL");
		// urlKey.add("GLOBAL_DIR_URL");
		urlKey.add("RESOLVE_IT_DETAIL_URL");
		List<GenericLookup> urlList = emailGenerationViewProcess
				.loadGenericLookupData(urlKey);
		if (urlList != null) {
			for (GenericLookup url : urlList) {
				if (url != null && url.getValue1().equalsIgnoreCase("CASP_URL")) {
					emailGenerationViewProcess.setCaspUrl(url.getValue2());
					/*
					 * } else if(url != null &&
					 * url.getValue1().equalsIgnoreCase("GLOBAL_DIR_URL")){
					 * emailGenerationViewProcess
					 * .setGlobalDirUrl(url.getValue2());
					 */
				} else if (url != null
						&& url.getValue1().equalsIgnoreCase(
								"RESOLVE_IT_DETAIL_URL")) {
					emailGenerationViewProcess.setResolveItDetailUrl(url
							.getValue2());
				}
			}
		}
		/*Added For Ecm Work Flow*/
		emailGenerationViewProcess.setCloseAssistanceReqFlag(emailGenerationViewProcess.checkCmpAssitanceReqFlag(cmpRequest.getId()));
		
		
		/*End  For Ecm Work Flow*/	

		model.addAttribute("emailGenerationViewProcess",
				emailGenerationViewProcess);

		log.debug("EmailGenerationViewController :: loadEmailGenerationView :: Ends .....");

		return "c3par.communication.emailGenerationView";
	}

	@RequestMapping(value = "/updateCMPRequestDetails.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String updateCMPRequestDetails(
			ModelMap model,
			@ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess,
			BindingResult result, HttpServletRequest request) {

		log.info("EmailGenerationViewController :: updateCMPRequestDetails :: getOrderItemId - "
				+ emailGenerationViewProcess.getCmpRequest().getOrderItemId());
		

		CMPRequest cmpRequest = emailGenerationViewProcess
				.getCMPRequestDetails(emailGenerationViewProcess
						.getCmpRequest().getOrderItemId());
		// REQUEST DETAILS
		cmpRequest.setRequestType(emailGenerationViewProcess.getCmpRequest()
				.getRequestType());
		cmpRequest.setRequestUrgency(emailGenerationViewProcess.getCmpRequest()
				.getRequestUrgency());
		cmpRequest.setRegion(emailGenerationViewProcess.getCmpRequest()
				.getRegion());
		cmpRequest.setEcmSector(emailGenerationViewProcess.getCmpRequest()
				.getEcmSector());
		cmpRequest.setBusinessjustification(emailGenerationViewProcess
				.getCmpRequest().getBusinessjustification());
		if(emailGenerationViewProcess.getCmpRequest().getCcrId() != null && !StringUtils.isEmpty(emailGenerationViewProcess.getCmpRequest().getCcrId()) &&
				!StringUtils.isBlank(emailGenerationViewProcess.getCmpRequest().getCcrId().trim())){
				cmpRequest.setCcrId(Util.filterCCRId(emailGenerationViewProcess.getCmpRequest().getCcrId().trim()));
			}
		// REQUEST DETAILS - Optional
		cmpRequest.setBusinessGroup(emailGenerationViewProcess.getCmpRequest()
				.getBusinessGroup());
		cmpRequest.setAffectedBusiness(emailGenerationViewProcess
				.getCmpRequest().getAffectedBusiness());
		cmpRequest.setThirdParty(emailGenerationViewProcess.getCmpRequest()
				.getThirdParty());
		cmpRequest.setSupplierId(emailGenerationViewProcess.getCmpRequest()
				.getSupplierId());
		cmpRequest.setDetailId(emailGenerationViewProcess.getCmpRequest()
				.getDetailId());
		cmpRequest.setConnectionName(emailGenerationViewProcess.getCmpRequest()
				.getConnectionName());
		cmpRequest.setRelationshipId(emailGenerationViewProcess.getCmpRequest()
				.getRelationshipId());
		// Update Date
		cmpRequest.setUpdatedDate(new Date());
		cmpRequest.setProjectSector(emailGenerationViewProcess.getCmpRequest().getProjectSector());
		
		
		List<GenericLookup> slodaysList = emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.SLO_DAYS);
		
		if(emailGenerationViewProcess.getCmpRequest().getRequestUrgency()!=null && !emailGenerationViewProcess.getCmpRequest().getRequestUrgency().isEmpty()){
			for(GenericLookup sloday : slodaysList){
				if(emailGenerationViewProcess.getCmpRequest().getRequestUrgency().equals(sloday.getValue1())){
					cmpRequest.setSloDays(Long.valueOf(sloday.getValue2()));
					log.debug("Matching slodays::Value1"+sloday.getValue1()+"::Value2::"+sloday.getValue2()+"request urgency::"+emailGenerationViewProcess.getCmpRequest().getRequestUrgency());
				}
				//log.debug("checking slodays>>>>"+sloday.getValue2()+"request urgency"+emailGenerationViewProcess.getCmpRequest().getRequestUrgency());
			}
		}
		 
	
		String forward = "forward:loadEmailGenerationView.act?cmpReqId="
				+ cmpRequest.getOrderItemId();
		boolean isError = false;
		// Contact Details
		if (emailGenerationViewProcess.getCmpRequest()
				.getCmpRequestContactXrefs() != null
				&& !emailGenerationViewProcess.getCmpRequest()
						.getCmpRequestContactXrefs().isEmpty()) {

			log.debug("EmailGenerationViewController :: updateCMPRequestDetails :: getCmpRequestContactXrefs");
			RoleInfoValidator validator = new RoleInfoValidator();

			for (CMPRequestContactXref cmpRequestContact : emailGenerationViewProcess
					.getCmpRequest().getCmpRequestContactXrefs()) {
				log.debug("EmailGenerationViewController :: updateCMPRequestDetails :: ssoid - "
						+ cmpRequestContact.getCiticontact().getSsoId()
						+ " :: isDisabled() - "
						+ cmpRequestContact.isDisabled());
				// User deleted existing contacts
				if (cmpRequestContact.getId() != null
						&& cmpRequestContact.getId().longValue() > 0
						&& cmpRequestContact.isDisabled()) {
					for (CMPRequestContactXref cmpreqcontact : cmpRequest
							.getCmpRequestContactXrefs()) {
						if (cmpreqcontact.getId().longValue() == cmpRequestContact
								.getId().longValue()) {
							log.debug("EmailGenerationViewController :: updateCMPRequestDetails :: deleting cmpreqcontact - "
									+ cmpreqcontact.getCiticontact().getSsoId());
							cmpreqcontact.setDisabled(true);
						}
					}
				}// User added new contact
				else if ((cmpRequestContact.getId() == null || cmpRequestContact
						.getId().longValue() <= 0)
						&& !cmpRequestContact.isDisabled()) {
					log.debug("EmailGenerationViewController :: updateCMPRequestDetails :: adding cmpreqcontact :: getSsoId -"
							+ cmpRequestContact.getCiticontact().getSsoId()
							+ " :: getRole - "
							+ cmpRequestContact.getRole().getId());
					cmpRequestContact.setCmpId(cmpRequest.getId());
					cmpRequestContact.setCiticontact(emailGenerationViewProcess
							.getCitiContactDetails(cmpRequestContact
									.getCiticontact().getSsoId()));
					cmpRequest.getCmpRequestContactXrefs().add(
							cmpRequestContact);
				} else {// User added new contact and deleted
					log.debug("EmailGenerationViewController :: updateCMPRequestDetails :: User added new contact and deleted");
				}

				// Validate the contacts and roles
				if (!cmpRequestContact.isDisabled()) {
					if (!validator.validateContactRole(cmpRequestContact
							.getCiticontact().getId(), cmpRequestContact
							.getRole().getId())) {
						log.debug("EmailGenerationViewController :: updateCMPRequestDetails :: validateContactRole :: citicontact - "
								+ cmpRequestContact.getCiticontact().getId()
								+ " :: role id"
								+ cmpRequestContact.getRole().getId());
						result.addError(new ObjectError(
								"cmpRequestContact",
								"The CMPRequest contains duplicate entries for a contacts (i.e. Contact and Role are same)."));
						isError = true;
						forward = "c3par.communication.emailGenerationView";
						break;
					}
				}
			}
		}

		if (!isError) {
			// update cmp Details
			emailGenerationViewProcess.updateCMPRequestDetails(cmpRequest);

			// ADD NOTE
			if (emailGenerationViewProcess.getAddNote() != null
					&& !emailGenerationViewProcess.getAddNote().trim()
							.isEmpty()) {
				CMPRequestNotes cmpRequestNotes = new CMPRequestNotes();
				cmpRequestNotes.setCmpRequest(cmpRequest);
				cmpRequestNotes.setNotes(emailGenerationViewProcess
						.getAddNote().trim());
				cmpRequestNotes.setCreated_date(new Date());
				cmpRequestNotes.setType(ECMConstants.ECM);
				// update CMP Notes
				emailGenerationViewProcess
						.updateAddNoteDetails(cmpRequestNotes);
			}
		} else {
			//if error, load dropdowns and other values
			emailGenerationViewProcess.setCmpRequest(cmpRequest);
			emailGenerationViewProcess.setRegionList(emailGenerationViewProcess.loadRegionList());
			emailGenerationViewProcess.setUrgencyList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.GENERIC_LOOKUP_PROCESS_PRIORITY));
			emailGenerationViewProcess.setDsmtSegmentSectorList(emailGenerationViewProcess.getDsmtSgmntSectorList());
			//Added For Project Sector
			emailGenerationViewProcess.setRequestTypeList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.CMP_REQUEST_TYPE));
			emailGenerationViewProcess.setTypeOfConnectivityList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.GENERIC_LOOKUP_TYPE_OF_CONNECTIVITY_INVOLVED));
			emailGenerationViewProcess.setAffectedBusinessList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.GENERIC_LOOKUP_AFFECTED_BUSINESS));
			emailGenerationViewProcess.setCmprolesList(emailGenerationViewProcess.loadCMPRoles());
			emailGenerationViewProcess.setEmailTemplateList(emailGenerationViewProcess.loadEmailTemplatesByName(ECMConstants.EMAIL_TEMPLATE_NAME));
			emailGenerationViewProcess.setSlodaysList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.SLO_DAYS));

			if (cmpRequest.getCcrId() != null && !cmpRequest.getCcrId().isEmpty()) {
				if(cmpRequest.getCcrId().indexOf(".") > 0){
					cmpRequest.setCcrId(cmpRequest.getCcrId().substring(0, cmpRequest.getCcrId().indexOf(".")));
				}
				
				cmpRequest.setChangeRequestDetails(emailGenerationViewProcess.getChangeRequestDetails(Long.valueOf(cmpRequest.getCcrId().trim()),cmpRequest.getOrderId()));
			}

			if (cmpRequest != null) {
				if (cmpRequest.getRegion() != null && !cmpRequest.getRegion().isEmpty()) {
					emailGenerationViewProcess.setSectorList(emailGenerationViewProcess.loadSectorList(cmpRequest.getRegion()));
				}
				if (cmpRequest.getRegion() != null && !cmpRequest.getRegion().isEmpty() && cmpRequest.getEcmSector() != null && !cmpRequest.getEcmSector().isEmpty()) {
					emailGenerationViewProcess.setBusinessUnitList(emailGenerationViewProcess.loadBusinessUnitList(cmpRequest.getRegion(),cmpRequest.getEcmSector()));
				}
			}
		}
		log.debug("EmailGenerationViewController :: updateCMPRequestDetails :: Ends ");

		return forward;
	}

	@RequestMapping(value = "/sendEmailGeneration.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String sendEmailGeneration(ModelMap model,@ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess,
			BindingResult result, HttpServletRequest request) {

		log.info("EmailGenerationViewController: sendEmailGeneration: starts - " + emailGenerationViewProcess.getChooseEmail());

		String cmpId = "", agentSsoId = "", forwardPage = "c3par.communication.emailGenerationView";
		boolean isError = false;
		CMPRequest cmpRequest = null;
		CmpRequestDTO cmpRequestDTO = new CmpRequestDTO();
		CitiContact citiContact = new CitiContact();
		String reqOnHold="REQ_ON_HOLD";

		cmpId = emailGenerationViewProcess.getCmpRequest().getOrderItemId();
		//emailGenerationViewProcess.get
		agentSsoId = request.getHeader("SM_USER").toUpperCase();

		cmpRequest = emailGenerationViewProcess.getCMPRequestDetails(cmpId);

		//Validations - start
		List<String> tempList = new ArrayList<String>();
		tempList.add(emailGenerationViewProcess.getChooseEmail().toUpperCase()+"_TASK");
		List<GenericLookup> mailTemplates = emailGenerationViewProcess.loadGenericLookupData(tempList);
		if(mailTemplates != null && !mailTemplates.isEmpty()){
			String activityCode = mailTemplates.get(0).getValue2();
			log.debug("EmailGenerationViewController: sendEmailGeneration: "+emailGenerationViewProcess.getChooseEmail()+" :: taskCode - "+activityCode);
			if(emailGenerationViewProcess.isWaitingforBusinessReply(cmpRequest.getId(), activityCode)){
				  result.addError(new ObjectError("cmpRequestId","Awaiting for BusinessUser reply. please send mail after getting reply from BusinessUser"));
				  isError = true;
			}
		}

		if (emailGenerationViewProcess.getChooseEmail() != null	&& emailGenerationViewProcess.getChooseEmail().equalsIgnoreCase("TRANSFER")) {
			String reassignedUser = emailGenerationViewProcess.getAssignedUser();
			
			boolean validUser = false;
			validUser = emailGenerationViewProcess.checkValidUser(reassignedUser);
			log.info("validUser::reassignedUser "+validUser);
			if(!validUser){
				  result.addError(new ObjectError("assignedUser","Given ECM Agent is not valid."));
				  isError = true;
			}
		}
		if(isError){
			//if error, load dropdowns and other values
			emailGenerationViewProcess.setCmpRequest(cmpRequest);
			emailGenerationViewProcess.setRegionList(emailGenerationViewProcess.loadRegionList());
			emailGenerationViewProcess.setUrgencyList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.GENERIC_LOOKUP_PROCESS_PRIORITY));
			emailGenerationViewProcess.setDsmtSegmentSectorList(emailGenerationViewProcess.getDsmtSgmntSectorList());
			//Added For Project Sector
			emailGenerationViewProcess.setRequestTypeList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.CMP_REQUEST_TYPE));
			emailGenerationViewProcess.setTypeOfConnectivityList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.GENERIC_LOOKUP_TYPE_OF_CONNECTIVITY_INVOLVED));
			emailGenerationViewProcess.setAffectedBusinessList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.GENERIC_LOOKUP_AFFECTED_BUSINESS));
			emailGenerationViewProcess.setCmprolesList(emailGenerationViewProcess.loadCMPRoles());
			emailGenerationViewProcess.setEmailTemplateList(emailGenerationViewProcess.loadEmailTemplatesByName(ECMConstants.EMAIL_TEMPLATE_NAME));
			emailGenerationViewProcess.setSlodaysList(emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.SLO_DAYS));

			if (cmpRequest.getCcrId() != null && !cmpRequest.getCcrId().isEmpty()) {
				if(cmpRequest.getCcrId().indexOf(".") > 0){
					cmpRequest.setCcrId(cmpRequest.getCcrId().substring(0, cmpRequest.getCcrId().indexOf(".")));
				}
				cmpRequest.setChangeRequestDetails(emailGenerationViewProcess.getChangeRequestDetails(Long.valueOf(cmpRequest.getCcrId().trim()),cmpRequest.getOrderId()));
			}

			if (cmpRequest != null) {
				if (cmpRequest.getRegion() != null && !cmpRequest.getRegion().isEmpty()) {
					emailGenerationViewProcess.setSectorList(emailGenerationViewProcess.loadSectorList(cmpRequest.getRegion()));
				}
				if (cmpRequest.getRegion() != null && !cmpRequest.getRegion().isEmpty() && cmpRequest.getEcmSector() != null && !cmpRequest.getEcmSector().isEmpty()) {
					emailGenerationViewProcess.setBusinessUnitList(emailGenerationViewProcess.loadBusinessUnitList(cmpRequest.getRegion(),cmpRequest.getEcmSector()));
				}
			}
			
			return forwardPage;
		}
		//Validations - end		

		cmpRequestDTO.setCmpId(cmpId);
		cmpRequestDTO.setSsoId(agentSsoId);
		cmpRequestDTO.setSecondTemplate(false);

		cmpRequestDTO.setCcrId(cmpRequest.getCcrId());
		cmpRequestDTO.setCmpRequestId(cmpRequest.getId());
		cmpRequestDTO.setBj(cmpRequest.getBusinessjustification());
		cmpRequestDTO.setRegion(cmpRequest.getRegion());
		cmpRequestDTO.setSector(cmpRequest.getAssignedGroup());
		cmpRequestDTO.setUrgency(cmpRequest.getRequestUrgency());
		cmpRequestDTO.setRequestType(cmpRequest.getRequestType());

		cmpRequestDTO.setTextForSubject(emailGenerationViewProcess.getTextForSubject());
		
		if(emailGenerationViewProcess.getChooseEmail().equals(reqOnHold))
		{
			if (emailGenerationViewProcess.getAdditionalTextHold() != null
					&& !(emailGenerationViewProcess.getAdditionalTextHold().isEmpty())) {

				cmpRequestDTO.setAddInfo(emailGenerationViewProcess
						.getAdditionalTextHold());
				} else {
				cmpRequestDTO.setAddInfo("No Additional Information");
			}
		}
		else
	
		{
		if (emailGenerationViewProcess.getAdditionalText() != null
				&& !(emailGenerationViewProcess.getAdditionalText().isEmpty())) {

			cmpRequestDTO.setAddInfo(emailGenerationViewProcess
					.getAdditionalText());
			} else {
			cmpRequestDTO.setAddInfo("No Additional Information");
		}
		}
		
		
		
		/*Added For ECMWorkFlow */
		//Commented Need to delete 
		/*if (emailGenerationViewProcess.getReqAdditionalInfo() != null
				&& !(emailGenerationViewProcess.getReqAdditionalInfo().isEmpty())) {

			cmpRequestDTO.setReqAdditionalInfo(emailGenerationViewProcess
					.getReqAdditionalInfo());
			} else {
				cmpRequestDTO.setReqAdditionalInfo("No Additional Information");
		}*/
		/*Added For */
		cmpRequestDTO.setAssistanceRequested(emailGenerationViewProcess.getAssistanceRequested());
		cmpRequestDTO.setCancelReason(emailGenerationViewProcess.getCancelReason());
		
		if (emailGenerationViewProcess.getAssignedUser() != null && !emailGenerationViewProcess.getAssignedUser().isEmpty()) {
			citiContact = emailGenerationViewProcess.getAgentDetails(emailGenerationViewProcess.getAssignedUser().toUpperCase());
			cmpRequestDTO.setReAssignedUser(citiContact.getFirstName() + " " + citiContact.getLastName());
			cmpRequestDTO.setReAssignedUserPhone(citiContact.getPhone());
			cmpRequestDTO.setReAssignedUserEmail(citiContact.getEmail());
		}
		
		citiContact = emailGenerationViewProcess.getAgentDetails(agentSsoId);
		cmpRequestDTO.setAgentName(citiContact.getFirstName() + " " + citiContact.getLastName());		
		cmpRequestDTO.setAgentPhone(citiContact.getPhone());
		cmpRequestDTO.setAgentEmail(citiContact.getEmail());

		StringBuilder requestorName = new StringBuilder("");
		StringBuilder primaryOwnerName = new StringBuilder("");
		StringBuilder secondaryOwnerName = new StringBuilder("");
		StringBuilder isoName = new StringBuilder("");
		StringBuilder toAddress = new StringBuilder("");
		StringBuilder ccAddress = new StringBuilder("");
		StringBuilder chgId = new StringBuilder("");
		StringBuilder chgDate = new StringBuilder("");

		if (cmpRequest.getCcrId() != null && !cmpRequest.getCcrId().isEmpty()) {
			if(cmpRequest.getCcrId().indexOf(".") > 0){
				cmpRequest.setCcrId(cmpRequest.getCcrId().substring(0, cmpRequest.getCcrId().indexOf(".")));
			}

            List<Map<String, String>> chgReq = emailGenerationViewProcess.getChangeRequestDetails(Long.valueOf(cmpRequest.getCcrId().trim()),cmpRequest.getOrderId());
            cmpRequest.setChangeRequestDetails(chgReq);
            Set<CmpRequestDTO.ChangeRequestDetails> appInfoSet = new HashSet<CmpRequestDTO.ChangeRequestDetails>();

            for (Map<String, String> chgRequest : chgReq) {
	            CmpRequestDTO.ChangeRequestDetails a = new CmpRequestDTO.ChangeRequestDetails();
	            if (chgId.length() < 1) {
	                chgId.append(chgRequest.get("CHGID"));
	                chgDate.append(chgRequest.get("CHGDATE"));
	            } else {
	            	
	                chgId.append(", " + chgRequest.get("CHGID"));
	                chgDate.append(", " + chgRequest.get("CHGDATE"));
	            }                    
	            a.setChgNum(chgRequest.get("CHGID"));
	            a.setChgDate(chgRequest.get("CHGDATE"));
	            appInfoSet.add(a);
            }            
            cmpRequestDTO.setChangeRequestDetails(appInfoSet.toArray(new CmpRequestDTO.ChangeRequestDetails[appInfoSet.size()]));
		}

		for (CMPRequestContactXref cmpRequestContactXref : cmpRequest
				.getCmpRequestContactXrefs()) {
			String role = cmpRequestContactXref.getRole().getName();
			if(role != null && role.length() > 0 && cmpRequestContactXref.getCiticontact() != null){
			
				if ("Requestor".equalsIgnoreCase(role)) {
					if (requestorName.length() < 1) {
						requestorName.append(cmpRequestContactXref.getCiticontact()
								.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					} else {
						requestorName.append(", "
								+ cmpRequestContactXref.getCiticontact()
										.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					}
					if (toAddress.length() < 1) {
						toAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						toAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
					if (!"E".equalsIgnoreCase(cmpRequestContactXref
							.getCiticontact().getEmployeeType())) {
						cmpRequestDTO.setSecondTemplate(true);
					}
				} else if ("Business_Owner".equalsIgnoreCase(role)) {
					if (primaryOwnerName.length() < 1) {
						primaryOwnerName.append(cmpRequestContactXref
								.getCiticontact().getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					} else {
						primaryOwnerName.append(", "
								+ cmpRequestContactXref.getCiticontact()
										.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					}
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else if ("Sec_Business_Owner".equalsIgnoreCase(role)) {
					if (secondaryOwnerName.length() < 1) {
						secondaryOwnerName.append(cmpRequestContactXref
								.getCiticontact().getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					} else {
						secondaryOwnerName.append(", "
								+ cmpRequestContactXref.getCiticontact()
										.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					}
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else if ("BISO".equalsIgnoreCase(role)) {
					if (isoName.length() < 1) {
						isoName.append(cmpRequestContactXref.getCiticontact()
								.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					} else {
						isoName.append(", "
								+ cmpRequestContactXref.getCiticontact()
										.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					}
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else {
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				}
			}
		}

		cmpRequestDTO.setChgId(chgId.toString());
		cmpRequestDTO.setChgDate(chgDate.toString());
		cmpRequestDTO.setRequestorName(requestorName.toString());
		cmpRequestDTO.setPrimaryOwnerName(primaryOwnerName.toString());
		cmpRequestDTO.setSecondaryOwnerName(secondaryOwnerName.toString());
		cmpRequestDTO.setIsoName(isoName.toString());
		cmpRequestDTO.setToAddresses(toAddress.toString());
		cmpRequestDTO.setCcAddresses(ccAddress.toString());
		cmpRequestDTO.setComments(emailGenerationViewProcess.getComments());

		forwardPage = "forward:loadEmailGenerationView.act?cmpReqId="+ cmpRequest.getOrderItemId();

		if (emailGenerationViewProcess.getChooseEmail() != null	&& emailGenerationViewProcess.getChooseEmail().equalsIgnoreCase("TRANSFER")) {
			String reassignedUser = emailGenerationViewProcess.getAssignedUser();
			log.info("EmailGenerationViewController :: sendEmailGeneration :: transfer Agent - "+ reassignedUser);
			
			// transfer Agent
			emailGenerationViewProcess.transferEcmAgent(reassignedUser, cmpId, agentSsoId);
			
			forwardPage = "forward:agentViewController.act";
		} else if (emailGenerationViewProcess.getChooseEmail() != null
				&& emailGenerationViewProcess.getChooseEmail()
						.equalsIgnoreCase("CANCEL")) {
			log.info("EmailGenerationViewController :: sendEmailGeneration :: CANCEL ");
			// update status as cancelled
			emailGenerationViewProcess.updateCMPRequestStatus(
					cmpRequest.getId(), "Cancelled");
			
			forwardPage = "forward:agentViewController.act";
		}
		
		// Read attached file
		if (emailGenerationViewProcess.getAttachedFile() != null && !emailGenerationViewProcess.getAttachedFile().isEmpty()) {
			
			HashMap<String, byte[]> fileToAttach = new HashMap<String, byte[]>();
			List<CommonsMultipartFile> uploadedFileList = emailGenerationViewProcess.getAttachedFile();
				
			for (CommonsMultipartFile uploadedFile : uploadedFileList) {
				if(uploadedFile != null && uploadedFile.getSize() > 0){
					byte[] bs = uploadedFile.getBytes();
					fileToAttach.put(uploadedFile.getOriginalFilename(), bs);
				}
			}	
			
			cmpRequestDTO.setFileAttachments(fileToAttach);
		}
		
		// send Email
		emailGenerationViewProcess.sendEmailGenerationView(
				emailGenerationViewProcess.getChooseEmail(), cmpRequestDTO);

		// ADD NOTE
		List<GenericLookup> emailTemplates = emailGenerationViewProcess.loadGenericLookupByName(ECMConstants.EMAIL_TEMPLATE_NAME);
		CMPRequestNotes cmpRequestNotes = new CMPRequestNotes();
		cmpRequestNotes.setCmpRequest(cmpRequest);
		for (GenericLookup emailTemplate : emailTemplates) {
			if (emailTemplate.getValue1().equalsIgnoreCase(emailGenerationViewProcess.getChooseEmail())) {
				if(emailTemplate.getValue1().equalsIgnoreCase("TRANSFER")){
					cmpRequestNotes.setNotes("Transferred to " +cmpRequestDTO.getReAssignedUser());
				}
				else if(emailTemplate.getValue1().equalsIgnoreCase("CANCEL")){
					cmpRequestNotes.setNotes(emailTemplate.getValue2() + " - Mail Sent\n" +
							"Reason(s) for cancellation:\n" +emailGenerationViewProcess.getCancelReason());
				}
				else{
					cmpRequestNotes.setNotes(emailTemplate.getValue2() + " - Mail Sent");
				}
			}
		}
		cmpRequestNotes.setCreated_date(new Date());
		cmpRequestNotes.setType(ECMConstants.EMAIL);
		
		// update CMP Notes
		emailGenerationViewProcess.updateAddNoteDetails(cmpRequestNotes);

		model.addAttribute("emailGenerationViewProcess",
				emailGenerationViewProcess);
		log.info("EmailGenerationViewController :: sendEmailGeneration :: ends");

		return forwardPage;
	}

	@RequestMapping(value = "/loadSectorDropDown.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody
	String loadSectorDropDown(
			ModelMap model,
			@ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess,
			HttpServletRequest request) {
		log.info("EmailGenerationViewController: loadSectorDropDown :: starts...");

		String regionName = request.getParameter("regionName");
		log.debug("EmailGenerationViewController::loadSectorDropDown regionName..."
				+ regionName);
		List<Sector> sectorList = emailGenerationViewProcess
				.loadSectorList(regionName);
		emailGenerationViewProcess.setSectorList(sectorList);

		StringBuffer sectorJSONSB = new StringBuffer();
		sectorJSONSB.append("[");
		sectorJSONSB
				.append("{\"item\":\"\",\"label\":\"---Select Sector---\"}");
		for (Sector sector : sectorList) {
			sectorJSONSB.append(",{\"item\":\"" + sector.getName()
					+ "\",\"label\":\"" + sector.getName() + "\"}");
		}
		sectorJSONSB.append("]");
		request.setAttribute("comboValues", sectorJSONSB.toString());
		model.addAttribute("emailGenerationViewProcess",
				emailGenerationViewProcess);

		log.info("EmailGenerationViewController::loadSectorDropDown method ends...");

		return sectorJSONSB.toString();
	}

	@RequestMapping(value = "/loadBussinessUnitDropDown.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody
	String loadBussinessUnitDropDown(
			ModelMap model,
			@ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess,
			HttpServletRequest request) {
		log.info("EmailGenerationViewController :: loadBussinessUnitDropDown method starts...");
		String regionName = request.getParameter("regionName");
		String sectorName = request.getParameter("sectorName");
		log.debug("EmailGenerationViewController :: loadBussinessUnitDropDown :: regionName - "
				+ regionName + " :: sectorName - " + sectorName);
		List<BusinessUnit> bulist = emailGenerationViewProcess
				.loadBusinessUnitList(regionName, sectorName);
		emailGenerationViewProcess.setBusinessUnitList(bulist);

		StringBuffer businessunitJSONSB = new StringBuffer();
		businessunitJSONSB.append("[");
		businessunitJSONSB
				.append("{\"item\":\"\",\"label\":\"---Select Business Group---\"}");
		for (BusinessUnit businessunit : bulist) {
			businessunitJSONSB.append(",{\"item\":\""
					+ businessunit.getBusinessName() + "\",\"label\":\""
					+ businessunit.getBusinessName() + "\"}");
		}
		businessunitJSONSB.append("]");
		request.setAttribute("comboValues", businessunitJSONSB.toString());
		model.addAttribute("emailGenerationViewProcess",
				emailGenerationViewProcess);

		log.info("EmailGenerationViewController :: loadBussinessUnitDropDown method ends...");

		return businessunitJSONSB.toString();
	}

	@RequestMapping(value = "/selectAuditTrialDetail.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String selectAuditTrialDetail(
			ModelMap model,
			@ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess,
			HttpServletRequest request) {
		log.info("EmailGenerationViewController :: selectAuditTrialDetail :: Start .....");
		Long cmpId = null;
		if (request.getParameter("cmpId") != null) {
			cmpId = Long.valueOf(request.getParameter("cmpId"));
		}

		log.debug("EmailGenerationViewController :: getTiMailAuditList ::cmpId"
				+ cmpId);
		List<TIMailAudit> tiMailAuditList = emailGenerationViewProcess
				.getAuditTrialDetail(cmpId);
		emailGenerationViewProcess.setTiMailAuditList(tiMailAuditList);
		log.debug("EmailGenerationViewController :: getTiMailAuditList ::"
				+ cmpId + "  size :: "
				+ emailGenerationViewProcess.getTiMailAuditList().size());

		model.addAttribute("emailGenerationViewProcess",
				emailGenerationViewProcess);
		log.debug("EmailGenerationViewController :: selectAuditTrialDetail :: Ends .....");

		// return "c3par.communication.tiMailAuditView";
		return "pages/communication/PopupEmailAudtiTrial";
	}
	
	@RequestMapping(value = "/saveAssignedUserFromEmailGen.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String saveAssignedUserFromEmailGen(
			ModelMap model,
			@ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess,BindingResult result,
			HttpServletRequest request) {
		log.info("EmailGenerationViewController :: saveAssignedUserFromEmailGen :: Start .....");   
		
		log.debug("EmailGenerationViewController :: saveAssignedUserFromEmailGen ::cmpId" 
				+ request.getParameter("orderId"));
		boolean isUpdated = false;
		String reassignedUser = emailGenerationViewProcess.getAssignUser();  
		log.debug("reassignedUser::saveAssignedUser::"+reassignedUser);
		log.info("SLO Days::"+emailGenerationViewProcess.getCmpRequest().getSloDays());
		boolean isError = false;
		boolean validUser = false;
		validUser = emailGenerationViewProcess.checkValidUser(reassignedUser);
		log.info("validUser::assignedUser::saveAssignedUser:: "+validUser);
		if(!validUser){
			log.debug("inside validuser::saveAssignedUser::");
			request.setAttribute("err_log",
					"Given ECM Agent is not valid. ");
			  isError = true;
		}
		if(!isError){
			log.debug("inside isError::saveAssignedUser::");
			isUpdated = emailGenerationViewProcess.updateAssignedEcmUser(request.getParameter("orderId"),emailGenerationViewProcess.getAssignUser(),
				emailGenerationViewProcess.getCmpRequest().getSloDays(),request.getHeader("SM_USER"),emailGenerationViewProcess.getLeadComment(),emailGenerationViewProcess.getCmpRequest().getProjectSector());
		}
		
		if (isUpdated && request.getParameter("orderItemId")!=null) {
			this.sendEmailNotificationToAgent(request.getParameter("orderItemId"),
					emailGenerationViewProcess.getAssignUser(), request.getHeader("SM_USER"), emailGenerationViewProcess);
		}
		model.addAttribute("emailGenerationViewProcess",
				emailGenerationViewProcess);
		
		log.debug("EmailGenerationViewController :: saveAssignedUserFromEmailGen :: Ends .....");

		return "forward:/loadEmailGenerationView.act?cmpReqId="+ emailGenerationViewProcess.getCmpRequest().getOrderItemId();
	}
	
	private void sendEmailNotificationToAgent(String cmpReqId, String AssignTo,
			String userId, EmailGenerationViewProcess emailGenerationViewProcess) {

		log.debug("Entering into sendEmailNotificationToAgent()...");

		CmpRequestDTO dto = new CmpRequestDTO();

		String mailTemplateName = "REQ_ASSIGNED_TO_ECM_AGENT";

		CitiContact citiContact = emailGenerationViewProcess
				.getCitiContactDetails(AssignTo);

		// Agent Info
		dto.setAgentName(citiContact.getFirstName() + " "
				+ citiContact.getLastName());
		dto.setAgentEmail(citiContact.getEmail());
		dto.setAgentPhone(citiContact.getPhone());
		dto.setToAddresses(citiContact.getEmail());

		citiContact = emailGenerationViewProcess.getCitiContactDetails(userId);

		// Lead Info
		dto.setLeadName(citiContact.getFirstName() + " "
				+ citiContact.getLastName());
		dto.setLeadEmail(citiContact.getEmail());
		dto.setLeadPhone(citiContact.getPhone());
		dto.setSsoId(citiContact.getSsoId());
		

		CMPRequest cmpRequest = emailGenerationViewProcess.getCMPRequestDetails(cmpReqId);

		CmpRequestDTO cmpRequestDTO = this.convertToDTO(cmpRequest, dto);

		emailGenerationViewProcess.sendEmailGenerationView(mailTemplateName,
				cmpRequestDTO);

		log.debug("Exit frm sendEmailNotificationToAgent()...");

	}

	private CmpRequestDTO convertToDTO(CMPRequest cmpRequest, CmpRequestDTO dto) {
		
		StringBuilder ccAddress = new StringBuilder("");		

		dto.setCmpId(cmpRequest.getOrderItemId());
		dto.setOrderId(cmpRequest.getOrderId());
		dto.setStep(cmpRequest.getTypeofConnectivityInvolved() + ": "
				+ cmpRequest.getRequestType());
		dto.setOrderBy(cmpRequest.getOrderByUser());
		dto.setOrderFor(cmpRequest.getOrderForUser());
		dto.setLoggedDate(this.dateFormatChange(cmpRequest.getAvailableDate()));
		dto.setDueDate(this.dateFormatChange(this.findDueDate(
				cmpRequest.getUpdateAssignedUserDate(), cmpRequest.getSloDays())));
		dto.setBj(cmpRequest.getBusinessjustification());
		dto.setCmpRequestId(cmpRequest.getId());
		
		if (ccAddress.length() < 1) {
			ccAddress.append(dto.getLeadEmail());
		} else {
			ccAddress.append("; "+ dto.getLeadEmail());
		}
		
		for (CMPRequestContactXref cmpRequestContactXref : cmpRequest
				.getCmpRequestContactXrefs()) {
			String role = cmpRequestContactXref.getRole().getName();
			if(role != null && role.length() > 0 && cmpRequestContactXref.getCiticontact() != null){
			
				if ("Requestor".equalsIgnoreCase(role)) {					
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				}else if ("Business_Owner".equalsIgnoreCase(role)) {					
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else if ("Sec_Business_Owner".equalsIgnoreCase(role)) {					
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else if ("BISO".equalsIgnoreCase(role)) {					
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else {
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				}
			}
		}
		dto.setCcAddresses(ccAddress.toString());
		return dto;
	}
	
	
	private Date findDueDate(Date assignedDate, Long SLODays) {

		Date dueDate = null;

		log.debug("The assignedDate:" + assignedDate + " and SLODays:"
				+ SLODays.intValue());

		if (assignedDate != null && SLODays != null) {

			try {

				Calendar calendar = Calendar.getInstance();
				calendar.setTime(assignedDate);

				for (int i = 0; i < SLODays.intValue(); i++) {

					calendar.add(Calendar.DATE, 1);
					if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
							|| Calendar.DAY_OF_WEEK == Calendar.SUNDAY) {
						calendar.add(Calendar.DATE, 2);
					}
				}

				dueDate = calendar.getTime();

			} catch (Exception ex) {
				log.error(ex.getMessage());
			}

		}

		return dueDate;
	}

	private Date dateFormatChange(Date inputDate) {

		Date fomattedDate = null;

		try {

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

			if (inputDate != null) {

				fomattedDate = sdf.parse(sdf.format(inputDate));
			}

		} catch (Exception ex) {
			log.error(ex.getMessage());
		}

		return fomattedDate;

	}

	@RequestMapping(value = "/cancelCMPRecord.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String cancelCMPRecord(
			ModelMap model,
			@ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess,BindingResult result,
			HttpServletRequest request) {
		log.info("Entering EmailGenerationViewController cancelCMPRecord.");
		Long cmpId = request.getParameter("cmpId") != null ? Long.valueOf(request.getParameter("cmpId")) : null;
		String soeId = request.getHeader("SM_USER").toUpperCase();
		log.debug("cancelCMPRecord CMP ID - "+cmpId+" and SOEID - "+soeId);
		String cancelTask ="cmp_cancel_request";
		String cancelStatus = "Cancelled";
		emailGenerationViewProcess.cmpActivityTrail(cmpId, soeId, cancelTask, ECMConstants.STATUS_COMPLETED);
		emailGenerationViewProcess.updateCMPRequestStatus(cmpId, cancelStatus);
		log.info("Exiting EmailGenerationViewController cancelCMPRecord.");
		return "forward:/loadEmailGenerationView.act?cmpReqId="+ emailGenerationViewProcess.getCmpRequest().getOrderItemId();
	}
	
	@RequestMapping(value = "/reOpenCmp.act", method = {RequestMethod.GET, RequestMethod.POST})
	public String reOpenCmp(ModelMap model, @ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess, BindingResult result, HttpServletRequest request){
		log.info("EmailGenerationViewController: reOpenCmp: starts");
		Long cmpId = request.getParameter("cmpId") != null ? Long.valueOf(request.getParameter("cmpId")) : null;
		String soeId = request.getHeader("SM_USER").toUpperCase();
		String status = "In Progress";
		String awaitingEcmInput="awaiting_ecm_input";
		emailGenerationViewProcess.cmpActivityTrail(cmpId, soeId, awaitingEcmInput, ECMConstants.STATUS_COMPLETED);
		emailGenerationViewProcess.updateCMPRequestStatus(cmpId, status);
		log.info("EmailGenerationViewController: reOpenCmp: ends");
		return "forward:/loadEmailGenerationView.act?cmpReqId="+ emailGenerationViewProcess.getCmpRequest().getOrderItemId();
	}
	
	@RequestMapping(value = "/getCmpData.act", method = {RequestMethod.GET, RequestMethod.POST})
    public ModelAndView getCmpData(HttpServletRequest request, HttpServletResponse response)
 throws IOException {
        log.info("cmpConsumingDataView start :: ");
        ModelAndView model=null;
        InputStream in=null;
        try {
            CMPRequest cmpRequest = new CMPRequest();
            String[] cmpRegArr = request.getParameter("cmpReqId").split("-");
            byte[] bytes = cmpRequest.getCmpData(cmpRegArr[0]);
            byte[] search = "<PurchaseOptions>".getBytes();
            byte[] replacement = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <PurchaseOrder><PurchaseOptions>"
                    .getBytes();
            in = new CmpUtil((new ByteArrayInputStream(bytes)), search, replacement);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            int b;
            while (-1 != (b = in.read())) {
                if (888 != b) {
                    bos.write(b);
                }
            }
            byte byteArr[] = bos.toByteArray();
            InputStream inputStream = new ByteArrayInputStream(byteArr);
            model = new ModelAndView("CmpDetails");
            model.addObject("xmlSource", inputStream);
            log.debug("cmpConsumingDataView End :: ");
            
        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {
            IOUtils.closeQuietly(in);
        }
        return model;
    }
	
	private String clobToString(Clob data)
	{
		System.out.println("Debug LOB issue clobToString 1");
	    final StringBuilder sb = new StringBuilder();
	    try
	    {
	        final Reader         reader = data.getCharacterStream();
	        System.out.println("Debug LOB issue clobToString 2");
	        final BufferedReader br     = new BufferedReader(reader);
	        int b;
	        while(-1 != (b = br.read()))
	        {
	            sb.append((char)b);
	        }
	        br.close();
	    }
	    catch (SQLException e)
	    {
	        log.error("SQL. Could not convert CLOB to string",e);
	        return e.toString();
	    }
	    catch (IOException e)
	    {
	        log.error("IO. Could not convert CLOB to string",e);
	        return e.toString();
	    }
	    return sb.toString();
	}
	/*Added For ECM WorkFlow*/
	@RequestMapping(value = "/closeAssitanceRequestMail.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String closeAssitanceRequestMail(ModelMap model,@ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess,
			BindingResult result, HttpServletRequest request) {
		try{
		 log.info("closeAssitanceRequestMail  start :: ");
		String cmpId = "", agentSsoId = "";
		cmpId = emailGenerationViewProcess.getCmpRequest().getOrderItemId();
		agentSsoId = request.getHeader("SM_USER").toUpperCase();
		CMPRequest cmpRequest = null;
		 log.info("Cmp Id   :: "+cmpId);
		 cmpRequest = emailGenerationViewProcess.getCMPRequestDetails(cmpId);
		CmpRequestDTO cmpRequestDTO = convertCmpToDto(cmpRequest, agentSsoId, cmpId, emailGenerationViewProcess);
		if (emailGenerationViewProcess.getAttachedFile() != null && !emailGenerationViewProcess.getAttachedFile().isEmpty()) {            
            HashMap<String, byte[]> fileToAttach = new HashMap<String, byte[]>();
            List<CommonsMultipartFile> uploadedFileList = emailGenerationViewProcess.getAttachedFile();                  
            for (CommonsMultipartFile uploadedFile : uploadedFileList) {
                  if(uploadedFile != null && uploadedFile.getSize() > 0){
                         byte[] bs = uploadedFile.getBytes();
                         fileToAttach.put(uploadedFile.getOriginalFilename(), bs);
                  }
            }            
            cmpRequestDTO.setFileAttachments(fileToAttach);
		}     
		log.info(" Id   :: "+cmpRequest.getId());
		emailGenerationViewProcess.sendEmailGenerationView("CLOSE_REQ_ASSIGNED_ASSISTANCE", cmpRequestDTO);
		}
		catch(Exception e){
			log.error(e,e);
		}
		 //emailGenerationViewProcess.cmpActivityTrail(cmpRequest.getId(), agentSsoId ,"closed_assitance_req", "COMPLETED");
		 log.info("closeAssitanceRequestMail  End :: ");
		
		 return "forward:/agentViewController.act";
		
	}
	private CmpRequestDTO  convertCmpToDto(CMPRequest cmpRequest,String  agentSsoId,String cmpId,EmailGenerationViewProcess emailGenerationViewProcess) {
		CmpRequestDTO cmpRequestDTO = new CmpRequestDTO();
		try{
			 log.info("convertCmpToDto  start :: ");
			 log.info("Cmp Id   :: "+cmpId);
		CitiContact citiContact = new CitiContact();
		cmpRequestDTO.setCmpId(cmpId);
		cmpRequestDTO.setSsoId(agentSsoId);
		cmpRequestDTO.setSecondTemplate(false);

		cmpRequestDTO.setCcrId(cmpRequest.getCcrId());
		cmpRequestDTO.setCmpRequestId(cmpRequest.getId());
		cmpRequestDTO.setBj(cmpRequest.getBusinessjustification());
		cmpRequestDTO.setRegion(cmpRequest.getRegion());
		cmpRequestDTO.setSector(cmpRequest.getAssignedGroup());
		cmpRequestDTO.setUrgency(cmpRequest.getRequestUrgency());
		cmpRequestDTO.setRequestType(cmpRequest.getRequestType());
		cmpRequestDTO.setTextForSubject(emailGenerationViewProcess.getTextForSubject());
		cmpRequestDTO.setAssistanceRequested(emailGenerationViewProcess.getAssistanceRequested());
		cmpRequestDTO.setCancelReason(emailGenerationViewProcess.getCancelReason());
		
		citiContact = emailGenerationViewProcess.getAgentDetails(agentSsoId);
		cmpRequestDTO.setAgentName(citiContact.getFirstName() + " " + citiContact.getLastName());		
		cmpRequestDTO.setAgentPhone(citiContact.getPhone());
		cmpRequestDTO.setAgentEmail(citiContact.getEmail());

		StringBuilder requestorName = new StringBuilder("");
		StringBuilder primaryOwnerName = new StringBuilder("");
		StringBuilder secondaryOwnerName = new StringBuilder("");
		StringBuilder isoName = new StringBuilder("");
		StringBuilder toAddress = new StringBuilder("");
		StringBuilder ccAddress = new StringBuilder("");
		StringBuilder chgId = new StringBuilder("");
		StringBuilder chgDate = new StringBuilder("");

		if (cmpRequest.getCcrId() != null && !cmpRequest.getCcrId().isEmpty()) {
			if(cmpRequest.getCcrId().indexOf(".") > 0){
				cmpRequest.setCcrId(cmpRequest.getCcrId().substring(0, cmpRequest.getCcrId().indexOf(".")));
			}

            List<Map<String, String>> chgReq = emailGenerationViewProcess.getChangeRequestDetails(Long.valueOf(cmpRequest.getCcrId().trim()),cmpRequest.getOrderId());
            cmpRequest.setChangeRequestDetails(chgReq);
            Set<CmpRequestDTO.ChangeRequestDetails> appInfoSet = new HashSet<CmpRequestDTO.ChangeRequestDetails>();

            for (Map<String, String> chgRequest : chgReq) {
	            CmpRequestDTO.ChangeRequestDetails a = new CmpRequestDTO.ChangeRequestDetails();
	            if (chgId.length() < 1) {
	                chgId.append(chgRequest.get("CHGID"));
	                chgDate.append(chgRequest.get("CHGDATE"));
	            } else {
	            	
	                chgId.append(", " + chgRequest.get("CHGID"));
	                chgDate.append(", " + chgRequest.get("CHGDATE"));
	            }                    
	            a.setChgNum(chgRequest.get("CHGID"));
	            a.setChgDate(chgRequest.get("CHGDATE"));
	            appInfoSet.add(a);
            }            
            cmpRequestDTO.setChangeRequestDetails(appInfoSet.toArray(new CmpRequestDTO.ChangeRequestDetails[appInfoSet.size()]));
		}

		for (CMPRequestContactXref cmpRequestContactXref : cmpRequest
				.getCmpRequestContactXrefs()) {
			String role = cmpRequestContactXref.getRole().getName();
			if(role != null && role.length() > 0 && cmpRequestContactXref.getCiticontact() != null){
			
				if ("Requestor".equalsIgnoreCase(role)) {
					if (requestorName.length() < 1) {
						requestorName.append(cmpRequestContactXref.getCiticontact()
								.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					} else {
						requestorName.append(", "
								+ cmpRequestContactXref.getCiticontact()
										.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					}
					if (toAddress.length() < 1) {
						toAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						toAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
					if (!"E".equalsIgnoreCase(cmpRequestContactXref
							.getCiticontact().getEmployeeType())) {
						cmpRequestDTO.setSecondTemplate(true);
					}
				} else if ("Business_Owner".equalsIgnoreCase(role)) {
					if (primaryOwnerName.length() < 1) {
						primaryOwnerName.append(cmpRequestContactXref
								.getCiticontact().getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					} else {
						primaryOwnerName.append(", "
								+ cmpRequestContactXref.getCiticontact()
										.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					}
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else if ("Sec_Business_Owner".equalsIgnoreCase(role)) {
					if (secondaryOwnerName.length() < 1) {
						secondaryOwnerName.append(cmpRequestContactXref
								.getCiticontact().getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					} else {
						secondaryOwnerName.append(", "
								+ cmpRequestContactXref.getCiticontact()
										.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					}
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else if ("BISO".equalsIgnoreCase(role)) {
					if (isoName.length() < 1) {
						isoName.append(cmpRequestContactXref.getCiticontact()
								.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					} else {
						isoName.append(", "
								+ cmpRequestContactXref.getCiticontact()
										.getFirstName()
								+ " "
								+ cmpRequestContactXref.getCiticontact()
										.getLastName());
					}
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else {
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				}
			}
		}

		cmpRequestDTO.setChgId(chgId.toString());
		cmpRequestDTO.setChgDate(chgDate.toString());
		cmpRequestDTO.setRequestorName(requestorName.toString());
		cmpRequestDTO.setPrimaryOwnerName(primaryOwnerName.toString());
		cmpRequestDTO.setSecondaryOwnerName(secondaryOwnerName.toString());
		cmpRequestDTO.setIsoName(isoName.toString());
		cmpRequestDTO.setToAddresses(toAddress.toString());
		cmpRequestDTO.setCcAddresses(ccAddress.toString());
		cmpRequestDTO.setComments(emailGenerationViewProcess.getComments());
		cmpRequestDTO.setAssistanceRequested(emailGenerationViewProcess.getCmpRequest().getBusinessjustification());
		cmpRequestDTO.setAddInfo(emailGenerationViewProcess.getAdditionalText());
		 //log.info("Cmp Id   :: "+cmpId);
		 log.info("convertCmpToDto  End :: "+toAddress);
		}
		catch(Exception e){
			log.error(e.toString(),e);
		}
		return cmpRequestDTO;
		
	}
	/*End  For ECM WorkFlow*/
	

}
