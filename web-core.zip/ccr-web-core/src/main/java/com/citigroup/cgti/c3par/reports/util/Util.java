/*
 * Created on Jun 10, 2005
 *
 */
package com.citigroup.cgti.c3par.reports.util;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

//import com.citigroup.cgti.c3par.reports.model.GroupDataEntity;
//import com.citigroup.cgti.c3par.reports.model.OutputEntity;
import com.citigroup.cgti.c3par.reports.model.DataSourceEntity;
import com.citigroup.cgti.c3par.reports.model.ReportColumnMetaEntity;
import com.citigroup.cgti.c3par.reports.model.ReportGroupEntity;
import com.citigroup.cgti.c3par.reports.model.ReportInnerFilterEntity;
import com.citigroup.cgti.c3par.reports.model.RequestedReportEntity;
import com.citigroup.cgti.c3par.reports.reportInterface.ReportException;
import com.mentisys.model.ManyAssociationList;


/**
 * The Class Util.
 *
 * @author Gerald Robinson
 *
 * </br>
 * <h1>Description</h1>
 */
public class Util implements Serializable{

    /** The log. */
    private static Logger log = Logger.getLogger(Util.class);

    /** The EQUAL. */
    public static String EQUAL = "=";

    /** The NOTEQUAL. */
    public static String NOTEQUAL = "<>";

    /** The GREATER. */
    public static String GREATER = ">";

    /** The LESSER. */
    public static String LESSER = "<";

    /** The GREATEREQUAL. */
    public static String GREATEREQUAL = ">=";

    /** The LESSEREQUAL. */
    public static String LESSEREQUAL = "<=";

    /** The ANDCONDITION. */
    public static String ANDCONDITION = "AND";

    /** The ORCONDITION. */
    public static String ORCONDITION = "OR";

    /** The SUMFUNCTION. */
    public static String SUMFUNCTION = "SUM";

    /** The AVERAGEFUNCTION. */
    public static String AVERAGEFUNCTION = "AVG";

    /** The COUNTFUNCTION. */
    public static String COUNTFUNCTION = "COUNT";

    /**
     * Convert to string.
     *
     * @param input the input
     * @param doesListContainsReportColumnMetaEntity the does list contains report column meta entity
     * @return the string
     */
    public String convertToString(List input,boolean doesListContainsReportColumnMetaEntity){
	StringBuffer output = new StringBuffer();
	if(doesListContainsReportColumnMetaEntity){
	    for (Iterator iter = input.iterator(); iter.hasNext();) {
		ReportColumnMetaEntity outputOriginalEntity = (ReportColumnMetaEntity)iter.next();
		output.append(","+outputOriginalEntity.getName());
	    }
	}else{
	    for (Iterator iter = input.iterator(); iter.hasNext();) {
		String inputString = (String)iter.next();
		output.append(","+inputString);
	    }
	}

	return (output.length()>0 ? output.toString().substring(1) : "");
    }


    /**
     * Checks if is column exist.
     *
     * @param output the output
     * @param originalList the original list
     * @return true, if is column exist
     */
    public boolean isColumnExist(String output,List originalList){
	Iterator iter = originalList.iterator();
	while(iter.hasNext()){
	    ReportColumnMetaEntity outputOriginalEntity = (ReportColumnMetaEntity)iter.next();
	    if(outputOriginalEntity.getName().trim().equals(output)){
		return true;
	    }
	}
	return false;
    }

    /**
     * Checks if is table exist.
     *
     * @param connection the connection
     * @param tableName the table name
     * @return true, if is table exist
     * @throws ReportException the report exception
     */
    public boolean isTableExist(Connection connection,String tableName) throws ReportException{
	try {
	    Statement stmt = connection.createStatement();
	    ResultSet rs = stmt.executeQuery("Select Report_ID from "+tableName);
	    return true;

	}catch(Exception e){
	    return false;
	}
    }


    /**
     * Make sql statement for row count.
     *
     * @param requestedReportEntity the requested report entity
     * @param startRowId the start row id
     * @return the string
     */
    public String makeSqlStatementForRowCount(RequestedReportEntity requestedReportEntity, long startRowId){
	StringBuffer sqlStatement = new StringBuffer("Select ");
	List columnList = requestedReportEntity.getColumnList();
	List groupList = null;
	int index = 0;
	try{
	    if(requestedReportEntity.getGroupBy()!=null){
		//			sqlStatement.append("DISTINCT");
		groupList = requestedReportEntity.getGroupBy();
		for (Iterator iterGroup = groupList.iterator(); iterGroup.hasNext();) {
		    ReportGroupEntity reportGroupEntity = (ReportGroupEntity) iterGroup.next();
		    String groupName = reportGroupEntity.getReportGroupColumnMeta().getName();
		    columnList.remove(groupName);
		    columnList.add(index,groupName);
		    index = index + 1;
		}
	    }


	    for (Iterator iter = columnList.iterator(); iter.hasNext();) {
		String columnName = (String) iter.next();
		if(sqlStatement.toString().trim().equals("Select") || sqlStatement.toString().trim().equals("Select DISTINCT"))
		    sqlStatement.append(" "+columnName);
		else
		    sqlStatement.append(" ,"+columnName);
	    }
	    sqlStatement.append(" from "+requestedReportEntity.getTableName());

	    if(requestedReportEntity.getReportMetaEntity().getReportsPackage().getIsCollection().booleanValue() &&
		    (requestedReportEntity.getDriverCollectionFilter()!=null && !requestedReportEntity.getDriverCollectionFilter().trim().equals(""))){
		if(requestedReportEntity.getCollectionDriverTableName().equals(requestedReportEntity.getTableName())){
		    sqlStatement.append(" Where (");
		    sqlStatement.append(formatCollectionFilterQuery(requestedReportEntity.getDriverCollectionFilter(),
			    requestedReportEntity.getDriverDsEntity(),""));
		    sqlStatement.append(" )");
		}else{
		    sqlStatement.append(" a ");
		    sqlStatement.append(" Where Exists ( select ");
		    sqlStatement.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());

		    sqlStatement.append(" from "+requestedReportEntity.getCollectionDriverTableName());
		    sqlStatement.append(" b Where a.");
		    sqlStatement.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());
		    sqlStatement.append(" = b.");
		    sqlStatement.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());
		    sqlStatement.append(" AND (");
		    sqlStatement.append(formatCollectionFilterQuery(requestedReportEntity.getDriverCollectionFilter(),
			    requestedReportEntity.getDriverDsEntity(),"b."));
		    sqlStatement.append(" )) ");
		}
	    }else if(requestedReportEntity.getReportFilterEntity()!=null){
		sqlStatement.append(" Where ");
		sqlStatement.append(getFilterQuery(requestedReportEntity));
		sqlStatement.append(" Order by Report_ID");
	    }else if(requestedReportEntity.getFilterString()!=null){
		sqlStatement.append(" Where (");
		sqlStatement.append(formatFilterQuery(requestedReportEntity));
		sqlStatement.append(" )");
		//sqlStatement.append(" Order by Report_ID");
	    }
	    if(requestedReportEntity.getCurrentPage()!=1){
		if(sqlStatement.indexOf(" Where ")>0){
		    sqlStatement.append(" and ");
		}else {
		    sqlStatement.append(" Where ");
		}
		sqlStatement.append(" Report_ID > " + startRowId);
	    }

	    //sqlStatement.append(" Order by Report_ID");


	}catch(Exception e){
	    log.error("Error while creating dynamic SQl :- " + e);

	}

	log.debug("SQL Query - " + sqlStatement.toString());
	return sqlStatement.toString();
    }

    /**
     * Make sql statement.
     *
     * @param requestedReportEntity the requested report entity
     * @param startRowId the start row id
     * @return the string
     */
    public String makeSqlStatement(RequestedReportEntity requestedReportEntity, long startRowId){
	StringBuffer sqlStatement = new StringBuffer("Select group_data,Report_Id ");
	List columnList = requestedReportEntity.getColumnList();
	List groupList = null;
	int index = 0;
	try{
	    if(requestedReportEntity.getGroupBy()!=null){
		//			sqlStatement.append(" group_data ");
		groupList = requestedReportEntity.getGroupBy();
		for (Iterator iterGroup = groupList.iterator(); iterGroup.hasNext();) {
		    ReportGroupEntity reportGroupEntity = (ReportGroupEntity)iterGroup.next();
		    String groupName = reportGroupEntity.getReportGroupColumnMeta().getName();
		    columnList.remove(groupName);
		    columnList.add(index,groupName);
		    index = index + 1;
		}
	    }


	    for (Iterator iter = columnList.iterator(); iter.hasNext();) {
		String columnName = (String) iter.next();
		if(sqlStatement.toString().trim().equals("Select"))
		    sqlStatement.append(" "+columnName);
		else
		    sqlStatement.append(" ,"+columnName);
	    }
	    sqlStatement.append(" from "+requestedReportEntity.getTableName());

	    if(requestedReportEntity.getReportMetaEntity().getReportsPackage().getIsCollection().booleanValue() &&
		    (requestedReportEntity.getDriverCollectionFilter()!=null && !requestedReportEntity.getDriverCollectionFilter().trim().equals(""))){
		if(requestedReportEntity.getCollectionDriverTableName().equals(requestedReportEntity.getTableName())){
		    sqlStatement.append(" Where (");
		    sqlStatement.append(formatCollectionFilterQuery(requestedReportEntity.getDriverCollectionFilter(),
			    requestedReportEntity.getDriverDsEntity(),""));
		    sqlStatement.append(" )");
		}else{
		    sqlStatement.append(" a ");
		    sqlStatement.append(" Where Exists ( select ");
		    sqlStatement.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());

		    sqlStatement.append(" from "+requestedReportEntity.getCollectionDriverTableName());
		    sqlStatement.append(" b Where a.");
		    sqlStatement.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());
		    sqlStatement.append(" = b.");
		    sqlStatement.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());
		    sqlStatement.append(" AND (");
		    sqlStatement.append(formatCollectionFilterQuery(requestedReportEntity.getDriverCollectionFilter(),
			    requestedReportEntity.getDriverDsEntity(),"b."));
		    sqlStatement.append(" )) ");
		}
	    }else if(requestedReportEntity.getReportFilterEntity()!=null){
		sqlStatement.append(" Where ");
		sqlStatement.append(getFilterQuery(requestedReportEntity));
		sqlStatement.append(" Order by Report_ID");
	    }else if(requestedReportEntity.getFilterString()!=null){
		sqlStatement.append(" Where (");
		sqlStatement.append(formatFilterQuery(requestedReportEntity));
		sqlStatement.append(" )");
		//sqlStatement.append(" Order by Report_ID");
	    }

	    if(requestedReportEntity.getCurrentPage()!=1){
		if(sqlStatement.indexOf(" Where ")>0){
		    sqlStatement.append(" and ");
		}else {
		    sqlStatement.append(" Where ");
		}
		sqlStatement.append(" Report_ID > " + startRowId);
	    }

	    sqlStatement.append(" Order by Report_ID");


	}catch(Exception e){
	    log.error("Error while creating dynamic SQl:- " + e);

	}

	log.debug("SQL Query - " + sqlStatement.toString());
	return sqlStatement.toString();
    }


    /**
     * Format filter query.
     *
     * @param requestedReportEntity the requested report entity
     * @return the string
     */
    public String formatFilterQuery(RequestedReportEntity requestedReportEntity){
	StringBuffer tempFilter = new StringBuffer(requestedReportEntity.getFilterString());
	String firstValue;
	String secondValue;
	while(tempFilter.indexOf("$")!=-1){
	    firstValue = getFirstValue(tempFilter.substring(tempFilter.lastIndexOf("$")+1));
	    secondValue = getSecondValue(tempFilter.substring(tempFilter.lastIndexOf("$")+1));
	    int valueSecondIndex = tempFilter.lastIndexOf("$") + tempFilter
	    .substring(tempFilter.lastIndexOf("$")).indexOf(secondValue);
	    tempFilter = tempFilter.replace(tempFilter.lastIndexOf("$"),tempFilter.lastIndexOf("$")+1,"");
	    if(isString(firstValue,requestedReportEntity.getDsEntity().getColumns())){
		tempFilter = tempFilter.replace(valueSecondIndex-1,valueSecondIndex+secondValue.length()-1,"'"+secondValue+"'");
	    }

	}

	return tempFilter.toString();
    }


    /**
     * Format collection filter query.
     *
     * @param filter the filter
     * @param dsEntity the ds entity
     * @param alias the alias
     * @return the string
     */
    public String formatCollectionFilterQuery(String filter, DataSourceEntity dsEntity, String alias){
	StringBuffer tempFilter = new StringBuffer(filter);
	String firstValue;
	String secondValue;
	while(tempFilter.indexOf("$")!=-1){
	    firstValue = getFirstValue(tempFilter.substring(tempFilter.lastIndexOf("$")+1));
	    secondValue = getSecondValue(tempFilter.substring(tempFilter.lastIndexOf("$")+1));
	    int valueSecondIndex = tempFilter.lastIndexOf("$") + tempFilter
	    .substring(tempFilter.lastIndexOf("$")).indexOf(secondValue);
	    tempFilter = tempFilter.replace(tempFilter.lastIndexOf("$"),tempFilter.lastIndexOf("$")+1,alias);
	    if(isString(firstValue,dsEntity.getColumns())){
		tempFilter = tempFilter.replace(valueSecondIndex-1+alias.length(),valueSecondIndex+secondValue.length()-1+alias.length(),"'"+secondValue+"'");
	    }

	}

	return tempFilter.toString();
    }


    /**
     * Format filter query for testing.
     *
     * @param requestedReportEntity the requested report entity
     * @return the string
     */
    public String formatFilterQueryForTesting(RequestedReportEntity requestedReportEntity){
	StringBuffer tempFilter = new StringBuffer(requestedReportEntity.getFilterString());
	//System.out.println("tempFilter=" +tempFilter);

	String firstValue;
	String secondValue;
	while(tempFilter.indexOf("$")!=-1){
	    firstValue = getFirstValue(tempFilter.substring(tempFilter.lastIndexOf("$")+1));
	    //System.out.println("firstValue=" +firstValue);
	    secondValue = getSecondValue(tempFilter.substring(tempFilter.lastIndexOf("$")+1));
	    //System.out.println("secondValue=" +secondValue);
	    if(secondValue.endsWith("(FTN")){
		secondValue.replaceAll("\\(FTN", "\\(FTN\\)");
	    }
	    if(secondValue.trim().equals("") || firstValue.trim().equals("")){
		return "invalid";
	    }
	    int valueSecondIndex = tempFilter.lastIndexOf("$") + 5;
	    tempFilter.replace(tempFilter.lastIndexOf("$"),tempFilter.lastIndexOf("$")+1+firstValue.length(),"1");
	    if(secondValue.startsWith("BETWEEN")){
		tempFilter.replace(tempFilter.lastIndexOf("BETWEEN"),tempFilter.lastIndexOf("BETWEEN")+39,"= 2");
	    }else{
		tempFilter.replace(valueSecondIndex-1,valueSecondIndex+secondValue.length()-1,"2");
	    }
	}
	return tempFilter.toString();
    }

    /**
     * Gets the first value.
     *
     * @param filter the filter
     * @return the first value
     */
    public String getFirstValue(String filter){
	log.debug("filter - " + filter);

	int indexEQUAL = filter.indexOf("=");
	int indexNOTEQUAL = filter.indexOf("!") ;
	int indexGREATER = filter.indexOf(">");
	int indexLESSER = filter.indexOf("<");
	int indexBETWEEN = filter.indexOf("BETWEEN");

	for (int i = 0; i < filter.length(); i++) {
	    if(i==indexEQUAL){
		filter = filter.substring(0,filter.indexOf("=")).trim();
		i = filter.length();
	    }else if(i==indexNOTEQUAL){
		filter = filter.substring(0,filter.indexOf("!")).trim();
		i = filter.length();
	    }else if(i==indexGREATER){
		filter = filter.substring(0,filter.indexOf(">")).trim();
		i = filter.length();
	    }else if(i==indexLESSER){
		filter = filter.substring(0,filter.indexOf("<")).trim();
		i = filter.length();
	    }else if(i==indexBETWEEN){
		filter = filter.substring(0,filter.indexOf("BETWEEN")).trim();
		i = filter.length();
	    }

	}
	return filter.trim();
    }

    /**
     * Gets the second value.
     *
     * @param filter the filter
     * @return the second value
     */
    public String getSecondValue(String filter){

	String subFilter = null;


	int indexEQUAL = filter.indexOf("=");
	int indexNOTEQUAL = filter.indexOf("!") ;
	int indexGREATER = filter.indexOf(">");
	int indexLESSER = filter.indexOf("<");
	int indexBETWEEN = filter.indexOf("BETWEEN");

	for (int i = 0; i < filter.length(); i++) {
	    if(i==indexEQUAL){
		subFilter = filter.substring(filter.indexOf("=")+1).trim();
		i = filter.length();
	    }else if(i==indexNOTEQUAL){
		subFilter = filter.substring(filter.indexOf("!")+1).trim();
		i = filter.length();
	    }else if(i==indexGREATER){
		subFilter = filter.substring(filter.indexOf(">")+1).trim();
		i = filter.length();
	    }else if(i==indexLESSER){
		subFilter = filter.substring(filter.indexOf("<")+1).trim();
		i = filter.length();
	    }else if(i==indexBETWEEN){
		subFilter = filter.substring(filter.indexOf("BETWEEN")).trim();
		i = filter.length();
	    }

	}

	if(subFilter.startsWith("=")||subFilter.startsWith(">")||subFilter.startsWith("<")){
	    subFilter = subFilter.substring(1).trim();
	}
	int indexAND = -1;
	int indexbracket = filter.trim().toUpperCase().indexOf(")");
	int indexOR = filter.trim().toUpperCase().indexOf(" OR") ;
	if(subFilter.startsWith("BETWEEN")){
	    if(filter.substring(filter.indexOf(" AND ")+5).trim().toUpperCase().indexOf(" AND ") != -1){
		indexAND = filter.substring(filter.indexOf(" AND ")).length() + 5 + filter.substring(filter.indexOf(" AND ")+5).trim().toUpperCase().indexOf(" AND");
	    }
	}else{
	    indexAND = filter.trim().toUpperCase().indexOf(" AND");
	}


	for (int i = 0; i < filter.length(); i++) {
	    if(i==indexbracket){
		subFilter = subFilter.substring(0,subFilter.indexOf(")"));
		i = filter.length();
	    }else if(i==indexOR){
		subFilter = subFilter.substring(0,subFilter.trim().toUpperCase().indexOf(" OR "));
		i = filter.length();
	    }else if(i==indexAND){
		subFilter = subFilter.substring(0,subFilter.trim().toUpperCase().indexOf(" AND "));
		i = filter.length();
	    }
	}

	return subFilter.trim();
    }


    /**
     * Gets the map.
     *
     * @param rs the rs
     * @param maxGroupSize the max group size
     * @param neededRows the needed rows
     * @param suppressColumnList the suppress column list
     * @param linkColumnList the link column list
     * @return the map
     * @throws SQLException the sQL exception
     * @throws ReportException the report exception
     */
    public Map getMap(ResultSet rs,int maxGroupSize, int neededRows, List suppressColumnList, Map linkColumnList)
    throws SQLException, ReportException {
	try{
	    ResultSetMetaData meta = rs.getMetaData();
	    List dataList = new ArrayList();
	    Map data = new TreeMap();
	    int numbers = 1;
	    int summaryRows = 0;
	    int columns = meta.getColumnCount();
	    String [] currentValue=null;
	    boolean isGrouped = false;
	    String summaryValue=null;
	    long rowSuppressed = 0;

	    Long rowNumber = Long.valueOf(0);

	    // Following commented block would add the columns names in the data set to be used as column headings.
	    // This was removed as the UI would take care of adding the column headings
	    //        for (int i=3;i<=columns;i++) {
	    //        	String columnName = meta.getColumnName(i);
	    //        	dataList.add(columnName);
	    //        }
	    //        data.put(Integer.valueOf(numbers),dataList);
	    //        numbers = numbers + 1;

	    if(maxGroupSize!=0){
		isGrouped = true;
	    }

	    String [] groupData = null;
	    int groupSize=-1;
	    int j = 3;
	    // data.size() - summaryRows gives the number of data rows included in the data set.
	    while((data.size()- summaryRows) < neededRows && rs.next()){
		if(isGrouped){
		    groupData = rs.getString(1).toString().split("/");
		    if(!groupData[0].trim().equals("Not Applicable")){
			groupSize = groupData.length - 1;
			summaryValue = groupData[groupSize];
		    }
		    j = maxGroupSize-(groupSize+1)+3;
		}
		dataList = new ArrayList(columns);
		if(currentValue==null){
		    currentValue = new String[columns+3];
		}

		addSpace(dataList,maxGroupSize-(groupSize+1));
		rowNumber = Long.valueOf(rs.getLong(2));
		for (int i=j;i<=columns;i++) {


		    /*if(meta.getColumnClassName(i).equals("Array")){
	        		dataList.add(rs.getArray(i));
	        	}else if(meta.getColumnClassName(i).indexOf("BigDecimal")!=-1){
	        		dataList.add(rs.getBigDecimal(i));
	    		}else if(meta.getColumnClassName(i).indexOf("Blob")!=-1){
	    			dataList.add(rs.getBlob(i));
	    		}else if(meta.getColumnClassName(i).indexOf("Boolean")!=-1){
	    			dataList.add(Boolean.valueOf(rs.getBoolean(i)));
	    		}else if(meta.getColumnClassName(i).indexOf("Byte")!=-1){
	    			dataList.add(new Byte(rs.getByte(i)));
	    		}else if(meta.getColumnClassName(i).indexOf("Clob")!=-1){
	    			dataList.add(rs.getClob(i));
	    		}else if(meta.getColumnClassName(i).indexOf("Date")!=-1){
	    			dataList.add(rs.getDate(i));
	    		}else if(meta.getColumnClassName(i).indexOf("Double")!=-1){
	    			dataList.add(new Double(rs.getDouble(i)));
	    		}else if(meta.getColumnClassName(i).indexOf("Float")!=-1){
	    			dataList.add(new Float(rs.getFloat(i)));
	    		}else if(meta.getColumnClassName(i).indexOf("Integer")!=-1){
	    			dataList.add(Integer.valueOf(rs.getInt(i)));
	    		}else if(meta.getColumnClassName(i).indexOf("Long")!=-1){
	    			dataList.add(Long.valueOf(rs.getLong(i)));
	    		}else if(meta.getColumnClassName(i).indexOf("Short")!=-1){
	    			dataList.add(new Short(rs.getShort(i)));
	    		}else if(meta.getColumnClassName(i).indexOf("String")!=-1){*/
		    List prevData = null;
		    boolean changed=false;
		    String columnName = rs.getString(i);

		    if(linkColumnList.keySet().contains(meta.getColumnName(i))){

			String url = linkColumnList.get(meta.getColumnName(i)) +""+columnName;

			columnName = "<B><U><a href=\"javascript:openLink('" + url + "')\">" + columnName + "</a></U></B>";


			log.debug("Column Name :- "+columnName);

		    }

		    log.debug("Util.getMap() Column - "+meta.getColumnName(i)+ " is Suppressed - "+suppressColumnList.contains(meta.getColumnName(i)));
		    if(data.size()>=1 && isGrouped && i-3>=maxGroupSize && suppressColumnList.contains(meta.getColumnName(i))){
			removeDuplicates(dataList,data,numbers,columnName,i);
		    }else{
			dataList.add(columnName);
		    }
		    /*}else if(meta.getColumnClassName(i).indexOf("Time")!=-1){
	    			dataList.add(rs.getTime(i));
	    		}else if(meta.getColumnClassName(i).indexOf("Timestamp")!=-1){
	    			dataList.add(rs.getTimestamp(i));
	    		}*/

		    if(i==(maxGroupSize-groupSize)+2 && summaryValue!="Not Applicable" && groupSize>=0){

			if(!summaryValue.trim().equalsIgnoreCase("none")){
			    dataList.add("Summary");
			    dataList.add("-");
			    dataList.add(summaryValue);
			}else{
			    dataList.add("<!--Summary-->");
			    dataList.add("<!----->");
			    dataList.add("<!--"+summaryValue+"-->");
			}

			data.put(Integer.valueOf(numbers),dataList);
			// the following method invocation fills the
			// dataList (i.e. summary row) with blank spaces. The number of spaces
			// to fill is computed using the total result set columns
			// minus (the already filled columns count + 2). The number 2 is for the
			// additional columns in the result set used for grouping (group_data, Report_Id)
			addSpace(dataList, (columns-dataList.size()-2));
			dataList = new ArrayList(columns);
			numbers = numbers + 1;
			// this is a summary row. so increment the summary row counter
			// this counter is used to identify the number of rows included in this data set
			summaryRows ++ ;
			if(groupSize>0){
			    summaryValue = groupData[groupSize-1];
			}
			groupSize = groupSize - 1;
			addSpace(dataList,maxGroupSize-(groupSize+1));
		    }
		}
		boolean dataPresent = false;
		for (int i = 0; i < dataList.size(); i++) {
		    Object dataElement = dataList.get(i);
		    if(dataElement != null && dataElement.toString().trim().length()>0){
			dataPresent = true;
			break;
		    }
		}

		if(dataPresent){
		    data.put(Integer.valueOf(numbers),dataList);
		    numbers = numbers + 1;
		}else{
		    rowSuppressed = rowSuppressed +1;
		}

	    }
	    data.put(Integer.valueOf(data.size()+1),rowNumber);
	    data.put(Integer.valueOf(data.size()+1),Long.valueOf(rowSuppressed));
	    return data;
	}catch(SQLException c){
	    log.error(c);
	    throw c;
	}catch(ReportException c){
	    log.error(c);
	    throw c;
	}


    }

    /**
     * Adds the space.
     *
     * @param dataList the data list
     * @param size the size
     */
    public void addSpace(List dataList,int size){
	for (int i = 0; i < size; i++) {
	    dataList.add(" ");
	}
    }


    /**
     * Removes the duplicates.
     *
     * @param dataList the data list
     * @param data the data
     * @param rowNumber the row number
     * @param columnName the column name
     * @param columnNumber the column number
     * @throws ReportException the report exception
     */
    public void removeDuplicates(List dataList,Map data,
	    int rowNumber,String columnName,int columnNumber)throws ReportException{
	//try{
	List prevData;
	boolean changed=false;
	int k = 1;
	int dataSize = dataList.size();
	prevData = (ArrayList)data.get(Integer.valueOf(rowNumber-k));

	while(!prevData.contains("Summary") && !prevData.contains("<!--Summary-->")){
	    if(prevData.size()>columnNumber-3){
		Object pdata = prevData.get(columnNumber-3);
		//String str = rs.getString(columnNumber);
		String str = columnName;
		str = (str == null ? "" : str.trim());
		if(pdata!= null && pdata.toString().trim().equals(str)){
		    dataList.add(" ");
		    changed=true;
		    break;
		}
	    }
	    k = k + 1;
	    if(rowNumber-k<0){
		break;
	    }
	    prevData = (ArrayList)data.get(Integer.valueOf(rowNumber-k));
	    if(prevData == null){
		break;
	    }
	}

	k = rowNumber-k;
	if(!changed){
	    while(k<rowNumber){
		k = k+1;
		prevData = (ArrayList)data.get(Integer.valueOf(k));
		if(prevData!=null){
		    if(prevData.size()>columnNumber-3){
			Object pdata = prevData.get(columnNumber-3);
			//String str = rs.getString(columnNumber);
			String str = columnName;
			if(pdata!= null && pdata.toString().trim().equals("")){
			    prevData.set(columnNumber-3,str);
			    dataList.add(" ");
			    k = rowNumber;
			    changed=true;
			}
		    }
		}
	    }
	}

	if(!changed){
	    //dataList.add(rs.getString(columnNumber));
	    dataList.add(columnName);

	}
	/*}catch(SQLException se){
			throw new ReportException("Error while checking for duplicates");
		}*/

    }

    /**
     * Check.
     *
     * @param sign the sign
     * @param isCondition the is condition
     * @return true, if successful
     */
    public boolean check(String sign,boolean isCondition){
	if(isCondition){
	    if(sign.equals(Util.ANDCONDITION)||sign.equals(Util.ORCONDITION)){
		return true;
	    }
	}else{
	    if(sign.equals(Util.EQUAL)||sign.equals(Util.NOTEQUAL)||sign.equals(Util.GREATER)||
		    sign.equals(Util.GREATEREQUAL)||sign.equals(Util.LESSER)||sign.equals(Util.LESSEREQUAL)){
		return true;
	    }
	}
	return false;
    }

    /**
     * Checks if is function exist.
     *
     * @param function the function
     * @return true, if is function exist
     */
    public boolean isFunctionExist(String function){
	if(function.equals(Util.SUMFUNCTION)||function.equals(Util.AVERAGEFUNCTION)
		||function.equals(Util.COUNTFUNCTION)){
	    return true;
	}
	return false;
    }

    /**
     * Gets the group queries.
     *
     * @param requestedReportEntity the requested report entity
     * @return the group queries
     */
    public Map getGroupQueries(RequestedReportEntity requestedReportEntity){
	StringBuffer filterBuffer = new StringBuffer();
	String filter = null;
	//		GroupDataEntity groupDataEntity = requestedReportEntity.getGroupBy();
	String tableName = requestedReportEntity.getTableName();
	String columnNames = null;
	Map queries = new HashMap();

	List groupColumn = new ArrayList();//groupDataEntity.getGroupColumnName();
	List function = new ArrayList();//groupDataEntity.getFunction();
	List summary = new ArrayList();//groupDataEntity.getSummaryColumnName();

	ManyAssociationList groupData = requestedReportEntity.getReportMetaEntity().getGroupData();



	Iterator iter = groupData.iterator();
	while (iter.hasNext()) {
	    ReportGroupEntity reportGroupEntity = (ReportGroupEntity) iter.next();
	    groupColumn.add(reportGroupEntity.getReportGroupColumnMeta().getName());
	    function.add(reportGroupEntity.getFunction());
	    if(reportGroupEntity.getFunction().trim().equalsIgnoreCase("none")){
		summary.add("none");
	    }else{
		summary.add(reportGroupEntity.getSummary().getReportSummaryColumnMeta().getName());
	    }

	}

	int size = groupColumn.size();
	columnNames = convertToString(groupColumn,false);
	int i = size-1;
	while(i>=0){
	    String element = null;

	    StringBuffer sql = new StringBuffer("update ");
	    sql.append(tableName);
	    sql.append(" a set group_data = (select ");
	    if(i!=size-1){
		sql.append("TRIM(a.group_data) || '/' || ");
	    }
	    if(function.get(i).toString().trim().equalsIgnoreCase("none") || summary.get(i).toString().trim().equalsIgnoreCase("none")){
		sql.append("'none'");
	    }else{
		sql.append(function.get(i).toString());
		sql.append("(");
		sql.append(summary.get(i).toString());
		sql.append(") ");
	    }
	    sql.append(" from ");
	    sql.append(tableName);
	    sql.append(" b where ");


	    if(requestedReportEntity.getReportMetaEntity().getReportsPackage().getIsCollection().booleanValue() &&
		    (requestedReportEntity.getDriverCollectionFilter()!=null && !requestedReportEntity.getDriverCollectionFilter().trim().equals(""))){
		if(requestedReportEntity.getCollectionDriverTableName().equals(requestedReportEntity.getTableName())){
		    filterBuffer.append(" (");
		    filterBuffer.append(formatCollectionFilterQuery(requestedReportEntity.getDriverCollectionFilter(),
			    requestedReportEntity.getDriverDsEntity(),""));
		    filterBuffer.append(" )");
		    sql.append(filterBuffer);
		    filter = filterBuffer.toString();
		}else{

		    sql.append("Exists ( select ");
		    sql.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());

		    sql.append(" from "+requestedReportEntity.getCollectionDriverTableName());
		    sql.append(" c Where b.");
		    sql.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());
		    sql.append(" = c.");
		    sql.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());
		    sql.append(" AND (");
		    sql.append(formatCollectionFilterQuery(requestedReportEntity.getDriverCollectionFilter(),
			    requestedReportEntity.getDriverDsEntity(),"c."));
		    sql.append(" )) ");


		    filterBuffer.append("Exists ( select ");
		    filterBuffer.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());

		    filterBuffer.append(" from "+requestedReportEntity.getCollectionDriverTableName());
		    filterBuffer.append(" e Where d.");
		    filterBuffer.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());
		    filterBuffer.append(" = e.");
		    filterBuffer.append(requestedReportEntity.getReportMetaEntity().getReportsPackage().getDriverColumn());
		    filterBuffer.append(" AND (");
		    filterBuffer.append(formatCollectionFilterQuery(requestedReportEntity.getDriverCollectionFilter(),
			    requestedReportEntity.getDriverDsEntity(),"e."));



		    filterBuffer.append(" )) ");

		    filter = filterBuffer.toString();
		}
	    }else if(requestedReportEntity.getReportFilterEntity()!=null && sql.toString().endsWith("b where ")){
		sql.append("( ");
		filter = getFilterQuery(requestedReportEntity);
		sql.append(filter);
		sql.append(") ");

	    }else if(requestedReportEntity.getFilterString()!=null && sql.toString().endsWith("b where ")){
		sql.append("( ");
		filter = formatFilterQuery(requestedReportEntity);
		sql.append(filter);
		sql.append(") ");
	    }

	    for (int j = i; j >= 0; j--) {
		element = groupColumn.get(j).toString();
		if(!sql.toString().endsWith("b where ")){
		    sql.append(" and ");
		}
		sql.append("a.");
		sql.append(element);
		sql.append("=b.");
		sql.append(element);
	    }
	    sql.append(" group by ");
	    sql.append(columnNames);
	    sql.append(") WHERE (a.report_id in(Select min(report_id) from ");
	    sql.append(tableName);
	    if(requestedReportEntity.getReportFilterEntity()!=null
		    || requestedReportEntity.getFilterString()!=null) {
		sql.append(" d Where ");
		sql.append(filter);
	    }

	    sql.append(" group by ");
	    sql.append(columnNames);
	    sql.append("))");

	    queries.put(groupColumn.get(i).toString(),sql.toString());
	    if(columnNames.lastIndexOf(",")!=-1)
		columnNames = columnNames.substring(0,columnNames.lastIndexOf(","));
	    i = i-1;


	}
	return queries;
    }


    /**
     * Gets the filter query.
     *
     * @param requestedReportEntity the requested report entity
     * @return the filter query
     */
    public String getFilterQuery(RequestedReportEntity requestedReportEntity){
	StringBuffer sql = new StringBuffer();
	try {
	    sql.append(" (");
	    sql.append(getFilter(requestedReportEntity));
	    sql.append(") ");
	    Map reportIndex = requestedReportEntity.getReportIndex();
	    List reportList = null;
	    if(requestedReportEntity.isNextData() && requestedReportEntity.getCurrentPage()!=1){
		sql.append("and (Report_ID > ");
		reportList = (ArrayList)reportIndex.get(
			Long.valueOf(requestedReportEntity.getCurrentPage()-1));
		sql.append(reportList.get(1).toString());
		sql.append(")");
	    }else{
		if(requestedReportEntity.getCurrentPage()!=1){
		    sql.append(" and ");
		    sql.append("(Report_ID > ");
		    reportList = (ArrayList)reportIndex.get(
			    Long.valueOf(requestedReportEntity.getCurrentPage()));
		    sql.append(reportList.get(0).toString());
		    sql.append(" and Report_ID < ");
		    sql.append(reportList.get(1).toString());
		    sql.append(")");
		}
	    }
	    return sql.toString();
	}catch(ReportException re){
	    log.error("Cannot create Filter Query :- " + re);
	    return null;
	}
    }

    /**
     * Gets the filter.
     *
     * @param requestedReportEntity the requested report entity
     * @return the filter
     * @throws ReportException the report exception
     */
    public String getFilter(RequestedReportEntity requestedReportEntity) throws ReportException{
	StringBuffer output = new StringBuffer();
	List reportInnerFilters = requestedReportEntity.
	getReportFilterEntity().getReportInnerFilters();
	List condition = requestedReportEntity.
	getReportFilterEntity().getCondition();

	for (int i = 0; i < reportInnerFilters.size(); i++) {
	    ReportInnerFilterEntity reportInnerFilter =
		(ReportInnerFilterEntity)reportInnerFilters.get(i);
	    if(i!=0){
		if(check(condition.get(i-1).toString(),true)){
		    output.append(" ");
		    output.append(condition.get(i-1).toString());
		    output.append(" ");
		}else {
		    throw new ReportException("Invalid Condition");
		}
	    }
	    output.append("(");
	    output.append(getInnerFilter(requestedReportEntity,reportInnerFilter));
	    output.append(")");
	}
	return output.toString();
    }

    /**
     * Gets the inner filter.
     *
     * @param requestedReportEntity the requested report entity
     * @param reportInnerFilter the report inner filter
     * @return the inner filter
     * @throws ReportException the report exception
     */
    public String getInnerFilter(RequestedReportEntity requestedReportEntity,
	    ReportInnerFilterEntity reportInnerFilter) throws ReportException{
	String columnName=null;
	String comparedColumnName=null;

	List columnNames = reportInnerFilter.getColumnNames();
	List isCompareToColumn = reportInnerFilter.getCompareToColumn();
	List compareValue = reportInnerFilter.getCompareValue();
	List condition = reportInnerFilter.getCondition();
	List outerCondition = reportInnerFilter.getOuterCondition();
	StringBuffer output = new StringBuffer();
	for (int i = 0; i < columnNames.size();i++) {
	    columnName = (String)columnNames.get(i);
	    if (isCompareToColumn.get(i).toString()=="TRUE"){
		comparedColumnName = (String)compareValue.get(i);
		if(i!=0){
		    output.append(" ");
		    if(check(outerCondition.get(i-1).toString(),true)){
			output.append(outerCondition.get(i-1));
		    }else{
			throw new ReportException("Invalid condition value");
		    }
		    output.append(" ");
		}
		output.append(columnName);
		if(check(condition.get(i).toString(),false)){
		    output.append(condition.get(i).toString());
		}else{
		    throw new ReportException("Invalid compare sign");
		}
		output.append(comparedColumnName);
	    }else{
		if(i!=0){
		    output.append(" ");
		    if(check(outerCondition.get(i-1).toString(),true)){
			output.append(outerCondition.get(i-1));
		    }else{
			throw new ReportException("Invalid condition value");
		    }
		    output.append(" ");
		}
		output.append(columnName);
		if(check(condition.get(i).toString(),false)){
		    output.append(condition.get(i).toString());
		}else{
		    throw new ReportException("Invalid compare sign");
		}
		if(isStringOrDate(columnName,
			requestedReportEntity.getDsEntity().getColumns())){
		    output.append("'");
		    output.append(compareValue.get(i).toString());
		    output.append("'");
		}else{
		    output.append(compareValue.get(i).toString());
		}

	    }
	}
	return output.toString();
    }



    /**
     * Checks if is string.
     *
     * @param value the value
     * @param outputList the output list
     * @return true, if is string
     */
    public boolean isString(String value,List outputList){
	Iterator iter = outputList.iterator();
	while(iter.hasNext()){
	    ReportColumnMetaEntity outputOriginalEntity = (ReportColumnMetaEntity)iter.next();
	    if(outputOriginalEntity.getName().trim().equals(value)){
		if(outputOriginalEntity.getDataType().trim().indexOf("String")!=-1){
		    return true;
		}
	    }
	}
	return false;
    }



    /**
     * Checks if is string or date.
     *
     * @param value the value
     * @param outputList the output list
     * @return true, if is string or date
     */
    public boolean isStringOrDate(String value,List outputList){
	Iterator iter = outputList.iterator();
	while(iter.hasNext()){
	    ReportColumnMetaEntity outputOriginalEntity = (ReportColumnMetaEntity)iter.next();
	    if(outputOriginalEntity.getName().trim().equals(value)){
		if(outputOriginalEntity.getDataType().trim().indexOf("String")!=-1
			||outputOriginalEntity.getDataType().trim().indexOf("Date")!=-1){
		    return true;
		}
	    }
	}
	return false;
    }

    /*public boolean isColumnSuppressable(){
	}*/

    /**
     * Replace in string buffer.
     *
     * @param searchBuffer the search buffer
     * @param searchFor the search for
     * @param replaceWith the replace with
     * @return the string
     */
    public String replaceInStringBuffer(StringBuffer searchBuffer, String searchFor, String replaceWith){
	searchBuffer.replace(searchBuffer.toString().toUpperCase().indexOf(searchFor.toUpperCase()),
		searchBuffer.toString().toUpperCase().indexOf(searchFor.toUpperCase())
		+ searchFor.length(), replaceWith);


	return searchBuffer.toString();


    }
    
    public static String filterCCRId(String ccrIdRecdFromCMP){
        //log.debug("CCR Received from CMP is "+ ccrIdRecdFromCMP);
        String cleanedUpCCRID = ccrIdRecdFromCMP;
        //check for point.
        int indexOfDecimal = ccrIdRecdFromCMP.indexOf(".");
        if(indexOfDecimal!= -1){
              cleanedUpCCRID = ccrIdRecdFromCMP.substring(0, indexOfDecimal);
        }
        cleanedUpCCRID = cleanedUpCCRID.replaceAll("[^0-9]","");
        try{
              if(cleanedUpCCRID.compareTo(ccrIdRecdFromCMP)!=0)
              {
                    
                    log.info("CCR ID has been converted from " +ccrIdRecdFromCMP+ " to "+cleanedUpCCRID );
              }
        }catch(Exception e){
              log.error("Exception occured while converting CCR id from CMP ",e);
        }
        return cleanedUpCCRID;
  }

}
