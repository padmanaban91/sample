package com.citigroup.cgti.c3par.controller.businessjustification;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.businessjustification.domain.ApprovalReviewProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class ApprovalReviewController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	

	@Autowired
	ApprovalReviewProcess approvalReviewProcess;

	@RequestMapping(value = "/reviewcomments.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String reviewComments(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		log.debug("Entering into reviewComments()..");

		String result = "c3par.review.review_comments";

		String action = request.getParameter("action");
		String type = request.getParameter("type");
		
		Util util = new Util();
		if (type == null || type.equalsIgnoreCase("null")) {
			type = "";
		}

		if (action == null) {
			action = request.getParameter("actionArg");
		}

		if (action != null) {

			if (action.equalsIgnoreCase("COMMENT")
					|| action.equalsIgnoreCase("COMMENT_NEXT")
					|| action.equalsIgnoreCase("COMMENT_PREV")) {

				try {
					String requestId = request.getParameter("requestId");

					if (requestId == null) {

						requestId = request.getParameter("requestIdArg");
					}

					String version_id = "1";
					
					Long tirequestId = Long.valueOf(request.getSession()
							.getAttribute("tireqid").toString());

					log.info("tirequestId::" + tirequestId);

					TIRequest tirequest = getApprovalReviewProcess().getTIRequestDetails(
							tirequestId);

					log.debug("The tirequest id: " + tirequest.getId());
					
					request.setAttribute("tirequestId", tirequest.getId());

					HashMap<String, String> hp1 = getApprovalReviewProcess().fetchRequestInfo(
							requestId, action);
					if (hp1.containsKey("REQ_ID")
							&& !((String) hp1.get("REQ_ID")).equals(""))
						requestId = (String) hp1.get("REQ_ID");
					if (hp1.containsKey("VERSION_ID")
							&& !((String) hp1.get("VERSION_ID")).equals(""))
						version_id = (String) hp1.get("VERSION_ID");

					request.setAttribute("VERSION_ID", version_id);

					ArrayList<HashMap<String, String>> sowCmpDet = new ArrayList<HashMap<String, String>>();
					if (tirequest != null && tirequest.getTiProcess() != null
							&& tirequest.getTiProcess().getId() != null) {
						sowCmpDet = util.getSOWCMPDetailsForAllVersions(tirequest.getTiProcess().getId());
					}
					request.setAttribute("SOW_CMP_DET", sowCmpDet);

					if (requestId != null) {
						Map<String,String> hp = null;

						hp = getApprovalReviewProcess().extractReviewComments(
								Long.parseLong(requestId));

						log.debug("Review Comments Map: "+hp);
						request.setAttribute("COMMENT_MAP", hp);
						request.setAttribute("requestId", requestId);
					}

				} catch (Exception ex) {

				}
				return result;
			}

			log.debug("Exit from reviewComments()..");
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/reviewdiscussion.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String reviewDiscussion(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		log.debug("Entering into reviewDiscussion()..");

		String result = "c3par.review.review_comments_more";

		String action = request.getParameter("action");
		String type = request.getParameter("type");
		HttpSession session = request.getSession();
		
		Long tirequestId = Long.valueOf(request.getSession()
				.getAttribute("tireqid").toString());

		log.info("tirequestId::" + tirequestId);

		TIRequest tirequest = getApprovalReviewProcess().getTIRequestDetails(
				tirequestId);

		log.debug("The tirequest id: " + tirequest.getId());
		
		request.setAttribute("tirequest", tirequest);
		

		if (type == null || type.equalsIgnoreCase("null")) {
			type = "";
		}

		if (action == null) {
			action = request.getParameter("actionArg");
		}

		if (action.equalsIgnoreCase("review_more")
				|| action.equalsIgnoreCase("review_more_next")
				|| action.equalsIgnoreCase("review_more_prev")
				|| action.equalsIgnoreCase("review_more_ip")) {

			String tiRequestId = null;
			if (session.getAttribute("requestId") != null) {
				tiRequestId = (String) session.getAttribute("requestId");
			} else if (tirequest != null) {
				tiRequestId = tirequest.getId().toString();
			}
			
			String processType = null;
			if (tirequest != null)
				processType = tirequest.getTiProcess().getTiprocessType().getProcessType();

			int currentPage = 0;
			if (action.equalsIgnoreCase("review_more")
					|| action.equalsIgnoreCase("review_more_ip")) {
				tiRequestId = request.getParameter("requestId");

				if (tiRequestId == null) {

					tiRequestId = request.getParameter("requestIdArg");
				}

				session.setAttribute("requestId", tiRequestId);

			}
			if (action.equalsIgnoreCase("review_more")
					|| action.equalsIgnoreCase("review_more_ip")) {
				currentPage = 1;
			} else if (action.equalsIgnoreCase("review_more_next")) {
				currentPage = ((Integer) session.getAttribute("currentPage"))
						.intValue() - 1;
			} else if (action.equalsIgnoreCase("review_more_prev")) {
				currentPage = ((Integer) session.getAttribute("currentPage"))
						.intValue() + 1;
			}

			if (tiRequestId != null) {

				List<Object> approval_list = null;
				try {
					Long tireq = Long.valueOf(tiRequestId);
					if (action.equalsIgnoreCase("review_more")) {
						int app_count = 0;
						app_count = getApprovalReviewProcess().getCount(
								"AllDiscussion", tireq, null);
						if (app_count > 1)
							app_count = app_count - 1;
						session.setAttribute("app_count",
								Integer.valueOf(app_count));
					}
					approval_list = (List<Object>) getApprovalReviewProcess().getAllDiscussions("AllDiscussion",
							tireq, null, currentPage, 10);
					log.debug("approval_list.size(): " + approval_list.size());
				} catch (Exception e) {
					log.error("Problen while getting approvals for "
							+ tiRequestId + " " + " >> " + e);
				}

				session.setAttribute("approval_list", approval_list);
				session.setAttribute("currentPage",
						Integer.valueOf(currentPage));
			}
			if (processType != null && processType.equalsIgnoreCase("IP")) {
				result = "c3par.review.review_comments_more_IP";
			}

		}

		log.debug("Exit from reviewDiscussion().....");

		return result;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/reviewaddinfo.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String reviewAddtionalInfo(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		log.debug("Entering into reviewAddtionalInfo()..");

		String result = "c3par.review.review_comments";
		
		Long tirequestId = Long.valueOf(request.getSession()
				.getAttribute("tireqid").toString());

		log.info("tirequestId::" + tirequestId);

		TIRequest tirequest = getApprovalReviewProcess().getTIRequestDetails(
				tirequestId);

		log.debug("The tirequest id: " + tirequest.getId());
		
		request.setAttribute("tirequestId", tirequest.getId());

		String action = request.getParameter("action");
		String type = request.getParameter("type");
		
		Util util = new Util();
	
		if (type == null || type.equalsIgnoreCase("null")) {
			type = "";
		}

		if (action != null) {

			if (action.equalsIgnoreCase("INFO")
					|| action.equalsIgnoreCase("INFO_IP")) {
				String processType = null;
				try {
					String requestId = request.getParameter("requestId");
					String version_id = "1";
					

					if (tirequest != null)
						processType = tirequest.getTiProcess().getTiprocessType()
								.getProcessType();
					HashMap<String,String> hp1 = getApprovalReviewProcess().fetchRequestInfo(
							requestId, action);
					if (hp1.containsKey("REQ_ID")
							&& !((String) hp1.get("REQ_ID")).equals(""))
						requestId = (String) hp1.get("REQ_ID");
					if (hp1.containsKey("VERSION_ID")
							&& !((String) hp1.get("VERSION_ID")).equals(""))
						version_id = (String) hp1.get("VERSION_ID");

					request.setAttribute("VERSION_ID", version_id);

					ArrayList<HashMap<String, String>> sowCmpDet = new ArrayList<HashMap<String, String>>();
					Map<String, String> temp = new HashMap<String, String>();
					if (tirequest != null && tirequest.getTiProcess() != null
							&& tirequest.getTiProcess().getId() != null) {
						sowCmpDet = util.getSOWCMPDetailsForAllVersions(tirequest.getTiProcess()
								.getId());
						temp = util.getTempAppAndRANum(tirequest.getId());
					}
					request.setAttribute("SOW_CMP_DET", sowCmpDet);
					request.setAttribute("TEMP_RA", temp);

					if (requestId != null) {
						Map<String, String> hp = null;
						if (action.equalsIgnoreCase("INFO"))
							hp = getApprovalReviewProcess().extractReviewInfo(
									Long.parseLong(requestId));
						else if (action.equalsIgnoreCase("INFO_IP"))
							hp = getApprovalReviewProcess()
									.extractReviewInfoForIP(
											Long.parseLong(requestId));

						request.setAttribute("COMMENT_MAP", hp);
						request.setAttribute("requestId", requestId);
					}

					if (action.equalsIgnoreCase("INFO_IP")
							|| (processType != null && processType
									.equalsIgnoreCase("IP"))) {
						result = "c3par.define.ip.reviewcomments";
					}

				} catch (Exception ex) {
				}

			}
		}

		log.debug("Exit from reviewAddtionalInfo()..");

		return result;
	}

	public ApprovalReviewProcess getApprovalReviewProcess() {
		return approvalReviewProcess;
	}

	public void setApprovalReviewProcess(
			ApprovalReviewProcess approvalReviewProcess) {
		this.approvalReviewProcess = approvalReviewProcess;
	}

}
