package com.citigroup.cgti.c3par.webtier.sessionmgmt;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;


/**
 * The Class CCRRequest.
 */
public class CCRRequest extends HttpServletRequestWrapper{

    /**
     * Instantiates a new cCR request.
     *
     * @param request the request
     */
    public CCRRequest(HttpServletRequest request) {
	super(request);
	// TODO Auto-generated constructor stub
    }

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpServletRequestWrapper#getRemoteUser()
     */
    public String getRemoteUser() {
	String remoteUser = super.getRemoteUser();
	if (remoteUser == null || "".equals(remoteUser.trim())) {
	    remoteUser = super.getHeader("Proxy-Remote-User");
	}
	return remoteUser;
    }

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpServletRequestWrapper#getQueryString()
     */
    public String getQueryString() {
	String queryString = super.getQueryString();
	return queryString;
    }

}
