/*
 * Created on Jun 6, 2005
 *
 */

package com.citigroup.cgti.c3par.reports.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.citigroup.cgti.c3par.reports.model.DataSourceEntity;
//import com.citigroup.cgti.c3par.reports.model.GroupDataEntity;
//import com.citigroup.cgti.c3par.reports.model.OutputEntity;
import com.citigroup.cgti.c3par.reports.model.ReportInnerFilterEntity;
import com.citigroup.cgti.c3par.reports.model.RequestedReportEntity;
import com.citigroup.cgti.c3par.reports.model.SQLStatementEntity;
import com.citigroup.cgti.c3par.reports.reportImpl.DefaultReportData;
import com.citigroup.cgti.c3par.reports.reportInterface.ReportData;
import com.citigroup.cgti.c3par.reports.reportInterface.ReportException;
import com.citigroup.cgti.c3par.reports.util.DBUtil;
import com.citigroup.cgti.c3par.reports.util.Util;
import org.apache.log4j.Logger;


/**
 * The Class RequestReportDAO.
 *
 * @author Gerald Robinson
 * 
 * </br>
 * <h1>Description</h1>
 */
public class RequestReportDAO implements Serializable{

    /** The requested report entity. */
    private RequestedReportEntity requestedReportEntity;

    //	private Util util;

    /** The log. */
    private static Logger log = Logger.getLogger(RequestReportDAO.class);

    /**
     * Instantiates a new request report dao.
     *
     * @param requestedReportEntity the requested report entity
     */
    public RequestReportDAO(RequestedReportEntity requestedReportEntity) {
	//		util = new Util();
	this.requestedReportEntity = requestedReportEntity;
    }

    /**
     * Initialise.
     *
     * @throws ReportException the report exception
     */
    public void initialise() throws ReportException {
	// 		Connection connection = DBUtil.getConnection(requestedReportEntity.getJndiName());
	if(requestedReportEntity.getDsEntity().getDiscriminator().equals("SQLStmt")){
	    // MOVED TO SQLStatementImpl where it belongs			
	    //			try{
	    //				StringBuffer command = new StringBuffer();
	    //				if(util.isTableExist(connection,requestedReportEntity.getTableName())) {
	    //					command.append("Drop table ");
	    //					command.append(requestedReportEntity.getTableName());
	    //					Statement stmt = connection.createStatement();
	    //					stmt.executeUpdate(command.toString());
	    //					command.delete(0,command.length());
	    //				}
	    //				command.append("Create table ");
	    //				command.append(requestedReportEntity.getTableName());
	    //				command.append(" AS ");
	    //				command.append(requestedReportEntity.getSourceData());
	    //				Statement stmt = connection.createStatement();
	    //				stmt.executeUpdate(command.toString());
	    //			}catch(SQLException e){
	    //				throw new ReportException("Error Creating the table:"+requestedReportEntity.getTableName());
	    //			}finally{
	    //				DBUtil.closeConnection(connection);
	    //			}
	}else {
	    //			 MOVED TO StoredProcedureImpl where it belongs				
	    //			Map inputs = requestedReportEntity.getInputs();
	    //			int size = inputs.size();
	    //			String procName = requestedReportEntity.getSourceData();
	    //			StringBuffer command = new StringBuffer();
	    //			command.append("{call ");
	    //			command.append(procName);
	    //			command.append("(");
	    //			for (int i = 1; i <= size; i++) {
	    //				if(i==1){
	    //					command.append("?");
	    //				}else{
	    //					command.append(", ?");
	    //				}
	    //			}
	    //			command.append(")}");
	    //			
	    //			try {
	    //				CallableStatement cs = connection.prepareCall(command.toString());
	    //				Integer key=null;
	    //				Object value=null;
	    //				for (int i = 1; i <= size; i++) {
	    //					key = Integer.valueOf(i);
	    //					value = inputs.get(key); 
	    //					if(value instanceof Array){
	    //						cs.setArray(key.intValue(),(Array)value);
	    //					}else if(value instanceof BigDecimal){
	    //						cs.setBigDecimal(key.intValue(),(BigDecimal)value);
	    //					}else if(value instanceof Blob){
	    //						cs.setBlob(key.intValue(),(Blob)value);
	    //					}else if(value instanceof Boolean){
	    //						cs.setBoolean(key.intValue(),((Boolean)value).booleanValue());
	    //					}else if(value instanceof Byte){
	    //						cs.setByte(key.intValue(),((Byte)value).byteValue());
	    //					}else if(value instanceof Clob){
	    //						cs.setClob(key.intValue(),(Clob)value);
	    //					}else if(value instanceof Date){
	    //						cs.setDate(key.intValue(),(Date)value);
	    //					}else if(value instanceof Double){
	    //						cs.setDouble(key.intValue(),((Double)value).doubleValue());
	    //					}else if(value instanceof Float){
	    //						cs.setFloat(key.intValue(),((Float)value).floatValue());
	    //					}else if(value instanceof Integer){
	    //						cs.setInt(key.intValue(),((Integer)value).intValue());
	    //					}else if(value instanceof Long){
	    //						cs.setLong(key.intValue(),((Long)value).longValue());
	    //					}else if(value instanceof Short){
	    //						cs.setShort(key.intValue(),((Short)value).shortValue());
	    //					}else if(value instanceof String){
	    //						cs.setString(key.intValue(),(String)value);
	    //					}else if(value instanceof Time){
	    //						cs.setTime(key.intValue(),(Time)value);
	    //					}else if(value instanceof Timestamp){
	    //						cs.setTimestamp(key.intValue(),(Timestamp)value);
	    //					}
	    //				}
	    //				
	    //				cs.execute();
	    //				
	    //			}catch(SQLException e){
	    //				throw new ReportException("Error executing Stored Procedure");
	    //			}finally{
	    //				DBUtil.closeConnection(connection);
	    //			}
	}

    }

    //	public void deleteTable() throws ReportException{
    //		if(requestedReportEntity.getDsEntity() instanceof SQLStatementEntity){
    //			SQLStatementEntity sqlStatementEntity = (SQLStatementEntity)requestedReportEntity.getDsEntity();
    //			Connection connection = DBUtil.getConnection(requestedReportEntity.getJndiName());
    //			String command = ("Drop table "+requestedReportEntity.getTableName());
    //			try{
    //				Statement stmt = connection.createStatement();
    //				stmt.executeUpdate(command);
    //			}catch(Exception e){
    //				throw new ReportException("Cannot delete the table");
    //			} finally {
    //				DBUtil.closeConnection(connection);
    //			}
    //		}
    //	}

    //	public boolean reset() throws ReportException{
    // MOVED TO SQLStatementImpl where this code belongs.		
    //		if(requestedReportEntity.getDsEntity() instanceof SQLStatementEntity){
    //			SQLStatementEntity sqlStatementEntity = (SQLStatementEntity)requestedReportEntity.getDsEntity();
    //			Connection connection = DBUtil.getConnection(requestedReportEntity.getJndiName());
    //			String command = ("{call refresh_data(?,?,?,?)}");
    //			
    //			try {
    //				CallableStatement cs = connection.prepareCall(command);
    //				String tableName = requestedReportEntity.getTableName();
    //				String arg2 = "temp."+util.convertToString(sqlStatementEntity.getOutputs(),true).replaceAll(",",",temp.");
    //				String arg3 = util.convertToString(requestedReportEntity.getSortOrder(),false);
    //				String tempTableName = "TEMP"+System.currentTimeMillis(); 
    //				cs.setString(1,tableName);
    //				cs.setString(2,arg2);
    //				cs.setString(3,arg3);
    //				cs.setString(4,tempTableName);
    //				cs.execute();
    //				return true;
    //			}catch(Exception se){

    //				log.error(se);
    //				throw new ReportException("Not able to reset the table");	
    //			}
    //			finally{
    //				DBUtil.closeConnection(connection);
    //			}
    //		}
    //		return false;
    //	}

    //	public ReportData get() throws ReportException{
    //		Connection connection = DBUtil.getConnection(requestedReportEntity.getJndiName());
    //		String sql = null;
    //		Map data = new HashMap();
    //		ResultSet rs = null ;
    //		Statement stmt = null;
    //		sql = util.makeSqlStatement(requestedReportEntity);
    //		int groupSize = 0;
    //		try{
    //			if(requestedReportEntity.getGroupBy()!=null){
    //				if(requestedReportEntity.getCurrentPage()==1 && requestedReportEntity.isNextData() ){
    //					
    //					List columnList = requestedReportEntity.getColumnList();
    //					int index = 0;
    //					List groupList = requestedReportEntity.getGroupBy().getGroupColumnName();
    //					for (Iterator iterGroup = groupList.iterator(); iterGroup.hasNext();) {
    //						String groupName = (String) iterGroup.next();
    //						columnList.remove(groupName);
    //						columnList.add(index,groupName);
    //						index = index + 1;
    //					}
    //					
    //					requestedReportEntity.setSortOrder(columnList);
    //					reset();
    //					updateTempTable();
    //					groupSize = requestedReportEntity.
    //					getGroupBy().getGroupColumnName().size();
    //				}else{
    //					groupSize = requestedReportEntity.
    //					getGroupBy().getGroupColumnName().size();
    //				}
    //				
    //				if((requestedReportEntity.getFilterString()!=null)){
    //					if(requestedReportEntity.getCurrentPage()==1 && requestedReportEntity.isNextData()){
    //						populateReportIndex(sql);
    //					}
    //					sql  = includePageFilter(new StringBuffer(sql));
    //				}
    //			}
    //			stmt = connection.createStatement();
    //			stmt.setMaxRows(requestedReportEntity.getBatchSize());
    //			rs = stmt.executeQuery(sql);
    //			data = util.getMap(rs,groupSize);
    //			return new DefaultReportData(data);
    //		}catch(Exception e){
    //			throw new ReportException("Unable to retrive value from the database");
    //		}finally{
    //			DBUtil.closeResultSet(rs);
    //			DBUtil.closeConnection(connection);
    //		}
    //	}


    //		public void updateTempTable() throws ReportException {
    //			Connection connection = DBUtil.getConnection(requestedReportEntity.getJndiName());
    //			String sql = null;
    //			Map data = new HashMap();
    //			Statement stmt = null;
    //			try{
    //				Map query = util.getGroupQueries(requestedReportEntity);
    //				
    //				List columnNames = requestedReportEntity.getGroupBy().getGroupColumnName();
    //				int size = columnNames.size();
    //				int i = size-1;
    //				while(i>=0){
    //					String column = columnNames.get(i).toString();
    //					sql = query.get(column).toString();
    //					stmt = connection.createStatement(); 
    //					stmt.executeUpdate(sql);
    //					i = i - 1;
    //				}
    //			}catch(Exception e){
    //				throw new ReportException("Unable to retrive value from the database");
    //			}finally{
    //				DBUtil.closeConnection(connection);
    //			}
    //	}

    //--------------------------------------------------------------
    //		public long getTotalPage() throws ReportException {
    //
    //			Connection connection = DBUtil.getConnection(requestedReportEntity.getJndiName());
    //			String sql = "select count(*) from "+requestedReportEntity.getTableName();
    //			ResultSet rs = null ;
    //			Statement stmt = null;
    //			try{
    //				stmt = connection.createStatement();
    //				rs = stmt.executeQuery(sql);
    //				while(rs.next()){
    //		        	return rs.getLong(1);
    //				}
    //				throw new ReportException("Error retriving the number of records");
    //			}catch(Exception e){
    //				throw new ReportException("Unable to retrive value from the database");
    //			}finally{
    //				DBUtil.closeStatement(stmt);
    //				DBUtil.closeResultSet(rs);
    //				DBUtil.closeConnection(connection);
    //			}
    //		}

    //		public void populateReportIndex(String sql){
    //			requestedReportEntity.setReportIndex(null);
    //			Map dataMap = new HashMap();
    //			List data = new ArrayList();
    //			try {
    //				Connection connection = DBUtil.getConnection(requestedReportEntity.getJndiName());
    //				ResultSet rs = null ;
    //				Statement stmt = connection.createStatement();
    //				rs = stmt.executeQuery(sql);
    //				int i;
    //				int pageCounter=1;
    //				int value=0;
    //				int counter=0;
    //				for (i = 1; rs.next(); i++) {
    //					value = rs.getInt(2);
    //					counter = counter + 1;

    //					if(i==1){
    //						data.add(Integer.valueOf(String.valueOf(value))) ;
    //					}else if(i == requestedReportEntity.getBatchSize()){
    //						data.add(Integer.valueOf(String.valueOf(value))) ;
    //						dataMap.put(Long.valueOf(pageCounter),data);
    //						pageCounter = pageCounter + 1;
    //						data = new ArrayList();
    //						i = 0;
    //					}
    //				}
    //				if(data.size()==1 && dataMap.size()!=0){
    //					data.add(Integer.valueOf(String.valueOf(value))) ;
    //					dataMap.put(Long.valueOf(pageCounter),data);
    //				}
    //					
    //				
    //				requestedReportEntity.setReportIndex(dataMap);
    //			}catch(Exception e){
    //				log.error(e);
    //
    //			} finally {
    //				
    //			}
    //			
    //		}

    //		public String includePageFilter(StringBuffer sql){
    //			List reportList = new ArrayList();
    //			Map reportIndex = requestedReportEntity.getReportIndex();
    //			
    //			if(requestedReportEntity.isNextData() && requestedReportEntity.getCurrentPage()!=1){
    //				sql.append(" and (Report_ID > ");
    //				reportList = (ArrayList)reportIndex.get(new 
    //						Long(requestedReportEntity.getCurrentPage()-1));
    //				sql.append(reportList.get(1).toString());
    //				sql.append(")");
    //			}else{
    //				if(requestedReportEntity.getCurrentPage()!=1){
    //					sql.append(" and ");
    //					sql.append("(Report_ID > ");
    //					reportList = (ArrayList)reportIndex.get(new 
    //							Long(requestedReportEntity.getCurrentPage()));
    //					sql.append(reportList.get(0).toString());
    //					sql.append(" and Report_ID < ");
    //					sql.append(reportList.get(1).toString());
    //					sql.append(")");
    //				}
    //			}
    //			sql.append(" Order by Report_ID");
    //			
    //			return sql.toString();
    //		}



}
