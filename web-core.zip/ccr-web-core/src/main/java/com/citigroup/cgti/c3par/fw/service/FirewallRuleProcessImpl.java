/**
 *
 */
package com.citigroup.cgti.c3par.fw.service;

import java.math.BigDecimal;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallPolicyGroup;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleDestinationIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleSourceIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallZone;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleApplication;
import com.citigroup.cgti.c3par.fw.domain.FirewallRulePolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.HistoryFireWallRule;
import com.citigroup.cgti.c3par.fw.domain.HistoryFireWallRuleDestinationIP;
import com.citigroup.cgti.c3par.fw.domain.HistoryFireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.HistoryFireWallRuleSourceIP;
import com.citigroup.cgti.c3par.fw.domain.HistoryFirewallRulePolicy;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.IPDetailsRequest;
import com.citigroup.cgti.c3par.fw.domain.Port;
import com.citigroup.cgti.c3par.fw.domain.PortServiceMapping;
import com.citigroup.cgti.c3par.fw.domain.SearchFirewallRuleRequest;
import com.citigroup.cgti.c3par.fw.domain.TIUploadedDocs;
import com.citigroup.cgti.c3par.fw.domain.TemplateConnection;
import com.citigroup.cgti.c3par.fw.domain.soc.persist.FirewallRuleProcessPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.util.StringUtil;

/**
 * @author bs45969
 *
 */
@SuppressWarnings("unchecked")
@Transactional
public class FirewallRuleProcessImpl extends BasePersistanceImpl implements
	FirewallRuleProcessPersistable {

    /** The log. */
    private static Logger log = Logger.getLogger(FirewallRuleProcessImpl.class);
    
    private JdbcTemplate jdbcTemplate;
	private CCRQueries ccrQueries;
	@Autowired
	ManageTIProcessImpl manageTIProcessImpl;
	
	
    
    
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public CCRQueries getCcrQueries() {
		return ccrQueries;
	}

	public void setCcrQueries(CCRQueries ccrQueries) {
		this.ccrQueries = ccrQueries;
	}

	private GenericLookup getGenericLookupValue(String key){
		Session session = getSession();
		GenericLookup genericlookup = null;
		List<GenericLookup> glList = (List<GenericLookup>) session
				.createQuery("from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.value1 = ?)").setString(0,key).list();

		if (glList != null && glList.size() > 0) {
			genericlookup = glList.get(0);
		}
		return genericlookup;
	}

    @Override
    @Transactional(readOnly = true)
    public FireWallRule getFirewallRule(long id) {
		Session session = getSession();
		session.enableFilter("excludeDeleted");
		FireWallRule fireWallRule =   (FireWallRule) session.createQuery(
			"from FireWallRule rule where rule.id=" + id).uniqueResult();
		if(fireWallRule != null){
			lazyInitialize(fireWallRule.getSourceIPs());
			lazyInitialize(fireWallRule.getDestinationIPs());
			lazyInitialize(fireWallRule.getPorts());
			lazyInitialize(fireWallRule.getPolicies());
			fireWallRule.setTemplateConnectionName(getConnectionName(fireWallRule.getTemplateID()));
		}
		if (fireWallRule != null && fireWallRule.getPorts() != null && fireWallRule.getPorts().size() > 0) {
			for (FireWallRulePort fireWallRulePort : fireWallRule.getPorts()) {
				if (fireWallRulePort!= null && fireWallRulePort.getPort() != null
						&& fireWallRulePort.getPort()!= null && "ICMP".equals(fireWallRulePort.getPort().getProtocol())) {
					fireWallRulePort.setControlMessage(getControlMessage(fireWallRulePort.getPort().getControlMsgId()));
				}
			}
		}
		return fireWallRule;
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<FireWallRule> getFirewallRules(FireWallRuleProcess fwRuleProcess) {
		Session session = getSession();
		Criteria criteria = session.createCriteria(FireWallRule.class);
		//criteria.createCriteria("updatedTIRequest", "updatedTIRequest");
		//criteria.createCriteria("updatedTIRequest.tiProcess", "tiProcess");
		
		/*if (fwRuleProcess.isIncompleteRules()) {
			List<Long> ruleIds = getIncompleteRules(fwRuleProcess
				    .getTiRequest());
			
			if (ruleIds != null) {
			    criteria.add(Restrictions.in("id", ruleIds));
			} 
		}*/
		
		criteria.createCriteria("tiRequest", "tiRequest");
		if (fwRuleProcess.getTiRequest() != 0) {
		    criteria.add(Restrictions.eq("tiRequest.id", fwRuleProcess
			    .getTiRequest()));
		}
		if (!StringUtil.isNullorEmpty(fwRuleProcess.getPolicy())) {
		    criteria.createCriteria("policy", "policy");
		    criteria.add(Restrictions.ilike("policy.name", fwRuleProcess
			    .getPolicy(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fwRuleProcess.getPolicyGroup())) {
		    criteria.createCriteria("policyGroup", "policyGroup");
		    criteria.add(Restrictions.ilike("policyGroup.name", fwRuleProcess
			    .getPolicyGroup(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fwRuleProcess.getSourceZone()) 
				&& !StringUtil.isNullorEmpty(fwRuleProcess.getDestinationZone())) {
			criteria.createCriteria("sourceNetworkZone", "sourceNetworkZone");
			criteria.createCriteria("destinationNetworkZone", "destinationNetworkZone");
			Criterion srcZone = Restrictions.ilike("sourceNetworkZone.name", fwRuleProcess
				    .getSourceZone(), MatchMode.ANYWHERE);
			Criterion dstZone = Restrictions.ilike("destinationNetworkZone.name",
				    fwRuleProcess.getDestinationZone(), MatchMode.ANYWHERE);
			criteria.add(Restrictions.or(srcZone, dstZone));
		}
		if (!StringUtil.isNullorEmpty(fwRuleProcess.getSourceIPAddress())) {
		    criteria.createCriteria("sourceIPs", "sourceIPs");
		    criteria.createCriteria("sourceIPs.ipAddress", "sourceIP");
		    criteria.add(Restrictions.ilike("sourceIP.ipAddress", fwRuleProcess
			    .getSourceIPAddress(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fwRuleProcess.getDestinationIPAddress())) {
		    criteria.createCriteria("destinationIPs", "destinationIPs");
		    criteria
			    .createCriteria("destinationIPs.ipAddress", "destinationIP");
		    criteria.add(Restrictions
			    .ilike("destinationIP.ipAddress", fwRuleProcess
				    .getDestinationIPAddress(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fwRuleProcess.getPortNumber())) {
		    criteria.createCriteria("ports", "ports");
		    criteria.createCriteria("ports.port", "port");
		    criteria.add(Restrictions.eq("port.portNumber", fwRuleProcess
			    .getPortNumber()));
		}
		if(!StringUtil.isNullorEmpty(fwRuleProcess.getIsIpReg()))
		{
			if (fwRuleProcess.getIsIpReg().equalsIgnoreCase("Y")) {
				log.debug("IP ==> " +fwRuleProcess.getIsIpReg());
				criteria.add(Restrictions.eq("isIpReg", "Y"));
			}
			else{
				log.debug("FIREWALL ==> " +fwRuleProcess.getIsIpReg());
				criteria.add(Restrictions.sqlRestriction("(IS_IPREG is null or IS_IPREG != 'Y')"));
			}
		}
		session.enableFilter("excludeDeleted");
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.addOrder(Order.desc("isNew"));
		criteria.addOrder(Order.desc("status"));
		criteria.addOrder(Order.desc("updated_date"));
		fwRuleProcess.setRowCount(getRowCount(criteria));
		
		addPagination(criteria, fwRuleProcess.getOffset(), fwRuleProcess
			.getLimit());
		List<FireWallRule> fireWallRules = criteria.list();
		
		for(FireWallRule fireWallRule : fireWallRules)	{
			log.debug("In firewallRuleProcessImpl getFirewallRulesCollectionLimit ---"+fwRuleProcess.getCollectionLimit());
		    fireWallRule.setSourceIPs(getSoureIpsByFirewallRule(fireWallRule.getId(),fwRuleProcess.getCollectionLimit()));
		    fireWallRule.setDestinationIPs(getDestinationIpsByFirewallRule(fireWallRule.getId(),fwRuleProcess.getCollectionLimit()));
		    fireWallRule.setPorts(getPortsByFirewallRule(fireWallRule.getId(),fwRuleProcess.getCollectionLimit()));
		    fireWallRule.setPolicies(getPoliciesByFirewallRule(fireWallRule.getId(),fwRuleProcess.getCollectionLimit()));
		    fireWallRule.setTemplateConnectionName(getConnectionName(fireWallRule.getTemplateID()));
		   fireWallRule.setOfacFlag(manageTIProcessImpl.getOFACFlagforRule(fireWallRule.getId()));
		    //log.debug("In Fire wall page  Ofac  ---"+fireWallRule.getIsOfacFlag());
		    
		}
		return fireWallRules;

    }

    @Override
    @Transactional(readOnly = true)
    public int getFirewallRulesRowCount(FireWallRuleProcess fwRuleProcess) {
		Session session = getSession();
		session.enableFilter("excludeDeleted");
		Criteria criteria = session.createCriteria(FireWallRule.class);
		criteria.createCriteria("tiRequest", "tiRequest");
		if (fwRuleProcess.getTiRequest() != 0) {
		    criteria.add(Restrictions.eq("tiRequest.id", fwRuleProcess
			    .getTiRequest()));
		}
		log.debug("getFirewallRulesRowCount ---"+criteria.toString());
		return getRowCount(criteria);
    }
    
    private int getNextRuleNumber(Long tiRequestId, String isIPReg) {
	    Session session = getSession();
		int nextrulenumber = 0;
		String isIpRegSQL = null;
		if(isIPReg != null && isIPReg.equalsIgnoreCase("Y"))
		{
			isIpRegSQL = "is_ipreg = 'Y'";
		}
		else
		{
			isIpRegSQL = "(is_ipreg != 'Y' or is_ipreg is null)";
		}
		SQLQuery query = session.createSQLQuery("select (nvl(max(rule_number),0)+1) as nextrulenumber from CON_FW_RULE " +
				"where ti_request_id = "+tiRequestId+" and "+isIpRegSQL);
		query.addScalar("nextrulenumber", IntegerType.INSTANCE);
		Integer count = (Integer)query.uniqueResult();
		nextrulenumber = count.intValue();
		return nextrulenumber;
    }

    @Override
    public Long saveFireWallRule(FireWallRule ruleData) throws BusinessException {
	    log.debug("saveFireWallRule----------------------------------------");
	    if(ruleData.getSourceIPs() != null){
		    log.debug("SOURCE IPS");
			for (FireWallRuleSourceIP ip : ruleData.getSourceIPs()) {
			    log.debug(ip.getId() + " ---- " + ip.getIpAddress().getId()
				    + " ---- " + ip.getIpAddress().getIpAddress()
				    + " ---- " + ip.getNAT()
				    + " ---- " + ip.isDeleted()
				    + " ---- " + ip.getObjRuleID()
				    );
			}
	    }
		if(ruleData.getDestinationIPs() != null){
			log.debug("DEST IPS");
			for (FireWallRuleDestinationIP ip : ruleData.getDestinationIPs()) {
				log.debug(ip.getId() + " ---- " + ip.getIpAddress().getId()
				    + " ---- " + ip.getIpAddress().getIpAddress()
				    + " ---- " + ip.getNAT()
				+ " ---- " + ip.isDeleted()
			    + " ---- " + ip.getObjRuleID()
				);
			}
		}
		if(ruleData.getPorts() != null){
			log.debug("PORTS");
			for (FireWallRulePort ip : ruleData.getPorts()) {
				log.debug(ip.getId() + " ---- " + ip.getPort().getId() + " ---- "
				    + ip.getPort().getPortNumber()
				+ " ---- " + ip.getPort().getProtocol()
				+ " ---- " + ip.getPort().getFlowOfData()
				+ " ---- " + ip.isDeleted()
				+ " ---- " + ip.getDescription()
			    + " ---- " + ip.getObjRuleID()
				);
			}
		}

		Long fireWallRuleId = null;
		if (ruleData.getId() != null && ruleData.getId().longValue() > 0) {
		    fireWallRuleId = ruleData.getId();
		    deleteFirewallRuleApplications(ruleData, false);
		    if(ruleData.getSourceIPs() != null){
		    	List<FireWallRuleSourceIP> deletedSourceIPs = getDeletedSoureIpsByFirewallRule(fireWallRuleId);
		    	List<FireWallRuleSourceIP> newDeletedSourceIPs = new ArrayList<FireWallRuleSourceIP>();
		    	log.debug("**************ruleData.getSourceIPs()==>"+ruleData.getSourceIPs().size()+"deletedSourceIPs ==>"+deletedSourceIPs.size());

				for(FireWallRuleSourceIP deletedSourceIP : deletedSourceIPs) {		
			    	Iterator<FireWallRuleSourceIP> fwRuleSourceIPIterator = ruleData.getSourceIPs().iterator();
			    	while(fwRuleSourceIPIterator.hasNext()) { 
	    				//log.debug("*****************inside loooooppp SourceIP");
			    		if(deletedSourceIP.getIpAddress().getId().equals(
			    				fwRuleSourceIPIterator.next().getIpAddress().getId())){
			    			//log.debug("*************ips are equal.. going to updated deleted tirequest");
			    			deletedSourceIP.setDeletedTIRequest(null);
			    			fwRuleSourceIPIterator.remove();
			    		}
			    	}
	    			newDeletedSourceIPs.add(deletedSourceIP);
	    			//log.debug("*************ip added in new SourceIP list");
		    	}
	    		ruleData.getSourceIPs().addAll(newDeletedSourceIPs);
    			//log.debug("*************all deleted IPs added in SourceIP list");
		    }
		    
		    if(ruleData.getSourceIPs() != null){
			    log.debug("Afer checking with deleted_source_IPS - final IPs going to save");
				for (FireWallRuleSourceIP ip : ruleData.getSourceIPs()) {
				    log.debug(ip.getId() + " ---- " + ip.getIpAddress().getId()
					    + " ---- " + ip.getIpAddress().getIpAddress()
					    + " ---- " + ip.getNAT()
					    + " ---- " + ip.isDeleted()
					    + " ---- " + ip.getObjRuleID()
					    );
				}
		    }
		    
		    if(ruleData.getDestinationIPs() != null){
		    	List<FireWallRuleDestinationIP> deletedDestinationIPs = getDeletedDestinationIpsByFirewallRule(fireWallRuleId);
		    	List<FireWallRuleDestinationIP> newDeletedDestinationIPs = new ArrayList<FireWallRuleDestinationIP>();
		    	log.debug("**************ruleData.getDestinationIPs()==>"+ruleData.getDestinationIPs().size()+"deletedDestinationIPs ==>"+deletedDestinationIPs.size());
	    		for(FireWallRuleDestinationIP deletedDestinationIP : deletedDestinationIPs) {   			
			    	Iterator<FireWallRuleDestinationIP> fwRuleDestinationIPIterator = ruleData.getDestinationIPs().iterator();
			    	while(fwRuleDestinationIPIterator.hasNext()) { 
	    				//log.debug("*****************inside loooooppp DestinationIP");
			    		if(deletedDestinationIP.getIpAddress().getId().equals(
			    				fwRuleDestinationIPIterator.next().getIpAddress().getId())){
			    			//log.debug("*************ips are equal.. going to updated deleted tirequest");
			    			deletedDestinationIP.setDeletedTIRequest(null);
			    			fwRuleDestinationIPIterator.remove();
			    		}
			    	}
	    			newDeletedDestinationIPs.add(deletedDestinationIP);
	    			//log.debug("*************ip added in new DestinationIP list");
		    	}
	    		ruleData.getDestinationIPs().addAll(newDeletedDestinationIPs);
    			//log.debug("*************all deleted IPs added in DestinationIP list");
		    }

			if(ruleData.getDestinationIPs() != null){
				log.debug("Afer checking with deleted_destination_IPS - final IPs going to save");
				for (FireWallRuleDestinationIP ip : ruleData.getDestinationIPs()) {
					log.debug(ip.getId() + " ---- " + ip.getIpAddress().getId()
					    + " ---- " + ip.getIpAddress().getIpAddress()
					    + " ---- " + ip.getNAT()
						+ " ---- " + ip.isDeleted()
					    + " ---- " + ip.getObjRuleID()
					);
				}
			}
			
		    if(ruleData.getPorts() != null) {
		    	List<FireWallRulePort> deletedPorts = getDeletedPortsByFirewallRule(fireWallRuleId);
		    	List<FireWallRulePort> newDeletedPorts = new ArrayList<FireWallRulePort>();
		    	for (FireWallRulePort deletedFireWallRulePort  : deletedPorts) {
		    		Iterator<FireWallRulePort> fwRulePortIterator = ruleData.getPorts().iterator();
		    		while (fwRulePortIterator.hasNext()) {
		    			if (deletedFireWallRulePort.getPort().getId().equals(fwRulePortIterator.next().getPort().getId())) {
		    				deletedFireWallRulePort.setDeletedTIRequest(null);
		    				fwRulePortIterator.remove();
		    			}
		    		}
		    		newDeletedPorts.add(deletedFireWallRulePort);
		    	}
		    	ruleData.getPorts().addAll(newDeletedPorts);
		    }
		    
		    if(ruleData.getPolicies() != null){
		    	ruleData.getPolicies().addAll(getDeletedPoliciesByFirewallRule(fireWallRuleId));
		    }
		    getHibernateTemplate().update(ruleData);
		} else {
					ruleData.setRuleNumber(getNextRuleNumber(ruleData.getTiRequest().getId(),ruleData.getIsIpReg()));
				    fireWallRuleId = (Long) getHibernateTemplate().save(ruleData);
		}
		return fireWallRuleId;
    }
    
    private void deleteFirewallRuleApplications(FireWallRule ruleData, boolean completeRule) {
    	List<Long> selectedIPs = new ArrayList<Long>();
    	if(ruleData.getSourceIPs() != null){
	    	for (FireWallRuleSourceIP ip : ruleData.getSourceIPs()) {
	    		if (completeRule || ip.isDeleted()) {
	    			selectedIPs.add(ip.getIpAddress().getId());
	    		} 
	    	}
    	}
    	if(ruleData.getDestinationIPs() != null){
	    	for (FireWallRuleDestinationIP ip : ruleData.getDestinationIPs()) {
	    		if (completeRule || ip.isDeleted()) {
	    			selectedIPs.add(ip.getIpAddress().getId());
	    		} 
	    	}
    	}
    	Long firewallId = ruleData.getId();
    	
    	StringBuffer fwApplqueryStr = new StringBuffer();
    	
    	if (selectedIPs != null && selectedIPs.size() > 0 && firewallId != null && ruleData.getTiRequest() != null) {
			fwApplqueryStr.append("update con_fw_rule_application set deleted_ti_request_id = "+ruleData.getTiRequest().getId());
			
			fwApplqueryStr.append(" where ip_id in (");
			int i=0;
			for (Long selIp : selectedIPs) {
				if (i > 0) {
					fwApplqueryStr.append(",");
				}
				fwApplqueryStr.append(selIp);
				i++;
			}
			fwApplqueryStr.append(") ");			
			fwApplqueryStr.append(" and rule_id ="+firewallId);			
			fwApplqueryStr.append(" and ti_request_id = "+ruleData.getTiRequest().getId());
			
			SQLQuery query = getSession().createSQLQuery(fwApplqueryStr.toString());
			int rows = query.executeUpdate();
			log.debug("FirewallRuleServiceImpl::deleteFirewallRuleApplications count---"+rows);
    	}
    }

    @Override
    @Transactional(readOnly = true)
    public List<FireWallZone> getFirewallZones(Long firewallGroup,
	    Long firewallPolicy) {
	List<FireWallZone> firewallZones = null;

	if (firewallPolicy != null && firewallPolicy.longValue() > 0) {
	    firewallZones = (List<FireWallZone>) getSession().createQuery(
		    "from FireWallZone zone where zone.policyId = "
			    + firewallPolicy).list();
	} else {
	    firewallZones = (List<FireWallZone>) getSession()
		    .createQuery(
			    "from FireWallZone zone where zone.policyId in ("
				    + "select id from FirewallPolicy pol where pol.fireWallPolicyGroup.id = "
				    + firewallGroup + ")").list();
	}
	return firewallZones;
    }
    
    private String getBroadAccessIP(Long id) {
    	String broadAccessIP = "";
    	SQLQuery query = getSession().createSQLQuery("select broad_access_ip from resourcetype where id="+id);
    	query.addScalar("broad_access_ip", StringType.INSTANCE);
    	broadAccessIP = (String)query.uniqueResult();
    	return broadAccessIP;
    }

    /*
     *To validate the Existing Ports and IPs
     */
    /**
     *
     * @param fireWallRule
     * @return
     */
    public FireWallRule validateIPsandPorts(FireWallRule fireWallRule) {
    	String srcBroadAccessIP = "";
    	String dstBroadAccessIP = "";
    	
    	if (fireWallRule.getSourceNetworkZone()!= null) {
    		srcBroadAccessIP = getBroadAccessIP(fireWallRule.getSourceNetworkZone().getId());
    	}
    	if (fireWallRule.getDestinationNetworkZone() != null) {
    		dstBroadAccessIP = getBroadAccessIP(fireWallRule.getDestinationNetworkZone().getId());
    	}
    	
    	Integer sourceIPcount = new Integer(0);
    	Long portcount = new Long(0);
    	Integer destIPcount = new Integer(0);
    	
	    FirewallRuleValidator ipAddressValidator = new FirewallRuleValidator();
	    ipAddressValidator.setSession(getSession());
	    ipAddressValidator.getTPASubnetMaster();
//	    OFAC Changes - start
	    ipAddressValidator.getOfacSubnetMaster();
//	    OFAC Changes - End
		List<FireWallRuleSourceIP> sourceIPs = fireWallRule.getSourceIPs();
		if (sourceIPs != null && !sourceIPs.isEmpty()) {
		    for (FireWallRuleSourceIP fireWallRuleSourceIP : sourceIPs) {
		    	if (fireWallRuleSourceIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleSourceIP.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRuleSourceIP.getDeletedTIRequest().getId().longValue() >= 0) {
		    		IPAddress orgIPAddress = ipAddressValidator.formatIPAddress(fireWallRuleSourceIP.getIpAddress());
		    		fireWallRuleSourceIP.setIpAddress(orgIPAddress);
     	    	} else if ("Y".equalsIgnoreCase(fireWallRuleSourceIP.getIpAddress().getTemplateFlag())) {
		    		List<FireWallRuleIP> tmpIPs = ipAddressValidator.getIPsforTemplateObject(
		    					fireWallRuleSourceIP.getIpAddress().getId(), 
		    					fireWallRuleSourceIP.getObjRuleID(), "N", fireWallRule.getTiRequest().getId());
				    		for (FireWallRuleIP fireWallRuleIP : tmpIPs) {
				    			ipAddressValidator.validateAndFormatIPAddress(fireWallRuleIP.getIpAddress()
				    					, fireWallRuleIP.getNAT(), srcBroadAccessIP);
				    			if (fireWallRuleIP.getIpAddress() != null && fireWallRuleIP.getIpAddress().getNoOfHost() != null) {
						    		sourceIPcount = sourceIPcount + fireWallRuleIP.getIpAddress().getNoOfHost();
						    	}
				    			ipAddressValidator.validateNATIP(fireWallRuleIP.getNAT());
				    		}
     	    	} else if (fireWallRule.getIsIpReg() != null && "Y".equalsIgnoreCase(fireWallRule.getIsIpReg())) {
     	    		ipAddressValidator.validateIPRegSourceIP(fireWallRuleSourceIP.getIpAddress());
     	    		fireWallRuleSourceIP.getIpAddress().setFormattedIP(fireWallRuleSourceIP.getIpAddress().getIpAddress());
		    		ipAddressValidator.validateNATIP(fireWallRuleSourceIP.getNAT());
		    		sourceIPcount = sourceIPcount + 1;
		    	} else {
		    		IPAddress orgIPAddress = ipAddressValidator.validateAndFormatIPAddress(fireWallRuleSourceIP.getIpAddress()
		    				, fireWallRuleSourceIP.getNAT(), srcBroadAccessIP);
		    		ipAddressValidator.validateNATIP(fireWallRuleSourceIP.getNAT());
			    	fireWallRuleSourceIP.setIpAddress(orgIPAddress);
			    	if (orgIPAddress.getNoOfHost() != null) {
			    		sourceIPcount = sourceIPcount + orgIPAddress.getNoOfHost();
			    	}
		    	}
		    }
		}
	
		List<FireWallRuleDestinationIP> destinationIPs = fireWallRule
			.getDestinationIPs();
		if (destinationIPs != null && !destinationIPs.isEmpty()) {
		    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : destinationIPs) {
		    	if (fireWallRuleDestinationIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId().longValue() >= 0) {
		    		IPAddress orgIPAddress = ipAddressValidator.formatIPAddress(fireWallRuleDestinationIP.getIpAddress());
		    		fireWallRuleDestinationIP.setIpAddress(orgIPAddress);
     	    	} else if ("Y".equalsIgnoreCase(fireWallRuleDestinationIP.getIpAddress().getTemplateFlag())) {
		    		List<FireWallRuleIP> tmpIPs = ipAddressValidator.getIPsforTemplateObject(
		    				fireWallRuleDestinationIP.getIpAddress().getId(), 
		    				fireWallRuleDestinationIP.getObjRuleID(), "N", fireWallRule.getTiRequest().getId());
		    		
				    		for (FireWallRuleIP fireWallRuleIP : tmpIPs) {
				    			ipAddressValidator.validateAndFormatIPAddress(fireWallRuleIP.getIpAddress(), fireWallRuleIP.getNAT()
				    					, dstBroadAccessIP);
				    			if (fireWallRuleIP.getIpAddress() != null && fireWallRuleIP.getIpAddress().getNoOfHost() != null) {
				    				destIPcount = destIPcount + fireWallRuleIP.getIpAddress().getNoOfHost();
						    	}
				    			ipAddressValidator.validateNATIP(fireWallRuleIP.getNAT());
				    		}
		    	} else {
		    		IPAddress orgIPAddress = ipAddressValidator.validateAndFormatIPAddress(fireWallRuleDestinationIP.getIpAddress(), fireWallRuleDestinationIP.getNAT()
		    				,dstBroadAccessIP);
		    		ipAddressValidator.validateNATIP(fireWallRuleDestinationIP.getNAT());
			    	fireWallRuleDestinationIP.setIpAddress(orgIPAddress);
			    	if (orgIPAddress.getNoOfHost() != null) {
			    		destIPcount = destIPcount + orgIPAddress.getNoOfHost();
			    	}
		    	}
			 }
		}
	
		List<FireWallRulePort> ports = fireWallRule.getPorts();
	
		if (ports != null && !ports.isEmpty()) {
		    for (FireWallRulePort fireWallRulePort : ports) {
		    	if (fireWallRulePort.getDeletedTIRequest() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
		    	if ("Y".equalsIgnoreCase(fireWallRulePort.getPort().getTemplateFlag())) {
		    		List<FireWallRulePort> tmpPorts = ipAddressValidator.getPortsforTemplateObject(
		    				fireWallRulePort.getPort().getId(), 
		    				fireWallRulePort.getObjRuleID(), "N", fireWallRule.getTiRequest().getId());
		    				    		
				    		for (FireWallRulePort fireWallRulePortTmp : tmpPorts) {
				    			ipAddressValidator.validatePort(fireWallRulePortTmp.getPort());
				    			if (fireWallRulePortTmp.getPort() != null && fireWallRulePortTmp.getPort().getPortCount() != null) {
					    			portcount = portcount + fireWallRulePortTmp.getPort().getPortCount();
					    		}
				    		}
		    	} else {
		    		Port port = ipAddressValidator.validatePort(fireWallRulePort.getPort());
		    		fireWallRulePort.setPort(port);
		    		if (port.getPortCount() != null) {
		    			portcount = portcount + port.getPortCount();
		    		}
		    	}
		    }
		}
		
		if ((fireWallRule.getSourceObject() != null && fireWallRule.getSourceObject().getIpAddress() != null
    			&& !fireWallRule.getSourceObject().getIpAddress().isEmpty())) {
			fireWallRule.getSourceObject().setNoOfHost(sourceIPcount);
    	}
    	if ((fireWallRule.getDestinationObject() != null && fireWallRule.getDestinationObject().getIpAddress() != null
    			&& !fireWallRule.getDestinationObject().getIpAddress().isEmpty())) {
    		fireWallRule.getDestinationObject().setNoOfHost(destIPcount);
    	}
    	if ((fireWallRule.getPortObject() != null && fireWallRule.getPortObject().getPortNumber() != null
    			&& !fireWallRule.getPortObject().getPortNumber().isEmpty())) {
    		fireWallRule.getPortObject().setPortCount(portcount);
    	}
		
		List<FirewallRulePolicy> policies = fireWallRule.getPolicies();
		
		if (policies != null && !policies.isEmpty()) {
		    for (FirewallRulePolicy firewallRulePolicy : policies) {
		    	if (firewallRulePolicy.getDeletedTIRequest() != null 
     	    			&& firewallRulePolicy.getDeletedTIRequest().getId() != null 
     	    			&& firewallRulePolicy.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
		    	
		    	ipAddressValidator.validatePolicies(firewallRulePolicy.getFirewallPolicy());
		    	}
		}
		fireWallRule.getValidationErrors().addAll(ipAddressValidator.getValidationErrors());
		return fireWallRule;
    }
    
    /*
     * To Identify the Existing Ports and IPs
     */
    /**
     *
     * @param fireWallRule
     * @return
     */
    public FireWallRule identifyExistingIPsandPorts(FireWallRule fireWallRule) {
    	Session session = getSession();
    	
		List<Long> tpaUpdateYes = new ArrayList<Long>();
		List<Long> tpaUpdateNo = new ArrayList<Long>();
		List<Long> ofacUpdateYes = new ArrayList<Long>();
		List<Long> ofacUpdateNo = new ArrayList<Long>();
		
		
		List<Long> anyUpdateYes = new ArrayList<Long>();
		List<Long> anyUpdateNo = new ArrayList<Long>();
		//fireWallRule.setIsOfacFlag("N");
		
		List<FireWallRuleSourceIP> sourceIPs = fireWallRule.getSourceIPs();
		List<IPAddress> ipAddress = null;		
		if (sourceIPs != null && !sourceIPs.isEmpty()) {
		    for (FireWallRuleSourceIP fireWallRuleSourceIP : sourceIPs) {
			if (!(fireWallRuleSourceIP.getId() != null && fireWallRuleSourceIP
				.getId().longValue() > 0)) {
				IPAddress orgIPAddress = fireWallRuleSourceIP.getIpAddress();
				if ("Y".equalsIgnoreCase(orgIPAddress.getTemplateFlag()) || (orgIPAddress.getId() != null && orgIPAddress.getId().longValue() > 0)) {
					ipAddress = (List<IPAddress>) session.createQuery(
						    "from IPAddress ip where ip.id = "
							    + orgIPAddress.getId()).list();
				} else {
					if (orgIPAddress.getIpAddress().indexOf("-") != -1) {
						ipAddress = (List<IPAddress>) session.createQuery(
							    "from IPAddress ip where ip.formattedStartIP = '"
								    + orgIPAddress.getFormattedStartIP() + "' and ip.formattedEndIP = '"
									    + orgIPAddress.getFormattedEndIP() + "'").list();
					} else if (orgIPAddress.getIpAddress().indexOf("/") != -1) {
						ipAddress = (List<IPAddress>) session.createQuery(
							    "from IPAddress ip where ip.ipAddress = '"
								    + orgIPAddress.getIpAddress() + "' and ip.formattedStartIP = '"
								    + orgIPAddress.getFormattedStartIP() + "' and ip.formattedEndIP = '"
									    + orgIPAddress.getFormattedEndIP() + "'").list();
					} else {
							ipAddress = (List<IPAddress>) session.createQuery(
								    "from IPAddress ip where ip.formattedIP = '"
									    + orgIPAddress.getFormattedIP() + "' ").list();
							if (ipAddress != null && !ipAddress.isEmpty()) {
								IPAddress address = ipAddress.get(0);
								if(!(address != null && (address.getIpAddress().indexOf("/") == -1) &&(address.getIpAddress().indexOf("-") == -1))){
									address=null;
								}
							}
						    	
					}
				}
				
			    if (ipAddress != null && !ipAddress.isEmpty()) {
			    	fireWallRuleSourceIP.setIpAddress(ipAddress.get(0));
			    	if (ipAddress.get(0).getTpaFlag() == null ||  !ipAddress.get(0).getTpaFlag().
			    			equalsIgnoreCase(orgIPAddress.getTpaFlag())) {
			    		if ("Y".equalsIgnoreCase(orgIPAddress.getTpaFlag())) {
			    			tpaUpdateYes.add(ipAddress.get(0).getId());
			    		} else {
			    			tpaUpdateNo.add(ipAddress.get(0).getId());
			    		}
			    	} 
			    	if (ipAddress.get(0).getOfacFlag() == null ||  !ipAddress.get(0).getOfacFlag().
			    			equalsIgnoreCase(orgIPAddress.getOfacFlag())) {
			    		
			    		
			    		if ("Y".equalsIgnoreCase(orgIPAddress.getOfacFlag())) {
			    			ofacUpdateYes.add(ipAddress.get(0).getId());
			    		} else {
			    			ofacUpdateNo.add(ipAddress.get(0).getId());
			    		}
			    	} 
			    	if (ipAddress.get(0).getAnyIP() == null ||  !ipAddress.get(0).getAnyIP().
	    					equalsIgnoreCase(orgIPAddress.getAnyIP())) {
			    		if ("Y".equalsIgnoreCase(orgIPAddress.getAnyIP())) {
			    			anyUpdateYes.add(ipAddress.get(0).getId());
			    		} else {
			    			anyUpdateNo.add(ipAddress.get(0).getId());
			    		}
			    	}
			    } else {
			    	fireWallRuleSourceIP.setIpAddress(orgIPAddress);
			    	getHibernateTemplate().save(orgIPAddress);
			    }
			}
		    }
		}
	
		List<FireWallRuleDestinationIP> destinationIPs = fireWallRule
			.getDestinationIPs();
		ipAddress = null;
		if (destinationIPs != null && !destinationIPs.isEmpty()) {
		    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : destinationIPs) {
			if (!(fireWallRuleDestinationIP.getId() != null && fireWallRuleDestinationIP
				.getId().longValue() > 0)) {
				IPAddress orgIPAddress = fireWallRuleDestinationIP.getIpAddress();
				
				if ("Y".equalsIgnoreCase(orgIPAddress.getTemplateFlag()) || (orgIPAddress.getId() != null && orgIPAddress.getId().longValue() > 0)) {
					ipAddress = (List<IPAddress>) session.createQuery(
						    "from IPAddress ip where ip.id = "
							    + orgIPAddress.getId()).list();
				} else {
					if (orgIPAddress.getIpAddress().indexOf("-") != -1) {
						ipAddress = (List<IPAddress>) session.createQuery(
							    "from IPAddress ip where ip.formattedStartIP = '"
								    + orgIPAddress.getFormattedStartIP() + "' and ip.formattedEndIP = '"
									    + orgIPAddress.getFormattedEndIP() + "'").list();
					} else if (orgIPAddress.getIpAddress().indexOf("/") != -1) {
						ipAddress = (List<IPAddress>) session.createQuery(
							    "from IPAddress ip where ip.ipAddress = '"
								    + orgIPAddress.getIpAddress() + "' and ip.formattedStartIP = '"
								    + orgIPAddress.getFormattedStartIP() + "' and ip.formattedEndIP = '"
									    + orgIPAddress.getFormattedEndIP() + "'").list();
					} else {
							ipAddress = (List<IPAddress>) session.createQuery(
								    "from IPAddress ip where ip.formattedIP = '"
									    + orgIPAddress.getFormattedIP() + "'").list();
					}
				}
			    if (ipAddress != null && !ipAddress.isEmpty()) {
			    	fireWallRuleDestinationIP.setIpAddress(ipAddress.get(0));
			    	if (ipAddress.get(0).getTpaFlag() == null ||  !ipAddress.get(0).getTpaFlag().
			    					equalsIgnoreCase(orgIPAddress.getTpaFlag())) {
			    		if ("Y".equalsIgnoreCase(orgIPAddress.getTpaFlag())) {
			    			tpaUpdateYes.add(ipAddress.get(0).getId());
			    		} else {
			    			tpaUpdateNo.add(ipAddress.get(0).getId());
			    		}
			    	} 
			    	if (ipAddress.get(0).getOfacFlag() == null ||  !ipAddress.get(0).getOfacFlag().
			    			equalsIgnoreCase(orgIPAddress.getOfacFlag())) {
			    		if ("Y".equalsIgnoreCase(orgIPAddress.getOfacFlag())) {
			    			ofacUpdateYes.add(ipAddress.get(0).getId());
			    		} else {
			    			ofacUpdateNo.add(ipAddress.get(0).getId());
			    		}
			    	} 
			    	if (ipAddress.get(0).getAnyIP() == null ||  !ipAddress.get(0).getAnyIP().
	    					equalsIgnoreCase(orgIPAddress.getAnyIP())) {
			    		if ("Y".equalsIgnoreCase(orgIPAddress.getAnyIP())) {
			    			anyUpdateYes.add(ipAddress.get(0).getId());
			    		} else {
			    			anyUpdateNo.add(ipAddress.get(0).getId());
			    		}
			    	} 
			    } else {
			    	fireWallRuleDestinationIP.setIpAddress(orgIPAddress);
			    	getHibernateTemplate().save(orgIPAddress);
			    }
			}
		    }
		}
	
		List<FireWallRulePort> ports = fireWallRule.getPorts();
		List<Port> port = null;
	
		if (ports != null && !ports.isEmpty()) {
		    for (FireWallRulePort fireWallRulePort : ports) {
			if (!(fireWallRulePort.getId() != null && fireWallRulePort
				.getId().longValue() > 0)) {
				
			    StringBuffer queryStr = new StringBuffer();
	
			    if ("Y".equalsIgnoreCase(fireWallRulePort.getPort().getTemplateFlag())  || (fireWallRulePort.getPort().getId() != null && fireWallRulePort.getPort().getId().longValue() > 0)) {
			    	queryStr.append("from Port pt where pt.id = "
							+ fireWallRulePort.getPort().getId());
			    } else {			    
				    queryStr.append("from Port pt where pt.portNumber = '"
							+ fireWallRulePort.getPort().getPortNumber() +
							"' and pt.protocol = '"
							+ fireWallRulePort.getPort().getProtocol()+
							"' and pt.flowOfData = '"
							+ fireWallRulePort.getPort().getFlowOfData()+"'");
		
				    if (fireWallRulePort.getPort().getControlMsgId() != null
					    && fireWallRulePort.getPort().getControlMsgId()
						    .longValue() > 0) {
					queryStr.append(" and pt.controlMsgId = '"
						+ fireWallRulePort.getPort().getControlMsgId()
						+ "'");
				    }
			    }
			    port = (List<Port>) session.createQuery(
				    queryStr.toString()).list();
			    if (port != null && !port.isEmpty()) {
			    	fireWallRulePort.setPort(port.get(0));
			    } else {
			    	getHibernateTemplate().save(fireWallRulePort.getPort());
			    }
			}
		    }
		}
		
		
		log.debug("tpaUpdateYes - "+tpaUpdateYes);
		StringBuffer queryString = new StringBuffer();
		if (tpaUpdateYes != null
				&& !tpaUpdateYes.isEmpty()) {
			queryString.append("update con_ip_master set is_tpa = 'Y' where id in (");
			/*for (Long id : tpaUpdateYes) {
				queryString.append(id+",");
			}*/ 
			queryString.append(tpaUpdateYes.toString().substring(1,tpaUpdateYes.toString().length()-1));
			queryString.append(")");
			
			SQLQuery query = getSession().createSQLQuery(queryString.toString());
			int rows = query.executeUpdate();
			log.debug("IPs updated TPA as Y count---"+rows);
		}
		
		
		log.debug("tpaUpdateNo - "+tpaUpdateNo);
		if (tpaUpdateNo != null
				&& !tpaUpdateNo.isEmpty()) {
			queryString.append("update con_ip_master set is_tpa = 'N' where id in (");
			/*for (Long id : tpaUpdateNo) {
				queryString.append(id +",");
			} */
			queryString.append(tpaUpdateNo.toString().substring(1,tpaUpdateNo.toString().length()-1));
			queryString.append(")");
			
			SQLQuery query = getSession().createSQLQuery(queryString.toString());
			int rows = query.executeUpdate();
			log.debug("IPs updated TPA as N count---"+rows);
		}
		log.debug("ofacUpdateYes - "+ofacUpdateYes);
		 queryString = new StringBuffer();
		if (ofacUpdateYes != null
				&& !ofacUpdateYes.isEmpty()) {
			queryString.append("update con_ip_master set is_ofac = 'Y' where id in (");
			/*for (Long id : tpaUpdateYes) {
				queryString.append(id+",");
			}*/ 
			queryString.append(ofacUpdateYes.toString().substring(1,ofacUpdateYes.toString().length()-1));
			queryString.append(")");
			
			SQLQuery query = getSession().createSQLQuery(queryString.toString());
			int rows = query.executeUpdate();
			//fireWallRule.setIsOfacFlag("Y");
			log.debug("IPs updated Ofac as Y count---"+rows);
		}
		
		
		log.debug("ofacUpdateNo - "+ofacUpdateNo);
		if (ofacUpdateNo != null
				&& !ofacUpdateNo.isEmpty()) {
			queryString.append("update con_ip_master set is_ofac = 'N' where id in (");
			/*for (Long id : tpaUpdateNo) {
				queryString.append(id +",");
			} */
			queryString.append(ofacUpdateNo.toString().substring(1,ofacUpdateNo.toString().length()-1));
			queryString.append(")");
			
			SQLQuery query = getSession().createSQLQuery(queryString.toString());
			int rows = query.executeUpdate();
			log.debug("IPs updated ofac as N count---"+rows);
		}
		
		log.debug("anyUpdateYes - "+anyUpdateYes);
		queryString = new StringBuffer();
		if (anyUpdateYes != null
				&& !anyUpdateYes.isEmpty()) {
			queryString.append("update con_ip_master set IS_ANY_IP = 'Y' where id in (");
			/*for (Long id : anyUpdateYes) {
				queryString.append(id +",");
			}*/ 
			queryString.append(anyUpdateYes.toString().substring(1,anyUpdateYes.toString().length()-1));
			queryString.append(")");
			
			SQLQuery query = getSession().createSQLQuery(queryString.toString());
			int rows = query.executeUpdate();
			log.debug("IPs updated ANY as Y count---"+rows);
		}
		
		
		log.debug("anyUpdateNo - "+anyUpdateNo);
		if (anyUpdateNo != null
				&& !anyUpdateNo.isEmpty()) {
			queryString.append("update con_ip_master set IS_ANY_IP = 'N' where id in (");
			/*for (Long id : anyUpdateNo) {
				queryString.append(id);
			} */
			queryString.append(anyUpdateNo.toString().substring(1,anyUpdateNo.toString().length()-1));
			queryString.append(")");
			
			SQLQuery query = getSession().createSQLQuery(queryString.toString());
			int rows = query.executeUpdate();
			log.debug("IPs updated ANY as N count---"+rows);
		}
		
		return fireWallRule;
    }
    
    /**
     * 
     * @param fireWallRule
     */
    @Transactional(readOnly = true)
    public boolean isRuleModified(FireWallRule fireWallRule) {
    	log.debug("isRuleModified firewall rule id - "+fireWallRule.getId());
    	StringBuffer queryString = new StringBuffer();
    	queryString.append("from FireWallRule fwr where fwr.deletedTIRequest is null and fwr.tiRequest.id = "+fireWallRule.getTiRequest().getId());
    	queryString.append(" and fwr.id = "+fireWallRule.getId());
    	if (fireWallRule.getPolicyGroup() != null && fireWallRule.getPolicyGroup().getId() != null
    			&& fireWallRule.getPolicyGroup().getId().longValue() > 0) {
    		queryString.append(" and fwr.policyGroup.id = "+fireWallRule.getPolicyGroup().getId());
    	}
    	/*if (fireWallRule.getPolicy() != null && fireWallRule.getPolicy().getId() != null
    			&& fireWallRule.getPolicy().getId().longValue() > 0) {
    		queryString.append(" and fwr.policy.id = "+fireWallRule.getPolicy().getId());
    	}*/
    	if (fireWallRule.getSourceZone() != null && fireWallRule.getSourceZone().getId() != null 
    			&& fireWallRule.getSourceZone().getId().longValue() > 0) {
    		queryString.append(" and fwr.sourceZone.id = "+fireWallRule.getSourceZone().getId());
    	}
    	if (fireWallRule.getDestinationZone() != null && fireWallRule.getDestinationZone().getId() != null 
    			&& fireWallRule.getDestinationZone().getId().longValue() > 0) {
    		queryString.append(" and fwr.destinationZone.id = "+fireWallRule.getDestinationZone().getId());
    	}
    	if (fireWallRule.getSourceNetworkZone() != null && fireWallRule.getSourceNetworkZone().getId() != null 
    			&& fireWallRule.getSourceNetworkZone().getId().longValue() > 0) {
    		queryString.append(" and fwr.sourceNetworkZone.id = "+fireWallRule.getSourceNetworkZone().getId());
    	}
    	if (fireWallRule.getDestinationNetworkZone() != null && fireWallRule.getDestinationNetworkZone().getId() != null 
    			&& fireWallRule.getDestinationNetworkZone().getId().longValue() > 0) {
    		queryString.append(" and fwr.destinationNetworkZone.id = "+fireWallRule.getDestinationNetworkZone().getId());
    	}
    	if (fireWallRule.getSourceObject() != null && fireWallRule.getSourceObject().getIpAddress() != null
    			&& !fireWallRule.getSourceObject().getIpAddress().isEmpty()) {
    		queryString.append(" and fwr.sourceObject.ipAddress = '"+fireWallRule.getSourceObject().getIpAddress().trim()+"'");
    	}
    	if (fireWallRule.getDestinationObject() != null && fireWallRule.getDestinationObject().getIpAddress() != null
    			&& !fireWallRule.getDestinationObject().getIpAddress().isEmpty()) {
    		queryString.append(" and fwr.destinationObject.ipAddress = '"+fireWallRule.getDestinationObject().getIpAddress().trim()+"'");
    	}
    	if (fireWallRule.getPortObject() != null && fireWallRule.getPortObject().getPortNumber() != null
    			&& !fireWallRule.getPortObject().getPortNumber().isEmpty()) {
    		queryString.append(" and fwr.portObject.portNumber = '"+fireWallRule.getPortObject().getPortNumber().trim()+"'");
    	}
    	log.debug("isRuleModified queryString - "+queryString.toString());
    	FireWallRule orgFirewallRule = (FireWallRule)getSession().createQuery(queryString.toString()).uniqueResult();
    	if (orgFirewallRule != null) {
    		log.debug("isRuleModified - orgFirewallRule is not null");
	    	FirewallRuleValidator ipAddressValidator = new FirewallRuleValidator();
	    	ipAddressValidator.setSession(getSession());
	    	log.debug("There are no changes to save");
	    	return ipAddressValidator.isRuleModified(orgFirewallRule, fireWallRule);
    	} 
    	return true;
    }
    
    /**
     * 
     * @param fireWallRule
     */
    @Transactional(readOnly = true)
    public FireWallRule identifyExistingRules(FireWallRule fireWallRule) {
    	StringBuffer queryString = new StringBuffer();
    	queryString.append("from FireWallRule fwr where fwr.deletedTIRequest is null and fwr.tiRequest.id = "+fireWallRule.getTiRequest().getId());
    	queryString.append(" and fwr.id != "+fireWallRule.getId());
    	if (fireWallRule.getPolicyGroup() != null && fireWallRule.getPolicyGroup().getId() != null
    			&& fireWallRule.getPolicyGroup().getId().longValue() > 0) {
    		queryString.append(" and fwr.policyGroup.id = "+fireWallRule.getPolicyGroup().getId());
    	}
    	/*if (fireWallRule.getPolicy() != null && fireWallRule.getPolicy().getId() != null
    			&& fireWallRule.getPolicy().getId().longValue() > 0) {
    		queryString.append(" and fwr.policy.id = "+fireWallRule.getPolicy().getId());
    	} else {
    		queryString.append(" and fwr.policy.id is null ");
    	}*/
    	if (fireWallRule.getSourceZone() != null && fireWallRule.getSourceZone().getId() != null 
    			&& fireWallRule.getSourceZone().getId().longValue() > 0) {
    		queryString.append(" and fwr.sourceZone.id = "+fireWallRule.getSourceZone().getId());
    	}
    	if (fireWallRule.getDestinationZone() != null && fireWallRule.getDestinationZone().getId() != null 
    			&& fireWallRule.getDestinationZone().getId().longValue() > 0) {
    		queryString.append(" and fwr.destinationZone.id = "+fireWallRule.getDestinationZone().getId());
    	}
    	if (fireWallRule.getSourceNetworkZone() != null && fireWallRule.getSourceNetworkZone().getId() != null 
    			&& fireWallRule.getSourceNetworkZone().getId().longValue() > 0) {
    		queryString.append(" and fwr.sourceNetworkZone.id = "+fireWallRule.getSourceNetworkZone().getId());
    	}
    	if (fireWallRule.getDestinationNetworkZone() != null && fireWallRule.getDestinationNetworkZone().getId() != null 
    			&& fireWallRule.getDestinationNetworkZone().getId().longValue() > 0) {
    		queryString.append(" and fwr.destinationNetworkZone.id = "+fireWallRule.getDestinationNetworkZone().getId());
    	}
    	List<FireWallRule> firewallRules = (List<FireWallRule>)getSession().createQuery(queryString.toString()).list();
    	FirewallRuleValidator ipAddressValidator = new FirewallRuleValidator();
    	ipAddressValidator.setSession(getSession());
    	ipAddressValidator.createSetsForCurrentRule(fireWallRule);
    	for (FireWallRule fwrule : firewallRules) {
    		ipAddressValidator.validateforDuplicateRules(fwrule, fireWallRule.getId());
    		if (ipAddressValidator.getValidationErrors() != null && ipAddressValidator.getValidationErrors().size() > 0) {
        		fireWallRule.getValidationErrors().addAll(ipAddressValidator.getValidationErrors());
            	return fireWallRule;
        	}
    	}
    	
    	//To Validate - Same IP cannot mapped with two different Network Zones.
    	queryString = new StringBuffer();
    	queryString.append("from FireWallRule fwr where fwr.deletedTIRequest is null and fwr.tiRequest.id = "+fireWallRule.getTiRequest().getId());
    	queryString.append(" and fwr.id != "+fireWallRule.getId());
    	firewallRules = (List<FireWallRule>)getSession().createQuery(queryString.toString()).list();
    	for (FireWallRule fwrule : firewallRules) {
    		ipAddressValidator.validateNetworkZonesWithIP(fwrule, fireWallRule.getId());
    	}
    	
    	if ((fireWallRule.getSourceObject() != null && fireWallRule.getSourceObject().getIpAddress() != null
    			&& !fireWallRule.getSourceObject().getIpAddress().isEmpty()) 
    			&& (fireWallRule.getSourceObject().getId() == null || fireWallRule.getSourceObject().getId().longValue() < 0)) {
        	if (isIPObjectNameExists(fireWallRule.getTiRequest().getId(), fireWallRule.getSourceObject().getIpAddress().trim())) {
        		fireWallRule.getValidationErrors().add("The Object Name already exists - "+fireWallRule.getSourceObject().getIpAddress());
        	}
    	}
    	if ((fireWallRule.getDestinationObject() != null && fireWallRule.getDestinationObject().getIpAddress() != null
    			&& !fireWallRule.getDestinationObject().getIpAddress().isEmpty()) 
			&& (fireWallRule.getDestinationObject().getId() == null || fireWallRule.getDestinationObject().getId().longValue() < 0)) {
        	if (isIPObjectNameExists(fireWallRule.getTiRequest().getId(), fireWallRule.getDestinationObject().getIpAddress().trim())) {
        		fireWallRule.getValidationErrors().add("The Object Name already exists - "+fireWallRule.getDestinationObject().getIpAddress());
        	}
    	}
    	if ((fireWallRule.getPortObject() != null && fireWallRule.getPortObject().getPortNumber() != null
    			&& !fireWallRule.getPortObject().getPortNumber().isEmpty()) 
			&& (fireWallRule.getPortObject().getId() == null || fireWallRule.getPortObject().getId().longValue() < 0)) {
    		if (isIPObjectNameExists(fireWallRule.getTiRequest().getId(), fireWallRule.getPortObject().getPortNumber().trim())) {
        		fireWallRule.getValidationErrors().add("The Object Name already exists - "+fireWallRule.getPortObject().getPortNumber());
        	}
    	}
    	if (ipAddressValidator.getValidationErrors() != null && ipAddressValidator.getValidationErrors().size() > 0) {
    		fireWallRule.getValidationErrors().addAll(ipAddressValidator.getValidationErrors());
        	return fireWallRule;
    	}
    	return fireWallRule;
    }

    /*
     *To Identify the Existing Ports and IPs
     */
    /**
     *
     * @param portNumber
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public String getServiceName(Long portNumber) throws BusinessException {
	String serviceName = "";
	List<PortServiceMapping> portServiceMappings = (List<PortServiceMapping>) getSession()
		.createQuery(
			"from PortServiceMapping psm where psm.portId="
				+ portNumber).list();
	PortServiceMapping portServiceMapping = null;
	if (portServiceMappings != null && !portServiceMappings.isEmpty()) {
	    portServiceMapping = portServiceMappings.get(0);
	} else {
	    throw new BusinessException("Service for Port Number - "
		    + portNumber + " does not exist");
	}

	if (portServiceMapping != null) {
	    serviceName = portServiceMapping.getServiceType();
	} else {
	    throw new BusinessException("Service for Port Number - "
		    + portNumber + " does not exist");
	}
	return serviceName;
    }

    @Override
    @Transactional(readOnly = true)
    public List<FireWallPolicyGroup> getFirewallGroups(Long fwLocation,
	    Long connectivityType) {
	Session session = getSession();
	List<FireWallPolicyGroup> list = (List<FireWallPolicyGroup>) session
		.createQuery(
			"from FireWallPolicyGroup fg where active='Y' and connectivityType.id = "
				+ connectivityType
				+ " and connectionFWLocation.id=" + fwLocation)
		.list();
	return list;

    }

    @Override
    @Transactional(readOnly = true)
    public List<FirewallPolicy> getFirewallPolicies(FireWallRuleProcess fwRuleProcess) {
		Session session = getSession();
		String policyName = fwRuleProcess.getPolicy();
		String firewallType = fwRuleProcess.getFwType();
		String policyGroup = fwRuleProcess.getPolicyGroup();
		int offSet = fwRuleProcess.getOffset();
		Criteria criteria = session.createCriteria(FirewallPolicy.class);
		if (policyName != null && !policyName.isEmpty()) {
		    criteria.add(Restrictions.ilike("name", policyName.trim(),
			    MatchMode.ANYWHERE));
		}
		if (firewallType != null && !firewallType.isEmpty()) {
		    criteria.add(Restrictions.eq("fwType", firewallType));
		}
		if (policyGroup != null && !policyGroup.isEmpty()) {
			criteria.createCriteria("fireWallPolicyGroup", "fireWallPolicyGroup");
			criteria.add(Restrictions.eq("fireWallPolicyGroup.id", Long.valueOf(policyGroup)));
		}
		if (fwRuleProcess.getFwName() != null && !fwRuleProcess.getFwName().isEmpty()) {
			criteria.createCriteria("firewalls", "firewalls");
		    criteria.add(Restrictions.ilike("firewalls.firewallName", fwRuleProcess
			    .getFwName(), MatchMode.ANYWHERE));
		}
		session.enableFilter("excludeDeleted");
		criteria.addOrder(Order.asc("id"));
		fwRuleProcess.setRowCount(getRowCount(criteria));
		addPagination(criteria, offSet, 10);
		List<FirewallPolicy> list = criteria.list();
		return list;
    }

    @Override
    @Transactional(readOnly = true)
    public List<IPAddress> getIPAddresses(SearchFirewallRuleRequest fwRuleProcess) {
    	log.info("FireWallRuleProcessImpl::getIPAddresses methods starts...");
    	//if (fwRuleProcess.getFwType() != null && !fwRuleProcess.getFwType().isEmpty()
		//		&& "IP".equalsIgnoreCase(fwRuleProcess.getFwType())) {
			Session session = getSession();
			int offSet = fwRuleProcess.getOffset();
			Criteria criteria = session.createCriteria(IPAddress.class);
			if (fwRuleProcess.getFilterText() != null && !fwRuleProcess.getFilterText().isEmpty()) {
			    criteria.add(Restrictions.ilike("ipAddress", fwRuleProcess.getFilterText(),
				    MatchMode.ANYWHERE));
			}
			
			criteria.add(Restrictions.ne("templateFlag", "Y"));
			criteria.addOrder(Order.asc("id"));
			fwRuleProcess.setRowCount(getRowCount(criteria));
			addPagination(criteria, offSet, 10);
			List<IPAddress> list = criteria.list();
			log.info("FireWallRuleProcessImpl::getIPAddresses methods ends...");
			return list;
    	/*} else {
    		log.info("FireWallRuleProcessImpl::getIPAddresses methods ends...");
    		return searchTemplateIPObjects(fwRuleProcess);
    	}*/    	
    }

    @Override
    @Transactional(readOnly = true)
    public List<FireWallRuleIP> searchTemplateIPObjects(SearchFirewallRuleRequest fwRuleProcess) {
 	   log.info("FireWallRuleProcessImpl::searchTemplateObjects methods starts..."+fwRuleProcess.getTiRequest());
 	   
 	   Session session = getSession();
 	   StringBuffer ipdetailsQuery = new StringBuffer();
 	
	 ipdetailsQuery.append(" select distinct mst.*, rule.ID as objruleid ");
 	   ipdetailsQuery.append(" from con_ip_master mst ,con_fw_rule rule, history_con_fw_rule hrule, ti_process tp, relationship rl, ti_request tr ");
 	   ipdetailsQuery.append(" where tp.id = tr.process_id and tp.relationship_id = rl.id ");
 	   ipdetailsQuery.append(" and rl.relationship_type in ('"+C3parStaticNames.IP_TEMPLATE+"') ");
 	   ipdetailsQuery.append(" and mst.template_flag = 'Y' ");
 	   ipdetailsQuery.append(" and rule.src_obj_id = mst.id and rule.deleted_ti_request_id is null ");
 	    
 	   ipdetailsQuery.append(" and tr.id=rule.ti_request_id and rule.ti_request_id <> "+fwRuleProcess.getTiRequest());
		
 	   ipdetailsQuery.append(" and rule.ID = hrule.con_fw_rule_id ");
		if (fwRuleProcess.getFilterText() != null && !fwRuleProcess.getFilterText().isEmpty()) {
			ipdetailsQuery.append(" and upper(mst.ip_address) like upper('%"+fwRuleProcess.getFilterText()+"%') ");
		}
		if (fwRuleProcess.getRequesterResourceType() != 0) {
			ipdetailsQuery.append(" and rule.src_nwzone_id = "+fwRuleProcess.getRequesterResourceType());
		}
		if (fwRuleProcess.getTargetResourceType() != 0) {
			ipdetailsQuery.append(" and rule.src_nwzone_id = "+fwRuleProcess.getTargetResourceType());
		}
	  ipdetailsQuery.append(" union "); 
	  ipdetailsQuery.append(" select distinct mst.*, rule.ID as objruleid ");
	  ipdetailsQuery.append(" from con_ip_master mst ,con_fw_rule rule , history_con_fw_rule hrule, ti_process tp, relationship rl, ti_request tr ");
	  ipdetailsQuery.append(" where tp.id = tr.process_id and tp.relationship_id = rl.id ");
	  ipdetailsQuery.append(" and rl.relationship_type in ('"+C3parStaticNames.IP_TEMPLATE+"') ");
	  ipdetailsQuery.append(" and mst.template_flag = 'Y' ");
	  ipdetailsQuery.append(" and rule.dst_obj_id = mst.id and rule.deleted_ti_request_id is null ");
	  
	  ipdetailsQuery.append(" and tr.id=rule.ti_request_id and rule.ti_request_id <> "+fwRuleProcess.getTiRequest());
		
 	   ipdetailsQuery.append(" and rule.ID = hrule.con_fw_rule_id ");
		if (fwRuleProcess.getFilterText() != null && !fwRuleProcess.getFilterText().isEmpty()) {
			ipdetailsQuery.append(" and upper(mst.ip_address) like upper('%"+fwRuleProcess.getFilterText()+"%') ");
		}
		if (fwRuleProcess.getRequesterResourceType() != 0) {
			ipdetailsQuery.append(" and rule.dst_nwzone_id = "+fwRuleProcess.getRequesterResourceType());
		}
		if (fwRuleProcess.getTargetResourceType() != 0) {
			ipdetailsQuery.append(" and rule.dst_nwzone_id = "+fwRuleProcess.getTargetResourceType());
		}
		
	  log.debug("IPDetailsServiceImpl::loadIPDetails query - >"+ipdetailsQuery.toString());
 	  SQLQuery query = session.createSQLQuery(ipdetailsQuery.toString());
 	  query.addEntity("mst", IPAddress.class);
	  query.addScalar("objruleid", LongType.INSTANCE);
 	  int rowCount = getRowCount(ipdetailsQuery.toString());
 	  fwRuleProcess.setRowCount(rowCount);
 	  addPagination(query, fwRuleProcess.getOffset(), 10);
 		
 	 // List<IPAddress> list = query.list();
	 List<FireWallRuleIP> ipList = new ArrayList<FireWallRuleIP>();
	 FireWallRuleIP fireWallRuleIP = null;
	   
	 List<Object[]> rows = query.list();
	
	 if(rows != null){
		for (Object[] obj : rows) {
			fireWallRuleIP = new FireWallRuleIP();
			fireWallRuleIP.setIpAddress((IPAddress)obj[0]);
			fireWallRuleIP.setObjRuleID((Long)obj[1]);
			ipList.add(fireWallRuleIP);
		}
	 }
	   
 	  log.info("FireWallRuleProcessImpl::searchTemplateObjects methods ends...");
 	  return ipList;
    }
    
    @Transactional(readOnly = true)
    public List<FireWallRulePort> searchTemplatePortObjects(SearchFirewallRuleRequest fwRuleProcess) {
  	   log.info("FireWallRuleProcessImpl::searchTemplateObjects methods starts...");
  	   log.debug("FireWallRuleProcessImpl::TIRequest..."+fwRuleProcess.getTiRequest());
  	   Session session = getSession();
  	   StringBuffer ipdetailsQuery = new StringBuffer();
  	
  	   ipdetailsQuery.append(" select distinct mst.*, rule.ID as objruleid ");
   	   ipdetailsQuery.append(" from con_port_lookup mst ");
   	   ipdetailsQuery.append(" ,con_fw_rule rule , history_con_fw_rule hrule , ti_process tp, relationship rl, ti_request tr " );
   	   ipdetailsQuery.append(" where tp.id = tr.process_id and tp.relationship_id = rl.id ");
 	   ipdetailsQuery.append(" and rl.relationship_type in ('"+C3parStaticNames.PORT_TEMPLATE+"') ");		
 	   ipdetailsQuery.append(" and rule.prt_obj_id=mst.id ");
 	   ipdetailsQuery.append(" and rule.deleted_ti_request_id is null ");
   	   ipdetailsQuery.append(" and mst.template_flag='Y' ");
   	   ipdetailsQuery.append(" and rule.ID = hrule.con_fw_rule_id ");
   	   ipdetailsQuery.append(" and tr.id=rule.ti_request_id and rule.ti_request_id <> "+fwRuleProcess.getTiRequest());
   		if (fwRuleProcess.getFilterText() != null && !fwRuleProcess.getFilterText().isEmpty()) {
   			ipdetailsQuery.append(" and upper(mst.port_number) like upper('%"+fwRuleProcess.getFilterText()+"%') ");
   		}
    
 	  log.debug("IPDetailsServiceImpl::loadIPDetails query - >"+ipdetailsQuery.toString());
  	  SQLQuery query = session.createSQLQuery(ipdetailsQuery.toString());
  	  query.addEntity("mst", Port.class);
	  query.addScalar("objruleid", LongType.INSTANCE);
  	  int rowCount = getRowCount(ipdetailsQuery.toString());
  	  fwRuleProcess.setRowCount(rowCount);
  	  addPagination(query, fwRuleProcess.getOffset(), 10);
  		
  	  //List<Port> list = query.list();
  	  List<FireWallRulePort> portList = new ArrayList<FireWallRulePort>();
  	  FireWallRulePort fireWallRulePort = null;
	   
  	  List<Object[]> rows = query.list();
  	  
  	  if(rows != null){
	  	  for (Object[] obj : rows) {
	  		fireWallRulePort = new FireWallRulePort();
	  		fireWallRulePort.setPort((Port)obj[0]);
	  		fireWallRulePort.setObjRuleID((Long)obj[1]);
	  		portList.add(fireWallRulePort);
	  	  }
  	  }
  		
  	  log.info("FireWallRuleProcessImpl::searchTemplateObjects methods ends...");
  	  return portList;
     }

    @Override
    public int resetFAFGeneratedStatus(long tiRequestId, long firewallGroupId,long fwRuleID,String isIPReg) {
    	log.info("FireWallRuleProcessImpl::resetFAFGeneratedStatus method...fwRuleID==>"+fwRuleID);
    	
    	String ipRegSql = "";    	
    	if(isIPReg != null && isIPReg.equalsIgnoreCase("Y")){
    		ipRegSql = " and isIpReg = 'Y'";
    	}else{
    		ipRegSql = " and ( isIpReg = 'N' or isIpReg is null)";
    	}
    	
	    int count = getSession().createQuery(
			" update FireWallRule set FAFGenerated=? where (updatedTIRequest.id= ? or deletedTIRequest.id= ?) and policyGroup.id=? "+ipRegSql)
		.setString(0, "N").setLong(1, tiRequestId).setLong(2, tiRequestId).setLong(3,firewallGroupId).executeUpdate();
	    
	    /*Session session = getSession();
	
		Query q1 = session.createSQLQuery("{ call UPDATE_FAF_STATUS(?,?,?) }");		
		q1.setLong(0, tiRequestId); 
		q1.setLong(1, fwRuleID); 
		q1.setLong(2, firewallGroupId);*/
		
		return count;
    }

    @Override
    @Transactional(readOnly = true)
    public FirewallPolicy getFirewallPolicy(FireWallRuleProcess fwRuleProcess) {
	Session session = getSession();
	return (FirewallPolicy) session.createQuery(
		"from FirewallPolicy rule where rule.id="
			+ fwRuleProcess.getFireWallRule().getPolicy().getId())
		.uniqueResult();
    }

    @Override
    public void deleteFirewallRule(Long firewallRuleId, Long tirequestId) {
		Session session = getSession();
		FireWallRule fireWallRule = (FireWallRule) session.get(FireWallRule.class, firewallRuleId);
		TIRequest tiRequest = new TIRequest();
		tiRequest.setId(tirequestId);
		fireWallRule.setStatus(FireWallRule.DELETE);
		fireWallRule.setFAFGenerated("N");
		fireWallRule.setDeletedTIRequest(tiRequest);
		getHibernateTemplate().update(fireWallRule);
		long policyGroup = 0;
		if(fireWallRule.getPolicyGroup() != null){
			policyGroup = fireWallRule.getPolicyGroup().getId();
		}	
		try {
			lazyInitialize(fireWallRule.getSourceIPs());
			lazyInitialize(fireWallRule.getDestinationIPs());
			deleteFirewallRuleApplications(fireWallRule, true);
		} catch (Exception e) {
			
		}
		resetFAFGeneratedStatus(tirequestId, policyGroup, firewallRuleId,fireWallRule.getIsIpReg());	
    }

    @Override
    public void toggleBidirectionalRule(Long firewallRuleId){
    	Session session = getSession();
    	FireWallRule fireWallRule = (FireWallRule) session.get(FireWallRule.class, firewallRuleId);
    	
    	if( fireWallRule.getBidirectional() == null || fireWallRule.getBidirectional().equalsIgnoreCase("OFF")){
    		fireWallRule.setBidirectional("ONINPROGRESS");
    	
    	} else if( fireWallRule.getBidirectional().equalsIgnoreCase("OFFINPROGRESS") ){
    		fireWallRule.setBidirectional("ON");
    		
    	} else if( fireWallRule.getBidirectional().equalsIgnoreCase("ON")){
    		fireWallRule.setBidirectional("OFFINPROGRESS");
    		
    	} else if( fireWallRule.getBidirectional().equalsIgnoreCase("ONINPROGRESS") ){
    		fireWallRule.setBidirectional("OFF");
    	}
    	
    	getHibernateTemplate().update(fireWallRule);
    }
    
    @Override
    @Transactional(readOnly = true)
    public HashMap<Long, Integer> applicationCountForIPs(FireWallRuleProcess fwRuleProcess) {
	    Session session = getSession();
		HashMap<Long, Integer> appCount = new HashMap<Long, Integer>();
		SQLQuery query = session.createSQLQuery("select fra.ip_id as ipid, count(*) as appcount " 
				+" from con_fw_rule_application fra "
				+" where fra.ti_request_id = " + fwRuleProcess.getTiRequest()
				+" and fra.rule_id = " + fwRuleProcess.getRuleId()
				+" and fra.deleted_ti_request_id is null "
				+" group by fra.ip_id");
		query.addScalar("ipid", LongType.INSTANCE);
		query.addScalar("appcount", IntegerType.INSTANCE);
		List<Object[]> rows = query.list();
		
		for (Object[] obj : rows) {
			appCount.put((Long)obj[0], (Integer)obj[1]);
		}
		return appCount;
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean completeCheckIPDetails(FireWallRuleProcess fwRuleProcess,String con_type) {
	    Session session = getSession();
	   // String isIpReg= fwRuleProcess.getIsIpReg();
		   String isIp = "";
		   if(con_type.equalsIgnoreCase("IpReg"))
			{
				isIp = "rule.IS_IPREG='Y'";
			}
			else
			{
				isIp = "(rule.IS_IPREG!='Y' or rule.IS_IPREG is null)";
			}
		SQLQuery query = session.createSQLQuery("select mst.ip_address "+
			" from con_ip_master mst "+  
			" left outer join con_fw_rule_source_ip sip on sip.ip_id=mst.id and sip.deleted_ti_request_id is null "+  
			" left outer join con_fw_rule rule on rule.id = sip.rule_id and rule.deleted_ti_request_id is null  " +
			" join resourcetype endA on rule.src_nwzone_id = endA.id and endA.name not in ('3rd Party/CEP','IP Reg ACL') "+ 
			" left outer join con_fw_rule_application fwrapp on fwrapp.deleted_ti_request_id is null and fwrapp.ip_id = mst.id and fwrapp.rule_id = rule.id "+
			" where rule.ti_request_id = "+fwRuleProcess.getTiRequest()+
			" and "
			+ isIp +
			" and (select count(*) from con_fw_rule_application fra, ti_application ta where fra.deleted_ti_request_id is null and fra.id = fwrapp.id "+
			" and ta.id = fwrapp.application_id) <= 0 "+
			" group by mst.ip_address "+
			" union   "+
			" select mst.ip_address "+
			" from con_ip_master mst "+
			" left outer join con_fw_rule_destination_ip dip on dip.ip_id=mst.id  and dip.deleted_ti_request_id is null  "+
			" left outer join con_fw_rule rule on rule.id = dip.rule_id  and rule.deleted_ti_request_id is null  "+
			" join resourcetype endB on rule.dst_nwzone_id = endB.id and endB.name <> '3rd Party/CEP' "+ 
			" left outer join con_fw_rule_application fwrapp on fwrapp.deleted_ti_request_id is null and fwrapp.ip_id = mst.id and fwrapp.rule_id = rule.id  "+
			" where rule.ti_request_id = "+fwRuleProcess.getTiRequest()+
			" and "
			+ isIp +
			" and (select count(*) from con_fw_rule_application fra, ti_application ta where fra.deleted_ti_request_id is null and fra.id = fwrapp.id "+
			" and ta.id = fwrapp.application_id) <= 0 "+
			" group by mst.ip_address"+
			" union "+
			" select distinct mst.ip_address "+
			" from con_ip_master mst, con_fw_rule rule, con_fw_rule_application cfra, ti_application ta,  "+
			" con_fw_rule_source_ip sip where mst.id = cfra.ip_id and ta.id=cfra.application_id "+
			" and sip.ip_id = cfra.ip_id and cfra.rule_id =  rule.id and ta.IS_DECOMMISSIONED = 'Y' and ta.is_device !='Y' and ta.IS_CSI = 'Y' "+
			" and rule.id = sip.rule_id "+
			" and "
			+ isIp +
			" and rule.ti_request_id = "+fwRuleProcess.getTiRequest()+
			" and rule.deleted_ti_request_id is null  "+
			" and sip.deleted_ti_request_id is null  "+
			" and cfra.deleted_ti_request_id is null" +
			" union "+
			" select distinct mst.ip_address "+
			" from con_ip_master mst, con_fw_rule rule, con_fw_rule_application cfra, ti_application ta,  "+
			" con_fw_rule_destination_ip sip where mst.id = cfra.ip_id and ta.id=cfra.application_id "+
			" and sip.ip_id = cfra.ip_id and cfra.rule_id =  rule.id and ta.IS_DECOMMISSIONED = 'Y' and ta.is_device !='Y' and ta.IS_CSI = 'Y' "+
			" and rule.id = sip.rule_id "+
			" and "
			+ isIp +
			" and rule.ti_request_id = "+fwRuleProcess.getTiRequest()+
			" and rule.deleted_ti_request_id is null  "+
			" and sip.deleted_ti_request_id is null  "+
			" and cfra.deleted_ti_request_id is null");
		List<Object[]> rows = query.list();
		
		if (rows != null ){
			log.debug("IP Complete Check rows size"+rows.size());
			if (rows.size() > 0) {
				return false;
			}
		}
		return true;
    }
    
    private List<Long> getIncompleteRules(Long tireqId) {
	    Session session = getSession();
		SQLQuery query = session.createSQLQuery("select distinct rule.id ruleid "+
			" from con_ip_master mst "+  
			" left outer join con_fw_rule_source_ip sip on sip.ip_id=mst.id and sip.deleted_ti_request_id is null "+  
			" left outer join con_fw_rule rule on rule.id = sip.rule_id and rule.deleted_ti_request_id is null  " +
			" join resourcetype endA on rule.src_nwzone_id = endA.id and endA.name <> '3rd Party/CEP' "+ 
			" left outer join con_fw_rule_application fwrapp on fwrapp.deleted_ti_request_id is null and fwrapp.ip_id = mst.id and fwrapp.rule_id = rule.id "+  
			" where rule.ti_request_id = "+tireqId+
			" and (select count(*) from con_fw_rule_application fra where fra.deleted_ti_request_id is null and fra.id = fwrapp.id) <= 0 "+
			" union   "+
			" select distinct rule.id ruleid "+
			" from con_ip_master mst "+
			" left outer join con_fw_rule_destination_ip dip on dip.ip_id=mst.id  and dip.deleted_ti_request_id is null  "+
			" left outer join con_fw_rule rule on rule.id = dip.rule_id  and rule.deleted_ti_request_id is null  "+
			" join resourcetype endB on rule.dst_nwzone_id = endB.id and endB.name <> '3rd Party/CEP' "+ 
			" left outer join con_fw_rule_application fwrapp on fwrapp.deleted_ti_request_id is null and fwrapp.ip_id = mst.id and fwrapp.rule_id = rule.id  "+ 
			" where rule.ti_request_id = "+tireqId+
			" and (select count(*) from con_fw_rule_application fra where fra.deleted_ti_request_id is null and fra.id = fwrapp.id) <= 0 ");
		query.addScalar("ruleId", LongType.INSTANCE);
		
		List<Object[]> rows = query.list();
		
		List<Long> ruleIds = new ArrayList<Long>();
		
		if (rows != null ){
			log.debug("IP Complete Check rows size"+rows.size());
			if (rows.size() > 0) {
				for (Object ruleId : rows) {
					ruleIds.add((Long)ruleId);				
				}
			}
		}
		return ruleIds;
    }

   @Override
    public List<FireWallRuleDestinationIP> getDestinationIpsByFirewallRule(
	    long firewallRuleId,int maxResults) {
	Session session = getSession();
	List<FireWallRuleDestinationIP> list = (List<FireWallRuleDestinationIP>) session
		.createQuery(
			"from FireWallRuleDestinationIP ip where ip.deletedTIRequest is null and ip.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId).setMaxResults(maxResults)
			
		.list();
	return list;
    }

   private List<FirewallRulePolicy> getPoliciesByFirewallRule(long firewallRuleId,int maxResults) {
	Session session = getSession();
	List<FirewallRulePolicy> list = (List<FirewallRulePolicy>) session
		.createQuery(
			"from FirewallRulePolicy policy where policy.deletedTIRequest is null and policy.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId).setMaxResults(maxResults)
		.list();
	return list;
   }
   
    @Override
    public List<FireWallRulePort> getPortsByFirewallRule(long firewallRuleId,int maxResults) {
	Session session = getSession();
	List<FireWallRulePort> list = (List<FireWallRulePort>) session
		.createQuery(
			"from FireWallRulePort port where port.deletedTIRequest is null and port.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId).setMaxResults(maxResults)
		.list();
	
	if (list != null && list.size() > 0) {
		for (FireWallRulePort fireWallRulePort : list) {
			if (fireWallRulePort!= null && fireWallRulePort.getPort() != null
					&& fireWallRulePort.getPort()!= null && "ICMP".equals(fireWallRulePort.getPort().getProtocol())) {
				fireWallRulePort.setControlMessage(getControlMessage(fireWallRulePort.getPort().getControlMsgId()));
			}
		}
	}
	return list;
    }

    private String getControlMessage(Long controlMsgId) {
		Session session = getSession();
		GenericLookup genericlookup = null;
		genericlookup = (GenericLookup) session
				.createQuery("from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.genericLookupDef.id = ?)").setLong(0,controlMsgId).uniqueResult();
		String controlMessage = "";
		if (genericlookup != null && genericlookup.getValue1() != null) {
			controlMessage = genericlookup.getValue1();
		}
		return controlMessage;
	}
    
    @Override
    public List<FireWallRuleSourceIP> getSoureIpsByFirewallRule(
	    long firewallRuleId,int maxResults) {
	Session session = getSession();
	List<FireWallRuleSourceIP> list = (List<FireWallRuleSourceIP>) session
		.createQuery(
			"from FireWallRuleSourceIP ip where ip.deletedTIRequest is null and ip.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId).setMaxResults(maxResults)
		.list();
	return list; 
    }
    
    private List<FireWallRuleDestinationIP> getDeletedDestinationIpsByFirewallRule(
	    long firewallRuleId) {
	Session session = getSession();
	List<FireWallRuleDestinationIP> list = (List<FireWallRuleDestinationIP>) session
		.createQuery(
			"from FireWallRuleDestinationIP ip where ip.deletedTIRequest is not null and ip.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId)
			
		.list();
	return list;
    }

    private List<FirewallRulePolicy> getDeletedPoliciesByFirewallRule(long firewallRuleId) {
    	Session session = getSession();
    	List<FirewallRulePolicy> list = (List<FirewallRulePolicy>) session
    		.createQuery(
    			"from FirewallRulePolicy policy where policy.deletedTIRequest is not null and policy.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId)
    		.list();
    	return list;
    }
   
    private List<FireWallRulePort> getDeletedPortsByFirewallRule(long firewallRuleId) {
	Session session = getSession();
	List<FireWallRulePort> list = (List<FireWallRulePort>) session
		.createQuery(
			"from FireWallRulePort port where port.deletedTIRequest is not null and port.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId)
		.list();
	return list;
    }

    
    private List<FireWallRuleSourceIP> getDeletedSoureIpsByFirewallRule(
	    long firewallRuleId) {
	Session session = getSession();
	List<FireWallRuleSourceIP> list = (List<FireWallRuleSourceIP>) session
		.createQuery(
			"from FireWallRuleSourceIP ip where ip.deletedTIRequest is not null and ip.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId)
		.list();
	return list; 
    }

    @Transactional(readOnly = true)
    public FireWallPolicyGroup getFirewallGroupByName(String name) {
		Session session = getSession();
		FireWallPolicyGroup fireWallPolicyGroup = null;
		List<FireWallPolicyGroup> list = (List<FireWallPolicyGroup>) session
			.createQuery(
				"from FireWallPolicyGroup grp where grp.name = ?").setString(0,name)
			.list();
		if (list != null && list.size() > 0) {
			fireWallPolicyGroup = list.get(0);
		}
		return fireWallPolicyGroup; 
    }
    
    @Transactional(readOnly = true)
    public FirewallPolicy getFirewallPoliyByName(String name) {
		Session session = getSession();
		FirewallPolicy firewallPolicy = null;
		List<FirewallPolicy> list = (List<FirewallPolicy>) session
			.createQuery(
				" from FirewallPolicy pol where upper(pol.name) = upper(?) ").setString(0,name)
			.list();
		if (list != null && list.size() > 0) {
			firewallPolicy = list.get(0);
		}
		return firewallPolicy; 
    }

	@Override
	@Transactional(readOnly = true)
	public boolean isFireWallRulesHasChanged(Long tiRequestId, String conType) {
		log.info("isFireWallRulesHasChanged starts");
		Session session = getSession();
		String isIp = "";
		if(conType.equalsIgnoreCase("IpReg"))
		{
			isIp = "rule.isIpReg='Y'";
		}
		else
		{
			isIp = "(rule.isIpReg!='Y' or rule.isIpReg is null)";
		}
		List fireWallRules = session
				.createQuery(
						"from FireWallRule rule where FAFGenerated='N' and (updatedTIRequest.id= ? or deletedTIRequest.id= ?) and " + isIp)
						.setLong(0, tiRequestId).setLong(1, tiRequestId).setMaxResults(
						1).list();
		
		return fireWallRules!=null && !fireWallRules.isEmpty();

	}
    @Override
    public void saveFireWallRuleBulkUpload(Long tiRequestID, String docType, String contentType, String docName, byte[] fileContent) {
    	TIUploadedDocs uploadedDoc = new TIUploadedDocs();
    	log.info("ManageFirewallRulesAction::FirewallRuleProcessImpl::saveFireWallRuleBulkUpload Starts...");
    	uploadedDoc.setTiRequestId(tiRequestID); 
		uploadedDoc.setDocType(docType);
		uploadedDoc.setContentType(contentType);
		uploadedDoc.setDocName(docName); 
		Blob fileBlob = Hibernate.getLobCreator(getSession()).createBlob(fileContent);
		uploadedDoc.setContent(fileBlob);
		
    	getHibernateTemplate().save(uploadedDoc);
    	log.info("ManageFirewallRulesAction::FirewallRuleProcessImpl::saveFireWallRuleBulkUpload Ends...");
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<TIUploadedDocs> getFireWallRuleBulkUploadFileList(Long tiRequestID ,String docType) {
    	List<TIUploadedDocs> formattedFileList = new ArrayList<TIUploadedDocs>();
    	
		Session session = getSession();
		
		String queryString = "select DOC.* " +
		"from TI_UPLOADED_DOCS DOC, TI_REQUEST TIR " +
		"where DOC.TI_REQUEST_ID = TIR.ID and DOC.DOC_TYPE = '"+docType+"' " +
		"AND TIR.PROCESS_ID = (SELECT PROCESS_ID FROM TI_REQUEST WHERE ID= "+tiRequestID+") " +
		"order by DOC.ID desc";
		
		SQLQuery query =  session.createSQLQuery(queryString);
		query.addEntity("DOC",TIUploadedDocs.class);
		
		formattedFileList = query.list();
		/*for(int count = 0; count < fileList.size(); count++){
			TIUploadedDocs tiuploadeddoc = new TIUploadedDocs();
			Object[] resultDoc = (Object[]) fileList.get(count);

			tiuploadeddoc.setId(((BigDecimal)resultDoc[0]).longValue());
			tiuploadeddoc.setDocName((String)resultDoc[1]);
			tiuploadeddoc.setCreateDate((Timestamp)resultDoc[2]);
			tiuploadeddoc.setVersion(((BigDecimal)resultDoc[3]).intValue());
			
			formattedFileList.add(tiuploadeddoc);
		}*/
    	return formattedFileList;
    }

    @Override
    @Transactional(readOnly = true)
    public TIUploadedDocs getFireWallRuleDownloadFile(Long id) {
		Session session = getSession();
		TIUploadedDocs tiUploadedDoc = null;
		List<TIUploadedDocs> list = (List<TIUploadedDocs>) session
			.createQuery(
				"from TIUploadedDocs docs where docs.id = ?").setLong(0, id)
			.list();
		if (list != null && list.size() > 0) {
			tiUploadedDoc = list.get(0);
		}
		return tiUploadedDoc; 
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<FirewallPolicy> getFirewallCircuitPolicyList(FireWallRuleProcess fwruleProcess) {
    	List<FirewallPolicy> resultList = new ArrayList<FirewallPolicy>();
    	log.info("ManageFirewallRulesAction::FirewallRuleProcessImpl::getFirewallCircuitPolicyList starts..."+fwruleProcess.getTiRequest());
		Session session = getSession();
		String isIpReg= fwruleProcess.getIsIpReg();
		String isIp = "";
		if(isIpReg=="Y")
		{
			isIp = "fwrule.is_ipreg='Y'";
		}
		else
		{
			isIp = "(fwrule.is_ipreg!='Y' or fwrule.is_ipreg is null)";
		}
		StringBuffer queryString = new StringBuffer();
		// ******** while changing query change getFirewallCircuitDetailsCheck() method query also
		//queryString.append(" select distinct fwpolicy.* from CON_FW_RULE fwrule, CON_FW_POLICY fwpolicy where fwrule.POLICY_ID = fwpolicy.ID and fwrule.DELETED_TI_REQUEST_ID is null and fwrule.TI_REQUEST_ID = "+fwruleProcess.getTiRequest());
		queryString.append(" select distinct fwpolicy.* from CON_FW_RULE fwrule, CON_FW_POLICY fwpolicy,CON_FW_RULE_POLICY rulepolicy "+
		"where fwpolicy.ID =rulepolicy.POLICY_ID "+
		"and rulepolicy.rule_id=fwrule.id "+
		"and rulepolicy.DELETED_TI_REQUEST_ID is null "+ 
		"and fwrule.DELETED_TI_REQUEST_ID is null  "+
		"and fwrule.TI_REQUEST_ID = "+fwruleProcess.getTiRequest()+" and "+isIp);
		// create sql query in hibernate
		SQLQuery query = session.createSQLQuery(queryString.toString());
		query.addEntity("fwpolicy", FirewallPolicy.class);
		//get the rowcount of the resultset
		int rowCount = getRowCount(queryString.toString());
		log.info("rowCount==>"+rowCount+",fwruleProcess.getOffset()==>"+fwruleProcess.getOffset()+",fwruleProcess.getLimit()==>"+fwruleProcess.getLimit());
		
		fwruleProcess.setRowCount(rowCount);
		// add pagination parameters
		addPagination(query, fwruleProcess.getOffset(), fwruleProcess.getLimit());
		//retrieve the result
		resultList = query.list();
		
		log.info("ManageFirewallRulesAction::FirewallRuleProcessImpl::getFirewallCircuitPolicyList Ends...");
    	return resultList;
    }

    @Override
    @Transactional(readOnly = true)
    public List<FireWallPolicyGroup> getFirewallCircuitGroupList(FireWallRuleProcess fwruleProcess) {
    	List<FireWallPolicyGroup> resultList = new ArrayList<FireWallPolicyGroup>();
    	log.info("ManageFirewallRulesAction::FirewallRuleProcessImpl::getFirewallCircuitGroupList starts..."+fwruleProcess.getTiRequest());
		Session session = getSession();
		String isIpReg= fwruleProcess.getIsIpReg();
		String isIp = "";
		if(isIpReg=="Y")
		{
			isIp = "fwrule.is_ipreg='Y'";
		}
		else
		{
			isIp = "(fwrule.is_ipreg!='Y' or fwrule.is_ipreg is null)";
		}
		StringBuffer queryString = new StringBuffer();
		// ******** while changing query change getFirewallCircuitDetailsCheck() method query also
		queryString.append(" select distinct fwgroup.* from CON_FW_RULE fwrule, CON_FW_GROUP fwgroup where fwrule.POLICY_GROUP_ID = fwgroup.ID and fwrule.DELETED_TI_REQUEST_ID is null and fwrule.TI_REQUEST_ID = "+fwruleProcess.getTiRequest()+" and "+isIp);
		
		// create sql query in hibernate
		SQLQuery query = session.createSQLQuery(queryString.toString());
		query.addEntity("fwgroup", FireWallPolicyGroup.class);
		//get the rowcount of the resultset
		int rowCount = getRowCount(queryString.toString());
		log.info("rowCount==>"+rowCount+",fwruleProcess.getOffset()==>"+fwruleProcess.getOffset()+",fwruleProcess.getLimit()==>"+fwruleProcess.getLimit());
		
		fwruleProcess.setRowCount(rowCount);
		// add pagination parameters
		addPagination(query, fwruleProcess.getOffset(), fwruleProcess.getLimit());
		//retrieve the result
		resultList = query.list();
		
		log.info("ManageFirewallRulesAction::FirewallRuleProcessImpl::getFirewallCircuitGroupList Ends...");
    	return resultList;
    }

    @Override
    @Transactional(readOnly = true)
    public boolean getFirewallCircuitDetailsCheck(Long tiRequestId) {
    	// ******** while changing query change getFirewallCircuitDetails() method query also    	
    	log.info("ManageFirewallRulesAction::FirewallRuleProcessImpl::getFirewallCircuitDetailsCheck starts..."+tiRequestId);
		Session session = getSession();
		
		StringBuffer queryString = new StringBuffer();
		// ==> while changing query change getFirewallCircuitDetailsCheck() method query also
		queryString.append(" select 1 as count");
		queryString.append(" from TI_REQUEST tirequest,FAF_FIREFLOW_TICKET faffwticket ,FAF_FW_RULE faffwrule left outer join CON_FW_POLICY fwpolicy on faffwrule.policy_id = fwpolicy.ID and fwpolicy.DELETE_FLAG = 'N'");
		queryString.append(" where tirequest.ID = "+tiRequestId+" and tirequest.FIREFLOW_FLAG = 'N' and tirequest.ID = faffwticket.TI_REQUEST_ID and faffwticket.ID = faffwrule.FIREFLOW_TICKET_ID");
		queryString.append(" union ");
		queryString.append(" select 1 as count");
		queryString.append(" from TI_REQUEST tirequest,FAF_FIREFLOW_TICKET faffwticket,FAF_FW_RULE faffwrule ,IMPL_FAF_FW_RULE implfaffwrule left outer join CON_FW_POLICY fwpolicy on implfaffwrule.policy_id = fwpolicy.ID and fwpolicy.DELETE_FLAG = 'N'");
		queryString.append(" where tirequest.ID = "+tiRequestId+" and tirequest.FIREFLOW_FLAG = 'Y' and tirequest.ID = faffwticket.TI_REQUEST_ID and faffwticket.ID = faffwrule.FIREFLOW_TICKET_ID and faffwrule.ID = implfaffwrule.FAF_FW_RULE_ID");
		// create sql query in hibernate
		SQLQuery query = session.createSQLQuery(queryString.toString());
		query.addScalar("count", IntegerType.INSTANCE);
		Integer isRecordAvailable = (Integer)query.uniqueResult();
		
		if(isRecordAvailable != null && isRecordAvailable.intValue() > 0)
			return true;
		else 
			return false;
    }
    
    @Override
    @Transactional(readOnly = true)
    public List getTIReqeustRelationshipDetails(Long tiRequestid) {
	    Session session = getSession();
	    ArrayList resultList = new ArrayList();
		SQLQuery query = session.createSQLQuery("select REQUESTER_RESOURCE_TYPE_ID,TARGET_RESOURCE_TYPE_ID,RELATIONSHIP_TYPE " +
				", (select ID from RESOURCETYPE where upper(NAME) = '"+C3parStaticNames.TEMPLATE_OBJ+"') as TEMPLATE_RESOURCE_TYPE" +
				" from RELATIONSHIP where ID = (select RELATIONSHIP_ID from CON_REQ where ID = " +
				"( select PROCESS_ID from TI_REQUEST where ID ="+tiRequestid+"))");
	
		List<Object[]> result = query.list();
		if(result != null && result.size() > 0){
			Object obj[] = result.get(0);
			if(obj != null){
				//REQUESTER_RESOURCE_TYPE_ID
				if(obj.length > 0 && obj[0] != null){
					resultList.add(new Integer(((BigDecimal)obj[0]).intValue()));
				}else{
					resultList.add(new Integer(0));
				}
				//TARGET_RESOURCE_TYPE_ID
				if(obj.length > 1 && obj[1] != null){
					resultList.add(new Integer(((BigDecimal)obj[1]).intValue()));
				}else{
					resultList.add(new Integer(0));
				}
				//RELATIONSHIP_TYPE
				if(obj.length > 2 && obj[2] != null){
					resultList.add((String)obj[2]);
				}else{
					resultList.add("");
				}
				//TEMPLATE RESOURE TYPE
				if(obj.length > 3 && obj[3] != null){
					resultList.add(new Integer(((BigDecimal)obj[3]).intValue()));
				}else{
					resultList.add(new Integer(0));
				}				
			}
		}else{
			resultList.add(new Integer(0));
			resultList.add(new Integer(0));
			resultList.add("");
		}
    	return resultList;
    }

    @Override
    @Transactional(readOnly = true)
    public List<TemplateConnection> getViewTemplate(FireWallRuleProcess fwRuleProcess) {
		Session session = getSession();
		List<TemplateConnection> templateConList = new ArrayList<TemplateConnection>();
		List resultList = null;
		
		String viewTemplateQuery = ccrQueries.getQueryByName(QueryConstants.VIEW_TEMPLATES);

		/*StringBuffer queryString = new StringBuffer();
		queryString.append("select nvl(conreq.ID,0) as processID,nvl(conreq.CONNECTION_NAME,'') as connectionName"); 
		queryString.append(",(select nvl(max(tirequest.ID),0) from TI_REQUEST tirequest where tirequest.PROCESS_ID = conreq.ID ");
		queryString.append("AND ");
		queryString.append("tirequest.id in( ");
		queryString.append("SELECT  max(tat.ti_request_id) ");
		queryString.append("FROM TI_ACTIVITY_TRAIL TAT,TI_REQUEST TIR,TI_TASK_TYPE TTT ");
		queryString.append("WHERE  ");
		queryString.append("TAT.ACTIVITY_ID=TTT.ID AND ");
		queryString.append("TTT.TASK='Firewall Implementation' AND ");
		queryString.append("tat.activity_status='COMPLETED' and ");
		queryString.append("TAT.TI_REQUEST_ID=TIR.ID and TIR.PROCESS_ID = CONREQ.ID ");
		queryString.append("GROUP BY TIR.PROCESS_ID ");
		queryString.append(")) as tiReqeustID ");
		queryString.append(",(select nvl(NAME,'') from RESOURCETYPE resourcetype where resourcetype.ID = conreq.SOURCE_RESOURCE_TYPE) as sourceNWZone");
		queryString.append(",(select nvl(NAME,'') from RESOURCETYPE resourcetype where resourcetype.ID = conreq.TARGET_RESOURCE_TYPE) as destinationNWZone");		
		queryString.append(",(select count(*) from CON_FW_RULE fwrule1, CON_FW_RULE fwrule2");
		queryString.append(" where fwrule1.ID = fwrule2.TMP_ID");
		queryString.append(" and fwrule2.TI_REQUEST_ID = "+fwRuleProcess.getTiRequest());
		queryString.append(" and fwrule2.DELETED_TI_REQUEST_ID is null");
		queryString.append(" and fwrule2.STATUS != 'DELETE'");
		queryString.append(" and fwrule1.TI_REQUEST_ID in (select tirequest.ID ");
		queryString.append(" from TI_REQUEST tirequest where tirequest.PROCESS_ID = conreq.ID)) as temCount");
		queryString.append(" from CON_REQ conreq, CON_REQ conreq1, ti_request tireq, RELATIONSHIP relation ");
		queryString.append(" where conreq.RELATIONSHIP_ID = relation.ID and conreq1.id=tireq.process_id ");
		queryString.append(" and tireq.id="+fwRuleProcess.getTiRequest()+" and (conreq.SOURCE_RESOURCE_TYPE = conreq1.SOURCE_RESOURCE_TYPE");
		queryString.append(" or conreq.SOURCE_RESOURCE_TYPE = conreq1.TARGET_RESOURCE_TYPE or ");
		queryString.append(" conreq.SOURCE_RESOURCE_TYPE IN (select ID from resourcetype rec where rec.name in ('Citiplex','DMZ')))");
		queryString.append(" and relation.RELATIONSHIP_TYPE = '"+C3parStaticNames.TEMPLATE_OBJ+"'");
		queryString.append(" and (select distinct 1 from history_con_fw_rule where ti_request_id in (select tirequest.ID ");
		queryString.append(" from TI_REQUEST tirequest where tirequest.PROCESS_ID = conreq.ID)) = 1 ");*/
		
		log.debug("getViewTemplate Query----->"+viewTemplateQuery);
		// create sql query in hibernate
		SQLQuery query = session.createSQLQuery(viewTemplateQuery);
		
		query.setLong(0, fwRuleProcess.getTiRequest());
		query.setLong(1, fwRuleProcess.getTiRequest());
		//query.setString(2, C3parStaticNames.TEMPLATE_OBJ);
		query.setLong(2, fwRuleProcess.getValidConnectionID()==0?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE);
		query.setLong(3, fwRuleProcess.getValidConnectionID()==0?0:fwRuleProcess.getValidConnectionID());
		query.setLong(4, fwRuleProcess.getValidConnectionName()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE);
		query.setString(5, fwRuleProcess.getValidConnectionName()==null?QueryConstants.QUERY_STRING_EXCLUDE:fwRuleProcess.getValidConnectionName().trim());


		SQLQuery query2 = session.createSQLQuery(ccrQueries.getQueryByName(QueryConstants.COUNT_VIEW_TEMPLATES));
		
		query2.setLong(0, fwRuleProcess.getTiRequest());
		query2.setLong(1, fwRuleProcess.getTiRequest());
		//query2.setString(2, C3parStaticNames.TEMPLATE_OBJ);
		query2.setLong(2, fwRuleProcess.getValidConnectionID()==0?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE);
		query2.setLong(3, fwRuleProcess.getValidConnectionID()==0?0:fwRuleProcess.getValidConnectionID());
		query2.setLong(4, fwRuleProcess.getValidConnectionName()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE);
		query2.setString(5, fwRuleProcess.getValidConnectionName()==null?QueryConstants.QUERY_STRING_EXCLUDE:fwRuleProcess.getValidConnectionName().trim());
		
		//get the rowcount of the resultset
		int rowCount = getRowCount(query2);
		log.debug("tirequest-->"+fwRuleProcess.getTiRequest()+"rowCount==>"+rowCount+",fwruleProcess.getOffset()==>"+fwRuleProcess.getOffset()+",fwruleProcess.getLimit()==>"+fwRuleProcess.getLimit());
		
		fwRuleProcess.setRowCount(rowCount);
		// add pagination parameters
		addPagination(query, fwRuleProcess.getOffset(), fwRuleProcess.getLimit());
		//retrieve the result
		resultList = query.list();
		log.debug("ManageFirewallRulesAction::FirewallRuleProcessImpl::getViewTemplate...size=>"+resultList.size());
		for(int count = 0; count < resultList.size(); count++){
			TemplateConnection templateCon = new TemplateConnection();
			Object[] resultDoc = (Object[]) resultList.get(count);

			templateCon.setProcessID(((BigDecimal)resultDoc[0]).longValue());			
			templateCon.setConnectionName((String)resultDoc[1]);			
			templateCon.setTiRequestID(((BigDecimal)resultDoc[2]).longValue());
			templateCon.setSourceNWZone((String)resultDoc[3]);
			templateCon.setDestinationNWZone((String)resultDoc[4]);		
			templateCon.setTemCount(((BigDecimal)resultDoc[5]).intValue());
			
			
			templateConList.add(templateCon);
		}
		return templateConList; 
    }    
    
    
    @Override
    @Transactional(readOnly = true)
    public List<HistoryFireWallRule> getTemplateFirewallRules(FireWallRuleProcess fwRuleProcess) {
    	StringBuffer queryString = new StringBuffer();
    	//Modified for task 42665
    	queryString.append("from HistoryFireWallRule fwr where fwr.deletedTIRequest is null and fwr.tiRequest.id = "+fwRuleProcess.getTiRequest());
    	
    	log.debug("getTemplateFirewallRules queryString - "+queryString.toString());
    	List<HistoryFireWallRule> fwruleList = (List<HistoryFireWallRule>)getSession().createQuery(queryString.toString()).list();    	
    	
    	log.debug("lazyInitialize....");
    	if(fwruleList != null && fwruleList.size() > 0){
    		for(HistoryFireWallRule fwrule:fwruleList){
    			lazyInitialize(fwrule);
    			lazyInitialize(fwrule.getSourceIPs());
    			lazyInitialize(fwrule.getDestinationIPs());
    			lazyInitialize(fwrule.getPorts());
    			lazyInitialize(fwrule.getPolicies());
    			lazyInitialize(fwrule.getSourceObject());
    			lazyInitialize(fwrule.getDestinationObject());
    			lazyInitialize(fwrule.getPortObject());
    		}
    	}
    	return fwruleList;
    }

    @Override
    public void saveTemplateFireWallRules(List<FireWallRule> firewallrules) {
    	if(firewallrules != null && firewallrules.size() > 0){
    		int fwRuleNumber = 0;
	    	for(FireWallRule fwrule:firewallrules){
	    		if(fwRuleNumber == 0){
	    			fwRuleNumber = getNextRuleNumber(fwrule.getTiRequest().getId(),fwrule.getIsIpReg());
	    		}else{
	    			fwRuleNumber++;
	    		}
	    		fwrule.setRuleNumber(fwRuleNumber);
	    		log.debug("FirewallRuleServiceImpl::saveTemplateFireWallRules...ruleNumber=>"+fwrule.getRuleNumber());
				getHibernateTemplate().saveOrUpdate(fwrule);

				/*if(fwrule != null && fwrule.getPolicyGroup() != null){
		    		log.debug("FirewallRuleServiceImpl::resetFAFGeneratedStatus....TIRequestID=>"+fwrule.getTiRequest().getId()+", FWPolicyGroup=>"+fwrule.getPolicyGroup().getId());
					resetFAFGeneratedStatus(fwrule.getTiRequest().getId(), fwrule.getPolicyGroup().getId(),fwrule.getId());
				}*/				
	    	}
    	}
    }

    @Override
    @Transactional(readOnly = true)
    public void deleteTemplateFirewallRules(FireWallRuleProcess fwRuleProcess) {
    	//update the status as DELETE and DELETED_TI_REQUEST_ID
    	StringBuffer queryString = new StringBuffer();
    	queryString.append("update CON_FW_RULE fwr set STATUS = 'DELETE', DELETED_TI_REQUEST_ID = " + fwRuleProcess.getTiRequest());
    	queryString.append(" where ( fwr.UPDATED_TI_REQUEST_ID = " + fwRuleProcess.getTiRequest());
    	queryString.append(" or fwr.TI_REQUEST_ID = " + fwRuleProcess.getTiRequest() + ")");
    	queryString.append(" and fwr.DELETED_TI_REQUEST_ID is null");
    	queryString.append(" and fwr.TMP_ID in ( select ID from CON_FW_RULE where ( UPDATED_TI_REQUEST_ID = " + fwRuleProcess.getTemplateID());
    	queryString.append(" or TI_REQUEST_ID = " + fwRuleProcess.getTemplateID() + ")");
    	queryString.append(" and DELETED_TI_REQUEST_ID is null )");
    	
    	SQLQuery query = getSession().createSQLQuery(queryString.toString());
		int rows = query.executeUpdate();
		log.debug("FirewallRuleServiceImpl::deleteTemplateFirewallRules....count=>"+rows);  
		
		if(rows > 0){
			//Reset FAFGenerated Status
			StringBuffer updatequeryString = new StringBuffer();
			updatequeryString.append("update CON_FW_RULE fwr set fwr.FAF_GENERATED = 'N'");
			updatequeryString.append(" where ( fwr.UPDATED_TI_REQUEST_ID = " + fwRuleProcess.getTiRequest());
			updatequeryString.append(" or fwr.TI_REQUEST_ID = " + fwRuleProcess.getTiRequest() + " ) ");
			updatequeryString.append(" and fwr.POLICY_GROUP_ID in ( ");
						updatequeryString.append(" select fwrule1.POLICY_GROUP_ID from CON_FW_RULE fwrule1 ,CON_FW_RULE fwrule2");
						updatequeryString.append(" where fwrule1.TMP_ID = fwrule2.ID");
						updatequeryString.append(" and (fwrule1.UPDATED_TI_REQUEST_ID = " + fwRuleProcess.getTiRequest());
						updatequeryString.append(" or fwrule1.TI_REQUEST_ID = " + fwRuleProcess.getTiRequest() + " ) ");
						updatequeryString.append(" and (fwrule2.UPDATED_TI_REQUEST_ID = " + fwRuleProcess.getTemplateID());
						updatequeryString.append(" or fwrule2.TI_REQUEST_ID = " + fwRuleProcess.getTemplateID() + ") )");
			
	    	SQLQuery updatequery = getSession().createSQLQuery(updatequeryString.toString());
			int updatedrows = updatequery.executeUpdate();
			log.debug("FirewallRuleServiceImpl::deleteTemplateFirewallRules....count=>"+updatedrows);
		}
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<FireWallRuleIP> getTemplateObjects() {
    	Session session = getSession();
    	List<FireWallRuleIP> firewallRuleIPs = (List<FireWallRuleIP>)
    	session.getNamedQuery("getIPsforTemplateObject")
    	.setLong(0, 264381)
    	.setLong(1, 52846)
    	.setString(2, "N")
    	.setLong(3, 53653).list();
    	/*SQLQuery query = session.createSQLQuery("{ ? = call GET_IPS_FOR_TMP_OBJ( ?, ?, ?) }");
    	query.setLong(0, 264381L)
    	.setLong(1, 52846L)
    	.setLong(2, 53653L);
    	query.addEntity(FireWallRuleSourceIP.class);
    	List<FireWallRuleIP> firewallRuleIPs = (List<FireWallRuleIP>)query.list();*/
    	return firewallRuleIPs;
    }

    @Override
    @Transactional(readOnly = true)
    public Long getFirewallGroupID(String firewallGroupName) throws BusinessException {
	    Session session = getSession();
		Long fwGroupID = 0L;
		SQLQuery query = session.createSQLQuery("select ID from CON_FW_GROUP " +
				"where FIREWALL_GROUP = '"+firewallGroupName+"'");
		query.addScalar("ID", LongType.INSTANCE);
		fwGroupID = (Long)query.uniqueResult();
		
		if (fwGroupID == null || fwGroupID == 0L) {
		    throw new BusinessException("Firewall Group ID for Name - "
			    + firewallGroupName + " does not exist");
		}	
		return fwGroupID;
    }

    @Override
    @Transactional( readOnly = true)
    public FireWallPolicyGroup getFirewallPolicyGroup(Long groupid) throws BusinessException {
	    if (groupid == null || groupid == 0L) {
		    throw new BusinessException("Firewall Group ID - " + groupid + " does not exist");
		}
		Session session = getSession();
		FireWallPolicyGroup fwgroup = null;
		List<FireWallPolicyGroup> fwgrouplist = (List<FireWallPolicyGroup>) session
				.createQuery("from com.citigroup.cgti.c3par.fw.domain.FireWallPolicyGroup group where group.active = 'Y' and group.id = ?)").setLong(0,groupid).list();

		if (fwgrouplist != null && fwgrouplist.size() > 0) {
			fwgroup = fwgrouplist.get(0);
		}
		return fwgroup;
    }
    @Transactional( readOnly = true)
    @Override
    public FirewallPolicy getFirewallPolicyForIPReg() throws BusinessException {
	   log.debug("inside firewall policy auto populate");
	   
	   String firewallPolicy = "Global-VPN-RPod-Policy";
	   GenericLookup genericLookup = getGenericLookupValue("IPREG_FIREWALL_POLICY");
	   
	   if (genericLookup != null) {
		   firewallPolicy = genericLookup.getValue2();
	   }
	   
		Session session = getSession();
		FirewallPolicy policy = null;
		List<FirewallPolicy> policyList = (List<FirewallPolicy>) session
				.createQuery("from com.citigroup.cgti.c3par.fw.domain.FirewallPolicy policy where Upper(policy.name) = Upper('"+firewallPolicy+"'))").list();
		log.debug(policyList);
		if (policyList != null && policyList.size() > 0) {
			policy = policyList.get(0);
		}
		return policy;
    }
    @Transactional(readOnly = true)
    @Override
    public String getIpRegSourceIP(IPAddress ipAddress, String relationshipType) throws BusinessException {
	   log.debug("inside bulk upload source ip check"); 
		Session session = getSession();
		String ipAddressStr = "";
		String user_type = "";
		if(C3parStaticNames.THIRD_PARTY.equalsIgnoreCase(relationshipType)){
		 user_type="EXTERNAL";
   	  	}
   	   	else{
   		   user_type="INTERNAL";
   	   	}
		if(ipAddress!= null && ipAddress.getIpAddress() != null){
			ipAddressStr = ipAddress.getIpAddress().trim();
    	}
    	SQLQuery query = session.createSQLQuery("select acl from ip_acl_assignment_master " +
    			"where acl = '" +ipAddressStr+ "' and USER_TYPE = '" +user_type+ "'");

		query.addScalar("acl", StringType.INSTANCE);
		List<String> accessType = (List<String>)query.list();
		
		if(accessType == null || accessType.isEmpty() || accessType.size() <= 0){		
			return "N";
		}
		else{ 
			return "Y"; 
    }
    }
    
    @Override
    //@Transactional( readOnly = false)
    @Transactional(readOnly = true)
    public boolean completeCheckFireWallRules(FireWallRuleProcess fwRuleProcess,String con_type) {
    	boolean completed = true;
	    Session session = getSession();
	   // String isIpReg= fwRuleProcess.getIsIpReg();
	    String isIp = "";
		   if(con_type.equalsIgnoreCase("IpReg"))
			{
				isIp = "rule.IS_IPREG='Y'";
			}
			else
			{
				isIp = "(rule.IS_IPREG!='Y' or rule.IS_IPREG is null)";
			}
		SQLQuery query = session.createSQLQuery("select distinct rule.id from ti_process tp ,relationship rl, ti_request tr, con_fw_rule rule where "+ 
		" tp.id = tr.process_id and tp.relationship_id = rl.id "+
		" and rl.relationship_type not in ('"+C3parStaticNames.IP_TEMPLATE+"','"+C3parStaticNames.PORT_TEMPLATE+"','"+C3parStaticNames.TEMPLATE_OBJ+"') and rule.ti_request_id = tr.id and "+ 
		" rule.ti_request_id =  "+fwRuleProcess.getTiRequest()+" and rule.deleted_ti_request_id is null "+
		" and "+isIp+
		" and ((select count(*) from con_fw_rule_source_ip where rule_id = rule.id and deleted_ti_request_id is null) <= 0 "+
		" or (select count(*) from con_fw_rule_destination_ip where rule_id = rule.id and deleted_ti_request_id is null) <= 0 "+
		" or (select count(*) from con_fw_rule_port where rule_id = rule.id and deleted_ti_request_id is null) <= 0)");
		
		log.debug("completeCheckFireWallRules.query::"+query.getQueryString());
		
		List<Object[]> rows = query.list();
		
		if (rows != null ) {
			log.debug("FireWallRules Complete Check rows size"+rows.size());
			if (rows.size() > 0) {
				completed = false;
			}
		}
	
		if (completed) {
			query = session.createSQLQuery("select distinct 1 from ti_process tp,relationship rl,ti_request tr,con_fw_rule cfr,con_fw_group cfg  "+
					" where tr.id = "+fwRuleProcess.getTiRequest()+" and tp.id = tr.process_id and tp.relationship_id = rl.id " +
					" and rl.relationship_type not in ('"+C3parStaticNames.IP_TEMPLATE+"','"+C3parStaticNames.PORT_TEMPLATE+"','"+C3parStaticNames.TEMPLATE_OBJ+"') "+
					" and cfr.ti_request_id = tr.id and cfr.deleted_ti_request_id is NULL and cfr.policy_group_id = cfg.id "+
					" and cfg.firewall_group in ('TEMPLATE_FIREWALLGROUP','FW_RULE_MIGRATION') ");
				
			log.debug("completeCheckFireWallRules.query::"+query.getQueryString());
			
			rows = query.list();
			
			if (rows != null ) {
				log.debug("FireWallRules Complete Check rows size"+rows.size());
				if (rows.size() > 0) {
					completed = false;
				}
			}
		}
		return completed;
    }
    
    public boolean isIPObjectNameExists(Long tiRequestId, String objectName) {
    	
    	String queryStr = " select distinct 1 from ti_process tp,relationship rl,ti_request tr,con_fw_rule cfr,con_ip_master mst "
    		+" where tp.id = tr.process_id and tp.relationship_id = rl.id "
    		+" and rl.relationship_type in ('"+C3parStaticNames.IP_TEMPLATE+"','"+C3parStaticNames.PORT_TEMPLATE+"','"+C3parStaticNames.TEMPLATE_OBJ+"') "
    		+" and cfr.ti_request_id = tr.id and cfr.deleted_ti_request_id is NULL and mst.id = cfr.src_obj_id " 
    		+" and upper(mst.ip_address) = upper('"+objectName+"') "
    		+" union "
    		+" select distinct 1 from ti_process tp,relationship rl,ti_request tr,con_fw_rule cfr,con_ip_master mst "
    		+" where tp.id = tr.process_id and tp.relationship_id = rl.id "
    		+" and rl.relationship_type in ('"+C3parStaticNames.IP_TEMPLATE+"','"+C3parStaticNames.PORT_TEMPLATE+"','"+C3parStaticNames.TEMPLATE_OBJ+"') "
    		+" and cfr.ti_request_id = tr.id and cfr.deleted_ti_request_id is NULL and mst.id = cfr.dst_obj_id " 
    		+" and upper(mst.ip_address) = upper('"+objectName+"')";
    	
    	Session session = getSession();
 		SQLQuery query = session.createSQLQuery(queryStr);
 		log.debug("isIPObjectNameExists::"+query.getQueryString());
		
		List<Object[]> rows = query.list();
		
		if (rows != null ){
			if (rows.size() > 0) {
				return true;
			}
		}
		return false;
    }
    
    public boolean isPortObjectNameExists(Long tiRequestId, String objectName) {
    	
    	String queryStr = "select distinct 1 from ti_process tp,relationship rl,ti_request tr,con_fw_rule cfr,con_port_lookup mst "
    		+" where tp.id = tr.process_id and tp.relationship_id = rl.id "
    		+" and rl.relationship_type in ("+C3parStaticNames.IP_TEMPLATE+"','"+C3parStaticNames.PORT_TEMPLATE+"','"+C3parStaticNames.TEMPLATE_OBJ+") "
    		+" and cfr.ti_request_id = tr.id and cfr.deleted_ti_request_id is NULL and mst.id = cfr.prt_obj_id " 
    		+" and upper(mst.port_number) = upper('"+objectName+"')";
    	
    	Session session = getSession();
 		SQLQuery query = session.createSQLQuery(queryStr);
 		log.debug("isPortObjectNameExists::"+query.getQueryString());
		
		List<Object[]> rows = query.list();
		
		if (rows != null ){
			if (rows.size() > 0) {
				return true;
			}
		}
		return false;
    }
     @Transactional(readOnly = true)
	 @Override
	 public List<FireWallPolicyGroup> getSearchFirewallGroups(FireWallRuleProcess fwruleProcess) {
			
		List<FireWallPolicyGroup> resultList = new ArrayList<FireWallPolicyGroup>();
    	log.info("ManageFirewallRulesAction::FirewallRuleProcessImpl::getFirewallGroups starts..."+fwruleProcess.getTiRequest());
		Session session = getSession();
		
		StringBuffer queryString = new StringBuffer();
		
		queryString.append(" select distinct fwgroup.* ");
		queryString.append(" from CON_FW_LOCATION location, GENERIC_LOOKUP lookup, GENERIC_LOOKUP_DEFs lookupdefs,");
		queryString.append(" CON_FW_GROUP fwgroup, CON_FW_POLICY fwpolicy, CON_FIREWALL firewall");
		queryString.append(" where location.ID = fwgroup.FW_LOCATION_ID and lookup.ID =  fwgroup.CONNECTIVITY_TYPE ");
		queryString.append(" and lookup.DEFINITION_ID = lookupdefs.ID and lookupdefs.NAME = 'CONNECTIVITY_TYPE' ");
		queryString.append(" and fwgroup.ID = fwpolicy.GROUP_ID(+) and fwpolicy.ID = firewall.POLICY_ID(+) ");
		queryString.append(" and lookup.DELETED = 'N' and fwgroup.IS_ACTIVE = 'Y'");
		queryString.append(" and fwpolicy.DELETE_FLAG = 'N' and firewall.DELETE_FLAG = 'N'");
		
		if (fwruleProcess.getConnectivityType() != null && !fwruleProcess.getConnectivityType().isEmpty()) 
			queryString.append(" and upper(lookup.VALUE1) like upper('%"+fwruleProcess.getConnectivityType()+"%') ");
		
		if (fwruleProcess.getLocation() != null && !fwruleProcess.getLocation().isEmpty()) 
			queryString.append(" and upper(location.LOCATION) like upper('%"+fwruleProcess.getLocation()+"%') ");
			
		if (fwruleProcess.getFirewallGroup() != null && !fwruleProcess.getFirewallGroup().isEmpty()) 
			queryString.append(" and upper(fwgroup.FIREWALL_GROUP) like upper('%"+fwruleProcess.getFirewallGroup()+"%') ");
			
		if (fwruleProcess.getFwType() != null && !fwruleProcess.getFwType().isEmpty()) 
			queryString.append(" and fwpolicy.FW_TYPE = '"+fwruleProcess.getFwType()+"' ");
			
		if (fwruleProcess.getPolicy() != null && !fwruleProcess.getPolicy().isEmpty()) 
			queryString.append(" and upper(fwpolicy.POLICY_NAME) like upper('%"+fwruleProcess.getPolicy()+"%')");

		if (fwruleProcess.getFwName() != null && !fwruleProcess.getFwName().isEmpty()) 
			queryString.append(" and upper(firewall.FIREWALL_NAME) like upper('%"+fwruleProcess.getFwName()+"%')");
		 
		// create sql query in hibernate
		SQLQuery query = session.createSQLQuery(queryString.toString());
		query.addEntity("fwgroup", FireWallPolicyGroup.class);
		//get the rowcount of the resultset
		int rowCount = getRowCount(queryString.toString());
		log.info("rowCount==>"+rowCount+",fwruleProcess.getOffset()==>"+fwruleProcess.getOffset()+",fwruleProcess.getLimit()==>"+fwruleProcess.getLimit());
		
		fwruleProcess.setRowCount(rowCount);
		// add pagination parameters
		addPagination(query, fwruleProcess.getOffset(), fwruleProcess.getLimit());
		//retrieve the result
		resultList = query.list();
		
		log.info("ManageFirewallRulesAction::FirewallRuleProcessImpl::getFirewallGroups Ends...");
    	return resultList;

	 }

	@Override
	public int copyTemplateOstiaAnswers(long templFWRuleID, long fwRuleID) {
		log
				.info("FireWallRuleProcessImpl::copyTemplateOstiaAnswers method...fwRuleID:templFWRuleID==>"
						+ fwRuleID + ":" + templFWRuleID);
		/*
		   getSession().createQuery(
			" update FireWallRule set FAFGenerated=? where (updatedTIRequest.id= ? or deletedTIRequest.id= ?) and policyGroup.id=?")
		.setString(0, "N").setLong(1, tiRequestId).setLong(2, tiRequestId).setLong(3,firewallGroupId).executeUpdate();
		   */
		Session session = getSession();

		Query q1 = session
				.createSQLQuery("{ call COPY_TEMPLATE_OSTIA_ANSWER(?,?) }");
		q1.setLong(0, templFWRuleID);
		q1.setLong(1, fwRuleID);

		return q1.executeUpdate();
	}

	@Override
	@Transactional(readOnly = true)
	public List getObjectIPList(Long tiReqId, String conType) {
		String conTypeQry = "";
		
		if ("FW".equalsIgnoreCase(conType)) {
		 conTypeQry = " (r.is_ipreg is null or r.is_ipreg != 'Y') ";	
		} else if ("IP".equalsIgnoreCase(conType)) {
		 conTypeQry = " (r.is_ipreg = 'Y') ";
		} else {
			conTypeQry = "";
		}
		Session session = getSession();
		String sql ="select ip.* from con_ip_master ip,con_fw_rule r "+
		"where ip.id=r.src_obj_id and r.updated_ti_request_id=? and "+conTypeQry;

		SQLQuery query = session.createSQLQuery(sql.toString());
		query.setLong(0, tiReqId);

		query.addEntity(IPAddress.class);
		return query.list();
	}

	@Override
	@Transactional(readOnly = true)
	public List getObjectPortList(Long tiReqId, String conType) {
		String conTypeQry = "";
		
		if ("FW".equalsIgnoreCase(conType)) {
		 conTypeQry = " (r.is_ipreg is null or r.is_ipreg != 'Y') ";	
		} else if ("IP".equalsIgnoreCase(conType)) {
		 conTypeQry = " (r.is_ipreg = 'Y') ";
		} else {
			conTypeQry = "";
		}
		Session session = getSession();
		String sql ="select ip.* from con_port_lookup ip,con_fw_rule r "+
		"where ip.id=r.prt_obj_id and r.updated_ti_request_id=? and "+conTypeQry;
		SQLQuery query = session.createSQLQuery(sql.toString());
		query.setLong(0, tiReqId);
		query.addEntity(Port.class);
		return query.list();
	}

	@Override
	public void updateIPObjectNames(List<IPAddress> ipAddresses) {
		getHibernateTemplate().saveOrUpdate(ipAddresses);
		
	}

	@Override
	public void updatePortObjectNames(List<Port> ports) {
		getHibernateTemplate().saveOrUpdate(ports);
		
	}

    @Override
    public String getConnectionName(Long ruleID) {
	    Session session = getSession();
		String connectionName = "";
		if(ruleID != null && ruleID.longValue() > 0L){
			SQLQuery query = session.createSQLQuery(
					" select tiprocess.PROCESS_NAME as processname from TI_PROCESS tiprocess, TI_REQUEST tirequest, CON_FW_RULE fwrule" +
					" where tiprocess.ID = tirequest.PROCESS_ID and tirequest.ID = fwrule.UPDATED_TI_REQUEST_ID" +
					" and fwrule.id = "+ruleID);
			query.addScalar("processname", StringType.INSTANCE);
			connectionName = (String)query.uniqueResult();
		}	
		return connectionName;
    }
    
    @Override
    @Transactional(readOnly = true)
    public FireWallRule getFirewallRuleForRisk(long id) {
		Session session = getSession();
		session.enableFilter("excludeDeleted");
		FireWallRule fireWallRule =   (FireWallRule) session.createQuery(
			"from FireWallRule rule where rule.id=" + id).uniqueResult();
		fireWallRule.setRiskSourceIPs(getIPsforRule(id, "S", "N", fireWallRule.getTiRequest().getId()));
		fireWallRule.setRiskDestinationIPs(getIPsforRule(id, "D", "N", fireWallRule.getTiRequest().getId()));
		fireWallRule.setRiskPorts(getPortsforRule(id, "N", fireWallRule.getTiRequest().getId()));
		return fireWallRule;
    }

    @SuppressWarnings("unchecked")
	private List<FireWallRuleIP> getIPsforRule(Long ruleId, String ipFlag, String forFAF, Long tiReqId) {
    	Session session = getSession();
    	List<FireWallRuleIP> firewallRuleIPs = (List<FireWallRuleIP>)
    	session.getNamedQuery("getIPsforRule")
    	.setLong(0, ruleId)
    	.setString(1, ipFlag)
    	.setString(2, forFAF)
    	.setLong(3, tiReqId).list();
    	return firewallRuleIPs;
    }
    
    @SuppressWarnings("unchecked")
	private List<FireWallRulePort> getPortsforRule(Long ruleId, String forFAF, Long tiReqId) {
    	Session session = getSession();
    	List<FireWallRulePort> firewallRulePorts = (List<FireWallRulePort>)
    	session.getNamedQuery("getPortsforRule")
    	.setLong(0, ruleId)
    	.setString(1, forFAF)
    	.setLong(2, tiReqId).list();
    	return firewallRulePorts;
    }
    
    @Override
    public void updateFirewallRuleQuestionnaires(FireWallRule ruleData, boolean deleteFlag) {
    	try {
    		if (deleteFlag) {
        		List<FirewallRuleQuestionnaire> firewallRuleQuestionnaires = null;
            	if (ruleData != null) {
            		log.debug("deleteOstiaQuestionnaire - firewallRule ID......."+ruleData.getId());
            		firewallRuleQuestionnaires = (List<FirewallRuleQuestionnaire>)getSession().createQuery("from FirewallRuleQuestionnaire where firewallRule.id = "
        					+ruleData.getId()).list();
            		if (firewallRuleQuestionnaires != null) {
        	    	log.debug("firewallRuleQuestionnaires size   --------->"+firewallRuleQuestionnaires.size());
            		}
            	}
        		if (firewallRuleQuestionnaires != null && !firewallRuleQuestionnaires.isEmpty()) {
        			log.debug("deleteOstiaQuestionnaire - to delete all.......");
    	    		for (FirewallRuleQuestionnaire ruleQuestionnaire : firewallRuleQuestionnaires) {
    	    			ruleQuestionnaire.setDeletedTIRequest(ruleData.getTiRequest());
    	    			ruleQuestionnaire.setUpdated_date(new Date());
    	    		}
    	    		getHibernateTemplate().saveOrUpdate(firewallRuleQuestionnaires);
        		}
        	} else {
			    List<FirewallRuleQuestionnaire> firewallRuleQuestionnaires = null;
		    	if (ruleData != null) {
		    		log.debug("saveOstiaQuestionnaire - firewallRule ID......."+ruleData.getId());
		    		firewallRuleQuestionnaires = (List<FirewallRuleQuestionnaire>)getSession().createQuery("from FirewallRuleQuestionnaire where firewallRule.id = "
							+ruleData.getId()+" and  deletedTIRequest is null").list();
		    		
		    		if (firewallRuleQuestionnaires != null && !firewallRuleQuestionnaires.isEmpty()) {
			    		for (FirewallRuleQuestionnaire ruleQuestionnaire : firewallRuleQuestionnaires) {
			    			ruleQuestionnaire.setStatus("RiskCheckNotDone");
			    			ruleQuestionnaire.setUpdatedTIRequest(ruleData.getTiRequest());
			    			ruleQuestionnaire.setUpdated_date(new Date());
			    		}
			    		getHibernateTemplate().saveOrUpdate(firewallRuleQuestionnaires);
		    		} else {
		    			FirewallRuleQuestionnaire firewallRuleQuestionnaire = new FirewallRuleQuestionnaire();
					    firewallRuleQuestionnaire.setUpdatedTIRequest(ruleData.getTiRequest());
					    firewallRuleQuestionnaire.setFirewallRule(ruleData);
					    firewallRuleQuestionnaire.setStatus("RiskCheckNotDone");
					    firewallRuleQuestionnaire.setType("Default");
					    getHibernateTemplate().save(firewallRuleQuestionnaire);
		    		}
		    	}
        	}
	    } catch (Exception e)  {
	    	log.error(e,e);
	    }
    }

    @Override
    @Transactional(readOnly = true)
    public List<FirewallRuleApplication> getFirewallRuleApplications(IPDetailsRequest ipDetailsRequest) {
 	   	log.debug("FirewallRuleProcessImpl::getFirewallRuleApplications methods starts...");
 		Session session = getSession();
 		
 		List<Long> ipids = new ArrayList<Long>(); 
		StringBuffer fwApplqueryStr = new StringBuffer();
		fwApplqueryStr.append("select distinct mst.id ipid from con_ip_master mst "
							 +" left outer join CON_FW_RULE_SOURCE_IP sip on sip.ip_id = mst.id  and sip.deleted_ti_request_id is null "
							 +" left outer join con_fw_rule rule on rule.id = sip.rule_id  and rule.deleted_ti_request_id is null "
							 +" where rule.ti_request_id = " + ipDetailsRequest.getTiRequest() +
							 		" and rule.id = " + ipDetailsRequest.getSourceRuleId());
		fwApplqueryStr.append(" union select distinct mst.id ipid from con_ip_master mst "
				 +" left outer join con_fw_rule_destination_ip dip on dip.ip_id = mst.id  and dip.deleted_ti_request_id is null "
				 +" left outer join con_fw_rule rule on rule.id = dip.rule_id  and rule.deleted_ti_request_id is null "
				 +" where rule.ti_request_id = " + ipDetailsRequest.getTiRequest() +
				 		" and rule.id = " + ipDetailsRequest.getSourceRuleId());
		
		SQLQuery query = session.createSQLQuery(fwApplqueryStr.toString());
		query.addScalar("ipid", LongType.INSTANCE);
		log.debug("IPDetailsServiceImpl::getIPsByFirewallRuleId query---"+query.getQueryString());
		ipids = (List<Long>) query.list();
 		
 		
 		Criteria criteria = session.createCriteria(FirewallRuleApplication.class);
 		criteria.createCriteria("tiRequest", "tiRequest");
 		
 		if (ipDetailsRequest.getTiRequest() != 0) {
 		    criteria.add(Restrictions.eq("tiRequest.id", ipDetailsRequest.getTiRequest()));
 		}
 		if (ipDetailsRequest != null && ipDetailsRequest.getSelectedRuleId() != null 
 				&& ipDetailsRequest.getSelectedRuleId().longValue() > 0) {
 			criteria.createCriteria("fireWallRule", "fireWallRule");
 			criteria.add(Restrictions.eq("fireWallRule.id", ipDetailsRequest.getSelectedRuleId()));
 		} 	
 		if (ipids != null 
				&& ipids.size() > 0) {
			criteria.createCriteria("ipAddress", "ipAddress");
			criteria.add(Restrictions.in("ipAddress.id", ipids));
		}
 		List<FirewallRuleApplication> firewallRuleApplications = new ArrayList<FirewallRuleApplication>(); 
 		
 		session.enableFilter("excludeDeleted");
 		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
 		
 		firewallRuleApplications = (List<FirewallRuleApplication>) criteria.list();
 		
 		log.debug("FirewallRuleProcessImpl::getFirewallRuleApplications size---"
 				+firewallRuleApplications != null ? firewallRuleApplications.size():"");
 		
 		log.debug("FirewallRuleProcessImpl::getFirewallRuleApplications methods ends...");
 		return firewallRuleApplications;
    }  
    

    @Override
    @Transactional(readOnly = true)
    public List<FireWallRuleSourceIP> getIPRegSoureIp(long connID,long tiReqID) {
	Session session = getSession();
	List<FireWallRuleSourceIP> list = new ArrayList<FireWallRuleSourceIP>();
	
	StringBuffer queryString = new StringBuffer();	
	queryString.append(" select distinct fwrulesourceip.* ");
	queryString.append(" from con_fw_rule fwrule, con_fw_rule_source_ip fwrulesourceip ");
	queryString.append(" where fwrule.ti_request_id = "+tiReqID+" and fwrule.id = fwrulesourceip.rule_id");
	queryString.append(" and fwrule.is_ipreg = 'Y' and fwrule.deleted_ti_request_id is null");
	// create sql query in hibernate
	SQLQuery query = session.createSQLQuery(queryString.toString());
	query.addEntity("fwrulesourceip", FireWallRuleSourceIP.class);
	//retrieve the result
	list = query.list();
			 
	return list; 
    }
    
    @Transactional(readOnly = true)
    public Long getPreviousVersionTIRequest(Long processID)
    {
    	Long tiRequest = 0L;
    	String reqType = "";
    	Session session = getSession();
    	StringBuilder queryString = new StringBuilder();
    	StringBuilder queryString1 = new StringBuilder();
    	queryString.append(" select request_type from ti_request_type where id in (select ti_request_type_id ");
    	queryString.append(" from ti_request where process_id=" +processID+ " and version_number=(select max(version_number) ");
    	queryString.append(" from ti_request where process_id="+processID+" ) and is_deleted = 'N' ) ");
    	log.debug("TI type query" +queryString);
    	SQLQuery query = session.createSQLQuery(queryString.toString());
    	query.addScalar("request_type",StringType.INSTANCE);
    	reqType = (String) query.uniqueResult();
    	if(reqType.equalsIgnoreCase("ACV"))
    	{
    		//if current phase is ACV, get previous ti_request_id
    		queryString1.append("select id from ti_request where process_id=" +processID+ " and version_number= ");
    		queryString1.append("(select max(version_number) from ti_request where process_id="+processID+" and ti_request_type_id not in ");
    		queryString1.append("(select id from ti_request_type where request_type in ('ACV','ManageContacts')) and is_deleted = 'N' ) and is_deleted = 'N' ");
    		log.debug("TI Request query for ACV" +queryString1);
    		query = session.createSQLQuery(queryString1.toString());
    		query.addScalar("id",LongType.INSTANCE);
    		tiRequest = (Long) query.uniqueResult();
    	}
    	else
    	{
    		//if current phase is other than ACV, get latest ti_request_id
    		queryString1.append("select max(id) as id from ti_request where process_id=" +processID+ " and is_deleted = 'N'");
        	log.debug("TI Request query for non ACV" +queryString1);
        	query = session.createSQLQuery(queryString1.toString());
        	query.addScalar("id",LongType.INSTANCE);
        	tiRequest = (Long) query.uniqueResult();	
    	}
    	return tiRequest;
    }
    
    //Added for task 42665-starts
    //Using history tables for aborted connections
    @Transactional(readOnly = true)
    public Long getPreviousVersionTIRequestForTemplate(Long processID)
    {
    	Long tiRequest = 0L;
    	Session session = getSession();
    	StringBuilder queryString = new StringBuilder();
    	
    		//if current phase is other than ACV, get latest ti_request_id
    		queryString.append("select max(ti_request_id) as id from history_con_fw_rule where ti_request_id in (select id from ti_request where process_id ="+processID+")");
        	log.debug("TI Request query for template connection" +queryString);
        	SQLQuery query = session.createSQLQuery(queryString.toString());
        	query.addScalar("id",LongType.INSTANCE);
        	tiRequest = (Long) query.uniqueResult();	
    	
    	return tiRequest;
    }
    
    
    @Override
    @Transactional(readOnly = true)
    public List<HistoryFireWallRule> getFirewallRulesForTemplate(FireWallRuleProcess fwRuleProcess) {
		Session session = getSession();
		Criteria criteria = session.createCriteria(HistoryFireWallRule.class);
		
		criteria.createCriteria("tiRequest", "tiRequest");
		if (fwRuleProcess.getTiRequest() != 0) {
		    criteria.add(Restrictions.eq("tiRequest.id", fwRuleProcess
			    .getTiRequest()));
		}
		
		session.enableFilter("excludeDeleted");
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.addOrder(Order.desc("isNew"));
		criteria.addOrder(Order.desc("status"));
		criteria.addOrder(Order.desc("updated_date"));
		fwRuleProcess.setRowCount(getRowCount(criteria));
		
		addPagination(criteria, fwRuleProcess.getOffset(), fwRuleProcess
			.getLimit());
		
		List<HistoryFireWallRule> fireWallRules = criteria.list();
		for(HistoryFireWallRule fireWallRule : fireWallRules)	{
			log.debug("In firewallRuleProcessImpl getFirewallRulesCollectionLimit ---"+fwRuleProcess.getCollectionLimit());
		    fireWallRule.setSourceIPs(getSoureIpsByFirewallRuleForTemplate(fireWallRule.getId(),fwRuleProcess.getCollectionLimit()));
		    fireWallRule.setDestinationIPs(getDestinationIpsByFirewallRuleForTemplate(fireWallRule.getId(),fwRuleProcess.getCollectionLimit()));
		    fireWallRule.setPorts(getPortsByFirewallRuleForTemplate(fireWallRule.getId(),fwRuleProcess.getCollectionLimit()));
		    fireWallRule.setPolicies(getPoliciesByFirewallRuleForTemplate(fireWallRule.getId(),fwRuleProcess.getCollectionLimit()));
		    fireWallRule.setTemplateConnectionName(getConnectionName(fireWallRule.getTemplateID()));
		    
		}
		return fireWallRules;

    }

    
     public List<HistoryFireWallRuleDestinationIP> getDestinationIpsByFirewallRuleForTemplate(
 	    long firewallRuleId,int maxResults) {
 	Session session = getSession();
 	List<HistoryFireWallRuleDestinationIP> list = (List<HistoryFireWallRuleDestinationIP>) session
 		.createQuery(
 			"from HistoryFireWallRuleDestinationIP ip where ip.deletedTIRequest is null and ip.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId).setMaxResults(maxResults)
 			
 		.list();
 	return list;
     }

    private List<HistoryFirewallRulePolicy> getPoliciesByFirewallRuleForTemplate(long firewallRuleId,int maxResults) {
 	Session session = getSession();
 	List<HistoryFirewallRulePolicy> list = (List<HistoryFirewallRulePolicy>) session
 		.createQuery(
 			"from HistoryFirewallRulePolicy policy where policy.deletedTIRequest is null and policy.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId).setMaxResults(maxResults)
 		.list();
 	return list;
    }
    
    
     public List<HistoryFireWallRulePort> getPortsByFirewallRuleForTemplate(long firewallRuleId,int maxResults) {
 	Session session = getSession();
 	List<HistoryFireWallRulePort> list = (List<HistoryFireWallRulePort>) session
 		.createQuery(
 			"from HistoryFireWallRulePort port where port.deletedTIRequest is null and port.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId).setMaxResults(maxResults)
 		.list();
 	
 	if (list != null && list.size() > 0) {
 		for (HistoryFireWallRulePort fireWallRulePort : list) {
 			if (fireWallRulePort!= null && fireWallRulePort.getPort() != null
 					&& fireWallRulePort.getPort()!= null && "ICMP".equals(fireWallRulePort.getPort().getProtocol())) {
 				fireWallRulePort.setControlMessage(getControlMessage(fireWallRulePort.getPort().getControlMsgId()));
 			}
 		}
 	}
 	return list;
     }

     
     
     public List<HistoryFireWallRuleSourceIP> getSoureIpsByFirewallRuleForTemplate(
 	    long firewallRuleId,int maxResults) {
 	Session session = getSession();
 	List<HistoryFireWallRuleSourceIP> list = (List<HistoryFireWallRuleSourceIP>) session
 		.createQuery(
 			"from HistoryFireWallRuleSourceIP ip where ip.deletedTIRequest is null and ip.fireWallRule.id = ? order by id desc").setLong(0,firewallRuleId).setMaxResults(maxResults)
 		.list();
 	return list; 
     }
     
     //Modified for task 42665-ends
}
