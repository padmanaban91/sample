/**
 *
 */
package com.citigroup.cgti.c3par.common.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.admin.domain.DailyLoad;
import com.citigroup.cgti.c3par.admin.domain.FirewallFreeze;
import com.citigroup.cgti.c3par.admin.domain.VacationFreeze;
import com.citigroup.cgti.c3par.audit.domain.AuditTrailProcess;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityBPMDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.LookupDTO;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.common.domain.AuditLog;
import com.citigroup.cgti.c3par.common.domain.AuditObjectType;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.GenericLookupDef;
import com.citigroup.cgti.c3par.common.domain.ISOContacts;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditResponse;
import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.domain.Person;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequestInfo;
import com.citigroup.cgti.c3par.fw.domain.FafFireflowTicket;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.SearchRelationshipProcess;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyLocationXref;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.webtier.forms.ListLookupsForm;
import com.citigroup.cgti.c3par.webtier.helper.Util;

/**
 * @author ne36745
 * 
 */
@SuppressWarnings("unchecked")
@Transactional
public class CommonServiceImpl extends BasePersistanceImpl implements
		CommonServicePersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(CommonServiceImpl.class);
	private FAFRequestInfo fafRequestInfo;

	@Override
	@Transactional(readOnly = true)
	public List<GenericLookup> getConnectivityTypes() {
		Session session = getSession();
		List<GenericLookup> list = (List<GenericLookup>) session
				.createQuery(
						"from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.genericLookupDef.id="
								+ getDefinitionId("CONNECTIVITY_TYPE")).list();

		return list;

	}

	private Long getDefinitionId(String defName) {
		Session session = getSession();
		GenericLookupDef res = (GenericLookupDef) session.createQuery(
				"from GenericLookupDef def where upper(def.name)=upper('"
						+ defName + "')").uniqueResult();

		return res.getId();

	}

	@Override
	@Transactional(readOnly = true)
	public List<FirewallLocation> getFirewallLocations() {
		Session session = getSession();
		List<FirewallLocation> list = (List<FirewallLocation>) session
				.createQuery("from FirewallLocation").list();
		return list;

	}

	@Override
	@Transactional(readOnly = true)
	public List<GenericLookup> getControlMessagesList() {
		Session session = getSession();
		List<GenericLookup> list = (List<GenericLookup>) session
				.createQuery(
						"from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.genericLookupDef.id="
								+ getDefinitionId("CONTROL MESSAGES")).list();

		return list;
	}

	@Override
	@Transactional(readOnly = true)
	public List<GenericLookup> getDeviceTypes() {
		Session session = getSession();
		List<GenericLookup> list = (List<GenericLookup>) session
				.createQuery(
						"from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.genericLookupDef.id="
								+ getDefinitionId("Device Type")).list();

		return list;

	}
	
	@Override
	@Transactional(readOnly = true)
	public List<GenericLookup> getProtocols() {
		Session session = getSession();
		List<GenericLookup> list = (List<GenericLookup>) session
				.createQuery(
						"from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.genericLookupDef.id="
								+ getDefinitionId("Protocol")).list();

		return list;

	}
	
	@Override
	@Transactional(readOnly = true)
	public List<GenericLookup> getFirewallTypes() {
		Session session = getSession();
		List<GenericLookup> list = (List<GenericLookup>) session
				.createQuery(
						"from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.genericLookupDef.id="
								+ getDefinitionId("Firewall")).list();

		return list;

	}

	/*
	 * public List<ResourceType> getResourceTypes() { Session session =
	 * getSession(); List<ResourceType> list = (List<ResourceType>)
	 * session.createQuery(
	 * "from com.citigroup.cgti.c3par.common.domain.ResourceType").list();
	 * 
	 * return list;
	 * 
	 * }
	 */

	@Transactional(readOnly = true)
	public List<ResourceType> getResourceTypes(Long processId) {
		log.info("In Service: CommonServiceImpl: getResourceTypes() starts ");
		Session session = getSession();
		String queryString = "select * from resourcetype rec where rec.name in ('Citiplex','DMZ') "
				+ " OR (rec.name not in ('Template','IP Template','Port Template', 'IP Reg ACL') AND rec.id = (select source_resource_type from con_req where id = "
				+ processId
				+ "))"
				+ " OR (rec.name not in ('Template','IP Template','Port Template', 'IP Reg ACL') AND rec.id = (select target_resource_type from con_req where id = "
				+ processId + "))";
		SQLQuery query = session.createSQLQuery(queryString);
		
		query.addEntity("rec", ResourceType.class);
		log.info("In Service: CommonServiceImpl: getResourceTypes()  ends ");
		return query.list();

	} 
	
	@Transactional(readOnly = true)
	public List<ResourceType> getInternalResourceTypes(Long processId) {
		log.info("In Service: CommonServiceImpl: getResourceTypes() starts ");
		Session session = getSession();
		String queryString = "select * from resourcetype rec where rec.perimeter = 'Internal' "
				+ " and rec.name not in ('Template','IP Template','Port Template','IP Reg ACL')";
		SQLQuery query = session.createSQLQuery(queryString);
		
		query.addEntity("rec", ResourceType.class);
		log.info("In Service: CommonServiceImpl: getResourceTypes()  ends ");
		return query.list();

	}
	
	
	@Transactional(readOnly = true)
	public List<ResourceType> getIPConnResourceTypes(Long processId) {
		log.info("In Service: CommonServiceImpl: getResourceTypes() starts ");
		Session session = getSession();
		String queryString = "select * from resourcetype rec where rec.name in ('IP Reg ACL') ";
		SQLQuery query = session.createSQLQuery(queryString);
		
		query.addEntity("rec", ResourceType.class);
		log.info("In Service: CommonServiceImpl: getResourceTypes()  ends ");
		return query.list();

	}   


	@Override
	 @Transactional( readOnly = true)
	public FAFRequestInfo getConnectionInfo(FAFRequestInfo fafRequestInfo,String isIPReg) {

		log.info("In Service: CommonServiceImpl: getConnectionInfo() called ");
		Util util = new Util();
		Long connectionId = fafRequestInfo.getOriginalConnectionRequestId();
		Person requestor = util.getRequesterDetails(connectionId);
		// if(planningEntity != null &&
		// !(planningEntity.getId().equals(connectionRequestId))){
		FAFRequest fafRequest = new FAFRequest();
		TIRequest tiRequest = fafRequest.getTIRequest(fafRequestInfo.getTiRequest());
		log.info("In Service: CommonServiceImpl: getConnectionInfo() TiRequest Id is: "
						+ fafRequestInfo.getTiRequest()
						+ "\t ConnectionId is: " + connectionId);
		Person currCycleRequestor = (util.getRequesterDetailsByTiRequest(fafRequestInfo.getTiRequest()));

		ArrayList origBusJustification = (util.getOrigBusJustification(connectionId, (long) tiRequest.getVersionNumber()));
		ArrayList businessContacts = (util.getBusinessContactsDetails(connectionId, (long) tiRequest.getVersionNumber()));
		String currBusJustfication=(util.getCurrentBusJustfication(tiRequest.getId()));
		ArrayList applicationList =util.getFirewallRuleApplicationDetails(tiRequest.getId(),isIPReg);
		Map<String, String> implInfo=util.getFirewallImplementationInfo(connectionId, tiRequest.getId(),(long) tiRequest.getVersionNumber(), fafRequestInfo.getIsIpReg());
		log.debug("In Service: CommonServiceImpl: Set the info to fafRequestInfo obj");
		Map<String, String> sowAndCmp = util.getCMPAndSOWByVersionWithoutType(connectionId, (long) tiRequest.getVersionNumber());
		String cabApprovers = util.getCabApproversList(fafRequestInfo.getTiRequest());
		fafRequestInfo.setFafSplInstruction((String)implInfo.get("SPL_INSTR"));
		fafRequestInfo.setFafCompletionDate((String)implInfo.get("COMPLETION_DATE"));
		fafRequestInfo.setFafInfomanId((String)implInfo.get("INFOMAN_ID"));
		log.info("Implementation info -- Special Instruction-- "+implInfo.get("SPL_INSTR"));
		log.info("Implementation info -- Completion Date-- "+implInfo.get("COMPLETION_DATE"));
		log.info("Implementation info -- Infoman Id-- "+implInfo.get("INFOMAN_ID"));
		fafRequestInfo.setCurrBusJustfication(currBusJustfication);
		fafRequestInfo.setCmpID(sowAndCmp.get("CMP"));
		fafRequestInfo.setSowNumber(sowAndCmp.get("SOW"));
		fafRequestInfo.setApplicationList(applicationList);
		fafRequestInfo.setOriginalConnectionRequestId(connectionId);
		fafRequestInfo.setConnectionName(fafRequestInfo.getConnectionName());
		fafRequestInfo.setRequestor(requestor);
		fafRequestInfo.setCurrCycleRequestor(currCycleRequestor);
		fafRequestInfo.setOrigBusJustification(origBusJustification);
		fafRequestInfo.setBusinessContacts(businessContacts);
		fafRequestInfo.setFireflowFlag(tiRequest.getFireflowFlag());
		fafRequestInfo.setVersionNumber(tiRequest.getVersionNumber());
		fafRequestInfo.setCabApprovers(cabApprovers);
		
		log.debug("In Service: Fireflow flag is: "
				+ fafRequestInfo.getFireflowFlag() + "\t SOW is: "
				+ fafRequestInfo.getSowNumber());
		log.debug("In Service: CommonServiceImpl: End of the service ");

		return fafRequestInfo;
	}

	@Override
	@Transactional( readOnly = true)
	public TIRequest getTIRequest(long processId, int version) {
		TIRequest tiRequest = null;
		log.debug("CommonServiceImpl: getTIRequest: Entered with Ti Process ID: "+ processId);
		try {
			tiRequest = (TIRequest) getSession().createQuery("from TIRequest tr where tr.tiProcess.id=? and tr.versionNumber=?")
			.setLong(0, processId)
			.setInteger(1, version).uniqueResult();
	    
		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException(
					" There was an exception while getting ti Request using tiprocess: processId is: "+ processId+"\t and version id"+version);
		}
		log.debug("CommonServiceImpl: getTIRequest: Exiting with Ti Request: processId is: "+ processId+"\t and version id"+version);
		return tiRequest;
	}

	@Override
	@Transactional(readOnly = true)
	public Map<Long, String> getAllCyclesAndVersion(long processId,String isIpReg) {
		Map<Long, String> verNoList = new LinkedHashMap<Long, String>();
		List<Object[]> tiRequests = null;
		FafFireflowTicket fafFireflowTicket = new FafFireflowTicket();
		log.debug("CommonServiceImpl: getAllCyclesAndVersion: Entered with Ti Process ID: "+ processId);
		try {
			/*tiRequests =  getSession().createQuery("select id,versionNumber,ti from TIRequest tr where tr.tiProcess.id=?")
			.setLong(0, processId)
			.list();*/
			String isIpRegSQL = null;
			if(isIpReg != null && isIpReg.equalsIgnoreCase("Y"))
			{
				isIpRegSQL = "ip_reg = 'Y'";
			}
			else
			{
				isIpRegSQL = "(ip_reg = 'N' or ip_reg is null)";
			}
			tiRequests =  getSession().createSQLQuery("select distinct t.id,t.version_number,f.ti_request_id from ti_request t left outer join faf_fireflow_ticket f"+ 
							" on f.ti_request_id=t.id and f.status not in (?, ?,?) and "+isIpRegSQL+" where t.process_id=? order by t.id desc").setString(0, FafFireflowTicket.REJECTED)
							.setString(1, FafFireflowTicket.DELETED).setString(2, FafFireflowTicket.REJRCTED).setLong(3, processId).list();
			
			for (Object[] objects : tiRequests) {
				Long tiReq=((BigDecimal) objects[0]).longValue();
				
				if (objects[2] != null) {
					StringBuffer sb = new StringBuffer();
					Long tiReqInTicket=((BigDecimal) objects[2]).longValue();
					if(tiReq.equals(tiReqInTicket)){
						sb.append("*");
						sb.append(objects[1]);
						verNoList.put(tiReq, sb.toString());
						sb = null;
					} 
				} else {
					verNoList.put(tiReq , objects[1].toString());
				}
					
			}
	    
		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException(
					" There was an exception while getting Version num list using processId is: "+ processId);
			
		}
		log.debug("CommonServiceImpl: getAllCyclesAndVersion: Version Number List is: "+ verNoList);
		
		return verNoList;
	}

	@Override
	@Transactional( readOnly = true)
	public TIRequest getPlanningTIRequest(Long processId) {
	    TIRequest tiRequest = null;
		log.debug("CommonServiceImpl: getPlanningTIRequest: Entered with Ti Process ID: "+ processId);
		try {
			tiRequest = (TIRequest) getSession().createQuery("from TIRequest tr where tr.tiProcess.id=? order by tr.id asc")
			.setLong(0, processId).setMaxResults(1).uniqueResult();
	    
		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException(
					" There was an exception while getting ti Request using tiprocess: processId is: "+ processId);
		}
		log.debug("CommonServiceImpl: getPlanningTIRequest: Exiting with Ti Request: processId is: "+ processId);
		return tiRequest;
	}
	
	@Transactional(readOnly = true)
	public Long getPlanningIdForTiRequestId(Long tiRequestId){
		Long planningId = 0L;
		try {
			SQLQuery query = getSession().createSQLQuery("select planning_id planningid from c3par.ti_request_planning_xref where ti_request_id="+tiRequestId.longValue());
			query.addScalar("planningid", LongType.INSTANCE);
			planningId = (Long)query.uniqueResult();
			
			if (planningId == null || planningId.longValue() == 0) {				
				SQLQuery query1 = getSession().createSQLQuery("select max(planning_id) planningid from c3par.ti_request_planning_xref where ti_request_id in (select b.id from c3par.ti_request a ,c3par.ti_request b where a.id= "+tiRequestId.longValue()+" and a.process_id=b.process_id )");
				query1.addScalar("planningid", LongType.INSTANCE);
				planningId = (Long)query1.uniqueResult();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		log.debug("Planning Id is " + planningId + " for tiRequestID " + tiRequestId);
		return planningId;
	}
	
	@Transactional(readOnly = true)
	public boolean isBuscritEmerConnection(Long tirequestid){
		Long tireqid = 0L;
		
		SQLQuery query = getSession().createSQLQuery(" select ti.id tireqid from TI_REQUEST ti, GENERIC_LOOKUP lookup " +
					" where ti.id = "+tirequestid.longValue()+" and ti.priority_id = lookup.id and lookup.value1  in ('BUSCRIT','EMER')");
		query.addScalar("tireqid", LongType.INSTANCE);
		tireqid = (Long)query.uniqueResult();
		
		log.debug("isBuscritEmerConnection :: tirequestid -> "+tirequestid);
		
		if (tireqid != null && tireqid.longValue() > 0) {
			return true;
		}
		return false;		
	}
	/*
	@Override
	public FireWallZone getFirewallZone(String name){
		List<FireWallZone> firewallZones = null;
		FireWallZone fireWallZone = null;
	    firewallZones = (List<FireWallZone>) getSession()
		    .createQuery("from FireWallZone zone where zone.name = ?)").setString(0,name);
	    
		if (firewallZones != null && firewallZones.size() > 0) {
			fireWallZone = firewallZones.get(0);
		}
		return fireWallZone;
	}
	*/
	
	@Override
	@Transactional(readOnly = true)
	public ResourceType getNetworkZone(String nwZone){
		List<ResourceType> networkZones = null;
		ResourceType networkZone = null;
		networkZones = (List<ResourceType>) getSession()
		    .createQuery("from ResourceType resourceType where upper(resourceType.name) = upper(?))").setString(0,nwZone).list();
	    
		if (networkZones != null && networkZones.size() > 0) {
			networkZone = networkZones.get(0);
		}
		return networkZone;
	}
	
	@Override
	@Transactional(readOnly = true)
	public GenericLookup getControlMessage(String controlMessage){
		Session session = getSession();
		GenericLookup genericlookup = null;
		List<GenericLookup> glList = (List<GenericLookup>) session
				.createQuery("from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.value1 = ?)").setString(0,controlMessage).list();

		if (glList != null && glList.size() > 0) {
			genericlookup = glList.get(0);
		}
		return genericlookup;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public GenericLookup getControlMessage(Long controlMsgId) {
		Session session = getSession();
		GenericLookup genericlookup = null;
		genericlookup = (GenericLookup) session
				.createQuery("from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.id = ?)").setLong(0,controlMsgId).uniqueResult();

		return genericlookup;
	}
	
	@Override
	public List<TIMailAudit> getEMailAuditTrailList(AuditTrailProcess auditTrailProcess) {
		Session session = getSession();
		log.debug("CommonServiceImpl: getEMailAuditTrailList: started :: processId ==> "+ auditTrailProcess.getTiProcess());
		
		StringBuffer query = new StringBuffer();
		query.append("select tiprocess.ID ProcessID ");
		query.append(",decode(tirequesttype.request_type,'Create','Planning','Maintain','Maintenance', 'Terminate', 'Termination', 'ACV', 'ACV','ManageContacts','Maintain Contacts') RequestType ");
		query.append(",tirequest.VERSION_NUMBER Version ");
		query.append(",timailaudit.TEMPLATE_ID Activity ");
		query.append(",timailaudit.TO_LIST ToList ");
		query.append(",timailaudit.CC_LIST CcList ");
		query.append(",timailaudit.DONOTSEND_LIST doNotSendList ");
		query.append(",to_char(timailaudit.CREATED_DATE,'MM-DD-YYYY HH24:MI') CreatedDate ");
		query.append(",timailaudit.ID MailAuditID ");
		query.append(",(select lookup.value2 from generic_lookup lookup, generic_lookup_defs def where lookup.definition_id = def.id and def.name = 'MAIL_AUDIT_LABEL' and ");
		query.append(" upper(lookup.VALUE1) = upper(timailaudit.TEMPLATE_ID)) notificationLabel ");		
		query.append("from TI_PROCESS tiprocess, TI_REQUEST tirequest, TI_REQUEST_TYPE tirequesttype, TI_MAIL_AUDIT timailaudit ");
		query.append("where tiprocess.ID = tirequest.PROCESS_ID ");
		query.append("and tirequest.ID = timailaudit.TI_REQUEST_ID ");
		query.append("and tirequest.TI_REQUEST_TYPE_ID = tirequesttype.ID ");
		query.append("and tiprocess.ID = " + auditTrailProcess.getTiProcess());
		query.append("order by tirequest.VERSION_NUMBER desc, timailaudit.CREATED_DATE asc");
		
		SQLQuery sqlquery = session.createSQLQuery(query.toString());

		sqlquery.addScalar("ProcessID", LongType.INSTANCE);
		sqlquery.addScalar("RequestType", StringType.INSTANCE);
		sqlquery.addScalar("Version", IntegerType.INSTANCE);
		sqlquery.addScalar("Activity", StringType.INSTANCE);
		sqlquery.addScalar("ToList", StringType.INSTANCE);
		sqlquery.addScalar("CcList", StringType.INSTANCE);
		sqlquery.addScalar("doNotSendList", StringType.INSTANCE);
		sqlquery.addScalar("CreatedDate", StringType.INSTANCE);
		sqlquery.addScalar("MailAuditID", LongType.INSTANCE);
		sqlquery.addScalar("notificationLabel", StringType.INSTANCE);
		
		List<Object[]> rows = sqlquery.list();
		List<TIMailAudit> list = new ArrayList<TIMailAudit>();
		TIMailAudit mailAudit = null;
		
		if(rows != null){
			int prevVerNo = 0, verNo = 0;
			for (Object[] obj : rows) {
				mailAudit = new TIMailAudit();
				
				verNo = (Integer)obj[2];
				
				mailAudit.setProcessID((Long)obj[0]);
				mailAudit.setRequestType((String)obj[1]);
				if(verNo != 0 && prevVerNo != verNo){
					mailAudit.setVersionNumber((Integer)obj[2]);
				}else{
					mailAudit.setVersionNumber(0);
				}
				mailAudit.setTemplateID((String)obj[3]);
				mailAudit.setToList((String)obj[4]);
				mailAudit.setCcList((String)obj[5]);
				mailAudit.setDoNotSendList((String)obj[6]);
				mailAudit.setCreatedDateDisplay((String)obj[7]);
				mailAudit.setId((Long)obj[8]);
				mailAudit.setNotificationType((String)obj[9]);
					//Retrieve the response mails
					List<TIMailAuditResponse> responseMails = (List<TIMailAuditResponse>) session
							.createQuery("from TIMailAuditResponse res where res.tiMailAudit.id = ?)").setLong(0,mailAudit.getId()).list();				
					mailAudit.setResponseMails(responseMails);

				list.add(mailAudit);				
				prevVerNo = verNo;
			}
		}
		log.debug("CommonServiceImpl: getEMailAuditTrailList: Ends :: list.size ==> "+ list != null ? list.size() : "Empty"); 
		return list;
	}

	@Override
	public TIMailAudit getEMailAuditTrail(AuditTrailProcess auditTrailProcess) {
		Session session = getSession();
		log.debug("CommonServiceImpl: getEMailAuditTrail: Starts :: getEmailAuditTrailID ==> "+auditTrailProcess.getEmailAuditTrailID()); 
		TIMailAudit mailAudit = null;
		List<TIMailAudit> mailAuditList = (List<TIMailAudit>) session
				.createQuery("from TIMailAudit audit where audit.id = ?)").setLong(0,auditTrailProcess.getEmailAuditTrailID()).list();

		if (mailAuditList != null && mailAuditList.size() > 0) {
			mailAudit = mailAuditList.get(0);
		}
		return mailAudit;
	}

	@Override
	public TIMailAuditResponse getResponseEMailAuditTrail(AuditTrailProcess auditTrailProcess) {
		Session session = getSession();
		log.debug("CommonServiceImpl: getResponseEMailAuditTrail: Starts :: getEmailAuditTrailID ==> "+auditTrailProcess.getEmailAuditTrailID()); 
		TIMailAuditResponse mailAudit = null;
		List<TIMailAuditResponse> mailAuditList = (List<TIMailAuditResponse>) session
				.createQuery("from TIMailAuditResponse resaudit where resaudit.id = ?)").setLong(0,auditTrailProcess.getEmailAuditTrailID()).list();

		if (mailAuditList != null && mailAuditList.size() > 0) {
			mailAudit = mailAuditList.get(0);
		}
		return mailAudit;
	}
	
	@Override
	public List<AuditLog> getAdminChangeDetails(Long processID) {
		
		Session session = getSession();
		/*Criteria criteria = session.createCriteria(AuditLog.class);
		criteria.createCriteria("tiRequest", "tiRequest");
		criteria.createCriteria("tiRequest.tiProcess","tiProcess");
		if (processID != 0) {
		    criteria.add(Restrictions.eq("tiProcess.id",processID));
		}
		List<AuditLog> auditLogList = criteria.list();*/
		
		String query = "select log.* from audit_log log, ti_request ti where log.ti_request_id = ti.id and ti.process_id = "+processID+ " order by created_date desc ";
		
		SQLQuery sqlquery = session.createSQLQuery(query);
		sqlquery.addEntity("log", AuditLog.class);
		
		List<AuditLog> auditLogList = (List<AuditLog>)sqlquery.list();
		
		return auditLogList;
	}

	/**
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<RelationshipDTO> getRelationshipList(SearchRelationshipProcess searchRelationshipProcess) {
		Session session = getSession();
		List<RelationshipDTO> relationshipDTOs = new ArrayList<RelationshipDTO>();
		log.info("CommonServiceImpl :: searchRelationshipProcess.getOldRelationshipId() ===> "+searchRelationshipProcess.getOldRelationshipId());
		try{
			StringBuffer query = new StringBuffer();
			query.append("select a.id, a.name, a.status, a.relationship_type as type, a.requester_id as requester from relationship a, relationship b where (a.deleted is null or a.deleted = 'N') ");
			query.append("and a.RELATIONSHIP_TYPE = b.RELATIONSHIP_TYPE and nvl(a.REQUESTER_RESOURCE_TYPE_ID,0) = nvl(b.REQUESTER_RESOURCE_TYPE_ID,0) and nvl(a.TARGET_RESOURCE_TYPE_ID,0) = nvl(b.TARGET_RESOURCE_TYPE_ID,0) and a.STATUS = b.STATUS and b.id = "+searchRelationshipProcess.getOldRelationshipId());
			
			if (searchRelationshipProcess != null) {
				if (searchRelationshipProcess.getRelationshipId() != null && !searchRelationshipProcess.getRelationshipId().isEmpty()) {
					query.append(" and a.id = "+searchRelationshipProcess.getRelationshipId());
				}
				
				if (searchRelationshipProcess.getRelationshipName() != null && !searchRelationshipProcess.getRelationshipName().isEmpty()) {
					query.append(" and a.name like ('%"+searchRelationshipProcess.getRelationshipName()+"%')");
				}
				/*
				if (searchRelationshipProcess.getStatus() != null && !searchRelationshipProcess.getStatus().isEmpty()) {
					query.append(" and a.status = '"+searchRelationshipProcess.getRelationshipName()+"'");
				}
				
				if (searchRelationshipProcess.getRelationshipType() != null && !searchRelationshipProcess.getRelationshipType().isEmpty()) {
					query.append(" and a.relationship_type = '"+searchRelationshipProcess.getRelationshipType()+"'");
				}
				*/
				if (searchRelationshipProcess.getCreatedBy() != null && !searchRelationshipProcess.getCreatedBy().isEmpty()) {
					query.append(" and a.requester_id like ('%"+searchRelationshipProcess.getCreatedBy()+"%')");
				}
			}
			query.append(" order by a.id desc");
			
			log.debug("CommonServiceImpl :: "+query);
			
			SQLQuery sqlquery = session.createSQLQuery(query.toString());
			sqlquery.addScalar("id", LongType.INSTANCE);
			sqlquery.addScalar("name", StringType.INSTANCE);
			sqlquery.addScalar("status", StringType.INSTANCE);
			sqlquery.addScalar("type", StringType.INSTANCE);
			sqlquery.addScalar("requester", StringType.INSTANCE);
			
			int rowCount = getRowCount(query.toString());
			searchRelationshipProcess.setRowCount(rowCount);
			addPagination(sqlquery, searchRelationshipProcess.getOffset(), searchRelationshipProcess.getLimit());
			
			List<Object[]> resultList = sqlquery.list();
			
			RelationshipDTO dto;
			if (resultList!= null) {
				for (Object[] rs : resultList) {
					dto = new RelationshipDTO();
					dto.setId((Long)rs[0]);
					dto.setName((String)rs[1]);
					dto.setStatus((String)rs[2]);
					dto.setType((String)rs[3]);
					dto.setRequestorSOEId((String)rs[4]);
					relationshipDTOs.add(dto);
				}
			}
		}catch(Exception e){
			log.error(e, e);
		}
		return relationshipDTOs;
	}
	
	/**
	 * 
	 */
	@Override
	public List<ContactDetailsDTO> getContactsDetails(Long contactID, String objectName, String entry) {
		
		Session session = getSession();
		
		String table = objectName;
		
		if ("old".equals(entry)) {
			AuditObjectType auditObjectType = getAuditObjectType(objectName);
			if (auditObjectType != null) {
					table = auditObjectType.getObjectNameHistory();
			}
		}
		
		String query = ("SELECT distinct cc.first_name || ' ' || cc.last_name Name,cc.sso_id,cc.email,cc.phone,rr.display_name role,history.primary_contact,history.notify_contact,history.system_generated " +
						"FROM "+table+" history,citi_contact cc,role rr " +
						"WHERE history.citi_contact_id = cc.id and " +
					   	"history.role_id=rr.id and history.id = " +contactID) ;

		SQLQuery sqlquery = session.createSQLQuery(query);
		sqlquery.addScalar("name", StringType.INSTANCE);
		sqlquery.addScalar("sso_id", StringType.INSTANCE);
		sqlquery.addScalar("email", StringType.INSTANCE);
		sqlquery.addScalar("phone", StringType.INSTANCE);
		sqlquery.addScalar("role", StringType.INSTANCE);
		sqlquery.addScalar("primary_contact", StringType.INSTANCE);
		sqlquery.addScalar("notify_contact", StringType.INSTANCE);
		sqlquery.addScalar("system_generated", StringType.INSTANCE);
		
		List<Object[]> resultList = sqlquery.list();
		List<ContactDetailsDTO> contactListDTO = new ArrayList<ContactDetailsDTO>();
		ContactDetailsDTO dto;
		String val = "";
		if(resultList!= null){
			for(Object[] rs : resultList) {
				dto = new ContactDetailsDTO();
				dto.setName((String)rs[0]);
				dto.setSsoID((String)rs[1]);
				dto.setEmailID((String)rs[2]);
				dto.setPhoneNo((String)rs[3]);
				dto.setRole((String)rs[4]);
				val = "";
				if ("Y".equalsIgnoreCase((String)rs[5])) {
					val = "Yes";
				} else {
					val = "No";
				}
				dto.setPrimaryContact(val);
				val = "";
				if ("Y".equalsIgnoreCase((String)rs[6]) || "1".equalsIgnoreCase((String)rs[6])) {
					val = "Yes";
				} else {
					val = "No";
				}
				dto.setNotifyContact(val);
				val = "";
				if ("Y".equalsIgnoreCase((String)rs[7])) {
					val = "Yes";
				} else {
					val = "No";
				}
				dto.setSystemGenerated(val);
				contactListDTO.add(dto);
			}
		}
		return contactListDTO;
	}
	
	/**
	 * 
	 */
	@Override
	public List<RelationshipDTO> getRelationshipDetails(Long relationID){
		Session session = getSession();
		String query = ("select id, name, RELATIONSHIP_TYPE type, status, REQUESTER_ID requestor from relationship where id = ")+relationID;
		SQLQuery sqlQuery = session.createSQLQuery(query);
		sqlQuery.addScalar("id", LongType.INSTANCE);
		sqlQuery.addScalar("name", StringType.INSTANCE);
		sqlQuery.addScalar("type", StringType.INSTANCE);
		sqlQuery.addScalar("status", StringType.INSTANCE);
		sqlQuery.addScalar("requestor", StringType.INSTANCE);
		List<Object[]> resultList =sqlQuery.list();
		
		List<RelationshipDTO> relationshipDTOList = new ArrayList<RelationshipDTO>();
		RelationshipDTO dto;
		if(resultList!= null){
			for(Object[] rs :resultList) {
				dto = new RelationshipDTO();
				dto.setId((Long)rs[0]);
				dto.setName((String)rs[1]);
				dto.setType((String)rs[2]);
				dto.setStatus((String)rs[3]);
				dto.setRequestorSOEId((String)rs[4]);
				relationshipDTOList.add(dto);
			}
		}
		
		return relationshipDTOList;
		
		
	}
	
	private AuditObjectType getAuditObjectType(String objectName) {
	
		AuditObjectType auditObjectType = null;
		List<AuditObjectType> auditObjectTypes = (List<AuditObjectType>) getSession().
					createQuery(" from AuditObjectType where objectName = '"+objectName+"'").list();
		
		if (auditObjectTypes != null && !auditObjectTypes.isEmpty()) {
			auditObjectType =  auditObjectTypes.get(0);
		} 
		return auditObjectType;
		
	}
	
	@Override
	public void saveDailyLoad(List<DailyLoad> uploadedFile){
		
		HibernateTemplate ht = getHibernateTemplate();
		for (DailyLoad dailyLoad : uploadedFile){
			ht.saveOrUpdate(dailyLoad);
		}
		
	}
	@Override
	public void saveVacationFreeze(List<VacationFreeze> uploadedFile){
		
		HibernateTemplate ht = getHibernateTemplate();
		for (VacationFreeze vacationFreeze : uploadedFile){
			ht.saveOrUpdate(vacationFreeze);
		}
	}
	
	@Override
	public void saveFirewallFreeze(List<FirewallFreeze> uploadedFile){
		
		try {
			HibernateTemplate ht = getHibernateTemplate();
			for (FirewallFreeze firewallFreeze : uploadedFile){
				ht.saveOrUpdate(firewallFreeze);
			}
			log.debug("save fw Load success");
		} catch (DataAccessException e) {
			log.error("Error in saving fw rule"+e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Override
	@Transactional(readOnly = true)
    public FirewallLocation getFirewallLocByName(String name) {
        Session session = getSession();
        FirewallLocation fwLoc = null;
        List<FirewallLocation> list = (List<FirewallLocation>) session
                .createQuery(" from FirewallLocation loc where upper(loc.fwLocation) = upper(?) ").setString(0, name)
                .list();
        if (list != null && list.size() > 0) {
            fwLoc = list.get(0);
        }
        return fwLoc;
    }
	
	@Override
	@Transactional(readOnly = true)
	public List<DailyLoad> getDailyLoad() {
		log.info("inside commonserviceImpl:getDailyLoad");
		Session session = getSession();
		List<DailyLoad> list = (List<DailyLoad>) session.createQuery(" from DailyLoad order by id desc ").list();
		log.debug("dailyload:list"+list.size());
		return list;
	}
	
	
	
	@Override
	@Transactional(readOnly = true)
	public List<VacationFreeze> getVFreeze() {
		Session session = getSession();
		List<VacationFreeze> list = (List<VacationFreeze>) session.createQuery(" from VacationFreeze order by id desc ").list();
		
		return list;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<FirewallFreeze> getFwFreeze() {
		Session session = getSession();
		
		List<FirewallFreeze> list = (List<FirewallFreeze>) session.createQuery(" from FirewallFreeze order by id desc ").list();
		
		return list;
		
	}
	
	@Override
	@Transactional(readOnly = true)
	public GenericLookup getDay(String day) {
		Session session =getSession();
		GenericLookup genericLookup=null;
		List<GenericLookup> list =(List<GenericLookup>) session.createQuery(" from com.citigroup.cgti.c3par.common.domain.GenericLookup lookup where upper(lookup.value1) = upper(?) ").setString(0,day)
									.list();
		if(list !=null && list.size() > 0) {
			genericLookup =list.get(0);
		}
		return genericLookup;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<ActivityBPMDTO> getActivity(Long processId){
		Session session = getSession();
		String query = "SELECT tiact.activity_id aID, "+
						"tiact.bpm_instance_id bpmID,ttt.task name, "+
						"ti_request_id tireq,tiact.id activityTrailID,tiact.lockedby userid,tiact.PI_REQUESTED_ACTIVITY  piRequestId "+
						"FROM ti_activity_trail tiact "+
						"JOIN ti_task_type ttt "+
						"ON tiact.activity_id=ttt.id "+
						"WHERE ti_request_id = (SELECT MAX(id) FROM ti_request tireq WHERE process_id = '"+processId+"') "+
						"AND ttt.task_code "+
						"NOT IN ('cr_creation','start_process','risk_exec_ip','risk_exec','risk_re_exec','risk_re_exec_ip') " +
						"AND (tiact.activity_status in ('SCHEDULED') OR " +
						"(ttt.task_code in ('Exception') AND (tiact.activity_status not in ('COMPLETED','REMOVED')))" +
						" ) ";
		
		SQLQuery sqlQuery = session.createSQLQuery(query);	
		
		sqlQuery.addScalar("aID", LongType.INSTANCE);
		sqlQuery.addScalar("bpmID", StringType.INSTANCE);
		sqlQuery.addScalar("name", StringType.INSTANCE);
		sqlQuery.addScalar("tireq", LongType.INSTANCE);
		sqlQuery.addScalar("activityTrailID", LongType.INSTANCE);
		sqlQuery.addScalar("userid", LongType.INSTANCE);
		sqlQuery.addScalar("piRequestId", LongType.INSTANCE);
		List<Object[]> resultList =sqlQuery.list();
		
		List<ActivityBPMDTO> activityBPMDTOList = new ArrayList<ActivityBPMDTO>();
		ActivityBPMDTO dto;
		if(resultList!= null){
			for(Object[] rs :resultList) {
				dto = new ActivityBPMDTO();
				dto.setActivityId((Long)rs[0]);
				dto.setBpmInstanceId((String)rs[1]);
				dto.setActivityName((String)rs[2]);
				dto.setTiRequestId((Long)rs[3]);
				dto.setActivityTrailID((Long)rs[4]);
				dto.setUserid((Long)rs[5]);
				if(rs[6]!=null){
					dto.setProvidedInfoActivityId((Long)rs[6]);
				}
				activityBPMDTOList.add(dto);
			}
		}
		
		return activityBPMDTOList;
		
		
		
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<ActivityBPMDTO> getAllActivity(){
		Session session = getSession();
		String query = "SELECT distinct tiact.activity_id aID,ttt.task name "+
					   "FROM ti_activity_trail tiact JOIN ti_task_type ttt "+ 
					   "ON tiact.activity_id=ttt.id "+
					   "where ttt.task_code IN ('bus_jus','tec_arc','bu_mgr_app','iso_app','otrm_app','ope_imp','appsense_imp','proxy_imp','gncc_imp','act_con','han_rfc_exc','ope_ipreg_imp','Active') order by ttt.task";
						
		
		SQLQuery sqlQuery = session.createSQLQuery(query);	
		
		log.debug("Query to retrieve activity"+sqlQuery);
		sqlQuery.addScalar("aID", LongType.INSTANCE);
		
		sqlQuery.addScalar("name", StringType.INSTANCE);
		
		List<Object[]> resultList =sqlQuery.list();
		
		List<ActivityBPMDTO> activityBPMDTOList = new ArrayList<ActivityBPMDTO>();
		ActivityBPMDTO dto;
		if(resultList!= null){
			for(Object[] rs :resultList) {
				dto = new ActivityBPMDTO();
				dto.setActivityId((Long)rs[0]);
				
				dto.setActivityName((String)rs[1]);
				
				activityBPMDTOList.add(dto);
			}
		}
		
		return activityBPMDTOList;
		
		
		
	}
	
	
	
	
	
	@Override
	public void updateInstance(Long processID,String activityID){
		Session session = getSession();
		String activityStage = null ;
		String taskCode = null;
		Long aID = Long.valueOf(activityID);
		log.debug("Activity id"+aID);
		
		String query = "SELECT distinct ttt.task_code task "+
		   				"FROM ti_activity_trail tiact JOIN ti_task_type ttt "+ 
		   				"ON tiact.activity_id=ttt.id where activity_id= "+aID;
		
		SQLQuery queryExecute= session.createSQLQuery(query);
		log.debug("Query to retrieve activity"+queryExecute);
		
		queryExecute.addScalar("task", StringType.INSTANCE);
		taskCode=(String) queryExecute.uniqueResult();
		log.debug("task code ++"+taskCode);
				
		if(taskCode.equalsIgnoreCase("bus_jus")||taskCode.equalsIgnoreCase("tec_arc")) {
			activityStage="DC";
		}else if(taskCode.equalsIgnoreCase("bu_mgr_app")||taskCode.equalsIgnoreCase("iso_app")||taskCode.equalsIgnoreCase("otrm_app")){
			activityStage="AP";
		}else if(taskCode.equalsIgnoreCase("ope_imp")||taskCode.equalsIgnoreCase("appsense_imp")||taskCode.equalsIgnoreCase("proxy_imp")||taskCode.equalsIgnoreCase("gncc_imp")||taskCode.equalsIgnoreCase("han_rfc_exc")){
			activityStage="IM";
		}else if(taskCode.equalsIgnoreCase("act_con")){
			activityStage="VA";
		}else {
			activityStage="";
		}
		
		
		SQLQuery sqlQuery = session.createSQLQuery("INSERT INTO C3PAR.TI_ACTIVITY_TRAIL "+
												  "(ID,TI_REQUEST_ID,ACTIVITY_STAGE,ACTIVITY_ID,ACTIVITY_STATUS,USER_ROLE_ID,ACTIVITY_STARTDATE,"+
												  "ACTIVITY_MODE,VERSION_NO) VALUES "+
												  "(SEQ_TI_ACTIVITY_TRAIL.nextval, " +
												  "(SELECT MAX(ID) FROM TI_REQUEST WHERE PROCESS_ID = "+processID+"),'"+activityStage+"',"+
												  activityID+
												  " ,'SCHEDULED',1,sysdate,'NEW', " +
												  "(Select max(version_no)+1 from ti_activity_trail where ti_request_id=(SELECT MAX(ID) FROM TI_REQUEST WHERE PROCESS_ID = "+processID+") " +
												  "))");
		sqlQuery.executeUpdate();
		log.debug("updateactivitytrail done -insert done"+sqlQuery);
		SQLQuery sqlQuery1 = session.createSQLQuery("update ti_process set autopush = 'Y' where id= " +processID);
		sqlQuery1.executeUpdate();
	}
	
	@Override
	public void updateActivityTrail(Long activityTrailId) {
		Session session = getSession();
		SQLQuery sqlQuery = session.createSQLQuery("UPDATE ti_activity_trail SET activity_status = 'REMOVED' ,ACTIVITY_ENDDATE = sysdate "+
													"WHERE id = "+activityTrailId );
													
													

		sqlQuery.executeUpdate();
		log.debug("updateactivitytrail done"+sqlQuery);
	}

	/*
	 * 
	 * Method to validate ISO contact in Target contacts screen 
	 *
	 */
	@Override
	public boolean validateISOContact(String soeId) {
		Session session = getSession();
		List<ISOContacts> list = (List<ISOContacts>) session.createQuery(
				"from ISOContacts iso where upper(iso.soeID)=upper('" + soeId + "') and iso.isDeleted = 'N' ").list();
		log.debug("validateISOContact :: SOEID -> "+soeId);
		if (list != null && list.size() > 0) {
			return true;
		}
		return false;
	}
	
	//Added for 47182 starts
	//To list the relationship
	@Override
	@Transactional(readOnly = true)
	public List<Relationship> getListOfRelationship(SearchRelationshipProcess searchRelationshipProcess) {
		Session session = getSession();
		Criteria criteria = session.createCriteria(Relationship.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		if(searchRelationshipProcess.getRelationship()!= null){
			log.debug("dfffff"); 
		if(searchRelationshipProcess.getRelationship().getId() != null)
		{
			log.debug("id in csip" +searchRelationshipProcess.getRelationship().getId());
			criteria.add(Restrictions.eq("id", searchRelationshipProcess.getRelationship().getId()));
		}
		if (!StringUtil.isNullorEmpty(searchRelationshipProcess.getRelationship().getName())) {
			log.debug("name in csip" +searchRelationshipProcess.getRelationship().getName());
		    criteria.add(Restrictions.ilike("name", searchRelationshipProcess.getRelationship().getName().replaceAll("\\*", "%"), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(searchRelationshipProcess.getRelationship().getStatus())) {
			log.debug("status in csip" +searchRelationshipProcess.getRelationship().getStatus());
		    criteria.add(Restrictions.eq("status", searchRelationshipProcess.getRelationship().getStatus()));
		}
		/*if (!StringUtil.isNullorEmpty(searchRelationshipProcess.getRelationship().getDataIsPublic())) {
			log.debug("dip in csip" +searchRelationshipProcess.getRelationship().getId());
		    criteria.add(Restrictions.ilike("dataIsPublic", searchRelationshipProcess.getRelationship().getDataIsPublic(), MatchMode.ANYWHERE));
		}*/
		if (!StringUtil.isNullorEmpty(searchRelationshipProcess.getRelationship().getRequesterId())) {
			log.debug("soid in csip" +searchRelationshipProcess.getRelationship().getRequesterId());
		    criteria.add(Restrictions.ilike("requesterId", searchRelationshipProcess.getRelationship().getRequesterId().replaceAll("\\*", "%"), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(searchRelationshipProcess.getRelationship().getOspServiceName())) {
			log.debug("ser name" +searchRelationshipProcess.getRelationship().getOspServiceName());
		    criteria.add(Restrictions.eq("ospServiceName", searchRelationshipProcess.getRelationship().getOspServiceName()));
		}
		if (!StringUtil.isNullorEmpty(searchRelationshipProcess.getRelationship().getAccessCitiData())) {
			log.debug("acd" +searchRelationshipProcess.getRelationship().getAccessCitiData());
		    criteria.add(Restrictions.eq("accessCitiData", searchRelationshipProcess.getRelationship().getAccessCitiData()));
		}
		if (!StringUtil.isNullorEmpty(searchRelationshipProcess.getRelationship().getAccessCustomerData())) {
			log.debug("accd" +searchRelationshipProcess.getRelationship().getAccessCustomerData());
		    criteria.add(Restrictions.eq("accessCustomerData", searchRelationshipProcess.getRelationship().getAccessCustomerData()));
		}

		if (!StringUtil.isNullorEmpty(searchRelationshipProcess.getRelationship().getIsoutsourceProvider())) {
			log.debug("isout" +searchRelationshipProcess.getRelationship().getIsoutsourceProvider());
		    criteria.add(Restrictions.eq("isoutsourceProvider", searchRelationshipProcess.getRelationship().getIsoutsourceProvider()));
		}
		if(searchRelationshipProcess.getRelationship().getRequesterResourceType() !=null && searchRelationshipProcess.getRelationship().getTargetResourceType() != null){
			
		if (searchRelationshipProcess.getRelationship().getRequesterResourceType().getId() != null) {
			log.debug("isout" +searchRelationshipProcess.getRelationship().getTargetResourceType().getId());
			 criteria.createCriteria("requesterResourceType", "resourceType");
		    criteria.add(Restrictions.eq("resourceType.id", searchRelationshipProcess.getRelationship().getRequesterResourceType().getId()));
		}
		if (searchRelationshipProcess.getRelationship().getTargetResourceType().getId() != null) {
			log.debug("isout" +searchRelationshipProcess.getRelationship().getTargetResourceType().getId());
			 criteria.createCriteria("targetResourceType", "TargetResourceType");
		    criteria.add(Restrictions.eq("TargetResourceType.id", searchRelationshipProcess.getRelationship().getTargetResourceType().getId()));
		}
		}		
		if (searchRelationshipProcess.getBuId() != null) { 
			log.debug("buid" +searchRelationshipProcess.getBuId());
			 criteria.createCriteria("relcitiHierarchyXrefs", "relcitiHierarchyXrefs");
			 criteria.createCriteria("relcitiHierarchyXrefs.citiHierarchyMaster", "citiHierarchyMaster");
			 criteria.createCriteria("citiHierarchyMaster.businessUnit", "businessUnit");
			  criteria.add(Restrictions.eq("businessUnit.id", searchRelationshipProcess.getBuId()));
		}
		if (!StringUtil.isNullorEmpty(searchRelationshipProcess.getRelationship().getRelationshipType())) {
			log.debug("" +
					"" +searchRelationshipProcess.getRelationship().getRelationshipType());
			 criteria.add(Restrictions.eq("relationshipType", searchRelationshipProcess.getRelationship().getRelationshipType()));
		}
		if(searchRelationshipProcess.getRelationship().getThirdParty() !=null){
		if (searchRelationshipProcess.getRelationship().getThirdParty().getId() != null) {
			log.debug("tpid" +searchRelationshipProcess.getRelationship().getThirdParty().getId());
			criteria.createCriteria("thirdParty", "thirdParty");
			 criteria.add(Restrictions.eq("thirdParty.id", searchRelationshipProcess.getRelationship().getThirdParty().getId()));
		}}
	
		if (searchRelationshipProcess.getBuIdTp() != null) { 
			log.debug("buidTp" +searchRelationshipProcess.getBuIdTp());
			 criteria.createCriteria("relcitiHierarchyXrefs", "relcitiHierarchyXrefs");
			 criteria.createCriteria("relcitiHierarchyXrefs.citiHierarchyMaster", "citiHierarchyMaster");
			 criteria.createCriteria("citiHierarchyMaster.businessUnit", "businessUnit");
			  criteria.add(Restrictions.eq("businessUnit.id", searchRelationshipProcess.getBuIdTp()));
		}
	 
		if (searchRelationshipProcess.getDataClassi() != null) { 
			log.debug("dc" +searchRelationshipProcess.getDataClassi());
			 criteria.createCriteria("lookupId", "lookupId");
			 criteria.add(Restrictions.eq("lookupId.classificationId", searchRelationshipProcess.getDataClassi()));
			
		}

		}
		//criteria.add(Restrictions.eq("isDeleted", "N"));
		criteria.addOrder(Order.desc("id"));
		searchRelationshipProcess.setRowCount(getRowCount(criteria));
		if(searchRelationshipProcess.isPaginationRequired()){
			addPagination(criteria, searchRelationshipProcess.getOffset(), searchRelationshipProcess.getLimit());
		}
		log.debug("row count" +searchRelationshipProcess.getRowCount());
		List<Relationship> list = criteria.list();
		
		if(list != null)
			log.debug("CommonServiceImpl :: getListOfRelationship :: size ::"+list.size());
		
		return list;
	}
	
	//To get the business unit based on the search string
	@Override
	@Transactional(readOnly = true)
	public List<BusinessUnit> getBusiUnitList(SearchRelationshipProcess searchRelationshipProcess){
		Session session = getSession();

		StringBuffer queryString = new StringBuffer();
		log.debug("bu name" +searchRelationshipProcess.getReqBusFilter());
		queryString.append(" select distinct bu.* from  BUSINESS_UNIT bu where bu.business_name like '%"+searchRelationshipProcess.getReqBusFilter()+"%' ");
		
		SQLQuery query = session.createSQLQuery(queryString.toString());
		query.addEntity("bu", BusinessUnit.class);

		List<BusinessUnit> list = query.list();	
		if(list != null)
			log.debug("CommonServiceImpl :: getBusiUnitList :: size ::"+list.size());
		
		return list;
	}
	
	//to get the third party list based on the search string
	@Override
	@Transactional(readOnly = true)
    public List getThirdPartyList1(SearchRelationshipProcess searchRelationshipProcess) {
	    Session session = getSession();
	    LookupDTO obj = null;
	    ArrayList<LookupDTO> objList = new ArrayList<LookupDTO>();
	    log.debug("into third party search");
		HashMap<Long, String> appCount = new HashMap<Long, String>();
		SQLQuery query = session.createSQLQuery("select tp.id as id, tp.name as name " 
				+" from third_party tp "
				+" where name like '%" +searchRelationshipProcess.getThirdPartyFilter()+ "%' ");
		query.addScalar("id", LongType.INSTANCE);
		query.addScalar("name", StringType.INSTANCE);
		List<Object[]> rows = query.list();
		log.debug("tp list size" +rows.size());
		for (Object[] obj1 : rows) {
			//appCount.put((Long)obj[0], (String)obj[1]);
			obj = new LookupDTO ((Long)obj1[0],(String)obj1[1],null);
		  	 objList.add( obj );  // obj.setName(rs.getString(1)); obj.setStatus(rs.getString(2));
		}
		log.debug("list size" +objList.size());
		return objList;
    }
	
	//to get the list of end points
	@Transactional(readOnly = true)
	public List<ResourceType> getResourceList(){
		Session session = getSession();

		Criteria criteria = session.createCriteria(ResourceType.class);
		criteria.add(Restrictions.eq("status", "Active"));
		criteria.addOrder(Order.asc("id"));

		List<ResourceType> list = criteria.list();
		if(list != null)
			log.debug("CommonServiceImpl ::  getResourceList :: size ::"+list.size());
		
		return list;
	}
	
	//to get the business unit for search string from third party screen
	@Override
	@Transactional(readOnly = true)
	public List<BusinessUnit> getBusiUnitListForTp(SearchRelationshipProcess searchRelationshipProcess){
		Session session = getSession();

		StringBuffer queryString = new StringBuffer();
		log.debug("bu name for tp" +searchRelationshipProcess.getReqBusFilter());
		queryString.append(" select distinct bu.* from  BUSINESS_UNIT bu where bu.business_name like '%"+searchRelationshipProcess.getReqBusFilterTp()+"%' ");
		
		SQLQuery query = session.createSQLQuery(queryString.toString());
		query.addEntity("bu", BusinessUnit.class);

		List<BusinessUnit> list = query.list();	
		if(list != null)
			log.debug("CommonServiceImpl :: getBusiUnitListForTp :: size ::"+list.size());
		
		return list;
	}
	
	//to get the list of classification
	@Override
	@Transactional(readOnly = true)
    public List getDatClassificationList() {
	    Session session = getSession();
	    LookupDTO obj = null;
	    ArrayList<LookupDTO> objList = new ArrayList<LookupDTO>();
	    log.debug("fetch data classification list");
		SQLQuery query = session.createSQLQuery("select id as id, value1 as name from generic_lookup where definition_id in (select id from generic_lookup_defs where name = 'Classification')" );
		query.addScalar("id", LongType.INSTANCE);
		query.addScalar("name", StringType.INSTANCE);
		List<Object[]> rows = query.list();
		log.debug("tp list size" +rows.size());
		for (Object[] obj1 : rows) {
			//appCount.put((Long)obj[0], (String)obj[1]);
			obj = new LookupDTO ((Long)obj1[0],(String)obj1[1],null);
		  	 objList.add( obj );  // obj.setName(rs.getString(1)); obj.setStatus(rs.getString(2));
		}
		log.debug("list size" +objList.size());
		return objList;
    }
	//To load the GenericLookupDef data and get the type drown list for Manage Look up
	@Override
	@Transactional(readOnly = true)
	public List<GenericLookupDef> getListLookupData() {
		Session session = getSession();
		Criteria criteria = session.createCriteria(GenericLookupDef.class);
	 	List<GenericLookupDef> list = criteria.list();
	 	return list;
	} 
	
	
	
	//To get the General look up list filtered by id and Name
 
	@Override
	@Transactional(readOnly = true)
	public List  getListLookupDataDefList(Long id,String name) {  
		log.debug("id>>>>>>>" +id+"name>>>>>>>>>>>>>>>>>"+name);
		Session session = getSession();
		ListLookupsForm obj = null;
	    ArrayList<ListLookupsForm> objList = new ArrayList<ListLookupsForm>();
		StringBuffer queryString = new StringBuffer();
		 
		if(id!=null&&!name.isEmpty()){
		 
		queryString.append(" select b.ID, a.NAME,b.VALUE1 from  GENERIC_LOOKUP_DEFS a ,GENERIC_LOOKUP b   where a.ID=b.DEFINITION_ID  and b.VALUE1='"+name+"' and b.DEFINITION_ID="+id);
		 
		}
		else if(id!=null&&name.isEmpty()){
			 
			queryString.append("select b.ID,a.NAME,b.VALUE1 from  GENERIC_LOOKUP_DEFS a ,GENERIC_LOOKUP b   where a.ID=b.DEFINITION_ID  and b.DEFINITION_ID="+id);
			 
		}else if(id==null&&name!=null){
			 
			queryString.append("select b.ID, a.NAME,b.VALUE1 from  GENERIC_LOOKUP_DEFS a ,GENERIC_LOOKUP b   where a.ID=b.DEFINITION_ID  and b.VALUE1='"+name+"'");
		}
		SQLQuery query = session.createSQLQuery(queryString.toString()); 
		
	 	List<Object[]> rows = query.list();
		log.debug("gen look up list size" +rows.size());
		for (Object[] obj1 : rows) {
		     obj = new ListLookupsForm(obj1[0].toString(),(String)obj1[1], (String)obj1[2]);
		  	 objList.add( obj ); 
		
	}
	return objList;
	}
		// Add Manage Look Up data 
		@Override
	 
		public void saveLookUpData(Long id, String value){
			Session session = getSession();
			GenericLookupDef genLookupDefObj=new GenericLookupDef();
			GenericLookup genLookupObj =new GenericLookup();
			log.info("Look up data :: ID -> "+id+" :: VAl ->"+value);
			List<GenericLookupDef> list = (List<GenericLookupDef>) session.createQuery("from GenericLookupDef defObj where defObj.id="+id).list();
			if (list != null && list.size() > 0) {
			 
			log.debug("id::"+id+"value::"+value);
		        genLookupDefObj.setId(id);
				genLookupObj.setValue1(value);
				genLookupObj.setValue2(value);
				genLookupObj.setIsDeleted("N");
		        genLookupObj.setGenericLookupDef(genLookupDefObj);
		        id = (Long) getHibernateTemplate().save(genLookupObj); 
		     	log.debug("Parent id::::...................."+id);
		 
			}
		}
		//Adding for port enhancement - Protocol 17- adding description
		@Override
		
		public void saveLookUpData(Long id, String value, String value1){
			Session session = getSession();
			GenericLookupDef genLookupDefObj=new GenericLookupDef();
			GenericLookup genLookupObj =new GenericLookup();
			log.info("Look up data :: ID -> "+id+" :: VAl ->"+value+" :: VAl ->"+value1);
			List<GenericLookupDef> list = (List<GenericLookupDef>) session.createQuery("from GenericLookupDef defObj where defObj.id="+id).list();
			if (list != null && list.size() > 0) {
			 
			log.debug("id::"+id+"value::"+value);
		        genLookupDefObj.setId(id);
				genLookupObj.setValue1(value);
				genLookupObj.setValue2(value1);
				genLookupObj.setIsDeleted("N");
		        genLookupObj.setGenericLookupDef(genLookupDefObj);
		        id = (Long) getHibernateTemplate().save(genLookupObj); 
		     	log.debug("Parent id::::...................."+id);
		 
			}
		}



		// Update Manage Look Up data
				@Override
				public void updateLookUpData(Long lookUpDefID,Long id, String value){
					Session session = getSession(); 
				 
					GenericLookup genLookupObj =null;
                 
					    log.info("Look up data :: ID -> "+id+" :: VAl ->"+value);
					    GenericLookupDef genLookupDefObj=new GenericLookupDef();
				        genLookupObj = new GenericLookup();
				        genLookupDefObj.setId(lookUpDefID);
				        genLookupObj.setId(id);
				        genLookupObj.setValue1(value);
						genLookupObj.setValue2(value);
						genLookupObj.setIsDeleted("N");
						genLookupObj.setGenericLookupDef(genLookupDefObj);
				     	session.merge(genLookupObj);
					 
				}
				@Override
				public void updateLookUpData(Long lookUpDefID,Long id, String value,String value1){
					Session session = getSession(); 
				 
					GenericLookup genLookupObj =null;
                 
					    log.info("Look up data :: ID -> "+id+" :: VAl ->"+value);
					    GenericLookupDef genLookupDefObj=new GenericLookupDef();
				        genLookupObj = new GenericLookup();
				        genLookupDefObj.setId(lookUpDefID);
				        genLookupObj.setId(id);
				        genLookupObj.setValue1(value);
						genLookupObj.setValue2(value1);
						genLookupObj.setIsDeleted("N");
						genLookupObj.setGenericLookupDef(genLookupDefObj);
				     	session.merge(genLookupObj);
					 
				}
				
				 public ThirdPartyLocationXref loadThirdPartyLocation(Long thirdPartyId){
						Session session = getSession();
                      	Criteria criteria = session.createCriteria(ThirdPartyLocationXref.class);	
					    criteria.add(Restrictions.eq("thirdParty.id", thirdPartyId));
				    	List<ThirdPartyLocationXref> list = criteria.list();
						if(list != null && list.size() > 0){
							log.debug("genericLookupList :: loadThirdPartyLocation :: size ::"+list.size());
							return list.get(0);
						}
						
						return list.get(0);
				    }
				 
				//To load the GenericLookupDef data and get the type drown list for Manage Look up
					@Override
					@Transactional(readOnly = true)
					public List<GenericLookup> getListLookupDataById(Long id) {
						Session session = getSession();
						Criteria criteria = session.createCriteria(GenericLookup.class);
						criteria.add(Restrictions.eq("id", id));
				     	List<GenericLookup> list = criteria.list();
					 	return list;
					}

					@Override
					@Transactional(readOnly = true)
					public List<GenericLookup> getGenericLookupByName(String name) {
						Session session = getSession();
						//List<GenericLookup> genericLookupList = new ArrayList<GenericLookup>();
						List<GenericLookup> genericLookupList = (List<GenericLookup>) session.createQuery(
										"from com.citigroup.cgti.c3par.common.domain.GenericLookup gen" +
										" where gen.genericLookupDef.id= "
												+ getDefinitionId(name)+" and gen.isDeleted='N'").list();
					    log.debug("Size of list in getGenericLookupByName: "+genericLookupList.size());   
					 	return genericLookupList;  
					} 
					
	@Override
	@Transactional(readOnly = true)
	public List<GenericLookup> getGenericLookupData(List<String> names) {
		Session session = getSession();

 		log.debug("CommonServiceImpl :: getGenericLookupData :: names - "+names);  
 		
		Criteria criteria = session.createCriteria(GenericLookup.class);
		criteria.add(Restrictions.in("value1", names));
		criteria.add(Restrictions.eq("isDeleted", "N"));
     	List<GenericLookup> genericLookupList = criteria.list();

     	if(genericLookupList != null)
     		log.debug("CommonServiceImpl :: getGenericLookupData :: list size - "+genericLookupList.size());  
	    
	 	return genericLookupList;
	} 
	
	@Override
	@Transactional(readOnly = true)
	public List<ActivityBPMDTO> getActivityByStatus(Long processId,String status){
		Session session = getSession();
		String query = "SELECT tiact.activity_id aID, "+
						"tiact.bpm_instance_id bpmID,ttt.task name, "+
						"ti_request_id tireq,tiact.id activityTrailID,tiact.lockedby userid,tiact.PI_REQUESTED_ACTIVITY  piRequestId "+
						"FROM ti_activity_trail tiact "+
						"JOIN ti_task_type ttt "+
						"ON tiact.activity_id=ttt.id "+
						"WHERE ti_request_id = (SELECT MAX(id) FROM ti_request tireq WHERE process_id = '"+processId+"') "+
						"AND ttt.task_code "+
						"NOT IN ('cr_creation','start_process','risk_exec_ip','risk_exec','risk_re_exec','risk_re_exec_ip') " +
						"AND (tiact.activity_status in ('"+status+"'))"
						+ " order by tiact.ACTIVITY_STARTDATE desc ";
		
		SQLQuery sqlQuery = session.createSQLQuery(query);	
		if("EXPIRED".equalsIgnoreCase(status)){
			sqlQuery.setMaxResults(1);
		}
		sqlQuery.addScalar("aID", LongType.INSTANCE);
		sqlQuery.addScalar("bpmID", StringType.INSTANCE);
		sqlQuery.addScalar("name", StringType.INSTANCE);
		sqlQuery.addScalar("tireq", LongType.INSTANCE);
		sqlQuery.addScalar("activityTrailID", LongType.INSTANCE);
		sqlQuery.addScalar("userid", LongType.INSTANCE);
		sqlQuery.addScalar("piRequestId", LongType.INSTANCE);
		List<Object[]> resultList =sqlQuery.list();
		
		List<ActivityBPMDTO> activityBPMDTOList = new ArrayList<ActivityBPMDTO>();
		ActivityBPMDTO dto;
		if(resultList!= null){
			for(Object[] rs :resultList) {
				dto = new ActivityBPMDTO();
				dto.setActivityId((Long)rs[0]);
				dto.setBpmInstanceId((String)rs[1]);
				dto.setActivityName((String)rs[2]);
				dto.setTiRequestId((Long)rs[3]);
				dto.setActivityTrailID((Long)rs[4]);
				dto.setUserid((Long)rs[5]);
				if(rs[6]!=null){
					dto.setProvidedInfoActivityId((Long)rs[6]);
				}
				activityBPMDTOList.add(dto);
			}
		}
		return activityBPMDTOList;
	}
	@Override
	@Transactional(readOnly = true)
	public List<GenericLookup> getEmailTemplateList(String name) {
		Session session = getSession();
		//List<GenericLookup> genericLookupList = new ArrayList<GenericLookup>();
		List<GenericLookup> genericLookupList = (List<GenericLookup>) session.createQuery(
						"from com.citigroup.cgti.c3par.common.domain.GenericLookup gen" +
						" where gen.genericLookupDef.id= "
								+ getDefinitionId(name)+" and gen.isDeleted='N' order by value2  asc").list();
	    log.debug("Size of list in getGenericLookupByName: "+genericLookupList.size());   
	 	return genericLookupList;  
	} 

	

}
