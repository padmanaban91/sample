package com.citigroup.cgti.c3par.controller.relationship;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.dashboard.webtier.helper.AttributeToListPositionMapBuilder;
import com.citigroup.cgti.c3par.relationship.domain.AssignThirdPartyLocationProcess;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.RelationshipProcess;

@Controller
public class AssignThirdPartyLocationController extends RelationshipBaseController{

    public static final String ATTRIBUTE_LOCATION_ID = "getId" ;
    private static final String[] attrs = new String[] {ATTRIBUTE_LOCATION_ID} ;

	private static Logger log = Logger.getLogger(AssignThirdPartyLocationController.class);

	@RequestMapping(value = "/populateThirdPartyLocation.act", method = {RequestMethod.GET, RequestMethod.POST })
	public String populateThirdPartyLocation(ModelMap model, @ModelAttribute("assignThirdPartyLocationProcess") AssignThirdPartyLocationProcess assignTPLocProcess,
													HttpServletRequest request) {
		log.debug("AssignThirdPartyLocationController :: populateThirdPartyLocation :: Method Starts");
		
		String assignTo = request.getParameter("assignTo");
		if(assignTo != null && !assignTo.isEmpty() && !"null".equals(assignTo)) {
			request.getSession().setAttribute("CITI_TP_LOCATION_ASSIGN_TO",	assignTo);
		}		
		log.debug("AssignThirdPartyLocationController :: populateThirdPartyLocation :: assignTo - " + assignTo);

		RelationshipProcess relprocess = getRelationshipProcess(request);
		assignTPLocProcess.setCanEdit(relprocess.isCanEdit());
		assignTPLocProcess.setRelationshipName(relprocess.getRelationship().getName());
		
		List<Location> assignedTPLocations = new ArrayList<Location>();
		Long thirdPartyId = 0L;
		if (assignTo != null && assignTo.equalsIgnoreCase("requester")) {
			assignTPLocProcess.setThirdPartyName(relprocess.getRelationship().getThirdParty().getName());
			thirdPartyId = relprocess.getRelationship().getThirdParty().getId();
			
			if(relprocess.getRequesterThirdPartyLocations() != null ){
				assignedTPLocations = relprocess.getRequesterThirdPartyLocations();
			}
		}else if (assignTo != null && assignTo.equalsIgnoreCase("target")) {
			assignTPLocProcess.setThirdPartyName(relprocess.getRelationship().getUturnThirdParty().getName());
			thirdPartyId = relprocess.getRelationship().getUturnThirdParty().getId();
			
			if(relprocess.getTargetThirdPartyLocations() != null ){
				assignedTPLocations = relprocess.getTargetThirdPartyLocations();
			}
		}
		log.debug("AssignThirdPartyLocationController :: populateThirdPartyLocation :: thirdPartyId - " + thirdPartyId);

		assignTPLocProcess.setThirdPartyId(thirdPartyId);
		assignTPLocProcess.setAssignedThirdPartyLocationList(assignedTPLocations);
		
		List<Location> newTpLocations = new ArrayList<Location>();
		List<Location> currentTPLoc = assignTPLocProcess.loadThirdPartyLocations(thirdPartyId);
		//add existing location into map builder to remove & avoid duplicates
		AttributeToListPositionMapBuilder listPosition = new AttributeToListPositionMapBuilder(assignedTPLocations, attrs);

		if(currentTPLoc != null && !currentTPLoc.isEmpty()){
			for(Location location:currentTPLoc){
				Integer id = listPosition.getPosition(ATTRIBUTE_LOCATION_ID, location.getId());
				if(id == null){
				    newTpLocations.add(location);
				}
			}
		}
		
	    /*if(newTpLocations != null){	
	    	newTpLocations.addAll(getAllLocation(thirdPartyId, request.getHeader("SM_USER"), assignTPLocProcess));
	    }*/
		request.getSession().setAttribute("CITI_TP_LOCATIONS",	newTpLocations);
		request.getSession().setAttribute("CITI_TP_LOCATIONS_ASSIGNED",	assignedTPLocations);
		
		log.debug("AssignThirdPartyLocationController :: populateThirdPartyLocation :: newTpLocations - " + newTpLocations.size());
		
		assignTPLocProcess.setAllThirdPartyLocationList(newTpLocations);
		assignTPLocProcess.setSelectedTPLocation(null);
		assignTPLocProcess.setUnselectedTPLocation(null);		
		model.addAttribute("assignThirdPartyLocationProcess",assignTPLocProcess);

		return "pages/relationship/AssignThirdPartyLocations";
	}

	@RequestMapping(value = "/assignThirdPartyLocation.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String assignThirdPartyLocation( ModelMap model, @ModelAttribute("assignThirdPartyLocationProcess") AssignThirdPartyLocationProcess assignTPLocProcess,
												HttpServletRequest request) {
		log.debug("AssignThirdPartyLocationController :: assignThirdPartyLocation :: Method Starts");
		
		String assignTo = (String) request.getSession().getAttribute("CITI_TP_LOCATION_ASSIGN_TO");	
		String[] selectedTPLocIds = assignTPLocProcess.getSelectedTPLocation();
		
		List<Location> alltpLocations = (List<Location>) request.getSession().getAttribute("CITI_TP_LOCATIONS");
		List<Location> assignedtpLocations = (List<Location>) request.getSession().getAttribute("CITI_TP_LOCATIONS_ASSIGNED");	
		
		if(selectedTPLocIds != null && selectedTPLocIds.length > 0){
			int count = 0;
			for(String locIds:selectedTPLocIds){
				int index = Integer.valueOf(locIds);
				log.debug("AssignThirdPartyLocationController :: assignThirdPartyLocation :: index - "+index);
				
				Location loc = (Location) alltpLocations.get(index-count);
				
				if(loc != null && loc.getId() == null || loc.isFromCASP()){
					Long locId = assignTPLocProcess.saveLocation(loc);
					loc.setId(locId);
					log.debug("AssignThirdPartyLocationController :: assignThirdPartyLocation :: locId - "+locId);
				}
				assignedtpLocations.add(loc);
				alltpLocations.remove(index-count);
				
				count++;
			}
		}
		request.getSession().setAttribute("CITI_TP_LOCATIONS",alltpLocations);
		request.getSession().setAttribute("CITI_TP_LOCATIONS_ASSIGNED",assignedtpLocations);
		assignTPLocProcess.setAssignedThirdPartyLocationList(assignedtpLocations);
		assignTPLocProcess.setAllThirdPartyLocationList(alltpLocations);
		assignTPLocProcess.setSelectedTPLocation(null);
		assignTPLocProcess.setUnselectedTPLocation(null);
		
		//set the list in the relationship process for save
		RelationshipProcess relprocess = getRelationshipProcess(request);
		if (assignTo != null && assignTo.equalsIgnoreCase("requester")) {
			relprocess.setRequesterThirdPartyLocations(assignTPLocProcess.getAssignedThirdPartyLocationList());
		}else if (assignTo != null && assignTo.equalsIgnoreCase("target")) {
			relprocess.setTargetThirdPartyLocations(assignTPLocProcess.getAssignedThirdPartyLocationList());
		}
		setInSession(request, relprocess);
		
		model.addAttribute("assignThirdPartyLocationProcess",assignTPLocProcess);
		
		return "pages/relationship/AssignThirdPartyLocations";
	}

	@RequestMapping(value = "/unassignThirdPartyLocation.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String unassignThirdPartyLocation( ModelMap model, @ModelAttribute("assignThirdPartyLocationProcess") AssignThirdPartyLocationProcess assignTPLocProcess,
							HttpServletRequest request) {
		log.debug("AssignThirdPartyLocationController :: unassignThirdPartyLocation :: Method Starts");
		
		String assignTo = (String) request.getSession().getAttribute("CITI_TP_LOCATION_ASSIGN_TO");	
		String[] unassignedTPlocs = assignTPLocProcess.getUnselectedTPLocation();
		
		List<Location> alltpLocations = (List<Location>) request.getSession().getAttribute("CITI_TP_LOCATIONS");
		List<Location> assignedtpLocations = (List<Location>) request.getSession().getAttribute("CITI_TP_LOCATIONS_ASSIGNED");	

		if(unassignedTPlocs != null && unassignedTPlocs.length > 0){
			int count = 0;
			for(String locIds:unassignedTPlocs){
				int index = Integer.valueOf(locIds);
				log.debug("AssignThirdPartyLocationController :: assignThirdPartyLocation :: index - "+index);
				
				Location loc = (Location) assignedtpLocations.get(index-count);
				alltpLocations.add(loc);
				assignedtpLocations.remove(index-count);
				count++;
			}
		}

		request.getSession().setAttribute("CITI_TP_LOCATIONS",alltpLocations);
		request.getSession().setAttribute("CITI_TP_LOCATIONS_ASSIGNED",assignedtpLocations);
		assignTPLocProcess.setAssignedThirdPartyLocationList(assignedtpLocations);
		assignTPLocProcess.setAllThirdPartyLocationList(alltpLocations);
		assignTPLocProcess.setSelectedTPLocation(null);
		assignTPLocProcess.setUnselectedTPLocation(null);
		
		//set the list in the relationship process for save
		RelationshipProcess relprocess = getRelationshipProcess(request);
		if (assignTo != null && assignTo.equalsIgnoreCase("requester")) {
			relprocess.setRequesterThirdPartyLocations(assignTPLocProcess.getAssignedThirdPartyLocationList());
		}else if (assignTo != null && assignTo.equalsIgnoreCase("target")) {
			relprocess.setTargetThirdPartyLocations(assignTPLocProcess.getAssignedThirdPartyLocationList());
		}
		setInSession(request, relprocess);
		
		model.addAttribute("assignThirdPartyLocationProcess",assignTPLocProcess);
		return "pages/relationship/AssignThirdPartyLocations";
	}

	@RequestMapping(value = "/deleteThirdPartyLocationAssigned.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String deleteThirdPartyLocationAssigned( ModelMap model, @ModelAttribute("assignThirdPartyLocationProcess") AssignThirdPartyLocationProcess assignTPLocProcess,
							HttpServletRequest request) {
		
		String tpIdstr = request.getParameter("selectedThirdParty");
		String tplocstr = request.getParameter("selectedId");
		
		String assignTo = (String) request.getSession().getAttribute("CITI_TP_LOCATION_ASSIGN_TO");	
		
		log.debug("AssignThirdPartyLocationController :: deleteThirdPartyLocationAssigned :: tpIdstr - "+tpIdstr+" :: tplocstr - "+tpIdstr);
		
		if(tpIdstr != null && !tpIdstr.isEmpty() && tplocstr != null && !tplocstr.isEmpty()){
			Long tpid = Long.valueOf(tpIdstr);
			Long tploc = Long.valueOf(tplocstr);

			int count = assignTPLocProcess.getTpRelationshipForLocation(tploc);
			if(count <= 0){
				assignTPLocProcess.deleteLocationById(tploc);
			}else{
				log.error("ThirdParty Location is already used in the relationship");
				request.getSession().setAttribute("ERROR_MSG",	"ThirdParty Location is already used in the relationship");
			}
		}
		
		return "forward:/populateThirdPartyLocation.act?assignTo="+assignTo;
	}
	/*private List<Location> getAllLocation(Long tpId, String remoteUser,AssignThirdPartyLocationProcess assignTPLocProcess){

		log.debug("AssignThirdPartyLocationController::getAllLocation :: tpId - "+tpId);
		List<Location> locationList= new ArrayList<Location>();
		Location locationForm = null;
		
		ThirdParty thirdparty = assignTPLocProcess.getThirdParty(tpId);
		Long detailId = thirdparty.getDetailId();
		Long caspId = thirdparty.getCaspId();
		log.debug("AssignThirdPartyLocationController::getAllLocation :: detailId - "+detailId+" :: caspId - "+caspId);

		try{
			SOADataComponent soaDataComponent = new SOADataComponent();
			ProfileInfoFactory profileInfoFactory = (ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");
	
			PartnersSiteListType siteDetails = profileInfoFactory.getCASPService().getPartnerSiteDetails(caspId.intValue(), remoteUser, detailId);
	
			for(int i=0;i<siteDetails.getSiteUtilizationList().getSiteUtilization().size();i++){
				for(int j=0;j<siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().size();j++){
					locationForm = new Location();
					String countryName = siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getCountry().getName().get(0);
					GenericLookup countryCode = null;
					locationForm.setFromCASP(true);
					
					if(countryName != null && !countryName.isEmpty()){
						countryCode = assignTPLocProcess.getCountryCode(countryName);
					}
					
					if(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getFreeTextAddress()!=null && siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().size()>0){
						locationForm.setAddress(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getFreeTextAddress().getAddressLine().get(0));
					}
					if(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getFreeTextAddress()!=null && siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().size()>1){
						locationForm.setAddress2(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getFreeTextAddress().getAddressLine().get(1));
					}
					if(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getLocality()!=null){
						locationForm.setCity(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getLocality().getName().get(0));
					}
					if(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getCountry()!=null){
						locationForm.setCountryId(countryCode);
					}
					if(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getAdministrativeArea()!=null && siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getAdministrativeArea().getName()!=null){
						locationForm.setState(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getAdministrativeArea().getName().get(0));
					}
					if(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getPostCode().getIdentifier().get(0)!=null){
						locationForm.setZip(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteAddress().get(j).getPostCode().getIdentifier().get(0));
					}
					if(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getAssessments()!=null){
						locationForm.setAssessmentId((siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getAssessments().getAssessmentID()).toString());
						locationForm.setAssessmentDesc(new String(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getAssessments().getAssessmentStatusDesc()));
					}
					
					locationForm.setSiteDetailId(Long.valueOf(siteDetails.getSiteUtilizationList().getSiteUtilization().get(i).getSiteDetailID()));
					locationList.add(locationForm);
				}
			}
		}catch(Exception e){
			log.error(e);
		}

		log.debug("AssignThirdPartyLocationController::getAllLocation :: locationList - "+locationList.size());
		
		return locationList;
	}*/
	 
}
