package com.citigroup.cgti.c3par.controller.firewall;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.IPRegACL;
import com.citigroup.cgti.c3par.fw.domain.PersonalObject;
import com.citigroup.cgti.c3par.fw.domain.PersonalObjectIP;
import com.citigroup.cgti.c3par.fw.domain.PersonalObjectPort;
import com.citigroup.cgti.c3par.fw.domain.Port;
import com.citigroup.cgti.c3par.fw.domain.SearchFirewallRuleRequest;
import com.citigroup.cgti.c3par.model.TIRequestEntity;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

@Controller
public class FirewallSearchController extends BaseController {
	
	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	private static final String FLOW_OF_DATA_ATOB = "Endpoint A -> Endpoint B";
	
	 /*
     * To Search the IP Address
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/searchIPAddress.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String searchIPAddress(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallSearchController::searchIPAddress method starts...");
    	String filterText = null;
    	int offSet = 0;
    	String result = "pages/jsp/fw/SearchIPAddress";
    	int sourceNWZone = 0;
    	int destNWZone = 0;
    	String relationshipType = "";
    	
    	String searchType = "";
    	String con_type = (String) request.getSession().getAttribute("con_type");
    	String ipType = (String) request.getParameter("ipType");

    	String field = (String)request.getParameter("field");
    	if (request.getParameter("sourceNWZone") != null) {
    		sourceNWZone = Integer.valueOf(request.getParameter("sourceNWZone"));
    	}
    	if (request.getParameter("destNWZone") != null) {
    		destNWZone = Integer.valueOf(request.getParameter("destNWZone"));
    	}
    	if (request.getParameter("relationshipType") != null) {
    		relationshipType = request.getParameter("relationshipType");
    	}
    	if ("ipReg".equalsIgnoreCase(con_type))
    	{
    		if("SourceIP".equalsIgnoreCase(ipType)){
    			searchType = "IPR";
    		}
    		else{
    			searchType = "IP";
    		}
    	}
    	else
    	{
    	 searchType = "IP";
    	}
    	
    	SearchFirewallRuleRequest searchFirewallRuleRequest = new SearchFirewallRuleRequest();
	    searchFirewallRuleRequest.setField(field);
	    searchFirewallRuleRequest.setRequesterResourceType(sourceNWZone);
	    searchFirewallRuleRequest.setTargetResourceType(destNWZone);
	    searchFirewallRuleRequest.setOffset(offSet);
	    searchFirewallRuleRequest.setFilterType(searchType);
	    searchFirewallRuleRequest.setFilterText(filterText);
	    searchFirewallRuleRequest.setRelationshipType(relationshipType);
	    searchFirewallRuleRequest.setIpType(ipType);
	    TIRequest tiRequestEntity = null;
		tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
		searchFirewallRuleRequest.setTiRequest(tiRequestEntity.getId());
		if (searchFirewallRuleRequest.getFilterType() != null && !searchFirewallRuleRequest.getFilterType().isEmpty()
				&& "IP".equalsIgnoreCase(searchFirewallRuleRequest.getFilterType())) {  
			List<IPAddress> ipAddressList = searchFirewallRuleRequest.getIPAddresses();
		    searchFirewallRuleRequest.setIpAddressList(ipAddressList);
		} else if (searchFirewallRuleRequest.getFilterType() != null && !searchFirewallRuleRequest.getFilterType().isEmpty()
				&& "PER".equalsIgnoreCase(searchFirewallRuleRequest.getFilterType())) {
			List<PersonalObject> personalObjectIPs = searchFirewallRuleRequest.listPersonalObjectIPs();
			if (personalObjectIPs != null) {
				log.debug("PersonalObjectIPs Size "+personalObjectIPs.size());
			}
			searchFirewallRuleRequest.setPersonalObjects(personalObjectIPs);
		} else if (searchFirewallRuleRequest.getFilterType() != null && !searchFirewallRuleRequest.getFilterType().isEmpty()
				&& "TMP".equalsIgnoreCase(searchFirewallRuleRequest.getFilterType())) {  
			List<FireWallRuleIP> ipList = searchFirewallRuleRequest.searchTemplateIPObjects();
			searchFirewallRuleRequest.setFirewallRuleIPList(ipList);
		} else {
			List<IPRegACL> ipRegACLList = searchFirewallRuleRequest.getIpRegACL();
			log.debug("Fetching access types");
		    searchFirewallRuleRequest.setIpRegACLList(ipRegACLList);
		}
		model.addAttribute("searchFirewallRuleRequest", searchFirewallRuleRequest);
	    log.info("FirewallSearchController::searchIPAddress method ends...sourceNWZone==>"+sourceNWZone+"...destNWZone==>"+destNWZone);
	    log.info("FirewallSearchController:: ipType"+ipType);
		return result;
    }
	
	@RequestMapping(value = "/paginateIPAddress.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String paginateIPAddress(HttpServletRequest request, ModelMap model, @ModelAttribute("searchFirewallRuleRequest") SearchFirewallRuleRequest searchFirewallRuleRequest) {
    	log.info("FirewallSearchController::searchIPAddress method starts...");
    	String filterText = null;
    	int offSet = 0;
    	String result = "pages/jsp/fw/IPAddressPopup";
    	String type = null;
    	int sourceNWZone = 0;
    	int destNWZone = 0;
    	String relationshipType = "";
    	
    	String searchType = "";
    	String con_type = (String) request.getSession().getAttribute("con_type");
    	String ipType = (String) request.getParameter("ipType");

    	String field = (String)request.getParameter("field");
    	if (request.getParameter("sourceNWZone") != null) {
    		sourceNWZone = Integer.valueOf(request.getParameter("sourceNWZone"));
    	}
    	if (request.getParameter("destNWZone") != null) {
    		destNWZone = Integer.valueOf(request.getParameter("destNWZone"));
    	}
    	if (request.getParameter("relationshipType") != null) {
    		relationshipType = request.getParameter("relationshipType");
    	}
    	if ("ipReg".equalsIgnoreCase(con_type))
    	{
    		if("SourceIP".equalsIgnoreCase(ipType)){
    			searchType = "IPR";
    		}
    		else{
    			searchType = "IP";
    		}
    	}
    	else
    	{
    	 searchType = "IP";
    	}
    	if (searchFirewallRuleRequest != null) {
    		filterText = searchFirewallRuleRequest.getFilterText();
    		offSet = searchFirewallRuleRequest.getOffset();
    		field = searchFirewallRuleRequest.getField();
    		searchType = searchFirewallRuleRequest.getFilterType();
    		sourceNWZone = searchFirewallRuleRequest.getRequesterResourceType();
        	destNWZone = searchFirewallRuleRequest.getTargetResourceType();
        	relationshipType = searchFirewallRuleRequest.getRelationshipType();
    		type = (String)request.getParameter("type");
    		
    		if ("N".equalsIgnoreCase(type)) {
        		offSet = offSet+10;
        	} else if ("P".equalsIgnoreCase(type)) {
        		offSet = offSet-10;
        	}
    	}
    	
	    searchFirewallRuleRequest = new SearchFirewallRuleRequest();
	    searchFirewallRuleRequest.setField(field);
	    searchFirewallRuleRequest.setRequesterResourceType(sourceNWZone);
	    searchFirewallRuleRequest.setTargetResourceType(destNWZone);
	    searchFirewallRuleRequest.setOffset(offSet);
	    searchFirewallRuleRequest.setFilterType(searchType);
	    searchFirewallRuleRequest.setFilterText(filterText);
	    searchFirewallRuleRequest.setRelationshipType(relationshipType);
	    searchFirewallRuleRequest.setIpType(ipType);
	    TIRequest tiRequestEntity = null;
		tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
		searchFirewallRuleRequest.setTiRequest(tiRequestEntity.getId());
		if (searchFirewallRuleRequest.getFilterType() != null && !searchFirewallRuleRequest.getFilterType().isEmpty()
				&& "IP".equalsIgnoreCase(searchFirewallRuleRequest.getFilterType())) {  
			List<IPAddress> ipAddressList = searchFirewallRuleRequest.getIPAddresses();
		    searchFirewallRuleRequest.setIpAddressList(ipAddressList);
		} else if (searchFirewallRuleRequest.getFilterType() != null && !searchFirewallRuleRequest.getFilterType().isEmpty()
				&& "PER".equalsIgnoreCase(searchFirewallRuleRequest.getFilterType())) {
			List<PersonalObject> personalObjectIPs = searchFirewallRuleRequest.listPersonalObjectIPs();
			if (personalObjectIPs != null) {
				log.debug("PersonalObjectIPs Size "+personalObjectIPs.size());
			}
			searchFirewallRuleRequest.setPersonalObjects(personalObjectIPs);
		} else if (searchFirewallRuleRequest.getFilterType() != null && !searchFirewallRuleRequest.getFilterType().isEmpty()
				&& "TMP".equalsIgnoreCase(searchFirewallRuleRequest.getFilterType())) {  
			List<FireWallRuleIP> ipList = searchFirewallRuleRequest.searchTemplateIPObjects();
			searchFirewallRuleRequest.setFirewallRuleIPList(ipList);
		} else {
			List<IPRegACL> ipRegACLList = searchFirewallRuleRequest.getIpRegACL();
			log.debug("Fetching access types");
		    searchFirewallRuleRequest.setIpRegACLList(ipRegACLList);
		}
	    log.info("FirewallSearchController::searchIPAddress method ends...sourceNWZone==>"+sourceNWZone+"...destNWZone==>"+destNWZone);
	    log.info("FirewallSearchController:: ipType"+ipType);
	    model.addAttribute("searchFirewallRuleRequest", searchFirewallRuleRequest);
		return result;
    }
	
    /*
     * To Add IP Personal Object
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/addPersonalObjectIP.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String addPersonalObjectIP(HttpServletRequest request, ModelMap model, @ModelAttribute("searchFirewallRuleRequest") SearchFirewallRuleRequest searchFirewallRuleRequest) {
    	log.info("SearchFirewallRuleAction::addPersonalObject methods starts...");
    	int sourceNWZone = searchFirewallRuleRequest.getRequesterResourceType();
    	int destNWZone = searchFirewallRuleRequest.getTargetResourceType();
    	String field = searchFirewallRuleRequest.getField();
    	String relationshipType = searchFirewallRuleRequest.getRelationshipType();
    	searchFirewallRuleRequest = new SearchFirewallRuleRequest();
    	searchFirewallRuleRequest.setRequesterResourceType(sourceNWZone);
		searchFirewallRuleRequest.setTargetResourceType(destNWZone);
		searchFirewallRuleRequest.setField(field);
		searchFirewallRuleRequest.setRelationshipType(relationshipType);
    	PersonalObject personalObject = new PersonalObject();
    	List<PersonalObjectIP> personalObjectIPs = new ArrayList<PersonalObjectIP>();
    	PersonalObjectIP personalObjectIP = new PersonalObjectIP();
    	IPAddress ipAddress = new IPAddress();
    	personalObjectIP.setIpAddress(ipAddress);
    	personalObjectIPs.add(personalObjectIP);
    	personalObject.setPersonalObjectIPs(personalObjectIPs);
    	searchFirewallRuleRequest.setPersonalObject(personalObject);
    	model.addAttribute("searchFirewallRuleRequest", searchFirewallRuleRequest);
		log.info("SearchFirewallRuleAction::addPersonalObject methods ends...");
		return "pages/jsp/fw/ViewPersonalObject";
    }
    
    /*
     * To Edit IP Personal Object
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/editPersonalObjectIP.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String editPersonalObjectIP(HttpServletRequest request, ModelMap model, @ModelAttribute("searchFirewallRuleRequest") SearchFirewallRuleRequest searchFirewallRuleRequest) {
    	log.info("SearchFirewallRuleAction::editPersonalObjectIP methods starts...");
    	
    	Long objectId = Long.valueOf(request.getParameter("objectId"));
    	
    	int sourceNWZone = searchFirewallRuleRequest.getRequesterResourceType();
    	int destNWZone = searchFirewallRuleRequest.getTargetResourceType();
    	String field = searchFirewallRuleRequest.getField();
    	String relationshipType = searchFirewallRuleRequest.getRelationshipType();
    	searchFirewallRuleRequest = new SearchFirewallRuleRequest();
    	searchFirewallRuleRequest.setRequesterResourceType(sourceNWZone);
		searchFirewallRuleRequest.setTargetResourceType(destNWZone);
		searchFirewallRuleRequest.setField(field);
		searchFirewallRuleRequest.setRelationshipType(relationshipType);
    	searchFirewallRuleRequest.setObjectId(objectId);
    	PersonalObject personalObject = searchFirewallRuleRequest.findPersonalObject();
    	searchFirewallRuleRequest.setPersonalObject(personalObject);
    	model.addAttribute("searchFirewallRuleRequest", searchFirewallRuleRequest);
		log.info("SearchFirewallRuleAction::editPersonalObjectIP methods ends...");
		return "pages/jsp/fw/ViewPersonalObject";
    }
    
    /*
     * To Add Port Personal Object
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/addPersonalObjectPort.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String addPersonalObjectPort(HttpServletRequest request, ModelMap model, @ModelAttribute("searchFirewallRuleRequest") SearchFirewallRuleRequest searchFirewallRuleRequest) {
    	log.info("SearchFirewallRuleAction::addPersonalObjectPort methods starts...");
    	String field = searchFirewallRuleRequest.getField();
    	String relationshipType = searchFirewallRuleRequest.getRelationshipType();
    	searchFirewallRuleRequest = new SearchFirewallRuleRequest();
		searchFirewallRuleRequest.setField(field);
		searchFirewallRuleRequest.setRelationshipType(relationshipType);
    	loadSessionAttributes(searchFirewallRuleRequest, request);
    	PersonalObject personalObject = new PersonalObject();
    	List<PersonalObjectPort> personalObjectPorts = new ArrayList<PersonalObjectPort>();
    	PersonalObjectPort personalObjectPort = new PersonalObjectPort();
    	Port port = new Port(); 
    	port.setProtocol("TCP");
    	personalObjectPort.setPort(port);
    	personalObjectPorts.add(personalObjectPort);
    	personalObject.setPersonalObjectPorts(personalObjectPorts);
    	searchFirewallRuleRequest.setPersonalObject(personalObject);
    	model.addAttribute("searchFirewallRuleRequest", searchFirewallRuleRequest);
		log.info("SearchFirewallRuleAction::addPersonalObjectPort methods ends...");
		return "pages/jsp/fw/ViewPersonalObjectPort";
    }
    

    
    /*
     * To Edit Port Personal Object
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/editPersonalObjectPort.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String editPersonalObjectPort(HttpServletRequest request, ModelMap model, @ModelAttribute("searchFirewallRuleRequest") SearchFirewallRuleRequest searchFirewallRuleRequest) {
    	log.info("SearchFirewallRuleAction::editPersonalObjectPort methods starts...");
    	Long objectId = Long.valueOf(request.getParameter("objectId"));
    	String field = searchFirewallRuleRequest.getField();
    	String relationshipType = searchFirewallRuleRequest.getRelationshipType();
    	searchFirewallRuleRequest = new SearchFirewallRuleRequest();
		searchFirewallRuleRequest.setField(field);
		searchFirewallRuleRequest.setRelationshipType(relationshipType);
    	searchFirewallRuleRequest.setObjectId(objectId);
    	PersonalObject personalObject = searchFirewallRuleRequest.findPersonalObject();
    	searchFirewallRuleRequest.setPersonalObject(personalObject);
    	loadSessionAttributes(searchFirewallRuleRequest, request);
    	model.addAttribute("searchFirewallRuleRequest", searchFirewallRuleRequest);
		log.info("SearchFirewallRuleAction::editPersonalObjectPort methods ends...");
		return "pages/jsp/fw/ViewPersonalObjectPort";
    }
    
    /**
     * 
     */
	@RequestMapping(value = "/savePersonalObjectIP.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String savePersonalObjectIP(HttpServletRequest request, ModelMap model, 
			@ModelAttribute("searchFirewallRuleRequest") SearchFirewallRuleRequest searchFirewallRuleRequest, BindingResult bresult) {
    	log.info("SearchFirewallRuleAction::submitPersonalObject method Starts");
    	String result =  "pages/jsp/fw/ViewPersonalObject";
    	
    	TIRequest tiRequestEntity = null;
 		tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
 		C3parUser user = new C3parUser();
 		user.setId(tiRequestEntity.getUser().getId());
 		
    	PersonalObject personalObject = searchFirewallRuleRequest.getPersonalObject();
    	personalObject.setType("IP");
    	personalObject.setIsDeleted("N");
    	personalObject.setValidationErrors(new ArrayList<String>());
    	
    	personalObject.setUpdatedBy(user);
    	personalObject.setUpdated_date(new Date());
    	
    	if (!(personalObject.getId() != null && personalObject.getId().longValue() > 0)) {
    		personalObject.setCreatedBy(user);
    	}
    	
    	for (PersonalObjectIP personalObjectIP : personalObject.getPersonalObjectIPs()) {
    		if (personalObjectIP.isDeleted()) {
    			personalObjectIP.setIsDeleted("Y");
    		}
    		personalObjectIP.setUpdated_date(new Date());
    	}
    	
    	int sourceNWZone = searchFirewallRuleRequest.getRequesterResourceType();
    	int destNWZone = searchFirewallRuleRequest.getTargetResourceType();
    	String field = searchFirewallRuleRequest.getField();
    	String relationshipType = searchFirewallRuleRequest.getRelationshipType();
    	personalObject = searchFirewallRuleRequest.validatePersonalObject(personalObject);
    	
    	if (personalObject.getValidationErrors() != null && personalObject.getValidationErrors().size() > 0) {
			for (String error : personalObject.getValidationErrors()) {
				bresult.addError(new ObjectError("personalObject.error", error));
			}
			request.setAttribute("loadPage", "add");
			result =  "pages/jsp/fw/SearchIPAddress";
			return result;
		}
    	
    	searchFirewallRuleRequest.setPersonalObject(personalObject);
    	searchFirewallRuleRequest.getPersonalObject().setPersonalObjectPorts(null);
    	try {
    		searchFirewallRuleRequest.savePersonalObjects();
    	} catch (Exception e) {
    		log.error(e, e);
    		log.error("Business Exception Occured... - "+e.getMessage());
    		bresult.addError(new ObjectError("personalObject.error", 
			"Not able to save the Personal Object. Execption Occured."));
    		request.setAttribute("loadPage", "add");
    		result =  "pages/jsp/fw/SearchIPAddress";
			return result;
    	}
    	searchFirewallRuleRequest = new SearchFirewallRuleRequest();
    	searchFirewallRuleRequest.setFilterText("");
		searchFirewallRuleRequest.setOffset(0);
		searchFirewallRuleRequest.setRequesterResourceType(sourceNWZone);
		searchFirewallRuleRequest.setTargetResourceType(destNWZone);
		searchFirewallRuleRequest.setField(field);
		searchFirewallRuleRequest.setFilterType("PER");
		searchFirewallRuleRequest.setRelationshipType(relationshipType);
    	log.info("SearchFirewallRuleAction::submitPersonalObject method ends");
    	return "forward:/searchIPAddress.act";
    }
    
    /**
     * 
     */
	@RequestMapping(value = "/savePersonalObjectPort.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String savePersonalObjectPort(HttpServletRequest request, ModelMap model, 
			@ModelAttribute("searchFirewallRuleRequest") SearchFirewallRuleRequest searchFirewallRuleRequest, BindingResult bresult) {
    	log.info("SearchFirewallRuleAction::savePersonalObjectPort method Starts");
    	String result =  "add_personalobject";
    	
    	TIRequestEntity tiRequestEntity = null;
 		tiRequestEntity = (TIRequestEntity) request.getSession().getAttribute("TI_REQUEST_ENTITY");
 		C3parUser user = new C3parUser();
 		user.setId(tiRequestEntity.getUserId());
 		
    	PersonalObject personalObject = searchFirewallRuleRequest.getPersonalObject();
    	personalObject.setType("PRT");
    	personalObject.setIsDeleted("N");
    	personalObject.setValidationErrors(new ArrayList<String>());
    	
    	personalObject.setUpdatedBy(user);
    	personalObject.setUpdated_date(new Date());
    	
    	if (!(personalObject.getId() != null && personalObject.getId().longValue() > 0)) {
    		personalObject.setCreatedBy(user);
    	}
    	
    	for (PersonalObjectPort personalObjectPort : personalObject.getPersonalObjectPorts()) {
    		if (personalObjectPort.isDeleted()) {
    			personalObjectPort.setIsDeleted("Y");
    		}
    		if (!(personalObjectPort.getPort().getProtocol().equalsIgnoreCase("TCP") 
	    			|| personalObjectPort.getPort().getProtocol().equalsIgnoreCase("UDP")
	    			|| personalObjectPort.getPort().getProtocol().equalsIgnoreCase("OBJECT"))) {
				personalObjectPort.getPort().setPortNumber(personalObjectPort.getPort().getProtocol());
	    	}
			personalObjectPort.getPort().setFlowOfData(FLOW_OF_DATA_ATOB);
			personalObjectPort.setUpdated_date(new Date());
    	}
    	
    	String field = searchFirewallRuleRequest.getField();
    	String relationshipType = searchFirewallRuleRequest.getRelationshipType();
    	personalObject = searchFirewallRuleRequest.validatePersonalObjectPort(personalObject);
    	
    	if (personalObject.getValidationErrors() != null && personalObject.getValidationErrors().size() > 0) {
			for (String error : personalObject.getValidationErrors()) {
				bresult.addError(new ObjectError("personalObject.error", error));
			}
			loadSessionAttributes(searchFirewallRuleRequest, request);
			request.setAttribute("loadPage", "add");
			result =  "show_PortObjects";
			return result;
		}
    	
    	searchFirewallRuleRequest.setPersonalObject(personalObject);
    	searchFirewallRuleRequest.getPersonalObject().setPersonalObjectIPs(null);
    	try {
    		searchFirewallRuleRequest.savePersonalObjectsPort();
    	} catch (Exception e) {
    		log.error(e, e);
    		log.error("Business Exception Occured... - "+e.getMessage());
    		loadSessionAttributes(searchFirewallRuleRequest, request);
    		bresult.addError(new ObjectError("personalObject.error", 
			"Not able to save the Personal Object. Execption Occured."));
    		request.setAttribute("loadPage", "add");
    		result =  "show_PortObjects";
			return result;
    	}
    	searchFirewallRuleRequest = new SearchFirewallRuleRequest();
    	searchFirewallRuleRequest.setFilterText("");
		searchFirewallRuleRequest.setOffset(0);
		searchFirewallRuleRequest.setField(field);
		searchFirewallRuleRequest.setFilterType("PER");
		searchFirewallRuleRequest.setRelationshipType(relationshipType);
    	log.info("SearchFirewallRuleAction::savePersonalObjectPort method ends");
    	return "forward:/searchPortObjects.act";
    }
    
    /*
     * To Search the IP Address
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/searchPortObjects.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String searchPortObjects(HttpServletRequest request, ModelMap model) {
    	log.info("ManageFirewallRulesAction::searchPortObjects method starts...");
    	String filterText = null;
    	int offSet = 0;
    	String result = "pages/jsp/fw/SearchPortObjects";
    	
    	String field = (String)request.getParameter("field");
    	
    	String filterType = (String)request.getParameter("filterType");
    	
    	String relationshipType = (String)request.getParameter("relationshipType");
    	
    	String searchType = "PER";
    	
    	if(filterType != null){
    		searchType = filterType;
    	}	
    	
    	SearchFirewallRuleRequest searchFirewallRuleRequest = new SearchFirewallRuleRequest();
	    searchFirewallRuleRequest.setField(field);
	    searchFirewallRuleRequest.setOffset(offSet);
	    searchFirewallRuleRequest.setFilterType(searchType);
	    searchFirewallRuleRequest.setFilterText(filterText);
	    searchFirewallRuleRequest.setRelationshipType(relationshipType);
	    TIRequest tiRequestEntity = null;
		tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
		searchFirewallRuleRequest.setTiRequest(tiRequestEntity.getId());
		if (searchFirewallRuleRequest.getFilterType() != null && !searchFirewallRuleRequest.getFilterType().isEmpty()
				&& "PER".equalsIgnoreCase(searchFirewallRuleRequest.getFilterType())) {
			List<PersonalObject> personalObjectPorts = searchFirewallRuleRequest.listPersonalObjectPorts();
			searchFirewallRuleRequest.setPersonalObjects(personalObjectPorts);
		} else {
			List<FireWallRulePort> portObjectsList = searchFirewallRuleRequest.searchTemplatePortObjects();
			searchFirewallRuleRequest.setFirewallRulePortList(portObjectsList);
		}
		model.addAttribute("searchFirewallRuleRequest", searchFirewallRuleRequest);
	    log.info("ManageFirewallRulesAction::searchPortObjects method ends...");
		return result;
    }
	
	/*
     * To Search the IP Address
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/paginatePortObjects.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String paginatePortObjects(HttpServletRequest request, ModelMap model, @ModelAttribute("searchFirewallRuleRequest") SearchFirewallRuleRequest searchFirewallRuleRequest) {
    	log.info("ManageFirewallRulesAction::searchPortObjects method starts...");
    	String filterText = null;
    	int offSet = 0;
    	String result = "pages/jsp/fw/PortPopup";
    	String type = null;
    	
    	String field = (String)request.getParameter("field");
    	
    	String relationshipType = (String)request.getParameter("relationshipType");
    	
    	String searchType = "PER";
    	
    	if (searchFirewallRuleRequest != null) {
    		filterText = searchFirewallRuleRequest.getFilterText();
    		offSet = searchFirewallRuleRequest.getOffset();
    		field = searchFirewallRuleRequest.getField();
    		searchType = searchFirewallRuleRequest.getFilterType();
    		relationshipType = searchFirewallRuleRequest.getRelationshipType();
    		type = (String)request.getParameter("type");
    		
    		if ("N".equalsIgnoreCase(type)) {
        		offSet = offSet+10;
        	} else if ("P".equalsIgnoreCase(type)) {
        		offSet = offSet-10;
        	}
    	}
    	
	    searchFirewallRuleRequest = new SearchFirewallRuleRequest();
	    searchFirewallRuleRequest.setField(field);
	    searchFirewallRuleRequest.setOffset(offSet);
	    searchFirewallRuleRequest.setFilterType(searchType);
	    searchFirewallRuleRequest.setFilterText(filterText);
	    searchFirewallRuleRequest.setRelationshipType(relationshipType);
	    TIRequestEntity tiRequestEntity = null;
		tiRequestEntity = (TIRequestEntity) request.getSession().getAttribute("TI_REQUEST_ENTITY");
		searchFirewallRuleRequest.setTiRequest(tiRequestEntity.getId());
		if (searchFirewallRuleRequest.getFilterType() != null && !searchFirewallRuleRequest.getFilterType().isEmpty()
				&& "PER".equalsIgnoreCase(searchFirewallRuleRequest.getFilterType())) {
			List<PersonalObject> personalObjectPorts = searchFirewallRuleRequest.listPersonalObjectPorts();
			searchFirewallRuleRequest.setPersonalObjects(personalObjectPorts);
		} else {
			List<FireWallRulePort> portObjectsList = searchFirewallRuleRequest.searchTemplatePortObjects();
			searchFirewallRuleRequest.setFirewallRulePortList(portObjectsList);
		}
		model.addAttribute("searchFirewallRuleRequest", searchFirewallRuleRequest);
	    log.info("ManageFirewallRulesAction::searchPortObjects method ends...");
		return result;
    }
    
    private void loadSessionAttributes(SearchFirewallRuleRequest firewallRuleProc, HttpServletRequest request) {
    	firewallRuleProc.setControlMessagesList((List<GenericLookup>)request.getSession().getAttribute("CONTROLMSGS"));
    	firewallRuleProc.setResourceTypes((List<ResourceType>)request.getSession().getAttribute("RESOURCETYPE"));
    	firewallRuleProc.setProtocolList((List<GenericLookup>)request.getSession().getAttribute("PROTOCOLLIST"));
    }
	
	
	}
