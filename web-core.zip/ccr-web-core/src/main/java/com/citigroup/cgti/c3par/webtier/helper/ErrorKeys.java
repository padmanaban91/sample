/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  [2002-2003] Mentisys, Inc.  All rights reserved.
 * The contents of this material are confidential and proprietary to
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.webtier.helper;


/**
 * The Interface ErrorKeys.
 */
public interface ErrorKeys {
    //	String CHANGE_TP_ACTION_SEARCH_FORM_NOT_FOUND = "error.thirdparty.change.search.form.not.found" ;
    //	String CHANGE_TP_ACTION_SEARCH_HAS_NO_SELECTION = "error.thirdparty.change.search.has.no.selections" ;
    //	String CHANGE_TP_ACTION_SEARCH_RELATIOSHIP_FORM_NOT_FOUND = "error.thirdparty.change.search.relationship.form.not.found" ;
    //	
    //	String CHANGE_BU_ACTION_SEARCH_FORM_NOT_FOUND = "error.bu.change.search.form.not.found";
    //	String CHANGE_BU_ACTION_SEARCH_HAS_NO_SELECTION = "error.bu.change.search.has.no.selections" ;
    //	String CHANGE_BU_ACTION_SEARCH_RELATIOSHIP_FORM_NOT_FOUND = "error.bu.change.search.relationship.form.not.found" ;
    //	
    //	String ADD_CITI_LOCATION_ACTION_SEARCH_FORM_NOT_FOUND = "error.citi.location.add.search.form.not.found";
    //	String ADD_CITI_LOCATION_ACTION_SEARCH_RELATIOSHIP_FORM_NOT_FOUND = "error.citi.location.add.search.relationship.form.not.found" ;
    //	
    //	String ADD_TP_LOCATION_ACTION_SEARCH_FORM_NOT_FOUND = "error.tp.location.add.search.form.not.found" ;
    //	
    //	String ADD_TP_LOCATION_ACTION_SEARCH_RELATIOSHIP_FORM_NOT_FOUND = "error.tp.location.add.search.has.no.selections" ;
    //	String ADD_CITI_CONTACT_ACTION_SEARCH_FORM_NOT_FOUND = null;
    //	String ADD_CITI_CONTACT_ACTION_SEARCH_RELATIOSHIP_FORM_NOT_FOUND = null;

    /** The RELATIOSHI p_ for m_ no t_ found. */
    String RELATIOSHIP_FORM_NOT_FOUND = "relationship.form.not.found"; 

    /** The SEARC h_ for m_ no t_ found. */
    String SEARCH_FORM_NOT_FOUND = "search.form.not.found";

}