package com.citigroup.cgti.c3par.webtier.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import org.apache.log4j.Logger;


/**
 * The Class DateConversionHelper.
 */
public class DateConversionHelper
{

    /** The log. */
    private static Logger log = Logger.getLogger(DateConversionHelper.class);

    /**
     * Gets the month in int.
     *
     * @param month the month
     * @return the month in int
     */
    public static String getMonthInInt(String month)
    {
	String tmonth = "0";
	if(month != null)
	{
	    if(month.equals("JAN")) tmonth = "01"; 
	    else if(month.equals("FEB")) tmonth = "02"; 
	    else if(month.equals("MAR")) tmonth = "03"; 
	    else if(month.equals("APR")) tmonth = "04"; 
	    else if(month.equals("MAY")) tmonth = "05"; 
	    else if(month.equals("JUN")) tmonth = "06"; 
	    else if(month.equals("JUL")) tmonth = "07"; 
	    else if(month.equals("AUG")) tmonth = "08"; 
	    else if(month.equals("SEP")) tmonth = "09"; 
	    else if(month.equals("OCT")) tmonth = "10"; 
	    else if(month.equals("NOV")) tmonth = "11"; 
	    else if(month.equals("DEC")) tmonth = "12";
	}

	return tmonth;
    }

    /**
     * Gets the int to month.
     *
     * @param month the month
     * @return the int to month
     */
    public static String getIntToMonth(String month)
    {
	String tmonth = "";
	if(month.equals("1")) tmonth = "JAN"; 
	else if(month.equals("2")) tmonth = "FEB"; 
	else if(month.equals("3")) tmonth = "MAR"; 
	else if(month.equals("4")) tmonth = "APR"; 
	else if(month.equals("5")) tmonth = "MAY"; 
	else if(month.equals("6")) tmonth = "JUN"; 
	else if(month.equals("7")) tmonth = "JUL"; 
	else if(month.equals("8")) tmonth = "AUG"; 
	else if(month.equals("9")) tmonth = "SEP"; 
	else if(month.equals("10")) tmonth = "OCT"; 
	else if(month.equals("11")) tmonth = "NOV"; 
	else if(month.equals("12")) tmonth = "DEC";

	return tmonth;
    }

    /**
     * Gets the int to month.
     *
     * @param month the month
     * @return the int to month
     */
    public static String getIntToMonth(int month)
    {
	String[] month_names = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" }; 
	return  month_names[month];
    }


    /**
     * Gets the date.
     *
     * @param year the year
     * @param month the month
     * @param day the day
     * @return the date
     */
    public static Date getDate(String year,String month,String day)
    {
	Date date = new Date();

	int y, m, d;
	try {
		if(year != null	&& month != null && day != null){			
		    y = Integer.parseInt(year);
		    m = Integer.parseInt(month);
		    d = Integer.parseInt(day);
		    GregorianCalendar c = new GregorianCalendar();
		    c.setLenient(false);
		    c.set(y, m - 1, d);
		    date = c.getTime();
		    return date;
		}else{
			return null;
		}
	} catch (Exception e) {
	    // TO DO
	    log.error(e);
	    return null;

	}
    }

    public static String convertToString(Date date,String format){
	String returnString = "";
	try {
	    DateFormat dateFormat = new SimpleDateFormat(format);
	    returnString = dateFormat.format(date);
	} catch (Exception e) {
	    log.error(e, e);
	}
	return returnString;
    }


}