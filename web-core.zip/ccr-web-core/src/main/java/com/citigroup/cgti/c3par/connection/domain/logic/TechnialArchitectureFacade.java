package com.citigroup.cgti.c3par.connection.domain.logic;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.appsense.domain.AppsenseDTO;
import com.citigroup.cgti.c3par.appsense.domain.ConnectionOstiaGroup;
import com.citigroup.cgti.c3par.connection.domain.ConnectionFWPolicyXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionFWRuleXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionFirewallPolicyLookUp;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIPPairMaster;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIPPairXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIPXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIpsecTunnelMaster;
import com.citigroup.cgti.c3par.connection.domain.ConnectionPortXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionProcess;
import com.citigroup.cgti.c3par.connection.domain.ConnectionVIPMaster;
import com.citigroup.cgti.c3par.connection.domain.FirewallRuleRequest;
import com.citigroup.cgti.c3par.connection.domain.IPPairRequest;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.logic.C3parServiceFacade;


/**
 * The Interface TechnialArchitectureFacade.
 */
@SuppressWarnings( { "unchecked" })
public interface TechnialArchitectureFacade extends C3parServiceFacade {

    /**
     * Look up method for ConnectionProcess with Maintenance Connection Request
     * Id.
     *
     * @param maintenanceRequestId the maintenance request id
     * @return the connection by maintenance request
     */
    ConnectionProcess getConnectionByMaintenanceRequest(
	    Long maintenanceRequestId);

    /**
     * Look up method for ConnectionProcess with Orginal Connection Request Id.
     *
     * @param orginalRequestId the orginal request id
     * @return the connection by orginal request
     */
    ConnectionProcess getConnectionByOrginalRequest(Long orginalRequestId);

    /**
     * Look up method for ConnectionProcess with Orginal Connection Request Id.
     *
     * @param orginalRequestId the orginal request id
     * @param loadRef the load ref
     * @return the connection by orginal request
     */
    ConnectionProcess getConnectionByOrginalRequest(Long orginalRequestId,
	    boolean loadRef);


    /**
     * This method updates the database record for the given ConnectionIPMaster,
     * the returned ConnectionProcess will have the updated ConnectionIPMaster
     * loaded.
     *
     * @param conProcess the con process
     * @param conIPXref the con ip xref
     * @return ConnectionProcess with updated ConnectionIPMaster loaded
     */
    ConnectionProcess updateIPMaster(ConnectionProcess conProcess,
	    ConnectionIPXref conIPXref);

    /**
     * This methods returns ConnectionProcess loaded with IPMaster records of
     * the specified resourceType. If isOnlyShare is true then only Shared
     * IPMaster records are loaded. if isFlush is set to true then the existing
     * records are flushed out while loading the new records. The number records
     * equal to pageNo * 6 (default) is skipped and the remaining are loaded.
     *
     * @param conProcess the con process
     * @param performerFilterList the performer filter list
     * @return List of ConnectionIPMaster
     */
    /*
     * List loadIPMaster(ConnectionProcess conProcess, String resourceType,
     * boolean isOnlyShare,boolean isFlush);
     */

    /**
     * This method deletes ConnectionIPMaster records from the database. If the
     * ConnectionIPMaster is not shared by any other connection, it removes only
     * the reference to this ConnectionProcess
     *
     * If isSelectAll flag in the ConnectionProcess is TRUE it will
     * delete/de-reference all the ConnectionIPMaster records of the currenly
     * loaded resource type. .
     *
     * If isSelectAll flag in the ConnectionProcess is TRUE AND isSelected on
     * one/more ConnectionIPMaster is False, then it will delete/de-reference
     * all the ConnectionIPMaster records of the currenly loaded resource type
     * EXCLUDING those ConnectionIPMaster with isSelected is FALSE.
     *
     * Note: If isSelectAll flag in the ConnectionProcess is TRUE then this
     * operation (delete/de-reference) is performed on all the records NOT just
     * the records loaded for display on the page.
     *
     * @param conProcess
     * @param performerFilterList
     * @return ConnectionProcess with conIPMaster deleted
     */
    ConnectionProcess deleteIPMaster(ConnectionProcess conProcess,
	    Map performerFilterList);

    /**
     * This method returns list of ConnectionVIPMaster for the given
     * ConnectionIPMaster id.
     *
     * @param conProcess the con process
     * @param performerFilterList the performer filter list
     * @return List of ConnectionVIPMaster
     */

    // List loadAvialableVirtualIP(Long c,ConnectionProcess conProcess);
    /**
     * This method returns the ConnectionVIPMaster for the given
     * ConnectionIPMaster id assigned for this ConnectionProcess
     *
     * @param id
     *            ConnectionIPMaster id
     * @param conProcess
     * @return List of ConnectionVIPMaste.
     */

    // List loadAssignedVirtualIP(Long id,ConnectionProcess conProcess);
    /**
     * This method deletes ConnectionVIPMaster with isSelected Flag True for the
     * given ConnectionProcess and if the given ConnectionVIPMaster is not
     * associated with any other ConnectionProcess then it deletes the
     * ConnectionVIPMaster
     *
     * @param conProcess
     * @param performerFilterList
     * @return ConnectionProcess with the ConnectionVIPMaster deleted
     */
    ConnectionProcess deleteVirtualIP(ConnectionProcess conProcess,
	    List performerFilterList);

    /**
     * This method adds the given ConnectionVIPMaster to the ConnectionIPMaster
     * and associates the ConnectionVIPMaster to the ConnectionProcess.
     *
     * @param conProcess the con process
     * @param conVIPMst the con vip mst
     * @return ConnectionProcess with ConnectionVIPMaster added
     */
    ConnectionProcess addVirtualIP(ConnectionProcess conProcess,
	    ConnectionVIPMaster conVIPMst);

    /**
     * Adds the virtual ip.
     *
     * @param conProcess the con process
     * @param conVIPMstList the con vip mst list
     * @return the connection process
     */
    ConnectionProcess addVirtualIP(ConnectionProcess conProcess,
	    List conVIPMstList);

    /**
     * Update virtual ip.
     *
     * @param conProcess the con process
     * @param conVIPMstList the con vip mst list
     * @return the connection process
     */
    ConnectionProcess updateVirtualIP(ConnectionProcess conProcess,
	    List conVIPMstList);

    /**
     * Load template master.
     *
     * @param conProcess the con process
     * @return the list
     */
    List loadTemplateMaster(ConnectionProcess conProcess);

    /**
     * Assign template.
     *
     * @param conProcess the con process
     * @param connectionIPXref the connection ip xref
     * @return the connection process
     */
    ConnectionProcess assignTemplate(ConnectionProcess conProcess,ConnectionIPXref connectionIPXref);

    /**
     * This method creates new ConnectionIPPariMaster objects for the
     * ConnectionProcess
     *
     * If isStartPointSelectAll OR isEndPointSelectAll flag in the IPPairRequest
     * is TRUE and if ALL the ConnectionIPMasters in the list has isSelected
     * flag set TRUE then all ConnectionIPMasters for the connection with the
     * same Resourcetypes are paried.
     *
     * If isStartPointSelectAll OR isEndPointSelectAll flag in the IPPairRequest
     * is TRUE AND if ONE or MORE ConnectionIPMaster's isSelected flag is FALSE
     * only those ConnectionIPMasters are ignored for pairing.
     *
     * @param conProcess the con process
     * @param iPPairRequest the i p pair request
     * @param endAFilterMap TODO
     * @param endBFilterMap TODO
     * @return ConnectionProcess with ConnectionIPPariMaster List flushed.
     */
    ConnectionProcess createIPPair(ConnectionProcess conProcess,
	    IPPairRequest iPPairRequest, Map endAFilterMap, Map endBFilterMap);

    /**
     * This method updates the given ConnectionIPPairMaster and adds it to the
     * ConnectionProcess.
     *
     * @param conProcess the con process
     * @param conIPPairMst the con ip pair mst
     * @return ConnectionProcess with updated CoonectionIPPairMaster loaded
     */
    ConnectionProcess updateIPPair(ConnectionProcess conProcess,
	    ConnectionIPPairMaster conIPPairMst);

    /**
     * Delete ip pair.
     *
     * @param conProcess the con process
     * @param performerFilterMap the performer filter map
     * @return ConnectionProcess with Deleted IPPairs removed.
     */
    ConnectionProcess deleteIPPair(ConnectionProcess conProcess,
	    Map performerFilterMap);

    /**
     * Update ip xref.
     *
     * @param conProcess the con process
     * @param filterMap the filter map
     * @param application the application
     * @return the connection process
     */
    ConnectionProcess updateIPXref(ConnectionProcess conProcess,Map filterMap,
	    Application application);

    /**
     * Adds the port.
     *
     * @param conProcess the con process
     * @param conPortXref the con port xref
     * @param riskDirectionList the risk direction list
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    ConnectionProcess addPort(ConnectionProcess conProcess,
	    ConnectionPortXref conPortXref,List riskDirectionList, Map performerFilterMap);

    /**
     * Delete common ports.
     *
     * @param conProcess the con process
     * @param conPortXrefList the con port xref list
     * @param pairFilterMap the pair filter map
     * @param portFilterMap the port filter map
     * @return the connection process
     */
    ConnectionProcess deleteCommonPorts(ConnectionProcess conProcess,
	    List conPortXrefList, Map pairFilterMap, Map portFilterMap);

    /**
     * Delete all ports.
     *
     * @param conProcess the con process
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    ConnectionProcess deleteAllPorts(ConnectionProcess conProcess,
	    Map performerFilterMap);

    /**
     * Update port.
     *
     * @param conProcess the con process
     * @param conPortXref the con port xref
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    ConnectionProcess updatePort(ConnectionProcess conProcess,
	    ConnectionPortXref conPortXref, Map performerFilterMap);

    /**
     * Adds the ostia.
     *
     * @param conProcess the con process
     * @param conPortXrefList the con port xref list
     * @param conOstiaGroup the con ostia group
     * @param pairFilterMap the pair filter map
     * @param portFilterMap the port filter map
     * @return the connection process
     */
    ConnectionProcess addOstia(ConnectionProcess conProcess,
	    List conPortXrefList, ConnectionOstiaGroup conOstiaGroup,
	    Map pairFilterMap, Map portFilterMap,boolean copyOstiaAnswers);

    /**
     * Adds the ostia answers.
     *
     * @param apsProcess the aps process
     * @param conOstiaGroup the con ostia group
     * @return the appsense process
     */
    AppsenseDTO addOstiaAnswers(AppsenseDTO apsProcess,
	    ConnectionOstiaGroup conOstiaGroup);


    /**
     * Update ostia.
     *
     * @param conProcess the con process
     * @param conPortXref the con port xref
     * @param conOstiaGroup the con ostia group
     * @param pairFilterMap the pair filter map
     * @param portFilterList the port filter list
     * @return the connection process
     */
    ConnectionProcess updateOstia(ConnectionProcess conProcess,
	    ConnectionPortXref conPortXref, ConnectionOstiaGroup conOstiaGroup,
	    Map pairFilterMap, List portFilterList);

    /**
     * Update ostia group.
     *
     * @param conProcess the con process
     * @param conOstiaGroup the con ostia group
     * @return the connection process
     */
    ConnectionProcess updateOstiaGroup(ConnectionProcess conProcess,
	    ConnectionOstiaGroup conOstiaGroup);

    /**
     * Update ostia group.
     *
     * @param appsenseProcess the appsense process
     * @param conOstiaGroup the con ostia group
     * @return the appsense process
     */
    AppsenseDTO updateOstiaGroup(AppsenseDTO appsenseProcess,
	    ConnectionOstiaGroup conOstiaGroup);

    /**
     * Adds the connection firewall.
     *
     * @param conProcess the con process
     * @param fwPolicyLookUp the fw policy look up
     * @param connectionFWPolicyXref the connection fw policy xref
     * @param conFWPolicyMstList the con fw policy mst list
     * @return the connection process
     */
    ConnectionProcess addConnectionFirewall(ConnectionProcess conProcess,
	    ConnectionFirewallPolicyLookUp fwPolicyLookUp,
	    ConnectionFWPolicyXref connectionFWPolicyXref,
	    List conFWPolicyMstList);

    /**
     * Update connection firewall.
     *
     * @param conProcess the con process
     * @param connectionFWPolicyXref the connection fw policy xref
     * @return the connection process
     */
    ConnectionProcess updateConnectionFirewall(ConnectionProcess conProcess,
	    ConnectionFWPolicyXref connectionFWPolicyXref);

    /**
     * Delete connection firewall.
     *
     * @param conProcess the con process
     * @return the connection process
     */
    ConnectionProcess deleteConnectionFirewall(ConnectionProcess conProcess);

    /**
     * Gets the firewall rule.
     *
     * @param connectionIPPairXref the connection ip pair xref
     * @return the firewall rule
     */
    List getFirewallRule(ConnectionIPPairXref connectionIPPairXref);

    /**
     * Gets the firewall rule.
     *
     * @param connectionFWRuleXref the connection fw rule xref
     * @param conProcess the con process
     * @return the firewall rule
     */
    ConnectionFWRuleXref getFirewallRule(ConnectionFWRuleXref  connectionFWRuleXref,ConnectionProcess conProcess);

    /**
     * Adds the firewall rule.
     *
     * @param conProcess the con process
     * @param fwRuleRequest the fw rule request
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    ConnectionProcess addFirewallRule(ConnectionProcess conProcess,
	    FirewallRuleRequest fwRuleRequest, Map performerFilterMap);

    /**
     * Adds the firewall rule.
     *
     * @param conProcess the con process
     * @param firewallRuleList the firewall rule list
     * @param performerFilterList the performer filter list
     * @param conIPPairMst the con ip pair mst
     * @return the connection process
     */
    ConnectionProcess addFirewallRule(ConnectionProcess conProcess,
	    List firewallRuleList, List performerFilterList,
	    ConnectionIPPairMaster conIPPairMst);

    /**
     * Update firewall rule.
     *
     * @param conProcess the con process
     * @param connectionFWRuleXref the connection fw rule xref
     */
    void updateFirewallRule(ConnectionProcess conProcess,ConnectionFWRuleXref connectionFWRuleXref);

    /**
     * Delete firewall rule.
     *
     * @param conProcess the con process
     * @param conFWRuleXrefList the con fw rule xref list
     * @param pairFilterMap the pair filter map
     * @param fwFilterMap the fw filter map
     * @return the connection process
     */
    ConnectionProcess deleteFirewallRule(ConnectionProcess conProcess,
	    List conFWRuleXrefList, Map pairFilterMap, Map fwFilterMap);

    /**
     * Delete firewall rule.
     *
     * @param conProcess the con process
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    ConnectionProcess deleteFirewallRule(ConnectionProcess conProcess,
	    Map performerFilterMap);

    /**
     * Adds the tunnel.
     *
     * @param conProcess the con process
     * @param conIpsecTunnelMst the con ipsec tunnel mst
     * @return the connection ipsec tunnel master
     */
    ConnectionIpsecTunnelMaster addTunnel(ConnectionProcess conProcess,
	    ConnectionIpsecTunnelMaster conIpsecTunnelMst);

    /**
     * Gets the tunnel.
     *
     * @param name the name
     * @param citiIpsecPeerAddr the citi ipsec peer addr
     * @param remoteIpsecPeerAddr the remote ipsec peer addr
     * @return the tunnel
     */
    List getTunnel(String name, String citiIpsecPeerAddr,
	    String remoteIpsecPeerAddr);

    /**
     * Update tunnel.
     *
     * @param conProcess the con process
     * @param conIpsecTunnelMst the con ipsec tunnel mst
     * @return the connection process
     */
    ConnectionProcess updateTunnel(ConnectionProcess conProcess,
	    ConnectionIpsecTunnelMaster conIpsecTunnelMst);

    /**
     * Delete tunnel.
     *
     * @param conProcess the con process
     * @param conIpsecTunnelMst the con ipsec tunnel mst
     * @return the connection process
     */
    ConnectionProcess deleteTunnel(ConnectionProcess conProcess,
	    ConnectionIpsecTunnelMaster conIpsecTunnelMst);

    /**
     * Gets the ostia group.
     *
     * @param ostiaGroupId the ostia group id
     * @return the ostia group
     */
    ConnectionOstiaGroup getOstiaGroup(Long ostiaGroupId);

    /**
     * Adds the application.
     *
     * @param application the application
     * @return the application
     */
    Application addApplication(Application application);

    /**
     * Load object with childs.
     *
     * @param parentList the parent list
     * @param childRef the child ref
     * @param loadRef the load ref
     * @param pageSize the page size
     * @param filters the filters
     * @return the list
     */
    List loadObjectWithChilds(List parentList, List childRef, boolean loadRef,
	    int pageSize, List filters);

    /**
     * Upload firewall stage data.
     *
     * @param resultList the result list
     */
    void uploadFirewallStageData(List resultList);

    //void sendEmailToAppOwners(Long connID) throws Exception;

    /**
     * Send oper anal schedule email.
     *
     * @param connID the conn id
     * @param sheduleDate the shedule date
     * @throws Exception the exception
     */
    void sendOperAnalScheduleEmail(Long connID, Date sheduleDate) throws Exception;

    /**
     * Send email faf completion.
     *
     * @param connectionID the connection id
     * @param reportType the report type
     * @throws Exception the exception
     */
    void sendEmailFAFCompletion(Long connectionID,String reportType) throws Exception;

    /**
     * Send oa sch email.
     *
     * @param connID the conn id
     * @throws Exception the exception
     */
    void sendOASchEmail(Long connID) throws Exception;

    /**
     * Send conn approval email.
     *
     * @param connID the conn id
     * @param activityName the activity name
     * @throws Exception the exception
     */
    void sendConnApprovalEmail(Long connID,String activityName) throws Exception;

    /**
     * Insert template port master.
     *
     * @param connID the conn id
     * @param ip_pair_xref_id the ip_pair_xref_id
     * @throws Exception the exception
     */
    void insertTemplatePortMaster(Long connID, Long ip_pair_xref_id)throws Exception;
}