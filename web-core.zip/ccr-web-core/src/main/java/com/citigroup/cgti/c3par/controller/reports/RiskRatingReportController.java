package com.citigroup.cgti.c3par.controller.reports;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.reports.domain.RiskRatingReport;
import com.citigroup.cgti.c3par.reports.domain.RiskRatingReportProcess;

@Controller
public class RiskRatingReportController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	private final String PARENT = "parent";	
	private final String CASP = "casp";	
	private final String DETAIL = "detail";	
	private final String Y = "Y";	
	private final String N = "N";

	@RequestMapping(value = "/riskRatingReport_exportParent", method = { RequestMethod.GET, RequestMethod.POST })
	public String exportParentRiskRating(ModelMap model, @ModelAttribute("riskratingProcess") RiskRatingReportProcess riskratingProcess){
		log.info("RiskRatingReportController :: exportParentRiskRating method starts");
		
		getReportBasedOnType(model,riskratingProcess,PARENT, Y);
		
		return "pages/reports/VendorParentRiskReportExport";
	}

	@RequestMapping(value = "/riskRatingReport_exportCasp", method = { RequestMethod.GET, RequestMethod.POST })
	public String exportCaspRiskRating(ModelMap model, @ModelAttribute("riskratingProcess") RiskRatingReportProcess riskratingProcess){
		log.info("RiskRatingReportController :: exportCaspRiskRating method starts");
		
		getReportBasedOnType(model,riskratingProcess,CASP, Y);
		
		return "pages/reports/VendorCaspRiskReportExport";
	}

	@RequestMapping(value = "/riskRatingReport_exportDetail", method = { RequestMethod.GET, RequestMethod.POST })
	public String exportDetailRiskRating(ModelMap model, @ModelAttribute("riskratingProcess") RiskRatingReportProcess riskratingProcess){
		log.info("RiskRatingReportController :: exportDetailRiskRating method starts");
		
		getReportBasedOnType(model,riskratingProcess,DETAIL, Y);
		
		return "pages/reports/VendorDetailRiskReportExport";
	}

	@RequestMapping(value = "/riskRatingReport_exportConnection", method = { RequestMethod.GET, RequestMethod.POST })
	public String exportConnectionRiskRating(ModelMap model, @ModelAttribute("riskratingProcess") RiskRatingReportProcess riskratingProcess){
		log.info("RiskRatingReportController :: exportConnectionRiskRating method starts");
		
		connectionRiskRating(model,riskratingProcess,Y);
		
		return "pages/reports/ConnectionRiskReportExport";
	}

	@RequestMapping(value = "/riskRatingReport_parent", method = { RequestMethod.GET, RequestMethod.POST })
	public String parentRiskRating(ModelMap model, @ModelAttribute("riskratingProcess") RiskRatingReportProcess riskratingProcess){
		log.info("RiskRatingReportController :: parentRiskRating method starts");
		
		getReportBasedOnType(model,riskratingProcess,PARENT, N);
		
		return "c3par.reports.riskrating.vendorParent";
	}

	@RequestMapping(value = "/riskRatingReport_casp", method = { RequestMethod.GET, RequestMethod.POST })
	public String caspRiskRating(ModelMap model, @ModelAttribute("riskratingProcess") RiskRatingReportProcess riskratingProcess){
		log.info("RiskRatingReportController :: caspRiskRating method starts");
		
		getReportBasedOnType(model,riskratingProcess,CASP, N);
		
		return "c3par.reports.riskrating.vendorCasp";
	}

	@RequestMapping(value = "/riskRatingReport_detail", method = { RequestMethod.GET, RequestMethod.POST })
	public String detailRiskRating(ModelMap model, @ModelAttribute("riskratingProcess") RiskRatingReportProcess riskratingProcess){
		log.info("RiskRatingReportController :: detailRiskRating method starts");
		
		getReportBasedOnType(model,riskratingProcess,DETAIL, N);
		
		return "c3par.reports.riskrating.vendorDetail";
	}

	@RequestMapping(value = "/riskRatingReport_connection", method = { RequestMethod.GET, RequestMethod.POST })
	public String connRiskRating(ModelMap model, @ModelAttribute("riskratingProcess") RiskRatingReportProcess riskratingProcess){
		log.info("RiskRatingReportController :: connRiskRating method starts");
		
		connectionRiskRating(model,riskratingProcess,N);
		
		return "c3par.reports.riskrating.connection";
	}

	public void getReportBasedOnType(ModelMap model, RiskRatingReportProcess riskratingProcess, String type, String export){

		if(riskratingProcess == null){
			riskratingProcess = new RiskRatingReportProcess();
		}
		
		List<RiskRatingReport> reportlist =  riskratingProcess.getVendorList(riskratingProcess.getVendorNameFilter(), type, export);
		riskratingProcess.setReportList(reportlist);
		model.addAttribute("riskratingProcess",riskratingProcess);		
	}

	public void connectionRiskRating(ModelMap model, RiskRatingReportProcess riskratingProcess, String export){

		if(riskratingProcess == null){
			riskratingProcess = new RiskRatingReportProcess();
		}
		
		List<RiskRatingReport> reportlist =  riskratingProcess.getConnLevelList(riskratingProcess.getConnIdFilter(),export);
		riskratingProcess.setReportList(reportlist);
		model.addAttribute("riskratingProcess",riskratingProcess);		
	}
}
