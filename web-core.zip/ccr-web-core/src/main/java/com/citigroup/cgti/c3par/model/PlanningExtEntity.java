package com.citigroup.cgti.c3par.model;


/**
 * The Class PlanningExtEntity.
 */
public class PlanningExtEntity extends PlanningEntity{

    /** The desc business perspective. */
    private	String	descBusinessPerspective;

    /** The manager name. */
    private	String	managerName;

    /** The group raising rfc. */
    private	String	groupRaisingRfc;

    /** The implemented bau timelines. */
    private	String	implementedBauTimelines;

    /** The standard change cycle. */
    private	String	standardChangeCycle;

    /** The department owner process. */
    private	String	departmentOwnerProcess;

    /** The clash request. */
    private	String	clashRequest;

    /** The risk unplanned change. */
    private	String	riskUnplannedChange;

    /** The additional business testing. */
    private	String	additionalBusinessTesting;

    /** The test plan contact person. */
    private	String	testPlanContactPerson;

    /**
     * Instantiates a new planning ext entity.
     */
    public PlanningExtEntity() {
	// TODO Auto-generated constructor stub
    }

    /**
     * Gets the desc business perspective.
     *
     * @return the desc business perspective
     */
    public String getDescBusinessPerspective() {
	return descBusinessPerspective;
    }

    /**
     * Sets the desc business perspective.
     *
     * @param descBusinessPerspective the new desc business perspective
     */
    public void setDescBusinessPerspective(String descBusinessPerspective) {
	this.descBusinessPerspective = descBusinessPerspective;
    }

    /**
     * Gets the manager name.
     *
     * @return the manager name
     */
    public String getManagerName() {
	return managerName;
    }

    /**
     * Sets the manager name.
     *
     * @param managerName the new manager name
     */
    public void setManagerName(String managerName) {
	this.managerName = managerName;
    }

    /**
     * Gets the group raising rfc.
     *
     * @return the group raising rfc
     */
    public String getGroupRaisingRfc() {
	return groupRaisingRfc;
    }

    /**
     * Sets the group raising rfc.
     *
     * @param groupRaisingRfc the new group raising rfc
     */
    public void setGroupRaisingRfc(String groupRaisingRfc) {
	this.groupRaisingRfc = groupRaisingRfc;
    }

    /**
     * Gets the implemented bau timelines.
     *
     * @return the implemented bau timelines
     */
    public String getImplementedBauTimelines() {
	return implementedBauTimelines;
    }

    /**
     * Sets the implemented bau timelines.
     *
     * @param implementedBauTimelines the new implemented bau timelines
     */
    public void setImplementedBauTimelines(String implementedBauTimelines) {
	this.implementedBauTimelines = implementedBauTimelines;
    }

    /**
     * Gets the standard change cycle.
     *
     * @return the standard change cycle
     */
    public String getStandardChangeCycle() {
	return standardChangeCycle;
    }

    /**
     * Sets the standard change cycle.
     *
     * @param standardChangeCycle the new standard change cycle
     */
    public void setStandardChangeCycle(String standardChangeCycle) {
	this.standardChangeCycle = standardChangeCycle;
    }

    /**
     * Gets the department owner process.
     *
     * @return the department owner process
     */
    public String getDepartmentOwnerProcess() {
	return departmentOwnerProcess;
    }

    /**
     * Sets the department owner process.
     *
     * @param departmentOwnerProcess the new department owner process
     */
    public void setDepartmentOwnerProcess(String departmentOwnerProcess) {
	this.departmentOwnerProcess = departmentOwnerProcess;
    }

    /**
     * Gets the clash request.
     *
     * @return the clash request
     */
    public String getClashRequest() {
	return clashRequest;
    }

    /**
     * Sets the clash request.
     *
     * @param clashRequest the new clash request
     */
    public void setClashRequest(String clashRequest) {
	this.clashRequest = clashRequest;
    }

    /**
     * Gets the risk unplanned change.
     *
     * @return the risk unplanned change
     */
    public String getRiskUnplannedChange() {
	return riskUnplannedChange;
    }

    /**
     * Sets the risk unplanned change.
     *
     * @param riskUnplannedChange the new risk unplanned change
     */
    public void setRiskUnplannedChange(String riskUnplannedChange) {
	this.riskUnplannedChange = riskUnplannedChange;
    }

    /**
     * Gets the additional business testing.
     *
     * @return the additional business testing
     */
    public String getAdditionalBusinessTesting() {
	return additionalBusinessTesting;
    }

    /**
     * Sets the additional business testing.
     *
     * @param additionalBusinessTesting the new additional business testing
     */
    public void setAdditionalBusinessTesting(String additionalBusinessTesting) {
	this.additionalBusinessTesting = additionalBusinessTesting;
    }

    /**
     * Gets the test plan contact person.
     *
     * @return the test plan contact person
     */
    public String getTestPlanContactPerson() {
	return testPlanContactPerson;
    }

    /**
     * Sets the test plan contact person.
     *
     * @param testPlanContactPerson the new test plan contact person
     */
    public void setTestPlanContactPerson(String testPlanContactPerson) {
	this.testPlanContactPerson = testPlanContactPerson;
    }

}
