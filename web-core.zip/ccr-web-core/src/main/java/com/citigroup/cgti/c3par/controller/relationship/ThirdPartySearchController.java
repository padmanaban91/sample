package com.citigroup.cgti.c3par.controller.relationship;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.model.ThirdPartyEntity;
import com.citigroup.cgti.c3par.relationship.domain.ThirdParty;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartySearchProcess;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;

@Controller
public class ThirdPartySearchController {

	private static Logger log = Logger.getLogger(ThirdPartySearchController.class);

	@RequestMapping(value = "/loadThirdPartyPopUp.act", method = {RequestMethod.POST, RequestMethod.GET })
	public String loadThirdPartyPopUp(ModelMap model,@ModelAttribute("thirdPartySearchProcess") ThirdPartySearchProcess thirdPartySearchProcess,HttpServletRequest request) {

		String assignTo = request.getParameter("ASSIGN_TO");

		if ( assignTo != null && !assignTo.isEmpty()) {
			request.getSession().setAttribute("ASSIGN_TO",	assignTo);
		}	
				
		thirdPartySearchProcess = new ThirdPartySearchProcess();
		model.addAttribute("thirdPartySearchProcess", thirdPartySearchProcess);

		return "pages/relationship/ThirdPartySearchPopUp";
	}

	@RequestMapping(value = "/searchThirPartyName.act", method = { RequestMethod.POST, RequestMethod.GET })
	public String searchThirParty(ModelMap model,@ModelAttribute("thirdPartySearchProcess") ThirdPartySearchProcess thirdPartySearchProcess
									,BindingResult result,HttpServletRequest request) {

		String valueToLook = null;
		int valueToLook1 = 0;
		List<ThirdPartyEntity> thirdPartyEntityList;
		List<ThirdParty> allthirdPartyList = new ArrayList<ThirdParty>();
		List<ThirdParty> thirdPartyList = new ArrayList<ThirdParty>();
		
		if(thirdPartySearchProcess.getThirdPartyNameSearch() != null && !thirdPartySearchProcess.getThirdPartyNameSearch().isEmpty()){
			log.debug("ThirdPartySearchController :: searchThirParty :: thirdPartySearchProcess.getThirdPartyNameSearch() - "+thirdPartySearchProcess.getThirdPartyNameSearch());
			valueToLook = thirdPartySearchProcess.getThirdPartyNameSearch();
		}else if(thirdPartySearchProcess.getCaspIdFilter() != null &&  !thirdPartySearchProcess.getCaspIdFilter().isEmpty()){
			log.debug("ThirdPartySearchController :: searchThirParty :: thirdPartySearchProcess.getCaspIdFilter() - "+thirdPartySearchProcess.getCaspIdFilter());
			valueToLook1 = Integer.valueOf(thirdPartySearchProcess.getCaspIdFilter());			
		}
		
		log.debug("ThirdPartySearchController :: searchThirParty :: valueToLook - "+valueToLook+" :: valueToLook1 - "+valueToLook1);
		
		if(valueToLook != null || valueToLook1 != 0 ) {
			try {
				SOADataComponent soaDataComponent = new SOADataComponent();
				ProfileInfoFactory profileInfoFactory = (ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");
				
				if(valueToLook != null && !valueToLook.isEmpty()){
					log.debug("ThirdPartySearchController :: searchThirParty :: ThirdPartyNameSearch search ");
					thirdPartyEntityList = profileInfoFactory.getCASPService().getAllSupplierDetails(valueToLook, request.getHeader("SM_USER"));
				}else{
					log.debug("ThirdPartySearchController :: searchThirParty :: CaspIdFilter search :: RemoteUser - "+request.getHeader("SM_USER"));
					thirdPartyEntityList = profileInfoFactory.getCASPService().getPartnerDetails(request.getHeader("SM_USER"),valueToLook1);
				}
				long count = 0;
				Iterator<ThirdPartyEntity> it = thirdPartyEntityList.iterator();
				while(it.hasNext()) {
				    ThirdPartyEntity entity = (ThirdPartyEntity) it.next();
		
				    ThirdParty info = new ThirdParty();
				    info.setId(count);
				   
				    info.setName(entity.getName());
				    info.setCaspId(entity.getCaspId());
				    info.setParentName(entity.getParentName());
				    info.setParentId(entity.getParentId());
		
				    allthirdPartyList.add(info);
				    count++;
				}
			}catch(Exception ex) {
				if (ex instanceof RemoteException) {
				    String messageFormat = "<x20:Description   xmlns:x20=\"http://service.citigroup.com/provider/domainservices/fault/x2005/\">";
				    String localizedMessage = ex.getLocalizedMessage();
				    int index = localizedMessage.indexOf(messageFormat);

				    if(index!=-1){
						String message = localizedMessage.substring(index+messageFormat.length(),localizedMessage.indexOf("</x20:Description>"));
						//String message = ex.getLocalizedMessage().substring(ex.getLocalizedMessage().indexOf("<Description>")+13,ex.getLocalizedMessage().indexOf("</Description>"));
						result.addError(new ObjectError("thirdPartyName", message));
				    } else if(ex.getLocalizedMessage().indexOf("Failed to send request")!=-1) {
				    	result.addError(new ObjectError("thirdPartyName", "The service is unavailable"));
				    } else {
				    	result.addError(new ObjectError("thirdPartyName", "No result found."));
				    }
				}
				log.error(ex);
			}
			
			String pageType = thirdPartySearchProcess.getPageType();
			//Setting page number
			thirdPartySearchProcess = setPaginationValues(thirdPartySearchProcess,0,10,0,pageType);
			thirdPartySearchProcess.setRowCount(allthirdPartyList.size());
			for(int index = thirdPartySearchProcess.getOffset();index < thirdPartySearchProcess.getLimit();index++){
				if(allthirdPartyList.size() > index){
					thirdPartyList.add(allthirdPartyList.get(index));
				}
			}
			//setting the pagination values based on doNotSendEmailList
			thirdPartySearchProcess.setTotalPages(getTotalPages(thirdPartySearchProcess.getRowCount(), thirdPartySearchProcess.getLimit()));		

			request.getSession().setAttribute("THIRD_PARTY_LIST", thirdPartyList);
			request.getSession().setAttribute("ALL_THIRD_PARTY_LIST", allthirdPartyList);
			thirdPartySearchProcess.setAllThirdPartyList(thirdPartyList);
			model.addAttribute("thirdPartySearchProcess",thirdPartySearchProcess);
		}
		
		return "pages/relationship/ThirdPartySearchPopUp";
	}

	@RequestMapping(value = "/searchThirPartyPagination.act", method = { RequestMethod.POST, RequestMethod.GET })
	public String searchThirPartyPagination(ModelMap model,@ModelAttribute("thirdPartySearchProcess") ThirdPartySearchProcess thirdPartySearchProcess
									,BindingResult result,HttpServletRequest request) {

		List<ThirdParty> allthirdPartyList = (List<ThirdParty>)request.getSession().getAttribute("ALL_THIRD_PARTY_LIST");
		List<ThirdParty> thirdPartyList = new ArrayList<ThirdParty>();
		
		String pageType = thirdPartySearchProcess.getPageType();
		//Setting page number
		thirdPartySearchProcess = setPaginationValues(thirdPartySearchProcess,0,10,0,pageType);
		
		for(int index = thirdPartySearchProcess.getOffset();index < (thirdPartySearchProcess.getPageNo() * thirdPartySearchProcess.getLimit());index++){
			if(allthirdPartyList.size() > index){
				thirdPartyList.add(allthirdPartyList.get(index));
			}
		}
		//setting the pagination values based on doNotSendEmailList
		thirdPartySearchProcess.setTotalPages(getTotalPages(thirdPartySearchProcess.getRowCount(), thirdPartySearchProcess.getLimit()));		

		request.getSession().setAttribute("THIRD_PARTY_LIST", thirdPartyList);
		thirdPartySearchProcess.setAllThirdPartyList(thirdPartyList);
		model.addAttribute("thirdPartySearchProcess",thirdPartySearchProcess);

		return "pages/relationship/ThirdPartySearchPopUp";
	}
	
	@RequestMapping(value = "/submitThirdPartySeleted.act", method = {RequestMethod.POST, RequestMethod.GET })
	public String submitThirdPartySeleted(ModelMap model,@ModelAttribute("thirdPartySearchProcess") ThirdPartySearchProcess thirdPartySearchProcess
													,BindingResult result,HttpServletRequest request) {
		int valueToLook = 0;		
		List<ThirdParty> thirdPartyDetailList = new ArrayList<ThirdParty>();
		List<ThirdParty> thirdPartyList = (List<ThirdParty>)request.getSession().getAttribute("THIRD_PARTY_LIST");
		ThirdParty tpInfo = null;
		//get CASP id
		if(thirdPartySearchProcess.getSelectedId() != null  &&  !thirdPartySearchProcess.getSelectedId().isEmpty() ){
			log.debug("ThirdPartySearchController :: submitThirdPartySeleted :: getSelectedId - "+thirdPartySearchProcess.getSelectedId());
			
			int id = Integer.parseInt(thirdPartySearchProcess.getSelectedId());
			tpInfo = thirdPartyList.get(id);
			valueToLook = Integer.valueOf(tpInfo.getCaspId().toString());
		}

		log.debug("ThirdPartySearchController :: submitThirdPartySeleted :: valueToLook - "+valueToLook);
		
		if(valueToLook != 0){
			try {
	
			    SOADataComponent soaDataComponent = new SOADataComponent();
			    ProfileInfoFactory profileInfoFactory = (ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");
			    List<ThirdParty> thirdPartyEntityList = profileInfoFactory.getCASPService().getPartnerDetails(valueToLook, request.getHeader("SM_USER"));
	
			    Iterator it = thirdPartyEntityList.iterator();
			    while(it.hasNext()) {
					ThirdPartyEntity entity = (ThirdPartyEntity) it.next();
		
					ThirdParty info = new ThirdParty();
	
					info.setDetailId(entity.getDetailId());
					info.setRegion(entity.getRegion());
					info.setCountry(entity.getCountry());
					info.setMainCategory(entity.getMainCategory());
					info.setSubcategory(entity.getSubCategory());
					
					info.setCaspId(tpInfo.getCaspId());					
					info.setName(tpInfo.getName());
					info.setParentId(tpInfo.getParentId());
					info.setParentName(tpInfo.getParentName());
					info.setSource("CASP");

					thirdPartyDetailList.add(info);
			    }
			}catch(Exception ex) {
				if (ex instanceof RemoteException) {
				    String messageFormat = "<x20:Description   xmlns:x20=\"http://service.citigroup.com/provider/domainservices/fault/x2005/\">";
				    String localizedMessage = ex.getLocalizedMessage();
				    int index = localizedMessage.indexOf(messageFormat);
	
				    if(index!=-1){
						String message = localizedMessage.substring(index+messageFormat.length(),localizedMessage.indexOf("</x20:Description>"));
						//String message = ex.getLocalizedMessage().substring(ex.getLocalizedMessage().indexOf("<Description>")+13,ex.getLocalizedMessage().indexOf("</Description>"));
						result.addError(new ObjectError("thirdPartyName", message));
				    } else if(ex.getLocalizedMessage().indexOf("Failed to send request")!=-1) {
				    	result.addError(new ObjectError("thirdPartyName", "The service is unavailable"));
				    } else {
				    	result.addError(new ObjectError("thirdPartyName", "No result found."));
				    }
				}
				log.error(ex);
			}
		}
		request.getSession().setAttribute("THIRD_PARTY_DETAIL_LIST",thirdPartyDetailList);
		thirdPartySearchProcess.setAllThirdPartyList(thirdPartyDetailList);
		model.addAttribute("thirdPartySearchProcess",thirdPartySearchProcess);
		
		return "pages/relationship/ThirdPartySearchDetails";
	}

	@RequestMapping(value = "/submitThirdParty.act", method = {RequestMethod.POST, RequestMethod.GET })
	public String submitThirdParty(ModelMap model,@ModelAttribute("thirdPartySearchProcess") ThirdPartySearchProcess thirdPartySearchProcess
										,BindingResult result,HttpServletRequest request) {
		
		String assignTo = (String) request.getSession().getAttribute("ASSIGN_TO");
		List<ThirdParty> sessionThirdPartyList = (List<ThirdParty>) request.getSession().getAttribute("THIRD_PARTY_DETAIL_LIST");
		Long thirdPartyId = 0L;
		
		String indexid = request.getParameter("siteTpId");
		ThirdParty thirdparty = null;
		if(indexid != null && !indexid.isEmpty()){
			thirdparty = sessionThirdPartyList.get(Integer.parseInt(indexid));
		}

		log.debug("ThirdPartySearchController :: submitThirdParty :: indexid - "+indexid);
		
		List<ThirdParty> newThirdPartyList = null;
		if(thirdparty != null){
			thirdPartySearchProcess.setCaspIdFilter(thirdparty.getCaspId().toString());
			thirdPartySearchProcess.setParentIdFilter(thirdparty.getParentId());
			thirdPartySearchProcess.setDetailIdFilter(thirdparty.getDetailId());
			newThirdPartyList = thirdPartySearchProcess.loadThirdPartyProcessList(thirdPartySearchProcess);
		}
		
		if(newThirdPartyList == null || newThirdPartyList.isEmpty() || newThirdPartyList.size() == 0){

			log.debug("ThirdPartySearchController :: submitThirdPartySeletedItems :: thirdPartyList - empty ");
			try {				    
			    if(thirdparty != null){
				    Long id = thirdPartySearchProcess.saveThirdPartyDetails(thirdparty);
				    
					log.debug("ThirdPartySearchController :: submitThirdPartySeletedItems :: thirdParty id - "+id);
					
				    thirdparty.setId(id);
				    newThirdPartyList = new ArrayList<ThirdParty>();
				    newThirdPartyList.add(thirdparty);
			    }
			}catch(Exception ex) {
				/*if (ex instanceof RemoteException) {
				    String messageFormat = "<x20:Description   xmlns:x20=\"http://service.citigroup.com/provider/domainservices/fault/x2005/\">";
				    String localizedMessage = ex.getLocalizedMessage();
				    int index = localizedMessage.indexOf(messageFormat);
	
				    if(index!=-1){
						String message = localizedMessage.substring(index+messageFormat.length(),localizedMessage.indexOf("</x20:Description>"));
						//String message = ex.getLocalizedMessage().substring(ex.getLocalizedMessage().indexOf("<Description>")+13,ex.getLocalizedMessage().indexOf("</Description>"));
						result.addError(new ObjectError("thirdPartyName", message));
				    } else if(ex.getLocalizedMessage().indexOf("Failed to send request")!=-1) {
				    	result.addError(new ObjectError("thirdPartyName", "The service is unavailable"));
				    } else {
				    	result.addError(new ObjectError("thirdPartyName", "No result found."));
				    }
				}*/
				log.error(ex);
			}			
		}
		if(newThirdPartyList != null && !newThirdPartyList.isEmpty()){
			if (assignTo.equalsIgnoreCase("requester")) {
				log.debug("ThirdPartySearchController :: submitThirdParty :: newThirdPartyList - "+newThirdPartyList.size());
				
				for (ThirdParty thirdPartyObj : newThirdPartyList) {
					thirdPartySearchProcess.setName(thirdPartyObj.getName());
					thirdPartySearchProcess.setParentName(thirdPartyObj.getParentName());
					thirdPartySearchProcess.setRegion(thirdPartyObj.getRegion());
					thirdPartySearchProcess.setCountry(thirdPartyObj.getCountry());
					thirdPartySearchProcess.setMainCategory(thirdPartyObj.getMainCategory());
					thirdPartySearchProcess.setSubCategory(thirdPartyObj.getSubcategory());
					thirdPartySearchProcess.setCaspId(thirdPartyObj.getCaspId());
					thirdPartySearchProcess.setDetailId(thirdPartyObj.getDetailId());
					thirdPartySearchProcess.setParentId(thirdPartyObj.getParentId());
					//thirdPartySearchProcess.setDescription(checkedThirdPartyid);
					thirdPartyId = thirdPartyObj.getId();
				}
				thirdPartySearchProcess.setAllThirdPartyList(newThirdPartyList);
				request.getSession().setAttribute("THIRD_PARTY_ID",thirdPartyId);
				request.getSession().removeAttribute("TARGET_THIRD_PARTY_ID");
	
			} else {
				for (ThirdParty thirdPartyObj : newThirdPartyList) {
					thirdPartySearchProcess.setTargetThirdPartyName(thirdPartyObj.getName());
					thirdPartySearchProcess.setTargetThirdPartyParentName(thirdPartyObj.getParentName());
					thirdPartySearchProcess.setTargetThirdPartyRegion(thirdPartyObj.getRegion());
					thirdPartySearchProcess.setTargetThirdPartyCountry(thirdPartyObj.getCountry());
					thirdPartySearchProcess.setTargetThirdPartyMainCategory(thirdPartyObj.getMainCategory());
					thirdPartySearchProcess.setTargetThirdPartySubCategory(thirdPartyObj.getSubcategory());
					thirdPartySearchProcess.setTargetCaspId(thirdPartyObj.getCaspId());
					thirdPartySearchProcess.setTargetDetailId(thirdPartyObj.getDetailId());
					thirdPartySearchProcess.setTargetParentId(thirdPartyObj.getParentId());
					//thirdPartySearchProcess.setDescription(checkedThirdPartyid);
					thirdPartyId = thirdPartyObj.getId();
				}
				thirdPartySearchProcess.setAllThirdPartyList(newThirdPartyList);
				request.getSession().setAttribute("TARGET_THIRD_PARTY_ID",thirdPartyId);
				request.getSession().removeAttribute("THIRD_PARTY_ID");
	
			}
		}
		request.getSession().setAttribute("thirdPartySearchProcess",thirdPartySearchProcess);
		model.addAttribute("thirdPartySearchProcess", thirdPartySearchProcess);

		return "pages/dashboard/ClosePopupWindowResponse";
	}

	private ThirdPartySearchProcess setPaginationValues(ThirdPartySearchProcess thirdPartySearchProcess, int curOffSet, int limit, int pageNo, String pageType){
		if(thirdPartySearchProcess != null){
			curOffSet = thirdPartySearchProcess.getOffset();		
			limit = thirdPartySearchProcess.getLimit();		
			pageNo = thirdPartySearchProcess.getPageNo();
		}
		//thirdPartySearchProcess = new ThirdPartySearchProcess();
		thirdPartySearchProcess.setLimit(limit);
		thirdPartySearchProcess.setPaginationRequired(true);
		if (pageType != null && "N".equalsIgnoreCase(pageType)) {
			thirdPartySearchProcess.setOffset(curOffSet+thirdPartySearchProcess.getLimit());
			thirdPartySearchProcess.setPageNo(pageNo+1);
		} else if (pageType != null && "P".equalsIgnoreCase(pageType)) {
			thirdPartySearchProcess.setOffset(curOffSet-thirdPartySearchProcess.getLimit());
			thirdPartySearchProcess.setPageNo(pageNo-1);
		} else if (pageType != null && "X".equalsIgnoreCase(pageType)) {
			thirdPartySearchProcess.setOffset(limit * (pageNo-1));
			thirdPartySearchProcess.setPageNo(pageNo);
		} else if (pageType != null && "L".equalsIgnoreCase(pageType)) {
			thirdPartySearchProcess.setOffset(0);
			thirdPartySearchProcess.setPageNo(1);
		}else {
			thirdPartySearchProcess.setOffset(0);
			thirdPartySearchProcess.setPageNo(1);
			thirdPartySearchProcess.setLimit(10);
		}

		log.debug("ThirdPartySearchController :: setPaginationValues :: Offset - "+thirdPartySearchProcess.getOffset()
				+" :: PageNo - "+thirdPartySearchProcess.getPageNo()+" :: Limit - "+thirdPartySearchProcess.getLimit());
		
		return thirdPartySearchProcess;
	}

	private int getTotalPages(int rowCount, int limit){		
		int totalPages = 0;		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}	
		
		return totalPages;
	}
}
