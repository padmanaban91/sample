package com.citigroup.cgti.c3par.oneapproval;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

/**
 * 
 * @author ne36745
 *
 */
public abstract class OneApprovalAction {
	/**
	 * 
	 */
	private Logger log = Logger.getLogger(OneApprovalAction.class);
	
	private static final String DESIGNENGINEER = "DESIGN ENGINEER";
	private static final String PROJECTCOORDINATOR = "PROJECT COORDINATOR";
	private static final String C3PARSYSTEMADMIN = "C3PARSYSTEMADMIN";
	private static final String BISO = "BISO";
	
	private JdbcTemplate jdbcTemplate;
	
	/**
	 * @return the jdbcTemplate
	 */
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	/**
	 * @param jdbcTemplate the jdbcTemplate to set
	 */
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	/**
	 * 
	 * @param message
	 * The method will be overriden by sub classes to process the incoming messages.
	 */
	public abstract void process(OneApprovalMessageLog message);
	
	
	/**
	 * 
	 */
	public String getInstanceId(Long tiRequestId) {
		String instanceId = null;			
		SqlRowSet rs = getJdbcTemplate().queryForRowSet("select bpm_instance_id from ti_activity_trail "+
				" where bpm_instance_id is not null and ti_request_id = "+tiRequestId+" and activity_status = 'SCHEDULED'");
		if (rs.next()) {
			instanceId = rs.getString(1);
		}
		return instanceId;
		
	}
	protected Map<String,String> getAcvInstanceId(Long processId,Long tiRequestId,String ssoId){
        String instanceId=null;
        String role = null;
        String activityId = null;
        StringBuilder taskIdForACVSQL = null;
        Map<String,String> taskIdDetails = null;
        try{
        	log.info("OneApprovalAction :: getAcvInstanceId : processId :"+processId);
			log.info("OneApprovalAction :: getAcvInstanceId : tiRequestId :"+tiRequestId);
			log.info("OneApprovalAction :: getAcvInstanceId : ssoId :"+ssoId);
        	taskIdForACVSQL = new StringBuilder();
        	taskIdDetails = new HashMap<String,String>();
        	taskIdForACVSQL.append(" SELECT A.TASK_ID,A.TASK_ROLE,TI_AUDITTRAIL_ID,DECODE(A.TASK_ROLE,'C3PARSYSTEMADMIN','1','Design_Engineer','2','Project_Coordinator','3',  ");
        	taskIdForACVSQL.append(" 'Business User','4','BISO','5','1') TASK_ROLE_PRIORITY FROM CCR_TASK_REF A,  ");
        	taskIdForACVSQL.append(" SECURITY_ROLE B, C3PAR_USER_ROLE_XREF C, C3PAR_USERS D WHERE A.TASK_ROLE = B.NAME  ");
        	taskIdForACVSQL.append(" AND A.TASK_ROLE IN ('C3PARSYSTEMADMIN','Design_Engineer','Project_Coordinator','Business User','BISO')   ");
        	taskIdForACVSQL.append(" AND B.ID = C.ROLE_ID AND C.USER_ID = D.ID AND UPPER(D.SSO_ID) = UPPER(?)  ");
        	taskIdForACVSQL.append(" AND A.TI_REQUEST_ID=? AND A.CONNECTION_ID=? AND CON_TYPE='ACV'  ");
        	taskIdForACVSQL.append(" ORDER BY TASK_ROLE_PRIORITY  ");
        	log.info("MailAction :: getAcvInstanceId : taskIdForACVSQL :"+taskIdForACVSQL.toString());
			SqlRowSet rs = jdbcTemplate.queryForRowSet(taskIdForACVSQL.toString(), new Object[]{ssoId,tiRequestId,processId});
            if (rs.next()) {
                instanceId = rs.getString(1);
                role = rs.getString(2);
                activityId = rs.getString(3);
                taskIdDetails.put("instanceId", instanceId);
				taskIdDetails.put("role", role);
				taskIdDetails.put("activityId", activityId);
            }
            log.info("OneApprovalAction :: getAcvInstanceId : instanceId :"+instanceId);
            log.info("OneApprovalAction :: getAcvInstanceId : role :"+role);
            log.info("OneApprovalAction :: getAcvInstanceId : activityId :"+activityId);
        }catch(Exception e){
            log.error("Error has occurred in  getAcvInstanceId ::"+e.toString());
        }
        return taskIdDetails;
    }
	
	protected long getAcvActivityTrailId(String taskId){
        long activityTrailId=0;
        try{
            SqlRowSet rs = getJdbcTemplate().queryForRowSet("SELECT TI_AUDITTRAIL_ID FROM CCR_TASK_REF WHERE TASK_ID='"+taskId+"' ");
            if (rs.next()) {
            	activityTrailId = rs.getLong(1);
            }
            log.info(" activityTrailId :: "+activityTrailId);
        }catch(Exception e){
            log.error("Error has occurred in  getAcvActivityTrailId ::"+e.toString());
        }
        return activityTrailId;
       
    }
	
	protected String toCheckActivity(Long processId,Long tiRequestId,String ssoId){
        log.info("processId "+processId+" tiRequestId :: "+tiRequestId+" ssoId "+ssoId);
        try{
            SqlRowSet rs = getJdbcTemplate().queryForRowSet("select TASK_ID from CCR_TASK_REF WHERE ti_request_id="+tiRequestId+" and ACTIVITY_STATUS ='Ready' and PHASE='ACV'");
            if (rs.next()) {
               return "LOCK";
            }
            rs = getJdbcTemplate().queryForRowSet("select TASK_PARTICIPANT from CCR_TASK_REF WHERE ti_request_id="+tiRequestId+" and ACTIVITY_STATUS ='Reserved' and PHASE='ACV'");
            if(rs.next()){
                log.info(" rs.getString(1) "+rs.getString(1));
                if(ssoId.equalsIgnoreCase(rs.getString(1))){
                    return "COMPLETE"; 
                }else{
                    return "UNLOCK"; 
                }
            }
        }catch(Exception e){
            log.error("Error has occurred in  getInstanceId ::"+e.toString());
        }
        return null;
       
    }
	
	/**
	 * 
	 * @param userId
	 * @return
	 */
	protected String getSSOID(String GEId) {
		String ssoId = null;
		SqlRowSet rs = getJdbcTemplate().queryForRowSet("SELECT SSO_ID FROM CITI_CONTACT WHERE GEID = ?", new Object[] {GEId});
		
		if (rs.next()) {
			ssoId = rs.getString(1);
		}
		return ssoId;
	}
	
	/**
	 * 
	 * @param email
	 * @return
	 */
	protected Long getUserID(String ssoId) {
		Long userId = null;
		SqlRowSet rs = getJdbcTemplate().queryForRowSet("SELECT MAX(ID) FROM C3PAR_USERS WHERE SSO_ID IS NOT NULL AND UPPER(SSO_ID) = ?",  new Object[] {ssoId.toUpperCase()});
		
		if (rs.next()) {
			userId = rs.getLong(1);
		}
		return userId;
	}
	
	/**
	 * 
	 * @param comments
	 * @param tiRequestId
	 * @param roleName
	 * @param userId
	 * @return
	 */
	protected boolean addComments(String comments, Long tiRequestId, String roleName, Long userId, String approvalSystem) {
		
		final StringBuilder insertSql =  new StringBuilder();
		insertSql.append("INSERT INTO C3PAR.TI_REQUEST_COMMENTS(ID,TI_REQUEST_ID,COMMENT_TYPE,ROLE_ID,COMMENTS,USER_ID,COMMENT_DATE) " );
		insertSql.append(" VALUES(C3PAR.SEQ_TI_REQUEST_COMMENTS.NEXTVAL,?,?,(SELECT MAX(ID) FROM C3PAR.ROLE WHERE UPPER(NAME) LIKE UPPER(?)),?,?,SYSDATE) ");
		
		getJdbcTemplate().update(insertSql.toString(), new Object[]{tiRequestId, "A", roleName, comments, userId});
		
		final StringBuilder updateSql =  new StringBuilder();
		updateSql.append("update ti_activity_trail set approval_system = ? where id in (select id from ti_activity_trail "+
					" where bpm_instance_id is not null and ti_request_id = ? and activity_status = 'SCHEDULED')");
		
		getJdbcTemplate().update(updateSql.toString(), new Object[]{approvalSystem,tiRequestId});
		return true;
	}
	
	/**
	 * 
	 * @param ssoId
	 * @return
	 */
	protected String getRolesForACVApproval(String ssoId) {
		String role = null;
		final StringBuilder query = new StringBuilder();
		query.append(" SELECT SR.NAME FROM C3PAR_USER_ROLE_XREF CURX, security_role SR, C3PAR_USERS CU WHERE CURX.USER_ID=CU.ID AND CURX.ROLE_ID=SR.ID AND "); 
		query.append(" UPPER(CU.SSO_ID) IN(?) AND SR.NAME IN (?,?,?,?) " );
		
		SqlRowSet rs = getJdbcTemplate().queryForRowSet( query.toString(), new Object[] {ssoId,PROJECTCOORDINATOR,DESIGNENGINEER,C3PARSYSTEMADMIN,BISO} );
		
		if (rs.next()) {
			role = rs.getString(1);
		}
		return role;
	}
	
	protected boolean updateVerificationFlag(Long tiRequestId, String verificationFlag) {
		final String insertSql = "UPDATE C3PAR.TI_REQUEST SET ANNUAL_VERIFICATION_FLAG = ? WHERE ID = ?";
	 
		getJdbcTemplate().update(insertSql, new Object[]{verificationFlag, tiRequestId});
		return true;
	}
	
	public Long saveMail(String referenceNo,String ssoID,String mailSub){
		Long tiMailID=0L;
		Long id=0L;
		
		SqlRowSet rs1 = getJdbcTemplate().queryForRowSet("SELECT C3PAR.SEQ_TI_MAIL_AUDIT_RESPONSE.NEXTVAL FROM DUAL");
		if (rs1.next()) {
			id = rs1.getLong(1);
		}
		log.debug("Ti_mail_audit_response id :"+id);
		
		final String selIdQuery = "SELECT ID FROM TI_MAIL_AUDIT where EMAIL_REFERENCE_NO = ? ";
		SqlRowSet rs = getJdbcTemplate().queryForRowSet(selIdQuery, new Object[]{referenceNo});

		if (rs.next()) {
			tiMailID = rs.getLong(1);
		}
		log.debug("Ti mail audit ID :"+tiMailID);
		
		String insertMailSql = "INSERT INTO C3PAR.TI_MAIL_AUDIT_RESPONSE("
    		+ " ID,TI_MAIL_AUDIT_ID,FROM_USER_ID,MAIL_SUBJECT,ACTION_TAKEN,REMARKS,CREATED_DATE,UPDATED_DATE)"
    		+ " VALUES(?,?,?,?,?,?"
    		+ ",sysdate,sysdate)";
		
		getJdbcTemplate().update(insertMailSql,new Object[]{id,tiMailID,ssoID,mailSub,"",""});		
		return id;
	}
	
	public void update(Long mailID,String action,String remarks){
		
		log.info("Inside OnaApprovalAction Update method starts here...");
		
		String sql = "UPDATE C3PAR.TI_MAIL_AUDIT_RESPONSE set ACTION_TAKEN =?, REMARKS = ? WHERE ID =?";
		
		getJdbcTemplate().update(sql,new Object[]{action,remarks,mailID});
		log.debug("Query for ti_mail_audit_response-> "+sql+"   - Parameters - action-> "+action+", remarks-> "+remarks+", mailID-> "+mailID);
		
		log.info("Inside OnaApprovalAction Update method ends here...");
	}
	
	// parse the exception message and return only the message content
	public String getExceptionMessage(Exception exception){
		if(exception != null){
			String message = exception.getMessage();
			if(!message.isEmpty() && message.length() > 200){
				return message.substring(0, 200);
			}else if(!message.isEmpty()){
				return message;
			}
		}
		return "Not able to perform the action due to exception";
	}
}
