package com.citigroup.cgti.c3par.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.admin.domain.ProxyDeviceNameProcess;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.ProxyDeviceName;
import com.citigroup.cgti.c3par.common.domain.ProxyLocation;

/*
 * @ne36745
 */
@Controller
public class ProxyDeviceNameController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(ProxyDeviceNameController.class);
	
	/*
	 * The method to load proxy device names
	 */
	@RequestMapping(value = "/loadProxyDeviceNames.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String loadProxyDeviceNames(ModelMap model){
		log.info("ProxyDeviceNameController : loadProxyDeviceNames starts here..");
		ProxyDeviceNameProcess proxyDeviceNameProcess = new ProxyDeviceNameProcess();
		List<ProxyDeviceName> list = proxyDeviceNameProcess.getProxyDeviceNames();
		List<ProxyLocation> locations = proxyDeviceNameProcess.getProxyLocations();
		proxyDeviceNameProcess.setProxyDeviceNameList(list);
		proxyDeviceNameProcess.setProxyLocationList(locations);
		proxyDeviceNameProcess.setCountries(proxyDeviceNameProcess.getAllCountries());
		model.addAttribute("proxyDeviceNameProcess",proxyDeviceNameProcess);
		log.info("ProxyDeviceNameController : loadProxyDeviceNames ends here..");
		return "c3par.admin.proxydevice";
	}
	
	
	/*
	 * The method to add new resource type
	 */
	@RequestMapping(value = "/addProxyDeviceName.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String addProxyDeviceName(ModelMap model,@ModelAttribute("proxyDeviceNameProcess") ProxyDeviceNameProcess proxyDeviceNameProcess, HttpServletRequest request, BindingResult result){
		log.info("ProxyDeviceNameController : addProxyDeviceName starts here..");
	//	String user = request.getRemoteUser();
		String user = request.getHeader("SM_USER");
		List<GenericLookup> countriesList = proxyDeviceNameProcess.getAllCountries();
		boolean validationFailed =  false;
		
		if(proxyDeviceNameProcess.getProxyDeviceName() == null || proxyDeviceNameProcess.getProxyDeviceName().getPolicyName() == null
				|| proxyDeviceNameProcess.getProxyDeviceName().getPolicyName().isEmpty()){
			result.addError(new ObjectError("manageResourceType.name","Policy is missing"));
			validationFailed = true;
		}
		if(proxyDeviceNameProcess.getProxyDeviceName() == null || proxyDeviceNameProcess.getProxyDeviceName().getDeviceName() == null
				|| proxyDeviceNameProcess.getProxyDeviceName().getDeviceName().isEmpty()){
			result.addError(new ObjectError("manageResourceType.name","Device is missing"));
			validationFailed = true;
		}
		if(proxyDeviceNameProcess.getProxyDeviceName() == null || proxyDeviceNameProcess.getProxyDeviceName().getCountryCode() == null
				|| proxyDeviceNameProcess.getProxyDeviceName().getCountryCode().isEmpty()){
			result.addError(new ObjectError("manageResourceType.name","Country is missing"));
			validationFailed = true;
		}
		
		if (!validationFailed) {
			for(GenericLookup countryObj : countriesList){
				if(proxyDeviceNameProcess.getProxyDeviceName().getCountryCode().equals(countryObj.getValue2())){
					log.debug("country id."+countryObj.getValue1());
					proxyDeviceNameProcess.getProxyDeviceName().setCountry(countryObj.getValue1());
				}
			}
			log.debug("Country Code: "+proxyDeviceNameProcess.getProxyDeviceName().getCountryCode()+" " +
					"- Country Name: "+proxyDeviceNameProcess.getProxyDeviceName().getCountry());
			
			proxyDeviceNameProcess.getProxyDeviceName().setCreatedBy(user);
			proxyDeviceNameProcess.getProxyDeviceName().setModifiedBy(user);
			
			boolean exists = proxyDeviceNameProcess.updateProxyDeviceName(proxyDeviceNameProcess.getProxyDeviceName());
			
			if (exists) {
				result.addError(new ObjectError("manageResourceType.name","The Mapping already exists"));
				List<ProxyDeviceName> list = proxyDeviceNameProcess.getProxyDeviceNames();
				List<ProxyLocation> locations = proxyDeviceNameProcess.getProxyLocations();
				proxyDeviceNameProcess.setProxyDeviceNameList(list);
				proxyDeviceNameProcess.setProxyLocationList(locations);
				proxyDeviceNameProcess.setCountries(countriesList);
				model.addAttribute("proxyDeviceNameProcess",proxyDeviceNameProcess);
				return "c3par.admin.proxydevice";
			}
		} else {
			List<ProxyDeviceName> list = proxyDeviceNameProcess.getProxyDeviceNames();
			List<ProxyLocation> locations = proxyDeviceNameProcess.getProxyLocations();
			proxyDeviceNameProcess.setProxyDeviceNameList(list);
			proxyDeviceNameProcess.setProxyLocationList(locations);
			proxyDeviceNameProcess.setCountries(countriesList);
			model.addAttribute("proxyDeviceNameProcess",proxyDeviceNameProcess);
			return "c3par.admin.proxydevice";
		}
		
		log.info("ProxyDeviceNameController : addProxyDeviceName ends here..");
		return "forward:/loadProxyDeviceNames.act";
	}
	
	/*
	 * The method to add new resource type
	 */
	@RequestMapping(value = "/editProxyDeviceName.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String editProxyDeviceName(ModelMap model,@ModelAttribute("proxyDeviceNameProcess") ProxyDeviceNameProcess proxyDeviceNameProcess, HttpServletRequest request, BindingResult result){
		log.info("ProxyDeviceNameController : editProxyDeviceName starts here..");
		
		Long selectedId = proxyDeviceNameProcess.getSelectedId();
		
		proxyDeviceNameProcess = new ProxyDeviceNameProcess();
		proxyDeviceNameProcess.setProxyDeviceName(proxyDeviceNameProcess.loadProxyDeviceName(selectedId));
		
		List<ProxyDeviceName> list = proxyDeviceNameProcess.getProxyDeviceNames();
		List<ProxyLocation> locations = proxyDeviceNameProcess.getProxyLocations();
		
		proxyDeviceNameProcess.setProxyDeviceNameList(list);
		proxyDeviceNameProcess.setProxyLocationList(locations);
		proxyDeviceNameProcess.setCountries(proxyDeviceNameProcess.getAllCountries());
		model.addAttribute("proxyDeviceNameProcess",proxyDeviceNameProcess);
		
		log.info("ProxyDeviceNameController : editProxyDeviceName ends here..");
		return "c3par.admin.proxydevice";
	}
	
	
	/*
	 * The method to delete device
	 */
	@RequestMapping(value = "/deleteProxyDeviceName.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String deleteProxyDeviceName(ModelMap model,@ModelAttribute("proxyDeviceNameProcess") ProxyDeviceNameProcess proxyDeviceNameProcess, HttpServletRequest request, BindingResult result){
		log.info("ProxyDeviceNameController : deleteProxyDeviceName starts here..");
		
		Long selectedId = proxyDeviceNameProcess.getSelectedId();
		
		proxyDeviceNameProcess.deleteProxyDeviceName(selectedId);
		
		log.info("ProxyDeviceNameController : deleteProxyDeviceName ends here..");
		return "forward:/loadProxyDeviceNames.act";
	}
	
}
