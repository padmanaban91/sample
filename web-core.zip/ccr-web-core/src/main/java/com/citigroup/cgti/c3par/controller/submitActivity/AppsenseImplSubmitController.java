package com.citigroup.cgti.c3par.controller.submitActivity;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.webtier.helper.FAFReviewThread;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

/*
 * @nc43495
 */
@Controller
public class AppsenseImplSubmitController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(AppsenseImplSubmitController.class);
	
	@Autowired
	WsPapiFacade papiFacade;
	
	Util util=new Util();

	@Autowired
	WorkflowUtil workflowUtil;
	
	@RequestMapping(value = "/loadApsImplSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(ModelMap model,@ModelAttribute("appsenseImplProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session){
		log.info("Appsense impl Submit Controller load method starts here...");
		
		String tiReq = (String)session.getAttribute("tireqid");
		String actId = (String)session.getAttribute("activityid");
		
		Long tiReqId = Long.valueOf(0);
		Long activityId = Long.valueOf(0);
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		if(actId!=null){
		    try{activityId=Long.valueOf(actId);}catch(Exception e){activityId = Long.valueOf(0);}
		}
		log.debug("tiReq:"+tiReq+"ActivityId"+activityId);
		
		String taskId = (String) session.getAttribute("taskId");
		if(StringUtil.isNullorEmpty(actId)){
			activityId = workflowUtil.getAuditTrailId(activityId, taskId);
		}
		
		submitActivityProcess = new SubmitActivityProcess();
		
		//supplementary review roles display
		HashMap<String,String> roles = submitActivityProcess.findInstanceId(tiReqId, activityId);
		submitActivityProcess.setRoles(roles);
		List<LookUpVO> supReviewRole = submitActivityProcess.getSupReviewRoles((String)roles.get("ROLE"));
		log.debug("Appsense impl Submit Controller:"+supReviewRole.size());
		submitActivityProcess.setSupReviewRoles(supReviewRole);
		
		//set activity role
		submitActivityProcess.setActivityRole((String)roles.get("ROLE"));
		session.setAttribute("activityRole",submitActivityProcess.getActivityRole());
		log.debug("activity role:"+submitActivityProcess.getActivityRole());
		
		/*//setInstanceID
		String instanceId = (String)roles.get("INST_ID");
		session.setAttribute("instanceID", instanceId);
		log.debug("instanceId"+instanceId);*/
		
		// setTaskID
		log.debug("*********taskId************" + taskId);
		
		//Approval comments display
		String role = (String)roles.get("ROLE");
		submitActivityProcess.setTiReqCmtsList(submitActivityProcess.getComments(tiReqId, role, "A"));
		
		//Discussion comments display
		submitActivityProcess.setDiscussCmtsList(submitActivityProcess.getComments(tiReqId, role, "D"));
		
		//Appsense AD group display 
		TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
	
		Long appsenseADGroupID = Long.valueOf(0);
		AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		if(tiRequest.getTiProcess() != null){
			 appsenseADGroupID =  util.getAppsADGroupID(tiRequest.getTiProcess().getId());
		   if(appsenseADGroupID != 0){
			   appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(appsenseADGroupID);
			   submitActivityProcess.setAppsensePolicyMasterID(appsenseADGroup.getId());
			    submitActivityProcess.setAppsensePolicyID(appsenseADGroup.getPolicyID());
				submitActivityProcess.setAppsenseADGroupName(appsenseADGroup.getName());
				submitActivityProcess.setAppsensePolicyName(appsenseADGroup.getPolicyName());
				submitActivityProcess.setAppsensePolicyStatus(appsenseADGroup.getIsNew());
		   }
		   log.info("appsenseADGroupID in action:: "+appsenseADGroupID);
		}
		submitActivityProcess.setAppsenseADGroupID(appsenseADGroupID);
		
		  model.addAttribute("appsenseImplProcess", submitActivityProcess);
		
		return "c3par.appsenseImpl";
	}
	
	@RequestMapping(value = "/saveApsImplSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String save(ModelMap model,@ModelAttribute("appsenseImplProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request) throws Exception{
	log.info("Appsense impl Submit Controller:Save method starts here...");
	formSubmit(submitActivityProcess,result,session,request);
	return "forward:/logon.act?forwardTo=bpm";
		
	}
	
	
	@RequestMapping(value = "/submitApsImpl.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String submit(ModelMap model,@ModelAttribute("appsenseImplProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request) {
	log.info("Appsense impl Submit Controller:Save method starts here...");
	
	try {
		formSubmit(submitActivityProcess,result,session,request);
		log.debug("Appsense impl Submit PAPI Enter ");
		
		//WsPapiFacade papiFacade = new WsPapiFacade ();
		
		String taskId = (String)session.getAttribute("taskId");
		String userId  = request.getHeader("SM_USER");
		String nextSelectedAction = submitActivityProcess.getCurrentAction();
		String tiReq = (String)session.getAttribute("tireqid");
		log.debug("tiReq: " + tiReq);
		String nextRole = null;
		log.debug("taskId: " + taskId +"action"+nextSelectedAction);
		log.debug("userId: " + userId);
		
		log.debug("Before calling PAPI For BJ Submit");
		
		if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getProvideInfoRole());
		}else {
			nextRole = util.moveToActivity(submitActivityProcess.getCurrentRole());
		}
		
		log.debug("Selected role:"+nextRole);
		
		if ("UNLOCKED".equals( nextSelectedAction ) || "COMPLETED".equals( nextSelectedAction ) ) {
			papiFacade.completeActivity(userId, taskId, nextSelectedAction); 
			return "forward:/defaultInboxView.act";
		}
		
		if("REJECTED".equalsIgnoreCase(nextSelectedAction)){
			log.debug("inside Rejected scenario..."+nextSelectedAction);
			papiFacade.completeActivity(userId, taskId,"REJECTED");
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.completeActivity(userId, taskId, WsPapiFacade.ActivityStatus.PROVIDEINFO,WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("RESCHEDULED".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.rescheduleActivity(userId, Long.valueOf(tiReq),"apsimpl_schedule_user_notification",submitActivityProcess.getApsImpScheduleDate());
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
	} catch (OperationException_Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return "forward:/defaultInboxView.act";
		
	}
	
	
	//data collection
    private void formSubmit(SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session,
			HttpServletRequest request)throws Exception{
    	log.debug("Appsense impl Submit Controller form Submit begins...");
    	
    	String messgXML = (String)request.getSession().getAttribute("MESSAGEXML");
		log.info("messgXML::"+messgXML);
		
		String tiReq = (String)session.getAttribute("tireqid");
		
		submitActivityProcess.setActivityRole((String)session.getAttribute("activityRole"));
		log.debug("activity role inside form submit:"+submitActivityProcess.getActivityRole());
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );
		
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		
		//Getting request type
		TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
		
		if(submitActivityProcess.getCurrentAction()==null){
			submitActivityProcess.setCurrentAction(ActivityData.STATUS_COMPLETED);
		}
		
		if(submitActivityProcess.getCurrentRole()==null){
			submitActivityProcess.setCurrentRole(submitActivityProcess.getActivityRole());
		}

		log.info("Request Parameters::"+request.getParameterNames());
		log.info("Request current role="+request.getParameter("currentRole"));
		log.info("current action =" + submitActivityProcess.getCurrentAction());
		log.info("current role=" + submitActivityProcess.getCurrentRole());
		log.info("comments = " + submitActivityProcess.getComments());
		

		String ssoID = request.getHeader("SM_USER");
		
		TiRequestComments tiReqComments = new TiRequestComments();
		tiReqComments.setTiRequest(tiRequest);
		tiReqComments.setComments(submitActivityProcess.getComments());
		tiReqComments.setRoleName(submitActivityProcess.getActivityRole());
		tiReqComments.setApproverSoeID(ssoID);
		
		//update Appsense implementation data in ti_request table
		
		Long infomanID = 0l;
		StringBuffer schTsmp = new StringBuffer();
		StringBuffer compTsmp = new StringBuffer();
		
		if(submitActivityProcess.getApsInfomanID() == null ||
				submitActivityProcess.getApsInfomanID().longValue() == 0L){
			infomanID = 0L;
		}else{
			infomanID = submitActivityProcess.getApsInfomanID();
		}
		
		//reschedule date
		if(submitActivityProcess.getApsImpScheduleDate() !=null && !submitActivityProcess.getApsImpScheduleDate().isEmpty()){
			schTsmp.append(submitActivityProcess.getApsImpScheduleDate());
		} else{
			schTsmp.append("");
		}
		
		
		//completed date
		if(submitActivityProcess.getApsImpCompletedDate()!=null && !submitActivityProcess.getApsImpCompletedDate().isEmpty()
			&& submitActivityProcess.getApsImpCompletedTime()!=null	&& !submitActivityProcess.getApsImpCompletedTime().isEmpty()){
			compTsmp.append(submitActivityProcess.getApsImpCompletedDate());
			compTsmp.append(" ");
			compTsmp.append(submitActivityProcess.getApsImpCompletedTime());
		}else{
			compTsmp.append("");
		}

		
		log.debug("update information:"+schTsmp.toString()+"completed date"+compTsmp.toString()+"infoman id"+infomanID);
	
		submitActivityProcess.appsenseImpUpdate(tiReqId, infomanID, schTsmp.toString(), compTsmp.toString());
		
		//updating App Sense AD group information 
		if(submitActivityProcess.getAppsensePolicyMasterID() != null && submitActivityProcess.getAppsensePolicyMasterID().intValue()!=0){
			
			
			if (!"N".equalsIgnoreCase(submitActivityProcess.getAppsensePolicyStatus())) {
				AppsenseADGroup adGroup = new AppsenseADGroup();
				adGroup.setName(submitActivityProcess
					.getAppsenseADGroupName());
				adGroup.setId(submitActivityProcess
					.getAppsensePolicyMasterID());
				
			    if (submitActivityProcess.getAppsensePolicyMasterID() != null && submitActivityProcess.getAppsensePolicyMasterID().intValue()!=0) {
			    	submitActivityProcess.updateAppsensePolicyID(submitActivityProcess
					.getAppsensePolicyName(), submitActivityProcess
					.getAppsensePolicyID(), submitActivityProcess
					.getAppsenseADGroupName(), submitActivityProcess
					.getAppsensePolicyMasterID());
			    }
			    
			    log.debug("Appsense AD group data:"+submitActivityProcess
				.getAppsensePolicyName()+" "+submitActivityProcess
				.getAppsensePolicyID()+" "+submitActivityProcess
				.getAppsenseADGroupName()+" "+ submitActivityProcess
				.getAppsensePolicyMasterID());
			}
		}
		
		if(ActivityData.STATUS_COMPLETED.equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
		    TIProcess tiProcess = submitActivityProcess.getProcessData(tiReqId.longValue());
		    
			if(ActivityData.IS_NEW.equals(tiProcess.getProcessActivityMode()) || ActivityData.IS_REWORK.equals(tiProcess.getProcessActivityMode())){
			    insertFAFQueueRequest(request,tiProcess.getId(),"insertintoaafstate");
			}
		}  
		//updating tiRequest comments
		if(!"PROVIDEINFO".equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
			submitActivityProcess.addComments(tiReqComments, "A", "save");
		}else {
			submitActivityProcess.addComments(tiReqComments, "D", "save");
		}
			
    }
    
    
    public void insertFAFQueueRequest(HttpServletRequest request, Long connectionRequestId, String requestType)
    	    throws Exception {
    		log.debug("TIRequestCommentsAction.insertFAFQueueRequest() START");
    		Util util=new Util();
    		if("all".equals(requestType)){
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculate","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculatepaf","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculateaaf","N");
    		} else if("terminateall".equals(requestType)){
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminatefaf","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminateaaf","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminatepaf","N");
    		} else {
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),requestType,"N");
    		}
    		FAFReviewThread.getInstance().startThread(request);
    		FAFReviewThread.getInstance().notifyThread();
    		log.debug("TIRequestCommentsAction.insertFAFQueueRequest() END");
    	    }
}
