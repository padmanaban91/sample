package com.citigroup.cgti.c3par.webtier.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.citigroup.cgti.c3par.connection.domain.logic.TechnialArchitectureFacade;
import com.citigroup.cgti.c3par.soa.vc.logic.RFCService;



/**
 * The Class FAFReviewThread.
 */
public class FAFReviewThread {

    /** The list. */
    private List list=Collections.synchronizedList(new ArrayList());

    /** The is flag started. */
    private boolean isFlagStarted;

    /** The mgr. */
    private TechnialArchitectureFacade mgr = null;

    /** The ctx. */
    private WebApplicationContext ctx = null;

    /** The faf thread. */
    private static FAFReviewThread fafThread=null;

    /** The rfc service. */
    private RFCService rfcService = null;


    /** The log. */
    private static Logger log = Logger.getLogger(FAFReviewThread.class);

    /** The run faf calculation thread. */
    private Runnable runFAFCalculationThread = new Runnable() {
	public void run() {
	    try {
		print("Entered in run method for runFAFCalculationThread");
		calculateQueuedFAF();
		print("Returned in run method for runFAFCalculationThread");
	    } catch (InterruptedException ix) {
		print("runFAFCalculationThread interrupted!");
	    } catch (Exception x) {
		print("runFAFCalculationThread threw an Exception!!!\n" + x);
		log.error(x);
	    }
	}
    };

    /**
     * The Class FAFComputationThread.
     */
    private class FAFComputationThread extends Thread {

	/** The hh. */
	private HashMap hh;

	/**
	 * Instantiates a new fAF computation thread.
	 *
	 * @param hmap the hmap
	 */
	public FAFComputationThread (HashMap hmap){
	    super();
	    this.hh=hmap;
	}

	/* (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	public void run() {
	    try {
		print("Entered in run method for runFAFComputationThread");
		computeNSendMail(this.hh);
		print("Returned in run method for runFAFComputationThread");
	    } catch (InterruptedException ix) {
		print("runFAFComputationThread interrupted!");
	    } catch (Exception x) {
		print("runFAFComputationThread threw an Exception!!!\n" + x);
		log.error(x);
	    }
	}
    }

    /**
     * Start thread.
     *
     * @param request the request
     */
    public synchronized void  startThread(HttpServletRequest request){
	if(!this.isFlagStarted){
	    this.isFlagStarted=true;
	    Thread fafCalculationQueueThread = new Thread(runFAFCalculationThread, "FAFCalculationThread");
	    fafCalculationQueueThread.start();

	}
    }

    /**
     * Start computation thread.
     *
     * @param hh the hh
     */
    public void  startComputationThread(HashMap hh){
	FAFComputationThread fafComputationThread=new FAFComputationThread(hh);
	fafComputationThread.start();
    }

    /**
     * Notify thread.
     */
    public void notifyThread(){
	if(list.isEmpty()){
	    synchronized (list) {
		print("added: ");
		list.notifyAll();
		print("notified");
	    }
	    print("leaving");
	}
    }

    /**
     * Instantiates a new fAF review thread.
     */
    private FAFReviewThread() {
	super();
    }

    /**
     * Gets the single instance of FAFReviewThread.
     *
     * @return single instance of FAFReviewThread
     */
    public static synchronized FAFReviewThread getInstance(){
	if(fafThread==null){
	    fafThread=new FAFReviewThread();
	}
	return fafThread;
    }
    /*	public void run() {
	if("DESIGN_ENGINEER".equals(this.stepName)){

	 Util util = new Util();
	 util.recalculate(conreqId);
	} else if("NETWORK_ENGINEER".equals(this.stepName)){

	 Util util = new Util();

	}
	}*/

    /**
     * Calculate queued faf.
     *
     * @throws Exception the exception
     */
    private void calculateQueuedFAF() throws Exception {
	Util util=new Util();
	while(true){
	    synchronized (list) {
		if (list.isEmpty()) {
		    print("wait()");
		    list.wait(300000);
		    print("done with wait()");
		}
		// list = util.getQueuedFAFRequests();
		list = util.getFAFRequestsWithFlagQ();
		String fafQueuingEnabledFlag = null;
		Iterator listIter = list.iterator();
		while(listIter.hasNext()){
		    HashMap hh = (HashMap)listIter.next();
		    fafQueuingEnabledFlag = util.getFAFQueuingEnabledFlag();
		    if("Y".equals(fafQueuingEnabledFlag)){
			computeNSendMail(hh);
		    } else {
			startComputationThread(hh);
		    }
		}
		if("Y".equals(fafQueuingEnabledFlag)){
		    list = util.getFAFRequestsWithFlagQ();
		    //list = util.getQueuedFAFRequests();
		} else {
		    Thread.sleep(3000);
		}
	    }
	}
    }

    /**
     * Compute n send mail.
     *
     * @param hh the hh
     * @throws Exception the exception
     */
    private void computeNSendMail(HashMap hh) throws Exception{
	Util util=new Util();
	String reportType=null;
	String reqType= (String)hh.get("REQ_TYPE");
	Long conReqId = Long.valueOf((String)hh.get("CON_REQ_ID"));
	String sendMailFlag= (String)hh.get("SEND_MAIL_FLAG");
	String retValue=null;
	if("calculate".equals(reqType)){
	    reportType="FAF";
	    retValue= util.updateFAFQueue(conReqId,reqType);
	}else if("terminatefaf".equals(reqType)){
	    reportType="FAF";
	    retValue= util.updateFAFQueue(conReqId,reqType);
	}else if("recalculate".equals(reqType)){
	    reportType="FAF";
	    retValue= util.updateFAFQueue(conReqId,reqType);
	}else if("insertintofafstate".equals(reqType)){
	    reportType="FAF";
	    retValue= util.updateFAFQueue(conReqId,reqType);
	    if("true".equalsIgnoreCase(retValue)){
		util.updateFafFlagInPortMaster(conReqId);
	    }
	}
	else if("generatepaf".equals(reqType)){
	    reportType="PAF";
	    retValue= util.generatePafReview(conReqId);
	}else if("recalculatepaf".equals(reqType)){
	    reportType="PAF";
	    retValue= util.recalculatePAF(conReqId);
	}else if("insertintopafstate".equals(reqType)){
	    reportType="PAF";
	    retValue= util.insertIntoPafState(conReqId);
	}else if("generateaaf".equals(reqType)){
	    reportType="AAF";
	    retValue= util.generateAafReview(conReqId);
	}else if("recalculateaaf".equals(reqType)){
	    reportType="AAF";
	    retValue= util.recalculateAAF(conReqId);
	}else if("insertintoaafstate".equals(reqType)){
	    reportType="AAF";
	    retValue= util.insertIntoAafState(conReqId);
	}else if("terminatepaf".equals(reqType)){
	    reportType="PAF";
	    retValue= util.generateTerminatePAF(conReqId);
	}else if("terminateaaf".equals(reqType)){
	    reportType="AAF";
	    retValue= util.generateTerminateAAF(conReqId);
	}
	/*if (("calculate" .equals(reqType))|| ("terminatefaf".equals(reqType)) ||"recalculate".equals(reqType)){
	    Long tiRequestId=util.getLatestTiRequestId(conReqId);
	    List rfcRequestList=rfcService.storeRFCRequest(tiRequestId,RFCRequestDTO.RFC_CREATE_TYPE_AUTO);
	    String aclVarianceFlag=rfcService.getACLVarianceFlag(tiRequestId);
	    if (aclVarianceFlag != null
		    && aclVarianceFlag.equalsIgnoreCase("N")) {
		rfcService.storeRFCRequestStatus(tiRequestId, rfcRequestList);
	    }

	}*/
	/*if("Y".equals(sendMailFlag) && "true".equals(retValue)){
	    mgr.sendEmailFAFCompletion(conReqId,reportType);

	} */
	//else if("N".equals(sendMailFlag)){
	//Thread.sleep(20000);
	if(util.isComputationWait(conReqId)){
	    if(util.isOutputComputationsComplete(conReqId))
		Util.writeMessage(conReqId);
	}
	print("Removed "+conReqId);
    }

    /**
     * Prints the.
     *
     * @param msg the msg
     */
    private static void print(String msg) {
	String name = Thread.currentThread().getName();
	log.debug(name + ": " + msg);
    }

    /**
     * Gets the context.
     *
     * @param servletContext the servlet context
     * @return the context
     */
    private WebApplicationContext getContext(ServletContext servletContext) {
	log.debug("getContext(): Start");
	if (ctx == null) {
	    log.debug("Getting Spring  Context ....");
	    ctx = WebApplicationContextUtils.getWebApplicationContext(servletContext);
	    log.debug("Getting Spring  Context ....");
	}
	log.debug("getContext(): End");
	return ctx;
    }

    /**
     * Gets the bean.
     *
     * @param request the request
     * @param strManager the str manager
     * @return the bean
     */
    private Object getBean(HttpServletRequest request, String strManager) {
	log.debug("getService(): Start");
	Object mgr = ((getContext(request.getSession().getServletContext())).getBean(strManager));
	log.debug("getService(): End");
	return mgr;
    }



}
