package com.citigroup.cgti.c3par.controller.relationship;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;

import com.citigroup.cgti.c3par.relationship.domain.RelationshipProcess;
import com.citigroup.cgti.c3par.webtier.helper.SessionAttributesNames;

@Controller
public class RelationshipBaseController{

	private static final long serialVersionUID = 1L;

	private Logger log = Logger.getLogger(this.getClass().getName());

	protected void setInSession(HttpServletRequest request, RelationshipProcess relationshipProcess) {
		HttpSession session = request.getSession();
		log.info("set relatioshipprocess in session ");
		session.setAttribute(SessionAttributesNames.RELATIONSHIP_INFO_FORM, relationshipProcess);
    }

	protected RelationshipProcess getRelationshipProcess(HttpServletRequest request) {
		if(request.getSession().getAttribute(SessionAttributesNames.RELATIONSHIP_INFO_FORM)!=null){
			log.info("get relatioshipprocess in session ");
			RelationshipProcess relationshipProcess = (RelationshipProcess) request.getSession().getAttribute(SessionAttributesNames.RELATIONSHIP_INFO_FORM);	
			return relationshipProcess ;
		}
		return null;
		
    }

}
