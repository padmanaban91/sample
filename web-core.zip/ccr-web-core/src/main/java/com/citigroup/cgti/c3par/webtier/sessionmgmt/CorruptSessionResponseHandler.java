/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.webtier.sessionmgmt;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * This interface defines methods to handle a request in case of session
 * corruption.
 * 
 * @author pkadam
 */
public interface CorruptSessionResponseHandler {

    /**
     * This method returns a boolean. True if the handler successfully handled the
     * request. False otherwise.
     *
     * @param request the request
     * @param response the response
     * @return true, if successful
     */
    boolean handle(HttpServletRequest request, HttpServletResponse response);
}
