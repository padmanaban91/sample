/*
 * Created on Feb 3, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.webtier.helper;

import java.util.ArrayList;
import java.util.List;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.MaintenanceDAO;
import com.citigroup.cgti.c3par.dao.TerminationDAO;
import com.citigroup.cgti.c3par.model.MaintenanceEntity;
import com.citigroup.cgti.c3par.model.TerminationEntity;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;
import org.apache.log4j.Logger;


/**
 * The Class ProcessEntityHelper.
 *
 * @author dr97938
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ProcessEntityHelper {

    /** The log. */
    private static Logger log = Logger.getLogger(ProcessEntityHelper.class);
    //Given an inventory id get the corresponding in progress maintenance entity whose status is not complete
    /**
     * Find maintenance entity.
     *
     * @param inventoryId the inventory id
     * @return the maintenance entity
     */
    public static  MaintenanceEntity findMaintenanceEntity(Long inventoryId)
    {
	C3parSession c3parSession = new C3parSession();
	MaintenanceDAO maintenanceDAO = new MaintenanceDAO(c3parSession);
	Condition condition = new Condition();

	List entityList = new ArrayList();
	try
	{
	    OperatorExpression connectionIdExp = 
		new OperatorExpression(MaintenanceDAO.COLUMN_CONNECTION_ID, Operator.EQUAL, inventoryId);
	    condition.addExpression(connectionIdExp);

	    OperatorExpression statusExp = 
		new OperatorExpression(MaintenanceDAO.COLUMN_STATUS, Operator.NOT_EQUAL, C3parStatusLookupNames.MAINTENANCE_COMPLETE);
	    condition.addExpression(statusExp);

	    entityList = maintenanceDAO.query(condition, false);
	    if(entityList != null && entityList.size() > 0)
		return ((MaintenanceEntity)entityList.get(0));
	}
	catch(DatabaseException ex)
	{
	    log.error(ex);
	}
	finally
	{
	    if(c3parSession != null)
		c3parSession.releaseConnection();
	}

	return  null;
    }
    //	Given an inventory id get the corresponding in progress Termination entity whose status is not terminated
    /**
     * Find termination entity.
     *
     * @param inventoryId the inventory id
     * @return the termination entity
     */
    public static  TerminationEntity findTerminationEntity(Long inventoryId)
    {
	C3parSession c3parSession = new C3parSession();
	TerminationDAO termDAO = new TerminationDAO(c3parSession);
	Condition condition = new Condition();

	List entityList = new ArrayList();
	try
	{
	    OperatorExpression connectionIdExp = 
		new OperatorExpression(TerminationDAO.COLUMN_CONNECTION_ID,Operator.EQUAL,inventoryId);
	    condition.addExpression(connectionIdExp);

	    OperatorExpression statusExp = 
		new OperatorExpression(TerminationDAO.COLUMN_STATUS, Operator.NOT_EQUAL, C3parStatusLookupNames.TERMINATED);
	    condition.addExpression(statusExp);

	    entityList = termDAO.query(condition, false);
	    if(entityList != null && entityList.size() > 0)
		return ((TerminationEntity)entityList.get(0));
	}
	catch(DatabaseException ex)
	{
	    log.error(ex);
	}
	finally
	{
	    if(c3parSession != null)
		c3parSession.releaseConnection();
	}

	return  null;
    }
    //	Given an inventory id get the correspondingi Terminated entity whose status is terminated
    /**
     * Find terminated entity.
     *
     * @param inventoryId the inventory id
     * @return the termination entity
     */
    public static  TerminationEntity findTerminatedEntity(Long inventoryId)
    {
	C3parSession c3parSession = new C3parSession();
	TerminationDAO termDAO = new TerminationDAO(c3parSession);
	Condition condition = new Condition();

	List entityList = new ArrayList();
	try
	{
	    OperatorExpression connectionIdExp = 
		new OperatorExpression(TerminationDAO.COLUMN_CONNECTION_ID,Operator.EQUAL,inventoryId);
	    condition.addExpression(connectionIdExp);

	    OperatorExpression statusExp = 
		new OperatorExpression(TerminationDAO.COLUMN_STATUS, Operator.EQUAL, C3parStatusLookupNames.TERMINATED);
	    condition.addExpression(statusExp);

	    entityList = termDAO.query(condition, false);
	    if(entityList != null && entityList.size() > 0)
		return ((TerminationEntity)entityList.get(0));
	}
	catch(DatabaseException ex)
	{
	    log.error(ex);
	}
	finally
	{
	    if(c3parSession != null)
		c3parSession.releaseConnection();
	}

	return  null;
    }

}



