/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright � [2002-2004] Mentisys, Inc.  All rights reserved.
 * The contents of this material are confidential and proprietary to
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.webtier.helper;
import javax.servlet.ServletRequest;


/**
 * The Class SessionHelpers.
 */
public class SessionHelpers
{

    /**
     * Retrieves a "request argument"
     * First checks if the argument was passed as a parameter and, if so, place it of the request objects attributes.
     * Lastly it returns the value from the attribute.
     *
     * @param request the request
     * @param arg_name the arg_name
     * @return the request arg
     */
    static public String getRequestArg(ServletRequest request, String arg_name)
    {
	String s = (String)request.getParameter(arg_name);
	if(s != null)
	{
	    request.setAttribute(arg_name, s);					
	}
	else
	{
	    s = (String)request.getAttribute(arg_name);
	    if(s == null)
	    {
		s = "";
		request.setAttribute(arg_name, s);
	    }
	}
	return s;
    }
}
