package com.citigroup.cgti.c3par.fw.service;

import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_CONTEXT;
import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_PWD;
import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_SAML_URL;
import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_SSO_FIREFLOW_LOGIC_URL;
import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_SSO_FIREFLOW_URL;
import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_SSO_REDIRECT_URL;
import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_SSO_REFRESH_URL;
import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_SSO_SESSION;
import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_SSO_URL;
import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_URL;
import static com.citigroup.cgti.c3par.util.C3parProperties.ALGOSEC_USER;
import static com.citigroup.cgti.c3par.util.C3parProperties.DEV_MODE;
import static com.citigroup.cgti.c3par.util.C3parProperties.DIRECTOR_CC_DL;

import java.io.IOException;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.Cookie;

/*import noNamespace.FirewallDocument2.Firewall;
import noNamespace.InitialPlanDocument;
import noNamespace.InitialPlanDocument.InitialPlan;
import noNamespace.ResultDocument.Result;
import noNamespace.RuleDocument.Rule;
import noNamespace.SuggestionDocument.Suggestion;
import noNamespace.TrafficLineDocument.TrafficLine;
import noNamespace.TrafficLinesDocument.TrafficLines;
import noNamespace.WorkOrderDocument.WorkOrder;
import noNamespace.WorkOrdersDocument;
import noNamespace.WorkOrdersDocument.WorkOrders;*/

/*import org.apache.http.HttpException;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.cookie.BasicClientCookie;*/

import org.apache.log4j.Logger;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.citi.cgti.c3par.fw.ws.domain.FireFlowMessageRequest;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequestInfo;
import com.citigroup.cgti.c3par.fw.domain.FafFireflowTicket;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRule;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleDestinationIpObj;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRulePortObj;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleSourceIpObj;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleSuggestion;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.IPAddressObj;
import com.citigroup.cgti.c3par.fw.domain.PortObject;
import com.citigroup.cgti.c3par.fw.domain.soc.fireflow.FireflowExternalizable;
import com.citigroup.cgti.c3par.util.PasswordEncryptDecrypt;
import com.citigroup.cgti.c3par.util.StringUtil;

@Service
public class FireFlowServiceImpl implements FireflowExternalizable {
	static Logger log = Logger.getLogger(FireFlowServiceImpl.class);

	RestTemplate restTemplate;

	public RestTemplate getRestTemplate() {
		return restTemplate;
	}

	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	@Transactional(readOnly = true)
	public void getFFTicketDetails(String ticketId) {
		log.info("inside getFFTicketDetails");

		String taskResource = "ticket/" + ticketId;
		String query = "?user=" + ALGOSEC_USER + "&pass=" + ALGOSEC_USER;
		// String query = "?user=ccrffsys&pass=!Alg0$3c!";
		// String query = "?user=ccrffsys&pass=Eg4ds!@";

		try {
			StringBuffer url = new StringBuffer();
			url.append(ALGOSEC_URL);
			url.append(ALGOSEC_CONTEXT);
			url.append(taskResource);
			url.append("/");
			url.append(query);

			URI uri = new URI(url.toString());

			log.error("url= " + url);

			String response = restTemplate.postForObject(uri, null, String.class);
			String xml = response.substring(response.indexOf("<Ticket>"), response.indexOf("</Ticket>") + 9);
			// log.info(xml);
			// this.parseFireflowTicketXml(ticket);

		} catch (HttpClientErrorException httpExp) {
			httpExp.printStackTrace();
		} catch (RestClientException res) {
			res.printStackTrace();
		} catch (Exception e) {
			log.error(e, e);
		}

	}

	public static String getTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy::HH:mm:ss:SS");
		Date now = new Date();

		return sdf.format(now);
	}

	@Override
	public String createFireflowTicket(FafFireflowTicket ticket, Cookie[] requestCookies) {
		
	
		String ticketNumber = null;
		try {
			log.info("Inside createFireflowTicket for TiRequestId "+ticket.getTiRequest().getId()+" FAFFireFlowTicket ID "+ticket.getId());
			HttpComponentsClientHttpRequestFactory factory = (HttpComponentsClientHttpRequestFactory) restTemplate.getRequestFactory();
//			DefaultHttpClient client = (DefaultHttpClient) factory.getHttpClient();
			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
//			if (DEV_MODE.equalsIgnoreCase("False"))
//				siteminderAuthentication(client, requestCookies);
//			else
//				userNamePasswordAuthentication(map);

			StringBuffer url = new StringBuffer();
			url.append(ALGOSEC_URL);
			url.append(ALGOSEC_CONTEXT); 
			url.append("ticket/new");
			log.debug("url -->" + url);
		
			String content = buildTicketContent(ticket);
			map.add("content", content);
			String restResponse = restTemplate.postForObject(new URI(url.toString()), map, String.class);
			log.debug(" Ticket Create REST API Response :" + restResponse);
			
			if(restResponse.indexOf("# Ticket") != - 1 && restResponse.indexOf("created.") != -1)
				ticketNumber = restResponse.substring(restResponse.indexOf("# Ticket") + 9, restResponse.indexOf("created."));
			
			if (ticketNumber != null){
				ticketNumber = ticketNumber.trim();
				log.info("Fireflow Ticket Creation Successful for TiRequestId "+ticket.getTiRequest().getId()+" FAFFireFlowTicket ID "+ticket.getId() +" Fireflow Ticket Number "+ticketNumber);
			}else{
				throw new RuntimeException("Fireflow Ticket Creation not Successful for TiRequestId "+ticket.getTiRequest().getId()+" FAFFireFlowTicket ID "+ticket.getId());
			}
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - " + e.getMessage());
			e.printStackTrace();
			throw new ApplicationException(e.getMessage(),e);
		}
		return ticketNumber;

	}

	private String buildTicketContent(FafFireflowTicket ticket) {
		FAFRequestInfo fafRequestInfo = ticket.getFafRequestInfo();
		String fireflowTicketSubject = fafRequestInfo.getOriginalConnectionRequestId() + "." + fafRequestInfo.getVersionNumber() + "-" + fafRequestInfo.getConnectionName();

		log.debug("fireflowTicketSubject " + fireflowTicketSubject);

		StringBuilder trafficTuples = new StringBuilder();
		List<FafFirewallRule> rules = ticket.getFafFireWallRules();
		log.info("Total number of Rules : " + rules.size());
		for (FafFirewallRule fafFireWallRule : rules) {

			if (fafFireWallRule.getFafFireFlowTicket().getTicketNumber() == null)
				log.info(fafFireWallRule.toString());
			trafficTuples.append(fafFireWallRule);
			trafficTuples.append("|");
		}

		String content = "Queue: 1\n" + "Owner: " + ALGOSEC_USER + "\n" + "Creator: " + ALGOSEC_USER + "\n" + "Subject: " + fireflowTicketSubject + "\n" + "Requestor: " + fafRequestInfo.getCurrCycleRequestor().getEmailAddress() + "\n" + "Cc: "+ DIRECTOR_CC_DL +"\n" + "CF.{connectionId}: " + fafRequestInfo.getOriginalConnectionRequestId() + "\n" + "CF.{requestId}: " + fafRequestInfo.getTiRequest() + "\n" + "CF.{Category}: " + ticket.getPolicyGroup().getName() + "\n" + "CF.{openedViaRest}: "+ "Yes" +  "\n" + "CF.{Traffic tuples}: " + trafficTuples;
		log.debug("RestAPI Post Content "+content);
		return content;
	}

	
	private void userNamePasswordAuthentication(MultiValueMap<String, String> map) {
		log.info("SSO Disabled, using credentials from Properties file");
		PasswordEncryptDecrypt passwordEncryptDecrypt = new PasswordEncryptDecrypt();
		map.add("pass", passwordEncryptDecrypt.decrypt(ALGOSEC_PWD));
		map.add("user", ALGOSEC_USER);
	}

	/*private void siteminderAuthentication(DefaultHttpClient client, Cookie[] requestCookies) {
		try {
			org.apache.http.impl.cookie.BasicClientCookie httpCookie = getSiteminderClientCookies(client, requestCookies);
			client.getCookieStore().addCookie(httpCookie);
			performSAMLAssertion();
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - " + e.getMessage());
			e.printStackTrace();
		}
	}

	org.apache.http.impl.cookie.BasicClientCookie  getSiteminderClientCookies(DefaultHttpClient client, Cookie[] requestCookies) {
		log.debug("inside setSiteminderClientCookies  method");
		
		org.apache.http.impl.cookie.BasicClientCookie httpCookie = null;
		for (int i = 0; i < requestCookies.length; i++) {
			Cookie cookie = requestCookies[i];
			if (cookie.getName().equals("SMSESSION")) {
				httpCookie = new BasicClientCookie(cookie.getName(),cookie.getValue());
				httpCookie.setComment(cookie.getComment());
				httpCookie.setDomain(".ssmb.com");
				httpCookie.setAttribute(cookie.getName(),cookie.getValue());
				httpCookie.setValue(cookie.getValue());
				httpCookie.setVersion(cookie.getVersion());
				httpCookie.setPath("/");
				break;
			}
			// client.getState().addCookie(httpCookie);
		}
		log.debug("setSiteminderClientCookies : Cookie values  Name" + httpCookie.getName() + " Path " + httpCookie.getPath() + " Domain " + httpCookie.getDomain() + " Value " + httpCookie.getValue() + " Version " + httpCookie.getVersion() + " Comment " + httpCookie.getComment());
		return httpCookie;
	}*/

	private void performSAMLAssertion() throws IOException/*, HttpException */{
		try {
			log.debug("inside executeHttpRequest  method");
			String restResponse = restTemplate.getForObject(ALGOSEC_SSO_URL, String.class);
			log.debug("SAML Response : " + restResponse);
			String samlToken = getSamlToken(restResponse);
			if (samlToken == null) {
				throw new RuntimeException("System Error. SAML Response body is Null !!!!. Please Investigate");
			}
			// HttpEntity<String> samlResponse= new HttpEntity<String>(body);
			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
			map.add("SAMLResponse", samlToken);
			restResponse = restTemplate.postForObject(ALGOSEC_URL+ALGOSEC_SAML_URL, map, String.class);
			log.debug("Algosec Home Page Redirect : " + restResponse);
			restResponse = restTemplate.getForObject(ALGOSEC_URL+ALGOSEC_SSO_REDIRECT_URL, String.class);
			log.debug("Algosec Home Page Refresh : " + restResponse);
			restResponse = restTemplate.getForObject(ALGOSEC_URL+ALGOSEC_SSO_REDIRECT_URL+ALGOSEC_SSO_REFRESH_URL, String.class);
			log.debug("Algosec Home Page : " + restResponse);
			restResponse = restTemplate.getForObject(ALGOSEC_URL+ALGOSEC_SSO_FIREFLOW_URL, String.class);
			log.debug("Algosec Ticket Redirect : " + restResponse);
			String[] fireflowUrlToken = printFireflowToken(restResponse);
			restResponse = restTemplate.getForObject(ALGOSEC_URL+ALGOSEC_SSO_FIREFLOW_URL+ALGOSEC_SSO_FIREFLOW_LOGIC_URL + fireflowUrlToken[0].substring(1, fireflowUrlToken[0].length() - 1) + ALGOSEC_SSO_SESSION + fireflowUrlToken[1].substring(2, fireflowUrlToken[1].length() - 1), String.class);
			log.debug("Algosec Ticket : " + restResponse);

			/*restResponse = restTemplate.getForObject("https://algosec-lab1.eur.nsroot.net/FireFlow/REST/1.0/ticket/5", String.class);
			log.debug("Algosec Ticket 5: " + restResponse);

			restResponse = restTemplate.getForObject("https://algosec-lab1.eur.nsroot.net/FireFlow/REST/1.0/ticket/6", String.class);
			log.debug("Algosec Ticket 6: " + restResponse);*/

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ApplicationException(e.getMessage(),e);
		}
	}


	private String getSamlToken(String samlHtml) {
		String str = null;
		try {
			str = samlHtml.substring(samlHtml.indexOf("<input"));
			str = str.substring(str.indexOf("value=\"") + "value=\"".length());
			str = str.substring(0, str.indexOf(">"));
			str = str.substring(0, str.indexOf("\""));
			log.debug(str);
		} catch (Exception e) {

			e.printStackTrace();
		}
		return str;
	}

	private String[] printFireflowToken(String str) {
		 
		str = str.substring(str.lastIndexOf("fireFlowSingleSignOn(") + "fireFlowSingleSignOn(".length(), str.indexOf(", fireFlowSingleSignOnCallback);"));
		String[] strToken = str.split(",");
		log.debug(strToken[0].substring(1, strToken[0].length() - 1));
		log.debug(strToken[1].substring(2, strToken[1].length() - 1));

		return strToken;

	}


	@Override
	public List<FafFirewallRuleSuggestion> parseFireflowTicketXml(FireFlowMessageRequest message) {

		log.info("inside parse sevice method");
		List<FafFirewallRuleSuggestion> fafFirewallRuleSuggestions = null;
		FafFireflowTicket fireflowTicket = new FafFireflowTicket();
		FafFirewallRuleSuggestion ruleSuggestion = null;

		try {
			FafFireflowTicket ticket = fireflowTicket.findFireflowTicketByNumber(message.getFfTicketId().trim());// reconsider
																													// -

			// parseWorkOrder(ticket,xmlString);
			String initialPlan = message.getInitialPlan();
			String workOrders = message.getWorkOrders();
			String statusId = message.getId();
			if (statusId.equals(ticket.PLAN) && initialPlan != null && initialPlan.length() > 0 && initialPlan.startsWith("<![CDATA[<InitialPlan>")) {
				fafFirewallRuleSuggestions = parseInitialPlan(ticket, message);

			} else if (statusId.equals(ticket.PLAN)) {
				throw new BusinessException("No Initial Plan XML to parse");
			}
			if (statusId.equals(ticket.LCK_TICK) && workOrders != null && workOrders.length() > 0 && workOrders.startsWith("<![CDATA[<WorkOrders>")) {
				if ('A' == ticket.getType()) {
					fafFirewallRuleSuggestions = parseWorkOrder(ticket, message);
				}
				if ('D' == ticket.getType()) {
					fafFirewallRuleSuggestions = parseDropWorkOrder(ticket, message);
				}

			} else if (statusId.equals(ticket.LCK_TICK) && !ticket.hasChildTicket()) {
				if (StringUtil.isEqual(message.getFfTicketId(), message.getFfSubTicketId())) {
					throw new BusinessException("No Work Order XML to parse");
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(e.getMessage());
		}
		return fafFirewallRuleSuggestions;
	}

	private List<FafFirewallRuleSuggestion> parseDropWorkOrder(FafFireflowTicket ticket, FireFlowMessageRequest message) {
	    List<FafFirewallRuleSuggestion> fafFirewallRuleSuggestions = new ArrayList<FafFirewallRuleSuggestion>();
		/*String xmlString = message.getWorkOrders();
		String woXmlStr1 = xmlString.substring(xmlString.indexOf("<WorkOrders>"), xmlString.indexOf("</WorkOrders>") + 13);
		log.info(woXmlStr1);

		List<FafFirewallRuleSuggestion> fafFirewallRuleSuggestions = new ArrayList<FafFirewallRuleSuggestion>();
		Map<String, FafFirewallRuleSuggestion> ruleSuggestions = new HashMap<String, FafFirewallRuleSuggestion>();
		// step 2: parse the WO xml using xmlbeans factory method
		try {
			WorkOrdersDocument workOrdersDoc = WorkOrdersDocument.Factory.parse(woXmlStr1);
			WorkOrders workOrders = workOrdersDoc.getWorkOrders();
			log.info(workOrders);
			WorkOrder[] woArray = workOrders.getWorkOrderArray();
			String policyName = "";
			String deviceName = "";
			String messageValue = message.getMessage();
			log.info("parseWorkOrder.message.getMessage():" + messageValue);
			if (messageValue != null) {
				String[] messageValues = messageValue.split(";");
				policyName = messageValues[0].split("=")[1];
				if (messageValues.length > 1)
					deviceName = messageValues[1].split("=")[1];
				log.info("parseWorkOrder.message.getMessage().policyName:" + policyName);
			}
			// step 4: iterate thru the work order and extract required data
			for (int i = 0; i < woArray.length; i++) { //
				log.info("trafficLine for " + i + " workorder is " + woArray[i].getTrafficLineArray().length);
				TrafficLine[] trafficLineArray = woArray[i].getTrafficLineArray();
				// step 5: for each workorder get the number of traffic lines.
				for (int j = 0; j < trafficLineArray.length; j++) {
					FirewallPolicy policy = null;
					// step 6: for each traffic line get the suggestion
					TrafficLine trafficLine = trafficLineArray[j];
					Suggestion suggestion = trafficLine.getSuggestion();
					// step 7: get the firewall details from firewallName
					log.info("translated firewall name : " + deviceName.replace('_', '-'));
					com.citigroup.cgti.c3par.fw.domain.Firewall firewall = ticket.findFirewallByName(deviceName.replace('_', '-'));
					// step 8: get the corresponding Implementation Rules using
					// the policyId

					if (firewall == null) {
						throw new BusinessException("Firewall not available in  CCR for the ticket:firewall " + ticket.getTicketNumber() + ":" + deviceName.replace('_', '-'));
					}
					int ccrRuleSequence = trafficLine.getNumber().intValue();
					String ffRuleNumber = "";
					String key = ticket.getTicketNumber().trim() + ":" + firewall.getFirewallPolicy().getId() + ":" + ccrRuleSequence;
					log.info("key" + key);
					FafFirewallRuleSuggestion ruleSuggestion = ruleSuggestions.get(key);
					if (trafficLine.getSuggestion().getRulesToModify() != null || trafficLine.getSuggestion().getRulesToRemove() != null) {
						Rule[] rulesToModify = null;
						if (trafficLine.getSuggestion().getRulesToModify() != null) {
							rulesToModify = trafficLine.getSuggestion().getRulesToModify().getRuleArray();
						}

						Rule[] rulesToRemove = null;
						if (trafficLine.getSuggestion().getRulesToRemove() != null) {
							rulesToRemove = trafficLine.getSuggestion().getRulesToRemove().getRuleArray();
						}

						Rule[] allRules = null;
						if (rulesToModify != null && rulesToModify.length > 0 && rulesToRemove != null && rulesToRemove.length > 0) {
							allRules = new Rule[rulesToModify.length + rulesToRemove.length];
							System.arraycopy(rulesToModify, 0, allRules, 0, rulesToModify.length);
							System.arraycopy(rulesToRemove, 0, allRules, rulesToModify.length, rulesToRemove.length);
						} else if (rulesToModify != null && rulesToModify.length > 0) {
							allRules = rulesToModify;
						} else if (rulesToRemove != null && rulesToRemove.length > 0) {
							allRules = rulesToRemove;
						}
						for (Rule rule : allRules) {
							ffRuleNumber = rule.getRuleNumber().toString();
							if (ruleSuggestion == null) {

								ruleSuggestion = new FafFirewallRuleSuggestion().findFafFirewallRuleSuggestion(ticket.getTicketNumber().trim(), firewall.getFirewallPolicy().getId(), ccrRuleSequence, ffRuleNumber);

								if (ruleSuggestion != null && StringUtil.isEqual(ruleSuggestion.getSubTicketStatus(), FafFireflowTicket.LCK_TICK)) {
									continue;
								}
								if (ruleSuggestion == null) {
									FAFRequest fafRequest = new FAFRequest();
									FafFirewallRule fafFirewallRule = fafRequest.findRequestedRule(ticket.getTicketNumber().trim(), ccrRuleSequence);

									if (firewall == null) {
										throw new BusinessException("Firewall not available in  CCR for the ticket:firewall " + ticket.getTicketNumber() + ":" + deviceName.replace('_', '-'));
									}
									policy = firewall.getFirewallPolicy();
									if (policy == null) {
										throw new BusinessException("No policy available in  CCR for the ticket:firewall " + ticket.getTicketNumber() + ":" + deviceName.replace('_', '-'));
									}
									ruleSuggestion = new FafFirewallRuleSuggestion();
									ruleSuggestion.setFafFirewallRule(fafFirewallRule);
									ruleSuggestion.setDestinationNetworkZone(fafFirewallRule.getDestinationNetworkZone());
									ruleSuggestion.setSourceNetworkZone(fafFirewallRule.getSourceNetworkZone());
									ruleSuggestion.setSourceZone(fafFirewallRule.getSourceZone());
									ruleSuggestion.setDestinationZone(fafFirewallRule.getDestinationZone());
									ruleSuggestion.setPolicy(policy);
									// to clarify
									ruleSuggestion.setAction(suggestion.getSuggestedAction());

								}
								ruleSuggestion.setRuleNumber(ffRuleNumber);
								ruleSuggestion.setSubTicketNo(message.getFfSubTicketId());
								ruleSuggestion.setFirewallBrand(suggestion.getFirewallBrand());
								ruleSuggestion.setAction(suggestion.getSuggestedAction());
								ruleSuggestion.setStatus(suggestion.getAction());
								ruleSuggestion.setFfComment(woArray[i].getImplementationNotes());
								ruleSuggestion.setFfDeviceName(deviceName);
								ruleSuggestion.setFfPolicyName(policyName);
								ruleSuggestion.setSubTicketStatus(message.getId());

							}
							ruleSuggestions.put(key, ruleSuggestion);
						}
					} else {
						if (ruleSuggestion == null) {

							ruleSuggestion = new FafFirewallRuleSuggestion().findFafFirewallRuleSuggestion(ticket.getTicketNumber().trim(), firewall.getFirewallPolicy().getId(), ccrRuleSequence);

							if (ruleSuggestion != null && StringUtil.isEqual(ruleSuggestion.getSubTicketStatus(), FafFireflowTicket.LCK_TICK)) {
								continue;
							}
							if (ruleSuggestion == null) {
								FAFRequest fafRequest = new FAFRequest();
								FafFirewallRule fafFirewallRule = fafRequest.findRequestedRule(ticket.getTicketNumber().trim(), ccrRuleSequence);

								if (firewall == null) {
									throw new BusinessException("Firewall not available in  CCR for the ticket:firewall " + ticket.getTicketNumber() + ":" + deviceName.replace('_', '-'));
								}
								policy = firewall.getFirewallPolicy();
								if (policy == null) {
									throw new BusinessException("No policy available in  CCR for the ticket:firewall " + ticket.getTicketNumber() + ":" + deviceName.replace('_', '-'));
								}
								ruleSuggestion = new FafFirewallRuleSuggestion();
								ruleSuggestion.setFafFirewallRule(fafFirewallRule);
								ruleSuggestion.setDestinationNetworkZone(fafFirewallRule.getDestinationNetworkZone());
								ruleSuggestion.setSourceNetworkZone(fafFirewallRule.getSourceNetworkZone());
								ruleSuggestion.setSourceZone(fafFirewallRule.getSourceZone());
								ruleSuggestion.setDestinationZone(fafFirewallRule.getDestinationZone());
								ruleSuggestion.setPolicy(policy);
								// to clarify
								ruleSuggestion.setAction(suggestion.getSuggestedAction());

							}
							ruleSuggestion.setRuleNumber(ffRuleNumber);
							ruleSuggestion.setSubTicketNo(message.getFfSubTicketId());
							ruleSuggestion.setFirewallBrand(suggestion.getFirewallBrand());
							ruleSuggestion.setAction(suggestion.getSuggestedAction());
							ruleSuggestion.setStatus(suggestion.getAction());
							ruleSuggestion.setFfComment(woArray[i].getImplementationNotes());
							ruleSuggestion.setFfDeviceName(deviceName);
							ruleSuggestion.setFfPolicyName(policyName);
							ruleSuggestion.setSubTicketStatus(message.getId());

						}
						ruleSuggestions.put(key, ruleSuggestion);
					}

				}
			}
			Set<String> keys = ruleSuggestions.keySet();
			for (String key : keys) {
				fafFirewallRuleSuggestions.add(ruleSuggestions.get(key));
			}
		} catch (Exception e) {
			throw new BusinessException("WO XML PARSING ERROR " + e.getMessage());
		}*/
		return fafFirewallRuleSuggestions;
	}

	private List<FafFirewallRuleSuggestion> parseInitialPlan(FafFireflowTicket ticket, FireFlowMessageRequest message) {
	    List<FafFirewallRuleSuggestion> fafFirewallRuleSuggestions = new ArrayList<FafFirewallRuleSuggestion>();
		/*String xmlString = message.getInitialPlan();
		List<FafFirewallRuleSuggestion> fafFirewallRuleSuggestions = new ArrayList<FafFirewallRuleSuggestion>();
		FafFirewallRuleSuggestion ruleSuggestion = null;
		try {
			FirewallPolicy policy = null;
			String status = null;
			String action;

			String xmlStr1 = xmlString.substring(xmlString.indexOf("<InitialPlan>"), xmlString.indexOf("</InitialPlan>") + 14);

			log.info(xmlStr1);

			List<FafFirewallRule> rules = ticket.getFafFireWallRules();
			log.info("rules in ticket " + rules.size());

			InitialPlanDocument initialPlanDoc = InitialPlanDocument.Factory.parse(xmlStr1);
			if (initialPlanDoc != null) {

				InitialPlan initalPlan = (InitialPlan) initialPlanDoc.getInitialPlan();

				Result result = (Result) initalPlan.getInitialPlanResultForTraffic().getResult();
				action = (String) initalPlan.getInitialPlanResultForTraffic().getTrafficAction();
				Firewall[] firewalls = (Firewall[]) result.getFirewallArray();

				for (Firewall firewall : firewalls) {
					status = firewall.getStatus();
					if (status != null && (!"N/A".equalsIgnoreCase(status) && !"Fail".equalsIgnoreCase(status))) {
						TrafficLines trafficLinesObj = firewall.getTrafficLines();
						if (trafficLinesObj == null) {
							throw new BusinessException("No traffic lines available for ticket:firewall " + ticket.getTicketNumber() + ":" + firewall.getName());
						}
						TrafficLine[] trafficLines = trafficLinesObj.getTrafficLineArray();
						log.info("translated firewall name in Initial Plan : " + firewall.getName().replace('_', '-'));
						com.citigroup.cgti.c3par.fw.domain.Firewall firewallObject = ticket.findFirewallByName(firewall.getName().replace('_', '-'));
						if (firewallObject == null) {
							throw new BusinessException("Firewall not available in  CCR for the ticket:firewall " + ticket.getTicketNumber() + ":" + firewall.getName());
						}
						policy = firewallObject.getFirewallPolicy();
						if (policy == null) {
							throw new BusinessException("No policy available in  CCR for the ticket:firewall " + ticket.getTicketNumber() + ":" + firewall.getName());
						}
						for (TrafficLine trafficLine : trafficLines) {
							if (trafficLine.getStatus() != null && !trafficLine.getStatus().equalsIgnoreCase("N/A")) {
								int ccrRuleSequence = trafficLine.getNumber2().intValue();
								FAFRequest fafRequest = new FAFRequest();
								FafFirewallRule fafFirewallRule = fafRequest.findRequestedRule(ticket.getTicketNumber().trim(), ccrRuleSequence);
								if (fafFirewallRule == null) {
									throw new BusinessException("No rule requested for ticket:seq " + ticket.getTicketNumber() + ":" + ccrRuleSequence);
								}
								ruleSuggestion = ticket.getFafFirewallRuleSuggestion(fafFirewallRule.getId(), policy.getId());
								if (ruleSuggestion == null) {
									ruleSuggestion = new FafFirewallRuleSuggestion();
									ruleSuggestion.setFafFirewallRule(fafFirewallRule);
									ruleSuggestion.setDestinationNetworkZone(fafFirewallRule.getDestinationNetworkZone());
									ruleSuggestion.setSourceNetworkZone(fafFirewallRule.getSourceNetworkZone());
									ruleSuggestion.setSourceZone(fafFirewallRule.getSourceZone());
									ruleSuggestion.setDestinationZone(fafFirewallRule.getDestinationZone());
									ruleSuggestion.setPolicy(policy);
									ruleSuggestion.setAction(action);
									ruleSuggestion.setStatus(status);
								}
								if (!fafFirewallRuleSuggestions.contains(ruleSuggestion)) {
									fafFirewallRuleSuggestions.add(ruleSuggestion);
								}
							}
						}
					}

				}

			}

		} catch (Exception e) {
			throw new BusinessException("PLAN XML PARSING ERROR " + e.getMessage());
		}*/
		return fafFirewallRuleSuggestions;
	}

	private List<FafFirewallRuleSuggestion> parseWorkOrder(FafFireflowTicket ticket, FireFlowMessageRequest message) {
	    List<FafFirewallRuleSuggestion> fafFirewallRuleSuggestions = new ArrayList<FafFirewallRuleSuggestion>();
		/*String xmlString = message.getWorkOrders();
		String woXmlStr1 = xmlString.substring(xmlString.indexOf("<WorkOrders>"), xmlString.indexOf("</WorkOrders>") + 13);
		log.info(woXmlStr1);

		List<FafFirewallRuleSuggestion> fafFirewallRuleSuggestions = new ArrayList<FafFirewallRuleSuggestion>();
		Map<String, FafFirewallRuleSuggestion> ruleSuggestions = new HashMap<String, FafFirewallRuleSuggestion>();
		// step 2: parse the WO xml using xmlbeans factory method
		try {
			WorkOrdersDocument workOrdersDoc = WorkOrdersDocument.Factory.parse(woXmlStr1);
			WorkOrders workOrders = workOrdersDoc.getWorkOrders();
			log.info(workOrders);
			WorkOrder[] woArray = workOrders.getWorkOrderArray();
			String policyName = "";
			String deviceName = "";
			String messageValue = message.getMessage();
			log.info("parseWorkOrder.message.getMessage():" + messageValue);
			if (messageValue != null) {
				String[] messageValues = messageValue.split(";");
				policyName = messageValues[0].split("=")[1];
				if (messageValues.length > 1)
					deviceName = messageValues[1].split("=")[1];
				log.info("parseWorkOrder.message.getMessage().policyName:" + policyName);
			}
			// step 4: iterate thru the work order and extract required data
			for (int i = 0; i < woArray.length; i++) { //
				log.info("trafficLine for " + i + " workorder is " + woArray[i].getTrafficLineArray().length);
				TrafficLine[] trafficLineArray = woArray[i].getTrafficLineArray();
				// step 5: for each workorder get the number of traffic lines.
				for (int j = 0; j < trafficLineArray.length; j++) {
					FirewallPolicy policy = null;
					// step 6: for each traffic line get the suggestion
					TrafficLine trafficLine = trafficLineArray[j];
					Suggestion suggestion = trafficLine.getSuggestion();
					// step 7: get the firewall details from firewallName
					log.info("translated firewall name : " + deviceName.replace('_', '-'));
					com.citigroup.cgti.c3par.fw.domain.Firewall firewall = ticket.findFirewallByName(deviceName.replace('_', '-'));
					// step 8: get the corresponding Implementation Rules using
					// the policyId
					if (firewall == null) {
						throw new BusinessException("Firewall not available in  CCR for the ticket:firewall " + ticket.getTicketNumber() + ":" + deviceName.replace('_', '-'));
					}
					int ccrRuleSequence = trafficLine.getNumber().intValue();
					String key = ticket.getTicketNumber().trim() + ":" + firewall.getFirewallPolicy().getId() + ":" + ccrRuleSequence;
					log.info("key" + key);
					FafFirewallRuleSuggestion ruleSuggestion = ruleSuggestions.get(key);

					if (ruleSuggestion == null) {
						ruleSuggestion = new FafFirewallRuleSuggestion().findFafFirewallRuleSuggestion(ticket.getTicketNumber().trim(), firewall.getFirewallPolicy().getId(), ccrRuleSequence);
						if (ruleSuggestion != null && StringUtil.isEqual(ruleSuggestion.getSubTicketStatus(), FafFireflowTicket.LCK_TICK)) {
							continue;
						}
						if (ruleSuggestion == null) {
							FAFRequest fafRequest = new FAFRequest();
							FafFirewallRule fafFirewallRule = fafRequest.findRequestedRule(ticket.getTicketNumber().trim(), ccrRuleSequence);

							if (firewall == null) {
								throw new BusinessException("Firewall not available in  CCR for the ticket:firewall " + ticket.getTicketNumber() + ":" + deviceName.replace('_', '-'));
							}
							policy = firewall.getFirewallPolicy();
							if (policy == null) {
								throw new BusinessException("No policy available in  CCR for the ticket:firewall " + ticket.getTicketNumber() + ":" + deviceName.replace('_', '-'));
							}
							ruleSuggestion = new FafFirewallRuleSuggestion();
							ruleSuggestion.setFafFirewallRule(fafFirewallRule);
							ruleSuggestion.setDestinationNetworkZone(fafFirewallRule.getDestinationNetworkZone());
							ruleSuggestion.setSourceNetworkZone(fafFirewallRule.getSourceNetworkZone());
							ruleSuggestion.setSourceZone(fafFirewallRule.getSourceZone());
							ruleSuggestion.setDestinationZone(fafFirewallRule.getDestinationZone());
							ruleSuggestion.setPolicy(policy);
							// to clarify
							ruleSuggestion.setAction(suggestion.getSuggestedAction());
							ruleSuggestion.setStatus(suggestion.getAction());
							ruleSuggestion.setFfComment(woArray[i].getImplementationNotes());
						}
					}
					ruleSuggestion.setRuleNumber(suggestion.getRuleNumber());
					ruleSuggestion.setSubTicketNo(message.getFfSubTicketId());
					ruleSuggestion.setFirewallBrand(suggestion.getFirewallBrand());
					ruleSuggestion.setAction(suggestion.getSuggestedAction());
					ruleSuggestion.setStatus(suggestion.getAction());
					ruleSuggestion.setFfDeviceName(deviceName);
					ruleSuggestion.setFfPolicyName(policyName);
					ruleSuggestion.setSubTicketStatus(message.getId());
					ruleSuggestion.setFfComment(woArray[i].getImplementationNotes());
					if (!"NoActionRequired".equalsIgnoreCase(suggestion.getSuggestedAction())) {
						String[] recommendedSources = suggestion.getSource().getRecommendedValuesArray();
						String[] currentSources = suggestion.getSource().getCurrentValuesArray();
						for (String recommendedSource : recommendedSources) {

							FafFirewallRuleSourceIpObj srcObj = new FafFirewallRuleSourceIpObj();
							srcObj.setImplFafFirewallRule(ruleSuggestion);
							IPAddressObj srcIpAddress = new IPAddressObj();
							srcIpAddress.setIpAddress(recommendedSource);
							srcObj.setIpAddress(srcIpAddress);
							if (StringUtil.isContains(recommendedSource, currentSources)) {
								srcObj.setCurrentValueFlag(FafFirewallRuleSourceIpObj.YES);
							}
							ruleSuggestion.getSourceIPs().add(srcObj);
						}
						String[] recommendedDestinations = suggestion.getDestination().getRecommendedValuesArray();
						String[] currentDestinations = suggestion.getDestination().getCurrentValuesArray();
						for (String recommendedDestination : recommendedDestinations) {
							FafFirewallRuleDestinationIpObj destObj = new FafFirewallRuleDestinationIpObj();
							destObj.setImplFafFirewallRule(ruleSuggestion);
							IPAddressObj destIpAddress = new IPAddressObj();
							destIpAddress.setIpAddress(recommendedDestination);
							destObj.setIpAddress(destIpAddress);
							if (StringUtil.isContains(recommendedDestination, currentDestinations)) {
								destObj.setCurrentValueFlag(FafFirewallRuleSourceIpObj.YES);
							}
							ruleSuggestion.getDestinationIPs().add(destObj);
						}
						String[] recommendedServices = suggestion.getService().getRecommendedValuesArray();
						String[] currentServices = suggestion.getService().getCurrentValuesArray();
						for (String recommendedService : recommendedServices) {
							FafFirewallRulePortObj portObj = new FafFirewallRulePortObj();
							portObj.setImplFafFirewallRule(ruleSuggestion);
							PortObject port = new PortObject();
							port.setService(recommendedService);
							if (StringUtil.isContains(recommendedService, currentServices)) {
								portObj.setCurrentValueFlag(FafFirewallRuleSourceIpObj.YES);
							}
							portObj.setPort(port);
							ruleSuggestion.getPorts().add(portObj);
						}
					}
					ruleSuggestions.put(key, ruleSuggestion);
				}
			}
			Set<String> keys = ruleSuggestions.keySet();
			for (String key : keys) {
				fafFirewallRuleSuggestions.add(ruleSuggestions.get(key));
			}
		} catch (Exception e) {
			throw new BusinessException("WO XML PARSING ERROR " + e.getMessage());
		}*/
		return fafFirewallRuleSuggestions;
	}

	@Override
	public void updateFireflowTicketStatus(FafFireflowTicket ticket, Cookie[] requestCookies) {
		
		String ticketNumber = null;
		try {
			log.info("Inside updateFireflowTicketStatus for TiRequestId "+ticket.getTiRequest().getId()+" FAFFireFlowTicket ID "+ticket.getId());
			HttpComponentsClientHttpRequestFactory factory = (HttpComponentsClientHttpRequestFactory) restTemplate.getRequestFactory();
//			DefaultHttpClient client = (DefaultHttpClient)factory.getHttpClient();
			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
			/*if (DEV_MODE.equalsIgnoreCase("False"))
				siteminderAuthentication(client, requestCookies);
			else
				userNamePasswordAuthentication(map);*/

			StringBuffer url = new StringBuffer();
			url.append(ALGOSEC_URL);
			url.append(ALGOSEC_CONTEXT); 
			url.append("ticket/" + ticket.getTicketNumber().trim());
			log.debug("url -->" + url);
		
			String content = "Queue: 1\n" + "Owner: " + ALGOSEC_USER + "\n" + "Creator: " + ALGOSEC_USER + "\n" + "Status: " + ticket.getStatus();
			map.add("content", content);
			String restResponse = restTemplate.postForObject(new URI(url.toString()), map, String.class);
			
			log.debug(" Ticket Update REST API Response :" + restResponse);
			
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - " + e.getMessage());
			e.printStackTrace();
			throw new ApplicationException(e.getMessage(),e);
		}	
		
/*		if ("FALSE".equalsIgnoreCase(DEV_MODE))
			return;
		

		try {
			log.debug("setting ticket status to :" + ticket.getStatus());
			StringBuffer url = new StringBuffer();
			url.append(ALGOSEC_URL);
			url.append(ALGOSEC_CONTEXT);
			url.append("ticket/" + ticket.getTicketNumber().trim());
			// url.append("/");
			// url.append(query);
			log.info("url -->" + url);
			URI uri;

			uri = new URI(url.toString());

			String content = "Queue: 1\n" + "Owner: " + ALGOSEC_USER + "\n" + "Creator: " + ALGOSEC_USER + "\n" + "Status: " + ticket.getStatus();
			PasswordEncryptDecrypt passwordEncryptDecrypt = new PasswordEncryptDecrypt();
			String pwd = passwordEncryptDecrypt.encrypt(ALGOSEC_PWD);
			pwd = passwordEncryptDecrypt.decrypt(pwd);
			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
			map.add("user", ALGOSEC_USER);
			map.add("pass", pwd);
			map.add("content", content);
			String restResponse = restTemplate.postForObject(uri, map, String.class);
			log.info("restResponse -->" + restResponse);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
*/
	}


}
