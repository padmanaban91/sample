/**
 *
 */
package com.citigroup.cgti.c3par.businessjustification.service;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.businessjustification.domain.soc.persist.EmerBuscritServicePersistable;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;

@SuppressWarnings("unchecked")
@Transactional
public class EmerBuscritServiceImpl extends BasePersistanceImpl implements
		EmerBuscritServicePersistable {

	private static Logger log = Logger.getLogger(EmerBuscritServiceImpl.class);

	/** The Constant TABLE. */
	public static final String TABLE = "PLANNING";

	/** The custom sequence. */
	private String customSequence;

	/** The database sequence. */
	private String databaseSequence;

	// Column names
	/** The Constant COLUMN_PLANNEDACTIVATEDATE. */
	public static final String COLUMN_PLANNEDACTIVATEDATE = "PLANNED_ACTIVATE_DATE";

	/** The Constant COLUMN_SECURITYREVIEWCOMMENT. */
	public static final String COLUMN_SECURITYREVIEWCOMMENT = "SECURITY_REVIEW_COMMENT";

	/** The Constant COLUMN_SECURITYREVIEWCOMMENT_LEN. */
	public static final int COLUMN_SECURITYREVIEWCOMMENT_LEN = 4000;

	/** The Constant COLUMN_SPONSORREVIEWCOMMENTS. */
	public static final String COLUMN_SPONSORREVIEWCOMMENTS = "SPONSOR_REVIEW_COMMENTS";

	/** The Constant COLUMN_SPONSORREVIEWCOMMENTS_LEN. */
	public static final int COLUMN_SPONSORREVIEWCOMMENTS_LEN = 4000;

	/** The Constant COLUMN_ACTIVATECONNECTIONCOMMENT. */
	public static final String COLUMN_ACTIVATECONNECTIONCOMMENT = "ACTIVATE_CONNECTION_COMMENT";

	/** The Constant COLUMN_ACTIVATECONNECTIONCOMMENT_LEN. */
	public static final int COLUMN_ACTIVATECONNECTIONCOMMENT_LEN = 4000;

	/** The Constant COLUMN_APPROVEDETAILDESIGNCOMMENT. */
	public static final String COLUMN_APPROVEDETAILDESIGNCOMMENT = "APPROVE_DETAIL_DESIGN_COMMENT";

	/** The Constant COLUMN_APPROVEDETAILDESIGNCOMMENT_LEN. */
	public static final int COLUMN_APPROVEDETAILDESIGNCOMMENT_LEN = 4000;

	/** The Constant COLUMN_INTEGRATIONCOMPLETED. */
	public static final String COLUMN_INTEGRATIONCOMPLETED = "INTEGRATION_COMPLETED";

	/** The Constant COLUMN_INTEGRATIONSTATUSCOMMENTS. */
	public static final String COLUMN_INTEGRATIONSTATUSCOMMENTS = "INTEGRATION_STATUS_COMMENTS";

	/** The Constant COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN. */
	public static final int COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN = 4000;

	/** The Constant COLUMN_PROCUREMENTDATE. */
	public static final String COLUMN_PROCUREMENTDATE = "PROCUREMENT_DATE";

	/** The Constant COLUMN_PROCUREMENTCOMMENTS. */
	public static final String COLUMN_PROCUREMENTCOMMENTS = "PROCUREMENT_COMMENTS";

	/** The Constant COLUMN_PROCUREMENTCOMMENTS_LEN. */
	public static final int COLUMN_PROCUREMENTCOMMENTS_LEN = 4000;

	/** The Constant COLUMN_PROCUREMENTOPTIONAL. */
	public static final String COLUMN_PROCUREMENTOPTIONAL = "PROCUREMENT_OPTIONAL";

	/** The Constant COLUMN_SYSTEMADMINCOMMENTS. */
	public static final String COLUMN_SYSTEMADMINCOMMENTS = "SYSTEM_ADMIN_COMMENTS";

	/** The Constant COLUMN_SYSTEMADMINCOMMENTS_LEN. */
	public static final int COLUMN_SYSTEMADMINCOMMENTS_LEN = 4000;

	/** The Constant COLUMN_OPERATIONALANALYSTCOMMENTS. */
	public static final String COLUMN_OPERATIONALANALYSTCOMMENTS = "OPERATIONAL_ANALYST_COMMENTS";

	/** The Constant COLUMN_OPERATIONALANALYSTCOMMENTS_LEN. */
	public static final int COLUMN_OPERATIONALANALYSTCOMMENTS_LEN = 4000;

	/** The Constant COLUMN_ISTGCOMMENTS. */
	public static final String COLUMN_ISTGCOMMENTS = "ISTG_COMMENTS";

	/** The Constant COLUMN_ISTGCOMMENTS_LEN. */
	public static final int COLUMN_ISTGCOMMENTS_LEN = 4000;

	/** The Constant COLUMN_INFOMANID. */
	public static final String COLUMN_INFOMANID = "INFOMAN_ID";

	/** The Constant COLUMN_OPANALYSTSCHEDULEDATE. */
	public static final String COLUMN_OPANALYSTSCHEDULEDATE = "OP_ANALYST_SCHEDULE_DATE";

	/** The Constant COLUMN_OPANALYSTCOMPLETEDDATE. */
	public static final String COLUMN_OPANALYSTCOMPLETEDDATE = "OP_ANALYST_COMPLETED_DATE";

	/** The Constant COLUMN_VAFLAG. */
	public static final String COLUMN_VAFLAG = "VA_FLAG";

	/** The Constant COLUMN_VAFLAG_LEN. */
	public static final int COLUMN_VAFLAG_LEN = 3;

	/** The Constant COLUMN_VANUMBER. */
	public static final String COLUMN_VANUMBER = "VA_NUMBER";

	/** The Constant COLUMN_VANUMBER_LEN. */
	public static final int COLUMN_VANUMBER_LEN = 20;

	/** The Constant COLUMN_VASCHDATE. */
	public static final String COLUMN_VASCHDATE = "VA_SCH_DATE";

	/** The Constant COLUMN_VACOMMENTS. */
	public static final String COLUMN_VACOMMENTS = "VA_COMMENTS";

	/** The Constant COLUMN_VACOMMENTS_LEN. */
	public static final int COLUMN_VACOMMENTS_LEN = 2000;

	/** The Constant COLUMN_ID. */
	public static final String COLUMN_ID = "ID";

	@Transactional(readOnly = true)
	public Long getPlanningIdForTiRequestId(Long tirequestid) {

		long planningId = 0;
		StringBuffer sql = new StringBuffer();

		if (tirequestid != null && tirequestid.longValue() > 0) {

			sql.append("select planning_id from c3par.ti_request_planning_xref where ti_request_id="
					+ tirequestid.longValue());

			Session session = getSession();

			planningId = ((BigDecimal) session.createSQLQuery(sql.toString())
					.list().get(0)).longValue();

			if (planningId == 0) {
				String planTermSQL = " select max(planning_id) from c3par.ti_request_planning_xref where ti_request_id in (select b.id from c3par.ti_request a ,c3par.ti_request b where a.id="
						+ tirequestid.longValue()
						+ "  and a.process_id=b.process_id ) ";

				planningId = ((BigDecimal) session.createSQLQuery(planTermSQL)
						.list().get(0)).longValue();
			}

		}
		return planningId;
	}

	@Transactional(readOnly = true)
	public Long updatePlanningPart(Planning planning) {

		String UPDATE_BY_ID_STMT = "UPDATE " + TABLE + " SET "
				+ COLUMN_PLANNEDACTIVATEDATE + " =  "
				+ planning.getPlannedActivateDate() + ", "
				+ COLUMN_SECURITYREVIEWCOMMENT + " =  "
				+ COLUMN_SECURITYREVIEWCOMMENT_LEN + ", "
				+ COLUMN_SPONSORREVIEWCOMMENTS + " =  "
				+ COLUMN_SPONSORREVIEWCOMMENTS_LEN + ", "
				+ COLUMN_ACTIVATECONNECTIONCOMMENT + " =  "
				+ COLUMN_ACTIVATECONNECTIONCOMMENT_LEN + ", "
				+ COLUMN_APPROVEDETAILDESIGNCOMMENT + " =  "
				+ COLUMN_APPROVEDETAILDESIGNCOMMENT_LEN + ", "
				+ COLUMN_INTEGRATIONCOMPLETED + " =  "
				+ planning.getIntegcompleted() + ", "
				+ COLUMN_INTEGRATIONSTATUSCOMMENTS + " =  "
				+ COLUMN_INTEGRATIONSTATUSCOMMENTS_LEN + ", "
				+ COLUMN_PROCUREMENTDATE + " =  "
				+ planning.getProcurementDate() + ", "
				+ COLUMN_PROCUREMENTCOMMENTS + " =  "
				+ COLUMN_PROCUREMENTCOMMENTS_LEN + ", "
				+ COLUMN_PROCUREMENTOPTIONAL + " =  "
				+ planning.getProcurementOptional() + ", "
				+ COLUMN_SYSTEMADMINCOMMENTS + " =  "
				+ COLUMN_SYSTEMADMINCOMMENTS_LEN + ", "
				+ COLUMN_OPERATIONALANALYSTCOMMENTS + " =  "
				+ COLUMN_OPERATIONALANALYSTCOMMENTS_LEN + ", "
				+ COLUMN_ISTGCOMMENTS + " =  " + COLUMN_ISTGCOMMENTS_LEN + ", "
				+ COLUMN_INFOMANID + " =  " + planning.getInfomanId() + ", "
				+ COLUMN_OPANALYSTSCHEDULEDATE + " =  "
				+ planning.getOpanalystScheduleDate() + ", "
				+ COLUMN_OPANALYSTCOMPLETEDDATE + " =  "
				+ planning.getOpanalystCompletedDate() + ", " + COLUMN_VAFLAG
				+ " =  " + COLUMN_VAFLAG_LEN + ", " + COLUMN_VANUMBER + " =  "
				+ COLUMN_VANUMBER_LEN + ", " + COLUMN_VASCHDATE + " =  "
				+ planning.getVaschDate() + ", " + COLUMN_VACOMMENTS + " =  "
				+ COLUMN_VACOMMENTS_LEN + " WHERE " + COLUMN_ID + " = "
				+ planning.getId();

		Session session = getSession();

		return ((BigDecimal) session.createSQLQuery(UPDATE_BY_ID_STMT).list()
				.get(0)).longValue();

	}

	@Transactional(readOnly = true)
	public void loadPlanningPart(Planning planning) {

		/** The SELEC t_ stmt. */
		String SELECT_STMT = "SELECT " + COLUMN_ID + ", "
				+ COLUMN_PLANNEDACTIVATEDATE + ", "
				+ COLUMN_SECURITYREVIEWCOMMENT + ", "
				+ COLUMN_SPONSORREVIEWCOMMENTS + ", "
				+ COLUMN_ACTIVATECONNECTIONCOMMENT + ", "
				+ COLUMN_APPROVEDETAILDESIGNCOMMENT + ", "
				+ COLUMN_INTEGRATIONCOMPLETED + ", "
				+ COLUMN_INTEGRATIONSTATUSCOMMENTS + ", "
				+ COLUMN_PROCUREMENTDATE + ", " + COLUMN_PROCUREMENTCOMMENTS
				+ ", " + COLUMN_PROCUREMENTOPTIONAL + ", "
				+ COLUMN_SYSTEMADMINCOMMENTS + ", "
				+ COLUMN_OPERATIONALANALYSTCOMMENTS + ", "
				+ COLUMN_ISTGCOMMENTS + ", " + COLUMN_INFOMANID + ", "
				+ COLUMN_OPANALYSTSCHEDULEDATE + ", "
				+ COLUMN_OPANALYSTCOMPLETEDDATE + ", " + COLUMN_VAFLAG + ", "
				+ COLUMN_VANUMBER + ", " + COLUMN_VASCHDATE + ", "
				+ COLUMN_VACOMMENTS + " FROM " + TABLE;

		/** The SELEC t_ b y_ i d_ stmt. */
		String SELECT_BY_ID_STMT = SELECT_STMT + " WHERE " + COLUMN_ID + " = "
				+ planning.getId();

		Session session = getSession();
		
		List list = session.createSQLQuery(SELECT_BY_ID_STMT).list();

	}

	@Transactional(readOnly = true)
	public boolean isDirectorPresent(Long planningId) {

		boolean directorPresent = false;

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT 1 FROM C3PAR.CON_REQ_CITI_CONTACT_XREF CRCCX, ROLE RL, citi_contact cc ");
		sql.append("WHERE ");
		sql.append("CRCCX.REQUEST_ID= " + planningId.longValue() + " AND ");
		sql.append("RL.ID=CRCCX.ROLE_ID AND ");
		sql.append("LOWER(RL.NAME)=LOWER('Director') AND ");
		sql.append("CC.ID= CRCCX.CITI_CONTACT_ID AND ");
		sql.append("UPPER(DECODE(CC.EMPLOYEE_TYPE,NULL,'C',CC.EMPLOYEE_TYPE))= 'E' AND ");
		sql.append("CRCCX.PRIMARY_CONTACT='Y' AND ");
		sql.append("crccx.notify_contact='Y'");
		sql.append("UNION ");
		sql.append("SELECT 1 FROM C3PAR.CON_REQ_CIT_RQCON_XREF CRCCX, ROLE RL , citi_contact cc ");
		sql.append("WHERE ");
		sql.append("CRCCX.REQUEST_ID=" + planningId.longValue() + " AND ");
		sql.append("RL.ID=CRCCX.ROLE_ID AND ");
		sql.append("LOWER(RL.NAME)=LOWER('Director') AND ");
		sql.append("CC.ID= CRCCX.CITI_CONTACT_ID AND ");
		sql.append("UPPER(DECODE(CC.EMPLOYEE_TYPE,NULL,'C',CC.EMPLOYEE_TYPE))= 'E' AND ");
		sql.append("CRCCX.PRIMARY_CONTACT='Y'  AND ");
		sql.append("crccx.notify_contact='Y'");

		log.debug("sql:-" + sql.toString());

		Session session = getSession();

		directorPresent = session.createSQLQuery(sql.toString()).list().size() > 0;

		return directorPresent;
	}

	@Transactional(readOnly = true)
	public String getRelationshipType(Long conReqId) {

		String relationshipType = null;

		String sql = "SELECT B.RELATIONSHIP_TYPE FROM CON_REQ A,RELATIONSHIP B WHERE A.RELATIONSHIP_ID=B.ID AND A.ID="
				+ conReqId;
		Session session = getSession();

		relationshipType = (String) session.createSQLQuery(sql.toString())
				.list().get(0);

		relationshipType = (relationshipType == null) ? "" : relationshipType
				.trim();

		return relationshipType;

	}

	@Transactional(readOnly = true)
	public String getPriority(Long priorityId) {

		String priority = null;
		StringBuffer sql = new StringBuffer();

		sql.append("SELECT  VALUE1 FROM GENERIC_LOOKUP where ID=" + priorityId);
		Session session = getSession();

		priority = (String) session.createSQLQuery(sql.toString()).list()
				.get(0);

		priority = (priority == null) ? "" : priority;

		return priority;

	}

}
