package com.citigroup.cgti.c3par.fw.fireflow.client;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.net.ssl.TrustManager;

/*import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;*/

import com.citigroup.cgti.c3par.util.C3parProperties;

;

public class FireflowHttpClient/* extends DefaultHttpClient*/ {

	public FireflowHttpClient() {

//		super(getMyConnectionManager());

	}

	/*private static ThreadSafeClientConnManager getMyConnectionManager() {
		ThreadSafeClientConnManager connectionManager = null;
		try {
			javax.net.ssl.SSLContext context = javax.net.ssl.SSLContext
					.getInstance("SSL");

			KeyStore clientTrustStore = getKeyStore(C3parProperties.CLIENT_TRUSTSTORE,
					C3parProperties.CLIENT_TRUSTSTORE_PWD);
			KeyStore serverTrustStore = getKeyStore(null, C3parProperties.SERVER_TRUSTSTORE_PWD);
			context.init(null, new TrustManager[] {
					new FireflowX509TrustManager(clientTrustStore),
					new FireflowX509TrustManager(serverTrustStore) }, null);
			SSLSocketFactory factory = new SSLSocketFactory(context,
					new AllowAllHostnameVerifier());
			SchemeRegistry schemeRegistry = new SchemeRegistry();
			schemeRegistry.register(new Scheme("https", 443, factory));
			connectionManager = new ThreadSafeClientConnManager(schemeRegistry);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connectionManager;
	}*/

	private static KeyStore getKeyStore(String keyStorePath, String passwordStr)
			throws KeyStoreException {
		KeyStore ks = null;
		//Null keyStores are handled by the downstream classes
		if (keyStorePath == null)
			return null;
		try {
			ks = KeyStore.getInstance("JKS");
			// get user password and file input stream
			char[] password = passwordStr.toCharArray();
			java.io.FileInputStream fis = new java.io.FileInputStream(
					keyStorePath);
			ks.load(fis, password);
			fis.close();
		} catch (FileNotFoundException e) {
			throw new KeyStoreException(e.getMessage(), e);
		} catch (NoSuchAlgorithmException e) {
			throw new KeyStoreException(e.getMessage(), e);
		} catch (CertificateException e) {
			throw new KeyStoreException(e.getMessage(), e);
		} catch (IOException e) {
			throw new KeyStoreException(e.getMessage(), e);
		}
		return ks;
	}

}
