/**
 * 
 */
package com.citigroup.cgti.c3par.webtier.job;

/**
 * @author ka58098
 *
 */
public class JobCronExpression {

    private String migrationServiceJob;
    private String scheduleAndACVExpirationMailJob;
    private String accessFormRemainderJob;
    private String approvalRemainderMailJob;
    private String citiContactUpdateJob;
    private String citiContactRefreshJob;
    private String clearReportTablesJob;
    private String jobDetailUserGroup;
    private String activityExpirationRemainderMailJob;
    private String acvInitiateJob;
    private String csiApplicationSynchJob;
    private String rfcNetInfoScheduler;
    private String jobDetailSN;
    private String jobDetail1WeekNTP;
    /**
     * @return the migrationServiceJob
     */
    public String getMigrationServiceJob() {
        return migrationServiceJob;
    }
    /**
     * @param migrationServiceJob the migrationServiceJob to set
     */
    public void setMigrationServiceJob(String migrationServiceJob) {
        this.migrationServiceJob = migrationServiceJob;
    }
    /**
     * @return the scheduleAndACVExpirationMailJob
     */
    public String getScheduleAndACVExpirationMailJob() {
        return scheduleAndACVExpirationMailJob;
    }
    /**
     * @param scheduleAndACVExpirationMailJob the scheduleAndACVExpirationMailJob to set
     */
    public void setScheduleAndACVExpirationMailJob(String scheduleAndACVExpirationMailJob) {
        this.scheduleAndACVExpirationMailJob = scheduleAndACVExpirationMailJob;
    }
    /**
     * @return the accessFormRemainderJob
     */
    public String getAccessFormRemainderJob() {
        return accessFormRemainderJob;
    }
    /**
     * @param accessFormRemainderJob the accessFormRemainderJob to set
     */
    public void setAccessFormRemainderJob(String accessFormRemainderJob) {
        this.accessFormRemainderJob = accessFormRemainderJob;
    }
    /**
     * @return the approvalRemainderMailJob
     */
    public String getApprovalRemainderMailJob() {
        return approvalRemainderMailJob;
    }
    /**
     * @param approvalRemainderMailJob the approvalRemainderMailJob to set
     */
    public void setApprovalRemainderMailJob(String approvalRemainderMailJob) {
        this.approvalRemainderMailJob = approvalRemainderMailJob;
    }
    /**
     * @return the citiContactUpdateJob
     */
    public String getCitiContactUpdateJob() {
        return citiContactUpdateJob;
    }
    /**
     * @param citiContactUpdateJob the citiContactUpdateJob to set
     */
    public void setCitiContactUpdateJob(String citiContactUpdateJob) {
        this.citiContactUpdateJob = citiContactUpdateJob;
    }
    /**
     * @return the citiContactRefreshJob
     */
    public String getCitiContactRefreshJob() {
        return citiContactRefreshJob;
    }
    /**
     * @param citiContactRefreshJob the citiContactRefreshJob to set
     */
    public void setCitiContactRefreshJob(String citiContactRefreshJob) {
        this.citiContactRefreshJob = citiContactRefreshJob;
    }
    /**
     * @return the clearReportTablesJob
     */
    public String getClearReportTablesJob() {
        return clearReportTablesJob;
    }
    /**
     * @param clearReportTablesJob the clearReportTablesJob to set
     */
    public void setClearReportTablesJob(String clearReportTablesJob) {
        this.clearReportTablesJob = clearReportTablesJob;
    }
    /**
     * @return the jobDetailUserGroup
     */
    public String getJobDetailUserGroup() {
        return jobDetailUserGroup;
    }
    /**
     * @param jobDetailUserGroup the jobDetailUserGroup to set
     */
    public void setJobDetailUserGroup(String jobDetailUserGroup) {
        this.jobDetailUserGroup = jobDetailUserGroup;
    }
    /**
     * @return the activityExpirationRemainderMailJob
     */
    public String getActivityExpirationRemainderMailJob() {
        return activityExpirationRemainderMailJob;
    }
    /**
     * @param activityExpirationRemainderMailJob the activityExpirationRemainderMailJob to set
     */
    public void setActivityExpirationRemainderMailJob(String activityExpirationRemainderMailJob) {
        this.activityExpirationRemainderMailJob = activityExpirationRemainderMailJob;
    }
    /**
     * @return the acvInitiateJob
     */
    public String getAcvInitiateJob() {
        return acvInitiateJob;
    }
    /**
     * @param acvInitiateJob the acvInitiateJob to set
     */
    public void setAcvInitiateJob(String acvInitiateJob) {
        this.acvInitiateJob = acvInitiateJob;
    }
    /**
     * @return the csiApplicationSynchJob
     */
    public String getCsiApplicationSynchJob() {
        return csiApplicationSynchJob;
    }
    /**
     * @param csiApplicationSynchJob the csiApplicationSynchJob to set
     */
    public void setCsiApplicationSynchJob(String csiApplicationSynchJob) {
        this.csiApplicationSynchJob = csiApplicationSynchJob;
    }
    /**
     * @return the rfcNetInfoScheduler
     */
    public String getRfcNetInfoScheduler() {
        return rfcNetInfoScheduler;
    }
    /**
     * @param rfcNetInfoScheduler the rfcNetInfoScheduler to set
     */
    public void setRfcNetInfoScheduler(String rfcNetInfoScheduler) {
        this.rfcNetInfoScheduler = rfcNetInfoScheduler;
    }
    /**
     * @return the jobDetailSN
     */
    public String getJobDetailSN() {
        return jobDetailSN;
    }
    /**
     * @param jobDetailSN the jobDetailSN to set
     */
    public void setJobDetailSN(String jobDetailSN) {
        this.jobDetailSN = jobDetailSN;
    }
    /**
     * @return the jobDetail1WeekNTP
     */
    public String getJobDetail1WeekNTP() {
        return jobDetail1WeekNTP;
    }
    /**
     * @param jobDetail1WeekNTP the jobDetail1WeekNTP to set
     */
    public void setJobDetail1WeekNTP(String jobDetail1WeekNTP) {
        this.jobDetail1WeekNTP = jobDetail1WeekNTP;
    }
    
    
}
