package com.citigroup.cgti.c3par.communication.service;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.internal.SessionImpl;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.TIActivityTrail;
import com.citigroup.cgti.c3par.communication.domain.AgentViewProcess;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CmpConnectionDetail;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.AgentViewPersistable;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.EmailGenerationViewServicePersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.reports.util.Util;

import oracle.jdbc.OracleTypes;
@Transactional
public class AgentViewImpl extends BasePersistanceImpl implements
		AgentViewPersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(AgentViewImpl.class);

	private EmailGenerationViewServicePersistable emailGenViewServicePersistable;

	public EmailGenerationViewServicePersistable getEmailGenViewServicePersistable() {
		return emailGenViewServicePersistable;
	}

	public void setEmailGenViewServicePersistable(
			EmailGenerationViewServicePersistable emailGenViewServicePersistable) {
		this.emailGenViewServicePersistable = emailGenViewServicePersistable;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public List<CMPRequest> getCmpReqData(AgentViewProcess agentViewProcess) {

		Session session = getSession();
		String orderBy = agentViewProcess.getOrderBy();

		String sortingColumnName = agentViewProcess.getSortingColumnName();

		Criteria criteria = session.createCriteria(CMPRequest.class);
		criteria.add(Restrictions.eq("assignedUser.id",
				agentViewProcess.getAgent()));
		criteria.add(Restrictions.eq("status","In Progress"));
		agentViewProcess.setTotalRecords(criteria.list().size());
		if(sortingColumnName != "CURRENT STATUS"){
			addPagination(criteria, agentViewProcess.getOffset(),
					agentViewProcess.getLimit());
			}

		log.debug("OrderBy passed: " + agentViewProcess.getOrderBy());
		log.debug("Column Name passed: "
				+ agentViewProcess.getSortingColumnName());

		

		if (orderBy != null && sortingColumnName != null) {
			
			if ("asc".equals(orderBy)) {
				if (sortingColumnName != null
						&& !sortingColumnName.equals("")
						&& sortingColumnName
								.equals("typeofConnectivityInvolved")) {
					criteria.addOrder(Order.asc("typeofConnectivityInvolved"))
							.addOrder(Order.asc("requestType"));
					log.debug("inside AgentViewImpl:typeofConnectivityInvolved "
							+ sortingColumnName);
				} else {
					if(sortingColumnName != "CURRENT STATUS"){
						criteria.addOrder(Order.asc(sortingColumnName));
						}
				}

			} else if ("desc".equals(orderBy)) {

				if (sortingColumnName != null
						&& !sortingColumnName.equals("")
						&& sortingColumnName
								.equals("typeofConnectivityInvolved")) {
					criteria.addOrder(Order.desc("typeofConnectivityInvolved"))
							.addOrder(Order.desc("requestType"));
					log.debug("inside AgentViewImpl:typeofConnectivityInvolved "
							+ sortingColumnName);
				} else {
					if(sortingColumnName != "CURRENT STATUS"){
						criteria.addOrder(Order.desc(sortingColumnName));
						}
				}

			}
			

		}
		
		List<CMPRequest> cmplist = criteria.list();
		for (CMPRequest cmp : cmplist) {
			SQLQuery resolvtItquery = session
					.createSQLQuery("select Rt.Ti_Request_Id, cr.id,Cr.Order_Item_Id from Resolve_It_Notify_Log rt , Cmp_Request cr, Ti_Activity_Trail ta where Rt.Cmp_Request_Id = Cr.Id and Rt.Ti_Request_Id = Ta.Ti_Request_Id and cr.id ="
							+ cmp.getId());
			log.debug("Querying String::getCurrentCounts::" + resolvtItquery);
			List<Object[]> resolveItobj = resolvtItquery.list();
			log.debug("is resolveItobj::getCmpReqData::" + resolveItobj.size());
			
			StringBuilder sqlQuery = new StringBuilder("select * from (select * from TI_ACTIVITY_TRAIL where CMP_ID = " +cmp.getId());
			StringBuilder tiRequestId = new StringBuilder("");

			if (resolvtItquery.list().size() > 0) {
				cmp.setCheckTiId("Y");
				
				for(Object[] rs : resolveItobj){
					if(tiRequestId != null && tiRequestId.length() > 0){
						tiRequestId.append(", " +rs[0].toString());
					}
					else{
						tiRequestId.append(rs[0].toString());
					}					
				}
			}
			else {
				cmp.setCheckTiId("N");
			}
			
			if(tiRequestId != null && tiRequestId.length() > 0){
				sqlQuery.append(" union select * from TI_ACTIVITY_TRAIL where TI_REQUEST_ID in (" +tiRequestId.toString().trim()+ ")");
			}
			sqlQuery.append(") TAT order by ID desc");

			SQLQuery query = session.createSQLQuery(sqlQuery.toString());
			query.addEntity("TAT", TIActivityTrail.class);
			cmp.setTiactivityTrail(query.list());
			
			List<TIActivityTrail> tiActivityList = (List<TIActivityTrail>)query.list();                   
            if(tiActivityList != null && !tiActivityList.isEmpty()){
            	if(tiActivityList.get(0)!=null){
            		if(tiActivityList.get(0).getActivity()!=null){
            			if(tiActivityList.get(0).getActivity().getTask()!=null){
                    cmp.setCurrentStatus(tiActivityList.get(0).getActivity().getTask());
            	}
            		}
            	}
            }
			
			lazyInitialize(cmp.getCmpRequestNotes());
			if (cmp.getCcrId() != null && !cmp.getCcrId().isEmpty()) {
				if(cmp.getCcrId().indexOf(".") > 0){
					if(cmp.getCcrId()!= null && !StringUtils.isEmpty(cmp.getCcrId()) && !StringUtils.isBlank(cmp.getCcrId().trim())){
						cmp.setCcrId(Util.filterCCRId(cmp.getCcrId().trim()));
						}
				}
				cmp.setChangeRequestDetails(emailGenViewServicePersistable
						.getChangeRequestDetails(Long.valueOf(cmp.getCcrId().trim()),cmp.getOrderId()));
			}

			CallableStatement callstm = null; 
			try {
				int time = 0;
				String procedureCall = "{call CALCULATE_ACTIVITY_TIME(?,?,?)}";
				callstm = ((SessionImpl) getSession()).connection()
						.prepareCall(procedureCall);
				callstm.setLong(1, cmp.getId());
				callstm.setString(2, "ECM TIMER");
				callstm.registerOutParameter(3, OracleTypes.BIGINT);
				callstm.executeUpdate();
				time = callstm.getBigDecimal(3).intValue();
				cmp.setEcmTimer(Long.valueOf(time));
			} catch (SQLException ex) {
				log.error(ex.getMessage());
			}

		}
		if (sortingColumnName.equals("CURRENT STATUS") && cmplist.size() > 0) {
			
			if ("desc".equals(orderBy)) {
            Collections.sort(cmplist, new Comparator<CMPRequest>() {
    public int compare(final CMPRequest cmp1, final CMPRequest cmp2) {
    	if(cmp2.getCurrentStatus() !=null && cmp1.getCurrentStatus() != null){
        return cmp1.getCurrentStatus().compareTo(cmp2.getCurrentStatus());
    	}else
    	return 0;
    }
   } );
   
    }else{
    	Collections.sort(cmplist, new Comparator<CMPRequest>() {
    	    public int compare(final CMPRequest cmp1, final CMPRequest cmp2) {
    	    	if(cmp2.getCurrentStatus() !=null && cmp1.getCurrentStatus() != null){
    	        return cmp2.getCurrentStatus().compareTo(cmp1.getCurrentStatus());
    	    	}else
    	    	return 0;
    	    }
    	   } );
    	
    }
			if (cmplist != null)
				log.debug("AgentViewImpl :: getCmpData :: size ::" + cmplist.size()+"and total records-->"+ agentViewProcess.getTotalRecords());	
			
			List<CMPRequest> tempCmpList = new ArrayList<CMPRequest>();
			int count = 0;
			for(CMPRequest tempRequest: cmplist) {
				
				if( agentViewProcess.getOffset() <= count &&  (agentViewProcess.getOffset() + agentViewProcess.getLimit()) >= count ) {
					log.debug("The Value of i..>" + count);
					tempCmpList.add(tempRequest);
				}
				count++;
			}
			
			if (tempCmpList.size() > 1) {
				log.debug("NEW CMP List Size..>" + tempCmpList.size());
				cmplist = tempCmpList;
			}
		}
		
		Long avg = 0L;
		SQLQuery avgquery = session
				.createSQLQuery("select id  from Cmp_Request where Assigned_User ="
						+ agentViewProcess.getAgent()
						+ "and status = 'Completed'");
		log.debug("Querying String::getCurrentCounts::" + avgquery);
		avgquery.addScalar("id", LongType.INSTANCE);
		List<Long> avgobj = avgquery.list();
		log.debug("Average is obj::getCmpReqData::" + avgobj.size());
		for (Long o1 : avgobj) {

			CallableStatement callstmn = null;
			try {
				int time = 0;
				String procedureCall = "{call CALCULATE_ACTIVITY_TIME(?,?,?)}";
				callstmn = ((SessionImpl) getSession()).connection()
						.prepareCall(procedureCall);
				callstmn.setLong(1, o1);
				callstmn.setString(2, "ECM TIMER");
				callstmn.registerOutParameter(3, OracleTypes.BIGINT);
				callstmn.executeUpdate();
				time = callstmn.getBigDecimal(3).intValue();
				log.debug("time::agentview::avg" + time);
				avg = avg + time;
				log.debug("sum of ecm timers::" + avg);
				} catch (SQLException ex) {
				log.error(ex, ex);
			}

		}if(avgobj.size() > 0){
		avg = avg / avgobj.size();
		log.debug("avg of ecm timers::" + avg);
		log.debug("setAvg::EcmTimer::" + avg);
		}
		agentViewProcess.setAvg(avg);

		SQLQuery query = session
				.createSQLQuery("select count(TYPE_OF_CONN_INVOLVED) CONNTYPE,TYPE_OF_CONN_INVOLVED  from cmp_request where type_of_conn_involved is not null and Assigned_User = "
						+ agentViewProcess.getAgent() + "and status = 'In Progress' and request_type !='Assistance Request'"
						+ "group by Type_Of_Conn_Involved" );
		log.debug("Querying String::getCurrentCounts::" + query); 
		query.addScalar("CONNTYPE", LongType.INSTANCE);
		query.addScalar("TYPE_OF_CONN_INVOLVED", StringType.INSTANCE);
		List<Object[]> obj = query.list();
		log.debug("is obj::getCmpReqData::" + obj.size());
		for (Object[] o1 : obj) {
			if (("Firewall").equalsIgnoreCase(o1[1].toString())) {
				agentViewProcess.setFw((Long) o1[0]);
			}
			if (("Proxy").equalsIgnoreCase(o1[1].toString())) {   
				agentViewProcess.setProxy((Long) o1[0]);
			}
			if (("IP Registration").equalsIgnoreCase(o1[1].toString())) {
				agentViewProcess.setIpReg((Long) o1[0]);
			}

		}

		SQLQuery query1 = session
				.createSQLQuery("select count(status) sta , status from Cmp_Request where status is not null and Assigned_User ="
						+ agentViewProcess.getAgent() + " group by status");
		log.debug("Querying1 String::getCurrentCounts::" + query1);
		query1.addScalar("sta", LongType.INSTANCE);
		query1.addScalar("status", StringType.INSTANCE);

		List<Object[]> obj1 = query1.list();
		log.debug("is obj1::getCmpReqData::" + obj1.size());
		agentViewProcess
				.setAllInProgress(agentViewProcess.getAllInProgress() == null ? 0
						: agentViewProcess.getAllInProgress());
		for (Object[] o2 : obj1) {
			if (("Cancelled").equalsIgnoreCase(o2[1].toString())) {
				agentViewProcess.setCanc((Long) o2[0]);

			}
			if (("Completed").equalsIgnoreCase(o2[1].toString())) { 
				agentViewProcess.setComp((Long) o2[0]);
			}
			
			if (("In Progress").equalsIgnoreCase(o2[1].toString())) {
				agentViewProcess.setAllInProgress((Long) o2[0]); 
			}
		}

		SQLQuery query2 = session
				.createSQLQuery("select count(Request_Type) REQTYP, Request_Type from Cmp_Request where Request_Type is not null and Assigned_User ="
						+ agentViewProcess.getAgent() + "group by Request_Type");
		log.debug("Querying2 String::getCurrentCounts::" + query2);
		query2.addScalar("REQTYP", LongType.INSTANCE);
		query2.addScalar("Request_Type", StringType.INSTANCE);

		List<Object[]> obj2 = query2.list();
		log.debug("is obj2::getCmpReqData::" + obj2.size());
		for (Object[] o3 : obj2) {
			if (("Termination").equalsIgnoreCase(o3[1].toString())) {
				agentViewProcess.setTerm((Long) o3[0]);

			}
			if (("Assistance Request").equalsIgnoreCase(o3[1].toString())) {
					agentViewProcess.setAssist((Long) o3[0]);
			}
		}
		
		SQLQuery sectorQuery = session
				.createSQLQuery("select Queue_Name from Ecm_Queue EQ,Ecm_Queue_Users EQU,Cmp_Request CR where Equ.User_Id ="+ agentViewProcess.getAgent() + " and equ.ECM_QUEUE_ID = eq.id");
		log.debug("Querying2 String::getCurrentCounts::" + sectorQuery);
		sectorQuery.addScalar("Queue_Name", StringType.INSTANCE);
		List<String> sectorObj = sectorQuery.list();
		log.debug("is sectorObj::getCmpReqData::" + sectorObj.size());
		for (String o4 : sectorObj) {
			agentViewProcess.setSectorAgent(o4);
		}
		agentViewProcess.setFw(agentViewProcess.getFw() == null ? 0
				: agentViewProcess.getFw());
		agentViewProcess.setProxy(agentViewProcess.getProxy() == null ? 0
				: agentViewProcess.getProxy());
		agentViewProcess.setIpReg(agentViewProcess.getIpReg() == null ? 0
				: agentViewProcess.getIpReg());
		agentViewProcess.setTerm(agentViewProcess.getTerm() == null ? 0
				: agentViewProcess.getTerm());
		agentViewProcess.setAssist(agentViewProcess.getAssist() == null ? 0
				: agentViewProcess.getAssist());
		agentViewProcess.setCanc(agentViewProcess.getCanc() == null ? 0
				: agentViewProcess.getCanc());
		agentViewProcess.setComp(agentViewProcess.getComp() == null ? 0
				: agentViewProcess.getComp());
		
		return cmplist;
	}
	@Transactional(readOnly = true)
	public List<CmpConnectionDetail> getProcessList(String ccrId) {
		log.info("CmpConnectionDetailsImpl.getProcessList method started: ");
		Session session = getSession();
		List<CmpConnectionDetail> processList = new ArrayList<CmpConnectionDetail>();
		try {
			String queryString = "SELECT  DISTINCT "
					+ "PROC.ID AS ID,PROC.VERSION_NUMBER AS VERSION_NUMBER, "
					+ "PROC.ID ||'.'|| PROC.VERSION_NUMBER AS DISPLAY_ID , "
					+ "PROCESS_NAME AS NAME,T.ACTIVITY_TYPE AS STATUS, "
					+ "CASE WHEN REQTY.REQUEST_TYPE = 'Create' THEN 'Planning' "
					+ "WHEN REQTY.REQUEST_TYPE = 'Maintain' THEN 'Maintenance' "
					+ "WHEN UPPER(REQTY.REQUEST_TYPE) = 'ACV' THEN 'ACV' "
					+ "WHEN REQTY.REQUEST_TYPE = 'ManageContacts' THEN 'Maintain Contacts' "
					+ "WHEN REQTY.REQUEST_TYPE = 'Terminate' THEN 'Termination' END AS PHASE, "
					+ "T.ACTIVITY_MODE AS TYPE, "
					+ "CASE WHEN PROC.PROCESS_TYPE_ID = 1 THEN 'Connection' "
					+ "WHEN PROC.PROCESS_TYPE_ID = 2 THEN 'IPRegistration' END AS TI_PROCESS, "
					+ "CASE WHEN t.activity_type= 'PROVIDEINFO' THEN role_info.name "
					+ "ELSE  role_app.name END as role,g_l.value1 as priority,lockedby_user.sso_id participant, "
					+ "req.id req_id, t.bpm_instance_id bpmInstanceId,task_type.albpm_activity_id albpmActivityId, task_type.task  task, tpt.BPM_PROCESS_NAME bpmProcessName,task_type.task_code taskcode "
					+ "FROM "
					+ "C3PAR.TI_PROCESS PROC "
					+ "JOIN  C3PAR.TI_PROCESS_TYPE TPT ON PROC.PROCESS_TYPE_ID=TPT.ID "
					+ "JOIN C3PAR.TI_REQUEST REQ ON PROC.ID = REQ.PROCESS_ID AND PROC.VERSION_NUMBER=REQ.VERSION_NUMBER "
					+ "JOIN C3PAR.TI_REQUEST_TYPE REQTY ON REQ.TI_REQUEST_TYPE_ID = REQTY.ID  "
					+ "JOIN C3PAR.TI_ACTIVITY_TRAIL T ON REQ.ID=T.TI_REQUEST_ID  "
					+ "LEFT JOIN C3PAR.ROLE  ROLE_APP ON ROLE_APP.ID = T.USER_ROLE_ID  "
					+ "LEFT JOIN C3PAR.ROLE  ROLE_INFO ON ROLE_INFO.ID = T.INFOUSER_ROLE_ID "
					+ "JOIN C3PAR.TI_TASK_TYPE TASK_TYPE ON TASK_TYPE.ID = T.ACTIVITY_ID "
					+ "JOIN C3PAR.GENERIC_LOOKUP G_L ON G_L.ID = REQ.PRIORITY_ID "
					+ "LEFT JOIN C3PAR.C3PAR_USERS LOCKEDBY_USER ON LOCKEDBY_USER.ID=T.LOCKEDBY "
					+ "JOIN C3PAR.RELATIONSHIP REL ON REL.ID=PROC.RELATIONSHIP_ID "
					+ "JOIN REL_CITI_HIERARCHY_XREF RELXREF ON REL.ID=RELXREF.RELATIONSHIP_ID "
					+ "JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=RELXREF.CITI_HIERARCHY_MASTER_ID "
					+ "LEFT JOIN C3PAR.CO_LOOKUP_DATA L ON L.ID = REL.LOOKUP_ID "
					+ "LEFT JOIN C3PAR.THIRD_PARTY THP ON REL.THIRD_PARTY_ID = THP.ID AND REL.RELATIONSHIP_TYPE ='THIRD_PARTY' "
					+ "LEFT JOIN BUSINESS_UNIT BU ON CITIMASTER.BU_ID=BU.ID "
					+ "LEFT JOIN (SELECT R.ID RELID,S1.ID SECID FROM C3PAR.RELATIONSHIP R  "
					+ "JOIN REL_CITI_HIERARCHY_XREF RELXREF ON R.ID=RELXREF.RELATIONSHIP_ID "
					+ "JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=RELXREF.CITI_HIERARCHY_MASTER_ID "
					+ "JOIN SECTOR S1 ON CITIMASTER.SECTOR_ID=S1.ID)SECT ON SECT.RELID=REL.ID "
					+ "LEFT JOIN (SELECT R.ID RELID, R1.ID REGID FROM "
					+ "C3PAR.RELATIONSHIP R "
					+ "JOIN REL_CITI_HIERARCHY_XREF RELXREF ON R.ID=RELXREF.RELATIONSHIP_ID "
					+ "JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=RELXREF.CITI_HIERARCHY_MASTER_ID "
					+ "JOIN REGION R1 ON CITIMASTER.REGION_ID=R1.ID)REG ON REG.RELID=REL.ID "
					+ "LEFT JOIN C3PAR_USERS REQ_SSO ON REQ_SSO.ID=REQ.USER_ID "
					+ "WHERE PROC.IS_DELETED = 'N' AND "
					+ "T.ACTIVITY_STATUS IN('SCHEDULED','END') AND TRIM(PROC.ID) ='"
					+ ccrId + "' ";

			SQLQuery sqlquery = session.createSQLQuery(queryString.toString());
			sqlquery.addScalar("ID", LongType.INSTANCE);
			sqlquery.addScalar("VERSION_NUMBER", LongType.INSTANCE);
			sqlquery.addScalar("DISPLAY_ID", StringType.INSTANCE);
			sqlquery.addScalar("NAME", StringType.INSTANCE);
			sqlquery.addScalar("STATUS", StringType.INSTANCE);
			sqlquery.addScalar("PHASE", StringType.INSTANCE);
			sqlquery.addScalar("TYPE", StringType.INSTANCE);
			sqlquery.addScalar("TI_PROCESS", StringType.INSTANCE);
			sqlquery.addScalar("role", StringType.INSTANCE);
			sqlquery.addScalar("priority", StringType.INSTANCE);
			sqlquery.addScalar("participant", StringType.INSTANCE);
			sqlquery.addScalar("req_id", LongType.INSTANCE);
			sqlquery.addScalar("bpmInstanceId", StringType.INSTANCE);
			sqlquery.addScalar("albpmActivityId", StringType.INSTANCE);
			sqlquery.addScalar("task", StringType.INSTANCE);
			sqlquery.addScalar("bpmProcessName", StringType.INSTANCE);
			sqlquery.addScalar("taskcode", StringType.INSTANCE);

			@SuppressWarnings("unchecked")
			List<Object[]> resultList = sqlquery.list();
			processList = new ArrayList<CmpConnectionDetail>();
			CmpConnectionDetail cmpConnectionDetail = null;
			if (resultList != null) {
				for (Object[] result : resultList) {

					cmpConnectionDetail = new CmpConnectionDetail();
					cmpConnectionDetail.setId((Long) result[0]);
					cmpConnectionDetail.setVersion_number(Long
							.valueOf((Long) result[1]));
					cmpConnectionDetail.setDisplay_id((String) result[2]);
					cmpConnectionDetail.setName((String) result[3]);
					cmpConnectionDetail.setStatus((String) result[4]);
					cmpConnectionDetail.setPhase((String) result[5]);
					cmpConnectionDetail.setType((String) result[6]);
					cmpConnectionDetail.setTiProcess((String) result[7]);
					cmpConnectionDetail.setRole((String) result[8]);
					cmpConnectionDetail.setPriority((String) result[9]);
					cmpConnectionDetail.setParticipant((String) result[10]);
					cmpConnectionDetail.setTirequestid(Long
							.valueOf((Long) result[11]));
					cmpConnectionDetail.setBmpInstanceId((String) result[12]);
					cmpConnectionDetail.setBpmActivityId((String) result[13]);
					cmpConnectionDetail.setTaskName((String) result[14]);
					cmpConnectionDetail.setBpmProcessName((String) result[15]);
					cmpConnectionDetail.setTaskCode((String) result[16]);
					processList.add(cmpConnectionDetail);

				}
			}

		} catch (Exception e) {
			log.info("Exception:: " + e);
		}
		log.info("Size of process List" + processList.size());
		return processList;
	}

	@Override
	@Transactional(readOnly = true)
	public int updateCCRId(String cmpOrderId, Long tireqId) {
		log.info("updateCCRId method starts");
		Session session = getSession();
		Long processId = 0L;
		int count = 0;
		String fetchUserIdQuery = "select process_id from ti_request where id="
				+ tireqId + "";
		SQLQuery sq = session.createSQLQuery(fetchUserIdQuery);
		sq.addScalar("process_id", LongType.INSTANCE);
		processId = (Long) sq.uniqueResult();
		if (processId > 0) {

			String sql = "update cmp_request set ccr_id='"
					+ processId.toString() + "' where order_id='" + cmpOrderId
					+ "'";
			log.info("sql:: " + sql);
			SQLQuery query = session.createSQLQuery(sql);
			count = query.executeUpdate();

		}
		log.info("updateCCRId method ends" + count);
		return count;
	}

	@Override
	@Transactional(readOnly = true)
	public int updateCmpId(String cmpOrderId, Long tireqId) {
		log.info("updateCmpId method starts");
		Session session = getSession();
		int count = 0;		

		String updateTiReq = "update ti_request set cmp_id='" + cmpOrderId
				+ "' where id=" + tireqId + "";
		SQLQuery queryReq = session.createSQLQuery(updateTiReq);
		queryReq.executeUpdate();	
		
		String updateResolve = "update resolve_it_notify_log set ti_request_id ="
					+ tireqId + " where cmp_id = '" + cmpOrderId + "'";
		SQLQuery queryRes = session.createSQLQuery(updateResolve);
		count = queryRes.executeUpdate();
		
		log.info("updateCmpId method ends" + count);
		return count;
	}

}
