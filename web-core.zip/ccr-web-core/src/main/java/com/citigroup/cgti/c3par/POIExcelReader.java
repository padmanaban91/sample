package com.citigroup.cgti.c3par;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;



/**
 * The Class POIExcelReader.
 */
@SuppressWarnings("unchecked")
public class POIExcelReader {

    /**
     * Instantiates a new pOI excel reader.
     */
    public POIExcelReader() {
    }

    /**
     * Gets the cell value.
     *
     * @param cell the cell
     * @return the cell value
     */
    public static String getCellValue(HSSFCell cell) {
	if (cell == null) {
	    return null;
	}
	String cellValue = null;

	switch (cell.getCellType()) {
	case HSSFCell.CELL_TYPE_NUMERIC:
	    cellValue = String.valueOf(cell.getNumericCellValue());
	    break;
	case HSSFCell.CELL_TYPE_STRING:
	    cellValue = cell.getStringCellValue();
	    break;
	}

	return cellValue;
    }

    /**
     * Parses the sheet.
     *
     * @param workbook the workbook
     * @param sheetName the sheet name
     * @return the list
     */
    public List parseSheet(HSSFWorkbook workbook, String sheetName) {

	List columns = null;
	List rows = null;

	HSSFSheet sheet = workbook.getSheet(sheetName);
	if (sheet != null) {
	    rows = new ArrayList();
	}

	for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
	    HSSFRow xlRow = sheet.getRow(i);

	    if (xlRow == null) {
		continue;
	    } else {
		int noOfColumns = xlRow.getPhysicalNumberOfCells();

		columns = new ArrayList();

		// for loop for number of cells which have contents
		for (int cellIndx = 0; cellIndx < noOfColumns; cellIndx++) {
		    HSSFCell cell = xlRow.getCell((short) cellIndx);

		    if (cell == null) {
			continue;
		    }

		    String cellValue = getCellValue(cell);
		    if (cellValue != null)
			columns.add(cellValue);
		}
	    }
	    if (columns != null && columns.size() > 0)
		rows.add(columns);
	}

	return rows;
    }


}
