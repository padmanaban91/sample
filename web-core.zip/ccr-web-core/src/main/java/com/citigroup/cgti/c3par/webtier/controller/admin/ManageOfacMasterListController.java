package com.citigroup.cgti.c3par.webtier.controller.admin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.admin.domain.ManageOfacMasterDTO;
import com.citigroup.cgti.c3par.admin.service.ManageOfacMasterService;
import com.citigroup.cgti.c3par.appsense.domain.OfacSubnetMaster;
import com.citigroup.cgti.c3par.fw.service.SubnetUtils;

@Controller
public class ManageOfacMasterListController {
	private Logger log = Logger.getLogger(this.getClass().getName());

	@Autowired
	ManageOfacMasterService manageOfacMasterService;

	@RequestMapping(value = "/searchManageOfacMaster.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String searchManageOfacMaster(ModelMap model,
			@ModelAttribute("manageOfacMasterProcess") ManageOfacMasterDTO manageOfacMasterDTO, BindingResult result) {
		log.debug("Methods starts...");
		manageOfacMasterDTO.setManageOfacMasterDTOList(null);
		String forward = "c3par.useradmin.manageOfacMaster";
		boolean addError = false;
		boolean noResult = false;

		try {
			if (manageOfacMasterDTO.getSearchIp() != null && manageOfacMasterDTO.getSearchIp().trim().length() > 0) {
				String ipAddress = manageOfacMasterDTO.getSearchIp();
				log.info("*******Given Search IP Address*********" + ipAddress);
				log.info("Inside Search Ip methods starts...");
				List<ManageOfacMasterDTO> manageOfacMasterDTOList = new ArrayList<ManageOfacMasterDTO>();
				List<OfacSubnetMaster> ofacSubnetMasterList = manageOfacMasterService.getIpDetails(ipAddress);
				ManageOfacMasterDTO manageOfacMaster = null;
				if (ofacSubnetMasterList.size() > 0) {
					for (OfacSubnetMaster ofacSubnetMaster : ofacSubnetMasterList) {
						manageOfacMaster = new ManageOfacMasterDTO();
						manageOfacMaster.setIpAddress(ofacSubnetMaster.getIpAddress());
						manageOfacMaster.setStartIPAddress(ofacSubnetMaster.getStartIPAddress());
						manageOfacMaster.setEndIPAddress(ofacSubnetMaster.getEndIPAddress());
						manageOfacMaster.setSubnet(ofacSubnetMaster.getSubnet());
						manageOfacMaster.setNoOfHost(ofacSubnetMaster.getNoOfHost());
						manageOfacMaster.setBroadCastAddress(ofacSubnetMaster.getBroadCastAddress());
						manageOfacMaster.setCreatedBy(ofacSubnetMaster.getCreatedBy());
						manageOfacMaster.setUpdatedBy(ofacSubnetMaster.getUpdatedBy());
						manageOfacMaster.setCreated_date(ofacSubnetMaster.getCreated_date());
						manageOfacMaster.setUpdated_date(ofacSubnetMaster.getUpdated_date());
						manageOfacMasterDTOList.add(manageOfacMaster);
					}
					manageOfacMasterDTO.setManageOfacMasterDTOList(manageOfacMasterDTOList);
				} else {
					log.info("Inside else : No search result for the given criteria : "
							+ manageOfacMasterDTO.getSearchIp());
					noResult = true;
				}
			} else {
				log.info("****************Else part****************");
				manageOfacMasterDTO.setDeleteIp("empty");
				addError = true;
			}
		} catch (Exception e) {
			log.error(e.toString(), e);
			addError = true;
		}
		if (addError) {
			log.info("ManageOfacController::searchManageOfacMaster:: Ip Address Empty:: Error...");
			result.addError(new ObjectError("manageOfacMasterDTO.ipAddress", new String[] { "admin.IPAddressEmpty" },
					null, null));
		}
		if (noResult) {
			log.info("ManageOfacController::searchManageOfacMaster:: No Records found...");
			result.addError(new ObjectError("manageOfacMasterDTO.ipAddress", new String[] { "admin.NoIPSearchResult" },
					null, null));
		}
		return forward;
	}

	@RequestMapping(value = "/loadManageOfacMaster.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadManageOfacMaster(ModelMap model,
			@ModelAttribute("manageOfacMasterProcess") ManageOfacMasterDTO manageOfacMasterDTO, BindingResult result) {
		log.debug("****ManageOfacMasterListController Methods starts...");
		String forward = "c3par.useradmin.manageOfacMaster";
		return forward;
	}

	@RequestMapping(value = "/deleteManageOfacMaster.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String editManageOfacMaster(ModelMap model,
			@ModelAttribute("manageOfacMasterProcess") ManageOfacMasterDTO manageOfacMasterDTO, BindingResult result,
			HttpServletRequest request) {

		boolean addError = false;
		boolean delResult = false;
		String updatedUser = request.getHeader("SM_USER");
		try {
			List<ManageOfacMasterDTO> manageOfacMasterDTOList = manageOfacMasterDTO.getManageOfacMasterDTOList();

			if (manageOfacMasterDTOList != null && manageOfacMasterDTOList.size() > 0) {
				Iterator<ManageOfacMasterDTO> iterator = manageOfacMasterDTOList.iterator();
				while (iterator.hasNext()) {
					ManageOfacMasterDTO dto1 = iterator.next();
					log.info("ManageOfacController::deleteManageOfacList" + dto1.getIpAddress() + "------"
							+ dto1.isSelected());
					if (dto1.isSelected()) {
						manageOfacMasterService.deleteManageOfacMasterList(dto1.getIpAddress(), updatedUser);
						delResult = true;
						log.info("*****************Remove IP Address:" + dto1.getIpAddress());
						iterator.remove();
					}
				}
			}

			manageOfacMasterDTO.setIpAddress("");
			log.info("***********IPList Size : " + manageOfacMasterDTO.getManageOfacMasterDTOList().size());
			model.addAttribute("manageOfacMasterDTO", manageOfacMasterDTO);
		} catch (Exception e) {
			log.info("*****Exception:****** " + e);
			addError = true;
		}
		if (addError) {
			log.info("ManageOfacMasterListController::deleteManageOfacMaster:: Ip Address cannot be deleted");
			result.addError(
					new ObjectError("manageOfacMasterDTO.ipAddress", new String[] { "admin.notdeleteIp" }, null, null));
		}
		if (delResult) {
			log.info("ManageOfacMasterListController::deleteManageOfacMaster:: Ip Address deleted");
			result.addError(
					new ObjectError("manageOfacMasterDTO.startIPAddress", new String[] { "admin.deletedIP" }, null, null));
		} else {
			log.info("ManageOfacMasterListController::deleteManageOfacMaster:: No IP Selected");
			result.addError(new ObjectError("manageOfacMasterDTO.ipAddress", new String[] { "admin.noIpSelected" },
					null, null));
		}
		return "c3par.useradmin.manageOfacMaster";
	}

	@RequestMapping(value = "/saveManageOfacMaster.act", method = { RequestMethod.POST })
	public String saveManageOfacMaster(ModelMap model,
			@ModelAttribute("manageOfacMasterProcess") ManageOfacMasterDTO manageOfacMasterDTO, BindingResult result,
			HttpServletRequest request) {

		log.info("************Save Ofac Master******************");
		boolean addError = false;
		boolean duplicateIp = false;
		boolean invalidIPError = false;
		boolean addedIp = false;
		boolean subnetIPError = false;
		SubnetUtils subnetUtils = null;
		String IP_ADDRESS = "(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})";
		String SLASH_FORMAT = IP_ADDRESS + "/(\\d{1,3})";
		Pattern addressPattern = Pattern.compile(IP_ADDRESS);
		Pattern cidrPattern = Pattern.compile(SLASH_FORMAT);
		System.out.println("**********Selected Type: "+manageOfacMasterDTO.getSelectedType());
		try {
			if (manageOfacMasterDTO.getIpAddress() != null && manageOfacMasterDTO.getIpAddress().trim().length() > 0) {
				List<OfacSubnetMaster> ofacSubnetMasterList = manageOfacMasterService
						.getExactIpDetails(manageOfacMasterDTO.getIpAddress());

				if (ofacSubnetMasterList.size() > 0) {
					log.info("*****Inside OfacSubnetMasterList.size()>0 block:****** ");
					duplicateIp = true;
				} else {
					Matcher ipMatcher = addressPattern.matcher(manageOfacMasterDTO.getIpAddress());
					Matcher subnetMatcher = cidrPattern.matcher(manageOfacMasterDTO.getIpAddress());
					if (ipMatcher.matches() && manageOfacMasterDTO.getSelectedType().equals("Individual")) {
						manageOfacMasterDTO.setStartIPAddress(manageOfacMasterDTO.getIpAddress());
						manageOfacMasterDTO.setEndIPAddress(manageOfacMasterDTO.getIpAddress());
						manageOfacMasterDTO.setSubnet(null);
						manageOfacMasterDTO.setNoOfHost(1L);
						manageOfacMasterDTO.setBroadCastAddress(null);
						manageOfacMasterDTO.setCreatedBy(request.getHeader("SM_USER"));
						manageOfacMasterService.saveManageOfacMasterList(manageOfacMasterDTO);
						addedIp = true;
					} else if (subnetMatcher.matches() && manageOfacMasterDTO.getSelectedType().equals("Subnet")) {
						subnetUtils = new SubnetUtils(manageOfacMasterDTO.getIpAddress());
						manageOfacMasterDTO.setStartIPAddress(subnetUtils.getInfo().getLowAddress());
						manageOfacMasterDTO.setEndIPAddress(subnetUtils.getInfo().getHighAddress());
						manageOfacMasterDTO.setSubnet(subnetUtils.getInfo().getAddress());
						manageOfacMasterDTO.setNoOfHost(Long.valueOf(subnetUtils.getInfo().getAddressCount()));
						manageOfacMasterDTO.setBroadCastAddress(subnetUtils.getInfo().getBroadcastAddress());
						manageOfacMasterDTO.setCreatedBy(request.getHeader("SM_USER"));
						manageOfacMasterService.saveManageOfacMasterList(manageOfacMasterDTO);
						addedIp = true;
					} else {
						log.info("****************Invalid ip part****************");
						invalidIPError = true;
					}
				}
			} else {// if soeID is not entered then show the error message
				log.info("****************Else part****************");
				addError = true;
			}
		} catch (IllegalArgumentException ex) {
			log.info("*****Exception block:****** " + ex);
			subnetIPError = true;
		}
		
		catch (Exception e) {
			log.info("*****Exception block:****** " + e);
			invalidIPError = true;
		}
		if (addError) {

			log.info("ManageOfacMasterListController::saveManageOfacMaster:: Ip Address Empty");
			result.addError(new ObjectError("manageOfacMasterDTO.ipAddress", new String[] { "admin.IPAddressEmpty" },
					null, null));
		}
		if (invalidIPError) {
			log.info("ManageOfacMasterListController::saveManageOfacMaster:: Ip Address invalid");
			result.addError(
					new ObjectError("manageTpaMasterDTO.ipAddress", new String[] { "admin.invalidIP" }, null, null));
		}
		if (duplicateIp) {
			log.info(
					"ManageOfacMasterListController::saveManageOfacMaster:: Invalid or Duplicate IP Address...");
			result.addError(
					new ObjectError("manageOfacMasterDTO.ipAddress", new String[] { "admin.DuplicateIP" }, null, null));
		}
		if (addedIp) {
			log.info(
					"ManageOfacMasterListController::saveManageOfacMaster:: IP Address added successfully...");
			result.addError(
					new ObjectError("manageOfacMasterDTO.startIPAddress", new String[] { "admin.IPAdd" }, null, null));
		}
		
		if (subnetIPError) {
			log.info(
					"ManageOfacMasterListController::saveManageOfacMaster::  Subnet Mask Bits out of range...");
			result.addError(
					new ObjectError("manageOfacMasterDTO.startIPAddress", new String[] { "admin.SubnetIPError" }, null, null));
		}

		manageOfacMasterDTO.setIpAddress(null);
		manageOfacMasterDTO.setStartIPAddress(null);
		manageOfacMasterDTO.setEndIPAddress(null);
		manageOfacMasterDTO.setSubnet(null);
		manageOfacMasterDTO.setNoOfHost(null);
		manageOfacMasterDTO.setBroadCastAddress(null);
		manageOfacMasterDTO.setCreatedBy(null);
		model.addAttribute("manageOfacMasterProcess", manageOfacMasterDTO);

		return "c3par.useradmin.manageOfacMaster";
	}
	
	/*method to initialize the size of Collection using WebDataBinder*/
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    binder.setAutoGrowCollectionLimit(1500);
	}

}
