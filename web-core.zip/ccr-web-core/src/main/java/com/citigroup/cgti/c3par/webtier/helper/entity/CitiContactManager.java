package com.citigroup.cgti.c3par.webtier.helper.entity;

import com.mentisys.dao.DatabaseException;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.citigroup.cgti.c3par.model.*;


/**
 * The Class CitiContactManager.
 */
public class CitiContactManager
{
    //=======================================================================================
    /**
     * Update.
     *
     * @param entity the entity
     * @param dbSession the db session
     * @return the long
     * @throws DatabaseException the database exception
     */
    static public Long update(CitiContactEntity entity,C3parSession dbSession) throws DatabaseException
    {
	Long id = null;
	if(entity != null)
	{
	    CitiContactDAO dao = new CitiContactDAO(dbSession);
	    dao.update(entity, dbSession.getArchiver());
	    id = entity.getId();
	}
	return id;
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param dbSession the db session
     * @throws DatabaseException the database exception
     */
    static public void delete(String id, C3parSession dbSession) throws DatabaseException
    {
	if(id != null && id.length() > 0)
	{
	    CitiContactManager.delete(Long.valueOf(id),dbSession);
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param dbSession the db session
     * @throws DatabaseException the database exception
     */
    static public void delete(Long id, C3parSession dbSession) throws DatabaseException
    {
	if(id != null)
	{
	    CitiContactEntity entity = CitiContactManager.get(id, dbSession);
	    CitiContactManager.delete(entity, dbSession);
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param entity the entity
     * @param dbSession the db session
     * @throws DatabaseException the database exception
     */
    static public void delete(CitiContactEntity entity, C3parSession dbSession) throws DatabaseException
    {
	if(entity != null)
	{
	    CitiContactDAO dao = new CitiContactDAO(dbSession);
	    dao.delete(entity, dbSession.getArchiver());
	}
    }

    //=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @param dbSession the db session
     * @return the citi contact entity
     * @throws DatabaseException the database exception
     */
    static public CitiContactEntity get(String id, C3parSession dbSession) throws DatabaseException
    {
	CitiContactEntity	entity = null;
	if(id != null && id.length() > 0)
	{
	    entity = CitiContactManager.get(Long.valueOf(id), dbSession);
	}
	return entity; 
    }

    //=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @param dbSession the db session
     * @return the citi contact entity
     * @throws DatabaseException the database exception
     */
    static public CitiContactEntity get(Long id, C3parSession dbSession) throws DatabaseException
    {
	CitiContactEntity entity = null;
	if(id != null)
	{
	    CitiContactDAO dao = new CitiContactDAO(dbSession);
	    entity = dao.get(id);
	}

	return entity;	
    }
}


