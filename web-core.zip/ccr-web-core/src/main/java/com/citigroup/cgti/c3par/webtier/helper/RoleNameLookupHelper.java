package com.citigroup.cgti.c3par.webtier.helper;


/*
 * CONFIDENTIAL  AND PROPRIETARY
 */

/**
 * The Class RoleNameLookupHelper.
 */
public final class RoleNameLookupHelper
{

    /** The Constant PROJECT_COORDINATOR. */
    public static final String PROJECT_COORDINATOR = "Project_Coordinator";

    /** The Constant PROJECT_SPONSOR. */
    public static final String PROJECT_SPONSOR = "PROJECT SPONSOR";

    /** The Constant BISO. */
    public static final String BISO = "BISO";

    /** The Constant DESIGN_ENGINEER. */
    public static final String DESIGN_ENGINEER = "Design_Engineer";

    /** The Constant SENIOR_DESIGN_ENGINEER. */
    public static final String SENIOR_DESIGN_ENGINEER = "SENIOR DESIGN ENGINEER";

    /** The Constant GNCC. */
    public static final String GNCC = "GNCC";

    /** The Constant REGULATORY_CONTACT. */
    public static final String REGULATORY_CONTACT = "REGULATORY CONTACT";

    /** The Constant REGULATORY. */
    public static final String REGULATORY = "Regulatory";

    /** The Constant LEGAL_CONTACT. */
    public static final String LEGAL_CONTACT = "Legal";

    /** The Constant LEGAL. */
    public static final String LEGAL = "LEGAL CONTACT";

    /** The Constant FINANCE_CONTROLLER. */
    public static final String FINANCE_CONTROLLER = "FINANCE CONTROLLER";

    /** The Constant PRIVACY. */
    public static final String PRIVACY = "PRIVACY";

    /** The Constant INTERNAL_AUDIT. */
    public static final String INTERNAL_AUDIT="Internal_Audit";

    /** The Constant TECHNICAL. */
    public static final String TECHNICAL = "TECHNICAL CONTACT";

    /** The Constant RELATIONSHIP_MANAGER. */
    public static final String RELATIONSHIP_MANAGER = "RELATIONSHIP MANAGER";

    /** The Constant TECHNICAL_SUPPORT. */
    public static final String TECHNICAL_SUPPORT = "TECHNICAL SUPPORT";

    /** The Constant ISS. */
    public static final String ISS = "ISS";

    /** The Constant C3PARSECURITYADMIN. */
    public static final String C3PARSECURITYADMIN = "C3PARSECURITYADMIN";

    /** The Constant C3PARUSER. */
    public static final String C3PARUSER = "C3PARUSER";

    /** The Constant C3PARSYSTEMADMIN. */
    public static final String C3PARSYSTEMADMIN = "C3PARSYSTEMADMIN";

    /** The Constant THIRDPARTY_WORKING_GROUP. */
    public static final String THIRDPARTY_WORKING_GROUP="ThirdParty_Working_Group";

    /** The Constant ISTG_CHAIR. */
    public static final String ISTG_CHAIR="ISTG_Chair";

    //IPRegistration  Roles
    /** The Constant MANAGER. */
    public static final String MANAGER="Manager";

    /** The Constant ISA. */
    public static final String ISA="ISA";

    /** The Constant APPLIED_ENGINEER. */
    public static final String APPLIED_ENGINEER="Applied_Engineer";

    /** The Constant OPERATIONAL_ANALYST. */
    public static final String OPERATIONAL_ANALYST="Operational_Analyst";

    /** The Constant REMOTE_ACCESS_ENGINEER. */
    public static final String REMOTE_ACCESS_ENGINEER="Remote_Access_Engineer";

    /** The Constant WWDS. */
    public static final String WWDS="WWDS";

    /** The Constant REQUESTOR. */
    public static final String REQUESTOR="Requestor";

    /** The Constant USER. */
    public static final String USER="User";




}