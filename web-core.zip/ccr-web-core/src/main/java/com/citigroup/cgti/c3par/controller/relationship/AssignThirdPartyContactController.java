package com.citigroup.cgti.c3par.controller.relationship;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.relationship.domain.AssignThirdPartyContactProcess;
import com.citigroup.cgti.c3par.relationship.domain.RelThirdPartyContXref;
import com.citigroup.cgti.c3par.relationship.domain.RelationshipProcess;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;
import com.citigroup.cgti.c3par.validator.relationship.RoleInfoValidator;


@Controller
public class AssignThirdPartyContactController extends RelationshipBaseController{

	private static Logger log = Logger.getLogger(AssignThirdPartyContactController.class);

	@RequestMapping(value = "/populateThirdPartyContacts.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String populateThirdPartyContacts( ModelMap model, @ModelAttribute("assignThirdPartyContactProcess") AssignThirdPartyContactProcess assignThirdPartyContactProcess,HttpServletRequest request) {
		log.debug("AssignThirdPartyContactController :: populateThirdPartyContacts :: Method Starts");
		
		List<Role> rolelist = assignThirdPartyContactProcess.loadRoleList();
		assignThirdPartyContactProcess.setRoleList(rolelist);

		String assignTo = request.getParameter("assignTo");
		if ( assignTo != null && !assignTo.isEmpty()) {
			request.getSession().setAttribute("CITI_TP_CONTACT_ASSIGN_TO",	assignTo);
		}	
		
		RelationshipProcess relprocess = getRelationshipProcess(request);
		assignThirdPartyContactProcess.setCanEdit(relprocess.isCanEdit());
		assignThirdPartyContactProcess.setRelationshipName(relprocess.getRelationship().getName());
		
		if (assignTo != null && assignTo.equalsIgnoreCase("requester")) {
			Long thirdpartyId = relprocess.getRelationship().getThirdParty().getId();
			
			log.debug("AssignThirdPartyContactController :: populateThirdPartyContacts :: thirdpartyId - " + thirdpartyId);
			
			List<ThirdPartyContact> allThirdPartyContacts = assignThirdPartyContactProcess.loadThirdPartyContacts(thirdpartyId);
			assignThirdPartyContactProcess.setAllThirdPartyContacts(allThirdPartyContacts);
			
			assignThirdPartyContactProcess.setThirdPartyContacts(relprocess.getRequesterThirdPartyContacts());
			assignThirdPartyContactProcess.setThirdPartyName(relprocess.getRelationship().getThirdParty().getName());
			assignThirdPartyContactProcess.setThirdPartyId(thirdpartyId);
			
			request.getSession().setAttribute("CITI_TP_CONTACT_LIST",	allThirdPartyContacts);

		} else if (assignTo != null && assignTo.equalsIgnoreCase("target")) {
			Long uturnThirdpartyId = relprocess.getRelationship().getUturnThirdParty().getId();
			
			log.debug("AssignThirdPartyContactController :: populateThirdPartyContacts :: UTurn thirdpartyId - " + uturnThirdpartyId);
			
			List<ThirdPartyContact> allThirdPartyContacts = assignThirdPartyContactProcess.loadThirdPartyContacts(uturnThirdpartyId);
			assignThirdPartyContactProcess.setAllThirdPartyContacts(allThirdPartyContacts);
			
			assignThirdPartyContactProcess.setThirdPartyContacts(relprocess.getTargetThirdPartyContacts());
			assignThirdPartyContactProcess.setThirdPartyName(relprocess.getRelationship().getUturnThirdParty().getName());
			assignThirdPartyContactProcess.setThirdPartyId(uturnThirdpartyId);

			request.getSession().setAttribute("CITI_TP_CONTACT_LIST",	allThirdPartyContacts);
		}

		assignThirdPartyContactProcess.setSelectedTPContact(null);
		assignThirdPartyContactProcess.setSelectedRole(null);
		assignThirdPartyContactProcess.setUnselectedTPContact(null);
		model.addAttribute("assignThirdPartyContactProcess",assignThirdPartyContactProcess);

		return "pages/relationship/AssignThirdPartyContact";
	}

	@RequestMapping(value = "/assignThirdPartyContacts.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String assignThirdPartyContacts(ModelMap model,@ModelAttribute("assignThirdPartyContactProcess") AssignThirdPartyContactProcess assignTPContactProcess
									,BindingResult result, HttpServletRequest request) {
		log.debug("AssignThirdPartyContactController :: assignThirdPartyContacts :: Method Starts");
		String assignTo = (String) request.getSession().getAttribute("CITI_TP_CONTACT_ASSIGN_TO");	
		
		//load role drop downlist
		List<Role> rolelist = assignTPContactProcess.loadRoleList();
		assignTPContactProcess.setRoleList(rolelist);
		
		List<ThirdPartyContact> allThirdPartyContacts = null;
		if(request.getSession().getAttribute("CITI_TP_CONTACT_LIST") != null){
			allThirdPartyContacts = (ArrayList<ThirdPartyContact>) request.getSession().getAttribute("CITI_TP_CONTACT_LIST");
		}
		assignTPContactProcess.setAllThirdPartyContacts(allThirdPartyContacts);
		
		List<RelThirdPartyContXref> contactlist = null;
		RelationshipProcess relprocess = getRelationshipProcess(request);
		if (assignTo.equals("requester")) {
			contactlist = relprocess.getRequesterThirdPartyContacts();
		}else if (assignTo.equals("target")) {
			contactlist = relprocess.getTargetThirdPartyContacts();
		}

		if(contactlist == null){
			contactlist = new ArrayList<RelThirdPartyContXref>();
		}
		
		String[] selectedTPContacts = assignTPContactProcess.getSelectedTPContact();
		String[] selectedRoles = assignTPContactProcess.getSelectedRole();
		
		RoleInfoValidator validator = new RoleInfoValidator();
		//add old contacts into validator for duplicate check
		for(RelThirdPartyContXref existingContact:contactlist){
			validator.validateContactRole(existingContact.getThirdPartyContact().getId(), existingContact.getRole().getId());
			
			log.debug("AssignThirdPartyContactController :: assignThirdPartyContacts :: existingContact :: getContactId "+existingContact.getThirdPartyContact().getId());
			log.debug("AssignThirdPartyContactController :: assignThirdPartyContacts :: existingContact :: getRole "+existingContact.getRole().getId());
		}
		
		if(selectedTPContacts != null && selectedRoles != null && selectedTPContacts.length > 0 && selectedRoles.length > 0){
			
			ThirdPartyContact thirdpartyContact = null;
			RelThirdPartyContXref relThirdPartyContXref = null;
			Role role = null;
			
			for(String tpContact:selectedTPContacts){
				log.debug("AssignThirdPartyContactController :: assignThirdPartyContacts :: tpContactId - "+tpContact);
				int index = Integer.valueOf(tpContact);
				ThirdPartyContact tpcontact = allThirdPartyContacts.get(index);
				thirdpartyContact = assignTPContactProcess.getThirdPartyContact(tpcontact.getId());
				
				Long roleid = Long.valueOf(selectedRoles[index]);
				
				if(roleid.longValue() > 0){
					role = assignTPContactProcess.getRole(roleid);
					
					if(validator.validateContactRole(thirdpartyContact.getId(), role.getId())){
						
						relThirdPartyContXref = new RelThirdPartyContXref();
						relThirdPartyContXref.setThirdPartyContact(thirdpartyContact);
						relThirdPartyContXref.setRole(role);
						
						contactlist.add(relThirdPartyContXref);
					}else{
						result.addError(new ObjectError("citiContact", "The relationship contains duplicate entries for a Citi contacts (i.e. Contact and Role are same)."));
						break;
					}
				}else{
					result.addError(new ObjectError("citiContact", "Please select the role"));
					break;
				}
			}
		}
		assignTPContactProcess.setThirdPartyContacts(contactlist);
		assignTPContactProcess.setSelectedTPContact(null);
		assignTPContactProcess.setSelectedRole(null);
		assignTPContactProcess.setUnselectedTPContact(null);

		if (assignTo.equals("requester")) {
			relprocess.setRequesterThirdPartyContacts(assignTPContactProcess.getThirdPartyContacts());
		}else if (assignTo.equals("target")) {
			relprocess.setTargetThirdPartyContacts(assignTPContactProcess.getThirdPartyContacts());
		}
		setInSession(request, relprocess);

		model.addAttribute("assignThirdPartyContactProcess",assignTPContactProcess);
		
		return "pages/relationship/AssignThirdPartyContact";
	}

	@RequestMapping(value = "/unAssignThirdPartyContacts.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String unAssignThirdPartyContacts(ModelMap model,@ModelAttribute("assignThirdPartyContactProcess") AssignThirdPartyContactProcess assignThirdPartyContactProcess,HttpServletRequest request) {

		log.debug("AssignThirdPartyContactController :: unAssignThirdPartyContacts :: Method Starts");
		
		String assignTo = (String) request.getSession().getAttribute("CITI_TP_CONTACT_ASSIGN_TO");			
		String[] unseletedThirdParty = assignThirdPartyContactProcess.getUnselectedTPContact();

		List<ThirdPartyContact> allThirdPartyContacts = null;
		if(request.getSession().getAttribute("CITI_TP_CONTACT_LIST") != null){
			allThirdPartyContacts = (ArrayList<ThirdPartyContact>) request.getSession().getAttribute("CITI_TP_CONTACT_LIST");
		}
		assignThirdPartyContactProcess.setAllThirdPartyContacts(allThirdPartyContacts);
		
		//load role drop downlist
		List<Role> rolelist = assignThirdPartyContactProcess.loadRoleList();
		assignThirdPartyContactProcess.setRoleList(rolelist);
		
		List<RelThirdPartyContXref> contactlist = null;
		RelationshipProcess relprocess = getRelationshipProcess(request);
		if (assignTo.equals("requester")) {
			contactlist = relprocess.getRequesterThirdPartyContacts();
		}else if (assignTo.equals("target")) {
			contactlist = relprocess.getTargetThirdPartyContacts();
		}

		int indexId = 0;
		
		if(unseletedThirdParty!= null && unseletedThirdParty.length > 0){
			int count = 0;
			for (String tpid : unseletedThirdParty) {
				log.debug("AssignThirdPartyContactController :: unAssignThirdPartyContacts :: tpid - "+tpid);
				indexId = Integer.valueOf(tpid);
				contactlist.remove(indexId-count);
				count++;
			}
		}
		assignThirdPartyContactProcess.setThirdPartyContacts(contactlist);
		assignThirdPartyContactProcess.setSelectedTPContact(null);
		assignThirdPartyContactProcess.setSelectedRole(null);
		assignThirdPartyContactProcess.setUnselectedTPContact(null);

		if (assignTo.equals("requester")) {
			relprocess.setRequesterThirdPartyContacts(assignThirdPartyContactProcess.getThirdPartyContacts());
		}else if (assignTo.equals("target")) {
			relprocess.setTargetThirdPartyContacts(assignThirdPartyContactProcess.getThirdPartyContacts());
		}
		setInSession(request, relprocess);
		
		model.addAttribute("assignThirdPartyContactProcess",assignThirdPartyContactProcess);
		
		return "pages/relationship/AssignThirdPartyContact";
	}

	@RequestMapping(value = "/deleteThirdPartyContactAssigned.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String deleteThirdPartyContactAssigned(ModelMap model,@ModelAttribute("assignThirdPartyContactProcess") AssignThirdPartyContactProcess assignTPContactProcess
									, HttpServletRequest request) {
		
		String tpIdstr = request.getParameter("selectedThirdParty");
		String tpcontactstr = request.getParameter("selectedId");
		
		String assignTo = (String) request.getSession().getAttribute("CITI_TP_CONTACT_ASSIGN_TO");	
		
		log.debug("AssignThirdPartyContactController :: deleteThirdPartyContactAssigned :: tpIdstr - "+tpIdstr+" :: tplocstr - "+tpIdstr);
		
		if(tpIdstr != null && !tpIdstr.isEmpty() && tpcontactstr != null && !tpcontactstr.isEmpty()){
			Long tpid = Long.valueOf(tpIdstr);
			Long tpcontact = Long.valueOf(tpcontactstr);

			int count = assignTPContactProcess.getTpRelationshipForContact(tpcontact);
			if(count <= 0){
				assignTPContactProcess.deleteContactById(tpcontact);
			}else{
				log.error("ThirdParty Contact is already used in the relationship");
				request.getSession().setAttribute("ERROR_MSG",	"ThirdParty Contact is already used in the relationship");
			}
		}
		
		return "forward:/populateThirdPartyContacts.act?assignTo="+assignTo;
	}
}
