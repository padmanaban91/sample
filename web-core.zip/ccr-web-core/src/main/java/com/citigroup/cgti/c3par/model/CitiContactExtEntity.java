package com.citigroup.cgti.c3par.model;


/**
 * The Class CitiContactExtEntity.
 */
public class CitiContactExtEntity extends CitiContactEntity {

    /** The employee type. */
    private String employeeType;
    
    private String geId;
    
    private String isTerminated;
    
    private String managerGeId; 

    private String employeeStatus;

    private String supervisorGeId;
    
    private String supervisorEmail;

    private String latestSupervisorGeId;

    private String supervisorLimit;
    private String supervisorFirstName;
    private String supervisorLastName;

    /**
     * Gets the employee type.
     *
     * @return the employeeType
     */
    public String getEmployeeType() {
    	return employeeType;
    }

    /**
     * Sets the employee type.
     *
     * @param employeeType the employeeType to set
     */
    public void setEmployeeType(String employeeType) {
    	this.employeeType = employeeType;
    }

	public String getGeId() {
		return geId;
	}

	public void setGeId(String geId) {
		this.geId = geId;
	}

	public String getIsTerminated() {
		return isTerminated;
	}

	public void setIsTerminated(String isTerminated) {
		this.isTerminated = isTerminated;
	}

	public String getManagerGeId() {
		return managerGeId;
	}

	public void setManagerGeId(String managerGeId) {
		this.managerGeId = managerGeId;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public String getSupervisorGeId() {
		return supervisorGeId;
	}

	public void setSupervisorGeId(String supervisorGeId) {
		this.supervisorGeId = supervisorGeId;
	}

	public String getSupervisorEmail() {
		return supervisorEmail;
	}

	public void setSupervisorEmail(String supervisorEmail) {
		this.supervisorEmail = supervisorEmail;
	}

	public String getLatestSupervisorGeId() {
		return latestSupervisorGeId;
	}

	public void setLatestSupervisorGeId(String latestSupervisorGeId) {
		this.latestSupervisorGeId = latestSupervisorGeId;
	}

	public String getSupervisorLimit() {
		return supervisorLimit;
	}

	public void setSupervisorLimit(String supervisorLimit) {
		this.supervisorLimit = supervisorLimit;
	}

	public String getSupervisorFirstName() {
		return supervisorFirstName;
	}

	public void setSupervisorFirstName(String supervisorFirstName) {
		this.supervisorFirstName = supervisorFirstName;
	}

	public String getSupervisorLastName() {
		return supervisorLastName;
	}

	public void setSupervisorLastName(String supervisorLastName) {
		this.supervisorLastName = supervisorLastName;
	}
}
