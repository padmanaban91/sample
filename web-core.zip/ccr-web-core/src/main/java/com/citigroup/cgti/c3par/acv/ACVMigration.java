package com.citigroup.cgti.c3par.acv;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;

public class ACVMigration {
	
	
	private JdbcTemplate jdbcTemplate;
	private CCRQueries ccrQueries;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public CCRQueries getCcrQueries() {
		return ccrQueries;
	}

	public void setCcrQueries(CCRQueries ccrQueries) {
		this.ccrQueries = ccrQueries;
	}

	@SuppressWarnings("unchecked")
	public Map<String, List> getACVRecords(int maxACV, int maxACVExp) {
		StringBuilder sb = new StringBuilder();
		Map<String, List> map = new HashMap<String, List>();

		List<String> li = null;
		
		sb.append("select process_id,ti_request_id,task_code,bpm_instance_id from(  ");
		sb.append("select tir.process_id,tir.id ti_request_id,ttt.task_code,tat.bpm_instance_id  ");
		sb.append("from  ");
		sb.append("c3par.ti_activity_trail tat  ");
		sb.append("join c3par.ti_task_type ttt on tat.activity_id=ttt.id  ");
		sb.append("join c3par.ti_request tir on tir.id=tat.ti_request_id  ");
		sb.append("join c3par.ti_request_type trt on trt.id=tir.ti_request_type_id  ");
		sb.append("where  ");
		sb.append("trt.request_type='ACV'  ");
		sb.append("and ttt.task_code in('acv_exp')  ");
		sb.append("and tat.activity_status='SCHEDULED'  ");
		sb.append("and tir.process_id not in (select process_id from c3par.ACV_MIGRATION_LOG)  ");
		sb.append("and tir.process_id in (select id from c3par.temp_ti_process)  ");
//		sb.append("and tir.process_id in (select process_id from c3par.email_notification where notification_required='N')  ");
		sb.append("order by tir.process_id  ");
		sb.append(")where rownum<="+maxACVExp);
		sb.append("union ");
		sb.append("select process_id,ti_request_id,task_code,bpm_instance_id from(  ");
		sb.append("select tir.process_id,tir.id ti_request_id,ttt.task_code,tat.bpm_instance_id  ");
		sb.append("from  ");
		sb.append("c3par.ti_activity_trail tat  ");
		sb.append("join c3par.ti_task_type ttt on tat.activity_id=ttt.id  ");
		sb.append("join c3par.ti_request tir on tir.id=tat.ti_request_id  ");
		sb.append("join c3par.ti_request_type trt on trt.id=tir.ti_request_type_id  ");
		sb.append("where  ");
		sb.append("trt.request_type='ACV'  ");
		sb.append("and ttt.task_code in('ver_sow')  ");
		sb.append("and tat.activity_status='SCHEDULED'  ");
		sb.append("and tir.process_id not in (select process_id from c3par.ACV_MIGRATION_LOG)  ");
		sb.append("and tir.process_id in (select id from c3par.temp_ti_process)  ");
//		sb.append("and tir.process_id in (select process_id from c3par.email_notification where notification_required='N')  ");
		sb.append("order by tir.process_id  ");
		sb.append(")where rownum<="+maxACV);
		
	/*	sb.append("select process_id,ti_request_id,task_code,bpm_instance_id from( ");
		sb.append("select tir.process_id,tir.id ti_request_id,ttt.task_code,tat.bpm_instance_id ");
		sb.append("from ");
		sb.append("c3par.ti_activity_trail tat ");
		sb.append("join c3par.ti_task_type ttt on tat.activity_id=ttt.id ");
		sb.append("join c3par.ti_request tir on tir.id=tat.ti_request_id ");
		sb.append("join c3par.ti_request_type trt on trt.id=tir.ti_request_type_id ");
		sb.append("where ");
		sb.append("trt.request_type='ACV' ");
		sb.append("and ttt.task_code in('acv_exp') ");
		sb.append("and tat.activity_status='SCHEDULED' ");
		sb.append("and tir.process_id not in (select process_id from c3par.ACV_MIGRATION_LOG) ");
		sb.append("order by tat.id desc ");
		sb.append(")");*/
		

		/*sb.append("select process_id,ti_request_id,task_code,bpm_instance_id from(     ");
		sb.append("select tir.process_id,tir.id ti_request_id,ttt.task_code,tat.bpm_instance_id ");
		sb.append("from  ");
		sb.append("c3par.ti_activity_trail tat ");
		sb.append("join c3par.ti_task_type ttt on tat.activity_id=ttt.id ");
		sb.append("join c3par.ti_request tir on tir.id=tat.ti_request_id ");
		sb.append("join c3par.ti_request_type trt on trt.id=tir.ti_request_type_id ");
		sb.append("join (select max(id) id from c3par.ti_request group by process_id) mx on mx.id=tir.id ");
		sb.append("join (select max(id) id from c3par.ti_activity_trail group by ti_request_id) mxtat on mxtat.id=tat.id ");
//		sb.append("join ti_process tp on tp.id=tir.process_id ");
//		sb.append("join relationship rl on rl.id=tp.relationship_id and rl.relationship_type in('THIRD_PARTY') ");
		sb.append("where ");
		sb.append("trt.request_type='ACV' ");
		sb.append("and ttt.task_code in('ver_sow','acv_exp') ");
		sb.append("and tat.activity_status='SCHEDULED' ");
		sb.append("and tir.process_id not in (select process_id from c3par.ACV_MIGRATION_LOG) ");
		sb.append("and tir.process_id in (select id from c3par.temp_ti_process) ");
		sb.append("and tir.process_id between 30000 and 55000 ");
		sb.append("order by tat.id desc");
		sb.append(")");*/

//		List<Map<String, Object>> maps = jdbcTemplate.queryForList(ccrQueries.getQueryByName(QueryConstants.GET_ACV_RECORDS_FOR_MIGRATION));
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sb.toString());

		for (Map<String, Object> rows : maps) {
			li = new ArrayList<String>();
			li.add(rows.get("ti_request_id")+"");
			li.add((String) rows.get("task_code"));
			li.add((String) rows.get("bpm_instance_id"));
			map.put(rows.get("process_id")+"", li);
		}

		return map;
	}
	
	
	public void triggerACVForMissingInstances(Long conreqId) {

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("TRIGGER_ACV_MISSING_INSTANCES").withSchemaName("C3PAR");

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("A_PROCESS_ID", conreqId);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		simpleJdbcCall.execute(in);
	}
	
	
	public void updateACVMigrationLog(Long conreqId, Long tireqId,
			String logMessage, String status, String instancePresent) {

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("LOGGING_ACV_MIGRATION").withSchemaName("C3PAR");;

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("A_PROCESS_ID", conreqId);
		inParamMap.put("A_TI_REQUEST_ID", tireqId);
		inParamMap.put("A_LOG_MESSAGE", logMessage);
		inParamMap.put("A_STATUS", status);
		inParamMap.put("A_IS_INSTANCE_PRESENT", instancePresent);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		simpleJdbcCall.execute(in);

	}
	
	
	public String getLatestBpmInstanceId(Long processId) {
		StringBuilder sb = new StringBuilder();

		sb.append("select tat.bpm_instance_id ");
		sb.append("from  ");
		sb.append("c3par.ti_activity_trail tat ");
		sb.append("join C3PAR.ti_task_type ttt on tat.activity_id=ttt.id ");
		sb.append("join C3PAR.ti_request tir on tir.id=tat.ti_request_id ");
		sb.append("join C3PAR.ti_request_type trt on trt.id=tir.ti_request_type_id ");
		sb.append("join (select max(id) id from C3PAR.ti_request group by process_id) mx on mx.id=tir.id ");
		sb.append("join (select max(id) id from C3PAR.ti_activity_trail group by ti_request_id) mxtat on mxtat.id=tat.id ");
		sb.append("where ");
		sb.append("trt.request_type='ACV' ");
		sb.append("and ttt.task_code in('ver_sow') ");
		sb.append("and tir.process_id=? ");
//		sb.append("and tir.process_id between 30000 and 55000 ");
		sb.append("and tat.activity_status='SCHEDULED'");
		
		try{

		return (String)jdbcTemplate.queryForObject(sb.toString(), new Object[]{processId},String.class);
		}catch(Exception e)
		{
			return null;
		}

	}
	 
	public void updateACVDatesCorrectly(Long conreqId) {

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("REVERT_ACV_DATES").withSchemaName("C3PAR");;

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("A_PROCESS_ID", conreqId);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		simpleJdbcCall.execute(in);

	}

	public void updateACVFlag(Long tireqId) {

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("UPDATE_ACV_FLAG").withSchemaName("C3PAR");;

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("A_TI_REQUEST_ID", tireqId);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		simpleJdbcCall.execute(in);

	}

	public void updateACVStatusFlag(Long processId, Long tiRequestId,
			String acvFlag) {

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("UPDATE_ACV_STATUS").withSchemaName("C3PAR");;

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("A_PROCESS_ID", processId);
		inParamMap.put("A_TI_REQUEST_ID", tiRequestId);
		inParamMap.put("A_STATUS_FLAG", acvFlag);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		simpleJdbcCall.execute(in);

	}

	public void updateACVDate(Long processId) {
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("UPDATE_ACV_DATE").withSchemaName("C3PAR");;

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("A_PROCESS_ID", processId);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		simpleJdbcCall.execute(in);

	}

	public Map<Long, Long> getACVRecordsAfterExpiration() {
		StringBuilder sb = new StringBuilder();
		Map<Long, Long> map = new HashMap<Long, Long>();

		sb.append("SELECT PROCESS_ID,TI_REQUEST_ID FROM c3par.ACV_STATUS WHERE ACV_STATUS_FLAG='A' ");
		sb.append("and  (PROCESS_ID,TI_REQUEST_ID)  in "); 
		sb.append("("); 
		sb.append("select tir.process_id,tir.id "); 
		sb.append("from   ");
		sb.append("c3par.ti_activity_trail tat "); 
		sb.append("join C3PAR.ti_task_type ttt on tat.activity_id=ttt.id "); 
		sb.append("		join C3PAR.ti_request tir on tir.id=tat.ti_request_id "); 
		sb.append("		join C3PAR.ti_request_type trt on trt.id=tir.ti_request_type_id "); 
		sb.append("		join (select max(id) id from C3PAR.ti_request group by process_id) mx on mx.id=tir.id "); 
		sb.append("join (select max(id) id from C3PAR.ti_activity_trail group by ti_request_id) mxtat on mxtat.id=tat.id "); 
		sb.append("where ");
		sb.append("trt.request_type='ACV' "); 
		sb.append("and ttt.task_code in('ver_sow') "); 
		sb.append("and tat.activity_status='SCHEDULED' "); 
		sb.append("and tir.process_id in (select process_id from C3PAR.ACV_MIGRATION_LOG) "); 
		sb.append("and tir.process_id between 1 and 25000 ");
		sb.append("and tir.process_id in (select id from C3PAR.temp_ti_process) ) ORDER BY ID");
		
		

		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sb
				.toString());

		for (Map<String, Object> rows : maps) {
			map.put((Long.valueOf(rows.get("PROCESS_ID")+"")), (Long.valueOf(rows
					.get("TI_REQUEST_ID")+"")));
		}

		return map;
	}

	public Map<Long, Long> getActiveACVRecords() {
		StringBuilder sb = new StringBuilder();
		Map<Long, Long> map = new HashMap<Long, Long>();

		sb.append("SELECT PROCESS_ID,TI_REQUEST_ID FROM C3PAR.ACV_STATUS WHERE ACV_STATUS_FLAG='P' and process_id between 30000 and 55000  ORDER BY PROCESS_ID");

		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sb
				.toString());

		for (Map<String, Object> rows : maps) {
			map.put((Long.valueOf(rows.get("PROCESS_ID")+"")), (Long.valueOf(rows
					.get("TI_REQUEST_ID")+"")));
		}

		return map;
	}

	public void updateAuditForACV(Long tiRequestId) {

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("UPDATE_AUDIT_FOR_ACV").withSchemaName("C3PAR");;

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("A_TI_REQUEST_ID", tiRequestId);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		simpleJdbcCall.execute(in);

		}
	
	
	public Map<Long, Long> getValidConnectionsForACV() {

		Map<Long, Long> map = new HashMap<Long, Long>();
		
		String sql = "select distinct tp.id PROCESS_ID, tp.id PROCESS_ID_VAL from ti_process tp,ti_activity_trail tat,ti_task_type ttt, ti_request tr where " +
		"(tp.TEMP_APPROVAL_FLAG = NULL or tp.TEMP_APPROVAL_FLAG = 'N') " +
		"and to_date(to_char(tp.ACTIVATION_EXP_DATE,'YYYY/MM/DD'),'YYYY/MM/DD')<=to_date(to_char(sysdate,'YYYY/MM/DD'),'YYYY/MM/DD') " +
		"and tr.process_id = tp.id and tp.version_number= tr.version_number " +
		"and tat.id = (select max(id) from ti_activity_trail tat1 where tat1.ti_request_id = tr.id) " +
		"and tat.activity_id = ttt.id and upper(ttt.task_code)=upper('Active') order by tp.id";

		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sql);

		for (Map<String, Object> rows : maps) {
			map.put((Long.valueOf(rows.get("PROCESS_ID")+"")), (Long.valueOf(rows
					.get("PROCESS_ID_VAL")+"")));
		}

		return map;
	}
	
	
	


}
