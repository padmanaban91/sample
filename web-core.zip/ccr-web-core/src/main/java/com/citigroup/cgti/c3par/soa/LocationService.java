package com.citigroup.cgti.c3par.soa;

/**
 * The Class LocationService.
 */
public class LocationService
{

}
