/*

 * Created on May 27, 2005
 *
 */
package com.citigroup.cgti.c3par.reports.reportInterface;


import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.reports.model.DataSourceEntity;
//import com.citigroup.cgti.c3par.reports.model.GroupDataEntity;
import com.citigroup.cgti.c3par.reports.model.ReportFilterEntity;
import com.mentisys.model.ManyAssociationList;




/**
 * The Interface DataRequester.
 *
 * @author Gerald Robinson
 * 
 * </br>
 * <h1>Description</h1>
 * This interface provides methods to fetch data required to present the
 * report, maintains the user preferences with respect to data.
 */
public interface DataRequester {

    /**
     * This method returns boolean,stating whether to suppress the duplicate data.
     *
     * @return boolean
     */
    public boolean isSuppressDuplicateData();

    /**
     * This method returns boolean,stating whether to suppress the duplicate data.
     *
     * @param suppressDuplicateData the new suppress duplicate data
     * @return void
     */
    public void setSuppressDuplicateData(boolean suppressDuplicateData);

    /**
     * This method returns the total number of rows that can be provided by the
     * this data requester.
     *
     * @return long
     * @throws ReportException the report exception
     */
    public long getRowCount() throws ReportException;

    /*
     * This method returns the current batch size.
     */
    /**
     * Gets the batch size.
     *
     * @return the batch size
     */
    public int getBatchSize();

    /**
     * This method changes the batch size to the given size.
     *
     * @param size the new batch size
     * @return int
     * @throws ReportException the report exception
     */
    public void setBatchSize(int size) throws ReportException;

    /**
     * This method gets data for the first page.
     *
     * @return - com.citigroup.cgti.c3par.reports.util.ReportData
     * @throws ReportException the report exception
     */
    public ReportData getFirstPageData() throws ReportException;

    /**
     * This method gets data for the following page.
     *
     * @return com.citigroup.cgti.c3par.reports.util.ReportData
     * @throws ReportException the report exception
     */
    public ReportData getNextPage() throws ReportException;

    /**
     * This method gets data for the previous page.
     *
     * @return com.citigroup.cgti.c3par.reports.util.ReportData
     * @throws ReportException the report exception
     */
    public ReportData getPrevPage() throws ReportException;

    /**
     * This method returns ReportData instance for the requested page number.
     *
     * @param number the number
     * @return ReportData
     * @throws ReportException the report exception
     */
    public ReportData getPage(long number) throws ReportException;


    /**
     * This method returns ReportData instance containing data starting from row startRowNum
     * with the number of rows specified in count.
     *
     * @param startRowNum the start row num
     * @param count the count
     * @return ReportData
     * @throws ReportException the report exception
     */
    public ReportData getData(long startRowNum, long count) throws ReportException ;


    /**
     * This method returns data of the selected column.
     *
     * @param columnName the column name
     * @return List - TODO-Content of the List - String
     * @throws ReportException the report exception
     */
    public List getColumnData(String columnName)throws ReportException;   

    /**
     * This method returns a list of column names to be provided from the initialize/prepared data set.
     * @return List - TODO-Content of the List - ColoumnMetaEntity or String
     *
     */
    public List getColumns();

    /**
     * This method sets the users preference to provide the selected data columns.
     *
     * @param columnList the new columns
     * @throws ReportException the report exception
     */
    public void setColumns(List columnList) throws ReportException;

    /**
     * This method returns a list of columns on which the data needs to be ordered.
     * @return List -  TODO-Content of the List - ColoumnMetaEntity or String
     */
    public List getSortOrder() ;

    /**
     * This method sets the column list which specifies the ordering of data.
     *
     * @param columnList the new sort order
     * @throws ReportException the report exception
     */
    public void setSortOrder(List columnList) throws ReportException;

    /**
     * This method sets the column list which specifies the ordering of data.
     * The descending parameter indicates whether the data is needed in ascending or descending order.
     *
     * @param columnList the column list
     * @param descending the descending
     * @throws ReportException the report exception
     */
    public void setSortOrder(List columnList, boolean descending) throws ReportException ;

    /**
     * This method returns the DataSourceEntity instance for this DataRequester.
     *
     * @return the data source entity
     */
    public DataSourceEntity getDataSourceEntity();

    /**
     * This method returns a Map of values used for requesting data.
     * @return - Map -  TODO-Content of the Map - InputEntity or String
     */
    public Map getInputValues();

    /**
     * This method sets the input values to be used to get the requested data.
     *
     * @return the report filter entity
     */
    //    public void setInputValues(Map values) throws ReportException;


    public Object getReportFilterEntity();

    /**
     * Sets the report filter entity.
     *
     * @param reportFilter The reportFilter to set.
     * @throws ReportException the report exception
     */
    public void setReportFilterEntity(Object reportFilter)  throws ReportException;

    /**
     * Gets the group data entity.
     *
     * @return the group data entity
     */
    public List getGroupDataEntity();

    /**
     * Sets the group data entity.
     *
     * @param groupDataEntity the new group data entity
     * @throws ReportException the report exception
     */
    public void setGroupDataEntity(ManyAssociationList groupDataEntity) throws ReportException ;

    /**
     * Gets the current page.
     *
     * @return the current page
     * @throws ReportException the report exception
     * @link dependency
     */
    /*#ReportData lnkReportData;*/

    public long getCurrentPage() throws ReportException;

    /**
     * Gets the total page.
     *
     * @return the total page
     * @throws ReportException the report exception
     */
    public long getTotalPage() throws ReportException;

    /**
     * Gets the current record number.
     *
     * @return the current record number
     * @throws ReportException the report exception
     */
    public Long getCurrentRecordNumber() throws ReportException;

    /**
     * Sets the page record.
     *
     * @param pageNumber the page number
     * @param startRecordNumber the start record number
     */
    public void setPageRecord(Integer pageNumber, Integer startRecordNumber);

    /**
     * Gets the page record.
     *
     * @param pageNumber the page number
     * @return the page record
     */
    public Integer getPageRecord(Integer pageNumber);

    /**
     * Gets the rows suppressed.
     *
     * @return the rows suppressed
     */
    public long getRowsSuppressed();

    /**
     * Sets the rows suppressed.
     *
     * @param key the key
     * @param rowsSuppressed the rows suppressed
     */
    public void setRowsSuppressed(Long key, Long rowsSuppressed);

    /**
     * Checks if is filter valid.
     *
     * @return true, if is filter valid
     * @throws ReportException the report exception
     */
    public boolean isFilterValid() throws ReportException ;


    /**
     * Sets the collection filter.
     *
     * @param collectionFilter the new collection filter
     * @throws ReportException the report exception
     */
    public void setCollectionFilter(String collectionFilter)  throws ReportException;

    /**
     * Gets the table name.
     *
     * @return the table name
     */
    public String getTableName();

    /**
     * Sets the collection driver table name.
     *
     * @param collectionDriverTableName the new collection driver table name
     */
    public void setCollectionDriverTableName(String collectionDriverTableName);

    /**
     * Sets the driver ds entity.
     *
     * @param driverDsEntity the new driver ds entity
     */
    public void setDriverDsEntity(DataSourceEntity driverDsEntity);

}
