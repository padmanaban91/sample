package com.citigroup.cgti.c3par.webtier.controller.communication;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.communication.domain.AgentViewProcess;
import com.citigroup.cgti.c3par.communication.domain.CmpConnectionDetail;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.WorkflowResult;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

@Controller
public class AgentViewController {
	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	@Autowired
	WorkflowUtil workflowUtil;
	
	@Autowired
	WorkflowCallServiceHelper wrkflowCallServiceHelper;

	@SuppressWarnings("unused")
	@RequestMapping(value = "/agentViewController.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadAgentView(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("agentViewProcess") AgentViewProcess agentViewProcess)
			throws Exception {

		log.debug("Entering into loadAgentView....");

		String orderBy = "asc";

		if (null != request.getParameter("orderBy")) {
			orderBy = (String) request.getParameter("orderBy");
		}

		String sortingColumnName = null;
		if (null != request.getParameter("columnName")) {
			sortingColumnName = (String) request.getParameter("columnName");

			String sortingColumnNameInSession = (String) request.getSession()
					.getAttribute("selectedColumnName");

			if (sortingColumnName.equalsIgnoreCase(sortingColumnNameInSession)) {
				agentViewProcess.setSameColumnSelected("true");
			}
		}
		log.debug("sortingColumnName::loadAgentView::" + sortingColumnName);
		if (null != request.getParameter("type")) {

			String actionType = (String) request.getParameter("type");
			if ("L".equals(actionType) || "FI".equals(actionType)
					|| "P".equals(actionType) || "N".equals(actionType)
					|| "LA".equals(actionType)) {
				orderBy = (String) request.getSession().getAttribute("OrderBy");
				sortingColumnName = (String) request.getSession().getAttribute(
						"selectedColumnName");

			}

		}

		String temp = sortingColumnName;
		request.getSession().setAttribute("selectedColumnName",
				sortingColumnName);
		sortingColumnName = this.columnNameConversion(sortingColumnName);

		log.debug("orderBy:" + orderBy);
		log.debug("columnName:" + sortingColumnName);

		agentViewProcess.setOrderBy(orderBy);
		agentViewProcess.setSortingColumnName(sortingColumnName);

		// Getting the CMP data from DB

		String soeId = request.getHeader("SM_USER");
		Long userId = agentViewProcess.getUserId(soeId);
		agentViewProcess.setAgent(userId);

		// Pagination

		String type = (String) request.getParameter("type");
		log.debug("loadAgentView::type::" + type);
		int curOffSet = agentViewProcess.getOffset();
		int limit = agentViewProcess.getLimit();
		int pageNo = agentViewProcess.getPageNo();
		int recordStartCount = agentViewProcess.getRecordStartCount();
		int recordEndCount = agentViewProcess.getRecordEndCount();
		int totalRecords = agentViewProcess.getTotalRecords();
		log.debug("agentViewProcess.getTotalRecords()::"
				+ agentViewProcess.getTotalRecords());

		if (agentViewProcess.getOffset() == 0
				&& agentViewProcess.getLimit() == 0
				&& agentViewProcess.getPageNo() == 0) {
			agentViewProcess.setOffset(0);
			agentViewProcess.setLimit(20);
			agentViewProcess.setPageNo(1);
			agentViewProcess.setRecordStartCount(1);
			agentViewProcess.setRecordEndCount(20);

		} else {
			int remainder = (agentViewProcess.getTotalRecords() % (agentViewProcess
					.getLimit()));
			if ("N".equalsIgnoreCase(type)) {
				agentViewProcess.setOffset(curOffSet
						+ agentViewProcess.getLimit());
				if ((agentViewProcess.getTotalRecords() <= (agentViewProcess
						.getRecordEndCount() + agentViewProcess.getLimit()))) {
					agentViewProcess.setRecordEndCount(agentViewProcess
							.getTotalRecords());
				} else {
					agentViewProcess
							.setRecordEndCount((agentViewProcess
									.getRecordEndCount() + agentViewProcess
									.getLimit()));
				}

				agentViewProcess.setRecordStartCount(agentViewProcess
						.getOffset() + 1);
			} else if ("P".equalsIgnoreCase(type)) {
				agentViewProcess.setOffset(curOffSet
						- agentViewProcess.getLimit());
				if (agentViewProcess.getRecordEndCount() == agentViewProcess
						.getTotalRecords()) {

					if (remainder == 0) {
						agentViewProcess.setRecordEndCount((agentViewProcess
								.getRecordEndCount() - agentViewProcess
								.getLimit()));
					} else {
						agentViewProcess.setRecordEndCount((agentViewProcess
								.getRecordEndCount() - remainder));
					}

				} else {
					agentViewProcess
							.setRecordEndCount((agentViewProcess
									.getRecordEndCount() - agentViewProcess
									.getLimit()));
				}
				agentViewProcess.setRecordStartCount(agentViewProcess
						.getOffset() + 1);
			} else if ("L".equalsIgnoreCase(type)) {
				agentViewProcess.setOffset(0);
				agentViewProcess.setRecordStartCount(1);
				if ((agentViewProcess.getTotalRecords() <= (agentViewProcess
						.getLimit()))) {
					agentViewProcess.setRecordEndCount(agentViewProcess
							.getTotalRecords());
				} else {
					agentViewProcess.setRecordEndCount(agentViewProcess
							.getLimit());
				}
				agentViewProcess.setLimit(agentViewProcess.getLimit());
			} else if ("FI".equalsIgnoreCase(type)) {
				agentViewProcess.setOffset(0);
				agentViewProcess.setRecordStartCount(1);
				if ((agentViewProcess.getTotalRecords() <= agentViewProcess
						.getLimit())) {
					agentViewProcess.setRecordEndCount(agentViewProcess
							.getTotalRecords());
				} else {
					agentViewProcess.setRecordEndCount(agentViewProcess
							.getLimit());
				}
			} else if ("LA".equalsIgnoreCase(type)) {
				if (remainder == 0) {
					agentViewProcess.setRecordStartCount(agentViewProcess
							.getTotalRecords()
							- agentViewProcess.getLimit()
							+ 1);
					agentViewProcess.setRecordEndCount(agentViewProcess
							.getTotalRecords());
					agentViewProcess.setOffset((agentViewProcess
							.getTotalRecords())
							- ((agentViewProcess.getLimit())));
				}
				if (remainder >= 1) {
					agentViewProcess.setRecordStartCount((agentViewProcess
							.getTotalRecords()) - (remainder - 1));
					agentViewProcess.setRecordEndCount(agentViewProcess
							.getTotalRecords());
					agentViewProcess.setOffset((agentViewProcess
							.getTotalRecords()) - (remainder));
				}
			} else {
				agentViewProcess.setOffset(0);
				agentViewProcess.setPageNo(1);
			}
		}

		if (request.getParameter("errMsg") != null) {
			agentViewProcess.setErrorMessage("Invalid CCR ID");
		}
		String snURL;
		snURL = agentViewProcess.getSnUrl();
		agentViewProcess.setServicenowURL(snURL);
		agentViewProcess.setResolveITMessageList(agentViewProcess
				.getCmpReqData());
		if(agentViewProcess.getResolveITMessageList() != null)
		{
		log.debug("agentViewProcess.getResolveITMessageList().size()::"
				+ agentViewProcess.getResolveITMessageList().size());
		if (agentViewProcess.getResolveITMessageList().size() <= 0) {
			agentViewProcess.setRecordStartCount(0);
			agentViewProcess.setRecordEndCount(0);
			agentViewProcess.setTotalRecords(0);
		}
		if (agentViewProcess.getResolveITMessageList().size() > 0
				&& type == null || type == "") {
			if (agentViewProcess.getResolveITMessageList().size() <= agentViewProcess
					.getLimit()) {
				agentViewProcess.setRecordEndCount(agentViewProcess
						.getResolveITMessageList().size());
			}
		}
		}
		agentViewProcess.setSelectedColumnName(temp);
		model.addAttribute("agentViewProcess", agentViewProcess);
		model.addAttribute("SelectedColumnName", temp);
		request.setAttribute("orderBy", agentViewProcess.getOrderBy());

		request.getSession().setAttribute("OrderBy",
				agentViewProcess.getOrderBy());
		request.getSession().setAttribute("ColumnName",
				agentViewProcess.getSortingColumnName());
		request.getSession().setAttribute("SelectedColumnName", temp);
		log.debug("Exiting from loadLeadview....");

		return "c3par.communication.agentView";
	}

	/**
	 * Sorting each column according to ColumnName
	 * 
	 */
	private String columnNameConversion(String inputStr) {

		log.debug("The inputStr: " + inputStr);

		String result = "assignedUser";

		if ("CMP REQ ID".equals(inputStr)) {

			result = "orderItemId";
		} else if ("DATE ASSIGNED".equals(inputStr)) {  

			result = "updateAssignedUserDate";
		} else if ("REQUEST TYPE".equals(inputStr)) {

			result = "typeofConnectivityInvolved";
		} else if ("CCR ID".equals(inputStr)) {

			result = "ccrId";
		} else if ("REQUESTER NAME".equals(inputStr)) {

			result = "orderForUser";
		} else if ("REGION".equals(inputStr)) {

			result = "region";
		} else if ("SECTOR".equals(inputStr)) {

			result = "ecmSector";
		}
		else if ("CURRENT STATUS".equals(inputStr)) {

			result = "CURRENT STATUS";  
		}

		return result;
	}

	/**
	 * 
	 * Displaying Connection Details
	 */
	@SuppressWarnings("unused")
	@RequestMapping(value = "/agentConnectionDetails.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String showConnectionDetails(
			ModelMap model,
			@ModelAttribute("agentViewProcess") AgentViewProcess agentViewProcess,
			HttpServletRequest request) {
		log.info("AgentViewController::showConnectionDetails method starts");
		String connectionId = request.getParameter("ccrId");
		if(connectionId!=null && !StringUtils.isEmpty(connectionId)){
			connectionId=connectionId.trim();
		}
		log.info("connectionId:: " + connectionId);
		String orderId = request.getParameter("orderId");
		log.info("orderId" + orderId);
		String bpmForward = "show_Detail";
		String fun_code = "showDetail";
		String phase = null;
		String taskCode = null;
		String participantId = null;
		String bpmActivityId = "";
		Long id = null;
		String ssoId = (String) request.getHeader("SM_USER");
		List<CmpConnectionDetail> processList = agentViewProcess
				.getProcessList(connectionId);

		if (processList != null && processList.size() > 0) {
			for (CmpConnectionDetail processDetail : processList) {
				id = processDetail.getTirequestid();
				phase = processDetail.getPhase();
				taskCode = processDetail.getTaskCode();
				bpmActivityId = processDetail.getBpmActivityId();
				participantId = processDetail.getParticipant();

			}
		}
		if (id != null) {
			return "forward:/bpmIntegrationAction.act?fun_code=showDetail&tireqid="
					+ id
					+ "&PHASE="
					+ phase
					+ "&forward=show_Detail&taskCodeId="
					+ taskCode
					+ "&tiRequestId="
					+ id
					+ "&ssoId="
					+ ssoId
					+ "&bpmActivityId="
					+ bpmActivityId
					+ "&participantId="
					+ participantId + "&ecmView=true&orderId=" + orderId + "";
		} else {
			return "forward:/agentViewController.act?errMsg=true";
		}
	}

	/**
	 * 
	 * Create CCR Connection Details
	 */
	@RequestMapping(value = "/createCCRConnection.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String createCCRConnection(
			ModelMap model,
			@ModelAttribute("agentViewProcess") AgentViewProcess agentViewProcess,
			HttpServletRequest request) throws Exception {
		log.info("AgentViewController::createCCRConnection method starts");
		final String NULL_STRING = "null";
		HttpSession session = request.getSession();
		String connectionName = (String) request.getParameter("processName");
		String relId = (String) request.getParameter("relId");
		String cmpOrderId = (String) request.getParameter("orderId");
		String relStatus = (String) request.getParameter("relStatus");
		String ssoId = (String) request.getHeader("SM_USER");
		String processType = TIProcess.CONNECTION;
		String priority = "";
		log.info("connectionName::" + connectionName + "::relId::" + relId
				+ "::relStatus::" + relStatus + "::cmpOrderId:: " + cmpOrderId);
		Long relationshipId = 0L;
		if (relId != null) {
			relationshipId = Long.valueOf(relId);
		}
		try {
			if (connectionName != null && relId != null && relStatus != null) {
				if (relStatus.equalsIgnoreCase("NOT CERTIFIED")) {
					priority = TIProcessDTO.BUSCRIT;
				} else {
					priority = TIProcessDTO.BAU;
				}
				TIProcessDTO tiProcessDTO = new TIProcessDTO();
				tiProcessDTO.setName(connectionName);
				tiProcessDTO.setRelationshipId(relationshipId);
				tiProcessDTO.setProcessType(processType);
				tiProcessDTO.setRequestorSOEId(ssoId);
				tiProcessDTO.setPriority(priority);
				Long tiRequestId = 0L;
				tiRequestId = agentViewProcess.insertProcess(tiProcessDTO);
				log.info("tiRequestId");
				if (tiRequestId != null) {
					log.info("AgentViewController::createCCRConnection method before send to bpm:"
							+ tiRequestId);
					this.intiatePlanningPhase(tiRequestId);
					/*WsPapiFacade papiCall = new WsPapiFacade();
					papiCall.callCreateProcess(
							tiProcessDTO.getRequestorSOEId(), tiRequestId,
							WsPapiFacade.CreateProcessActivity.FWRequest);*/
					
					if (cmpOrderId != null && !NULL_STRING.equals(cmpOrderId) ) {
						int count = agentViewProcess.updateCCRId(cmpOrderId,
								tiRequestId);
						log.info("CCR Id updated successfully");

						agentViewProcess.updateCmpId(cmpOrderId, tiRequestId);

					}
				}
			}
			if(session.getAttribute("orderId") != null){
				session.removeAttribute("orderId");
			}
		} catch (Exception ex) {
			log.error(ex, ex);
			String errorMsg = ex.toString();
			errorMsg = (errorMsg.lastIndexOf(":") != -1) ? errorMsg
					.substring(errorMsg.lastIndexOf(":") + 1) : errorMsg;
			log.error("errorMsg.." + errorMsg);
		}
		log.info("AgentViewController::createCCRConnection method ends");
		return "forward:/agentViewController.act";
	}
	private void intiatePlanningPhase(long tiRequestId) {
		Map<String, Object> workFlowParams=workflowUtil.buildWorkflowParamsForPlanning(tiRequestId);
		//Intiate  Planning phase
		WorkflowResult workResult=wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, workFlowParams, WorkflowEvent.CREATE, null);
	}
}
