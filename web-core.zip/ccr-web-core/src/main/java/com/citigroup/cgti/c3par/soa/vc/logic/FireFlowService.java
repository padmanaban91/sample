package com.citigroup.cgti.c3par.soa.vc.logic;


/**
 * The Interface FireFlowService.
 */
public interface FireFlowService {

    /**
     * Gets the algo sec connection ticket.
     *
     * @param tiRequestId the ti request Id
     * @return the algo sec connection ticket
     */
    public String getAlgoSecConnectionTicket(Long tiRequestId);
}




