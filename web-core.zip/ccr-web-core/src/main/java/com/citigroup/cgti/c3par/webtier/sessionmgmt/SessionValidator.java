/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.webtier.sessionmgmt;

import javax.servlet.http.HttpServletRequest;



/**
 * This interface defines methods to identify the validity of 
 * the session with respect to the operation/request.
 * 
 * @author pkadam
 *
 */
public interface SessionValidator {

    /**
     * This method should return a true value if the
     * HttpSession is found valid. False otherwise.
     *
     * @param request the request
     * @return true, if is session valid
     */
    boolean isSessionValid(HttpServletRequest request);
}
