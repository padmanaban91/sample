package com.citigroup.cgti.c3par.util;

import java.util.StringTokenizer;

import org.jgroups.Channel;
import org.jgroups.ChannelException;
import org.jgroups.JChannel;
import org.jgroups.Message;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.cache.CacheRelationship;
import com.citigroup.cgti.c3par.webtier.helper.LookupsManager;
import org.apache.log4j.Logger;


/**
 * The Class SynchronizeGenericLookup.
 */
public class SynchronizeGenericLookup implements Runnable
{

    /** The channel. */
    public static Channel channel;

    /** The log. */
    private static Logger log = Logger.getLogger(SynchronizeGenericLookup.class);

    /**
     * Gets the channel.
     *
     * @return the channel
     */
    public synchronized static Channel getChannel()
    {
	return channel;
    }

    /**
     * Initialize.
     *
     * @throws ChannelException the channel exception
     */
    public synchronized void initialize()
    throws ChannelException
    {
	if(channel == null || !channel.isOpen() || !channel.isConnected())
	{
	    String props="UDP:PING:FD:STABLE:NAKACK:UNICAST:FRAG:FLUSH:GMS:VIEW_ENFORCER:STATE_TRANSFER:QUEUE";
	    channel = new JChannel(props);
	    channel.connect(C3parProperties.GROUP_NAME);
	    channel.setOpt(Channel.LOCAL, Boolean.FALSE);
	    Thread t = new Thread(this);
	    t.start();			
	}
    }

    /* (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    public void run()
    {
	while(true)
	{
	    try
	    {
		Object obj = channel.receive(0);
		if(obj instanceof Message)
		{
		    Message msg = (Message)obj;
		    String data = (String)msg.getObject();
		    if(data != null)
		    {
			if(data.equalsIgnoreCase("C3parUsersChanged"))
			{
			    log.debug("Message received is : " + data);
			    //					LookupsManager.resetC3parUserLookup(new C3parSession());
			}
			else if(data.equalsIgnoreCase("GenericLookupChanged"))
			{
			    log.debug("Message received is : " + data);
			    LookupsManager.resetGenericLookup(new C3parSession());
			}
			else if(data.startsWith("RelationShipEntity"))
			{
			    log.debug("Message received is : " + data);
			    StringTokenizer token = new StringTokenizer(data, ",");
			    String entity = token.nextToken();
			    String id = token.nextToken();
			    String action = token.nextToken();
			    String entInstID = token.nextToken();
			    // chaged from groupname to entInstId
			    InvalidateRelationshipCache(action, id, entInstID);
			}
			else if(data.equalsIgnoreCase("ResetRelationShipEntity"))
			{
			    log.debug("Message received is : " + data);
			    CacheRelationship.getInstance().reset();
			}
			else if(data.equalsIgnoreCase("ThirdPartyServiceChanged"))
			{
			    log.debug("Message received is : " + data);
			    LookupsManager.resetThirdPartyServiceLookup(new C3parSession());
			}						
			else if(data.equalsIgnoreCase("ThirdPartyCategoryChanged"))
			{
			    log.debug("Message received is : " + data);
			    LookupsManager.resetThirdPartyCategoryLookup(new C3parSession());
			}
			else
			    log.debug("Message received is : " + data);
		    }
		}
	    }
	    catch(Exception ex)
	    {
		log.error(ex);
		try
		{
		    initialize();
		}
		catch(Exception e)
		{
		    log.error(e);
		    // what to do now?
		}
		break;
	    }
	}
    }

    /**
     * Invalidate relationship cache.
     *
     * @param action the action
     * @param id the id
     * @param entInstID the ent inst id
     */
    private void InvalidateRelationshipCache(String action, String id, String entInstID)
    {
	if(action.equalsIgnoreCase("insert") || 
		action.equalsIgnoreCase("delete") ||
		action.equalsIgnoreCase("update"))
	{
	    CacheRelationship.getInstance().invalidateCache(id, action, entInstID);
	}
	else
	    log.debug("The cache validation action was : " + action + " for relationship " + id );
    }
}