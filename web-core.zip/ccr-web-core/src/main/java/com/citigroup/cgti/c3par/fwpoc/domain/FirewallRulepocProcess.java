package com.citigroup.cgti.c3par.fwpoc.domain;


import com.citigroup.cgti.c3par.fw.domain.OstiaQuestionnaire;


 
public class FirewallRulepocProcess {
	

	private FirewallRulepoc firewallRulepoc;
	
    private OstiaQuestionnaire ostiaQuestionnaires;
    
    private OstiaQuestionnaire requestOstiaQuestionnaires;
    
	public OstiaQuestionnaire getRequestOstiaQuestionnaires() {
		return requestOstiaQuestionnaires;
	}
	public void setRequestOstiaQuestionnaires(
			OstiaQuestionnaire requestOstiaQuestionnaires) {
		this.requestOstiaQuestionnaires = requestOstiaQuestionnaires;
	}
	public OstiaQuestionnaire getOstiaQuestionnaires() {
		return ostiaQuestionnaires;
	}
	public void setOstiaQuestionnaires(OstiaQuestionnaire ostiaQuestionnaires) {
		this.ostiaQuestionnaires = ostiaQuestionnaires;
	}
	public FirewallRulepoc getFirewallRulepoc() {
		return firewallRulepoc;
	}
	public void setFirewallRulepoc(FirewallRulepoc firewallRulepoc) {
		this.firewallRulepoc = firewallRulepoc;
	}  
}
