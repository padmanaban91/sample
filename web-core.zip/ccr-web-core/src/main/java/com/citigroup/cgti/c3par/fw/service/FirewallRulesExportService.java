package com.citigroup.cgti.c3par.fw.service;

import com.citigroup.cgti.c3par.fw.domain.FirewallRulesExport;

public interface FirewallRulesExportService {
	
	FirewallRulesExport exportFirewallRules(Long tiRequestId, Long processId, String requestType, Integer versionNumber) throws Exception;
	String transformObjectXMLtoXSLTemplate(Object objectToTransform,String requestType);
}
