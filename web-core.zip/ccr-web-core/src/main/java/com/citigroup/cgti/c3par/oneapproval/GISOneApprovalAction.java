package com.citigroup.cgti.c3par.oneapproval;

import net.nsroot.eur.servicesolutions.cate.integration.MessageTypeEnum;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionStatusEnum;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;

/**
 * 
 * @author ne36745
 *
 */
public class GISOneApprovalAction extends OneApprovalAction {

    Logger log = Logger.getLogger(GISOneApprovalAction.class);

    /**
     * Process GIS Approve/Reject Action
     */
    @Autowired
    WsPapiFacade papiFacade;

    @Override
    public void process(OneApprovalMessageLog message) {

        String ssoId = null;
        String status = null;
        String comments = null;
        String messageType = null;

        // To get GEID, status and comments
        if (message.getOneApprovalmsgTextList() != null && message.getOneApprovalmsgTextList().size() > 0) {
            String geId = message.getOneApprovalmsgTextList().get(0).getUpdatedByGEId();
            status = message.getOneApprovalmsgTextList().get(0).getStatus();
            comments = message.getOneApprovalmsgTextList().get(0).getComments();
            messageType = message.getOneApprovalmsgTextList().get(0).getMessageType();
            ssoId = getSSOID(geId);
        }

        log.debug("GISOneApprovalAction Status: " + status);
        String approvalSystem = OneApprovalConstants.APPROVAL_SYSTEM_OA;

        if (message.getApproverType() != null && message.getApproverType().equalsIgnoreCase("F")) {
            approvalSystem = OneApprovalConstants.APPROVAL_SYSTEM_OA_FWD;
        } else if (message.getApproverType() != null && message.getApproverType().equalsIgnoreCase("D")) {
            approvalSystem = OneApprovalConstants.APPROVAL_SYSTEM_OA_DEL;
        }

        // Only if the status is APPROVED or REJECTED
        if (MessageTypeEnum.UPDATE.toString().equalsIgnoreCase(messageType)
                && PurchaseOptionStatusEnum.APPROVED.toString().equals(status)
                || PurchaseOptionStatusEnum.REJECTED.toString().equals(status)) {
            try {
                Long userId = getUserID(ssoId);
                if (PurchaseOptionStatusEnum.APPROVED.toString().equals(status)) {
                    log.debug("GISOneApprovalAction activity status to bpm: " + OneApprovalConstants.STATUS_COMPLETED);
                    papiFacade.completeActivity(userId.toString(), getInstanceId(message.getTiRequestId()),
                            OneApprovalConstants.STATUS_COMPLETED);
                } else {
                    log.debug("GISOneApprovalAction activity status to bpm: " + WsPapiFacade.ActivityStatus.REJECTED);
                    papiFacade.completeActivity(userId.toString(), getInstanceId(message.getTiRequestId()),
                            WsPapiFacade.ActivityStatus.REJECTED, WsPapiFacade.ActivityRejectedToRole.PC_ROLE);
                }
                addComments(comments, message.getTiRequestId(), OneApprovalConstants.ROLE_OTRM, getUserID(ssoId),
                        approvalSystem);
            } catch (OperationException_Exception e) {
                log.error(e, e);
            }
        }
    }

}
