package com.citigroup.cgti.c3par.controller.communication;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.EmailGenerationViewProcess;

@Controller
public class CmpDetailsViewController {  
	
	private static Logger log = Logger.getLogger(CmpDetailsViewController.class);
	
	/**
	 * 
	 * @param model
	 * TO loadEcmEmailTool  
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/CmpDetailsView.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String loadCmpDetailsView(ModelMap model,@ModelAttribute("emailGenerationViewProcess") EmailGenerationViewProcess emailGenerationViewProcess,HttpServletRequest request) {
		log.debug("Start ECM email view:emailView .....");
		String cmpReqId = null; 
		
		//user navigated from LeadView page
		if(request.getParameter("cmpReqId") != null){
			cmpReqId = request.getParameter("cmpReqId"); 
			log.info("CmpDetailsViewController :: loadCmpDetailsView :: user navigated from cmpdetails page :: cmpid - "+cmpReqId);
		}		
		CMPRequest cmpRequest =null;
		if(cmpReqId != null && !cmpReqId.isEmpty()){
			cmpRequest = emailGenerationViewProcess.getCMPRequestDetailsByOerderId(cmpReqId);
			log.info("CmpDetailsViewController :: cmpRequest inside ");
		}
		
		
		List<String> urlKey = new ArrayList<String>();
		urlKey.add("CASP_URL");
		// urlKey.add("GLOBAL_DIR_URL");
		urlKey.add("RESOLVE_IT_DETAIL_URL");
		List<GenericLookup> urlList = emailGenerationViewProcess
				.loadGenericLookupData(urlKey);
		if (urlList != null) {
			for (GenericLookup url : urlList) {
				if (url != null && url.getValue1().equalsIgnoreCase("CASP_URL")) {
					emailGenerationViewProcess.setCaspUrl(url.getValue2());
					/*
					 * } else if(url != null &&
					 * url.getValue1().equalsIgnoreCase("GLOBAL_DIR_URL")){
					 * emailGenerationViewProcess
					 * .setGlobalDirUrl(url.getValue2());
					 */
				} else if (url != null
						&& url.getValue1().equalsIgnoreCase(
								"RESOLVE_IT_DETAIL_URL")) {
					emailGenerationViewProcess.setResolveItDetailUrl(url
							.getValue2());
				}
			}
		}

		log.info("CmpDetailsViewController :: cmpRequest  22");
		
		emailGenerationViewProcess.setCmpRequest(cmpRequest); 
		model.addAttribute("emailGenerationViewProcess", emailGenerationViewProcess);   
		
		log.debug("CmpDetailsViewController :: loadCmpDetailsView :: Ends .....");      
		
		log.debug("End ECM Email View .....");
		return "pages/businessjustification/cmpDetails";
	}
	
}
