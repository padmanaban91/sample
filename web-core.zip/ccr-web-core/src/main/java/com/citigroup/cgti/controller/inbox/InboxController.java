package com.citigroup.cgti.controller.inbox;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;
import com.citigroup.cgti.inbox.dto.InboxCustomViewForm;
import com.citigroup.cgti.inbox.dto.InboxDTO;
import com.citigroup.cgti.inbox.dto.InboxParticipantSeachDTO;
import com.citigroup.cgti.inbox.entity.InboxView;
import com.citigroup.cgti.inbox.service.InboxService;
import com.citigroup.cgti.inbox.service.impl.InboxConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class InboxController {

	private static final Logger log = Logger.getLogger(InboxController.class.getName());
	@Autowired
	private InboxService inboxService;
	@Autowired
	private AdminServicePersistable adminServicePersistable;

	@Autowired
	WorkflowUtil workflowUtil;

	@RequestMapping(value = "/getInboxDetails.act", produces = "application/json", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody String getInboxdetails(ModelMap model, HttpServletRequest request,
			@RequestParam int iDisplayStart, @RequestParam int iDisplayLength, @RequestParam int sEcho,
			@RequestParam int iSortingCols, @RequestParam int iSortCol_0, @RequestParam String sSortDir_0)
			throws Exception {
		Long userId = null;
		String applyFilter = null;
		InboxDTO inboxDTO = null;
		Map<String, String> params = new HashMap<String, String>();
		String ssoId = request.getHeader("SM_USER");
		log.info("inbox user id is  ::" + ssoId);
		InboxJson<InboxDTO> inboxJson = new InboxJson<InboxDTO>();
		try {
			if (!StringUtil.isNullorEmpty(ssoId)) {
				userId = adminServicePersistable.getUserId(ssoId);
				params.put("ssoId", ssoId);
			}
			if (userId != null) {
				log.info("inbox user id is : " + userId);
				params.put("defaultView", "true");
				if (!"".equals(request.getSession().getAttribute("inboxDTO"))
						&& request.getSession().getAttribute("inboxDTO") != null) {
					inboxDTO = (InboxDTO) request.getSession().getAttribute("inboxDTO");
					if (InboxConstants.VIEW_FILTER.equals(inboxDTO.getApplyFilter())) {
						params.put(InboxConstants.VIEW_CODE, inboxDTO.getViewFilter());
						params.put(InboxConstants.VIEW_NAME, inboxDTO.getViewName());
						applyFilter = InboxConstants.VIEW_FILTER;
					} else {
						applyFilter = InboxConstants.APPLY_FILTER;
					}
					model.addAttribute("inboxProcess", inboxDTO);
					params = getFilterMap(inboxDTO, params);
					inboxDTO.setCurrPosition(new Integer(iDisplayStart));
					inboxDTO.setPageSize(new Integer(iDisplayLength));
					inboxDTO.setiSortCol_0(new Integer(iSortCol_0));
					inboxDTO.setsSortDir_0(sSortDir_0);
					log.info("applyFilter value :: " + applyFilter);
					inboxDTO = inboxService.getInboxDetails(params, userId.toString(), applyFilter, inboxDTO);

				} else {
					inboxDTO = new InboxDTO();
					inboxDTO.setCurrPosition(new Integer(iDisplayStart));
					inboxDTO.setPageSize(new Integer(iDisplayLength));
					inboxDTO.setiSortCol_0(new Integer(iSortCol_0));
					inboxDTO.setsSortDir_0(sSortDir_0);
					inboxDTO = inboxService.getInboxDetails(params, userId.toString(), InboxConstants.DEFAULT_FILTER,
							inboxDTO);
				}
				int totalRecords;
				if (inboxDTO.getTotalRecords() == null) {
					totalRecords = 0;
				} else {
					totalRecords = inboxDTO.getTotalRecords();
				}
				inboxJson.setAaData(inboxDTO.getInboxList());
				inboxJson.setiTotalDisplayRecords(totalRecords);
				inboxJson.setiTotalRecords(totalRecords);
				return toJson(inboxJson);
			}
		} catch (Exception e) {
			log.error("Error has occured in getInboxdetails :: " + e.toString());
			log.error(e.toString(), e);
		}
		return null;

	}

	private String toJson(InboxJson<?> inboxJson) {
		try {
			return new ObjectMapper().writeValueAsString(inboxJson);
		} catch (JsonProcessingException e) {
			log.error("Error has occurred in toJson method():: " + e.toString());
			log.error(e.toString(), e);
			return null;
		}
	}

	@RequestMapping(value = "/defaultInboxView.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String defaultInboxView(ModelMap model, @ModelAttribute("inboxProcess") InboxDTO inboxDTO,
			HttpServletRequest request) throws Exception {
		Long userId = null;
		List<InboxDTO> inboxList = new ArrayList<InboxDTO>();
		Map<String, String> params = new HashMap<String, String>();
		String ssoId = request.getHeader("SM_USER");
		log.info("inbox user id is " + ssoId);
		if (!StringUtil.isNullorEmpty(ssoId)) {
			userId = adminServicePersistable.getUserId(ssoId);
			params.put("ssoId", ssoId);
		}
		if (userId != null) {
			log.info("inbox user id is " + userId);
			params.put("defaultView", "true");
			if (!"".equals(request.getSession().getAttribute("inboxDTO"))
					&& request.getSession().getAttribute("inboxDTO") != null) {
				inboxDTO = (InboxDTO) request.getSession().getAttribute("inboxDTO");
			} /*else {
				inboxDTO.setUserId(userId);
				inboxDTO = inboxService.customViewByUser(inboxDTO);
				if(inboxDTO!=null && InboxConstants.TRUE.equals(inboxDTO.getIsCustomFilter())){
					log.info("inboxDTO.getIsCustomFilter() ::"+inboxDTO.getIsCustomFilter());
					request.getSession().setAttribute("inboxDTO", inboxDTO);
				}
			}*/
			model.addAttribute("inboxProcess", inboxDTO);
			inboxDTO = (InboxDTO) inboxService.getDropdownValues(userId.toString());
		}
		// log.info("inbox service list sixe is "+inboxList.size());
		// model.addAttribute("inboxList",inboxList);
		model.addAttribute("statusList", inboxDTO.getStatusList());
		model.addAttribute("modeList", inboxDTO.getModeList());
		model.addAttribute("activityList", inboxDTO.getActivityList());
		model.addAttribute("priorityList", inboxDTO.getPriorityList());
		model.addAttribute("phaseList", inboxDTO.getPhaseList());
		model.addAttribute("processList", inboxDTO.getProcessList());
		Map<String, ArrayList<InboxView>> viewList = new HashMap<String, ArrayList<InboxView>>();
		ArrayList<InboxView> customViewList = new ArrayList<InboxView>();
		ArrayList<InboxView> dailyViewList = new ArrayList<InboxView>();
		ArrayList<InboxView> defaultViewList = new ArrayList<InboxView>();
		if (inboxDTO.getViewList() != null && inboxDTO.getViewList().size() > 0) {
			for (InboxView inboxView : inboxDTO.getViewList()) {
				if (inboxView.getGroupViewBy().intValue() == 1) {
					customViewList.add(inboxView);
				} else if (inboxView.getGroupViewBy().intValue() == 2) {
					dailyViewList.add(inboxView);
				} else {
					defaultViewList.add(inboxView);
				}
			}
			if(!CollectionUtils.isEmpty(customViewList))
			viewList.put("Custom View", customViewList);
			viewList.put("Daily View", dailyViewList);
			viewList.put("Default View", defaultViewList);

		}
		model.addAttribute("viewList", viewList);
		model.addAttribute("ssoId", ssoId.toLowerCase());
		model.addAttribute("userId", userId);

		log.info("inbox service list sixe is " + inboxList.size());
		return "c3par.connection.inboxView";
	}

	private Map<String, String> getFilterMap(InboxDTO inboxDTO, Map<String, String> params) {
		if (inboxDTO.getProcessId()!=null && !"".equals(inboxDTO.getProcessId())) {
			String pId = inboxDTO.getProcessId();
			if (pId.contains(".")) {
				pId = pId.split("\\.")[0];
			}
			params.put(InboxConstants.ID, pId);
		}
		if (!"".equals(inboxDTO.getProcessName())) {
			params.put(InboxConstants.DESCRIPTION, inboxDTO.getProcessName());
		}
		if (!"".equals(inboxDTO.getShowActivity())) {
			params.put(InboxConstants.ACTIVITY, inboxDTO.getShowActivity());
		}
		if (!"".equals(inboxDTO.getShowPhase())) {
			params.put(InboxConstants.PHASE, inboxDTO.getShowPhase());
		}
		if (!"".equals(inboxDTO.getShowMode())) {
			params.put(InboxConstants.MODE, inboxDTO.getShowMode());
		}
		if (!"".equals(inboxDTO.getPriority())) {
			params.put(InboxConstants.PRIORITY, inboxDTO.getPriority());
		}
		if (!"".equals(inboxDTO.getStatus())) {
			params.put(InboxConstants.STATUS, inboxDTO.getStatus());
		}
		if (!"".equals(inboxDTO.getShowTiProcess())) {
			params.put(InboxConstants.TI_PROCESS, inboxDTO.getShowTiProcess());
		}
		if (!"".equals(inboxDTO.getInboxUserId())) {
			params.put(InboxConstants.INBOX_USER_ID, inboxDTO.getInboxUserId());
		}
		return params;
	}

	@RequestMapping(value = "/loadInbox.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadInboxView(ModelMap model, @ModelAttribute("inboxProcess") InboxDTO inboxDTO,
			HttpServletRequest request) throws Exception {
		log.info("------------loadInboxView----------------- ");
		Map<String, String> params = new HashMap<String, String>();
		Long userId = null;
		String ssoId = request.getHeader("SM_USER");

		String applyFilter = InboxConstants.APPLY_FILTER;
		if (!StringUtil.isNullorEmpty(ssoId)){
			userId = adminServicePersistable.getUserId(ssoId);
			params.put("ssoId", ssoId);
		}
		if (userId != null) {
			log.info("inboxDTO.getViewFilter() value: " + inboxDTO.getViewFilter());
			if (inboxDTO.getViewFilter() != null && inboxDTO.getViewFilter().length() != 0 && !"0".equals(inboxDTO.getViewFilter())) {
				params.put(InboxConstants.VIEW_CODE, inboxDTO.getViewFilter());
				params.put(InboxConstants.VIEW_NAME, inboxDTO.getViewName());
				applyFilter = InboxConstants.VIEW_FILTER;
				if(inboxDTO.getViewFilter().indexOf(InboxConstants.CUS_VIEWCODE)!= -1){
					inboxDTO.setUserId(userId);
					inboxDTO = inboxService.customViewByUser(inboxDTO);
					if(inboxDTO!=null && InboxConstants.TRUE.equals(inboxDTO.getIsCustomFilter())){
						model.addAttribute("inboxProcess", inboxDTO);
					}
				}
			}
			inboxDTO.setApplyFilter(applyFilter);
		}
		log.info("inboxDTO.getIsShowFilter() value :: " + inboxDTO.getIsShowFilter() + " applyFilter value ::"
				+ applyFilter);
		if (inboxDTO != null && ("true".equals(inboxDTO.getIsShowFilter())
				|| (inboxDTO.getViewFilter() != null && inboxDTO.getViewFilter().length() != 0 && !"0".equals(inboxDTO.getViewFilter())))) {
			request.getSession().setAttribute("inboxDTO", inboxDTO);
		} else {
			log.info(" dto object removed from  session");
			request.getSession().removeAttribute("inboxDTO");
		}
		inboxDTO = (InboxDTO) inboxService.getDropdownValues(userId.toString());
		inboxDTO.setViewFilter(inboxDTO.getViewFilter());
		model.addAttribute("statusList", inboxDTO.getStatusList());
		model.addAttribute("modeList", inboxDTO.getModeList());
		model.addAttribute("activityList", inboxDTO.getActivityList());
		model.addAttribute("priorityList", inboxDTO.getPriorityList());
		model.addAttribute("phaseList", inboxDTO.getPhaseList());
		model.addAttribute("processList", inboxDTO.getProcessList());
		Map<String, ArrayList<InboxView>> viewList = new HashMap<String, ArrayList<InboxView>>();
		ArrayList<InboxView> customViewList = new ArrayList<InboxView>();
		ArrayList<InboxView> dailyViewList = new ArrayList<InboxView>();
		ArrayList<InboxView> defaultViewList = new ArrayList<InboxView>();
		if (inboxDTO.getViewList() != null && inboxDTO.getViewList().size() > 0) {
			for (InboxView inboxView : inboxDTO.getViewList()) {
				if (inboxView.getGroupViewBy().intValue() == 1) {
					customViewList.add(inboxView);
				} else if (inboxView.getGroupViewBy().intValue() == 2) {
					dailyViewList.add(inboxView);
				} else {
					defaultViewList.add(inboxView);
				}
			}
			if(!CollectionUtils.isEmpty(customViewList))
			viewList.put("Custom View", customViewList);
			viewList.put("Daily View", dailyViewList);
			viewList.put("Default View", defaultViewList);

		}
		model.addAttribute("viewList", viewList);
		model.addAttribute("filterMap", params);
		model.addAttribute("ssoId", ssoId.toLowerCase());
		model.addAttribute("userId", userId);
		log.info("Exiting ");
		return "c3par.connection.inboxView";
	}

	@RequestMapping(value = "/inboxPopUp.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String openPoopUp(ModelMap model, @ModelAttribute("inboxProcess") InboxDTO inboxDTO,
			HttpServletRequest request) throws Exception {
		log.info(" Popup window Entering ");
		Long userId = null;
		String taskId = (String) request.getParameter("taskId");
		String tiProcessId = (String) request.getParameter("tiProcessId");
		String ssoId = request.getHeader("SM_USER");
		if (!StringUtil.isNullorEmpty(ssoId)) {
			userId = adminServicePersistable.getUserId(ssoId);
		}
		log.info(" connection taskId is:" + taskId + " and connection tiProcessId is:" + tiProcessId + " userId : "
				+ ssoId);
		if (taskId != null && tiProcessId != null) {
			inboxDTO = (InboxDTO) inboxService.adminDropdownList(Long.parseLong(taskId), Long.parseLong(tiProcessId),
					userId, ssoId);
		}
		model.addAttribute("connectionDetails", inboxDTO);
		return "c3par.connection.inboxPopUp";
	}

	@RequestMapping(value = "/savePopUp.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String savePopUpDetails(ModelMap model, @ModelAttribute("inboxProcess") InboxDTO inboxDTO,
			HttpServletRequest request) throws Exception {
		String ssoId = request.getHeader("SM_USER");
		log.info("inbox user id is " + ssoId);
		log.info("inboxDTO.getTaskId() " + inboxDTO.getTaskId() + " inboxDTO.getTiRequestId() "
				+ inboxDTO.getTiRequestId() + " inboxDTO.getPermissionActivity() " + inboxDTO.getPermissionActivity());
		int updated = 0;
		if (inboxDTO.getCcrTaskId() != null && inboxDTO.getTiRequestId() != null) {
			request.getSession().setAttribute("taskId", inboxDTO.getTaskId());
			// updated =
			// inboxService.unLockActivity(inboxDTO.getCcrTaskId(),inboxDTO.getTiRequestId(),inboxDTO.getPermissionActivity(),ssoId);
			workflowUtil.adminActivity(inboxDTO.getTaskId(), inboxDTO.getCcrTaskId(), inboxDTO.getTiRequestId(),
					inboxDTO.getPermissionActivity(), ssoId.toLowerCase());
		}
		log.info("The is updated :" + updated);
		model.addAttribute("connectionDetails", inboxDTO);
		return "forward:/defaultInboxView.act";
	}

	@RequestMapping(value = "/loadCustomView.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadCustomView(ModelMap model,
			@ModelAttribute("inboxCustomViewForm") InboxCustomViewForm inboxCustomViewForm, HttpServletRequest request)
			throws Exception {
		if(inboxCustomViewForm.getCustomviewCode()!=null && inboxCustomViewForm.getCustomviewCode().indexOf(InboxConstants.CUS_VIEWCODE)!= -1){
			inboxCustomViewForm=inboxService.customViewByViewcode(inboxCustomViewForm);	
		}else{
			inboxCustomViewForm.setCustomviewCode(null);
		}
		model.addAttribute("inboxCustomViewForm", inboxCustomViewForm);
		return "pages/jsp/Inbox/saveAsView";
	}
	
	@RequestMapping(value = "/deleteCustomView.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String deleteCustomView(ModelMap model,HttpServletRequest request)
			throws Exception {
		log.info("Entering");
		String viewCode=request.getParameter("viewCode");
		inboxService.deleteCustomView(viewCode);
		request.getSession().removeAttribute("inboxDTO");
		return "forward:/defaultInboxView.act";
	}

	@RequestMapping(value = "/saveAsView.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String saveAsView(ModelMap model,
			@ModelAttribute("inboxCustomViewForm") InboxCustomViewForm inboxCustomViewForm, HttpServletRequest request)
			throws Exception {
		inboxCustomViewForm = inboxService.saveCustomView(inboxCustomViewForm);
		inboxCustomViewForm.setSaveStatus(InboxConstants.TRUE);
		model.addAttribute("inboxCustomViewForm", inboxCustomViewForm);
		return "pages/jsp/Inbox/saveAsView";
	}

	@RequestMapping(value = "/searchPartcipant.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String searchPartcipant(ModelMap model,
			@ModelAttribute("searchPartcipant") InboxParticipantSeachDTO inboxPartcipant, HttpServletRequest request)
			throws Exception {

		List<InboxParticipantSeachDTO> participantList = inboxService.getParticipantList();

		return "pages/jsp/Inbox/inboxParticipantSearch";
	}
}
