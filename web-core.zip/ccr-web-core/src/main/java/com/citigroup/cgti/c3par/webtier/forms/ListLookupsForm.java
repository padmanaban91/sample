package com.citigroup.cgti.c3par.webtier.forms;

/*
 * CONFIDENTIAL  AND PROPRIETARY
 */
import java.util.List;


/**
 * The Class ListLookupsForm.
 */
public class ListLookupsForm  
{

    /** The m_ lookup defs. */
    private List 	m_LookupDefs;

    /** The m_ lookup value. */
    private	String	m_LookupValue;

    /** The m_ lookup def id. */
    private Long	m_LookupDefId;

    /** The m_ include deleted. */
    private Boolean	m_IncludeDeleted;

    /** The m_ include deleted state. */
    private String	m_IncludeDeletedState;

    /** The m_ have result. */
    private boolean m_HaveResult;
    
    private String	ids;
    
    private String name;
    
    public ListLookupsForm() {
  		 
  	}
    public ListLookupsForm(String ids,String name,String m_LookupValue) {
  		super();
  		this.ids = ids;
  		this.name = name;
  		this.m_LookupValue = m_LookupValue; 
  	}

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
   
	 
	public String getIds() {
		return ids;
	}
	public void setIds(String ids) {
		this.ids = ids;
	}
	/**
     * Gets the lookup value.
     *
     * @return the lookup value
     */
    public String getLookupValue() { return m_LookupValue; }

    /**
     * Sets the lookup value.
     *
     * @param lv the new lookup value
     */
    public void setLookupValue(String lv) { m_LookupValue = lv; }

    /**
     * Gets the lookup def id.
     *
     * @return the lookup def id
     */
    public Long getLookupDefId() { return m_LookupDefId; }

    /**
     * Sets the lookup def id.
     *
     * @param id the new lookup def id
     */
    public void setLookupDefId(Long id) { m_LookupDefId = id; }

    /**
     * Gets the include deleted.
     *
     * @return the include deleted
     */
    public Boolean getIncludeDeleted() { return m_IncludeDeleted; }

    /**
     * Sets the include deleted.
     *
     * @param include the new include deleted
     */
    public void setIncludeDeleted(Boolean include) { m_IncludeDeleted = include; }

    /**
     * Gets the include deleted state.
     *
     * @return the include deleted state
     */
    public String getIncludeDeletedState() { return m_IncludeDeleted == null ? "false" : m_IncludeDeleted.toString(); }

    /**
     * Sets the include deleted state.
     *
     * @param state the new include deleted state
     */
    public void setIncludeDeletedState(String state)
    {
	if(state != null && state.length() > 0)
	{
	    m_IncludeDeleted = Boolean.valueOf(state);
	}
    }

    /**
     * Gets the lookup defs.
     *
     * @return Returns the Lookup Definitions.
     */
    public List getLookupDefs() {
	return m_LookupDefs;
    }

    /**
     * Sets the lookup defs.
     *
     * @param lookup_defs The Lookup Definitions to set.
     */
    public void setLookupDefs(List lookup_defs) {
	m_LookupDefs = lookup_defs;
    }

    /**
     * Gets the have result.
     *
     * @return the have result
     */
    public boolean getHaveResult() { return m_HaveResult; }

    /**
     * Sets the have result.
     *
     * @param flag the new have result
     */
    public void setHaveResult(boolean flag) { m_HaveResult = flag; }

    //==================================================================================
    /**
     * Clear form.
     */
    public void clearForm()
    {
	m_LookupDefs = null;
	m_LookupDefId = null;
	m_LookupValue = "";
	m_HaveResult = false;
    }

}
