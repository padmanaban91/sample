/**
 *
 */
package com.citigroup.cgti.c3par.communication.service;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.GenericLookupDef;
import com.citigroup.cgti.c3par.common.domain.TIActivityTrail;
import com.citigroup.cgti.c3par.common.domain.TITaskType;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestAttachments;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestContactXref;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueSectors;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.CMPRequestPersistable;
import com.citigroup.cgti.c3par.domain.CMPRole;
import com.citigroup.cgti.c3par.fw.domain.ResolveITNotifyLog;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.reports.util.Util;
import com.citigroup.cgti.c3par.soa.model.ProfileEntity;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;
import com.citigroup.cgti.c3par.soa.util.SOAException;

import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfDataField;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfDataFieldGroup;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfDataFieldNameValue;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfPurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.Customer;
import net.nsroot.eur.servicesolutions.cate.integration.DataField;
import net.nsroot.eur.servicesolutions.cate.integration.DataFieldGroup;
import net.nsroot.eur.servicesolutions.cate.integration.DataFieldNameValue;
import net.nsroot.eur.servicesolutions.cate.integration.DataForm;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentItem;
import net.nsroot.eur.servicesolutions.cate.integration.OrderSystem;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOrder;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOrderDocument;
import net.nsroot.eur.servicesolutions.cate.integration.Status;

/**
 * @author eg41091
 * 
 */
@Transactional
public class CMPRequestImpl extends BasePersistanceImpl implements
		CMPRequestPersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(CMPRequestImpl.class);


	@Override
	public Long saveCmpRequestfield(String cmpRequestString) {
		log.debug("saveCmpRequestfield method starts");
		Long id=null; 
		CMPRequest cmpRequest = new CMPRequest();			
		List<CMPRequestContactXref> cmpRequestContactList = new ArrayList<CMPRequestContactXref>();			
		List <CMPRequestAttachments> cmpRequestAttachmentList = new ArrayList<CMPRequestAttachments>();	
		try {					
			List<CMPRole> roleList = getRoles();			
			List<EcmQueueSectors> sectorGroupList = getECMQueueSectors(getSession());			
			List<GenericLookup> urgencyList = getGenericLookupByName(ECMConstants.GENERIC_LOOKUP_REQUEST_URGENCY);
			List<GenericLookup> sloDaysList = getGenericLookupByName(ECMConstants.GENERIC_LOOKUP_SLO_DAYS);

			PurchaseOrderDocument purchaseOrderDocument = null;
			purchaseOrderDocument = PurchaseOrderDocument.Factory.parse(cmpRequestString);
			PurchaseOrder purchaseOrder = purchaseOrderDocument.getPurchaseOrder();
			ArrayOfPurchaseOptionDescription arrayOfPurchaseOptionDescription = purchaseOrder.getPurchaseOptions();
			PurchaseOptionDescription purchaseOptionDescription = arrayOfPurchaseOptionDescription.getPurchaseOptionDescriptionArray(0);
			FulfilmentItem fulfilmentItem = purchaseOptionDescription.getFulfilmentItem();
			// orderId
			cmpRequest.setOrderId(purchaseOptionDescription.getOrderSystem().getOrderID());
			log.debug("Order id:: " + cmpRequest.getOrderId());
			
			cmpRequest.setOrderItemId(purchaseOptionDescription.getOrderSystem().getOrderItemID());
			
			// Status
			Status status = fulfilmentItem.getStatus();
			cmpRequest.setStatus(status.getStatus().toString());
			// step
			cmpRequest.setStep(null);			
			cmpRequest.setAvailableDate(new Date());
			// closed Date
			cmpRequest.setClosedDate(null);
			// Order By User
			cmpRequest.setOrderByUser(purchaseOptionDescription.getOrderSystem().getOrderByUser().getFullname());						
			String geid = purchaseOptionDescription.getOrderSystem().getOrderByUser().getGeid();
			cmpRequest.setOrderBySoeID(geid);
			// orderForUser
			cmpRequest.setOrderForUser(purchaseOptionDescription.getOrderSystem().getOrderForUser().getFullname());
			// order for SOEID
			OrderSystem orderForSOEID = purchaseOptionDescription.getOrderSystem();
			Customer customerForSOEID = orderForSOEID.getOrderForUser();
			ArrayOfDataFieldNameValue arrayForSOEID = customerForSOEID.getAttributes();

			DataFieldNameValue dataFieldNameValueForSOEID[] = arrayForSOEID.getAttributeArray();
			int dataFieldNameValueForSOEIDSize = dataFieldNameValueForSOEID.length;
			for (int i = 0; i < dataFieldNameValueForSOEIDSize; i++) {
				String name = dataFieldNameValueForSOEID[i].getName();
				String value = dataFieldNameValueForSOEID[i].getValue();
				if (name.equalsIgnoreCase(("soeId"))){
					cmpRequest.setOrderForSoeID(value);
				}
			}				
			// Assigned Group
			DataForm dataForm = fulfilmentItem.getDataForm();
			ArrayOfDataFieldGroup dataFieldGroupPrSec1 = dataForm.getDataFieldGroups();
			DataFieldGroup dataFieldGroup[] = dataFieldGroupPrSec1.getDataFieldGroupArray();

			int dataFieldGroupSize = dataFieldGroup.length;

			for (int j = 0; j < dataFieldGroupSize; j++) {
				
				ArrayOfDataField arrayOfDataField = dataFieldGroup[j].getDataFields();
				DataField dataField3[] = arrayOfDataField.getDataFieldArray();
				//int dataFieldSize = dataField3.length;
				for (int ie = 0; ie < dataField3.length; ie++) {
					
					if (dataField3[ie] != null && dataField3[ie].getName() != null) {
						
						// Project sector
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("Project Sector")) {
							
							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
								
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int sec = 0; sec < validValue.length; sec++) {	
									if(validValue[sec] != null){
										cmpRequest.setProjectSector(validValue[sec].getValue());
									}
									for(EcmQueueSectors queueSector : sectorGroupList){
										if(validValue[sec] != null && queueSector != null && queueSector.getSector() != null &&
												validValue[sec].getValue().equalsIgnoreCase(queueSector.getSector().getName())){
											cmpRequest.setEcmSector(queueSector.getEcmQueue().getQueueName());										
										}
									}								
								}
							}
						}
					
						// Request Type
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("Request Type")) {
							
							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int reqType = 0; reqType < validValue.length; reqType++) {
									if(validValue[reqType] != null){
										cmpRequest.setRequestType(validValue[reqType].getValue());
									}
								}
							}
						}
						
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("Indicate the type of assistance required")) {
							
							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
								
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int conn = 0; conn < validValue.length; conn++) {
									if(validValue[conn] != null){
										cmpRequest.setTypeofConnectivityInvolved(validValue[conn].getValue());
									}
								}
							}
						}
						
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("Type of Connectivity Involved")) {
							
							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
								
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int conn = 0; conn < validValue.length; conn++) {
									if(validValue[conn] != null){
										cmpRequest.setTypeofConnectivityInvolved(validValue[conn].getValue());
									}
								}
							}
						}

						// Request Urgency
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& (dataField3[ie].getName().equalsIgnoreCase("Request Urgency"))) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int urg = 0; urg < validValue.length; urg++) {
									for(GenericLookup genericLookup : urgencyList){
										if(validValue[urg] != null && validValue[urg].getValue().equalsIgnoreCase(genericLookup.getValue1())){								
											cmpRequest.setRequestUrgency(genericLookup.getValue2());
										}
									}
								}
							}
						}
						
						//SLO Days
						if(cmpRequest.getRequestUrgency() != null){
							for(GenericLookup genericLookup : sloDaysList){
								if(cmpRequest.getRequestUrgency().equalsIgnoreCase(genericLookup.getValue1())){								
									cmpRequest.setSloDays(Long.valueOf(genericLookup.getValue2()));
								}
							}							
						}

						// Region
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("Region")) {
	
							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int region = 0; region < validValue.length; region++) {
									if(validValue[region] != null){
										cmpRequest.setRegion(validValue[region].getValue());
									}
								}
							}
						}
	
						// Business Justification
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("BUSINESS JUSTIFICATION")) {
	
							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int bus = 0; bus < validValue.length; bus++) {
									if(validValue[bus] != null){
										cmpRequest.setBusinessjustification(validValue[bus].getValue());
									}
								}
							}
						}
	
						// Termination Type
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("Termination Type")) {
	
							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int termType = 0; termType < validValue.length; termType++) {
									if(validValue[termType] != null){
										cmpRequest.setTerminationType(validValue[termType].getValue());
									}
								}
							}
						}
						
						//CCR ID
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("ID_2")) {
	
							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int ccrId = 0; ccrId < validValue.length; ccrId++) {
									if(validValue[ccrId] != null && !StringUtils.isEmpty(validValue[ccrId].getValue()) &&
											!StringUtils.isBlank(validValue[ccrId].getValue().trim())){
											cmpRequest.setCcrId(Util.filterCCRId(validValue[ccrId].getValue().trim()));
										}
									}
							}
						}
						
						// Affected Business
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("Affected Business")) {
	
							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int aff = 0; aff < validValue.length; aff++) {
									if(validValue[aff] != null){
										cmpRequest.setAffectedBusiness(validValue[aff].getName());
									}
								}
							}
						}
	
						// Business Group
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("biz_group")) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int biz = 0; biz < validValue.length; biz++) {
									if(validValue[biz] != null){
										cmpRequest.setBusinessGroup(validValue[biz].getValue());
									}
								}
							}
						}
	
						// Third Party Name
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("Third Party Company Name")) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int com = 0; com < validValue.length; com++) {
									if(validValue[com] != null){
										cmpRequest.setThirdParty(validValue[com].getValue());
									}
								}
							}
						}
	
						// CASP Supplier ID
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("CASP Supplier ID")) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int supp = 0; supp < validValue.length; supp++) {
									if(validValue[supp] != null){
										cmpRequest.setSupplierId(validValue[supp].getValue());
									}
								}
							}
						}
	
						// CASP Detail ID
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("CASP Detail ID")) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int det = 0; det < validValue.length; det++) {
									if(validValue[det] != null){
										cmpRequest.setDetailId(validValue[det].getValue());
									}
								}
							}
						}
						
						//Requestor
						if (dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("Requestor")) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int req = 0; req < validValue.length; req++) {
									CMPRequestContactXref cmpRequestContactRequestor = new CMPRequestContactXref();
									for (CMPRole role : roleList) {
										if (role.getName().equalsIgnoreCase("Requestor")) {
											cmpRequestContactRequestor.setRole(role);
										}
									}
									if (validValue[req] != null && validValue[req].getValue() != null) {								
										cmpRequestContactRequestor.setCiticontact((getUserIdForSsoId(validValue[req].getValue())));								
									}							
									cmpRequestContactList.add(cmpRequestContactRequestor);
								}
							}
						}
	
						// Business Owner SOEID
						if (dataField3[ie].getName() != null
								&& (dataField3[ie].getName().equalsIgnoreCase("Business Owner_SOEID"))) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int primary = 0; primary < validValue.length; primary++) {
									CMPRequestContactXref cmpRequestContactPrimary = new CMPRequestContactXref();
									for (CMPRole role : roleList) {
										if (role.getName().equalsIgnoreCase("Business_Owner")) {
											cmpRequestContactPrimary.setRole(role);
										}
									}
									if (validValue[primary] != null && validValue[primary].getValue() != null) {								
										cmpRequestContactPrimary.setCiticontact((getUserIdForSsoId(validValue[primary].getValue())));								
									}							
									cmpRequestContactList.add(cmpRequestContactPrimary);
								}
							}
						}
						
						// Secondary Business Owner
						if (dataField3[ie].getName() != null
								&& (dataField3[ie].getName().equalsIgnoreCase("Secondary Business Owner") 
										|| dataField3[ie].getName().equalsIgnoreCase("Business Owner - Secondary (must be Citi employee/FTE) *Note, the secondary cannot be the same as primary."))) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int c = 0; c < validValue.length; c++) {
									CMPRequestContactXref cmpRequestContactSecondary = new CMPRequestContactXref();
									for (CMPRole role : roleList) {
										if (role.getName().equalsIgnoreCase("Sec_Business_Owner")) {
											cmpRequestContactSecondary.setRole(role);
										}
									}
									if(validValue[c] != null && validValue[c].getValue() != null){
										cmpRequestContactSecondary.setCiticontact(getUserIdForSsoId(validValue[c].getValue()));
									}
									cmpRequestContactSecondary.setCreated_date(new Date());
									cmpRequestContactList.add(cmpRequestContactSecondary);
								}
							}
						}
						
						//BISO
						if (dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("BISO")) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();						
								for (int sec = 0; sec < validValue.length; sec++) {
									CMPRequestContactXref cmpRequestContactBiso = new CMPRequestContactXref();
									for (CMPRole role : roleList) {
										if (role.getName().equalsIgnoreCase("BISO")) {
											cmpRequestContactBiso.setRole(role);
										}
									}
									if (validValue[sec] != null && validValue[sec].getValue() != null) {
										cmpRequestContactBiso.setCiticontact(getuserIdForgGeid(validValue[sec].getValue()));
									}							
									cmpRequestContactList.add(cmpRequestContactBiso);
								}
							}
						}
	
						// Additional Contacts
						if (dataField3[ie].getName() != null
								&& dataField3[ie].getName().equalsIgnoreCase("Tester SOEID")) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int addCon = 0; addCon < validValue.length; addCon++) {
									CMPRequestContactXref cmpRequestContactTester = new CMPRequestContactXref();
									for (CMPRole role : roleList) {
										if (role.getName().equalsIgnoreCase("business_tester")) {
											cmpRequestContactTester.setRole(role);
										}
									}
									if (validValue[addCon] != null && validValue[addCon].getValue() != null) {
										cmpRequestContactTester.setCiticontact(getUserIdForSsoId(validValue[addCon].getValue()));
									}
									cmpRequestContactTester.setCreated_date(new Date());
									cmpRequestContactList.add(cmpRequestContactTester);
								}
							}
						}
						if (dataField3[ie].getName() != null
								&&  dataField3[ie].getName().equalsIgnoreCase("Coordinator")) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int cor = 0; cor < validValue.length; cor++) {
									CMPRequestContactXref cmpRequestContactTester = new CMPRequestContactXref();
									for (CMPRole role : roleList) {
										if (role.getName().equalsIgnoreCase("coordinator")) {
											cmpRequestContactTester.setRole(role);
										}
									}
									if (validValue[cor] != null && validValue[cor].getValue() != null) {
										cmpRequestContactTester.setCiticontact(getUserIdForSsoId(validValue[cor].getValue()));
									}
									cmpRequestContactTester.setCreated_date(new Date());
									cmpRequestContactList.add(cmpRequestContactTester);
								}
							}
						}
						
						if (dataField3[ie].getName() != null
								&&  dataField3[ie].getName().equalsIgnoreCase("MD")) {

							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
						
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								for (int md = 0; md < validValue.length; md++) {
									CMPRequestContactXref cmpRequestContactMd = new CMPRequestContactXref();
									for (CMPRole role : roleList) {
										if (role.getName().equalsIgnoreCase("Managing Director")) {
											cmpRequestContactMd.setRole(role);
										}
									}
									if (validValue[md] != null && validValue[md].getValue() != null) {
										cmpRequestContactMd.setCiticontact(getuserIdForgGeid(validValue[md].getValue()));
									}
									cmpRequestContactMd.setCreated_date(new Date());
									cmpRequestContactList.add(cmpRequestContactMd);
								}
							}
						}
						
						//Attachments 
						if (dataField3[ie] != null && dataField3[ie].getName() != null
								&& (dataField3[ie].getName().equalsIgnoreCase("Filter_Attachment") 
										|| dataField3[ie].getName().equalsIgnoreCase("Plug_Attachment") 
										|| dataField3[ie].getName().equalsIgnoreCase("SOCKS_Attachment") 
										|| dataField3[ie].getName().equalsIgnoreCase("Instance_Attachment") 
										|| dataField3[ie].getName().equalsIgnoreCase("FreeURL_Attachment") 
										|| dataField3[ie].getName().equalsIgnoreCase("PAC_Attachment") 
										|| dataField3[ie].getName().equalsIgnoreCase("Firewall_Attachment") 
										|| dataField3[ie].getName().equalsIgnoreCase("IPRegisration_Attachment") 
										|| dataField3[ie].getName().equalsIgnoreCase("User_List_Attachment") 
										|| dataField3[ie].getName().equalsIgnoreCase("Enginering_Design_Doc") 
										|| dataField3[ie].getName().equalsIgnoreCase("Additional Information_Document Upload") 
										|| dataField3[ie].getName().equalsIgnoreCase("Additional Information_Document Upload") 
										|| dataField3[ie].getName().equalsIgnoreCase("User_List_Attachment") 
										|| dataField3[ie].getName().equalsIgnoreCase("Proxy_Additional_PAC1_Attachment"))
										
										|| (dataField3[ie].getName().startsWith("Please attach screenshot of the error received.") && dataField3[ie].getName().endsWith("Screenshot should include the browser address"))
										
										|| (dataField3[ie].getName().startsWith("Please attach Screenshot of Citi desktop proxy settings" ) && dataField3[ie].getName().endsWith("Tab, LAN Settings)"))
																
														
								) {
							
							if(dataField3[ie] != null && dataField3[ie].getValidValues() != null && dataField3[ie].getValidValues().getValidValuesList() != null 
									&& dataField3[ie].getValidValues().getValidValuesList().getValidValueArray() != null){
								
								DataFieldNameValue validValue[] = dataField3[ie].getValidValues().getValidValuesList().getValidValueArray();
								
								for (int docName = 0; docName < validValue.length; docName++) {
									
									CMPRequestAttachments cmpRequestAttachment = new CMPRequestAttachments();
									if(validValue[docName] != null){
										if(validValue[docName].getName() != null){
											cmpRequestAttachment.setFileName(validValue[docName].getName());
										}
										if(validValue[docName].getValue() != null){
											cmpRequestAttachment.setAttchedFileUrl(validValue[docName].getValue());	
										}
									}
									if (dataField3[ie] != null && dataField3[ie].getName() != null) {
										cmpRequestAttachment.setAttachmentName(dataField3[ie].getName());
									}
									cmpRequestAttachmentList.add(cmpRequestAttachment);
								}
							}
						}
					}
				}
			}
			
			
			try{			
				id = (Long) getSession().save(cmpRequest);
				log.info("value of id::: "+id);
			}catch(Exception e){
				log.error("Exception::Save CMP Request :: " + e.getMessage());
				e.printStackTrace();
			}			
			
			if (id != null){
				if(cmpRequestContactList != null && cmpRequestContactList.size() > 0) {
				for (CMPRequestContactXref cmpReq : cmpRequestContactList) {
					cmpReq.setCmpId(id);
					getSession().save(cmpReq);
				}
			}
			if(cmpRequestAttachmentList != null && cmpRequestAttachmentList.size() > 0){
					for (CMPRequestAttachments cmpReqattachments : cmpRequestAttachmentList) {
						cmpReqattachments.setCmpId(id);
						getSession().save(cmpReqattachments);
					}
				}				
			}
		   
		} catch (Exception e) {
			log.error("Exception:: " + e.getMessage());
			log.error(e.toString(), e);
			id = (Long) getSession().save(cmpRequest);
			if (id != null){
				if(cmpRequestContactList != null && cmpRequestContactList.size() > 0) {
				for (CMPRequestContactXref cmpReq : cmpRequestContactList) {
					cmpReq.setCmpId(id);
					getSession().save(cmpReq);
				}
			}
			if(cmpRequestAttachmentList != null && cmpRequestAttachmentList.size() > 0){
					for (CMPRequestAttachments cmpReqattachments : cmpRequestAttachmentList) {
						cmpReqattachments.setCmpId(id);
						getSession().save(cmpReqattachments);
					}
				}
			}
		}
		log.debug("saveCmpRequestfield method ends ");
		return id;
	}

	@Transactional(readOnly = true)
	public CitiContact getUserIdForSsoId(String ssoid) {
		log.debug("getUserIdForSsoId method starts");
		Session session = getSession();
		log.debug("ssoid:: " + ssoid);
							
			Query query = session.createQuery("from CitiContact where upper(ssoId) = ?").setString(0, ssoid.toUpperCase());
			List<CitiContact> list = query.list();	
			//session.flush();
			log.debug("Session is flushed successfully.");
			if (list != null && list.size() > 0) {
				return list.get(0);
			}else{
				return addToCitiContact(ssoid, true);
			}			
		
	}
	@Transactional(readOnly = true)
	public CitiContact getuserIdForgGeid(String geid) {
		log.debug("getuserIdForgGeid method starts");
		Session session = getSession();		
		log.debug("geid:: " + geid);											
			Query query = session.createQuery("from CitiContact where upper(geid) = ?").setString(0, geid.toUpperCase());
			List<CitiContact> list = query.list();	
			//session.flush();
			log.debug("Session is flushed successfully.");
			if (list != null && list.size() > 0) {	
			
				return list.get(0);
			} else {
				return addToCitiContact(geid, false);
			}		
	}

	/*public void insertTiActivityTrail(Long cmpId) {
		log.debug("insertTiActivityTrail method starts");		
		String sql = "";
		log.info("cmpId:: " + cmpId);
		try {			
			sql = "insert into c3par.ti_activity_trail (id,activity_id,activity_type,activity_status,user_id,activity_startdate,ACTIVITY_ENDDATE,activity_mode,cmp_id) values "
					+ " (c3par.seq_ti_activity_trail.nextval,(select id from c3par.ti_task_type where task_code = 'cmp_request_create'),'"+ECMConstants.CMP_REQUEST_CREATED+"',"
					+"'"+ECMConstants.STATUS_COMPLETED+"',(select id from c3par.c3par_users where sso_id = 'system'),"
					+ "sysdate,sysdate,'" + ECMConstants.IS_NEW + "'," + cmpId + ")";
			Query query = getSession().createSQLQuery(sql);
			query.executeUpdate();
		} catch (Exception e) {
			log.error(e, e);
		} 
		log.debug("insertTiActivityTrail method ends ");
	}*/

	@SuppressWarnings("unchecked")
    public List<CMPRole> getRoles() {
		Session session = getSession();
		Criteria criteria = session.createCriteria(CMPRole.class);
		criteria.addOrder(Order.asc("id"));
		List<CMPRole> list = criteria.list();
		if (list != null)
			log.debug("CMPRequestImpl ::  getRoles :: size ::"
					+ list.size());
		return list;
	}	
	
	@SuppressWarnings("unchecked")
	private List<EcmQueueSectors> getECMQueueSectors(Session session){
		Criteria crit = session.createCriteria(EcmQueueSectors.class);
		crit.addOrder(Order.asc("id"));		
		List<EcmQueueSectors> list = crit.list();
		if(list != null){
			log.info("CMPRequestImpl ::  getECMQueueSectors :: size ::" +list.size());
		}
		return list;
		
	}
	
	 @SuppressWarnings("unchecked")
    private CitiContact addToCitiContact(String soeId, boolean isSOE) {
	    	log.debug("CMPRequestImpl :: addtoCitiContact Starts");
	    	log.info("soeId : " +soeId +" isSOE : "+isSOE);
	    	
	    	SOADataComponent soaDataComponent = new SOADataComponent();
		    ProfileInfoFactory profileInfoFactory =
			(ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");
		    ProfileEntity profileEntity = new ProfileEntity();
			try {
				if(isSOE) {
					profileEntity.setSoeId(soeId.toUpperCase());
					log.info("SOEID:: " + profileEntity.getSoeId());
				} else  {
					profileEntity.setGeId(soeId.toUpperCase());
					log.info("GEID:: " + profileEntity.getGeId());
				}
				
			} catch (SOAException e) {
				log.error(e.toString(),e);
			}
			List<CitiContact> citiContactList =  null;
			try {
				citiContactList = profileInfoFactory.getRitzService().getProfile(profileEntity,soeId.toUpperCase());
			} catch (RemoteException e) {
			    log.error(e.toString(),e);
			} catch (SOAException e) {
			    log.error(e.toString(),e);
			}
		    Iterator<CitiContact> it = citiContactList.iterator();
		    while(it.hasNext()) {
		    	CitiContact entity = (CitiContact) it.next();
		    	SQLQuery insertQuery = getSession().createSQLQuery("insert into citi_contact(ID,FIRST_NAME,LAST_NAME,RITS_ID,PHONE,EMAIL,SSO_ID,EMPLOYEE_TYPE,GEID,EMPLOYEE_STATUS,SUPERVISOR_GEID,SUPERVISOR_FIRST_NAME,SUPERVISOR_LAST_NAME) " +
		    												" values(seq_citi_contact.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?) ");
		    	insertQuery.setString(0, entity.getFirstName());
		    	insertQuery.setString(1, entity.getLastName());
		    	insertQuery.setString(2, entity.getRitsId());
		    	insertQuery.setString(3, entity.getPhone());
		    	insertQuery.setString(4, entity.getEmail());
		    	insertQuery.setString(5, entity.getSsoId());
		    	insertQuery.setString(6, entity.getEmployeeType());
		    	insertQuery.setString(7, entity.getGeId());
		    	insertQuery.setString(8, entity.getEmployeeStatus());
		    	insertQuery.setString(9, entity.getSupervisorGeId());
		    	insertQuery.setString(10, entity.getSupervisorFirstName());
		    	insertQuery.setString(11, entity.getSupervisorLastName());
		    	insertQuery.executeUpdate();
		    }
			String contactsQuery = "from CitiContact where upper(ssoId) = ?";
			if (!isSOE) {
				contactsQuery = "from CitiContact where upper(geid) = ?";
			}	
			Query query = getSession().createQuery(contactsQuery).setString(0, soeId.toUpperCase());
			List<CitiContact> list = query.list();				
			if (list != null && list.size() > 0) {	
				return list.get(0);
			} 				
			return null;
	    }

	@Transactional(readOnly = true)
	public void cmpActivityTrail(Long cmpId, String ssoId, String taskCode, String activityStatus) {
		
		log.debug("cmpTiActivityTrail method starts :: cmpId:: " + cmpId);		
		StringBuilder sql = new StringBuilder();
		StringBuilder updateSql = new StringBuilder();
		StringBuilder updateSql1 = new StringBuilder();	
		
		if(cmpId!=null){
			int count = updateCmpECMTimer(cmpId,taskCode);// update end date only for the ECM Timer
		}
				
		
		//update end date only for the Business Timer
		if(taskCode != null && (taskCode.equalsIgnoreCase("awaiting_additional_info_resp") || taskCode.equalsIgnoreCase("awaiting_paf_faf_verify_resp")
								|| taskCode.equalsIgnoreCase("awaiting_assist_term_log_resp") || taskCode.equalsIgnoreCase("awaiting_additional_info_assign_resp"))){
			String activityCode="";
			if(taskCode.equalsIgnoreCase("awaiting_additional_info_resp")){
				activityCode = "awaiting_additional_info";
			} else if(taskCode.equalsIgnoreCase("awaiting_paf_faf_verify_resp")){
				activityCode = "awaiting_paf_faf_verify";
			} else if(taskCode.equalsIgnoreCase("awaiting_assist_term_log_resp")){
				activityCode = "awaiting_assist_term_log";
			} else if(taskCode.equalsIgnoreCase("awaiting_additional_info_assign_resp")){
				activityCode = "awaiting_additional_info_assign";
			}
			updateSql1.append("update ti_activity_trail set activity_enddate = sysdate, activity_status = 'COMPLETED' where id in ");
			updateSql1.append(" (select acttrial.id from ti_activity_trail acttrial, ti_task_type ttt where acttrial.activity_id = ttt.id ");
			updateSql1.append(" and acttrial.activity_status = 'STARTED' and ttt.task_code = '"+activityCode+"' and acttrial.cmp_id = "+cmpId+" )");
			
			try {
				SQLQuery updateQuery1 = getSession().createSQLQuery(updateSql1.toString());
				updateQuery1.executeUpdate();
				//getSession().flush();
				log.debug("Session is flushed successfully.");
			} catch (Exception e) {
				log.error(e, e);
			}		
		}
		
		//update for activities - taskcode::Request on Hold and Cancel and closed requests
		if(taskCode != null && (taskCode.equalsIgnoreCase("req_on_hold") || taskCode.equalsIgnoreCase("cmp_cancel_request") || "closed_assitance_req".equals(taskCode))){
			updateSql.append("update ti_activity_trail set activity_enddate = sysdate, activity_status = 'COMPLETED' where id in ");
			updateSql.append(" (select acttrial.id from ti_activity_trail acttrial, ti_task_type ttt where acttrial.activity_id = ttt.id ");
			updateSql.append(" and acttrial.activity_status = 'STARTED' and acttrial.cmp_id = "+cmpId+" )");
		} // update end date for req On hold when req hold released
		else if(taskCode != null && taskCode.equalsIgnoreCase("req_hold_released")) {
			updateSql.append("update ti_activity_trail set activity_enddate = sysdate, activity_status = 'COMPLETED' where id in ");
			updateSql.append(" (select acttrial.id from ti_activity_trail acttrial where acttrial.activity_status = 'STARTED' and ");
			updateSql.append(" acttrial.activity_id in (select id from ti_task_type tt where tt.task_code in ('req_on_hold')) and acttrial.cmp_id = "+cmpId+") ");
		}//update end date for the activities not in  ECM Timer/Business Timer
		
		else { 
			updateSql.append("update ti_activity_trail set activity_enddate = sysdate, activity_status = 'COMPLETED' where id in ");
			updateSql.append(" (select acttrial.id from ti_activity_trail acttrial where acttrial.activity_status = 'STARTED' and ");
			updateSql.append(" acttrial.activity_id not in (select id from ti_task_type tt where tt.task_code in ('awaiting_additional_info', ");
			updateSql.append(" 'awaiting_paf_faf_verify','awaiting_assist_term_log','awaiting_additional_info_assign','cmp_reassign_user','cmp_assign_user', ");
			updateSql.append(" 'awaiting_additional_info_resp','awaiting_paf_faf_verify_resp','awaiting_assist_term_log_resp','awaiting_additional_info_assign_resp','bus_jus_ecm_start','req_on_hold')) and acttrial.cmp_id = "+cmpId+") ");
		}
		try {
			SQLQuery updateQuery = getSession().createSQLQuery(updateSql.toString());
			updateQuery.executeUpdate();
			//getSession().flush();
			log.debug("Session is flushed successfully.");
		} catch (Exception e) {
			log.error(e, e);
		} 
			
		//if cmp is cancelled then log the activity and update end date also
		if(taskCode != null && taskCode.equalsIgnoreCase("cmp_cancel_request")){
			sql.append("insert into c3par.ti_activity_trail (id,activity_id,activity_type,activity_status,user_id,activity_startdate,activity_enddate,activity_mode,cmp_id) values ");
			sql.append(" (c3par.seq_ti_activity_trail.nextval,(select id from c3par.ti_task_type where task_code = ?),(select task from c3par.ti_task_type where task_code = ?),'");
			sql.append(activityStatus + "',(select id from c3par.c3par_users where upper(sso_id) = ?),");
			sql.append("sysdate,sysdate,'" + ECMConstants.IS_NEW + "'," + cmpId + ")");				
		}
		
		
		else{ // log the activity (other than cancel)
			if( "closed_assitance_req".equals(taskCode)){
				log.info("Cmp Id  "+cmpId);
				sql.append("insert into c3par.ti_activity_trail (id,activity_id,activity_type,activity_status,user_id,activity_startdate,activity_enddate,activity_mode,cmp_id) values ");
				sql.append(" (c3par.seq_ti_activity_trail.nextval,(select id from c3par.ti_task_type where task_code = ?),(select task from c3par.ti_task_type where task_code = ?),'");
				sql.append(activityStatus + "',(select id from c3par.c3par_users where upper(sso_id) = ?),");
				sql.append("sysdate,sysdate,'" + ECMConstants.IS_NEW + "'," + cmpId + ")");	
				StringBuilder cmpStatusUpdateQuery= new StringBuilder("update cmp_request set status='COMPLETED',closed_date=sysdate where id="+ cmpId);
				SQLQuery cmpStatusUpdate = getSession().createSQLQuery(cmpStatusUpdateQuery.toString());
				cmpStatusUpdate.executeUpdate();	
				
				log.info("If Ended for  awaiting_assist_term_log_no_add_inofrm_req  "+cmpId);
				
			}
			else{
			
			
			sql.append("insert into c3par.ti_activity_trail (id,activity_id,activity_type,activity_status,user_id,activity_startdate,activity_mode,cmp_id) values ");
			sql.append(" (c3par.seq_ti_activity_trail.nextval,(select id from c3par.ti_task_type where task_code = ?),(select task from c3par.ti_task_type where task_code = ?),'");
			sql.append(activityStatus + "',(select id from c3par.c3par_users where upper(sso_id) = ?),");
			sql.append("sysdate,'" + ECMConstants.IS_NEW + "'," + cmpId + ")");
			}
			
		}

		try {
			SQLQuery query = getSession().createSQLQuery(sql.toString());
			query.setString(0, taskCode);
			query.setString(1, taskCode);
			query.setString(2, ssoId.toUpperCase());
			query.executeUpdate();		
			//getSession().flush();
			log.debug("Session is flushed successfully.");
		} catch (Exception e) {
			log.error(e, e);
		} 
		log.debug("cmpTiActivityTrail method ends ");
	}
	
	private int updateCmpECMTimer(Long cmpId,String taskCode)	{
		log.info("updateCmpECMTimer method starts");		
		StringBuilder updateQuery = new StringBuilder();
		Session session = getSession();
		int row = 0;
		try {	
		String tiSql = "from TIActivityTrail where activity_status='STARTED' and activity_enddate is null and cmp_id="+cmpId+" order by id desc";
		List<TIActivityTrail> tiActTrailList= (List<TIActivityTrail>) session.createQuery(tiSql.toString()).list();	
		log.info("tiActTrailList size of this list::: "+tiActTrailList.size());
		
		Criteria crit = getSession().createCriteria(TITaskType.class);		
		crit.addOrder(Order.desc("id"));
		List<TITaskType> tiTaskTypeList= crit.list();
	
		if(tiActTrailList != null && tiActTrailList.size() > 0 && tiTaskTypeList!=null && tiTaskTypeList.size() > 0){			
			for(TIActivityTrail tiActivityTrail : tiActTrailList){						
				if(tiActivityTrail.getActivity().getTaskCode()!= null && (tiActivityTrail.getActivity().getTaskCode().equalsIgnoreCase("cmp_reassign_user")
						|| tiActivityTrail.getActivity().getTaskCode().equalsIgnoreCase("cmp_assign_user")
						|| tiActivityTrail.getActivity().getTaskCode().equalsIgnoreCase("awaiting_additional_info_resp")
						|| tiActivityTrail.getActivity().getTaskCode().equalsIgnoreCase("awaiting_paf_faf_verify_resp")
						|| tiActivityTrail.getActivity().getTaskCode().equalsIgnoreCase("awaiting_assist_term_log_resp")
						|| tiActivityTrail.getActivity().getTaskCode().equalsIgnoreCase("awaiting_additional_info_assign_resp")
						|| tiActivityTrail.getActivity().getTaskCode().equalsIgnoreCase("bus_jus_ecm_start"))){
					for(TITaskType tiTaskType : tiTaskTypeList){
						if(tiTaskType.getTaskCode() != null && (tiTaskType.getTaskCode().equalsIgnoreCase(taskCode) && tiTaskType.getTaskTimerActivity() != null)){
							updateQuery.append("update ti_activity_trail set activity_enddate = sysdate, activity_status = 'COMPLETED' where id in ");
							updateQuery.append(" (select acttrial.id from ti_activity_trail acttrial where acttrial.activity_status = 'STARTED' and ");
							updateQuery.append(" acttrial.activity_id in (select id from ti_task_type tt where tt.task_code in ('cmp_reassign_user','cmp_assign_user', ");
							updateQuery.append(" 'awaiting_additional_info_resp','awaiting_paf_faf_verify_resp','awaiting_assist_term_log_resp','awaiting_additional_info_assign_resp', ");
							updateQuery.append(" 'bus_jus_ecm_start')) and acttrial.cmp_id = "+cmpId+") ");	
							SQLQuery query = session.createSQLQuery(updateQuery.toString());
							row = query.executeUpdate();	
							//session.flush();
							log.debug("Session is flushed successfully.");
						}						
					}
				}			
			}
			}
		} catch (Exception e) {
			log.error(e, e);
		}
		log.info("updateCmpECMTimer method ends"+row);
		return row;
	}
	
	
	public List<GenericLookup> getGenericLookupByName(String name) {
		Session session = getSession();		
		List<GenericLookup> genericLookupList = (List<GenericLookup>) session.createQuery(
						"from GenericLookup gen" +
						" where gen.genericLookupDef.id= "
								+ getDefinitionId(name)).list();
	    log.debug("Size of list in getGenericLookupByName: "+genericLookupList.size());
	    //session.flush();
	    
	 	return genericLookupList;  
	}
	
	private Long getDefinitionId(String defName) {
		Session session = getSession();
		GenericLookupDef res = (GenericLookupDef) session.createQuery(
				"from GenericLookupDef def where upper(def.name)=upper('"
						+ defName + "')").uniqueResult();
		//session.flush();	
		log.debug("Session is flushed successfully.");
		return res.getId();
	}
	
	@Override
    public byte[] getCmpData(String cmpRequestId) {
        log.info("Entering with CmpRequestId : " + cmpRequestId);
        Session session = getSession();
        byte[] notifyXML = new byte[1024];
        ResolveITNotifyLog resolveITNotifyLog = null;
        Query query = session.createQuery("from ResolveITNotifyLog where cmpID =:cmpRequestId");
        query.setString("cmpRequestId", cmpRequestId);
        log.debug("getCmpData Query :: " + query);
        List<ResolveITNotifyLog> resultList = query.list();
        if (resultList != null && resultList.size() > 0) {
            resolveITNotifyLog = new ResolveITNotifyLog();
            resolveITNotifyLog = resultList.get(0);
            notifyXML = resolveITNotifyLog.getNotificationXML();
        }
        log.info("Exiting with CmpRequestId : " + cmpRequestId);
        return notifyXML;
    }
	
	
	
}