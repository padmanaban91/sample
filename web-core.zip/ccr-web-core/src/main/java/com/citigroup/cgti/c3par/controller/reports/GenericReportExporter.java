package com.citigroup.cgti.c3par.controller.reports;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

public class GenericReportExporter extends AbstractExcelView {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	HSSFWorkbook workbook;

	public HSSFWorkbook getWorkbook() {
		return workbook;
	}

	public void setWorkbook(HSSFWorkbook workbook) {
		this.workbook = workbook;
	}

	@Override
	protected void buildExcelDocument(Map model, HSSFWorkbook workbook,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		log.debug("Entering into buildExcelDocument()...");
		
		setWorkbook(workbook);

		@SuppressWarnings("unchecked")
		Map<String, List> resultMap = (Map<String, List>) model
				.get("resultMap");

		log.debug("The resultMap.size() to excel processing.."
				+ resultMap.size());

		@SuppressWarnings("unchecked")
		List<String> reportColumNameList = resultMap.get("reportColumNameList");
		List<List> dataList = resultMap.get("dataList");
		
		List<String> reportNameList = resultMap.get("reportName");
		
		String reportName = reportNameList.get(0);
		
		log.debug("The received report name: "+reportName);			

		HSSFSheet excelSheet = workbook.createSheet("Report");
		setSelectedReportName(excelSheet,reportName);
		setExcelHeader(excelSheet, reportColumNameList);
		setExcelRows(excelSheet, dataList);

		log.debug("Exit from buildExcelDocument()...");

	}
	
	public void setSelectedReportName(HSSFSheet excelSheet, String reportName) {

		/*
		 * HSSFFont font = getWorkbook().createFont();
		 * font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); HSSFCellStyle style =
		 * workbook.createCellStyle(); style.setFont(font);
		 * style.setFillForegroundColor(HSSFColor.DARK_YELLOW.index);
		 */

		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

		excelSheet.createRow(0).createCell(0).setCellValue("Report Name:  " + reportName);

		excelSheet.createRow(1).createCell(0).setCellValue("Date: " + format.format(new Date()));

	}

	public void setExcelHeader(HSSFSheet excelSheet,
			List<String> reportColumnNameList) {		
		
		HSSFWorkbook workbook= this.getWorkbook();
		HSSFFont font = workbook.createFont();
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFont(font);
		//style.setFillForegroundColor(HSSFColor.BROWN.index);
		
		HSSFRow excelHeader = excelSheet.createRow(2);

		int col = 0;

		for (String columnName : reportColumnNameList) {
			
			excelHeader.createCell(col).setCellStyle(style);
			excelHeader.createCell(col).setCellValue(columnName);			
			col++;
		}

	}	

	public void setExcelRows(HSSFSheet excelSheet, List<List> reportData) {
		int record = 3;

		for (List eachRowList : reportData) {

			int i = 0;
			HSSFRow excelRow = excelSheet.createRow(record++);

			for (Object value : eachRowList) {
				if (null != value) {
					excelRow.createCell(i).setCellValue(value.toString());
				} else {
					excelRow.createCell(i).setCellValue("");
				}
				i++;
			}
		}

	}
}
