package com.citigroup.cgti.c3par.webtier.helper.entity;

import java.util.List;

import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.query.Condition;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.citigroup.cgti.c3par.model.*;


/**
 * The Class CitiResourceManager.
 */
public class CitiResourceManager
{
    //=======================================================================================
    /**
     * Update.
     *
     * @param entity the entity
     * @param dbs the dbs
     * @return the long
     * @throws DatabaseException the database exception
     */
    static public Long update(CitiResourceEntity entity, C3parSession dbs) throws DatabaseException
    {
	Long id = null;
	if(entity != null)
	{
	    CitiResourceDAO dao = new CitiResourceDAO(dbs);
	    dao.update(entity, dbs.getArchiver());
	    id = entity.getId();
	}
	return id;
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void delete(String id, C3parSession dbs) throws DatabaseException
    {
	if(id != null && id.length() > 0)
	{
	    CitiResourceManager.delete(Long.valueOf(id), dbs);
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void delete(Long id, C3parSession dbs) throws DatabaseException
    {
	if(id != null)
	{
	    CitiResourceEntity entity = CitiResourceManager.get(id);
	    CitiResourceManager.delete(entity, dbs);
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param entity the entity
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void delete(CitiResourceEntity entity, C3parSession dbs) throws DatabaseException
    {
	if(entity != null)
	{
	    CitiResourceDAO dao = new CitiResourceDAO(dbs);
	    dao.delete(entity, dbs.getArchiver());
	}
    }

    //=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @return the citi resource entity
     * @throws DatabaseException the database exception
     */
    static public CitiResourceEntity get(String id) throws DatabaseException
    {
	CitiResourceEntity	entity = null;
	if(id != null && id.length() > 0)
	{
	    entity = CitiResourceManager.get(Long.valueOf(id));
	}
	return entity;
    }

    //=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @return the citi resource entity
     * @throws DatabaseException the database exception
     */
    static public CitiResourceEntity get(Long id) throws DatabaseException
    {
	CitiResourceEntity	entity = null;
	if(id != null)
	{
	    CitiResourceDAO dao = new CitiResourceDAO(new C3parSession());
	    entity = dao.get(id);
	}
	return entity;	
    }

    /**
     * Gets the all.
     *
     * @return the all
     * @throws DatabaseException the database exception
     */
    static public List getAll() throws DatabaseException {
	CitiResourceDAO dao = new CitiResourceDAO(new C3parSession());

	Condition condition = new Condition();

	List l = dao.query(condition, false);

	return l ;
    }
}


