package com.citigroup.cgti.c3par.controller.admin;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.citigroup.cgti.c3par.admin.domain.UploadFirewallPolicyProcess;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;



@Controller
public class UploadFirewallPolicyController {
	
	private static Logger log = Logger.getLogger(UploadFirewallPolicyController.class); 
	
	@RequestMapping(value = "/uploadFirewallPolicy.act", method = RequestMethod.GET)
	public ModelAndView initialize(
			ModelMap model,
			@ModelAttribute("uploadFirewallPolicyForm") UploadFirewallPolicyProcess uploadFirewallPolicyForm) {
		if (uploadFirewallPolicyForm == null) {
			uploadFirewallPolicyForm = new UploadFirewallPolicyProcess();
		}
		
		
		uploadFirewallPolicyForm.setMessageFlag("No");
		
		
		Map fireWallTypeMap = uploadFirewallPolicyForm.getFireWallTypeMap();
		model.addAttribute("fireWallTypeList", fireWallTypeMap);
		return new ModelAndView("c3par.admin.uploadFirewall",
				"uploadFirewallPolicyForm", uploadFirewallPolicyForm);

	}
	

	@RequestMapping(value = "/uploadFirewallPolicySearch.act", method = RequestMethod.POST)
	public ModelAndView search(
			ModelMap model,
			@ModelAttribute("uploadFirewallPolicyForm") UploadFirewallPolicyProcess uploadFirewallPolicyForm) {
		if (uploadFirewallPolicyForm == null) {
			uploadFirewallPolicyForm = new UploadFirewallPolicyProcess();
		}
		try{
		Map fireWallTypeMap = uploadFirewallPolicyForm.getFireWallTypeMap();
		model.addAttribute("fireWallTypeList", fireWallTypeMap);
		
		String firewallName = uploadFirewallPolicyForm.getFireWallName().replace('*', '%');
		String managementRegion = uploadFirewallPolicyForm.getManagementRegion().replace('*', '%');
		List<FirewallPolicy> searchlist = uploadFirewallPolicyForm.searchFireWall(firewallName,uploadFirewallPolicyForm.getFireWallType(),managementRegion);
		uploadFirewallPolicyForm.setSearchResult(searchlist);
		
		uploadFirewallPolicyForm.setMessageFlag("No");
		}catch(Exception e){
			uploadFirewallPolicyForm.setMessageFlag("Yes");
			uploadFirewallPolicyForm.setMessage(e.getMessage());
		}
		return new ModelAndView("c3par.admin.uploadFirewall",
				"uploadFirewallPolicyForm", uploadFirewallPolicyForm);

	}
	
	@RequestMapping(value = "/uploadFirewallPolicySearch.act", method = RequestMethod.GET)
	public ModelAndView searchPagination(
			ModelMap model,
			@ModelAttribute("uploadFirewallPolicyForm") UploadFirewallPolicyProcess uploadFirewallPolicyForm) {
		if (uploadFirewallPolicyForm == null) {
			uploadFirewallPolicyForm = new UploadFirewallPolicyProcess();
		}
		try{
		Map fireWallTypeMap = uploadFirewallPolicyForm.getFireWallTypeMap();
		model.addAttribute("fireWallTypeList", fireWallTypeMap);
		
		String firewallName = uploadFirewallPolicyForm.getFireWallName();
		if(firewallName!=null){
			firewallName = firewallName.replace('*', '%');
		}
		String managementRegion = uploadFirewallPolicyForm.getManagementRegion();
		if(managementRegion!=null){
			managementRegion = managementRegion.replace('*', '%');
		}
		
		List<FirewallPolicy> searchlist = uploadFirewallPolicyForm.searchFireWall(firewallName,uploadFirewallPolicyForm.getFireWallType(),managementRegion);
		uploadFirewallPolicyForm.setSearchResult(searchlist);
		
		
		}catch(Exception e){
			uploadFirewallPolicyForm.setMessageFlag("Yes");
			uploadFirewallPolicyForm.setMessage(e.getMessage());
		}
		return new ModelAndView("c3par.admin.uploadFirewall",
				"uploadFirewallPolicyForm", uploadFirewallPolicyForm);

	}

private List parseSheet(HSSFWorkbook workbook, String sheetName) {

	List columns = null;
	List rows = null;

	HSSFSheet sheet = workbook.getSheet(sheetName);
	if (sheet != null) {
	    rows = new ArrayList();
	}

	for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
	    HSSFRow xlRow = sheet.getRow(i);

	    if (xlRow == null) {
		continue;
	    } else {
		int noOfColumns = xlRow.getPhysicalNumberOfCells();

		columns = new ArrayList();

		// for loop for number of cells which have contents
		for (int cellIndx = 0; cellIndx < noOfColumns; cellIndx++) {
		    HSSFCell cell = xlRow.getCell((short) cellIndx);

		    if (cell == null) {
			continue;
		    }

		    String cellValue = getCellValue(cell);
		    if (cellValue != null)
			columns.add(cellValue);
		}
	    }
	    if (columns != null && columns.size() > 0)
		rows.add(columns);
	}

	return rows;
   }

public static String getCellValue(HSSFCell cell) {
	if (cell == null) {
	    return null;
	}
	String cellValue = null;

	switch (cell.getCellType()) {
	case HSSFCell.CELL_TYPE_NUMERIC:
	    cellValue = String.valueOf(cell.getNumericCellValue());
	    break;
	case HSSFCell.CELL_TYPE_STRING:
	    cellValue = cell.getStringCellValue();
	    break;
	}

	return cellValue;
   }



@RequestMapping(value = "/uploadFirewallPolicyDocument.act", method = RequestMethod.POST)
public ModelAndView uploadDocument(
		ModelMap model,
		@ModelAttribute("uploadFirewallPolicyForm") UploadFirewallPolicyProcess uploadFirewallPolicyForm) {
	if (uploadFirewallPolicyForm == null) {
		uploadFirewallPolicyForm = new UploadFirewallPolicyProcess();
	}
	
	Map fireWallTypeMap = uploadFirewallPolicyForm.getFireWallTypeMap();
	model.addAttribute("fireWallTypeList", fireWallTypeMap);
    	String sql = "";
    	try{
    	    POIFSFileSystem fileSystem = null;
    	    InputStream inputStream = null;
    	   
    	    CommonsMultipartFile file = uploadFirewallPolicyForm.getPolicyFile();
    	  
    	   //log.debug("File Content Type=" + file.getContentType() + " File Name" + file.getFileItem().getName());
    	    if(file!=null){
    	    	inputStream = file.getInputStream();
    		 		fileSystem = new POIFSFileSystem(inputStream);
    		 
    		HSSFWorkbook workBook = new HSSFWorkbook(fileSystem);
    		
    		ArrayList resultList = (ArrayList) parseSheet(workBook,  
    			workBook.getSheetName(0));
    		
    		Iterator handle = resultList.iterator();
    		while(handle.hasNext()){
    		log.debug("resultList in UploadFirewallPolicyAction" + handle.next().toString());
    		}
    		sql = "delete from c3par.firewall_stage_data";
    		uploadFirewallPolicyForm.executeSQLs(sql);
    		sql = "delete from c3par.firewall_error_data";
    		uploadFirewallPolicyForm.executeSQLs(sql);   		
    		uploadFirewallPolicyForm.uploadFirewallStageData(resultList);
    		sql = "call FIREWALL_DATA_LOAD";
    		uploadFirewallPolicyForm.executeSQLs(sql);
    		sql = "select FIREWALL_NAME,FIREWALL_TYPE,FIREWALL_POLICY, MANAGEMENT_REGION from c3par.FIREWALL_ERROR_DATA";
    		List error_data = uploadFirewallPolicyForm.executeSQLs(sql);	
    		uploadFirewallPolicyForm.setMessageFlag("Yes");
			uploadFirewallPolicyForm.setMessage("File uploaded successfully. Duplicates were ignored.");
    	    }else{
    	    	uploadFirewallPolicyForm.setMessageFlag("Yes");
    			uploadFirewallPolicyForm.setMessage("Invalid File");
    	    }
    	}catch(Exception e){
			uploadFirewallPolicyForm.setMessageFlag("Yes");
			//uploadFirewallPolicyForm.setMessage(e.getMessage());
			uploadFirewallPolicyForm.setMessage("Invalid File");
		}
    	return new ModelAndView("c3par.admin.uploadFirewall",
			"uploadFirewallPolicyForm", uploadFirewallPolicyForm);

}

}
