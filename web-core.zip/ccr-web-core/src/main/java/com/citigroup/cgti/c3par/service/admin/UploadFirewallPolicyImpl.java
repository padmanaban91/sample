package com.citigroup.cgti.c3par.service.admin;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.common.domain.soc.persist.UploadFirewallPolicyPersistable;
import com.citigroup.cgti.c3par.fw.domain.Firewall;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRegion;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
@Transactional
public class UploadFirewallPolicyImpl extends BasePersistanceImpl implements UploadFirewallPolicyPersistable {

	@Override
	public void uploadFirewallStageData(List resultList) {
		try {
		    List<FirewallPolicy> list = new ArrayList<FirewallPolicy>();
		    List dataList = null;
		    List firewallPolicyList = null;
		    if (resultList != null) {
			  	for (int i = 0; i < resultList.size(); i++) {
			  	   FirewallPolicy fwPolicy = new FirewallPolicy();
				    dataList = new ArrayList();
				    dataList = (ArrayList)resultList.get(i);
				    fwPolicy.setName((String)dataList.get(2));
				    fwPolicy.setFwType((String)dataList.get(1));
				    FirewallRegion regionManagement = getManagementRegion((String)dataList.get(3));
				    
				    fwPolicy.setFirewallRegion(regionManagement);
				    fwPolicy.setCreated_date(new Date());
				    fwPolicy.setDeleteFlag("N");
				  			   
				    Firewall fw = new Firewall();
				    fw.setFirewallName((String)dataList.get(0));
				    fw.setFirewallPolicy(fwPolicy);
				    log.debug("Persisting to Firewall" +i);
				    persistFirewallToDB(fw);
				    }
				}
		} catch (Exception e) {
			throw new BusinessException("Problem while uploading the data");
		}

	}
	
	private void persistFirewallToDB(Firewall fw) {
		try {

			Session session = getSession();
			String fetchFireWallSql = "SELECT fwp FROM  FirewallPolicy AS fwp  WHERE fwp.fwType = '"
					+ fw.getFirewallPolicy().getFwType()
					+ "' and  Upper(fwp.name) like Upper('"
					+ fw.getFirewallPolicy().getName()
					+ "') and fwp.firewallRegion in (Select reg.id from FirewallRegion as reg where Upper(reg.region) like Upper('"
					+ fw.getFirewallPolicy().getFirewallRegion().getRegion()
					+ "'))";
			List firewallPolicyList = (List<FirewallPolicy>) session
					.createQuery(fetchFireWallSql.toString()).list();
			if (firewallPolicyList.isEmpty()) {
				session.persist(fw);
			}
			log.debug("Persisted to Firewall");
		} catch (Exception e) {
			log.error(e, e);
		}

	}

	private FirewallPolicy persistPolicyToDB(FirewallPolicy fwPolicy) {
		log.debug("Inside Policy");
		try{
			Session session = getSession();
			session.beginTransaction();
			Long key = Long.valueOf(session.createSQLQuery( "select SEQ_CON_FW_POLICY.nextval from dual").uniqueResult().toString());
			fwPolicy.setId(key);
			session.save(fwPolicy);
			   log.debug("Persisted to Policy"+key );
			   session.getTransaction().commit();
			}catch(Exception e){
			log.error(e,e);
		}
		return fwPolicy;
		
	}

	private FirewallRegion getManagementRegion(String name) {
		
		Session session = getSession();
		String sql = "from FirewallRegion where region = '"+name+"'";
		log.info("In executeSQL ");
		 try{
			 log.debug("fetchFireWallSql "+ sql);
		    	
			 FirewallRegion result = (FirewallRegion) session.createQuery(sql).uniqueResult();
			 return result;
		 }catch (Exception e) {
			 return null;
		}
		
	}


	@Override
	public List executeSQL(String sql) {
		List result = null;
		Session session = getSession();
		log.info("In executeSQL ");
		 try{
			 log.debug("fetchFireWallSql "+ sql);
		    	
			  result =  (List<FirewallPolicy>) session.createQuery(sql).list();
			 
		 }catch (Exception e) {
			// TODO: handle exception
		}
		 return result;
		
	}

	@Override
	@Transactional(readOnly = true)
	public List<FirewallPolicy> searchFireWall(String fireWallNameSearch,
			String fireWallTypeSearch, String managementRegionSearch){
		List<FirewallPolicy> firewallPolicyList = null;
		Session session = getSession();
		log.info("In searchFireWall ");
		
		    try{
/*		    	StringBuffer fetchFireWallSql = new StringBuffer("SELECT fwp FROM  FirewallPolicy AS fwp  WHERE");
		    	
		    			if((fireWallTypeSearch!=null) && (!fireWallTypeSearch.equalsIgnoreCase(""))){
		    					fetchFireWallSql.append("  fwp.fwType = '"+fireWallTypeSearch+"' and ");
		    			}
		    			if((fireWallNameSearch!=null) && (!fireWallNameSearch.equalsIgnoreCase(""))){
		    				fetchFireWallSql.append(" Upper(fwp.name) like Upper('"+fireWallNameSearch+ "') and ");
		    			}
		    			if((managementRegionSearch!=null) && (!managementRegionSearch.equalsIgnoreCase(""))){
		    				fetchFireWallSql.append(" fwp.firewallRegion in (Select reg.id from FirewallRegion as reg where Upper(reg.region) like Upper('"+managementRegionSearch+"'))");
		    			}*/
		    					
		    		StringBuffer fetchFireWallSql = new StringBuffer("SELECT fwp FROM  FirewallPolicy AS fwp WHERE");
				    	
		    			if((fireWallTypeSearch!=null) && (!fireWallTypeSearch.equalsIgnoreCase(""))){
		    					fetchFireWallSql.append(" fwp.fwType = '"+fireWallTypeSearch+"' and ");
		    			}
		    			if((managementRegionSearch!=null) && (!managementRegionSearch.equalsIgnoreCase(""))){
		    				fetchFireWallSql.append(" fwp.firewallRegion in (Select reg.id from FirewallRegion as reg where Upper(reg.region) like Upper('"+managementRegionSearch+"')) and");
		    			}
		    			if((fireWallNameSearch!=null) && (!fireWallNameSearch.equalsIgnoreCase(""))){
		    				fetchFireWallSql.append("( Upper(fwp.name) like Upper('"+fireWallNameSearch+ "') or (fwp.id in (Select fw.firewallPolicy.id from Firewall AS fw where Upper(fw.firewallName) like Upper('"+fireWallNameSearch+ "'))))");
		    			}
		    			
		    	log.debug("fetchFireWallSql "+ fetchFireWallSql.toString());
		    	
		    	firewallPolicyList=  (List<FirewallPolicy>) session.createQuery(fetchFireWallSql.toString()).list();
		    	
		    	log.debug("firewallPolicyList "+ firewallPolicyList.size());
		    	Iterator handle = firewallPolicyList.iterator();
	    		while(handle.hasNext()){
	    		log.debug("firewallPolicyList in UploadFirewallPolicyAction" + handle.next().toString());
	    		}
		      }
		    catch (HibernateException e)
		    {
		    	log.error(e,e);
		//	throw new DatabaseException("Could not load " + EntitlementDataDAO.ENTITY_NAME + " with id = " + id_to_get, e);
		    }
		    
		return firewallPolicyList;
		
	}
}
