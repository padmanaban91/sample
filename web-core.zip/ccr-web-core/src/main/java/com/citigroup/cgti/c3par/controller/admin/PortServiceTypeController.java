package com.citigroup.cgti.c3par.controller.admin;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.citigroup.cgti.c3par.admin.domain.PortServiceTypeProcess;
import com.citigroup.cgti.c3par.fw.domain.PortServiceMapping;

@Controller
public class PortServiceTypeController {

	private static Logger log = Logger
			.getLogger(PortServiceTypeController.class);


	@RequestMapping(value = "/portServiceTypeAction.act", method = RequestMethod.GET)
	public ModelAndView initialize(
			ModelMap model,
			@ModelAttribute("portServiceTypeForm") PortServiceTypeProcess portServiceTypeForm) {
		log.info("initialize in PortServiceTypeController");
		return new ModelAndView("c3par.admin.portServiceMapping",
				"portServiceTypeForm", portServiceTypeForm);

	}
/**
 * 
 * @param model
 * @param portServiceTypeForm
 * @param result
 * @return
 */
	@RequestMapping(value = "/portServiceTypeAddAction.act", method =  { RequestMethod.GET, RequestMethod.POST })
	private String add(ModelMap model,@ModelAttribute("portServiceTypeForm") PortServiceTypeProcess portServiceTypeForm,
			BindingResult result) {
		log.info("Enter add in PortServiceTypeController begins");
		
		try {
			if (portServiceTypeForm == null) {
				portServiceTypeForm = new PortServiceTypeProcess();
			}
		
			
			if (portServiceTypeForm.existPortServiceMapping(Long.valueOf(portServiceTypeForm.getPortIdString())) == false) {
				PortServiceMapping portServiceMapping= new PortServiceMapping();
				portServiceMapping.setIsNew("Y");
				portServiceMapping.setCreated_date(new Date());
				portServiceMapping.setDescription(portServiceTypeForm.getDescription());
				portServiceMapping.setPortId(Long.valueOf(portServiceTypeForm.getPortIdString()));
				portServiceMapping.setServiceType(portServiceTypeForm.getService());
				portServiceMapping.setDisabled(false);
		    	portServiceTypeForm.insertPortServiceMapping(portServiceMapping);
				portServiceTypeForm.setPortIdString("");
				portServiceTypeForm.setDescription("");
				portServiceTypeForm.setService("");
				portServiceTypeForm.setSearchPortIdString("");
				portServiceTypeForm.setSearchService("");
				model.addAttribute("isMessage","Y");
				portServiceTypeForm.validate("Port - "+ portServiceMapping.getPortId()+""+ " added successfully");
				 
			} else {
				PortServiceMapping portServiceMapping= new PortServiceMapping();
				portServiceMapping.setPortId(Long.valueOf(portServiceTypeForm.getPortIdString()));
				model.addAttribute("isMessage","N");
				portServiceTypeForm.validate("Port - "+ portServiceMapping.getPortId()+"" + " already exist");
				
				
			}
			model.addAttribute("portServiceTypeForm",portServiceTypeForm);
			log.info("add in PortServiceTypeController ends"); 
		} 
		catch (Exception e) {
			model.addAttribute("isError","Y");
			log.error(e,e);
			ObjectError error = new ObjectError("name",e.getMessage());
			result.addError(error);
		}
		return "c3par.admin.portServiceMapping";
				 
	}

	@RequestMapping(value = "/portServiceTypeSearchAction.act", method = RequestMethod.POST)
	public ModelAndView search(
			ModelMap model,
			@ModelAttribute("portServiceTypeForm") PortServiceTypeProcess portServiceTypeForm,
			BindingResult result) {

		log.info("search in PortServiceTypeController begins");

		List<PortServiceMapping> results = new ArrayList();
		
		if (portServiceTypeForm == null) {
			portServiceTypeForm = new PortServiceTypeProcess();
		}

		try {
			
			if (!portServiceTypeForm.getSearchPortIdString().isEmpty()) {
				results = portServiceTypeForm.findByPortId(Long.valueOf(portServiceTypeForm.getSearchPortIdString()));
			} else if (!portServiceTypeForm.getSearchService().isEmpty()) {
				results = portServiceTypeForm.findByServiceType(portServiceTypeForm.getSearchService());
			}
			portServiceTypeForm.setSearchResults(results);
			
		} catch (Exception e) {
			model.addAttribute("isError","Y");
			model.addAttribute("isMessage","N");
			ObjectError error = new ObjectError("name","Exception has occurred, search failed");
			result.addError(error);
		} 
		log.debug("searchResults in PortServiceTypeController ends");
		return new ModelAndView("c3par.admin.portServiceMapping",
				"portServiceTypeForm", portServiceTypeForm);
	}

	@RequestMapping(value = "/portServiceTypeUpdateAction.act", method = RequestMethod.POST)
	public ModelAndView update(
			ModelMap model,
			@ModelAttribute("portServiceTypeForm") PortServiceTypeProcess portServiceTypeForm,
			BindingResult result, HttpServletRequest request)
			{
		log.debug("update in PortServiceTypeController begins");
		Long actualPortId = Long.valueOf(0);
		String actualAppRunning = null;
		ModelAndView view = search(model, portServiceTypeForm, result);
		
		try {

		
		PortServiceMapping portServiceMapping = portServiceTypeForm.getPortServiceMapping(portServiceTypeForm.getUpdateID());
		actualPortId = portServiceMapping.getPortId();
		actualAppRunning = portServiceMapping.getServiceType();
		portServiceMapping.setPortId(portServiceTypeForm.getUpdatePort());
		portServiceMapping.setServiceType(portServiceTypeForm.getUpdateService());
		portServiceMapping.setDescription(portServiceTypeForm.getUpdateDescription());
		
		portServiceTypeForm.updatePortServiceMapping(portServiceMapping);
		portServiceTypeForm.setSearchPortIdString(portServiceTypeForm.getUpdatePort().toString());
		view = search(model, portServiceTypeForm, result);
		portServiceTypeForm.setPortIdString(actualPortId.toString());
		model.addAttribute("isMessage","Y");
		portServiceTypeForm.setPortIdString("");
		portServiceTypeForm.setDescription("");
		portServiceTypeForm.setService("");
		portServiceTypeForm.setSearchPortIdString("");
		portServiceTypeForm.setSearchService(""); 
		portServiceTypeForm.validate("Port - "+ portServiceMapping.getPortId()+"" + " edited successfully");	
		log.info("update in PortServiceTypeController ends");
		}
		catch (Exception e) {
			model.addAttribute("isError","Y");
			ObjectError error = new ObjectError("name",e.getMessage());
			result.addError(error);
			portServiceTypeForm.setSearchPortIdString(actualPortId.toString()); 
			view = search(model, portServiceTypeForm, result); 

		}

		return view;
		
	}
	

	@RequestMapping(value = "/portServiceTypeDeleteAction.act", method = RequestMethod.POST)
	public ModelAndView delete(
			ModelMap model,
			@ModelAttribute("portServiceTypeForm") PortServiceTypeProcess portServiceTypeForm, 
			BindingResult result)
			{
		log.info("delete in PortServiceTypeController begins");
		try {
			
			PortServiceMapping portServiceMapping = portServiceTypeForm.getPortServiceMapping(portServiceTypeForm.getUpdateID());
			List connectionIDs = portServiceTypeForm.getConnections(portServiceMapping.getPortId());
			if (connectionIDs != null) {
				if (connectionIDs.size() == 1) {
					portServiceTypeForm.deletePortServiceMapping(portServiceMapping);
					model.addAttribute("isMessage","Y");
					portServiceTypeForm.setPortIdString("");
					portServiceTypeForm.setDescription("");
					portServiceTypeForm.setService("");
					portServiceTypeForm.setSearchPortIdString("");
					portServiceTypeForm.setSearchService(""); 
					portServiceTypeForm.validate("Port - "+ portServiceMapping.getPortId()+"" + " deleted successfully");	 
				} else {
					model.addAttribute("isMessage","N");
					portServiceTypeForm.validate("Some Connection in process is using the Port/Application Running combination, so it cannot be deleted");
				}
			}else{
				portServiceTypeForm.deletePortServiceMapping(portServiceMapping);
				model.addAttribute("isMessage","Y");
				portServiceTypeForm.setPortIdString("");
				portServiceTypeForm.setDescription("");
				portServiceTypeForm.setService("");
				portServiceTypeForm.setSearchPortIdString("");
				portServiceTypeForm.setSearchService(""); 
				portServiceTypeForm.validate("Port - "+ portServiceMapping.getPortId()+"" + " deleted successfully");
			}
			
			portServiceTypeForm = new PortServiceTypeProcess();
			log.info("delete in PortServiceTypeController ends");
		
		}
		catch (Exception e) {
			log.error(e,e);
			model.addAttribute("isError","Y");
			ObjectError error = new ObjectError("name",e.getMessage());
			result.addError(error);
		}
		
		return new ModelAndView("c3par.admin.portServiceMapping",
				"portServiceTypeForm", portServiceTypeForm);

	}
}
