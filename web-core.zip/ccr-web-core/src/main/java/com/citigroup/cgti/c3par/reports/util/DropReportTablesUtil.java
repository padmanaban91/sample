package com.citigroup.cgti.c3par.reports.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.citigroup.cgti.c3par.DropReportTableLog;


/**
 * Added to drop temp tables created as part of report generation
 * @author ai82302
 *
 */
public class DropReportTablesUtil {
	
	/**
	 * 
	 */
    private JdbcTemplate jdbcTemplateCCR;
    
    /**
     * 
     */
	public DropReportTablesUtil() {}



	private Logger log = Logger.getLogger(DropReportTablesUtil.class);
	
	
	public void setJdbcTemplateCCR(JdbcTemplate jdbcTemplateCCR) {
		this.jdbcTemplateCCR = jdbcTemplateCCR;
	}

	/*1. Fetch the list of report tables older than 5 days
	 *2. Insert the report table names into the log table
	 *3. Drop the report tables
	 * 
	 * */
	//Fetch the list of report tables older than 5 days
	
	public void clearTempTables()
	{
		log.info("*************Start of clearTempTables******************");
		log.debug("Get list of tables to be dropped");
		
		String fetchTempTables = "Select obj.object_name, obj.created, sysdate from all_objects obj where obj.object_type = 'TABLE' "+ 
								"and regexp_like(obj.object_name, '[A-Z]{2}[0-9]{18}') and obj.created < (sysdate - 5) ";
		log.debug("fetch table list query" +fetchTempTables);
		 RowMapper<DropReportTableLog> tempTableMapper = new RowMapper<DropReportTableLog>() {  
		        public DropReportTableLog mapRow(ResultSet rs, int rowNum) throws SQLException {
		        	DropReportTableLog temptableNamesFromMapper = new DropReportTableLog();
		        	temptableNamesFromMapper.setTempTableName(rs.getString("object_name"));
		        	temptableNamesFromMapper.setCreatedDate(rs.getDate("created"));
		        	temptableNamesFromMapper.setDeletedDate(rs.getDate("sysdate"));
		            return temptableNamesFromMapper;
		            
		        }
		    };
		    
		    try{
			    final List<DropReportTableLog> tempTablesToBeDeleted = jdbcTemplateCCR.query(fetchTempTables, tempTableMapper);
			    log.info("list of tables size "+ tempTablesToBeDeleted.size());
			    if(tempTablesToBeDeleted.size()>0){
			    	updateLogTable(tempTablesToBeDeleted);
			    }
		    }
		    catch (DataAccessException e) {
		    	log.error(e, e);
		    	e.printStackTrace();
			} 
		    log.info("*************End of clearTempTables******************");
		}


	/**
	 * 
	 * @param tempTablesToBeDeleted
	 */
	//Insert the report table names into the log table
	
	private void updateLogTable(final List<DropReportTableLog> tempTablesToBeDeleted) {
		log.info("*******Start of updateLogTable*****");
		
		final String dynamicInsert = "INSERT INTO C3PAR.DROP_REPORT_TABLE_LOG (ID, TEMP_TABLE_NAME, CREATED_DATE, DELETED_DATE) values (c3par.SEQ_DROP_REPORT_TABLE_LOG.nextval,?,?,?)";
	           
		log.debug("insert sql:" +dynamicInsert);
		try{
			int[] noofRowsInserted = jdbcTemplateCCR.batchUpdate(dynamicInsert, new BatchPreparedStatementSetter() {
				
			 
				public void setValues(PreparedStatement pstmt, int i) throws SQLException {
					        pstmt.setString(1, tempTablesToBeDeleted.get(i).getTempTableName());
					        pstmt.setDate(2, (java.sql.Date) tempTablesToBeDeleted.get(i).getCreatedDate());
					        pstmt.setDate(3, (java.sql.Date) tempTablesToBeDeleted.get(i).getDeletedDate());
				}
				
			 
				public int getBatchSize() {
					// TODO Auto-generated method stub
					 return tempTablesToBeDeleted.size();
				}
			});
			log.debug("Total number of rows inserted "+noofRowsInserted.length);
			
			if(tempTablesToBeDeleted.size()>0 && noofRowsInserted.length>0){
				dropTempTables(tempTablesToBeDeleted);
				}
			}
		catch (DataAccessException e) {
			// TODO: handle exception
			log.error(e, e);
			e.printStackTrace();
		}
		log.info("*******End of updateLogTable*****");
		
	}


	/**
	 * 
	 * @param tempTablesToBeDeleted
	 */
	//Drop the report tables
	private void dropTempTables(List<DropReportTableLog> tempTablesToBeDeleted) {
		
		log.info("*******Start of dropTempTables*****");
		Connection conn;
		Statement st = null;
		StringBuilder sql;
		try {
			conn = jdbcTemplateCCR.getDataSource().getConnection();
			st=conn.createStatement();
			for(DropReportTableLog ctt : tempTablesToBeDeleted)
			{
				sql =  new StringBuilder("DROP TABLE ");
				sql.append(ctt.getTempTableName());
				//sql.append(";");
				
				st.addBatch(sql.toString());
				log.info("drop sql's" +sql.toString());
				
			}
			st.executeBatch();
		} catch (SQLException e) {
			log.error(e, e);
			e.printStackTrace();
		}
		log.info("*******End of dropTempTables*****");
		
		}
	}



	

