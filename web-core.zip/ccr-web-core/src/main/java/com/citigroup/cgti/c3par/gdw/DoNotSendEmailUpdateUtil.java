package com.citigroup.cgti.c3par.gdw;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.bpm.ejb.useradmin.GDWUser;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;

public class DoNotSendEmailUpdateUtil {

	private JdbcTemplate jdbcTemplateCCR;
	private JdbcTemplate jdbcTemplateGDW;
	
	Logger log = Logger.getLogger(this.getClass().getName());

	public void setJdbcTemplateCCR(JdbcTemplate jdbcTemplateCCR) {
		this.jdbcTemplateCCR = jdbcTemplateCCR;
	}

	public void setJdbcTemplateGDW(JdbcTemplate jdbcTemplateGDW) {
		this.jdbcTemplateGDW = jdbcTemplateGDW;
		
	}
	
	/*
	 * The method to retrieve the details of user whose CitiContactId is null
	 * @nc43495
	 */

	public void sync_GDW() {
		log.info("Inside DoNotSendEmailUpdateUtil:getContactDetails method starts...");
		Set<String> ssoIDList = new HashSet<String>();
		String query = "select distinct sso_id from c3par.DO_NOT_SEND_LIST where CITI_CONTACT_ID is null";
		ssoIDList = new HashSet<String>(jdbcTemplateCCR.queryForList(query, String.class));
		log.info("List of ssoID:"+ssoIDList);
		
		List<CitiContact> citiContact = getCitiContactID(ssoIDList);
		
		
		
		if(citiContact!=null && !citiContact.isEmpty()){
			//update donotsendemail table from citiCOntact table
			batchUpdate(citiContact);
		}else{
			List<GDWUser> contactDetails = getContactDetailsFromGDW(ssoIDList);
			batchInsert(contactDetails);
			List<CitiContact> citiContactId = getCitiContactID(ssoIDList);
			batchUpdate(citiContactId);
		}
		
		
	}
	
	/*
	 * The method to get citiContactId from CitiContact table
	 * @nc43495
	 */
	public List<CitiContact> getCitiContactID(Set<String> ssoIDList ){
		log.info("Inside DoNotSendEmailUpdateUtil:getCitiContactID method starts...");
		//Check whether citiContactID exists in Citi_contact table
		CitiContact citiContact ;
		List<CitiContact> idList = new ArrayList<CitiContact>();
    	for(String soeID  :ssoIDList ) {
		String citiContactQuery = "select id,sso_id from c3par.citi_contact where upper(sso_id) in ('"+soeID.toString()+"')";
		SqlRowSet rs = jdbcTemplateCCR.queryForRowSet(citiContactQuery);
		
		while(rs.next()){
			citiContact = new CitiContact();
			citiContact.setId(rs.getLong(1));
			citiContact.setSsoId(rs.getString(2));
			idList.add(citiContact);
		}
    	}
		log.info("Inside DoNotSendEmailUpdateUtil:getCitiContactID method ends..."+idList.size());
		return idList;
		
	}
	
	/*
	 * The method to retrieve Contact Details from GDW
	 * @nc43495
	 */
	public List<GDWUser> getContactDetailsFromGDW(Set<String> ssoIDList){
		log.info("Inside DoNotSendEmailUpdateUtil:getContactDetailsFromGDW method starts here...");
		List<GDWUser> gdwUserList = new ArrayList();
		
		for (String ssoID : ssoIDList) {
			String GDWQuery = "select distinct e.soeid,e.firstname,e.lastname,e.rits_id,e.phone,e.email,e.geid," +
								" e.employee_status,e.supervisor_geid,m.email as memail,m.geid as mgeid,m.firstname as mfirstname,m.lastname as mlastname " +
								" from  rdspr.gdw_user e ,rdspr.gdw_user m where  e.supervisor_geid=m.geid" +
								" and upper(e.soeid) = upper(?)";
			
			List<Map<String, Object>> rows = jdbcTemplateGDW.queryForList(GDWQuery,new Object[]{ssoID});
			
			log.info("GDW Details"+rows.size()+"||"+GDWQuery);
			
			for (Map row : rows) {
				GDWUser gdwUser = new GDWUser();
				gdwUser.setSoeid((String) row.get("soeid"));
				gdwUser.setFirstname((String) row.get("firstname"));
				gdwUser.setLastname((String) row.get("lastname"));
				gdwUser.setRits_id((String) row.get("rits_id"));
				gdwUser.setPhone((String) row.get("phone"));
				gdwUser.setEmail((String) row.get("email"));
				gdwUser.setGeid((String) row.get("geid"));
				gdwUser.setEmployee_status((String) row.get("employee_status"));
				gdwUser.setSupervisor_geid((String) row.get("supervisor_geid"));
				gdwUser.setSupervisor_firstname((String) row.get("mfirstname"));
				gdwUser.setSupervisor_lastname((String) row.get("mlastname"));
				gdwUserList.add(gdwUser);
				log.info("GDW..loop"+gdwUser.getSoeid());
				
			}
			log.info("GDW..loop..."+gdwUserList.size());
		}
		log.info("Inside DoNotSendEmailUpdateUtil:getContactDetailsFromGDW method ends..."+gdwUserList.size());
		return gdwUserList;
	}
	
	/*
	 * The method to update CitiContactId in DonotSendEmail table
	 * @nc43495
	 */
	public void batchInsert(final List<GDWUser> contactDetails){
		log.info("Batch insert into citiContact table starts here ..");
		
		String insertCitiContactQuery = "insert into c3par.citi_contact(ID,FIRST_NAME,LAST_NAME,RITS_ID,PHONE,EMAIL,SSO_ID,GEID,EMPLOYEE_STATUS,SUPERVISOR_GEID,SUPERVISOR_FIRST_NAME,SUPERVISOR_LAST_NAME) " +
										" values(c3par.seq_citi_contact.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?) ";
		
		try {
			int[] noofRowsInserted = jdbcTemplateCCR.batchUpdate(insertCitiContactQuery,
					new BatchPreparedStatementSetter() {
						public void setValues(PreparedStatement ps, int i)
								throws SQLException {
							ps.setString(1, contactDetails.get(i).getFirstname());
							ps.setString(2, contactDetails.get(i).getLastname());
							ps.setString(3, contactDetails.get(i).getRits_id());
							ps.setString(4, contactDetails.get(i).getPhone());
							ps.setString(5, contactDetails.get(i).getEmail());
							ps.setString(6, contactDetails.get(i).getSoeid());
							ps.setString(7, contactDetails.get(i).getGeid());
							ps.setString(8, contactDetails.get(i).getEmployee_status());
							ps.setString(9, contactDetails.get(i).getSupervisor_geid());
							ps.setString(10, contactDetails.get(i).getSupervisor_firstname());
							ps.setString(11, contactDetails.get(i).getSupervisor_lastname());
							
						}

						@Override
						public int getBatchSize() {
							// TODO Auto-generated method stub
							return contactDetails.size();
						}
					});
			log.info("Total number of rows inserted " + noofRowsInserted.length);
		} catch (DataAccessException e) {
			log.error(e,e);
			e.printStackTrace();
		}
	}	
		/*
		 * The method to update DonotSendEmailList
		 * @nc43495
		 */
		public void batchUpdate(final List<CitiContact> citiContactList){
			log.info("Batch update of citiContact ID in DoNotSendEmail starts here...");
			
			String updateQuery = "update c3par.DO_NOT_SEND_LIST set citi_contact_id = ? where upper(sso_id) = upper(?)";
			
			try {
			int[] noofRowsUpdated = jdbcTemplateCCR.batchUpdate(updateQuery, new BatchPreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement pstmt, int i) throws SQLException {
					        pstmt.setLong(1, citiContactList.get(i).getId());
					        pstmt.setString(2, citiContactList.get(i).getSsoId());
				}
				
				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					 return citiContactList.size();
				}
			});
			
			log.info("Total number of rows updated " + noofRowsUpdated.length);
		}catch (DataAccessException e) {
			log.error(e,e);
			e.printStackTrace();
		}
		
	}

}
