package com.citigroup.cgti.c3par.controller.communication;

import java.beans.PropertyEditorSupport;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule;
import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants;
import com.citigroup.cgti.c3par.communication.domain.EmailTemplateUpdationProcess;
import com.citigroup.cgti.c3par.domain.ConnectionDetailEmailVO;

@Controller
public class MailTemplateUpdateController implements MailModuleConstants{
	
	@Autowired
	IMailModule mailModuleImpl;
	private static Logger log = Logger.getLogger(MailTemplateUpdateController.class);
	
	
	@InitBinder
	public void binder(WebDataBinder binder) {binder.registerCustomEditor(Timestamp.class,
	    new PropertyEditorSupport() {
	        public void setAsText(String value) {
	            try {
	            	if(value == null || value.trim().length()==0)
	            		return;
	                Date parsedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(value);
	                setValue(new Timestamp(parsedDate.getTime()));
	            } catch (ParseException e) {
	                setValue(null);
	                log.error("Failed to parse timestamp",e);
	            }
	        }
	    });
	}
	
	@RequestMapping(value = "/updateMailTemplate.act", method = {RequestMethod.GET})
	public String loadMailTemplateUpdateView(ModelMap model,@ModelAttribute("emailTemplateUpdationProcess") EmailTemplateUpdationProcess emailTemplateUpdationProcess,
			HttpServletRequest request) {
		
		emailTemplateUpdationProcess.setEmailTemplateList(mailModuleImpl.getAllMailTemplates());
		emailTemplateUpdationProcess.setSelectedTemplateId("TEST");
		
		model.addAttribute("emailTemplateUpdationProcess", emailTemplateUpdationProcess);

		log.debug("EmailGenerationViewController :: loadEmailGenerationView :: Ends .....");

		return "c3par.communication.mailTemplateUpdateView";
		
	}

	@RequestMapping(value = "/updateMailTemplate.act", method = { RequestMethod.POST })
	public String submitMailTemplateUpdateView(ModelMap model,@ModelAttribute("emailTemplateUpdationProcess") EmailTemplateUpdationProcess emailTemplateUpdationProcess,
			HttpServletRequest request) {
		String templateId = request.getParameter("templateToUpdate");
		
		log.info("****submitMailTemplateUpdateView - templateId"+templateId+"Updated by"+emailTemplateUpdationProcess.getSelectedTemplateUpdatedBy());
		log.info("****submitMailTemplateUpdateView - body"+emailTemplateUpdationProcess.getSelectedTemplateBody());
		log.info("****submitMailTemplateUpdateView - getSelectedTemplateId"+emailTemplateUpdationProcess.getSelectedTemplateId());
		if(emailTemplateUpdationProcess.getSelectedTemplateBody() != null && !emailTemplateUpdationProcess.getSelectedTemplateBody().isEmpty()){
			mailModuleImpl.updateMailTemplate(emailTemplateUpdationProcess.getSelectedTemplateUpdatedBy(), emailTemplateUpdationProcess.getSelectedTemplateSubject(), 
					templateId, emailTemplateUpdationProcess.getSelectedTemplateBody());
		}
		
		emailTemplateUpdationProcess.setSelectedTemplateId(templateId);
		emailTemplateUpdationProcess.setEmailTemplateList(mailModuleImpl.getAllMailTemplates());
		
		model.addAttribute("emailTemplateUpdationProcess", emailTemplateUpdationProcess);

		log.debug("EmailGenerationViewController :: loadEmailGenerationView :: Ends .....");

		return "c3par.communication.mailTemplateUpdateView";
		
	}
	
		
	private ConnectionDetailEmailVO createDummyConnectionDetailEmailVO(){
		ConnectionDetailEmailVO ceo = new ConnectionDetailEmailVO();
		return ceo;
	}
	
}
