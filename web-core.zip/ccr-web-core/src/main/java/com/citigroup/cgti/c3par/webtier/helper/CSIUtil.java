/**
 *
 */
package com.citigroup.cgti.c3par.webtier.helper;

import java.rmi.RemoteException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.domain.ConnectionDetailEmailVO;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.soa.model.ApplicationDetailEntity;
import com.citigroup.cgti.c3par.soa.model.ProfileEntity;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaImpl.softwareAssetInfo.SoftwareAssetInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;
import com.citigroup.cgti.c3par.soa.softwareasset.ApplicationInfoType;
import com.citigroup.cgti.c3par.soa.softwareasset.BusinessFunctionalityType;
import com.citigroup.cgti.c3par.soa.softwareasset.BusinessInfoType;
import com.citigroup.cgti.c3par.soa.softwareasset.DomainServicesFault;
import com.citigroup.cgti.c3par.soa.softwareasset.IdentificationInfoType;
import com.citigroup.cgti.c3par.soa.softwareasset.ManagersInfoType;
import com.citigroup.cgti.c3par.soa.softwareasset.PersonNameType;
import com.citigroup.cgti.c3par.soa.softwareasset.SecurityInfoType;
import com.citigroup.cgti.c3par.soa.softwareasset.TechnicalInfoType;
import com.citigroup.cgti.c3par.soa.util.SOAException;


/**
 * The Class CSIUtil.
 *
 * @author ny02689
 */
@Component
public class CSIUtil {

	/** The log. */
    private static Logger log = Logger.getLogger(CSIUtil.class);
    private static final int SQL_BATCH_UPDATE_LIMIT = 1000;
    
	private JdbcTemplate jdbcTemplateCCR;
	private JdbcTemplate jdbcTemplateCSI;

	private boolean webServiceFlag;
	
	public boolean isWebServiceFlag() {
		return webServiceFlag;
	}

	public void setWebServiceFlag(boolean webServiceFlag) {
		this.webServiceFlag = webServiceFlag;
	}

	@Autowired
	SessionFactory sessionFactory;
	
	public JdbcTemplate getJdbcTemplateCCR() {
		return jdbcTemplateCCR;
	}


	public void setJdbcTemplateCCR(JdbcTemplate jdbcTemplateCCR) {
		this.jdbcTemplateCCR = jdbcTemplateCCR;
	}
	
	public JdbcTemplate getJdbcTemplateCSI() {
		return jdbcTemplateCSI;
	}


	public void setJdbcTemplateCSI(JdbcTemplate jdbcTemplateCSI) {
		this.jdbcTemplateCSI = jdbcTemplateCSI;
	}


	/**
     * Refresh csi values in ti application.
     *
     * @param applicationIds the application ids
     * @param remoteUser the remote user
     */
	public void refreshCSIValuesInTIApplication(Set<String> applicationIds,String remoteUser,boolean isWebService) {
		try {
			log.debug("Inside refreshCSIValuesInTIApplication! ");
			SOADataComponent soaDataComponent = new SOADataComponent();
			SoftwareAssetInfoFactory softwareAssetInfoFactory = (SoftwareAssetInfoFactory)
			soaDataComponent.getServiceFactory("softwareAssetInfo"); 
			List<ApplicationInfoType> infoType=null;
			Map<String, String> map = new HashMap<String, String>();
			String applicationId = null;
			int count=0;

			ApplicationDetailEntity applicationDetailEntity = new ApplicationDetailEntity();
			List<Map<String,String>> batchUpdateList = new ArrayList<Map<String,String>>();

			log.debug("isWebService : " +isWebService);
			log.debug("applicationIds.size() : " +applicationIds.size());
			if(applicationIds.size()>0) {
			if(isWebService){				
				for (Object element : applicationIds) {
					applicationId = (String) element;
					map.put("applicationId", applicationId);
					applicationDetailEntity.setAppId(map.get("applicationId"));
					log.debug("appli id : " +applicationId);
					log.debug("remote User : "+remoteUser);
					
					try {
						infoType = softwareAssetInfoFactory.getCSIService().getApplicationDetails(applicationDetailEntity,remoteUser);
					} catch (Exception e) {
						// log.error("Exception during External Service Invocation");
						log.error("Exception during webservice call to getApplicationDetails");
					}
					
					if(infoType!=null){
						log.debug("After SOA Invocation ");
						//test++; //to be removed after testing
						for (int i = 0; i < infoType.size(); ++i) {
							map.put("businessOwnerID", infoType.get(i).getBusinessInfo().getBusinessOwnerID());
							map.put("businessOwnerName", infoType.get(i).getBusinessInfo().getBusinessOwnerName().getNameValue());
							map.put("productManagerID", infoType.get(i).getManagersInfo().getProductManagerID());
							map.put("productManagerName", infoType.get(i).getManagersInfo().getProductManagerName().getNameValue());
							log.debug("appli status" +infoType.get(i).getIdentificationInfo().getStatus());
							
							if("Delete".equalsIgnoreCase(infoType.get(i).getIdentificationInfo().getStatus()) 
									|| "Retired".equalsIgnoreCase(infoType.get(i).getIdentificationInfo().getStatus()) ){ 
									//|| test <=30) { //to be removed after testing
								log.debug("To Update Decomission Flag" +map.get("applicationId"));
								updateApplicationData(map.get("applicationId"));
							}
							else{
								log.debug("deleted appli");
							}
						}
						try {
							map.put("businessOwnerEmail",getEmail(remoteUser,map.get("businessOwnerID")));
							map.put("productManagerEmail",getEmail(remoteUser,map.get("productManagerID")));
						} catch (Exception e) {
							log.error("Exception in Retreiving Mail Details.");
						}
						batchUpdateList.add(map);
						if(batchUpdateList.size()==applicationIds.size() || batchUpdateList.size()%SQL_BATCH_UPDATE_LIMIT==0){
							count++;
							log.debug("Batch Update Count: "+count);
							updateCSIData(batchUpdateList);
							batchUpdateList.clear();
						}
					}
					map.clear();
				}
			} else {
				log.debug("calling refreshCSIValuesInTIApplicationJDBCCall!");
				refreshCSIValuesInTIApplicationJDBCCall(applicationIds, remoteUser);
			}	
			}
		} catch (Exception e) {
			log.error("Exception in refreshCSIValuesInTIApplication", e);
		}
	}

	
	/**
	 * 
	 * @param applicationIds
	 * @param remoteUser
	 */
	private void refreshCSIValuesInTIApplicationJDBCCall(Set<String> applicationIds,String remoteUser) {
		log.info("Inside refreshCSIValuesInTIApplicationJDBCCall!");
		Map<String, String> map = new HashMap<String, String>();
	
		List<Map<String,String>> batchUpdateList = new ArrayList<Map<String,String>>();
		
		List<ApplicationInfoType> infoType = getApplicationDetailsFromCSIDB(applicationIds);
		
		int count = 0;
		boolean doBatchUpdate = false;
		
		if (infoType!=null) {
			
			for (int i=0; i < infoType.size(); i++) {
				
				
				if (i != 0) {
					i = i+1;
				}
				
				if (i == (infoType.size())) {
					break;
				}
				
				ApplicationInfoType o = infoType.get(i);
				
				for (int n = i+1; n < infoType.size(); n++) {
					
					ApplicationInfoType oo = infoType.get(n);
					
					if (Integer.parseInt(o.getIdentificationInfo().getSIMONAppID()) == Integer.parseInt(oo.getIdentificationInfo().getSIMONAppID())) {
						
						map = new HashMap<String, String>();
											
						if (o.getIdentificationInfo() != null) {					
							map.put("applicationId", o.getIdentificationInfo().getSIMONAppID());
						}
						
						if (o.getBusinessInfo() != null) {
							map.put("businessOwnerID", o.getBusinessInfo().getBusinessOwnerID());
							map.put("businessOwnerName", o.getBusinessInfo().getBusinessOwnerName().getNameValue());	
							map.put("businessOwnerEmail", o.getBusinessInfo().getBusinessOwnerEmail());
						}
						
						if (o.getManagersInfo() != null) {
							map.put("productManagerID", o.getManagersInfo().getProductManagerID());
							map.put("productManagerName", o.getManagersInfo().getProductManagerName().getNameValue());	
							map.put("productManagerEmail", o.getManagersInfo().getProductManagerEmail());
						}
						
						if (oo.getBusinessInfo() != null) {
							map.put("businessOwnerID", oo.getBusinessInfo().getBusinessOwnerID());
							map.put("businessOwnerName", oo.getBusinessInfo().getBusinessOwnerName().getNameValue());	
							map.put("businessOwnerEmail", oo.getBusinessInfo().getBusinessOwnerEmail());
						}
						
						if (oo.getManagersInfo() != null) {
							map.put("productManagerID", oo.getManagersInfo().getProductManagerID());
							map.put("productManagerName", oo.getManagersInfo().getProductManagerName().getNameValue());	
							map.put("productManagerEmail", oo.getManagersInfo().getProductManagerEmail());
						}
						
						if("Delete".equalsIgnoreCase(o.getIdentificationInfo().getStatus()) 
								|| "Retired".equalsIgnoreCase(o.getIdentificationInfo().getStatus()) ) { 
								//|| test <=30) { //to be removed after testing
							log.debug("To Update Decomission Flag" +map.get("applicationId"));
							updateApplicationStatusData(map.get("applicationId").toString());							
						}
						else{
							log.debug("appl status is: "+ o.getIdentificationInfo().getStatus());
						}
						
						batchUpdateList.add(map);
												
						if(batchUpdateList.size()%SQL_BATCH_UPDATE_LIMIT==0){												
							count++;
							log.info("batchUpdateList.size(): "+batchUpdateList.size());
							
							log.info("count--> "+ count);
							updateCSIDataJDBCCall(batchUpdateList);
							batchUpdateList.clear();
						} else {
							doBatchUpdate = true;
						}
						break;
					} 															
				}			
			} 
			
			if (doBatchUpdate) {
				updateCSIDataJDBCCall(batchUpdateList);
			}													
		}
	}
    	    
    /**
     * 
     * @param applicationIds
     * @return
     */
    public List<ApplicationInfoType> getApplicationDetailsFromCSIDB(Set<String> applicationIds) {
    	final Set<String> ids = applicationIds;
    	List<ApplicationInfoType> result = null; 
		StringBuilder sbCSIDBQuery = null;
		StringBuilder sbcsiDBQueryTemp = null;
		StringBuilder sbcsiDBQueryTemp1 = null;
		int total_count = ids.size();
		log.info("total_count : "+total_count);
		if(total_count>0) {
			sbCSIDBQuery = new StringBuilder();
			sbcsiDBQueryTemp = new StringBuilder();
			sbcsiDBQueryTemp1 = new StringBuilder();
			int maxINClauseCnt = 1000;
			int maxNoINClauseCnt = total_count/1000;
			int remainNoINClauseCnt = total_count%1000;
			log.info("maxNoINClauseCnt : "+maxNoINClauseCnt);
			log.info("remainNoINClauseCnt : "+remainNoINClauseCnt);			
			if(total_count<1000)
			{
				sbcsiDBQueryTemp1.append(" where gaf.product_id in (");
				for(int i=0;i<total_count;i++)
				{
					sbcsiDBQueryTemp1.append("?,");
				}
				sbcsiDBQueryTemp.append(sbcsiDBQueryTemp1.deleteCharAt( sbcsiDBQueryTemp1.length() -1).toString()+")");
			}
			else 
			{
				for( int i = 0 ; i <= maxNoINClauseCnt; i++ ) {
					if(i == maxNoINClauseCnt)
					{
						maxINClauseCnt = remainNoINClauseCnt;
					}
					for( int j = 0 ; j < maxINClauseCnt; j++ ) {
						if(i==0 && j==0){
							sbcsiDBQueryTemp.append(" where gaf.product_id in (?,");
						} else if(i!=0 && j==0) {
							sbcsiDBQueryTemp.append(" and gaf.product_id in (?,");
						} else if(j==maxINClauseCnt-1) {
							sbcsiDBQueryTemp.append("?)");
						} else {
							sbcsiDBQueryTemp.append("?,");
						}					
					}				
				}
			}
	    	
	    	log.info("Entering CSIUtil getApplicationDetailsFromCSIDB");
	    	
	    	sbCSIDBQuery.append("select gaf.product_id, gaf.prodstatus_disp, rl.role_name, rl.emp_fname, rl.emp_lname, rl.empid, rl.mail_id from viracsi.generalapp_fields gaf");
	    	sbCSIDBQuery.append(" join viracsi.ROLE rl on rl.product_id=gaf.product_id ");
	    	sbCSIDBQuery.append(sbcsiDBQueryTemp.toString());
	    	sbCSIDBQuery.append(" and rl.role_name in ('Application Manager', 'Primary Business/Information Owner')");
	    	
	    	try {    		
	    			log.debug("CSIUtil.getApplicationDetailsFromCSIDB() :: Query to be executed ---" + sbCSIDBQuery.toString());
	    			
	    			result = jdbcTemplateCSI.query(sbCSIDBQuery.toString(), ids.toArray(), new RowMapper<ApplicationInfoType>() {  
	    		    @Override  
	    		    public ApplicationInfoType mapRow(ResultSet rs, int rownumber) throws SQLException {
	    		    	
	    		    	ApplicationInfoType infoType = new ApplicationInfoType();
	    		    	
	    		    	if ("Primary Business/Information Owner".equalsIgnoreCase(rs.getString(3))) {
	    		    		BusinessInfoType bInfoType = new BusinessInfoType();
	        		    	bInfoType.setBusinessOwnerID(rs.getString(6));
	        		    	
	        		    	PersonNameType nameType = new PersonNameType();
	        		    	nameType.setNameValue(rs.getString(4)+" "+rs.getString(5));
	        		    	bInfoType.setBusinessOwnerName(nameType);
	        		    	bInfoType.setBusinessOwnerEmail(rs.getString(7));
	        		    	infoType.setBusinessInfo(bInfoType);   
	    		    	}
	    		    	
	    		    	if ("Application Manager".equalsIgnoreCase(rs.getString(3))) {
	    		    		ManagersInfoType mInfoType = new ManagersInfoType();
	        		    	mInfoType.setProductManagerID(rs.getString(6));
	        		    	
	        		    	PersonNameType nameType = new PersonNameType();
	        		    	nameType.setNameValue(rs.getString(4)+" "+rs.getString(5));
	        		    	mInfoType.setProductManagerName(nameType);
	        		    	mInfoType.setProductManagerEmail(rs.getString(7));
	        		    	infoType.setManagersInfo(mInfoType);        		    	
	    		    	}
	    		    	
	    		    	IdentificationInfoType iInfoType = new IdentificationInfoType();
	    		    	iInfoType.setSIMONAppID(String.valueOf(rs.getInt(1)));
	    		    	iInfoType.setStatus(rs.getString(2));    		    	
	    		    	infoType.setIdentificationInfo(iInfoType);    		    	
	    		    	
	    		        return infoType;  
	    		    }  
	    		    });     		    		    	
	    		
	    	} catch (DataAccessException e) {
	    		log.error("DataAccessException in getApplicationDetailsFromCSIDB",e);
	    	} 
    }
    	log.info("Exiting CSIUtil getApplicationDetailsFromCSIDB."); 
    	return result;
    }
       
    private void updateApplicationData(final String appId) {
    	log.info("Entering CSIUtil updateApplicationData");
    	log.info("updated ti_applcation table with  app id = "+appId);
    	StringBuffer sql = new StringBuffer();
    	sql.append("update TI_APPLICATION set  IS_DECOMMISSIONED = 'Y', DECOMMISSIONED_NOTIF_DATE = sysdate ");
    	sql.append("where application_id = ? ");
    	try {
    		log.debug("CSIUtil .updateApplicationData() :: Query to be executed ---" + sql.toString());
    		boolean result = jdbcTemplateCCR.execute(sql.toString(),new PreparedStatementCallback<Boolean>(){  
    			@Override  
    			public Boolean doInPreparedStatement(PreparedStatement ps)  
    			throws SQLException, DataAccessException {  
    				ps.setString(1,appId);  
    				return ps.execute();  
    			}  
    		}); 
    		log.info("updated ti_applcation table with  app id = "+appId+" with status = "+ result );
    	} catch (DataAccessException e) {
    		log.error("Exception in updateApplicationData",e);
    	}
    	log.info("Exiting CSIUtil updateApplicationData");
		
	}

	/**
     * Gets the email.
     *
     * @param remoteUser the remote user
     * @param id the id
     * @return the email
     * @throws RemoteException the remote exception
     * @throws SOAException the sOA exception
     * @throws DomainServicesFault the domain services fault
     */
    @SuppressWarnings("unchecked")
    private String getEmail(String remoteUser, String id) throws RemoteException, SOAException{
	String email = "";
	SOADataComponent soaDataComponent = new SOADataComponent();
	ProfileInfoFactory profileInfoFactory = (ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");
	ProfileEntity profileEntity = new ProfileEntity();
	profileEntity.setRitzId(id);
	List citiContactList = profileInfoFactory.getRitzService().getProfile(profileEntity, remoteUser);

	Iterator it = citiContactList.iterator();
	while(it.hasNext()) {
		CitiContact entity = (CitiContact) it.next();
		log.info("App OWNER EMAIL :" +entity.getEmail());
		email = entity.getEmail();
		break;
	}
	return email;
    }

    /**
     * Update csi data.
     *
     * @param map the map
     */
    private void updateCSIData (final List<Map<String, String>> updateList){
    	log.info("Entering CSIUtil updateCSIData");
    	StringBuffer sql = new StringBuffer();
    	sql.append("update TI_APPLICATION set app_owner_email = ? ,app_owner_full_name = ? , app_owner_geid = ?, ");
    	sql.append("app_mgr_email = ? , app_mgr_full_name = ? , app_mgr_geid = ? ");
    	sql.append(" where application_id = ? ");
    	try{
    		int[] resultCount = jdbcTemplateCCR.batchUpdate(sql.toString(), new BatchPreparedStatementSetter() {  
    			@Override
    			public void setValues(PreparedStatement ps, int i) throws SQLException {
    				int index=0;
    				Map<String,String> map = updateList.get(i);
    				log.info("Updating for "+map.get("applicationId"));
    				ps.setString(++index, map.get("businessOwnerEmail"));
    				ps.setString(++index, map.get("businessOwnerName"));
    				ps.setString(++index, map.get("businessOwnerID"));
    				ps.setString(++index, map.get("productManagerEmail"));
    				ps.setString(++index, map.get("productManagerName"));
    				ps.setString(++index, map.get("productManagerID"));
    				ps.setString(++index, map.get("applicationId"));
    				log.info("updating end");
    			}  
    			@Override
    			public int getBatchSize() {  
    				return updateList.size();  
    			}  
    		});
    		log.info("Batch update End. "+resultCount.length);
    	}
    	catch(Exception e)
    	{
    		log.error("Error in updateCSIData. ",e);
    	}
    	log.info("Exiting CSIUtil updateCSIData");
    }
    
    /**
     * 
     * @param updateList
     */
    private void updateCSIDataJDBCCall (final List<Map<String, String>> updateList) {
    	log.info("Entering CSIUtil updateCSIDataJDBCCall");
    	final StringBuilder sql = new StringBuilder();
    	
    	sql.append("update TI_APPLICATION set app_owner_email = ?, app_owner_full_name = ?, app_owner_geid = ?, app_mgr_email = ?, app_mgr_full_name = ?, app_mgr_geid = ? where application_id = ?");
    		
    	int[] result = null;
    	java.sql.Connection con = null;
    	PreparedStatement ps = null;
    	try{
    		
    		con = jdbcTemplateCCR.getDataSource().getConnection();    		
    		ps = con.prepareStatement(sql.toString()); 
    		con.setAutoCommit(false); 
    		
    		for (Map<String, String> map : updateList) {    		
    			
    			if (map.get("businessOwnerEmail") != null) {
    				ps.setString(1, map.get("businessOwnerEmail").toString()); 
    			} else {
    				ps.setString(1, null);
    			}
    			    			  			
    			ps.setString(2, map.get("businessOwnerName").toString());
				ps.setString(3, map.get("businessOwnerID").toString());
				
				if (map.get("productManagerEmail") != null) {
    				ps.setString(4, map.get("productManagerEmail").toString()); 
    			} else {
    				ps.setString(4, null);
    			}				
				
				ps.setString(5, map.get("productManagerName").toString());
				ps.setString(6, map.get("productManagerID").toString());
				ps.setInt(7, Integer.parseInt(map.get("applicationId").toString()));
				ps.addBatch();
				log.info("added to batch -->"+map.get("applicationId") + " " + map.get("businessOwnerEmail") +" " + map.get("businessOwnerName") + " " +map.get("businessOwnerID")+" "+ map.get("productManagerEmail") + " " +map.get("productManagerName")+" "+map.get("productManagerID"));
    		}    		

    		result = ps.executeBatch(); 
    		log.info("CCR DB update result -->"+result.length);
        	con.commit(); 

    		log.info("Batch update End. updateCSIDataJDBCCall ");
    	}
    	catch(SQLException e)
    	{    		
    		log.error("Error in updateCSIDataJDBCCall. ",e);
    	} finally {
    		
    		if (ps != null) {
    			try {
    				ps.close();    			
    			} catch (SQLException ex) {
    				log.info("failed to close preparedstatement");
    			}
    		}
    		
    		if (con != null) {
    			try {    			
    				con.close();
    			} catch (SQLException ex) {
    				log.info("failed to close connection");
    			}
    		}
    	}
    	log.info("Exiting CSIUtil updateCSIDataJDBCCall");
    }
    
    /**
     * 
     * @param appId
     */
    private void updateApplicationStatusData(final String appId) {
    	
    	log.info("Entering CSIUtil updateApplicationStatusData");
    	log.info("updated ti_applcation table with  app id = "+appId);
    	StringBuilder sql = new StringBuilder();
    	sql.append("update TI_APPLICATION set IS_DECOMMISSIONED = 'Y', DECOMMISSIONED_NOTIF_DATE = sysdate ");
    	sql.append("where application_id = ? ");
    	    	
    	java.sql.Connection con = null;
    	PreparedStatement ps = null;
    	try {
    		
    		con = jdbcTemplateCCR.getDataSource().getConnection();    		
    		ps = con.prepareStatement(sql.toString()); 
    		ps.setInt(1, Integer.parseInt(appId));
    		int result = ps.executeUpdate(); 
    		log.info("update result for ti_applcation table with  app id = "+appId+" with status = Y is :" + result);    	
    		
    	} catch(SQLException e) {    		
    		log.error("Error in updateApplicationStatusData. ",e);
    	} finally {
    		
    		if (ps != null) {
    			try {
    				ps.close();    			
    			} catch (SQLException ex) {
    				log.info("failed to close preparedstatement");
    			}
    		}
    		
    		if (con != null) {
    			try {    			
    				con.close();
    			} catch (SQLException ex) {
    				log.info("failed to close connection");
    			}
    		}
    	}
    	log.info("Exiting CSIUtil updateApplicationStatusData");    	
    }

   
    /**
     * Gets the ti application ids for given process id.
     *
     * @param processId the process id
     * @return the ti application ids for given process id
     */
    public Set<String> getTiApplicationIdsForGivenProcessId (final Long processId){
	log.info("Entering CSIUtil getTiApplicationIdsForGivenProcessId.");
	Set<String> appIdSet = new HashSet<String>();
	StringBuffer sql = new StringBuffer();
	sql.append("select distinct x.a from  ");
	sql.append("(SELECT tia.application_id a  ");
	sql.append("  FROM con_fw_rule_application cfra, ti_application tia, ti_request tr ");
	sql.append(" WHERE     cfra.application_id = tia.id  ");
	sql.append("       AND cfra.ti_request_id = tr.id  ");
	sql.append("	   and tr.process_id = ?  ");
	sql.append("UNION  ");
	sql.append("SELECT tia.application_id a  ");
	sql.append("  FROM aps_appsense_policy aap, ti_application tia  ");
	sql.append(" WHERE   tia.id = aap.application_id  ");
	sql.append("       AND aap.process_id = ?  ");
	sql.append("UNION  ");
	sql.append("SELECT tia.application_id a  ");
	sql.append("  FROM prx_proxy_filter ppf, ti_application tia  ");
	sql.append(" WHERE     ppf.process_id = ? ");
	sql.append("       AND tia.id = ppf.app_id)x where x.a is not null ");
	
	try {
		log.debug("CSIUtil .getTiApplicationIdsForGivenProcessId() :: Query to be executed ---" + sql.toString());
		List<String> result = jdbcTemplateCCR.query(sql.toString(),new PreparedStatementSetter() {
			int i=0;
            @Override
			public void setValues(PreparedStatement ps) throws
            SQLException {
            	ps.setLong(++i, processId); 
				ps.setLong(++i, processId); 
				ps.setLong(++i, processId); 
          }
        }, new RowMapper<String>(){  
		    @Override  
		    public String mapRow(ResultSet rs, int rownumber) throws SQLException {  
		        return rs.getString(1);  
		    }  
		    }); 
		appIdSet = result == null ? new HashSet<String>() : new HashSet<String>(result);
		log.info("ti_applcation table with  processId = "+processId +" Set Size: "+appIdSet.size());
	} catch (DataAccessException e) {
		log.error("DataAccessException in getTiApplicationIdsForGivenProcessId",e);
	} 
	log.info("Exiting CSIUtil getTiApplicationIdsForGivenProcessId.");
	return appIdSet;
    }

    /**
     * Gets the processid.
     *
     * @param tiRequestId the ti request id
     * @return the processid
     */
    public long getProcessid(final Long tiRequestId) {
    	log.info("Entering CSIUtil getProcessid.");
    	long process_id = 0;
    	try {
			if (tiRequestId != null && tiRequestId.longValue() > 0) {
				String sql = "select process_id from ti_request where id=?";
				process_id = jdbcTemplateCCR.query(sql,
						new PreparedStatementSetter() {
			    			@Override
			    			public void setValues(PreparedStatement preparedStatement) throws
			    			SQLException {
			    				preparedStatement.setLong(1, tiRequestId.longValue());
			    			}
						}, 
			    		new ResultSetExtractor<Long>() {
			    			@Override
			    			public Long extractData(ResultSet resultSet) throws SQLException,
			    			DataAccessException {
			    				if (resultSet.next()) {
			    					return resultSet.getLong(1);
			    				}
			    				return null;
			    			}
			    		});
				log.debug("getProcessid Value: "+process_id);
			}
		} catch (DataAccessException e) {
			log.error("DataAccessException in getProcessid: ",e);
		}
    	log.info("Exiting CSIUtil getProcessid.");
    	return process_id;
    }
    
    public List<ConnectionDetailEmailVO> getProcessIdsByTiApplicationID(){
    	log.info("Entering CSIUtil getProcessIdsByTiApplicationID.");
    	StringBuffer conFirewallSql = new StringBuffer();
    	List<ConnectionDetailEmailVO> result = new ArrayList<ConnectionDetailEmailVO>();
    	List<String> sqls = new ArrayList<String>();
    	conFirewallSql.append("    SELECT DISTINCT tr.process_id,                            ");
    	conFirewallSql.append("    tp.process_name,                                     ");
    	conFirewallSql.append("    ta.application_id,                                   ");
    	conFirewallSql.append("    ta.APPLICATION_NAME,                                 ");
    	conFirewallSql.append("    rn.name region,                                      ");
    	conFirewallSql.append("    bu.business_name,                                    ");
    	conFirewallSql.append("    tr.cmp_id,                                           ");
    	conFirewallSql.append("    tr.service_now_id,                                   ");
    	conFirewallSql.append("    cr.RATIONALE,                                        ");
    	conFirewallSql.append("    tr.id,                                               ");
    	conFirewallSql.append("    tr.VERSION_NUMBER,                                   ");
    	conFirewallSql.append("    ta.APP_OWNER_FULL_NAME,                              ");
    	conFirewallSql.append("    ta.APPLICAITON_DESC,                                 ");
    	conFirewallSql.append("    ta.SEC_CLASSIFICATION,                               ");
    	conFirewallSql.append("    ta.PER_DATA_INDICATOR                              ");
    	conFirewallSql.append("    FROM ti_request tr                                     ");
    	conFirewallSql.append("    JOIN TI_REQUEST_PLANNING_XREF TXREF                    ");
    	conFirewallSql.append("    ON TXREF.TI_REQUEST_ID=tr.id   				          ");
    	//--MODIFIED - START
    	conFirewallSql.append("    and tr.id in (select MAX(id) from  ti_request WHERE ti_request_type_id!=4 AND process_id = (select id from ti_process where id=tr.process_id and is_deleted='N'))        ");
    	//--MODIFIED - END
    	conFirewallSql.append("    and tr.ti_request_type_id != 3				          ");
    	conFirewallSql.append("    JOIN TI_PROCESS TP                                     ");
    	conFirewallSql.append("    ON TP.ID=TR.PROCESS_ID                                 ");
    	conFirewallSql.append("    AND TP.IS_DELETED ='N'                                 ");
    	conFirewallSql.append("    JOIN con_req cr                                        ");
    	conFirewallSql.append("    ON cr.id=TXREF.PLANNING_ID                             ");
    	//--MODIFIED - START
    	conFirewallSql.append("    join con_fw_rule cfr       ");
    	conFirewallSql.append("    on cfr.updated_ti_request_id = tr.id       ");
    	conFirewallSql.append("    and cfr.deleted_ti_request_Id is null       ");
    	conFirewallSql.append("    JOIN con_fw_rule_application cf                        ");
    	conFirewallSql.append("    ON cf.rule_id = cfr.id AND cf.DELETED_TI_REQUEST_ID IS NULL       ");
    	//--MODIFIED - END
    	conFirewallSql.append("    JOIN ti_application ta                                 ");
    	conFirewallSql.append("    ON ta.id =cf.APPLICATION_ID                            ");
    	conFirewallSql.append("    JOIN relationship r                                    ");
    	conFirewallSql.append("    ON r.id=tp.RELATIONSHIP_ID                             ");
    	conFirewallSql.append("    JOIN REL_CITI_HIERARCHY_XREF EI                        ");
    	conFirewallSql.append("    ON R.ID=EI.RELATIONSHIP_ID                             ");
    	conFirewallSql.append("    JOIN CITI_HIERARCHY_MASTER CITIMASTER                  ");
    	conFirewallSql.append("    ON CITIMASTER.ID=EI.CITI_HIERARCHY_MASTER_ID           ");
    	conFirewallSql.append("    JOIN REGION RN                                         ");
    	conFirewallSql.append("    ON CITIMASTER.REGION_ID=RN.ID                          ");
    	conFirewallSql.append("    JOIN BUSINESS_UNIT bu                                  ");
    	conFirewallSql.append("    ON CITIMASTER.BU_ID              =bu.id                ");
    	conFirewallSql.append("    WHERE ta.application_id         IS NOT NULL            ");
    	conFirewallSql.append("    AND ta.is_csi                    ='Y'                  ");
    	conFirewallSql.append("    AND ta.is_decommissioned             ='Y'            ");
    	//--MODIFIED - START
    	conFirewallSql.append("    AND upper(tr.is_deleted) <> 'Y'       ");
    	//--MODIFIED - END
    	conFirewallSql.append("    UNION                                                  ");
    	conFirewallSql.append("    SELECT DISTINCT tr.process_id,                         ");
    	conFirewallSql.append("    tp.process_name,                                     ");
    	conFirewallSql.append("    ta.application_id,                                  ");
    	conFirewallSql.append("    ta.APPLICATION_NAME,                                 ");
    	conFirewallSql.append("    rn.name region,                                      ");
    	conFirewallSql.append("    bu.business_name,                                    ");
    	conFirewallSql.append("    tr.cmp_id,                                           ");
    	conFirewallSql.append("    tr.service_now_id,                                   ");
    	conFirewallSql.append("    cr.RATIONALE,                                        ");
    	conFirewallSql.append("    tr.id,                                               ");
    	conFirewallSql.append("    tr.VERSION_NUMBER,                                    ");
    	conFirewallSql.append("    ta.APP_OWNER_FULL_NAME,                              ");
    	conFirewallSql.append("    ta.APPLICAITON_DESC,                                 ");
    	conFirewallSql.append("    ta.SEC_CLASSIFICATION,                               ");
    	conFirewallSql.append("    ta.PER_DATA_INDICATOR                              ");
    	conFirewallSql.append("    FROM ti_request tr                                     ");
    	conFirewallSql.append("    JOIN TI_REQUEST_PLANNING_XREF TXREF                    ");
    	conFirewallSql.append("    ON TXREF.TI_REQUEST_ID=tr.id   				          ");
    	//--MODIFIED - START
    	conFirewallSql.append("    and tr.id in (select MAX(id) from  ti_request WHERE ti_request_type_id!=4 AND process_id = (select id from ti_process where id=tr.process_id and is_deleted='N'))        ");
    	//--MODIFIED - END
    	conFirewallSql.append("    and tr.ti_request_type_id != 3				          ");
    	conFirewallSql.append("    JOIN TI_PROCESS TP                                     ");
    	conFirewallSql.append("    ON TP.ID=TR.PROCESS_ID                                 ");
    	conFirewallSql.append("    JOIN con_req cr                                        ");
    	conFirewallSql.append("    ON cr.id=TXREF.PLANNING_ID                             ");
    	conFirewallSql.append("    JOIN aps_appsense_policy aps                           ");
    	conFirewallSql.append("    ON aps.ti_request_id = tr.id                           ");
    	conFirewallSql.append("    JOIN ti_application ta                                 ");
    	conFirewallSql.append("    ON ta.id =aps.APPLICATION_ID                           ");
    	conFirewallSql.append("    JOIN relationship r                                    ");
    	conFirewallSql.append("    ON r.id=tp.RELATIONSHIP_ID                             ");
    	conFirewallSql.append("    JOIN REL_CITI_HIERARCHY_XREF EI                        ");
    	conFirewallSql.append("    ON R.ID=EI.RELATIONSHIP_ID                             ");
    	conFirewallSql.append("    JOIN CITI_HIERARCHY_MASTER CITIMASTER                  ");
    	conFirewallSql.append("    ON CITIMASTER.ID=EI.CITI_HIERARCHY_MASTER_ID           ");
    	conFirewallSql.append("    JOIN REGION RN                                         ");
    	conFirewallSql.append("    ON CITIMASTER.REGION_ID=RN.ID                          ");
    	conFirewallSql.append("    JOIN BUSINESS_UNIT bu                                  ");
    	conFirewallSql.append("    ON CITIMASTER.BU_ID              =bu.id                ");
    	conFirewallSql.append("    WHERE ta.application_id         IS NOT NULL            ");
    	conFirewallSql.append("    AND ta.is_csi                    ='Y'                  ");
    	conFirewallSql.append("    AND ta.is_decommissioned             ='Y'              ");
    	conFirewallSql.append("    UNION                                                  ");
    	conFirewallSql.append("    SELECT DISTINCT tr.process_id,                         ");
    	conFirewallSql.append("    tp.process_name,                                     ");
    	conFirewallSql.append("    ta.application_id,                                          ");
    	conFirewallSql.append("    ta.APPLICATION_NAME,                                 ");
    	conFirewallSql.append("    rn.name region,                                      ");
    	conFirewallSql.append("    bu.business_name,                                    ");
    	conFirewallSql.append("    tr.cmp_id,                                           ");
    	conFirewallSql.append("    tr.service_now_id,                                   ");
    	conFirewallSql.append("    cr.RATIONALE,                                        ");
    	conFirewallSql.append("    tr.id,                                               ");
    	conFirewallSql.append("    tr.VERSION_NUMBER,                                    ");
    	conFirewallSql.append("    ta.APP_OWNER_FULL_NAME,                              ");
    	conFirewallSql.append("    ta.APPLICAITON_DESC,                                 ");
    	conFirewallSql.append("    ta.SEC_CLASSIFICATION,                               ");
    	conFirewallSql.append("    ta.PER_DATA_INDICATOR                            ");
    	conFirewallSql.append("    FROM ti_request tr                                     ");
    	conFirewallSql.append("    JOIN TI_REQUEST_PLANNING_XREF TXREF                    ");
    	conFirewallSql.append("    ON TXREF.TI_REQUEST_ID=tr.id   				          ");
    	//--MODIFIED - START
    	conFirewallSql.append("    and tr.id in (select MAX(id) from  ti_request WHERE ti_request_type_id!=4 AND process_id = (select id from ti_process where id=tr.process_id and is_deleted='N'))        ");
    	//--MODIFIED - END
    	conFirewallSql.append("    and tr.ti_request_type_id != 3				          ");
    	conFirewallSql.append("    JOIN TI_PROCESS TP                                     ");
    	conFirewallSql.append("    ON TP.ID=TR.PROCESS_ID                                 ");
    	conFirewallSql.append("    JOIN con_req cr                                        ");
    	conFirewallSql.append("    ON cr.id=TXREF.PLANNING_ID                             ");
    	conFirewallSql.append("    JOIN prx_proxy_filter ppf                              ");
    	conFirewallSql.append("    ON ppf.ti_request_id = tr.id                           ");
    	conFirewallSql.append("    JOIN ti_application ta                                 ");
    	conFirewallSql.append("    ON ta.id =ppf.APP_ID                                   ");
    	conFirewallSql.append("    JOIN relationship r                                    ");
    	conFirewallSql.append("    ON r.id=tp.RELATIONSHIP_ID                             ");
    	conFirewallSql.append("    JOIN REL_CITI_HIERARCHY_XREF EI                        ");
    	conFirewallSql.append("    ON R.ID=EI.RELATIONSHIP_ID                             ");
    	conFirewallSql.append("    JOIN CITI_HIERARCHY_MASTER CITIMASTER                  ");
    	conFirewallSql.append("    ON CITIMASTER.ID=EI.CITI_HIERARCHY_MASTER_ID           ");
    	conFirewallSql.append("    JOIN REGION RN                                         ");
    	conFirewallSql.append("    ON CITIMASTER.REGION_ID=RN.ID                          ");
    	conFirewallSql.append("    JOIN BUSINESS_UNIT bu                                  ");
    	conFirewallSql.append("    ON CITIMASTER.BU_ID              =bu.id                ");
    	conFirewallSql.append("    WHERE ta.application_id         IS NOT NULL            ");
    	conFirewallSql.append("    AND ta.is_csi                    ='Y'                  ");
    	conFirewallSql.append("    AND ta.is_decommissioned             ='Y'       ");
    	//--MODIFIED -- START
    	conFirewallSql.append("    AND (upper(ppf.IS_DELETED) <> 'Y' OR ppf.IS_DELETED IS NULL)       ");
    	//--MODIFIED --END          	
    		try {
    			log.debug("CSIUtil .getProcessIdsByTiApplicationID() :: Query to be executed ---" + conFirewallSql.toString());
    			result.addAll(jdbcTemplateCCR.query(conFirewallSql.toString(), new RowMapper<ConnectionDetailEmailVO>(){  
    				@Override  
    				public ConnectionDetailEmailVO mapRow(ResultSet rs, int rownumber) throws SQLException {
    					ConnectionDetailEmailVO connectionDetailEmailVO = new ConnectionDetailEmailVO();
    					connectionDetailEmailVO.setProcessId(rs.getLong(1));
    					connectionDetailEmailVO.setConnectionName(rs.getString(2));
    					connectionDetailEmailVO.setApplicationId(rs.getLong(3));
    					connectionDetailEmailVO.setApplicationName(rs.getString(4));
    					connectionDetailEmailVO.setRegion(rs.getString(5));
    					connectionDetailEmailVO.setBusinessUnit(rs.getString(6));
    					if(rs.getString(7)!=null || !("").equals(rs.getString(7))){
    						log.debug("CMP ID Value: "+rs.getString(7));
    						connectionDetailEmailVO.setCmpID(rs.getString(7));
    					} else if(rs.getString(8)!=null || !("").equals(rs.getString(8))) {
    						log.debug("SErvice Now ID Value: "+rs.getString(8));
    						connectionDetailEmailVO.setCmpID(rs.getString(8));
    					} else {
    						log.debug("Empty");
    						connectionDetailEmailVO.setCmpID("-");
    					}
    					connectionDetailEmailVO.setComment(rs.getString(9));
    					connectionDetailEmailVO.setTiRequestID(rs.getLong(10));
    					connectionDetailEmailVO.setVersionNumber(rs.getLong(11));
    					log.debug("Application Owner Full Name: "+rs.getString(12));
    					connectionDetailEmailVO.setAppOwnerFullName(rs.getString(12));
    					log.debug("Application Function Name: "+rs.getString(13));
    					connectionDetailEmailVO.setFunction(rs.getString(13));
    					log.debug("Information Classification: "+rs.getString(14));
    					connectionDetailEmailVO.setSecClassification(rs.getString(14));
    					log.debug("Data Privacy - PII Indicator: "+rs.getString(15));
    					connectionDetailEmailVO.setPerDataIndicator(rs.getString(15));
    					return connectionDetailEmailVO;  
    				}  
    			})); 
    			log.debug("List of Connections: "+result.size() +" - " + new Date().toString() );
    		} catch (DataAccessException e) {
    			log.error("DataAccessException in getTiApplicationIdsForGivenProcessId",e);
    		} catch (Exception e) {
    			log.error("Error in getTiApplicationIdsForGivenProcessId",e);
    		}
    	
    	log.info("Exiting CSIUtil getProcessIdsByTiApplicationID.");
    	return result;
    }
    
    /**
     * 
     * @param applicationIds
     * @return
     */
    public List<ApplicationInfoType> searchApplicationDetailsFromCSIDB(ApplicationDetailEntity applicationDetailEntity) {

    	List<ApplicationInfoType> result = null; 
		StringBuilder sbCSIDBQuery = new StringBuilder();
	    	
	    	log.info("Entering CSIUtil searchApplicationDetailsFromCSIDB");	    	
	    	sbCSIDBQuery.append(" SELECT DISTINCT GAF.PRODUCT_ID, GAF.PRODSTATUS_DISP, RL.ROLE_NAME, RL.EMP_FNAME, RL.EMP_LNAME, ");
	    	sbCSIDBQuery.append(" RL.EMPID, RL.MAIL_ID, RL1.ROLE_NAME, RL1.EMP_FNAME, RL1.EMP_LNAME, RL1.EMPID, RL1.MAIL_ID, ");
	    	sbCSIDBQuery.append(" BASIC_FUNC.ACRONYM, BASIC_FUNC.SECCLASS_DISP, BASIC_FUNC.PDATA_IND, BASIC_FUNC.PROD_CRITICALITY, ");
	    	sbCSIDBQuery.append(" GAF.PRODUCT_NAME FROM VIRACSI.GENERALAPP_FIELDS GAF  ");
	    	sbCSIDBQuery.append(" JOIN VIRACSI.ROLE RL ON RL.PRODUCT_ID=GAF.PRODUCT_ID ");
	    	sbCSIDBQuery.append(" JOIN VIRACSI.ROLE RL1 ON RL1.PRODUCT_ID=GAF.PRODUCT_ID ");
	    	sbCSIDBQuery.append(" JOIN VIRACSI.APP_BUSFUNCTION APPBUSSFUN ON APPBUSSFUN.PRODUCT_ID=GAF.PRODUCT_ID ");
	    	sbCSIDBQuery.append(" JOIN VIRACSI.BASIC_FUNC BASIC_FUNC ON BASIC_FUNC.PRODUCT_ID=GAF.PRODUCT_ID ");
	    	sbCSIDBQuery.append(" WHERE UPPER(RL.ROLE_NAME) = UPPER('APPLICATION MANAGER') ");
	    	sbCSIDBQuery.append(" AND UPPER(RL1.ROLE_NAME) = UPPER('PRIMARY BUSINESS/INFORMATION OWNER') ");
	    	
	    	if(applicationDetailEntity.getAcronym() != null && !applicationDetailEntity.getAcronym().trim().equals("")){
	    		sbCSIDBQuery.append("AND UPPER(BASIC_FUNC.ACRONYM) = UPPER('").append(applicationDetailEntity.getAcronym().trim()).append("') ");
	    	}
	    	if(applicationDetailEntity.getAppId() != null && !applicationDetailEntity.getAppId().trim().equals("")){
	    		 sbCSIDBQuery.append(" AND GAF.PRODUCT_ID IN ('").append(applicationDetailEntity.getAppId().trim()).append("') ");
	    	}
	    	if(applicationDetailEntity.getAppName() != null && !applicationDetailEntity.getAppName().trim().equals("")){
	    		sbCSIDBQuery.append("AND UPPER(GAF.PRODUCT_NAME) LIKE UPPER('%").append(applicationDetailEntity.getAppName().trim()).append("%') ");
	    	}
	    	
	    	try {    		
	    			log.debug("CSIUtil.searchApplicationDetailsFromCSIDB() :: Query to be executed ---> : " + sbCSIDBQuery.toString());
	    			
	    			result = jdbcTemplateCSI.query(sbCSIDBQuery.toString(), new RowMapper<ApplicationInfoType>() {  
	    		    @Override  
	    		    public ApplicationInfoType mapRow(ResultSet rs, int rownumber) throws SQLException {
	    		    	
	    		    	ApplicationInfoType infoType = new ApplicationInfoType();
	    		    	StringBuilder sbBussFuncTypeQuery = new StringBuilder();
	    		    	List<String> buss_func_result = null;
	    		    	String primaryFunctionString = "";
	    		    	String hostNamesString = "";
	    		    	StringBuilder sbhostNamesQuery = new StringBuilder();
	    		    	List<String> hostNames_result = null;
	    		    	String Product_Id= rs.getString(1);

    		    		BusinessInfoType bInfoType = new BusinessInfoType();
        		    	bInfoType.setBusinessOwnerID(rs.getString(6));
        		    	bInfoType.setBusinessCriticality(rs.getString(16));//Not sure
        		    	PersonNameType bussOwnerNameType = new PersonNameType();
        		    	bussOwnerNameType.setNameValue(rs.getString(4)+" "+rs.getString(5));
        		    	bInfoType.setBusinessOwnerName(bussOwnerNameType);
        		    	bInfoType.setBusinessOwnerEmail(rs.getString(7));
        		    	infoType.setBusinessInfo(bInfoType);   
    		    	
    		    		ManagersInfoType mInfoType = new ManagersInfoType();
        		    	mInfoType.setProductManagerID(rs.getString(6));
        		    	
        		    	PersonNameType appManagerNameType = new PersonNameType();
        		    	appManagerNameType.setNameValue(rs.getString(9)+" "+rs.getString(10));
        		    	mInfoType.setProductManagerName(appManagerNameType);
        		    	mInfoType.setProductManagerEmail(rs.getString(12));
        		    	infoType.setManagersInfo(mInfoType);
	    		    	
	    		    	IdentificationInfoType iInfoType = new IdentificationInfoType();
	    		    	iInfoType.setSIMONAppID(String.valueOf(rs.getInt(1)));
	    		    	iInfoType.setStatus(rs.getString(2));    		    	
	    		    	iInfoType.setAcronym(rs.getString(13));
	    		    	iInfoType.setProductName(rs.getString(17));
	    		    	infoType.setIdentificationInfo(iInfoType); 
	    		    	
	    		    	SecurityInfoType sInfoType = new SecurityInfoType();
	    		    	sInfoType.setSecurityClassification(rs.getString(14));
	    		    	sInfoType.setPersonalDataIndicator(rs.getString(15));
	    		    	infoType.setSecurityInfo(sInfoType);
	    		    	
	    		    	BusinessFunctionalityType bussFuncType = new BusinessFunctionalityType();
	    		    	sbBussFuncTypeQuery.append(" SELECT PRIM_BUSFUNC_HIER_DISP FROM VIRACSI.APP_BUSFUNCTION WHERE PRODUCT_ID='");
	    		    	sbBussFuncTypeQuery.append(Product_Id).append("' ");
	    		    	log.debug("CSIUtil.searchApplicationDetailsFromCSIDB() :: Query to be executed ---> :" + sbBussFuncTypeQuery.toString());

	    		    	buss_func_result = jdbcTemplateCSI.query(sbBussFuncTypeQuery.toString(), new RowMapper<String>() {  
	    	    		    @Override  
	    	    		    public String mapRow(ResultSet rs, int rownumber) throws SQLException {
	    	    		    	return rs.getString(1);
	    	    		    }
	    		    	});
	    		    	
	    		    	for (String primaryFunction : buss_func_result)
	    		    	{
	    		    		primaryFunctionString += primaryFunction + "\t";
	    		    	}	 
	    		    	log.debug("CSIUtil.searchApplicationDetailsFromCSIDB() :: primaryFunctionString ::"+primaryFunctionString);
	    		    	bussFuncType.setPrimaryFunctions(primaryFunctionString);
	    		    	infoType.setBusinessFunctionality(bussFuncType);	    		    	
	    		    	
	    		    	TechnicalInfoType techInfoType = new TechnicalInfoType();
	    		    	sbhostNamesQuery.append(" SELECT HOSTNAME FROM VIRACSI.HOSTS WHERE PRODUCT_ID='");
	    		    	sbhostNamesQuery.append(Product_Id).append("' ");
	    		    	log.debug("CSIUtil.searchApplicationDetailsFromCSIDB() :: Query to be executed ---> :" + sbhostNamesQuery.toString());
	    		    	hostNames_result = jdbcTemplateCSI.query(sbhostNamesQuery.toString(), new RowMapper<String>() {  
	    	    		    @Override  
	    	    		    public String mapRow(ResultSet rs, int rownumber) throws SQLException {
	    	    		    	return rs.getString(1);
	    	    		    }
	    		    	});
	    		    	
	    		    	for (String hostNames : hostNames_result)
	    		    	{
	    		    		hostNamesString += hostNames + "\t";
	    		    	}
	    		    	log.debug("CSIUtil.searchApplicationDetailsFromCSIDB() :: hostNamesString ::"+hostNamesString);
	    		    	techInfoType.setHostName(hostNamesString);
	    		    	infoType.setTechnicalInfo(techInfoType);	    		    	
	    		        return infoType;  
	    		    }  
	    		    });     		    		    	
	    		
	    	} catch (DataAccessException e) {
	    		log.error("DataAccessException in searchApplicationDetailsFromCSIDB",e);
	    	} 
    	log.info("Exiting CSIUtil searchApplicationDetailsFromCSIDB."); 
    	return result;
    }
    
    public List<CitiContact> getEmailIdFromCSIDB(String ritsId) {
    	List<CitiContact> citiContactList = null;
    	Session session = null;
    	//String citiContactEmailQuery = " SELECT EMAIL FROM CITI_CONTACT WHERE RITS_ID=? ";
    	try {
    		log.info("Entering CSIUtil getEmailIdFromCSIDB");
    		log.info("Entering CSIUtil getEmailIdFromCSIDB : ritsId : "+ritsId);
    	/*citiContactList = jdbcTemplateCSI.query(citiContactEmailQuery, new Object[] {geId}, new RowMapper<CitiContact>() {  
		    @Override  
		    public CitiContact mapRow(ResultSet rs, int rownumber) throws SQLException {
		    	CitiContact citiContact = new CitiContact();
		    	citiContact.setEmail(rs.getString(1));
		    	return citiContact;
		    }});*/
    		try {
    		    session = sessionFactory.getCurrentSession();
    		} 
    		catch (HibernateException e) {
    		    session = sessionFactory.openSession();
    		}
    		Criteria criteria = session.createCriteria(CitiContact.class);
    		criteria.add(Restrictions.eq("ritsId", ritsId));
    		citiContactList = criteria.list();
	    } catch (DataAccessException e) {
			log.error("DataAccessException in getEmailIdFromCSIDB",e);
		} 
	    log.info("Exiting CSIUtil getEmailIdFromCSIDB."); 
	return citiContactList;
    }
}