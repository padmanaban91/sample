package com.citigroup.cgti.c3par.webtier.controller.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.admin.domain.ManageISOContactProcess;
import com.citigroup.cgti.c3par.common.domain.ISOContacts;
 
@Controller 
public class ManageISOContactsController     { 

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@RequestMapping(value = "/loadISOContactsList.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String loadISOContactsList(@ModelAttribute("manageISOContactProcess") ManageISOContactProcess manageISOContactProcess,ModelMap model) {
		log.info("ManageISOContactsController :: loadISOContactsList starts ");
		manageISOContactProcess = loadmanageisocontact(manageISOContactProcess);
		manageISOContactProcess.setSoeID("");
		model.addAttribute("manageISOContactProcess",manageISOContactProcess);
		
		return "c3par.admin.manageISOContacts";
	}

	public ManageISOContactProcess loadmanageisocontact(ManageISOContactProcess manageISOContactProcess){
		String pageType = manageISOContactProcess.getPageType();

		//Setting page number
		manageISOContactProcess = setPaginationValues(manageISOContactProcess,0,10,0,pageType);
		List<ISOContacts> isoContactsList = manageISOContactProcess.getManageISOContactList();	

		//setting the pagination values based on ISO Contact List
		manageISOContactProcess.setTotalPages(getTotalPages(manageISOContactProcess.getRowCount(), manageISOContactProcess.getLimit()));		
		manageISOContactProcess.setIsoContactList(isoContactsList);
		
		return manageISOContactProcess;
	}
	
	@RequestMapping(value = "/saveManageISOContact.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String saveManageISOContact(ModelMap model,@ModelAttribute("manageISOContactProcess") ManageISOContactProcess manageISOContactProcess, BindingResult result) {		
		log.info("ManageISOContactsController::saveManageISOContact methods starts...");
		boolean addError = false;
		try{
			//check whether soeID is entered or not
			if(manageISOContactProcess.getSoeID() != null && manageISOContactProcess.getSoeID().trim().length() > 0){
				//if soeID is entered then save / update the contact
				manageISOContactProcess.saveManageISOContactList(manageISOContactProcess.getSoeID().trim().toUpperCase());
			}else{//if soeID is not entered then show the error message		
				addError = true;
			}
		}catch(Exception e){
			addError = true;
		}
		if(addError){ 	
			log.info("ManageISOContactsController::saveManageISOContact:: Error...");
			result.addError(new ObjectError("manageISOContactProcess.soeID",new String[]{"admin.selectedSoeID"},null,null));
		}	
		
		manageISOContactProcess.setOffset(0);
		manageISOContactProcess.setPageNo(1);
		manageISOContactProcess.setLimit(10);	
		manageISOContactProcess.setPaginationRequired(true);
		List<ISOContacts> isoContactsList = manageISOContactProcess.getManageISOContactList();	
		
		//setting the pagination values based on ISO Contact list
		manageISOContactProcess.setTotalPages(getTotalPages(manageISOContactProcess.getRowCount(), manageISOContactProcess.getLimit()));		
		manageISOContactProcess.setIsoContactList(isoContactsList);
		manageISOContactProcess.setSoeID("");
		model.addAttribute("manageISOContactProcess",manageISOContactProcess);
		
		return "c3par.admin.manageISOContacts";
	}

	@RequestMapping(value = "/exportManageISOContactList.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String exportManageISOContactList(ModelMap model, @ModelAttribute("manageISOContactProcess") ManageISOContactProcess manageISOContactProcess) {
		log.info("ManageISOContactsController::exportManageISOContactList methods starts...");
		
		manageISOContactProcess = new ManageISOContactProcess();
		manageISOContactProcess.setPaginationRequired(false);
		// retrieve the ISO Contact list
		List<ISOContacts> isoContactsList = manageISOContactProcess.getManageISOContactList();	
	
		manageISOContactProcess.setIsoContactList(isoContactsList);
		manageISOContactProcess.setSoeID("");
		
		model.addAttribute("manageISOContactProcess",manageISOContactProcess);
		
		return "pages/admin/ManageISOContactListExport";
	}

	@RequestMapping(value = "/deleteManageISOContactList.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String deleteManageISOContactList(ModelMap model, @ModelAttribute("manageISOContactProcess") ManageISOContactProcess manageISOContactProcess) {
		log.info("ManageISOContactsController::deleteManageISOContactList methods starts...");

		List<ISOContacts> isoContactsList = manageISOContactProcess.getIsoContactList();	
		List<String> soeIDList = new ArrayList<String>();
		
		if(isoContactsList !=null && isoContactsList.size() > 0) {
			for(ISOContacts isocontact : isoContactsList) {
				log.info("ManageISOContactsController::deleteManageISOContactList"+isocontact.getSoeID()+"------"+isocontact.isSelected());
				if (isocontact.isSelected()) {
					soeIDList.add(isocontact.getSoeID());
				}
			}
			if(!soeIDList.isEmpty()){
				manageISOContactProcess.deleteManageISOContactList(soeIDList);	
			}
		}
		manageISOContactProcess.setSoeID("");
		model.addAttribute("manageISOContactProcess",manageISOContactProcess);
		
		return "forward:/loadISOContactsList.act";		
	}
	
	private ManageISOContactProcess setPaginationValues(ManageISOContactProcess manageISOContactProc, int curOffSet, int limit, int pageNo, String pageType){
		if(manageISOContactProc != null){
			curOffSet = manageISOContactProc.getOffset();		
			limit = manageISOContactProc.getLimit();		
			pageNo = manageISOContactProc.getPageNo();
		}
		manageISOContactProc = new ManageISOContactProcess();
		manageISOContactProc.setLimit(limit);
		manageISOContactProc.setPaginationRequired(true);
		if (pageType != null && "N".equalsIgnoreCase(pageType)) {
			manageISOContactProc.setOffset(curOffSet+manageISOContactProc.getLimit());
			manageISOContactProc.setPageNo(pageNo+1);
		} else if (pageType != null && "P".equalsIgnoreCase(pageType)) {
			manageISOContactProc.setOffset(curOffSet-manageISOContactProc.getLimit());
			manageISOContactProc.setPageNo(pageNo-1);
		} else if (pageType != null && "X".equalsIgnoreCase(pageType)) {
			manageISOContactProc.setOffset(limit * (pageNo-1));
			manageISOContactProc.setPageNo(pageNo);
		} else if (pageType != null && "L".equalsIgnoreCase(pageType)) {
			manageISOContactProc.setOffset(0);
			manageISOContactProc.setPageNo(1);
		}else {
			manageISOContactProc.setOffset(0);
			manageISOContactProc.setPageNo(1);
			manageISOContactProc.setLimit(10);
		}

		return manageISOContactProc;
	}

	private int getTotalPages(int rowCount, int limit){		
		int totalPages = 0;		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}	
		
		return totalPages;
	}
}

