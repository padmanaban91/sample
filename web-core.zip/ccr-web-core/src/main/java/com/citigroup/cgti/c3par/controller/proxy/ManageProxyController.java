package com.citigroup.cgti.c3par.controller.proxy;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.POIExcelReaderProxy;
import com.citigroup.cgti.c3par.POIExcelWriter;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiResource;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.model.RelationshipEntity;
import com.citigroup.cgti.c3par.model.TIRequestEntity;
import com.citigroup.cgti.c3par.proxy.domain.ManageProxyProcess;
import com.citigroup.cgti.c3par.proxy.domain.ProxyFilter;
import com.citigroup.cgti.c3par.proxy.domain.ProxyInstance;
import com.citigroup.cgti.c3par.proxy.domain.ProxyInstanceXref;
import com.citigroup.cgti.c3par.proxy.domain.ProxyProcess;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.webtier.helper.FAFReviewThread;
import com.citigroup.cgti.c3par.webtier.helper.LookupNameHelper;
import com.citigroup.cgti.c3par.webtier.helper.Util; 

/*
 * @nc43495
 */

@Controller
public class ManageProxyController {

	/** The log. */
	private static Logger log = Logger
			.getLogger(ManageProxyController.class);

	/** The util. */
	Util util = new Util();

	private int noOfRecords = 5;

	String errorMessage = null;

	private static ResourceBundle props = ResourceBundle.getBundle(System.getProperty("ccr-application"),Locale.getDefault());

	@RequestMapping(value = "/load.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String load(ModelMap model,HttpServletRequest request) {
		String forwardTo = null;
		String selectedTab = null;
		String recType = null;
		log.info("ManageProxyController.load()::Starts");
		request.setAttribute("addApplication", "false");
		selectedTab = request.getParameter("tab");
		ManageProxyProcess manageProxyProcess = new ManageProxyProcess();
		if (selectedTab.equals("manageProxy")) {
			recType = "BASIC";
		} else if (selectedTab.equals("managePacFile")) {
			recType = "BASIC";
		} else if (selectedTab.equals("manageSocks")) {
			recType = "SOCKS";
		} else if (selectedTab.equals("managePlug")) {
			recType = "PLUG";
		} else if (selectedTab.equals("manageUrlAccess")) {
			recType = "FREEURL_ADD";
		} else if (selectedTab.equals("addPAC")) {
			int noOfRecords =manageProxyProcess.getNoOfRecords();
			manageProxyProcess.setNoOfRecords(noOfRecords);
			try {
				return searchProxyInstance(model, manageProxyProcess, request);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Long processId;
		boolean isSelectAll = false;
		ProxyProcess proxyProcess = new ProxyProcess();
		ProxyFilter filterObject = new ProxyFilter();
		String filterSelection = manageProxyProcess.getFilterSelection();
		if ("yes".equalsIgnoreCase(request.getParameter("applyFilter"))) {
			filterObject = manageProxyProcess.getFilterObject();
		}
		if(manageProxyProcess.getNoOfRecords()==0){
			manageProxyProcess.setNoOfRecords(noOfRecords);
		}
		if ("yes".equalsIgnoreCase(request.getParameter("applyFilter"))) {
			manageProxyProcess.setFilterSelection(filterSelection);
			manageProxyProcess.setFilterObject(filterObject);
		}

		List proxyRegionList = util.getManageProxyRegion(recType);
		manageProxyProcess.setProxyRegionList(proxyRegionList);
		request.getSession().setAttribute("proxyRegionList", proxyRegionList);
		if (request.getParameter("processId") != null) {
			processId = Long.valueOf(request.getParameter("processId"));
			manageProxyProcess.setOriginalConnectionRequestId(processId);
		}else if(request.getSession().getAttribute("TI_REQUEST_ENTITY")!=null){
			manageProxyProcess.setTiRequest((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY"));
			processId=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getTiProcess().getId();
			manageProxyProcess.setOriginalConnectionRequestId(processId);
		}else {
			processId = manageProxyProcess.getOriginalConnectionRequestId();
		}
		log.info("processId===" + processId);
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}
		log.info("tiRequestId===" + tiRequestId);
		String requestType =  null;
		if (manageProxyProcess.getTiRequest().getTiRequestType() != null
				&& manageProxyProcess.getTiRequest().getTiRequestType().getName() != null) {
			requestType = manageProxyProcess.getTiRequest().getTiRequestType().getName();
			log.debug(" Request Type :: " + requestType);
			if (requestType != null
					&& requestType.equalsIgnoreCase("Terminate")) {
				log.debug("Setting DisplayMode to View for Termination Cycle");
				request.getSession().setAttribute("displayMode", "View");
			}
		}
		proxyProcess = manageProxyProcess.getProxyProcess(processId.longValue());
		proxyProcess.setSelectAll(isSelectAll);
		proxyProcess.setFilterObject(filterObject);
		if (selectedTab.equals("manageProxy")) {
			forwardTo = "c3par.manageProxy";
			List<ProxyFilter> proxyFilterList = manageProxyProcess.loadProxyFilters(
					proxyProcess, manageProxyProcess.getNoOfRecords());
			log.info("proxy Filter List--->>" + proxyFilterList);
			manageProxyProcess.setProxyFilterList(proxyFilterList);
			request.getSession().setAttribute("proxyFilterListManageProxy", proxyFilterList);
			request.getSession().setAttribute("viewSearch", "false");
			request.getSession().setAttribute("loadSearch", "false");
		} else if (selectedTab.equals("addPAC")) {
			forwardTo = "c3par.addPacFile";
			log.debug(" addPAC " + selectedTab);
			List<ProxyFilter> prxPacFileFilterLst = manageProxyProcess.loadProxyInstances(
					proxyProcess, manageProxyProcess.getNoOfRecords());
			log.info("Proxy Pac File Filter List --->>"
					+ prxPacFileFilterLst.size());
			manageProxyProcess.setProxyFilterList(prxPacFileFilterLst);
			// Have to consider the usage
			request.getSession().setAttribute("viewSearch", "false");
			request.getSession().setAttribute("loadSearch", "false");
		} else if (selectedTab.equals("managePacFile")) {
			forwardTo = "c3par.managePacFile";
			log.debug(" managePacFile " + selectedTab);
			List<ProxyFilter> prxPacFileFilterLst = manageProxyProcess
					.loadProxyPacFileFilters(proxyProcess,
							manageProxyProcess.getNoOfRecords());
			log.info("Proxy Pac File Filter List --->>"
					+ prxPacFileFilterLst.size());
			request.getSession().setAttribute("prxPacFileFilterLst", prxPacFileFilterLst);
			manageProxyProcess.setProxyFilterList(prxPacFileFilterLst);
		} else if (selectedTab.equals("manageSocks")) {
			log.debug(" manageSocks " + selectedTab);
			forwardTo = "c3par.manageProxySocks";
			manageProxyProcess.setPrxDataSizeList(util.getDataSizeList());
			manageProxyProcess.setPrxDataFrequencyList(util
					.getDataFrequencyList());
			List<ProxyFilter> prxSocksFilterLst = manageProxyProcess.loadProxySocksFilters(
					proxyProcess, manageProxyProcess.getNoOfRecords());
			request.getSession().setAttribute("prxDataSizeList", manageProxyProcess.getPrxDataSizeList());
			request.getSession().setAttribute("prxDataFrequencyList", manageProxyProcess.getPrxDataFrequencyList());
			request.getSession().setAttribute("prxSocksFilterLst", prxSocksFilterLst);
			log
			.info("Proxy Sock Filter List  --->>"
					+ prxSocksFilterLst.size());
			manageProxyProcess.setProxyFilterList(prxSocksFilterLst);
			request.getSession().removeAttribute("viewFrequency");
		} else if (selectedTab.equals("managePlug")) {
			forwardTo = "c3par.manageProxySocks";
			log.debug(" managePlug " + selectedTab);
			List<ProxyFilter> prxPlugFilterList = manageProxyProcess.loadProxyPlugFilters(
					proxyProcess, manageProxyProcess.getNoOfRecords());
			log
			.info("Proxy Plug Filter List  --->>"
					+ prxPlugFilterList.size());
			manageProxyProcess.setProxyFilterList(prxPlugFilterList);
			request.getSession().setAttribute("prxPlugFilterList", prxPlugFilterList);
			if(manageProxyProcess.getProxyFilter() != null){
				manageProxyProcess.getProxyFilter().setIsFTReqd("N");
			}
		} else if (selectedTab.equals("newInstance")) {
			forwardTo = "c3par.newProxyInstance";
			log.debug(" newInstance " + selectedTab);
			RelationshipEntity rel_entity = (RelationshipEntity) (request
					.getSession()).getAttribute("RELATIONSHIP_ENTITY");
			if(rel_entity == null){
				rel_entity = (RelationshipEntity)((TIRequestEntity)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getProcess().getRelationship();
			}
			// Long
			// regionId=util.getRegion(rel_entity.getBusinessUnit().getSectorId(),rel_entity.getEntInstanceId());
			String regionName = util.getRegionName(rel_entity.getId());
			manageProxyProcess.setPrxInsPurposeList(util
					.getPrxIns_PurposeList());
			// List proxyInstanceList =
			// proxyPersistable.findProxyInstances(rel_entity.getName());
			Long relationshipId = null;
			relationshipId = rel_entity.getId();
			log.info("Relationship Id::" + relationshipId);
			Long thirdPartyID = rel_entity.getThirdPartyId();
			Long pacCount = null;
			log.info("thirdPartyID:: " + thirdPartyID);
			String prxInstanceName = null;
			try {
				prxInstanceName = (String) util.getProxyInstanceRelationshipName(
						relationshipId, thirdPartyID);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			log.info("prxInstanceName in action:: " + prxInstanceName);
			request.setAttribute("prxInstanceName", prxInstanceName);
			List<ProxyInstance> proxyInstanceList = manageProxyProcess
					.findProxyInstances(prxInstanceName);
			if (proxyInstanceList.size() > 0) {
				if (proxyInstanceList != null) {
					ProxyInstance proxyInstance = (ProxyInstance) proxyInstanceList
							.get(0);
					manageProxyProcess.setPrxInstance(proxyInstance);
					manageProxyProcess.setIsRightReplacement(proxyInstance
							.getRightPlacement().getId());
					if (proxyInstance.getPacFileReq().equalsIgnoreCase("Y")) {
						pacCount = util.getProxyInsXrefCount(proxyInstance
								.getId());
						manageProxyProcess.setNoOfPacFiles(pacCount);
						log.debug("PAC ins count for the proxy instance id "
								+ proxyInstance.getId() + "is  " + pacCount);
					}

				}
			} else {
				// connectionRequestForm.getProxyInstance().setName(rel_entity.getName());
				manageProxyProcess.getPrxInstance().setName(
						prxInstanceName);
				if (regionName != null)
					manageProxyProcess.getPrxInstance().setRegion(
							regionName);
				manageProxyProcess.getPrxInstance().setIsNew("");
			}
		} else if (selectedTab.equals("manageUrlAccess")) {
			forwardTo = "c3par.manageUrlAccess";
			List<ProxyFilter> prxFreeUrlAccessList = manageProxyProcess
					.loadProxyFreeUrlAccess(proxyProcess, manageProxyProcess
							.getNoOfRecords());
			log.info("proxy Filter List--->>" + prxFreeUrlAccessList);
			manageProxyProcess.setProxyFilterList(prxFreeUrlAccessList);
			request.getSession().setAttribute("prxFreeUrlAccessList", prxFreeUrlAccessList);
		}
		if (!(selectedTab.equals("newInstance"))) {
			manageProxyProcess.setProxyProcess(proxyProcess);
			request.getSession().setAttribute("proxyProcess", proxyProcess);
			long totalRecords = proxyProcess.getTotalPrxFilters();
			noOfPages(manageProxyProcess, totalRecords, 1);
			request.getSession().setAttribute("viewFilter", "false");
		}
		request.getSession().setAttribute("selectedTab", selectedTab);
		
		String proxygnerateflag = manageProxyProcess.isProxyChangeCompleted(tiRequestId);
		request.getSession().setAttribute("isProxyChangeComplete", proxygnerateflag);
		String outputFormatFlag = manageProxyProcess.isPafGenerated(tiRequestId);
		request.getSession().setAttribute("outputFormatFlag", outputFormatFlag);
		log.debug("sd111"+outputFormatFlag);
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.info("ManageProxyController.load()::Ends");
		return forwardTo;
	}


	@RequestMapping(value = "/newInstance.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String newInstance(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request) {
		log.debug("Into listThirdParties");
		try{
			getCommonData(manageProxyProcess,request);
			Relationship rel_entity = (Relationship) (request
					.getSession()).getAttribute("RELATIONSHIP_ENTITY");
			if(rel_entity == null){
				rel_entity = (Relationship)((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getTiProcess().getRelationshipId();
			}
			String regionName = util.getRegionName(rel_entity.getId());
			log.debug("region name" +regionName);
			manageProxyProcess.setPrxInsPurposeList(util
					.getPrxIns_PurposeList());
			Long relationshipId = null;
			relationshipId = rel_entity.getId();
			log.info("Relationship Id::" + relationshipId);
			Long  thirdPartyID = null;
			if(rel_entity.getThirdParty() != null){
             thirdPartyID = rel_entity.getThirdParty().getId();
			}
			Long pacCount = null;
			log.info("thirdPartyID:: " + thirdPartyID); 
			String prxInstanceName = "";
			try {
				prxInstanceName = (String) util.getProxyInstanceRelationshipName(
						relationshipId, thirdPartyID);
				
				if (prxInstanceName!= null) {
					prxInstanceName = prxInstanceName.trim();
				}
			} catch (Exception e) {
				log.error(e,e);
			}
			log.info("prxInstanceName in action:: " + prxInstanceName);
			request.setAttribute("prxInstanceName", prxInstanceName);
			List<ProxyInstance> proxyInstanceList = manageProxyProcess
					.findProxyInstances(prxInstanceName);
			if (proxyInstanceList.size() > 0) {
				if (proxyInstanceList != null) {
					ProxyInstance proxyInstance = (ProxyInstance) proxyInstanceList
							.get(0);
					manageProxyProcess.setPrxInstance(proxyInstance);
					manageProxyProcess.setIsRightReplacement(proxyInstance
							.getRightPlacement().getId());
					if (proxyInstance.getPacFileReq().equalsIgnoreCase("Y")) {
						pacCount = util.getProxyInsXrefCount(proxyInstance
								.getId());
						manageProxyProcess.setNoOfPacFiles(pacCount);
						log.debug("PAC ins count for the proxy instance id "
								+ proxyInstance.getId() + "is  " + pacCount);   
					}
					
					request.setAttribute("isNew", "N");

				}
			} else {
				manageProxyProcess.setPrxInstance(new ProxyInstance());
				manageProxyProcess.getPrxInstance().setName(
						prxInstanceName);
				if (regionName != null) {
					manageProxyProcess.getPrxInstance().setRegion(
							regionName);
				}
				request.setAttribute("isNew", "Y");
				manageProxyProcess.getPrxInstance().setIsNew("");
			}
			model.addAttribute("manageProxyProcess",manageProxyProcess);
			log.debug("pac name while loading" +manageProxyProcess.getPrxInstance().getName() +manageProxyProcess.getPrxInstance().getRegion());
		}
		catch(Exception e){
			log.error(e,e);
		}

		return "c3par.newProxyInstance";
	}

	@RequestMapping(value = "/addProxyInstance.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String addProxyInstance(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request) {
		String insAction = null;
		GenericLookup lookup = null;
		boolean createMode = false;
		log.info("ManageProxyController.addProxyInstance :: Starts");
		try{
		insAction = request.getParameter("insAction");
		ProxyInstance proxyInstance = manageProxyProcess.getPrxInstance();
		lookup = new GenericLookup();
		lookup.setId(manageProxyProcess.getIsRightReplacement());
		proxyInstance.setRightPlacement(lookup);
		request.setAttribute("prxInstanceName", proxyInstance.getName());
		if (insAction.equals("create")) {
			proxyInstance.setIsNew("Y");
			createMode = true;
		} else if (insAction.equals("update")) {
			createMode = false;
		}
		log.debug("mode" +insAction);
		log.debug("Proxy instance id after insertion ::" + proxyInstance.getId());
		
		String instanceName = proxyInstance.getName();
		
		log.debug("pac name" +instanceName);
		if (proxyInstance.getPacFileReq().equalsIgnoreCase("Y") && proxyInstance
				.getId() != null && createMode) {
			Long pacCount = util.getProxyInsXrefCount(proxyInstance
					.getId());
			manageProxyProcess.setNoOfPacFiles(pacCount);
			log.debug("PAC ins count for the proxy instance id "
					+ proxyInstance.getId() + "is  " + pacCount);   

			for (int i = 1; i <= manageProxyProcess.getNoOfPacFiles()
					.intValue(); i++) {
				ProxyInstance prxPACInstance = new ProxyInstance();
				ProxyInstanceXref piXref = new ProxyInstanceXref();

				String insName = instanceName + "_" + i;
				prxPACInstance.setName(insName);
				prxPACInstance.setRecordType("PACFILE");
				prxPACInstance.setRegion(proxyInstance.getRegion());
				prxPACInstance.setRightPlacement(proxyInstance
						.getRightPlacement());
				prxPACInstance.setIsNew(proxyInstance.getIsNew());
				prxPACInstance.setPacFileReq(proxyInstance.getPacFileReq());
				prxPACInstance.setReasonForPACFile(proxyInstance.getReasonForPACFile());
				prxPACInstance.setInstanceDesc(proxyInstance.getInstanceDesc());
				prxPACInstance.setInternetAccess(proxyInstance.getInternetAccess());

				log.debug("pacinstance id after insertion ::"
						+ prxPACInstance.getId());
				piXref.setChildInstance(prxPACInstance);
				proxyInstance.getInstanceXrefSet().add(piXref);
			}

		} else {
			proxyInstance.setInstanceXrefSet(null);
		}
		manageProxyProcess.storeProxyInstance(proxyInstance, createMode);
		}
		catch(Exception e){
			log.error(e,e);
			manageProxyProcess.setPrxInsPurposeList(util
					.getPrxIns_PurposeList());
			return "c3par.newProxyInstance";
		}
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.info("ManageProxyController.addProxyInstance :: End");
		return "forward:/newInstance.act";
	}

	@RequestMapping(value = "/addPac.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String addPac(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request) {
		Long processId = 0L;
		try {
			return searchProxyInstance(model,manageProxyProcess,request);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try{	
			log.debug("manage/Proxy" +manageProxyProcess.getProxyRegionList().size());
			getCommonData(manageProxyProcess, request);
			ProxyProcess proxyProcess = new ProxyProcess();
			ProxyFilter filterObject = new ProxyFilter();
			boolean isSelectAll = false;
			isSelectAll = manageProxyProcess.getProxyProcess().isSelectAll();
			proxyProcess = manageProxyProcess.getProxyProcess(processId.longValue());
			proxyProcess.setSelectAll(isSelectAll);
			proxyProcess.setFilterObject(filterObject);
			List<ProxyFilter> prxPacFileFilterLst = manageProxyProcess.loadProxyInstances(
					proxyProcess, manageProxyProcess.getNoOfRecords());
			log.info("Proxy Pac File Filter List --->>"
					+ prxPacFileFilterLst.size());
			manageProxyProcess.setProxyFilterList(prxPacFileFilterLst);
			// Have to consider the usage
			request.getSession().setAttribute("viewSearch", "false");
			request.getSession().setAttribute("loadSearch", "false");
			manageProxyProcess.setProxyProcess(proxyProcess);
			long totalRecords = proxyProcess.getTotalPrxFilters();
			noOfPages(manageProxyProcess, totalRecords, 1);
			request.getSession().setAttribute("viewFilter", "false");
			request.getSession().setAttribute("proxyRegionList1", manageProxyProcess.getProxyRegionList());
			request.getSession().setAttribute("proxyProcess1", proxyProcess);
			model.addAttribute("manageProxyProcess",manageProxyProcess);
		}
		catch( Exception e)
		{
			log.error(e,e);
		}
		log.info("ManageProxyController.addProxyInstance :: End");
		return "c3par.addPacFile";
	}

	@RequestMapping(value = "/searchProxyInstance.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String searchProxyInstance(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request)
			throws Exception {
		String forwardTo = "loadAddPacFile";
		log.info("ManageProxyController.searchProxyInstance()::Starts");

		//connectionRequestForm.clear();
		if(manageProxyProcess.getNoOfRecords()==0){
			manageProxyProcess.setNoOfRecords(noOfRecords);
		}
		ProxyProcess proxyProcess = new ProxyProcess();
		Long lookUpId = util.getLookupId(LookupNameHelper.RIGHT_PLACEMENT);
		if(manageProxyProcess
				.getPrxInstance() == null){
			manageProxyProcess.setPrxInstance(new ProxyInstance());
		}
		GenericLookup rightPlacement=new GenericLookup();
		rightPlacement.setId(lookUpId);
		//connectionRequestForm.getProxyInstance().setRightPlacement(rightPlacement);
		List proxyRegionList = util.getManageProxyRegion("BASIC");
		log.debug("region size" +proxyRegionList.size());
		manageProxyProcess.setProxyRegionList(proxyRegionList);
		request.getSession().setAttribute("proxyRegionList", proxyRegionList);
		proxyProcess.setProxyInstanceObject(manageProxyProcess
				.getPrxInstance());
		List<ProxyInstance> proxyInstanceList = manageProxyProcess.loadProxyInstances(
				proxyProcess, manageProxyProcess.getNoOfRecords());
		log.info("proxyInstanceList --->>" + proxyInstanceList.size());
		List<ProxyInstance>  proxyPACInstanceList = new ArrayList(0);
		ProxyInstance proxyPACInstance=new ProxyInstance();
		proxyPACInstance.setInternetAccess("N");
		manageProxyProcess.setProxyPACInstance(proxyPACInstance);
		manageProxyProcess.setProxyPACInstanceList(proxyPACInstanceList);
		manageProxyProcess.setProxyInstanceList(proxyInstanceList);
		manageProxyProcess.setProxyProcess(proxyProcess);
		long totalRecords = proxyProcess.getTotalPrxInstance();
		noOfPages(manageProxyProcess, totalRecords, 1);
		totalRecords = proxyProcess.getTotalPACPrxInstance();
		log.debug("pac file size" +manageProxyProcess.getNoOfPACRecords());
		noOfPACPages(manageProxyProcess, totalRecords, 1);

		log.info("ManageProxyController.load()::Ends");
		return "c3par.addPacFile";
	}

	public void getCommonData(ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		Long processId;

		if (request.getParameter("processId") != null) {
			processId = Long.valueOf(request.getParameter("processId"));
			manageProxyProcess.setProcessId(processId);
		}else if(request.getSession().getAttribute("TI_REQUEST_ENTITY")!=null){
			manageProxyProcess.setTiRequest((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY"));
			processId=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getTiProcess().getId();
			manageProxyProcess.setProcessId(processId);
		}else {
			processId = manageProxyProcess.getProcessId();
		}
		log.info("processId===" + processId);
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}
		log.info("tiRequestId===" + tiRequestId);
		String requestType =  null;
		if (manageProxyProcess.getTiRequest().getTiRequestType() != null
				&& manageProxyProcess.getTiRequest().getTiRequestType().getName() != null) {
			requestType = manageProxyProcess.getTiRequest().getTiRequestType().getName();
			log.debug(" Request Type :: " + requestType);
			if (requestType != null
					&& requestType.equalsIgnoreCase("Terminate")) {
				log.debug("Setting DisplayMode to View for Termination Cycle");
				request.getSession().setAttribute("displayMode", "View");
			}
		}
	}

	private void noOfPages(ManageProxyProcess manageProxyProcess,
			long totalRecords, int pageNo) {
		long totalPages = totalRecords / manageProxyProcess.getNoOfRecords();
		if (totalRecords % manageProxyProcess.getNoOfRecords() > 0) {
			totalPages += 1;
			manageProxyProcess.setTotalPages(totalPages);
		} else {
			manageProxyProcess.setTotalPages(totalPages);
		}
		if (totalPages == 0) {
			manageProxyProcess.setPageNo((long) 0);
		} else {
			manageProxyProcess.setPageNo((long) pageNo);
		}
	}

	private void noOfPACPages(ManageProxyProcess manageProxyProcess,
			long totalRecords, int pageNo) {
		long totalPages = totalRecords / manageProxyProcess.getNoOfPACRecords();
		if (totalRecords % manageProxyProcess.getNoOfPACRecords() > 0) {
			totalPages += 1;
			manageProxyProcess.setTotalPACPages(totalPages);
		} else {
			manageProxyProcess.setTotalPACPages(totalPages);
		}
		if (totalPages == 0) {
			manageProxyProcess.setPACPageNo(0L);
		} else {
			manageProxyProcess.setPACPageNo((long) pageNo);
		}
	}

	@RequestMapping(value = "/loadProxyInstance.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadProxyInstance(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		log.debug("into loadProxyInstance");
		int pNo = manageProxyProcess.getPageNo().intValue();
		long recCount = manageProxyProcess.getProxyProcess().getTotalPrxInstance();
		log.debug("pa n rc" +pNo +recCount);
		addPac(model, manageProxyProcess, request);
		ProxyProcess proxyProcess = new ProxyProcess();
		proxyProcess.setProxyInstanceObject(manageProxyProcess.getPrxInstance());
		List<ProxyInstance> proxyInstanceList = manageProxyProcess.loadProxyInstances(
				proxyProcess,pNo, manageProxyProcess.getNoOfRecords());
		noOfPages(manageProxyProcess,recCount, pNo);
		manageProxyProcess.setProxyInstanceList(proxyInstanceList);
		ProxyInstance proxyInstance = manageProxyProcess 
				.getProxyInstance(manageProxyProcess
						.getSelectedProxyInstanceId());
		ProxyInstance proxyPACInstance = new ProxyInstance();
		proxyPACInstance.setInstanceName(proxyInstance.getName());
		proxyPACInstance.setInternetAccess("N");
		manageProxyProcess.setProxyPACInstance(proxyPACInstance);
		proxyProcess.setProxyInstanceObject(proxyInstance);
		List proxyPACInstanceList = manageProxyProcess.loadProxyPACInstances(
				proxyProcess, manageProxyProcess.getNoOfPACRecords());
		if (proxyPACInstanceList == null) {
			proxyPACInstanceList = new ArrayList(0);
		}
		log.debug("size of list" +proxyPACInstanceList.size() +manageProxyProcess.getProxyPACInstance());
		manageProxyProcess.setProxyPACInstanceList(proxyPACInstanceList);
		long totalRecords = proxyProcess.getTotalPACPrxInstance();
		log.debug("pac file size" +manageProxyProcess.getNoOfPACRecords());
		noOfPACPages(manageProxyProcess, totalRecords, 1);
		
		request.getSession().setAttribute("viewPAC", "false");
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.debug("out of loadProxyInstance");
		return  "c3par.addPacFile";
	}

	@RequestMapping(value = "/loadProxyPACInstance.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadProxyPACInstance(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		loadProxyInstance(model, manageProxyProcess, request);
		ProxyInstance proxyInstance = manageProxyProcess
				.getProxyInstance(manageProxyProcess
						.getSelectedProxyInstanceId());
		ProxyInstance proxyPACInstance = manageProxyProcess
				.getProxyInstance(manageProxyProcess
						.getSelectedProxyPACInstanceId());
		proxyPACInstance.setInstanceName(proxyInstance.getName());
		manageProxyProcess.setProxyPACInstance(proxyPACInstance);
		request.getSession().setAttribute("viewPAC", "true");
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		return "c3par.addPacFile";
	}

	@RequestMapping(value = "/addOrEditProxyPACInstance.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String addOrEditProxyPACInstance(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,BindingResult result,HttpServletRequest request) {
		String forwardTo = "loadAddPacFile";
		String insAction = null;
		GenericLookup lookup = null;
		boolean createMode = false;
		String pacFileOption = "N";
		log.info("ManageProxyController.addProxyInstance :: Starts");
		insAction = request.getParameter("insAction");
		ProxyInstance proxyInstance = manageProxyProcess
				.getProxyInstance(manageProxyProcess
						.getSelectedProxyInstanceId());

		try{
		if (insAction.equals("create")) {
			proxyInstance.setIsNew("Y");
			createMode = true;
		} else if (insAction.equals("update")) {
			createMode = false;
		}
		log.debug("Proxy instance id after insertion ::"
				+ proxyInstance.getId());
		String instanceName = proxyInstance.getName();
		ProxyInstance prxPACInstance = new ProxyInstance();
		prxPACInstance.setName(manageProxyProcess.getProxyPACInstance().getName());
		prxPACInstance.setRecordType("PACFILE");
		prxPACInstance.setRegion(proxyInstance.getRegion());
		prxPACInstance.setPortNumber(proxyInstance.getPortNumber());
		prxPACInstance.setRightPlacement(proxyInstance.getRightPlacement());
		if (createMode) {
			prxPACInstance.setId(null);
		}else{
			prxPACInstance.setId(manageProxyProcess
					.getSelectedProxyPACInstanceId());
		}
		if(manageProxyProcess.isProxyInstanceExists(prxPACInstance)){
			result.addError(new ObjectError("add", "The same PAC file is already exists.Please enter different name."));
			throw new BusinessException(
					"The same PAC file is already exists.Please enter different name.");
		}
		
		if (createMode) {
			prxPACInstance = new ProxyInstance();
			prxPACInstance.setInternetAccess(manageProxyProcess
					.getProxyPACInstance().getInternetAccess());
			prxPACInstance.setName(manageProxyProcess.getProxyPACInstance().getName().trim());
			prxPACInstance.setRecordType("PACFILE");
			prxPACInstance.setRegion(proxyInstance.getRegion());
			prxPACInstance.setPortNumber(proxyInstance.getPortNumber());
			prxPACInstance.setRightPlacement(proxyInstance.getRightPlacement());
			prxPACInstance.setIsNew(proxyInstance.getIsNew());
			prxPACInstance.setInstanceDesc(proxyInstance.getInstanceDesc());
			prxPACInstance.setPacFileReq(proxyInstance.getPacFileReq());
			//prxPACInstance.setInternetAccess(proxyInstance.getInternetAccess());
			prxPACInstance.setCreated_date(new Date());
			ProxyInstanceXref piXref = new ProxyInstanceXref();
			log.debug("pacinstance id after insertion ::"
					+ prxPACInstance.getId());
			piXref.setChildInstance(prxPACInstance);
			Set instanceXrefSet = new HashSet();
			piXref.setChildInstance(prxPACInstance);
			instanceXrefSet.add(piXref);
			proxyInstance.setInstanceXrefSet(instanceXrefSet);

			manageProxyProcess.storeProxyInstance(proxyInstance, false);
		} else {
			if (manageProxyProcess.isPACLocked(manageProxyProcess
					.getSelectedProxyPACInstanceId())) {
				result.addError(new ObjectError("add", "PAC instance has been locked and hence cannot be edited."));
				throw new BusinessException(
						"PAC instance has been locked and hence cannot be edited.");
			}
			prxPACInstance = manageProxyProcess
					.getProxyInstance(manageProxyProcess
							.getSelectedProxyPACInstanceId());
			log.debug("id value during update" +manageProxyProcess.getSelectedProxyPACInstanceId());
			prxPACInstance.setName(manageProxyProcess.getProxyPACInstance().getName().trim());
			prxPACInstance.setInternetAccess(manageProxyProcess
					.getProxyPACInstance().getInternetAccess());
			manageProxyProcess.updateProxyInstance(prxPACInstance);
		}
		ProxyProcess proxyProcess = new ProxyProcess();
		proxyProcess.setProxyInstanceObject(proxyInstance);
		List<ProxyInstance> proxyPACInstanceList = manageProxyProcess.loadProxyPACInstances(
				proxyProcess, manageProxyProcess.getNoOfPACRecords());
		if (proxyPACInstanceList == null) {
			proxyPACInstanceList = new ArrayList(0);
		}
		manageProxyProcess.setProxyPACInstanceList(proxyPACInstanceList);
		prxPACInstance = new ProxyInstance();
		prxPACInstance.setInstanceName(proxyInstance.getName());
		manageProxyProcess.setProxyPACInstance(prxPACInstance);
		long totalRecords = proxyProcess.getTotalPACPrxInstance();
		noOfPACPages(manageProxyProcess, totalRecords, 1);
		request.getSession().setAttribute("viewPAC", "false");
		forwardTo = loadProxyInstance(model, manageProxyProcess, request);
		}
		catch(Exception e){
			log.error(e,e);
			forwardTo = loadProxyInstance(model, manageProxyProcess, request);
		}
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.info("ManageProxyController.addProxyInstance :: End");
		return forwardTo;

	}

	@RequestMapping(value = "/deleteProxyPACInstance.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String deleteProxyPACInstance(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,BindingResult result,HttpServletRequest request) throws Exception{
		String forwardTo = "";
		ProxyProcess proxyProcess = new ProxyProcess();
		try{
		ProxyInstance proxyInstance = manageProxyProcess
				.getProxyInstance(manageProxyProcess
						.getSelectedProxyInstanceId());
		proxyProcess.setProxyInstanceObject(proxyInstance);
		if (manageProxyProcess.isURLAddedForPAC(manageProxyProcess
				.getSelectedProxyPACInstanceId())) {
			result.addError(new ObjectError("del", "URL has been assigned for the selected PAC instance and hence cannot be deleted."));
			throw new BusinessException(
					"URL has been assigned for the selected PAC instance and hence cannot be deleted.");
		}
		if (manageProxyProcess.isPACLocked(manageProxyProcess
				.getSelectedProxyPACInstanceId())) {
			result.addError(new ObjectError("loc", "PAC instance has been locked and hence cannot be deleted."));
			throw new BusinessException(
					"PAC instance has been locked and hence cannot be deleted.");
		}
		manageProxyProcess.deleteProxyInstance(manageProxyProcess
				.getSelectedProxyPACInstanceId());
		List<ProxyInstance> proxyPACInstanceList = manageProxyProcess.loadProxyPACInstances(
				proxyProcess, manageProxyProcess.getNoOfPACRecords());
		if (proxyPACInstanceList == null) {
			proxyPACInstanceList = new ArrayList(0);
		}
		manageProxyProcess.setProxyPACInstanceList(proxyPACInstanceList);
		long totalRecords = proxyProcess.getTotalPACPrxInstance();
		noOfPACPages(manageProxyProcess, totalRecords, 1);
		ProxyInstance prxPACInstance = new ProxyInstance();
		prxPACInstance.setInstanceName(proxyInstance.getName());
		manageProxyProcess.setProxyPACInstance(prxPACInstance);
		request.getSession().setAttribute("viewPAC", "false");
		forwardTo= loadProxyInstance(model, manageProxyProcess, request);
		}
		catch(Exception e){
			log.error(e,e);
			forwardTo= loadProxyInstance(model, manageProxyProcess, request);
		}
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		return forwardTo;
	}


	@RequestMapping(value = "/cancelProxyPACInstance.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String cancelProxyPACInstance(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request) {
		String forwardTo = "loadAddPacFile";
		ProxyInstance proxyInstance = manageProxyProcess
				.getProxyInstance(manageProxyProcess
						.getSelectedProxyInstanceId());
		ProxyInstance proxyPACInstance = new ProxyInstance();
		proxyPACInstance.setInstanceName(proxyInstance.getName());
		manageProxyProcess.setProxyPACInstance(proxyPACInstance);
		request.getSession().setAttribute("viewPAC", "false");
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		forwardTo= loadProxyInstance(model, manageProxyProcess, request);
		return forwardTo;
	}


	@RequestMapping(value = "/manageProxy.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String manageProxy(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request) {
		String recType = "BASIC";

		ProxyProcess proxyProcess = new ProxyProcess();
		ProxyFilter filterObject = new ProxyFilter();
		String filterSelection = manageProxyProcess.getFilterSelection();
		if ("yes".equalsIgnoreCase(request.getParameter("applyFilter"))) {
			filterObject = manageProxyProcess.getFilterObject();
		}
		if(manageProxyProcess.getNoOfRecords()==0){
			manageProxyProcess.setNoOfRecords(noOfRecords);
		}
		if ("yes".equalsIgnoreCase(request.getParameter("applyFilter"))) {
			manageProxyProcess.setFilterSelection(filterSelection);
			manageProxyProcess.setFilterObject(filterObject);
		}
		getCommonData(manageProxyProcess, request);
		proxyProcess = manageProxyProcess.getProxyProcess(manageProxyProcess.getProcessId().longValue());

		List proxyRegionList = util.getManageProxyRegion(recType);
		manageProxyProcess.setProxyRegionList(proxyRegionList);
		List<ProxyFilter> proxyFilterList = manageProxyProcess.loadProxyFilters(
				proxyProcess, manageProxyProcess.getNoOfRecords());
		log.info("proxy Filter List--->>" + proxyFilterList);
		manageProxyProcess.setProxyFilterList(proxyFilterList);
		request.getSession().setAttribute("viewSearch", "false");
		request.getSession().setAttribute("loadSearch", "false");
		manageProxyProcess.setProxyProcess(proxyProcess);
		log.debug("proxy is there" +manageProxyProcess.getProxyProcess().getIsNew());
		long totalRecords = proxyProcess.getTotalPrxFilters();
		noOfPages(manageProxyProcess, totalRecords, 1);
		request.getSession().setAttribute("viewFilter", "false");
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		return "c3par.manageProxy";
	}

	@RequestMapping(value = "/findProxyInstance.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String findProxyInstance(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request)
			throws Exception {

		String recType = "BASIC";
		String forwardTo = null;
		String regionName = null;
		String instanceName = null;
		String portNumber = null;
		long totalRecords = 1;
		int prxFilterTotalRecords = 0;
		log.info("ManageProxyController.findProxyInstance()::Starts" +manageProxyProcess.getProxyProcess());
		ProxyFilter proxyFilter = manageProxyProcess.getProxyFilter();
		ProxyInstance proxyInstance = manageProxyProcess.getPrxInstance();
		prxFilterTotalRecords = manageProxyProcess.getProxyProcess()
				.getTotalPrxFilters();
		ProxyProcess proxyProcess = new ProxyProcess();
		regionName = proxyInstance.getRegion();
		instanceName = proxyInstance.getName();
		portNumber = proxyInstance.getPortNumber();
		Long processId=null;
		if(manageProxyProcess.getOriginalConnectionRequestId()!=null){
			processId = manageProxyProcess.getOriginalConnectionRequestId();
		}else if(request.getSession().getAttribute("TI_REQUEST_ENTITY")!=null){
			processId=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getTiProcess().getId();
		}

		log.info("findProxyInstance:processId===" + processId);
		proxyProcess = manageProxyProcess.getProxyProcess(processId.longValue());
		Long replacementValue = util.getReplacementValue();
		List<ProxyInstance> proxyInstanceList;
		proxyInstanceList = manageProxyProcess.findProxyInstances(proxyProcess,
				instanceName, portNumber, regionName,
				recType, manageProxyProcess.getPrxInsNoOfRecords());
		log.info("ManageProxyController.findProxyInstance()::proxyInstanceList---"
				+ proxyInstanceList.size());

		totalRecords = proxyProcess.getTotalPrxInstance();
		if (manageProxyProcess.getSelectAll() != null
				&& "true".equals(manageProxyProcess.getSelectAll())) {
			proxyProcess.setSelectAll(true);
		} else {
			proxyProcess.setSelectAll(false);
		}
		log.info("ManageProxyController.findProxyInstance() isSelectAll :::: "
				+ proxyProcess.isSelectAll());
		proxyInstance.setName(null);
		proxyInstance.setPortNumber(null);
		proxyFilter.setProxyInstance(proxyInstance);
		request.getSession().setAttribute("proxyInstanceListForFilter", proxyInstanceList);
		manageProxyProcess.setPrxInstanceList(proxyInstanceList);
		log.info("In Find Proxy Instance Filter Size:"
				+ prxFilterTotalRecords);
		proxyProcess.setTotalPrxFilters(prxFilterTotalRecords);
		proxyProcess.setProxyFilterList(manageProxyProcess.getProxyFilterList());
		manageProxyProcess.setProxyProcess(proxyProcess);
		long totalPages = totalRecords
				/ manageProxyProcess.getPrxInsNoOfRecords();
		if (totalRecords % manageProxyProcess.getPrxInsNoOfRecords() > 0) {
			totalPages += 1;
			manageProxyProcess.setPrxInsTotalPages(totalPages);
		} else {
			manageProxyProcess.setPrxInsTotalPages(totalPages);
		}
		if (totalPages == 0) {
			manageProxyProcess.setPrxInsPageNo(0);
		} else {
			manageProxyProcess.setPrxInsPageNo(1);
		}
		request.getSession().setAttribute("loadSearch", "true");
		request.getSession().setAttribute("viewSearch", "false");
		request.getSession().setAttribute("proxyInstanceList1", proxyInstanceList);
		manageProxyProcess.setProxyRegionList((List<Region>) request.getSession().getAttribute("proxyRegionList"));
		manageProxyProcess.setProxyFilterList((List<ProxyFilter>) request.getSession().getAttribute("proxyFilterListManageProxy"));
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.info("ManageProxyController.findProxyInstance()::Ends");
		return "c3par.manageProxy";
	}

	@RequestMapping(value = "/loadUrl.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String loadUrl(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request) {
		log.info("ManageProxyController.loadUrl()::Starts");
		List<ProxyInstance> proxyInstanceList = manageProxyProcess.getPrxInstanceList();
		ProxyFilter proxyFilter = new ProxyFilter();
		if(proxyInstanceList!=null){
			log.debug("list size" +proxyInstanceList.size());
		}
		else{
			log.debug("into else");
		}
		ProxyInstance proxyInstance = new ProxyInstance();
		ProxyProcess proxyProcess = new ProxyProcess();
		Long processId=null;
		if(manageProxyProcess.getOriginalConnectionRequestId()!=null){
			processId = manageProxyProcess.getOriginalConnectionRequestId();
		}else if(request.getSession().getAttribute("TI_REQUEST_ENTITY")!=null){
			processId=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getTiProcess().getId();
		}
		proxyProcess = manageProxyProcess.getProxyProcess(processId.longValue());
		proxyInstance = manageProxyProcess.getPrxInstance();
		List proxyInstList = manageProxyProcess
				.findProxyInstances(proxyProcess,
						proxyInstance.getName(), proxyInstance
						.getPortNumber(), proxyInstance
						.getRegion(), "BASIC",
						(int) manageProxyProcess.getPrxInsPageNo(), manageProxyProcess
						.getPrxInsNoOfRecords());
		proxyInstance = manageProxyProcess
				.getProxyInstance(manageProxyProcess
						.getSelectedProxyInstanceId());
		proxyFilter.setProxyInstance(proxyInstance);
		manageProxyProcess.setProxyFilter(proxyFilter);
		manageProxyProcess.setProxyRegionList((List<Region>) request.getSession().getAttribute("proxyRegionList"));
		manageProxyProcess.setPrxInstanceList(proxyInstList);
		request.getSession().setAttribute("proxyInstanceListForFilter", proxyInstList);
		manageProxyProcess.setProxyFilterList((List<ProxyFilter>) request.getSession().getAttribute("proxyFilterListManageProxy"));
		
		long totalRecords = manageProxyProcess.getProxyProcess()
				.getTotalPrxInstance();
		
		long totalPages = totalRecords / manageProxyProcess.getPrxInsNoOfRecords();
		if (totalRecords % manageProxyProcess.getPrxInsNoOfRecords() > 0) {
			totalPages += 1;
			manageProxyProcess.setPrxInsTotalPages(totalPages);
		} else {
			manageProxyProcess.setPrxInsTotalPages(totalPages);
		}
		
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		request.getSession().setAttribute("selectedTab", "manageProxy");
		request.getSession().setAttribute("viewSearch", "true");
		log.info("ManageProxyController.loadUrl()::Ends");
		return "c3par.manageProxy";
	}

	@RequestMapping(value = "/addProxyFilterForProxy.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String addProxyFilterForProxy(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,BindingResult result, HttpServletRequest request){
		String forwardTo = null;
		String selectedTab = null;
		GenericLookup lookup = null;
		log.info("ManageProxyController.addProxyFilter() :: Starts...");
		String originalPrxName=manageProxyProcess.getProxyFilter().getProxyInstance().getName();
		String proxyFilterPort = manageProxyProcess.getProxyFilter().getOriginalPort();
		String proxyURL = manageProxyProcess.getProxyFilter().getUrl();
		String selectRegion = manageProxyProcess.getProxyFilter().getProxyInstance().getRegion();
		String selectStatement = manageProxyProcess.getProxyFilter().getStatement();
		String selectDomain = manageProxyProcess.getProxyFilter().getDomainName();

		log.info("proxyFilterPort::" + proxyFilterPort);
		log.info("proxyURL::" + proxyURL);
		selectedTab = request.getParameter("tab");

		Long processId=null;
		if(manageProxyProcess.getOriginalConnectionRequestId()!=null){
			processId = manageProxyProcess.getOriginalConnectionRequestId();
		}else if(request.getSession().getAttribute("TI_REQUEST_ENTITY")!=null){
			processId=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getTiProcess().getId();
		}
		log.info("processId===" + processId);
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq +"sfrd" +manageProxyProcess.getProxyProcess().getTotalPrxInstance());
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}
		log.info("tiRequestId===" + tiRequestId);
		String selectStatementRedirect = manageProxyProcess.getProxyFilter().getStatementRedirect();
		log.info("selectStatementRedirect :: " + selectStatementRedirect);
		ProxyFilter proxyFilter = manageProxyProcess.getProxyFilter();
		TIProcess tiProcess = manageProxyProcess.getTIProcess(tiRequestId.longValue());
		TIRequest tiRequest = manageProxyProcess.getTIRequest(tiRequestId.longValue());
		proxyFilter.setTiProcess(tiProcess);
		proxyFilter.setTiRequest(tiRequest);
		// Added for Task 9219
		AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		appsenseADGroup.setId(Long.valueOf(0));
		proxyFilter.setAppsenseADGroup(appsenseADGroup);
		try{
		if (selectedTab.equals("manageProxy")) {
			forwardTo = "c3par.manageProxy";
			if (proxyURL == null
					|| (proxyURL != null && proxyURL.trim().equals(""))) {
				result.addError(new ObjectError("url", "Please provide URL data."));
				throw new BusinessException("Please provide URL data.");
			} else {
				manageProxyProcess.storeProxyFilter(proxyFilter);
				manageProxyProcess.setProxyRegionList((List<Region>) request.getSession().getAttribute("proxyRegionList"));
			}
		} else if (selectedTab.equals("managePacFile")) {
			forwardTo = "c3par.managePacFile";
			manageProxyProcess.getProxyFilter().getProxyInstance().setName(manageProxyProcess.getProxyPACInstance().getName());
			if (selectRegion == null
					|| (selectRegion != null && selectRegion.trim().equals(""))
					|| (selectRegion != null && selectRegion.trim()
					.equalsIgnoreCase("-- Select Region --"))) {
				result.addError(new ObjectError("reg", "Please select the Region."));
				throw new BusinessException("Please select the Region.");
			}
			if (!(isValidData(selectStatement) && isValidData(selectDomain))) {
				result.addError(new ObjectError("dom", "Statement and Fully Qualified Domain Name or Application URL are mandatory."));
				throw new BusinessException(
						"Statement and Fully Qualified Domain Name or Application URL are mandatory.");
			}

			try {
				manageProxyProcess.storeProxyPacFileFilter(proxyFilter);
				manageProxyProcess.getProxyFilter().getProxyInstance().setName(originalPrxName);
			} catch (Exception e) {
				manageProxyProcess.getProxyFilter().getProxyInstance().setName(originalPrxName);
			}

		} else if (selectedTab.equals("manageSocks")) {
			log.info("ManageProxyController.manageSocks() :: Start...>>>>>>>>>>>");
			log.info("ManageProxyController.manageSocks() :: Start...  Src Flag Check>>>>>>>>>>>"+proxyFilter.getIsSrcFQDN());
			log.info("ManageProxyController.manageSocks() :: Start...  Destination Flag Check>>>>>>>>>>>"+proxyFilter.getIsDesFQDN());

			forwardTo = "c3par.manageProxySocks";
			if (selectRegion == null
					|| (selectRegion != null && selectRegion.trim().equals(""))
					|| (selectRegion != null && selectRegion.trim()
					.equalsIgnoreCase("-- Select Region --"))) {
				result.addError(new ObjectError("reg", "Please select the Region."));
				throw new BusinessException("Please select the Region.");
			}
			if (proxyFilterPort == null
					|| (proxyFilterPort != null && proxyFilterPort.trim()
					.equals(""))) {
				result.addError(new ObjectError("port", "Please provide Port data."));
				throw new BusinessException("Please provide Port data.");
			} else {
				if (!portCheck(proxyFilterPort)) {
					result.addError(new ObjectError("port", "Please provide valid Port data."));
					throw new BusinessException(
							"Please provide valid Port data.");
				}
			}
			if (proxyFilter.getProtocol() != null
					|| !(proxyFilter.getProtocol().equals(""))) {
				String tempPortValue = proxyFilter.getProtocol() + "/"
						+ proxyFilterPort;
				proxyFilter.setPort(tempPortValue);
			}
			if (proxyFilter.getIsFTReqd().equals("Y")) {
				if (manageProxyProcess.getDataFrequency() != null
						&& manageProxyProcess.getDataFrequency().intValue() != 0) {
					log.debug("File Transfer Data Frequency ::"
							+ manageProxyProcess.getDataFrequency());
					lookup = new GenericLookup();
					lookup.setId(manageProxyProcess.getDataFrequency());
					proxyFilter.setFrequency(lookup);
				} else {
					result.addError(new ObjectError("freq", "Please select Data Frequency when File Transfer is Required.  "));
					throw new BusinessException(
							"Please select Data Frequency when File Transfer is Required.  ");
				}
				if (manageProxyProcess.getDataSize() != null
						&& manageProxyProcess.getDataSize().intValue() != 0) {
					log.debug("File Transfer Data Size  ::"
							+ manageProxyProcess.getDataSize());
					lookup = new GenericLookup();
					lookup.setId(manageProxyProcess.getDataSize());
					proxyFilter.setFileSize(lookup);
				} else {
					result.addError(new ObjectError("data", "Please select Data Size when File Transfer is Required. "));
					throw new BusinessException(
							"Please select Data Size when File Transfer is Required.  ");
				}
			} else {
				proxyFilter.setFrequency(null);
				proxyFilter.setFileSize(null);
			}
			manageProxyProcess.storeProxySocksFilter(proxyFilter);
		} else if (selectedTab.equals("managePlug")) {
			log.info("ManageProxyController.managePlug() :: Start...>>>>>>>>>>>");
			log.info("ManageProxyController.managePlug() :: Start...  Src Flag Check>>>>>>>>>>>"+proxyFilter.getIsSrcFQDN());
			log.info("ManageProxyController.managePlug() :: Start...  Destination Flag Check>>>>>>>>>>>"+proxyFilter.getIsDesFQDN());

			forwardTo = "c3par.manageProxySocks";
			if (proxyFilterPort == null
					|| (proxyFilterPort != null && proxyFilterPort.trim()
					.equals(""))) {
				result.addError(new ObjectError("port", "Please provide Port data."));
				throw new BusinessException("Please provide Port data.");
			} else {
				if (!portCheck(proxyFilterPort)) {
					result.addError(new ObjectError("port", "Please provide valid Port data."));
					throw new BusinessException(
							"Please provide valid Port data.");
				}
			}
			if (proxyFilter.getProtocol() != null
					|| !(proxyFilter.getProtocol().equals(""))) {
				String tempPortValue = proxyFilter.getProtocol() + "/"
						+ proxyFilterPort;
				proxyFilter.setPort(tempPortValue);
			}
			manageProxyProcess.storeProxyPlugFilter(proxyFilter);
		} else if (selectedTab.equals("manageUrlAccess")) {
			forwardTo = "c3par.manageUrlAccess";
			if (selectRegion == null
					|| (selectRegion != null && selectRegion.trim().equals(""))
					|| (selectRegion != null && selectRegion.trim()
					.equalsIgnoreCase("-- Select Region --"))) {
				result.addError(new ObjectError("region", "Please select the Region."));
				throw new BusinessException("Please select the Region.");
			}
			if ((proxyFilter.getDomainName() == null || (proxyFilter.getDomainName() != null &&  proxyFilter
					.getDomainName().trim().equals("")))
					&& (proxyFilter.getUrl() == null || (proxyFilter.getUrl() != null &&  proxyFilter
					.getUrl().trim().equals("")))) {
				result.addError(new ObjectError("url", "Please enter data for eithier Fully Qualified Domain Name or Application Url."));
				throw new BusinessException(
						"Please enter data for eithier Fully Qualified Domain Name or Application Url.");
			}
			proxyFilter.getProxyInstance().setName(proxyFilter.getProxyInstance().getInstanceCode());
			manageProxyProcess.storeProxyFreeUrlAccess(proxyFilter);
		}
		request.setAttribute("tab", selectedTab);
		forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		request.setAttribute("selectedTab", selectedTab);
		
		//set proxy rfc generated flag
		manageProxyProcess.setproxyChangeGeneratedFlag(tiRequestId);
		//check the proxy rfc generated flag
		String proxygnerateflag = manageProxyProcess.isProxyChangeCompleted(tiRequestId);
		request.getSession().setAttribute("isProxyChangeComplete", proxygnerateflag);
		String outputFormatFlag = manageProxyProcess.isPafGenerated(tiRequestId);
		request.getSession().setAttribute("outputFormatFlag", outputFormatFlag);
		}
		catch(Exception e){
			log.error(e,e);
			forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);	
		}
		log.info("ManageProxyController.addProxyFilter() :: Ends...");
		return forwardTo;
	}


	private boolean isValidData(String data) {
		if (data != null && data.trim().equals("")) {
			return false;
		}
		return true;
	}

	private boolean portCheck(String port) {
		if(port.indexOf("-")!=-1){
			String frmPort = port.substring(0,port.indexOf("-"));
			String toPort =  port.substring(port.indexOf("-")+1);
			log.debug("ManageProxyController.portCheck:frmPort:"+frmPort+"toPort:"+toPort);
			for (int i = 0; i < frmPort.length(); i++) {
				if (!(frmPort.charAt(i) >= '0' && frmPort.charAt(i) <= '9')) {
					return false;
				}
			}
			for (int i = 0; i < toPort.length(); i++) {
				if (!(frmPort.charAt(i) >= '0' && toPort.charAt(i) <= '9')) {
					return false;
				}
			}
			return true;
		}else{
			for (int i = 0; i < port.length(); i++) {
				if (!(port.charAt(i) >= '0' && port.charAt(i) <= '9')) {
					return false;
				}
			}
			return true;
		}
	}
	
	@RequestMapping(value="/exportXlsFile.act",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	private ResponseEntity<String> exportXlsFile(HttpServletResponse response,@RequestParam String fileName){
		log.info("Entering exportXlsFile method:: ");
		try{
			String filePath =System.getProperty("application-log-path")+fileName;
			log.info("filePath :::"+filePath);
			File xls = new File(filePath); 
			FileInputStream in = new FileInputStream(xls);
			OutputStream out = response.getOutputStream();
			response.setHeader("Content-disposition","attachment; filename=" + fileName);
			byte[] buffer= new byte[8192]; 
			int length = 0;
			while ((length = in.read(buffer)) > 0){
			     out.write(buffer, 0, length);
			}
			in.close();
			out.close();
			log.info("Exiting exportXlsFile method:: ");
		}catch(Exception e){
			log.error("Error has occurred in exportXlsFile method:: "+e.toString());
		}
		
		return null;
	}
	

	@RequestMapping(value = "/uploadProxyFilterExcelAll.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String uploadProxyFilterExcel(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,BindingResult result, HttpServletRequest request){
		log.info("ManageProxyController.uploadProxyFilterExcel()::Starts");
		String forwardTo = "c3par.manageProxy";
		String selectedTab = request.getParameter("tab");
		log.info("selectedTab:: " + selectedTab);
		try {
			ProxyProcess proxyProcess = new ProxyProcess();
			Long processId=null;
			if(manageProxyProcess.getOriginalConnectionRequestId()!=null){
				processId = manageProxyProcess.getOriginalConnectionRequestId();
			}else if(request.getSession().getAttribute("TI_REQUEST_ENTITY")!=null){
				processId=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getTiProcess().getId();
			}
			manageProxyProcess.setNoOfRecords(noOfRecords);
			log.info("processId===" + processId);
			String tiReq = (String) request.getSession()
					.getAttribute("tireqid");
			log.info("tiReq from SESSION===" + tiReq);
			Long tiRequestId = Long.valueOf(0);
			if (tiReq != null) {
				try {
					tiRequestId = Long.valueOf(tiReq);
				} catch (Exception e) {
					tiRequestId = Long.valueOf(0);
				}
			}
			log.info("tiRequestId===" + tiRequestId);
			proxyProcess = manageProxyProcess.getProxyProcess(processId
					.longValue());
			ProxyFilter proxyFilter = manageProxyProcess.getProxyFilter();
			ProxyInstance proxyInstance = (ProxyInstance) proxyFilter
					.getProxyInstance();
			if (selectedTab != null && selectedTab.equals("managePacFile")) {
				manageProxyProcess.getProxyFilter().getProxyInstance().setName(manageProxyProcess.getProxyPACInstance().getName());
			}
			log.info("proxyInstance:: " + proxyInstance);
			TIProcess tiProcess = manageProxyProcess.getTIProcess(tiRequestId
					.longValue());
			log.info("tiProcess:: " + tiProcess);
			TIRequest tiRequest = manageProxyProcess.getTIRequest(tiRequestId
					.longValue());
			log.info("tiRequest:: " + tiRequest);
			CommonsMultipartFile file = manageProxyProcess.getUsersUploadExcelFormFile();
			log.info("file::: " + file);
			if (file == null 
					// || file.getFileData().length == 0
					|| file.equals("")) {
				request.setAttribute("err_log",
						"File Not Found.Pls Upload Excel File. ");
			}  else {
				List getProxyFilterReadDataList = (ArrayList) readExcelProxyFilterFile(
						file, tiProcess, tiRequest, proxyInstance, selectedTab);
				log.info("Size of getProxyFilterReadDataList::: "
						+ getProxyFilterReadDataList.size());
				List storedProxyFilterList =new ArrayList();
				String failureStatusMessage = "successMessage";
				storedProxyFilterList = (ArrayList) storeProxyFilterRecords(
						getProxyFilterReadDataList, manageProxyProcess, selectedTab);
				log.info("Size of Stored Proxy List::: "
						+ storedProxyFilterList.size());
				writeExcelProxyFilter(storedProxyFilterList, tiReq, selectedTab);
				if (getProxyFilterReadDataList == null || getProxyFilterReadDataList.size()==0)
				{
					failureStatusMessage = "norecords";
				}
				String filePath = null;
				File fileExist = null;
				String file_status = "false";
				if (!"uploadFailed".equals(failureStatusMessage)) {
					for (int i = 0; i < storedProxyFilterList.size(); i++) {
						ProxyFilter proxyFilterStatus = (ProxyFilter) storedProxyFilterList
								.get(i);
						if (!proxyFilterStatus.getStatus().equals("Success")) {
							failureStatusMessage = "failureMessage";
							break;
						}

					}
				}

				if (selectedTab != null && selectedTab.equals("manageProxy")) {
					//filePath = props.getString("XLS_FILE_WRITE_PROXY_FILTER_PATH")+ tiReq + "_proxy.xls";
					filePath=System.getProperty("application-log-path")+ tiReq + "_proxy.xls";
					
					fileExist = new File(filePath);
					if (fileExist == null || !fileExist.exists()
							|| fileExist.equals("")) {
						request.setAttribute("file_status", "false");
					} else {
						log.info("File Exists");
						request.setAttribute("file_status", "true");
					}
					request.setAttribute("fileStoredPath", tiReq+ "_proxy.xls");
					forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
				}
				if (selectedTab != null && selectedTab.equals("managePacFile")) {
					//filePath = props.getString("XLS_FILE_WRITE_PROXY_FILTER_PATH")+ tiReq + "_pac.xls";
					filePath=System.getProperty("application-log-path")+ tiReq + "_pac.xls";
					fileExist = new File(filePath);
					if (fileExist == null || !fileExist.exists()
							|| fileExist.equals("")) {
						request.setAttribute("file_status", "false");
					} else {
						log.info("File Exists");
						request.setAttribute("file_status", "true");
					}
					request.setAttribute("fileStoredPath", tiReq + "_pac.xls");
					forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
				}
				if (selectedTab != null && selectedTab.equals("manageSocks")) {
					//filePath = props.getString("XLS_FILE_WRITE_PROXY_FILTER_PATH")+ tiReq + "_socks.xls";
					filePath=System.getProperty("application-log-path")+ tiReq + "_socks.xls";
					fileExist = new File(filePath);
					if (fileExist == null || !fileExist.exists()
							|| fileExist.equals("")) {
						request.setAttribute("file_status", "false");
					} else {
						log.info("File Exists");
						request.setAttribute("file_status", "true");
					}
					request.setAttribute("fileStoredPath", tiReq + "_socks.xls");
					
				}
				if (selectedTab != null && selectedTab.equals("managePlug")) {
					//filePath = props.getString("XLS_FILE_WRITE_PROXY_FILTER_PATH")+ tiReq + "_plug.xls";
					filePath=System.getProperty("application-log-path")+ tiReq + "_plug.xls";
					fileExist = new File(filePath);
					if (fileExist == null || !fileExist.exists()
							|| fileExist.equals("")) {
						request.setAttribute("file_status", "false");
					} else {
						log.info("File Exists");
						request.setAttribute("file_status", "true");
					}
					request.setAttribute("fileStoredPath", tiReq + "_plug.xls");
					forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
				}
				if (failureStatusMessage.equals("successMessage")) {
					request
					.setAttribute(
							"success_log",
							"Upload Completed.Template data uploaded successfully. Download template and check.");
				} else if (failureStatusMessage.equals("failureMessage")) {
					request
					.setAttribute("success_log",
							"Upload Completed. Download the template and check for errors.");
				}
				else if (failureStatusMessage.equals("uploadFailed")) {
					request
					.setAttribute("error_log",
							"Upload Failed. Download the template and check for errors.");
				}else if (failureStatusMessage.equals("norecords")) {
					request
					.setAttribute("error_log",
							"No rows found to upload. Please check the template if application type is provided.");
				}
			}
			
				forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		} catch (Exception ex) {
			log.info("Exception occurred");
			result.addError(new ObjectError("dom","Please enter data for eithier Fully Qualified Domain Name or Application Url."));
			/*throw new BusinessException(
					"Error ocurred while uploading the Excel");*/
			forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		}
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.info("ManageProxyController.uploadProxyFilterExcel()::Ends");
		return forwardTo;
	}


	private List readExcelProxyFilterFile(CommonsMultipartFile file, TIProcess tiProcess,
			TIRequest tiRequest, ProxyInstance proxyInstance, String selectedTab)
					throws IOException {
		log
		.info("ManageProxyController.uploadProxyFilterExcel().readExcelProxyFilterFile() :: Starts");
		List readDataProxyFilterList = new ArrayList();
		try {
			POIExcelReaderProxy objPOIExcelReader = new POIExcelReaderProxy();
			POIFSFileSystem fileSystem = null;
			fileSystem = new POIFSFileSystem(file.getInputStream());
			HSSFWorkbook workBook = new HSSFWorkbook(fileSystem);
			ArrayList resultList = (ArrayList) objPOIExcelReader.parseSheet(
					workBook, workBook.getSheetName(0));
			String statusMessage="";
			if (resultList != null) {
				log.info("resultList.size():: " + resultList.size());
				for (int i = 0; i < resultList.size(); i++) {
					ProxyFilter proxyFilter = new ProxyFilter();
					List dataList = new ArrayList();
					dataList = (ArrayList) resultList.get(i);
					proxyFilter.setProxyInstance(proxyInstance);
					if (selectedTab != null
							&& selectedTab.equals("manageProxy")) {
						proxyFilter.setUrl((String) dataList.get(0));
						proxyFilter.setAction((String) dataList.get(1));
					} else if (selectedTab != null
							&& selectedTab.equals("managePacFile")) {
						proxyFilter.setStatement((String) dataList.get(0));
						proxyFilter.setStatementRedirect((String) dataList
								.get(1));
						proxyFilter.setDomainName((String) dataList.get(2));
						proxyFilter.setAction((String) dataList.get(3));
					}
					else if (selectedTab.equals("manageSocks")) {
						String isSrcFQDN=(String) dataList.get(0);
						proxyFilter.setIsSrcFQDN("Yes".equalsIgnoreCase(isSrcFQDN)?"Y":"N");
						String sourceIp=(String) dataList.get(1);
						proxyFilter.setSourceIp( sourceIp);
						String isDesFQDN=(String) dataList.get(2);
						proxyFilter.setIsDesFQDN("Yes".equalsIgnoreCase(isDesFQDN)?"Y":"N");
						String externalIp =(String) dataList.get(3);
						proxyFilter.setExternalIp(externalIp );
						String proxyFilterPort=(String) dataList.get(5);
						String protocol=(String) dataList.get(4);
						if(proxyFilterPort != null){
							try {
								Double d = Double.valueOf(proxyFilterPort);
								proxyFilterPort = (String.valueOf((long)d.longValue()));
							} catch (Exception e) {

								log.error("Error with proxyFilterPort");
							}
						}
						if(protocol == null)
							protocol=" ";
						if(proxyFilterPort == null)
							proxyFilterPort=" ";
						String tempPortValue = protocol + "/"
								+ proxyFilterPort;
						proxyFilter.setPort(tempPortValue);
						String isFTReqd = (String) dataList.get(6);
						String dataFrequency = ((String) dataList.get(7));
						String dataSize=(String) dataList.get(8);
						proxyFilter.setIsFTReqd("Yes".equalsIgnoreCase(isFTReqd)?"Y":"N");
						if ( isFTReqd != null && isFTReqd.equalsIgnoreCase("Yes")) {
							if (dataFrequency != null
									) {
								log.debug("File Transfer Data Frequency ::"
										+ dataFrequency);
								proxyFilter.setFrequency(util.getLookupIdByValueAndType(dataFrequency,LookupNameHelper.DATA_FREQUENCY));
							} 

							if (dataSize != null
									) {
								log.debug("File Transfer Data Size  ::"
										+ dataSize);
								proxyFilter.setFileSize(util.getLookupIdByValueAndType(dataSize,LookupNameHelper.DATA_SIZE));
							}
						} else {
							proxyFilter.setFrequency(null);
							proxyFilter.setFileSize(null);
						}
						String action =(String) dataList.get(9);
						proxyFilter.setAction(action);
						if(sourceIp == null || "".equals(sourceIp.trim())){
							statusMessage="Please provide Source IP.";
						} else if( isSrcFQDN != null && "No".equalsIgnoreCase(isSrcFQDN.trim()) && !checkIp(sourceIp)){
							statusMessage="Please provide valid Source IP.";
						} else if(externalIp == null || "".equals(externalIp.trim())){
							statusMessage="Please provide External IP.";
						} else if( isDesFQDN != null && "No".equalsIgnoreCase(isDesFQDN.trim()) && !checkIp(externalIp)){
							statusMessage="Please provide valid External IP.";
						} else if(protocol == null || "".equals(protocol.trim())){
							statusMessage="Please provide Protocol data.";
						} else if(proxyFilterPort == null || "".equals(proxyFilterPort.trim())){
							statusMessage="Please provide Port data.";
						}else if(isFTReqd == null || "".equals(isFTReqd.trim())){
							statusMessage="Please select File Transfer is Required or not. ";
						}else if(isFTReqd != null || "Yes".equalsIgnoreCase(isFTReqd.trim())){
							if(dataFrequency == null || "".equals(dataFrequency.trim())){
								statusMessage="Please select Data Frequency when File Transfer is Required. ";
							} else if(dataSize == null || "".equals(dataSize.trim())){
								statusMessage="Please select Data Size when File Transfer is Required. ";
							} 
						}else if(action == null || "".equals(action.trim())){
							statusMessage="Please select action ";
						}
					} else if (selectedTab.equals("managePlug")) {
						String isSrcFQDN=(String) dataList.get(1);
						proxyFilter.setIsSrcFQDN("Yes".equalsIgnoreCase(isSrcFQDN)?"Y":"N");
						String sourceIp=(String) dataList.get(2);
						proxyFilter.setSourceIp( sourceIp);
						String isDesFQDN=(String) dataList.get(3);
						proxyFilter.setIsDesFQDN("Yes".equalsIgnoreCase(isDesFQDN)?"Y":"N");
						String externalIp =(String) dataList.get(4);
						proxyFilter.setExternalIp(externalIp );
						String proxyFilterPort=(String) dataList.get(6);
						String protocol=(String) dataList.get(5);
						if(proxyFilterPort != null){
							try {
								Double d = Double.valueOf(proxyFilterPort);
								proxyFilterPort = (String.valueOf((long)d.longValue()));
							} catch (Exception e) {

								log.error("Error with proxyFilterPort");
							}
						}
						if(protocol == null)
							protocol=" ";
						if(proxyFilterPort == null)
							proxyFilterPort=" ";
						String tempPortValue = protocol + "/"
								+ proxyFilterPort;
						proxyFilter.setPort(tempPortValue);
						String requestType= (String) dataList.get(0);
						proxyFilter.setRequestType(requestType);
						String action =(String) dataList.get(7);
						proxyFilter.setAction(action);
						if(requestType == null || "".equals(requestType.trim())){
							statusMessage="Please select request type ";
						}
						if(sourceIp == null || "".equals(sourceIp.trim())){
							statusMessage="Please provide Source IP.";
						} else if( isSrcFQDN != null && "No".equalsIgnoreCase(isSrcFQDN.trim()) && !checkIp(sourceIp)){
							statusMessage="Please provide valid Source IP.";
						} else if(externalIp == null || "".equals(externalIp.trim())){
							statusMessage="Please provide External IP.";
						} else if( isDesFQDN != null && "No".equalsIgnoreCase(isDesFQDN.trim()) && !checkIp(externalIp)){
							statusMessage="Please provide valid External IP.";
						} else if(protocol == null || "".equals(protocol.trim())){
							statusMessage="Please provide Protocol data.";
						} else if(proxyFilterPort == null || "".equals(proxyFilterPort.trim())){
							statusMessage="Please provide Port data.";
						}else if(action == null || "".equals(action.trim())){
							statusMessage="Please select action";
						}

					} 
					proxyFilter.setStatus(statusMessage);
					proxyFilter.setTiProcess(tiProcess);
					proxyFilter.setTiRequest(tiRequest);
					// Added for Task 9219
					AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
					appsenseADGroup.setId(Long.valueOf(0));
					proxyFilter.setAppsenseADGroup(appsenseADGroup);
					readDataProxyFilterList.add(proxyFilter);
				}
				log
				.info("Size of readDataProxyFilterList after reading the Excel::: "
						+ readDataProxyFilterList.size());
			}
			log.info("Data read successfully.......");
		} catch (IOException ioEx) {
			log.error(ioEx, ioEx);
			throw new BusinessException(
					"Error occurred while reading from Excel");
		} catch (Exception ex) {
			log.error(ex, ex);
			throw new BusinessException(
					"Error occurred while reading from Excel");
		}
		log
		.info("ManageProxyController.uploadProxyFilterExcel().readExcelProxyFilterFile() :: Ends");
		return readDataProxyFilterList;
	}

	public static boolean checkIp(String sip) {
		if(sip==null | "".equals(sip))
			return false;
		String[] parts = sip.split("\\.");
		for (String s : parts) {
			if(s.contains("/")){
				String[] subnet = s.split("\\/");
				for(String sub : subnet){
					int j=0;
					try {
						j = Integer.parseInt(sub);
					} catch (NumberFormatException e) {
						return false;

					}
					if (j < 0 || j > 255) {
						return false;
					}
				}
			}
			else{

				int i = 0;
				try {
					i = Integer.parseInt(s);
				} catch (NumberFormatException e) {
					return false;

				}
				if (i < 0 || i > 255) {
					return false;
				}
			}
		}
		return true;
	}


	private void writeExcelProxyFilter(List proxyFilterWriteList, String tiReq,
			String selectedTab) throws Exception {
		log
		.info("ManageProxyController.uploadProxyFilterExcel().writeExcelProxyFilter() :: Starts");
		POIExcelWriter objPOIExcelWriter = new POIExcelWriter();
		//String filePath = props.getString("XLS_FILE_WRITE_PROXY_FILTER_PATH");
		String filePath=System.getProperty("application-log-path");
		String fileName = null;
		if (selectedTab != null && selectedTab.equals("manageProxy")) {
			fileName = tiReq + "_proxy" + ".xls";
		} else if (selectedTab != null && selectedTab.equals("managePacFile")) {
			fileName = tiReq + "_pac" + ".xls";
		}
		else if (selectedTab != null
				&& selectedTab.equals("manageSocks")) {
			fileName = tiReq + "_socks" + ".xls";
		} else if (selectedTab != null
				&& selectedTab.equals("managePlug")) {
			fileName = tiReq + "_plug" + ".xls";
		}
		filePath = filePath + fileName;
		log.info("filePath:: " + filePath);
		File file = new File(filePath);
		try {
			log.info("Size of Proxy Filter Write List::: "
					+ proxyFilterWriteList.size());
			HSSFWorkbook workBook = new HSSFWorkbook();
			HSSFSheet sheet = null;
			if (selectedTab != null && selectedTab.equals("manageProxy")){
				sheet = workBook.createSheet("proxy_filter");
			} else if (selectedTab != null
					&& selectedTab.equals("managePacFile")) {
				sheet = workBook.createSheet("pac_file");
			}else if (selectedTab != null
					&& selectedTab.equals("manageSocks")) {
				sheet = workBook.createSheet("socks");
			} else if (selectedTab != null
					&& selectedTab.equals("managePlug")) {
				sheet = workBook.createSheet("Plug");
			}
			objPOIExcelWriter.parseSheet(workBook, sheet, proxyFilterWriteList,
					selectedTab);
			FileOutputStream out = new FileOutputStream(file);
			workBook.write(out);
			out.close();
			log.info("Data has been written successfully");
		} catch (IOException ioEx) {
			log.error(ioEx, ioEx);
			throw new BusinessException(
					"Error occurred while writing the records in the Excel");
		} catch (Exception e) {
			log.error(e, e);
			throw new BusinessException(
					"Error occurred while writing the records in the Excel");
		}
		log
		.info("ManageProxyController.uploadProxyFilterExcel().writeExcelProxyFilter() :: Ends");
	}


	private List storeProxyFilterRecords(List storeRecordList,
			ManageProxyProcess manageProxyProcess, String selectedTab) {
		log
		.info("ManageProxyController.uploadProxyFilterExcel().storeProxyFilterRecords() :: Starts");
		List storedStatusList = new ArrayList();
		for (int i = 0; i < storeRecordList.size(); i++) {
			ProxyFilter proxyFilter = new ProxyFilter();
			proxyFilter = (ProxyFilter) storeRecordList.get(i);
			try {
				log.info("Trying to insert record in the database");
				if (selectedTab != null && selectedTab.equals("manageProxy")) {
					manageProxyProcess.storeProxyFilter(proxyFilter);
				} else if (selectedTab != null
						&& selectedTab.equals("managePacFile")) {
					manageProxyProcess.storeProxyPacFileFilter(proxyFilter);
				} else if ((selectedTab != null
						&& selectedTab.equals("manageSocks") )&& (proxyFilter.getStatus()==null || "".equals(proxyFilter.getStatus().trim()))) {
					manageProxyProcess.storeProxySocksFilter(proxyFilter);
				}else if ((selectedTab != null
						&& selectedTab.equals("managePlug") )&& (proxyFilter.getStatus()==null || "".equals(proxyFilter.getStatus().trim()))) {
					manageProxyProcess.storeProxyPlugFilter(proxyFilter);
				}
				log.info("Records inserted successfully");
				if ((proxyFilter.getStatus()==null || "".equals(proxyFilter.getStatus().trim()))) {
					proxyFilter.setStatus("Success");
				}
			} catch (Exception ex) {
				if (ex instanceof ApplicationException) {
					proxyFilter.setStatus("Failure :"+ ex.getMessage());
				}
			}


			storedStatusList.add(proxyFilter);
		}
		log.info("Size of storedStatusList:: " + storedStatusList.size());
		log
		.info("ManageProxyController.uploadProxyFilterExcel().storeProxyFilterRecords() :: Ends");
		return storedStatusList;

	}

	@RequestMapping(value = "/loadPrxInstanceName.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String loadPrxInstanceName(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		String forwardTo = null;
		String selectedTab = null;
		String regionName = null;
		GenericLookup lookup = new GenericLookup();
		log.info("ManageProxyController.loadProxyInstanceName()::Starts");
		selectedTab = request.getParameter("tab");
		regionName = request.getParameter("region");
		String recordType = request.getParameter("recordType");
		String selectRegion = manageProxyProcess.getProxyFilter()
				.getProxyInstance().getRegion();
		List proxyRegionList= (List) request.getSession().getAttribute("proxyRegionList");
		manageProxyProcess.setProxyRegionList(proxyRegionList);
		manageProxyProcess.setPrxDataFrequencyList((List) request.getSession().getAttribute("prxDataFrequencyList"));
		manageProxyProcess.setProxyProcess((ProxyProcess) request.getSession().getAttribute("proxyProcess")); 
		manageProxyProcess.setPrxDataSizeList((List) request.getSession().getAttribute("prxDataSizeList"));
		if (selectedTab.equals("managePacFile")
				|| selectedTab.equals("manageUrlAccess")) {
			Long lookUpId = null;
			if (selectedTab.equals("managePacFile")) {
				forwardTo = "c3par.managePacFile";
				manageProxyProcess.getProxyFilter().getProxyInstance()
				.setPortNumber(null);
				manageProxyProcess.getProxyFilter().setDomainName(null);
				manageProxyProcess.getProxyFilter().setStatement(null);
				manageProxyProcess.getProxyFilter().setStatementRedirect(null);
				lookUpId = util.getLookupId(LookupNameHelper.RIGHT_PLACEMENT);
			} else {
				forwardTo = "c3par.manageUrlAccess";
			}
			manageProxyProcess.getProxyFilter().setUrl(null);
			if (!(selectRegion == null
					|| (selectRegion != null && selectRegion.trim().equals("")) || (selectRegion != null && selectRegion
					.trim().equalsIgnoreCase("-- Select Region --")))) {
				List<LookUpVO> lookUpVOs = null;
				List<ProxyInstance> proxyInstanceList = null;
				if (selectedTab.equals("managePacFile")) {
					lookUpVOs = util.getProxyInstanceMasterName(
							recordType, regionName, lookUpId);
				}else{
					/*lookUpVOs = util.getProxyInstanceName("proxy",
							recordType, regionName, lookUpId);*/
					ArrayList<ProxyInstance> freeURLInsDtata = (ArrayList<ProxyInstance>) util.getFreeURLInstance(recordType, regionName);
					for (ProxyInstance proxyInstance : freeURLInsDtata) {
						log.debug("Inst desc : " +proxyInstance.getInstanceDesc());
					}
					
					if (freeURLInsDtata != null && freeURLInsDtata.size() > 0) {
						proxyInstanceList = new ArrayList<>();
						manageProxyProcess.setProxyInstanceList(new ArrayList<>());
						for(ProxyInstance proxyInstance : freeURLInsDtata) {
							manageProxyProcess.getProxyInstanceList().add(proxyInstance);
							manageProxyProcess.getProxyFilter().getProxyInstance().setName(proxyInstance.getInstanceName());
							manageProxyProcess.getProxyFilter().getProxyInstance().setInstanceDesc(proxyInstance.getInstanceDesc());
							proxyInstanceList.add(proxyInstance);
							log.debug("insName : " +manageProxyProcess.getProxyFilter().getProxyInstance().getInstanceDesc());
						}
					} /*else {
						errorMessage = "No Free URL data for particular Region";
						return forwardTo;
					}*/
				}

				if (lookUpVOs != null && !lookUpVOs.isEmpty()) {
				manageProxyProcess
				.setProxyInstanceList(lookUpVOs);
				} else {
					manageProxyProcess
					.setProxyInstanceList(proxyInstanceList);
				}
				manageProxyProcess
				.setProxyPACInstanceList(new ArrayList(0));
				request.getSession().setAttribute("freeUrlList", manageProxyProcess.getProxyInstanceList());
				request.getSession().setAttribute("proxyInstanceList", manageProxyProcess.getProxyInstanceList());
			}

		} else if (selectedTab.equals("manageSocks") || selectedTab.equals("managePlug")) {
			List socksInsData = util.getProxySocksInstance(recordType, regionName);
			if (selectedTab.equals("manageSocks")) {
				forwardTo = "c3par.manageProxySocks";
			} else {
				forwardTo = "c3par.manageProxySocks";
			}
			log.debug("socksData size" +socksInsData.size());
			if (socksInsData != null && socksInsData.size() > 0) {
				if (socksInsData.get(2) != null)
					lookup.setId(Long.valueOf(socksInsData.get(2).toString()));
				manageProxyProcess.getProxyFilter().getProxyInstance().setName((String) socksInsData.get(0));
				manageProxyProcess.getProxyFilter().getProxyInstance().setPortNumber((String) socksInsData.get(1));
				manageProxyProcess.getProxyFilter().getProxyInstance().setRightPlacement(lookup);
				manageProxyProcess.getProxyFilter().getProxyInstance().setRecordType((String) socksInsData.get(3));
				manageProxyProcess.getProxyFilter().getProxyInstance().setInstanceDesc((String) socksInsData.get(4));
				log.debug("insName : " +manageProxyProcess.getProxyFilter().getProxyInstance().getInstanceDesc());
			} else {
				errorMessage = "No Instance data for particular Region";
				return forwardTo;
			}
			log.debug("have to replace the load method");
		}
		forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.info("ManageProxyController.loadProxyInstanceName()::Ends");
		return forwardTo;
	}

	@RequestMapping(value = "/loadPACInstances.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String loadPACInstances(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		String forwardTo = "c3par.managePacFile";

		Long proxyId = null;
		String portNumber = "";
		Integer index = null;
		log.info("ManageProxyController.loadPrxPACPortNumber()::Starts");
		List proxyInstanceList = (List) request.getSession().getAttribute("proxyInstanceList");
		List proxyRegionList= (List) request.getSession().getAttribute("proxyRegionList");
		manageProxyProcess.setProxyInstanceList(proxyInstanceList);
		manageProxyProcess.setProxyRegionList(proxyRegionList);
		index = Integer.valueOf(request.getParameter("proxyId"));
		log.debug("list size" +proxyInstanceList.size());
		LookUpVO lookupVO = (LookUpVO) proxyInstanceList.get(index.intValue());
		proxyId = Long.valueOf(lookupVO.getValue());
		ProxyProcess prxProcess = new ProxyProcess();
		prxProcess.getProxyInstanceObject().setId(proxyId);
		List<ProxyInstance> PACInstances = manageProxyProcess.loadProxyPACInstances(prxProcess, 0);
		manageProxyProcess
		.setProxyPACInstanceList(PACInstances);
		request.getSession().setAttribute("proxyPACInstanceList", PACInstances);
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.debug("ManageProxyController.loadPrxPACPortNumber()::Port Number ---"
				+ portNumber);
		manageProxyProcess.setProxyProcess((ProxyProcess) request.getSession().getAttribute("proxyProcess"));
		forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.info("ManageProxyController.loadPrxPACPortNumber()::Ends");
		return forwardTo;
	}

	@RequestMapping(value = "/loadProxyFilter.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String loadProxyFilter(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		String forwardTo = null;
		String selectedTab = null;
		List<ProxyFilter> proxyFilterList = null;
		int index = -1;
		log.info("ManageProxyController.loadProxyFilter()::Starts");
		selectedTab = request.getParameter("tab");
		manageProxyProcess.setDataFrequency(Long.valueOf(0));
		manageProxyProcess.setDataSize(Long.valueOf(0));
		manageProxyProcess.setSelectAll("false");
		manageProxyProcess.setProxyProcess((ProxyProcess) request.getSession().getAttribute("proxyProcess"));
		int totalRecords = manageProxyProcess.getProxyProcess()
				.getTotalPrxFilters();
		log.info("Toatl PRX Filters"
				+ manageProxyProcess.getProxyProcess()
				.getTotalPrxFilters()
				+ "PRX FILTER Page Number "
				+ manageProxyProcess.getPageNo());
		noOfPages(manageProxyProcess, totalRecords, 1);
		if(selectedTab.equals("managePacFile")){
			proxyFilterList = (List) request.getSession().getAttribute("prxPacFileFilterLst");
		}else if(selectedTab.equals("manageSocks")){
			proxyFilterList = (List) request.getSession().getAttribute("prxSocksFilterLst");
		}else if(selectedTab.equals("managePlug")){
			proxyFilterList = (List) request.getSession().getAttribute("prxPlugFilterList");
		}else if(selectedTab.equals("manageUrlAccess")){
			proxyFilterList = (List) request.getSession().getAttribute("prxFreeUrlAccessList");
		}else if(selectedTab.equals("manageProxy")){
			proxyFilterList = (List) request.getSession().getAttribute("proxyFilterListManageProxy");
		}
		List proxyRegionList =(List)  request.getSession().getAttribute("proxyRegionList");
		manageProxyProcess.setProxyRegionList(proxyRegionList);
		manageProxyProcess.setProxyFilterList(proxyFilterList);
		String indexId = request.getParameter("indexId");
		log.info("ManageProxyController.loadProxyFilter()::Indexid::: " + indexId + "pf list" +proxyFilterList.size());
		if (proxyFilterList != null && proxyFilterList.size() > 0) {
			for (int i = 0; i < proxyFilterList.size(); i++) {
				ProxyFilter proxyFilter = (ProxyFilter) proxyFilterList.get(i);
				proxyFilter.setSelected(false);
			}
		}
		if ((indexId != null) && !indexId.equals("null")) {
			index = Integer.valueOf(indexId).intValue();
		}

		if (index >= 0) {

			ProxyFilter proxyFilter = (ProxyFilter) proxyFilterList.get(index);
			if (proxyFilter.getApplication() == null) {
				proxyFilter.setApplication(new Application());
			}
			manageProxyProcess.setProxyFilter(proxyFilter);
			if (selectedTab.equals("managePacFile")) {
				ProxyFilter origFilter = manageProxyProcess.loadProxyFilter(proxyFilter.getId());

				ProxyInstance instance = manageProxyProcess.getInstanceforPAC(origFilter.getProxyInstance().getId());
				ProxyInstance proxyPACInstance = manageProxyProcess.getProxyInstance(origFilter.getProxyInstance().getId());				
				if(instance == null){
					instance = proxyPACInstance;
				}
				if(instance != null){
					instance.setPortNumber(proxyPACInstance.getPortNumber());
				}
				manageProxyProcess.setProxyPACInstance(proxyPACInstance);
				manageProxyProcess.getProxyFilter().setProxyInstance(instance);
				forwardTo = "c3par.managePacFile";
			} else if (selectedTab.equals("manageSocks")) {
				forwardTo = "c3par.manageProxySocks";
				if (proxyFilter.getFrequency() != null) {
					manageProxyProcess
					.setDataFrequency(((GenericLookup) proxyFilter
							.getFrequency()).getId());
					manageProxyProcess.setPrxDataFrequencyList((List) request.getSession().getAttribute("prxDataFrequencyList"));
					
				}
				if (proxyFilter.getFileSize() != null) {
					manageProxyProcess
					.setDataSize(((GenericLookup) proxyFilter
							.getFileSize()).getId());
					manageProxyProcess.setPrxDataSizeList((List) request.getSession().getAttribute("prxDataSizeList"));
				}
				if (proxyFilter.getFrequency() != null
						|| proxyFilter.getFileSize() != null) {
					request.getSession().setAttribute("viewFrequency", "true");
				}
				log.debug("val" +manageProxyProcess.getDataFrequency() +manageProxyProcess.getDataSize());

			} else if (selectedTab.equals("managePlug")) {
				forwardTo = "c3par.manageProxySocks";
			} else if (selectedTab.equals("manageUrlAccess")) {
				forwardTo = "c3par.manageUrlAccess";
			} else if (selectedTab.equals("manageProxy")) {
				forwardTo = "c3par.manageProxy";
				request.getSession().setAttribute("viewSearch", "true");
				request.getSession().setAttribute("loadSearch", "false");
			}
			if (selectedTab.equals("manageSocks")
					|| selectedTab.equals("managePlug")) {
				if (proxyFilter.getPort() != null) {
					if (proxyFilter.getPort().indexOf("/") != -1) {
						StringTokenizer st = new StringTokenizer(proxyFilter
								.getPort(), "/");
						if (st.countTokens() > 0) {
							proxyFilter.setProtocol(st.nextToken());
							proxyFilter.setOriginalPort(st.nextToken());
						}
					} else {
						proxyFilter.setOriginalPort(proxyFilter.getPort());
					}
				}
			}
		}
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		request.getSession().setAttribute("selectedTab", selectedTab);
		request.getSession().setAttribute("viewFilter", "true");
		log.info("ManageProxyController.loadProxyFilter()::Ends");
		return forwardTo;
	}

	@RequestMapping(value = "/removeProxyFilterAll.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String removeProxyFilterAll(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,BindingResult result, HttpServletRequest request){
		String forwardTo = "load";
		List<ProxyFilter> proxyFilterList = null;
		log.info("ManageProxyController.removeProxyFilter() :: Starts...");
		String selectedTab = request.getParameter("tab");
		try{
		ProxyProcess proxyProcess = manageProxyProcess.getProxyProcess();
		proxyFilterList = manageProxyProcess.getProxyFilterList();
		proxyProcess.setProxyFilterList(proxyFilterList);
		if(!"showAll".equalsIgnoreCase(manageProxyProcess.getFilterSelection())){
			proxyProcess.setFilterEnabled(true);
		}
		boolean isSelectedAps = false;
		boolean isSelectedFlag = false;

		//if select All is checked then check whether all instances are navigated or //when individual instances are selected
		if((!manageProxyProcess.getProxyProcess().isSelectAll()) || (manageProxyProcess.getProxyProcess().isSelectAll() && (proxyProcess.getProxyFilterList().size() == proxyProcess.getTotalPrxFilters()))){
			for (int i = 0; i < proxyFilterList.size(); i++) {
				ProxyFilter proxyFilter = (ProxyFilter) proxyFilterList.get(i);
				if (proxyFilter.isSelected()) {
					log.debug("into select");
					isSelectedFlag = true;
				}
				log.debug("not select");
			}
		}
		//if select All is checked and not all the instances are loaded meant navigated
		else if(manageProxyProcess.getProxyProcess().isSelectAll() && (proxyProcess.getProxyFilterList().size() != proxyProcess.getTotalPrxFilters())){
			isSelectedFlag = true;
		}
		if (!isSelectedFlag) {

			if (selectedTab.equals("manageSocks")) {
				result.addError(new ObjectError("sock", "Please select one or more Socks from the list to delete"));
			} else if (selectedTab.equals("managePlug")) {
				result.addError(new ObjectError("plug", "Please select one or more Plug from the list to delete"));
			} else if (selectedTab.equals("managePacFile")) {
				result.addError(new ObjectError("pac", "Please select one or more PAC from the list to delete"));
			} else if (selectedTab.equals("manageProxy")) {
				result.addError(new ObjectError("pro", "Please select one or more Filter from the list to delete"));
			}else if (selectedTab.equals("manageUrlAccess")) {
				result.addError(new ObjectError("sock", "Please select one or more Filter from the list to delete"));
			}

		}
		if (selectedTab.equals("manageProxy")) {
			manageProxyProcess.deleteProxyFilter(proxyProcess);
			manageProxyProcess.setSelectAll("false");
			forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		} else if (selectedTab.equals("managePacFile")) {
			manageProxyProcess.deleteProxyPacFileFilter(proxyProcess);
			forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		} else if (selectedTab.equals("manageSocks")) {
			manageProxyProcess.deleteProxySocksFilter(proxyProcess);
			forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		} else if (selectedTab.equals("managePlug")) {
			manageProxyProcess.deleteProxyPlugFilter(proxyProcess);
			forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		} else if (selectedTab.equals("manageUrlAccess")) {
			manageProxyProcess.deleteProxyFreeUrlAccess(proxyProcess);
			forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		}
		manageProxyProcess.setProxyRegionList((List<Region>) request.getSession().getAttribute("proxyRegionList"));

		String tiReq = (String) request.getSession().getAttribute("tireqid");
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}
		log.info("tiRequestId===" + tiRequestId);
		
		//set proxy rfc generated flag
		manageProxyProcess.setproxyChangeGeneratedFlag(tiRequestId);
		//check the proxy rfc generated flag
		String proxygnerateflag = manageProxyProcess.isProxyChangeCompleted(tiRequestId);
		request.getSession().setAttribute("isProxyChangeComplete", proxygnerateflag);
		String outputFormatFlag = manageProxyProcess.isPafGenerated(tiRequestId);
		request.getSession().setAttribute("outputFormatFlag", outputFormatFlag);
		log.info("ManageProxyController.removeProxyFilter() :: Ends...");
		}
		catch(Exception e){
			log.error(e,e);
		}
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		return forwardTo;
	}

	@RequestMapping(value = "/loadProxyFilterListAll.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String loadProxyFilterListAll(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		String forwardTo = null;
		String selectedTab = null;
		int prxInsTotalRecords = 0;
		List<ProxyInstance> prxInsList = null;
		ProxyFilter proxyFilter = new ProxyFilter();
		try{
		log.info("ManageProxyController.loadProxyFilterList()::Starts");
		if(manageProxyProcess.getProxyFilter() != null){
			log.debug("dsf");
			proxyFilter = manageProxyProcess.getProxyFilter();
		}	
		else{
			log.debug("message");
		}
		selectedTab = request.getParameter("tab");
		if (selectedTab.equals("manageProxy")) {
		prxInsTotalRecords = manageProxyProcess.getProxyProcess()
				.getTotalPrxInstance();
		prxInsList = manageProxyProcess.getProxyProcess()
				.getProxyInstanceList();
		}
		ProxyProcess proxyProcess = manageProxyProcess.getProxyProcess();
		List<ProxyFilter> proxyFilterList = new ArrayList();
		Long processId=null;
		if(manageProxyProcess.getOriginalConnectionRequestId()!=null){
			processId = manageProxyProcess.getOriginalConnectionRequestId();
		}else if(request.getSession().getAttribute("TI_REQUEST_ENTITY")!=null){
			processId=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getTiProcess().getId();
		}
		log.info("loadProxyFilterList:processId===" + processId);
		ProxyFilter filterObject = new ProxyFilter();
		String filterSelection = manageProxyProcess.getFilterSelection();
		if ("yes".equalsIgnoreCase(request.getParameter("applyFilter"))) {
			log.debug("all");
			filterObject = manageProxyProcess.getFilterObject();
		}
		if(manageProxyProcess.getNoOfRecords()==0){
			manageProxyProcess.setNoOfRecords(noOfRecords);
		}
		if ("yes".equalsIgnoreCase(request.getParameter("applyFilter"))) {
			log.debug("al" +filterSelection +filterObject);
			manageProxyProcess.setFilterSelection(filterSelection);
			manageProxyProcess.setFilterObject(filterObject);
		}
		proxyProcess.setFilterObject(filterObject);
		if (selectedTab.equals("manageProxy")) {
			forwardTo = "c3par.manageProxy";
			proxyFilterList = manageProxyProcess.loadProxyFilters(proxyProcess,
					manageProxyProcess.getNoOfRecords());
			request.getSession().setAttribute("proxyFilterListManageProxy", proxyFilterList);
			log.info("Size of loadProxyFilterList--" + proxyFilterList.size());
			proxyProcess.setTotalPrxInstance(prxInsTotalRecords);
			proxyProcess.setProxyInstanceList(prxInsList);
			manageProxyProcess.setPrxInstanceList((List) request.getSession().getAttribute("proxyInstanceListForFilter"));
			long totalRecords = manageProxyProcess.getProxyProcess().getTotalPrxInstance();
			log.debug("sff" +manageProxyProcess.getPrxInsNoOfRecords() +proxyProcess.getTotalPrxInstance());
			long totalPages = totalRecords / manageProxyProcess.getPrxInsNoOfRecords();
			if (totalRecords % manageProxyProcess.getPrxInsNoOfRecords() > 0) {
				totalPages += 1;
				manageProxyProcess.setPrxInsTotalPages(totalPages);
			} else {
				manageProxyProcess.setPrxInsTotalPages(totalPages);
			}
			log.debug("page val" +totalRecords +totalPages +manageProxyProcess.getPrxInsTotalPages());
		} else if (selectedTab.equals("managePacFile")) {
			forwardTo = "c3par.managePacFile";
			proxyFilterList = manageProxyProcess.loadProxyPacFileFilters(
					proxyProcess, manageProxyProcess.getNoOfRecords());
			request.getSession().setAttribute("prxPacFileFilterLst", proxyFilterList);
			manageProxyProcess.setProxyInstanceList((List) request.getSession().getAttribute("proxyInstanceList"));
			manageProxyProcess.setProxyPACInstanceList((List) request.getSession().getAttribute("proxyPACInstanceList"));
			log.info("Size of loadProxyPacFilterList--"
					+ proxyFilterList.size());
		} else if (selectedTab.equals("manageSocks")) {
			forwardTo = "c3par.manageProxySocks";
			proxyFilterList = manageProxyProcess.loadProxySocksFilters(
					proxyProcess, manageProxyProcess.getNoOfRecords());
			request.getSession().setAttribute("prxSocksFilterLst", proxyFilterList);
			log.info("Size of proxySocksFilterList--" + proxyFilterList.size());
			manageProxyProcess.setDataFrequency(null);
			manageProxyProcess.setDataSize(null);
			manageProxyProcess.setPrxDataFrequencyList((List) request.getSession().getAttribute("prxDataFrequencyList"));
			manageProxyProcess.setPrxDataSizeList((List) request.getSession().getAttribute("prxDataSizeList"));
			request.getSession().removeAttribute("viewFrequency");
		} else if (selectedTab.equals("managePlug")) {
			forwardTo = "c3par.manageProxySocks";
			proxyFilterList = manageProxyProcess.loadProxyPlugFilters(
					proxyProcess, manageProxyProcess.getNoOfRecords());
			request.getSession().setAttribute("prxPlugFilterList", proxyFilterList);
			log.info("Size of proxyPlugFilterList--" + proxyFilterList.size());
		} else if (selectedTab.equals("manageUrlAccess")) {
			forwardTo = "c3par.manageUrlAccess";
			proxyFilterList = manageProxyProcess.loadProxyFreeUrlAccess(
					proxyProcess, manageProxyProcess.getNoOfRecords());
			manageProxyProcess.setProxyInstanceList((List) request.getSession().getAttribute("freeUrlList"));
			request.getSession().setAttribute("prxFreeUrlAccessList", proxyFilterList);
			log.info("Size of proxyUrlAccessFilterList--"
					+ proxyFilterList.size());
		}

		if (manageProxyProcess.getSelectAll() != null
				&& "true".equals(manageProxyProcess.getSelectAll())) {
			proxyProcess.setSelectAll(true);
			if (proxyFilterList != null && proxyFilterList.size() > 0) {
				for (int i = 0; i < proxyFilterList.size(); i++) {
					ProxyFilter proxyFilter1 = (ProxyFilter) proxyFilterList
							.get(i);
					log
					.info("ManageProxyController.loadProxyFilterList()::proxyProcess.selected  :::"
							+ proxyProcess.isSelectAll());
					if(!proxyFilter1.isAlreadyAccessed())
						proxyFilter1.setSelected(proxyProcess.isSelectAll());
				}
			}
		} else {
			proxyProcess.setSelectAll(false);
			manageProxyProcess.setSelectAll("false");
		}
		if (proxyFilterList != null && proxyFilterList.size() > 0) {
			for (int i = 0; i < proxyFilterList.size(); i++) {
				ProxyFilter proxyFilter1 = (ProxyFilter) proxyFilterList.get(i);
				if (proxyFilter1.getApplication() == null) {
					proxyFilter1.setApplication(new Application());
				}
			}
		}

		long totalRecords = proxyProcess.getTotalPrxFilters();
		noOfPages(manageProxyProcess, totalRecords, 1);
		proxyFilter.setApplication(new Application());
		manageProxyProcess.setProxyFilter(proxyFilter);
		manageProxyProcess.setProxyFilterList(proxyFilterList);
		manageProxyProcess.setProxyProcess(proxyProcess);
		request.getSession().setAttribute("viewFilter", "false");
		
		manageProxyProcess.setProxyRegionList((List<Region>) request.getSession().getAttribute("proxyRegionList"));
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		}
		catch(Exception e){
			log.error(e , e);
		}
		log.info("ManageProxyController.loadProxyFilterList()::Ends");
		return forwardTo;
	}

	@RequestMapping(value = "/resetCSIProxy.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String resetCSIProxy(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		String forwardTo = "load";
		log.info("ManageProxyController.resetCSI()::Starts");
		manageProxyProcess.getProxyFilter()
		.setApplication(new Application());
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.info("ManageProxyController.resetCSI()::Ends");
		return forwardTo;
	}

	@RequestMapping(value = "/addApplicationProxy.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String addApplicationProxy(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,BindingResult result, HttpServletRequest request){
		String forwardTo = "load";
		// String indexId = null;
		boolean isSelectedFlag = false;
		log.info("ManageProxyController.addApplication()::Starts");
		try{
		ProxyProcess proxyProcess = manageProxyProcess.getProxyProcess();
		log.debug("prp value" +proxyProcess);
		//log.debug("prp fil value" +proxyProcess.isFilterEnabled());
		Application application = manageProxyProcess.getProxyFilter()
				.getApplication();
		if(!"showAll".equalsIgnoreCase(manageProxyProcess.getFilterSelection())){
			proxyProcess.setFilterEnabled(true);    
		}
		String selectedTab = request.getParameter("tab");
		if (selectedTab != null) {
			if (selectedTab.equals("managePacFile")) {
				forwardTo = "c3par.managePacFile";
			} else if (selectedTab.equals("manageSocks")) {
				forwardTo = "c3par.manageProxySocks";
			} else if (selectedTab.equals("managePlug")) {
				forwardTo = "c3par.manageProxySocks";
			} else {
				forwardTo = "c3par.manageProxy";
			}
		}
		List proxyFilterList = manageProxyProcess.getProxyFilterList();
		proxyProcess.setProxyFilterList(manageProxyProcess.getProxyFilterList());
		//if select All is checked then check whether all instances are navigated or //when individual instances are selected
		if((!manageProxyProcess.getProxyProcess().isSelectAll()) || (manageProxyProcess.getProxyProcess().isSelectAll() && (proxyProcess.getProxyFilterList().size() == proxyProcess.getTotalPrxFilters()))){
			for (int i = 0; i < proxyFilterList.size(); i++) {
				ProxyFilter proxyFilter = (ProxyFilter) proxyFilterList.get(i);
				if (proxyFilter.isSelected()) {
					isSelectedFlag = true;
				}
			}
		}
		//if select All is checked and not all the instances are loaded meant navigated
		else if(manageProxyProcess.getProxyProcess().isSelectAll() && (proxyProcess.getProxyFilterList().size() != proxyProcess.getTotalPrxFilters())){
			isSelectedFlag = true;
		}
		if (!isSelectedFlag) {
			manageProxyProcess.getProxyFilter().getApplication()
			.setIsCSI("");
			if (selectedTab.equals("manageSocks")) {
				result.addError(new ObjectError("sock", "Please select one or more Socks from the list to add Application."));
			} else if (selectedTab.equals("managePlug")) {
				result.addError(new ObjectError("plug", "Please select one or more Plug from the list to add Application."));
			} else if (selectedTab.equals("managePacFile")) {
				result.addError(new ObjectError("pac", "Please select one or more PAC from the list to add Application."));
			} else if (selectedTab.equals("manageProxy")) {
				result.addError(new ObjectError("filter", "Please select one or more Filter from the list to add Application."));
			}

		}
		application = manageProxyProcess.storeApplication(application);
		log.debug("applio id" +application.getId());
		if (application != null) {
			if (selectedTab.equals("manageSocks")) {
				manageProxyProcess.updateProxySocksFilter(proxyProcess,
						application);
			} else if (selectedTab.equals("managePlug")) {
				manageProxyProcess.updateProxyPlugFilter(proxyProcess,
						application);
			} else if (selectedTab.equals("managePacFile")) {
				manageProxyProcess.updateProxyPacFileFilter(proxyProcess,
						application);
			} else if (selectedTab.equals("manageProxy")) {
				manageProxyProcess.updateProxyFilter(proxyProcess, application);
			}
		}
		manageProxyProcess.getProxyProcess().setSelectAll(false);
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}
		log.info("tiRequestId===" + tiRequestId);
		manageProxyProcess.setproxyChangeGeneratedFlag(tiRequestId);
		//check the proxy rfc generated flag
		String proxygnerateflag = manageProxyProcess.isProxyChangeCompleted(tiRequestId);
		request.getSession().setAttribute("isProxyChangeComplete", proxygnerateflag);
		String outputFormatFlag = manageProxyProcess.isPafGenerated(tiRequestId);
		request.getSession().setAttribute("outputFormatFlag", outputFormatFlag);
		
		manageProxyProcess.setSelectAll("false");
		forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		}
		catch(Exception e){
			log.error(e,e);
		}
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.info("ManageProxyController.addApplication()::Ends");
		return forwardTo;

	}

	@RequestMapping(value = "/removeApplicationProxy.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String removeApplicationProxy(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,BindingResult result, HttpServletRequest request){
		String forwardTo = "load";
		// String indexId = null;
		boolean isSelectedFlag = false;
		log.info("ManageProxyController.removeApplication()::Starts");
		try{
		ProxyProcess proxyProcess = manageProxyProcess.getProxyProcess();
		if(!"showAll".equalsIgnoreCase(manageProxyProcess.getFilterSelection())){
			proxyProcess.setFilterEnabled(true);
		}
		String selectedTab = request.getParameter("tab");
		if (selectedTab != null) {
			if (selectedTab.equals("managePacFile")) {
				forwardTo = "c3par.managePacFile";
			} else if (selectedTab.equals("manageSocks")) {
				forwardTo = "c3par.manageProxySocks";
			} else if (selectedTab.equals("managePlug")) {
				forwardTo = "c3par.manageProxySocks";
			} else {
				forwardTo = "c3par.manageProxy";
			}
		}
		List proxyFilterList = manageProxyProcess.getProxyFilterList();
		proxyProcess.setProxyFilterList(manageProxyProcess.getProxyFilterList());
		//if select All is checked then check whether all instances are navigated or //when individual instances are selected
		if((!manageProxyProcess.getProxyProcess().isSelectAll()) || (manageProxyProcess.getProxyProcess().isSelectAll() && (proxyProcess.getProxyFilterList().size() == proxyProcess.getTotalPrxFilters()))){
			for (int i = 0; i < proxyFilterList.size(); i++) {
				ProxyFilter proxyFilter = (ProxyFilter) proxyFilterList.get(i);
				if (proxyFilter.isSelected()) {
					isSelectedFlag = true;
				}
			}
		}
		//if select All is checked and not all the instances are loaded meant navigated
		else if(manageProxyProcess.getProxyProcess().isSelectAll() && (proxyProcess.getProxyFilterList().size() != proxyProcess.getTotalPrxFilters())){
			isSelectedFlag = true;
		}

		if (!isSelectedFlag) {
			manageProxyProcess.getProxyFilter().getApplication()
			.setIsCSI("");
			if (selectedTab.equals("manageSocks")) {
				result.addError(new ObjectError("name", "Please select one or more Socks from the list to remove Application."));
			} else if (selectedTab.equals("managePlug")) {
				result.addError(new ObjectError("plug", "Please select one or more Plug from the list to remove Application."));
			} else if (selectedTab.equals("managePacFile")) {
				result.addError(new ObjectError("pac", "Please select one or more PAC from the list to remove Application."));
			} else if (selectedTab.equals("manageProxy")) {
				result.addError(new ObjectError("filter", "Please select one or more Filter from the list to remove Application."));
			}

		}
		if (selectedTab.equals("manageSocks")) {
			manageProxyProcess.updateProxySocksFilter(proxyProcess, null);
		} else if (selectedTab.equals("managePlug")) {
			manageProxyProcess.updateProxyPlugFilter(proxyProcess, null);
		} else if (selectedTab.equals("managePacFile")) {
			manageProxyProcess.updateProxyPacFileFilter(proxyProcess, null);
		} else if (selectedTab.equals("manageProxy")) {
			manageProxyProcess.updateProxyFilter(proxyProcess, null);
		}

		manageProxyProcess.getProxyProcess().setSelectAll(false);
		manageProxyProcess.setSelectAll("false");
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}
		log.info("tiRequestId===" + tiRequestId);
		manageProxyProcess.setproxyChangeGeneratedFlag(tiRequestId);
		//check the proxy rfc generated flag
		String proxygnerateflag = manageProxyProcess.isProxyChangeCompleted(tiRequestId);
		request.getSession().setAttribute("isProxyChangeComplete", proxygnerateflag);
		String outputFormatFlag = manageProxyProcess.isPafGenerated(tiRequestId);
		request.getSession().setAttribute("outputFormatFlag", outputFormatFlag);
		forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		}
		catch(Exception e){
			log.error(e,e);
		}
		log.info("ManageProxyController.removeApplication()::Ends");
		return forwardTo;

	}

	@RequestMapping(value = "/loadProxyReview.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String loadProxyReview(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		log.info("pAFProxyReviewAction.load()::Starts:action::");
		String forwardTo = "c3par.waitImgPAF.new";
		request.getSession().removeAttribute("PAFNoHeader");
		try{
		FAFReviewThread.getInstance().startThread(request);
		String action = (String) request.getSession().getAttribute("action");
		action = (String) request.getParameter("action");
		log.debug("action value" +action);
		Long tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());
		log.debug("ti req id" +tirequestId);
		if("loadNoHdr".equals(action)){
			forwardTo = "pages/proxy/waitImgPAF";
			request.getSession().setAttribute("PAFNoHeader", "TRUE");
		}
		Map implInfo=new HashMap();
		Long connectionId ;
		if(request.getParameter("processId")!=null){
			connectionId=Long.valueOf(request.getParameter("processId"));
			manageProxyProcess.setOriginalConnectionRequestId(connectionId);
		}else{
			connectionId=manageProxyProcess.getOriginalConnectionRequestId();
		}
		log.info("connectionId:: "+connectionId);
		if(connectionId != null){
			if(!"".equals(connectionId)){
				manageProxyProcess.setExtResConnectionID(null);
				Long originalConnectionRequestId = connectionId;
				manageProxyProcess.setOriginalConnectionRequestId(originalConnectionRequestId);
			}
		}
		TIRequest tiRequest = manageProxyProcess.getTIRequestDetails(tirequestId);
		Planning planning = manageProxyProcess.getPlanning();
		manageProxyProcess.setTiRequest(tiRequest);
		log.debug("rel data" +tiRequest.getTiProcess().getRelationship().getId());
		log.info("planningEntity ConnectionName");
		if (request.getSession().getAttribute("CONNECTION_REQUEST_ENTITY") != null) {
			planning = (Planning)request.getSession().getAttribute("CONNECTION_REQUEST_ENTITY");
		}
		manageProxyProcess.setBusinessDetails(util.getBusinessDetails(connectionId,planning,"paf"));
		log.info("Before calling the function for generation of PAF Review ");
		String retValue = "";
		String requestType = null;
		tiRequest = (TIRequest) request.getSession().getAttribute(
				"TI_REQUEST_ENTITY");
		if (tiRequest.getTiRequestType() != null
				&& tiRequest.getTiRequestType().getName() != null) {
			requestType = tiRequest.getTiRequestType().getName();
			log.debug(" Request Type :: " + requestType);
			// Delete PAF is generated for Termination phase
			if (requestType != null
					&& requestType.equalsIgnoreCase("Terminate")) {
				retValue = util.queueFAFRequest(connectionId,request.getHeader("SM_USER"), "terminatepaf", "Y");
				FAFReviewThread.getInstance().notifyThread();
			} else {
				retValue = util.queueFAFRequest(connectionId, request.getHeader("SM_USER"), "generatepaf", "Y");
				FAFReviewThread.getInstance().notifyThread();
			}
		}
		if(!"true".equals(retValue)){
			log.error(retValue);
			throw new ApplicationException("Error During Generation of PAF Review Page! Please contact System Administrator.");
		}
		log.info("Successfully completed the generation of PAF Review ");
		log.info("Execution of the Business information Details");
		
		tiRequest = (TIRequest) request.getSession().getAttribute(
    			"TI_REQUEST_ENTITY");
		
		String pafGenerated = manageProxyProcess.isPafGenerated(tirequestId);
		
		if (!"true".equalsIgnoreCase(pafGenerated)) {
	    	if (tiRequest.getTiRequestType() != null
	    			&& tiRequest.getTiRequestType().getName() != null) {
	    		requestType = tiRequest.getTiRequestType().getName();
	    		log.debug(" Request Type :: " + requestType);
	    		// Delete PAF is generated for Termination phase
	    		if (requestType != null
	    				&& requestType.equalsIgnoreCase("Terminate")) {
	    			/*retValue = util.queueFAFRequest(connectionId, request
	    					.getRemoteUser(), "terminatepaf", "Y");
	    			//FAFReviewThread.getInstance().notifyThread();
	    			util.generateTerminatePAF(connectionId);*/
	    			
	    		} else {
	    			retValue = util.queueFAFRequest(connectionId, request.getHeader("SM_USER"), "recalculatepaf", "Y");    			
	    			util.recalculatePAF(connectionId);
	    		}
	    	}
		}

		Long processId=manageProxyProcess.getOriginalConnectionRequestId();
		log.info("processId==="+processId);
		String tiReq = (String)request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION==="+tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}

		log.info("tiRequestId==="+tiRequestId);	

		manageProxyProcess.setBusinessDetails(util.getBusinessDetails(connectionId,planning,"paf"));
		manageProxyProcess.setFafqueueReqs(util.getQueuedFAFRequests());
		manageProxyProcess.setApplicationList(util.getProxyApplicationDetails(connectionId));
		Long versionID = manageProxyProcess.getBusinessDetails().getVersionId();
		if(versionID == null){
			versionID= Long.valueOf(0);
		}
		log.info("version id:::: "+versionID);
		String rationale = util.getRationaleByVersion(processId,versionID,"PAF");
		log.debug("rationale" +rationale);
		manageProxyProcess.setRationale(rationale);
		Map<String,String> sowAndCmp = util.getCMPAndSOWByVersion(processId,versionID,"PAF");
		manageProxyProcess.setCMPReview(sowAndCmp.get("CMP"));
		manageProxyProcess.setSOWReview(sowAndCmp.get("SOW"));
		//Added by Uma - Spl Instr Starts

		implInfo=util.getImplementationInfo(manageProxyProcess.getOriginalConnectionRequestId(),versionID, "paf");
		log.debug("Implemntation Info --- "+implInfo.size());
		if(implInfo.size()>0){
			manageProxyProcess.setPrxSplInstruction((String)implInfo.get("SPL_INSTR"));
			manageProxyProcess.setPrxCompletionDate((String)implInfo.get("COMPLETION_DATE"));
			manageProxyProcess.setPrxInfomanId((Long)implInfo.get("INFOMAN_ID"));
			manageProxyProcess.setChangeNo((String)implInfo.get("CHANGE_NUMBER"));
			log.info("Implementation info -- Special Instruction-- "+implInfo.get("SPL_INSTR"));
			log.info("Implementation info -- Completion Date-- "+implInfo.get("COMPLETION_DATE"));
			log.info("Implementation info -- Infoman Id-- "+implInfo.get("INFOMAN_ID"));
			log.info("Implementation info -- Change number -- "+implInfo.get("CHANGE_NUMBER"));
		}
		AppsenseADGroup appsenseADGroup = (AppsenseADGroup)util.getAppsenseADGroupName(processId,"PAF");
		if(appsenseADGroup != null){
			log.info("AD Group Name:: "+appsenseADGroup.getName() +" / Policy Id:: "+appsenseADGroup.getPolicyID()+"/"+"Policy Name::: "+appsenseADGroup.getPolicyName());
			manageProxyProcess.setAppsPolicyId(appsenseADGroup.getPolicyID());
			manageProxyProcess.setAppsPolicyName(appsenseADGroup.getPolicyName());
			manageProxyProcess.setAppsADGroupName(appsenseADGroup.getName());
		}
		request.setAttribute("current_versionID_paf", versionID);
		request.setAttribute("action", action);
		String outputFormatFlag = manageProxyProcess.isPafGenerated(tiRequestId);
		request.getSession().setAttribute("outputFormatFlag", outputFormatFlag);
		}
		catch(Exception e){
			log.error(e,e);
		}
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		
		log.info("pAFProxyReviewAction.load()::ends.forwardTo::"+forwardTo);
		return forwardTo;
	}

	@RequestMapping(value = "/calculatePAF.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String calculatePAF(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		log.info("pAFProxyReviewAction.calculate()::Starts");
		log.info("Calculate method is getting executed");
		String forwardTo = "c3par.pafProxyReview.new";
		String noHeader = null;
		log.debug("pAFProxyReviewAction.calculate()::PAFNoHeader::"+request.getSession().getAttribute("PAFNoHeader"));
		if(request.getSession().getAttribute("PAFNoHeader") != null && (noHeader = (String)request.getSession().getAttribute("PAFNoHeader")).equals("TRUE")){
			forwardTo = "pages/proxy/paf_proxy_review";
			request.getSession().removeAttribute("PAFNoHeader");
			request.setAttribute("action", "loadNoHdr");
		}
		else{
			request.setAttribute("action", "load");
		}
		String reviewStatus = (String)request.getSession().getAttribute("statusMode");
		Map implInfo=new HashMap();
		Long connectionId ;

		if(request.getParameter("processId")!=null){
			connectionId=Long.valueOf(request.getParameter("processId"));
			manageProxyProcess.setOriginalConnectionRequestId(connectionId);
		}else{
			connectionId=manageProxyProcess.getOriginalConnectionRequestId();
		}
		log.info("connectionId:: "+connectionId);
		if(connectionId != null){
			if(!"".equals(connectionId)){
				manageProxyProcess.setExtResConnectionID(null);
				Long originalConnectionRequestId = connectionId;
				manageProxyProcess.setOriginalConnectionRequestId(originalConnectionRequestId);
			}
		}
		//Long processId=connectionRequestForm.getConnectionId();
		Long processId = manageProxyProcess.getOriginalConnectionRequestId();
		log.info("processId==="+processId);
		String tiReq = (String)request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION==="+tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}
		TIRequest tiRequest = manageProxyProcess.getTIRequestDetails(tiRequestId);
		log.info("tiRequestId==="+tiRequestId);
		Planning planning = manageProxyProcess.getPlanning();
		Long versionID = 0L;
		if (request.getSession().getAttribute("CONNECTION_REQUEST_ENTITY") != null) {
			planning = (Planning)request.getSession().getAttribute("CONNECTION_REQUEST_ENTITY");
		}
    	Long planningId = manageProxyProcess.getPlanningId(tiRequestId);
		
		log.info("Controller :: loadReview :: tirequestId "+ tiRequestId.longValue() + " :: planningId :: " + planningId);

		planning = manageProxyProcess.getPlanningDetails(planningId);
		if(reviewStatus != null && !reviewStatus.isEmpty()){
		     versionID = manageProxyProcess.getBusinessDetails().getVersionId();
		}
		else{
			manageProxyProcess.setBusinessDetails(util.getBusinessDetails(connectionId,planning,"paf"));
			versionID = manageProxyProcess.getBusinessDetails().getVersionId();
		}
		manageProxyProcess.setApplicationList(util.getProxyApplicationDetails(connectionId));
		log.info("version Id before ::: "+versionID);
		if(manageProxyProcess != null && manageProxyProcess.getBusinessDetails().getVersionId() != null){
    	    versionID = manageProxyProcess.getBusinessDetails().getVersionId();
    	} else {
    	    versionID =  util.getLatestVersionIdForPAFReview(processId);
    	}
		if(reviewStatus != null && !reviewStatus.isEmpty()){
			
		if(reviewStatus.equals("ReviewPrevious") && versionID != null && versionID.longValue() > 1 ){
    	    //versionID = Long.valueOf(versionID.longValue() -1);
    	    
    	} else if( reviewStatus.equals("ReviewCurrent")){
    	    versionID = util.getLatestVersionIdForPAFReview(connectionId);
    	}
		manageProxyProcess.setBusinessDetails(util.getBusinessDetails1(connectionId,planning,"paf",reviewStatus,versionID));
		}
		
		log.info("version Id in calculate before ::: "+versionID);
		String rationale = util.getRationaleByVersion(processId,versionID,"PAF");
		manageProxyProcess.setRationale(rationale);
		if(versionID == null){
			versionID= Long.valueOf(0);
		}
		Map<String,String> sowAndCmp = util.getCMPAndSOWByVersion(processId,versionID,"PAF");
    	manageProxyProcess.setCMPReview(sowAndCmp.get("CMP"));
    	manageProxyProcess.setSOWReview(sowAndCmp.get("SOW"));
    	FAFRequest fafRequest = new FAFRequest();
		manageProxyProcess.setCurrBusJustfi(fafRequest.getOrigBusJustification(connectionId, versionID));
		//Added by Uma - Spl Instr - starts
		implInfo=util.getImplementationInfo(manageProxyProcess.getOriginalConnectionRequestId(),versionID, "paf");
		log.debug("Implemntation Info --- "+implInfo.size());
		if(implInfo.size()>0){
			manageProxyProcess.setPrxSplInstruction((String)implInfo.get("SPL_INSTR"));
			manageProxyProcess.setPrxCompletionDate((String)implInfo.get("COMPLETION_DATE"));
			manageProxyProcess.setPrxInfomanId((Long)implInfo.get("INFOMAN_ID"));
			manageProxyProcess.setChangeNo((String)implInfo.get("CHANGE_NUMBER"));
			log.info("Implementation info -- Special Instruction-- "+implInfo.get("SPL_INSTR"));
			log.info("Implementation info -- Completion Date-- "+implInfo.get("COMPLETION_DATE"));
			log.info("Implementation info -- Infoman Id-- "+implInfo.get("INFOMAN_ID"));
			log.info("Implementation info -- Change number -- "+implInfo.get("CHANGE_NUMBER"));
		}

		AppsenseADGroup appsenseADGroup = (AppsenseADGroup)util.getAppsenseADGroupName(processId,"PAF");
		if(appsenseADGroup != null){
			log.info("AD Group Name:: "+appsenseADGroup.getName() +" / Policy Id:: "+appsenseADGroup.getPolicyID()+"/"+"Policy Name::: "+appsenseADGroup.getPolicyName());
			manageProxyProcess.setAppsPolicyId(appsenseADGroup.getPolicyID());
			manageProxyProcess.setAppsPolicyName(appsenseADGroup.getPolicyName());
			manageProxyProcess.setAppsADGroupName(appsenseADGroup.getName());
		}
		request.setAttribute("current_versionID_paf", versionID);
		Long versionId=(Long)request.getAttribute("current_versionID_paf");
		request.setAttribute("processId", connectionId);
    	request.getSession().setAttribute("processId", connectionId);
		if(versionId==null)
		{
			versionId=Long.valueOf(0);
		}
		List proxyRecordData = util.getData_Proxy(manageProxyProcess.getOriginalConnectionRequestId(),versionId);
		request.setAttribute("proxyRecordData",proxyRecordData);

		String proxy_implementer = util.getCurrentProcess_status(manageProxyProcess.getOriginalConnectionRequestId(),versionId,ActivityData.ACTIVITY_PROXY_IMP);
		request.setAttribute("proxy_implementer",proxy_implementer);
		Long id = null;
		if(manageProxyProcess.getTiRequest() != null){
			id = manageProxyProcess.getTiRequest().getId();
		}else if(request.getSession().getAttribute("TI_REQUEST_ENTITY") != null){
			id=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getId();
		}
		if(id != null){
			request.setAttribute("highRiskFlagAppsense", util.isAppsenseHighRisk(id)==true?"Yes":"No");
			request.setAttribute("highRiskFlagProxy", util.isProxyHighRisk(id)==true?"Yes":"No");
		}else{
			request.setAttribute("highRiskFlagAppsense", "No");
			request.setAttribute("highRiskFlagProxy","No");
		}
		manageProxyProcess.setTiRequest(tiRequest);
		model.addAttribute("manageProxyProcess",manageProxyProcess);
		log.info("version Id in calculate after::: "+versionID);
		log.info("pAFProxyReviewAction.calculate()::ends:forwardTo::"+forwardTo);
		return forwardTo;
	}

	@RequestMapping(value = "/instanceNameRecords.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String instanceNameRecords(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		log.info("pAFProxyReviewAction.instanceNameRecords()::Starts");
		String forwardTo ="c3par.pafProxyReview.new";
		Long processId=manageProxyProcess.getOriginalConnectionRequestId();
		log.info("processId==="+processId);
		Long versionID = manageProxyProcess.getBusinessDetails().getVersionId();
		log.info("versionID:: "+versionID);
		if(versionID == null){
			versionID= Long.valueOf(0);
		}
		log.info("version id:::: "+versionID);
		String proxyType = (String)request.getParameter("type");
		log.info("proxyType::"+proxyType);
		if(proxyType != null && !proxyType.equalsIgnoreCase("")){
			List proxyTypeList = new ArrayList();
			String[] temp = proxyType.split(",");
			for (String element : temp) {
				log.info("temp:: "+element);
				proxyTypeList.add(element);
			}
			request.setAttribute("display", "instanceNameDisplay");
			manageProxyProcess.setProxyInstanceNameList(manageProxyProcess.getProxyInstanceName(processId, versionID,proxyTypeList));
		}
		request.setAttribute("current_versionID_paf", versionID);
		request.setAttribute("processId", processId);
		request.getSession().setAttribute("proxyInstanceNameList", manageProxyProcess.getProxyInstanceNameList());
		log.info("pAFProxyReviewAction.instanceNameRecords()::Ends");
		Long versionId=(Long)request.getAttribute("current_versionID_paf");
		if(versionId==null)
		{
			versionId=Long.valueOf(0);
		}
		List proxyRecordData = util.getData_Proxy(manageProxyProcess.getOriginalConnectionRequestId(),versionId);
		request.setAttribute("proxyRecordData",proxyRecordData);

		String proxy_implementer = util.getCurrentProcess_status(manageProxyProcess.getOriginalConnectionRequestId(),versionId,ActivityData.ACTIVITY_PROXY_IMP);
		request.setAttribute("proxy_implementer",proxy_implementer);
		Long id = null;
		if(manageProxyProcess.getTiRequest() != null){
			id = manageProxyProcess.getTiRequest().getId();
		}else if(request.getSession().getAttribute("TI_REQUEST_ENTITY") != null){
			id=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getId();
		}
		if(id != null){
			request.setAttribute("highRiskFlagAppsense", util.isAppsenseHighRisk(id)==true?"Yes":"No");
			request.setAttribute("highRiskFlagProxy", util.isProxyHighRisk(id)==true?"Yes":"No");
		}else{
			request.setAttribute("highRiskFlagAppsense", "No");
			request.setAttribute("highRiskFlagProxy","No");
		}
		request.getSession().setAttribute("processId", processId);
		forwardTo=calculatePAF(model, manageProxyProcess, request);
		
		model.addAttribute("manageProxyProcess", manageProxyProcess);
		return forwardTo;
	}

	@RequestMapping(value = "/fetchFilterCombination.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String fetchFilterCombination(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		log.info("pAFProxyReviewAction.fetchFilterCombination()::Starts");
		String forwardTo ="c3par.pafProxyReview.new";
		try{
		Long processId=manageProxyProcess.getOriginalConnectionRequestId();
		log.info("processId==="+processId);
		Long versionID = manageProxyProcess.getBusinessDetails().getVersionId();
		log.info("versionID:: "+versionID);
		if(versionID == null){
			versionID= Long.valueOf(0);
		}
		log.info("version id:::: "+versionID);
		String type = (String)request.getParameter("setValue");
		log.info("type:: "+type);
		String instanceNames = (String)request.getParameter("instValues");
		log.info("selected instanceNames::"+instanceNames);
		List proxyInstanceList = new ArrayList();
		String[] temp1 = instanceNames.split(",");
		for (String element : temp1) {
			log.info("temp1:: "+element);
			Long iDProxyList = Long.valueOf(element);
			proxyInstanceList.add(iDProxyList);
		}
		String combType = null;
		List proxyCombinationList = new ArrayList();
		if(type != null){
			if(type.equals("addFilters")){
				combType = "1";
				proxyCombinationList = manageProxyProcess.getProxyCombinationFilter(processId, versionID, combType, proxyInstanceList);
				manageProxyProcess.setProxyInstCombinatonList(proxyCombinationList);
				log.debug("sizeadd" +proxyCombinationList.size());
			}else if(type.equals("deleteFilters")){
				combType="3";
				proxyCombinationList = manageProxyProcess.getProxyCombinationFilter(processId, versionID, combType, proxyInstanceList);
				manageProxyProcess.setProxyInstCombinatonList(proxyCombinationList);
				log.debug("size" +proxyCombinationList.size());
			}
		}
		request.setAttribute("display", "instanceNameDisplay");
		request.setAttribute("displayFilter", "combinationFilter");
		request.setAttribute("current_versionID_paf", versionID);

		log.info("pAFProxyReviewAction.instanceNameRecords()::Ends");
		Long versionId=(Long)request.getAttribute("current_versionID_paf");
		if(versionId==null)
		{
			versionId=Long.valueOf(0);
		}
		List proxyRecordData = util.getData_Proxy(manageProxyProcess.getOriginalConnectionRequestId(),versionId);
		request.setAttribute("proxyRecordData",proxyRecordData);

		String proxy_implementer = util.getCurrentProcess_status(manageProxyProcess.getOriginalConnectionRequestId(),versionId,ActivityData.ACTIVITY_PROXY_IMP);
		request.setAttribute("proxy_implementer",proxy_implementer);
		Long id = null;
		if(manageProxyProcess.getTiRequest() != null){
			id = manageProxyProcess.getTiRequest().getId();
		}else if(request.getSession().getAttribute("TI_REQUEST_ENTITY") != null){
			id=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getId();
		}
		if(id != null){
			request.setAttribute("highRiskFlagAppsense", util.isAppsenseHighRisk(id)==true?"Yes":"No");
			request.setAttribute("highRiskFlagProxy", util.isProxyHighRisk(id)==true?"Yes":"No");
		}else{
			request.setAttribute("highRiskFlagAppsense", "No");
			request.setAttribute("highRiskFlagProxy", "No");
		}
		log.info("pAFProxyReviewAction.fetchFilterCombination()::Ends");
		forwardTo = calculatePAF(model, manageProxyProcess, request);
		manageProxyProcess.setProxyInstanceNameList((List<ProxyInstance>) request.getSession().getAttribute("proxyInstanceNameList"));
		}
		catch(Exception e){
			log.error(e,e);
			forwardTo = calculatePAF(model, manageProxyProcess, request);
			manageProxyProcess.setProxyInstanceNameList((List<ProxyInstance>) request.getSession().getAttribute("proxyInstanceNameList"));
		}
		log.debug("dsfdsfdsf" +manageProxyProcess.getProxyInstanceNameList().size());
		model.addAttribute("manageProxyProcess", manageProxyProcess);
		return forwardTo;
	}

	@RequestMapping(value = "/movePageProxy.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String movePage(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,BindingResult result,HttpServletRequest request){
		log.info("ManageProxyController.movePage:: Starts...");
		String forwardTo = null;
		String selectedTab = request.getParameter("tab");
		ProxyInstance proxyInstance = manageProxyProcess.getPrxInstance();
		long totalRecords = 1;
		long prxInsTotalRecords = 1;
		Long pageNumber = Long.valueOf(0);
		int pageNo = 0;
		int trec = 0;
		boolean flag = false;
		
		try{
		log.debug("get Number of Records  "
				+ manageProxyProcess.getNoOfRecords());
		String next = (String) request.getParameter("next");
		ProxyFilter filterObject = manageProxyProcess.getFilterObject();
		
		//manageProxyProcess.getProxyProcess().setFilterObject(filterObject);
		if (selectedTab != null) {
			request.getSession().setAttribute("selectedTab", selectedTab);

			if ("addPAC1".equals(selectedTab)) {
				manageProxyProcess.setProxyProcess((ProxyProcess) request.getSession().getAttribute("proxyProcess1"));
				return movePACInstanceList(model, manageProxyProcess,result, request);
			}
			if ("addPAC".equals(selectedTab)) {
				manageProxyProcess.setProxyProcess((ProxyProcess) request.getSession().getAttribute("proxyProcess1"));
				return moveProxyInstanceList(model, manageProxyProcess,result, request);
			}
			
			if (selectedTab.equals("prxInstance")) {
				pageNumber = Long.valueOf(manageProxyProcess.getPrxInsPageNo());
				prxInsTotalRecords = manageProxyProcess.getProxyProcess()
						.getTotalPrxInstance();
				trec = manageProxyProcess.getProxyProcess()
						.getTotalPrxInstance();
				log.info("Total PRX Instance"
						+ manageProxyProcess.getProxyProcess()
						.getTotalPrxInstance() + "PRx Ins Page Number "
						+ manageProxyProcess.getPrxInsPageNo());

			} else {
				
				pageNumber = Long.valueOf(manageProxyProcess.getPageNo());
				totalRecords = manageProxyProcess.getProxyProcess()
						.getTotalPrxFilters();
				log.info("Toatl PRX Filters"
						+ manageProxyProcess.getProxyProcess()
						.getTotalPrxFilters()
						+ "PRX FILTER Page Number "
						+ manageProxyProcess.getPageNo());
			}
			manageProxyProcess.setProxyProcess((ProxyProcess) request.getSession().getAttribute("proxyProcess"));
			pageNo = pageNumber.intValue();
			if (next.equals("true")) {
				pageNo = pageNo + 1;
			} else {
				pageNo = pageNo - 1;
				if (pageNo <= 0) {
					flag = true;
				}
			}
			if (selectedTab.equals("manageProxy")) {
				forwardTo = "c3par.manageProxy";
				if (!flag) {
					request.getSession().setAttribute("viewSearch", "false");
					List proxyFilterList = manageProxyProcess.loadProxyFilters(
							manageProxyProcess.getProxyProcess(), pageNo,
							manageProxyProcess.getNoOfRecords());
					log.info("proxyFilterList--->>>" + proxyFilterList.size());
					if (proxyFilterList != null && proxyFilterList.size() > 0)
						manageProxyProcess
						.setProxyFilterList(proxyFilterList);
					
				}
				manageProxyProcess.setPrxInstanceList((List) request.getSession().getAttribute("proxyInstanceListForFilter"));
			} else if (selectedTab.equals("managePacFile")) {
				forwardTo = "c3par.managePacFile";
				if (!flag) {
					List proxyPacFilterList = manageProxyProcess
							.loadProxyPacFileFilters(manageProxyProcess
									.getProxyProcess(), pageNo,
									manageProxyProcess.getNoOfRecords());
					log.info("proxy pac File FilterList--->>>"
							+ proxyPacFilterList.size());
					if (proxyPacFilterList != null
							&& proxyPacFilterList.size() > 0)
						manageProxyProcess
						.setProxyFilterList(proxyPacFilterList);
				}
			} else if (selectedTab.equals("manageSocks")) {
				forwardTo = "c3par.manageProxySocks";
				if (!flag) {
					List proxySocksFilterList = manageProxyProcess
							.loadProxySocksFilters(manageProxyProcess
									.getProxyProcess(), pageNo,
									manageProxyProcess.getNoOfRecords());
					log.info("proxy Socks FilterList--->>>"
							+ proxySocksFilterList.size());
					if (proxySocksFilterList != null
							&& proxySocksFilterList.size() > 0)
						manageProxyProcess
						.setProxyFilterList(proxySocksFilterList);
				}
			} else if (selectedTab.equals("managePlug")) {
				forwardTo = "c3par.manageProxySocks";
				if (!flag) {
					List proxyPlugFilterList = manageProxyProcess
							.loadProxyPlugFilters(manageProxyProcess
									.getProxyProcess(), pageNo,
									manageProxyProcess.getNoOfRecords());
					log.info("proxy Plug FilterList--->>>"
							+ proxyPlugFilterList.size());
					if (proxyPlugFilterList != null
							&& proxyPlugFilterList.size() > 0)
						manageProxyProcess
						.setProxyFilterList(proxyPlugFilterList);
				}
			} else if (selectedTab.equals("manageUrlAccess")) {
				forwardTo = "c3par.manageUrlAccess";
				if (!flag) {
					List proxyFreeUrlFilterList = manageProxyProcess
							.loadProxyFreeUrlAccess(manageProxyProcess
									.getProxyProcess(), pageNo,
									manageProxyProcess.getNoOfRecords());
					log.info("proxy URL Access FilterList--->>>"
							+ proxyFreeUrlFilterList.size());
					if (proxyFreeUrlFilterList != null
							&& proxyFreeUrlFilterList.size() > 0)
						manageProxyProcess
						.setProxyFilterList(proxyFreeUrlFilterList);
				}
			} else if (selectedTab.equals("prxInstance")) {
				forwardTo = "c3par.manageProxy";
				if (!flag) {
					List proxyInstanceList = manageProxyProcess
							.findProxyInstances(manageProxyProcess
									.getProxyProcess(),
									proxyInstance.getName(), proxyInstance
									.getPortNumber(), proxyInstance
									.getRegion(), "BASIC",
									pageNo, manageProxyProcess
									.getPrxInsNoOfRecords());
					log
					.info("ManageProxyController.movePage()::proxyInstanceList---"
							+ proxyInstanceList);
					if (proxyInstanceList != null
							&& proxyInstanceList.size() > 0)
						manageProxyProcess
						.setPrxInstanceList(proxyInstanceList);
					request.getSession().setAttribute("viewSearch", "false");
				}
			}
		}
		request.getSession().setAttribute("viewFilter", "false");
		request.getSession().removeAttribute("viewFrequency");
		if (!selectedTab.equals("prxInstance")) {
			if (next.equals("true")) {
				if ((manageProxyProcess.getProxyFilterList() != null)
						&& (manageProxyProcess.getProxyFilterList().size() > 0)) {
					if (manageProxyProcess.getProxyProcess().isSelectAll()) {
						for (int i = 0; i < manageProxyProcess
								.getProxyFilterList().size(); i++) {
							ProxyFilter proxyFilter = (ProxyFilter) manageProxyProcess
									.getProxyFilterList().get(i);
							if(!proxyFilter.isAlreadyAccessed()){
								proxyFilter.setSelected(manageProxyProcess
										.getProxyProcess().isSelectAll());
							}

						}
					}
				}
			} else {
				if (manageProxyProcess.getProxyProcess().isSelectAll()) {
					for (int i = 0; i < manageProxyProcess
							.getProxyFilterList().size(); i++) {
						ProxyFilter proxyFilter = (ProxyFilter) manageProxyProcess
								.getProxyFilterList().get(i);
						if(!proxyFilter.isAlreadyAccessed()){
							proxyFilter.setSelected(manageProxyProcess
									.getProxyProcess().isSelectAll());
						}
					}
				}
			}
		}
		if (selectedTab.equals("prxInstance")) {

			long totalPages = prxInsTotalRecords
					/ manageProxyProcess.getPrxInsNoOfRecords();
			if (prxInsTotalRecords
					% manageProxyProcess.getPrxInsNoOfRecords() > 0) {
				totalPages += 1;
				manageProxyProcess.setPrxInsTotalPages(totalPages);
			} else {
				manageProxyProcess.setPrxInsTotalPages(totalPages);
			}
			if (totalPages == 0) {
				manageProxyProcess.setPrxInsPageNo(0);
			} else {
				manageProxyProcess.setPrxInsPageNo(pageNo);
			}
			if (manageProxyProcess.getPrxInsPageNo() <= 0) {
				if (manageProxyProcess.getPrxInsPageNo() == 0
						&& manageProxyProcess.getPrxInsTotalPages() == 0)
					manageProxyProcess.setPrxInsPageNo(0);
				else if (manageProxyProcess.getPrxInsPageNo() == 0
						&& manageProxyProcess.getPrxInsTotalPages() > 0)
					manageProxyProcess.setPrxInsPageNo(1);
				result.addError(new ObjectError("page", "You are in the First Page"));
			} else if (manageProxyProcess.getPrxInsPageNo() > manageProxyProcess
					.getPrxInsTotalPages()) {
				manageProxyProcess.setPrxInsPageNo(manageProxyProcess
						.getPrxInsTotalPages());
				result.addError(new ObjectError("page", "You are in the Last Page"));
			}

		} else {
			noOfPages(manageProxyProcess, totalRecords, pageNo);
			if (!selectedTab.equals("manageProxy"))
				request.getSession().setAttribute("loadSearch", "false");
			if (manageProxyProcess.getPageNo() <= 0) {
				if (manageProxyProcess.getPageNo() == 0
						&& manageProxyProcess.getTotalPages() == 0)
					manageProxyProcess.setPageNo((long) 0);
				else if (manageProxyProcess.getPageNo() == 0
						&& manageProxyProcess.getTotalPages() > 0)
					manageProxyProcess.setPageNo((long) 1);
				result.addError(new ObjectError("page", "You are in the First Page"));
			} else if (manageProxyProcess.getPageNo() > manageProxyProcess
					.getTotalPages()) {
				manageProxyProcess.setPageNo(manageProxyProcess
						.getTotalPages());
				result.addError(new ObjectError("page", "You are in the Last Page"));
			}
		}
		manageProxyProcess.setProxyRegionList((List<Region>) request.getSession().getAttribute("proxyRegionList"));
		manageProxyProcess.getProxyProcess()
				.setTotalPrxInstance(trec);
		}
		catch(Exception e){
			log.error(e,e);
		}
		model.addAttribute("manageProxyProcess", manageProxyProcess);
		log.info("ManageProxyController.movePage:: End...");
		return forwardTo;
	}

	@RequestMapping(value = "/movePACInstanceList.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String movePACInstanceList(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess, BindingResult result, HttpServletRequest request){
		ProxyProcess proxyProcess = null;
		Long pageNumber = Long.valueOf(manageProxyProcess.getPACPageNo());
		String next = (String) request.getParameter("next");
		int pageNo = pageNumber.intValue();
		log.debug("page noc" +Long.valueOf(manageProxyProcess.getPageNo()));
		log.debug("page nocc" +Long.valueOf(manageProxyProcess.getTotalPages()));
		boolean flag = false;
		if (next.equals("true")) {
			pageNo = pageNo + 1;
			if (pageNo > manageProxyProcess
					.getTotalPACPages()) {
				flag = true;
			}
		} else {
			pageNo = pageNo - 1;
			if (pageNo <= 0) {
				flag = true;
			}
		}

		long totalRecords;
		if (pageNo <= 0) {
			if (pageNo == 0
					&& manageProxyProcess.getTotalPACPages() == 0)
				manageProxyProcess.setPACPageNo(0L);
			else if (pageNo == 0
					&& manageProxyProcess.getTotalPACPages() > 0)
				manageProxyProcess.setPACPageNo(1L);

		} else if (pageNo > manageProxyProcess
				.getTotalPACPages()) {
			manageProxyProcess.setPACPageNo( manageProxyProcess
					.getTotalPACPages());

		}
		if (!flag) {
			proxyProcess = new ProxyProcess();
			ProxyInstance proxyInstance = (ProxyInstance) manageProxyProcess
					.getPrxInstance();
			if (proxyInstance == null) {
				proxyInstance = new ProxyInstance();
			}
			proxyInstance.setId(manageProxyProcess
					.getSelectedProxyInstanceId());
			proxyProcess.setProxyInstanceObject(proxyInstance);
			List proxyPACInstanceList = manageProxyProcess.loadProxyPACInstances(
					proxyProcess, pageNo, manageProxyProcess
					.getNoOfPACRecords());
			if (proxyPACInstanceList == null) {
				proxyPACInstanceList = new ArrayList(0);
			}
			manageProxyProcess.setProxyPACInstanceList(proxyPACInstanceList);
			manageProxyProcess.setProxyProcess(proxyProcess);

		}else{
			proxyProcess = manageProxyProcess.getProxyProcess();
		}
		totalRecords = proxyProcess.getTotalPACPrxInstance();
		noOfPACPages(manageProxyProcess, totalRecords, pageNo);
		if (manageProxyProcess.getPACPageNo() <= 0) {
			if (manageProxyProcess.getPACPageNo() == 0
					&& manageProxyProcess.getTotalPACPages() == 0)
				manageProxyProcess.setPACPageNo(0L);
			else if (manageProxyProcess.getPACPageNo() == 0
					&& manageProxyProcess.getTotalPACPages() > 0)
				manageProxyProcess.setPACPageNo(1L);
			result.addError(new ObjectError("page", "You are in the First Page"));
		} else if (manageProxyProcess.getPACPageNo() > manageProxyProcess
				.getTotalPACPages()) {
			manageProxyProcess.setPACPageNo(manageProxyProcess
					.getTotalPACPages());
			result.addError(new ObjectError("page", "You are in the Last Page"));
		}
		return "c3par.addPacFile";
	}

	@RequestMapping(value = "/moveProxyInstanceList.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String moveProxyInstanceList(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,BindingResult result, HttpServletRequest request){
		ProxyProcess proxyProcess = null;
		if(manageProxyProcess
				.getPrxInstance() == null){
			manageProxyProcess.setPrxInstance(new ProxyInstance());
		}


		log.debug("page no" +Long.valueOf(manageProxyProcess.getPageNo()));
		log.debug("page nod" +Long.valueOf(manageProxyProcess.getTotalPages()));
		Long pageNumber = Long.valueOf(manageProxyProcess.getPageNo());
		String next = (String) request.getParameter("next");
		int pageNo = pageNumber.intValue();
		boolean flag = false;
		if (next.equals("true")) {
			pageNo = pageNo + 1;
			log.debug("into true");
			if (pageNo > manageProxyProcess
					.getTotalPages()) {
				flag = true;
			}
		} else {
			log.debug("into else");
			pageNo = pageNo - 1;
			if (pageNo <= 0) {
				flag = true;
			}
		}
		if (pageNo <= 0) {
			if (pageNo == 0
					&& manageProxyProcess.getTotalPages() == 0)
				manageProxyProcess.setPageNo(0L);
			else if (pageNo == 0
					&& manageProxyProcess.getTotalPages() > 0)
				manageProxyProcess.setPageNo((long) 1);

		} else if (pageNo > manageProxyProcess
				.getTotalPages()) {
			manageProxyProcess.setPageNo(manageProxyProcess
					.getTotalPages());

		}
		if (!flag) {
			proxyProcess = new ProxyProcess();
			proxyProcess.setProxyInstanceObject(manageProxyProcess
					.getPrxInstance());
			List proxyInstanceList = manageProxyProcess.loadProxyInstances(
					proxyProcess, pageNo, manageProxyProcess
					.getNoOfRecords());
			log.info("proxyInstanceList --->>" + proxyInstanceList.size());
			manageProxyProcess.setSelectedProxyInstanceId(0L);
			ProxyInstance proxyPACInstance = new ProxyInstance();
			manageProxyProcess.setProxyPACInstance(proxyPACInstance);
			List proxyPACInstanceList = new ArrayList(0);
			manageProxyProcess
			.setProxyPACInstanceList(proxyPACInstanceList);
			manageProxyProcess.setProxyInstanceList(proxyInstanceList);
			manageProxyProcess.setProxyProcess(proxyProcess);
		}else{
			proxyProcess = manageProxyProcess.getProxyProcess();
		}
		long totalRecords = proxyProcess.getTotalPrxInstance();
		noOfPages(manageProxyProcess, totalRecords, pageNo);
		totalRecords = proxyProcess.getTotalPACPrxInstance();
		noOfPACPages(manageProxyProcess, totalRecords, 1);
		if (manageProxyProcess.getPageNo() <= 0) {
			if (manageProxyProcess.getPageNo() == 0
					&& manageProxyProcess.getTotalPages() == 0)
				manageProxyProcess.setPageNo(0L);
			else if (manageProxyProcess.getPageNo() == 0
					&& manageProxyProcess.getTotalPages() > 0)
				manageProxyProcess.setPageNo((long) 1);
			result.addError(new ObjectError("page", "You are in the First Page"));
		} else if (manageProxyProcess.getPageNo() > manageProxyProcess
				.getTotalPages()) {
			manageProxyProcess.setPageNo(manageProxyProcess
					.getTotalPages());
			result.addError(new ObjectError("page", "You are in the First Page"));
		}
		manageProxyProcess.setProxyRegionList((List<Region>) request.getSession().getAttribute("proxyRegionList"));
		return "c3par.addPacFile";
	}

	@RequestMapping(value = "/loadPACPortNumber.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String loadPACPortNumber(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		String forwardTo = "c3par.managePacFile";
		Long proxyId = null;
		String portNumber = "";
		Integer index = null;
		GenericLookup lookup = new GenericLookup();
		log.info("ManageProxyController.loadPACPortNumber()::Starts");
		List proxyInstanceList1 = (List) request.getSession().getAttribute("proxyInstanceList");
		List proxyRegionList= (List) request.getSession().getAttribute("proxyRegionList");
		manageProxyProcess.setProxyInstanceList(proxyInstanceList1);
		manageProxyProcess.setProxyRegionList(proxyRegionList);
		manageProxyProcess.setProxyPACInstanceList((List) request.getSession().getAttribute("proxyPACInstanceList"));
		List proxyInstanceList = manageProxyProcess.getProxyPACInstanceList();
		index = Integer.valueOf(request.getParameter("proxyId"));
		ProxyInstance  proxyInstance = (ProxyInstance) proxyInstanceList.get(index.intValue());
		if (proxyInstance.getPortNumber() != null) {
			portNumber = proxyInstance.getPortNumber();
		}
		if (proxyInstance.getRightPlacement() != null) {

			manageProxyProcess.getProxyFilter().getProxyInstance()
			.setRightPlacement(proxyInstance.getRightPlacement());
		}
		manageProxyProcess.getProxyFilter().getProxyInstance()
		.setPortNumber(portNumber);
		manageProxyProcess.getProxyFilter().getProxyInstance()
		.setRecordType("PACFILE");
		log.debug("ManageProxyController.loadPACPortNumber()::Port Number ---"
				+ portNumber);
		manageProxyProcess.setProxyProcess((ProxyProcess) request.getSession().getAttribute("proxyProcess"));
		forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		log.info("ManageProxyController.loadPACPortNumber()::Ends");
		model.addAttribute("manageProxyProcess", manageProxyProcess);
		return forwardTo;
	}
	
	
	 @RequestMapping(value = "/recalculate.act", method = { RequestMethod.GET, RequestMethod.POST })
	    private String recalculate(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
	    	log.info("pAFProxyReviewAction.recalculate()::Starts");
	    	String forwardTo = "c3par.waitImgPAF.new";
	    	Map implInfo=new HashMap();
	    	Long connectionId ;
	    	FAFReviewThread.getInstance().startThread(request);
	    	if(request.getParameter("processId")!=null){
	    	    connectionId=Long.valueOf(request.getParameter("processId"));
	    	    manageProxyProcess.setOriginalConnectionRequestId(connectionId);
	    	}else{
	    	    connectionId=manageProxyProcess.getOriginalConnectionRequestId();
	    	}
	    	log.info("connectionId:: "+connectionId);
	    	if(connectionId != null){
	    	    if(!"".equals(connectionId)){
	    	    	manageProxyProcess.setExtResConnectionID(null);
	    		Long originalConnectionRequestId = connectionId;
	    		manageProxyProcess.setOriginalConnectionRequestId(originalConnectionRequestId);
	    	    }
	    	}
	    	Planning planning = manageProxyProcess.getPlanning();

	    	manageProxyProcess.setBusinessDetails(util.getBusinessDetails(connectionId,planning,"paf"));
	    	log.info("Before calling the function for generation of PAF Review ");
	    	String retValue = "";
	    	TIRequest tiRequest = null;
	    	String requestType = null;
	    	tiRequest = (TIRequest) request.getSession().getAttribute(
	    			"TI_REQUEST_ENTITY");
	    	if (tiRequest.getTiRequestType() != null
	    			&& tiRequest.getTiRequestType().getName() != null) {
	    		requestType = tiRequest.getTiRequestType().getName();
	    		log.debug(" Request Type :: " + requestType);
	    		// Delete PAF is generated for Termination phase
	    		if (requestType != null
	    				&& requestType.equalsIgnoreCase("Terminate")) {
	    			retValue = util.queueFAFRequest(connectionId, request.getHeader("SM_USER"), "terminatepaf", "Y");
	    			//FAFReviewThread.getInstance().notifyThread();
	    			util.generateTerminatePAF(connectionId);
	    			
	    		} else {
	    			retValue = util.queueFAFRequest(connectionId, request.getHeader("SM_USER"), "recalculatepaf", "Y");
	    			//FAFReviewThread.getInstance().notifyThread();
	    			util.recalculatePAF(connectionId);
	    		}
	    	}
	    	
	    	
	    	if(!"true".equals(retValue)){
	    	    log.error(retValue);
	    	    throw new ApplicationException("Error During Re-Calculation of PAF Review Page! Please contact System Administrator.");
	    	}
	    	log.info("PAFReviewAction:Successfully completed the re-calculation of PAF Review ");

	    	
	    	Long processId=manageProxyProcess.getConnectionId();
	    	log.info("processId==="+processId);
	    	String tiReq = (String)request.getSession().getAttribute("tireqid");
	    	log.info("tiReq from SESSION==="+tiReq);
	    	Long tiRequestId = Long.valueOf(0);
	    	if (tiReq != null) {
	    	    try {
	    		tiRequestId = Long.valueOf(tiReq);
	    	    } catch (Exception e) {
	    		tiRequestId = Long.valueOf(0);
	    	    }
	    	}
	    	log.info("tiRequestId==="+tiRequestId);
	    	manageProxyProcess.setBusinessDetails(util.getBusinessDetails(connectionId,planning,"paf"));
	    	manageProxyProcess.setFafqueueReqs(util.getQueuedFAFRequests());
	    	manageProxyProcess.setApplicationList(util.getProxyApplicationDetails(connectionId));
	    	Long versionID = manageProxyProcess.getBusinessDetails().getVersionId();
	    	if(versionID == null){
	    	    versionID= Long.valueOf(0);
	    	}
	    	String rationale = util.getRationaleByVersion(processId,versionID,"PAF");
	    	manageProxyProcess.setRationale(rationale);
	    	//Added by Uma - Special Instr -Starts
	    	implInfo=util.getImplementationInfo(manageProxyProcess.getOriginalConnectionRequestId(),versionID,"paf");
	    	log.debug("Implemntation Info --- "+implInfo.size());
	    	Map<String,String> sowAndCmp = util.getCMPAndSOWByVersion(processId,versionID,"PAF");
	    	manageProxyProcess.setCMPReview(sowAndCmp.get("CMP"));
	    	manageProxyProcess.setSOWReview(sowAndCmp.get("SOW"));
	    	if(implInfo.size()>0){
	    		manageProxyProcess.setPrxSplInstruction((String)implInfo.get("SPL_INSTR")); 
	    		manageProxyProcess.setPrxCompletionDate((String)implInfo.get("COMPLETION_DATE"));
	    		manageProxyProcess.setPrxInfomanId((Long)implInfo.get("INFOMAN_ID"));
	    		manageProxyProcess.setChangeNo((String)implInfo.get("CHANGE_NUMBER"));
	    	    log.info("Implementation info -- Special Instruction-- "+implInfo.get("SPL_INSTR"));
	    	    log.info("Implementation info -- Completion Date-- "+implInfo.get("COMPLETION_DATE"));
	    	    log.info("Implementation info -- Infoman Id-- "+implInfo.get("INFOMAN_ID"));
	    	    log.info("Implementation info -- Change number -- "+implInfo.get("CHANGE_NUMBER"));
	    	}
	    	AppsenseADGroup appsenseADGroup = (AppsenseADGroup)util.getAppsenseADGroupName(processId,"PAF");
	    	if(appsenseADGroup != null){
	    	    log.info("AD Group Name:: "+appsenseADGroup.getName() +" / Policy Id:: "+appsenseADGroup.getPolicyID()+"/"+"Policy Name::: "+appsenseADGroup.getPolicyName());
	    	    manageProxyProcess.setAppsPolicyId(appsenseADGroup.getPolicyID());
	    	    manageProxyProcess.setAppsPolicyName(appsenseADGroup.getPolicyName());
	    	    manageProxyProcess.setAppsADGroupName(appsenseADGroup.getName());
	    	}
	    	request.setAttribute("current_versionID_paf", versionID);
	    	request.setAttribute("processId", connectionId);
	    	request.getSession().setAttribute("processId", connectionId);
	    	String outputFormatFlag = manageProxyProcess.isPafGenerated(tiRequestId);
			request.getSession().setAttribute("outputFormatFlag", outputFormatFlag);
	    	model.addAttribute("manageProxyProcess", manageProxyProcess);
	    	log.info("version id:::"+versionID);
	    	log.info("pAFProxyReviewAction.recalculate()::ends");
	    	return forwardTo;
	        }    
	    
	    @RequestMapping(value = "/exportPAF.act", method = { RequestMethod.GET, RequestMethod.POST })
	    private String exportPAF(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request, HttpServletResponse response){
	    	log.info("pAFProxyReviewAction.export()::Starts");
	    	String forwardTo ="reviewPAF";
	    	Long processId=manageProxyProcess.getOriginalConnectionRequestId();
	    	log.info("processId==="+processId);
	    	Long versionID = manageProxyProcess.getBusinessDetails().getVersionId();
	    	log.info("versionID:: "+versionID);
	    	if(versionID == null){
	    	    versionID= Long.valueOf(0);
	    	}
	    	Long version_export_id = null;
	    	String status = (String)request.getParameter("status");
	    	log.info("Status::: "+status);
	    	if(status.equals("current")){
	    	    version_export_id = versionID;
	    	}else if(status.equals("previous")){
	    	    version_export_id = Long.valueOf(versionID.longValue() -1);
	    	}
	    	Util util = new Util();
	    	Long tiRequestId = util.getTIRequestIdForVersion(processId, version_export_id.intValue());
	    	
	    	log.info("tiRequestId==="+tiRequestId);
	    	
	    	String paf = manageProxyProcess.getProxyAccessFormText(tiRequestId, processId, version_export_id);
	    	log.debug("paf string" +paf);
	    	paf = paf.replaceAll("\n", "\r\n");
	    	manageProxyProcess.setPafString(paf);
	    	//Added for task 45182 ends
	    	response.setContentType("text/plain; charset=utf-8");
	    	response.setHeader("Content-Disposition", "attachment; filename="+processId+"-"+versionID+".txt");
	    	
	    	//response.flushBuffer();
	    	forwardTo = "pages/jsp/review/paf_export_page";
	    	request.setAttribute("current_versionID_paf", versionID);
	    	log.info("pAFProxyReviewAction.export()::Ends");
	    	return forwardTo;
	        }
	    
	    @RequestMapping(value = "/reviewStatusMode.act", method = { RequestMethod.GET, RequestMethod.POST })
	    private String reviewStatusMode(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request, HttpServletResponse response){
	    	log.info("pAFProxyReviewAction.reviewStatusMode()::Starts");
	    	String forwardTo ="c3par.pafProxyReview.new";
	    	Long connectionId;
	    	Long processId=manageProxyProcess.getOriginalConnectionRequestId();
	    	log.info("processId==="+processId); 
	    	String action = (String) request.getSession().getAttribute("action");
			action = (String) request.getParameter("action");
			log.debug("action value in rev" +action);
	    	if("loadNoHdr".equals(action)){
				forwardTo = "pages/proxy/paf_proxy_review";
				request.getSession().setAttribute("PAFNoHeader", "TRUE");
			}
	    	if(request.getParameter("processId")!=null){
	    	    connectionId=Long.valueOf(request.getParameter("processId"));
	    	    manageProxyProcess.setOriginalConnectionRequestId(connectionId);
	    	}else{
	    	    connectionId=manageProxyProcess.getOriginalConnectionRequestId();
	    	}
	    	log.info("connectionId:: "+connectionId);
	    	if(connectionId != null){
	    	    if(!"".equals(connectionId)){
	    	    	manageProxyProcess.setExtResConnectionID(null);
	    		Long originalConnectionRequestId = connectionId;
	    		manageProxyProcess.setOriginalConnectionRequestId(originalConnectionRequestId);
	    	    }
	    	}
	    	String reviewStatus = (String)request.getParameter("statusMode");
	    	log.info("reviewStatus::: "+reviewStatus);

	    	Planning planning = manageProxyProcess.getPlanning();
	    	Long tiRequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());
	    	Long planningId = manageProxyProcess.getPlanningId(tiRequestId);
			
			log.info("Controller :: loadReview :: tirequestId "+ tiRequestId.longValue() + " :: planningId :: " + planningId);

			planning = manageProxyProcess.getPlanningDetails(planningId);
	    	Long versionID = Long.valueOf(0);
	    	if(manageProxyProcess != null && manageProxyProcess.getBusinessDetails().getVersionId() != null){
	    	    versionID = manageProxyProcess.getBusinessDetails().getVersionId();
	    	} else {
	    	    versionID =  util.getLatestVersionIdForPAFReview(processId);
	    	}
	    	log.info("versionID:: "+versionID);
	    	if(reviewStatus.equals("ReviewPrevious") && versionID != null && versionID.longValue() > 1 ){
	    	    versionID = Long.valueOf(versionID.longValue() -1);
	    	    
	    	} else if( reviewStatus.equals("ReviewCurrent")){
	    	    versionID = util.getLatestVersionIdForPAFReview(connectionId);
	    	   
	    	}
	    	TIRequest tiRequest = manageProxyProcess.getTIRequestDetails(tiRequestId);
	    	String rationale = util.getRationaleByVersion(processId,versionID,"PAF");
	    	manageProxyProcess.setRationale(rationale);
	    	Map<String,String> sowAndCmp = util.getCMPAndSOWByVersion(processId,versionID,"PAF");
	    	manageProxyProcess.setCMPReview(sowAndCmp.get("CMP"));
	    	manageProxyProcess.setSOWReview(sowAndCmp.get("SOW"));
	    	FAFRequest fafRequest = new FAFRequest();
			manageProxyProcess.setCurrBusJustfi(fafRequest.getOrigBusJustification(connectionId, versionID));
	    	//Added by Uma - Special Instruction Starts
	    	Map implInfo=new HashMap();
	    	implInfo=util.getImplementationInfo(manageProxyProcess.getOriginalConnectionRequestId(),versionID,"paf");
	    	log.debug("Implemntation Info --- "+implInfo.size());
	    	if(implInfo.size()>0){
	    		manageProxyProcess.setPrxSplInstruction((String)implInfo.get("SPL_INSTR"));
	    		manageProxyProcess.setPrxCompletionDate((String)implInfo.get("COMPLETION_DATE"));
	    		manageProxyProcess.setPrxInfomanId((Long)implInfo.get("INFOMAN_ID"));
	    		manageProxyProcess.setChangeNo((String)implInfo.get("CHANGE_NUMBER"));
	    	    log.info("Implementation info -- Special Instruction-- "+implInfo.get("SPL_INSTR"));
	    	    log.info("Implementation info -- Completion Date-- "+implInfo.get("COMPLETION_DATE"));
	    	    log.info("Implementation info -- Infoman Id-- "+implInfo.get("INFOMAN_ID"));
	    	    log.info("Implementation info -- Change number -- "+implInfo.get("CHANGE_NUMBER"));
	    	}

	    	AppsenseADGroup appsenseADGroup = (AppsenseADGroup)util.getAppsenseADGroupName(processId,"PAF");
	    	if(appsenseADGroup != null){
	    	    log.info("AD Group Name:: "+appsenseADGroup.getName() +" / Policy Id:: "+appsenseADGroup.getPolicyID()+"/"+"Policy Name::: "+appsenseADGroup.getPolicyName());
	    	    manageProxyProcess.setAppsPolicyId(appsenseADGroup.getPolicyID());
	    	    manageProxyProcess.setAppsPolicyName(appsenseADGroup.getPolicyName());
	    	    manageProxyProcess.setAppsADGroupName(appsenseADGroup.getName());
	    	}
	    	manageProxyProcess.setBusinessDetails(util.getBusinessDetails1(connectionId,planning,"paf",reviewStatus,versionID));
	    	manageProxyProcess.setApplicationList(util.getProxyApplicationDetails(connectionId));
	    	request.setAttribute("displayFilter", "review");
	    	request.setAttribute("current_versionID_paf", versionID);
	    	request.getSession().setAttribute("processId", processId);
	    	request.getSession().setAttribute("statusMode", reviewStatus);
	    	Long versionId=(Long)request.getAttribute("current_versionID_paf");
		    if(versionId==null)
		    {
			versionId=Long.valueOf(0);
		    }
		    List proxyRecordData = util.getData_Proxy(manageProxyProcess.getOriginalConnectionRequestId(),versionId);
		    request.setAttribute("proxyRecordData",proxyRecordData);

		    String proxy_implementer = util.getCurrentProcess_status(manageProxyProcess.getOriginalConnectionRequestId(),versionId,ActivityData.ACTIVITY_PROXY_IMP);
		    request.setAttribute("proxy_implementer",proxy_implementer);
		    Long id = null;
		    if(manageProxyProcess.getTiRequest() != null){
		    	id = manageProxyProcess.getTiRequest().getId();
		    }else if(request.getSession().getAttribute("TI_REQUEST_ENTITY") != null){
		    	id=((TIRequest)request.getSession().getAttribute("TI_REQUEST_ENTITY")).getId();
		    }
		    if(id != null){
		    	request.setAttribute("highRiskFlagAppsense", util.isAppsenseHighRisk(id)==true?"Yes":"No");
		    	request.setAttribute("highRiskFlagProxy", util.isProxyHighRisk(id)==true?"Yes":"No");
		    }else{
		    	request.setAttribute("highRiskFlagAppsense", "No");
		    	request.setAttribute("highRiskFlagProxy", "No");
		    }
		    manageProxyProcess.setTiRequest(tiRequest);
	    	log.info("pAFProxyReviewAction.reviewStatusMode()::Ends");
	    	model.addAttribute("manageProxyProcess", manageProxyProcess);
	    	return forwardTo;
	        }



	@RequestMapping(value = "/generateProxyRFC.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String generateProxyRFC(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		String forwardTo = "";

		log.info("ManageProxyController :: generateProxyRFC :: Starts");
		
		String action = request.getParameter("fncode");
		if(action != null && action.equalsIgnoreCase("update_pac")){
			forwardTo="forward:/load.act?tab=managePacFile";
		} else if(action != null && action.equalsIgnoreCase("update_filter")){
			forwardTo="forward:/load.act?tab=manageProxy";
		} else if(action != null && action.equalsIgnoreCase("update_plug")){
			forwardTo="forward:/load.act?tab=managePlug";
		} else if(action != null && action.equalsIgnoreCase("update_socks")){
			forwardTo="forward:/load.act?tab=manageSocks";
		} else if(action != null && action.equalsIgnoreCase("free_url")){
			forwardTo="forward:/load.act?tab=manageUrlAccess";
		}
		
		String tiReq = (String) request.getSession().getAttribute("tireqid");		
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}
		String pafGen = manageProxyProcess.isPafGenerated(tiRequestId);
		log.debug("paf gen" +pafGen);
		if(pafGen.equalsIgnoreCase("false")){
			log.debug("into false");
			request.setAttribute("err_log",
					"Please generate PAF before Proxy Change ");
			return forwardTo;
		}
		String status = manageProxyProcess.generateProxyRFC(tiRequestId);
		
		if(status != null && status.equalsIgnoreCase("SUCCESS")){
			request.getSession().setAttribute("isProxyChangeComplete", "true");
		}

		log.info("ManageProxyController :: generateProxyRFC :: Ends - status"+status+ " :: forwardTo - "+forwardTo);
		
		return forwardTo;
	}
	
	@RequestMapping(value = "/cancelApplicationProxy.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String cancelApplication(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request){
		String forwardTo = "load";
		log.info("ManageProxyAction.cancelApplication()::Starts");
		String selectedTab = request.getParameter("tab");
		if (selectedTab != null) {
		    if (selectedTab.equals("managePacFile")) {
			forwardTo = "loadPacFile";
		    } else if (selectedTab.equals("manageSocks")) {
			forwardTo = "loadSocks";
		    } else if (selectedTab.equals("managePlug")) {
			forwardTo = "loadPlug";
		    } else {
			forwardTo = "load";
		    }
		}
		Application application = manageProxyProcess.getProxyFilter()
		.getApplication();
		application.setIsCSI("");
		application.setApplicationName("");
		application.setAppOwnerFullName("");
		application.setAppOwnerGEID("");
		application.setFunction("");
		manageProxyProcess.getProxyProcess().setSelectAll(false);
		manageProxyProcess.setSelectAll("false");
		request.getSession().setAttribute("selectedTab", selectedTab);
		forwardTo = loadProxyFilterListAll(model, manageProxyProcess, request);
		model.addAttribute("manageProxyProcess", manageProxyProcess);
		log.info("ManageProxyAction.cancelApplication()::Ends");
		return forwardTo;
	    }
	
	@RequestMapping(value = "/addResourceProxy.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String addResourceProxy(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,BindingResult result, HttpServletRequest request){
		String forwardTo = "c3par.manageProxy";
		boolean selectedFilterFlag = false;
		log.debug("sdsdds" +forwardTo);
		log.info("manageProxyAction.addResource()::Starts");
		try{
		List proxyFilterList = manageProxyProcess.getProxyFilterList();
		if (proxyFilterList.size() > 0) {
		    for (int i = 0; i < proxyFilterList.size(); i++) {
			ProxyFilter proxyFilter = (ProxyFilter) proxyFilterList.get(i);
			if (proxyFilter.isSelected()) {
			    selectedFilterFlag = true;
			}
		    }
		} else {
			result.addError(new ObjectError("page", "Proxy Filter should be available to add CSI/NON CSI Application"));
		} 
		if (!selectedFilterFlag) {
			result.addError(new ObjectError("page", "Please select one or more Proxy Filter(s) to add CSI/NON CSI Application."));
		}
		request.setAttribute("addApplication", "true");
		String selectedTab = request.getParameter("tab");
		log.debug("st" +selectedTab);
		if (selectedTab != null) {

		    if (selectedTab.equals("managePacFile")) {
			forwardTo = "c3par.managePacFile";
		    } else if (selectedTab.equals("manageSocks")) {
			forwardTo = "c3par.manageProxySocks";
		    } else if (selectedTab.equals("managePlug")) {
			forwardTo = "c3par.manageProxySocks";
		    } else {
			forwardTo = "c3par.manageProxy";  
			manageProxyProcess.setPrxInstanceList((List) request.getSession().getAttribute("proxyInstanceListForFilter"));
			long totalRecords = manageProxyProcess.getProxyProcess().getTotalPrxInstance();
			long totalPages = totalRecords / manageProxyProcess.getPrxInsNoOfRecords();
			if (totalRecords % manageProxyProcess.getPrxInsNoOfRecords() > 0) {
				totalPages += 1;
				manageProxyProcess.setPrxInsTotalPages(totalPages);
			} else {
				manageProxyProcess.setPrxInsTotalPages(totalPages);
			}
			log.debug("page val" +totalRecords +totalPages);
		    }
		}
		if (request.getSession().getAttribute("COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY") != null) {
		    CitiResource citiResourceEntity = (CitiResource) request.getSession().getAttribute("COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY");
		    manageProxyProcess.setIpResourceId(Long.valueOf(citiResourceEntity.getCwhiId()));
		    log.debug("ManageProxyAction.addResource()::getName " + citiResourceEntity.getName());

		    manageProxyProcess.getProxyFilter().getApplication().setApplicationID(Long.valueOf(citiResourceEntity.getCwhiId()));
		    if ((citiResourceEntity.getName() == null) || citiResourceEntity.getName().equalsIgnoreCase("NULL")) {
		    	manageProxyProcess.getProxyFilter().getApplication().setApplicationName("");
		    } else {
		    	manageProxyProcess.getProxyFilter().getApplication().setApplicationName(citiResourceEntity.getName());
		    }
		    if ((citiResourceEntity.getFunctionalityDescription() == null) || citiResourceEntity.getFunctionalityDescription().equalsIgnoreCase("NULL")) {
		    	manageProxyProcess.getProxyFilter().getApplication().setFunction("");
		    } else {
		    	manageProxyProcess.getProxyFilter().getApplication().setFunction(citiResourceEntity.getFunctionalityDescription());
		    }

		    manageProxyProcess.getProxyFilter().getApplication().setAppOwnerFullName(citiResourceEntity.getOwner());
		    if ((citiResourceEntity.getOwnerid() == null) || citiResourceEntity.getOwnerid().equalsIgnoreCase("NULL")) {
		    	manageProxyProcess.getProxyFilter().getApplication().setAppOwnerGEID("");
		    } else {
		    	manageProxyProcess.getProxyFilter().getApplication().setAppOwnerGEID(citiResourceEntity.getOwnerid());
		    }
		    if (manageProxyProcess.getProxyFilter().getApplication().getIsCSI() != null
			    && manageProxyProcess.getProxyFilter().getApplication().getIsCSI().equalsIgnoreCase("Y")
			    && request.getSession().getAttribute("APP_OWNER_EMAIL") != null) {
		    	manageProxyProcess.getProxyFilter().getApplication().setAppOwnerEmail((String) request.getSession().getAttribute("APP_OWNER_EMAIL"));
		    } else {
		    	manageProxyProcess.getProxyFilter().getApplication().setAppOwnerEmail(null);
		    }

		    if (manageProxyProcess.getProxyFilter().getApplication().getIsCSI() != null
			    && manageProxyProcess.getProxyFilter().getApplication().getIsCSI().equalsIgnoreCase("Y")) {
				if (request.getSession().getAttribute("APP_MGR_EMAIL") != null) {
				    String managerEmail = (String) request.getSession().getAttribute("APP_MGR_EMAIL");
				    manageProxyProcess.getProxyFilter().getApplication().setAppManagerEmail(managerEmail);
				    log.debug("managerEmail for ManageProxyAction: "+ managerEmail);
				}
				if (request.getSession().getAttribute("APP_MGR_FULL_NAME") != null) {
				    String appManagerFullName = (String) request.getSession().getAttribute("APP_MGR_FULL_NAME");
				    manageProxyProcess.getProxyFilter().getApplication().setAppManagerFullName(appManagerFullName);
				    log.debug("appManagerFullName for ManageProxyAction: " + appManagerFullName);
				}
				if (request.getSession().getAttribute("APP_MGR_GEID") != null) {
				    String appManagerGEID = (String) request.getSession().getAttribute("APP_MGR_GEID");
				    manageProxyProcess.getProxyFilter().getApplication().setAppManagerGEID(appManagerGEID);
				    log.debug("appManagerGEID for ManageProxyAction: " + appManagerGEID);
				}
		    } else {
		    	manageProxyProcess.getProxyFilter().getApplication().setAppManagerEmail(null);
		    	manageProxyProcess.getProxyFilter().getApplication().setAppManagerFullName(null);
		    	manageProxyProcess.getProxyFilter().getApplication().setAppManagerGEID(null);
		    }
		    manageProxyProcess.getProxyFilter().getApplication().setSecClassification(citiResourceEntity.getClassification());
		    manageProxyProcess.getProxyFilter().getApplication().setPersonaDataIndicator(citiResourceEntity.getPersonalDataIndicator());
		    manageProxyProcess.getProxyFilter().getApplication().setIsDevice("N");
		    manageProxyProcess.getProxyFilter().getApplication().setIsCSI("Y");
		    request.setAttribute("CSI", "CSI");
		} else {

		}
		manageProxyProcess.setProxyRegionList((List) request.getSession().getAttribute("proxyRegionList"));
		}
		catch(Exception e){
			log.error(e,e);
		}
		log.debug("fwd" +forwardTo);
		request.setAttribute("CSI", "CSI");
		request.getSession().removeAttribute(
		"COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY");
		model.addAttribute("manageProxyProcess", manageProxyProcess);
		log.info("ManageProxyAction.addResource()::Ends");
		return forwardTo;
	    }
	
	@RequestMapping(value = "/exportAllProxy.act", method = { RequestMethod.GET, RequestMethod.POST })
	private String exportAllProxy(ModelMap model,@ModelAttribute("manageProxyProcess") ManageProxyProcess manageProxyProcess,HttpServletRequest request, HttpServletResponse response){
	    	log.info("PAFProxyReviewAction.exportAll()::Starts");
	    	String forwardTo;
	    	Long processId=manageProxyProcess.getOriginalConnectionRequestId();
	    	log.info("processId==="+processId);
	    	String tiReq = (String)request.getSession().getAttribute("tireqid");
	    	log.info("tiReq from SESSION==="+tiReq);
	    	Long tiRequestId = Long.valueOf(0);
	    	if (tiReq != null) {
	    	    try {
	    		tiRequestId = Long.valueOf(tiReq);
	    	    } catch (Exception e) {
	    		tiRequestId = Long.valueOf(0);
	    	    }
	    	}
	    	log.info("tiRequestId==="+tiRequestId);
	    	
	    	String paf = manageProxyProcess.getAllProxyAccessFormText(tiRequestId, processId);
	    	log.debug("export All paf string" +paf);
	    	paf = paf.replaceAll("\n", "\r\n");
	    	manageProxyProcess.setPafString(paf);
	    	response.setContentType("text/plain; charset=utf-8");
	    	response.setHeader("Content-Disposition", "attachment; filename="+processId+".txt");
	    	
	    	forwardTo = "pages/jsp/review/paf_export_page";
	    	log.info("PAFProxyReviewAction.exportALL()::Ends");
	    	return forwardTo;
	        }
	    
}
