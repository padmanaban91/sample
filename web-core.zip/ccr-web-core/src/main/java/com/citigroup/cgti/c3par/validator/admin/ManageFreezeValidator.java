package com.citigroup.cgti.c3par.validator.admin;

import java.util.ArrayList;
import java.util.List;

import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;

import com.citigroup.cgti.c3par.admin.domain.DailyLoad;
import com.citigroup.cgti.c3par.admin.domain.FirewallFreeze;
import com.citigroup.cgti.c3par.admin.domain.ManageFreezeProcess;
import com.citigroup.cgti.c3par.admin.domain.VacationFreeze;

public class ManageFreezeValidator implements Validator {


	public boolean supports(Class<?> paramClass) {
		return ManageFreezeProcess.class.equals(paramClass);
	}

	@Override
	public void validate(Object obj, Errors errors) {

	}

	public List<ObjectError> dailyLoadValidation(List<DailyLoad> dlList) {
		List<ObjectError> errlist = new ArrayList<ObjectError>();
		for (DailyLoad dl : dlList) {
			if(dl !=null) {
			
			if (dl.getFwLoc()==null || dl.getFwLoc().getFwLocation()==null || dl.getFwLoc().getFwLocation().isEmpty()) {
				errlist.add(new ObjectError("location",new String[]{"dailyLoad.location"},new String[]{""},"") );	
			}
			if (dl.getGenericLookup().getValue1() == null || dl.getGenericLookup().getValue1().isEmpty()) {
				errlist.add(new ObjectError("day",new String[]{"dailyLoad.genericLookup.value1"},new String[]{""},"") );	
			}
			if (dl.getLoadValue() == null || dl.getLoadValue().longValue() == 0) {
				errlist.add(new ObjectError("loadValue",new String[]{"dailyLoad.loadValue"},new String[]{""},"") );	
			}
			if (dl.getGlobalData()==null || dl.getGlobalData().isEmpty()) {
				errlist.add(new ObjectError("globalData",new String[]{"dailyLoad.globalData"},new String[]{""},"") );	

			}
			
			}
		}
		return errlist;
	}

	public List<ObjectError> firewallFreezeValidation(
			List<FirewallFreeze> fwList) {
		List<ObjectError> errlist = new ArrayList<ObjectError>();
		for (FirewallFreeze fw : fwList) {
			if(fw !=null) {
				
		
			if (fw.getFwPolicy().getName() == null || fw.getFwPolicy().getName().isEmpty()) {
				errlist.add(new ObjectError("policyName",new String[]{"firewallFreeze.fwPolicy.name"},new String[]{""},"") );	
			}
			if (fw.getRegion() == null || fw.getRegion().isEmpty()) {
				errlist.add(new ObjectError("region",new String[]{"firewallFreeze.region"},new String[]{""},"") );	
			}
			if (fw.getFreezeStartDateDisplay() == null || fw.getFreezeStartDateDisplay().isEmpty()) {
				errlist.add(new ObjectError("freezeStartDate",new String[]{"firewallFreeze.freezeStartDateDisplay"},new String[]{""},"") );	
			}
			if (fw.getFreezeEndDateDisplay()==null || fw.getFreezeEndDateDisplay().isEmpty()) {
				errlist.add(new ObjectError("freezeEndDate",new String[]{"firewallFreeze.freezeEndDateDisplay"},new String[]{""},"") );	
			}
			if (fw.getComments() ==null || fw.getComments().isEmpty()) {
				errlist.add(new ObjectError("comments",new String[]{"firewallFreeze.comments"},new String[]{""},"") );	
			}
		}
		}
		return errlist;
	}

	public List<ObjectError> vacationFreezeValidation(
			List<VacationFreeze> vfreeze) {
		List<ObjectError> errlist = new ArrayList<ObjectError>();
		
		for (VacationFreeze vf : vfreeze) {
			if(vf !=null){
			if (vf.getFwLoc().getFwLocation()==null || vf.getFwLoc().getFwLocation().isEmpty()) {
				errlist.add(new ObjectError("VFlocation",new String[]{"vacationFreeze.fwLoc.fwLocation"},new String[]{""},"") );	
			}
			if (vf.getFromDateDisplay() == null || vf.getFromDateDisplay().isEmpty()) {
				errlist.add(new ObjectError("VFfromDate",new String[]{"vacationFreeze.fromDateDisplay"},new String[]{""},"") );	
			}
			if (vf.getToDateDisplay() == null || vf.getToDateDisplay().isEmpty()) {
				errlist.add(new ObjectError("VFLoad",new String[]{"vacationFreeze.loadAvailable"},new String[]{""},"") );	
			}

		}
		}
		return errlist;
	}
}
