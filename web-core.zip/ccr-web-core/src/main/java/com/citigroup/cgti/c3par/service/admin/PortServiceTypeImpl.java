package com.citigroup.cgti.c3par.service.admin;

import java.util.List;

import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.soc.persist.PortServiceTypePersistable;
import com.citigroup.cgti.c3par.fw.domain.PortServiceMapping;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
@Transactional
public class PortServiceTypeImpl extends BasePersistanceImpl implements PortServiceTypePersistable {

	@Override
	@Transactional(readOnly = true)
	public List getConnections(Long actualPortId) throws Exception {
		try{
		Session session = getSession();
		String sqlStatement = "SELECT * FROM IP_PAIR, NET_PORT WHERE IP_PAIR.ID =  NET_PORT.IP_PAIR_ID AND NET_PORT.PORT_NUMBER = '"+actualPortId+"'";
		log.debug("SQL to be Executed"+sqlStatement);
		List connectionList = session.createSQLQuery(sqlStatement).list();
		return connectionList;
		}catch (Exception e){
			log.error(e,e);
			throw  e;
		}
		
	}

	@Override
	@Transactional(readOnly = true)
	public PortServiceMapping existPortServiceMapping(Long portId) throws Exception {
		try{
		PortServiceMapping record = null; ;
		Session session = getSession();
		String sqlStatement = "FROM PortServiceMapping WHERE portId = '" + portId + "'";
		log.debug("SQL to be Executed"+sqlStatement);
		List<PortServiceMapping> portServiceMapping= session.createQuery(sqlStatement).list();
		if(portServiceMapping!=null){
			for(PortServiceMapping portServiceMappingResult:portServiceMapping){
				record = portServiceMappingResult;
			}
		}
		return record;
	}catch (Exception e){
		log.error(e,e);
		throw  e;
	}
	}

	@Override
	public void insertPortServiceMapping(PortServiceMapping portServiceMapping) throws Exception {
		try{
		Session session = getSession();
		
		/* Long key = Long.valueOf(session.createSQLQuery( "select SEQ_PORT_SERVICE_MAPPING.nextval from dual").uniqueResult().toString());
		 portServiceMapping.setId(key);
		 log.debug("select SEQ_PORT_SERVICE_MAPPING.nextval from dual" + portServiceMapping.getPortId());
		 log.debug("select SEQ_PORT_SERVICE_MAPPING.nextval from dual" + portServiceMapping.getPortId());
		 log.debug("select SEQ_PORT_SERVICE_MAPPING.nextval from dual" + portServiceMapping.getDescription());
		 log.debug("select SEQ_PORT_SERVICE_MAPPING.nextval from dual" + portServiceMapping.getServiceType());*/
		 session.persist(portServiceMapping);
		
	}catch (Exception e){
		
		log.error(e,e);
		throw  e;
	}
	}

	@Override
	@Transactional(readOnly = true)
	public List<PortServiceMapping> findByPortId(String portId) throws Exception{
		try{
		Session session = getSession();
		String sqlStatement = "FROM PortServiceMapping WHERE portId = '" + portId + "'";
		log.debug("SQL to be Executed"+sqlStatement);
		List<PortServiceMapping> portServiceMappingList = session.createQuery(sqlStatement).list();
		return portServiceMappingList;
	}catch (Exception e){
		log.error(e,e);
		throw  e;
	}
	}

	@Override
	@Transactional(readOnly = true)
	public List<PortServiceMapping> findByServiceType(String searchService) throws Exception{
		try{
		Session session = getSession();
		String sqlStatement = "FROM PortServiceMapping WHERE serviceType = '" + searchService + "'";
		log.debug("SQL to be Executed"+sqlStatement);
		List<PortServiceMapping> portServiceMappingList = session.createQuery(sqlStatement).list();
		return portServiceMappingList;
	}catch (Exception e){
		log.error(e,e);
		throw  e;
	}
	}

	@Override
	@Transactional(readOnly = true)
	public PortServiceMapping getPortServiceMapping(String iD) throws Exception{
		try{
		Session session = getSession();
		String sqlStatement = "FROM PortServiceMapping WHERE Id = '" + iD + "'";
		log.debug("SQL to be Executed"+sqlStatement);
		PortServiceMapping portServiceMapping= (PortServiceMapping)session.createQuery(sqlStatement).uniqueResult();
		return portServiceMapping;
	}catch (Exception e){
		log.error(e,e);
		throw  e;
	}
	}
	

	@Override
	public void updatePortServiceMapping(PortServiceMapping portServiceMapping) throws Exception{
		try{
		Session session = getSession();
		session.merge(portServiceMapping);
	}catch (Exception e){
		log.error(e,e);
		throw  e;
	}
		
	}

	@Override
	public void deletePortServiceMapping(PortServiceMapping portServiceMapping) throws Exception{
		try{
		Session session = getSession();
		session.delete(portServiceMapping);
	}catch (Exception e){
		log.error(e,e);
		throw  e;
	}
		
	}

}
