package com.citigroup.cgti.c3par.fw.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.decisionservice.FirewallRuleDTO;
import com.citigroup.cgti.c3par.decisionservice.FlagDTO;
import com.citigroup.cgti.c3par.decisionservice.IpAddressDTO;
import com.citigroup.cgti.c3par.decisionservice.OstiaQuestionDTO;
import com.citigroup.cgti.c3par.decisionservice.OstiaQuestionnaireDTO;
import com.citigroup.cgti.c3par.decisionservice.PortDTO;
import com.citigroup.cgti.c3par.decisionservice.PossibleAnswersDTO;
import com.citigroup.cgti.c3par.decisionservice.RiskDefinitionDTO;
import com.citigroup.cgti.c3par.decisionservice.TiRequestDTO;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestion;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.PossibleAnswers;
import com.citigroup.cgti.c3par.fw.domain.RiskDefinition;

public class FirewallRuleMapper {

	private ManageTIProcessImpl manageTIProcess;
	
	/**
	 * @return the manageTIProcess
	 */
	public ManageTIProcessImpl getManageTIProcess() {
		return manageTIProcess;
	}

	/**
	 * @param manageTIProcess the manageTIProcess to set
	 */
	public void setManageTIProcess(ManageTIProcessImpl manageTIProcess) {
		this.manageTIProcess = manageTIProcess;
	}
	
	/** The log. */
    private static Logger log = Logger.getLogger(FirewallRuleMapper.class);

	public FirewallRuleDTO convertFirewallRuleToFirewallRuleDTO(FireWallRule fireWallRule, TiRequestDTO tiRequestDTO, Long tiRequestId) {
		
		FirewallRuleDTO firewallRuleDTO = new FirewallRuleDTO();
		
		String broadAccessFlag = manageTIProcess.getBroadAccessFlag(tiRequestId);
		
		List<FlagDTO> flagList = new ArrayList<FlagDTO>();
		flagList = new ArrayList<FlagDTO>();
		FlagDTO flagDTO = new FlagDTO();
		flagDTO.setKey("BROAD_ACCESS");
		flagDTO.setValue(broadAccessFlag);
		flagList.add(flagDTO);
		tiRequestDTO.getRiskCheckFlags().addAll(flagList);
		firewallRuleDTO.setTiRequest(tiRequestDTO);
		
		if (fireWallRule != null) {
			firewallRuleDTO.setId(fireWallRule.getId());
			firewallRuleDTO.setTransactionId("ConnectionID:"+fireWallRule.getTiRequest().getTiProcess().getId()+"TIR:"
										+fireWallRule.getTiRequest().getId()+"~FWR:"+fireWallRule.getId());
			if(fireWallRule.getSourceNetworkZone() != null){
				firewallRuleDTO.setSourceNetworkSegment(fireWallRule.getSourceNetworkZone().getName());
			} else {
				firewallRuleDTO.setSourceNetworkSegment("");
			}
			if(fireWallRule.getDestinationNetworkZone() != null){
				firewallRuleDTO.setDestinationNetworkSegment(fireWallRule.getDestinationNetworkZone().getName());
			} else {
				firewallRuleDTO.setDestinationNetworkSegment("");
			}
			IpAddressDTO ipAddressDTO = null;
			PortDTO portDTO = null;
			
			String tpaFlag = manageTIProcess.getTPAFlagforRule(fireWallRule.getId());
			
			String thirdParty = new String();
			
			if ("3rd Party/CEP".equals(tiRequestDTO.getSourceResourceType()) ||
					"3rd Party/CEP".equals(tiRequestDTO.getTargetResourceType())) {
				thirdParty = "Y";
			}
			
			flagList = new ArrayList<FlagDTO>();
			flagDTO = new FlagDTO();
			flagDTO.setKey("TPA");
			flagDTO.setValue(tpaFlag);
			flagList.add(flagDTO);
			
			flagDTO = new FlagDTO();
			flagDTO.setKey("THIRD_PARTY");
			flagDTO.setValue(thirdParty);
			flagList.add(flagDTO);
			firewallRuleDTO.getRiskCheckFlags().addAll(flagList);
			
			if (fireWallRule.getRiskSourceIPs() != null && !fireWallRule
					.getRiskSourceIPs().isEmpty()) {
				String srcTPA = "N";
			    for (FireWallRuleIP fireWallRuleSourceIP : fireWallRule.getRiskSourceIPs()) {
			    	ipAddressDTO = new IpAddressDTO();
			    	ipAddressDTO.setIpAddress(fireWallRuleSourceIP.getIpAddress().getIpAddress());
			    	ipAddressDTO.setAnyIP("Y".equalsIgnoreCase(fireWallRuleSourceIP.getIpAddress().getAnyIP()) ? true : false);
			    	ipAddressDTO.setTpa("Y".equalsIgnoreCase(fireWallRuleSourceIP.getIpAddress().getTpaFlag()) ? true : false);
			    	if (ipAddressDTO.isTpa()) {
			    		srcTPA = "Y";
			    	}	else {
			    		srcTPA = "N";
			    	}
			    	firewallRuleDTO.getSourceIPAddress().add(ipAddressDTO);
			    }
			    flagDTO = new FlagDTO();
				flagDTO.setKey("SRCTPA");
				flagDTO.setValue(srcTPA);
				flagList.add(flagDTO);
				firewallRuleDTO.getRiskCheckFlags().addAll(flagList);
			} else {
				IpAddressDTO ipAddress = new IpAddressDTO();
				ipAddress.setIpAddress("");
				firewallRuleDTO.getSourceIPAddress().add(ipAddress);
			}
			
			
		
			if (fireWallRule.getRiskDestinationIPs() != null && !fireWallRule
					.getRiskDestinationIPs().isEmpty()) {
				String dstTPA = "N";
			    for (FireWallRuleIP fireWallRuleDestinationIP : fireWallRule.getRiskDestinationIPs()) {
			    	ipAddressDTO = new IpAddressDTO();
			    	ipAddressDTO.setIpAddress(fireWallRuleDestinationIP.getIpAddress().getIpAddress());
			    	ipAddressDTO.setAnyIP("Y".equalsIgnoreCase(fireWallRuleDestinationIP.getIpAddress().getAnyIP()) ? true : false);
			    	ipAddressDTO.setTpa("Y".equalsIgnoreCase(fireWallRuleDestinationIP.getIpAddress().getTpaFlag()) ? true : false);
			    	if (ipAddressDTO.isTpa()) {
			    		dstTPA = "Y";
			    	}	else {
			    		dstTPA = "N";
			    	}
			    	firewallRuleDTO.getDestinationIPAddress().add(ipAddressDTO);
			    }
			    flagDTO = new FlagDTO();
				flagDTO.setKey("DSTTPA");
				flagDTO.setValue(dstTPA);
				flagList.add(flagDTO);
				firewallRuleDTO.getRiskCheckFlags().addAll(flagList);
			} else {
				IpAddressDTO ipAddress = new IpAddressDTO();
				ipAddress.setIpAddress("");
				firewallRuleDTO.getDestinationIPAddress().add(ipAddress);
			}
		
			if (fireWallRule.getRiskPorts() != null && !fireWallRule
					.getRiskPorts().isEmpty()) {
			    for (FireWallRulePort fireWallRulePort : fireWallRule.getRiskPorts()) {
			    	portDTO = new PortDTO();
			    	portDTO.setPortNumber(fireWallRulePort.getPort().getPortNumber());
			    	if (!"1-65535".equalsIgnoreCase(fireWallRulePort.getPort().getPortNumber())
			    			&& ("TCP".equalsIgnoreCase(fireWallRulePort.getPort().getProtocol())
			    			|| "UDP".equalsIgnoreCase(fireWallRulePort.getPort().getProtocol()))) {
			    		if (fireWallRulePort.getPort().getPortNumber().indexOf("-") != -1) {
			    			String[] portRange = fireWallRulePort.getPort().getPortNumber().split("-");
			    			portDTO.setStartPort(Long.valueOf(portRange[0]));
				    		portDTO.setEndPort(Long.valueOf(portRange[1]));
			    		} else {
			    			portDTO.setStartPort(Long.valueOf(fireWallRulePort.getPort().getPortNumber()));
				    		portDTO.setEndPort(Long.valueOf(fireWallRulePort.getPort().getPortNumber()));
			    		}
			    	} else {
			    		portDTO.setStartPort(0L);
			    		portDTO.setEndPort(0L);
			    	}
			    	portDTO.setProtocol(fireWallRulePort.getPort().getProtocol());
			    	portDTO.setDefaultService("Y".equalsIgnoreCase(fireWallRulePort.getDefaultService()) ? true : false);
			    	firewallRuleDTO.getPort().add(portDTO);
			    }
			}
			
			
			log.debug("------------------------------------------------------------------------------------------------------------------");
			log.debug("								INPUT::");
			log.debug("------------------------------------------------------------------------------------------------------------------");
			log.debug("");
			log.debug("CCR " + firewallRuleDTO.getTransactionId());
			log.debug("");
			log.debug("Source IP(s)::");
			log.debug("----------------------");
			for (int ipCount=0;ipCount < firewallRuleDTO.getSourceIPAddress().size();ipCount++) {
				ipAddressDTO = (IpAddressDTO)firewallRuleDTO.getSourceIPAddress().get(ipCount); 
				log.debug("IPAddress:: " + ipAddressDTO.getIpAddress() + "  is TPA:: " + ipAddressDTO.isTpa());
			}
			log.debug("----------------------");
			log.debug("Destination IP(s)::");
			log.debug("----------------------");
			for (int ipCount=0;ipCount < firewallRuleDTO.getDestinationIPAddress().size();ipCount++) {
				ipAddressDTO = (IpAddressDTO)firewallRuleDTO.getDestinationIPAddress().get(ipCount); 
				log.debug("IPAddress:: " + ipAddressDTO.getIpAddress() + "  is TPA:: " + ipAddressDTO.isTpa());
			}
			log.debug("----------------------");
			log.debug("Port(s)::");
			log.debug("----------------------");
			for (int portCount=0;portCount < firewallRuleDTO.getPort().size();portCount++) {
				portDTO = (PortDTO)firewallRuleDTO.getPort().get(portCount); 
				log.debug("Port Number:: " + portDTO.getPortNumber() + " :: Protocol:: " + portDTO.getProtocol() + "Start :: " + portDTO.getStartPort() + " :: End:: " + portDTO.getEndPort() + " :: Default Service :: " + portDTO.isDefaultService());
			}
			log.debug("");
			log.debug("");
		} else {
			firewallRuleDTO.setSourceNetworkSegment("");
			firewallRuleDTO.setDestinationNetworkSegment("");
			
			IpAddressDTO ipAddress = new IpAddressDTO();
			ipAddress.setIpAddress("");
			firewallRuleDTO.getSourceIPAddress().add(ipAddress);
			firewallRuleDTO.getDestinationIPAddress().add(ipAddress);
			
			PortDTO port = new PortDTO();
			port.setPortNumber("");
			port.setProtocol("");
			port.setStartPort(0L);
			port.setEndPort(0L);
			firewallRuleDTO.getPort().add(port);
		}
		return firewallRuleDTO;
		
	}
	
	public HashMap<String, OstiaQuestionnaire> convertFirewallRuleDTOToFirewallRule(FirewallRuleDTO outputFirewallRuleDTO) {
		
		HashMap<String, OstiaQuestionnaire> questionnaireMap = new HashMap<String, OstiaQuestionnaire>();
		
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("								FIREWALL RULE OUTPUT::");
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("");
		log.debug("Risk Definition Count()"
				 + " for CCR " + outputFirewallRuleDTO.getTransactionId() + " is :: "+ outputFirewallRuleDTO.getOstiaQuestionnaires().get(0).getRiskDefinitions().size());
		log.debug("");
		for (int i=0; i < outputFirewallRuleDTO.getOstiaQuestionnaires().get(0).getRiskDefinitions().size(); i++) {
			RiskDefinitionDTO riskDefinition = (RiskDefinitionDTO)outputFirewallRuleDTO.getOstiaQuestionnaires().get(0).getRiskDefinitions().get(i);
//			log.info("Ostia Questions for Risk Definition [ " + i + "] :: "
//				+ riskDefinition.getRiskCode());
			log.debug("Number of Ostia Questions for Risk Definition [" + (i+1) + "] :: "
					+ riskDefinition.getRiskCode() + " are :: " + riskDefinition.getOstiaQuestion().size());
			log.debug("----------------------");
			for (int j=0;j < riskDefinition.getOstiaQuestion().size();j++) {
				OstiaQuestionDTO ostiaQuestion = (OstiaQuestionDTO)riskDefinition.getOstiaQuestion().get(j);
//				log.info("Ostia Question [" + j + "] :: Question Control Code :: " + ostiaQuestion.getQuestionControlNumber()
//						+ " :: Question :: " + ostiaQuestion.getQuestion() + " :: Answer Type :: " + ostiaQuestion.getAnswerType()
//						+ " :: Answer Group :: " + ostiaQuestion.getOptionsGroupName());
				log.debug("Ostia Question [" + (j+1) + "] :: Question Control Code :: " + ostiaQuestion.getQuestionControlNumber()
						+ " :: Question :: " + ostiaQuestion.getQuestion() + " :: Answer Type :: " + ostiaQuestion.getAnswerType()
						+ " :: Answer Group :: " + getPossibleAnswers(ostiaQuestion.getPossibleAnswers()));
			}
			log.debug("----------------------");
			log.debug("");
		}
		
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("								REQUEST RULE OUTPUT::");
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("");
		log.debug("Risk Definition Count()"
				 + " for CCR " + outputFirewallRuleDTO.getTransactionId() + " is :: "+ outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires().get(0).getRiskDefinitions().size());
		log.debug("");
		for (int i=0; i < outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires().get(0).getRiskDefinitions().size(); i++) {
			RiskDefinitionDTO riskDefinition = (RiskDefinitionDTO)outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires().get(0).getRiskDefinitions().get(i);
//			log.info("Ostia Questions for Risk Definition [ " + i + "] :: "
//				+ riskDefinition.getRiskCode());
			log.debug("Number of Ostia Questions for Risk Definition [" + (i+1) + "] :: ("+riskDefinition.getRiskRating()+")"
					+ riskDefinition.getRiskCode() + " are :: " + riskDefinition.getOstiaQuestion().size());
			log.debug("----------------------");
			for (int j=0;j < riskDefinition.getOstiaQuestion().size();j++) {
				OstiaQuestionDTO ostiaQuestion = (OstiaQuestionDTO)riskDefinition.getOstiaQuestion().get(j);
//				log.info("Ostia Question [" + j + "] :: Question Control Code :: " + ostiaQuestion.getQuestionControlNumber()
//						+ " :: Question :: " + ostiaQuestion.getQuestion() + " :: Answer Type :: " + ostiaQuestion.getAnswerType()
//						+ " :: Answer Group :: " + ostiaQuestion.getOptionsGroupName());
				log.debug("Ostia Question [" + (j+1) + "] :: Question Control Code :: " + ostiaQuestion.getQuestionControlNumber()
						+ " :: Question :: " + ostiaQuestion.getQuestion() + " :: Answer Type :: " + ostiaQuestion.getAnswerType()
						+ " :: Answer Group :: " + getPossibleAnswers(ostiaQuestion.getPossibleAnswers()));
			}
			log.debug("----------------------");
			log.debug("");
		}
		
		//List<OstiaQuestionnaire> ostiaQuestionnaires = new ArrayList<OstiaQuestionnaire>();
		OstiaQuestionnaire ostiaQuestionnaire = null;
		
		//FirewallRuleOstiaQuestion firewallRuleOstiaAnswer = null;
		
		//List<FirewallRuleOstiaQuestion> firewallRuleOstiaAnswers = new ArrayList<FirewallRuleOstiaQuestion>();
		
		if (outputFirewallRuleDTO.getOstiaQuestionnaires() != null
				&& outputFirewallRuleDTO.getOstiaQuestionnaires().size() > 0) {
			
			OstiaQuestionnaireDTO ostiaQuestionnaireDTO 
						= outputFirewallRuleDTO.getOstiaQuestionnaires().get(0);
			List<RiskDefinitionDTO> riskDefinitionDTOs 
							= ostiaQuestionnaireDTO.getRiskDefinitions();
			
			ostiaQuestionnaire = new OstiaQuestionnaire();
			ostiaQuestionnaire.setCode(ostiaQuestionnaireDTO.getCode());
			ostiaQuestionnaire.setDescription(ostiaQuestionnaireDTO.getDescription());
			ostiaQuestionnaire.setType(ostiaQuestionnaireDTO.getType());
			ostiaQuestionnaire.setBaselineName(ostiaQuestionnaireDTO.getBaselineName());
			ostiaQuestionnaire.setBaselineReportUrl(ostiaQuestionnaireDTO.getBaselineReportUrl());
			
			ostiaQuestionnaire.setRiskDefinitions(new ArrayList<RiskDefinition>());
			RiskDefinition riskDefinition = null;
			for (RiskDefinitionDTO riskDefinitionDTO : riskDefinitionDTOs) {
				riskDefinition = new RiskDefinition();
				riskDefinition.setRiskCode(riskDefinitionDTO.getRiskCode());
				riskDefinition.setRiskDescription(riskDefinitionDTO.getRiskDescription());
				if (riskDefinitionDTO.getRiskRating() != null) {
					riskDefinition.setRiskRating(riskDefinitionDTO.getRiskRating().doubleValue());
				}
				riskDefinition.setOstiaQuestions(new ArrayList<OstiaQuestion>());
				OstiaQuestion ostiaQuestion = null;
				
				List<OstiaQuestionDTO> ostiaQuestionDTOs =  riskDefinitionDTO.getOstiaQuestion();
				
				for (OstiaQuestionDTO ostiaQuestionDTO : ostiaQuestionDTOs) {
					ostiaQuestion = new OstiaQuestion();
					ostiaQuestion.setQuestionControlNumber(ostiaQuestionDTO.getQuestionControlNumber());
					ostiaQuestion.setQuestion(ostiaQuestionDTO.getQuestion());
					ostiaQuestion.setHint(ostiaQuestionDTO.getHint());
					ostiaQuestion.setAnswerType(ostiaQuestionDTO.getAnswerType());
					
					PossibleAnswers possibleAnswers = null;
					ostiaQuestion.setPossibleAnswers(new ArrayList<PossibleAnswers>());
					
					if ("SELECT".equalsIgnoreCase(ostiaQuestionDTO.getAnswerType())
							|| "MULTISELECT".equalsIgnoreCase(ostiaQuestionDTO.getAnswerType())) {
						List<PossibleAnswersDTO> possibleAnswersDTOs = ostiaQuestionDTO.getPossibleAnswers();
						for (PossibleAnswersDTO possibleAnswersDTO : possibleAnswersDTOs) {
							possibleAnswers = new PossibleAnswers();
							possibleAnswers.setAnswer(possibleAnswersDTO.getAnswer());
							possibleAnswers.setOptionsGroupName(possibleAnswersDTO.getOptionsGroupName());
							ostiaQuestion.getPossibleAnswers().add(possibleAnswers);
						}
					}
					
					riskDefinition.getOstiaQuestions().add(ostiaQuestion);
				}
				ostiaQuestionnaire.getRiskDefinitions().add(riskDefinition);
			}
			
		}
		questionnaireMap.put("FWRULE", ostiaQuestionnaire);
		
		ostiaQuestionnaire = null;
		
		if (outputFirewallRuleDTO.getTiRequest() != null && outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires() != null
				&& outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires().size() > 0) {
			OstiaQuestionnaireDTO ostiaQuestionnaireDTO 
						= outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires().get(0);
			List<RiskDefinitionDTO> riskDefinitionDTOs 
							= ostiaQuestionnaireDTO.getRiskDefinitions();
			
			ostiaQuestionnaire = new OstiaQuestionnaire();
			ostiaQuestionnaire.setCode(ostiaQuestionnaireDTO.getCode());
			ostiaQuestionnaire.setDescription(ostiaQuestionnaireDTO.getDescription());
			ostiaQuestionnaire.setType(ostiaQuestionnaireDTO.getType());
			ostiaQuestionnaire.setBaselineName(ostiaQuestionnaireDTO.getBaselineName());
			ostiaQuestionnaire.setBaselineReportUrl(ostiaQuestionnaireDTO.getBaselineReportUrl());
			
			ostiaQuestionnaire.setRiskDefinitions(new ArrayList<RiskDefinition>());
			RiskDefinition riskDefinition = null;
			for (RiskDefinitionDTO riskDefinitionDTO : riskDefinitionDTOs) {
				riskDefinition = new RiskDefinition();
				riskDefinition.setRiskCode(riskDefinitionDTO.getRiskCode());
				riskDefinition.setRiskDescription(riskDefinitionDTO.getRiskDescription());
				riskDefinition.setOstiaQuestions(new ArrayList<OstiaQuestion>());
				OstiaQuestion ostiaQuestion = null;
				
				List<OstiaQuestionDTO> ostiaQuestionDTOs =  riskDefinitionDTO.getOstiaQuestion();
				
				for (OstiaQuestionDTO ostiaQuestionDTO : ostiaQuestionDTOs) {
					ostiaQuestion = new OstiaQuestion();
					ostiaQuestion.setQuestionControlNumber(ostiaQuestionDTO.getQuestionControlNumber());
					ostiaQuestion.setQuestion(ostiaQuestionDTO.getQuestion());
					ostiaQuestion.setHint(ostiaQuestionDTO.getHint());
					ostiaQuestion.setAnswerType(ostiaQuestionDTO.getAnswerType());
					riskDefinition.getOstiaQuestions().add(ostiaQuestion);
				}
				ostiaQuestionnaire.getRiskDefinitions().add(riskDefinition);
			}
			
		}
		questionnaireMap.put("REQUEST", ostiaQuestionnaire);
		
		return questionnaireMap;
	}
	
	private String getPossibleAnswers(List<PossibleAnswersDTO> possibleAnswers) {
		StringBuffer buffer = new StringBuffer();
		for (PossibleAnswersDTO possibleAnswersDTO : possibleAnswers) {
			if (possibleAnswersDTO != null) {
				buffer.append(possibleAnswersDTO.getAnswer() + " , ");
			}
		}
		return buffer.toString();
	}
	
}
