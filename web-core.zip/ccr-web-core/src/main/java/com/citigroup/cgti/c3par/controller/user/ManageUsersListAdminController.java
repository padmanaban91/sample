package com.citigroup.cgti.c3par.controller.user;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.Detail;
import javax.xml.soap.DetailEntry;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citigroup.cgti.c3par.audit.domain.AuditC3parUsersData;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.AdminProcess;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.soa.model.ProfileEntity;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.user.domain.C3parUserHierarchyXref;
import com.citigroup.cgti.c3par.user.domain.C3parUserRoleXref;
import com.citigroup.cgti.c3par.user.domain.SecurityRole;
import com.mentisys.util.databaserealm.PasswordEncryption;
import com.mentisys.util.databaserealm.PasswordEncryptionException;

@Controller
public class ManageUsersListAdminController {

	private Logger log = Logger.getLogger(this.getClass().getName());
	public static final String TIME_ZONE_UTC = "UTC";
	
	@RequestMapping(value = "/userManageC3parUsers.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String manageC3parUsers(ModelMap model,
			@ModelAttribute("adminProcess") AdminProcess adminProcess,
			HttpServletRequest request) {
		log.debug("ManageUserAdminController::manageC3parUsers methods starts...");

		String forward = "c3par.useradmin.manageUsers";

		if (adminProcess == null) {
			adminProcess = new AdminProcess();
		}

		String remoteUser = request.getHeader("SM_USER");

		if (remoteUser != null) {
			remoteUser = remoteUser.toLowerCase();
		}
		if (remoteUser != null && remoteUser.startsWith("guest_")) {
			request.getSession().setAttribute("USER_SSO_ID",
					remoteUser.substring(remoteUser.indexOf("_") + 1));
		} else {
			request.getSession().setAttribute("USER_SSO_ID", remoteUser);
		}

		String ssoId = null;
		String firstName = null;
		String lastName = null;
		if (adminProcess != null) {

			ssoId = adminProcess.getSoeID();

			firstName = adminProcess.getFirstName();

			lastName = adminProcess.getLastName();

		}

		// Setting page number
		String type = (String) request.getParameter("pageType");

		adminProcess = setPaginationValues(adminProcess, 0, 10, 0, type);

		adminProcess.setSoeID(ssoId);
		adminProcess.setFirstName(firstName);
		adminProcess.setLastName(lastName);

		// retrieve the C3par Users
		List<C3parUser> c3parUsers = adminProcess.listC3ParUsers();
		log.debug("adminProcess.listC3ParUsers()::manageC3parUsers::"
				+ adminProcess.listC3ParUsers());

		// setting the pagination values

		adminProcess.setTotalPages(getTotalPages(adminProcess.getRowCount(),
				adminProcess.getLimit()));
		adminProcess.setC3parUsers(c3parUsers);

		model.addAttribute("adminProcess", adminProcess);
		log.debug("ManageUserAdminController::manageC3parUsers methods ends...");

		return forward;
	}

	private AdminProcess setPaginationValues(AdminProcess adminProcess,
			int curOffSet, int limit, int pageNo, String pageType) {
		if (adminProcess != null) {
			curOffSet = adminProcess.getOffset();
			limit = adminProcess.getLimit();
			pageNo = adminProcess.getPageNo();
		}
		adminProcess = new AdminProcess();
		adminProcess.setLimit(limit);
		adminProcess.setPaginationRequired(true);
		if (pageType != null && "N".equalsIgnoreCase(pageType)) {
			adminProcess.setOffset(curOffSet + adminProcess.getLimit());
			adminProcess.setPageNo(pageNo + 1);
		} else if (pageType != null && "P".equalsIgnoreCase(pageType)) {
			adminProcess.setOffset(curOffSet - adminProcess.getLimit());
			adminProcess.setPageNo(pageNo - 1);
		} else if (pageType != null && "X".equalsIgnoreCase(pageType)) {
			adminProcess.setOffset(limit * (pageNo - 1));
			adminProcess.setPageNo(pageNo);
		} else if (pageType != null && "L".equalsIgnoreCase(pageType)) {
			adminProcess.setOffset(0);
			adminProcess.setPageNo(1);
		} else {
			adminProcess.setOffset(0);
			adminProcess.setPageNo(1);
			adminProcess.setLimit(10);
		}

		return adminProcess;
	}

	private int getTotalPages(int rowCount, int limit) {
		int totalPages = 0;
		if (rowCount % limit > 0) {
			totalPages = Math.round((rowCount / limit) + 0.5f);
		} else {
			totalPages = Math.round(rowCount / limit);
		}

		return totalPages;
	}

	@RequestMapping(value = "/userEditC3parUser.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String editC3parUser(ModelMap model,
			@ModelAttribute("adminProcess") AdminProcess adminProcess,
			HttpServletRequest request) {
		log.debug("indide Manage UserAdminController :editC3parUser starts here...");
		String userId = request.getParameter("userId");
		loadC3parUser(adminProcess, Long.valueOf(userId), "EDIT", request);
		model.addAttribute("adminProcess", adminProcess);
		log.debug("indide Manage UserAdminController :editC3parUser ends here...");
		return "c3par.useradmin.addEditUser";
	}

	@RequestMapping(value = "/userInformation.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String userInformation(ModelMap model,
			@ModelAttribute("adminProcess") AdminProcess adminProcess,
			HttpServletRequest request) {
		log.debug("indide Manage UserAdminController :userInformation starts here...");

		String userId = request.getParameter("userId");

		loadC3parUser(adminProcess, Long.valueOf(userId), "VIEW", request);
		request.setAttribute("Edit", "true");
		model.addAttribute("adminProcess", adminProcess);
		log.debug("indide Manage UserAdminController :userInformation ends here...");
		return "c3par.useradmin.userinfo";
	}

	@RequestMapping(value = "/userProfile.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String userProfile(ModelMap model,
			@ModelAttribute("adminProcess") AdminProcess adminProcess,
			HttpServletRequest request) {
		log.debug("indide Manage UserAdminController :userProfile starts here...");
		String soeId = request.getHeader("SM_USER");
		adminProcess = new AdminProcess();
		Long userId = adminProcess.getUserId(soeId);
		loadC3parUser(adminProcess, userId, "VIEW", request);
		request.setAttribute("Edit", "true");
		model.addAttribute("adminProcess", adminProcess);
		log.debug("indide Manage UserAdminController :userInformation ends here...");
		return "c3par.useradmin.userinfo";
	}

	private AdminProcess loadC3parUser(AdminProcess adminProcess, Long userId,
			String mode, HttpServletRequest request) {
		log.debug("Entering into loadC3parUser");

		adminProcess.setRegionList(adminProcess.getRegions());
		adminProcess.setSectorList(adminProcess.getSectors("ALL"));
		adminProcess.setSecurityRoleList(adminProcess.getSecurityRoles());

		if (userId != null && userId.longValue() > 0) {

			adminProcess.setC3parUser(adminProcess.retrieveC3parUser(userId));
		}

		List<Long> selectedRoles = new ArrayList<Long>();
		;
		List<C3parUserRoleXref> userRoleList = adminProcess.getC3parUser()
				.getUserRoleList();

		if (userRoleList != null && !userRoleList.isEmpty()) {

			for (C3parUserRoleXref c3parUserRoleXref : userRoleList) {

				if (c3parUserRoleXref.getSecurityRole() != null) {

					selectedRoles.add(c3parUserRoleXref.getSecurityRole()
							.getId());
				}
			}
			adminProcess.setSelectedRoles(selectedRoles);
		}

		if ("EDIT".equalsIgnoreCase(mode)) {

			request.getSession().setAttribute("REGIONS",
					adminProcess.getRegionList());
			request.getSession().setAttribute("SECTORS",
					adminProcess.getSectorList());
			request.getSession().setAttribute("SECURITYROLES",
					adminProcess.getSecurityRoles());

			createRegionSectorMap(request);

		} else if ("VIEW".equalsIgnoreCase(mode)) {

			if (adminProcess.getC3parUser().getActive() != null
					&& "Y".equalsIgnoreCase(adminProcess.getC3parUser()
							.getActive())) {
				adminProcess.getC3parUser().setActive("Active");
			} else if (adminProcess.getC3parUser().getActive() != null
					&& "P".equalsIgnoreCase(adminProcess.getC3parUser()
							.getActive())) {
				adminProcess.getC3parUser().setActive("Inprogress");
			} else {
				adminProcess.getC3parUser().setActive("InActive");
			}

			if (adminProcess.getC3parUser().getAdmin() != null
					&& "Y".equalsIgnoreCase(adminProcess.getC3parUser()
							.getAdmin())) {
				adminProcess.getC3parUser().setAdmin("Yes");
			} else {
				adminProcess.getC3parUser().setAdmin("No");
			}
		}
		return adminProcess;
	}

	private void createRegionSectorMap(HttpServletRequest request) {
		List<Region> regionList = (List<Region>) request.getSession()
				.getAttribute("REGIONS");
		Map<Long, String> regionsMap = new HashMap<Long, String>();
		if (regionList != null && !regionList.isEmpty()) {
			for (Region region : regionList) {
				regionsMap.put(region.getId(), region.getName());
			}
			request.getSession().setAttribute("REGIONSMAP", regionsMap);
		}

		List<Sector> sectorList = (List<Sector>) request.getSession()
				.getAttribute("SECTORS");
		Map<Long, String> sectorsMap = new HashMap<Long, String>();
		if (sectorList != null && !sectorList.isEmpty()) {
			for (Sector sector : sectorList) {
				sectorsMap.put(sector.getId(), sector.getName());
			}
			request.getSession().setAttribute("SECTORSMAP", sectorsMap);
		}

		List<SecurityRole> securityRolesList = (List<SecurityRole>) request
				.getSession().getAttribute("SECURITYROLES");
		Map<String, Long> securityRolesMap = new HashMap<String, Long>();
		if (securityRolesList != null && !securityRolesList.isEmpty()) {
			for (SecurityRole securityRole : securityRolesList) {
				securityRolesMap.put(securityRole.getName(),
						securityRole.getId());
			}
			request.getSession().setAttribute("SECURITYROLESMAP",
					securityRolesMap);
		}
	}

	@RequestMapping(value = "/userAddEditUser.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String addEditUser(ModelMap model,
			@ModelAttribute("adminProcess") AdminProcess adminProcess,
			HttpServletRequest request) {
		log.info("Inside ManageUserListAdminController : addEditUser methods starts here ...");
		adminProcess = new AdminProcess();
		adminProcess.setC3parUser(new C3parUser());
		adminProcess.setRegionList(adminProcess.getRegions());
		adminProcess.setSectorList(adminProcess.getSectors("ALL"));
		adminProcess.setSecurityRoleList(adminProcess.getSecurityRoles());
		request.getSession().removeAttribute("USERHIERARCHYLIST");

		request.getSession().setAttribute("REGIONS",
				adminProcess.getRegionList());
		request.getSession().setAttribute("SECTORS",
				adminProcess.getSectorList());
		request.getSession().setAttribute("SECURITYROLES",
				adminProcess.getSecurityRoleList());

		createRegionSectorMap(request);
		model.addAttribute("adminProcess", adminProcess);
		log.info("Inside ManageUserListAdminController : addEditUser methods ends here ...");
		return "c3par.useradmin.addEditUser";
	}

	@RequestMapping(value = "/userGetRitsData.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String getRitsData(ModelMap model,
			@ModelAttribute("adminProcess") AdminProcess adminProcess,
			HttpServletRequest request) {
		try {

			log.info("Entered in getritsdata::"
					+ adminProcess.getC3parUser().getSsoId());
			SOADataComponent soaDataComponent = new SOADataComponent();
			ProfileInfoFactory profileInfoFactory = (ProfileInfoFactory) soaDataComponent
					.getServiceFactory("profileInfo");
			ProfileEntity profileEntity = new ProfileEntity();
			profileEntity.setSoeId(adminProcess.getC3parUser().getSsoId());
			List<CitiContact> citiContactList = profileInfoFactory
					.getRitzService().getProfile(profileEntity,
					        request.getHeader("SM_USER"));
			Iterator it = citiContactList.iterator();

			while (it.hasNext()) {

				CitiContact entity = (CitiContact) it.next();
				adminProcess.getC3parUser().setFirstName(entity.getFirstName());
				adminProcess.getC3parUser().setLastName(entity.getLastName());
				adminProcess.getC3parUser().setEmail(entity.getEmail());
				adminProcess.getC3parUser().setEmployeeType(
						entity.getEmployeeType());
				adminProcess.getC3parUser().setGeId(entity.getGeId());

			}

		} catch (RemoteException e) {
			Throwable th = e.detail;
			if (th instanceof SOAPFaultException) {

				SOAPFaultException se = (SOAPFaultException) e.detail;
				Detail detail = se.getDetail();
				String value = "Error in retrieving value";

				if (detail != null) {

					Iterator it = detail.getDetailEntries();

					while (it.hasNext()) {

						DetailEntry newEntry = (DetailEntry) it.next();
						if (newEntry.getElementName().getLocalName()
								.equalsIgnoreCase("Description")) {
							value = newEntry.getValue();
						}
					}
				}
				request.setAttribute("mesg_log", value);
			} else {
				request.setAttribute("mesg_log", e.getMessage());
			}
		} catch (Exception e) {
			request.setAttribute("mesg_log", e.getMessage());
		}
		adminProcess.setRegionList(adminProcess.getRegions());
		adminProcess.setSectorList(adminProcess.getSectors("ALL"));
		adminProcess.setSecurityRoleList(adminProcess.getSecurityRoles());
		model.addAttribute("adminProcess", adminProcess);
		log.info("Inside ManageUserListAdminController : getRitsData methods ends here ...");

		return "c3par.useradmin.addEditUser";
	}

	@RequestMapping(value = "/userPopulateSectors.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody
	String populateSectors(ModelMap model,
			@ModelAttribute("adminProcess") AdminProcess adminProcess,
			HttpServletRequest request) {
		log.debug("Inside ManageUserListAdminController : populateSectors methods starts here ...");
		Long selectedRegion = adminProcess.getSelectedRegion();

		StringBuilder regionString = new StringBuilder();
		if (selectedRegion == -1) {

			regionString = new StringBuilder("ALL");
		} else {
			regionString.append(selectedRegion);
		}

		List<Sector> sectors = adminProcess.getSectors(regionString.toString());
		request.getSession().setAttribute("SECTORS", sectors);
		createRegionSectorMap(request);
		StringBuffer sectorsJSONSB = new StringBuffer();
		sectorsJSONSB.append("[");
		sectorsJSONSB.append("{\"item\":\"-1\",\"label\":\"ALL SECTORS\"}");
		for (Sector sector : sectors) {
			sectorsJSONSB.append(",{\"item\":\"" + sector.getId()
					+ "\",\"label\":\"" + sector.getName() + "\"}");
		}
		sectorsJSONSB.append("]");
		request.setAttribute("comboValues", sectorsJSONSB.toString());

		model.addAttribute("adminProcess", adminProcess);
		log.debug("Inside ManageUserListAdminController : populateSectors methods ends here ...");
		return sectorsJSONSB.toString();
	}

	@RequestMapping(value = "/userPopulateUserHierarchyList.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String populateUserHierarchyList(ModelMap model,
			@ModelAttribute("adminProcess") AdminProcess adminProcess,
			HttpServletRequest request, BindingResult result) {
		log.info("populateUserHierarchyList Starts .....");

		List<ObjectError> errlist = new ArrayList<ObjectError>();
		// To fetch the values from session
		List<C3parUserHierarchyXref> userHierarchyList = adminProcess
				.getC3parUser().getUserHierarchyList();

		if (userHierarchyList == null || userHierarchyList.isEmpty()) {
			userHierarchyList = new ArrayList<C3parUserHierarchyXref>();
		}

		String action = request.getParameter("action");

		// When the ADD action is called
		if ("ADD".equalsIgnoreCase(action)) {

			Map<Long, String> regionsMap = (Map<Long, String>) request
					.getSession().getAttribute("REGIONSMAP");
			Map<Long, String> sectorsMap = (Map<Long, String>) request
					.getSession().getAttribute("SECTORSMAP");

			Long selectedRegion = adminProcess.getSelectedRegion();
			List<Long> selectedSectors = adminProcess.getSelectedSectors();

			boolean validationFailed = false;

			if (selectedRegion == null) {
				errlist.add(new ObjectError(
						"adminProcess.C3parUser.selectedRegion",
						new String[] { "C3parUser.selectedRegion" }, null, null));
				validationFailed = true;
			}
			if (selectedSectors == null || selectedSectors.isEmpty()) {
				errlist.add(new ObjectError(
						"adminProcess.C3parUser.selectedSectors",
						new String[] { "C3parUser.selectedSectors" }, null,
						null));
				validationFailed = true;
			}
			if (adminProcess.getPermission() == null
					|| adminProcess.getPermission().isEmpty()) {
				errlist.add(new ObjectError(
						"adminProcess.C3parUser.permission",
						new String[] { "C3parUser.permission" }, null, null));
				validationFailed = true;
			}

			if (!validationFailed) {
				List<Long> selectedRegions = new ArrayList<Long>();
				if (selectedRegion == -1) {
					selectedRegions.addAll(regionsMap.keySet());
				} else {
					selectedRegions.add(selectedRegion);
				}

				if (selectedSectors != null && selectedSectors.size() == 1
						&& selectedSectors.get(0) == -1) {
					selectedSectors.remove(0);
					selectedSectors.addAll(sectorsMap.keySet());
				}

				C3parUserHierarchyXref c3parUserHierarchyXref = null;
				CitiHierarchyMaster citiHierarchyMaster = null;
				Region region = null;
				Sector sector = null;

				for (Long regionId : selectedRegions) {
					region = new Region();
					region.setId(regionId);

					region.setName(regionsMap.get(regionId));

					for (Long sectorId : selectedSectors) {

						if (!checkUserHierarchyExists(regionId, sectorId,
								adminProcess)) {
							sector = new Sector();
							sector.setId(sectorId);

							sector.setName(sectorsMap.get(sectorId));

							c3parUserHierarchyXref = new C3parUserHierarchyXref();
							citiHierarchyMaster = new CitiHierarchyMaster();
							citiHierarchyMaster.setRegion(region);
							citiHierarchyMaster.setSector(sector);

							c3parUserHierarchyXref
									.setCitiHierarchyMaster(citiHierarchyMaster);
							c3parUserHierarchyXref.setPermission(adminProcess
									.getPermission());
							userHierarchyList.add(c3parUserHierarchyXref);
						}
					}
				}
			}
			// When editing a single row in the table
		} else if ("EDIT".equalsIgnoreCase(action)) {
			String editRegId = request.getParameter("regionId");
			String editSecId = request.getParameter("sectorId");
			String permission = request.getParameter("permission");
			adminProcess.setSelectedRegion(Long.valueOf(editRegId));
			List<Long> selectedSectors = new ArrayList<Long>();
			selectedSectors.add(Long.valueOf(editSecId));
			adminProcess.setSelectedSectors(selectedSectors);
			adminProcess.setPermission(permission);
			request.setAttribute("EditIndexId", "EditIndexId");
		} // When the UPDATE action is called
		else if ("UPDATE".equalsIgnoreCase(action)) {
			Long selectedRegion = adminProcess.getSelectedRegion();
			List<Long> selectedSectors = adminProcess.getSelectedSectors();
			String permission = adminProcess.getPermission();

			boolean validationFailed = false;

			if (selectedRegion == null) {
				errlist.add(new ObjectError(
						"adminProcess.C3parUser.selectedRegion",
						new String[] { "C3parUser.selectedRegion" }, null, null));
				validationFailed = true;
			}
			if (selectedSectors == null || selectedSectors.isEmpty()) {
				errlist.add(new ObjectError(
						"adminProcess.C3parUser.selectedSectors",
						new String[] { "C3parUser.selectedSectors" }, null,
						null));
				validationFailed = true;
			}
			if (adminProcess.getPermission() == null
					|| adminProcess.getPermission().isEmpty()) {
				errlist.add(new ObjectError(
						"adminProcess.C3parUser.permission",
						new String[] { "C3parUser.permission" }, null, null));
				validationFailed = true;
			}

			if (!validationFailed) {
				for (Long sectorId : selectedSectors) {
					if (userHierarchyList != null
							&& !userHierarchyList.isEmpty()) {
						for (C3parUserHierarchyXref c3parUserHierarchyXref : userHierarchyList) {
							if (c3parUserHierarchyXref != null
									&& c3parUserHierarchyXref
											.getCitiHierarchyMaster() != null
									&& c3parUserHierarchyXref
											.getCitiHierarchyMaster()
											.getSector() != null
									&& c3parUserHierarchyXref
											.getCitiHierarchyMaster()
											.getRegion() != null
									&& sectorId.equals(c3parUserHierarchyXref
											.getCitiHierarchyMaster()
											.getSector().getId())
									&& selectedRegion
											.equals(c3parUserHierarchyXref
													.getCitiHierarchyMaster()
													.getRegion().getId())) {
								c3parUserHierarchyXref
										.setPermission(permission);
							}
						}
					}
				}
			}
		} // When the DELETE action is called
		else if ("DELETE".equalsIgnoreCase(action)) {
			List<C3parUserHierarchyXref> newUserHierarchyList = userHierarchyList;
			userHierarchyList = new ArrayList<C3parUserHierarchyXref>();
			if (newUserHierarchyList != null && !newUserHierarchyList.isEmpty()) {
				for (C3parUserHierarchyXref c3parUserHierarchyXref : newUserHierarchyList) {
					if (c3parUserHierarchyXref != null
							&& !c3parUserHierarchyXref.isDeleted()) {
						userHierarchyList.add(c3parUserHierarchyXref);
					}
				}
			}
		}		
		adminProcess.setRegionList(adminProcess.getRegions());
		adminProcess.setSectorList(adminProcess.getSectors("ALL"));
		adminProcess.setSecurityRoleList(adminProcess.getSecurityRoles());
		adminProcess.getC3parUser().setUserHierarchyList(userHierarchyList);

		for (ObjectError error : errlist) {
			result.addError(error);
		}
		model.addAttribute("adminProcess", adminProcess);
		log.debug("Inside ManageUserListAdminController : populateUserHierarchyList methods ends here ...");
		return "c3par.useradmin.addEditUser";
	}

	private boolean checkUserHierarchyExists(Long regionId, Long sectorId,
			AdminProcess adminProcess) {
		List<C3parUserHierarchyXref> userHierarchyList = adminProcess
				.getC3parUser().getUserHierarchyList();
		if (userHierarchyList != null && !userHierarchyList.isEmpty()) {
			for (C3parUserHierarchyXref c3parUserHierarchyXref : userHierarchyList) {
				if (c3parUserHierarchyXref != null
						&& c3parUserHierarchyXref.getCitiHierarchyMaster() != null
						&& c3parUserHierarchyXref.getCitiHierarchyMaster()
								.getSector() != null
						&& c3parUserHierarchyXref.getCitiHierarchyMaster()
								.getRegion() != null
						&& sectorId.equals(c3parUserHierarchyXref
								.getCitiHierarchyMaster().getSector().getId())
						&& regionId.equals(c3parUserHierarchyXref
								.getCitiHierarchyMaster().getRegion().getId())) {
					return true;
				}
			}
		}
		return false;
	}

	@RequestMapping(value = "/userSaveC3parUser.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String saveC3parUser(ModelMap model,
			@ModelAttribute("adminProcess") AdminProcess adminProcess,
			HttpServletRequest request, BindingResult result) {
		log.debug("Inside ManageUserListAdminController : saveC3parUser methods starts here ...");
		C3parUser c3parUser = adminProcess.getC3parUser();

		Long userId = null;
		
		boolean update = false;
		boolean validate = true;
		List<ObjectError> errlist = new ArrayList<ObjectError>();
		log.debug("ManageUserListAdminController::saveC3parUser::c3parUser.getActive()::"
				+ c3parUser.getActive());

		C3parUser extRecord = null;
		if (c3parUser != null && c3parUser.getId() != null
				&& c3parUser.getId().longValue() > 0) {
			userId = c3parUser.getId();
			update = true;
			extRecord = adminProcess.retrieveC3parUser(Long.valueOf(userId));
			if (c3parUser.getActive() == null
					|| c3parUser.getActive().isEmpty()) {
				c3parUser.setActive("N");
			}
			if ("N".equals(c3parUser.getActive())) {
				validate = false;
			}
		}

		List<ObjectError> validationerrorlist = validateC3parUser(validate,
				adminProcess, request);

		if (validationerrorlist != null && validationerrorlist.size() > 0) {

			for (ObjectError error : validationerrorlist) {
				result.addError(error);
			}

			adminProcess.setRegionList(adminProcess.getRegions());
			adminProcess.setSectorList(adminProcess.getSectors("ALL"));
			adminProcess.setSecurityRoleList(adminProcess.getSecurityRoles());

			return "c3par.useradmin.addEditUser";
		}

		String password = c3parUser.getSsoId().trim().toLowerCase() + "!!";
		try {
			password = PasswordEncryption.getInstance().encrypt(password);
		} catch (PasswordEncryptionException e) {
			e.printStackTrace();
		}
		try {
			String loginSsoId = request.getSession()
					.getAttribute("USER_SSO_ID").toString();
			if (!update) {
				c3parUser.setPassword(password);
				c3parUser.setActive("Y");
				// c3parUser.setWfStatus("Pending");
				c3parUser.setWfStatus("Bulk_Upload");
				c3parUser.setCreatedUser(loginSsoId);
				// c3parUser.setRequestedBy(loginSsoId);
				c3parUser.setRequestedBy("initialize_migration");
				c3parUser.setRequestedDate(new Date());
				c3parUser.setCreated_date(new Date());
				c3parUser.setUpdated_date(new Date());
			} else {
				/*
				 * if ("true".equals(c3parUser.getActive())) {
				 * c3parUser.setActive("Y"); } else { c3parUser.setActive("N");
				 * }
				 */
				c3parUser.setWfStatus("Pending");
				c3parUser.setUpdated_date(new Date());
				c3parUser.setManagerApprover("");
				c3parUser.setMgrReviewedDate(null);
				c3parUser.setSysadminApprover("");
				c3parUser.setSysadminReviewedDate(null);
				c3parUser.setIsaApprover("");
				c3parUser.setIsaReviewedDate(null);
				c3parUser.setUpdatedUser(loginSsoId);
				// setting the existing values
				if (extRecord != null) {
					c3parUser.setPassword(extRecord.getPassword());
					c3parUser.setCreatedUser(extRecord.getCreatedUser());
					c3parUser.setRequestedBy(extRecord.getRequestedBy());
					c3parUser.setRequestedDate(extRecord.getRequestedDate());
					c3parUser.setCreated_date(extRecord.getCreated_date());
				}
			}

			List<C3parUserRoleXref> userRoleList = new ArrayList<C3parUserRoleXref>();

			//Type Cast to fix duplicate on selected roles
			Set<Long> selectedRoles = new HashSet<Long>(adminProcess.getSelectedRoles());

			C3parUserRoleXref c3parUserRoleXref = null;
			SecurityRole securityRole = null;

			Map<String, Long> securityRoleMap = (Map<String, Long>) request
					.getSession().getAttribute("SECURITYROLESMAP");
			selectedRoles.add(securityRoleMap.get(ActivityData.ROLE_ENT_REQ));
			selectedRoles.add(securityRoleMap.get("C3PARUSER"));
			
			//If ECM Manager or ECM Lead ECM Agent to be added.			
			if (selectedRoles.contains(securityRoleMap
					.get(ActivityData.ROLE_ECM_Manager))
					&& !selectedRoles.contains(securityRoleMap
							.get("ECM Lead")) ){
				selectedRoles.add(securityRoleMap.get("ECM Lead"));
			}
			if (selectedRoles.contains(securityRoleMap
					.get(ActivityData.ROLE_ECM_Manager))
					&& !selectedRoles.contains(securityRoleMap
							.get("ECM Agent")) ){
				selectedRoles.add(securityRoleMap.get("ECM Agent"));
			}
			if (selectedRoles.contains(securityRoleMap
					.get(ActivityData.ROLE_ECM_Manager))
					&& !selectedRoles.contains(securityRoleMap
							.get("ECM")) ){
				selectedRoles.add(securityRoleMap.get("ECM"));
			}
			if (selectedRoles.contains(securityRoleMap
					.get(ActivityData.ROLE_ECM_Lead))
					&& !selectedRoles.contains(securityRoleMap
							.get("ECM Agent")) ){
				selectedRoles.add(securityRoleMap.get("ECM Agent"));
			}
			if (selectedRoles.contains(securityRoleMap
					.get(ActivityData.ROLE_ECM_Lead))
					&& !selectedRoles.contains(securityRoleMap
							.get("ECM")) ){
				selectedRoles.add(securityRoleMap.get("ECM"));
			}
			if (selectedRoles.contains(securityRoleMap
					.get(ActivityData.ROLE_ECM_Agent))
					&& !selectedRoles.contains(securityRoleMap
							.get("ECM")) ){
				selectedRoles.add(securityRoleMap.get("ECM"));
			}
			// If ECM, Project Coordinator also to be added
			if (selectedRoles.contains(securityRoleMap
					.get(ActivityData.ROLE_ECM))
					&& !selectedRoles.contains(securityRoleMap
							.get("Project_Coordinator"))) {
				selectedRoles.add(securityRoleMap.get("Project_Coordinator"));
			}
			// If ECM, Technical Coordinator also to be added
			if (selectedRoles.contains(securityRoleMap
					.get(ActivityData.ROLE_ECM))
					&& !selectedRoles.contains(securityRoleMap
							.get("Design_Engineer"))) {
				selectedRoles.add(securityRoleMap.get("Design_Engineer"));
			}
			// If Manager, Business User also to be added
			if (selectedRoles.contains(securityRoleMap.get("Manager"))
					&& !selectedRoles.contains(securityRoleMap
							.get("Business User"))) {
				selectedRoles.add(securityRoleMap.get("Business User"));
			}
			// If System Administrator
			if (selectedRoles.contains(securityRoleMap.get("C3PARSYSTEMADMIN"))) {
				c3parUser.setAdmin("Y");
			} else {
				c3parUser.setAdmin("N");
			}		
			
			List<C3parUserRoleXref> extUserRoleList = null;

			if (update) {
				extUserRoleList = extRecord.getUserRoleList();
			}

			log.debug("Selected Roles ... " + selectedRoles);
			StringBuffer selectedRoleNames = new StringBuffer();
			StringBuffer existingRoleNames = new StringBuffer();
			for (Long roleId : selectedRoles) {
				log.info("Map Key: "+getKeyFromValue(roleId,securityRoleMap));
				selectedRoleNames.append(getKeyFromValue(roleId,securityRoleMap)).append(",");
				C3parUserRoleXref c3parUserRoleXrefExt = roleExists(
						extUserRoleList, roleId);
				if (c3parUserRoleXrefExt != null) {
					existingRoleNames.append(getKeyFromValue(roleId,securityRoleMap)).append(",");
					userRoleList.add(c3parUserRoleXrefExt);
				} else {
					securityRole = new SecurityRole();
					c3parUserRoleXref = new C3parUserRoleXref();
					securityRole.setId(roleId);
					c3parUserRoleXref.setC3parUser(c3parUser);
					c3parUserRoleXref.setSecurityRole(securityRole);
					c3parUserRoleXref.setUpdated_date(new Date());
					userRoleList.add(c3parUserRoleXref);
				}
			}
			String rolesToAudit = selectedRoleNames.deleteCharAt(selectedRoleNames.length()-1).toString();
			log.debug(" Selected Roles Names: "+rolesToAudit);
			c3parUser.setUserRoleList(userRoleList);
			adminProcess.setC3parUser(c3parUser);

			c3parUser = adminProcess.validateC3parUser();

			if (c3parUser.getValidationErrors() != null
					&& c3parUser.getValidationErrors().size() > 0) {
				for (String error : c3parUser.getValidationErrors()) {

					errlist.add(new ObjectError("adminProcess.C3parUser",
							new String[] { error }, null, null));

				}
				adminProcess.setRegionList(adminProcess.getRegions());
				adminProcess.setSectorList(adminProcess.getSectors("ALL"));
				adminProcess.setSecurityRoleList(adminProcess
						.getSecurityRoles());

				for (ObjectError error : errlist) {

					result.addError(error);

				}

				return "c3par.useradmin.addEditUser";
			}
			try {
				userId = adminProcess.saveC3parUser();
				log.debug("User created in CCR : " + userId);
				AuditC3parUsersData auditC3parUsersData = createAuditUsersData(userId,adminProcess,loginSsoId);
				String status=auditC3parUsersData.getIsActiveCurrent();
				if(status!=null){
					status = status.equals("Y") ? "ACTIVE" : "IN-ACTIVE";
				}
				if(extRecord!=null && update){
					auditC3parUsersData.setAction("UPDATE");
					String existingRoles = existingRoleNames.deleteCharAt(existingRoleNames.length()-1).toString();
					log.debug("Existing Roles: "+existingRoles);
					auditC3parUsersData.setRoleStrPrev(existingRoles);
					auditC3parUsersData.setIsActivePrev(extRecord.getActive());
					auditC3parUsersData.setEntStrPrev(getEntitlements(extRecord));
					auditC3parUsersData.setEventDescription("User "+extRecord.getSsoId()+" Updated and Status is "+status);
				}else {
					auditC3parUsersData.setAction("CREATE");
					auditC3parUsersData.setEventDescription("User "+c3parUser.getSsoId()+" Created and Status is "+status);
				}
				auditC3parUsersData.setRoleStrCurrent(rolesToAudit);
				String deviceHostName = request.getServerName().substring(0, request.getServerName().indexOf("."));
				auditC3parUsersData.setHostName(deviceHostName);
				auditC3parUsersData.setHostNameAddress(request.getServerName());
				log.debug("Before auditC3parUsersData Save "+auditC3parUsersData.toString());
				adminProcess.saveAuditUsersData();
			} catch (Exception e) {
				log.error("Exception in Saving Audit Log table",e);
			}
			//Due to the BPM Migration, there is no need to have BPM update
			
			/*if (update) {
				WsPapiFacade papiFacade = new WsPapiFacade();
				papiFacade.isaEdit(loginSsoId);
			} else {
				WsPapiFacade papiFacade = new WsPapiFacade();
				papiFacade.createProcessUserEntitlement(loginSsoId,
						c3parUser.getSsoId(), "Y");
			}*/

		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - " + e.getMessage());

			ObjectError error = new ObjectError("name",
					"Not able to create the User.Exception has occurred.");
			result.addError(error);

			adminProcess.setRegionList(adminProcess.getRegions());
			adminProcess.setSectorList(adminProcess.getSectors("ALL"));
			adminProcess.setSecurityRoleList(adminProcess.getSecurityRoles());
			return "c3par.useradmin.addEditUser";
		}
		loadC3parUser(adminProcess, Long.valueOf(userId), "EDIT", request);

		for (ObjectError error : errlist) {
			result.addError(error);
		}

		model.addAttribute("adminProcess", adminProcess);

		log.debug("Inside ManageUserListAdminController : saveC3parUser methods ends here ...");
		return "c3par.useradmin.addEditUser";
	}

	private List<ObjectError> validateC3parUser(boolean validate,
			AdminProcess adminProcess, HttpServletRequest request) {

		List<ObjectError> errlist = new ArrayList<ObjectError>();
		if (adminProcess.getC3parUser().getSsoId() == null
				|| adminProcess.getC3parUser().getSsoId().isEmpty()) {

			errlist.add(new ObjectError("adminProcess.C3parUser",
					new String[] { "c3parUser.ssoId" }, null, null));

		}

		if (adminProcess.getC3parUser().getFirstName() == null
				|| adminProcess.getC3parUser().getFirstName().isEmpty()) {

			errlist.add(new ObjectError("adminProcess.C3parUser",
					new String[] { "c3parUser.firstName" }, null, null));

		}

		if (adminProcess.getC3parUser().getLastName() == null
				|| adminProcess.getC3parUser().getLastName().isEmpty()) {

			errlist.add(new ObjectError("adminProcess.C3parUser",
					new String[] { "c3parUser.lastName" }, null, null));

		}

		if (adminProcess.getC3parUser().getEmail() == null
				|| adminProcess.getC3parUser().getEmail().isEmpty()) {

			errlist.add(new ObjectError("adminProcess.C3parUser",
					new String[] { "c3parUser.email" }, null, null));

		}

		if (adminProcess.getC3parUser().getEmployeeType() == null
				|| adminProcess.getC3parUser().getEmployeeType().isEmpty()) {

			errlist.add(new ObjectError("adminProcess.C3parUser",
					new String[] { "c3parUser.employeeType" }, null, null));

		}
		log.debug("Validate --> " + validate);
		// These are not to be validated, if the user is going to be inactivated
		if (validate) {
			if (adminProcess.getSelectedRoles() == null
					|| adminProcess.getSelectedRoles().isEmpty()) {
				errlist.add(new ObjectError("adminProcess.C3parUser",
						new String[] { "c3parUser.selectedRoles" }, null, null));

			}

			List<Long> selectedRoles = adminProcess.getSelectedRoles();
			Map<String, Long> securityRoleMap = (Map<String, Long>) request
					.getSession().getAttribute("SECURITYROLESMAP");

			if (selectedRoles != null
					&& (selectedRoles.contains(securityRoleMap
							.get("Project_Coordinator")) || selectedRoles
							.contains(securityRoleMap.get("Design_Engineer")))
					&& !selectedRoles.contains(securityRoleMap.get("ECM"))) {

				errlist.add(new ObjectError("adminProcess.C3parUser",
						new String[] { "projectCoordinator_designEngineer" },
						null, null));

			}

			if (selectedRoles != null
					&& (selectedRoles.contains(securityRoleMap
							.get("Project_Coordinator"))
							|| selectedRoles.contains(securityRoleMap
									.get("Design_Engineer"))
							|| selectedRoles.contains(securityRoleMap
									.get("ECM"))
							|| selectedRoles.contains(securityRoleMap
									.get("Business User"))
							|| selectedRoles.contains(securityRoleMap
									.get("Manager")) || selectedRoles
								.contains(securityRoleMap.get("BISO")))) {
				if (adminProcess.getC3parUser().getUserHierarchyList() == null
						|| adminProcess.getC3parUser().getUserHierarchyList()
								.isEmpty()) {
					errlist.add(new ObjectError(
							"adminProcess.C3parUser",
							new String[] { "projectCoordinator_designEngineer_Ecm" },
							null, null));

				}
			}			
			//Added for ECM Manager, ECM Lead and ECM Agent
			if (selectedRoles != null
					&& (selectedRoles.contains(securityRoleMap
							.get("ECM Lead"))
							|| selectedRoles.contains(securityRoleMap
									.get("ECM Agent"))
							|| selectedRoles.contains(securityRoleMap
									.get("ECM Manager")))) {
				if (adminProcess.getC3parUser().getUserHierarchyList() == null
						|| adminProcess.getC3parUser().getUserHierarchyList()
								.isEmpty()) {
					errlist.add(new ObjectError(
							"adminProcess.C3parUser",
							new String[] { "EcmLead_EcmManager_EcmAgent" },
							null, null));

				}
			}
		}
		return errlist;
	}

	private C3parUserRoleXref roleExists(
			List<C3parUserRoleXref> extUserRoleList, Long roleId) {
		if (extUserRoleList != null && !extUserRoleList.isEmpty()) {
			for (C3parUserRoleXref c3parUserRoleXrefExt : extUserRoleList) {
				if (c3parUserRoleXrefExt.getSecurityRole() != null
						&& roleId.equals(c3parUserRoleXrefExt.getSecurityRole()
								.getId())) {
					return c3parUserRoleXrefExt;
				}
			}
		}
		return null;
	}
	
	private AuditC3parUsersData createAuditUsersData(Long userId, AdminProcess adminProcess, String loginSSOId){
		log.info("Entering ManageusersListAdminController createAuditUsersData.");
		AuditC3parUsersData auditC3parUsersData = new AuditC3parUsersData();
		C3parUser c3parUser = adminProcess.getC3parUser();
		auditC3parUsersData.setUserId(userId);
		auditC3parUsersData.setUpdatedByUser(loginSSOId);
		auditC3parUsersData.setUpdated_date(new Date());
		auditC3parUsersData.setMgrApprover("");
		auditC3parUsersData.setMgrApprovedDate(null);
		auditC3parUsersData.setIsaApprover("");
		auditC3parUsersData.setIsaApprovedDate(null);
		auditC3parUsersData.setIsActiveCurrent(c3parUser.getActive());
		auditC3parUsersData.setEntStrCurrent(getEntitlements(c3parUser));
		auditC3parUsersData.setAuditLogInsertedDate(new Date());
		auditC3parUsersData.setSysadminApprover("");
		auditC3parUsersData.setSysadminReviewedDate(null);
		auditC3parUsersData.setLogDateTime(getDateTimeInUTC());
		auditC3parUsersData.setAffectedUser(c3parUser.getSsoId());
		adminProcess.setAuditC3parUsersData(auditC3parUsersData);
		log.info("Exiting ManageusersListAdminController createAuditUsersData.");
		return auditC3parUsersData;		
	}
	
	private String getEntitlements(C3parUser c3parUser){
		log.info("Entering ManageusersListAdminController getEntitlements.");
		StringBuilder entitlements = new StringBuilder("");
		List<C3parUserHierarchyXref> c3parUserHierarchyXrefList = c3parUser.getUserHierarchyList();
		if(c3parUserHierarchyXrefList!=null && c3parUserHierarchyXrefList.size()>0){
			for(C3parUserHierarchyXref c3parUserHierarchyXref : c3parUserHierarchyXrefList ){
				CitiHierarchyMaster citiHierarchyMaster = c3parUserHierarchyXref.getCitiHierarchyMaster();
				if(citiHierarchyMaster!=null){
					log.debug("ID: "+citiHierarchyMaster.getRegion().getName() + " - Name "+ citiHierarchyMaster.getSector().getName());
					entitlements.append(citiHierarchyMaster.getRegion().getName())
							.append("-").append(citiHierarchyMaster.getSector().getName())
							.append(",");
				}
			}
			if(!entitlements.equals("")){
				entitlements.deleteCharAt(entitlements.length()-1);
			}
			log.debug("Formated Entitlements with Region:"+entitlements.toString());
		}
		log.info("Exiting ManageusersListAdminController getEntitlements.");
		return entitlements.toString();
	}
	
	private String getKeyFromValue(Long id, Map<String, Long> securityRoleMap){
		for (String role : securityRoleMap.keySet()) {
		      if (securityRoleMap.get(role).equals(id)) {
		        return role;
		      }
		    }
		return "";
	}
	
	private Calendar getDateTimeInUTC(){
		TimeZone timeZone = TimeZone.getTimeZone(TIME_ZONE_UTC);
		Calendar calendar = Calendar.getInstance(timeZone);
		return calendar;
	}
	
}
