package com.citigroup.cgti.c3par.search.domain;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.bpm.ejb.rel.SearchRelationshipImpl;
import com.citigroup.cgti.c3par.bpm.ejb.search.ProxySearchImpl;
import com.citigroup.cgti.c3par.bpm.ejb.search.SearchProcessesImpl;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ApplicationSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.AppsenseSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ConIPAddressSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ConIPDetailsSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ConIPPairFWSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ConIPPortSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.GeneralSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.IPRegDetSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.OpeImpInputSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ProxySearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.SearchByContactAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.SecAclSearchAttributes;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

@SuppressWarnings( { "unchecked", "unused" })
//@Configurable
public class  SearchProcess{

//	private ClassPathXmlApplicationContext context;
	
	/*@Autowired
	private  ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl())esImpl  ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl());
	
	@Autowired
	private ccrBeanFactory.getProxySearchImpl()  ccrBeanFactory.getProxySearchImpl();

	@Autowired
	private ccrBeanFactory.getSearchRelationshipImpl() ccrBeanFactory.getSearchRelationshipImpl();

	@Autowired
	private ManageTIProcessImpl manageTIProcess;
	
	@Autowired
	private AgentViewPersistable agentViewPersistable;
	*/
	
	CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	

	/** The log. */
	private static Logger log = Logger.getLogger(SearchProcess.class);

	private ApplicationSearchAttributes applicationSearchAttributes;
	private ConIPDetailsSearchAttributes conIPDetailsSearchAttributes;
	private ConIPAddressSearchAttributes conIPAddressSearchAttributes;
	private ConIPPairFWSearchAttributes conIPPairFWSearchAttributes;
	private ConIPPortSearchAttributes conIPPortSearchAttributes;
	private SearchByContactAttributes searchByContactAttributes;
	private SecAclSearchAttributes secAclSearchAttributes;
	
	private GeneralSearchAttributes generalSearchAttributes;
	private IPRegDetSearchAttributes ipregDetSearchAttributes;
	private ProxySearchAttributes proxySearchAttribute;
	private AppsenseSearchAttributes appSenseSearchAttributes;
	private OpeImpInputSearchAttributes opeImpInputSearchAttributes;

	private List processList;
	private List proxyInstList;
	private List dataClassificationList;
	private List priorityList;
	private List taskActivityList;
	private List tptList;
	private List buList;
	private List tpaswgReviewStatusList;
	private List tpaswgReviewTypeList;
	private List region;
	private List appSenseInstanceList;
	private List sectorList;
	private List proxyRegionList;
	private Map searchTypeList;
	private List rolesList;
	private List taskTypeList;
	private List regionList;
	private List sectorList1;
	private List allRolesList;

	private Integer searchResultCount;
	private Integer pageNo;
	private Integer totalPages;
	private Integer searchRecordCount;
	private Integer pageSize;
	private Long selectedProcessId;
	private Long selectedRequestId;
	private String participantId;
	private String selectedProcessStatus;
	private String searchType;
	private String buFilter = null;
	private String tptFilter = null;
	private TIProcessDTO tiprocessDTO;
	private Long requestID;
	private String unlockErrorMsg;
	
	private boolean isECM = false;
	private boolean isParticipate = false;
	
	private String bmpInstanceId;
	private String bpmActivityId;
	private String activityId;
	private String taskName;
	private String taskCode;
	private boolean noResultsFound;
	private String activityStage;
	
	private CitiContact citiContact;

	/*public SearchProcess() throws Exception {
		log.info("SearchProcess.SearchProcess method Starts");
		 this.context = new ClassPathXmlApplicationContext(new String[] {
	    		 "ejbContext.xml",
		  "dataAccessContext.xml" });
		try {
			searchProcImpl = (SearchProcessesImpl)context.getBean("searchProcesses");
			log.debug("SearchProcess.SearchProcess: searchProcessesImpl object created successfully");
			
			proxySearchImpl = (ISearchProxy)context.getBean("proxySearch");
			log.debug("SearchProcess.SearchProcess: proxySearchImpl object created successfully");
			
			searchRelshipImpl = (ISearchRelationship)context.getBean("searchRelationship");
			log.debug("SearchProcess.SearchProcess: searchRelationshipImpl object created successfully");
			
			manageTIProcessImpl = (IManageTIProcess) context.getBean("manageTIProcessImpl");
			log.debug("SearchProcess.SearchProcess: manageTIProcessImpl object created successfully");

		} catch (Exception ex) {
			log
					.error("Exception occurred while getting SearchProcessesRemote :"
							+ ex.getMessage());
			throw new BusinessException(
					"Exception occurred while getting SearchProcessesRemote");
		}
		
		log.info("SearchProcess.SearchProcess method Ends");
	}*/
	

	public SearchByContactAttributes getSearchByContactAttributes() {
		return searchByContactAttributes;
	}

	public void setSearchByContactAttributes(
			SearchByContactAttributes searchByContactAttributes) {
		this.searchByContactAttributes = searchByContactAttributes;
	}
	
	public SecAclSearchAttributes getSecAclSearchAttributes() {
		return secAclSearchAttributes;
	}

	public void setSecAclSearchAttributes(
			SecAclSearchAttributes secAclSearchAttributes) {
		this.secAclSearchAttributes = secAclSearchAttributes;
	}
	
	public ConIPDetailsSearchAttributes getConIPDetailsSearchAttributes() {
		return conIPDetailsSearchAttributes;
	}

	public void setConIPDetailsSearchAttributes(
			ConIPDetailsSearchAttributes conIPDetailsSearchAttributes) {
		this.conIPDetailsSearchAttributes = conIPDetailsSearchAttributes;
	}
	
	public boolean isNoResultsFound() {
		return noResultsFound;
	}

	public String getTaskCode() {
		return taskCode;
	}

	public void setTaskCode(String taskCode) {
		this.taskCode = taskCode;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public void setNoResultsFound(boolean noResultsFound) {
		this.noResultsFound = noResultsFound;
	}

	public String getBmpInstanceId() {
		return bmpInstanceId;
	}

	public void setBmpInstanceId(String bmpInstanceId) {
		this.bmpInstanceId = bmpInstanceId;
	}

	public String getBpmActivityId() {
		return bpmActivityId;
	}

	public void setBpmActivityId(String bpmActivityId) {
		this.bpmActivityId = bpmActivityId;
	}
	/*public SearchProcessesImpl getSearchProcessesImpl() {
		return ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl());
	}*/

	public boolean isECM() {
		return isECM;
	}

	public void setECM(boolean isECM) {
		this.isECM = isECM;
	}

	public boolean isParticipate() {
		return isParticipate;
	}

	public void setParticipate(boolean isParticipate) {
		this.isParticipate = isParticipate;
	}


	

	public ManageTIProcessImpl getManageTIProcess() {
		return (ManageTIProcessImpl)ccrBeanFactory.getManageTIProcess();
	}

	public ProxySearchImpl getProxySearchImpl() {
		return ccrBeanFactory.getProxySearchImpl();
	}


	public SearchRelationshipImpl getSearchRelationshipImpl() {
		return ccrBeanFactory.getSearchRelationshipImpl();
	}

	public String getUnlockErrorMsg() {
		return unlockErrorMsg;
	}

	public void setUnlockErrorMsg(String unlockErrorMsg) {
		this.unlockErrorMsg = unlockErrorMsg;
	}
	
	

	public TIProcessDTO getTiprocessDTO() throws Exception {
		log.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getTiprocessDTO: request id is:" + getRequestID());

		if (getRequestID() != null && this.tiprocessDTO == null) {
			this.tiprocessDTO= ccrBeanFactory.getManageTIProcess().getProcessDTO(getRequestID(),taskCode,null);
		} 
		return this.tiprocessDTO;
	}

	public void setTiprocessDTO(TIProcessDTO tiprocessDTO) {
		this.tiprocessDTO = tiprocessDTO;
	}

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	public Map getSearchTypeList() {
		return searchTypeList;
	}

	public void setSearchTypeList(Map searchTypeList) {
		this.searchTypeList = searchTypeList;
	}

	public AppsenseSearchAttributes getAppSenseSearchAttributes() {
		return appSenseSearchAttributes;
	}

	public void setAppSenseSearchAttributes(
			AppsenseSearchAttributes appSenseSearchAttributes) {
		this.appSenseSearchAttributes = appSenseSearchAttributes;
	}

	public ApplicationSearchAttributes getApplicationSearchAttributes() {
		return applicationSearchAttributes;
	}

	public void setApplicationSearchAttributes(
			ApplicationSearchAttributes applicationSearchAttributes) {
		this.applicationSearchAttributes = applicationSearchAttributes;
	}

	public ConIPAddressSearchAttributes getConIPAddressSearchAttributes() {
		return conIPAddressSearchAttributes;
	}

	public void setConIPAddressSearchAttributes(
			ConIPAddressSearchAttributes conIPAddressSearchAttributes) {
		this.conIPAddressSearchAttributes = conIPAddressSearchAttributes;
	}

	public ConIPPairFWSearchAttributes getConIPPairFWSearchAttributes() {
		return conIPPairFWSearchAttributes;
	}

	public void setConIPPairFWSearchAttributes(
			ConIPPairFWSearchAttributes conIPPairFWSearchAttributes) {
		this.conIPPairFWSearchAttributes = conIPPairFWSearchAttributes;
	}

	public ConIPPortSearchAttributes getConIPPortSearchAttributes() {
		return conIPPortSearchAttributes;
	}

	public void setConIPPortSearchAttributes(
			ConIPPortSearchAttributes conIPPortSearchAttributes) {
		this.conIPPortSearchAttributes = conIPPortSearchAttributes;
	}

	public GeneralSearchAttributes getGeneralSearchAttributes() {
		return generalSearchAttributes;
	}

	public void setGeneralSearchAttributes(
			GeneralSearchAttributes generalSearchAttributes) {
		this.generalSearchAttributes = generalSearchAttributes;
	}

	public IPRegDetSearchAttributes getIpregDetSearchAttributes() {
		return ipregDetSearchAttributes;
	}

	public void setIpregDetSearchAttributes(
			IPRegDetSearchAttributes ipregDetSearchAttributes) {
		this.ipregDetSearchAttributes = ipregDetSearchAttributes;
	}

	public ProxySearchAttributes getProxySearchAttribute() {
		return proxySearchAttribute;
	}

	public void setProxySearchAttribute(
			ProxySearchAttributes proxySearchAttribute) {
		this.proxySearchAttribute = proxySearchAttribute;
	}

	public OpeImpInputSearchAttributes getOpeImpInputSearchAttributes() {
		return opeImpInputSearchAttributes;
	}

	public void setOpeImpInputSearchAttributes(
			OpeImpInputSearchAttributes opeImpInputSearchAttributes) {
		this.opeImpInputSearchAttributes = opeImpInputSearchAttributes;
	}

	

	public List getProxyInstList() throws Exception {
		if (getProxySearchAttribute() != null
				&& getProxySearchAttribute().getPrxChangeType() != null
				&& getProxySearchAttribute().getRegion() != null) {
			return ccrBeanFactory.getProxySearchImpl().getPrxInstanceNameList(
					getProxySearchAttribute().getPrxChangeType(),
					getProxySearchAttribute().getRegion());
		} else {
			return new ArrayList();
		}
	}

	public void setProxyInstList(List proxyInstList) {
		this.proxyInstList = proxyInstList;
	}

	public List getTptList() throws Exception {

		if ((getTptFilter() == null)
				|| (getTptFilter() != null && getTptFilter().isEmpty())) {
			return new ArrayList();
		} else {
			return ccrBeanFactory.getSearchRelationshipImpl().getThirdParty(getTptFilter());
		}
	}

	public void setTptList(List tptList) {
		this.tptList = tptList;
	}

	public List getBuList() throws Exception {

		if ((getBuFilter() == null)
				|| (getTptFilter() != null && getBuFilter().isEmpty())) {
			return new ArrayList();
		} else {
			return ccrBeanFactory.getSearchRelationshipImpl().getBusinessUnit(getBuFilter());
		}
	}

	public void setBuList(List buList) {
		this.buList = buList;
	}

	public List getTpaswgReviewStatusList() throws Exception {
		return ccrBeanFactory.getSearchRelationshipImpl().getTPASWGReviewStatus();
	}

	public void setTpaswgReviewStatusList(List tpaswgReviewStatusList) {
		this.tpaswgReviewStatusList = tpaswgReviewStatusList;
	}

	public List getTpaswgReviewTypeList() throws Exception {
		return ccrBeanFactory.getSearchRelationshipImpl().getTPASWGReviewType();
	}

	public void setTpaswgReviewTypeList(List tpaswgReviewTypeList) {
		this.tpaswgReviewTypeList = tpaswgReviewTypeList;
	}

	public List getAppSenseInstanceList() throws Exception {
		/*log.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getAppSenseInstanceList : ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl())esRemote.getProxyInstance()"
				+ ccrBeanFactory.getProxySearchImpl().getProxyInstance());*/
		return ccrBeanFactory.getProxySearchImpl().getProxyInstance();
	}

	public void setAppSenseInstanceList(List appSenseInstanceList) {
		this.appSenseInstanceList = appSenseInstanceList;
	}

	public List getSectorList() throws Exception {
		if ((getGeneralSearchAttributes() != null)
				&& (getGeneralSearchAttributes().getRegion() != null)) {
			log
					.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getSectorList:GeneralSearchAttributes and Region are not null");
			return ccrBeanFactory.getSearchRelationshipImpl()
					.getSector(getGeneralSearchAttributes().getRegion());
		} else {
			return new ArrayList();
		}
	}

	public void setSectorList(List sectorList) {
		this.sectorList = sectorList;
	}

	public List getProxyRegionList() throws Exception {

		if (getProxySearchAttribute() != null
				&& getProxySearchAttribute().getPrxChangeType() != null) {
			/*log
					.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getProxySearchAttribute  getPrxChangeType are not null:"
							+ getProxySearchAttribute().getPrxChangeType());*/
			return ccrBeanFactory.getProxySearchImpl()
					.getProxyRegion(getProxySearchAttribute()
							.getPrxChangeType());
		} else {
			return new ArrayList();
		}
	}

	public void setProxyRegionList(List proxyRegionList) {
		this.proxyRegionList = proxyRegionList;
	}

	public Integer getSearchResultCount() {
		return searchResultCount;
	}

	public void setSearchResultCount(Integer searchResultCount) {
		this.searchResultCount = searchResultCount;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(Integer totalPages) {
		this.totalPages = totalPages;
	}

	public Long getSelectedProcessId() {
		return selectedProcessId;
	}

	public void setSelectedProcessId(Long selectedProcessId) {
		this.selectedProcessId = selectedProcessId;
	}

	public Long getSelectedRequestId() {
		return selectedRequestId;
	}

	public void setSelectedRequestId(Long selectedRequestId) {
		this.selectedRequestId = selectedRequestId;
	}

	public String getParticipantId() {
		return participantId;
	}

	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}

	public String getSelectedProcessStatus() {
		return selectedProcessStatus;
	}

	public void setSelectedProcessStatus(String selectedProcessStatus) {
		this.selectedProcessStatus = selectedProcessStatus;
	}

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public String getBuFilter() {
		return buFilter;
	}

	public void setBuFilter(String buFilter) {
		this.buFilter = buFilter;
	}

	public String getTptFilter() {
		return tptFilter;
	}

	public void setTptFilter(String tptFilter) {
		this.tptFilter = tptFilter;
	}

	public List getPriorityList() throws Exception {
		List list = ccrBeanFactory.getSearchRelationshipImpl().getPriority();
		if (list == null) {
			list = new ArrayList();
		}
		return list;
	}

	public void setPriorityList(List priorityList) {
		this.priorityList = priorityList;
	}

	public List getTaskActivityList() throws Exception {
		List list = ccrBeanFactory.getSearchRelationshipImpl().getTaskList();
		if (list == null) {
			list = new ArrayList();
		}
		return list;
	}

	public void setTaskActivityList(List taskActivityList) {
		this.taskActivityList = taskActivityList;
	}
	
	public List getRolesList() throws Exception {
 		List list = ccrBeanFactory.getSearchProcess().getMyTaskContactPageDropdownList(generalSearchAttributes, ccrBeanFactory.getSearchProcess().LISTTYPE_ROLE);
		if (list == null) {
			list = new ArrayList();
		}
		return list;
	}

	public void setRolesList(List rolesList) {
		this.rolesList = rolesList;
	}
	
	public List getTaskTypeList() throws Exception {
	 
		List list = (ccrBeanFactory.getSearchProcess()).getMyTaskContactPageDropdownList(generalSearchAttributes, ccrBeanFactory.getSearchProcess().LISTTYPE_TASK);
		if (list == null) {
			list = new ArrayList();
		}
		return list;
	}

	public void setTaskTypeList(List taskTypeList) {
		this.taskTypeList = taskTypeList;
	}

	public List getRegion() throws Exception {
		List list = ccrBeanFactory.getSearchRelationshipImpl().getRegion();
		if (list == null) {
			list = new ArrayList();
		}
		return list;
	}

	public void setRegion(List region) {
		this.region = region;
	}
	
	public List getRegionList() throws Exception {
		List list = ccrBeanFactory.getSearchProcess().getMyTaskContactPageDropdownList(generalSearchAttributes, ccrBeanFactory.getSearchProcess().LISTTYPE_REGION);
		if (list == null) {
			list = new ArrayList();
		}
		return list;
	}

	public void setRegionList(List regionList) {
		this.regionList = regionList;
	}

	public List getSectorList1() throws Exception {
		List list =  ccrBeanFactory.getSearchProcess().getMyTaskContactPageDropdownList(generalSearchAttributes, ccrBeanFactory.getSearchProcess().LISTTYPE_SECTOR);
		if (list == null) {
			list = new ArrayList(); 
		}
		return list;
	}

	public void setSectorList1(List sectorList1) {
		this.sectorList1 = sectorList1;
	}


	public List getDataClassificationList() throws Exception {
		List list = ccrBeanFactory.getSearchRelationshipImpl().getDataClassification();
		if (list == null) {
			list = new ArrayList();
		}
		return list;
	}

	public void setDataClassificationList(List dataClassificationList) {
		this.dataClassificationList = dataClassificationList;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getSearchRecordCount() throws Exception {
		int searchRecordCount = 0;
		if(getSearchType().equals("MY_TASK")&& generalSearchAttributes.getRequesterSOEId() != null
				&& !generalSearchAttributes.getRequesterSOEId().equals("")){
		 
			 
			log.debug("Inside SearchProcess.getSearchRecordCount:getSearchType():"+getSearchType()+"generalSearchAttributes.getRequesterSOEId()::"+
					generalSearchAttributes.getRequesterSOEId());
		 
	 
			searchRecordCount = ccrBeanFactory.getSearchProcess().getMyTaskRecordCount(generalSearchAttributes.getRequesterSOEId(), 0, 0);
			 
			 
			return searchRecordCount;
		}
		else if(getSearchType().equals("MY_TASK_CONTACTS")&& generalSearchAttributes.getRequesterSOEId() != null
				&& !generalSearchAttributes.getRequesterSOEId().equals("")){
			 
			 
			log.debug("Inside SearchProcess.getSearchRecordCount for Contacts:getSearchType():"+getSearchType()+"generalSearchAttributes.getRequesterSOEId()::"+
					generalSearchAttributes.getRequesterSOEId());
			 
			 
			searchRecordCount = ccrBeanFactory.getSearchProcess().getMyTaskContactRecordCount(generalSearchAttributes, 0, 0);
			 
			return searchRecordCount;
		}else if (getSearchType().equals("GENERAL") && generalSearchAttributes != null) {
			searchRecordCount = ccrBeanFactory.getSearchProcess().getGeneralSearchRecordCount(generalSearchAttributes);
			return searchRecordCount;
		}else if (getSearchType().equals("APPLICATION") && applicationSearchAttributes != null) {
			searchRecordCount = ccrBeanFactory.getSearchProcess().getGeneralSearchApplicationRecordCount(applicationSearchAttributes);
			return searchRecordCount;
		}else if (getSearchType().equals("CON_IP_DETAILS") && conIPDetailsSearchAttributes != null) {
			searchRecordCount = ccrBeanFactory.getSearchProcess().getGeneralSearchIpFwPrPcRecordCount(conIPDetailsSearchAttributes);
			return searchRecordCount;
		}
		else if (getSearchType().equals("SEARCH_BY_CONTACT")
				&& searchByContactAttributes != null) {
			searchRecordCount = ccrBeanFactory.getSearchProcess()
					.getGeneralSearchCnRgScPcAppRecordCount(
							searchByContactAttributes);
			return searchRecordCount;
		}
		else if (getSearchType().equals("SEC_ACL")
				&& secAclSearchAttributes != null) {
			searchRecordCount = ccrBeanFactory.getSearchProcess()
					.getGeneralSearchSecAclRecordCount(
							secAclSearchAttributes);
			return searchRecordCount;
		}
		else if (getSearchType().equals("CON_IP_ADDRESS")
				&& conIPAddressSearchAttributes != null) {
			searchRecordCount = ccrBeanFactory.getSearchProcess()
					.getGeneralSearchIpRecordCount(
							conIPAddressSearchAttributes);
			return searchRecordCount;
		} else if (getSearchType().equals("CON_IP_PAIR_FW")
				&& conIPPairFWSearchAttributes != null) {
			searchRecordCount = ccrBeanFactory.getSearchProcess()
					.getGeneralSearchPolicyRecordCount(conIPPairFWSearchAttributes);
			return searchRecordCount;
		} else if (getSearchType().equals("CON_IP_PAIR_PORT")
				&& conIPPortSearchAttributes != null) {
			searchRecordCount = ccrBeanFactory.getSearchProcess()
					.getGeneralSearchPortRecordCount(conIPPortSearchAttributes);
			return searchRecordCount;
		} else if (getSearchType().equals("IP_REG")
				&& ipregDetSearchAttributes != null) {
			searchRecordCount =ccrBeanFactory.getSearchProcess()
					.getSearchRecordCount(ipregDetSearchAttributes, 0, 0);
			return searchRecordCount;
		} else if (getSearchType().equals("OP_IMP")
				&& opeImpInputSearchAttributes != null) {
			searchRecordCount = ccrBeanFactory.getSearchProcess()
					.getGeneralSearchOpeImpRecordCount(
							opeImpInputSearchAttributes);
			return searchRecordCount;
		} else if (getSearchType().equals("APPSENSE")
				&& appSenseSearchAttributes != null) {
			searchRecordCount = ccrBeanFactory.getSearchProcess()
					.getGeneralSearchAppsenseRecordCount(appSenseSearchAttributes);
			return searchRecordCount;
		} else if (getSearchType().equals("PROXY")
				&& proxySearchAttribute != null) {
			searchRecordCount =ccrBeanFactory.getSearchProcess()
					.getGeneralSearchProxyRecordCount(proxySearchAttribute);
			return searchRecordCount;
		} else {
			return searchRecordCount;
		}
	}

	public void setSearchRecordCount(Integer searchRecordCount) {
		this.searchRecordCount = searchRecordCount;
	}

	
	public List getProcessList() throws Exception {
		return getProcessList(0);
	}
	
	
	public List getProcessList(int recCnt) throws Exception {
		log.info(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getProcessList method started: ");
		log.debug("Inside the  ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getProcessList pagesize and pageno:"
				+ getPageSize() + ":" + getPageNo());
		if (getSearchType().equals("MY_TASK")
				&& generalSearchAttributes.getRequesterSOEId() != null 
				&& !generalSearchAttributes.getRequesterSOEId().equals("")) {
		 
			processList =  ccrBeanFactory.getSearchProcess().getMyTaskSearchResult(
					generalSearchAttributes.getRequesterSOEId(), getPageSize(), getPageNo());
			log.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getProcessList method ProcessList Size: "
					+ processList.size());
			log.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getProcessList method started: ");
			 
			return processList;

		}else if (getSearchType().equals("MY_TASK_CONTACTS")
				&& generalSearchAttributes.getRequesterSOEId() != null 
				&& !generalSearchAttributes.getRequesterSOEId().equals("")) {
			 
			 
			 
	 
			processList =   ccrBeanFactory.getSearchProcess().getMyContactTaskSearchResult(
					generalSearchAttributes, getPageSize(), getPageNo(),recCnt);
			log.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getProcessList method ProcessList Size: "
					+ processList.size());
			log.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getProcessList method started: ");
			 
			return processList;

		}else if (getSearchType().equals("GENERAL")
				&& generalSearchAttributes != null) {
			log
					.debug("Inside the  ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getProcessList pagesize and pageno:"
							+ getPageSize() + ":" + getPageNo());
			processList =  ccrBeanFactory.getSearchProcess().getGeneralSearchRecord(
					generalSearchAttributes, getPageSize(), getPageNo(),recCnt);
			log.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getProcessList method ProcessList Size: "
					+ processList.size());
			log.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).getProcessList method started: ");
			return processList;
		} else if (getSearchType().equals("APPLICATION")
				&& applicationSearchAttributes != null) {
			log
					.debug("Before appliation search Result:getPageSize(), getPageNo():"
							+ getPageSize() + ":" + getPageNo());
			processList =  ccrBeanFactory.getSearchProcess().getGeneralSearchApplicationResult(
					applicationSearchAttributes, getPageSize(), getPageNo(),recCnt);
			return processList;
		} else if (getSearchType().equals("CON_IP_DETAILS")
				&& conIPDetailsSearchAttributes != null) {
			processList =  ccrBeanFactory.getSearchProcess().getGeneralSearchIpFwPrPcResult(
					conIPDetailsSearchAttributes, getPageSize(), getPageNo(),recCnt);
			return processList;
		
		} else if (getSearchType().equals("CON_IP_ADDRESS")
				&& conIPAddressSearchAttributes != null) {
			processList =  ccrBeanFactory.getSearchProcess().getGeneralSearchIpResult(
					conIPAddressSearchAttributes, getPageSize(), getPageNo(),recCnt);
			return processList;
		} else if (getSearchType().equals("SEARCH_BY_CONTACT")
				&& searchByContactAttributes != null) {
			processList = ccrBeanFactory.getSearchProcess()
					.getGeneralSearchCnRgScPcAppResult(
							searchByContactAttributes, getPageSize(), getPageNo(),recCnt);
			return processList;
		} else if (getSearchType().equals("SEC_ACL")
				&& secAclSearchAttributes != null) {
			processList =   ccrBeanFactory.getSearchProcess()
					.getGeneralSearchSecAclResult(
							secAclSearchAttributes, getPageSize(), getPageNo(),recCnt); 
			return processList;
		} else if (getSearchType().equals("CON_IP_PAIR_FW")
				&& conIPPairFWSearchAttributes != null) {
			processList = ccrBeanFactory.getSearchProcess().getGeneralSearchPolicyResult(
					conIPPairFWSearchAttributes, getPageSize(), getPageNo(),recCnt);
			return processList;
		} else if (getSearchType().equals("CON_IP_PAIR_PORT")
				&& conIPPortSearchAttributes != null) {
			processList =  ccrBeanFactory.getSearchProcess().getGeneralSearchPortResult(
					conIPPortSearchAttributes, getPageSize(), getPageNo(),recCnt);
			return processList;
		} else if (getSearchType().equals("IP_REG")
				&& ipregDetSearchAttributes != null) {
			processList =  ccrBeanFactory.getSearchProcess().getSearchResult(
					ipregDetSearchAttributes, getPageSize(), getPageNo());
			return processList;
		} else if (getSearchType().equals("OP_IMP")
				&& opeImpInputSearchAttributes != null) {
			processList =  ccrBeanFactory.getSearchProcess().getGeneralSearchOpeImpResult(
					opeImpInputSearchAttributes, getPageSize(), getPageNo(),recCnt);
			return processList;
		} else if (getSearchType().equals("APPSENSE")
				&& appSenseSearchAttributes != null) {
			processList =  ccrBeanFactory.getSearchProcess().getGeneralSearchAppsenseResult(
					appSenseSearchAttributes, getPageSize(), getPageNo(),recCnt);
			return processList;
		} else if (getSearchType().equals("PROXY")
				&& proxySearchAttribute != null) {
			processList =  ccrBeanFactory.getSearchProcess().getGeneralSearchProxyResult(
					proxySearchAttribute, getPageSize(), getPageNo(),recCnt);
			return processList;
		} else {
			return new ArrayList();
		}
	}

	public void setProcessList(List processList) {
		this.processList = processList;
	}

	public List getAllRolesList() throws Exception {
		return  ccrBeanFactory.getSearchProcess().getAllRolesList();
	}

	public void setAllRolesList(List allRolesList) {
		this.allRolesList = allRolesList;
	}
	
	public void validate(String message) throws Exception {
		throw new Exception(message);
	}


	public CitiContact getCitiContact() {
		log.debug(" ((SearchProcessesImpl)ccrBeanFactory.getSearchProcessesImpl()).CitiContact: request id is:" + getRequestID());
		if (getRequestID() != null && this.citiContact == null && this.tiprocessDTO !=null) {
			this.citiContact=  ccrBeanFactory.getSearchProcess().getBusinessOwnerDetails(getRequestID(),this.tiprocessDTO.getRelationshipType());
		} 
		return this.citiContact;
	}

	public void setCitiContact(CitiContact citiContact) {
		this.citiContact = citiContact;
	}

	public int updateCmpId(String cmpOrderId,Long tireqId)  {
		return ccrBeanFactory.getAgentViewPersistable().updateCmpId(cmpOrderId,tireqId);
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getActivityStage() {
		return activityStage;
	}

	public void setActivityStage(String activityStage) {
		this.activityStage = activityStage;
	}

 }
