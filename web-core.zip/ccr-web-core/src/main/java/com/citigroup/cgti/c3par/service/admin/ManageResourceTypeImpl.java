package com.citigroup.cgti.c3par.service.admin;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.admin.domain.soc.persist.ManageResourceTypePersistable;
import com.citigroup.cgti.c3par.common.domain.ProxyDeviceName;
import com.citigroup.cgti.c3par.common.domain.ProxyLocation;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;

/*
 * @nc43495
 */

@SuppressWarnings("unchecked")
@Transactional
public class ManageResourceTypeImpl extends BasePersistanceImpl implements ManageResourceTypePersistable {
	
	/** The log. */
	private static Logger log = Logger.getLogger(DonotSendMailServiceImpl.class);
	
	//To retrieve resource type list
	@Override
	@Transactional(readOnly = true)
	public List<ResourceType> getResourceType(){
		log.info("ResourceTypeImpl :: getResourceType starts here ...");
		Session session = getSession();
		Criteria criteria = session.createCriteria(ResourceType.class);
		List<ResourceType> list = criteria.list();
		criteria.addOrder(Order.asc("perimeter"));
		criteria.addOrder(Order.asc("name"));
		log.debug("ResourceTypeImpl :: getResourceType"+list);
		if(list != null)
			log.info("ResourceTypeImpl :: getResourceType :: ends here ::"+list.size());	
		return list;
	}

	//To add new Resource Type
	@Override
	public void addResourceType(ResourceType resourceType,String userID){
		log.info("ResourceTypeImpl:addResourceType ::"+resourceType.getName());
		Session session = getSession();
			ResourceType resType=new ResourceType();
			resType.setName(resourceType.getName());
			resType.setPerimeter(resourceType.getPerimeter());
			resType.setCreatedBy(userID.toLowerCase());
			resType.setStatus("Active");
			resType.setCreated_date(new Date());
			resType.setBroadAccessIp("");
			resType.setModifiedBy(userID.toLowerCase());
			resType.setUpdated_date(new Date());
			session.saveOrUpdate(resType);
		log.info("ResourceTypeImpl:addResourceType ends here ..");
	}
	
	
	//To update Resource type
	@Override
	public void updateResourceType(String id,String status,String userID){
		log.info("ResourceTypeImpl :: updateResourceType starts here ..."+status+"id"+id+"userID"+userID);
		Session session = getSession();
		SQLQuery sqlQuery = session.createSQLQuery("update resourcetype set status='"+status+"',MODIFIED_BY='"+userID.toLowerCase()+"',MODIFIED_DATE=sysdate where id="+id);
		sqlQuery.executeUpdate();
		log.info("ResourceTypeImpl :: updateResourceType query"+sqlQuery);
		
	}
	
	//To retrieve resource type list
	@Override
	@Transactional(readOnly = true)
	public List<ProxyDeviceName> getProxyDeviceNames() {
		log.info("ResourceTypeImpl :: getProxyDeviceNames starts here ...");
		Session session = getSession();
		Criteria criteria = session.createCriteria(ProxyDeviceName.class);
		List<ProxyDeviceName> list = criteria.list();
		criteria.addOrder(Order.desc("id"));
		//criteria.addOrder(Order.asc("name"));
		log.debug("ResourceTypeImpl :: getProxyDeviceNames"+list);
		if(list != null)
			log.info("ResourceTypeImpl :: getProxyDeviceNames :: ends here ::"+list.size());	
		return list;
	}

	
	@Override
	@Transactional(readOnly = true)
	public List<ProxyLocation> getProxyLocations() {
		log.info("ResourceTypeImpl :: getProxyLocations starts here ...");
		Session session = getSession();
		Criteria criteria = session.createCriteria(ProxyLocation.class);
		List<ProxyLocation> list = criteria.list();
		//criteria.addOrder(Order.asc("perimeter"));
		//criteria.addOrder(Order.asc("name"));
		log.debug("ResourceTypeImpl :: getProxyLocations"+list);
		if(list != null)
			log.info("ResourceTypeImpl :: getProxyLocations :: ends here ::"+list.size());	
		return list;
	}
	
	//To update ProxyDeviceName
	@Override
	public boolean updateProxyDeviceName(ProxyDeviceName proxyDeviceName) {
		log.info("ResourceTypeImpl:updateProxyDeviceName :: starts");
		
		if (!(proxyDeviceName != null && proxyDeviceName.getId() != null && proxyDeviceName.getId().intValue() > 0)) {
		Session session = getSession();
		Query query = null;
		if (proxyDeviceName.getInstanceName() != null && !proxyDeviceName.getInstanceName().isEmpty()) {
			query = session.createQuery("from ProxyDeviceName where proxyLocation.id = ? and " +
					"policyName = ? and instanceName = ? and deviceName = ?").setLong(0, proxyDeviceName.getProxyLocation().getId())
					.setString(1, proxyDeviceName.getPolicyName()).setString(2, proxyDeviceName.getInstanceName())
					.setString(3, proxyDeviceName.getDeviceName());
		} else {
			query = session.createQuery("from ProxyDeviceName where proxyLocation.id = ? and " +
					"policyName = ? and deviceName = ?").setLong(0, proxyDeviceName.getProxyLocation().getId())
					.setString(1, proxyDeviceName.getPolicyName()).setString(2, proxyDeviceName.getDeviceName());
		}
		
		List<ProxyDeviceName> deviceNames = (List<ProxyDeviceName>) query.list();

		if (deviceNames != null && deviceNames.size() > 0) {
			return true;
		}
		}
		
		getHibernateTemplate().saveOrUpdate(proxyDeviceName);
		log.info("ResourceTypeImpl:updateProxyDeviceName ends here ..");
		return false;
		
	}
	
	//To load ProxyDeviceName
	/**
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public ProxyDeviceName loadProxyDeviceName(Long id) {
		log.info("ResourceTypeImpl:updateProxyDeviceName :: starts");
		Session session = getSession();
		return (ProxyDeviceName)session.createQuery("from ProxyDeviceName where id = "+id).uniqueResult();
	}
	
	//To delete ProxyDeviceName
	/**
	 * 
	 */
	@Override
	public void deleteProxyDeviceName(Long id) {
		log.info("ResourceTypeImpl:deleteProxyDeviceName :: starts");
		Session session = getSession();
		ProxyDeviceName deviceName = (ProxyDeviceName)session.get(ProxyDeviceName.class, id);
		getHibernateTemplate().delete(deviceName);
	}
	
}
