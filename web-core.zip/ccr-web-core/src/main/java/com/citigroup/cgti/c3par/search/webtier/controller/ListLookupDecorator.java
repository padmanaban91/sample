package com.citigroup.cgti.c3par.search.webtier.controller;

import org.apache.log4j.Logger;
import org.displaytag.decorator.TableDecorator;

import com.citigroup.cgti.c3par.webtier.forms.ListLookupsForm;

public class ListLookupDecorator extends TableDecorator  {
	
	
	private static Logger log = Logger.getLogger(ListLookupDecorator.class);
	 
	  
		public String getIds()
		   {
		     
		    ListLookupsForm cuurentRowObj= (ListLookupsForm) getCurrentRowObject();
		    String lookUpVal="" ;
            String lookUpid="";
		    lookUpVal = cuurentRowObj.getLookupValue(); 
		    lookUpid = cuurentRowObj.getIds(); 
		   
		    
		   String contextPath= this.getPageContext().getServletContext().getContextPath();

		    return "<a href=\""+contextPath+"/loadEditLookupsController.act?lookUpValue=" + lookUpVal+"&lookUpID="+lookUpid+ " \">Edit</a>";
		   }

	     

}
