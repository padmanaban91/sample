package com.citigroup.cgti.c3par.controller.businessjustification;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiResource;
import com.citigroup.cgti.c3par.businessjustification.domain.SearchInCSIProcess;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.soa.model.ApplicationDetailEntity;
import com.citigroup.cgti.c3par.soa.model.ProfileEntity;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaImpl.softwareAssetInfo.SoftwareAssetInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;
import com.citigroup.cgti.c3par.soa.softwareasset.ApplicationInfoType;
import com.citigroup.cgti.c3par.webtier.helper.CSIUtil;
import com.sun.xml.ws.fault.ServerSOAPFaultException;


/**
 * The Class SearchInCSIController.
 */
@Controller
public class SearchInCSIController {

	/** The Constant QUERY_MESSAGE. */
    public static final String QUERY_MESSAGE = "connection.csi.querymessage" ;
    public static final String QUERY_ERROR = "application.csi.queryerror" ;

    /** The log. */
    private static Logger log = Logger.getLogger(SearchInCSIController.class);
    
    @Autowired
	private CSIUtil csiUtil;

    @RequestMapping(value = "/loadCSISearch.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(HttpServletRequest request, ModelMap model){
    	String module = request.getParameter("module");
		log.info("SearchInCSIController starts here..");
		SearchInCSIProcess searchInCSIProcess = new SearchInCSIProcess();
		model.addAttribute("searchInCSIProcess",searchInCSIProcess);
		log.info("SearchInCSIController ends here..");
		if ("managenetwork".equals(module)) {
			return "pages/businessjustification/searchInCSI";
		} else {
			return "pages/businessjustification/searchInCSIPopup";
		}
	}
    
    @RequestMapping(value = "/searchInCSI.act", method = {RequestMethod.GET,RequestMethod.POST})
   	public String searchInRits(ModelMap model,@ModelAttribute("searchInCSIProcess") SearchInCSIProcess searchInCSIProcess, 
   			HttpServletRequest request, BindingResult result){
    	String module = request.getParameter("module");
    	boolean isWebService = false;
    	List<ApplicationInfoType> infoType = null;
    	CitiResource citiResource = null;
 	    List<CitiResource> citiResources = null;
   		log.info("SearchInCSIController starts here..");
   		
   		try {
   			isWebService = csiUtil.isWebServiceFlag();
   			
   			ApplicationDetailEntity applicationDetailEntity = new ApplicationDetailEntity();
   			
	 	    if(searchInCSIProcess.getAcronym() != null && !searchInCSIProcess.getAcronym().trim().equals(""))
	 		applicationDetailEntity.setAcronym(searchInCSIProcess.getAcronym());
	 	    if(searchInCSIProcess.getApplicationId() != null && !searchInCSIProcess.getApplicationId().trim().equals(""))
	 		applicationDetailEntity.setAppId(searchInCSIProcess.getApplicationId());
	 	    if(searchInCSIProcess.getApplicationName() != null && !searchInCSIProcess.getApplicationName().trim().equals(""))
	 		applicationDetailEntity.setAppName(searchInCSIProcess.getApplicationName());
   			
   			log.info("SearchInCSIController : isWebService : "+isWebService);
   			if(isWebService)
   			{
		   		SOADataComponent soaDataComponent = new SOADataComponent();
		 	    SoftwareAssetInfoFactory softwareAssetInfoFactory = (SoftwareAssetInfoFactory)
		 	    soaDataComponent.getServiceFactory("softwareAssetInfo");
		 	    infoType =
		 		softwareAssetInfoFactory.getCSIService().getApplicationDetails(applicationDetailEntity,request.getHeader("SM_USER"));	 	    
   			}
   			else
   			{
   				log.info("Calling getApplicationDetailsFromCSIDB!");
   				infoType = csiUtil.searchApplicationDetailsFromCSIDB(applicationDetailEntity);
   			}
   			if(infoType!=null)
   			{
   				log.info("infoType is not null after Calling getApplicationDetailsFromCSIDB!");
		 	    citiResources = new ArrayList<CitiResource>();		
		 	    for (ApplicationInfoType element : infoType) {
			 	    citiResource = new CitiResource();
			 		String acronym=element.getIdentificationInfo().getAcronym();
			 		log.info("acronym : "+acronym);
			 		if( acronym==null || (acronym!=null &&(acronym.length()==0 || acronym.equals("")||acronym.equalsIgnoreCase("NULL"))))
			 		    citiResource.setName(element.getIdentificationInfo().getProductName());
			 		else {
			 			citiResource.setName(acronym);
			 		}
			 		log.info("Name : "+citiResource.getName());
			 		citiResource.setIpAddress(element.getTechnicalInfo().getHostName());
			 		log.info("IpAddress : "+citiResource.getIpAddress());
			 		citiResource.setCriticality(element.getBusinessInfo().getBusinessCriticality().toUpperCase());
			 		log.info("Criticality : "+citiResource.getCriticality());
			 		citiResource.setClassification(element.getSecurityInfo().getSecurityClassification().toUpperCase());
			 		log.info("Classification : "+citiResource.getClassification());
			 		citiResource.setCwhiId(element.getIdentificationInfo().getSIMONAppID());
			 		log.info("CwhiId : "+citiResource.getCwhiId());
			 		citiResource.setFunctionalityDescription(element.getBusinessFunctionality().getPrimaryFunctions());
			 		log.info("FunctionalityDescription : "+citiResource.getFunctionalityDescription());
			 		citiResource.setOwnerid(element.getBusinessInfo().getBusinessOwnerID());
			 		log.info("Ownerid : "+citiResource.getOwnerid());
			 		citiResource.setOwner(element.getBusinessInfo().getBusinessOwnerName().getNameValue());
			 		log.info("Owner : "+citiResource.getOwner());
			 		citiResource.setAppManagerFullName(element.getManagersInfo().getProductManagerName().getNameValue());
			 		log.info("AppManagerFullName : "+citiResource.getAppManagerFullName());
			 		citiResource.setAppManagerGEID(element.getManagersInfo().getProductManagerID());
			 		log.info("AppManagerGEID : "+citiResource.getAppManagerGEID());
			 		citiResource.setPersonalDataIndicator(element.getSecurityInfo().getPersonalDataIndicator());
			 		log.info("PersonalDataIndicator : "+citiResource.getPersonalDataIndicator());
			 		citiResources.add(citiResource);
		 	    }
   			}
	 	   request.getSession().setAttribute("CITI_RESOURCES_LIST", citiResources);
	 	   searchInCSIProcess.setCitiResourceList(citiResources);
	 	   
   		} catch(Exception e) {
   			log.error(e.toString(),e);
   			if (e instanceof ServerSOAPFaultException){
   				log.error("SOAPFaultException received..!!!");
				ObjectError error= new ObjectError("name",ECMConstants.ERROR_MSG_SOA);
				result.addError(error);
			}
   		}
   		model.addAttribute("searchInCSIProcess", searchInCSIProcess);
   		log.info("SearchInCSIController ends here..");
   		if ("managenetwork".equals(module)) {
			return "pages/businessjustification/searchInCSI";
		} else {
			return "pages/businessjustification/searchInCSIPopup";
		}
   	}


    @RequestMapping(value = "/selectCSIApplicationMN.act", method = {RequestMethod.GET,RequestMethod.POST})
   	public String selectCSIApplicationModelMN(ModelMap model,@ModelAttribute("searchInCSIProcess") SearchInCSIProcess searchInCSIProcess, 
		HttpServletRequest request, BindingResult result){
    	
    	String module = request.getParameter("module");
    	log.info("select CSI ----");
    	boolean isWebService = false;
    	List<CitiContact> citiContactList = null;
    	try {
		isWebService = csiUtil.isWebServiceFlag();
       	log.debug("isWebService ----> : "+isWebService);
		List<CitiResource> citiResourceList = (List<CitiResource>)request.getSession().getAttribute("CITI_RESOURCES_LIST");
		 
		 String selectedId = searchInCSIProcess.getSelectedId();
		 
		 log.debug("selectedId ----"+selectedId);
		 CitiResource selected  = null;
		 for (CitiResource citiResource : citiResourceList) {
			 if (selectedId.equals(citiResource.getCwhiId())) {
				 selected = citiResource;
				 break;
			 }
		 }
		 
		if (selected != null && selected.getOwnerid() != null && !selected.getOwnerid().isEmpty()) {
			if(isWebService) {
			SOADataComponent soaDataComponent = new SOADataComponent();	
			ProfileInfoFactory profileInfoFactory =
			    (ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");	
			ProfileEntity profileEntity = new ProfileEntity();
			profileEntity.setRitzId(selected.getOwnerid());
				citiContactList = profileInfoFactory.getRitzService().getProfile(profileEntity, request.getHeader("SM_USER"));
			} else {				
				citiContactList = csiUtil.getEmailIdFromCSIDB(selected.getOwnerid());
			}
	
			Iterator it = citiContactList.iterator();
			while(it.hasNext()) {
			    CitiContact entity = (CitiContact) it.next();
			    request.getSession().setAttribute("APP_OWNER_EMAIL", entity.getEmail());
			    log.info("OWNER EMAIL :" +entity.getEmail());
			    break;
			}
		}
		
		if (selected != null && selected.getAppManagerGEID() != null && !selected.getAppManagerGEID().isEmpty()) {
			if(isWebService) {
				SOADataComponent soaDataComponent = new SOADataComponent();	
				ProfileInfoFactory profileInfoFactory =
				    (ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");	
				ProfileEntity profileEntity = new ProfileEntity();
				profileEntity.setRitzId(selected.getAppManagerGEID());
				citiContactList = profileInfoFactory.getRitzService().getProfile(profileEntity, request.getHeader("SM_USER"));
			} else {				
				citiContactList = csiUtil.getEmailIdFromCSIDB(selected.getAppManagerGEID());
			}
			Iterator it = citiContactList.iterator();
			while(it.hasNext()) {
			    CitiContact entity = (CitiContact) it.next();
			    request.getSession().setAttribute("APP_MGR_EMAIL", entity.getEmail());
			    log.info("MANAGER EMAIL :" +entity.getEmail());
			    selected.setAppManagerEmail( entity.getEmail());
			    break;
			}
		}
		
		 request.getSession().setAttribute("COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY", selected);
		} catch(Exception e) {
		    log.error(e,e);
		}
		return "forward:/loadCSIDetails.act";
	
    }
    
    @RequestMapping(value = "/selectCSIApplication.act", method = {RequestMethod.GET,RequestMethod.POST})
   	public @ResponseBody String selectCSIApplicationModel(ModelMap model,@ModelAttribute("searchInCSIProcess") SearchInCSIProcess searchInCSIProcess, 
		HttpServletRequest request, BindingResult result){
    	
    	log.info("select CSI ----");
    	boolean isWebService = false;
    	List<CitiContact> citiContactList = null;
    	try {
       	isWebService = csiUtil.isWebServiceFlag();
       	log.debug("isWebService ----> : "+isWebService);
		List<CitiResource> citiResourceList = (List<CitiResource>)request.getSession().getAttribute("CITI_RESOURCES_LIST");
		 
		 String selectedId = searchInCSIProcess.getSelectedId();
		 
		 log.debug("selectedId ----> : "+selectedId);
		 CitiResource selected  = null;
		 for (CitiResource citiResource : citiResourceList) {
			 if (selectedId.equals(citiResource.getCwhiId())) {
				 selected = citiResource;
				 break;
			 }
		 }
		 
		if (selected != null && selected.getOwnerid() != null && !selected.getOwnerid().isEmpty()) {			
			if(isWebService) {
				SOADataComponent soaDataComponent = new SOADataComponent();				
				ProfileInfoFactory profileInfoFactory =
				    (ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");		
				ProfileEntity profileEntity = new ProfileEntity();
				profileEntity.setRitzId(selected.getOwnerid());
				citiContactList = profileInfoFactory.getRitzService().getProfile(profileEntity, request.getHeader("SM_USER"));
			} else {				
				citiContactList = csiUtil.getEmailIdFromCSIDB(selected.getOwnerid());
			}		
	
			Iterator it = citiContactList.iterator();
			while(it.hasNext()) {
			    CitiContact entity = (CitiContact) it.next();
			    request.getSession().setAttribute("APP_OWNER_EMAIL", entity.getEmail());
			    log.info("OWNER EMAIL :" +entity.getEmail());
			    break;
			}
		}
		
		if (selected != null && selected.getAppManagerGEID() != null && !selected.getAppManagerGEID().isEmpty()) {
			if(isWebService) {
			SOADataComponent soaDataComponent = new SOADataComponent();
	
			ProfileInfoFactory profileInfoFactory =
			    (ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");
	
			ProfileEntity profileEntity = new ProfileEntity();
			profileEntity.setRitzId(selected.getAppManagerGEID());
			citiContactList = profileInfoFactory.getRitzService().getProfile(profileEntity, request.getHeader("SM_USER"));
			} else {				
				citiContactList = csiUtil.getEmailIdFromCSIDB(selected.getAppManagerGEID());
			}
			Iterator it = citiContactList.iterator();
			while(it.hasNext()) {
			    CitiContact entity = (CitiContact) it.next();
			    request.getSession().setAttribute("APP_MGR_EMAIL", entity.getEmail());
			    log.info("MANAGER EMAIL :" +entity.getEmail());
			    selected.setAppManagerEmail( entity.getEmail());
			    break;
			}
		}
		
		 request.getSession().setAttribute("COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY", selected);
		} catch(Exception e) {
		    log.error(e,e);
		    return "FAIL";
		}
	
    	return "SUCCESS";
    }
    

}