package com.citigroup.cgti.c3par.fw.service;

import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.Person;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.accessform.FafAccessForm;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleDestinationIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleSourceIP;
import com.citigroup.cgti.c3par.fw.domain.Firewall;
import com.citigroup.cgti.c3par.fw.domain.FirewallRulePolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRulesExport;
import com.citigroup.cgti.c3par.model.PlanningEntity;

@Component
@Transactional
public class FirewallRulesExportServiceImpl implements
		FirewallRulesExportService {

	private static Logger log = Logger
			.getLogger(FirewallRulesExportServiceImpl.class);

	@Autowired
	@Qualifier("jdbcTemplate_ccr")
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	SessionFactory sessionFactory;
	
	private static final String IPFRE_REQUEST_TYPE = "IPFRE";
	
	private static final String FRE_REQUEST_TYPE = "FRE";
	
	private static final String YES = "Y";
	
	private static final String NO = "N";
	
	private static final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	
	@Autowired
	private CCRQueries ccrQueries;
	@Transactional(readOnly = true)
	public FirewallRulesExport exportFirewallRules(Long tiRequestId,
			Long processId, String requestType, Integer versionID) throws Exception {
		if(requestType.equals("Firewall")) {
			requestType = FRE_REQUEST_TYPE;
		} else {
			requestType = IPFRE_REQUEST_TYPE;
		}

		FirewallRulesExport firewallRulesExport = new FirewallRulesExport();

		firewallRulesExport.setConID(processId);
		firewallRulesExport.setVersion(Long.valueOf(versionID));

		// Original Requester Information
		firewallRulesExport.setRequestor(getRequesterDetails(processId));

		long planningId = getPlanningIdForTiRequestId(tiRequestId);
		if (planningId == 0) {
			throw new Exception(
					" No Planning Id is associated with the TiRequestId "
							+ tiRequestId);
		}
		PlanningEntity planningEntity = new PlanningEntity();
		planningEntity = getPlanningEntity(Long.valueOf(planningId));

		// Business Information
		RelationshipDTO relDTO = new RelationshipDTO();
		relDTO = getRelationshipEntity(planningEntity.getRelationshipId());
		firewallRulesExport.setRelDTO(relDTO);
		firewallRulesExport.setConName(planningEntity.getConnectionName());

		// Current cycle Requester 
		firewallRulesExport
				.setCurrCycleRequestor(getRequesterDetails(planningEntity
						.getId()));

		log.debug("Current Cycle Requestor:"
				+ firewallRulesExport.getCurrCycleRequestor());
		if (versionID.longValue() == 1) {
			String just = getCurrentBusJustfication(tiRequestId);
			// Current Business Justification
			firewallRulesExport.setCurrentBusJus(just);
			// Original Business Justification
			firewallRulesExport.setOriginalBusJus(just);
		} else {
			// Current Business Justification
			firewallRulesExport
					.setCurrentBusJus(getCurrentBusJustfication(tiRequestId));
			// Original Business Justification
			firewallRulesExport.setOriginalBusJus(getOrigBusJustification(
					processId, versionID));
		}

		log.debug("Original BusinessJustification:"
				+ firewallRulesExport.getOriginalBusJus());
		// Application Details
		if (FRE_REQUEST_TYPE.equalsIgnoreCase(requestType)) {
			firewallRulesExport
					.setApplicationDetails(getFirewallRuleApplicationDetails(
							tiRequestId, NO));
		} else if (IPFRE_REQUEST_TYPE.equalsIgnoreCase(requestType)) {
			firewallRulesExport
					.setApplicationDetails(getFirewallRuleApplicationDetails(
							tiRequestId, YES));
		}

		log.debug("Application Details"
				+ firewallRulesExport.getApplicationDetails());

		// System ID and SOW

		Map<String, String> sowAndCmp = getCMPAndSOWByVersionWithoutType(
				processId, versionID);
		firewallRulesExport
				.setSystemID(sowAndCmp.get("CMP") != null ? sowAndCmp
						.get("CMP") : "");
		firewallRulesExport.setSOW(sowAndCmp.get("SOW") != null ? sowAndCmp
				.get("SOW") : "");
		log.debug("AccessFormGenerator:CMP/SOW"
				+ firewallRulesExport.getSystemID()
				+ firewallRulesExport.getSOW());

		// Business Contacts Information
		firewallRulesExport.setBusinessContacts(getBusinessContactsDetails(
				processId, versionID));
		log.debug("AccessFormGeneration:GetRole/Business Contact Information:"
				+ firewallRulesExport.getBusinessContacts());

		// Special Instructions/Completion Date/Change Number
		Map<String, Object> implInfo = null;
		implInfo = getImplementationInfo(processId, versionID,
				requestType);
		if (implInfo.size() > 0) {
			String changeNo = (String) implInfo.get("CHANGE_NUMBER");
			String compDate = (String) implInfo.get("COMPLETION_DATE");
			String specialIns = (String) implInfo.get("SPL_INSTR");
			Long infoman = (Long) implInfo.get("INFOMAN_ID");
			firewallRulesExport
					.setSpecialInstructions(specialIns != null ? specialIns
							: "");
			firewallRulesExport.setCompletionDate(compDate != null ? compDate
					: "");
			firewallRulesExport.setInfomanID(infoman != null ? infoman : 0);
			firewallRulesExport.setChangeNumber(changeNo != null ? changeNo
					: "");

			log.debug("Special Instructions"
					+ firewallRulesExport.getSpecialInstructions()
					+ "Completion Date:"
					+ firewallRulesExport.getCompletionDate() + "Infoman ID:"
					+ firewallRulesExport.getInfomanID() + "ChangeNumber:"
					+ firewallRulesExport.getChangeNumber());
		}

		
		log.debug("Implementation Status : "
				+ firewallRulesExport.getImplStatus());
		

		// Cab Approvers for IP and Firewall
		if (FRE_REQUEST_TYPE.equalsIgnoreCase(requestType)
				|| IPFRE_REQUEST_TYPE.equalsIgnoreCase(requestType)) {
			String cabApprovers = getCabApproversList(tiRequestId);
			firewallRulesExport.setCabApprovers(cabApprovers);
			log.debug("Firewall rule Export : Cab Approvers List"
					+ firewallRulesExport.getCabApprovers());
		}
		FireWallRuleProcess	firewallRuleProcess = new FireWallRuleProcess();
		//Get previous version of tirequest if phase is ACV
		tiRequestId=firewallRuleProcess.getPreviousVersionTIRequest(processId);
		List<FireWallRule> fwRules = getFirewallRules(tiRequestId, requestType);
		
		log.debug("FW: " + getFirewallRules(tiRequestId, requestType));
		List<FafAccessForm> rulesDetails = getFirewallRulesDetails(fwRules, tiRequestId);
		firewallRulesExport.setFwImplDetails(rulesDetails);
		return firewallRulesExport;

	}

	public long getPlanningIdForTiRequestId(Long tiRequestId) throws Exception {
		long planningId = 0;

		if (tiRequestId != null && tiRequestId.longValue() > 0) {
			try {

				String sql = "select planning_id from c3par.ti_request_planning_xref where ti_request_id=?";
				SqlRowSet rs = jdbcTemplate.queryForRowSet(sql.toString(),
						new Object[] { tiRequestId.longValue() });

				if (rs.next()) {
					planningId = rs.getLong(1);
				}
				if (planningId == 0) {
					String planTermSQL = " select max(planning_id) from c3par.ti_request_planning_xref where ti_request_id in (select b.id from c3par.ti_request a ,c3par.ti_request b where a.id=?  and a.process_id=b.process_id ) ";
					SqlRowSet rs1 = jdbcTemplate.queryForRowSet(
							planTermSQL.toString(),
							new Object[] { tiRequestId.longValue() });
					;

					if (rs1.next()) {
						planningId = rs1.getLong(1);
					}
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		log.debug("Planning Id is " + planningId + " for tiRequestID "
				+ tiRequestId);
		return planningId;

	}

	public Person getRequesterDetails(Long connectionRequestId) {

		String sql = "SELECT d.FIRST_NAME || ' ' || d.LAST_NAME name, d.SSO_ID soe_id, d.EMAIL e_mail FROM con_req a, c3par_users d WHERE A.ID = ?"
				+ " AND upper(a.requester_id) = upper(d.SSO_ID)";

		Map data = new HashMap();
		Person person = new Person();
		List dataList = null;

		try {
			data = runQuery(sql, 3,
					new Object[] { connectionRequestId.toString() });
		} catch (Exception e) {
			log.error(e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					person.setFullName((String) dataList.get(0));
					person.setSoeID((String) dataList.get(1));
					person.setEmailAddress((String) dataList.get(2));

				}
				counter = counter + 1;
			}
		}
		return person;
	}

	public Map runQuery(String statement, int columns, Object obj[])
			throws Exception {

		Map data = null;
		List dataList = null;
		int counter = 0;
		int rowId = 0;

		try {
			SqlRowSet result = jdbcTemplate.queryForRowSet(statement, obj);

			if (result != null) {
				while (result.next()) {
					if (data == null)
						data = new HashMap();
					rowId = rowId + 1;
					counter = 1;
					dataList = new ArrayList();
					dataList.add(result.getString(counter));
					data.put(Integer.valueOf(rowId), dataList);
					while (counter < columns) {
						counter = counter + 1;
						dataList.add(result.getString(counter));
					}
				}

			}
		} catch (Exception e) {
			log.error(e);
		}
		return data;

	}

	private PlanningEntity getPlanningEntity(Long planningId) {
		PlanningEntity planningEntity = new PlanningEntity();

		try {

			String sql = "select ID,RELATIONSHIP_ID,CONNECTION_NAME,RATIONALE from con_req where id=?";
			SqlRowSet rs = jdbcTemplate.queryForRowSet(sql,
					new Object[] { planningId });

			if (rs.next()) {
				planningEntity.setId(Long.valueOf(rs.getLong(1)));
				planningEntity.setRelationshipId(Long.valueOf(rs.getLong(2)));
				planningEntity.setConnectionName(rs.getString(3));
				planningEntity.setRationale(rs.getString(4));
			}

		} catch (Exception e) {
			log.error(e);
		}
		return planningEntity;
	}
	
	private RelationshipDTO getRelationshipEntity(Long planningId) {
		RelationshipDTO relDTO = new RelationshipDTO();
		
		StringBuilder sql = new StringBuilder();
		
		try {
			
			sql.append("SELECT DISTINCT REL.ID,REL.NAME,BU.BUSINESS_NAME  ");
			sql.append("FROM C3PAR.RELATIONSHIP REL ");
			sql.append("JOIN C3PAR.REL_CITI_HIERARCHY_XREF RXREF  ");
			sql.append("ON RXREF.RELATIONSHIP_ID = REL.ID ");
			sql.append("JOIN C3PAR.CITI_HIERARCHY_MASTER CITIHIERARCHYMASTER ");
			sql.append("ON CITIHIERARCHYMASTER.ID = RXREF.CITI_HIERARCHY_MASTER_ID ");
			sql.append("JOIN C3PAR.BUSINESS_UNIT BU ");
			sql.append("ON CITIHIERARCHYMASTER.BU_ID =BU.ID ");
			sql.append("WHERE REL.ID = ? ");
			
			SqlRowSet rs  = jdbcTemplate.queryForRowSet(sql.toString(),new Object [] {planningId});
			if (rs.next()) {
				relDTO.setId(Long.valueOf(rs.getLong(1)));
				relDTO.setName(rs.getString(2));
				relDTO.setBusinessName(rs.getString(3));
			}

		} catch (Exception e) {
			log.error(e);
		} 
		return relDTO;

	}
	
	public String getCurrentBusJustfication(Long tiRequestId) {
		String sql = "select con.rationale from con_req con, ti_request_planning_xref x where "+
					 "con.id=x.planning_id and x.ti_request_id= ? ";

		Map data = new HashMap();
		String currentBusJustfication="";
		List dataList = null;

		try {
			data = runQuery(sql, 1,new Object[]{tiRequestId});
		} catch (Exception e) {
			log.error(e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					currentBusJustfication=(String) dataList.get(0);
					
				}
				counter = counter + 1;
			}
		}
		return currentBusJustfication;
	}
	
public ArrayList getFirewallRuleApplicationDetails(Long tiRequestId,String isIPReg) {
		
		String queryToExecute = "";
		if(isIPReg != null && isIPReg.equalsIgnoreCase(YES)){
			queryToExecute =ccrQueries.getQueryByName(QueryConstants.EXPORTRULES_GETAPPLICATIONDETAILS_IPREG);
		}
		else{
			queryToExecute =ccrQueries.getQueryByName(QueryConstants.EXPORTRULES_GETAPPLICATIONDETAILS_FW);
		}
		
		
		Map data = null;
		ArrayList returnList = new ArrayList();
		// Application application = new Application();
		List dataList = null;

		try {
			data = runQuery(queryToExecute,6,new Object[]{tiRequestId.toString(),tiRequestId.toString()});
			
			log.debug("Application details for Firewall and IPreg"+data +"+++"+queryToExecute);
		} catch (Exception e) {
			log.error(e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList =  (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					Application application = new Application();
					Person person = new Person();
					application.setApplicationID(Long.valueOf((String) dataList.get(0)));
					application.setApplicationName((String) dataList.get(1));
					person.setFullName((String) dataList.get(2));
					person.setGeid((String) dataList.get(3));
					application.setSecClassification((String) dataList.get(4));
					application.setPersonaDataIndicator((String) dataList.get(5));
					application.setAppOwner(person);
					returnList.add(application);

				}
				counter = counter + 1;
			}
		}else{
			String query = "";
			if(isIPReg != null && isIPReg.equalsIgnoreCase(YES)){
				query =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_IPREG);
			}
			else{
				query =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_FW);
			}
			
			
			data = new HashMap();
			returnList = new ArrayList();
			// Application application = new Application();
			dataList = null;
			

			try {
				data = runQuery(query, 6,new Object[]{tiRequestId.toString(),tiRequestId.toString()});
				log.debug("Application details for Firewall and IPreg"+data +"+++"+queryToExecute);
				
			} catch (Exception e) {
				log.error(e);
			}
			if (data != null && data.size() > 0) {
				while (counter <= data.size()) {
					dataList = (ArrayList) data.get(Integer.valueOf(counter));
					if (dataList != null && dataList.size() > 0) {
						Application application = new Application();
						Person person = new Person();
						application.setApplicationID(Long.valueOf((String) dataList.get(0)));
						application.setApplicationName((String) dataList.get(1));
						person.setFullName((String) dataList.get(2));
						person.setGeid((String) dataList.get(3));
						application.setSecClassification((String) dataList.get(4));
						application.setPersonaDataIndicator((String) dataList.get(5));
						application.setAppOwner(person);
						returnList.add(application);

					}
					counter = counter + 1;
				}
			}
			
		}
		return returnList;
		
	}

	public String getCabApproversList(long tiRequest) {
		StringBuilder cabApprovers= new StringBuilder();
		Map data = new HashMap();
		List dataList = null;
		
		String queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETCABAPPROVERLIST);
		log.debug(" get cab approvers sql is "+queryToExecute);
		
		try {
			data = runQuery(queryToExecute, 1,new Object[]{tiRequest});
					
		} catch (Exception e) {
			log.error(e);
		}
		
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					if(counter !=1 ){
					cabApprovers.append(",");
					}
					cabApprovers.append(dataList.get(0));
				}
				counter = counter + 1;
			}
		}
		log.debug("cab app" +cabApprovers.toString());
		return cabApprovers.toString(); 
	}
	
	public String getOrigBusJustification(Long connectionRequestId,
			Integer versionID) {

		String sql = "SELECT CONREQ.RATIONALE " 
				+" FROM TI_REQUEST_PLANNING_XREF TXREF,TI_REQUEST TREQ,CON_REQ CONREQ "
				+" WHERE TXREF.PLANNING_ID = ? "
				+"  AND TREQ.ID = TXREF.TI_REQUEST_ID AND CONREQ.ID = TREQ.PROCESS_ID";
		
		
		log.debug(" java getOrigBusJustification sql is "+sql.toString());

		Map data = new HashMap();
		String busJustification = "";
		List dataList = null;

		try {
			data = runQuery(sql.toString(), 1,new Object[]{connectionRequestId});
		} catch (Exception e) {
			log.error(e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					busJustification=(String) dataList.get(0);
				}
				counter = counter + 1;
			}
		}
		log.debug("GetOriginalBusinessJustification.."+busJustification);
		return busJustification;
	}
	
	public Map<String,String> getCMPAndSOWByVersionWithoutType(Long processId,Integer versionNumber) {

		
		String sow = null;
		String cmp = null;
		Map<String,String> sowAndCmp = new HashMap<String,String>();
		
		try {
			
			StringBuilder sql = new StringBuilder();
			
			sql.append("select tir.SOW_NUMBER,tir.CMP_ID,tir.SERVICE_NOW_ID from ti_request tir  ");
			sql.append("where tir.process_id=? and ");
			sql.append("tir.version_number=?  and rownum = 1 ");
			
			SqlRowSet result  = jdbcTemplate.queryForRowSet(sql.toString(),new Object [] {processId,versionNumber});
			log.debug("getCMPAndSOWByVersion SQL " + sql.toString());
			log.debug(sql.toString());
			
			
			
			if (result.next()) {
				sow = result.getString(1);
				if (result.getString(2)!= null && !result.getString(2).isEmpty()) {
					cmp = result.getString(2);
				} else {
					cmp = result.getString(3);
				}
				sowAndCmp.put("CMP",cmp);
				sowAndCmp.put("SOW",sow);
			}
		
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
		log.info("getCMPAndSOWByVersionWithoutType processId:versionNumber:CMP/SOW "+ processId +":"+versionNumber+":"+cmp+"/"+sow);
		return sowAndCmp;
	}
	
	/**
	 * Gets the business contacts details.
	 *
	 * @param connectionRequestId
	 *            the connection request id
	 * @param versionNo
	 *            the version no
	 * @return the business contacts details
	 */
	public ArrayList<Person> getBusinessContactsDetails(Long connectionRequestId,Integer versionNo) {
		 
		String tableName="";
		String relationshipType="";
		
		try {
			relationshipType = getRelationshipType(connectionRequestId);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if(relationshipType.equalsIgnoreCase("U_TURN") || relationshipType.equalsIgnoreCase("CITI_CON")){
			
			tableName="con_req_cit_rqcon_xref";
		}else {
			tableName="con_req_citi_contact_xref";
		}
			String sql = "SELECT distinct  rr.display_name,cc.first_name || ' ' || cc.last_name biso_name, cc.rits_id rits_id, cc.geid FROM ti_request_planning_xref trpx, ti_request tr, "+tableName+" crccx,planning p,citi_contact cc,role rr WHERE tr.process_id = ?"
						+ " AND trpx.ti_request_id = tr.id and tr.version_number = ?"
						+ " and trpx.planning_id = p.id and crccx.request_id = p.id and crccx.citi_contact_id = cc.id and crccx.role_id=rr.id and crccx.primary_contact = 'Y' and rr.name in ('Business_Owner','BISO','Business_Tester')";
		
		Map data = new HashMap();
		List dataList = null;
		ArrayList<Person> returnList = new ArrayList<Person>();
		
		
		try {
			data = runQuery(sql, 4,new Object[]{connectionRequestId.toString(),versionNo});
		} catch (Exception e) {
			log.error(e);
		}
		int counter = 1;
		if (data != null && data.size() > 0) {
			while (counter <= data.size()) {
				dataList = (ArrayList) data.get(Integer.valueOf(counter));
				if (dataList != null && dataList.size() > 0) {
					Person person = new Person();
					Role role = new Role();
					role.setName((String)dataList.get(0));
					person.setRole(role);
					log.debug("Role name"+person.getRole());
					person.setFullName((String) dataList.get(1));
					person.setGeid((String) dataList.get(3));
					returnList.add(person);
				}
				counter = counter + 1;
			}
		}
		return returnList;
	}
	
	/**
	 * Gets the implementation info.
	 *
	 * @param processId
	 *            the process id
	 * @param versionId
	 *            the version id
	 * @param reqType
	 *            the req type
	 * @return the implementation info
	 */
	public Map<String,Object> getImplementationInfo(Long processId, Integer versionId,
			String reqType) {
		log.info("Get implementation info starts here..."+reqType);
		// ArrayList reviewInfo= new ArrayList();
		HashMap<String,Object> reviewInfo = new HashMap<String,Object>();
		
		String queryToExecute = "";
		
		
		try {
			
			 if (reqType.equalsIgnoreCase("FRE")) {
				queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_FAFIMPLINFO);
				
			} else if (reqType.equalsIgnoreCase("IPFRE")) {
				queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_IPFAFIMPLINFO);
				
			}
			SqlRowSet result  = jdbcTemplate.queryForRowSet(queryToExecute,new Object[]{processId,versionId});

			
			log.debug("Query to be executed ---" + queryToExecute+ "  for Request ID " + processId);
			if (result.next()) {

				if (reqType.equalsIgnoreCase("IPFRE")) {
					//Modified for task:45874 - added setter part
					if (result.getString(1) != null) {
						reviewInfo.put("SPL_INSTR", result.getString(1));
						
					} else {
						reviewInfo.put("SPL_INSTR", "");
					}
					if (result.getDate(2) != null) {
						Date dt = result.getDate(2);
						
						reviewInfo.put("COMPLETION_DATE",
								(sdf.format(dt) ));
					} else {
						reviewInfo.put("COMPLETION_DATE", "");
					}
					if(result.getString(3)!=null){
						reviewInfo.put("INFOMAN_ID",Long.valueOf(result.getString(3)));
					}else{
						reviewInfo.put("INFOMAN_ID",0L);
					}
					
					
				} else {
					if (result.getString(1) != null) {
						reviewInfo.put("SPL_INSTR", result.getString(1));
					} else {
						reviewInfo.put("SPL_INSTR", "");
					}
					if (result.getDate(2) != null) {
						Date dt = result.getDate(2);
						
						reviewInfo.put("COMPLETION_DATE",
								(sdf.format(dt)));
					} else {
						reviewInfo.put("COMPLETION_DATE", "");
					}
					if(result.getString(3)!=null){
						reviewInfo.put("INFOMAN_ID",Long.valueOf(result.getString(3)));
					}else{
						reviewInfo.put("INFOMAN_ID",0L);
					}
					
					
				}

			}
			if(reqType.equalsIgnoreCase("FRE")){
				
				String sql1 = "select rfc_id from rfc_request where ti_request_id in (select id from ti_request where process_id =" +processId+ " and version_number = "+versionId+" ) and upper(rfc_type) = upper('Firewall') and is_ipreg = 'N' ";
				SqlRowSet result1  = jdbcTemplate.queryForRowSet(sql1.toString());
				
				if(result1.next()) {
					reviewInfo.put("CHANGE_NUMBER", result1.getString(1));
				}
			}else if(reqType.equalsIgnoreCase("IPFRE")){
				
				String sql1 = "select rfc_id from rfc_request where ti_request_id in (select id from ti_request where process_id =" +processId+ " and version_number = "+versionId+" ) and upper(rfc_type) = upper('Firewall') and is_ipreg = 'Y' ";
				SqlRowSet result1  = jdbcTemplate.queryForRowSet(sql1.toString());
				if(result1.next()) {
					reviewInfo.put("CHANGE_NUMBER", result1.getString(1));
				}
			}
		} catch (Exception ex) {
			log.error(ex);
			ex.printStackTrace();
		} 
		log.debug("GetImplementationInfo:"+reviewInfo.get("CHANGE_NUMBER")+"completion"+reviewInfo.get("COMPLETION_DATE")+"Infoman"+reviewInfo.get("INFOMAN_ID"));
		return reviewInfo;
	}
	
public String getRelationshipType(Long conReqId) throws Exception {
		
		String relationshipType = null;
		
		try {
			
			String sql = "SELECT B.RELATIONSHIP_TYPE FROM CON_REQ A,RELATIONSHIP B WHERE A.RELATIONSHIP_ID=B.ID AND A.ID =?";
			SqlRowSet result  = jdbcTemplate.queryForRowSet(sql,new Object [] {conReqId});

			if (result != null && result.next()) {
				relationshipType = result.getString(1);

			}
			relationshipType = (relationshipType == null) ? ""
					: relationshipType.trim();
			log.info("relationshipType is::" + relationshipType
					+ "for CON_REQ Id::" + conReqId);
		} catch (Exception e) {
			log.error(e);
		} 
		return relationshipType;
	}

	public String transformObjectXMLtoXSLTemplate(Object objectToTransform,String requestType) {
		TransformerFactory tFactory = TransformerFactory.newInstance();
		Transformer transformer;
		StringWriter outWriter = new StringWriter();
		StreamResult result = new StreamResult(outWriter);
		String xml = getAccessForm(requestType);
		log.debug("XML Transformation:"+xml);
		try {
			transformer = tFactory.newTransformer(new StreamSource(new StringReader(xml)));
			transformer.transform(new javax.xml.transform.stream.StreamSource(new StringReader(convertoXML(objectToTransform).toString())), result);
		}
		 catch (TransformerConfigurationException e) {
			log.error(e,e);
			
		 
		} catch (TransformerException e) {
			log.error(e,e);
			
		} catch (JAXBException e) {
			log.error(e,e);
			
		}
		return outWriter.getBuffer().toString();
	}
	
	private String getAccessForm(String requestType){
	  	log.debug("AccessFormTextGenerator:starts"); 
	  	
		
	  	Connection con = null; 
	  	PreparedStatement stmt = null;
	  	ResultSet rs = null;
	  	String templateXML = "";
	  	requestType = requestType+".xsl";
	  	log.debug("RequestTYpe"+requestType);
	  	String sql = "select FILE_TEXT from c3par.CCR_Reference_Files where UPPER(FILE_NAME) ='"+requestType.toUpperCase()+"'";		
	  	try {
	  		
			con = DataSourceUtils.getConnection(jdbcTemplate.getDataSource());   
			stmt = con.prepareStatement(sql);			
			rs = stmt.executeQuery();
			while (rs.next())
		    {
		    	Clob data = rs.getClob(1);
		    	
		    	if(data != null && data.length() > 0){
		    		
		    		templateXML = data.getSubString(1, (int) data.length());
			    	log.debug("AccessFormTextGenerator:: read Data completed ........"+templateXML);
		    	}
		    }
		} catch (Exception e) {
			log.error(e,e);
		}    
		finally {
			JdbcUtils.closeResultSet(rs);
			JdbcUtils.closeStatement(stmt);
			DataSourceUtils.releaseConnection(con, jdbcTemplate.getDataSource());
		}   
		
		log.debug("AccessFormTextGenerator:ends...");
		return templateXML;
	}
	
	public StringWriter convertoXML(Object o) throws JAXBException {
		
		JAXBContext context = JAXBContext.newInstance(o.getClass());
		Marshaller m = context.createMarshaller();
	    m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
	    StringWriter sw = new StringWriter();
		
		//Converting supervisorEmail object to XML file
		m.marshal(o, sw );
		//Apply the XML values to XSL Template using XSLT transformation
			StringWriter outWriter = new StringWriter();
			StreamResult result = new StreamResult(outWriter);
			
			
		return sw;
	    
	}
	
    @Transactional(readOnly = true)
    public List<FireWallRule> getFirewallRules(Long tiRequestId, String requestType) {
    	
    	Session session = null;
    	if(!TransactionSynchronizationManager.isActualTransactionActive()){
			session = sessionFactory.openSession();
		}else{
			 session=sessionFactory.getCurrentSession();
		}
		Criteria criteria = session.createCriteria(FireWallRule.class);
		criteria.add(Restrictions.eq("tiRequest.id", tiRequestId));
		criteria.add(Restrictions.isNull("deletedTIRequest"));
		
		if(requestType.equals("FRE")) {
			criteria.add(Restrictions.sqlRestriction("(IS_IPREG is null or IS_IPREG != 'Y')"));
		} else {
			criteria.add(Restrictions.eq("isIpReg", "Y"));
		}
		
		List<FireWallRule> fireWallRules = criteria.list();
		
		log.debug("firewall Rule count: " + fireWallRules.size());
				

		return fireWallRules;

    }
    
    List<FafAccessForm> getFirewallRulesDetails(List<FireWallRule> fireWallRules, Long tiRequestId) {
    	
    	Integer combination = 1;
    	List<FafAccessForm> fafAccessForms = new ArrayList<>();
    	for (FireWallRule fireWallRule : fireWallRules) {
    		FafAccessForm firewallRules = new FafAccessForm();
    		StringBuilder firewallNames = new StringBuilder();
    		String objectNameSIP = "";
    		String objectNamePORT= "";
    		StringBuilder sourceIP = new StringBuilder();
    		StringBuilder destIP = new StringBuilder();
    		StringBuilder port = new StringBuilder();
    		
    		
    		firewallRules.setCombination(combination++);
    		List<FirewallRulePolicy> policies = fireWallRule.getPolicies();
    		int fCount = 0;
    		for (FirewallRulePolicy firewallRulePolicy : policies) {
    			List<Firewall> firewallList = firewallRulePolicy.getFirewallPolicy().getFirewalls();
    			for (Firewall firewall : firewallList) {
    				firewallNames.append(firewall.getFirewallName());
					fCount++;
					if (fCount < firewallList.size()) {
						firewallNames.append(" / ");
					}
				}
			}
    		
    		if (fireWallRule.getSourceObject() != null ) {
				objectNameSIP = fireWallRule.getSourceObject().getIpAddress();
			}
    		
    		if (fireWallRule.getSourceNetworkZone() != null && fireWallRule.getSourceNetworkZone().getName().length() > 0) {
    			firewallRules.setSrcZone(fireWallRule.getSourceNetworkZone().getName()+" "+objectNameSIP);
			}
			
			if (fireWallRule.getPortObject() != null ) {
				objectNamePORT = fireWallRule.getPortObject().getPortNumber();
			}
			
			List<FireWallRuleSourceIP> sourceIPs = fireWallRule.getSourceIPs();
			if (sourceIPs != null && !sourceIPs.isEmpty()) {
				for (FireWallRuleSourceIP fireWallRuleSourceIP : sourceIPs) {	
					String templateFlag = fireWallRuleSourceIP.getIpAddress().getTemplateFlag();
					if(/*isObjExpandable != null && isObjExpandable.equalsIgnoreCase("Y")
							&& */templateFlag != null && templateFlag.equalsIgnoreCase("Y")){
						List<FireWallRuleIP>  fireWallRuleIP = getIPsforTemplateObject(fireWallRuleSourceIP.getIpAddress().getId(), fireWallRuleSourceIP.getObjRuleID(), "N", tiRequestId);
						for(FireWallRuleIP ruleSourceIP:fireWallRuleIP){
							addTemplateIPs(sourceIP, ruleSourceIP, tiRequestId);
						}					
					}
					else{
						addSourceIP(sourceIP, fireWallRuleSourceIP, tiRequestId);
					}
				}
				firewallRules.setSrcIP(sourceIP.toString());
			}
			if (fireWallRule.getDestinationNetworkZone() != null && fireWallRule.getDestinationNetworkZone().getName().length() > 0) {
				firewallRules.setDestZone(fireWallRule.getDestinationNetworkZone().getName());
			}
			
			List<FireWallRuleDestinationIP> destinationIPs = fireWallRule.getDestinationIPs();
			if (destinationIPs != null && !destinationIPs.isEmpty())  {
				for (FireWallRuleDestinationIP fireWallRuleDestinationIP : destinationIPs) {
					String templateFlag = fireWallRuleDestinationIP.getIpAddress().getTemplateFlag();
					if(/*isObjExpandable != null && isObjExpandable.equalsIgnoreCase("Y")
							&& */templateFlag != null && templateFlag.equalsIgnoreCase("Y")){
						List<FireWallRuleIP>  fireWallRuleIP = getIPsforTemplateObject(fireWallRuleDestinationIP.getIpAddress().getId(), fireWallRuleDestinationIP.getObjRuleID(), "N", tiRequestId);
						for(FireWallRuleIP fireWallRuleDestIP:fireWallRuleIP){
							addTemplateIPs(destIP, fireWallRuleDestIP, tiRequestId);
						}					
					}
					else{
						addDestinationIP(destIP,fireWallRuleDestinationIP,tiRequestId);
					}					
				}
				
				firewallRules.setDestIP(destIP.toString());
			}
			
			List<FireWallRulePort> ports = fireWallRule.getPorts();

			if (ports != null && !ports.isEmpty()) {
				for (FireWallRulePort fireWallRulePort : ports) {
					String templateFlag = fireWallRulePort.getPort().getTemplateFlag();
					if(/*isObjExpandable != null && isObjExpandable.equalsIgnoreCase("Y")
							&& */templateFlag != null && templateFlag.equalsIgnoreCase("Y")){
						List<FireWallRulePort>  rulePort = getPortsforTemplateObject( fireWallRulePort.getPort().getId(), fireWallRulePort.getObjRuleID(), "N", tiRequestId);
						for(FireWallRulePort newFireWallRulePort:rulePort){
							addTemplatePort(port, newFireWallRulePort, tiRequestId);
						}						
					}
					else{
						addPort(port, fireWallRulePort, tiRequestId);
					}
				}
				firewallRules.setPorts(port.toString()+" "+objectNamePORT);
			}
			
			if(fireWallRule.getRuleNumber() != null){
				firewallRules.setTupleNo(fireWallRule.getRuleNumber());
			}
    		
			
			if(fireWallRule.getPolicies() != null && !fireWallRule.getPolicies().isEmpty()){
				List<FirewallRulePolicy> firewallRulePolicies = fireWallRule.getPolicies();
				StringBuilder policyName = new StringBuilder();
				for (FirewallRulePolicy firewallRulePolicy : firewallRulePolicies) {
					policyName.append(firewallRulePolicy.getFirewallPolicy());
					if (firewallRulePolicy.getUpdatedTIRequest() != null && tiRequestId != firewallRulePolicy
							.getUpdatedTIRequest().getId()) {
						policyName.append("	*");
					}					
				}
				firewallRules.setFwPolicyName(policyName.toString());
			}
			if(fireWallRule.getPolicies() != null && !fireWallRule.getPolicies().isEmpty()){
				List<FirewallRulePolicy> firewallRulePolicies = fireWallRule.getPolicies();
				for (FirewallRulePolicy firewallRulePolicy : firewallRulePolicies) {
					firewallRules.setFwType(firewallRulePolicy.getFirewallPolicy().getFwType());					
					//fwType.append("\n ");
				}
			}	
			
			
			if(fireWallRule.getRuleType() != null){
				firewallRules.setRuleType(fireWallRule.getRuleType().equalsIgnoreCase("A")?"ALLOW":"DENY");
			}
			
			if(fireWallRule.getRiskyRule()!=null){
				if(fireWallRule.getRiskyRule().equalsIgnoreCase(YES)){
					firewallRules.setOstiaRisk("Yes");
				}
				else{
					firewallRules.setOstiaRisk("No");
				}
			}
    		
			log.debug("Firewall Rule Export: "+firewallRules.getCombination()+"srczone"+firewallRules.getSrcZone()+
					"srcIP"+firewallRules.getSrcIP()+"tupleNumber"+firewallRules.getTupleNo()+"dest zone"+firewallRules.getDestZone()+"DestIP"+firewallRules.getDestIP()+
					"RequestType"+firewallRules.getReqType()+"Port"+firewallRules.getPorts()+"Risk"+firewallRules.getOstiaRisk()+"Policy"+firewallRules.getFwPolicyName());
			fafAccessForms.add(firewallRules);
		}
    	
    	return fafAccessForms;
    }
    
    private void addSourceIP(StringBuilder sourceIP, FireWallRuleSourceIP fireWallRuleSourceIP,long TiRequest){
		sourceIP.append(fireWallRuleSourceIP.getIpAddress().getIpAddress());
		if(fireWallRuleSourceIP.getNAT()!=null){
			sourceIP.append(" NAT - "+fireWallRuleSourceIP.getNAT());
		}
		if (fireWallRuleSourceIP.getObjRuleID() != null
				&& fireWallRuleSourceIP.getObjRuleID().longValue() > 0) {
			if(fireWallRuleSourceIP.getIpAddress().getAFAObjectName() != null){
				sourceIP.append(" ("+ fireWallRuleSourceIP.getIpAddress().getAFAObjectName() + ")");
			}else{
				sourceIP.append(" ()");
			}
		}
		if (fireWallRuleSourceIP.getUpdatedTIRequest() != null &&
				TiRequest != fireWallRuleSourceIP.getUpdatedTIRequest().getId()) {
			sourceIP.append("  *");
		}
		if("Y".equals(fireWallRuleSourceIP.getIpAddress().getTpaFlag())){
			sourceIP.append("(TPA)");
		}
		if("Y".equals(fireWallRuleSourceIP.getIpAddress().getOfacFlag())){
            sourceIP.append("(OFAC)");
    }
		sourceIP.append("\n");
	}
    
    private void addDestinationIP(StringBuilder destIP, FireWallRuleDestinationIP fireWallRuleDestinationIP,long TiRequest){
		destIP.append(fireWallRuleDestinationIP.getIpAddress().getIpAddress());
		if(fireWallRuleDestinationIP.getNAT()!=null){
			destIP.append(" NAT - "+fireWallRuleDestinationIP.getNAT()
					);
		}
		if (fireWallRuleDestinationIP.getObjRuleID() != null
				&& fireWallRuleDestinationIP.getObjRuleID().longValue() > 0) {
			if( fireWallRuleDestinationIP.getIpAddress().getAFAObjectName() != null){
				destIP.append(" ("+ fireWallRuleDestinationIP.getIpAddress().getAFAObjectName() + ")");
			}else{
				destIP.append(" ()");
			}			
		}
		if (fireWallRuleDestinationIP.getUpdatedTIRequest() != null &&
				TiRequest != fireWallRuleDestinationIP.getUpdatedTIRequest().getId()) {
			destIP.append("  *");
		}
		if("Y".equals(fireWallRuleDestinationIP.getIpAddress().getTpaFlag())){
			destIP.append("(TPA)");
		}
		if("Y".equals(fireWallRuleDestinationIP.getIpAddress().getOfacFlag())){
            destIP.append("(OFAC)");}

		destIP.append("\n");
	}
    
	private void addTemplateIPs(StringBuilder ips, FireWallRuleIP fireWallRuleIP,long tiRequestId){
		ips.append(fireWallRuleIP.getIpAddress().getIpAddress());
		if(fireWallRuleIP.getNAT()!=null){
			ips.append(" NAT - "+fireWallRuleIP.getNAT());
		}
		if (fireWallRuleIP.getObjRuleID() != null
				&& fireWallRuleIP.getObjRuleID().longValue() > 0) {
			if(fireWallRuleIP.getIpAddress().getAFAObjectName() != null){
				ips.append(" ("+ fireWallRuleIP.getIpAddress().getAFAObjectName() + ")");
			}else{
				ips.append(" ()");
			}			
		}
		if (fireWallRuleIP.getUpdatedTIRequest() != null &&
				tiRequestId != fireWallRuleIP.getUpdatedTIRequest().getId()) {
			ips.append("  *");
		}
		ips.append("\n");
	}
    
    @SuppressWarnings("unchecked")
    public List<FireWallRuleIP> getIPsforTemplateObject(Long ipId, Long ruleId, String forFAF, Long tiReqId) {
    	log.info("Entered into getIPsforTemplateObject Method ::>>> ipId  : "+ipId+"  ruleId :"+ruleId+" forFAF  :" +forFAF+"  tiReqId :::"+tiReqId);
    	Session session = null;
    	if(!TransactionSynchronizationManager.isActualTransactionActive()){
			session = sessionFactory.openSession();
		}else{
			 session=sessionFactory.getCurrentSession();
		}
    	List<FireWallRuleIP> firewallRuleIPs = (List<FireWallRuleIP>)
    	session.getNamedQuery("getIPsforTemplateObject")
    	.setLong(0, ipId)
    	.setLong(1, ruleId)
    	.setString(2, forFAF)
    	.setLong(3, tiReqId).list();
    	log.info("Exited from getIPsforTemplateObject Method ");
    	return firewallRuleIPs;
    }
    
    @SuppressWarnings("unchecked")
	public List<FireWallRulePort> getPortsforTemplateObject(Long ipId, Long ruleId, String forFAF, Long tiReqId) {
    	Session session = null;
    	if(!TransactionSynchronizationManager.isActualTransactionActive()){
			session = sessionFactory.openSession();
		}else{
			 session=sessionFactory.getCurrentSession();
		}
    	List<FireWallRulePort> firewallRulePorts = (List<FireWallRulePort>)
    	session.getNamedQuery("getPortsforTemplateObject")
    	.setLong(0, ipId)
    	.setLong(1, ruleId)
    	.setString(2, forFAF)
    	.setLong(3, tiReqId).list();
    	return firewallRulePorts;
    }
    
    
    private void addTemplatePort(StringBuilder port, FireWallRulePort fireWallRulePort,long TiRequest){
		if (fireWallRulePort.getObjRuleID() != null
				&& fireWallRulePort.getObjRuleID().longValue() > 0) {
			port.append(fireWallRulePort.getPort().toString());
			if(fireWallRulePort.getPort().getAFAObjectName() != null){
				port.append(" ("+ fireWallRulePort.getPort().getAFAObjectName() + ")");
			}else{
				port.append(" ()");
			}			
		} else {
			port.append(fireWallRulePort.getPort().toString());
		}
		if (fireWallRulePort.getUpdatedTIRequest() != null &&
				TiRequest != fireWallRulePort.getUpdatedTIRequest().getId()) {
			port.append("  *");
		}
		port.append("\n");
	}
    
    private void addPort(StringBuilder port, FireWallRulePort fireWallRulePort,long TiRequest){
		if (fireWallRulePort.getObjRuleID() != null
				&& fireWallRulePort.getObjRuleID().longValue() > 0) {
			port.append(fireWallRulePort.getPort().toString());
			if(fireWallRulePort.getPort().getAFAObjectName()!= null){
				port.append(" (" + fireWallRulePort.getPort().getAFAObjectName() + ")");
			}else{
				port.append(" ()");
			}
		} else {
			if (fireWallRulePort.getPort().getProtocol().endsWith("_UUID")) {
				String port1 = fireWallRulePort.getPort().toString();
				if (fireWallRulePort.getServiceName() != null) {
					port.append(port1).append("\t").append("|").append("\t")
							.append(fireWallRulePort.getServiceName());
				} else {
					port.append(port1);
				}
			} else {
				port.append(fireWallRulePort.getPort().toString());
			}
		}
		if (fireWallRulePort.getUpdatedTIRequest() != null &&
				TiRequest != fireWallRulePort.getUpdatedTIRequest().getId()) {
			port.append("  *");
		}
		port.append("\n");
	}
}
