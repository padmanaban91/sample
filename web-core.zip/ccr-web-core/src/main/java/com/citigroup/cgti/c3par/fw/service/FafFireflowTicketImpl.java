/**
 *
 */
package com.citigroup.cgti.c3par.fw.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FafFireflowTicket;
import com.citigroup.cgti.c3par.fw.domain.FafFireflowTicketLog;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRule;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleDestinationIP;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleDestinationIpObj;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRulePort;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRulePortObj;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleSourceIP;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleSourceIpObj;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleSuggestion;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.Firewall;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.IPAddressObj;
import com.citigroup.cgti.c3par.fw.domain.PortObject;
import com.citigroup.cgti.c3par.fw.domain.soc.persist.FireflowRequestPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.util.StringUtil;

/**
 * @author gs71854
 * 
 */
@SuppressWarnings("unchecked")
@Transactional
public class FafFireflowTicketImpl extends BasePersistanceImpl implements
		FireflowRequestPersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(FafFireflowTicketImpl.class);

	@Override
	public FafFirewallRule getFafFirewallRule(long id) {

		Session session = getSession();
		session.enableFilter("excludeDeleted");
		return (FafFirewallRule) session.createQuery(
				"from FafFireflowTicket rule where rule.id=" + id)
				.uniqueResult();

	}

	@Override
	@Transactional(readOnly = true)
	public FafFireflowTicket getFafFireflowTicket(
			FafFireflowTicket fireflowTicket) {

		System.out.println("Returning Fireflow Ticket now");
		Session session = getSession();

		return (FafFireflowTicket) session.createQuery(
				"from FafFireflowTicket ticket where ticket.id = "
						+ fireflowTicket.getId()).uniqueResult();
	}

	@Override
	@Transactional(readOnly = true)
	public FafFireflowTicket getFafFireflowTicketByNumber(String ticketNo) {

		System.out.println("Returning Fireflow Ticket now");
		Session session = getSession();

		return (FafFireflowTicket) session.createQuery(
				"from FafFireflowTicket t where t.ticketNumber ='" + ticketNo+"'")
				.uniqueResult();
	}

	@Override
	public List<FafFireflowTicket> getFafFireflowTickets(
			FireWallRuleProcess fwRuleProcess) {
		Session session = getSession();
		Long tiRequest = fwRuleProcess.getTiRequest();
		// List list =
		// session.createQuery("from FafFireflowTicket tickets where tickets.tiRequest.id="+tiRequest+" and (tickets.status is null or tickets.status=4)").list();
		List list = session
				.createQuery(
						"from FafFireflowTicket tickets where (tickets.status is null or tickets.status!=4) and tickets.tiRequest.id="
								+ tiRequest
								+ "order by tickets.type , tickets.id desc")
				.list();

		return list;
	}

	@Override
	public void generateFAF(Long tiRequest, String isIPReg) throws SQLException {
		Session session = getSession();

		Query q1 = session.createSQLQuery("{ call ADD_FAF_CLEAN(?,?) }");
		q1.setLong(0, tiRequest); // first parameter, index starts with 0
		q1.setString(1, isIPReg);
		q1.executeUpdate();
		Query q2 = session.createSQLQuery("{ call ADD_FAF(?,?) }");
		q2.setLong(0, tiRequest); // first parameter, index starts with 0
		q2.setString(1, isIPReg);
		q2.executeUpdate();
		Query q3 = session.createSQLQuery("{ call DEL_FAF_CLEAN(?,?) }");
		q3.setLong(0, tiRequest); // first parameter, index starts with 0
		q3.setString(1, isIPReg);
		q3.executeUpdate();
		Query q4 = session.createSQLQuery("{ call DEL_FAF(?,?) }");
		q4.setLong(0, tiRequest); // first parameter, index starts with 0
		q4.setString(1, isIPReg); 
		q4.executeUpdate();

		/*
		 * session.getTransaction().commit(); session.close();
		 */

	}

	@Override
	@Transactional( readOnly = true)
	public List<FafFireflowTicket> getFafFireflowTickets(Long tiRequest,String isIpReg) {
		Session session = getSession();
		String isIp = "";
		if(isIpReg.equalsIgnoreCase("Y"))
		{
			isIp = "tickets.ipReg='Y'";
		}
		else
		{
			isIp = "(tickets.ipReg!='Y' or tickets.ipReg is null)";
		}
		List list = session
				.createQuery(
						"from FafFireflowTicket tickets where tickets.status not in (?, ?,?) and tickets.tiRequest.id="
								+ tiRequest
								+ " and "
								+isIp
								+" order by tickets.type , tickets.id desc")
								.setString(0, FafFireflowTicket.REJECTED)
				.setString(1, FafFireflowTicket.DELETED).setString(2, FafFireflowTicket.REJRCTED).list();

		return list;
	}

	@Override
	public List<FafFireflowTicket> getTicketsToBeCreated(Long tiRequest) {
		Session session = getSession();
		List list = session
				.createQuery(
						"from FafFireflowTicket tickets where tickets.status=? and tickets.tiRequest.id="
								+ tiRequest
								+ " order by tickets.type , tickets.id desc")
				.setString(0, FafFireflowTicket.NOT_POSTED).list();

		return list;
	}

	@Override
	public FafFireflowTicket getFafFireflowTicket(Long id) {
		Session session = getSession();

		return (FafFireflowTicket) session.createQuery(
				"from FafFireflowTicket ticket where ticket.id=" + id)
				.uniqueResult();
	}

	@Override
	@Transactional( readOnly = true)
	public List<FafFireflowTicket> findFafFireflowTicketsByLocationId(
			Long locationId) {
		Session session = getSession();
		List list = session
				.createQuery(
						"from FafFireflowTicket tickets where tickets.policyGroup.connectionFWLocation.id=? order by tickets.type , tickets.id desc")
				.setLong(0, locationId).list();

		return list;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<FafFireflowTicket> findFafFireflowTicketsByLocationAndTiRequest(
			Long locationId, Long tiRequestId) {
		Session session = getSession();
		String[] statusToExclude={FafFireflowTicket.DELETED,FafFireflowTicket.CANCELLED,FafFireflowTicket.REJECTED,FafFireflowTicket.REJRCTED};
		List list = session
				.createQuery(
						"from FafFireflowTicket tickets where tickets.policyGroup.connectionFWLocation.id=? and tickets.tiRequest.id=? "
								+ "and tickets.status not in (:statuses) order by tickets.type , tickets.id desc")
				.setLong(0, locationId).setLong(1, tiRequestId)
				.setParameterList("statuses",  statusToExclude)
				.list();
		return list;
	}

	@Override
	public Long saveFafFirewallRuleSuggestion(FafFirewallRuleSuggestion ruleData) {
		System.out.println(this.getClass().getName()
				+ ".saveFafFirewallRuleSuggestion() method called");

		// identifyExistingIPsandPorts(ruleData);
		//Long fireWallRuleId = null;
		/*if (ruleData.getId() != null && ruleData.getId().longValue() > 0) {
		    fireWallRuleId = ruleData.getId();
		    getHibernateTemplate().update(ruleData);
		} else {
		*/
		getHibernateTemplate().saveOrUpdate(ruleData);

		//System.out.println("completed insert -->" + fireWallRuleId);
		return ruleData.getId();

	}

	@Override
	@Transactional(readOnly = true)
	public List<FafFirewallRuleSuggestion> getFafFirewallRuleSuggestions(
			FafFirewallRuleSuggestion fafFirewallRuleSuggestion) {
		Session session = getSession();
		String ruleId = "193";
		List list = session.createQuery(
				"from FafFirewallRuleSuggestion rules where rules.fafFirewallRule.id="
						+ ruleId).list();

		return list;
	}

	@Override
	@Transactional(readOnly = true)
	public FafFirewallRuleSuggestion getFafFirewallRuleSuggestionById(
			FafFirewallRuleSuggestion fafFirewallRuleSuggestion) {
		Session session = getSession();
		String Id = "3682";
		return (FafFirewallRuleSuggestion) session.createQuery(
				"from FafFirewallRuleSuggestion rules where rules.id=" + Id)
				.uniqueResult();

	}

	@Override
	@Transactional(readOnly = true)
	public List<FafFireflowTicket> getFafFireflowTickets(
			FafFireflowTicket fireflowTicket) {
		Session session = getSession();
		String tiRequest = "52996";
		List list = session.createQuery(
				"from FafFireflowTicket tickets where tickets.tiRequest.id="
						+ tiRequest
						+ " and (tickets.status is null or tickets.status!=4)")
				.list();

		return list;
	}

	@Override
	public Long saveFafFirewallSuggestedDestIpObj(
			FafFirewallRuleSuggestion fafFirewallSuggestedDestIpObj) {
		System.out.println(this.getClass().getName()
				+ ".fafFirewallSuggestedDestIpObj() method called");

		// identifyExistingIPsandPorts(ruleData);
		Long fireWallRuleId = null;
		if (fafFirewallSuggestedDestIpObj.getId() != null
				&& fafFirewallSuggestedDestIpObj.getId().longValue() > 0) {
			fireWallRuleId = fafFirewallSuggestedDestIpObj.getId();
			getHibernateTemplate().update(fafFirewallSuggestedDestIpObj);
		} else {

			fireWallRuleId = (Long) getHibernateTemplate().save(
					fafFirewallSuggestedDestIpObj);
		}
		System.out.println("completed insert -->" + fireWallRuleId);
		return fireWallRuleId;
	}

	@Override
	public Long saveFafFirewallSuggestedPortObj(
			FafFirewallRuleSuggestion fafFirewallSuggestedPortObj) {
		System.out.println(this.getClass().getName()
				+ ".fafFirewallSuggestedPortObj() method called");

		getHibernateTemplate().saveOrUpdate(
				fafFirewallSuggestedPortObj.getPorts());
		return null;
	}

	@Override
	public Long saveFafFirewallSuggestedSourceIpObj(
			FafFirewallRuleSuggestion fafFirewallSuggestedSourceIpObj) {
		System.out.println(this.getClass().getName()
				+ ".fafFirewallSuggesteSourceIpObj() method called");

		/*	  Long srcObjId = null; 
			  if (fafFirewallSuggestedSourceIpObj.getId() != null &&
			  fafFirewallSuggestedSourceIpObj.getId().longValue() > 0) {
				  srcObjId = fafFirewallSuggestedSourceIpObj.getId();
			  getHibernateTemplate().update(fafFirewallSuggestedSourceIpObj); }
			  else {
			  
				  srcObjId = (Long) getHibernateTemplate().saveOrUpdateAll(fafFirewallSuggestedSourceIpObj.getSourceIPs());
				 }
			 
			System.out.println("completed update -->"+srcObjId);
		*/
		getHibernateTemplate().saveOrUpdate(
				fafFirewallSuggestedSourceIpObj.getSourceIPs());
		return null;

	}

	@Override
	public Long updateFafFireflowTicket(FafFireflowTicket fafFireflowTicket) {
		log.debug("updateFafFireflowTicket called");
		//boolean  fafCompleted = isFFTicketsImplemented(tiReqId);
		String sql ="update faf_fireflow_ticket set status='"+fafFireflowTicket.getStatus()+"' where id="+fafFireflowTicket.getId();
		
			SQLQuery query = getSession().createSQLQuery(sql);
			query.executeUpdate();
		
		log.debug("updateFafFireflowTicket called  and updated "+sql);
		return fafFireflowTicket.getId();
	}

	@Override
	// @Transactional( readOnly = true)
	@Transactional(propagation = Propagation.REQUIRES_NEW, timeout=1200)
	public List<FafFirewallRule> findRequestedRulesByRequest(
			FAFRequest fafRequest) {
		List<FafFirewallRule> requestedRules = null;
		Session session = null;
		try{
		log
				.info("In Action: FafFireflowTicketImpl: findRequestedRulesByRequest() ");
		log
				.info("In Action: FafFireflowTicketImpl: findRequestedRulesByRequest() "
						+ "fafRequest.getPolicy() "
						+ fafRequest.getPolicy()
						+ " \t fafRequest.getSourceIPAddress()"
						+ fafRequest.getSourceIPAddress()
						+ "\n fafRequest.getPolicyGroup()"
						+ fafRequest.getPolicyGroup()
						+ "\t fafRequest.getPortNumber()"
						+ fafRequest.getPortNumber());
		if(!TransactionSynchronizationManager.isActualTransactionActive()){
			session=getNewSession();
		}else{
			 session=getSession();
		}
		TIRequest tiRequest = new TIRequest();
		tiRequest.setId(fafRequest.getTiRequest());
		Criteria criteria = session.createCriteria(FafFirewallRule.class);
		criteria.createCriteria("fafFireFlowTicket", "fafFireFlowTicket");
		criteria.createCriteria("fafFireFlowTicket.policyGroup", "policyGroup");
		criteria.createCriteria("fafFireFlowTicket.tiRequest", "tiRequest");
//		criteria.createCriteria("fireWallRule", "fireWallRule");
		criteria
				.add(Restrictions.eq("tiRequest.id", fafRequest.getTiRequest()));
		criteria.add(Restrictions.eq("deleted", "N"));
		criteria.createCriteria("policies", "policies");
		criteria.createCriteria("policies.firewallPolicy", "firewallPolicy");
		//todo filter
		if (!StringUtil.isNullorEmpty(fafRequest.getPolicy())) {
			
			criteria.add(Restrictions.ilike("firewallPolicy.name", fafRequest
					.getPolicy(), MatchMode.ANYWHERE));
		
		}
		if (!StringUtil.isNullorEmpty(fafRequest.getPolicyGroup())) {
			criteria.add(Restrictions.ilike("policyGroup.name", fafRequest
					.getPolicyGroup(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fafRequest.getSourceZone())) 				{
			criteria.createCriteria("sourceNetworkZone", "sourceNetworkZone");
			criteria.createCriteria("destinationNetworkZone", "destinationNetworkZone");
			Criterion srcZone = Restrictions.ilike("sourceNetworkZone.name", fafRequest
				    .getSourceZone(), MatchMode.ANYWHERE);
			Criterion dstZone = Restrictions.ilike("destinationNetworkZone.name",
					fafRequest
				    .getSourceZone(), MatchMode.ANYWHERE);
			criteria.add(Restrictions.or(srcZone, dstZone));
		}	
	

		if (!StringUtil.isNullorEmpty(fafRequest.getSourceIPAddress())) {
			criteria.createCriteria("sourceIPs", "sourceIPs");
			criteria.createCriteria("sourceIPs.ipAddress", "sourceIP");
			criteria.add(Restrictions.ilike("sourceIP.ipAddress", fafRequest
					.getSourceIPAddress(), MatchMode.ANYWHERE));

		}
		if (!StringUtil.isNullorEmpty(fafRequest.getDestinationIPAddress())) {
			criteria.createCriteria("destinationIPs", "destinationIPs");
			criteria
					.createCriteria("destinationIPs.ipAddress", "destinationIP");
			criteria.add(Restrictions.ilike("destinationIP.ipAddress",
					fafRequest.getDestinationIPAddress(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fafRequest.getPortNumber())) {
			criteria.createCriteria("ports", "ports");
			criteria.createCriteria("ports.port", "port");
			criteria.add(Restrictions.eq("port.portNumber", fafRequest
					.getPortNumber()));
		}
		if (!fafRequest.getType().equalsIgnoreCase("N")) {
			criteria.add(Restrictions.eq("fafFireFlowTicket.type", fafRequest
					.getType()));
		}
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.DELETED));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.REJECTED));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.REJRCTED));
		if (fafRequest.isPaginationRequired()) {
			fafRequest.setRowCount(getRowCount(criteria));
			addPagination(criteria, fafRequest.getFirstResult(), fafRequest
					.getMaxResult());
		}
		
		if(fafRequest.getIsIPReg() != null && fafRequest.getIsIPReg().equalsIgnoreCase("Y")){
			criteria.add(Restrictions.eq("fafFireFlowTicket.ipReg", fafRequest.getIsIPReg()));
		}else{
			Criterion isIPReg = Restrictions.eq("fafFireFlowTicket.ipReg", fafRequest.getIsIPReg());
			Criterion isIPRegNull = Restrictions.isNull("fafFireFlowTicket.ipReg");
			criteria.add(Restrictions.or(isIPReg, isIPRegNull));
		}
		
		criteria.addOrder(Order.asc("firewallPolicy.name").ignoreCase());
		criteria.addOrder(Order.desc("ruleSequence"));
		requestedRules = criteria.list();
		fafRequest.setRequestedRules(requestedRules);
		
		if (requestedRules != null && requestedRules.size() > 0) {
			for (FafFirewallRule fafFirewallRule : requestedRules) {
				if (fafFirewallRule != null && fafFirewallRule.getPorts() != null
						&& fafFirewallRule.getPorts().size() > 0) {
					for (FafFirewallRulePort fafFirewallRulePort : fafFirewallRule.getPorts()) {
						if (fafFirewallRulePort != null && fafFirewallRulePort.getPort() != null
								&& "ICMP".equals(fafFirewallRulePort.getPort().getProtocol())) {
							fafFirewallRulePort.setControlMessage(getControlMessage(fafFirewallRulePort.getPort().getControlMsgId()));
						}
					}
				}
			}
		}
		for(FafFirewallRule fafFirewallRule:requestedRules){
			
			log.info("In Action: FafFireflowTicketImpl: findRequestedRulesByRequest() for loop to identify the IP and Port");
			
			log.debug("In Action: FafFireflowTicketImpl: check is Object Expandable " + fafRequest.getIsObjExpandable());
			if(("Y").equalsIgnoreCase(fafRequest.getIsObjExpandable())){
				log.debug("In Action: FafFireflowTicketImpl: check fafFirewallRule.getSourceIPs() ");
				if(fafFirewallRule.getSourceIPs()!= null && !fafFirewallRule.getSourceIPs().isEmpty()){
					log.debug("In Action: FafFireflowTicketImpl: check fafFirewallRule.getSourceIPs() and entered Not NULL :>>>");
					List<FafFirewallRuleSourceIP> newFireWallRuleSourceIP = new ArrayList<FafFirewallRuleSourceIP>();
					log.debug(" Source IP of fafFirewallRule.getSourceIPs() ::>>>>" +fafFirewallRule.getSourceIPs());
					List<FafFirewallRuleSourceIP> fafFirewallRuleSourceIP=fafFirewallRule.getSourceIPs();
					log.debug("Size of fafFirewallRuleSourceIP ::>>> "+ fafFirewallRuleSourceIP.size());
					for(FafFirewallRuleSourceIP fafFirewallRuleSrcIP:fafFirewallRuleSourceIP){
						log.debug(" The value of fafFirewallRuleSrcIP.getIpAddress() ::: >>>"+fafFirewallRuleSrcIP.getIpAddress());
						String templateFlag = fafFirewallRuleSrcIP.getIpAddress().getTemplateFlag();
						log.debug("Check template Flag Source IP:::>>>>>>"+ templateFlag );
						if(templateFlag != null && templateFlag.equalsIgnoreCase("Y")){
							List<FireWallRuleIP>  fireWallRuleIP = fafRequest.getIPsforTemplateObject(fafFirewallRuleSrcIP.getIpAddress().getId(), fafFirewallRuleSrcIP.getObjRuleID(), "N", fafRequest.getTiRequest());
							//Conversion of FireWallRuleIP to FafFirewallRuleSourceIP
							for(FireWallRuleIP newFireWallRuleIP:fireWallRuleIP){
								log.debug("Conversion of FireWallRuleIP to FafFirewallRuleSourceIP ::::>>>>>");
								FafFirewallRuleSourceIP addNewFafFirewallRuleSourceIP=new FafFirewallRuleSourceIP();
								addNewFafFirewallRuleSourceIP.setIpAddress( newFireWallRuleIP.getIpAddress());
								addNewFafFirewallRuleSourceIP.setNAT(newFireWallRuleIP.getNAT());
								addNewFafFirewallRuleSourceIP.setObjRuleID(newFireWallRuleIP.getObjRuleID());
								addNewFafFirewallRuleSourceIP.setUpdatedTIRequest(newFireWallRuleIP.getUpdatedTIRequest());
								newFireWallRuleSourceIP.add(addNewFafFirewallRuleSourceIP);
							}
						
						}
						else{
							FafFirewallRuleSourceIP addNewFafFirewallRuleSourceIP=new FafFirewallRuleSourceIP();
							addNewFafFirewallRuleSourceIP.setIpAddress(fafFirewallRuleSrcIP.getIpAddress());
							newFireWallRuleSourceIP.add(addNewFafFirewallRuleSourceIP);
						}
					
					}
					fafFirewallRule.setSourceIPs(newFireWallRuleSourceIP);
					
				}
				
				//For Destination IP Address
				
				if(fafFirewallRule.getDestinationIPs()!= null && !fafFirewallRule.getDestinationIPs().isEmpty()){
					List<FafFirewallRuleDestinationIP> newFafFirewallRuleDestinationIP = new ArrayList<FafFirewallRuleDestinationIP>();
					List<FafFirewallRuleDestinationIP> fafFirewallRuleDestinationIP=fafFirewallRule.getDestinationIPs();
					log.debug("The Value of Destination IP Address >>>> :::"+fafFirewallRule.getDestinationIPs());
					log.debug("The Size of Destination IP Address >>>> :::"+fafFirewallRule.getDestinationIPs().size());
					for(FafFirewallRuleDestinationIP fafFirewallRuleDesIP:fafFirewallRuleDestinationIP){
						log.debug(" The value of fafFirewallRuleDestinationIP.getIpAddress() ::: >>>"+fafFirewallRuleDesIP.getIpAddress());
						String templateFlag = fafFirewallRuleDesIP.getIpAddress().getTemplateFlag();
						log.debug("Check template Flag Destination IP:::>>>>>>"+ templateFlag );
						if(templateFlag != null && templateFlag.equalsIgnoreCase("Y")){
							log.debug("Entered Template Flag Yes Ip_Id is ::"+ fafFirewallRuleDesIP.getIpAddress().getId() +"  Rule ID : >>" + fafFirewallRuleDesIP.getObjRuleID() );

							List<FireWallRuleIP>  fireWallRuleIP = fafRequest.getIPsforTemplateObject(fafFirewallRuleDesIP.getIpAddress().getId(), fafFirewallRuleDesIP.getObjRuleID(), "N", fafRequest.getTiRequest());
							log.debug(" The Size of object IPs ::::>>>>>" +fireWallRuleIP.size());
							for(FireWallRuleIP newFireWallRuleIP:fireWallRuleIP){
								log.debug("Conversion of FireWallRuleIP to FafFirewallRuleDestinationIP ::::>>>>>");
								log.debug("The Object IP Values ::>>>"+ newFireWallRuleIP.getIpAddress());
								FafFirewallRuleDestinationIP addNewFafFirewallRuleDestinationIP=new FafFirewallRuleDestinationIP();
								addNewFafFirewallRuleDestinationIP.setIpAddress( newFireWallRuleIP.getIpAddress());
								addNewFafFirewallRuleDestinationIP.setNAT(newFireWallRuleIP.getNAT());
								addNewFafFirewallRuleDestinationIP.setObjRuleID(newFireWallRuleIP.getObjRuleID());
								addNewFafFirewallRuleDestinationIP.setUpdatedTIRequest(newFireWallRuleIP.getUpdatedTIRequest());
								newFafFirewallRuleDestinationIP.add(addNewFafFirewallRuleDestinationIP);
							}
						
						}
						else{
							FafFirewallRuleDestinationIP addNewFafFirewallRuleDestinationIP=new FafFirewallRuleDestinationIP();
							addNewFafFirewallRuleDestinationIP.setIpAddress(fafFirewallRuleDesIP.getIpAddress());
							newFafFirewallRuleDestinationIP.add(addNewFafFirewallRuleDestinationIP);   
						}
					
					}
					fafFirewallRule.setDestinationIPs(newFafFirewallRuleDestinationIP);
				}				
				// For Port
				if(fafFirewallRule.getPorts()!= null && !fafFirewallRule.getPorts().isEmpty()){
					List<FafFirewallRulePort> newFafFirewallRulePort = new ArrayList<FafFirewallRulePort>();
					List<FafFirewallRulePort> fafFirewallRulePort=fafFirewallRule.getPorts();
					for(FafFirewallRulePort fafFirewallRulePrt:fafFirewallRulePort){
						String templateFlag = fafFirewallRulePrt.getPort().getTemplateFlag();
						if(templateFlag != null && templateFlag.equalsIgnoreCase("Y")){
							List<FireWallRulePort>  fireWallRulePort = fafRequest.getPortsforTemplateObject( fafFirewallRulePrt.getPort().getId(), fafFirewallRulePrt.getObjRuleID(), "N", fafRequest.getTiRequest());
							for(FireWallRulePort newFireWallRulePort:fireWallRulePort){
								FafFirewallRulePort addNewFafFirewallRulePort=new FafFirewallRulePort();
								addNewFafFirewallRulePort.setPort( newFireWallRulePort.getPort());
								
								if (newFireWallRulePort != null && newFireWallRulePort.getPort() != null
										&& "ICMP".equals(newFireWallRulePort.getPort().getProtocol())) {
									addNewFafFirewallRulePort.setControlMessage(getControlMessage(newFireWallRulePort.getPort().getControlMsgId()));
								}
								
								newFafFirewallRulePort.add(addNewFafFirewallRulePort);
							}						
						}
						else{
							FafFirewallRulePort addNewFafFirewallRulePort=new FafFirewallRulePort();
							addNewFafFirewallRulePort.setPort( fafFirewallRulePrt.getPort());
							addNewFafFirewallRulePort.setControlMessage(fafFirewallRulePrt.getControlMessage());
							newFafFirewallRulePort.add(addNewFafFirewallRulePort);
						}					
					}
					fafFirewallRule.setPorts(newFafFirewallRulePort);
				}							
			}
			if(fafFirewallRule.getSourceIPs()!= null && !fafFirewallRule.getSourceIPs().isEmpty()){
				Collections.sort(fafFirewallRule.getSourceIPs());
			}
			if(fafFirewallRule.getDestinationIPs()!= null && !fafFirewallRule.getDestinationIPs().isEmpty()){
				Collections.sort(fafFirewallRule.getDestinationIPs());
			}
			if(fafFirewallRule.getPorts()!= null && !fafFirewallRule.getPorts().isEmpty()){
				Collections.sort(fafFirewallRule.getPorts());
			}
		}
		}
		catch(Exception e){
			log.error("Exception in findRequestedRulesByRequest ::"+e.getMessage(),  e);
		}
		finally{
			if (!TransactionSynchronizationManager.isActualTransactionActive() && session!=null) {
				session.close();
			}
		}
		return requestedRules;
	}
	
	private String getControlMessage(Long controlMsgId) {
			Session session = getSession();
			GenericLookup genericlookup = null;
			genericlookup = (GenericLookup) session
					.createQuery("from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.id = ?)").setLong(0,controlMsgId).uniqueResult();
			String controlMessage = "";
			if (genericlookup != null && genericlookup.getValue1() != null) {
				controlMessage = genericlookup.getValue1();
			}
			return controlMessage;
		}
	
	@Override
	 @Transactional( readOnly = true)
	public List<FafFirewallRuleSuggestion> findRecommendedRulesByRequest(
			FAFRequest fafRequest) {
		log
				.info("In Action: FafFireflowTicketImpl: findRequestedRulesByTicket() ");
		log
				.info("In Action: FafFireflowTicketImpl: findRequestedRulesByTicket() "
						+ "fafRequest.getPolicy() "
						+ fafRequest.getPolicy()
						+ " \t fafRequest.getSourceIPAddress()"
						+ fafRequest.getSourceIPAddress()
						+ "\n fafRequest.getPolicyGroup()"
						+ fafRequest.getPolicyGroup()
						+ "\t fafRequest.getPortNumber()"
						+ fafRequest.getPortNumber());

		Session session = getSession();
		Criteria criteria = session
				.createCriteria(FafFirewallRuleSuggestion.class);
		criteria.createCriteria("fafFirewallRule", "fafFirewallRule");
		criteria.createCriteria("fafFirewallRule.fafFireFlowTicket",
				"fafFireFlowTicket");
		criteria.createCriteria("fafFireFlowTicket.tiRequest", "tiRequest");
		criteria.createCriteria("policy", "policy");
		//todo filter
		criteria
				.add(Restrictions.eq("tiRequest.id", fafRequest.getTiRequest()));
		if (!StringUtil.isNullorEmpty(fafRequest.getPolicy())) {
			criteria.add(Restrictions.ilike("policy.name", fafRequest
					.getPolicy(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fafRequest.getPolicyGroup())) {
			criteria.createCriteria("fafFireFlowTicket.policyGroup",
					"policyGroup");
			criteria.add(Restrictions.ilike("policyGroup.name", fafRequest
					.getPolicyGroup(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fafRequest.getSourceZone())) 				{
			criteria.createCriteria("sourceNetworkZone", "sourceNetworkZone");
			criteria.createCriteria("destinationNetworkZone", "destinationNetworkZone");
			Criterion srcZone = Restrictions.ilike("sourceNetworkZone.name", fafRequest
				    .getSourceZone(), MatchMode.ANYWHERE);
			Criterion dstZone = Restrictions.ilike("destinationNetworkZone.name",
					fafRequest
				    .getSourceZone(), MatchMode.ANYWHERE);
			criteria.add(Restrictions.or(srcZone, dstZone));
		}
		

		if (!StringUtil.isNullorEmpty(fafRequest.getSourceIPAddress())) {
			criteria.createCriteria("sourceIPs", "sourceIPs");
			criteria.createCriteria("sourceIPs.ipAddress", "sourceIP");
			criteria.add(Restrictions.ilike("sourceIP.ipAddress", fafRequest
					.getSourceIPAddress(), MatchMode.ANYWHERE));

		}
		if (!StringUtil.isNullorEmpty(fafRequest.getDestinationIPAddress())) {
			criteria.createCriteria("destinationIPs", "destinationIPs");
			criteria
					.createCriteria("destinationIPs.ipAddress", "destinationIP");
			criteria.add(Restrictions.ilike("destinationIP.ipAddress",
					fafRequest.getDestinationIPAddress(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fafRequest.getPortNumber())) {
			criteria.createCriteria("ports", "ports");
			criteria.createCriteria("ports.port", "port");
			criteria.add(Restrictions.eq("port.portNumber", fafRequest
					.getPortNumber()));
		}
		if (!fafRequest.getType().equalsIgnoreCase("N")) {
			criteria.add(Restrictions.eq("fafFireFlowTicket.type", fafRequest
					.getType()));
		}

		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.DELETED));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.REJECTED));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.REJRCTED));
		if (fafRequest.isPaginationRequired()) {
			fafRequest.setRowCount(getRowCount(criteria));
			addPagination(criteria, fafRequest.getFirstResult(), fafRequest
					.getMaxResult());
		}
		criteria.createCriteria("fireWallRule", "fireWallRule");
		if(fafRequest.getIsIPReg() != null && fafRequest.getIsIPReg().equalsIgnoreCase("Y")){
			criteria.add(Restrictions.eq("fireWallRule.isIpReg", fafRequest.getIsIPReg()));
		}else{
			Criterion isIPReg = Restrictions.eq("fireWallRule.isIpReg", fafRequest.getIsIPReg());
			Criterion isIPRegNull = Restrictions.isNull("fireWallRule.isIpReg");
			criteria.add(Restrictions.or(isIPReg, isIPRegNull));
		}
				
		criteria.addOrder(Order.asc("policy.name"));
		criteria.addOrder(Order.desc("id"));
		List<FafFirewallRuleSuggestion> recommendedRules = criteria.list();
		fafRequest.setRecommendedRules(recommendedRules);
		return recommendedRules;
	}

	@Override
	@Transactional(readOnly = true)
	public FirewallPolicy getFirewallPolicyByName(String policyName) {
		Session session = getSession();

		return (FirewallPolicy) session.createQuery(
				"from FirewallPolicy p where p.deleteFlag = 'N' and p.name='" + policyName + "'")
				.uniqueResult();

	}

	@Override
	@Transactional(readOnly = true)
	public Firewall getFirewallByName(String firewallName) {
		Session session = getSession();

		return (Firewall) session
				.createQuery(
						"from Firewall fw where fw.deleteFlag = 'N' and fw.firewallPolicy.deleteFlag='N' and translate(lower(fw.firewallName),'_','-') ='"+ firewallName + "'").uniqueResult();
	}

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	public List<FafFirewallRule> findRequestedRulesByLocation(Long locId, Long tiReqId, String isIPReg, String requestType) {
		Session session = getSession();
		Criteria criteria = session.createCriteria(FafFirewallRule.class);
		criteria.createCriteria("fafFireFlowTicket", "fafFireFlowTicket");
		criteria.createCriteria("fafFireFlowTicket.tiRequest", "tiRequest");
		criteria.createCriteria("fafFireFlowTicket.policyGroup", "policyGroup");
		criteria.createCriteria("policyGroup.connectionFWLocation","connectionFWLocation");
		criteria.createCriteria("policies", "policies");
		criteria.createCriteria("policies.firewallPolicy", "firewallPolicy");
		criteria.add(Restrictions.eq("fafFireFlowTicket.status",FafFireflowTicket.NOT_POSTED));
		criteria.add(Restrictions.eq("fafFireFlowTicket.ipReg",isIPReg));
		/*if(requestType!=null && !requestType.trim().equals(""))
		{
			criteria.add(Restrictions.eq("fafFireFlowTicket.type",requestType));
		}*/
		criteria.add(Restrictions.eq("tiRequest.id", tiReqId));
		criteria.add(Restrictions.eq("deleted", "N"));
		criteria.add(Restrictions.eq("connectionFWLocation.id", locId));
		criteria.addOrder(Order.asc("firewallPolicy.name").ignoreCase());
		criteria.addOrder(Order.desc("ruleSequence"));
		List<FafFirewallRule> requestedRules = criteria.list();
		if (requestedRules != null && requestedRules.size() > 0) {
			for (FafFirewallRule fafFirewallRule : requestedRules) {
				if (fafFirewallRule != null && fafFirewallRule.getPorts() != null
						&& fafFirewallRule.getPorts().size() > 0) {
					for (FafFirewallRulePort fafFirewallRulePort : fafFirewallRule.getPorts()) {
						if (fafFirewallRulePort != null && fafFirewallRulePort.getPort() != null
								&& "ICMP".equals(fafFirewallRulePort.getPort().getProtocol())) {
							fafFirewallRulePort.setControlMessage(getControlMessage(fafFirewallRulePort.getPort().getControlMsgId()));
						}
					}
				}
			}
		}
		for(FafFirewallRule fafFirewallRule:requestedRules){
			if(fafFirewallRule.getSourceIPs()!= null && !fafFirewallRule.getSourceIPs().isEmpty()){
				Collections.sort(fafFirewallRule.getSourceIPs());
			}
			if(fafFirewallRule.getDestinationIPs()!= null && !fafFirewallRule.getDestinationIPs().isEmpty()){
				Collections.sort(fafFirewallRule.getDestinationIPs());
			}
			if(fafFirewallRule.getPorts()!= null && !fafFirewallRule.getPorts().isEmpty()){
				Collections.sort(fafFirewallRule.getPorts());
			}
		
		}
		return requestedRules;
	}

	@Override
	@Transactional(readOnly = true)
	public FafFirewallRuleSuggestion getFafFirewallRuleSuggestion(
			String ticketNo, Long policyId, int ruleSeq) {
		Session session = getSession();
		Criteria criteria = session
				.createCriteria(FafFirewallRuleSuggestion.class);
		criteria.createCriteria("fafFirewallRule", "fafFirewallRule");
		criteria.createCriteria("fafFirewallRule.fafFireFlowTicket",
				"fafFireFlowTicket");
		criteria.createCriteria("policy", "policy");
		criteria.add(Restrictions
				.eq("fafFireFlowTicket.ticketNumber", ticketNo));
		criteria.add(Restrictions.eq("policy.id", policyId));
		criteria.add(Restrictions.eq("fafFirewallRule.ruleSequence", ruleSeq));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.DELETED));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.REJECTED));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.REJRCTED));
		FafFirewallRuleSuggestion suggestion = (FafFirewallRuleSuggestion) criteria
				.uniqueResult();
		// List list = session.createQuery("from FafFirewallRuleSuggestion s where s.policy.id="+policyId).list();
		return suggestion;

	}

	@Override
	@Transactional(readOnly = true)
	public FafFirewallRuleSuggestion getFafFirewallRuleSuggestion(
			Long fafFiewallRuleId, Long policyId) {
		Session session = getSession();
		Criteria criteria = session
				.createCriteria(FafFirewallRuleSuggestion.class);
		criteria.createCriteria("fafFirewallRule", "fafFirewallRule");
		criteria.createCriteria("policy", "policy");
		criteria.add(Restrictions.eq("fafFirewallRule.id", fafFiewallRuleId));
		criteria.add(Restrictions.eq("policy.id", policyId));
		FafFirewallRuleSuggestion suggestion = (FafFirewallRuleSuggestion) criteria
				.uniqueResult();
		// List list = session.createQuery("from FafFirewallRuleSuggestion s where s.policy.id="+policyId).list();
		return suggestion;

	}

	@Override
	 @Transactional( readOnly = true)
	public List<FafFirewallRuleSuggestion> findRecommendedRulesByLocation(Long locId, Long tiReqId, String isIPReg) {
		Session session = getSession();
		Criteria criteria = session
				.createCriteria(FafFirewallRuleSuggestion.class);
		criteria.createCriteria("fafFirewallRule", "fafFirewallRule");
		criteria.createCriteria("fafFirewallRule.fafFireFlowTicket","fafFireFlowTicket");
		criteria.createCriteria("fafFireFlowTicket.tiRequest", "tiRequest");
		criteria.createCriteria("policy", "policy");
		criteria.createCriteria("fafFireFlowTicket.policyGroup", "policyGroup");
		criteria.createCriteria("policyGroup.connectionFWLocation","connectionFWLocation");
		criteria.add(Restrictions.eq("connectionFWLocation.id", locId));
		criteria.add(Restrictions.eq("tiRequest.id", tiReqId));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",FafFireflowTicket.DELETED));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",FafFireflowTicket.REJECTED));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",FafFireflowTicket.REJRCTED));
		criteria.add(Restrictions.eq("fafFireFlowTicket.ipReg",isIPReg));
		criteria.addOrder(Order.asc("policy.name"));
		criteria.addOrder(Order.desc("id"));
		List<FafFirewallRuleSuggestion> recommendedRules = criteria.list();
		return recommendedRules;
	}

	@Override
	 @Transactional( readOnly = true)
	public List<FirewallLocation> findLocationsByRequest(Long tiReqId) {
		StringBuffer sql = new StringBuffer();
		Session session = getSession();
		sql.append("select * from con_fw_location where id in (");
		sql
				.append("select cfg.fw_location_id from faf_fireflow_ticket fft, ti_request tir, con_fw_group cfg ");
		sql
				.append("where tir.id = fft.ti_request_id and cfg.id = fft.fw_group and tir.id = ?)");
		List<FirewallLocation> list = session.createSQLQuery(sql.toString())
				.addEntity(FirewallLocation.class).setLong(0, tiReqId).list();

		return list;
	}

	@Override
	public void saveFafFireflowTicketLog(
			FafFireflowTicketLog fafFireflowTicketLog) {
		getHibernateTemplate().save(fafFireflowTicketLog);

	}

	@Override
	public List<FafFireflowTicket> getTicketsToBeResolved(long tiRequest) {
		Session session = getSession();
		List list = session
				.createQuery(
						"from FafFireflowTicket ticket where ticket.status=? and ticket.tiRequest.id=? and ticket.ticketNumber is not null"
								+ " order by ticket.type , ticket.id desc")
				.setString(0, FafFireflowTicket.DELETED).setLong(1, tiRequest)
				.list();

		return list;
	}

	@Override
	public FafFireflowTicketLog findTicketLog(Long id) {
		Session session = getSession();
		session.enableFilter("excludeDeleted");
		return (FafFireflowTicketLog) session.createQuery(
				"from FafFireflowTicketLog obj where obj.id=" + id)
				.uniqueResult();

	}

	@Override
	@Transactional(readOnly = true)
	public FafFirewallRule findRequestedRule(String ticketNumber,
			int ccrRuleEquence) {
		log.debug("findRequestedRule called");
		Session session = getSession();
		return (FafFirewallRule) session.createQuery(
				"from FafFirewallRule rule where rule.fafFireFlowTicket.ticketNumber ='"
						+ ticketNumber + "' and rule.ruleSequence="
						+ ccrRuleEquence + " and rule.deleted='N'")
				.uniqueResult();
	}

	@Override
	public void saveFafFirewallRuleSuggestions(
			List<FafFirewallRuleSuggestion> fafFirewallRuleSuggestions) {
		log.info("saveFafFirewallRuleSuggestions starts");
		for(FafFirewallRuleSuggestion fafFirewallRuleSuggestion:fafFirewallRuleSuggestions){
			Set<FafFirewallRuleSourceIpObj> sourceIPs =fafFirewallRuleSuggestion.getSourceIPs();
			Set<FafFirewallRuleDestinationIpObj> destinationIPs =fafFirewallRuleSuggestion.getDestinationIPs();
			Set<FafFirewallRulePortObj> ports =fafFirewallRuleSuggestion.getPorts();
			for(FafFirewallRuleSourceIpObj sourceIP:sourceIPs){
				IPAddressObj addressObj =getIPAddressObj(sourceIP.getIpAddress().getIpAddress());
				if(addressObj!= null){
					sourceIP.setIpAddress(addressObj);
				}
				
			}
			for(FafFirewallRuleDestinationIpObj destinationIP:destinationIPs){
				IPAddressObj addressObj =getIPAddressObj(destinationIP.getIpAddress().getIpAddress());
				if(addressObj!= null){
				destinationIP.setIpAddress(addressObj);
				}
			}
			for(FafFirewallRulePortObj port:ports){
				PortObject portObject =getPortObject(port.getPort().getService());
				if(portObject!= null){
				port.setPort(portObject);
				}
			}
		}
		getHibernateTemplate().saveOrUpdate(fafFirewallRuleSuggestions);
		log.info("saveFafFirewallRuleSuggestions ends");

	}

	@Override
	@Transactional(readOnly = true)
	public boolean isTicketsToBeCreated(long tiRequest) {
		Session session = getSession();
		List tickets = session
				.createQuery(
						"from FafFireflowTicket tickets where tickets.status=? and tickets.tiRequest.id="
								+ tiRequest
								+ " order by tickets.type , tickets.id desc")
				.setString(0, FafFireflowTicket.NOT_POSTED).setMaxResults(1)
				.list();

		return tickets != null && !tickets.isEmpty();
	}

	@Override
	@Transactional(readOnly = true)
	public boolean isFFTicketsImplemented(Long tiReqId) {
		Session session = getSession();
		List tickets = session
				.createQuery(
						"from FafFireflowTicket tickets where tickets.status in (:ids) and tickets.tiRequest.id="
								+ tiReqId
								+ " order by tickets.type , tickets.id desc")
				.setParameterList("ids",  FafFireflowTicket.getStatusToConsiderImplemented())
				.setMaxResults(1)
				.list();

		return tickets == null || tickets.isEmpty();
	}
	
	@Override
	@Transactional(readOnly = true)
	public boolean isFFTicketsValidated(Long tiReqId) {
		Session session = getSession();
		List tickets = session
				.createQuery(
						"from FafFireflowTicket tickets where tickets.status in (:ids) and tickets.tiRequest.id="
								+ tiReqId
								+ " order by tickets.type , tickets.id desc")
			.setParameterList("ids",  FafFireflowTicket.getStatusToConsiderValidaed())
				.list();

		return tickets == null || tickets.isEmpty();
	}


	@Override
	public void resetRFCGeneratedStatus(Long tiReqId,String conType) {
		log.debug("resetRFCGeneratedStatus called");
		//boolean  fafCompleted = isFFTicketsImplemented(tiReqId);
		String sql = "";
		if(conType.equalsIgnoreCase("IpReg"))
		{
			sql="update ti_request set IP_RFC_GENERATE_FLAG='N' where id="+tiReqId;
		}
		else
		{
			sql="update ti_request set RFC_GENERATE_FLAG='N' where id="+tiReqId;
		}
		//String sql ="update ti_request set RFC_GENERATE_FLAG='N' where id="+tiReqId;
		
			SQLQuery query = getSession().createSQLQuery(sql);
			query.executeUpdate();
		
		log.debug("resetRFCGeneratedStatus called  and updated "+sql);
	}

	@Override
	public List getFafFireflowTicketsByReqId(Long tiRequestId) {

		System.out.println("Returning Fireflow Ticket now");
		Session session = getSession();
		List list = session
		.createQuery(
				"from FafFireflowTicket tickets where tickets.ticketNumber is not null and tickets.status not in ('DELETED','rejected','REJRCTED') and tickets.tiRequest.id=" + tiRequestId + "order by tickets.type , tickets.id desc")
		.list();

         return list;

	}
	
	@Override
	@Transactional(readOnly = true)
	public List getFafFireflowTicketsByReqIdNew(Long tiRequestId) {

		System.out.println("Returning Fireflow Ticket now for new");
		Session session = getSession();
		List list = session
		.createQuery(
				"from FafFireflowTicket tickets where tickets.status not in ('DELETED','rejected','REJRCTED') and tickets.tiRequest.id=" + tiRequestId + "order by tickets.type , tickets.id desc")
		.list();

         return list;

	}

	@Override
	public IPAddressObj getIPAddressObj(String address) {
		Session session = getSession();
		List<IPAddressObj> addressObjs= session.createQuery(
				"from IPAddressObj obj where obj.ipAddress='" + address+"'")
				.setMaxResults(1).list();
		if(addressObjs != null && !addressObjs.isEmpty()){
			return addressObjs.get(0);
		}else{
			return null;
		}
	}

	@Override
	public PortObject getPortObject(String service) {
		Session session = getSession();
		List<PortObject> portObjs= session.createQuery(
				"from PortObject obj where obj.service='" + service+"'")
				.setMaxResults(1).list();
		
		if(portObjs != null && !portObjs.isEmpty()){
			return portObjs.get(0);
		}else{
			return null;
		}
	}

	@Override
	public void deleteRFCFirewallRecords(Long tiReqId, String type) {
		Session session = getSession();
		String query ="";
		if(type.equalsIgnoreCase("IpReg"))
		{
			query ="{ call rfc_generate.cleanup_rfcdetails(?,'Y') }";
		}
		else
		{
			query ="{ call rfc_generate.cleanup_rfcdetails(?,'N') }";
		}
		log.debug("deleteRFCFirewallRecords called");
		Query q1 = session.createSQLQuery(query);
		q1.setLong(0, tiReqId); 
		q1.executeUpdate();

		log.debug("deleteRFCFirewallRecords called  and updated ");

	}

	@Override
	@Transactional(readOnly = true)
	public FafFirewallRuleSuggestion getFafFirewallRuleSuggestion(
			String ticketNo, Long policyId, int ruleSeq, String ffRuleNumber) {
		Session session = getSession();
		Criteria criteria = session
				.createCriteria(FafFirewallRuleSuggestion.class);
		criteria.createCriteria("fafFirewallRule", "fafFirewallRule");
		criteria.createCriteria("fafFirewallRule.fafFireFlowTicket",
				"fafFireFlowTicket");
		criteria.createCriteria("policy", "policy");
		criteria.add(Restrictions
				.eq("ruleNumber", ffRuleNumber));
		criteria.add(Restrictions
				.eq("fafFireFlowTicket.ticketNumber", ticketNo));
		criteria.add(Restrictions.eq("policy.id", policyId));
		criteria.add(Restrictions.eq("fafFirewallRule.ruleSequence", ruleSeq));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.DELETED));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.REJECTED));
		criteria.add(Restrictions.ne("fafFireFlowTicket.status",
				FafFireflowTicket.REJRCTED));
		FafFirewallRuleSuggestion suggestion = (FafFirewallRuleSuggestion) criteria
				.uniqueResult();
		// List list = session.createQuery("from FafFirewallRuleSuggestion s where s.policy.id="+policyId).list();
		return suggestion;
	}
	@Override
	  @SuppressWarnings("unchecked")
		public List<FireWallRuleIP> getIPsforTemplateObject(Long ipId, Long ruleId, String forFAF, Long tiReqId) {
	    	log.info("Entered into getIPsforTemplateObject Method ::>>> ipId  : "+ipId+"  ruleId :"+ruleId+" forFAF  :" +forFAF+"  tiReqId :::"+tiReqId);
			Session session = getSession();
	    	List<FireWallRuleIP> firewallRuleIPs = (List<FireWallRuleIP>)
	    	session.getNamedQuery("getIPsforTemplateObject")
	    	.setLong(0, ipId)
	    	.setLong(1, ruleId)
	    	.setString(2, forFAF)
	    	.setLong(3, tiReqId).list();
	    	log.info("Exited from getIPsforTemplateObject Method ");
	    	return firewallRuleIPs;
	    }

	@Override   @SuppressWarnings("unchecked")
		public List<FireWallRulePort> getPortsforTemplateObject(Long ipId, Long ruleId, String forFAF, Long tiReqId) {
	    	Session session = getSession();
	    	List<FireWallRulePort> firewallRulePorts = (List<FireWallRulePort>)
	    	session.getNamedQuery("getPortsforTemplateObject")
	    	.setLong(0, ipId)
	    	.setLong(1, ruleId)
	    	.setString(2, forFAF)
	    	.setLong(3, tiReqId).list();
	    	return firewallRulePorts;
	    }

	@Override
	public boolean hasFailedChildTicket(String ticketNumber) {
		log.debug("hasFailedChildTicket called");
		Session session = getSession();
		List list = session
		.createQuery(
				"from FafFireflowTicketLog log where log.ffTicketId=? and log.ffSubTicketId<>log.ffTicketId and log.ffId='LCK_TICK' and upper(log.parsingStatus) like '%FAILED%'")
		.setString(0, ticketNumber).list();
		boolean returnValue =(list!=null && !list.isEmpty());
		log.debug("hasFailedChildTicket called>ticketNumber:value"+ticketNumber+returnValue);
         return returnValue;
	}
	    
	@Override
	public boolean hasChildTicket(String ticketNumber) {
		log.debug("hasChildTicket called");
		Session session = getSession();
		List list = session
		.createQuery(
				"from FafFireflowTicketLog log where log.ffTicketId=? and log.ffSubTicketId<>log.ffTicketId")
		.setString(0, ticketNumber).list();
		boolean returnValue =(list!=null && !list.isEmpty());
		log.debug("hasChildTicket called>ticketNumber:value"+ticketNumber+returnValue);
         return returnValue;
	}

	@Override
	 @Transactional( readOnly = true)
	public List<Long> getAllTiRequests(Long processId, String isIpReg, String expType) {
		Session session = getSession();
		String condition = "" , type = "";
		if(isIpReg.equalsIgnoreCase("Y"))
		{
			condition = "WHERE	UPPER(TTT.TASK)=UPPER('IP Registration Implementation') ";	
		}
		else
		{
			condition = "WHERE	UPPER(TTT.TASK)=UPPER('Firewall Implementation') ";
		}
		if(!expType.equalsIgnoreCase("Impl")){
		type = "union "+
				"select id as id from ti_request where process_id="+processId+" and version_number=(select max(version_number) " +
				"from ti_request where process_id="+processId+" and ti_request_type_id not in " +
				"(select id from ti_request_type where request_type in ('ACV','ManageContacts')))";
		}
	
		SQLQuery query = session.createSQLQuery("SELECT distinct TI_REQUEST_ID as id  FROM "+
												"TI_ACTIVITY_TRAIL TAT "+
												"JOIN TI_REQUEST TIR ON TIR.ID=TAT.TI_REQUEST_ID "+
												"JOIN TI_TASK_TYPE TTT ON TTT.ID=TAT.ACTIVITY_ID "+
												condition+
												" AND UPPER(TAT.ACTIVITY_STATUS)=UPPER('COMPLETED') "+
												"AND TIR.PROCESS_ID="+processId+" "+
												type+
												" ");
												
		log.debug("tireq query" +query);
		query.addScalar("id",LongType.INSTANCE);
		List<Long> tiRequests =query.list();
		return tiRequests;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	public TIRequest getTIRequestForGlobalTx(long tiRequestId) {
		TIRequest tiRequest = null;
		log.debug("BasePersistanceImpl:getTIRequest: Entered with Ti Request ID:"
				+ tiRequestId);
		try {
			tiRequest = (TIRequest) getSession().get(TIRequest.class,
					Long.valueOf(tiRequestId));
		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException(
					" There was an exception while getting ti Request:"
							+ tiRequestId);
		}
		log.debug("BasePersistanceImpl:getTIRequest: Exiting with Ti Request:"
				+ tiRequestId);

		if (tiRequest != null && tiRequest.getTiProcess().getId() != null) {
			log.debug("BasePersistanceImpl:getTIRequest: Exiting with Ti Process: "
					+ tiRequest.getTiProcess().getId());
		}

		return tiRequest;
	}

}