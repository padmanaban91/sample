package com.citigroup.cgti.c3par.controller.relationship;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.dashboard.webtier.helper.AttributeToListPositionMapBuilder;
import com.citigroup.cgti.c3par.relationship.domain.AssignCitiLocationProcess;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnitLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.RelReqCitiLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.RelationshipProcess;
import com.citigroup.cgti.c3par.relationship.domain.ResourceTypeLocXref;

@Controller
public class AssignCitiLocationController extends RelationshipBaseController{

	public static final String ATTRIBUTE_LOCATION_ID = "getId";
	private static final String[] attrs = new String[] { ATTRIBUTE_LOCATION_ID };

	private static Logger log = Logger.getLogger(AssignCitiLocationController.class);

	@RequestMapping(value = "/populateCitiLocations.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String populateCitiLocations(ModelMap model, @ModelAttribute("assignCitiLocationProcess") AssignCitiLocationProcess assignCitiLocationProcess
									,HttpServletRequest request) {
		log.debug("AssignCitiLocationController::populateCitiLocations methods starts...");
		
		try {
			String assignTo = request.getParameter("assignTo");
			if ( assignTo != null && !assignTo.isEmpty()) {
				request.getSession().setAttribute("CITI_LOCATION_ASSIGN_TO",assignTo);
			}
			Long resourceTypeId = null;
			
			RelationshipProcess relprocess = getRelationshipProcess(request);
			assignCitiLocationProcess.setCanEdit(relprocess.isCanEdit());
			assignCitiLocationProcess.setRelationshipName(relprocess.getRelationship().getName());
			assignCitiLocationProcess.setBusinessUnitName(relprocess.getBusinessUnit().getBusinessName());
			assignCitiLocationProcess.setSectorName(relprocess.getSector().getName());
			assignCitiLocationProcess.setRelationshipType(relprocess.getRelationship().getRelationshipType());
			
			List<Location> assignedCitiLocations = new ArrayList<Location>();
			if ("requester".equalsIgnoreCase(assignTo)){
				List<RelReqCitiLocationXref> reqcitiloclist = relprocess.getRelReqCitiLocXrefList();
				if(reqcitiloclist != null && !reqcitiloclist.isEmpty()){
					for(RelReqCitiLocationXref reqcitiloc:reqcitiloclist){
						assignedCitiLocations.add(reqcitiloc.getLocation());
					}
				}
				resourceTypeId = relprocess.getRequesterResourceTypeId();
				assignCitiLocationProcess.setReqCitiLocations(assignedCitiLocations);
				request.getSession().setAttribute("CITI_LOCATION_REQ",assignedCitiLocations);
			}else if ("target".equalsIgnoreCase(assignTo)){
				List<RelCitiLocationXref> citiloclist = relprocess.getRelCitiLocXrefList();
				if(citiloclist != null && !citiloclist.isEmpty()){
					for(RelCitiLocationXref citiloc:citiloclist){
						assignedCitiLocations.add(citiloc.getLocation());
					}
				}
				resourceTypeId = relprocess.getTargetResourceTypeId();
				assignCitiLocationProcess.setCitiLocations(assignedCitiLocations);
				request.getSession().setAttribute("CITI_LOCATION_TAR",assignedCitiLocations);
			}
			//add existing location into map builder to remove & avoid duplicates
			AttributeToListPositionMapBuilder listPosition = new AttributeToListPositionMapBuilder(assignedCitiLocations, attrs);

			List<Location> allcitiLocations = new ArrayList<Location>();
			List<Location> newcitiLocations = new ArrayList<Location>();
			
			List<BusinessUnitLocationXref> citilocationsBusinessList = null;
			if (relprocess.getBusinessUnit() != null && relprocess.getBusinessUnit().getId() != null) {
				citilocationsBusinessList = assignCitiLocationProcess.SearchBusinessUnitLocation(relprocess.getBusinessUnit().getId());
			} 
			if(citilocationsBusinessList != null && !citilocationsBusinessList.isEmpty()){
				log.debug("AssignCitiLocationController::populateCitiLocations :: citilocationsBusinessList "+citilocationsBusinessList.size());
				for(BusinessUnitLocationXref buloc:citilocationsBusinessList){
					newcitiLocations.add(buloc.getLocation());
				}
			}
			
			List<ResourceTypeLocXref> restypelocList = null;
			if(resourceTypeId != null && resourceTypeId.longValue() > 0){
				restypelocList = assignCitiLocationProcess.searchResourceTypeLocXref(resourceTypeId);
			}
			if(restypelocList != null && !restypelocList.isEmpty()){
				log.debug("AssignCitiLocationController::populateCitiLocations :: restypelocList "+restypelocList.size());
				for(ResourceTypeLocXref restypeloc:restypelocList){
					newcitiLocations.add(restypeloc.getLocation());
				}
			}

			if(newcitiLocations != null && !newcitiLocations.isEmpty()){
				for(Location location:newcitiLocations){
					Integer id = listPosition.getPosition(ATTRIBUTE_LOCATION_ID, location.getId());
					if(id == null){
						allcitiLocations.add(location);
					}
				}
			}			
			assignCitiLocationProcess.setResourceTypeId(resourceTypeId);
			assignCitiLocationProcess.setBusinessUnitId(relprocess.getBusinessUnit().getId());
			assignCitiLocationProcess.setAllCitiLocations(allcitiLocations);
			assignCitiLocationProcess.setSelectedItems(null);	
			assignCitiLocationProcess.setUnSelectedItems(null);
			request.getSession().setAttribute("CITI_LOCATION_ALL",allcitiLocations);
			
			setInSession(request, relprocess);
			model.addAttribute("assignCitiLocationProcess",assignCitiLocationProcess);			
		} catch (Exception e) {
			log.error("Exception occured while performing a query to fetch third party locations",e);
		}
		
		return "pages/relationship/AssignCitigroupLocations";
	}

	@RequestMapping(value = "/assignCitiLocation.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String assignCitiLocation(ModelMap model,@ModelAttribute("assignCitiLocationProcess") AssignCitiLocationProcess assignCitiLocationProcess
			 						,HttpServletRequest request) {
		log.debug("AssignCitiLocationController::assignCitiLocation methods starts...");
		String assignTo = (String) request.getSession().getAttribute("CITI_LOCATION_ASSIGN_TO");	

		String[] selectedCitiLocIds = assignCitiLocationProcess.getSelectedItems();

		List<Location> allCitiLocations = (List<Location>) request.getSession().getAttribute("CITI_LOCATION_ALL");
		List<Location> assignedtpLocations = null;
		
		if(assignTo != null && assignTo.equalsIgnoreCase("requester")){
			assignedtpLocations =  (List<Location>) request.getSession().getAttribute("CITI_LOCATION_REQ");
		}else if(assignTo != null && assignTo.equalsIgnoreCase("target")){
			assignedtpLocations =  (List<Location>) request.getSession().getAttribute("CITI_LOCATION_TAR");
		}		
		
		if(selectedCitiLocIds != null && selectedCitiLocIds.length > 0){
			int count = 0;
			for(String locIds:selectedCitiLocIds){
				int index = Integer.valueOf(locIds);
				log.debug("AssignThirdPartyContactController :: assignCitiLocation :: index - "+index);				
				Location loc = (Location) allCitiLocations.get(index-count);
				
				assignedtpLocations.add(loc);
				allCitiLocations.remove(index-count);
				count++;
			}
		}
		request.getSession().setAttribute("CITI_LOCATION_ALL",allCitiLocations);

		//set the list in the relationship process for save
		RelationshipProcess relprocess = getRelationshipProcess(request);
		
		if(assignTo != null && assignTo.equalsIgnoreCase("requester")){
			assignCitiLocationProcess.setReqCitiLocations(assignedtpLocations);
			request.getSession().setAttribute("CITI_LOCATION_REQ",assignedtpLocations);

			//set into relationship process
			List<RelReqCitiLocationXref> reqcitiloclist = new ArrayList<RelReqCitiLocationXref>();
			
			for(Location reqcitiloc:assignedtpLocations){
				RelReqCitiLocationXref locxref = new RelReqCitiLocationXref();
				locxref.setLocation(reqcitiloc);
				reqcitiloclist.add(locxref);
			}
			relprocess.setRelReqCitiLocXrefList(reqcitiloclist);
					
		}else if(assignTo != null && assignTo.equalsIgnoreCase("target")){
			assignCitiLocationProcess.setCitiLocations(assignedtpLocations);
			request.getSession().setAttribute("CITI_LOCATION_TAR",assignedtpLocations);

			//set into relationship process
			List<RelCitiLocationXref> citiloclist = new ArrayList<RelCitiLocationXref>();
			
			for(Location citiloc:assignedtpLocations){
				RelCitiLocationXref locxref = new RelCitiLocationXref();
				locxref.setLocation(citiloc);
				citiloclist.add(locxref);
			}
			relprocess.setRelCitiLocXrefList(citiloclist);
			
		}		
		assignCitiLocationProcess.setAllCitiLocations(allCitiLocations);
		assignCitiLocationProcess.setSelectedItems(null);	
		assignCitiLocationProcess.setUnSelectedItems(null);
		
		setInSession(request, relprocess);
		model.addAttribute("assignCitiLocationProcess", assignCitiLocationProcess);
		
		return "pages/relationship/AssignCitigroupLocations";
	}

	@RequestMapping(value = "/unassignCitiLocation.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String unassignCitiLocation(ModelMap model,@ModelAttribute("assignCitiLocationProcess") AssignCitiLocationProcess assignCitiLocationProcess
			 						,HttpServletRequest request) {
		log.debug("AssignCitiLocationController::unassignCitiLocation methods starts...");
		String assignTo = (String) request.getSession().getAttribute("CITI_LOCATION_ASSIGN_TO");	

		String[] unselectedCitiLocIds = assignCitiLocationProcess.getUnSelectedItems();

		List<Location> allCitiLocations = (List<Location>) request.getSession().getAttribute("CITI_LOCATION_ALL");
		List<Location> assignedtpLocations = null;
		
		if(assignTo != null && assignTo.equalsIgnoreCase("requester")){
			assignedtpLocations =  (List<Location>) request.getSession().getAttribute("CITI_LOCATION_REQ");
		}else if(assignTo != null && assignTo.equalsIgnoreCase("target")){
			assignedtpLocations =  (List<Location>) request.getSession().getAttribute("CITI_LOCATION_TAR");
		}		
		
		if(unselectedCitiLocIds != null && unselectedCitiLocIds.length > 0){
			int count = 0;
			for(String locIds:unselectedCitiLocIds){
				int index = Integer.valueOf(locIds);
				log.debug("AssignThirdPartyContactController :: unassignCitiLocation :: index - "+index);
				
				Location loc = (Location) assignedtpLocations.get(index-count);				
				assignedtpLocations.remove(index-count);
				allCitiLocations.add(loc);
				count++;
			}
		}
		request.getSession().setAttribute("CITI_LOCATION_ALL",allCitiLocations);

		//set the list in the relationship process for save
		RelationshipProcess relprocess = getRelationshipProcess(request);
		
		if(assignTo != null && assignTo.equalsIgnoreCase("requester")){
			assignCitiLocationProcess.setReqCitiLocations(assignedtpLocations);
			request.getSession().setAttribute("CITI_LOCATION_REQ",assignedtpLocations);

			//set into relationship process
			List<RelReqCitiLocationXref> reqcitiloclist = new ArrayList<RelReqCitiLocationXref>();
			
			for(Location reqcitiloc:assignedtpLocations){
				RelReqCitiLocationXref locxref = new RelReqCitiLocationXref();
				locxref.setLocation(reqcitiloc);
				reqcitiloclist.add(locxref);
			}
			relprocess.setRelReqCitiLocXrefList(reqcitiloclist);
					
		}else if(assignTo != null && assignTo.equalsIgnoreCase("target")){
			assignCitiLocationProcess.setCitiLocations(assignedtpLocations);
			request.getSession().setAttribute("CITI_LOCATION_TAR",assignedtpLocations);

			//set into relationship process
			List<RelCitiLocationXref> citiloclist = new ArrayList<RelCitiLocationXref>();
			
			for(Location citiloc:assignedtpLocations){
				RelCitiLocationXref locxref = new RelCitiLocationXref();
				locxref.setLocation(citiloc);
				citiloclist.add(locxref);
			}
			relprocess.setRelCitiLocXrefList(citiloclist);
			
		}		
		assignCitiLocationProcess.setAllCitiLocations(allCitiLocations);
		assignCitiLocationProcess.setSelectedItems(null);	
		assignCitiLocationProcess.setUnSelectedItems(null);
		
		setInSession(request, relprocess);
		model.addAttribute("assignCitiLocationProcess", assignCitiLocationProcess);
		
		return "pages/relationship/AssignCitigroupLocations";
	}

	@RequestMapping(value = "/deleteCitiLocations.act", method = {RequestMethod.GET, RequestMethod.POST })
	public String deleteCitiLocations(ModelMap model, @ModelAttribute("assignCitiLocationProcess") AssignCitiLocationProcess assignCitiLocationProcess
										,HttpServletRequest request) {

		String locstr = request.getParameter("locationId");
		String assignTo = (String) request.getSession().getAttribute("CITI_LOCATION_ASSIGN_TO");	
		
		log.debug("AssignThirdPartyLocationController :: deleteCitiLocations :: locId - "+locstr);
		
		if(locstr != null && !locstr.isEmpty()){
			Long locId = Long.valueOf(locstr);

			int count = assignCitiLocationProcess.getRelationshipForCitiLocation(locId);
			if(count <= 0){
				assignCitiLocationProcess.deleteCitiLocationXrefById(locId);
			}else{
				log.error("Citigroup Location is already used in the relationship");
				request.getSession().setAttribute("ERROR_MSG",	"Citigroup Location is already used in the relationship");
			}
		}
		
		return "forward:/populateCitiLocations.act?assignTo="+assignTo;
	}
	 
}
