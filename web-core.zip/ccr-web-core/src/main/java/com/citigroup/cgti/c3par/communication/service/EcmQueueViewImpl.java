package com.citigroup.cgti.c3par.communication.service;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.communication.domain.EcmQueue;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueSectors;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueUsers;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueViewProcess;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.EcmQueueViewPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.user.domain.C3parUser;




@Transactional
public class EcmQueueViewImpl extends BasePersistanceImpl implements
		EcmQueueViewPersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(EcmQueueViewImpl.class);

	private DataSource dataSource;

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	@Transactional(readOnly = true)
	public List<EcmQueue> selectQueueDetails(EcmQueueViewProcess ecmQueueViewProcess) {

		List<EcmQueue> list = null;
		log.info("EcmQueueViewImpl::selectQueueDetails starts>>>");
		try{
			Session session = getSession();		
			Criteria query = session.createCriteria(EcmQueue.class); 
			list = (List<EcmQueue>)query.list();		
			log.debug("selectQueueDetails :: size"+list.size());
		
		} catch (Exception e) {
			log.error("EcmQueueViewImpl::selectQueueDetails>>> " + e);
		}

		return list;
	}

	@Override
	@Transactional(readOnly = true)
	public List<EcmQueueUsers> ecmUserRoleList(long ecmqueueId) throws Exception 
	{
		List<EcmQueueUsers> userRolelist = null;
		Session session = getSession();
		log.info("In EcmQueueViewImpl :: ecmUserRoleList");
		    try{
		    	
		    	String fetchSectorSql = "from EcmQueueUsers where ecmQueue.id="+ecmqueueId;
		    	log.debug("user role list query ::"+fetchSectorSql);
		    	userRolelist=  (List<EcmQueueUsers>) session.createQuery(fetchSectorSql).list();
		    	
		    	log.debug("lazyInitialize...EcmQueueUsers...");
		    	if(userRolelist != null && userRolelist.size() > 0){
		    		for(EcmQueueUsers userRole:userRolelist){
		    			lazyInitialize(userRole); 
		    			lazyInitialize(userRole.getC3parUser());
		    			lazyInitialize(userRole.getC3parUser().getUserRoleList());
		    			lazyInitialize(userRole.getEcmQueue());
		    		}
		    	}
		    	log.debug("In EcmQueueViewImpl ecmUserRoleList details"+session.createQuery(fetchSectorSql)+"   "+userRolelist.size());
		      }
		    catch (HibernateException e){
		    	log.error(e,e);
		    	throw new Exception("Exception has occured",e);
		    }
		    
	    return userRolelist;
    }
	
	

	
	@Override
    public boolean mapEcmUsertoSector(Long sector, String ecmUser,String userId) {
           // TODO Auto-generated method stub
           
           log.info("IMPL:Entering into mapEcmUsertoSector()..");  
            
           int result = 0;
           EcmQueueUsers ecmQusers; 
           C3parUser c3parUser = new C3parUser();
           EcmQueue eq = new EcmQueue();
           try {
                  Session session = getSession();  
                  Query query = session.createQuery("from C3parUser where upper(ssoId) = ?").setString(0, ecmUser.toUpperCase());
                     Long c3ParUserId = ((C3parUser) query.list().get(0)).getId();
                     log.debug("EcmQueueViewImpl :: mapEcmUsertoSector :: c3ParUserId:"+c3ParUserId);
           
                     if(c3ParUserId!=null){
                    	 
                	   ecmQusers= (EcmQueueUsers) session.createQuery("from EcmQueueUsers where c3parUser.id=" +c3ParUserId).uniqueResult();
                       log.info("ecmQusers.."+ecmQusers);
                       if(ecmQusers != null){
  		                        if(ecmQusers.getEcmQueue().getId() != sector){
  		                        	 eq.setId(sector);
  		                        	 ecmQusers.setEcmQueue(eq);
  		                             log.info("eQusers.getEcmQueue()."+ecmQusers.getEcmQueue().getId());
  		                             getHibernateTemplate().saveOrUpdate(ecmQusers);
  		                        }
  			           }else{
  			        	   ecmQusers = new EcmQueueUsers();
  			                  eq.setId(sector);
  			                  c3parUser.setId(c3ParUserId);
  			                  ecmQusers.setEcmQueue(eq);
  			                  ecmQusers.setC3parUser(c3parUser);
  			                  log.info("eQusers.getEcmQueue().getId()1S.."+ecmQusers.getEcmQueue().getId());
  			                  log.info("eQusers.getEcmQueue().getId()1W.."+ecmQusers.getC3parUser().getId());
  			                  getHibernateTemplate().saveOrUpdate(ecmQusers);
  			           }
  			         
  		                  
                   }
               
		   } catch (Exception e) {
                  log.error("EcmQueueViewImpl::mapEcmUsertoSector>>> " + e);
           }
           
           log.info("Exit from mapEcmUsertoSector()..");
                        
           return result==1? true:false;            
    }


	@Override
	@Transactional(readOnly = true)
	public List<Long>  selectedEcmSector(long ecmqueueId) throws Exception  { 
		
		List<Long> selectedSectors =new ArrayList<Long>(); 
		List<EcmQueueSectors> ecmSectorList = null;
		Session session = getSession();  
		log.info("In EcmQueueViewImpl :: selectedEcmSector method");
	    try{
	    	String fetchSectorSql = "from EcmQueueSectors where ecmQueue.id="+ecmqueueId;
	    	log.debug("selected sector queue list query ::"+fetchSectorSql);
	    	ecmSectorList=  (List<EcmQueueSectors>) session.createQuery(fetchSectorSql).list();
	    	log.debug("In EcmQueueViewImpl ecmSectorList details>>>"+session.createQuery(fetchSectorSql)+">> sector list  "+ecmSectorList.size());
	    	
	    	if(ecmSectorList != null) {
				   for(EcmQueueSectors ecmSector : ecmSectorList){
					   log.debug("selected sector ids from selectedEcmSector>>"+ecmSector.getSector().getId());
					   selectedSectors.add(ecmSector.getSector().getId());
					}
			    	
			 }
	   }catch (HibernateException e)
	    {
	    	log.error(e,e);
	    	throw new Exception("Exception has occured",e);
	    }
		return  selectedSectors;
	}
	
	
	
	@Override
	public void updateEcmQueueViewDetails(EcmQueueViewProcess ecmqueueViewProcess){
		
		Long ecmqueueId =  ecmqueueViewProcess.getEcmQueueId();
		deleteEcmQueueSector(ecmqueueId);
		List<Long> selectedSectors = ecmqueueViewProcess.getSelectedSectors();
		if (selectedSectors != null && selectedSectors.size() > 0){
			for (Long sectorId : selectedSectors) {
				log.debug("sectorID selected array values::sectorId" + sectorId); 
				log.debug("save ECM Sector Queue EcmQueueViewImpl :: updateEcmQueueViewDetails::ecmqueueId::"+ecmqueueId);
				updateEcmSectorQueue(sectorId,ecmqueueId);
			}
		}
		
		if(ecmqueueViewProcess.getEcmQueueUsersList() != null && !ecmqueueViewProcess.getEcmQueueUsersList().isEmpty()){ 
			for(EcmQueueUsers ecmQueueUsers:ecmqueueViewProcess.getEcmQueueUsersList()){
				log.debug("EcmQueueViewImpl :: deleteEcmQueueViewDetail :: id - "+ecmQueueUsers.getId()+" :: isDisabled() - "+ecmQueueUsers.isDisabled());				
				//User deleted existing ecmQueueUser
				if(ecmQueueUsers.getId() != null && ecmQueueUsers.getId().longValue() > 0 && ecmQueueUsers.isDisabled()){
					log.debug("ecm id ::"+ecmqueueId+" :: ecmQueue User id - "+ecmQueueUsers.getId()+" :: isDisabled() - "+ecmQueueUsers.isDisabled());	
					deleteEcmQueueUser(ecmQueueUsers.getId(),ecmqueueId);
					log.debug("deleted :: ecmQueue User id - "+ecmQueueUsers.getId());
				}
			}
		}
		
		
		
	}
	
	

	public boolean deleteEcmQueueUser(long ecmUserId,long ecmQueueId){
		
		int result = 0;
		log.info("Entering into deleteEcmQueueUser..");
		log.debug(">>>>EcmQueueViewImpl:: deleteEcmQueueUser:: ecmUserId::"+ecmUserId+"ecmQueueId ::"+ecmQueueId);
		SQLQuery query = getSession().createSQLQuery("delete from ECM_QUEUE_USERS where ID = "+ecmUserId);
		result = query.executeUpdate();
		log.debug("EcmQueueViewImpl::deleteEcmQueueUser...deleted::"+ecmQueueId+"::"+result); 
		log.info("Exit from updateEcmSectorQueue()..");
	    return result==1? true:false;     
	}
	
	public boolean deleteEcmQueueSector(long ecmqueueId){
		int result = 0;
		log.info("Entering into deleteEcmQueueSector..");
		log.debug(">>>>EcmQueueViewImpl:: deleteEcmQueueSector:: ecmQueueId ::"+ecmqueueId);
		SQLQuery query = getSession().createSQLQuery("delete from ECM_QUEUE_SECTORS where ECM_QUEUE_ID = "+ecmqueueId);
		result = query.executeUpdate();
		log.debug("EcmQueueViewImpl::deleteEcmQueueSector...deleted::"+ecmqueueId+"::result::"+result); 
		log.info("Exit from deleteEcmQueueSector()..");
	    return result==1? true:false;     
	}
	
	public boolean updateEcmSectorQueue(long sectorId, long ecmqueueId){
		 
        log.info("Entering into updateEcmSectorQueue()..");
        
        int result = 0;
        EcmQueueSectors ecmQueueSectors;
        EcmQueue ecmQueue = new EcmQueue();
        Sector sector = new Sector();
         
        try {
           ecmQueueSectors = new EcmQueueSectors();
    	   ecmQueue.setId(ecmqueueId);
    	   ecmQueueSectors.setEcmQueue(ecmQueue);
    	   sector.setId(sectorId);
    	   ecmQueueSectors.setSector(sector);
           getHibernateTemplate().saveOrUpdate(ecmQueueSectors);
           result = 1;
        } catch (Exception e) {
               log.error("EcmQueueViewImpl::updateEcmSectorQueue>>> " + e);
        }
        log.info("Exit from updateEcmSectorQueue..result >>"+result);
        return result==1? true:false;     
	}
	
}
	