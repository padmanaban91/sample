package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;
import java.util.List;

import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;

public class TechnicalContactRejectAction extends MailAction {

Logger log = Logger.getLogger(TechnicalContactRejectAction.class);
	
private final static String ROLE_NAME = "TECHNICAL CONTACT";
	@Override
	public void process(IncomingMessage message) {
		
		log.info("Inside TechnicalContactRejectAction process method ");
		
		super.processReject(message,ROLE_NAME);
		
	}
}
