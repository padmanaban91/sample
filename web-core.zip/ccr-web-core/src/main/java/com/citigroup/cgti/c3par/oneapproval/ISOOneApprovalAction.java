package com.citigroup.cgti.c3par.oneapproval;

import net.nsroot.eur.servicesolutions.cate.integration.MessageTypeEnum;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionStatusEnum;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;

/**
 * 
 * @author ne36745
 *
 */
public class ISOOneApprovalAction extends OneApprovalAction {

    Logger log = Logger.getLogger(ISOOneApprovalAction.class);

    /**
     * Process ISO Approve/Reject Action
     */
    @Override
    public void process(OneApprovalMessageLog message) {

        String ssoId = null;
        String status = null;
        String comments = null;
        String messageType = null;

        // To get GEID, status and comments
        if (message.getOneApprovalmsgTextList() != null && message.getOneApprovalmsgTextList().size() > 0) {
            String geId = message.getOneApprovalmsgTextList().get(0).getUpdatedByGEId();
            status = message.getOneApprovalmsgTextList().get(0).getStatus();
            comments = message.getOneApprovalmsgTextList().get(0).getComments();
            messageType = message.getOneApprovalmsgTextList().get(0).getMessageType();
            ssoId = getSSOID(geId);
        }

        WsPapiFacade papiFacade = new WsPapiFacade();
        log.debug("ISOOneApprovalAction Status: " + status);
        String approvalSystem = OneApprovalConstants.APPROVAL_SYSTEM_OA;

        if (message.getApproverType() != null && message.getApproverType().equalsIgnoreCase("F")) {
            approvalSystem = OneApprovalConstants.APPROVAL_SYSTEM_OA_FWD;
        } else if (message.getApproverType() != null && message.getApproverType().equalsIgnoreCase("D")) {
            approvalSystem = OneApprovalConstants.APPROVAL_SYSTEM_OA_DEL;
        }
        Long responseId = 0L;
        // Only if the status is APPROVED or REJECTED
        if (MessageTypeEnum.UPDATE.toString().equalsIgnoreCase(messageType)
                && PurchaseOptionStatusEnum.APPROVED.toString().equals(status)
                || PurchaseOptionStatusEnum.REJECTED.toString().equals(status)) {
            responseId = saveMail(message.getOrderingSystemMappingId(), ssoId,
                    "OA:" + message.getActivity() + "/" + message.getOrderId());
            try {
                Long userId = getUserID(ssoId);
                if (PurchaseOptionStatusEnum.APPROVED.toString().equals(status)) {
                    log.debug("ISOOneApprovalAction activity status to bpm: " + OneApprovalConstants.STATUS_COMPLETED);
                    // papiFacade.completeActivity(userId.toString(),
                    // getInstanceId(message.getTiRequestId()),
                    // OneApprovalConstants.STATUS_COMPLETED);

                } else {
                    log.debug("ISOOneApprovalAction activity status to bpm: " + WsPapiFacade.ActivityStatus.REJECTED);
                    papiFacade.completeActivity(userId.toString(), getInstanceId(message.getTiRequestId()),
                            WsPapiFacade.ActivityStatus.REJECTED, WsPapiFacade.ActivityRejectedToRole.PC_ROLE);
                }
                addComments(comments, message.getTiRequestId(), OneApprovalConstants.ROLE_BISO, getUserID(ssoId),
                        approvalSystem);
                update(responseId, "Y", "Action completed successfully");
            } catch (OperationException_Exception e) {
                update(responseId, "N", getExceptionMessage(e));
                log.error(e, e);
            }
        }
    }

}
