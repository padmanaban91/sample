/*
 * Created on Mar 28, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.webtier.helper;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.lookup.SecurityRoleLookup;
import com.citigroup.cgti.c3par.model.C3parUsersEntity;
import com.citigroup.cgti.c3par.model.RegionEntity;
import com.citigroup.cgti.c3par.model.SectorEntity;
import com.citigroup.cgti.c3par.model.SecurityRoleEntity;


/**
 * The Class UserEntitlementHelper.
 *
 * @author dr97938
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UserEntitlementHelper {

    /** The Constant REGION. */
    public static final String REGION="Region";

    /** The Constant SECTOR. */
    public static final String SECTOR="Sector";

    /** The Constant SECTOR_LIST. */
    public static final String SECTOR_LIST="SECTOR_LIST";

    /** The Constant DEFAULT_SECTOR_LIST. */
    public static final String DEFAULT_SECTOR_LIST="DEF_SECTOR_LIST";

    /** The log. */
    private static Logger log = Logger.getLogger(UserEntitlementHelper.class);

    /**
     * Gets the id for security admin.
     *
     * @return the id for security admin
     */
    public  Long getIdForSecurityAdmin()
    {
	List securityRoleList = SecurityRoleLookup.getInstance().getAll();
	Long id=null;
	if(securityRoleList!=null)
	{
	    Iterator itr=securityRoleList.iterator();
	    while(itr.hasNext())
	    {
		SecurityRoleEntity roleEntity=(SecurityRoleEntity)itr.next();
		if(roleEntity!=null && roleEntity.equals("C3PARSECURITYADMIN"))
		{
		    id=roleEntity.getId();
		    break;
		}
	    }
	}
	return id;
    }

    /**
     * Gets the id for c3 par user.
     *
     * @return the id for c3 par user
     */
    public  Long getIdForC3PARUser()
    {
	List securityRoleList = SecurityRoleLookup.getInstance().getAll();
	Long id=null;
	if(securityRoleList!=null)
	{
	    Iterator itr=securityRoleList.iterator();
	    while(itr.hasNext())
	    {
		SecurityRoleEntity roleEntity=(SecurityRoleEntity)itr.next();
		if(roleEntity!=null && roleEntity.getName().equals("C3PARUSER"))
		{
		    id=roleEntity.getId();
		    break;
		}
	    }
	}
	return id;
    }

    /**
     * Gets the id for entitlement requester.
     *
     * @return the id for entitlement requester
     */
    public  Long getIdForEntitlementRequester()
    {
	List securityRoleList = SecurityRoleLookup.getInstance().getAll();
	Long id=null;
	if(securityRoleList!=null)
	{
	    Iterator itr=securityRoleList.iterator();
	    while(itr.hasNext())
	    {
		SecurityRoleEntity roleEntity=(SecurityRoleEntity)itr.next();
		if(roleEntity!=null && roleEntity.getName().equals("Entitlement Requester"))
		{
		    id=roleEntity.getId();
		    break;
		}
	    }
	}
	return id;
    }

    //Added for 9348 - ECM Role - Starts
    /**
     * Gets the id for Project Coordinator.
     *
     * @return the id for Project Coordinator
     */
    public  Long getIdForProjectCoordinator()
    {
	List securityRoleList = SecurityRoleLookup.getInstance().getAll();
	Long id=null;
	if(securityRoleList!=null)
	{
	    Iterator itr=securityRoleList.iterator();
	    while(itr.hasNext())
	    {
		SecurityRoleEntity roleEntity=(SecurityRoleEntity)itr.next();
		if(roleEntity!=null && roleEntity.getName().equals("Project_Coordinator"))
		{
		    id=roleEntity.getId();
		    break;
		}
	    }
	}
	return id;
    }

    /**
     * Gets the id for Design Engineer.
     *
     * @return the id for Design Engineer
     */
    public  Long getIdForTechnicalCoordinator()
    {
	List securityRoleList = SecurityRoleLookup.getInstance().getAll();
	Long id=null;
	if(securityRoleList!=null)
	{
	    Iterator itr=securityRoleList.iterator();
	    while(itr.hasNext())
	    {
		SecurityRoleEntity roleEntity=(SecurityRoleEntity)itr.next();
		if(roleEntity!=null && roleEntity.getName().equals("Design_Engineer"))
		{
		    id=roleEntity.getId();
		    break;
		}
	    }
	}
	return id;
    }

    /**
     * Gets the id for ECM.
     *
     * @return the id for ECM
     */
    public  Long getIdForECM()
    {
	List securityRoleList = SecurityRoleLookup.getInstance().getAll();
	Long id=null;
	if(securityRoleList!=null)
	{
	    Iterator itr=securityRoleList.iterator();
	    while(itr.hasNext())
	    {
		SecurityRoleEntity roleEntity=(SecurityRoleEntity)itr.next();
		if(roleEntity!=null && roleEntity.getName().equals("ECM"))
		{
		    id=roleEntity.getId();
		    break;
		}
	    }
	}
	return id;
    }
    //Added for 9348 - ECM Role - Ends

    /**
     * Gets the id for Manager / BusinessManager.
     *
     * @return the id for Manager / BusinessManager
     */
    public  Long getIdForManager()
    {
	List securityRoleList = SecurityRoleLookup.getInstance().getAll();
	Long id=null;
	if(securityRoleList!=null)
	{
	    Iterator itr=securityRoleList.iterator();
	    while(itr.hasNext())
	    {
		SecurityRoleEntity roleEntity=(SecurityRoleEntity)itr.next();
		if(roleEntity!=null && roleEntity.getName().equals("Manager"))
		{
		    id=roleEntity.getId();
		    break;
		}
	    }
	}
	return id;
    }

    /**
     * Gets the id for BusinessUser.
     *
     * @return the id for BusinessUser
     */
    public  Long getIdForBusinessUser()
    {
	List securityRoleList = SecurityRoleLookup.getInstance().getAll();
	Long id=null;
	if(securityRoleList!=null)
	{
	    Iterator itr=securityRoleList.iterator();
	    while(itr.hasNext())
	    {
		SecurityRoleEntity roleEntity=(SecurityRoleEntity)itr.next();
		if(roleEntity!=null && roleEntity.getName().equals("Business User"))
		{
		    id=roleEntity.getId();
		    break;
		}
	    }
	}
	return id;
    }
    //given user id get all entitlements
    /**
     * Gets the entitlements for user.
     *
     * @param userId the user id
     * @return the entitlements for user
     */
    public  List getEntitlementsForUser(Long userId)
    {
	List userEntitlementList=new ArrayList();

	try
	{
	    /*C3parUsersLookup dao = C3parUsersLookup.getInstance();
	    C3parUsersEntity entity = dao.getById(userId);
	    List entitlements=entity.getUserEntitlements();
	    if(entitlements!=null)
	    {
		Iterator itr=entitlements.iterator();
		while(itr.hasNext())
		{
		    C3parUserEntitlementXrefEntity userEntXref=	(C3parUserEntitlementXrefEntity)itr.next();
		    //UserEntitlementEntityForm entitForm=new UserEntitlementEntityForm();
		    //entitForm.setPermission(userEntXref.getPermissions());
		    UserEntitlementEntityForm entitForm=getDataForInstanceId(userEntXref.getEntitlementInstanceId());
		    entitForm.setPermission(userEntXref.getPermissions());
		    userEntitlementList.add(entitForm);
		}
	    }*/
	}
	catch(Exception e)
	{
	    log.error(e);
	}
	return userEntitlementList;
    }


    /**
     * Gets the entitled users.
     *
     * @param activeEntInsts the active ent insts
     * @param isAdmin the is admin
     * @return the entitled users
     */
    public  List getEntitledUsers(Set activeEntInsts,boolean isAdmin)
    {
	C3parSession dbsession=new C3parSession();
	Connection con=null;
	Statement stmt =null;
	ResultSet rs=null;
	String sql=null;

	//C3parUserEntitlementXrefDAO usrEntDAO=new C3parUserEntitlementXrefDAO(dbsession);
	List userEntities = new ArrayList();
	StringBuffer str=new StringBuffer();
	try
	{
	    con=dbsession.getConnection();
	    stmt=con.createStatement();
	    if(!isAdmin)
	    {
		String entIds=convertCollectionToString(activeEntInsts);
		sql ="select distinct  c3par_users.id,c3par_users.FIRST_NAME,c3par_users.LAST_NAME from usr_ent_xref,c3par_users where usr_ent_xref.USER_ID=c3par_users.id and usr_ent_xref.ENTITLEMENT_INSTANCE_ID in ("+entIds +") order by c3par_users.FIRST_NAME";
	    }
	    else
		sql ="select distinct  c3par_users.id,c3par_users.FIRST_NAME,c3par_users.LAST_NAME from usr_ent_xref,c3par_users where usr_ent_xref.USER_ID=c3par_users.id  order by c3par_users.FIRST_NAME";
	    rs = stmt.executeQuery(sql);
	    if(rs!=null)
	    {

		while(rs.next())
		{
		    C3parUsersEntity ent=new C3parUsersEntity();
		    ent.setId(Long.valueOf(rs.getLong(1)));
		    ent.setFirstName(rs.getString(2));
		    ent.setLastName(rs.getString(3));
		    userEntities.add(ent);

		}
	    }

	}
	catch(Exception e)
	{
	    log.error(e);
	}
	finally
	{
	    try
	    {
		if(rs!=null)
		    rs.close();
		if(stmt!=null)
		    stmt.close();
		if(con!=null)
		    con.close();
	    }
	    catch(SQLException e)
	    {
		log.error(e);
	    }
	}

	return userEntities;
    }

    /**
     * Convert collection to string.
     *
     * @param instIds the inst ids
     * @return the string
     */
    public  String convertCollectionToString(Collection instIds)
    {
	StringBuffer  str=new StringBuffer();

	if(instIds!=null)
	{
	    Iterator itr=instIds.iterator();
	    int size=instIds.size();
	    int count=0;
	    while(itr.hasNext())
	    {
		str.append((Long)itr.next());
		if(count!=size-1)
		    str.append(",");
		count++;
	    }

	}
	if(str!=null && str.length()==0 )
	    return null;
	else
	    return (str.toString());

    }

 
    /**
     * Convert array to string.
     *
     * @param ids the ids
     * @return the string
     */
    public  String convertArrayToString(Object[] ids)
    {
	StringBuffer  str=new StringBuffer();
	if(ids!=null){
	    int length=ids.length;
	    for(int i=0;i<length;i++){
		str.append(ids[i]);
		if(i!=length-1)
		    str.append(",");
	    }
	}
	if(str!=null && str.length()==0 )
	    return null;
	else
	    return (str.toString());
    }
    
    public Long checkEntitlementExists(String ssoID) throws Exception
    {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		Long id = 0L;
		C3parSession dbsession = new C3parSession();	
		try{
		    StringBuffer str=new StringBuffer("select id from c3par_users where upper(sso_id) = upper('"+ssoID+"')");
		    log.debug("UserEntitlementHelper::getNewRolesForEntitlement::str==>"+str.toString());
		    con = dbsession.getConnection();
		    stmt = con.createStatement();
		    rs = stmt.executeQuery(str.toString());
		    if(rs != null && rs.next())
		    {
		    	id = rs.getLong(1);
		    }
		}
		catch(SQLException e){
		    log.error(e);
		    throw e;
		}
		catch(Exception e){
		    log.error(e);
		    throw e;
		}
		finally{
			if(rs != null)
				rs.close();
			if(stmt != null)
				stmt.close();
			if(con != null)
				con.close();
		}
		return id;
    }
    public String isUserIDExistsInCCR(String ssoID)
    {
    	String isexists = "N";
    	try{
    		Long Id = checkEntitlementExists(ssoID);
    		if(Id != null && Id > 0){
    			isexists = "Y";
    		}
    	}catch(Exception e){
    		log.error(e);
    	}
    	return isexists;
    }
    public List<Long> getNewRolesForEntitlement(String contactListRole,String existsInCCR) throws Exception{
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		List<Long> rolesList=new ArrayList<Long>();
		C3parSession dbsession = new C3parSession();	
		try{
		    StringBuffer str=new StringBuffer("select new_role from target_contact_accept_mapping targetmap join role r on targetmap.role_id = r.id ");
		    str.append("where r.display_name = '"+contactListRole+"' and exists_ccr = '"+ existsInCCR +"'");
		    log.debug("UserEntitlementHelper::getNewRolesForEntitlement::str==>"+str.toString());
		    con = dbsession.getConnection();
		    stmt = con.createStatement();
		    rs = stmt.executeQuery(str.toString());
		    if(rs != null && rs.next())
		    {    		 
		    	rolesList = getSecurityRoleIDs(rs.getString(1));
		    }
		}
		catch(SQLException e){
		    log.error(e);
		    throw e;
		}
		catch(Exception e){
		    log.error(e);
		    throw e;
		}
		finally{
			if(rs != null)
				rs.close();
			if(stmt != null)
				stmt.close();
			if(con != null)
				con.close();
		}
		return rolesList;
    }
    public List<Long> getSecurityRoleIDs(String roles) throws Exception
    {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		List<Long> rolesList=new ArrayList<Long>();
		C3parSession dbsession = new C3parSession();
		if(roles != null && !roles.isEmpty())
		{
			try{
				if(roles != null && !roles.isEmpty() && roles.trim().length() > 0){
				    StringBuffer str=new StringBuffer("select id from security_role where name in ('" + roles.replace(",", "','") +"')");
				    log.debug("UserEntitlementHelper::getSecurityRoleIDs::str==>"+str.toString());
				    con = dbsession.getConnection();
				    stmt = con.createStatement();
				    rs = stmt.executeQuery(str.toString());
				    if(rs != null)
			    		 while(rs.next()) {
			 				rolesList.add(Long.valueOf(rs.getLong(1)));
			 			}
				}
			}
			catch(SQLException e){
			    log.error(e);
			    throw e;
			}
			catch(Exception e){
			    log.error(e);
			    throw e;
			}
			finally{
				if(rs != null)
					rs.close();
				if(stmt != null)
					stmt.close();
				if(con != null)
					con.close();
			}
		}
		return rolesList;
    }
    /*public List buildHierRegSecForEntit(Long []selectedRegionIds,Long[] selectedSectorIds){
    	List hierRegSecCombList=new ArrayList();
    	
    	for (Long selectedRegionId : selectedRegionIds)
    	    for (Long finalSeclectedSecId : selectedSectorIds) {
    		RegionSectorInstanceRuleEntity regSecEntity = new RegionSectorInstanceRuleEntity();
    		regSecEntity.setRegionID(selectedRegionId);
    		regSecEntity.setSectorID(finalSeclectedSecId);
    		hierRegSecCombList.add(regSecEntity);
    	    }
    	return hierRegSecCombList;
    }*/

  	/*public void addUserEntitlement(Long regionID,Long sectorID,String permission,List allRegionsList,List allSectorsList ,List entitlementList)
    {
		UserEntitlementEntityForm userEntitEntity=new UserEntitlementEntityForm();
	
		userEntitEntity.setRegionID(regionID);
		userEntitEntity.setSectorID(sectorID);
		userEntitEntity.setPermission(permission);
		userEntitEntity.setRegion(getRegionForID(regionID,allRegionsList));
		userEntitEntity.setSector(getSectorForID(sectorID,allSectorsList));
		entitlementList.add(userEntitEntity);
    }*/
    String getRegionForID(Long regionID, List allRegionsList)
    {
		String region="";
		if(allRegionsList!=null)
		{
		    Iterator regionItr=allRegionsList.iterator();
		    while(regionItr.hasNext())
		    {
			RegionEntity regionEntity=(RegionEntity)regionItr.next();
			if(regionEntity.getId().equals(regionID))
			{
			    //userEntitEntity.setRegion(regionEntity.getName());
			    region=regionEntity.getName();
			    break;
			}
		    }
		}
		return region;
    }

    String getSectorForID(Long sectorID, List allSectorsList)
    {
		String sector="";
		if(allSectorsList!=null)
		{
		    Iterator sectorItr=allSectorsList.iterator();
		    while(sectorItr.hasNext())
		    {
			SectorEntity sectorEntity=(SectorEntity)sectorItr.next();
			if(sectorEntity.getId().equals(sectorID))
			{
			    sector=sectorEntity.getName();
			    break;
			}
		    }
		}
		return sector;
    }
   /* public HashMap getConnectionRegionAndSectorID(Long connectionID) throws Exception
    {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		C3parSession dbsession = new C3parSession();
		HashMap regSec = new HashMap();
		try{
		    StringBuffer str=new StringBuffer("select reg.id reg_id, sec.id sec_id, reg.NAME reg_NAME, sec.name sec_name");
		    str.append(" from c3par.ti_process tiproc,c3par.relationship rel,c3par.ent_inst entinst,c3par.ent_data regdat");
		    str.append(" ,c3par.ent_data secdat,c3par.region reg, c3par.sector sec");
		    str.append(" where tiproc.ID="+connectionID+" and tiproc.RELATIONSHIP_ID=rel.id and rel.ent_instance_id=entinst.ID");
		    str.append(" and entinst.ID=regdat.ENTITLEMENT_INSTANCE_ID and regdat.ENTITLEMENT_NODE_ID=1 and regdat.RULE_ID=1");
		    str.append(" and regdat.DATA=reg.id and regdat.ENTITLEMENT_INSTANCE_ID=secdat.ENTITLEMENT_INSTANCE_ID");
		    str.append(" and secdat.ENTITLEMENT_NODE_ID=2 and secdat.DATA=sec.ID");
		    
		    log.debug("UserEntitlementHelper::getConnectionRegionAndSectorID::str==>"+str.toString());
		    con = dbsession.getConnection();
		    stmt = con.createStatement();
		    rs = stmt.executeQuery(str.toString());
		    if(rs != null && rs.next())
		    {
		    	regSec.put("reg_id", Long.valueOf(rs.getLong(1)));
		    	regSec.put("sec_id", Long.valueOf(rs.getLong(2)));
		    }
		}
		catch(SQLException e){
		    log.error(e);
		    throw e;
		}
		catch(Exception e){
		    log.error(e);
		    throw e;
		}
		finally{
			if(rs != null)
				rs.close();
			if(stmt != null)
				stmt.close();
			if(con != null)
				con.close();
		}
		return regSec;
    }*/
    

    public List<Long> checkContactRoleExists(String ssoID,String contactListRole,String existsInCCR) throws Exception{
		Connection con=null;
		Statement stmt=null,stmt1=null;
		ResultSet rs=null,rs1 = null;
		List<Long> rolesList=new ArrayList<Long>();
		C3parSession dbsession = new C3parSession();
		try{
		    StringBuffer sql=new StringBuffer("select not_exist_role, new_role from target_contact_accept_mapping targetmap join role r on targetmap.role_id = r.id ");
		    sql.append(" where r.display_name = '"+contactListRole+"' and exists_ccr = '"+ existsInCCR +"'");
		    log.debug("UserEntitlementHelper::checkContactRoleExists::sql==>"+sql.toString());
		    con = dbsession.getConnection();
		    stmt = con.createStatement();
		    rs = stmt.executeQuery(sql.toString());
   		 	HashSet<String> roleset = new HashSet();
		    if(rs != null && rs.next())
		    {
		    	String notexistingrole = String.valueOf(rs.getString(1));
		    	String newrole = String.valueOf(rs.getString(2));
		    	log.debug("UserEntitlementHelper::checkContactRoleExists::existingrole==>"+notexistingrole+",newrole==>"+newrole);
		    	if(notexistingrole != null && !notexistingrole.isEmpty()){
		    		 StringBuffer sql1=new StringBuffer("select secrole.name from c3par_users users join C3PAR_USER_ROLE_XREF userxref on users.id = userxref.user_id");
		    		 sql1.append(" join security_role secrole on userxref.role_id = secrole.id where upper(users.sso_id) = upper('"+ssoID+"')");
		    		 log.debug("UserEntitlementHelper::checkContactRoleExists::sql1==>"+sql1.toString());
		    		 stmt1 = con.createStatement();
		    		 rs1 = stmt1.executeQuery(sql1.toString());
		    		 if(rs1 != null) {
		    			 while(rs1.next()){
		    				 roleset.add(rs1.getString(1));
		    			 }
		 			}
		    		log.debug("UserEntitlementHelper::checkContactRoleExists::roleset==>"+roleset); 
			    	//boolean addnewrole = false;
		    		boolean addnewrole = true;
		    		StringTokenizer notexistingroleTokens = new StringTokenizer(notexistingrole,",");
		    		while(notexistingroleTokens.hasMoreElements()){
		    			if(roleset.contains(notexistingroleTokens.nextToken())){ // if any one role exists, then no need to add new role(s)
		    				addnewrole = false;
		    				break;
		    			}
		    			/*if(!roleset.contains(notexistingroleTokens.nextToken())){ // if any one role not exists, then add the new role(s)
		    				addnewrole = true;
		    				break;
		    			}*/
		    		}
		    		log.debug("UserEntitlementHelper::checkContactRoleExists::addnewrole==>"+addnewrole); 
		    		if(addnewrole){
		    			StringTokenizer newroleTokens = new StringTokenizer(newrole,",");
		    			StringBuffer newroleAdd=new StringBuffer();
		    			String role;
		    			while(newroleTokens.hasMoreElements()){
		    				role = newroleTokens.nextToken();
		    				if(!roleset.contains(role)){
		    					if(newroleAdd.length() <= 0)
		    						newroleAdd.append(role);
		    					else
		    						newroleAdd.append(","+role);
		    				}
		    			}
		    			log.debug("UserEntitlementHelper::checkContactRoleExists::newroleAdd==>"+newroleAdd.toString()); 
		    			rolesList = getSecurityRoleIDs(newroleAdd.toString());
		    		}
		    	}
		    }
		}
		catch(SQLException e){
		    log.error(e);
		    throw e;
		}
		catch(Exception e){
		    log.error(e);
		    throw e;
		}
		finally{
			if(rs != null)
				rs.close();
			if(stmt != null)
				stmt.close();
			if(rs1 != null)
				rs1.close();
			if(stmt1 != null)
				stmt1.close();
			if(con != null)
				con.close();
		}
		return rolesList;
    }
}