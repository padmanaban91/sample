package com.citigroup.cgti.c3par.webtier.helper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.citigroup.cgti.c3par.C3parSession;


/**
 * The Class RoboHelper.
 */
public class RoboHelper {

    /**
     * Retrive url.
     *
     * @param id the id
     * @param status the status
     * @param c3parSession the c3par session
     * @return the string
     * @throws Exception the exception
     */
    public static String retriveURL(String id, String status, C3parSession c3parSession)
    throws Exception
    {
	ResultSet rs = null;
	String url = null;
	PreparedStatement ps = null;
	try {
	    ps = c3parSession.getConnection().prepareStatement(SELECT_URL);
	    ps.setString(1,id);
	    ps.setString(2, status);
	    rs = ps.executeQuery();
	    if (rs.next())
	    {	
		url = rs.getString("URL");
	    }

	}
	finally {
	    if(ps != null)
		ps.close();
	    if(c3parSession != null)
		c3parSession.releaseConnection();
	}

	return url;
    }

    /** The SELEC t_ url. */
    private static String SELECT_URL = "SELECT URL FROM ROBO_HELP WHERE ID = ? AND STATUS = ?";
}


