package com.citigroup.cgti.c3par.audit.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.audit.domain.AuditTrailProcess;
import com.citigroup.cgti.c3par.audit.domain.soc.persist.AuditTrialPersistable;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.common.domain.AuditLog;
import com.citigroup.cgti.c3par.common.domain.AuditObjectType;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditResponse;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.domain.TIRequestType;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;
@Transactional
public class AuditTrialImpl extends BasePersistanceImpl implements
		AuditTrialPersistable {

	/** The log. */
	Logger log = Logger.getLogger(AuditTrialImpl.class);
	@Transactional(readOnly = true)
	public TIProcess getAuditTrail(TIProcess tiProcess) {
		this.log.debug("Start AuditTrailImpl.getAuditTrial");  

		StringBuilder query = new StringBuilder(); 

		log.debug("tiProcess.getId()::getAuditTrail::" + tiProcess.getId());
		if ((tiProcess.getId() != null) && (tiProcess.getId().longValue() != 0)) {
			log.debug("inside first if::getAuditTrail::");
			try {
				Session session = getSession();

				query.append("SELECT * FROM ( ");
				query.append("(SELECT distinct d.id , e.task Activity , decode(c.request_type,'Create','Planning','Maintain', ");
				query.append("'Maintenance', 'Terminate', 'Termination', 'ACV', 'ACV','ManageContacts','Maintain Contacts') RequestType, f.DISPLAY_NAME ActivityRole, i.DISPLAY_NAME infoActivityRole, ");
				query.append("g.sso_id UserID, ");
				query.append("h.sso_id Lockedby, ");
				query.append("d.activity_status Status, d.activity_mode ActivityMode, to_char(d.activity_startdate,'MM-DD-YYYY HH24:MI') ");
				query.append("StartDate, to_char(d.activity_enddate,'MM-DD-YYYY HH24:MI') EndDate, a.id processId, ");
				query.append("a.process_name processName, b.version_number versionNumber, b.id tiRequestId, d.activity_type activityType, ");
				query.append("r.baseline_name, (select listagg(r.rule_number,',') within group (order by r.rule_number) from ti_risk_audit_trail a, ");
				query.append("con_fw_rule r where a.tuple_number = r.id and r.deleted_ti_request_id is null and a.act_trail_id = d.id) tuple_list, d.approval_system, d.bpm_instance_id ");
				query.append("FROM ti_process a, ti_request b, ");
				query.append("TI_REQUEST_TYPE C, TI_ACTIVITY_TRAIL D, TI_TASK_TYPE E, ROLE F, c3par_users g, c3par_users h, ROLE i, ti_risk_audit_trail r  ");
				query.append("WHERE a.id = b.process_id AND b.ti_request_type_id=c.id AND b.id = d.ti_request_id AND ");
				query.append("d.activity_id = e.id AND d.user_role_id = f.id(+) AND d.INFOUSER_ROLE_ID = i.id(+) AND d.user_id = g.id(+) AND d.lockedby = h.id(+) ");
				query.append("and d.id  = r.act_trail_id(+) ");
				query.append("AND a.id = " + tiProcess.getId() +")"); 
				query.append("UNION"); 
				query.append("(SELECT distinct d.id , e.task Activity , ");
				query.append("'' RequestType, f.DISPLAY_NAME ActivityRole, i.DISPLAY_NAME infoActivityRole, ");
				query.append("g.sso_id UserID, ");
				query.append("h.sso_id Lockedby, ");
				query.append("d.activity_status Status, d.activity_mode ActivityMode, to_char(d.activity_startdate,'MM-DD-YYYY HH24:MI') ");
				query.append("StartDate, to_char(d.activity_enddate,'MM-DD-YYYY HH24:MI') EndDate, a.id processId, ");
				query.append("a.process_name processName, b.version_number versionNumber, b.id tiRequestId, d.activity_type activityType, ");
				query.append("r.baseline_name, (select listagg(r.rule_number,',') within group (order by r.rule_number) from ti_risk_audit_trail a, ");
				query.append("con_fw_rule r where a.tuple_number = r.id and r.deleted_ti_request_id is null and a.act_trail_id = d.id) tuple_list, d.approval_system, d.bpm_instance_id ");
				query.append("FROM ti_process a, ti_request b, ");
				query.append("TI_REQUEST_TYPE C, TI_ACTIVITY_TRAIL D, TI_TASK_TYPE E, ROLE F, c3par_users g, c3par_users h, ROLE i, ti_risk_audit_trail r,resolve_it_notify_log rinl1  ");
				query.append("WHERE a.id = b.process_id AND b.ti_request_type_id=c.id AND ");
				query.append("d.activity_id = e.id AND d.user_role_id = f.id(+) AND d.INFOUSER_ROLE_ID = i.id(+) AND d.user_id = g.id(+) AND d.lockedby = h.id(+) ");
				query.append("and d.id  = r.act_trail_id(+)  ");
				query.append("AND d.cmp_id = rinl1.CMP_REQUEST_ID ");
				query.append("AND rinl1.TI_REQUEST_ID = b.ID  ");
				query.append("AND a.id = " + tiProcess.getId());
				query.append("AND d.cmp_id in (SELECT rinl.cmp_request_id ");
				query.append("		FROM resolve_it_notify_log rinl, ");
				query.append("		  ti_request tr, ");
				query.append("		  ti_process tp ");
				query.append("		WHERE rinl.ti_request_id=tr.id ");
				query.append("		AND tp.id               ="+ tiProcess.getId()); 
				query.append("		and tp.id = tr.process_id)) ");
				query.append(") ORDER BY versionNumber desc, id ASC ");				
				log.info("strQuery::" + query);
				SQLQuery sqlquery = session.createSQLQuery(query.toString());
				log.debug("query.toString() ::getEMailAuditTrailList:: "
						+ query.toString());

				sqlquery.addScalar("Activity", StringType.INSTANCE);
				sqlquery.addScalar("ActivityMode", StringType.INSTANCE);
				sqlquery.addScalar("ActivityRole", StringType.INSTANCE);
				sqlquery.addScalar("infoActivityRole", StringType.INSTANCE);
				sqlquery.addScalar("UserID", StringType.INSTANCE);
				sqlquery.addScalar("Lockedby", StringType.INSTANCE);
				sqlquery.addScalar("Status", StringType.INSTANCE);
				sqlquery.addScalar("StartDate", StringType.INSTANCE);
				sqlquery.addScalar("EndDate", StringType.INSTANCE);
				sqlquery.addScalar("activityType", StringType.INSTANCE);
				sqlquery.addScalar("baseline_name", StringType.INSTANCE);
				sqlquery.addScalar("tuple_list", StringType.INSTANCE);
				sqlquery.addScalar("approval_system", StringType.INSTANCE);
				sqlquery.addScalar("bpm_instance_id", StringType.INSTANCE);
				sqlquery.addScalar("tiRequestId", LongType.INSTANCE);
				sqlquery.addScalar("versionNumber", IntegerType.INSTANCE);
				sqlquery.addScalar("RequestType", StringType.INSTANCE);
				sqlquery.addScalar("processName", StringType.INSTANCE);

				List<Object[]> rows = sqlquery.list();

				if (rows != null) {
					log.debug("rs is ::getAuditTrail::");

					TIRequest tiRequest = new TIRequest();
					tiRequest.setId(Long.valueOf(0));

					for (Object[] obj : rows) {
						ActivityData activityData = new ActivityData();

						activityData.setActivityName((String) obj[0]);

						activityData.setActivityMode((String) obj[1]);

						activityData.setUserRole((String) obj[2]);

						activityData.setInfoUserRole((String) obj[3]);

						activityData.setUserID((String) obj[4]);

						activityData.setLockedBy((String) obj[5]);

						activityData.setActivityStatus((String) obj[6]);

						activityData.setActivityStartDate((String) obj[7]);

						activityData.setActivityEndDate((String) obj[8]);

						activityData.setActivityType((String) obj[9]);

						activityData.setBaselineName((String) obj[10]);

						activityData.setTupleList((String) obj[11]);

						activityData.setApprovalSystem((String) obj[12]);

						activityData.setAlbpmActivityID((String) obj[13]);

						if (tiRequest.getId().longValue() == 0) {
							log.debug("inside second if::getAuditTrail::");
							tiRequest.setId((Long) (obj[14]));
							tiRequest.setVersionNumber((Integer) obj[15]);
							TIRequestType tiRequestType = new TIRequestType();
							tiRequestType.setName((String) obj[16]);
							tiRequest.setTiRequestType(tiRequestType);
							log.debug("tiRequestType::getAuditTrail::"
									+ tiRequestType);
							tiProcess.getTiRequestList().add(tiRequest);
							log.debug("tiRequest::getAuditTrail::" + tiRequest);
							tiProcess.setName((String) obj[17]);
						} else if ((tiRequest.getId().longValue() != 0)
								&& (tiRequest.getId().longValue() != (Long) (obj[14]))) {
							tiRequest = new TIRequest();
							tiRequest.setId((Long) (obj[14]));
							tiRequest.setVersionNumber((Integer) obj[15]);
							TIRequestType tiRequestType = new TIRequestType();
							tiRequestType.setName((String) obj[16]);
							tiRequest.setTiRequestType(tiRequestType);
							tiProcess.getTiRequestList().add(tiRequest);
						} else if ((tiRequest.getId().longValue() != 0)
								&& (tiRequest.getId().longValue() == (Long) (obj[14]))
								&& (tiRequest.getTiRequestType().getName() == null)) {
							log.debug("Assigning request type to empty field due to CMP audit record");
							tiRequest = (TIRequest) tiProcess.getTiRequestList().get(tiProcess.getTiRequestList().size()-1);
							TIRequestType tiRequestType = new TIRequestType();
							tiRequestType.setName((String) obj[16]);
							tiRequest.setTiRequestType(tiRequestType);
						}
						
						if ((ActivityData.STATUS_COMPLETED
								.equalsIgnoreCase(activityData
										.getActivityStatus()) || ActivityData.STATUS_REJECTED
								.equalsIgnoreCase(activityData
										.getActivityStatus()))
								&& (OneApprovalConstants.APPROVAL_SYSTEM_OA_FWD
										.equalsIgnoreCase(activityData
												.getApprovalSystem()) || OneApprovalConstants.APPROVAL_SYSTEM_OA_DEL
										.equalsIgnoreCase(activityData
												.getApprovalSystem()))) {
							log.debug("inside third if ::getAuditTrail::");
							String action = "DELEGATED";
							String type = "D";
							if (OneApprovalConstants.APPROVAL_SYSTEM_OA_FWD
									.equalsIgnoreCase(activityData
											.getApprovalSystem())) {
								action = "FORWARDED";
								type = "F";
							}
							String alternateApprover = getAlternateApprover(
									tiProcess.getId(), tiRequest.getId(),
									tiRequest.getVersionNumber(),
									activityData.getAlbpmActivityID(), type);
							String status = activityData.getActivityStatus()
									+ "[" + action + " TO " + alternateApprover
									+ "]";
							activityData.setActivityStatus(status);
						}

						tiRequest.getActivityDataList().add(activityData);

					}
				}

			} catch (Exception e) {
				log.error(e, e);
			}
		}
		/*TIRequest tr = (TIRequest) tiProcess.getTiRequestList().get(0);
		log.debug("Request type of TiRequest: "+tr.getTiRequestType().getName());*/
		this.log.debug("End AuditTrailImpl.getAuditTrial");
		return tiProcess;
	}

	private String getAlternateApprover(Long processId, Long tiRequestId,
			int version, String bpmInstanceId, String type) {
		String alternateApprover = null;

		StringBuilder query = new StringBuilder();
		try {
			log.debug("getAlternateApprover() Enter ");
			log.debug("tiRequestId  " + tiRequestId);

			Session session = getSession();

			String sql = "select contact.sso_id Id from oneapproval_msg_log log, citi_contact contact where log.alternate_approver = contact.geid "
					+ "and log.order_id = '"
					+ tiRequestId
					+ "-"
					+ bpmInstanceId
					+ "' and log.approver_type = '"
					+ type
					+ "'";

			SQLQuery sqlquery = session.createSQLQuery(query.toString());
			log.debug("query.toString() ::getEMailAuditTrailList:: "
					+ query.toString());
			sqlquery.addScalar("Id", StringType.INSTANCE);

			List<Object[]> rows = sqlquery.list();
			if (rows != null) {
				log.debug("rows is ::getAlternateApprover::");

				for (Object[] obj : rows) {
					alternateApprover = (String) obj[0];
				}

				log.debug("alternateApprover : " + alternateApprover);
				log.debug("getAlternateApprover() End ");
			}
		} catch (Exception e) {
			log.debug("getAlternateApprover() ", e);
		}

		return alternateApprover;
	}

	@Override
	public List<TIMailAudit> getEMailAuditTrailList(
			AuditTrailProcess auditTrailProcess) {
		Session session = getSession();
		log.debug("AuditTrailImpl: getEMailAuditTrailList: started :: processId ==> "
				+ auditTrailProcess.getTiProcess());

		StringBuffer query = new StringBuffer();
		query.append("select tiprocess.ID ProcessID ");
		query.append(",decode(tirequesttype.request_type,'Create','Planning','Maintain','Maintenance', 'Terminate', 'Termination', 'ACV', 'ACV','ManageContacts','Maintain Contacts') RequestType ");
		query.append(",tirequest.VERSION_NUMBER Version ");
		query.append(",timailaudit.TEMPLATE_ID Activity ");
		query.append(",timailaudit.TO_LIST ToList ");
		query.append(",timailaudit.CC_LIST CcList ");
		query.append(",timailaudit.DONOTSEND_LIST doNotSendList ");
		query.append(",to_char(timailaudit.CREATED_DATE,'MM-DD-YYYY HH24:MI') CreatedDate ");
		query.append(",timailaudit.ID MailAuditID ");
		query.append(",(select lookup.value2 from generic_lookup lookup, generic_lookup_defs def where lookup.definition_id = def.id and def.name = 'MAIL_AUDIT_LABEL' and ");
		query.append(" upper(lookup.VALUE1) = upper(timailaudit.TEMPLATE_ID)) notificationLabel ");
		query.append("from TI_PROCESS tiprocess, TI_REQUEST tirequest, TI_REQUEST_TYPE tirequesttype, TI_MAIL_AUDIT timailaudit ");
		query.append("where tiprocess.ID = tirequest.PROCESS_ID ");
		query.append("and tirequest.ID = timailaudit.TI_REQUEST_ID ");
		query.append("and tirequest.TI_REQUEST_TYPE_ID = tirequesttype.ID ");
		query.append("and tiprocess.ID = " + auditTrailProcess.getTiProcess());
		query.append("order by tirequest.VERSION_NUMBER desc, timailaudit.CREATED_DATE asc");

		SQLQuery sqlquery = session.createSQLQuery(query.toString());

		log.debug("query.toString() ::getEMailAuditTrailList:: "
				+ query.toString());

		sqlquery.addScalar("ProcessID", LongType.INSTANCE);
		sqlquery.addScalar("RequestType", StringType.INSTANCE);
		sqlquery.addScalar("Version", IntegerType.INSTANCE);
		sqlquery.addScalar("Activity", StringType.INSTANCE);
		sqlquery.addScalar("ToList", StringType.INSTANCE);
		sqlquery.addScalar("CcList", StringType.INSTANCE);
		sqlquery.addScalar("doNotSendList", StringType.INSTANCE);
		sqlquery.addScalar("CreatedDate", StringType.INSTANCE);
		sqlquery.addScalar("MailAuditID", LongType.INSTANCE);
		sqlquery.addScalar("notificationLabel", StringType.INSTANCE);

		List<Object[]> rows = sqlquery.list();
		List<TIMailAudit> list = new ArrayList<TIMailAudit>();
		TIMailAudit mailAudit = null;

		if (rows != null) {
			int prevVerNo = 0, verNo = 0;
			for (Object[] obj : rows) {
				mailAudit = new TIMailAudit();

				verNo = (Integer) obj[2];

				mailAudit.setProcessID((Long) obj[0]);
				mailAudit.setRequestType((String) obj[1]);
				if (verNo != 0 && prevVerNo != verNo) {
					mailAudit.setVersionNumber((Integer) obj[2]);
				} else {
					mailAudit.setVersionNumber(0);
				}
				mailAudit.setTemplateID((String) obj[3]);
				mailAudit.setToList((String) obj[4]);
				mailAudit.setCcList((String) obj[5]);
				mailAudit.setDoNotSendList((String) obj[6]);
				mailAudit.setCreatedDateDisplay((String) obj[7]);
				mailAudit.setId((Long) obj[8]);
				mailAudit.setNotificationType((String) obj[9]);
				// Retrieve the response mails
				List<TIMailAuditResponse> responseMails = (List<TIMailAuditResponse>) session
						.createQuery(
								"from TIMailAuditResponse res where res.tiMailAudit.id = ?)")
						.setLong(0, mailAudit.getId()).list();
				mailAudit.setResponseMails(responseMails);

				list.add(mailAudit);
				prevVerNo = verNo;
			}
		}
		log.debug("AuditTrailImpl: getEMailAuditTrailList: Ends :: list.size ==> "
				+ list != null ? list.size() : "Empty");
		return list;
	}

	@Override
	@Transactional(readOnly = true)
	public TIMailAudit getEMailAuditTrail(AuditTrailProcess auditTrailProcess) {
		Session session = getSession();
		log.debug("CommonServiceImpl: getEMailAuditTrail: Starts :: getEmailAuditTrailID ==> "
				+ auditTrailProcess.getEmailAuditTrailID());
		TIMailAudit mailAudit = null;
		List<TIMailAudit> mailAuditList = (List<TIMailAudit>) session
				.createQuery("from TIMailAudit audit where audit.id = ?)")
				.setLong(0, auditTrailProcess.getEmailAuditTrailID()).list();

		if (mailAuditList != null && mailAuditList.size() > 0) {
			mailAudit = mailAuditList.get(0);
		}
		return mailAudit;
	}

	@Override
	@Transactional(readOnly = true)
	public TIMailAuditResponse getResponseEMailAuditTrail(
			AuditTrailProcess auditTrailProcess) {
		Session session = getSession();
		log.debug("CommonServiceImpl: getResponseEMailAuditTrail: Starts :: getEmailAuditTrailID ==> "
				+ auditTrailProcess.getEmailAuditTrailID());
		TIMailAuditResponse mailAudit = null;
		List<TIMailAuditResponse> mailAuditList = (List<TIMailAuditResponse>) session
				.createQuery(
						"from TIMailAuditResponse resaudit where resaudit.id = ?)")
				.setLong(0, auditTrailProcess.getEmailAuditTrailID()).list();

		if (mailAuditList != null && mailAuditList.size() > 0) {
			mailAudit = mailAuditList.get(0);
		}
		return mailAudit;
	}

	@Override
	@Transactional(readOnly = true)
	public List<AuditLog> getAdminChangeDetails(Long processID) {

		Session session = getSession();
		/*
		 * Criteria criteria = session.createCriteria(AuditLog.class);
		 * criteria.createCriteria("tiRequest", "tiRequest");
		 * criteria.createCriteria("tiRequest.tiProcess","tiProcess"); if
		 * (processID != 0) {
		 * criteria.add(Restrictions.eq("tiProcess.id",processID)); }
		 * List<AuditLog> auditLogList = criteria.list();
		 */

		String query = "select log.* from audit_log log, ti_request ti where log.ti_request_id = ti.id and ti.process_id = "
				+ processID + " order by created_date desc ";

		SQLQuery sqlquery = session.createSQLQuery(query);
		sqlquery.addEntity("log", AuditLog.class);

		List<AuditLog> auditLogList = (List<AuditLog>) sqlquery.list();

		return auditLogList;
	}

	@Override
	@Transactional(readOnly = true)
	public List<ContactDetailsDTO> getContactsDetails(Long contactID,
			String objectName, String entry) {

		Session session = getSession();

		String table = objectName;

		if ("old".equals(entry)) {
			AuditObjectType auditObjectType = getAuditObjectType(objectName);
			if (auditObjectType != null) {
				table = auditObjectType.getObjectNameHistory();
			}
		}

		String query = ("SELECT distinct cc.first_name || ' ' || cc.last_name Name,cc.sso_id,cc.email,cc.phone,rr.display_name role,history.primary_contact,history.notify_contact,history.system_generated "
				+ "FROM "
				+ table
				+ " history,citi_contact cc,role rr "
				+ "WHERE history.citi_contact_id = cc.id and "
				+ "history.role_id=rr.id and history.id = " + contactID);

		SQLQuery sqlquery = session.createSQLQuery(query);
		sqlquery.addScalar("name", StringType.INSTANCE);
		sqlquery.addScalar("sso_id", StringType.INSTANCE);
		sqlquery.addScalar("email", StringType.INSTANCE);
		sqlquery.addScalar("phone", StringType.INSTANCE);
		sqlquery.addScalar("role", StringType.INSTANCE);
		sqlquery.addScalar("primary_contact", StringType.INSTANCE);
		sqlquery.addScalar("notify_contact", StringType.INSTANCE);
		sqlquery.addScalar("system_generated", StringType.INSTANCE);

		List<Object[]> resultList = sqlquery.list();
		List<ContactDetailsDTO> contactListDTO = new ArrayList<ContactDetailsDTO>();
		ContactDetailsDTO dto;
		String val = "";
		if (resultList != null) {
			for (Object[] rs : resultList) {
				dto = new ContactDetailsDTO();
				dto.setName((String) rs[0]);
				dto.setSsoID((String) rs[1]);
				dto.setEmailID((String) rs[2]);
				dto.setPhoneNo((String) rs[3]);
				dto.setRole((String) rs[4]);
				val = "";
				if ("Y".equalsIgnoreCase((String) rs[5])) {
					val = "Yes";
				} else {
					val = "No";
				}
				dto.setPrimaryContact(val);
				val = "";
				if ("Y".equalsIgnoreCase((String) rs[6])
						|| "1".equalsIgnoreCase((String) rs[6])) {
					val = "Yes";
				} else {
					val = "No";
				}
				dto.setNotifyContact(val);
				val = "";
				if ("Y".equalsIgnoreCase((String) rs[7])) {
					val = "Yes";
				} else {
					val = "No";
				}
				dto.setSystemGenerated(val);
				contactListDTO.add(dto);
			}
		}
		return contactListDTO;
	}
	@Transactional(readOnly = true)
	public List<RelationshipDTO> getRelationshipDetails(Long relationID) {
		Session session = getSession();
		String query = ("select id, name, RELATIONSHIP_TYPE type, status, REQUESTER_ID requestor from relationship where id = ")
				+ relationID;
		SQLQuery sqlQuery = session.createSQLQuery(query);
		sqlQuery.addScalar("id", LongType.INSTANCE);
		sqlQuery.addScalar("name", StringType.INSTANCE);
		sqlQuery.addScalar("type", StringType.INSTANCE);
		sqlQuery.addScalar("status", StringType.INSTANCE);
		sqlQuery.addScalar("requestor", StringType.INSTANCE);
		List<Object[]> resultList = sqlQuery.list();

		List<RelationshipDTO> relationshipDTOList = new ArrayList<RelationshipDTO>();
		RelationshipDTO dto;
		if (resultList != null) {
			for (Object[] rs : resultList) { 
				dto = new RelationshipDTO();
				dto.setId((Long) rs[0]);
				dto.setName((String) rs[1]);
				dto.setType((String) rs[2]); 
				dto.setStatus((String) rs[3]);
				dto.setRequestorSOEId((String) rs[4]);
				relationshipDTOList.add(dto);
			}
		}

		return relationshipDTOList;

	}

	private AuditObjectType getAuditObjectType(String objectName) {

		AuditObjectType auditObjectType = null;
		List<AuditObjectType> auditObjectTypes = (List<AuditObjectType>) getSession()
				.createQuery(
						" from AuditObjectType where objectName = '"
								+ objectName + "'").list();

		if (auditObjectTypes != null && !auditObjectTypes.isEmpty()) {
			auditObjectType = auditObjectTypes.get(0);
		}
		return auditObjectType;

	}
}
