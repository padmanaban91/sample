package com.citigroup.cgti.c3par.webtier.helper;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;

import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.admin.domain.DailyLoad;
import com.citigroup.cgti.c3par.admin.domain.FirewallFreeze;
import com.citigroup.cgti.c3par.admin.domain.VacationFreeze;

/**
 * The Class POIExcelReader.
 */
@SuppressWarnings("unchecked")
public class ExcelReader {

	/**
	 * Instantiates a new pOI excel reader.
	 */
	public ExcelReader() {
	}

    /** The log. */
    private static Logger log = Logger
	    .getLogger(ExcelReader.class);

	/**
	 * Gets the cell value.
	 * 
	 * @param cell
	 *            the cell
	 * @return the cell value
	 */
	public static String getCellValue(HSSFCell cell) {
		if (cell == null) {
			return null;
		}
		String cellValue = null;

		switch (cell.getCellType()) {
		case HSSFCell.CELL_TYPE_NUMERIC:
			cellValue = String.valueOf(cell.getNumericCellValue());
			break;
		case HSSFCell.CELL_TYPE_STRING:
			cellValue = cell.getStringCellValue();
			break;
		case HSSFCell.CELL_TYPE_BLANK:
			cellValue = "";
			break;
		case HSSFCell.CELL_TYPE_ERROR:
			cellValue = "";
			break;
		}

		if (cellValue != null) {
			cellValue = cellValue.trim();
		}
		
		return cellValue;
	}

	/**
	 * Parses the sheet.
	 * 
	 * @param workbook
	 *            the workbook
	 * @param sheetName
	 *            the sheet name
	 * @return the list
	 */
	public List parseSheet(HSSFWorkbook workbook, String sheetName,
			int startIndex, int colCount) {

		List columns = null;
		List rows = null;

		HSSFSheet sheet = workbook.getSheet(sheetName);
		if (sheet != null) {
			rows = new ArrayList();
		}
		int rowCount = sheet.getPhysicalNumberOfRows();
		for (int i = startIndex; i < rowCount; i++) {
			HSSFRow xlRow = sheet.getRow(i);
			int emptyColumns = 0;
			if (xlRow == null) {
				continue;
			} else {
				columns = new ArrayList();
				// for loop for number of cells which have contents
				for (int cellIndx = 0; cellIndx < colCount; cellIndx++) {
					HSSFCell cell = xlRow.getCell(cellIndx);
					String cellValue = getCellValue(cell);
					columns.add(cellValue);
					
					if(cellValue == null || cellValue.isEmpty()){
						emptyColumns++;
					}
				}
			}
			//if all columns are empty, consider as empty row, so no need to read data
			if(emptyColumns == colCount){ 
				continue;
			}
			if (columns != null && columns.size() > 0)
				rows.add(columns);
		}
		return rows;
	}

	public HSSFWorkbook writeIntoExcel(List uploadedFileList, List<FireWallRule> fwList) throws Exception {	
		log.debug("ManageFirewallRulesAction::writeIntoExcel::Starting......");
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Sheet1");

	    Font headerFont = workbook.createFont();
	    headerFont.setFontHeightInPoints((short)11);
	    headerFont.setFontName("Calibri");
	    headerFont.setColor(HSSFColor.WHITE.index);
	    headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
	    
	    CellStyle headerStyle = workbook.createCellStyle();
	    headerStyle.setFillForegroundColor(HSSFColor.DARK_BLUE.index);
	    headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	    headerStyle.setFont(headerFont);

	    Font font = workbook.createFont();
	    font.setFontHeightInPoints((short)11);
	    font.setFontName("Calibri");
	    
	    CellStyle style = workbook.createCellStyle();
	    style.setFont(font);

	    Font errFont = workbook.createFont();
	    errFont.setFontHeightInPoints((short)11);
	    errFont.setFontName("Calibri");
	    errFont.setColor(HSSFColor.RED.index);
	    
	    CellStyle errStyle = workbook.createCellStyle();
	    errStyle.setFont(errFont);

		HSSFRow HeaderRow = sheet.createRow((short) 0);
		HeaderRow.setHeight((short)330);
		createCell(HeaderRow, 0, "Tuple Number", headerStyle);
		createCell(HeaderRow, 1, "FW Policy", headerStyle);
		createCell(HeaderRow, 2, "Rule Type(Allow/Deny)", headerStyle);
		createCell(HeaderRow, 3, "Src Network Zone", headerStyle);
		createCell(HeaderRow, 4, "Dst Network Zone", headerStyle);
		createCell(HeaderRow, 5, "Source", headerStyle);
		createCell(HeaderRow, 6, "Source", headerStyle);
		createCell(HeaderRow, 7, "Destination", headerStyle);
		createCell(HeaderRow, 8, "Destination", headerStyle);
		createCell(HeaderRow, 9, "", headerStyle);
		createCell(HeaderRow, 10, "Port Details", headerStyle);
		createCell(HeaderRow, 11, "Port Details", headerStyle);
		createCell(HeaderRow, 12, "Port Details", headerStyle);
		createCell(HeaderRow, 13, "Port Details", headerStyle);
		createCell(HeaderRow, 14, "", headerStyle);
		createCell(HeaderRow, 15, "", headerStyle);
		createCell(HeaderRow, 16, "Status Msg", headerStyle);

		HSSFRow HeaderRow1 = sheet.createRow((short) 1);
		HeaderRow1.setHeight((short)330);
		createCell(HeaderRow1, 0, "", headerStyle);
		createCell(HeaderRow1, 1, "", headerStyle);
		createCell(HeaderRow1, 2, "", headerStyle);
		createCell(HeaderRow1, 3, "", headerStyle);
		createCell(HeaderRow1, 4, "", headerStyle);
		createCell(HeaderRow1, 5, "IP", headerStyle);
		createCell(HeaderRow1, 6, "NAT IP", headerStyle);
		createCell(HeaderRow1, 7, "IP", headerStyle);
		createCell(HeaderRow1, 8, "NAT IP", headerStyle);
		createCell(HeaderRow1, 9, "Protocol", headerStyle);
		createCell(HeaderRow1, 10, "Port No", headerStyle);
		createCell(HeaderRow1, 11, "Service", headerStyle);
		createCell(HeaderRow1, 12, "Default/Other", headerStyle);
		createCell(HeaderRow1, 13, "Traffic Type", headerStyle);
		createCell(HeaderRow1, 14, "Justification", headerStyle);
		createCell(HeaderRow1, 15, "Control Message", headerStyle);
		createCell(HeaderRow1, 16, "", headerStyle);
		
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 5, 6));
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 7, 8));
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 10, 13));
		log.debug("ManageFirewallRulesAction::writeIntoExcel::Headers completed......");
		int fwRuleCount = 0, fwRuleErrMsgCount = 0;
		int fileRowCount = 2;
		FireWallRule fwrule = null;
		for (int i = 0; i < uploadedFileList.size(); i++) {
			ArrayList rowList = (ArrayList) uploadedFileList.get(i);

			String celValue = (String) rowList.get(0);
			log.debug("ManageFirewallRulesAction::writeIntoExcel::writting-"+celValue);
			if (celValue != null && (!celValue.isEmpty()) && celValue.length() > 0) {
				if (fwrule != null) {
					for (int cellIndx = fwRuleErrMsgCount; cellIndx < fwrule.getValidationErrors().size(); cellIndx++) {
						HSSFRow xlsErrorRow = sheet.createRow((short) fileRowCount++);
						createCell(xlsErrorRow, 16, fwrule.getValidationErrors().get(fwRuleErrMsgCount++), errStyle);
					}
				}
				fwrule = fwList.get(fwRuleCount++);
				fwRuleErrMsgCount = 0;
			}
			HSSFRow xlsrow = sheet.createRow((short) fileRowCount++);
			for (short cellIndx = 0; cellIndx < 16; cellIndx++) {
				String cellValue = (String) rowList.get(cellIndx);
				log.debug("ManageFirewallRulesAction::writeIntoExcel::writting-"+cellValue);
				if(cellValue != null && !cellValue.isEmpty() && (cellIndx == 0 || cellIndx == 10)){
					try {
						cellValue = String.valueOf(new Double(cellValue).intValue());
					} catch (NumberFormatException n) {
						
					}
				}
				createCell(xlsrow, cellIndx, cellValue, style);
			}
			if(fwrule.getValidationErrors().size() > fwRuleErrMsgCount){
				createCell(xlsrow, 16, fwrule.getValidationErrors().get(fwRuleErrMsgCount++), errStyle);
			}
		}
		if (fwrule != null) {
			for (int cellIndx = fwRuleErrMsgCount; cellIndx < fwrule.getValidationErrors().size(); cellIndx++) {
				HSSFRow xlsErrorRow = sheet.createRow((short) fileRowCount++);
				createCell(xlsErrorRow, 16, fwrule.getValidationErrors().get(fwRuleErrMsgCount++), errStyle);
			}
		}
		log.debug("ManageFirewallRulesAction::writeIntoExcel::Completed......");
		return workbook;
	}
	private void createCell(HSSFRow row, int cellIndex, String data, CellStyle style){
		row.createCell(cellIndex).setCellValue(data);
		row.getCell(cellIndex).setCellStyle(style);
	}
	
	public HSSFWorkbook dailyLoadExcel(List<DailyLoad> list) throws Exception {	
		log.debug("AdminUploadAction ..DailyLoad");
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Sheet1");

	    Font headerFont = workbook.createFont();
	    headerFont.setFontHeightInPoints((short)11);
	    headerFont.setFontName("Calibri");
	    headerFont.setColor(HSSFColor.WHITE.index);
	    headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
	    
	    CellStyle headerStyle = workbook.createCellStyle();
	    headerStyle.setFillForegroundColor(HSSFColor.DARK_BLUE.index);
	    headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	    headerStyle.setFont(headerFont);

	    Font font = workbook.createFont();
	    font.setFontHeightInPoints((short)11);
	    font.setFontName("Calibri");
	    
	    CellStyle style = workbook.createCellStyle();
	    style.setFont(font);

	    Font errFont = workbook.createFont();
	    errFont.setFontHeightInPoints((short)11);
	    errFont.setFontName("Calibri");
	    errFont.setColor(HSSFColor.RED.index);
	    
	    CellStyle errStyle = workbook.createCellStyle();
	    errStyle.setFont(errFont);

		HSSFRow HeaderRow = sheet.createRow((short) 0);
		HeaderRow.setHeight((short)330);
		createCell(HeaderRow, 0, "ID", headerStyle);
		createCell(HeaderRow, 1, "LOCATION", headerStyle);
		createCell(HeaderRow, 2, "DAY", headerStyle);
		createCell(HeaderRow, 3, "LOAD VALUE", headerStyle);
		createCell(HeaderRow, 4, "GLOBAL_LOAD", headerStyle);
		
		/*sheet.addMergedRegion(new CellRangeAddress(0, 0, 4, 5));
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 6, 7));
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 9, 12));*/
		log.debug("Admin Upload Action::writeIntoExcel::Headers completed......");
		
		
		
		DailyLoad dload=null;
		HSSFRow xlsrow = null;
		int j = 0;
		for (int i = 0; i < list.size(); i++) {
			xlsrow = sheet.createRow((short) (i+1));
			dload = (DailyLoad) list.get(i);
			
			createCell(xlsrow, 0, dload.getId()+"", style);
			if (dload.getFwLoc() != null) {
				createCell(xlsrow, 1, dload.getFwLoc().getFwLocation()+"", style);
			} else {
				createCell(xlsrow, 1, "", style);
			}
			if (dload.getGenericLookup() != null) {
				createCell(xlsrow, 2, dload.getGenericLookup().getValue1()+"", style);
			} else {
				createCell(xlsrow, 2, "", style);
			}
			if (dload.getLoadValue() != null) {
			createCell(xlsrow, 3, dload.getLoadValue()+"", style);
			} else {
				createCell(xlsrow, 3, "", style);
			}
			if (dload.getGlobalData() != null) {
			createCell(xlsrow, 4, dload.getGlobalData()+"", style);
			} else {
				createCell(xlsrow, 4, "", style);
			}
		}
		log.debug("Admin Upload Action::writeIntoExcel::DailyLoad completed......");
		return workbook;
	}
	
	public HSSFWorkbook fwLoadExcel(List<FirewallFreeze> list) throws Exception {	
		log.debug("AdminUploadAction ..FirewallFreeze");
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Sheet1");

	    Font headerFont = workbook.createFont();
	    headerFont.setFontHeightInPoints((short)11);
	    headerFont.setFontName("Calibri");
	    headerFont.setColor(HSSFColor.WHITE.index);
	    headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
	    
	    CellStyle headerStyle = workbook.createCellStyle();
	    headerStyle.setFillForegroundColor(HSSFColor.DARK_BLUE.index);
	    headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	    headerStyle.setFont(headerFont);

	    Font font = workbook.createFont();
	    font.setFontHeightInPoints((short)11);
	    font.setFontName("Calibri");
	    
	    CellStyle style = workbook.createCellStyle();
	    style.setFont(font);

	    Font errFont = workbook.createFont();
	    errFont.setFontHeightInPoints((short)11);
	    errFont.setFontName("Calibri");
	    errFont.setColor(HSSFColor.RED.index);
	    
	    CellStyle errStyle = workbook.createCellStyle();
	    errStyle.setFont(errFont);

		HSSFRow HeaderRow = sheet.createRow((short) 0);
		HeaderRow.setHeight((short)330);
		createCell(HeaderRow, 0, "ID", headerStyle);
		createCell(HeaderRow, 1, "FIREWALL POLICY", headerStyle);
		createCell(HeaderRow, 2, "PHYSICAL REGION", headerStyle);
		createCell(HeaderRow, 3, "FREEZE START DATE", headerStyle);
		createCell(HeaderRow, 4, "FREEZE END DATE", headerStyle);
		createCell(HeaderRow, 5, "COMMENTS", headerStyle);
		/*sheet.addMergedRegion(new CellRangeAddress(0, 0, 4, 5));
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 6, 7));
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 9, 12));*/
		log.debug("Admin Upload Action::writeIntoExcel::Headers completed......");
		
		
		
		FirewallFreeze fwFreeze = null;
		
		HSSFRow xlsrow = null;
		
		for (int i = 0; i < list.size(); i++) {
			xlsrow = sheet.createRow((short) (i+1));
			fwFreeze = (FirewallFreeze) list.get(i);
			
			createCell(xlsrow, 0, fwFreeze.getId()+"", style);
			if (fwFreeze.getFwPolicy() != null && fwFreeze.getFwPolicy().getName() != null) {
				createCell(xlsrow, 1, fwFreeze.getFwPolicy().getName()+"", style);
				log.debug("Firewall policy name ++++"+fwFreeze.getFwPolicy().getName());
			} else {
				createCell(xlsrow, 1, "", style);
			}

			if (fwFreeze.getRegion() != null) {
				createCell(xlsrow, 2, fwFreeze.getRegion()+"", style);
			}else {
				createCell(xlsrow, 2, "", style);
			}
			
			if (fwFreeze.getFreezeStartDate() != null) {
				createCell(xlsrow, 3, fwFreeze.getFreezeStartDate()+"", style);
			}else {
				createCell(xlsrow, 3, "", style);
			}
			if (fwFreeze.getFreezeEndDate() != null) {
				createCell(xlsrow, 4, fwFreeze.getFreezeEndDate()+"", style);
			}else {
				createCell(xlsrow, 4, "", style);
			}
			if (fwFreeze.getComments() != null) {
				createCell(xlsrow, 5, fwFreeze.getComments()+"", style);
			}else {
				createCell(xlsrow, 5, "", style);
			}
			
		}
		log.debug("Admin Upload Action::writeIntoExcel::Firewall freeze Completed......");
		return workbook;
	}
	
	
	
	public HSSFWorkbook VacationFreezeExcel(List<VacationFreeze> list) throws Exception {	
		log.debug("AdminUploadAction ..VacationFreeze");
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Sheet1");

	    Font headerFont = workbook.createFont();
	    headerFont.setFontHeightInPoints((short)11);
	    headerFont.setFontName("Calibri");
	    headerFont.setColor(HSSFColor.WHITE.index);
	    headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
	    
	    CellStyle headerStyle = workbook.createCellStyle();
	    headerStyle.setFillForegroundColor(HSSFColor.DARK_BLUE.index);
	    headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	    headerStyle.setFont(headerFont);

	    Font font = workbook.createFont();
	    font.setFontHeightInPoints((short)11);
	    font.setFontName("Calibri");
	    
	    CellStyle style = workbook.createCellStyle();
	    style.setFont(font);

	    Font errFont = workbook.createFont();
	    errFont.setFontHeightInPoints((short)11);
	    errFont.setFontName("Calibri");
	    errFont.setColor(HSSFColor.RED.index);
	    
	    CellStyle errStyle = workbook.createCellStyle();
	    errStyle.setFont(errFont);

		HSSFRow HeaderRow = sheet.createRow((short) 0);
		HeaderRow.setHeight((short)330);
		createCell(HeaderRow, 0, "ID", headerStyle);
		createCell(HeaderRow, 1, "LOCATION", headerStyle);
		createCell(HeaderRow, 2, "FROM DATE", headerStyle);
		createCell(HeaderRow, 3, "TO DATE", headerStyle);
		createCell(HeaderRow, 4, "LOAD AVAILABLE", headerStyle);
		
		log.debug("Admin Upload Action::writeIntoExcel::VacationFreeze Headers completed......");
				
		VacationFreeze vacFreeze = null;
				
		HSSFRow xlsrow = null;
		
		for (int i = 0; i < list.size(); i++) {
			xlsrow = sheet.createRow((short) (i+1));
			vacFreeze = (VacationFreeze) list.get(i);
			
			createCell(xlsrow, 0, vacFreeze.getId()+"", style);
			if (vacFreeze.getFwLoc() != null) {
				createCell(xlsrow, 1, vacFreeze.getFwLoc().getFwLocation()+"", style);
			} else {
				createCell(xlsrow, 1, "", style);
			}
			if (vacFreeze.getFromDate() != null) {
				createCell(xlsrow, 2, vacFreeze.getFromDate()+"", style);
			}else {
				createCell(xlsrow, 2, "", style);
			}
			if (vacFreeze.getToDate() != null) {
				createCell(xlsrow, 3, vacFreeze.getToDate()+"", style);
			}else {
				createCell(xlsrow, 3, "", style);
			}
			
			
			if (vacFreeze.getLoadAvailable() != null) {
				createCell(xlsrow, 4, vacFreeze.getLoadAvailable()+"", style);
			}else {
				createCell(xlsrow, 4, "", style);
			}
			
		}

			
			
		
		log.debug("Admin Upload Action::writeIntoExcel::VacationFreeze Completed......");
		return workbook;
	}
		
	
}
