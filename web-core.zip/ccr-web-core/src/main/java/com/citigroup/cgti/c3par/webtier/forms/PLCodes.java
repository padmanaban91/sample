package com.citigroup.cgti.c3par.webtier.forms;

import java.util.ArrayList;

public class PLCodes {
	private String id;
	
	private ArrayList values;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public ArrayList getValues() {
		return values;
	}

	public void setValues(ArrayList values) {
		this.values = values;
	}

}
