package com.citigroup.cgti.c3par.configuation;

import org.springframework.jdbc.core.JdbcTemplate;

import com.citigroup.cgti.c3par.util.PasswordEncryptDecrypt;


public class EnvironmentVariable {
	
	private String envVar;
	private String decryptedMailStoreUri;
	private JdbcTemplate jdbcTemplateCCR;
	private PasswordEncryptDecrypt EncryptDecryptUtil;
	
//	private final String ENV_VAR = "select VALUE1 from generic_lookup where DEFINITION_ID= (SELECT ID FROM generic_lookup_defs WHERE NAME='ENVIRONMENT_VARIABLE')";
	
	private final String ENV_VAR = "select KEY_VALUE from SERVER_CONSTANTS where KEY_NAME= 'ENVIRONMENT'";
	private final String ENCRYPTED_MAIL_STORE_URI = "select KEY_VALUE from SERVER_CONSTANTS where KEY_NAME= 'ENCRYPTED_MAIL_STORE_URI' and key_env = (select KEY_VALUE from SERVER_CONSTANTS where KEY_NAME= 'ENVIRONMENT')";


	public JdbcTemplate getJdbcTemplateCCR() {
		return jdbcTemplateCCR;
	}

	public void setJdbcTemplateCCR(JdbcTemplate jdbcTemplateCCR) {
		this.jdbcTemplateCCR = jdbcTemplateCCR;
	}

	public PasswordEncryptDecrypt getEncryptDecryptUtil() {
		return EncryptDecryptUtil;
	}

	public void setEncryptDecryptUtil(PasswordEncryptDecrypt encryptDecryptUtil) {
		EncryptDecryptUtil = encryptDecryptUtil;
	}

	public String getEnvVar() {
		return envVar;
	}

	public void setEnvVar(String envVar) {
		this.envVar = (String)getJdbcTemplateCCR().queryForObject(ENV_VAR,String.class); ;
	}

	
	
	public String getDecryptedMailStoreUri() {
		return decryptedMailStoreUri;
	}

	public void setDecryptedMailStoreUri(String decryptedMailStoreUri) {
		String encryptedMailStoreUri = (String)getJdbcTemplateCCR().queryForObject(ENCRYPTED_MAIL_STORE_URI,String.class);
		//System.out.println("encryptedMailStoreUri -->"+encryptedMailStoreUri);
		//System.out.println("decryptedMailStoreUri -->"+EncryptionUtil.decrypt((String)getJdbcTemplateCCR().queryForObject(ENCRYPTED_MAIL_STORE_URI,String.class)));
		this.decryptedMailStoreUri = EncryptDecryptUtil.decrypt(encryptedMailStoreUri);


	}

	
}
