/**
 * 
 */
package com.citigroup.cgti.controller.inbox;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.kie.api.task.model.TaskSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.ccr.workflow.CCRWorkflowConstants;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;
import com.citigroup.cgti.inbox.dto.InboxDTO;
import com.citigroup.cgti.inbox.service.InboxService;
import com.citigroup.cgti.inbox.service.impl.InboxConstants;

/**
 * @author ka58098
 *
 */
@Controller
public class WorkFlowEventController {

    private static final Logger log = Logger.getLogger(WorkFlowEventController.class.getName());
    @Autowired
    WorkflowCallServiceHelper wrkflowCallServiceHelper;
    @Autowired
    WorkflowUtil workflowUtil;
    @Autowired
    private InboxService inboxService;

    @RequestMapping(value = "/workFlowEventLock.act", method = { RequestMethod.GET, RequestMethod.POST })
    public String workFlowEventLock(ModelMap model, @ModelAttribute("inboxProcess") InboxDTO inboxDTO,
            HttpServletRequest request) throws Exception {
        Long tiRequestId = Long.parseLong(request.getParameter(CCRWorkflowConstants.TIREQUESTID));
        Long userId = null;
        if(!StringUtil.isNullorEmpty(request.getParameter(CCRWorkflowConstants.USERID)))
        userId=Long.parseLong(request.getParameter(CCRWorkflowConstants.USERID));
        String ssoId = request.getHeader("SM_USER");
        String lockedBy = request.getParameter(CCRWorkflowConstants.LOCKEDBY);
        String forward = request.getParameter(CCRWorkflowConstants.FORWARD);
        String activityStage = request.getParameter(CCRWorkflowConstants.ACTIVITYSTAGE);
        String bpmActivityId = request.getParameter(CCRWorkflowConstants.BPMACTIVITYID);
        log.info("forward value is :: " + forward + " activityStage value is ::" + activityStage);
        if (!StringUtil.isNullorEmpty(activityStage) && !"pro_inf".equalsIgnoreCase(forward) && !"act_con".equalsIgnoreCase(forward) && 
        		!"uat_request_validation".equalsIgnoreCase(forward)/*
                                       * && !"AdminSupport".equalsIgnoreCase(
                                       * bpmActivityId)
                                       */) {
            boolean isActivityValid = inboxService.isBJCompletedByUser(tiRequestId, userId);
            if (isActivityValid) {
                return "forward:/bpmIntegrationAction.act?review=true&landingTab=true&errorMsg="
                        + InboxConstants.ERRORMSG;
            }
        }
        // long workItemId=workflowUtil.getWorkItemByTiRequestId(tiRequestId);
        String workItemId = request.getParameter(CCRWorkflowConstants.TASKID);
        request.getSession().setAttribute("taskId", workItemId);
        log.info("************Inside WorkFlow Event-------Task ID****************" + workItemId);
        log.info(" tiRequestId " + tiRequestId + " workItemId  " + workItemId + " lockedBy " + lockedBy);
        if (lockedBy != null && !"".equals(lockedBy) && !"null".equals(lockedBy)) {
            return "forward:/authenticate.act?instanceId=" + workItemId + "&participantId=" + ssoId;
        }
        log.info("::Lock Activity::");
        lockActivity(ssoId, tiRequestId, Long.parseLong(workItemId));
        return "forward:/authenticate.act?instanceId=" + workItemId + "&participantId=" + ssoId;
    }

    @RequestMapping(value = "/grabActivity.act", method = { RequestMethod.GET, RequestMethod.POST })
    public String workFlowGrabActivity(ModelMap model, @ModelAttribute("inboxProcess") InboxDTO inboxDTO,
            HttpServletRequest request) {
        log.info("Entering workFlowGrabActivity ::");
        String workItemId = String.valueOf(inboxDTO.getTaskId());
        String ssoId = request.getHeader("SM_USER");
        log.info("workItemId :: " + workItemId + " taskId ::" + request.getParameter("taskId"));
        unLockActivity(ssoId, inboxDTO.getTiRequestId(), inboxDTO.getTaskId(),true);
        lockActivity(ssoId, inboxDTO.getTiRequestId(), inboxDTO.getTaskId());
        request.getSession().setAttribute("taskId", workItemId);
        return "forward:/authenticate.act?instanceId=" + workItemId + "&participantId=" + ssoId;
    }

    private void lockActivity(String ssoId, Long tiRequestId, Long workItemId) {
        log.info("Entering Lock Activity ::");
        Map<String, Object> userFlowParams = new HashMap<String, Object>();
        TaskSummary taskSummary = workflowUtil.getTaskSummary(workItemId);
        userFlowParams.put("soeid", ssoId);
        userFlowParams.put(CCRWorkflowConstants.TASK_SUMMARY, taskSummary);
        log.info(" process instance id ==" + taskSummary.getProcessInstanceId());
        wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, userFlowParams, WorkflowEvent.LOCK,
                tiRequestId);
        log.info("Exiting::");
    }

    private void unLockActivity(String ssoId, Long tiRequestId, Long workItemId,boolean isGrabActivity) {
        log.info("Entering unLock Activity::");
        Map<String, Object> adminFlowParams = new HashMap<String, Object>();
        adminFlowParams.put("soeid", ssoId);
        adminFlowParams.put(CCRWorkflowConstants.TASK_SUMMARY, workflowUtil.getTaskSummary(workItemId));
        if(isGrabActivity){
        	adminFlowParams.put(CCRWorkflowConstants.IS_GRAB_ACTIVITY, new Boolean(isGrabActivity));
        }
        wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, adminFlowParams, WorkflowEvent.UNLOCK,
                tiRequestId);
        log.info("Exiting::");
    }

   

    @RequestMapping(value = "/workFlowEventUnLock.act", method = { RequestMethod.GET, RequestMethod.POST })
    public String workFlowEventUnLock(ModelMap model, HttpServletRequest request,boolean isGrabActivity) throws Exception {
        Long tiRequestId = Long.parseLong(request.getParameter(CCRWorkflowConstants.TIREQUESTID));
        String workItemId = request.getParameter(CCRWorkflowConstants.TASKID);
        String ssoId = request.getHeader("SM_USER");
        // long workItemId=workflowUtil.getWorkItemByTiRequestId(tiRequestId);
        log.info(" tiRequestId :: " + tiRequestId + " workItemId ::" + workItemId);
        unLockActivity(ssoId, tiRequestId, Long.parseLong(workItemId),false);
        return "forward:/loadMyTasksController.act";
    }

  
}
