package com.citigroup.cgti.c3par.controller.appsense;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseApplication;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseDTO;
import com.citigroup.cgti.c3par.appsense.domain.ManageAppsenseProcess;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiResource;
import com.citigroup.cgti.c3par.controller.firewall.BaseController;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.webtier.helper.AppsenseUtil;
import com.citigroup.cgti.c3par.webtier.helper.Util;

/*
 * @nc43495
 */
@SuppressWarnings("unchecked")
@Controller
public class ManageAppsenseController extends BaseController {

	/** The log. */
	public static Logger log = Logger
			.getLogger(ManageAppsenseController.class);
	

	/** The util. */
	Util util = new Util();
	
	AppsenseUtil appsenseUtil = new AppsenseUtil();

	/** The props. */
	private static ResourceBundle props = ResourceBundle.getBundle(System.getProperty("ccr-application"), Locale.getDefault());
	

	@RequestMapping(value = "/loadAppsense.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String loadAppsense(ModelMap model, HttpServletRequest request) {
		log.info("ManageAppsenseController:load method starts here ...");
	
		String requestType = null;
		ManageAppsenseProcess manageAppsenseProcess = new ManageAppsenseProcess();
		AppsenseApplication appsenseApplication = new AppsenseApplication();
		AppsenseDTO apsProcess = new AppsenseDTO();
		request.getSession().removeAttribute("appsApplication");
		
		manageAppsenseProcess.setBlackListedAppsList(util.getBlackListedApplication());
		manageAppsenseProcess.setRiskPortList(util.getRiskPort());
		
		Application application = new Application();
		application.setIsBlackListed("Y");
		application.setIsDevice("N");
		application.setIsCSI("N");
		appsenseApplication.setApplication(application);
		manageAppsenseProcess.setAppsenseApplication(appsenseApplication);

		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		requestType = tiRequest.getTiRequestType().getName();

			if (requestType != null
					&& requestType.equalsIgnoreCase("Terminate")) {
				log.debug("Setting DisplayMode to View for Termination Cycle");
				request.getSession().setAttribute("displayMode", "View");
			}

		apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		manageAppsenseProcess.setOffset(0);
		manageAppsenseProcess.setPageNo(1);
		manageAppsenseProcess.setLimit(5);
		List<AppsenseApplication> appsenseApplicationList = manageAppsenseProcess.loadAppsenseApplications(apsProcess,manageAppsenseProcess);
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		int limit = 5;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		log.info("appsenseApplicationList--->>>" + appsenseApplicationList);
		manageAppsenseProcess.setAppsenseApplicationList(appsenseApplicationList);
		manageAppsenseProcess.setApsProcess(apsProcess);

		appsenseApplication.setTiProcess(tiProcess);
		appsenseApplication.setTiRequest(tiRequest);
		
		appsenseApplication.setPortUnblock("N");
		manageAppsenseProcess.setAppsenseApplication(appsenseApplication);
		appsenseApplication.getApplication().setIsBlackListed("Y");
		
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}
		
		model.addAttribute("appsenseData", manageAppsenseProcess);
		request.setAttribute("addApplication", "false");
		request.getSession().setAttribute("viewIndex", "edit");
		request.getSession().removeAttribute("viewAppsense");
		request.getSession().setAttribute("appsApplication",manageAppsenseProcess.getAppsenseApplicationList());
		
		
		isAppsenseCompleteCheck(request);

		log.info("ManageAppsenseProcess.load()::Ends");
		return "c3par.appsense";
	}
	
	
	public String loadAppsenseData(ModelMap model, HttpServletRequest request, ManageAppsenseProcess manageAppsenseProcess) {
		log.info("ManageAppsenseController:load method starts here ...");
		
		int curOffSet = manageAppsenseProcess.getOffset();
		int limit = manageAppsenseProcess.getLimit();
		int pageNo = manageAppsenseProcess.getPageNo();
		
		log.debug("ManageAppsenseController:load offset "+curOffSet);
		log.debug("ManageAppsenseController:load limit "+limit);

		manageAppsenseProcess.setBlackListedAppsList(util.getBlackListedApplication());
		manageAppsenseProcess.setRiskPortList(util.getRiskPort());
		
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		AppsenseDTO apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		
		manageAppsenseProcess.setOffset(Integer.valueOf(curOffSet));
		manageAppsenseProcess.setLimit(Integer.valueOf(limit));
		manageAppsenseProcess.setPageNo(Integer.valueOf(pageNo));
		
		List<AppsenseApplication> appsenseApplicationList = manageAppsenseProcess.loadAppsenseApplications(apsProcess,manageAppsenseProcess);
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		
		if (rowCount%manageAppsenseProcess.getLimit() > 0) {
			totalPages = Math.round((rowCount/manageAppsenseProcess.getLimit())+0.5f);
		} else {
			totalPages = Math.round(rowCount/manageAppsenseProcess.getLimit());
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		log.info("appsenseApplicationList--->>>" + appsenseApplicationList);
		manageAppsenseProcess.setAppsenseApplicationList(appsenseApplicationList);
		manageAppsenseProcess.setApsProcess(apsProcess);
		
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}

		model.addAttribute("appsenseData", manageAppsenseProcess);
		request.setAttribute("addApplication", "true");
		request.getSession().setAttribute("viewIndex", "edit");
		request.getSession().removeAttribute("viewAppsense");
		request.getSession().setAttribute("appsApplication",manageAppsenseProcess.getAppsenseApplicationList());
		
		isAppsenseCompleteCheck(request);

		log.info("ManageAppsenseProcess.load()::Ends");
		return "c3par.appsense";
	}
	
	@RequestMapping(value = "/paginateAppsense.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String paginateAppsense(ModelMap model, HttpServletRequest request, @ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess) {
		log.info("ManageAppsenseController:load method starts here ...");
	
		String requestType = null;
		
		int curOffSet = manageAppsenseProcess.getOffset();
		int limit = manageAppsenseProcess.getLimit();
		int pageNo = manageAppsenseProcess.getPageNo();
		String type = (String)request.getParameter("type");
		
		log.debug("ManageAppsenseController::paginateIPs type..."+type);
		
		manageAppsenseProcess = new ManageAppsenseProcess();
		AppsenseApplication appsenseApplication = new AppsenseApplication();
		AppsenseDTO apsProcess = new AppsenseDTO();
		request.getSession().removeAttribute("appsApplication");
		
		manageAppsenseProcess.setBlackListedAppsList(util.getBlackListedApplication());
		manageAppsenseProcess.setRiskPortList(util.getRiskPort());
		
		Application application = new Application();
		application.setIsBlackListed("Y");
		application.setIsDevice("N");
		application.setIsCSI("N");
		appsenseApplication.setApplication(application);
		manageAppsenseProcess.setAppsenseApplication(appsenseApplication);

		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		requestType = tiRequest.getTiRequestType().getName();

			if (requestType != null
					&& requestType.equalsIgnoreCase("Terminate")) {
				log.debug("Setting DisplayMode to View for Termination Cycle");
				request.getSession().setAttribute("displayMode", "View");
			}

		apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		manageAppsenseProcess.setLimit(limit);
		if ("N".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(curOffSet+manageAppsenseProcess.getLimit());
			manageAppsenseProcess.setPageNo(pageNo+1);
		} else if ("P".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(curOffSet-manageAppsenseProcess.getLimit());
			manageAppsenseProcess.setPageNo(pageNo-1);
		} else if ("X".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(limit * (pageNo-1));
			manageAppsenseProcess.setPageNo(pageNo);
		} else if ("L".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(0);
			manageAppsenseProcess.setPageNo(1);
		} else {
			manageAppsenseProcess.setOffset(0);
			manageAppsenseProcess.setPageNo(1);
		}
		
		List<AppsenseApplication> appsenseApplicationList = manageAppsenseProcess.loadAppsenseApplications(apsProcess,manageAppsenseProcess);
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		log.info("appsenseApplicationList--->>>" + appsenseApplicationList);
		manageAppsenseProcess.setAppsenseApplicationList(appsenseApplicationList);
		manageAppsenseProcess.setApsProcess(apsProcess);

		appsenseApplication.setTiProcess(tiProcess);
		appsenseApplication.setTiRequest(tiRequest);
		
		appsenseApplication.setPortUnblock("N");
		manageAppsenseProcess.setAppsenseApplication(appsenseApplication);
		appsenseApplication.getApplication().setIsBlackListed("Y");
		
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}
		
		model.addAttribute("appsenseData", manageAppsenseProcess);
		request.setAttribute("addApplication", "false");
		request.getSession().setAttribute("viewIndex", "edit");
		request.getSession().setAttribute("selectedTab", "aps");
		request.getSession().removeAttribute("viewAppsense");
		request.getSession().setAttribute("appsApplication",manageAppsenseProcess.getAppsenseApplicationList());
		
		log.info("ManageAppsenseProcess.load()::Ends");
		return "c3par.appsense";
	}
	
	
	
	@RequestMapping(value = "/addResourceAppsense.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String addAppsenseResource(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		
		log.info("ManageAppsenseProcess.addResource()::Starts");
		String selectedTab = request.getParameter("tab");
		String forwardTo = "c3par.appsense";
		String indexId = null;
		manageAppsenseProcess.setBlackListedAppsList(util.getBlackListedApplication());
		manageAppsenseProcess.setRiskPortList(util.getRiskPort());
		manageAppsenseProcess.setAppsenseApplicationList((List<AppsenseApplication>)request.getSession().getAttribute("appsApplication"));
		
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		
		AppsenseDTO apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		manageAppsenseProcess.setApsProcess(apsProcess);
		
		if (request.getParameter("indexId") != null) {
			indexId = (String) (request.getParameter("indexId"));
		}
		if (indexId != null && !indexId.equals("")) {
			request.setAttribute("EditIndexId", indexId);
		}
		if (selectedTab != null) {
			request.getSession().setAttribute("selectedTab", selectedTab);
		}
		if (request.getSession().getAttribute(
				"COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY") != null) {
			log.debug("CSI selected ");
			CitiResource citiResourceEntity = (CitiResource) request
					.getSession().getAttribute(
							"COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY");
			manageAppsenseProcess.setIpResourceId(Long.valueOf(citiResourceEntity
					.getCwhiId()));
			log.debug("ManageAppsenseProcess.addResource()::getName "
					+ citiResourceEntity.getName());
				manageAppsenseProcess.getAppsenseApplication().getApplication()
						.setApplicationID(Long.valueOf(citiResourceEntity.getCwhiId()));
				if ((citiResourceEntity.getName() == null)
						|| citiResourceEntity.getName()
								.equalsIgnoreCase("NULL")) {
					manageAppsenseProcess.getAppsenseApplication()
							.getApplication().setApplicationName("");
				} else {
					manageAppsenseProcess.getAppsenseApplication()
							.getApplication()
							.setApplicationName(citiResourceEntity.getName());
				}
				if ((citiResourceEntity.getFunctionalityDescription() == null)
						|| citiResourceEntity.getFunctionalityDescription()
								.equalsIgnoreCase("NULL")) {
					manageAppsenseProcess.getAppsenseApplication()
							.getApplication().setFunction("");
				} else {
					manageAppsenseProcess
							.getAppsenseApplication()
							.getApplication()
							.setFunction(
									citiResourceEntity
											.getFunctionalityDescription());
				}

				manageAppsenseProcess.getAppsenseApplication().getApplication()
						.setAppOwnerFullName(citiResourceEntity.getOwner());
				if ((citiResourceEntity.getOwnerid() == null)
						|| citiResourceEntity.getOwnerid().equalsIgnoreCase(
								"NULL")) {
					manageAppsenseProcess.getAppsenseApplication()
							.getApplication().setAppOwnerGEID("");
				} else {
					manageAppsenseProcess.getAppsenseApplication()
							.getApplication()
							.setAppOwnerGEID(citiResourceEntity.getOwnerid());
				}
				if (manageAppsenseProcess.getAppsenseApplication()
						.getApplication().getIsCSI() != null
						&& manageAppsenseProcess.getAppsenseApplication()
								.getApplication().getIsCSI()
								.equalsIgnoreCase("Y")
						&& request.getSession().getAttribute("APP_OWNER_EMAIL") != null) {
					manageAppsenseProcess
							.getAppsenseApplication()
							.getApplication()
							.setAppOwnerEmail(
									(String) request.getSession().getAttribute(
											"APP_OWNER_EMAIL"));
				} else {
					manageAppsenseProcess.getAppsenseApplication()
							.getApplication().setAppOwnerEmail(null);
				}
				// added for new columns Start
				if (manageAppsenseProcess.getAppsenseApplication()
						.getApplication().getIsCSI() != null
						&& manageAppsenseProcess.getAppsenseApplication()
								.getApplication().getIsCSI()
								.equalsIgnoreCase("Y")) {
					if (request.getSession().getAttribute("APP_MGR_EMAIL") != null) {
						String managerEmail = (String) request.getSession()
								.getAttribute("APP_MGR_EMAIL");
						manageAppsenseProcess.getAppsenseApplication()
								.getApplication()
								.setAppManagerEmail(managerEmail);
						log.debug("managerEmail for aps ManageAppsenseProcess: "
								+ managerEmail);
					}
					if (request.getSession().getAttribute("APP_MGR_FULL_NAME") != null) {
						String appManagerFullName = (String) request
								.getSession().getAttribute("APP_MGR_FULL_NAME");
						manageAppsenseProcess.getAppsenseApplication()
								.getApplication()
								.setAppManagerFullName(appManagerFullName);
						log.debug("appManagerFullName for aps ManageAppsenseProcess: "
								+ appManagerFullName);
					}
					if (request.getSession().getAttribute("APP_MGR_GEID") != null) {
						String appManagerGEID = (String) request.getSession()
								.getAttribute("APP_MGR_GEID");
						manageAppsenseProcess.getAppsenseApplication()
								.getApplication()
								.setAppManagerGEID(appManagerGEID);
						log.debug("appManagerGEID for aps ManageAppsenseProcess: "
								+ appManagerGEID);
					}
				} else {
					manageAppsenseProcess.getAppsenseApplication()
							.getApplication().setAppManagerEmail(null);
					manageAppsenseProcess.getAppsenseApplication()
							.getApplication().setAppManagerFullName(null);
					manageAppsenseProcess.getAppsenseApplication()
							.getApplication().setAppManagerGEID(null);
				}
				// added for new columns end
				manageAppsenseProcess.getAppsenseApplication().getApplication()
						.setIsBlackListed("N");
				manageAppsenseProcess.getAppsenseApplication().getApplication()
						.setIsDevice("N");
				manageAppsenseProcess.getAppsenseApplication().getApplication()
						.setIsCSI("Y");


		} 
		
		
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}
		
		request.setAttribute("CSI", "CSI");
		request.getSession().removeAttribute(
				"COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY");
		model.addAttribute("appsenseData", manageAppsenseProcess);
		log.info("ManageAppsenseProcess.addResource()::Ends");
		return forwardTo;
	}
	
	@RequestMapping(value = "/addAppsenseApplication.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String addAppsenseApplication(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request, BindingResult bresult) {
		log.info("ManageAppsenseProcess.addAppsensePolicy() :: Starts...");
		
		try {
		
		AppsenseApplication appsenseApplication = manageAppsenseProcess
				.getAppsenseApplication();
		
		log.info("Appsesne application -add"+manageAppsenseProcess
				.getAppsenseApplication());
		String portData = appsenseApplication.getPortUnblock();
		String portNumber = null;
		String protocol = null;
		String[] portNo = null;
		String applicationType = null;
		boolean applicationName = false;
		boolean applcationFunction = false;
		boolean appOwner = false;
		boolean appOwnerGEID = false;
		boolean appExecFile = false;

		log.info("applicationName::" + appsenseApplication.getApplication().getApplicationName() + ",isCSI::"
				+ appsenseApplication.getApplication().getIsCSI());
		
		if (appsenseApplication.getApplication() != null
				&& appsenseApplication.getApplication().getIsCSI() != null) {
			applicationType = appsenseApplication.getApplication().getIsCSI();
			String blackList = appsenseApplication.getApplication()
					.getIsBlackListed();
			log.info("applicationType::" + applicationType + ",blackList::"
					+ blackList);
			
			if (applicationType != null && (blackList != null && blackList.trim().equalsIgnoreCase("N"))
					&& (applicationType.trim().equalsIgnoreCase("Y") || applicationType
							.trim().equalsIgnoreCase("N"))) {
				applicationName = appsenseUtil.isValidData(appsenseApplication
						.getApplication().getApplicationName());
				applcationFunction =appsenseUtil. isValidData(appsenseApplication
						.getApplication().getFunction());
				appOwner = appsenseUtil.isValidData(appsenseApplication.getApplication()
						.getAppOwnerFullName());
				appOwnerGEID = appsenseUtil.isValidData(appsenseApplication.getApplication()
						.getAppOwnerGEID());
				appExecFile = appsenseUtil.isValidData(appsenseApplication.getApplication()
						.getExeFileName());

				if (blackList.trim().equalsIgnoreCase("N")
						&& applicationType.trim().equalsIgnoreCase("N")) {
					if (!(applicationName && applcationFunction && appOwner
							&& appOwnerGEID && appExecFile)) {
						throw new BusinessException(
								"Please fill all the details which are * marked.");
					}
				} else if (blackList.trim().equalsIgnoreCase("N")
						&& applicationType.trim().equalsIgnoreCase("Y")) {
					if (!(applicationName && appExecFile)) {
						throw new BusinessException(
								"ApplicationName and file name are mandatory.");
					}

				}

			}
		}
		if (appsenseApplication.getApsPortMaster() != null
				&& appsenseApplication.getApsPortMaster().getPortLookUp() != null) {
			if (portData != null
					&& (portData.equalsIgnoreCase("YES") || portData
							.equalsIgnoreCase("Y"))) {
				if (appsenseApplication.getApsPortMaster().getPortLookUp()
						.getPortNumber() != null) {
					String port = appsenseApplication.getApsPortMaster()
							.getPortLookUp().getPortNumber();
					portNo = port.split("/");
					protocol = portNo[0];
					portNumber = portNo[1];
				}
				if (portNumber != null) {
					appsenseApplication.getApsPortMaster().getPortLookUp()
							.setPortNumber(portNumber);
					appsenseApplication.getApsPortMaster().getPortLookUp()
							.setProtocol(protocol);
					log.info("portData::" + portData + "::portNumber"
							+ portNumber + "::Protocol" + protocol);
				}
			}
		}

		if (portData != null
				&& (portData.trim().equalsIgnoreCase("Y") || portData.trim()
						.equalsIgnoreCase("YES"))) {
			if (portNumber == null
					|| (portNumber != null && (portNumber.trim().equals("") || portNumber
							.trim().equalsIgnoreCase("--Select Port--")))) {
				throw new BusinessException("Port number should be selected.");
			}
		}
		String tiReq = (String) request.getSession().getAttribute("tireqid");

		log.info("tiReq from SESSION===" + tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}

		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId
				.longValue());
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId
				.longValue());
		appsenseApplication.setTiProcess(tiProcess);
		appsenseApplication.setTiRequest(tiRequest);
		
		
		String adGroupName = manageAppsenseProcess.getAppsADGroupName();
		
		AppsenseADGroup appsenseADGroupName = new AppsenseADGroup();
		appsenseADGroupName = (AppsenseADGroup) util
				.checkAppsADGroupName(adGroupName);
		if (appsenseADGroupName.getId() == null) {
			appsenseADGroupName.setName(manageAppsenseProcess
					.getAppsADGroupName());
			appsenseADGroupName.setPolicyID(manageAppsenseProcess
					.getAppsPolicyId());
			appsenseADGroupName.setPolicyName(manageAppsenseProcess
					.getAppsPolicyName());
			appsenseADGroupName = manageAppsenseProcess
					.storeAppsADGroup(appsenseADGroupName);
			util.updateAppsADGroupID(tiProcess.getId(),
					appsenseADGroupName.getId());
			util.updateProxyADGroupID(tiProcess.getId(),
					appsenseADGroupName.getId());
			manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroupName
					.getId());
			appsenseApplication.setAppsenseADGroup(appsenseADGroupName);
		} else {
			appsenseADGroupName.setName(manageAppsenseProcess
					.getAppsADGroupName());
			appsenseADGroupName.setPolicyID(manageAppsenseProcess
					.getAppsPolicyId());
			appsenseADGroupName.setPolicyName(manageAppsenseProcess
					.getAppsPolicyName());	
			appsenseADGroupName = manageAppsenseProcess
					.updateAppsADGroup(appsenseADGroupName);
			appsenseApplication.setAppsenseADGroup(appsenseADGroupName);
		}
		
		manageAppsenseProcess.storeAppsenseApplication(appsenseApplication);
		} catch (BusinessException e) {
			log.error("Business Exception Occured... - "+e.getMessage());
			bresult.addError(new ObjectError("appsenseData.appsenseApplication", e.getMessage()));
			return loadAppsenseData(model, request, manageAppsenseProcess);
		}  catch (ApplicationException e) {
			log.error("Application Exception Occured... - "+e.getMessage());
			bresult.addError(new ObjectError("appsenseData.appsenseApplication", e.getMessage()));
			return loadAppsenseData(model, request, manageAppsenseProcess);
		}
		
		log.info("ManageAppsenseProcess.addAppsensePolicy() :: Ends...");
		return "forward:/loadAppsense.act";
	}

	
	@RequestMapping(value = "/loadAppsensePolicy.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadAppsensePolicy(
			ModelMap model,@ModelAttribute("appsenseData")
			ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		log.info("ManageAppsenseController:load method starts here ...");
	
		String curOffSet = request.getParameter("offset");
		String limit = request.getParameter("limit");
		String pageNo = request.getParameter("pageNo");
		
		log.debug("ManageAppsenseController:load offset "+curOffSet);
		log.debug("ManageAppsenseController:load limit "+limit);

		manageAppsenseProcess = new ManageAppsenseProcess();
		AppsenseApplication appsenseApplication = new AppsenseApplication();
		AppsenseDTO apsProcess = new AppsenseDTO();
		request.getSession().removeAttribute("appsApplication");
		
		manageAppsenseProcess.setBlackListedAppsList(util.getBlackListedApplication());
		manageAppsenseProcess.setRiskPortList(util.getRiskPort());
		
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		
		manageAppsenseProcess.setOffset(Integer.valueOf(curOffSet));
		manageAppsenseProcess.setLimit(Integer.valueOf(limit));
		manageAppsenseProcess.setPageNo(Integer.valueOf(pageNo));
		
		List<AppsenseApplication> appsenseApplicationList = manageAppsenseProcess.loadAppsenseApplications(apsProcess,manageAppsenseProcess);
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		
		if (rowCount%manageAppsenseProcess.getLimit() > 0) {
			totalPages = Math.round((rowCount/manageAppsenseProcess.getLimit())+0.5f);
		} else {
			totalPages = Math.round(rowCount/manageAppsenseProcess.getLimit());
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		log.info("appsenseApplicationList--->>>" + appsenseApplicationList);
		manageAppsenseProcess.setAppsenseApplicationList(appsenseApplicationList);
		manageAppsenseProcess.setApsProcess(apsProcess);

		appsenseApplication.setTiProcess(tiProcess);
		appsenseApplication.setTiRequest(tiRequest);
		
		String indexId = request.getParameter("indexId");
		
		log.info("ManageAppsenseProcess.loadAppsensePolicy()::Indexid::: "
				+ indexId);
		int index = -1;
		if ((indexId != null) && !indexId.equals("null")) {
			index = Integer.valueOf(indexId).intValue();
		}
		
		String protocol = null;
		String portNo = null;

		if (index >= 0) {
				AppsenseApplication apsApplication = (AppsenseApplication) (((AppsenseApplication) appsenseApplicationList
						.get(index)));
				if (apsApplication.getApsPortMaster().getConnectionIPMaster()
						.getIpAddress() != null
						&& apsApplication.getApsPortMaster()
								.getConnectionIPMaster().getStartIPAddress() == null
						&& apsApplication.getApsPortMaster()
								.getConnectionIPMaster().getSubnet() == null) {
					apsApplication.getApsPortMaster().getConnectionIPMaster()
							.setUserInputType("SINGLE");
				} else if (((apsApplication.getApsPortMaster()
						.getConnectionIPMaster().getStartIPAddress() != null) || (apsApplication
						.getApsPortMaster().getConnectionIPMaster()
						.getEndIPAddress() != null))
						&& apsApplication.getApsPortMaster()
								.getConnectionIPMaster().getSubnet() == null) {
					apsApplication.getApsPortMaster().getConnectionIPMaster()
							.setUserInputType("MULTIPLE");
				} else if (apsApplication.getApsPortMaster()
						.getConnectionIPMaster().getSubnet() != null) {
					apsApplication.getApsPortMaster().getConnectionIPMaster()
							.setUserInputType("SUBNET");
				}
				if (apsApplication.getPortUnblock() != null
						&& (apsApplication.getPortUnblock().equalsIgnoreCase(
								"YES") || apsApplication.getPortUnblock()
								.equalsIgnoreCase("Y"))) {
					protocol = apsApplication.getApsPortMaster()
							.getPortLookUp().getProtocol();
					portNo = apsApplication.getApsPortMaster().getPortLookUp()
							.getPortNumber();
					log.info("protocol" + protocol + "port Number " + portNo);
					if (protocol != null && portNo != null) {
						apsApplication.getApsPortMaster().getPortLookUp()
								.setPortNumber(protocol + "/" + portNo);
					}
				}
				if (apsApplication.getApplication() != null) {
					if (apsApplication.getApplication().getIsBlackListed() != null) {
						if (apsApplication.getApplication().getIsBlackListed()
								.equals("Y")) {
							apsApplication.getApplication().setIsCSI("N");
						}
					}
					if (apsApplication.getApplication().getIsCSI() != null) {
						if (apsApplication.getApplication().getIsCSI()
								.equals("Y"))
							apsApplication.getApplication().setIsBlackListed(
									"N");
					}
				}
				apsApplication.getApplication().setIsDevice("N");
				manageAppsenseProcess.setAppsenseApplication(apsApplication);
				request.getSession().setAttribute("viewIndex", "view");
				request.getSession().setAttribute("viewAppsense", "true");
		}
		
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}
		
		model.addAttribute("appsenseData", manageAppsenseProcess);
		request.getSession().setAttribute("appsApplication",manageAppsenseProcess.getAppsenseApplicationList());
		
		log.info("ManageAppsenseProcess.load()::Ends");
		return "c3par.appsense";
	}
	
	

	@RequestMapping(value = "/uploadAppsenseApplicationExcel.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String uploadAppsenseApplicationExcel(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request, HttpServletResponse response, BindingResult bResult) {
		log.info("ManageAppsenseProcess.uploadAppsenseApplicationExcel()::Starts");
		
		String selectedTab = request.getParameter("tab");
		log.info("selectedTab:: " + selectedTab);
		try {
			
			String tiReq = (String) request.getSession()
					.getAttribute("tireqid");
			log.info("tiReq from SESSION===" + tiReq);
			Long tiRequestId = Long.valueOf(0);
			if (tiReq != null) {
				try {
					tiRequestId = Long.valueOf(tiReq);
				} catch (Exception e) {
					tiRequestId = Long.valueOf(0);
				}
			}
			log.info("tiRequestId===" + tiRequestId);
			
			
			TIProcess tiProcess = manageAppsenseProcess
					.getTIProcess(tiRequestId.longValue());
			log.info("tiProcess:: " + tiProcess);
			TIRequest tiRequest = manageAppsenseProcess
					.getTIRequest(tiRequestId.longValue());
			log.info("tiRequest:: " + tiRequest);
			
			Long processId = tiProcess.getId();

			log.info("processId===" + processId);
			
			manageAppsenseProcess.setTirequest(tiRequest);
			
			AppsenseApplication appsenseApplication = manageAppsenseProcess
					.getAppsenseApplication();
			log.info("appsenseApplication:: " + appsenseApplication);
			
			CommonsMultipartFile file = manageAppsenseProcess
					.getAppsenseUploadExcelFormFile();
			log.info("file::: " + file);
				List<AppsenseApplication> getAppsenseApplicationReadDataList = (ArrayList<AppsenseApplication>) appsenseUtil.readExcelAppsenseApplicationFile(
						request, response, file, tiProcess, tiRequest,
						appsenseApplication, manageAppsenseProcess, selectedTab);
				log.info("Size of getProxyFilterReadDataList::: "
						+ getAppsenseApplicationReadDataList.size());
				List<AppsenseApplication> storedAppsenseApplicationList = null;
				String failureStatusMessage = "norecords";
				if (appsenseUtil.isAppUploadValid(getAppsenseApplicationReadDataList)) {
					storedAppsenseApplicationList = (ArrayList<AppsenseApplication>) appsenseUtil.storeAppsenseApplicationRecords(
							getAppsenseApplicationReadDataList,
							manageAppsenseProcess, selectedTab);
					log.info("Size of Stored AppsenseApplicaiton List::: "
							+ storedAppsenseApplicationList.size());
					appsenseUtil.writeExcelAppsenseApplication(
							storedAppsenseApplicationList, tiReq, selectedTab);
					failureStatusMessage = "successMessage";
				} else {
					appsenseUtil.writeExcelAppsenseApplication(
							getAppsenseApplicationReadDataList, tiReq,
							selectedTab);
					failureStatusMessage = "uploadfailed";
				}

				String filePath = null;
				File fileExist = null;
				String file_status = "false";
				if (selectedTab != null ) {
					if (!"uploadfailed".equals(failureStatusMessage)) {
						for (int i = 0; i < storedAppsenseApplicationList
								.size(); i++) {
							AppsenseApplication appsenseApplication3 = (AppsenseApplication) storedAppsenseApplicationList
									.get(i);
							if (appsenseApplication3.getStatus()
									.equalsIgnoreCase("Failure")) {
								failureStatusMessage = "failureMessage";
							}
						}
					}
					if (getAppsenseApplicationReadDataList == null
							|| getAppsenseApplicationReadDataList.size() == 0) {
						failureStatusMessage = "norecords";
					}

					if (failureStatusMessage.equals("successMessage")) {
						request.setAttribute(
								"success_log",
								"Upload Completed.Template data uploaded successfully. Download template and check.");
					} else if (failureStatusMessage.equals("failureMessage")) {
						request.setAttribute("success_log",
								"Upload Completed. Download the template and check for errors.");
					} else if (failureStatusMessage.equals("uploadfailed")) {
						request.setAttribute("error_log",
								"Upload Failed. Download the template and check for errors.");
					} else if (failureStatusMessage.equals("norecords")) {
						request.setAttribute(
								"error_log",
								"No rows found to upload. Please check the template if application type is provided.");
					}
					//filePath = props.getString("XLS_FILE_WRITE_PROXY_FILTER_PATH")+ tiReq + "_appsenseApp.xls";
					filePath=System.getProperty("application-log-path")+ tiReq + "_appsenseApp.xls";
					fileExist = new File(filePath);
					if (fileExist == null || !fileExist.exists()
							|| fileExist.equals("")) {
						request.setAttribute("file_status", "false");
					} else {
						log.info("File Exists");
						request.setAttribute("file_status", "true");
					}
					request.setAttribute("fileStoredPath", tiReq
							+ "_appsenseApp.xls");
			}
		} catch (Exception e) {
			log.error(e,e);
			log.info("Exception occurred");
			bResult.addError(new ObjectError("appsenseData.appsenseApplication", "Error ocurred while uploading the Excel"));
			return loadAppsenseData(model, request, manageAppsenseProcess);
		}
		log.info("ManageAppsenseProcess.uploadAppsenseApplicationExcel()::Ends");
		return "forward:/loadAppsense.act";
	}
	

	@RequestMapping(value = "/removeAppsensePolicy.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String removeAppsensePolicy(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		AppsenseDTO apsProcess = manageAppsenseProcess.getApsProcess();
		log.debug("Is SelectAll for apsProcess::: " + apsProcess.isSelectAll());
		
		List<AppsenseApplication> appsenseApplicationList = manageAppsenseProcess.getAppsenseApplicationList();
		apsProcess.setAppsenseApplicationList(appsenseApplicationList);
		manageAppsenseProcess.deleteAppsenseApplication(apsProcess);
		
		return "forward:/loadAppsense.act";
	}

}
