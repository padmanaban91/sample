package com.citigroup.cgti.c3par.connection.domain.logic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.connection.domain.ConnectionCPFirewall;
import com.citigroup.cgti.c3par.connection.domain.ConnectionFirewallPolicyLookUp;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIPXref;
import com.citigroup.cgti.c3par.domain.ResourceType;
import com.citigroup.cgti.c3par.performer.dao.PerformerDAO;
import com.citigroup.cgti.c3par.performer.util.PerformerFilter;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class TechnicalArchitectureLookup.
 */
@SuppressWarnings( { "unchecked", "unused" })
public class TechnicalArchitectureLookup implements
TechnicalArchitectureLookupFacade {

    /** The log. */
    private Logger log = Logger.getLogger(this.getClass().getName());

    /** The performer dao. */
    private PerformerDAO performerDao;

    /**
     * Sets the performer dao.
     *
     * @param performerDao The performerDao to set.
     */
    public void setPerformerDao(PerformerDAO performerDao) {
	this.performerDao = performerDao;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.connection.domain.logic.TechnicalArchitectureLookupFacade#getResourceTypeObjs(java.lang.String)
     */
    public List getResourceTypeObjs(String perimeter) {
	List returnData = new ArrayList();
	try {
	    List filters = new ArrayList();
	    PerformerFilter filter = new PerformerFilter();
	    filter.setAttribute("perimeter");
	    filter.setFunction(PerformerTypes.EQUAL);
	    filter.setValue(perimeter);
	    filters.add(filter);

	    filter = new PerformerFilter();
	    filter.setAttribute("status");
	    filter.setFunction(PerformerTypes.EQUAL);
	    filter.setValue("Active");
	    filters.add(filter);

	    List data = performerDao.findEntities(new ResourceType(), 0,
		    filters);

	    if (data != null && data.size() > 0) {
		returnData.addAll(data);
	    }
	} catch (Exception e) {
	    log.error(e);
	    if (e instanceof BusinessException) {
		throw new BusinessException(e.getMessage());
	    } else {
		throw new ApplicationException(e.getMessage());
	    }
	}
	return returnData;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.connection.domain.logic.TechnicalArchitectureLookupFacade#getResourceTypeObjsName(java.lang.String)
     */
    public List getResourceTypeObjsName(String resourceTypeName) {
	List returnData = new ArrayList();
	try {
	    List filters = new ArrayList();
	    PerformerFilter filter = new PerformerFilter();
	    filter.setAttribute("resourceTypeName");
	    filter.setFunction(PerformerTypes.EQUAL);
	    filter.setValue(resourceTypeName);
	    filters.add(filter);

	    filter = new PerformerFilter();
	    filter.setAttribute("status");
	    filter.setFunction(PerformerTypes.EQUAL);
	    filter.setValue("Active");
	    filters.add(filter);

	    List data = performerDao.findEntities(new ResourceType(), 0,
		    filters);

	    if (data != null && data.size() > 0) {
		returnData.addAll(data);
	    }
	} catch (Exception e) {
	    log.error(e);
	    if (e instanceof BusinessException) {
		throw new BusinessException(e.getMessage());
	    } else {
		throw new ApplicationException(e.getMessage());
	    }
	}
	return returnData;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.connection.domain.logic.TechnicalArchitectureLookupFacade#loadIPXref(java.lang.Long)
     */
    public ConnectionIPXref loadIPXref(Long id) {
	ConnectionIPXref connectionIPXref = null;
	try {
	    connectionIPXref = (ConnectionIPXref) performerDao.get(id, 0,
		    new ConnectionIPXref());
	} catch (Exception e) {
	    log.error(e);
	    if (e instanceof BusinessException) {
		throw new BusinessException(e.getMessage());
	    } else {
		throw new ApplicationException(e.getMessage());
	    }
	}
	return connectionIPXref;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.connection.domain.logic.TechnicalArchitectureLookupFacade#loadIPXrefForIpId(java.lang.Long, java.lang.Long)
     */
    public ConnectionIPXref loadIPXrefForIpId(Long id, Long connectionRequestId) {
	ConnectionIPXref connectionIPXref = null;
	try {
	    List filters = new ArrayList();
	    PerformerFilter filter = new PerformerFilter();
	    filter.setAttribute("connectionIPMaster");
	    filter.setFunction(PerformerTypes.EQUAL);
	    filter.setValue(id);
	    filters.add(filter);
	    filter = new PerformerFilter();
	    filter.setAttribute("CONNECTION_REQUEST_ID");
	    filter.setFunction(PerformerTypes.EQUAL);
	    filter.setValue(connectionRequestId);
	    filters.add(filter);
	    List childRef = new ArrayList();
	    childRef.add("connectionVIPXrefList");
	    List ipXrefObjs = performerDao.findEntities(new ConnectionIPXref(),
		    0, filters, childRef);
	    if (ipXrefObjs != null && ipXrefObjs.size() > 0) {
		connectionIPXref = (ConnectionIPXref) ipXrefObjs.get(0);
	    }
	} catch (Exception e) {
	    log.error(e);
	    if (e instanceof BusinessException) {
		throw new BusinessException(e.getMessage());
	    } else {
		throw new ApplicationException(e.getMessage());
	    }
	}
	return connectionIPXref;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.connection.domain.logic.TechnicalArchitectureLookupFacade#getConnectionFWPolicyLookUP(java.util.Map)
     */
    public ConnectionFirewallPolicyLookUp getConnectionFWPolicyLookUP(
	    Map filterMap) {
	ConnectionFirewallPolicyLookUp fwPolicyLookUp = null;
	try {
	    fwPolicyLookUp = new ConnectionFirewallPolicyLookUp();
	    //Load objects of connectionFWPolicyMaster
	    fwPolicyLookUp.next("connectionFWPolicyMasterList", filterMap, 10,
		    true, true);
	} catch (Exception e) {
	    log.error(e);
	    if (e instanceof BusinessException) {
		throw new BusinessException(e.getMessage());
	    } else {
		throw new ApplicationException(e.getMessage());
	    }
	}
	return fwPolicyLookUp;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.connection.domain.logic.TechnicalArchitectureLookupFacade#getCheckPointFirewalls(java.lang.Long)
     */
    public List getCheckPointFirewalls(Long id) {
	List returnData = new ArrayList();
	try {


	    Map filterMap = new HashMap();
	    List filterList = new ArrayList();
	    PerformerFilter filter= new PerformerFilter();
	    filter.setAttribute("FIREWALL_POLICY_ID");
	    filter.setFunction(PerformerTypes.EQUAL);
	    filter.setValue(id);
	    filterList.add(filter);
	    filter = new PerformerFilter();
	    filter.setAttribute("deleteFlag");
	    filter.setFunction(PerformerTypes.EQUAL);
	    filter.setValue("N");
	    filterList.add(filter);
	    List data = performerDao.findEntities(
		    new ConnectionCPFirewall(), 0, filterList);

	    if (data != null && data.size() > 0) {
		returnData.addAll(data);
	    }
	} catch (Exception e) {
	    log.error(e);
	    if (e instanceof BusinessException) {
		throw new BusinessException(e.getMessage());
	    } else {
		throw new ApplicationException(e.getMessage());
	    }
	}
	return returnData;
    }
}
