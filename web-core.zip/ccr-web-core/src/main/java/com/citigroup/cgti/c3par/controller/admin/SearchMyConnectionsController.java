package com.citigroup.cgti.c3par.controller.admin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.kie.api.task.model.TaskSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.ModelAndView;

import com.citigroup.cgti.c3par.bpm.ejb.domain.LookupDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.GeneralSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.Process;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.SearchMyConnectionsProcess;
import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.citigroup.cgti.ccr.workflow.CCRWorkflowConstants;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;



@Controller
public class SearchMyConnectionsController {

	private static Logger log = Logger
			.getLogger(SearchMyConnectionsController.class);
	
	/** The ctx. */
	private WebApplicationContext ctx = null;
	
	@Autowired
	Util util_helper;
	
	@Autowired
	ManageTIProcessImpl manageTIProcessImpl;
		
	@Autowired
	WsPapiFacade papiFacade;
	
	@Autowired
	WorkflowCallServiceHelper wrkflowCallServiceHelper;
	
	@Autowired
	WorkflowUtil workflowUtil;

	@RequestMapping(value = "/myConnectionInitialize.act", method = RequestMethod.GET)
	public ModelAndView initialize(
			ModelMap model,
			@ModelAttribute("searchMyConnectionsForm") SearchMyConnectionsProcess searchMyConnectionsForm) {
		log.info("initialize in SearchMyConnectionsController");
		return new ModelAndView("c3par.search.myconnections",
				"searchMyConnectionsForm", searchMyConnectionsForm);

	}
	
	@RequestMapping(value = "/myConnectionBulkACV.act", method = RequestMethod.POST)
	public String bulkAcv(
			ModelMap model,HttpServletRequest request) {
		log.info("bulkAcv in SearchMyConnectionsController");
		
		SubmitActivityProcess submitActivityProcess = new SubmitActivityProcess();
		
		String requestIds = request.getParameter("arg_ti_req_id");
		String sow_number = request.getParameter("a_sow_number");
		String comments_data = request.getParameter("comments_data");
		String requesterSOEId = request.getParameter("arg_requesterSOEId");
		String connxId = request.getParameter("connxId");
		String role_actual = request.getParameter("role_actual");
		String activity_trail_id = request.getParameter("activity_trail_id");
		String activity_name = request.getParameter("activityId");
		String str[] = requestIds.split("##");
		String split_role [] = role_actual.split("##");
		String split_trail_id [] = activity_trail_id.split("##");
		String split_activity_id [] = activity_name.split("##");
		String split_procId[] = connxId.split("##");
		String userId  = request.getHeader("SM_USER");
		log.info("requesterSOEId--"+requesterSOEId);
		int counter = 0;
		String cnt = "";
		String taskId = "";
		String activity_status = "";
		TIRequest tiRequest = null;
		Map<Long,String> updateSOWupdateMap=new HashMap<Long,String>();
		for(String s : str)
		{
			long tiProcessId = Long.parseLong(split_procId[counter]);
			if(updateSOWupdateMap.get(tiProcessId)!=null){
				counter = counter+1;
				continue;
			}
			submitActivityProcess.verifySOWUpdate(Long.parseLong(s), "Y", sow_number);
			long tiAuditTrialId = Long.parseLong(split_trail_id[counter]);
			Map<String,String> taskIdDetails = manageTIProcessImpl.getTaskIdForACV(tiProcessId, tiAuditTrialId,userId);
			if(taskIdDetails!=null)
			{
				taskId = (String)taskIdDetails.get("taskId");
				activity_status = (String)taskIdDetails.get("activity_status");
			}
			log.info("Before calling updateBPMInstanceId : taskId -->"+taskId);
			manageTIProcessImpl.updateBPMInstanceId(Long.parseLong(str[counter]), taskId);
			TiRequestComments tiReqComments = new TiRequestComments();
			tiRequest = new TIRequest();
			tiRequest.setId((Long.parseLong(s)));
			tiReqComments.setTiRequest(tiRequest);
			tiReqComments.setComments(comments_data);
			tiReqComments.setRoleName(split_role[counter]);
			tiReqComments.setApproverSoeID(requesterSOEId);
			submitActivityProcess.addComments(tiReqComments, "A", "save");
			util_helper.updateRoleId(Long.valueOf(split_trail_id[counter]), split_role[counter]);
			counter = counter+1;
			updateSOWupdateMap.put(new Long(tiProcessId), "N");
		}
		String instanceIds = request.getParameter("instanceId");
		String split_instanceIds[] = instanceIds.split("##");
		List<Map> li  = new ArrayList<Map>();		
		counter = 0;
		taskId = "";
		activity_status = "";
		for(String s : split_procId)
		{	
			long tiProcessId = Long.parseLong(s);
			String isProcessed=updateSOWupdateMap.get(tiProcessId);
			if(isProcessed!=null && "Y".equalsIgnoreCase(isProcessed)){
				counter = counter+1;
				continue;
			}
			Map<String,String> mp  = new HashMap<String,String>();
			mp.put("process_id", s);
			mp.put("bpm_inst_id",split_instanceIds[counter]);
			mp.put("role_name",split_role[counter]);
			mp.put("activity_name",split_activity_id[counter]);
			//cnt = "status"+counter;
			cnt = "status"+s;
			mp.put(cnt,"success");
			li.add(mp);
			String processId = split_procId[counter];
			try {
				//log.info("bpm_inst_id-->"+split_instanceIds[counter]);
				log.info("userId-->"+userId);
				log.info("Before Parsing tiProcessId-->"+split_procId[counter]);
				log.info("Before Parsing tiAuditTrialId-->"+split_trail_id[counter]);
				log.info("Before Parsing tiRequestId-->"+Long.parseLong(str[counter]));
				long tiAuditTrialId = Long.parseLong(split_trail_id[counter]);				
				Map<String,String> taskIdDetails = manageTIProcessImpl.getTaskIdForACV(tiProcessId, tiAuditTrialId,userId);
				if(taskIdDetails!=null)
				{
					taskId = (String)taskIdDetails.get("taskId");
					activity_status = (String)taskIdDetails.get("activity_status");
				}
				log.info("Before calling unlock Activity for activity_status -->"+activity_status);				
				if(activity_status!=null && !activity_status.equals("") && activity_status.equals("RESERVED"))
				{
					log.info("Before calling unlock Activity for taskId -->"+taskId);
					Map<String, Object> submitFlowParams = workflowUtil.buildWorkflowParamsForUnLock(userId, null, Long.parseLong(taskId));
					submitFlowParams.put(CCRWorkflowConstants.IS_GRAB_ACTIVITY,new Boolean(true));
					wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, submitFlowParams, WorkflowEvent.UNLOCK, null);
				}				
				log.info("Before calling lock Activity");
				Map<String, Object> userFlowParams=new HashMap<String,Object>();
				TaskSummary taskSummary = workflowUtil.getTaskSummary(Long.parseLong(taskId));
				userFlowParams.put("soeid", userId);
				userFlowParams.put(CCRWorkflowConstants.TASK_SUMMARY,taskSummary );
				log.info(" process instance id ==>"+taskSummary.getProcessInstanceId());
				wrkflowCallServiceHelper.callWorkflowService(FlowType.ACV, userFlowParams, WorkflowEvent.LOCK, Long.parseLong(str[counter]));
							
				log.info("Before calling completeACVActivity");
				papiFacade.completeACVActivity(userId, taskId, "COMPLETED",tiAuditTrialId,Long.parseLong(str[counter]));
				log.info("After Making JBPM Call");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.debug("Exception Occured in bulk ACV for process Id :"+processId+" : is :"+e);
				mp.put(cnt,"failed");
				submitActivityProcess.verifySOWUpdate(Long.parseLong(str[counter]), "N", sow_number);
			}finally{
				updateSOWupdateMap.put(new Long(tiProcessId), "Y");
				counter = counter+1;
			}
		};
		
		request.setAttribute("bulk_acv_data", li);		
		return "pages/jsp/search/bulkACV";
	}
	
	/**
	 * Gets the context.
	 *
	 * @param servletContext the servlet context
	 * @return the context
	 */
	protected WebApplicationContext getContext(ServletContext servletContext) {
		log.debug("getContext(): Start");
		if (ctx == null) {
			log.debug("Getting Spring  Context ....");
			ctx = WebApplicationContextUtils.getWebApplicationContext(servletContext);
			log.debug("Getting Spring  Context ....");
		}
		log.debug("getContext(): End");
		return ctx;
	}
	
	/**
	 * Gets the bean.
	 *
	 * @param request the request
	 * @param strManager the str manager
	 * @return the bean
	 */
	protected Object getBean(HttpServletRequest request, String strManager) {
		log.info("getService(): Start");
		Object mgr = ((getContext(request.getSession().getServletContext())).getBean(strManager));
		log.info("getService(): End");
		return mgr;
	}
	
	@RequestMapping(value = "/myConnectionMyOwnAction.act", method = RequestMethod.POST)
	public ModelAndView myOwn(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("searchMyConnectionsForm") SearchMyConnectionsProcess searchMyConnectionsForm) {
		try{
		log.info("myOwn in SearchMyConnectionsController");
		Map<String, String> rolesList= loadTaskContactRoleList(searchMyConnectionsForm);
		Map<String, String> taskTypeList = loadTaskContactActivityList(searchMyConnectionsForm);
		Map<String, String> regionList = loadTaskContactRegionList(searchMyConnectionsForm);
		Map<String, String> sectorList = loadSectorListForContact(searchMyConnectionsForm);
		

		GeneralSearchAttributes generalSearchAttributes = new GeneralSearchAttributes();
		List<Process>lst = new ArrayList<Process>();
		if(searchMyConnectionsForm.getGeneralSearchAttributes() != null){
			generalSearchAttributes = searchMyConnectionsForm.getGeneralSearchAttributes();
			log.info("requester" +searchMyConnectionsForm.getGeneralSearchAttributes().getRequesterSOEId());
		}
					
		generalSearchAttributes.setActualRequestor(generalSearchAttributes.getRequesterSOEId());
		searchMyConnectionsForm.setGeneralSearchAttributes(generalSearchAttributes);
		
		searchMyConnectionsForm.setOffset(0);
		searchMyConnectionsForm.setPageNo(1);
		searchMyConnectionsForm.setLimit(10);
		
		lst = searchMyConnectionsForm.getMyConnections();
		searchMyConnectionsForm.setProcessList(lst);
		
		int rowCount = searchMyConnectionsForm.getRowCount();
		
		//To calculate no of pages
		int totalPages = 0;
		int limit = 10;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		
		searchMyConnectionsForm.setTotalPages(totalPages);
		
		model.addAttribute("processList", lst);
		model.addAttribute("taskTypeList", taskTypeList);
		model.addAttribute("rolesList", rolesList);
		model.addAttribute("regionList", regionList);
		model.addAttribute("sectorList", sectorList);
		}
		catch(Exception e){
			log.error(e,e);
		}
		return new ModelAndView("c3par.search.myconnections",
				"searchMyConnectionsForm", searchMyConnectionsForm);

	}
	
	
	@RequestMapping(value = "/myConnectionExportAction.act", method = RequestMethod.POST)
		public String exportContact(
				ModelMap model,
				HttpServletRequest request,
				@ModelAttribute("searchMyConnectionsForm") SearchMyConnectionsProcess searchMyConnectionsForm) {
		
			log.info("initialize in SearchMyConnectionsController");
			GeneralSearchAttributes generalSearchAttributes = new GeneralSearchAttributes();
			List<Process>lst = new ArrayList<Process>();
			if(searchMyConnectionsForm.getGeneralSearchAttributes() != null){
				generalSearchAttributes = searchMyConnectionsForm.getGeneralSearchAttributes();
				log.info("requester" +searchMyConnectionsForm.getGeneralSearchAttributes().getRequesterSOEId());
			}
						
			generalSearchAttributes.setActualRequestor(generalSearchAttributes.getRequesterSOEId());
			searchMyConnectionsForm.setGeneralSearchAttributes(generalSearchAttributes);
			searchMyConnectionsForm.setExport(true);
			
			List<Process> exportList = new ArrayList<Process>();
			try {
				exportList = searchMyConnectionsForm.getMyConnections();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			log.info("Check size"+ exportList.size());
			model.addAttribute("exportProcessList", exportList);
			return "pages/jsp/search/exportContactTasks";

		}
	
	@RequestMapping(value = "/myConnectionSearchAction.act", method = RequestMethod.POST)
	public ModelAndView search(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("searchMyConnectionsForm") SearchMyConnectionsProcess searchMyConnectionsForm){
	
			
		try{
			Map<String, String> rolesList= loadTaskContactRoleList(searchMyConnectionsForm);
			Map<String, String> taskTypeList = loadTaskContactActivityList(searchMyConnectionsForm);
			Map<String, String> regionList = loadTaskContactRegionList(searchMyConnectionsForm);
			Map<String, String> sectorList = loadSectorListForContact(searchMyConnectionsForm);
			model.addAttribute("taskTypeList", taskTypeList);
			model.addAttribute("rolesList", rolesList);
			model.addAttribute("regionList", regionList);
			model.addAttribute("sectorList", sectorList);
			
			
			GeneralSearchAttributes generalSearchAttributes = new GeneralSearchAttributes();
			List<Process>lst = new ArrayList<Process>();
			if(searchMyConnectionsForm.getGeneralSearchAttributes() != null){
				generalSearchAttributes = searchMyConnectionsForm.getGeneralSearchAttributes();
				log.info("requester" +searchMyConnectionsForm.getGeneralSearchAttributes().getRequesterSOEId());
			}
						
			generalSearchAttributes.setActualRequestor(generalSearchAttributes.getRequesterSOEId());
			searchMyConnectionsForm.setGeneralSearchAttributes(generalSearchAttributes);
			
			searchMyConnectionsForm.setOffset(0);
			searchMyConnectionsForm.setPageNo(1);
			searchMyConnectionsForm.setLimit(10);
			
			lst = searchMyConnectionsForm.getMyConnections();
			searchMyConnectionsForm.setProcessList(lst);
			
			int rowCount = searchMyConnectionsForm.getRowCount();
			
			//To calculate no of pages
			int totalPages = 0;
			int limit = 10;
			
			if (rowCount%limit > 0) {
				totalPages = Math.round((rowCount/limit)+0.5f);
			} else {
				totalPages = Math.round(rowCount/limit);
			}
			
			searchMyConnectionsForm.setTotalPages(totalPages);
			
			model.addAttribute("processList", lst);
			
			log.info("SearchAction.loadMyContactTasks method ends ");
			
		}catch (Exception e){
			log.error(e,e);
		}
		return new ModelAndView("c3par.search.myconnections", "searchMyConnectionsForm", searchMyConnectionsForm);
}
	
	
	@RequestMapping(value = "/myConnectionPaginateAction.act", method = RequestMethod.POST)
	public ModelAndView myConnectionPaginateAction(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("searchMyConnectionsForm") SearchMyConnectionsProcess searchMyConnectionsForm){
	
		String type = (String)request.getParameter("type");
		
		int curOffSet = searchMyConnectionsForm.getOffset();
		int limit = searchMyConnectionsForm.getLimit();
		int pageNo = searchMyConnectionsForm.getPageNo();
			
		try{
			Map<String, String> rolesList= loadTaskContactRoleList(searchMyConnectionsForm);
			Map<String, String> taskTypeList = loadTaskContactActivityList(searchMyConnectionsForm);
			Map<String, String> regionList = loadTaskContactRegionList(searchMyConnectionsForm);
			Map<String, String> sectorList = loadSectorListForContact(searchMyConnectionsForm);
			model.addAttribute("taskTypeList", taskTypeList);
			model.addAttribute("rolesList", rolesList);
			model.addAttribute("regionList", regionList);
			model.addAttribute("sectorList", sectorList);
			
			
			GeneralSearchAttributes generalSearchAttributes = new GeneralSearchAttributes();
			List<Process>lst = new ArrayList<Process>();
				
			if(searchMyConnectionsForm.getGeneralSearchAttributes() != null){
				generalSearchAttributes = searchMyConnectionsForm.getGeneralSearchAttributes();
				log.info("requester" +searchMyConnectionsForm.getGeneralSearchAttributes().getRequesterSOEId());
			}
						
			generalSearchAttributes.setActualRequestor(generalSearchAttributes.getRequesterSOEId());
			searchMyConnectionsForm.setGeneralSearchAttributes(generalSearchAttributes);
			
			searchMyConnectionsForm.setLimit(limit);
			
			if ("N".equalsIgnoreCase(type)) {
				searchMyConnectionsForm.setOffset(curOffSet+searchMyConnectionsForm.getLimit());
				searchMyConnectionsForm.setPageNo(pageNo+1);
			} else if ("P".equalsIgnoreCase(type)) {
				searchMyConnectionsForm.setOffset(curOffSet-searchMyConnectionsForm.getLimit());
				searchMyConnectionsForm.setPageNo(pageNo-1);
			} else if ("X".equalsIgnoreCase(type)) {
				searchMyConnectionsForm.setOffset(limit * (pageNo-1));
				searchMyConnectionsForm.setPageNo(pageNo);
			} else if ("L".equalsIgnoreCase(type)) {
				searchMyConnectionsForm.setOffset(0);
				searchMyConnectionsForm.setPageNo(1);
			} else {
				searchMyConnectionsForm.setOffset(0);
				searchMyConnectionsForm.setPageNo(1);
			}
			
			lst = searchMyConnectionsForm.getMyConnections();
			searchMyConnectionsForm.setProcessList(lst);
			
			int rowCount = searchMyConnectionsForm.getRowCount();
			
			//To calculate no of pages
			int totalPages = 0;
			
			if (rowCount%limit > 0) {
				totalPages = Math.round((rowCount/limit)+0.5f);
			} else {
				totalPages = Math.round(rowCount/limit);
			}
			
			searchMyConnectionsForm.setTotalPages(totalPages);
			
			model.addAttribute("processList", lst);
			
			log.info("SearchAction.loadMyContactTasks method ends ");
			
		}catch (Exception e){
			log.error(e,e);
		}
		return new ModelAndView("c3par.search.myconnections", "searchMyConnectionsForm", searchMyConnectionsForm);
}
	

/*public List<Process> fetchResult(SearchMyConnectionsProcess searchMyConnectionsForm, boolean isExport){
	
	GeneralSearchAttributes generalSearchAttributes = new GeneralSearchAttributes();
	List<Process>lst = new ArrayList<Process>();
	try {
		if(searchMyConnectionsForm == null){
			log.info("searchform is null");
			searchMyConnectionsForm = new SearchMyConnectionsProcess();
		}else{
			if(searchMyConnectionsForm.getGeneralSearchAttributes() != null){
				generalSearchAttributes = searchMyConnectionsForm.getGeneralSearchAttributes();
				log.info("requester" +searchMyConnectionsForm.getGeneralSearchAttributes().getRequesterSOEId());
			}
		}
		if(generalSearchAttributes.getRequesterSOEId()== null || generalSearchAttributes.getRequesterSOEId().isEmpty()){
				*//**
				 * Exception here
				 **//*
			
		}			
		generalSearchAttributes.setActualRequestor(generalSearchAttributes.getRequesterSOEId());
		searchMyConnectionsForm.setGeneralSearchAttributes(generalSearchAttributes);
		searchMyConnectionsForm.setSearchType("MY_TASK_CONTACTS");
		
	if (searchMyConnectionsForm.getPageNo() == null || searchMyConnectionsForm.getPageNo() == 0) {
		log.info("Page size is null");
		searchMyConnectionsForm.setPageNo(1);
	}
	Integer totalPages = searchMyConnectionsForm.getSearchRecordCount();
	int recCnt = totalPages.intValue();
	searchMyConnectionsForm.setPageSize(generalSearchAttributes.getSize());
	if (isExport) {
		// get all results for export
		searchMyConnectionsForm.setPageSize(totalPages);
	}
	int size = generalSearchAttributes.getSize();
	log.info("SearchAction.loadMyContactstasks.totalPages:"+totalPages);
	if (totalPages.intValue() == 0) {
		totalPages = 0;
	} else if (totalPages.intValue() / size == 0) {
		totalPages = 1;
	} else if (totalPages.intValue() % size > 0) {
		totalPages = totalPages.intValue() / size + 1;
	} else if (totalPages.intValue() % size == 0) {
		totalPages = totalPages.intValue() / size;
	}
	log.info("SearchAction.loadMyContactsTasks method:totalpages:"
			+ totalPages);
	searchMyConnectionsForm.setTotalPages(totalPages); 
	
	
	lst = searchMyConnectionsForm.loadProcessList(recCnt);
	
	}
	catch (Exception e){
		log.error(e,e);
	}
	return lst;
}*/


	public Map<String, String> loadTaskContactRoleList(SearchMyConnectionsProcess searchMyConnectionsForm) throws Exception {
		log.info("loadTaskContactRoleList");
		
		ArrayList<LookupDTO> rolesList = (ArrayList<LookupDTO>) searchMyConnectionsForm.getRolesList();
		Map<String, String> rolesMap = new HashMap();
		for(LookupDTO lookUpDTO: rolesList){
			rolesMap.put(String.valueOf(lookUpDTO.getValue()),lookUpDTO.getName());
		}
		log.info("roleList" + rolesList.toString());
		return rolesMap;
	}

	public Map<String, String> loadTaskContactActivityList(SearchMyConnectionsProcess searchMyConnectionsForm) throws Exception {
		log.info("loadTaskContactActivityList");

		ArrayList<LookupDTO> activityList = (ArrayList<LookupDTO>) searchMyConnectionsForm.getTaskTypeList();
		Map<String, String> activityMap = new HashMap();
		for(LookupDTO lookUpDTO: activityList){
			activityMap.put(String.valueOf(lookUpDTO.getValue()),lookUpDTO.getName());
		}
		log.info("activitiesList" + activityList.toString());
		return activityMap;
	}
	
	public Map<String, String> loadTaskContactRegionList(SearchMyConnectionsProcess searchMyConnectionsForm) throws Exception {
		log.info("loadTaskContactRegionList");

		ArrayList<LookupDTO> regionList = (ArrayList<LookupDTO>) searchMyConnectionsForm.getRegionList();
		Map<String, String> regionMap = new HashMap();
		for(LookupDTO lookUpDTO: regionList){
			regionMap.put(String.valueOf(lookUpDTO.getValue()),lookUpDTO.getName());
		}
		log.info("regionList" + regionList.toString());
		return regionMap;
	}
	
	public Map<String, String> loadSectorListForContact(SearchMyConnectionsProcess searchMyConnectionsForm) throws Exception {
		    	log.info("SEctor List...");
		    	
		    	ArrayList<LookupDTO> firewallGroupList = (ArrayList<LookupDTO>) searchMyConnectionsForm.getSectorList();
		    	Map<String, String> firewallGroupMap = new HashMap();
				for(LookupDTO lookUpDTO: firewallGroupList){
					firewallGroupMap.put(String.valueOf(lookUpDTO.getValue()),lookUpDTO.getName());
				}
			    log.info("sectorList" +firewallGroupList.toString());
				return firewallGroupMap;
		    }
}