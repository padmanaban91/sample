package com.citigroup.cgti.c3par.connection.domain.logic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.C3parTxSession;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseDTO;
import com.citigroup.cgti.c3par.appsense.domain.ConnectionOstiaGroup;
import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleUtil;
import com.citigroup.cgti.c3par.connection.domain.ConnectionFWPolicyXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionFWRuleXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionFirewallPolicyLookUp;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIPPairMaster;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIPPairXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIPXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIpsecTunnelMaster;
import com.citigroup.cgti.c3par.connection.domain.ConnectionPortXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionProcess;
import com.citigroup.cgti.c3par.connection.domain.ConnectionRiskPortOstia;
import com.citigroup.cgti.c3par.connection.domain.ConnectionVIPMaster;
import com.citigroup.cgti.c3par.connection.domain.FirewallRuleRequest;
import com.citigroup.cgti.c3par.connection.domain.FirewallStageData;
import com.citigroup.cgti.c3par.connection.domain.IPPairRequest;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.C3PARMailMessage;
import com.citigroup.cgti.c3par.domain.logic.TIProcessService;
import com.citigroup.cgti.c3par.performer.dao.PerformerDAO;
import com.citigroup.cgti.c3par.performer.dao.PerformerDO;
import com.citigroup.cgti.c3par.performer.dao.PerformerExpression;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.dao.PerformerQueryBuilder;
import com.citigroup.cgti.c3par.performer.dao.PerformerUtil;
import com.citigroup.cgti.c3par.performer.util.PerformerException;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;
import com.citigroup.cgti.c3par.util.C3parProperties;


/**
 * The Class TechnialArchitectureImpl.
 */
@SuppressWarnings( { "unchecked", "unused" })
public class TechnialArchitectureImpl extends TIProcessService {

    /** The default page size. */
    final int defaultPageSize = 5;

    /** The log. */
    protected Logger log = Logger.getLogger(this.getClass().getName());

    /** The performer dao. */
    protected PerformerDAO performerDao;

    /** The c3par tx session. */
    private C3parTxSession c3parTxSession;


    /**
     * Sets the c3par tx session.
     *
     * @param txSession the new c3par tx session
     */
    public void setC3parTxSession(C3parTxSession txSession) {
	c3parTxSession = txSession;
    }


    /**
     * Send oa sch email.
     *
     * @param connID the conn id
     */
    public void sendOASchEmail(Long connID) {

	log.debug("TechnialArchitectureImpl.sendOASchEmail() START");

	Connection con = null;
	PreparedStatement stmt = null;
	C3parSession c3parSession=new C3parSession();
	ResultSet rs = null;

	String connName = "";

	Set  emailAddr =new HashSet();

	String projectCoordinator = "";


	StringBuilder sbQry = new StringBuilder("SELECT DISTINCT CON_REQ.ID,CON_REQ.CONNECTION_NAME,CON_FW_MGMT_REGION.OPERATION_ANALYST_EMAIL,CON_REQ.REQUESTER_ID ");
	sbQry.append(" FROM   CON_REQ, CON_FW_MGMT_REGION, CON_FW_POLICY_XREF, CON_FW_POLICY_MASTER ");
	sbQry.append(" WHERE ( ");
	sbQry.append(" (CON_FW_MGMT_REGION.ID =CON_FW_POLICY_MASTER.FW_MGMT_REGION_ID) ");
	sbQry.append(" AND (CON_FW_POLICY_XREF.FIREWALL_POLICY_ID =CON_FW_POLICY_MASTER.ID) ");
	sbQry.append(" AND (CON_FW_POLICY_XREF.CONNECTION_REQUEST_ID =" + connID +")");
	sbQry.append(" AND (CON_FW_POLICY_XREF.CONNECTION_REQUEST_ID = CON_REQ.ID)" );
	sbQry.append(" )");
	log.info("TechnialArchitectureImpl.sendOASchEmail()::::: sbQry::::"+sbQry.toString());
	try {
	    con = c3parSession.getConnection();
	    stmt = con.prepareStatement(sbQry.toString());
	    StringBuilder toAddress = new StringBuilder();
	    rs = stmt.executeQuery();
	    if (rs != null) {
		while (rs.next()) {
		    connName = rs.getString(2);
		    if(rs.getString(3)!=null){
				emailAddr.add(rs.getString(3));
				toAddress.append(rs.getString(3)+";");
		    }
		    projectCoordinator= rs.getString(4);
		}
	    }
	    if( emailAddr!=null && emailAddr.size()>0){
		String []emailAddress=(String [])emailAddr.toArray(new String[emailAddr.size()]);

		log.info("TechnialArchitectureImpl.sendOASchEmail() emailAddr::::"+emailAddr);
		SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
		StringBuilder msgTxt = new StringBuilder();
		String mailSubject = "Scheduled Implementation: Connection Request: "+connID +" - "+ connName;
		msg.setSubject(mailSubject);
		msg.setSentDate(new Date());
		msg.setTo(emailAddress);
		msgTxt.append("Operational Analyst Contact,");
		msgTxt.append("\n\n");
		msgTxt.append("A new connection request has been created in C3PAR. ");
		msgTxt.append("\n\n");
		msgTxt.append("Please review and approve or reject the connection Request. ");
		msgTxt.append("If approved, please schedule the implementation. ");
		msgTxt.append("\n\n");
		msgTxt.append("Connection Request Name: " + connName + "\n");
		msgTxt.append("Connection ID: " + connID + "\n");
		msgTxt.append("Project Coordinator: " + projectCoordinator);
		msgTxt.append("\n");
		msgTxt.append("Action: Approve or Reject the Connection Request and schedule the implementation. \n\n");
		msgTxt.append("Please do not respond to this email. \n\n");
		msgTxt.append("C3PAR System.");
		msg.setText(msgTxt.toString());


		if (msg != null) {
		    if (msg.getTo() != null)
			log.debug("MESSAGE TO " + msg.getTo().toString());
		    log.debug("MESSAGE SUBJECT " + msg.getSubject());
		    log.debug("MESSAGE TXT " + msg.getText());
		}

		log.debug("sending email to appowners for conn id" + connID);
		this.mailSender.send(msg);
		
		//insert mail information into TI_MAIL_AUDIT for Audit
		C3PARMailMessage mailMsg = new C3PARMailMessage();
		mailMsg.setTiRequestID(new Long(0L));
		mailMsg.setTemplateID("");
		mailMsg.setToAddresses(toAddress.toString());
		mailMsg.setCcAddresses("");
		mailMsg.setMsgSubject(mailSubject);
		mailMsg.setMsgContent(msgTxt.toString());				
		mailActivityAudit(mailMsg);
	    }
	} catch (MailException ex) {
	    log.error(ex);
	} catch (Exception ex) {
	    log.error(ex);
	} finally {
	    try {
		if (rs != null)
		    rs.close();
		if (stmt != null)
		    stmt.close();
		if (con != null)
		    con.close();

	    } catch (Exception e) {
		log.error(e);
	    }
	}

	log.debug("TechnialArchitectureImpl.sendOASchEmail() END");
    }

    /**
     * Upload firewall stage data.
     *
     * @param resultList the result list
     */
    public void uploadFirewallStageData(List resultList){
	try {
	    List list = new ArrayList();
	    List dataList = null;
	    FirewallStageData fwData = null;
	    if (resultList != null) {
		for (int i = 0; i < resultList.size(); i++) {
		    fwData = new FirewallStageData();
		    dataList = new ArrayList();
		    dataList = (ArrayList) resultList.get(i);

		    fwData.setFwName((String)dataList.get(0));
		    fwData.setFwType((String)dataList.get(1));
		    fwData.setFwPolicy((String)dataList.get(2));
		    fwData.setMgmtRegion((String)dataList.get(3));
		    //performerDao.insert(fwData);
		    list.add(fwData);
		}
		performerDao.insert(list);

	    }
	} catch (PerformerException e) {
	    throw new BusinessException("Problem while uploading the data");
	}

    }

    /**
     * Sets the performer dao.
     *
     * @param performerDao The performerDao to set.
     */
    public void setPerformerDao(PerformerDAO performerDao) {
	this.performerDao = performerDao;
    }

    /**
     * Delete ip master.
     *
     * @param conProcess the con process
     * @param performerFilterList the performer filter list
     * @return the connection process
     */
    public ConnectionProcess deleteIPMaster(ConnectionProcess conProcess,
	    Map performerFilterList) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Update ip master.
     *
     * @param conProcess the con process
     * @param conIPXref the con ip xref
     * @return the connection process
     */
    public ConnectionProcess updateIPMaster(ConnectionProcess conProcess,
	    ConnectionIPXref conIPXref) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Adds the tunnel.
     *
     * @param conProcess the con process
     * @param conIpsecTunnelMst the con ipsec tunnel mst
     * @return the connection ipsec tunnel master
     */
    public ConnectionIpsecTunnelMaster addTunnel(ConnectionProcess conProcess,
	    ConnectionIpsecTunnelMaster conIpsecTunnelMst) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Creates the ip pair.
     *
     * @param conProcess the con process
     * @param iPPairRequest the i p pair request
     * @param endAFilterMap the end a filter map
     * @param endBFilterMap the end b filter map
     * @return the connection process
     */
    public ConnectionProcess createIPPair(ConnectionProcess conProcess,
	    IPPairRequest iPPairRequest, Map endAFilterMap, Map endBFilterMap) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Delete ip pair.
     *
     * @param conProcess the con process
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    public ConnectionProcess deleteIPPair(ConnectionProcess conProcess,
	    Map performerFilterMap) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Delete tunnel.
     *
     * @param conProcess the con process
     * @param conIpsecTunnelMst the con ipsec tunnel mst
     * @return the connection process
     */
    public ConnectionProcess deleteTunnel(ConnectionProcess conProcess,
	    ConnectionIpsecTunnelMaster conIpsecTunnelMst) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Gets the tunnel.
     *
     * @param name the name
     * @param citiIpsecPeerAddr the citi ipsec peer addr
     * @param remoteIpsecPeerAddr the remote ipsec peer addr
     * @return the tunnel
     */
    public List getTunnel(String name, String citiIpsecPeerAddr,
	    String remoteIpsecPeerAddr) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Update ip xref.
     *
     * @param conProcess the con process
     * @param filterMap the filter map
     * @param application the application
     * @return the connection process
     */
    public ConnectionProcess updateIPXref(ConnectionProcess conProcess,Map filterMap,
	    Application application) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Update ip pair.
     *
     * @param conProcess the con process
     * @param conIPPairMst the con ip pair mst
     * @return the connection process
     */
    public ConnectionProcess updateIPPair(ConnectionProcess conProcess,
	    ConnectionIPPairMaster conIPPairMst) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Update tunnel.
     *
     * @param conProcess the con process
     * @param conIpsecTunnelMst the con ipsec tunnel mst
     * @return the connection process
     */
    public ConnectionProcess updateTunnel(ConnectionProcess conProcess,
	    ConnectionIpsecTunnelMaster conIpsecTunnelMst) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Adds the firewall rule.
     *
     * @param conProcess the con process
     * @param fwRuleRequest the fw rule request
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    public ConnectionProcess addFirewallRule(ConnectionProcess conProcess,
	    FirewallRuleRequest fwRuleRequest, Map performerFilterMap) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Adds the firewall rule.
     *
     * @param conProcess the con process
     * @param firewallRuleList the firewall rule list
     * @param performerFilterList the performer filter list
     * @param conIPPairMst the con ip pair mst
     * @return the connection process
     */
    public ConnectionProcess addFirewallRule(ConnectionProcess conProcess,
	    List firewallRuleList, List performerFilterList,
	    ConnectionIPPairMaster conIPPairMst) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Load template master.
     *
     * @param conProcess the con process
     * @return the list
     */
    public List loadTemplateMaster(ConnectionProcess conProcess) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Assign template.
     *
     * @param conProcess the con process
     * @param connectionIPXref the connection ip xref
     * @return the connection process
     */
    public ConnectionProcess assignTemplate(ConnectionProcess conProcess,ConnectionIPXref connectionIPXref) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Delete firewall rule.
     *
     * @param conProcess the con process
     * @param conFWRuleXrefList the con fw rule xref list
     * @param pairFilterMap the pair filter map
     * @param fwFilterMap the fw filter map
     * @return the connection process
     */
    public  ConnectionProcess deleteFirewallRule(ConnectionProcess conProcess,
	    List conFWRuleXrefList, Map pairFilterMap, Map fwFilterMap) {
	throw new ApplicationException("Method not implemented.");

    }

    /**
     * Delete firewall rule.
     *
     * @param conProcess the con process
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    public ConnectionProcess deleteFirewallRule(ConnectionProcess conProcess,
	    Map performerFilterMap) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Gets the firewall rule.
     *
     * @param connectionIPPairXref the connection ip pair xref
     * @return the firewall rule
     */
    public List getFirewallRule(ConnectionIPPairXref connectionIPPairXref) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Gets the firewall rule.
     *
     * @param connectionFWRuleXref the connection fw rule xref
     * @param conProcess the con process
     * @return the firewall rule
     */
    public ConnectionFWRuleXref getFirewallRule(ConnectionFWRuleXref  connectionFWRuleXref,ConnectionProcess conProcess){
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Update firewall rule.
     *
     * @param conProcess the con process
     * @param connectionFWRuleXref the connection fw rule xref
     */
    public void updateFirewallRule(ConnectionProcess conProcess,ConnectionFWRuleXref connectionFWRuleXref) {
	throw new ApplicationException("Method not implemented.");

    }

    /**
     * Adds the port.
     *
     * @param conProcess the con process
     * @param conPortXref the con port xref
     * @param riskDirectionList the risk direction list
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    public ConnectionProcess addPort(ConnectionProcess conProcess,
	    ConnectionPortXref conPortXref,List riskDirectionList, Map performerFilterMap) {
	throw new ApplicationException("Method not implemented.");

    }

    /**
     * Delete all ports.
     *
     * @param conProcess the con process
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    public ConnectionProcess deleteAllPorts(ConnectionProcess conProcess,
	    Map performerFilterMap) {
	throw new ApplicationException("Method not implemented.");

    }

    /**
     * Delete common ports.
     *
     * @param conProcess the con process
     * @param conPortXrefList the con port xref list
     * @param pairFilterMap the pair filter map
     * @param portFilterMap the port filter map
     * @return the connection process
     */
    public ConnectionProcess deleteCommonPorts(ConnectionProcess conProcess,
	    List conPortXrefList, Map pairFilterMap, Map portFilterMap) {
	throw new ApplicationException("Method not implemented.");

    }

    /**
     * Update port.
     *
     * @param conProcess the con process
     * @param conPortXref the con port xref
     * @param performerFilterMap the performer filter map
     * @return the connection process
     */
    public ConnectionProcess updatePort(ConnectionProcess conProcess,
	    ConnectionPortXref conPortXref, Map performerFilterMap) {
	throw new ApplicationException("Method not implemented.");

    }

    /**
     * Insert template port master.
     *
     * @param connID the conn id
     * @param ip_pair_xref_id the ip_pair_xref_id
     * @throws Exception the exception
     */
    public void insertTemplatePortMaster(Long connID, Long ip_pair_xref_id)throws Exception {
	throw new ApplicationException("Method not implemented.");

    }

    /**
     * Adds the ostia.
     *
     * @param conProcess the con process
     * @param conPortXrefList the con port xref list
     * @param conOstiaGroup the con ostia group
     * @param pairFilterMap the pair filter map
     * @param portFilterList the port filter list
     * @return the connection process
     */
    public ConnectionProcess addOstia(ConnectionProcess conProcess,
	    List conPortXrefList, ConnectionOstiaGroup conOstiaGroup,
	    Map pairFilterMap, Map portFilterList,boolean copyOstiaAnswers) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Adds the ostia answers.
     *
     * @param apsProcess the aps process
     * @param conOstiaGroup the con ostia group
     * @return the appsense process
     */
    public AppsenseDTO addOstiaAnswers(AppsenseDTO apsProcess,
	    ConnectionOstiaGroup conOstiaGroup){
	throw new ApplicationException("Method not implemented.");
    }


    /**
     * Gets the ostia group.
     *
     * @param ostiaGroupId the ostia group id
     * @return the ostia group
     */
    public ConnectionOstiaGroup getOstiaGroup(Long ostiaGroupId) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Update ostia.
     *
     * @param conProcess the con process
     * @param conPortXref the con port xref
     * @param conOstiaGroup the con ostia group
     * @param pairFilterMap the pair filter map
     * @param portFilterList the port filter list
     * @return the connection process
     */
    public ConnectionProcess updateOstia(ConnectionProcess conProcess,
	    ConnectionPortXref conPortXref, ConnectionOstiaGroup conOstiaGroup,
	    Map pairFilterMap, List portFilterList) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Update ostia group.
     *
     * @param conProcess the con process
     * @param conOstiaGroup the con ostia group
     * @return the connection process
     */
    public ConnectionProcess updateOstiaGroup(ConnectionProcess conProcess,
	    ConnectionOstiaGroup conOstiaGroup) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Update ostia group.
     *
     * @param appsenseProcess the appsense process
     * @param conOstiaGroup the con ostia group
     * @return the appsense process
     */
    public AppsenseDTO updateOstiaGroup(AppsenseDTO appsenseProcess,
	    ConnectionOstiaGroup conOstiaGroup) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Adds the connection firewall.
     *
     * @param conProcess the con process
     * @param fwPolicyLookUp the fw policy look up
     * @param connectionFWPolicyXref the connection fw policy xref
     * @param conFWPolicyMstList the con fw policy mst list
     * @return the connection process
     */
    public ConnectionProcess addConnectionFirewall(
	    ConnectionProcess conProcess, ConnectionFirewallPolicyLookUp fwPolicyLookUp, ConnectionFWPolicyXref connectionFWPolicyXref,List conFWPolicyMstList) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Update connection firewall.
     *
     * @param conProcess the con process
     * @param connectionFWPolicyXref the connection fw policy xref
     * @return the connection process
     */
    public ConnectionProcess updateConnectionFirewall(
	    ConnectionProcess conProcess, ConnectionFWPolicyXref connectionFWPolicyXref) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Delete connection firewall.
     *
     * @param conProcess the con process
     * @return the connection process
     */
    public ConnectionProcess deleteConnectionFirewall(
	    ConnectionProcess conProcess) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Adds the virtual ip.
     *
     * @param conProcess the con process
     * @param conVIPMst the con vip mst
     * @return the connection process
     */
    public ConnectionProcess addVirtualIP(ConnectionProcess conProcess,
	    ConnectionVIPMaster conVIPMst) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Update virtual ip.
     *
     * @param conProcess the con process
     * @param conVIPMstList the con vip mst list
     * @return the connection process
     */
    public ConnectionProcess updateVirtualIP(ConnectionProcess conProcess,
	    List conVIPMstList) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Adds the virtual ip.
     *
     * @param conProcess the con process
     * @param conVIPMstList the con vip mst list
     * @return the connection process
     */
    public ConnectionProcess addVirtualIP(ConnectionProcess conProcess,
	    List conVIPMstList) {
	throw new ApplicationException("Method not implemented.");

    }

    /**
     * Delete virtual ip.
     *
     * @param conProcess the con process
     * @param performerFilterList the performer filter list
     * @return the connection process
     */
    public ConnectionProcess deleteVirtualIP(ConnectionProcess conProcess,
	    List performerFilterList) {
	throw new ApplicationException("Method not implemented.");
    }

    /**
     * Adds the application.
     *
     * @param application the application
     * @return the application
     */
    public Application addApplication(Application application) {
	throw new ApplicationException("Method not implemented.");
    }

    /*
     * (non-Javadoc)
     *
     * @see com.citigroup.cgti.c3par.connection.domain.logic.TechnialArchitectureFacade#deleteVirtualIP(com.citigroup.cgti.c3par.connection.domain.ConnectionProcess,
     *      java.util.List)
     */

    /*
     * (non-Javadoc)
     *
     * @see com.citigroup.cgti.c3par.connection.domain.logic.TechnialArchitectureFacade#getConnectionByMaintenanceRequest(java.lang.Long)
     */
    /**
     * Gets the connection by maintenance request.
     *
     * @param maintenanceRequestId the maintenance request id
     * @return the connection by maintenance request
     */
    public ConnectionProcess getConnectionByMaintenanceRequest(
	    Long maintenanceRequestId) {
	log
	.debug("Begin TechnialArchitectureImpl.getConnectionByMaintenanceRequest");
	ConnectionProcess connectionProcess = null;
	try {
	    // PerformerDAO dao = PerformerFactory.getPerformer(new
	    // C3parPerformerConnection());
	    connectionProcess = (ConnectionProcess) performerDao.get(
		    maintenanceRequestId, 0, new ConnectionProcess());
	} catch (PerformerException pe) {
	    log.error(pe, pe);

	}
	log
	.debug("End TechnialArchitectureImpl.getConnectionByMaintenanceRequest");
	return connectionProcess;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.citigroup.cgti.c3par.connection.domain.logic.TechnialArchitectureFacade#getConnectionByOrginalRequest(java.lang.Long)
     */
    /**
     * Gets the connection by orginal request.
     *
     * @param orginalRequestId the orginal request id
     * @return the connection by orginal request
     */
    public ConnectionProcess getConnectionByOrginalRequest(Long orginalRequestId) {
	log
	.debug("Begin TechnialArchitectureImpl.getConnectionByOrginalRequest");
	ConnectionProcess connectionProcess = null;
	try {
	    // PerformerDAO dao = PerformerFactory.getPerformer(new
	    // C3parPerformerConnection());
	    connectionProcess = (ConnectionProcess) performerDao.get(
		    orginalRequestId, defaultPageSize, new ConnectionProcess());
	} catch (PerformerException pe) {
	    log.error(pe, pe);

	}
	log.debug("End TechnialArchitectureImpl.getConnectionByOrginalRequest");
	return connectionProcess;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.citigroup.cgti.c3par.connection.domain.logic.TechnialArchitectureFacade#getConnectionByOrginalRequest(java.lang.Long,
     *      boolean)
     */
    /**
     * Gets the connection by orginal request.
     *
     * @param orginalRequestId the orginal request id
     * @param loadRef the load ref
     * @return the connection by orginal request
     */
    public ConnectionProcess getConnectionByOrginalRequest(
	    Long orginalRequestId, boolean loadRef) {
	log
	.debug("Begin TechnialArchitectureImpl.getConnectionByOrginalRequest");
	ConnectionProcess connectionProcess = null;
	try {
	    // PerformerDAO dao = PerformerFactory.getPerformer(new
	    // C3parPerformerConnection());
	    connectionProcess = (ConnectionProcess) performerDao.get(
		    orginalRequestId, defaultPageSize, new ConnectionProcess(),
		    false);
	} catch (PerformerException pe) {
	    log.error(pe, pe);

	}
	log.debug("End TechnialArchitectureImpl.getConnectionByOrginalRequest");
	return connectionProcess;
    }

    /**
     * Load object with childs.
     *
     * @param parentList the parent list
     * @param childRef the child ref
     * @param loadRef the load ref
     * @param pageSize the page size
     * @param filters the filters
     * @return the list
     */
    public List loadObjectWithChilds(List parentList, List childRef,
	    boolean loadRef, int pageSize, List filters) {
	// List filters = new ArrayList();
	try {
	    parentList = performerDao.loadObjectWithChilds(parentList,
		    childRef, loadRef, pageSize, filters);
	} catch (PerformerException e) {
	    // TODO Auto-generated catch block
	    log.error(e);
	    throw new ApplicationException(e.getMessage());
	}

	return parentList;
    }

    /**
     * List to string.
     *
     * @param data the data
     * @return the string
     */
    public static String listToString(List data) {
	if (data != null && data.size() > 0) {
	    Iterator iter = data.iterator();
	    StringBuilder sb = new StringBuilder();
	    while (iter.hasNext()) {
		sb.append(",'");
		sb.append(((PerformerDO)iter.next()).getId());
		sb.append("'");
	    }
	    return sb.toString().substring(1);
	} else {
	    return null;
	}
    }

    /**
     * Update ip pair xref status.
     *
     * @param isDelete the is delete
     * @param conProcess the con process
     * @param performerFilterMap the performer filter map
     * @throws Exception the exception
     */
    protected void updateIPPairXrefStatus(boolean isDelete, ConnectionProcess conProcess, Map performerFilterMap) throws Exception {
	log.debug("Start updateIPPairXrefStatus");

	List ipPairXrefList = new ArrayList();
	ConnectionIPPairXref conectionIPPairXref = new ConnectionIPPairXref();

	List conIPPairXrefList = conProcess.getConnectionIPPairXrefList();
	if (conIPPairXrefList != null && conIPPairXrefList.size() > 0) {
	    if (conProcess.isSelectAll()) {
		for (int i = 0; i < conIPPairXrefList.size(); i++) {
		    ConnectionIPPairXref tempConIPPairXref = (ConnectionIPPairXref) conIPPairXrefList
		    .get(i);
		    if (!tempConIPPairXref.isSelected()) {
			ipPairXrefList.add(tempConIPPairXref.getId());
		    }
		}
	    } else {
		for (int i = 0; i < conIPPairXrefList.size(); i++) {
		    ConnectionIPPairXref tempConIPPairXref = (ConnectionIPPairXref) conIPPairXrefList
		    .get(i);
		    if (tempConIPPairXref.isSelected()) {
			ipPairXrefList.add(tempConIPPairXref.getId());
		    }
		}
	    }
	}

	PerformerQueryBuilder pqbIPPairXref = new PerformerQueryBuilder();
	pqbIPPairXref.setPerformerName("a", ConnectionIPPairXref.class
		.getName());
	pqbIPPairXref.addWhereCondition("CONNECTION_REQUEST_ID",
		PerformerTypes.EQUAL, conProcess.getId().toString());
	if (conProcess.isSelectAll()) {
	    if (ipPairXrefList != null && ipPairXrefList.size() > 0) {
		pqbIPPairXref.addWhereCondition("ID",
			PerformerTypes.NOT_IN, ipPairXrefList);
	    }
	} else {
	    pqbIPPairXref.addWhereCondition("ID", PerformerTypes.IN,
		    ipPairXrefList);
	}
	if (performerFilterMap != null
		&& performerFilterMap.keySet().size() > 0) {
	    pqbIPPairXref.addWhereCondition(PerformerTypes.ID,
		    PerformerTypes.IN, PerformerUtil
		    .getPerformerQueryBuilder(conectionIPPairXref,
			    performerFilterMap, false));
	}

	List updateQueryList = new ArrayList();

	/*String sql = "update c3par.con_ip_pair_xref set status = 'INCOMPLETE' where id in " +
				"( select a.id from c3par.con_ip_pair_xref a, " +
				"( SELECT   a.id, NVL (d.status, 'Incomplete') status " +
				"FROM c3par.con_ip_pair_xref a, c3par.con_port_xref b, c3par.con_riskport_ostia c, c3par.con_ostia_group d " +
				"WHERE a.connection_request_id = " +
				+ conProcess.getId().longValue() +
				" AND b.ip_pair_xref_id(+) = a.id AND " +
				"c.PORT_ID "+ ((isDelete)?"(+)":"") + "= b.PORT_ID and " +
				"d.id(+) = c.GROUP_ID AND a.id IN (" +
				pqbIPPairXref.toString(true) +
				") GROUP BY d.status, a.id ORDER BY A.id DESC) b where a.id = b.id " +
				"and upper(a.STATUS) = upper('complete')  and upper(b.status) = upper('incomplete') )";


		updateQueryList.add(sql);

		sql = "update c3par.con_ip_pair_xref set status = 'COMPLETE' where id in " +
		"( select a.id from c3par.con_ip_pair_xref a, " +
		"( SELECT   a.id, NVL (d.status, 'Incomplete') status " +
		"FROM c3par.con_ip_pair_xref a, c3par.con_port_xref b, c3par.con_riskport_ostia c, c3par.con_ostia_group d " +
		"WHERE a.connection_request_id = " +
		+ conProcess.getId().longValue() +
		" AND b.ip_pair_xref_id(+) = a.id AND " +
		"c.PORT_ID "+ ((isDelete)?"(+)":"") + "= b.PORT_ID and " +
		"d.id(+) = c.GROUP_ID AND a.id IN (" +
		pqbIPPairXref.toString(true) +
		") GROUP BY d.status, a.id having count(status) = 1 ORDER BY A.id DESC) b where a.id = b.id " +
		"and upper(a.STATUS) = upper('incomplete')  and upper(b.status) = upper('complete') )";

		log.debug("UPDATE IP PAIR XREF STATUS QUERY::" + sql);

		updateQueryList.add(sql);*/

	/*String sql = "update c3par.con_ip_pair_xref set status = 'INCOMPLETE' where id in " +
				"( select a.id from c3par.con_ip_pair_xref a, " +
				"( select * from ( SELECT   a.id, NVL (d.status, 'Incomplete') status " +
				"FROM c3par.con_ip_pair_xref a, c3par.con_port_xref b, c3par.con_riskport_ostia c, c3par.con_ostia_group d " +
				"WHERE a.connection_request_id = " +
				conProcess.getId().longValue() +
				" AND b.ip_pair_xref_id(+) = a.id AND " +
				"c.PORT_ID "+ ((isDelete)?"(+)":"") + "= b.PORT_ID and " +
				"d.id(+) = c.GROUP_ID AND a.id IN (" +
				pqbIPPairXref.toString(true) +
				") GROUP BY d.status, a.id ORDER BY A.id DESC) group by status, id  having count(status) > 1) b where a.id = b.id )";*/

	/*String sql = "UPDATE c3par.con_ip_pair_xref SET status = 'INCOMPLETE' WHERE id IN " +
				"( SELECT a.id FROM c3par.con_ip_pair_xref a, " +
				"(select id from  (SELECT   * FROM (SELECT   a.id, NVL (d.status, 'Incomplete') status " +
				"FROM c3par.con_ip_pair_xref a, c3par.con_port_xref b, c3par.con_riskport_ostia c, c3par.con_ostia_group d " +
				"WHERE a.connection_request_id = " +
				conProcess.getId().longValue() +
				" AND b.ip_pair_xref_id(+) = a.id AND " +
				"c.PORT_ID "+ ((isDelete)?"(+)":"") + "= b.PORT_ID and " +
				"d.id(+) = c.GROUP_ID AND a.id IN ( " +
				pqbIPPairXref.toString(true) +
				") GROUP BY d.status, a.id ORDER BY a.id DESC)  GROUP BY status, id) " +
				"group by id HAVING COUNT (id) > 1) b WHERE a.id = b.id)";
		updateQueryList.add(sql);
		performerDao.executeDMLQuery(sql);
		sql = "update c3par.con_ip_pair_xref set status = 'INCOMPLETE' where id in " +
				"( select a.id from c3par.con_ip_pair_xref a, " +
				"( select * from ( SELECT   a.id, NVL (d.status, 'Incomplete') status " +
				"FROM c3par.con_ip_pair_xref a, c3par.con_port_xref b, c3par.con_riskport_ostia c, c3par.con_ostia_group d " +
				"WHERE a.connection_request_id = " +
				conProcess.getId().longValue() +
				" AND b.ip_pair_xref_id(+) = a.id AND " +
				"c.PORT_ID "+ ((isDelete)?"(+)":"") + "= b.PORT_ID and " +
				"d.id(+) = c.GROUP_ID AND a.id IN (" +
				pqbIPPairXref.toString(true) +
				") GROUP BY d.status, a.id ORDER BY A.id DESC) group by status, id  having count(status) = 1) b " +
				"where a.id = b.id and upper(a.STATUS) = upper('complete')  and (upper(b.status) = upper('incomplete') " +
				"or upper(b.status) = upper('not started')) )";
		updateQueryList.add(sql);
		performerDao.executeDMLQuery(sql);*/
	String sql = "update c3par.con_ip_pair_xref set status = 'INCOMPLETE' where id in " +
	"( select a.id from c3par.con_ip_pair_xref a where id not in " +
	"( select a.id from c3par.con_ip_pair_xref a, c3par.con_port_xref b, " +
	"c3par.con_riskport_ostia c where a.id = b.IP_PAIR_XREF_ID and b.port_id = c.port_id " +
	"and a.id in (" +
	pqbIPPairXref.toString(true) +
	")) and a.id in (" +
	pqbIPPairXref.toString(true) +
	") " +
	"UNION select a.id from c3par.con_ip_pair_xref a, c3par.con_port_xref b, " +
	"c3par.con_port_master c , c3par.con_riskport_ostia d  where a.id = b.ip_pair_xref_id " +
	" and c.id = b.port_id and d.port_id = c.id and d.group_id is null  and a.id in (" +
	pqbIPPairXref.toString(true) +
	") " +
	"UNION select a.id from c3par.con_ip_pair_xref a, c3par.con_port_xref b, c3par.con_port_master c, " +
	"c3par.con_riskport_ostia d , c3par.con_ostia_group e where a.id = b.ip_pair_xref_id and c.id = b.port_id " +
	"and d.port_id = c.id and e.id = d.group_id and e.status is null and a.id in (" +
	pqbIPPairXref.toString(true) +
	") " +
	"UNION select a.id from c3par.con_ip_pair_xref a, c3par.con_port_xref b, c3par.con_port_master c, " +
	"c3par.con_riskport_ostia d , c3par.con_ostia_group e where a.id = b.ip_pair_xref_id and c.id = b.port_id and " +
	"d.port_id = c.id and e.id = d.group_id and upper(e.status) = upper('incomplete') " +
	"and a.id in (" +
	pqbIPPairXref.toString(true) +
	") )";
	performerDao.executeDMLQuery(sql);
	/*sql = "update c3par.con_ip_pair_xref set status = 'COMPLETE' where id in " +
				"( select a.id from c3par.con_ip_pair_xref a, " +
				"( select * from ( SELECT   a.id, NVL (d.status, 'Incomplete') status " +
				"FROM c3par.con_ip_pair_xref a, c3par.con_port_xref b, c3par.con_riskport_ostia c, c3par.con_ostia_group d " +
				"WHERE a.connection_request_id = " +
				conProcess.getId().longValue() +
				" AND b.ip_pair_xref_id(+) = a.id AND " +
				"c.PORT_ID "+ ((isDelete)?"(+)":"") + "= b.PORT_ID and " +
				"d.id(+) = c.GROUP_ID AND a.id IN (" +
				pqbIPPairXref.toString(true) +
				") GROUP BY d.status, a.id ORDER BY A.id DESC) group by status, id  having count(status) = 1) b " +
				"where a.id = b.id and upper(a.STATUS) = upper('incomplete')  and (upper(b.status) = upper('complete') ) )";*/

	sql = "UPDATE c3par.con_ip_pair_xref SET status = 'COMPLETE' WHERE id IN " +
	"( SELECT   a.id FROM c3par.con_ip_pair_xref a, c3par.con_port_xref b, c3par.con_riskport_ostia c, " +
	"c3par.con_ostia_group d WHERE a.connection_request_id = " +
	conProcess.getId().longValue() +
	" AND b.ip_pair_xref_id(+) = a.id AND " +
	"c.PORT_ID "+ ((isDelete)?"(+)":"") + "= b.PORT_ID and " +
	"d.id(+) = c.GROUP_ID AND a.id IN ( SELECT   id FROM (SELECT   * FROM (SELECT   " +
	"a.id, NVL (d.status, 'Incomplete') status FROM c3par.con_ip_pair_xref a, c3par.con_port_xref b, " +
	"c3par.con_riskport_ostia c, c3par.con_ostia_group d WHERE a.connection_request_id = " +
	conProcess.getId().longValue() +
	" AND b.ip_pair_xref_id(+) = a.id AND " +
	"c.PORT_ID "+ ((isDelete)?"(+)":"") + "= b.PORT_ID and " +
	"d.id(+) = c.GROUP_ID AND a.id IN ( " +
	pqbIPPairXref.toString(true) +
	") GROUP BY d.status, a.id ORDER BY a.id DESC) GROUP BY status, id) GROUP BY id HAVING COUNT (id) = 1 ) " +
	"and  UPPER (a.status) = UPPER ('incomplete')	and  upper(d.status) = upper('complete') )";
	updateQueryList.add(sql);
	//performerDao.executeDMLQuery(sql);
	log.debug("updateIPPairXrefStatus QUERY::" + updateQueryList);
	//		performerDao.executeBatch(updateQueryList);

	log.debug("End updateIPPairXrefStatus");
    }

    /**
     * Gets the seletected pairs.
     *
     * @param conProcess the con process
     * @param performerFilterMap the performer filter map
     * @param sql the sql
     * @return the seletected pairs
     */
    protected Object getSeletectedPairs(ConnectionProcess conProcess,
	    Map performerFilterMap, String sql) {
	log.info("Begin TechnialArchitectureImpl.getSeletectedPairs");
	List connProcessIpPairXrefList = conProcess
	.getConnectionIPPairXrefList();
	Iterator iter = connProcessIpPairXrefList.iterator();
	ConnectionIPPairXref connProcessIpPairXref = null;
	List conditionList = new ArrayList();
	List pairs = new ArrayList();
	PerformerPagerDO pairObj = null;
	if (conProcess.isSelectAll()) {
	    try {

		sql = sql + " ORDER BY CON_IP_PAIR_MASTER.ID DESC ";

		pairObj = (PerformerPagerDO) performerDao
		.mapQueryToObjectUsingPager(Long.valueOf(0),
			new ConnectionIPPairXref(), sql,
			PerformerTypes.RECORD_PER_BATCH);
	    } catch (Exception e) {
		log.error(e, e);

		throw new ApplicationException(e.getMessage());
	    }
	    return pairObj;
	} else {
	    while (iter.hasNext()) {
		connProcessIpPairXref = (ConnectionIPPairXref) iter.next();
		if (connProcessIpPairXref.getConnectionIPPairMaster()
			.isSelected()) {
		    conditionList.add(connProcessIpPairXref
			    .getConnectionIPPairMaster());
		}
	    }
	    List connProcessIpPairXrefIds = TechnicalArchitectureUtil
	    .getIds(conditionList);
	    pairs = connProcessIpPairXrefIds;
	    log.info("End TechnialArchitectureImpl.getSeletectedPairs");
	    return pairs;
	}
    }

    /**
     * Gets the port objs.
     *
     * @param conProcess the con process
     * @param conPortXrefList the con port xref list
     * @param isAllportsSelected the is allports selected
     * @param pairFilterMap the pair filter map
     * @param portFilters the port filters
     * @param isDelete the is delete
     * @return the port objs
     * @throws Exception the exception
     */
    protected List getPortObjs(ConnectionProcess conProcess,
	    List conPortXrefList, boolean isAllportsSelected,
	    Map pairFilterMap, Map portFilters, boolean isDelete)
    throws Exception {
	log.info("Begin TechnialArchitectureImpl.getPortObjs");
	List condition = new ArrayList();

	StringBuilder sql = null;

	if (!isDelete) {
	    sql = new StringBuilder(TechnicalArchitectureUtil
		    .getCommonPortsQueryStringOnOstiaPage(conProcess,
			    pairFilterMap, portFilters));
	} else {
	    sql = new StringBuilder(
		    TechnicalArchitectureUtil.getCommonPortsQueryString(
			    conProcess, pairFilterMap,portFilters));
	}

	Iterator conPortXrefListIter = conPortXrefList.iterator();
	if (isAllportsSelected) {
	    while (conPortXrefListIter.hasNext()) {
		ConnectionPortXref conPortXref = (ConnectionPortXref) conPortXrefListIter
		.next();
		if (!conPortXref.getConnectionPortMst().isSelected()) {
		    condition.add(conPortXref.getConnectionPortMst());
		}
	    }

	    if (condition != null && condition.size() > 0) {
		sql.append(" AND CON_PORT_XREF.PORT_ID NOT IN (");
		sql.append(PerformerUtil.listToString(TechnicalArchitectureUtil
			.getIds(condition)));
		sql.append(")");
	    }

	} else {
	    while (conPortXrefListIter.hasNext()) {
		ConnectionPortXref conPortXref = (ConnectionPortXref) conPortXrefListIter
		.next();
		if (conPortXref.getConnectionPortMst().isSelected()) {
		    condition.add(conPortXref.getConnectionPortMst());
		}
	    }

	    if (condition != null && condition.size() > 0) {
		sql.append(" AND CON_PORT_XREF.PORT_ID IN (");
		sql.append(PerformerUtil.listToString(TechnicalArchitectureUtil
			.getIds(condition)));
		sql.append(")");
	    }
	}
	// }

	sql
	.append(" AND CON_PORT_XREF.IP_PAIR_XREF_ID in (SELECT ID FROM CON_IP_PAIR_XREF "
		+ "WHERE CONNECTION_REQUEST_ID = "
		+ conProcess.getId()
		+ " )");
	List portObjs = performerDao.mapQueryToPerformerDoObjectWithParentId(
		new ConnectionPortXref(), sql.toString(),
		new ConnectionIPPairMaster());
	log.info("End TechnialArchitectureImpl.getPortObjs");
	return portObjs;
    }
    /*public void sendEmailToAppOwners(Long connID) throws Exception{
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sendEmail=C3parProperties.SENDEMAIL_TO_CSIAPPOWNER;
		C3parSession c3parSession = new C3parSession();

		try {
			if(connID!=null){
				StringBuilder sql=new StringBuilder(" select distinct con.CONNECTION_NAME,usr.FIRST_NAME,usr.LAST_NAME,con.REQUESTER_ID,reg.NAME,sec.NAME , bu.BUSINESS_NAME,app.APPLICATION_ID,app.APPLICATION_NAME,app.APP_OWNER_FULL_NAME,app.APP_OWNER_EMAIL ");
				sql.append(" from c3par.con_req con, c3par.relationship rel,c3par.ent_data ed1,c3par.ent_data ed2, c3par.ti_application app,c3par.region reg,c3par.sector sec,c3par.business_unit bu,c3par.con_ip_xref cipx,c3par.con_ip_master cipm,C3PAR.C3PAR_USERS usr where con.relationship_id=rel.id and rel.ENT_INSTANCE_ID =ed1.ENTITLEMENT_INSTANCE_ID ");
				sql.append(" and ed1.ENTITLEMENT_INSTANCE_ID=ed2.ENTITLEMENT_INSTANCE_ID and ed1.id!=ed2.id and ed1.ENTITLEMENT_NODE_ID=1 and ed2.ENTITLEMENT_NODE_ID=2 and ed1.DATA=reg.id and ed2.data=sec.id and rel.BUSINESS_UNIT_ID=bu.id and  con.ID=cipx.CONNECTION_REQUEST_ID and cipx.IP_ID=cipm.ID and cipm.DELETE_FLAG!='T' ");
				sql.append(" and cipx.APPLICATION_ID=app.ID and app.IS_CSI='Y' and app.IS_DEVICE='N' and CON.REQUESTER_ID=usr.SSO_ID and  con.id= "+connID);
//				log.debug(" sql is"+sql.toString());
				Set emailAddr= new HashSet();
				//emailAddr.add("dl.CITS.C3par.Development@imcnam.ssmb.com");
				String connectionName=null;

				String firstName=null;
				String lastName=null;
				String ssoID=null;
				String bu=null;
				String reg=null;
				String sec=null;

				conn =c3parSession.getConnection();
				Set appInfoSet =new HashSet();
				stmt = conn.prepareStatement(sql.toString());
				rs = stmt.executeQuery();
				if(rs!=null){
					while (rs.next()){
						connectionName=rs.getString(1);
						firstName=rs.getString(2);
						lastName=rs.getString(3);
						ssoID=rs.getString(4);
						reg=rs.getString(5);
						sec=rs.getString(6);
						bu=rs.getString(7);
						StringBuilder appInfo=new StringBuilder();
						appInfo.append(rs.getString(8));
						appInfo.append(" - "+rs.getString(9));
						appInfo.append("- "+rs.getString(10));
						appInfoSet.add(appInfo.toString());
						if(rs.getString(11)!=null)
							emailAddr.add(rs.getString(11));
					}

						SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
						if( emailAddr!=null && emailAddr.size()>0){
							String []emailAddress=(String [])emailAddr.toArray(new String[emailAddr.size()]);
							//String[] array = (String[])set.toArray(new String[set.size()]);
							//for(int j=0;j<emailAddress.length;j++)
								//log.debug(" email Address "+j+emailAddress[j]);
							StringBuilder msgTxt=new StringBuilder();
							msg.setSubject("Approval Requested: Connection Request: "+connID+" - "+connectionName);
							msg.setSentDate(new Date());
							msg.setTo(emailAddress);
							msgTxt.append("Hello Application Owner:");
							msgTxt.append("\n");
							msgTxt.append("This email has been auto-generated by the C3PAR system to alert you that a request has been made to gain access to your application.");
							msgTxt.append("\n");
							msgTxt.append("Connection Name: "+connectionName+ "\n");

							msgTxt.append("Connection ID: "+connID+"\n");

							msgTxt.append("Requesting Region: "+reg+"\n");

							msgTxt.append("Requesting Sector: "+sec+"\n");

							msgTxt.append("Requesting Business Unit: "+bu+"\n");

							msgTxt.append("Project Coordinator: "+firstName+" "+lastName+"("+ssoID+")");
							msgTxt.append("\n");
							msgTxt.append("Application Information: \n");
							msgTxt.append("ApplicationID - ApplicationName - ApplicationOwner \n");
							Iterator itr=appInfoSet.iterator();
							while(itr.hasNext()){
								msgTxt.append((String)itr.next());
								msgTxt.append("\n");
							}

							msgTxt.append("If you need additional details login to C3PAR  to review the connection :https://c3par.nj.ssmb.com ");
							msgTxt.append("\n");
							msgTxt.append("\n If you accept this request, please take no action - if you would like to reject this access request, please contact the Firewall Operations Team immediately: *GT GFRAO Change Management");
							msgTxt.append("\n");
														msgTxt.append(" Thank you,");
							msgTxt.append("\n");
							msgTxt.append(" C3PAR ");
							msg.setText(msgTxt.toString());
							//log.debug("MESSAGE IS "+msgTxt.toString());
							if(msg!=null){
							if(msg.getTo()!=null)
								log.debug("MESSAGE TO "+msg.getTo().toString());
								log.debug("MESSAGE SUBJECT "+msg.getSubject());
								log.debug("MESSAGE TXT "+msg.getText());
							}
							if(sendEmail!=null && sendEmail.equalsIgnoreCase("FALSE"))
								msg.setTo(C3parProperties.ISA_REGISTRY_EMAIL);
								try{
									log.debug("sending email to appowners for process id"+connID);
						            this.mailSender.send(msg);
						        }
						        catch(MailException ex) {
						            // simply log it and go on...
						            log.error(ex);
						        }


					}


				}
			}
		}
		 catch (Exception e) {
				log.error(e);
			} finally {
				try {
					if(rs!=null)
						rs.close();
					if(stmt!=null)
						stmt.close();
					if(conn!=null)
						conn.close();
				} catch (Exception ex) {
					log.error(ex);
				}
			}
	}*/
    /**
     * Send oper anal schedule email.
     *
     * @param connID the conn id
     * @param sheduleDate the shedule date
     */
    public void sendOperAnalScheduleEmail(Long connID,Date sheduleDate){

	Connection conn = null;
	PreparedStatement stmt = null, stmtPC  = null;
	ResultSet rs = null;
	ResultSet rsPC = null;
	String connName=null;
	Set emailAddr= new HashSet();
	String sendEmail=C3parProperties.SENDEMAIL_TO_CSIAPPOWNER;
	C3parSession c3parSession = new C3parSession();
	String projectCoordinator=null;
	String process_type = "Connection";
	StringBuilder toAddress=new StringBuilder();
	
	
	if(connID!=null){
	    try {
	    String emailSql=("select usr.email from c3par.c3par_users usr,c3par.c3par_user_role_xref usrxref ,c3par.security_role srole where  usrxref.role_id=srole.id and usrxref.user_id=usr.id and srole.NAME='C3PARSYSTEMADMIN' and usr.is_active='Y' ");
		//emailSql.append(" union ");
		//emailSql.append(" SELECT C3PAR_USERS.EMAIL FROM CITI_CONTACT, C3PAR_USERS WHERE UPPER(CITI_CONTACT.FIRST_NAME) = UPPER(C3PAR_USERS.FIRST_NAME) AND UPPER(CITI_CONTACT.LAST_NAME) = UPPER(C3PAR_USERS.LAST_NAME) AND CITI_CONTACT.ID IN");
		//emailSql.append(" (SELECT citi_contact_id FROM CON_REQ_CITI_CONTACT_XREF WHERE  role_id in (3,4)  and request_id = ");
		//emailSql.append(connID+ ") and c3par_users.IS_ACTIVE='Y'");
	    StringBuilder pcSql=new StringBuilder(" select a.ID,a.process_name,b.EMAIL,b.FIRST_NAME || ' ' || b.LAST_NAME as Name,a.process_type_id " +
			"from c3par.ti_process a,c3par.ti_request r,c3par.c3par_users b " +
			"where a.id = r.process_id and r.user_id=b.id and b.IS_ACTIVE='Y' and a.ID=" +connID);

		try {
		conn =c3parSession.getConnection();
		stmt = conn.prepareStatement(emailSql);
		rs = stmt.executeQuery();
		if(rs!=null){
		    while (rs.next()){
			if(rs.getString(1)!=null)
			    emailAddr.add(rs.getString(1));
		    	toAddress.append(rs.getString(3)+";");
		    }
		}
		 } catch (Exception e) {
				log.error(e);
			    } finally {
					c3parSession.closeResultSet( rs );
					c3parSession.closeStatement( stmt );
			    }
		
		/*
		 * Project Coordinator,

	Your Connection Request has received all the required approvals and will be implemented on [networkEnggSheduleDate.sheduleDate].

	Connection Request Name: GCG - Primerica - MetLife Connection Request
	ID: 446 Project Coordinator: pb92734
	Action: No action required.

	Please do not respond to this email.

	C3PAR System
		 */

			    stmtPC = conn.prepareStatement(pcSql.toString());
			    rsPC = stmtPC.executeQuery();
		
			    if(rsPC!=null){
		    while (rsPC.next()){
			connName=rsPC.getString(2);
			if(rsPC.getString(3)!=null){
			    emailAddr.add(rsPC.getString(3));
			    toAddress.append(rsPC.getString(3)+";");
			}
			projectCoordinator=rsPC.getString(4);
		 
			if(rsPC.getString(5)!=null && rsPC.getLong(5)==2)
			    process_type = "IP Registration";
			else
			    process_type="Connection";
		    }

		}
	    } catch (Exception e) {
		log.error(e);
	    } finally {
		try {
			c3parSession.closeResultSet( rsPC );
			c3parSession.closeStatement( stmtPC );
				
		    if(conn!=null)
			conn.close();
		} catch (Exception ex) {
		    log.error(ex);
		}
	    }

	    SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
	    if( emailAddr!=null && emailAddr.size()>0){
		String []emailAddress=(String [])emailAddr.toArray(new String[emailAddr.size()]);

		for(int j=0;j<emailAddress.length;j++)
		    log.debug(" email Address "+j+emailAddress[j]);
		StringBuilder msgTxt=new StringBuilder();
		msg.setSubject("Scheduled Implementation: "+process_type+" Request: "+connID+" - "+connName);
		msg.setSentDate(new Date());
		msg.setTo(emailAddress);
		msgTxt.append("Project Coordinator,");
		msgTxt.append("\n\n");

		msgTxt.append("Your "+process_type+" Request has received all the required approvals and will be implemented on "+sheduleDate);
		msgTxt.append("\n\n");
		msgTxt.append(""+process_type+" Request Name: "+connName+ "\n");

		msgTxt.append(""+process_type+" ID: "+connID+"\n");
		msgTxt.append("Project Coordinator: "+projectCoordinator);
		msgTxt.append("\n");
		msgTxt.append("Action: No action required. \n\n");
		msgTxt.append("Please do not respond to this email. \n\n");
		msgTxt.append("C3PAR System");


		msg.setText(msgTxt.toString());
		//log.debug("MESSAGE IS "+msgTxt.toString());
		if(msg!=null){
		    if(msg.getTo()!=null)
			log.debug("MESSAGE TO "+msg.getTo().toString());
		    log.debug("MESSAGE SUBJECT "+msg.getSubject());
		    log.debug("MESSAGE TXT "+msg.getText());
		}
		if(sendEmail!=null && sendEmail.equalsIgnoreCase("FALSE"))
		    msg.setTo(C3parProperties.ISA_REGISTRY_EMAIL);
		try{
		    log.debug("sending email to appowners for conn id"+connID);
		    this.mailSender.send(msg);

			//insert mail information into TI_MAIL_AUDIT for Audit
			C3PARMailMessage mailMsg = new C3PARMailMessage();
			mailMsg.setTiRequestID(new Long(0L));
			mailMsg.setTemplateID("");
			mailMsg.setToAddresses(toAddress.toString());
			mailMsg.setCcAddresses("");
			mailMsg.setMsgSubject(msg.getSubject());
			mailMsg.setMsgContent(msgTxt.toString());				
			mailActivityAudit(mailMsg);
		}
		catch(MailException ex) {

		    log.error(ex);
		}


	    }

	}
    }

    /**
     * Send conn approval email.
     *
     * @param connID the conn id
     * @param activityName the activity name
     */
    public void sendConnApprovalEmail(Long connID, String activityName){

	//Completed Implementation: IP Registration Request: testtpskip
	Connection conn = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;

	Set emailAddr= new HashSet();
	String sendEmail=C3parProperties.SENDEMAIL_TO_CSIAPPOWNER;
	C3parSession c3parSession = new C3parSession();

	SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
	boolean isUserWithRolePresent=true;
	String role=null;
	String processName=null;

	try{
	    if(connID!=null){
		conn =c3parSession.getConnection();
		HashMap reqDetails=getRequester(connID);
		String processDetSQL=new String(" select role,process from c3par.progress_bar where upper(activity_name) like upper('"+activityName+"')");

		try {
		stmt =conn.prepareStatement(processDetSQL);
		rs=stmt.executeQuery();
		if(rs!=null){
		    while (rs.next()){
			role=rs.getString(1);
			processName=rs.getString(2);
		    }
		}
		} catch (Exception e) {
			 log.error(e);
		}
		finally {
			c3parSession.closeResultSet( rs );
			c3parSession.closeStatement( stmt );	
		}

		StringBuilder contactSQL=new StringBuilder("SELECT C3PAR_USERS.EMAIL FROM CITI_CONTACT, C3PAR_USERS  WHERE UPPER(CITI_CONTACT.FIRST_NAME) = UPPER(C3PAR_USERS.FIRST_NAME) AND 	UPPER(CITI_CONTACT.LAST_NAME) = UPPER(C3PAR_USERS.LAST_NAME) and C3PAR_USERS.IS_ACTIVE ='Y'  AND CITI_CONTACT.ID IN (SELECT citi_contact_id FROM CON_REQ_CITI_CONTACT_XREF WHERE request_id = ? ");
		contactSQL.append(" AND role_id = (select id from c3par.role where lower(name) like lower('"+role+"')))");

		stmt=conn.prepareStatement(contactSQL.toString());
		stmt.setLong(1, connID.longValue());
		rs=stmt.executeQuery();
	
		if(rs!=null){
		    while (rs.next()){
			if(rs.getString(1)!=null)
			    emailAddr.add(rs.getString(1));
		    }
		}
		//if theres no user with the role send email to Project coordinator and ISo third Party Registry


		if(emailAddr!=null && emailAddr.size()==0){
		    isUserWithRolePresent=false;
		    if(reqDetails.get("EMAIL") !=null)
			emailAddr.add((String)reqDetails.get("EMAIL"));
		    emailAddr.add(C3parProperties.ISA_REGISTRY_EMAIL);
		}
		if(emailAddr!=null && emailAddr.size()>0){
		    String []emailAddress=(String [])emailAddr.toArray(new String[emailAddr.size()]);
		    StringBuilder toAddress = new StringBuilder();

		    for(int j=0;j<emailAddress.length;j++){
		    	log.debug(" email Address "+j+emailAddress[j]);
		    	toAddress.append(emailAddress[j]+";");
		    }

		    msg.setSubject(buildSubject(role,processName,activityName,connID,(String)reqDetails.get("CONNAME"),isUserWithRolePresent));
		    msg.setSentDate(new Date());
		    msg.setTo(emailAddress);
		    msg.setText(buildMessageBody(role,processName,activityName,reqDetails,isUserWithRolePresent));
		    if(sendEmail!=null && sendEmail.equalsIgnoreCase("FALSE"))
			msg.setTo(C3parProperties.ISA_REGISTRY_EMAIL);
		    if(msg!=null){
			if(msg.getTo()!=null)
			    log.debug("MESSAGE TO "+msg.getTo().toString());
			log.debug("MESSAGE SUBJECT "+msg.getSubject());
			log.debug("MESSAGE TXT "+msg.getText());
		    }

		    try{
			log.debug("sending email to in last step by oa for conn id"+connID);
			this.mailSender.send(msg);
			
				//insert mail information into TI_MAIL_AUDIT for Audit
				C3PARMailMessage mailMsg = new C3PARMailMessage();
				mailMsg.setTiRequestID(new Long(0L));
				mailMsg.setTemplateID(activityName);
				mailMsg.setToAddresses(toAddress.toString());
				mailMsg.setCcAddresses("");
				mailMsg.setMsgSubject(msg.getSubject());
				mailMsg.setMsgContent(msg.getText());				
				mailActivityAudit(mailMsg);
		    }
		    catch(MailException ex) {
			// simply log it and go on...
			log.error(ex);
		    }

		    finally {
		
				c3parSession.closeResultSet( rs );
				c3parSession.closeStatement( stmt );	

		    	try {
			    if(conn!=null)
				conn.close();
			} catch (Exception e) {
			    log.error(e);
			}
		    }


		}
	    }
	}
	catch (Exception e) {
	    log.error(e);
	} finally {
	    try {
		if(rs!=null)
		    rs.close();
		if(stmt!=null)
		    stmt.close();
		if(conn!=null)
		    conn.close();
	    } catch (Exception e) {
		log.error(e);
	    }
	}
    }

    /**
     * Builds the subject.
     *
     * @param role the role
     * @param processName the process name
     * @param activityName the activity name
     * @param connID the conn id
     * @param connName the conn name
     * @param isUserWithRolePresent the is user with role present
     * @return the string
     */
    String buildSubject(String role ,String processName ,String activityName,Long connID,String connName,boolean isUserWithRolePresent){
	StringBuilder subject=new StringBuilder();
	//if("BISO".equalsIgnoreCase(role)){
	if (processName !=null){
	    if(processName.equalsIgnoreCase("Planning")|| processName.equalsIgnoreCase("Activation"))
		subject.append("New");
	    else if(processName.equalsIgnoreCase("Maintenance"))
		subject.append("Update");
	    else if(processName.equalsIgnoreCase("Termination"))
		subject.append("Terminate");
	}
	subject.append(" Connection Request: "+connID+" - "+connName);
	//}
	if(!isUserWithRolePresent)
	    subject.append(" ** UNDELIVERED EMAIL  REDIRECTED- Requires Your Immediate Attention **");
	return subject.toString();

    }

    /**
     * Builds the message body.
     *
     * @param role the role
     * @param processName the process name
     * @param activityName the activity name
     * @param reqDetails the req details
     * @param isUserWithRolePresent the is user with role present
     * @return the string
     */
    String buildMessageBody(String role ,String processName ,String activityName,HashMap reqDetails,boolean isUserWithRolePresent){
	StringBuilder msgTxt=new StringBuilder();
	String systemAdminComments=null;
	String displayRole=role;
	if("Design Engineer".equalsIgnoreCase(role))
	    displayRole="TI Engineering Support";
	if(!isUserWithRolePresent)
	    msgTxt.append("C3par system could not deliver the below email to the assigned contact. You are required to forward this mail \n" +
	    "to the appropriate contact to push your connection forward through the c3par system for implementation. \n\n\n");

	msgTxt.append(displayRole+" Contact,\n\n");
	if (processName !=null){
	    if(activityName!=null && ("Review Details".equalsIgnoreCase(activityName) || "Sign Off Detailed Design".equalsIgnoreCase(activityName)
		    || "Technical Architecture".equalsIgnoreCase(activityName)||"Update Technical Architecture".equalsIgnoreCase(activityName)
		    || "Review Connection Make Changes".equalsIgnoreCase(activityName) )){
		if(processName.equalsIgnoreCase("Planning")|| processName.equalsIgnoreCase("Activation"))
		    msgTxt.append("A new");
		else if(processName.equalsIgnoreCase("Maintenance"))
		    msgTxt.append("A maintenance");
		else if(processName.equalsIgnoreCase("Termination"))
		    msgTxt.append("A new Terminate");
		msgTxt.append(" connection request has been created \n");
		msgTxt.append("in the Registry System. \n");
	    }

	    if("Review Details".equalsIgnoreCase(activityName) || "Sign Off Detailed Design".equalsIgnoreCase(activityName)
		    || "Update Technical Architecture".equalsIgnoreCase(activityName) )
		msgTxt.append("Please review the connection \n\n");

	    if("Technical Architecture".equalsIgnoreCase(activityName)){
		msgTxt.append("Please develop the \n");
		msgTxt.append("High Level Design documentation and upload \n");
		msgTxt.append("into the Registry system. \n\n");
	    }else if("Rework Technical Architecture".equalsIgnoreCase(activityName)){
		systemAdminComments=getSytemAdminComments((String)reqDetails.get("CONID"));
		if(systemAdminComments!=null)
		    msgTxt.append("The connection has been rejected by the Third Party Working group, the reason is "+systemAdminComments+"\n");
		else
		    msgTxt.append("The connection has been rejected.  \n");
	    }
	    else if("Rework Design Document".equalsIgnoreCase(activityName))
		msgTxt.append("The connection has been rejected.  \n");
	    //else

	    msgTxt.append("\n"+"Connection Name: "+(String)reqDetails.get("CONNAME")+"\n");
	    msgTxt.append("Connection ID: "+(String)reqDetails.get("CONID")+"\n");
	    msgTxt.append("Project Coordinator: "+(String)reqDetails.get("FIRSTNAME")+" "+(String)reqDetails.get("LASTNAME")+"\n");

	    if("Rework Technical Architecture".equalsIgnoreCase(activityName)){
		if(systemAdminComments!=null)
		    msgTxt.append("Rejection Reason: "+systemAdminComments+"\n");
		msgTxt.append("Action: Rework the connection. \n");
	    } else if("Rework Design Document".equalsIgnoreCase(activityName)){
		msgTxt.append("Action: Rework the connection. \n");
	    } else if("Review Connection Make Changes".equalsIgnoreCase(activityName)){
		msgTxt.append("Action: Please review the connection that needs \n");
		msgTxt.append("to be terminated and make the necessary changes \n");
	    } else if("Technical Architecture".equalsIgnoreCase(activityName)){
		msgTxt.append("Action: Develop High Level Design and upload into the Registry system for this connection. \n");
	    }else if ("Update Technical Architecture".equalsIgnoreCase(activityName)){
		msgTxt.append("Action: Review the update connection request  and make the necessary  changes. \n");
	    }else{
		msgTxt.append("Action: Review, then approve or reject the connection request . \n");
	    }
	    msgTxt.append("\n\nPlease do not respond to this email.\n");
	    msgTxt.append("\n\nC3PAR System");
	}

	return msgTxt.toString();

    }

    /**
     * Gets the sytem admin comments.
     *
     * @param connID the conn id
     * @return the sytem admin comments
     */
    protected String getSytemAdminComments(String connID)
    {
	Connection conn = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	String sysComments=null;
	C3parSession c3parSession = new C3parSession();
	try{
	    StringBuilder sysAdminSQL=new StringBuilder(" SELECT SYSTEM_ADMIN_COMMENTS FROM PLANNING WHERE ID = ?");
	    conn =c3parSession.getConnection();
	    stmt=conn.prepareStatement(sysAdminSQL.toString());
	    stmt.setLong(1, Long.valueOf(connID).longValue());
	    rs=stmt.executeQuery();
	    if(rs!=null){
		while (rs.next()){
		    sysComments=rs.getString(1);
		}
	    }
	}catch (Exception e) {
	    log.error(e);
	} finally {
	    try {
		if(rs!=null)
		    rs.close();
		if(stmt!=null)
		    stmt.close();
		if(conn!=null)
		    conn.close();
	    } catch (Exception e) {
		log.error(e);
	    }
	}

	return sysComments;
    }

    /**
     * Gets the requester.
     *
     * @param connID the conn id
     * @return the requester
     */
    protected HashMap getRequester(Long connID) {
	Connection conn = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;

	HashMap reqDetails= new HashMap();

	C3parSession c3parSession = new C3parSession();
	try{
	    StringBuilder reqSQL=new StringBuilder(" select * from ( select a.id connid,connection_name,requester_id ,first_name,last_name ,email from c3par.con_req a ,c3par.c3par_users b where a.id in ( select max(planning_id) from c3par.maintenance where connection_id in (select id from c3par.connection where connection_request_id= ?) group by connection_id ) and lower(a.REQUESTER_ID)=lower(b.sso_id) and b.is_active='Y' ");
	    reqSQL.append(" union select con_req.id connid,connection_name,requester_id,first_name,last_name ,email from c3par.con_req ,c3par_users  where con_req.id=? and lower(requester_id)=lower(sso_id) and is_active='Y' ) order by connid asc");
	    conn =c3parSession.getConnection();
	    stmt=conn.prepareStatement(reqSQL.toString());
	    stmt.setLong(1, connID.longValue());
	    stmt.setLong(2, connID.longValue());
	    rs=stmt.executeQuery();
	    reqDetails.put("CONID",connID.toString());
	    if(rs!=null){
		while (rs.next()){
		    //reqDetails.put("CONID",rs.getString(1));
		    reqDetails.put("CONNAME",rs.getString(2));
		    reqDetails.put("SSOID",rs.getString(3));
		    reqDetails.put("FIRSTNAME",rs.getString(4));
		    reqDetails.put("LASTNAME",rs.getString(5));
		    if(rs.getString(6)!=null)
			reqDetails.put("EMAIL",rs.getString(6));

		}
	    }

	}
	catch (Exception e) {
	    log.error(e);
	} finally {
	    try {
		if(rs!=null)
		    rs.close();
		if(stmt!=null)
		    stmt.close();
		if(conn!=null)
		    conn.close();
	    } catch (Exception e) {
		log.error(e);
	    }
	}

	return reqDetails;
    }

    /**
     * Update port master share flag.
     *
     * @param pqbIPPairXref the pqb ip pair xref
     * @param havingExpression the having expression
     */
    protected void updatePortMasterShareFlag (PerformerQueryBuilder pqbIPPairXref, PerformerExpression havingExpression) {
	try {
	    if (havingExpression == null) {
		havingExpression = new PerformerExpression();
		havingExpression.setExpression("count(?)<=1");
		havingExpression.addBinders("a", "connectionPortMst");
	    }

	    PerformerQueryBuilder pqbPortXref = new PerformerQueryBuilder();
	    pqbPortXref.setPerformerName("a", ConnectionPortXref.class.getName());
	    pqbPortXref.addSelectColumn("a", "connectionPortMst");
	    /*if (pqbIPPairXref != null) {
				pqbPortXref.addWhereCondition("a", "ip_pair_xref_id", PerformerTypes.IN, pqbIPPairXref);
			}*/
	    pqbPortXref.addGroupBy("a", "connectionPortMst");
	    pqbPortXref.addHaving(havingExpression);

	    StringBuilder sqlQuery = new StringBuilder();
	    sqlQuery.append("UPDATE ");
	    sqlQuery.append(PerformerTypes.CONN_PORT_MASTER_TABEL);
	    sqlQuery.append(" SET SHARE_FLAG='F', UPDATED_DATE = TO_DATE('" +
		    PerformerUtil.getFormatedDate((Date) new Date(),PerformerTypes.DATE_FORMAT3)+ "','"
		    + PerformerTypes.DATE_FORMAT4+ "')  WHERE ID IN ");

	    sqlQuery.append("(");
	    sqlQuery.append(pqbPortXref.toString(true));

	    sqlQuery.append(" ) ");
	    sqlQuery.append(" and share_flag = 'T'");

	    log.debug("QUERY::" + sqlQuery.toString());
	    performerDao.executeDMLQuery(sqlQuery.toString());
	} catch (PerformerException e) {
	    // TODO Auto-generated catch block
	    log.error(e);
	    throw new ApplicationException (e.getMessage());
	}
    }

    /**
     * Delete risk port ostia.
     */
    protected void deleteRiskPortOstia () {
	try {


	    PerformerQueryBuilder pqbPortXref = new PerformerQueryBuilder();
	    pqbPortXref.setPerformerName("a", ConnectionPortXref.class.getName());
	    pqbPortXref.addSelectColumn("a", "connectionPortMst");

	    PerformerQueryBuilder pqbRiskPortOstia = new PerformerQueryBuilder();
	    pqbRiskPortOstia.setPerformerName("", ConnectionRiskPortOstia.class.getName());
	    pqbRiskPortOstia.addWhereCondition("port_id", PerformerTypes.NOT_IN, pqbPortXref);

	    log.debug("QUERY::" + pqbRiskPortOstia.toString(true));
	    performerDao.delete(pqbRiskPortOstia);

	} catch (PerformerException e) {
	    // TODO Auto-generated catch block
	    log.error(e);
	    throw new ApplicationException (e.getMessage());
	}
    }

    /**
     * Send email faf completion.
     *
     * @param connectionID the connection id
     * @param reportType the report type
     * @throws Exception the exception
     */
    public void sendEmailFAFCompletion(Long connectionID,String reportType) throws Exception {

	C3parSession c3parSession = new C3parSession();
	Connection conn = null;
	PreparedStatement stmt = null;
	//	PreparedStatement updatestmt = null;
	ResultSet rs = null;
	String sendFAFCompletionEmail=C3parProperties.FAF_COMPLETION_EMAIL;
	String sendEmail="TRUE";
	boolean tstSendMailMode=false;
	if(sendEmail!=null && sendEmail.equalsIgnoreCase("TRUE"))
	    tstSendMailMode=true;

	try {
	    if(connectionID!=null){
		StringBuilder  sql= new StringBuilder(" select distinct cu.email,cu.first_name,cu.last_name,cr.connection_name from c3par_users cu,faf_queue_con_requests fqcr,con_req cr " );
		sql.append(" where fqcr.requester_soeid=cu.sso_id and cr.id=fqcr.con_req_id and fqcr.id=(select max(id) from faf_queue_con_requests where con_req_id="+connectionID.toString()+") and fqcr.con_req_id= "+connectionID.toString());
		//		StringBuilder  updatesql= new StringBuilder("update faf_queue_con_requests set completed_time=sysdate where completed_time is null and con_req_id="+ connectionID.toString());
		String emailAddr= null;
		String requesterFirstName=null;
		String requesterLastName=null;
		String connectionName=null;
		conn =c3parSession.getConnection();
		stmt = conn.prepareStatement(sql.toString());
		rs = stmt.executeQuery();
		while (rs.next()){
		    if(rs.getString(1)!=null)
			emailAddr = rs.getString(1);
		    requesterFirstName = rs.getString(2);
		    requesterLastName = rs.getString(3);
		    connectionName = rs.getString(4);
		    break;
		}
		//		updatestmt=conn.prepareStatement(updatesql.toString());
		//		updatestmt.execute();
		SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
		if(emailAddr!=null ){
		    String []emailAddress=new String [1];
		    emailAddress[0] = emailAddr;
		    for(int j=0;j<emailAddress.length;j++)
			log.debug(" email Address "+j+emailAddress[j]);
		    boolean msgExists=false;
		    StringBuilder msgTxt=new StringBuilder();
		    String displayReportType = (reportType == "FAF") ? "Firewall Access Form (FAF)" : (reportType == "PAF") ? "Proxy Access Form (PAF)" : (reportType == "AAF") ? "AppSense Access Form (AAF)" : "";
		    msg.setSubject(displayReportType+" Calculation Completed: Connection Request: "+connectionID+" - "+connectionName);
		    msg.setSentDate(new Date());
		    msg.setTo(emailAddress);
		    msg.setCc(sendFAFCompletionEmail);
		    msgTxt.append("Hello "+requesterFirstName+" "+requesterLastName+" ("+displayReportType+" Requester) :");
		    msgTxt.append("\n\n");
		    msgTxt.append("This email has been auto-generated by the C3PAR system to alert you that "+reportType+" has been successfully calculated for the below connection, as requested.");
		    msgTxt.append("\n\n");
		    msgTxt.append("Connection ID: "+connectionID.toString());
		    msgTxt.append("\nConnection Name: "+connectionName);
		    //Added as part of Defct 5227 Strats
		    msgTxt.append("\n\n");
		    String implementor = (reportType == "FAF") ? "PSO" : (reportType == "PAF") ? "PAFPSO" : (reportType == "AAF") ? "AAFPSO" : "";
		    msgTxt.append("Your "+displayReportType+" is now available for review in the system. Bel" +
			    "ow is the summary of Add and /or Delete Combinations generated by "+displayReportType+" Computation. If the output contains delete rules and do not want them to be processed please contact " +implementor+" immediately.");

		    msgTxt.append("\n");

		    List policyNameList = new ArrayList();
		    MailModuleUtil mmUtil=new MailModuleUtil();
		    if(reportType == "FAF"){

			policyNameList= mmUtil.getFAFCombinations(connectionID.toString());
		    }
		    else if(reportType == "PAF"){
			policyNameList= mmUtil.getPAFCombinations(connectionID.toString());
		    }
		    else if(reportType == "AAF"){
			policyNameList= mmUtil.getAAFCombinations(connectionID.toString());
		    }
		    Iterator rit = policyNameList.iterator();
		    if (policyNameList.size()== 0)
		    {
			msgTxt.append("\n");
			msgTxt.append("There are no Add and /or Delete Combinations.");
		    }
		    while(rit.hasNext())
		    {
			msgTxt.append("\n");
			msgTxt.append((String)rit.next());
		    }
		    //Added - 5227 Ends


		    msgTxt.append(" \n\nYou may view/review the connection for checking "+reportType+". "+"\n");
		    msgTxt.append(" \nDO NOT Reply to this message. Please contact '*IS GLOBAL CCR', in case of any problem. "+"\n\n");
		    msgTxt.append("Thank you,"+"\n");
		    msgTxt.append("C3PAR");
		    msg.setText(msgTxt.toString());
		    //log.debug("MESSAGE IS "+msgTxt.toString());
		    if(msg!=null){
			msgExists=true;
		    }
		    if(msgExists && tstSendMailMode){
			try{
			    log.debug("sending email to FAFRequester for connection id"+connectionID);
			    this.mailSender.send(msg);
			    
				//insert mail information into TI_MAIL_AUDIT for Audit
				C3PARMailMessage mailMsg = new C3PARMailMessage();
				mailMsg.setTiRequestID(new Long(0L));
				mailMsg.setTemplateID("");
				mailMsg.setToAddresses(emailAddr);
				mailMsg.setCcAddresses(sendFAFCompletionEmail);
				mailMsg.setMsgSubject(msg.getSubject());
				mailMsg.setMsgContent(msgTxt.toString());				
				mailActivityAudit(mailMsg);
			}
			catch(MailException ex) {
			    // simply log it and go on...
			    log.error(ex);
			} catch (Exception e){
			    log.error(e);
			}
			finally {
			    try {
				if(rs!=null)
				    rs.close();
				if(stmt!=null)
				    stmt.close();
				if(conn!=null)
				    conn.close();

			    } catch (Exception e) {
				log.error(e);
			    }
			}
		    }

		}
	    }
	}
	catch (Exception e) {
	    log.error(e);
	} finally {
	    try {
		if(rs!=null)
		    rs.close();
		if(stmt!=null)
		    stmt.close();
		if(conn!=null)
		    conn.close();

	    } catch (Exception e) {
		log.error(e);
	    }

	}
    }

	private void mailActivityAudit(C3PARMailMessage mailMessageVO){
		log.info("TechnialArchitectureImpl ::mailActivityAudit");		
		try{
			MailModuleUtil util = new MailModuleUtil();
			util.mailActivityAudit(mailMessageVO);
		}catch(Exception ex){
			log.error(ex,ex);
		}
	}
}

@SuppressWarnings( { "unchecked" })
class IPPairXrefComparator implements Comparator
{
    // Compare two Strings. Callback for sort.
    // effectively returns a-b;
    // e.g. +1 (or any +ve number) if a > b
    // 0 if a == b
    // -1 (or any -ve number) if a < b
    public final int compare ( Object a, Object b )
    {
	ConnectionIPPairXref startIPPairXref = (ConnectionIPPairXref)a;
	ConnectionIPPairXref endIPPairXref = (ConnectionIPPairXref)b;
	return( (String)startIPPairXref.getId().toString() ).compareTo( (String)endIPPairXref.getId().toString() );
    } // end compare
} // end class IPPairXrefComparator