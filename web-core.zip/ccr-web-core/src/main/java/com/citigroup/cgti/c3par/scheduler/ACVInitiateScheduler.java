/**
 * 
 */
package com.citigroup.cgti.c3par.scheduler;

import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.acv.ProcessACV;


/**
 * @author mr89025
 *
 */

public class ACVInitiateScheduler {
	
	private static Logger log = Logger.getLogger(ACVInitiateScheduler.class);
	
	private ManageTIProcessImpl manageTIProcessImpl;
	
	private ProcessACV processACV;
	
	public ManageTIProcessImpl getManageTIProcessImpl() {
		return manageTIProcessImpl;
	}

	public void setManageTIProcessImpl(ManageTIProcessImpl manageTIProcessImpl) {
		this.manageTIProcessImpl = manageTIProcessImpl;
	}
	
	public ProcessACV getProcessACV() {
		return processACV;
	}

	public void setProcessACV(ProcessACV processACV) {
		this.processACV = processACV;
	}

	public void initiateACVProcess() {
		log.info("Entering ACVInitiateScheduler initiateACVProcess.");
		try {
			long tiProcessId = 0;
			List<String> ACVList = manageTIProcessImpl.getProcessesForACV();
			log.info("ACVInitiateScheduler : initiateACVProcess : size of ACVList :"+ACVList.size());
			
			//Following commented code for test purpose
			
			/*if(ACVList!=null && ACVList.get(0)!=null && (!"".equals(ACVList.get(0))))
				tiProcessId = Long.parseLong(ACVList.get(0));
			log.info("ACVInitiateScheduler : initiateACVProcess : ACV : tiProcessId :"+tiProcessId);
			processACV.intiateACVPhase(tiProcessId,"ACV");
			log.info("ACV Initiation Completed For tiProcessId :"+tiProcessId);
			boolean isACVFlagUpdated = processACV.updateACVFlag(tiProcessId,"Y");
			log.info("ACVInitiateScheduler : initiateACVProcess : isACVFlagUpdated :"+isACVFlagUpdated);
			processACV.completeACVPhase(tiProcessId,"AC81662");			
			*/
			 
			if(ACVList!=null && ACVList.size()>0)
			{
				for(String processId : ACVList)
				{
					if(processId!=null && (!"".equals(processId)))
					{
						tiProcessId = Long.parseLong(processId);
						log.info("ACVInitiateScheduler : initiateACVProcess : ACV : tiProcessId :"+tiProcessId);
						processACV.intiateACVPhase(tiProcessId,"ACV");
						log.info("ACV Initiation Completed for Process Id : "+tiProcessId);
					}
					
				}	
			}
			
			
			tiProcessId = 0;
			List<String> TEMPAPPList = manageTIProcessImpl.getProcessesForApprovalExpiration();
			log.info("ACVInitiateScheduler : initiateACVProcess : size of TEMPAPPList :"+TEMPAPPList.size());
			
			//Following commented code for test purpose
			
			/*if(TEMPAPPList!=null && TEMPAPPList.get(0)!=null && (!"".equals(TEMPAPPList.get(0))))
				tiProcessId = Long.parseLong(TEMPAPPList.get(0));
			log.info("ACVInitiateScheduler : initiateACVProcess : TEMPAPP : tiProcessId :"+tiProcessId);
			processACV.intiateACVPhase(tiProcessId,"TEMP_APP");
			log.info("Temp Approval Initiation Completed For tiProcessId :"+tiProcessId);
			processACV.completeACVPhase(tiProcessId,"AC81662");*/		
			
			 
			if(TEMPAPPList!=null && TEMPAPPList.size()>0)
			{
				for(String processId : TEMPAPPList)
				{
					if(processId!=null && (!"".equals(processId)))
					{
						tiProcessId = Long.parseLong(processId);
						log.info("ACVInitiateScheduler : initiateACVProcess : TEMPAPP : tiProcessId :"+tiProcessId);
						processACV.intiateACVPhase(tiProcessId,"TEMP_APP");
						log.info("Temp Approval Initiation Completed for Process Id : "+tiProcessId);
					}
					
				}	
			}
			
			
			
		} catch (Exception e) {
			log.error("Exception in ACVInitiateScheduler : initiateACVProcess :"+e);
			e.printStackTrace();
		}
		log.info("Exiting ACVInitiateScheduler initiateACVProcess.");
	}
	

}
