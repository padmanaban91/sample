package com.citigroup.cgti.c3par.model;


/**
 * The Class TIApplicationExtEntity.
 */
public class TIApplicationExtEntity extends TIApplicationEntity {


    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The app manager full name. */
    private	String	appManagerFullName;

    /** The app manager geid. */
    private	String	appManagerGEID;

    /** The app manager email. */
    private	String	appManagerEmail;

    /**
     * Gets the app manager full name.
     *
     * @return the app manager full name
     */
    public String getAppManagerFullName() {
	return appManagerFullName;
    }

    /**
     * Sets the app manager full name.
     *
     * @param appManagerFullName the new app manager full name
     */
    public void setAppManagerFullName(String appManagerFullName) {
	this.appManagerFullName = appManagerFullName;
    }

    /**
     * Gets the app manager geid.
     *
     * @return the app manager geid
     */
    public String getAppManagerGEID() {
	return appManagerGEID;
    }

    /**
     * Sets the app manager geid.
     *
     * @param appManagerGEID the new app manager geid
     */
    public void setAppManagerGEID(String appManagerGEID) {
	this.appManagerGEID = appManagerGEID;
    }

    /**
     * Gets the app manager email.
     *
     * @return the app manager email
     */
    public String getAppManagerEmail() {
	return appManagerEmail;
    }

    /**
     * Sets the app manager email.
     *
     * @param appManagerEmail the new app manager email
     */
    public void setAppManagerEmail(String appManagerEmail) {
	this.appManagerEmail = appManagerEmail;
    }
}
