package com.citigroup.cgti.c3par.fwpoc.domain;


import java.util.List;



public class FirewallRulepoc {
	
	 protected String sourceNetworkSegment;
	 protected String destinationNetworkSegment; 
	
	 protected Long id;
	 protected String transactionId;

	 private String fwLocation;

	 private String connectivityType;
	 private String sourceZone;
	 private String destinationZone;
	 private String policyGroup;
	 private String firewallPolicyname;
	 
	 private String ostiaQuestionStatus1;	
	 private String ostiaQuestionTextAnswer1;
	 private String ostiaQuestionSingleAnswer1;
	 private String ostiaQuestionOtherText1;
	 private String ostiaQuestionStatus2;	
	 private String ostiaQuestionTextAnswer2;
	 private String ostiaQuestionSingleAnswer2;
	 private String ostiaQuestionOtherText2;
	 private String ostiaQuestionTextAnswer3;
	 private List riskCheckFlags;
     private String sourceResourceType;
     private String targetResourceType;
     private String relationshipType;
	 private String tpa;
     private String broadAccess;
     private String thirdParty;
	 private List sourceIPs;
	 private List destinationIPs;
	 private List portNumbers;
	 private List protocols;
	 private List serviceNumbers;
	 
	 
	 private List otherPorts;
	 
	 private boolean otherPortExist;  
	  
	 public String getOstiaQuestionTextAnswer3() {
		return ostiaQuestionTextAnswer3;
	}

	public void setOstiaQuestionTextAnswer3(String ostiaQuestionTextAnswer3) {
		this.ostiaQuestionTextAnswer3 = ostiaQuestionTextAnswer3;
	}

	public String getSourceZone() {
		return sourceZone;
	}

	public void setSourceZone(String sourceZone) {
		this.sourceZone = sourceZone;
	}

	public String getDestinationZone() {
		return destinationZone;
	}

	public void setDestinationZone(String destinationZone) {
		this.destinationZone = destinationZone;
	}

	public String getPolicyGroup() {
		return policyGroup;
	}

	public void setPolicyGroup(String policyGroup) {
		this.policyGroup = policyGroup;
	}

	
	 

    public String getFirewallPolicyname() {
		return firewallPolicyname;
	}

	public void setFirewallPolicyname(String firewallPolicyname) {
		this.firewallPolicyname = firewallPolicyname;
	}

	public String getConnectivityType() {
		return connectivityType;
	}

	public void setConnectivityType(String connectivityType) {
		this.connectivityType = connectivityType;
	}

	/**
     * Gets the fw location.
     *
     * @return the fw location
     */
    public String getFwLocation() {
	return fwLocation;
    }

    /**
     * Sets the fw location.
     *
     * @param fwLocation the new fw location
     */
    public void setFwLocation(String fwLocation) {
	this.fwLocation = fwLocation;
    }
	    

	public String getSourceNetworkSegment() {
		return sourceNetworkSegment;
	}

	public void setSourceNetworkSegment(String sourceNetworkSegment) {
		this.sourceNetworkSegment = sourceNetworkSegment;
	}

	public String getDestinationNetworkSegment() {
		return destinationNetworkSegment;
	}

	public void setDestinationNetworkSegment(String destinationNetworkSegment) {
		this.destinationNetworkSegment = destinationNetworkSegment;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getOstiaQuestionStatus1() {
		return ostiaQuestionStatus1;
	}

	public void setOstiaQuestionStatus1(String ostiaQuestionStatus1) {
		this.ostiaQuestionStatus1 = ostiaQuestionStatus1;
	}

	public String getOstiaQuestionTextAnswer1() {
		return ostiaQuestionTextAnswer1;
	}

	public void setOstiaQuestionTextAnswer1(String ostiaQuestionTextAnswer1) {
		this.ostiaQuestionTextAnswer1 = ostiaQuestionTextAnswer1;
	}

	public String getOstiaQuestionSingleAnswer1() {
		return ostiaQuestionSingleAnswer1;
	}

	public void setOstiaQuestionSingleAnswer1(String ostiaQuestionSingleAnswer1) {
		this.ostiaQuestionSingleAnswer1 = ostiaQuestionSingleAnswer1;
	}

	public String getOstiaQuestionOtherText1() {
		return ostiaQuestionOtherText1;
	}

	public void setOstiaQuestionOtherText1(String ostiaQuestionOtherText1) {
		this.ostiaQuestionOtherText1 = ostiaQuestionOtherText1;
	}

	public String getOstiaQuestionStatus2() {
		return ostiaQuestionStatus2;
	}

	public void setOstiaQuestionStatus2(String ostiaQuestionStatus2) {
		this.ostiaQuestionStatus2 = ostiaQuestionStatus2;
	}

	public String getOstiaQuestionTextAnswer2() {
		return ostiaQuestionTextAnswer2;
	}

	public void setOstiaQuestionTextAnswer2(String ostiaQuestionTextAnswer2) {
		this.ostiaQuestionTextAnswer2 = ostiaQuestionTextAnswer2;
	}

	public String getOstiaQuestionSingleAnswer2() {
		return ostiaQuestionSingleAnswer2;
	}

	public void setOstiaQuestionSingleAnswer2(String ostiaQuestionSingleAnswer2) {
		this.ostiaQuestionSingleAnswer2 = ostiaQuestionSingleAnswer2;
	}

	public String getOstiaQuestionOtherText2() {
		return ostiaQuestionOtherText2;
	}

	public void setOstiaQuestionOtherText2(String ostiaQuestionOtherText2) {
		this.ostiaQuestionOtherText2 = ostiaQuestionOtherText2;
	}

	public List getSourceIPs() {
		return sourceIPs;
	}

	public void setSourceIPs(List sourceIPs) {
		this.sourceIPs = sourceIPs;
	}

	public List getDestinationIPs() {
		return destinationIPs;
	}

	public void setDestinationIPs(List destinationIPs) {
		this.destinationIPs = destinationIPs;
	}

	public List getPortNumbers() {
		return portNumbers;
	}

	public void setPortNumbers(List portNumbers) {
		this.portNumbers = portNumbers;
	}

	public List getProtocols() {
		return protocols;
	}

	public void setProtocols(List protocols) {
		this.protocols = protocols;
	}

	public List getServiceNumbers() {
		return serviceNumbers;
	}

	public void setServiceNumbers(List serviceNumbers) {
		this.serviceNumbers = serviceNumbers;
	}

	
	
	
	 public List getRiskCheckFlags() {
			return riskCheckFlags;
		}

		public void setRiskCheckFlags(List riskCheckFlags) {
			this.riskCheckFlags = riskCheckFlags;
		}

		public String getSourceResourceType() {
			return sourceResourceType;
		}

		public void setSourceResourceType(String sourceResourceType) {
			this.sourceResourceType = sourceResourceType;
		}

		public String getTargetResourceType() {
			return targetResourceType;
		}

		public void setTargetResourceType(String targetResourceType) {
			this.targetResourceType = targetResourceType;
		}

		public String getRelationshipType() {
			return relationshipType;
		}

		public void setRelationshipType(String relationshipType) {
			this.relationshipType = relationshipType;
		}

		public String getTpa() {
			return tpa;
		}

		public void setTpa(String tpa) {
			this.tpa = tpa;
		} 

		public String getBroadAccess() {
			return broadAccess;
		}

		public void setBroadAccess(String broadAccess) {
			this.broadAccess = broadAccess;
		}

		public String getThirdParty() {
			return thirdParty;
		}

		public void setThirdParty(String thirdParty) {
			this.thirdParty = thirdParty;
		}

		public boolean isOtherPortExist() {
			return otherPortExist;
		}

		public void setOtherPortExist(boolean otherPortExist) {
			this.otherPortExist = otherPortExist;
		}

		public List getOtherPorts() {
			return otherPorts;
		} 

		public void setOtherPorts(List otherPorts) {
			this.otherPorts = otherPorts;
		}	
	
		
		
}
