/**
 *
 */

package com.citigroup.cgti.c3par.secacl.service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.acl.domain.ACLVariance;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.secacl.domain.soc.persist.ManageAclVariancePersistable;

/**
 * The Class ACLVarianceDao.
 * 
 * @author bv93883
 */

@Transactional
public class ManageAclVarianceImpl extends BasePersistanceImpl implements ManageAclVariancePersistable {

	/** The log. */
	protected Logger log = Logger.getLogger(this.getClass().getName());

	@Override
	@Transactional(readOnly = true)
	public ACLVariance getACLVarianceData(TIProcess tiProcess) {
		ACLVariance aclVariance = new ACLVariance();
		Session session = getSession();
		try {
			Criteria crit = session.createCriteria(ACLVariance.class);
			crit.add(Restrictions.eq("tiRequest", tiProcess.getTiRequest()));
			aclVariance = (ACLVariance) crit.uniqueResult();
		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException(" There was an exception while ACLVariance for the given process ID::"+ tiProcess.getId());
		}
		return aclVariance;
	}
	
	@Override
	@Transactional(readOnly = true)
	public ACLVariance getACLVariance(TIProcess tiProcess) {
		ACLVariance aclVariance = new ACLVariance();
		Session session = getSession();
		try {
			Criteria crit = session.createCriteria(ACLVariance.class);

			crit.createCriteria("tiRequest", "tiRequest");
			crit.createCriteria("tiRequest.tiProcess", "tiProcess");
			crit.add(Restrictions.eq("tiProcess.id", tiProcess.getId()));
			crit.add(Restrictions.eq("tiRequest.versionNumber",tiProcess.getVersionNumber()));

			aclVariance = (ACLVariance) crit.uniqueResult();

		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException(
					" There was an exception while ACLVariance for the given process ID::"
							+ tiProcess.getId());
		}
		return aclVariance;
	}
	
	@Override
	public void storeACLVariance(ACLVariance aclVariance) {
		Long id = null;
		if (aclVariance == null || !(aclVariance instanceof ACLVariance)) {
			throw new ApplicationException(
					"The received object is not of required type ACLVariance");
		}
		Session session = getSession();
		try {

			if (aclVariance != null) {
				id = (Long) session.save(aclVariance);
			}
		} catch (ApplicationException e) {
			log.error(e, e);
			throw e;
		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException(
					" There was an exception while storing the ACLVariance with ACLVariance ID::"+ id);
		}
		log.info("ACLVarianceDao:storeACLVariance: Exiting with the ACLVariance with ACLVariance ID::" + id);
	}

	@Override
	public void deleteACLVariance(ACLVariance aclVariance) {
		int noRecordsDeleted = 0;
		if (aclVariance == null || !(aclVariance instanceof ACLVariance)) {
			throw new ApplicationException(
					"ACLVarianceDao:deleteACLVariance: The received object is not of required type ACLVariance is null");
		}
		Session session = getSession();
		Long processId = aclVariance.getTiProcess().getId();
		Long tiRequestId = aclVariance.getTiRequest().getId();
		try {
			String deleteQuery = "delete from ACLVariance where process_id = ? and ti_request_id = ? ";
			Query q = session.createQuery(deleteQuery).setLong(0, processId)
					.setLong(1, tiRequestId);
			noRecordsDeleted = q.executeUpdate();
		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException(
					" There was an exception while deleting acl Variance for the process ID::"
							+ processId + " and TiRequest Id ::" + tiRequestId);
		}
	}

	@SuppressWarnings("unchecked")
	public void updateACLVariance(ACLVariance aclVariance) {
		int noRecordsUpdated = 0;
		if (aclVariance == null || !(aclVariance instanceof ACLVariance)) {
			throw new ApplicationException(
					"ACLVarianceDao:deleteACLVariance: The received object is not of required type ACLVariance is null");
		}
		Session session = getSession();
		Long processId = aclVariance.getTiProcess().getId();
		Long tiRequestId = aclVariance.getTiRequest().getId();
		try {
			Criteria crit = session.createCriteria(ACLVariance.class);
			crit.add(Restrictions.eq("tiProcess", aclVariance.getTiProcess()));
			crit.add(Restrictions.eq("tiRequest", aclVariance.getTiRequest()));
			List<ACLVariance> aclVarianceList = crit.list();
			for (ACLVariance aclVar : aclVarianceList) {
				aclVar.setAcl_name(aclVariance.getAcl_name());
				aclVar.setAcl_device_routers(aclVariance.getAcl_device_routers());
				aclVar.setAcl_justification(aclVariance.getAcl_justification());
				aclVar.setUpdated_date((new Date()));
				session.update(aclVar);
				noRecordsUpdated++;
			}
		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException(
					" There was an exception while updating acl Variance for the process ID::"
							+ processId + " and TiRequest Id ::" + tiRequestId
							+ "aclVariance id ::" + aclVariance.getId());
		}
	}

}