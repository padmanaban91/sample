package com.citigroup.cgti.c3par.appsense.webtier.forms;

import java.util.ArrayList;
import java.util.List;

import com.citigroup.cgti.c3par.appsense.domain.AppsenseAAFCombination;
import com.citigroup.cgti.c3par.domain.BusinessDetails;


/**
 * The Class AAFReviewForm.
 */
@SuppressWarnings( { "unchecked" })
public class AAFReviewForm {

    /** The process id. */
    private Long processId;

    /** The request id. */
    private Long requestId;

    /** The business details. */
    private BusinessDetails businessDetails = new BusinessDetails();

    /** The combination list. */
    private List combinationList = new ArrayList();//List of AppsenseAAFCombination objects

    /** The version id. */
    private Long versionId;

    /** The fafqueue reqs. */
    private ArrayList fafqueueReqs = new ArrayList();

    /** The appsense types. */
    private String appsenseTypes;

    /** The appsense aaf combination. */
    private AppsenseAAFCombination appsenseAAFCombination =  new AppsenseAAFCombination();

    /** The aps spl instruction. */
    private String apsSplInstruction;

    /** The aps completion date. */
    private String apsCompletionDate;

    /** The aps infoman id. */
    private Long apsInfomanId;
    
    private String aafString;
    /**
     * Gets the version id.
     *
     * @return the version id
     */
    public Long getVersionId() {
	return versionId;
    }

    /**
     * Sets the version id.
     *
     * @param versionId the new version id
     */
    public void setVersionId(Long versionId) {
	this.versionId = versionId;
    }

    /**
     * Gets the combination list.
     *
     * @return the combination list
     */
    public List getCombinationList() {
	return combinationList;
    }

    /**
     * Sets the combination list.
     *
     * @param combinationList the new combination list
     */
    public void setCombinationList(List combinationList) {
	this.combinationList = combinationList;
    }

    /**
     * Gets the fafqueue reqs.
     *
     * @return the fafqueue reqs
     */
    public ArrayList getFafqueueReqs() {
	return fafqueueReqs;
    }

    /**
     * Sets the fafqueue reqs.
     *
     * @param fafqueueReqs the new fafqueue reqs
     */
    public void setFafqueueReqs(ArrayList fafqueueReqs) {
	this.fafqueueReqs = fafqueueReqs;
    }

    /**
     * Gets the process id.
     *
     * @return the process id
     */
    public Long getProcessId() {
	return processId;
    }

    /**
     * Sets the process id.
     *
     * @param processId the new process id
     */
    public void setProcessId(Long processId) {
	this.processId = processId;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public Long getRequestId() {
	return requestId;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(Long requestId) {
	this.requestId = requestId;
    }

    /**
     * Gets the business details.
     *
     * @return the business details
     */
    public BusinessDetails getBusinessDetails() {
	return businessDetails;
    }

    /**
     * Sets the business details.
     *
     * @param businessDetails the new business details
     */
    public void setBusinessDetails(BusinessDetails businessDetails) {
	this.businessDetails = businessDetails;
    }

    /**
     * Gets the appsense types.
     *
     * @return the appsense types
     */
    public String getAppsenseTypes() {
	return appsenseTypes;
    }

    /**
     * Sets the appsense types.
     *
     * @param appsenseTypes the new appsense types
     */
    public void setAppsenseTypes(String appsenseTypes) {
	this.appsenseTypes = appsenseTypes;
    }

    /**
     * Gets the aps spl instruction.
     *
     * @return the aps spl instruction
     */
    public String getApsSplInstruction() {
	return apsSplInstruction;
    }

    /**
     * Sets the aps spl instruction.
     *
     * @param apsSplInstruction the new aps spl instruction
     */
    public void setApsSplInstruction(String apsSplInstruction) {
	this.apsSplInstruction = apsSplInstruction;
    }

    /**
     * Gets the aps completion date.
     *
     * @return the aps completion date
     */
    public String getApsCompletionDate() {
	return apsCompletionDate;
    }

    /**
     * Sets the aps completion date.
     *
     * @param apsCompletionDate the new aps completion date
     */
    public void setApsCompletionDate(String apsCompletionDate) {
	this.apsCompletionDate = apsCompletionDate;
    }

    /**
     * Gets the aps infoman id.
     *
     * @return the aps infoman id
     */
    public Long getApsInfomanId() {
	return apsInfomanId;
    }

    /**
     * Sets the aps infoman id.
     *
     * @param apsInfomanId the new aps infoman id
     */
    public void setApsInfomanId(Long apsInfomanId) {
	this.apsInfomanId = apsInfomanId;
    }

    /**
     * Gets the appsense aaf combination.
     *
     * @return the appsense aaf combination
     */
    public AppsenseAAFCombination getAppsenseAAFCombination() {
	return appsenseAAFCombination;
    }

    /**
     * Sets the appsense aaf combination.
     *
     * @param appsenseAAFCombination the new appsense aaf combination
     */
    public void setAppsenseAAFCombination(
	    AppsenseAAFCombination appsenseAAFCombination) {
	this.appsenseAAFCombination = appsenseAAFCombination;
    }

	public void setAafString(String aafString) {
		this.aafString = aafString;
	}

	public String getAafString() {
		return aafString;
	}
}
