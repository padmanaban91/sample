package com.citigroup.cgti.c3par.gdw;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.citigroup.cgti.c3par.bpm.ejb.useradmin.GDWUser;

public class CitiContactUpdate {

	private JdbcTemplate jdbcTemplateCCR;
	private JdbcTemplate jdbcTemplateGDW;
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	Logger log = Logger.getLogger(this.getClass().getName());

	public void setJdbcTemplateCCR(JdbcTemplate jdbcTemplateCCR) {
		this.jdbcTemplateCCR = jdbcTemplateCCR;
	}

	public void setJdbcTemplateGDW(JdbcTemplate jdbcTemplateGDW) {
		this.jdbcTemplateGDW = jdbcTemplateGDW;
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplateGDW.getDataSource());
	}

	public void synchCCR_GDW() {
		try {
			long startTime = System.currentTimeMillis();
			List<String> ccrUserList = new ArrayList<String>();
			String activeCCRUsersQuery = "select distinct sso_id from citi_contact where  employee_status = 'A'";
			ccrUserList = jdbcTemplateCCR.queryForList(activeCCRUsersQuery,
					String.class);
			int noOfUsers = ccrUserList.size();
			log.info("active ccr users in citi contact -->"
					+ ccrUserList.size());
			int counter = 0;
			for (; counter <= noOfUsers;) {
				log.info("processing ccr users  -->from "
						+ counter
						+ "to "
						+ (((counter + 1000) > noOfUsers ? noOfUsers
								: counter + 999)));
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("ids", ccrUserList.subList(counter,
						((counter + 1000) > noOfUsers ? noOfUsers
								: counter + 999)));
				final ArrayList<GDWUser> employeesSelectedForUpdate = new ArrayList();
				final ArrayList<GDWUser> employeesSelectedForUpdateFinal = new ArrayList();
				StringBuffer query = new StringBuffer();
				query.append(" SELECT DISTINCT                                                                                                                 ");
				query.append("   e.soeid,                                                                                                                      ");
				query.append("   e.location_code a,                                                                                                            ");
				query.append("   e.firstname,                                                                                                                  ");
				query.append("   e.lastname,                                                                                                                   ");
				query.append("   e.rits_id,                                                                                                                    ");
				query.append("   e.phone,                                                                                                                      ");
				query.append("   e.email,                                                                                                                      ");
				query.append("   e.employee_class,                                                                                                             ");
				query.append("   e.geid,                                                                                                                       ");
				query.append("   e.employee_status,                                                                                                            ");
				query.append("   e.supervisor_geid,                                                                                                            ");
				query.append("   m.email     AS memail,                                                                                                        ");
				query.append("   m.geid      AS mgeid,                                                                                                         ");
				query.append("   m.firstname AS mfirstname,                                                                                                    ");
				query.append("   m.lastname  AS mlastname,                                                                                                     ");
				query.append("   GOC.MAN_SEG_ID ,                                                                                                              ");
				query.append("   e.GOC_CODE ,                                                                                                                  ");
				query.append("   GEO.MAN_GEOID_L2_ID                                                                                    AS Region_id ,         ");
				query.append("   GEO.MAN_GEOID_L2_NAME                                                                                  AS Region ,            ");
				query.append("   SEG.MAN_SEGID_L4_ID                                                                                    AS Sector_id,          ");
				query.append("   SEG.MAN_SEGID_L4_NAME                                                                                  AS Sector ,            ");
				query.append("   NVL(SEG.MAN_SEGID_L8_ID,NVL(SEG.MAN_SEGID_L7_ID,NVL(SEG.MAN_SEGID_L6_ID,SEG.MAN_SEGID_L5_ID)))         AS Business_Unit_id ,  ");
				query.append("   NVL(SEG.MAN_SEGID_L8_NAME,NVL(SEG.MAN_SEGID_L7_NAME,NVL(SEG.MAN_SEGID_L6_NAME,SEG.MAN_SEGID_L5_NAME))) AS Business_Unit       ");
				query.append(" FROM rdspr.gdw_user m ,                                                                                                         ");
				query.append("   rdspr.gdw_user e                                                                                                              ");
				query.append(" LEFT JOIN rdspr.D_DSMT_GOC GOC                                                                                                  ");
				query.append(" ON e.GOC_CODE = GOC.C_GOC_ID                                                                                                    ");
				query.append(" LEFT JOIN rdspr.D_DSMT_SEGMENT SEG                                                                                              ");
				query.append(" ON GOC.MAN_SEG_ID = SEG.MAN_SEGID                                                                                               ");
				query.append(" LEFT JOIN rdspr.D_DSMT_GEOGRAPHY GEO                                                                                            ");
				query.append(" ON GOC.MAN_GEO_ID      = GEO.MAN_GEOID                                                                                          ");
				query.append(" WHERE e.supervisor_geid=m.geid                                                                                                  ");
				query.append(" AND e.employee_status  ='A'                                                                                                     ");
				query.append(" AND e.soeid           IN (:ids)                                                                                                      ");
				
				//Old query
				//"select distinct e.soeid,e.location_code a,e.firstname,e.lastname,e.rits_id,e.phone,e.email,e.employee_class,e.geid,e.employee_status,e.supervisor_geid,m.email as memail,m.geid as mgeid,m.firstname as mfirstname,m.lastname as mlastname from  rdspr.gdw_user e ,rdspr.gdw_user m where  e.supervisor_geid=m.geid and e.employee_status='A' and e.soeid IN (:ids)",
				List<Map<String, Object>> rows = namedParameterJdbcTemplate.queryForList(query.toString(),	params);
				log.debug("rows Size: "+rows.size());
				for (Map row : rows) {
					GDWUser gdwUser = new GDWUser();
					gdwUser.setSoeid((String) row.get("soeid"));
					gdwUser.setLocation_code((String) row.get("location_code"));
					gdwUser.setFirstname((String) row.get("firstname"));
					gdwUser.setLastname((String) row.get("lastname"));
					gdwUser.setRits_id((String) row.get("rits_id"));
					gdwUser.setPhone((String) row.get("phone"));
					gdwUser.setEmail((String) row.get("email"));
					gdwUser.setEmployee_class((String) row
							.get("employee_class"));
					gdwUser.setGeid((String) row.get("geid"));
					gdwUser.setEmployee_status((String) row
							.get("EMPLOYEE_STATUS"));
					gdwUser.setSupervisor_geid((String) row
							.get("supervisor_geid"));
					gdwUser
							.setLatest_supervisor_geid((String) row
									.get("mgeid"));
					gdwUser.setSupervisor_firstname((String) row
							.get("mfirstname"));
					gdwUser.setSupervisor_lastname((String) row
							.get("mlastname"));
					gdwUser.setSupervisor_email((String) row.get("memail"));
					
					gdwUser.setManSegmentId((String) row.get("MAN_SEG_ID"));
					gdwUser.setGoc_code((String) row.get("GOC_CODE"));
					gdwUser.setDsmtRegionId((String) row.get("REGION_ID"));
					gdwUser.setDsmtRegionName((String) row.get("REGION"));
					gdwUser.setDsmtSectorId((String) row.get("SECTOR_ID"));
					gdwUser.setDsmtSectorName((String) row.get("SECTOR"));
					gdwUser.setDsmtBusinessUnitId((String) row.get("BUSINESS_UNIT_ID"));
					gdwUser.setDsmtBusinessUnitName((String) row.get("BUSINESS_UNIT"));
					log.debug("new values added."+gdwUser.getManSegmentId());
					employeesSelectedForUpdate.add(gdwUser);
					// log.info("adding gwd user  -->" + gdwUser.getSoeid());
				}
				for (String ssoidToUpdate : ccrUserList) {

					for (GDWUser user : employeesSelectedForUpdate) {
						if (user.getSoeid() != null
								&& user.getSoeid().equalsIgnoreCase(
										ssoidToUpdate)) {
							log.info("will be updating gwd user  -->"
									+ user.getSoeid());
							employeesSelectedForUpdateFinal.add(user);
						}
					}

				}
				if (employeesSelectedForUpdateFinal != null
						&& employeesSelectedForUpdate.size() > 0) {
					batchUpdateEmployees(employeesSelectedForUpdateFinal);
				}
				counter += 1000;
			}
			long estimatedTime = System.currentTimeMillis() - startTime;
			log.info("<estimatedTime>" + estimatedTime);
		} catch (DataAccessException e) {
			log.info("<CCR-GDW failed>" + e.getMessage());
			e.printStackTrace();
		}
	}

	private void batchUpdateEmployees(final List<GDWUser> employeeToBeUpdated) {

		String updateEmpStatusInCitiContactsQuery = "update citi_contact set location_id=?,first_name=?,last_name=?,rits_id=?,phone=?,email=?,geid=?,employee_status=?,"
				+ "supervisor_geid=?,supervisor_email=?,latest_supervisor_geid=?,supervisor_first_name=?,supervisor_last_name=?,"
				+ "GOC_CODE=?, MAN_SEGMENT_ID=?,DSMT_REGION_ID=?,DSMT_REGION_NAME=?,DSMT_SECTOR_ID=?,DSMT_SECTOR_NAME=?,DSMT_BUSINESS_UNIT_ID=?,DSMT_BUSINESS_UNIT_NAME=?,"
				+ "updated_date=sysdate where upper(sso_id)=(?)";

		try {
			// log.info("date "+employeeToBeUpdated.getBo_emp_term_date());

			int[] noofRowsUpdated = jdbcTemplateCCR.batchUpdate(
					updateEmpStatusInCitiContactsQuery,
					new BatchPreparedStatementSetter() {

						@Override
						public void setValues(PreparedStatement ps, int i)
								throws SQLException {
							ps.setString(1, employeeToBeUpdated.get(i)
									.getLocation_code());
							ps.setString(2, employeeToBeUpdated.get(i)
									.getFirstname());
							ps.setString(3, employeeToBeUpdated.get(i)
									.getLastname());
							ps.setString(4, employeeToBeUpdated.get(i)
									.getRits_id());
							ps.setString(5, employeeToBeUpdated.get(i)
									.getPhone());
							ps.setString(6, employeeToBeUpdated.get(i)
									.getEmail());
							ps.setString(7, employeeToBeUpdated.get(i)
									.getGeid());
							ps.setString(8, employeeToBeUpdated.get(i)
									.getEmployee_status());
							ps.setString(9, employeeToBeUpdated.get(i)
									.getSupervisor_geid());
							ps.setString(10, employeeToBeUpdated.get(i)
									.getSupervisor_email());
							ps.setString(11, employeeToBeUpdated.get(i)
									.getLatest_supervisor_geid());
							ps.setString(12, employeeToBeUpdated.get(i)
									.getSupervisor_firstname());
							ps.setString(13, employeeToBeUpdated.get(i)
									.getSupervisor_lastname());
							ps.setString(14, employeeToBeUpdated.get(i)
									.getGoc_code());
							ps.setString(15, employeeToBeUpdated.get(i)
									.getManSegmentId());
							ps.setString(16, employeeToBeUpdated.get(i)
									.getDsmtRegionId());
							ps.setString(17, employeeToBeUpdated.get(i)
									.getDsmtRegionName());
							ps.setString(18, employeeToBeUpdated.get(i)
									.getDsmtSectorId());
							ps.setString(19, employeeToBeUpdated.get(i)
									.getDsmtSectorName());
							ps.setString(20, employeeToBeUpdated.get(i)
									.getDsmtBusinessUnitId());
							ps.setString(21, employeeToBeUpdated.get(i)
									.getDsmtBusinessUnitName());
							
							//where condition value
							ps.setString(22, employeeToBeUpdated.get(i)
									.getSoeid());
						}

						@Override
						public int getBatchSize() {
							// TODO Auto-generated method stub
							return employeeToBeUpdated.size();
						}
					});
			log.info("Total number of rows update " + noofRowsUpdated.length);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 
	 * @param geID
	 * @return
	 */
	//Retrieve the level of contact from GDW database
		public int getContactLevel(String geID) {
			log.info("contact level ");
			int managerLevelValue = 0;
			String managerLevelQuery = "select max(LEVEL) from rdspr.gdw_user start with geid=? connect by nocycle prior supervisor_geid = geid";
			List<Map<String,Object>> managerLevel = jdbcTemplateGDW.queryForList(managerLevelQuery, geID);
			//return managerLevel!=null?managerLevel.size():0;
			if(managerLevel!=null){
				if(managerLevel.size()>0){
					managerLevelValue=((BigDecimal)managerLevel.get(0).get("max(level)")).intValueExact();	
				}
			}
			log.info("managerLevelValue  "+managerLevelValue);
			return managerLevelValue;
		}

		//Get the role id for director
		public int getRoleId() {
			log.info("role id for director ");
			int roleIDValue = 0;
			String managerLevelQuery = "select id from role where name='Director'";
			List<Map<String,Object>> roleID = jdbcTemplateCCR.queryForList(managerLevelQuery);
			//return roleID!=null?roleID.size():0;
			if(roleID!=null){
				if(roleID.size()>0){
					roleIDValue=((BigDecimal)roleID.get(0).get("id")).intValueExact();	
				}
			}
			log.info("roleIDValue  "+roleIDValue);
			return roleIDValue;
		}
}
