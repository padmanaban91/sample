package com.citigroup.cgti.c3par.fw.service;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import javax.xml.namespace.QName;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.citigroup.cgti.c3par.decisionservice.DecisionServiceCcrFwRiskRules;
import com.citigroup.cgti.c3par.decisionservice.DecisionServiceCcrFwRiskRulesImplService;
import com.citigroup.cgti.c3par.decisionservice.DecisionServiceRequest;
import com.citigroup.cgti.c3par.decisionservice.DecisionServiceResponse;
import com.citigroup.cgti.c3par.decisionservice.DecisionServiceSoapFault;
import com.citigroup.cgti.c3par.decisionservice.FirewallRule;
import com.citigroup.cgti.c3par.decisionservice.FirewallRuleDTO;
import com.citigroup.cgti.c3par.decisionservice.FlagDTO;
import com.citigroup.cgti.c3par.decisionservice.TiRequestDTO;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.soc.riskreview.RiskReviewExternalizable;
import com.citigroup.cgti.c3par.rules.service.RulesService;
import com.citigroup.cgti.c3par.util.C3parProperties;

public class RiskReviewBRMService 
					implements RiskReviewExternalizable {
	
	private static Logger log = Logger.getLogger(RiskReviewBRMService.class);
	
	private javax.xml.ws.Service rulesService;
	private DecisionServiceCcrFwRiskRules rulesDecision;
	
	@Autowired
	private FirewallRuleMapper firewallRuleMapper;
	
	@Autowired
	private FirewallRuleDroolsMapper firewallRuleDroolsMapper;
	
	@Autowired
	private RulesService droolsRulesService;
	
	@Autowired
	private RuleFlagProviderProperties ruleFlagProviderProperties;
	
	boolean droolsEnabled=false;
	
	public HashMap<String, OstiaQuestionnaire> executeRiskRules(FireWallRule fireWallRule, TiRequestDTO tiRequestDTO, Long tiRequestId) throws DecisionServiceSoapFault {
		
	 HashMap<String, OstiaQuestionnaire> ostiaQuestionnaire =null;
	
	 
	 String ruleflag = getRuleFlagProviderProperties().getRuleproviderflag();
	 log.debug("executeRiskRules method "+ruleflag);
	 if(ruleflag==null || ("iLog".equalsIgnoreCase(ruleflag))){
		    log.debug("Using Team Server");
			URL wsdlLocation = null;
			try {
				wsdlLocation = new URL(C3parProperties.RULE_EXECUTION_SERVER_ENDPOINT);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			QName serviceName = new QName(C3parProperties.RULE_EXECUTION_SERVER_NAMESPACE, 
						C3parProperties.RULE_EXECUTION_SERVER_SERVICENAME);
			//DecisionServiceCcrFwRiskRules_Service.
			this.rulesService = new DecisionServiceCcrFwRiskRulesImplService(wsdlLocation, serviceName);
			rulesDecision = rulesService
					.getPort(DecisionServiceCcrFwRiskRules.class);
			FirewallRuleDTO firewallRuleDTO =  firewallRuleMapper.convertFirewallRuleToFirewallRuleDTO(fireWallRule, tiRequestDTO, tiRequestId);
			
			DecisionServiceRequest decisionRequest = new DecisionServiceRequest();
			FirewallRule firewallRule = new FirewallRule();
			decisionRequest.setFirewallRule(firewallRule);
			firewallRule.setFirewallRule(firewallRuleDTO);
	
			DecisionServiceResponse response = rulesDecision
					.executeDecisionService(decisionRequest);
			FirewallRuleDTO outputFirewallRuleDTO = response.getFirewallRule()
					.getFirewallRule();
			ostiaQuestionnaire =  firewallRuleMapper.convertFirewallRuleDTOToFirewallRule(outputFirewallRuleDTO);
		} else{
		    log.debug("Using Drools Server");
			com.citigroup.cgti.c3par.rules.model.TiRequestDTO tiRequest=convertTODroolsTiRequestDto(tiRequestDTO);
		    com.citigroup.cgti.c3par.rules.model.FirewallRuleDTO  firewallRuleDTO =  firewallRuleDroolsMapper.convertFirewallRuleToFirewallRuleDTO(fireWallRule, tiRequest, tiRequestId);
		    droolsRulesService.executeRules(firewallRuleDTO);
		    ostiaQuestionnaire= firewallRuleDroolsMapper.convertFirewallRuleDTOToFirewallRule(firewallRuleDTO);
		}
		return ostiaQuestionnaire;
	
    }
	private com.citigroup.cgti.c3par.rules.model.TiRequestDTO  convertTODroolsTiRequestDto(TiRequestDTO tiRequestDTO){
		com.citigroup.cgti.c3par.rules.model.TiRequestDTO  tiRequest=new com.citigroup.cgti.c3par.rules.model.TiRequestDTO();
		tiRequest.setBusinessUnit(tiRequestDTO.getBusinessUnit());
		tiRequest.setConnectionType(tiRequestDTO.getConnectionType());
		//tiRequest.setOstiaQuestionnaires(tiRequestDTO.getOstiaQuestionnaires());
		tiRequest.setRegion(tiRequestDTO.getRegion());
		tiRequest.setRelationshipType(tiRequestDTO.getRelationshipType());
		tiRequest.setRequestPriority(tiRequestDTO.getRequestPriority());
		tiRequest.setSourceResourceType(tiRequestDTO.getSourceResourceType());
		tiRequest.setTargetResourceType(tiRequestDTO.getTargetResourceType());
		tiRequest.setThirdParty(tiRequestDTO.getThirdParty());
		tiRequest.setUturnThirdParty(tiRequestDTO.getUturnThirdParty());
		for(FlagDTO flagDto:tiRequestDTO.getRiskCheckFlags()){
			com.citigroup.cgti.c3par.rules.model.FlagDTO droolsFlagDto=new com.citigroup.cgti.c3par.rules.model.FlagDTO();
			droolsFlagDto.setKey(flagDto.getKey());
			droolsFlagDto.setValue(flagDto.getValue());
			droolsFlagDto.setTiRequest(true);
			tiRequest.getRiskCheckFlags().add(droolsFlagDto);
		}
		return tiRequest;
	}
	 public RuleFlagProviderProperties getRuleFlagProviderProperties() {
		return ruleFlagProviderProperties;
	 }

	public void setRuleFlagProviderProperties(RuleFlagProviderProperties ruleFlagProviderProperties) {
		this.ruleFlagProviderProperties = ruleFlagProviderProperties;
	}
}
