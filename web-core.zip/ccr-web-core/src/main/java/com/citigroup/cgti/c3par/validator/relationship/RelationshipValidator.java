package com.citigroup.cgti.c3par.validator.relationship;

import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.relationship.domain.RelCitiContXref;
import com.citigroup.cgti.c3par.relationship.domain.RelReqCitiContactXref;
import com.citigroup.cgti.c3par.relationship.domain.RelThirdPartyContXref;

public class RelationshipValidator {

	/** The log. */
	private static Logger log = Logger.getLogger(RelationshipValidator.class);
	
    public boolean isUTurnCitiContactExist(List<RelReqCitiContactXref> reqContactList, List<RelCitiContXref> tarContactList){
		boolean isISORoleExist = false;
		boolean isDERoleExist = false;
		boolean isEmployee=false;
		
		boolean reqContactExists = false;
		boolean tarContactExists = false;
		com.citigroup.cgti.c3par.webtier.helper.Util relationCheck = new com.citigroup.cgti.c3par.webtier.helper.Util();
		
		log.debug("RelationshipValidator :: isUTurnCitiContactExist");
		
		if(reqContactList != null && !reqContactList.isEmpty()){
			log.debug("RelationshipValidator :: isUTurnCitiContactExist :: requester contacts");
			
			for(RelReqCitiContactXref reqContact:reqContactList){
		
				if(reqContact.getRole().getName() != null && reqContact.getRole().getName().equalsIgnoreCase("DESIGN ENGINEER")){
				    try {
				    	isEmployee=relationCheck.isISO_TCPresent(reqContact.getContactId().getRitsId());
				    } catch (Exception e) {
				    	log.error(e, e);
				    }
				    if(isEmployee){
				    	isDERoleExist = true;
				    }				    
				}
				if(reqContact.getRole().getName() != null && reqContact.getRole().getName().equalsIgnoreCase("BISO")){
				    try {
				    	isEmployee=relationCheck.isISO_TCPresent(reqContact.getContactId().getRitsId());
				    } catch (Exception e) {
				    	log.error(e, e);
				    }
				    if(isEmployee){
				    	isISORoleExist = true;
				    }
				}
			    if(isDERoleExist && isISORoleExist){
			    	reqContactExists = true;
			    }
			}
		}

		if(tarContactList != null && !tarContactList.isEmpty()){
			log.debug("RelationshipValidator :: isUTurnCitiContactExist :: target contacts");
			
			for(RelCitiContXref tarContact:tarContactList){
		
				if(tarContact.getRole().getName() != null && tarContact.getRole().getName().equalsIgnoreCase("DESIGN ENGINEER")){
				    try {
				    	isEmployee=relationCheck.isISO_TCPresent(tarContact.getContactId().getRitsId());
				    } catch (Exception e) {
				    	log.error(e, e);
				    }
				    if(isEmployee){
				    	isDERoleExist = true;
				    }
				}
				if(tarContact.getRole().getName() != null && tarContact.getRole().getName().equalsIgnoreCase("BISO")){
				    try {
				    	isEmployee=relationCheck.isISO_TCPresent(tarContact.getContactId().getRitsId());
				    } catch (Exception e) {
				    	log.error(e, e);
				    }
				    if(isEmployee){
				    	isISORoleExist = true;
				    }
				}
			    if(isDERoleExist && isISORoleExist){
			    	tarContactExists = true;
			    }
			}
		}

		log.debug("RelationshipValidator :: isUTurnCitiContactExist :: reqContactExists - "+reqContactExists+" :: tarContactExists - "+tarContactExists);
		return (reqContactExists || tarContactExists);
    }

    public boolean isCitiContactExist(List<RelReqCitiContactXref> reqContactList, List<RelCitiContXref> tarContactList){

		boolean reqContactExists = false;
		boolean tarContactExists = false;

		log.debug("RelationshipValidator :: isCitiContactExist");
		
		if(reqContactList != null && !reqContactList.isEmpty()){
			log.debug("RelationshipValidator :: isCitiContactExist :: requester contacts");

			for(RelReqCitiContactXref reqContact:reqContactList){
				reqContactExists = true;
			}
		}
		if(tarContactList != null && !tarContactList.isEmpty()){
			log.debug("RelationshipValidator :: isCitiContactExist :: target contacts");

			for(RelCitiContXref tarContact:tarContactList){
				tarContactExists = true;
			}
		}

		log.debug("RelationshipValidator :: isCitiContactExist :: reqContactExists - "+reqContactExists+" :: tarContactExists - "+tarContactExists);
		return (reqContactExists || tarContactExists);
    }

    public boolean isThirdPartyContactExist(List<RelThirdPartyContXref> relTPConXref, Long tpId){
		log.debug("RelationshipValidator :: isThirdPartyContactExist :: starts");
		boolean isContactExists = false;
		if(tpId != null && relTPConXref != null && !relTPConXref.isEmpty()){
		    for(RelThirdPartyContXref tpcont:relTPConXref){
		    	isContactExists = true;
		    }
		}
		return isContactExists;
    }

    public boolean isISOCitiContactExist(List<RelReqCitiContactXref> reqContactList, List<RelCitiContXref> tarContactList){
		boolean isISORoleExist = false;
		boolean isEmployee=false;
	
		com.citigroup.cgti.c3par.webtier.helper.Util relationCheck = new com.citigroup.cgti.c3par.webtier.helper.Util();

		boolean reqContactExists = false;
		boolean tarContactExists = false;

		log.debug("RelationshipValidator :: isISOCitiContactExist");
		
		if(reqContactList != null && !reqContactList.isEmpty()){
			log.debug("RelationshipValidator :: isISOCitiContactExist :: requester contacts");
			
			for(RelReqCitiContactXref reqContact:reqContactList){
							
				if(reqContact.getRole().getName() != null && reqContact.getRole().getName().equalsIgnoreCase("BISO")){
				    try {
				    	isEmployee=relationCheck.isISO_TCPresent(reqContact.getContactId().getRitsId());
				    } catch (Exception e) {
				    	log.error(e, e);
				    }
				    
				    if(isEmployee){
				    	isISORoleExist = true;
				    }
				}
		
			    if(isISORoleExist){
			    	reqContactExists = true;
			    }
			}
		}

		if(tarContactList != null && !tarContactList.isEmpty()){
			log.debug("RelationshipValidator :: isISOCitiContactExist :: target contacts");
			
			for(RelCitiContXref tarContact:tarContactList){
							
				if(tarContact.getRole().getName() != null && tarContact.getRole().getName().equalsIgnoreCase("BISO")){
				    try {
				    	isEmployee=relationCheck.isISO_TCPresent(tarContact.getContactId().getRitsId());
				    } catch (Exception e) {
				    	log.error(e, e);
				    }
				    
				    if(isEmployee){
				    	isISORoleExist = true;
				    }
				}
		
			    if(isISORoleExist){
			    	tarContactExists = true;
			    }
			}
		}

		log.debug("RelationshipValidator :: isISOCitiContactExist :: reqContactExists - "+reqContactExists+" :: tarContactExists - "+tarContactExists);
		return (reqContactExists || tarContactExists);
    }

}