package com.citigroup.cgti.c3par.reports.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.reports.domain.GenericReport;
import com.citigroup.cgti.c3par.reports.domain.GenericReportProcess;
import com.citigroup.cgti.c3par.reports.domain.soc.persist.GenericReportServicePersistable;
@Transactional
public class GenericReportServiceImpl extends BasePersistanceImpl implements
		GenericReportServicePersistable {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@Override
	@Transactional(readOnly = true)
	public List<GenericReport> getReportList(GenericReportProcess reportProcess) {

		log.debug("Entering into getReportList()..");

		Session session = getSession();

		String sql = "(SELECT ID, NAME FROM REPORT_META where REPORTS_PACKAGE_ID = (select id from rep_package "
				+ "where name = '"
				+ reportProcess.getPackageName()
				+ "') and (is_Deleted = 'N' or is_Deleted = 'n') and (USER_ID = 'ALL' or USER_ID = '"
				+ reportProcess.getRemoteUser()
				+ "'))"
				+ "UNION"
				+ "(SELECT REPORT_META.ID, REPORT_META.NAME FROM REPORT_META,c3parUsers_Report_xref where REPORTS_PACKAGE_ID = (select id from rep_package "
				+ "where name = '"
				+ reportProcess.getPackageName()
				+ "') and REPORT_META.ID = c3parUsers_Report_xref.REPORT_ID"
				+ " AND (is_Deleted = 'N' or is_Deleted = 'n') AND (c3parUsers_Report_xref.USER_ID IN (SELECT id from c3par_users where SSO_ID = '"
				+ reportProcess.getRemoteUser() + "')))";

		@SuppressWarnings("unchecked")
		List<Object[]> list = session.createSQLQuery(sql).list();

		if (list != null)
			log.debug("ReportServiceImpl :: getReportList :: size ::"
					+ list.size());

		List<GenericReport> genericReportList = null;
		genericReportList = new ArrayList<GenericReport>();

		// In the object array, index 0 is 'ID' and index 1 is 'report name'.

		for (Object[] obj : list) {

			GenericReport reportObj = new GenericReport();
			reportObj.setId(obj[0].toString());
			reportObj.setName(obj[1].toString());
			genericReportList.add(reportObj);

		}

		log.debug("Exit from getReportList()..");
		return genericReportList;
	}
	

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<String> getReportColumnNames(Long reportId) {

		List<String> columnNamesList = new ArrayList<String>();

		String sqlQuery = "select Name from REPORT_COLUMN_META where DATA_SOURCE_ID=(select source_id from REPORT_META where id="
				+ reportId + ")";
		
		log.debug("sqlQuery :"+sqlQuery);

		Session session = getSession();		

		columnNamesList =  session.createSQLQuery(sqlQuery).list();		
		
		log.debug("columnNamesList: "+columnNamesList);

		return columnNamesList;
	}
	
	@Transactional(readOnly = true)
	public List<Object[]> getReportData(Long reportId){	
		

		String sqlForQuery = "select statement from ds_sql_statement where id=(select source_id from REPORT_META where id="+reportId+ ")";;
		
		log.debug("sqlForQuery :"+sqlForQuery);
		
		Session session = getSession();

		@SuppressWarnings("unchecked")
		String sqlForData = session.createSQLQuery(sqlForQuery).list().get(0).toString()+" where rownum <= 65500";
		
		log.debug("The sqlForData :"+sqlForData);
		
		@SuppressWarnings("unchecked")
		List<Object[]> list = session.createSQLQuery(sqlForData).list();

		if (list != null)
			log.debug("ReportServiceImpl :: getReportData :: size ::"
					+ list.size());
		
		return list;
	}

}
