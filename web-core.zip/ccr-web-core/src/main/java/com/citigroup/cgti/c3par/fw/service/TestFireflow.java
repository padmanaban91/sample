/*package com.citigroup.cgti.c3par.fw.service;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import com.citigroup.cgti.c3par.fw.domain.soc.fireflow.FireflowExternalizable;
import com.citigroup.cgti.c3par.fw.fireflow.WebClientWrapper;

public class TestFireflow {

	*//**
	 * @param args
	 *//*
	public static void main(String[] args) {
		System.out.println("test 1");
		postTicket();
		System.out.println("test complete");

	}
	
	
	private static FAF_FireFlowTicket getFireFlowService() {
		ApplicationContext ctx = new FileSystemXmlApplicationContext("/c3parWebApp/WEB-INF/applicationContextFireflow.xml");
		FireFlowService svc = (FireFlowService) ctx.getBean("fireflowService");
		return svc;
	}
	
	public static void postTicket() {


		String fireflowTicketSubject = "123" + "." + "1" + "-Test";
		
		
		
	 		String taskResource = "ticket/new";

	 		String query = "?user=sb47760&pass=sb47760";
	 		//String query = "?user=ccrffsys&pass=!Alg0$3c!";
	 		//String query = "?user={user}&pass=Eg4ds!@";
			String content = "Queue: 1\n"+
			 "Owner: sb47760\n"+
			 "Creator: sb47760\n"+
			 "Subject: "+ fireflowTicketSubject +"\n"+
			 "Requestor: girish.shahri@citi.com\n" +	        		                                               
			 "Cc: venkateswara.atla@citi.com\n" +
			 "CF.{connectionId}: "+ "123" +"\n" +
			 "CF.{requestId}: "+ "12345" + "\n" +
				 "CF.{Requested Source}: 10.0.0.20\n"+
				"CF.{Requested Destination}: 10.0.5.20\n"+
				 "CF.{Requested Service}: TCP/20000\n"+
				 "CF.{Requested Action}: Allow\n"+

			 "CF.{Requested Category}: EMEA_B2B_InCountry\n";+ticket.getPolicyGroup().getName()+
				 
			 "CF.{Category}: EMEA_B2B_InCountry\n"+
			// "CF.{Traffic tuples}: "+trafficTuples;
			 "CF.{Traffic tuples}: 172.16.1.5;172.16.0.5;tcp/55000;Allow";
			

	 		try {
	 			StringBuffer url = new StringBuffer();
	 			url.append("https://10.154.220.85");
	 			url.append(":");
	 			url.append("443");
	 			url.append("/");
	 			url.append("FireFlow/REST");
	 			url.append("/");
	 			url.append("1.0");
	 			url.append("/");
	 			url.append(taskResource);
	 			//url.append("/");
	 			//url.append(query);
	 			
	 			URI uri = new URI(url.toString());
	 			
	 			HttpContext localContext = new BasicHttpContext();
	 	    	HttpPost httpPost = new HttpPost(uri);
	 	    	DefaultHttpClient httpclient = (DefaultHttpClient) WebClientWrapper.wrapClient(new DefaultHttpClient());
	 	    	
			

				
				List<BasicNameValuePair> nameValuePairs = new ArrayList<BasicNameValuePair>();
	 	        //nameValuePairs.add(new BasicNameValuePair("user", "ccrffsys"));
		        //nameValuePairs.add(new BasicNameValuePair("pass", "Eg4ds!@"));
		        //nameValuePairs.add(new BasicNameValuePair("pass", "!Alg0$3c!"));
				
	 	        nameValuePairs.add(new BasicNameValuePair("user", "sb47760"));
		        nameValuePairs.add(new BasicNameValuePair("pass", "sb47760"));

		        
		        nameValuePairs.add(new BasicNameValuePair("content",content));
		        
	 			System.out.println("url -->"+url);
	  			
	 			httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs)); 

	 			HttpResponse response = httpclient.execute(httpPost, localContext);
	 	        HttpEntity entity = (HttpEntity) response.getEntity();

	 	        BufferedHttpEntity responseEntity = new BufferedHttpEntity((HttpEntity) entity);
		        
		       String result = EntityUtils.toString(responseEntity); 	 			
		       System.out.println("--Response-------:"+result);
	 			
		       String ticketId = result.substring(result.indexOf("# Ticket") + 9, result.indexOf("created."));
		       
		       System.out.println("--ticketId-------:"+ticketId);
		       //getFFTicketDetails(ticketId.trim());
			
}catch(HttpClientErrorException httpExp){
    System.out.println(httpExp);
    System.out.println("Exception Occured... - " +httpExp.getMessage());
		httpExp.printStackTrace();
		
	}catch(RestClientException  res){
	    System.out.println(res);
	    System.out.println("Exception Occured... - " + res.getMessage());
      res.printStackTrace();
	}
	catch (Exception e) {
	    System.out.println(e);
	    System.out.println("Exception Occured... - " + e.getMessage());
		e.printStackTrace();
	}
			
			
	}
	private static FireflowExternalizable getFireFlowService() {
		ApplicationContext ctx = new FileSystemXmlApplicationContext("/c3parWebApp/WEB-INF/applicationContextFireflow.xml");
		FireflowExternalizable svc = (FireflowExternalizable) ctx.getBean("fireflowExternalizable");
		//FireFlowService svc = (FireFlowService) ctx.getBean("fireflowService");
		return svc;
	}
	

}*/