package com.citigroup.cgti.c3par.search.domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import com.citigroup.cgti.c3par.bpm.ejb.search.domain.Process;

public class SearchToExcelReport { 
	
	private JdbcTemplate jdbcTemplate;
	private final SimpleDateFormat formater = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss aa");
	private String htmlContent;
	
	
	
	public String getSearchResults (String query) {
		//GenericSearchHandler handler = new GenericSearchHandler();
		//jdbcTemplate.query(query, handler);
		//return handler.getSearchResults();
		
		return htmlContent;
	}


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	private class GenericSearchHandler implements RowCallbackHandler {
		
		private StringBuilder searchResults = new StringBuilder();
		
		public String getSearchResults () {
			return searchResults.toString();
		}

		@Override
		public void processRow(ResultSet rs) throws SQLException {
			Process processObj = new Process();
			processObj.setId(Long.valueOf(rs.getLong(1)));
			processObj.setVersion_number(Long.valueOf(rs.getLong(2)));
			processObj.setDisplay_id(rs.getString(3));
			processObj.setName(rs.getString(4));
			processObj.setStatus(rs.getString(5));
			processObj.setPhase(rs.getString(6));
			processObj.setType(rs.getString(7));
			processObj.setTiProcess(rs.getString(8));
			processObj.setRole(rs.getString(9));
			processObj.setPriority(rs.getString(10));
			processObj.setParticipant(rs.getString(11));
			processObj.setTirequestid(Long.valueOf(rs.getLong(12)));
			processObj.setBmpInstanceId(rs.getString(13));
			processObj.setBpmActivityId(rs.getString(14));
			processObj.setTaskName(rs.getString(15));
			processObj.setBpmProcessName(rs.getString(16));
			processObj.setTaskCode(rs.getString(17));
			
			searchResults.append("62283.1 Business Justification	Planning	NEW	  Connection	BAU	RK52645" ); // TODO  Convert to meaningful Excel row
			
			
			
			  //	ID	    Name	Activity                	Phase	Type	TIProcess	Priority	Participant
	 		//	62283.1	PC_2121	  Business Justification	Planning	NEW	  Connection	BAU	RK52645
			
		     //  rs.getString(1) - ID
 		     //  rs.getString(2), - Name
 		     //  rs.getString(6) - Phase
 		     //  rs.getString(7) - Type
 		     //  rs.getString(10) - Priority
 	         //  rs.getString(11)) - Participant
 		     //  rs.getString(14))	 

		}
		

	/*	private Object createMyTasksModel(ResultSet rs) throws DatabaseException, SQLException {
			Process processObj = new Process();
			processObj.setDisplay_id(rs.getString(1));
			processObj.setName(rs.getString(2));
			processObj.setTirequestid(Long.valueOf(rs.getLong(3)));
			processObj.setBmpInstanceId(rs.getString(4));
			processObj.setBpmActivityId(rs.getString(5));
			processObj.setTaskName(rs.getString(6));
			processObj.setActivityCode(rs.getString(7));
 			if(rs.getTimestamp(8)!= null) processObj.setLockedDate(formater.format(rs.getTimestamp(8)));
			
 		//	ID	    Name	Activity                	Phase	Type	TIProcess	Priority	Participant
 		//	62283.1	PC_2121	Business Justification	Planning	NEW	  Connection	BAU	RK52645

 			
 			 //  rs.getString(1) - ID
		     //  rs.getString(2), - Name
		     //  rs.getString(6) - Phase
		     //  rs.getString(7) - Type
		     //  rs.getString(10) - Priority
	         //  rs.getString(11)) - Participant
		     //  rs.getString(14))	
 			
			return processObj;
		}
		
		
		private Object createMyContactTasksModel(ResultSet rs) throws DatabaseException, SQLException {
			Process processObj = new Process();
			processObj.setId(rs.getLong(1));
			processObj.setDisplay_id(rs.getString(1));
			processObj.setName(rs.getString(2));
			processObj.setTaskName(rs.getString(3));
			processObj.setStatus(rs.getString(4));
			if(rs.getTimestamp(5)!= null) processObj.setLockedDate(formater.format(rs.getTimestamp(5)));
			processObj.setPriority(rs.getString(6));
			processObj.setBmpInstanceId(rs.getString(7));
			processObj.setBpmActivityId(rs.getString(8));
			processObj.setTaskCode(rs.getString(9));
			processObj.setPhase(rs.getString(10));
			processObj.setTirequestid(rs.getLong(11));
			processObj.setTiProcess(rs.getString(12));
			processObj.setRole(rs.getString(13));
			processObj.setTimeInActivity(rs.getLong(14));
			return processObj;
		}*/
		
	}


	public String getHtmlContent() {
		return htmlContent;
	}


	public void setHtmlContent(String htmlContent) {
		this.htmlContent = htmlContent;
	}

	
	 

}
