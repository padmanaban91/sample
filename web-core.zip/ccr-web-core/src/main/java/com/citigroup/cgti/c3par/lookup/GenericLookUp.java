/*
 * Created on Aug 4, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.lookup;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.ip.dao.IPRegDetailDAO;
import com.citigroup.cgti.c3par.model.BusinessUnitEntity;

import org.apache.log4j.Logger;
import com.citigroup.cgti.c3par.domain.Region;
import com.mentisys.dao.DatabaseException;
import com.citigroup.cgti.c3par.domain.LookUpVO;

import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;
import com.citigroup.cgti.c3par.dao.ProgressBarDAO;
import com.citigroup.cgti.c3par.model.ProgressBarEntity;


/**
 * The Class GenericLookUp.
 *
 * @author nu29793
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GenericLookUp
{

    /** The c3par session. */
    private C3parSession c3parSession;

    //Table Names
    /** The REGIO n_ table. */
    public  String	REGION_TABLE = "REGION";

    /** The BUSNIES s_ uni t_ table. */
    public String   BUSNIESS_UNIT_TABLE = "BUSINESS_UNIT";

    /** The GENERI c_ looku p_ table. */
    public String   GENERIC_LOOKUP_TABLE = "GENERIC_LOOKUP";

    /** The SECURIT y_ rol e_ table. */
    public String   SECURITY_ROLE_TABLE = "SECURITY_ROLE";

    //Database connection details
    /** The con. */
    Connection con=null;

    /** The stmt. */
    PreparedStatement stmt=null;

    /** The rs. */
    ResultSet rs=null;

    //object and list
    /** The obj. */
    LookUpVO obj=null;

    /** The data. */
    String data="";

    /** The obj list. */
    ArrayList objList=null;

    //Logger
    /** The log. */
    Logger log = Logger.getLogger(this.getClass().getName());


    /**
     * Gets the region type.
     *
     * @return the region type
     * @throws Exception the exception
     */
    public ArrayList getRegionType() throws Exception{

	try{
	    StringBuffer sql=new StringBuffer("select ID,NAME from ");
	    sql.append(REGION_TABLE);
	    sql.append(" WHERE LOWER(IS_ACTIVE) = LOWER('y') ");
	    //			  	objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }

    /**
     * Gets the iP business unit type.
     *
     * @return the iP business unit type
     * @throws Exception the exception
     */
    public ArrayList getIPBusinessUnitType() throws Exception{

	try{
	    StringBuffer sql=new StringBuffer("select ID,VALUE1 from ");
	    sql.append(GENERIC_LOOKUP_TABLE);
	    sql.append(" WHERE DEFINITION_ID = 25 ");
	    //				  	objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }

    /**
     * Gets the iP connection type.
     *
     * @return the iP connection type
     * @throws Exception the exception
     */
    public ArrayList getIPConnectionType() throws Exception{

	try{
	    StringBuffer sql=new StringBuffer("select ID,VALUE1 from ");
	    sql.append(GENERIC_LOOKUP_TABLE);
	    sql.append(" WHERE DEFINITION_ID = 24 ");

	    //				  	objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }


    /**
     * Gets the connection bandwidth.
     *
     * @return the connection bandwidth
     * @throws Exception the exception
     */
    public ArrayList getConnectionBandwidth() throws Exception{

	try{
	    StringBuffer sql=new StringBuffer("select ID,VALUE1 from ");
	    sql.append(GENERIC_LOOKUP_TABLE);
	    sql.append(" WHERE DEFINITION_ID = 22 ");

	    //			  	objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }



    /**
     * Gets the iP roles.
     *
     * @return the iP roles
     * @throws Exception the exception
     */
    public ArrayList getIPRoles() throws Exception{

	try{
	    /*	StringBuffer sql=new StringBuffer("select ID,NAME FROM ");
				  	sql.append(SECURITY_ROLE_TABLE);
				  	sql.append("  WHERE ID=15 OR ID=6 OR ID=16 OR ID=20 ");*/
	    StringBuffer sql=new StringBuffer("select id,name from role where citi='Y'");
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }

    /**
     * Gets the iP business reason.
     *
     * @return the iP business reason
     * @throws Exception the exception
     */
    public ArrayList getIPBusinessReason() throws Exception{

	try{
	    StringBuffer sql=new StringBuffer("select ID,VALUE1 from ");
	    sql.append(GENERIC_LOOKUP_TABLE);
	    sql.append(" WHERE DEFINITION_ID = 26 ");

	    //				  	objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }

    /**
     * Gets the iP ostia os.
     *
     * @return the iP ostia os
     * @throws Exception the exception
     */
    public ArrayList getIPOstiaOS() throws Exception{

	try{
	    StringBuffer sql=new StringBuffer("select ID,VALUE1 from ");
	    sql.append(GENERIC_LOOKUP_TABLE);
	    sql.append(" WHERE DEFINITION_ID = 19 ");

	    //				  	objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }

    /**
     * Gets the iP ostia network segment.
     *
     * @return the iP ostia network segment
     * @throws Exception the exception
     */
    public ArrayList getIPOstiaNetworkSegment() throws Exception{

	try{
	    StringBuffer sql=new StringBuffer("select ID,VALUE1 from ");
	    sql.append(GENERIC_LOOKUP_TABLE);
	    sql.append(" WHERE DEFINITION_ID = 20 ");

	    //				  	objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }


    /**
     * Gets the iP ostia operating systems.
     *
     * @return the iP ostia operating systems
     * @throws Exception the exception
     */
    public ArrayList getIPOstiaOperatingSystems() throws Exception{

	try{
	    StringBuffer sql=new StringBuffer("select ID,VALUE1 from ");
	    sql.append(GENERIC_LOOKUP_TABLE);
	    sql.append(" WHERE DEFINITION_ID = 19 ");

	    //				  	objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }


    /**
     * Gets the iP access type.
     *
     * @return the iP access type
     * @throws Exception the exception
     */
    public ArrayList getIPAccessType() throws Exception{

	try{
	    StringBuffer sql=new StringBuffer("select ID,VALUE1 from ");
	    sql.append(GENERIC_LOOKUP_TABLE);
	    sql.append(" WHERE DEFINITION_ID = 23 ");
	    //				  	objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }

    /**
     * Gets the business unit.
     *
     * @param sectorId the sector id
     * @return the business unit
     * @throws Exception the exception
     */
    public ArrayList getBusinessUnit(Long sectorId) throws Exception{

	try{
	    /*
		  	    "select ID,BUSINESS_NAME from ");
			  	sql.append(BUSNIESS_UNIT_TABLE);
			  	sql.append(" WHERE SECTOR_ID= " + sectorId.longValue()+ " AND IS_ACTIVE = 'Y'");
	     */

	    StringBuffer sql=new StringBuffer("select business_unit.id,business_unit.BUSINESS_NAME  from ");

	    sql.append("hierarchy_detail,hierarchy_parent_detail,business_unit where  business_unit.IS_ACTIVE!='N' and ");
	    sql.append("hierarchy_detail.DATA_ID=business_unit.ID AND ");
	    sql.append("hierarchy_detail.NODE_TYPE_ID=3 and ");
	    sql.append("hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID and ");
	    sql.append("hierarchy_parent_detail.PARENT_ID = ");
	    sql.append("(select hierarchy_detail.ID from  hierarchy_detail where  hierarchy_detail.NODE_TYPE_ID=2 and ");
	    sql.append("hierarchy_detail.DATA_ID=  " + sectorId.longValue()+ ") order by business_unit.BUSINESS_NAME");

	    //				objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }


    /**
     * Gets the pL code.
     *
     * @param businessUnitId the business unit id
     * @return the pL code
     * @throws Exception the exception
     */
    public String getPLCode(Long businessUnitId) throws Exception{

	try{

	    StringBuffer sql=new StringBuffer("select ID,COST_CENTER from BUSINESS_UNIT where ID = " + businessUnitId.longValue()+ " ");

	    log.debug("Value of Sql "+sql.toString());
	    //		  		objList=new ArrayList();
	    objList=lookup(sql.toString());

	    LookUpVO obj=(LookUpVO)objList.get(0);

	    data=obj.getName();

	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Value of PL Code :getPLCode() : "+ data);
	return data;
    }

    /**
     * Gets the citi contact.
     *
     * @param relationshipID the relationship id
     * @return the citi contact
     * @throws Exception the exception
     */
    public ArrayList getCitiContact(Long relationshipID) throws Exception{

	try{
	    long relID=relationshipID.longValue();
	    StringBuffer sql=new StringBuffer("select  distinct a.ID,a.FIRST_NAME,a.LAST_NAME from CITI_CONTACT a ,relationship b where (a.RESOURCE_TYPE_ID=b.REQUESTER_RESOURCE_TYPE_ID and b.id="+relID);
	    sql.append(" )or ( a.RESOURCE_TYPE_ID=b.TARGET_RESOURCE_TYPE_ID and b.id="+relID);
	    sql.append(") or (a.BUSINESSUNIT_ID=b.BUSINESS_UNIT_ID and b.id="+relID+") order by a.first_name");

	    //StringBuffer sql=new StringBuffer("select ID,FIRST_NAME,LAST_NAME from CITI_CONTACT where BUSINESSUNIT_ID = " + businessUnitId.longValue()+ " ");

	    objList=new ArrayList();

	    log.debug("Inside the lookup"+ sql);

	    con=c3parSession.getConnection();

	    stmt = con.prepareStatement(sql.toString());

	    rs = stmt.executeQuery();

	    if(rs!=null)
	    {
		while(rs.next())
		{
		    obj=new LookUpVO();

		    obj.setValue(rs.getLong(1));
		    obj.setName(rs.getString(2)+" "+ rs.getString(3));
		    objList.add(obj);

		}
	    }


	}//end of try
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not load ", e);
	}
	finally
	{
	    c3parSession.closeResultSet(rs);
	    c3parSession.closeStatement(stmt);
	    c3parSession.releaseConnection();
	}
	log.debug("Size of Value Object List is "+ objList.size());

	return objList;
    }


    /**
     * Gets the third party users.
     *
     * @param relationShipID the relation ship id
     * @return the third party users
     * @throws Exception the exception
     */
    public ArrayList getThirdPartyUsers(ArrayList relationShipID) throws Exception{

	try{

	    StringBuffer iquery=new StringBuffer();

	    if(relationShipID !=null)
	    {

		for(int i=0;i<relationShipID.size();i++)
		{
		    iquery.append(relationShipID.get(i).toString());
		    iquery.append(",");
		}
	    }

	    iquery=iquery.deleteCharAt(iquery.lastIndexOf(","));

	    StringBuffer sql=new StringBuffer("select a.ID ,a.FIRST_NAME,a.LAST_NAME from TP_CONTACT a,RELATIONSHIP b Where b.THIRD_PARTY_ID=a.THIRDPARTY_ID AND b.ID IN ("+iquery+")");

	    objList=new ArrayList();

	    log.debug("Inside the lookup"+ sql);

	    con=c3parSession.getConnection();

	    stmt = con.prepareStatement(sql.toString());

	    rs = stmt.executeQuery();

	    if(rs!=null)
	    {
		while(rs.next())
		{
		    obj=new LookUpVO();

		    obj.setValue(rs.getLong(1));
		    obj.setName(rs.getString(2)+" "+ rs.getString(3));
		    objList.add(obj);

		}
	    }


	}//end of try
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not load ", e);
	}
	finally
	{
	    c3parSession.closeResultSet(rs);
	    c3parSession.closeStatement(stmt);
	    c3parSession.releaseConnection();
	}
	log.debug("Size of Value Object List is "+ objList.size());

	return objList;
    }

    /**
     * Gets the sector.
     *
     * @param regionId the region id
     * @return the sector
     * @throws Exception the exception
     */
    public ArrayList getSector(Long regionId) throws Exception{

	try{

	    StringBuffer sql=new StringBuffer("select sector.id,sector.NAME from ");

	    sql.append("hierarchy_detail,hierarchy_parent_detail,sector where  sector.IS_ACTIVE!='N' and ");
	    sql.append("hierarchy_detail.DATA_ID=sector.ID AND ");
	    sql.append("hierarchy_detail.NODE_TYPE_ID=2 and ");
	    sql.append("hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID and ");
	    sql.append("hierarchy_parent_detail.PARENT_ID = ");
	    sql.append("(select hierarchy_detail.ID from  hierarchy_detail where  hierarchy_detail.NODE_TYPE_ID=1 and ");
	    sql.append("hierarchy_detail.DATA_ID=  " + regionId.longValue()+ ") order by sector.NAME");
	    log.debug("Value of Sql "+sql.toString());
	    //			  	objList=new ArrayList();
	    objList=lookup(sql.toString());
	}
	catch (Exception e)
	{
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return objList;
    }


    //Generic method which is used to pass query
    /**
     * Lookup.
     *
     * @param sql the sql
     * @return the array list
     * @throws Exception the exception
     */
    public ArrayList lookup(String sql) throws Exception
    {

	objList=new ArrayList();
	try{
	    log.debug("Inside the lookup"+ sql);

	    con=c3parSession.getConnection();

	    stmt = con.prepareStatement(sql);

	    rs = stmt.executeQuery();

	    if(rs!=null)
	    {
		while(rs.next())
		{
		    obj=new LookUpVO();

		    obj.setValue(rs.getLong(1));
		    obj.setName(rs.getString(2));
		    objList.add(obj);

		}
	    }



	}//end of try
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not load ", e);
	}
	finally
	{
	    c3parSession.closeResultSet(rs);
	    c3parSession.closeStatement(stmt);
	    c3parSession.releaseConnection();
	}
	log.debug("Size of Value Object List is "+ objList.size());

	return objList;

    }


    /**
     * Sets the c3par session.
     *
     * @param session the new c3par session
     */
    public void setC3parSession(C3parSession session) {
	c3parSession = session;
    }

    /**
     * Gets the role by task.
     *
     * @param taskName the task name
     * @return the role by task
     * @throws Exception the exception
     */
    public String getRoleByTask(String taskName) throws Exception{
	try{
	    StringBuffer sql=new StringBuffer("select ID, Role from progress_bar where activity_name = '");
	    sql.append(taskName+"'");
	    log.debug("Value of Sql "+sql.toString());
	    objList=lookup(sql.toString());
	}
	catch (Exception e){
	    throw new DatabaseException("Could not load ", e);
	}

	log.debug("Size of list is "+ objList.size());
	return ((LookUpVO)objList.get(0)).getName();
    }

}