package com.citigroup.cgti.c3par.controller.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.admin.domain.DoNotSendMailList;
import com.citigroup.cgti.c3par.admin.domain.DonotSendMailProcess;

@Controller
public class DonotSendMailController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@RequestMapping(value = "/loaddonotsendmaillist.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String loaddonotsendmaillist(@ModelAttribute("donotSendMailProcess") DonotSendMailProcess donotSendMailProcess,ModelMap model, BindingResult result) {
		log.info("DonotSendMailController :: loaddonotsendmaillist starts ");
		donotSendMailProcess = loaddonotsendmail(donotSendMailProcess);
		model.addAttribute("donotSendMailProcess",donotSendMailProcess);
		
		return "c3par.admin.donotSendMail";
	}

	public DonotSendMailProcess loaddonotsendmail(DonotSendMailProcess donotSendMailProcess){
		String pageType = donotSendMailProcess.getPageType();

		//Setting page number
		donotSendMailProcess = setPaginationValues(donotSendMailProcess,0,10,0,pageType);
		List<DoNotSendMailList> doNotSendEmailList = donotSendMailProcess.getDoNotSendEmailList();	

		//setting the pagination values based on doNotSendEmailList
		donotSendMailProcess.setTotalPages(getTotalPages(donotSendMailProcess.getRowCount(), donotSendMailProcess.getLimit()));		
		donotSendMailProcess.setDonotSendMailList(doNotSendEmailList);
		
		return donotSendMailProcess;
	}
	
	@RequestMapping(value = "/savedonotsendmail.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String savedonotSendMailList(ModelMap model,@ModelAttribute("donotSendMailProcess") DonotSendMailProcess donotSendMailProcess, BindingResult result) {		
		log.info("DonotSendMailController::savedonotSendMailList methods starts...");
		boolean addError = false;
		try{
			//check whether soeID is entered or not
			if(donotSendMailProcess.getSoeID() != null && donotSendMailProcess.getSoeID().trim().length() > 0){
				//if soeID is entered then save / update the contact
				donotSendMailProcess.saveDoNotSendEmailList(donotSendMailProcess.getSoeID().trim());
			}else{//if soeID is not entered then show the error message		
				addError = true;
			}
		}catch(Exception e){
			addError = true;
		}
		if(addError){ 	
			log.info("DonotSendMailController::savedonotSendMailList:: Error...");
			result.addError(new ObjectError("donotSendMailProcess.soeID",new String[]{"admin.donotsendmail.soeID"},null,null));
		}	
		
		donotSendMailProcess.setOffset(0);
		donotSendMailProcess.setPageNo(1);
		donotSendMailProcess.setLimit(10);	
		donotSendMailProcess.setPaginationRequired(true);
		List<DoNotSendMailList> doNotSendEmailList = donotSendMailProcess.getDoNotSendEmailList();
		
		//setting the pagination values based on doNotSendEmailList
		donotSendMailProcess.setTotalPages(getTotalPages(donotSendMailProcess.getRowCount(), donotSendMailProcess.getLimit()));		
		donotSendMailProcess.setDonotSendMailList(doNotSendEmailList);
		model.addAttribute("donotSendMailProcess",donotSendMailProcess);
		
		return "c3par.admin.donotSendMail";
	}

	@RequestMapping(value = "/exportdonotsendmail.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String exportDoNotSendMail(ModelMap model, @ModelAttribute("donotSendMailProcess") DonotSendMailProcess donotSendMailProcess) {
		log.info("DonotSendMailController::exportDoNotSendMail methods starts...");
		
		donotSendMailProcess = new DonotSendMailProcess();
		donotSendMailProcess.setPaginationRequired(false);
		// retrieve the DoNotSendEmailList
		List<DoNotSendMailList> doNotSendEmailList = donotSendMailProcess.getDoNotSendEmailList();	
	
		donotSendMailProcess.setDonotSendMailList(doNotSendEmailList);
		
		model.addAttribute("donotSendMailProcess",donotSendMailProcess);
		
		return "pages/admin/DonotSendMailListExport";
	}

	@RequestMapping(value = "/deletedonotsendmail.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String deleteDoNotSendMail(ModelMap model, @ModelAttribute("donotSendMailProcess") DonotSendMailProcess donotSendMailProcess) {
		log.info("DonotSendMailController::deleteDoNotSendMail methods starts...");
	
		List<DoNotSendMailList> doNotSendEmailLists = donotSendMailProcess.getDonotSendMailList();
		List<String> soeIDList = new ArrayList<String>();
		
		if(doNotSendEmailLists !=null && doNotSendEmailLists.size() > 0) {
			for(DoNotSendMailList doNotSendEmailList : doNotSendEmailLists) {
				log.info("DonotSendMailController::deleteDoNotSendMail"+doNotSendEmailList.getSoeID()+"------"+doNotSendEmailList.isSelected());
				if (doNotSendEmailList.isSelected()) {
					soeIDList.add(doNotSendEmailList.getSoeID());
				}
			}			
			donotSendMailProcess.deleteDoNotSendEmailList(soeIDList);			
		}
		
		donotSendMailProcess = null;
		
		return "forward:/loaddonotsendmaillist.act";		
	}
	
	private DonotSendMailProcess setPaginationValues(DonotSendMailProcess donotSendMailProc, int curOffSet, int limit, int pageNo, String pageType){
		if(donotSendMailProc != null){
			curOffSet = donotSendMailProc.getOffset();		
			limit = donotSendMailProc.getLimit();		
			pageNo = donotSendMailProc.getPageNo();
		}
		donotSendMailProc = new DonotSendMailProcess();
		donotSendMailProc.setLimit(limit);
		donotSendMailProc.setPaginationRequired(true);
		if (pageType != null && "N".equalsIgnoreCase(pageType)) {
			donotSendMailProc.setOffset(curOffSet+donotSendMailProc.getLimit());
			donotSendMailProc.setPageNo(pageNo+1);
		} else if (pageType != null && "P".equalsIgnoreCase(pageType)) {
			donotSendMailProc.setOffset(curOffSet-donotSendMailProc.getLimit());
			donotSendMailProc.setPageNo(pageNo-1);
		} else if (pageType != null && "X".equalsIgnoreCase(pageType)) {
			donotSendMailProc.setOffset(limit * (pageNo-1));
			donotSendMailProc.setPageNo(pageNo);
		} else if (pageType != null && "L".equalsIgnoreCase(pageType)) {
			donotSendMailProc.setOffset(0);
			donotSendMailProc.setPageNo(1);
		}else {
			donotSendMailProc.setOffset(0);
			donotSendMailProc.setPageNo(1);
			donotSendMailProc.setLimit(10);
		}

		return donotSendMailProc;
	}

	private int getTotalPages(int rowCount, int limit){		
		int totalPages = 0;		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}	
		
		return totalPages;
	}
}
