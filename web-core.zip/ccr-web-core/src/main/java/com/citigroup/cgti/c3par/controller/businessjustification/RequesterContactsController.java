package com.citigroup.cgti.c3par.controller.businessjustification;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.audit.domain.AuditC3parUsersData;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade.GlobalActivityArgName;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade.GlobalActivityName;
import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiReqConXref;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityErrors;
import com.citigroup.cgti.c3par.common.domain.AdminProcess;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.common.domain.HistoryContact;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.user.domain.C3parUserHierarchyXref;
import com.citigroup.cgti.c3par.user.domain.C3parUserRoleXref;
import com.citigroup.cgti.c3par.user.domain.SecurityRole;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.webtier.helper.UserEntitlementHelper;
import com.mentisys.util.databaserealm.PasswordEncryption;

@Controller
public class RequesterContactsController extends BusJusBaseController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	public static final String TIME_ZONE_UTC = "UTC";

	@RequestMapping(value = "/loadRequesterContacts.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadRequesterContacts(HttpServletRequest request,
			ModelMap model) {
		log.info("RequesterContactsController :: loadRequestorContacts :: start ");
		BusinessJustificationProcess busjusProcess = new BusinessJustificationProcess();

		Long tirequestId = getTirequestID(request);
		TIRequest tirequest = busjusProcess.getTIRequestDetails(tirequestId);
		busjusProcess.setTirequest(tirequest);

		Long planningId = busjusProcess.getPlanningId(busjusProcess
				.getTirequest().getId());
		ConnectionRequest conreq = busjusProcess
				.getConnectionRequest(planningId);
		
		// completion check
		completionCheck(request, conreq, tirequest);

		String action = request.getParameter("action");

		String currentVersionNumber = request
				.getParameter("currentVersionNumber");

		Integer versionNumberTemp;

		if ("nextVersion".equals(action)) {

			versionNumberTemp = Integer.parseInt(currentVersionNumber) + 1;

			Long tirid = busjusProcess
					.getTiRequestForVersion(versionNumberTemp, tirequest.getTiProcess().getId());

			planningId = busjusProcess.getPlanningId(tirid);

			busjusProcess.setCurrVersionNo(versionNumberTemp);

		} else if ("previousVersion".equals(action)) {

			versionNumberTemp = Integer.parseInt(currentVersionNumber) - 1;

			Long tirid = busjusProcess
					.getTiRequestForVersion(versionNumberTemp,tirequest.getTiProcess().getId());

			planningId = busjusProcess.getPlanningId(tirid);

			busjusProcess.setCurrVersionNo(versionNumberTemp);

		} else {

			busjusProcess.setCurrVersionNo(busjusProcess.getTirequest()
					.getVersionNumber());
		}

		log.debug("Current version number....: "
				+ busjusProcess.getCurrVersionNo());

		log.debug("planningId...." + planningId);


		busjusProcess.setRequesterContacts(busjusProcess
				.getRequesterContactsList(planningId));
		if (busjusProcess.getRequesterContacts() != null) {
			log.debug("Planning ID " + planningId + " Requester Contacts Size "
					+ busjusProcess.getRequesterContacts().size());
		}
		model.addAttribute("busjusProcess", busjusProcess);
		return "c3par.businessjustification.requesterContacts";
	}

	@RequestMapping(value = "/assignCitiReqContactsAction.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String assignCitiReqContactsAction(	HttpServletRequest request,	@ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess
			,BindingResult result, ModelMap model) {
		log.info("RequesterContactsController :: assignCitiContactsAction :: start ");

		String saUpdate = request.getParameter("saUpdate");

		Long tirequestId = getTirequestID(request);
		TIRequest tirequest = busjusProcess.getTIRequestDetails(tirequestId);
		busjusProcess.setTirequest(tirequest);

		Long planningId = busjusProcess.getPlanningId(busjusProcess.getTirequest().getId());
		log.debug("planningId...." + planningId);

		String[] roleIds = (String[]) request.getSession().getAttribute("CITI_CONTACT_ROLEID");
		CitiContact citiContact = (CitiContact) request.getSession().getAttribute("RITS_CITI_CONTACT_ENTITY");
		request.getSession().removeAttribute("RITS_CITI_CONTACT_ENTITY");
		request.getSession().removeAttribute("CITI_CONTACT_ROLEID");

   		boolean isExist = true;
   		
  		if (citiContact != null && roleIds != null){
	   		for(String roleId: roleIds){
	   			Role role = busjusProcess.getRole(Long.valueOf(roleId));
		   		if(role != null && "ISO".equals(role.getDisplayName())){
			   	    isExist = busjusProcess.validateISOContact(citiContact.getSsoId());   		
			   		  	  
			   		log.debug("ISOValidation::isExist: "+isExist); 
			   		  
			   		 if(!isExist){
			   			result.addError(new ObjectError("ISOValidationError",new String[]{SubmitActivityErrors.BJ_ISO_CONTACTS_LIST},null,null));
			   		 } 
		   		} 
	   		}
  		} 

		if (citiContact != null && isExist) {
			List<Long> xrefIds = busjusProcess.saveConReqCitiReqContactXref(planningId, citiContact, roleIds);

			if ("true".equalsIgnoreCase(saUpdate) && xrefIds != null && xrefIds.size() > 0) {
				HistoryContact historyContact = null;
				List<HistoryContact> historyContacts = new ArrayList<HistoryContact>();
				for (Long xrefId : xrefIds) {
					historyContact = new HistoryContact();
					historyContact.setXrefId(xrefId);
					historyContact.setSoeId(citiContact.getSsoId());
					historyContacts.add(historyContact);
				}
				String soeId = (String) request.getSession().getAttribute("ssoId");
				busjusProcess.addContactsBySA(historyContacts, busjusProcess.getTirequest().getId(), soeId, "requester");
			}
		}
		busjusProcess.setCurrVersionNo(busjusProcess.getTirequest().getVersionNumber());
		busjusProcess.setRequesterContacts(busjusProcess.getRequesterContactsList(planningId));

		ConnectionRequest conreq = busjusProcess.getConnectionRequest(planningId);
		// completion check
		completionCheck(request, conreq, tirequest);

		if (busjusProcess.getRequesterContacts() != null) {
			log.debug("Planning ID " + planningId + " Target Contacts Size " + busjusProcess.getRequesterContacts().size());
		}
		return "c3par.businessjustification.requesterContacts";
	}

	@RequestMapping(value = "/unAssignCitiReqContactsAction.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String unAssignCitiReqContactsAction(
			HttpServletRequest request,
			@ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess,
			ModelMap model) {
		log.info("RequesterContactsController :: unassignCitiContactsAction :: start ");
		String saUpdate = request.getParameter("saUpdate");
		Long tiRequestId = getTirequestID(request);
		TIRequest tirequest = busjusProcess.getTIRequestDetails(tiRequestId);
		busjusProcess.setTirequest(tirequest);

		// copy contacts from relationship contacts table (first time)
		busjusProcess.copyContactsFromRelationship(tiRequestId);

		Long planningId = busjusProcess.getPlanningId(busjusProcess
				.getTirequest().getId());
		log.debug("planningId...." + planningId);

		String[] xrefIds = busjusProcess.getCitiContactIds();
		if (null != xrefIds) {
			busjusProcess.deleteConReqCitiReqContactXref(xrefIds);
			List<ConReqCitiReqConXref> deleteList = busjusProcess
					.getRequesterContacts();

			if ("true".equalsIgnoreCase(saUpdate)) {
				List<HistoryContact> historyContacts = new ArrayList<HistoryContact>();
				HistoryContact historyContact = null;

				for (ConReqCitiReqConXref conReqCitiContactXref : deleteList) {
					for (String id : xrefIds) {
		    			if (conReqCitiContactXref.getId().equals(Long.parseLong(id))) {
							historyContact = new HistoryContact();
							historyContact.setCreated_date(new Date());
							historyContact.setContactId(conReqCitiContactXref
									.getCiticontact().getId());
							historyContact.setRoleId(conReqCitiContactXref
									.getRole().getId());
							historyContact
									.setNotifyContact(conReqCitiContactXref
											.getNotifyContact());
							historyContact
									.setPrimaryContact(conReqCitiContactXref
											.getPrimaryContact());
							historyContact
									.setSystemGenerated(conReqCitiContactXref
											.getSystemGenerated());
							historyContact.setSoeId(conReqCitiContactXref
									.getCiticontact().getSsoId());
							historyContacts.add(historyContact);
						}
					}
				}

				String soeId = (String) request.getSession().getAttribute(
						"ssoId");
				busjusProcess.deleteContactsBySA(historyContacts, busjusProcess
						.getTirequest().getId(), soeId, "requester");
			}
		}

		busjusProcess.setCurrVersionNo(busjusProcess.getTirequest()
				.getVersionNumber());
		busjusProcess.setRequesterContacts(busjusProcess
				.getRequesterContactsList(planningId));

		ConnectionRequest conreq = busjusProcess
				.getConnectionRequest(planningId);
		// completion check
		completionCheck(request, conreq, tirequest);

		return "c3par.businessjustification.requesterContacts";
	}

	@RequestMapping(value = "/notifyCitiReqContactsAction.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String notifyCitiReqContactsAction(
			HttpServletRequest request,
			@ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess,
			ModelMap model) {
		log.info("RequesterContactsController :: notifyCitiReqContactsAction :: start ");
		String saUpdate = request.getParameter("saUpdate");
		Long tirequestId = getTirequestID(request);
		TIRequest tirequest = busjusProcess.getTIRequestDetails(tirequestId);
		busjusProcess.setTirequest(tirequest);

		Long planningId = busjusProcess.getPlanningId(busjusProcess.getTirequest().getId());
		log.debug("planningId...." + planningId);

		String[] xrefIds = busjusProcess.getCitiContactIds();
		List<ConReqCitiReqConXref> citiContactXrefs = busjusProcess.getRequesterContactsList(planningId);
		List<ContactDetailsDTO> conList = new ArrayList<ContactDetailsDTO>();
		Long xrefid = null;

		for (ConReqCitiReqConXref conReqCitiContactXref : citiContactXrefs) {
			for (int i = 0; i < xrefIds.length; i++) {
				log.debug("RequesterContactsController :: notifyCitiContactsAction :: " + conReqCitiContactXref.getId() + " - " + xrefIds[i]);
				xrefid = Long.valueOf(xrefIds[i]);
				if (conReqCitiContactXref.getId() != null && conReqCitiContactXref.getId().longValue() == xrefid.longValue()) {
					ContactDetailsDTO contact = new ContactDetailsDTO();
					contact.setName(conReqCitiContactXref.getCiticontact().getFirstName()	+ " " + conReqCitiContactXref.getCiticontact().getLastName());
					contact.setFirstName(conReqCitiContactXref.getCiticontact().getFirstName());
					contact.setLastName(conReqCitiContactXref.getCiticontact().getLastName());
					contact.setEmailID(conReqCitiContactXref.getCiticontact().getEmail());
					contact.setRole(conReqCitiContactXref.getRole().getDisplayName());
					contact.setSsoID(conReqCitiContactXref.getCiticontact().getSsoId());
					contact.setId(conReqCitiContactXref.getCiticontact().getId());
					contact.setRoleId(conReqCitiContactXref.getRole().getId());
					conList.add(contact);
				}
			}
		}

		busjusProcess.sendMailToTargetContacts(conList, tirequest, "requester");
		requestUserEntitlement(request, tirequest, conList, busjusProcess);

		busjusProcess.setCurrVersionNo(busjusProcess.getTirequest().getVersionNumber());
		busjusProcess.setRequesterContacts(busjusProcess.getRequesterContactsList(planningId));
		busjusProcess.setCitiContactIds(null);
		return "c3par.businessjustification.requesterContacts";
	}

	@RequestMapping(value = "/saveCitiReqesterContacts.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String saveCitiReqesterContacts(
			HttpServletRequest request,
			@ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess,
			ModelMap model) {
		log.info("TargetContactsController :: saveCitiReqesterContacts :: start ");

		Long tirequestId = getTirequestID(request);
		TIRequest tirequest = busjusProcess.getTIRequestDetails(tirequestId);
		busjusProcess.setTirequest(tirequest);

		saveConReqCitiRequestorContact(request, busjusProcess, model);

		return "c3par.businessjustification.requesterContacts";
	}

	@RequestMapping(value = "/continueCitiReqesterContacts.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String continueCitiReqesterContacts(
			HttpServletRequest request,
			@ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess,
			ModelMap model) {
		log.info("TargetContactsController :: continueCitiReqesterContacts :: start ");

		String forwardTo = null;

		Long tirequestId = getTirequestID(request);
		TIRequest tirequest = busjusProcess.getTIRequestDetails(tirequestId);
		busjusProcess.setTirequest(tirequest);

		saveConReqCitiRequestorContact(request, busjusProcess, model);

		if (busjusProcess.getTirequest() != null
				&& C3parStaticNames.CITI_CON.equalsIgnoreCase(busjusProcess
						.getTirequest().getTiProcess().getRelationshipId()
						.getRelationshipType())) {
			if (busjusProcess.isBuscritEmerConnection(tirequestId)) {
				forwardTo = "redirect:/emerbuscritload.act";
			} else {
				forwardTo = "redirect:/loadFirewallRules.act";
			}
		} else if (busjusProcess.getTirequest() != null
				&& C3parStaticNames.U_TURN.equalsIgnoreCase(busjusProcess
						.getTirequest().getTiProcess().getRelationshipId()
						.getRelationshipType())) {
			forwardTo = "redirect:/loadThirdPartyContacts.act";
		}
		log.info("TargetContactsController :: continueCitiReqesterContacts :: forwardTo - "
				+ forwardTo);

		return forwardTo;
	}

	private void saveConReqCitiRequestorContact(HttpServletRequest request,
			BusinessJustificationProcess busjusProcess, ModelMap model) {

		String saUpdate = request.getParameter("saUpdate");

		Long planningId = busjusProcess.getPlanningId(busjusProcess
				.getTirequest().getId());
		log.debug("planningId...." + planningId);

		List<ConReqCitiReqConXref> submittedList = busjusProcess
				.getRequesterContacts();
		List<ConReqCitiReqConXref> citiContactXrefs = busjusProcess
				.getRequesterContactsList(planningId);

		Map<Integer, HistoryContact> newHistoryContacts = new HashMap<Integer, HistoryContact>();
		Map<Integer, HistoryContact> oldHistoryContacts = new HashMap<Integer, HistoryContact>();

		if (submittedList != null && !submittedList.isEmpty()) {
			for (ConReqCitiReqConXref citiContactXref : submittedList) {
				log.debug("Modified: " + citiContactXref.getModified());
				if ("true".equalsIgnoreCase(citiContactXref.getModified())) {
					modifyConReqCitiReqContactXref(citiContactXrefs,
							citiContactXref, newHistoryContacts,
							oldHistoryContacts);
				}
			}
		}

		if ("true".equalsIgnoreCase(saUpdate)) {
			String soeId = (String) request.getSession().getAttribute("ssoId");
			busjusProcess.updateContactsBySA(newHistoryContacts,
					oldHistoryContacts, busjusProcess.getTirequest().getId(),
					soeId, "requester");
		}

		busjusProcess.updateConReqCitiReqContactXref(citiContactXrefs);
		busjusProcess.setCurrVersionNo(busjusProcess.getTirequest()
				.getVersionNumber());
		busjusProcess.setRequesterContacts(busjusProcess
				.getRequesterContactsList(planningId));
	}

	private void modifyConReqCitiReqContactXref(
			List<ConReqCitiReqConXref> citiContactXrefs,
			ConReqCitiReqConXref citiContactXref,
			Map<Integer, HistoryContact> newHistoryContacts,
			Map<Integer, HistoryContact> oldHistoryContacts) {
		HistoryContact historyContact = null;
		int i = 0;
		for (ConReqCitiReqConXref citiContactXrefExt : citiContactXrefs) {
			if (citiContactXrefExt.getId().equals(citiContactXref.getId())) {
				i++;
				historyContact = new HistoryContact();
				historyContact.setXrefId(citiContactXref.getId());
				historyContact.setSoeId(citiContactXref.getCiticontact()
						.getSsoId());
				newHistoryContacts.put(Integer.valueOf(i), historyContact);

				historyContact = new HistoryContact();
				historyContact.setCreated_date(new Date());
				historyContact.setContactId(citiContactXrefExt.getCiticontact()
						.getId());
				historyContact.setSoeId(citiContactXrefExt.getCiticontact()
						.getSsoId());
				historyContact.setRoleId(citiContactXrefExt.getRole().getId());
				historyContact.setNotifyContact(citiContactXrefExt
						.getNotifyContact());
				historyContact.setPrimaryContact(citiContactXrefExt
						.getPrimaryContact());
				historyContact.setSystemGenerated(citiContactXrefExt
						.getSystemGenerated());
				oldHistoryContacts.put(Integer.valueOf(i), historyContact);

				citiContactXrefExt.setNotifyContact(citiContactXref
						.getNotifyContact());
				citiContactXrefExt.setPrimaryContact(citiContactXref
						.getPrimaryContact());
			}
		}
	}

	private Long getTirequestID(HttpServletRequest request) {

		Long tirequestId = 0L;
		if (request.getSession().getAttribute("tireqid") != null) {
			tirequestId = Long.valueOf(request.getSession()
					.getAttribute("tireqid").toString());
		} else if (request.getParameter("tireqid") != null) {
			tirequestId = Long.valueOf(request.getParameter("tireqid").trim());
		} else { // if(request.getParameter("tiRequestId") != null){
			tirequestId = Long.valueOf(request.getParameter("tiRequestId"));
		}
		log.debug("getTirequestID..... " + tirequestId);
		return tirequestId;
	}

	private void requestUserEntitlement(HttpServletRequest request,
			TIRequest tiReq, List<ContactDetailsDTO> contactDetailsDTOList,
			BusinessJustificationProcess businessJustificationProcess) {
		log.debug("requestUserEntitlement :: requestUserEntitlement starts..."
				+ tiReq.getTiProcess().getId());
		UserEntitlementHelper usrEntHelper = new UserEntitlementHelper();
		String forwardTo = "";
		String loginSSOID = (String) request.getSession().getAttribute("ssoId");
		AdminProcess adminprocess = new AdminProcess();
		StringBuffer selectedRoleNames = new StringBuffer();
		StringBuffer existingRoleNames = new StringBuffer();
		String rolesToAudit="";
		String existingRoles="";
		Long c3parUserId = null;
		C3parUser extRecord = null;
		C3parUser newUser = null;
		boolean update = false;
		
		Map<Long,String> securityRolesMap = new HashMap<Long, String>();
		for(SecurityRole role: adminprocess.getSecurityRoles()){
			securityRolesMap.put(role.getId(),role.getName());
		}
		
		
		for (ContactDetailsDTO contactDto : contactDetailsDTOList) {
			long userID = 0L;
			try {
				userID = usrEntHelper.checkEntitlementExists(contactDto
						.getSsoID());
			} catch (Exception e) {
				log.error(e);
			}
			log.debug("loginSSOID::" + loginSSOID + "SsoID::"
					+ contactDto.getSsoID() + ", isExists::" + userID);
			try {
				if (userID <= 0) {
					// if user not exists in CCR System
					newUser = new C3parUser();
					log.debug("requestUserEntitlement :: new requestUserEntitlement::userNotExists");
					newUser.setFirstName(contactDto.getFirstName().trim());
					newUser.setLastName(contactDto.getLastName().trim());
					newUser.setEmail(contactDto.getEmailID().trim());
					newUser.setSsoId(contactDto.getSsoID().trim());

					String password = contactDto.getSsoID().trim()
							.toLowerCase()
							+ "!!";
					password = PasswordEncryption.getInstance().encrypt(
							password);
					newUser.setPassword(password);

					newUser.setCreated_date(new Date());
					newUser.setActive("P");
					newUser.setWfStatus("system_new_user");
					newUser.setRequestedBy("initialize_migration");
					newUser.setRequestedDate(new Date());

					// Adding roles for the user
					List<C3parUserRoleXref> userRoleList = new ArrayList<C3parUserRoleXref>();
					C3parUserRoleXref c3parUserRoleXref = null;
					SecurityRole securityRole = null;

					List<Long> roles = usrEntHelper.getNewRolesForEntitlement(
							contactDto.getRole(), "N");
					roles.addAll(usrEntHelper.getSecurityRoleIDs("C3PARUSER"));
					roles.addAll(usrEntHelper
							.getSecurityRoleIDs("Entitlement Requester"));

					
					for (Long roleId : roles) {
						log.debug("AssignCitiContactsAction :: new UserEntitlement::roleId-"
								+ roleId);
						selectedRoleNames.append(securityRolesMap.get(roleId)).append(",");
						securityRole = new SecurityRole();
						c3parUserRoleXref = new C3parUserRoleXref();
						securityRole.setId(roleId);
						c3parUserRoleXref.setC3parUser(newUser);
						c3parUserRoleXref.setSecurityRole(securityRole);
						c3parUserRoleXref.setUpdated_date(new Date());
						userRoleList.add(c3parUserRoleXref);
					}
					newUser.setUserRoleList(userRoleList);

					// add region and sector
					List<CitiHierarchyMaster> citihiermaslist = adminprocess
							.getConnectionRegSecBU(tiReq.getTiProcess().getId());
					List<C3parUserHierarchyXref> hierxreflist = new ArrayList<C3parUserHierarchyXref>();
					C3parUserHierarchyXref hierxref = null;
					CitiHierarchyMaster hiermas = null;

					for (CitiHierarchyMaster citihiermas : citihiermaslist) {
						hierxref = new C3parUserHierarchyXref();

						hiermas = new CitiHierarchyMaster();
						hiermas.setRegion(new Region());
						hiermas.getRegion().setId(
								citihiermas.getRegion().getId());
						hiermas.setSector(new Sector());
						hiermas.getSector().setId(
								citihiermas.getSector().getId());
						log.debug("requestUserEntitlement :: new UserEntitlement:: citihiermas.getRegion().getId()"
								+ citihiermas.getRegion().getId()
								+ " = citihiermas.getSector().getId()-"
								+ citihiermas.getSector().getId());

						hierxref.setCitiHierarchyMaster(hiermas);
						hierxref.setPermission("WRITE");
						hierxref.setInactive("N");
						hierxref.setC3parUser(newUser);

						hierxreflist.add(hierxref);
					}
					newUser.setUserHierarchyList(hierxreflist);
					newUser.setCreatedUser(loginSSOID);
					// save the user
					adminprocess.setC3parUser(newUser);
					c3parUserId=adminprocess.saveC3parUser();
					log.debug("User Saved If Block");
				} else {
					// if user exists in CCR System
					log.debug("requestUserEntitlement :: update requestUserEntitlement::user Exists");
					existingRoleNames = new StringBuffer();
					update = true;
					C3parUser user = adminprocess.retrieveC3parUser(Long
							.valueOf(userID));
					extRecord = user;
					// add roles
					List<Long> newroles = null;
					try {
						newroles = usrEntHelper.checkContactRoleExists(
								user.getSsoId(), contactDto.getRole(), "Y");
					} catch (Exception e) {
						log.error("Exception::", e);
					}
					List<C3parUserRoleXref> extUserRoleList = user
							.getUserRoleList();
					List<C3parUserRoleXref> userRoleList = new ArrayList<C3parUserRoleXref>();
					C3parUserRoleXref c3parUserRoleXref = null;
					SecurityRole securityRole = null;

					for(C3parUserRoleXref role : extUserRoleList){
						existingRoleNames.append(role.getSecurityRole().getName()).append(",");
					}
					
					//To add existing roles in current user.
					if(selectedRoleNames.length()>0) {
						selectedRoleNames.append(",");
					} else if(selectedRoleNames.length()==0){
						selectedRoleNames.append(existingRoleNames);
					}
					
					// add not exists role to the user
					log.debug("Selected Roles ... " + newroles);
					boolean isAdd = false;
					for (Long roleId : newroles) {
						isAdd = true;
						if (extUserRoleList != null
								&& !extUserRoleList.isEmpty()) {
							for (C3parUserRoleXref c3parUserRoleXrefExt : extUserRoleList) {
								if (c3parUserRoleXrefExt.getSecurityRole() != null
										&& roleId.equals(c3parUserRoleXrefExt
												.getSecurityRole().getId())) {
									isAdd = false;
								}
							}
						}
						if (isAdd) {
							securityRole = new SecurityRole();
							c3parUserRoleXref = new C3parUserRoleXref();
							securityRole.setId(roleId);
							// c3parUserRoleXref.setC3parUser(user);
							c3parUserRoleXref.setSecurityRole(securityRole);
							c3parUserRoleXref.setUpdated_date(new Date());
							userRoleList.add(c3parUserRoleXref);
							log.debug("requestUserEntitlement :: update requestUserEntitlement:: add newrole - "
									+ roleId);
							selectedRoleNames.append(securityRolesMap.get(roleId)).append(",");
							log.debug("selectedRoleNames Names appened: "+selectedRoleNames);
						}
					}
					
					user.getUserRoleList().addAll(userRoleList);
					log.debug("requestUserEntitlement :: update requestUserEntitlement:: getUserRoleList - "
							+ user.getUserRoleList().size());
					// add region and sector if not exists
					List<CitiHierarchyMaster> citihiermaslist = adminprocess
							.getConnectionRegSecBU(tiReq.getTiProcess().getId());
					List<C3parUserHierarchyXref> userhierxreflist = user
							.getUserHierarchyList(); // get existing region,
														// sector list
					List<C3parUserHierarchyXref> hierxreflist = new ArrayList<C3parUserHierarchyXref>();

					C3parUserHierarchyXref hierxref = null;
					CitiHierarchyMaster hiermas = null;

					for (CitiHierarchyMaster citihiermas : citihiermaslist) {
						isAdd = true;
						if (userhierxreflist != null
								&& !userhierxreflist.isEmpty()) {
							for (C3parUserHierarchyXref userhierxref : userhierxreflist) {
								if (citihiermas
										.getRegion()
										.getId()
										.equals(userhierxref
												.getCitiHierarchyMaster()
												.getRegion().getId())
										&& citihiermas
												.getSector()
												.getId()
												.equals(userhierxref
														.getCitiHierarchyMaster()
														.getSector().getId())) {
									isAdd = false;
								}
							}
						}
						if (isAdd) {
							hierxref = new C3parUserHierarchyXref();

							hiermas = new CitiHierarchyMaster();
							hiermas.setRegion(new Region());
							hiermas.getRegion().setId(
									citihiermas.getRegion().getId());
							hiermas.setSector(new Sector());
							hiermas.getSector().setId(
									citihiermas.getSector().getId());
							log.debug("requestUserEntitlement :: new UserEntitlement:: citihiermas.getRegion().getId()"
									+ citihiermas.getRegion().getId()
									+ " = citihiermas.getSector().getId()-"
									+ citihiermas.getSector().getId());

							hierxref.setCitiHierarchyMaster(hiermas);
							hierxref.setPermission("WRITE");
							hierxref.setInactive("N");
							// hierxref.setC3parUser(user);

							hierxreflist.add(hierxref);
						}
					}
					user.getUserHierarchyList().addAll(hierxreflist);
					log.debug("requestUserEntitlement :: update requestUserEntitlement:: getUserHierarchyList - "
							+ user.getUserHierarchyList().size());

					// set status to update in bpm
					user.setWfStatus("system_update_user");
					user.setRequestedBy("initialize_migration");

					// save the user
					adminprocess.setC3parUser(user);
					c3parUserId = adminprocess.saveC3parUser();
					log.debug("User Saved Else Block");
				}
				
				
				try {
					AuditC3parUsersData auditC3parUsersData = createAuditUsersData(c3parUserId,adminprocess,loginSSOID);
					String status=auditC3parUsersData.getIsActiveCurrent();
					if(status!=null){
						status = status.equals("Y") ? "ACTIVE" : "IN-ACTIVE";
					}
					if(update){
						auditC3parUsersData.setAction("UPDATE");
						if(existingRoleNames.toString().endsWith(",")) {
							existingRoles = existingRoleNames.deleteCharAt(existingRoleNames.length()-1).toString();
						}
						log.debug("Existing Roles: "+existingRoles);
						auditC3parUsersData.setRoleStrPrev(existingRoles);
						auditC3parUsersData.setIsActivePrev(extRecord.getActive());
						auditC3parUsersData.setEntStrPrev(getEntitlements(extRecord));
						auditC3parUsersData.setEventDescription("User "+extRecord.getSsoId()+" Updated and Status is "+status);
					}else {
						auditC3parUsersData.setAction("CREATE");
						auditC3parUsersData.setEventDescription("User "+newUser.getSsoId()+" Created and Status is "+status);
					}
					if(selectedRoleNames.toString().endsWith(",")) {
						rolesToAudit = selectedRoleNames.deleteCharAt(selectedRoleNames.length()-1).toString();
					}
					log.debug("Selected Roles in User: "+rolesToAudit);
					auditC3parUsersData.setRoleStrCurrent(rolesToAudit);
					String deviceHostName = request.getServerName().substring(0, request.getServerName().indexOf("."));
					auditC3parUsersData.setHostName(deviceHostName);
					auditC3parUsersData.setHostNameAddress(request.getServerName());
					log.debug("Before auditC3parUsersData Save "+auditC3parUsersData.toString());
					adminprocess.saveAuditUsersData();
				} catch (Exception e) {
					log.error("Error in Audit Logging User Data: ",e);
				}

				if (userID <= 0) {
					// if user not exists in CCR System then Send Mail
					// Notification to the user
					businessJustificationProcess
							.sendMailForUserEntitlementCreate(contactDto, tiReq);
				}

			} catch (Exception ex) {
				log.error(ex, ex);
				forwardTo = "failure";
			}
		}
		
		
		// call BPM Webservice to sync CCR Users and BPM Users
		try {
			log.debug("AssignCitiContactsAction :: requestUserEntitlement::submitting to BPM"
					+ loginSSOID.toLowerCase());
			WsPapiFacade papiFacade = new WsPapiFacade();
			papiFacade.callGlobalInteractive(loginSSOID.toLowerCase(),
					GlobalActivityName.UserMigration,
					GlobalActivityArgName.UserAdmin);
			log.debug("AssignCitiContactsAction :: requestUserEntitlement:: After submitting to BPM");
		} catch (Exception ex) {
			log.error(ex, ex);
		}

		log.debug("AssignCitiContactsAction :: requestUserEntitlement ends");
	}
	
	private AuditC3parUsersData createAuditUsersData(Long userId, AdminProcess adminProcess, String loginSSOId){
		log.info("Entering RequesterContactsController createAuditUsersData.");
		AuditC3parUsersData auditC3parUsersData = new AuditC3parUsersData();
		C3parUser c3parUser = adminProcess.getC3parUser();
		auditC3parUsersData.setUserId(userId);
		auditC3parUsersData.setUpdatedByUser(loginSSOId);
		auditC3parUsersData.setUpdated_date(new Date());
		auditC3parUsersData.setMgrApprover("");
		auditC3parUsersData.setMgrApprovedDate(null);
		auditC3parUsersData.setIsaApprover("");
		auditC3parUsersData.setIsaApprovedDate(null);
		auditC3parUsersData.setIsActiveCurrent(c3parUser.getActive());
		auditC3parUsersData.setEntStrCurrent(getEntitlements(c3parUser));
		auditC3parUsersData.setAuditLogInsertedDate(new Date());
		auditC3parUsersData.setSysadminApprover("");
		auditC3parUsersData.setSysadminReviewedDate(null);
		auditC3parUsersData.setLogDateTime(getDateTimeInUTC());
		auditC3parUsersData.setAffectedUser(c3parUser.getSsoId());
		adminProcess.setAuditC3parUsersData(auditC3parUsersData);
		log.info("Exiting RequesterContactsController createAuditUsersData.");
		return auditC3parUsersData;		
	}
	
	private String getEntitlements(C3parUser c3parUser){
		log.info("Entering RequesterContactsController getEntitlements.");
		StringBuilder entitlements = new StringBuilder("");
		List<C3parUserHierarchyXref> c3parUserHierarchyXrefList = c3parUser.getUserHierarchyList();
		if(c3parUserHierarchyXrefList!=null && c3parUserHierarchyXrefList.size()>0){
			for(C3parUserHierarchyXref c3parUserHierarchyXref : c3parUserHierarchyXrefList ){
				CitiHierarchyMaster citiHierarchyMaster = c3parUserHierarchyXref.getCitiHierarchyMaster();
				if(citiHierarchyMaster!=null){
					log.debug("ID: "+citiHierarchyMaster.getRegion().getName() + " - Name "+ citiHierarchyMaster.getSector().getName());
					entitlements.append(citiHierarchyMaster.getRegion().getName())
							.append("-").append(citiHierarchyMaster.getSector().getName())
							.append(",");
				}
			}
			if(!entitlements.equals("")){
				entitlements.deleteCharAt(entitlements.length()-1);
			}
			log.debug("Formated Entitlements with Region:"+entitlements.toString());
		}
		log.info("Exiting RequesterContactsController getEntitlements.");
		return entitlements.toString();
	}
	
	private Calendar getDateTimeInUTC(){
		TimeZone timeZone = TimeZone.getTimeZone(TIME_ZONE_UTC);
		Calendar calendar = Calendar.getInstance(timeZone);
		return calendar;
	}

}
