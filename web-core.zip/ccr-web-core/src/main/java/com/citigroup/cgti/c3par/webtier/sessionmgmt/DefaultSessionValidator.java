/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.webtier.sessionmgmt;

import javax.servlet.http.HttpServletRequest;


/**
 * This implements the SessionValidator interface.
 * 
 * @author pkadam
 */
public class DefaultSessionValidator implements SessionValidator {

    /**
     * This method returns a true value.
     *
     * @param request the request
     * @return boolean
     */
    public boolean isSessionValid(HttpServletRequest request) {
	return true ;
    }
}
