package com.citigroup.cgti.c3par.ip.helper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.C3parSessionFactory;
import com.citigroup.cgti.c3par.webtier.helper.GenericHelper;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
//import com.citigroup.cgti.c3par.C3parSession;
//import com.citigroup.cgti.c3par.C3parThinSession;
//import com.citigroup.cgti.c3par.util.FrameworkConstants;



/**
 * The Class IPRegHelper.
 */
public class IPRegHelper extends GenericHelper {
	//Map function_ids from c3par_function table to the respection paths
	/** The Constant IP_BUSINESS_CASE_FID. */
	public static final String IP_BUSINESS_CASE_FID="20";

	/** The Constant IP_REGISTER_IP_FID. */
	public static final String IP_REGISTER_IP_FID="21";

	/** The Constant IP_CITIGROUP_CONTACTS_FID. */
	public static final String IP_CITIGROUP_CONTACTS_FID="22";

	/** The Constant IP_SCREENING_QUESTIONS_FID. */
	public static final String IP_SCREENING_QUESTIONS_FID="23";

	/** The Constant IP_REGISTRATION_FID. */
	public static final String IP_REGISTRATION_FID="18";

	/** The Constant IP_CREATE_IP_FID. */
	public static final String IP_CREATE_IP_FID="19";

	/** The Constant IP_BUSINESS_CASE_FID_MAINT. */
	public static final String IP_BUSINESS_CASE_FID_MAINT="36";

	/** The Constant IP_REGISTER_IP_FID_MAINT. */
	public static final String IP_REGISTER_IP_FID_MAINT="37";

	/** The Constant IP_CITIGROUP_CONTACTS_FID_MAINT. */
	public static final String IP_CITIGROUP_CONTACTS_FID_MAINT="38";

	/** The Constant IP_PATH. */
	public static final String IP_PATH=IP_REGISTRATION_FID+"~"+IP_CREATE_IP_FID;

	/** The Constant CONN_BUSINESS_CASE_FID. */
	public static final String CONN_BUSINESS_CASE_FID="4";

	/** The Constant CONN_CONNECTION_BASIC_INFO_FID. */
	public static final String CONN_CONNECTION_BASIC_INFO_FID="5";

	/** The Constant CONN_CITIGROUP_CONTACTS_FID. */
	public static final String CONN_CITIGROUP_CONTACTS_FID="6";

	/** The Constant CONN_3RD_PARTY_CONTACTS_FID. */
	public static final String CONN_3RD_PARTY_CONTACTS_FID="7";

	/** The Constant CONN_TPISA_ASSESSMENT_FID. */
	public static final String CONN_TPISA_ASSESSMENT_FID="8";

	/** The Constant CONN_DATA_INFORMATION_FID. */
	public static final String CONN_DATA_INFORMATION_FID="9";

	/** The Constant CONN_DOCUMENT_UPLOAD_FID. */
	public static final String CONN_DOCUMENT_UPLOAD_FID="10";

	/** The Constant CONN_EMER_BUSCRIT_FID. */
	public static final String CONN_EMER_BUSCRIT_FID="69";

	/** The Constant CONN_CONNECTION_FID. */
	public static final String CONN_CONNECTION_FID="2";

	/** The Constant CONN_CREATE_CONNECTION_FID. */
	public static final String CONN_CREATE_CONNECTION_FID="3";


	/** The Constant CONN_PATH. */
	public static final String CONN_PATH=CONN_CONNECTION_FID+"~"+CONN_CREATE_CONNECTION_FID;


	/** The log. */
	protected Logger log = Logger.getLogger(getClass());

	/** The node count. */
	int nodeCount=0;

	/** The found. */
	boolean found=false;

	/** The path length. */
	int pathLength=IP_PATH.split("~").length;

	/** The path. */
	String path[]=IP_PATH.split("~");

	/**
	 * Run query return id.
	 *
	 * @param sql the sql
	 * @return the long
	 * @throws Exception the exception
	 */
	public Long runQueryReturnID(String sql) throws Exception{
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		DatabaseSession c3parSession=C3parSessionFactory.getC3parSession();
		Long id=null;
		try{
			con =c3parSession.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql.toString());
			if(rs!=null){
				while(rs.next()){
					id=Long.valueOf(rs.getLong(1));
				}
			}
		}
		finally{
			if(rs!=null)
				rs.close();
			if(stmt!=null)
				stmt.close();
			if(con!=null){
				c3parSession.releaseConnection();
			}
		}
		return id;
	}


	/**
	 * Sets the status.
	 *
	 * @param functionList the function list
	 * @param fID the f id
	 * @param status the status
	 * @param path the path
	 * @throws Exception the exception
	 */
	public void setStatus(ArrayList functionList,String fID,String status,String[] path) throws Exception{
		if(functionList!=null && functionList.size()>0){
			for (int i=0; i < functionList.size()&& !found ; i++) {
				HashMap functionMap = (HashMap)functionList.get(i);
				String functionID=(String)functionMap.get("function_id");
				if(nodeCount==pathLength){
					if(functionID!=null && functionID.equals(fID)){
						log.debug("Function id "+functionID +" Function Status "+status);
						functionMap.put("function_status",status);
						found=true;
						break;
					}
				}
				if( nodeCount<pathLength && functionID!=null && functionID.equals(path[nodeCount])){
					nodeCount++;
					setStatus((ArrayList)functionMap.get("child"),fID,status,path);
				}


			}
		}
	}

	/**
	 * Reset.
	 */
	public void reset(){
		nodeCount=0;
		found=false;
	}


	/**
	 * method for getting emer buscrit function id from the c3par_function.
	 *
	 * @return the emer buscrit function id
	 */
	public String getEmerBuscritFunctionId() {
		log.info("IPRegHelper.getEmerBuscritFunctionId()");
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		DatabaseSession c3parSession = C3parSessionFactory.getC3parSession();
		String emerBuscritFunctionId = null;
		try {
			con = c3parSession.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(" select ID from c3par_function where description='EMER_BUSCRIT_QUESTIONS' ");
			if (rs != null) {
				while (rs.next()) {
					emerBuscritFunctionId = String.valueOf(rs.getInt(1));
					log.info("IPRegHelper.getEmerBuscritFunctionId() with emerBuscritFunctionId = "+emerBuscritFunctionId);
				}
			}
		}
		catch(Exception ex){
			log.error(ex, ex);
		}
		finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (con != null) {
					c3parSession.releaseConnection();
				}
			} catch (SQLException e) {
				log.error(e, e);
			}
		}
		return emerBuscritFunctionId;
	}

	/**
	 * Gets the rfc questionaire function id.
	 *
	 * @return the rfc questionaire function id
	 */
	public String getRfcQuestionaireFunctionId() {
		log.info("IPRegHelper.getRfcQuestionaireFunctionId() Starts");
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		DatabaseSession c3parSession = C3parSessionFactory.getC3parSession();
		String functionId = null;
		try {
			con = c3parSession.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery("select ID from c3par_function where description='CONTINGENCY_CHANGES'");
			if (rs.next()) {
				functionId = String.valueOf(rs.getInt(1));
				log.debug("IPRegHelper.getRfcQuestionaireFunctionId() with functionId = " + functionId);
			}
		}
		catch (SQLException sqle) {
			log.error(sqle.getMessage() + " with error code " + sqle.getErrorCode());
		} catch (DatabaseException de) {
			log.error(de.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
		} finally {
			c3parSession.closeResultSet(rs);
			c3parSession.closeStatement(stmt);
			c3parSession.releaseConnection();
		}
		log.info("IPRegHelper.getRfcQuestionaireFunctionId() Ends");
		return functionId;
	}
}