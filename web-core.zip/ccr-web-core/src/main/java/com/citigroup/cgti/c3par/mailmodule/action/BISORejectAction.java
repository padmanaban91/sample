package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;

/**
 * 
 * @author ne36745
 *
 */
public class BISORejectAction extends MailAction {

	Logger log = Logger.getLogger(BISORejectAction.class);
	
	private final static String ROLE = "BISO";
	
	private final static String STATUS = "REJECTED";
	private static final String SUCCESS = "Successful";
	private static final String FAILURE = "Failed";
	
	@Override
	public void process(IncomingMessage message) {
		log.info("Process method of IsoApproveAction --------------------");
		
		Long processId = null;
		
		if (message != null && message.getProcessId() != null) {
			processId = Long.parseLong(message.getProcessId().trim());
		}
		Long tiRequestId = getTIRequestID(processId);
		
		if (checkReferenceNumber(message.getReferenceNo(), tiRequestId,message.getSsoId())) {
		
			String instanceId = null;
			
			SqlRowSet rs = getJdbcTemplate().queryForRowSet("select bpm_instance_id from ti_activity_trail "+
					" where bpm_instance_id is not null and ti_request_id = (select max(id) from ti_request where process_id = "+processId+") and activity_status = 'SCHEDULED'");
			
			if (rs.next()) {
				instanceId = rs.getString(1);
			}
			
		    WsPapiFacade papiFacade = new WsPapiFacade ();
	
	        log.debug("Before calling PAPI --------------------------- ");
	        
	        //message.setSsoId("hb26743");
	        
	        Long userId = getUserID(message.getSsoId());
	
	        try {
	        	addComments(message.getComments(), tiRequestId, ROLE, userId);
				papiFacade.completeActivity(message.getSsoId(), instanceId, WsPapiFacade.ActivityStatus.REJECTED, WsPapiFacade.ActivityRejectedToRole.PC_ROLE);
				sendAckMail(message.getAction(),message.getSsoId(),processId,SUCCESS,message.getEntity());
				update(message.getMailID(),message.getReferenceNo(),"Y","Action completed successfully");
	        } catch (OperationException_Exception e) {
	        	sendAckMail(message.getAction(),message.getSsoId(),processId,FAILURE,message.getEntity());
	        	update(message.getMailID(),message.getReferenceNo(),"N",getExceptionMessage(e));
				log.error(e,e);
				e.printStackTrace();
			} 
		} else {
			sendAckMail(message.getAction(),message.getSsoId(),processId,FAILURE,message.getEntity());
			update(message.getMailID(),message.getReferenceNo(),"N","The response Email from the user is not authorized");
			log.debug("Refernce ID not matching "+ message.getReferenceNo());
		}

		log.info("End of Process method of IsoApproveAction --------------------");
	}
	
}
