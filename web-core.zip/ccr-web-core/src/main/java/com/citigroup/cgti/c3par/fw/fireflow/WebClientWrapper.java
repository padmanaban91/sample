/*package com.citigroup.cgti.c3par.fw.fireflow;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.impl.client.DefaultHttpClient;

import com.citigroup.cgti.c3par.util.C3parProperties;

public class WebClientWrapper {

	public static HttpClient wrapClient(HttpClient base) {
	
	try {
		SSLContext ctx = SSLContext.getInstance("TLS");
		X509TrustManager tm = new X509TrustManager() {
		
			public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {
			}
		
			public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
			}
		
			public X509Certificate[] getAcceptedIssuers() {
			return null;
		    }
		};
		String keystorePassord = "changeit";
		KeyStore ks = KeyStore.getInstance("JKS");
		ks.load( null, null );
		//FileInputStream fis = new FileInputStream(C3parProperties.ALGOSEC_CERTIFICATE);
		FileInputStream fis = new FileInputStream("c:\\soa\\AlgoSec1080-Lab.eur.nsroot.net.crt");
		BufferedInputStream bis = new BufferedInputStream(fis);   
		CertificateFactory cf = CertificateFactory.getInstance( "X.509" );   
		Certificate cert = null; 
		while ( bis.available() > 0 )   
		{   
		 cert = cf.generateCertificate( bis );   
		 ks.setCertificateEntry("SGCert", cert );   
		}   
	
		KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		kmf.init(ks, keystorePassord.toCharArray());
		ctx.init(kmf.getKeyManagers(), new TrustManager[] { tm }, null);
		HostnameVerifier hostnameVerifier = org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;
		SSLSocketFactory ssf = new SSLSocketFactory(ctx,((X509HostnameVerifier) hostnameVerifier));
		ClientConnectionManager ccm = base.getConnectionManager();
		SchemeRegistry sr = ccm.getSchemeRegistry();
		sr.register(new Scheme("https", 443, ssf));
		return new DefaultHttpClient(ccm, base.getParams());
		} 
	catch (Exception ex) {
	ex.printStackTrace();
	return null;
	}
	}
}

*/