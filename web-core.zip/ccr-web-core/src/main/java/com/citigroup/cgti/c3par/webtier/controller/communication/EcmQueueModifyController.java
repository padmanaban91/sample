package com.citigroup.cgti.c3par.webtier.controller.communication;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.communication.domain.EcmLeadViewProcess;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueViewProcess;



@Controller
public class EcmQueueModifyController{    

	private static Logger log = Logger.getLogger(EcmQueueModifyController.class);

	@RequestMapping(value = "/selectEcmQueueViewUser.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String ecmQueueModiy(ModelMap model, @ModelAttribute("ecmQueueViewProcess") EcmQueueViewProcess ecmQueueViewProcess
									,HttpServletRequest request) {
				log.info("EcmQueueModifyController::ecmQueueModiy methods starts...");
				
				
				model.addAttribute("ecmQueueViewProcess",ecmQueueViewProcess);
				return "c3par.communication.ecmQueueModify";
				
	} 
	
	
	@RequestMapping(value = "/mapEcmUsertoSector.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String mapEcmUsertoSector(ModelMap model, @ModelAttribute("ecmQueueViewProcess") EcmQueueViewProcess ecmQueueViewProcess,BindingResult result
									,HttpServletRequest request) {
				log.info("Entering into mapEcmUsertoSector()..");
				String ecmUser = (String) request.getParameter("ecmUser");
				log.debug("ecmUser::" + ecmUser);					
				
				boolean validUser = false;
				validUser = ecmQueueViewProcess.checkValidUser(ecmUser);
				log.info("validUser:: "+validUser);						
				if(!validUser){
					//ecmQueueViewProcess.setErrorMessage("ECM User cannot be mapped due to invalid user.");
					result.addError(new ObjectError(
							"ecmUser",
							"ECM User cannot be mapped due to invalid user."));
				}else{
					String sector = (String) request.getParameter("sector");
					log.debug("sector::" + sector);					
					String userId = request.getHeader("SM_USER"); 
					ecmQueueViewProcess.mapEcmUsertoSector(Long.valueOf(sector),ecmUser,userId);
				}
				log.info("Exit from mapEcmUsertoSector()..");
				model.addAttribute("ecmQueueViewProcess",ecmQueueViewProcess);
				return "c3par.communication.ecmQueueModify";
	}
	
	 
}

