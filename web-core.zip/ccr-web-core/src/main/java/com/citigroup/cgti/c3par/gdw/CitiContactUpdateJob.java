/**
 * 
 */
package com.citigroup.cgti.c3par.gdw;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.context.ApplicationContext;

import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;

/**
 * @author ka58098
 *
 */
public class CitiContactUpdateJob implements Job {
    private static Logger log = Logger.getLogger(CitiContactUpdateJob.class);
    private ApplicationContext appContext = null;
  
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.info("Start job ::");
        appContext = CCRApplicationContextUtils.getApplicationContext();
        CitiContactUpdateUtil citiContactUpdateUtil = (CitiContactUpdateUtil) appContext.getBean("citiContactUpdateScheduler");
        citiContactUpdateUtil.synchCCR_GDW();
        log.info("End job ::");
    }
}
