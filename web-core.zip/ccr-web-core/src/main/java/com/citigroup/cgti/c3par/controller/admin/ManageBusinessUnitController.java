package com.citigroup.cgti.c3par.controller.admin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.citigroup.cgti.c3par.admin.domain.AddCitiBusinessUnitProcess;
import com.citigroup.cgti.c3par.admin.domain.CitiGroupInfoProcess;
import com.citigroup.cgti.c3par.admin.domain.GetAllPLCodeProcess;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;
import com.citigroup.cgti.c3par.soa.wfpprofile.FMOHierarchyType;

import com.citigroup.cgti.c3par.webtier.forms.PLCodes;
import com.sun.xml.ws.fault.ServerSOAPFaultException;

@Controller
public class ManageBusinessUnitController {
	
	private static Logger log = Logger.getLogger(ManageBusinessUnitController.class);
	
	@RequestMapping(value = "/manageCitiGroupInfo.act", method = RequestMethod.GET)
	public ModelAndView initialize(
			ModelMap model,
			@ModelAttribute("citiGroupInfoForm") CitiGroupInfoProcess citiGroupInfoForm,
			BindingResult result) {
		if (citiGroupInfoForm == null) {
			citiGroupInfoForm = new CitiGroupInfoProcess();
		}
		HashMap <String,String> regionList = new HashMap<String, String>();
		HashMap <String,String> sectorList = new HashMap<String, String>();
		try{
		regionList = citiGroupInfoForm.getRegionList();
		log.info("initialize in ManageBusinessUnitController"+citiGroupInfoForm.getRegionList().toString());
		sectorList = citiGroupInfoForm.getSectorList();
		
		}
		catch (Exception e) {
			log.debug("In Exception initialize");
			//log.error(e,e);
			ObjectError error = new ObjectError("name",e.getMessage());
			result.addError(error);
		}
		model.addAttribute("regionList", regionList);
		model.addAttribute("sectorList", sectorList);
		return new ModelAndView("c3par.admin.citiGroupInfo",
				"citiGroupInfoForm", citiGroupInfoForm);

	}
	@RequestMapping(value = "/manageCitiGroupInfo.act", method = RequestMethod.POST)
	public ModelAndView initializeOnCancel(
			ModelMap model,
			@ModelAttribute("citiGroupInfoForm") CitiGroupInfoProcess citiGroupInfoForm,
			BindingResult result) {
		if (citiGroupInfoForm == null) {
			citiGroupInfoForm = new CitiGroupInfoProcess();
		}
		HashMap <String,String> regionList = new HashMap<String, String>();
		HashMap <String,String> sectorList = new HashMap<String, String>();
		try{
		regionList = citiGroupInfoForm.getRegionList();
		log.info("initialize in ManageBusinessUnitController"+citiGroupInfoForm.getRegionList().toString());
		sectorList = citiGroupInfoForm.getSectorList();
		}catch (Exception e) {
			log.debug("In Exception initializeOnCancel");
			//log.error(e,e);
			ObjectError error = new ObjectError("name",e.getMessage());
			result.addError(error);
		}
		model.addAttribute("regionList", regionList);
		model.addAttribute("sectorList", sectorList);
		return new ModelAndView("c3par.admin.citiGroupInfo",
				"citiGroupInfoForm", citiGroupInfoForm);

	}


	
	@RequestMapping(value = "/citiGroupInfoFormAddBUnit.act", method = RequestMethod.POST)
	public ModelAndView addBUnit(
			ModelMap model,
			@ModelAttribute("addCitiBusinessUnitForm") AddCitiBusinessUnitProcess addCitiBusinessUnitFormModel,
			BindingResult result) {
		AddCitiBusinessUnitProcess addCitiBusinessUnitForm = new AddCitiBusinessUnitProcess();
		HashMap <String,String> sectorList = new HashMap<String, String>();
		try{
		CitiGroupInfoProcess citiGroupInfoForm = new CitiGroupInfoProcess();
		sectorList = citiGroupInfoForm.getSectorList();
		
	
			log.debug("In addBUnit");
		}
		catch (Exception e) {
			log.debug("In Exception addBUnit");
			//log.error(e,e);
			ObjectError error = new ObjectError("name",e.getMessage());
			result.addError(error);
		}
		model.addAttribute("sectorList", sectorList);
		return new ModelAndView("c3par.admin.addBusinessUnit",
				"addCitiBusinessUnitForm", addCitiBusinessUnitForm);

	}

	@RequestMapping(value = "/citiGroupInfoFormSaveBUnit.act", method = RequestMethod.POST)
	public ModelAndView saveBUnit(
			ModelMap model,
			@ModelAttribute("addCitiBusinessUnitForm") AddCitiBusinessUnitProcess addCitiBusinessUnitForm,
			BindingResult result) {
			log.debug("In saveBUnit"+addCitiBusinessUnitForm.getSectorName());
			Sector sector = new Sector();
			log.debug("Sec ID"+addCitiBusinessUnitForm.getCostCenter());
			sector.setId(Long.valueOf(addCitiBusinessUnitForm.getSectorName()));
			HashMap <String,String> sectorList = new HashMap<String, String>();
			BusinessUnit bUnit = new BusinessUnit();
			bUnit.setBusinessName(addCitiBusinessUnitForm.getUnitName());
			bUnit.setCostCenter(addCitiBusinessUnitForm.getCostCenter());
			bUnit.setDescription(addCitiBusinessUnitForm.getDescription());
			bUnit.setSector(sector);
			bUnit.setIsactive("Y");
			CitiGroupInfoProcess citiGroupInfoForm = new CitiGroupInfoProcess();
			try{
				sectorList = citiGroupInfoForm.getSectorList();
			String message = citiGroupInfoForm.addBusinessUnit(bUnit);
			log.debug("Out Message"+message);
			if(message!=null&&!(message.equalsIgnoreCase(""))){
				log.debug("In message"+message);
				citiGroupInfoForm.validate(message);
			}
			
		
			} catch(Exception e){
				log.debug("In Exception saveBUnit");
				//log.error(e,e);
				ObjectError error = new ObjectError("name",e.getMessage());
				result.addError(error);
			}
			model.addAttribute("sectorList", sectorList);
		return new ModelAndView("c3par.admin.addBusinessUnit",
				"addCitiBusinessUnitForm", addCitiBusinessUnitForm);

	}
	
	@RequestMapping(value = "/getPLCodes.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String getPLCodes(
			ModelMap model,
			@ModelAttribute("getAllPLCodeForm") GetAllPLCodeProcess getAllPLCodeForm,
			BindingResult result) {
			log.debug("In getPLCodes");
			getAllPLCodeForm.setDisplay("no");
		return "pages/jsp/search/getAllPLCode";

	}
	
	@RequestMapping(value = "/getListPLCodes.act", method = RequestMethod.POST)
	public String listPLCodes(
			ModelMap model,
			@ModelAttribute("getAllPLCodeForm") GetAllPLCodeProcess getAllPLCodeForm,
			BindingResult result,
			HttpServletRequest request) {
			log.debug("In getPLCodesList "+  getAllPLCodeForm.getPlcode());
			try {
			   
			    SOADataComponent soaDataComponent = new SOADataComponent();
			    ProfileInfoFactory profileInfoFactory =
				(ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");

			    List<FMOHierarchyType> fmoHierarchyType =
				profileInfoFactory.getFMOService().getFMODetailsByExpenseCode(null, getAllPLCodeForm.getPlcode(), request.getHeader("SM_USER"));

			    List<PLCodes>plAllCodesList = new ArrayList<PLCodes>();
			    for (FMOHierarchyType type : fmoHierarchyType) {
			    PLCodes info = new PLCodes();
				info.setId(type.getCodes().getExpenseCode());
				info.setValues(new ArrayList(3));
				info.getValues().add(type.getCodes().getExpenseCode());
				info.getValues().add(type.getBusinessHeirarcy().getValue().getExpenseCodeDesc());
				StringBuffer plCodeList = new StringBuffer();
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel00() != null ? type.getBusinessHeirarcy().getValue().getLevel00().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel01() != null ? type.getBusinessHeirarcy().getValue().getLevel01().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel02() != null ? type.getBusinessHeirarcy().getValue().getLevel02().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel03() != null ? type.getBusinessHeirarcy().getValue().getLevel03().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel04() != null ? type.getBusinessHeirarcy().getValue().getLevel04().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel05() != null ? type.getBusinessHeirarcy().getValue().getLevel05().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel06() != null ? type.getBusinessHeirarcy().getValue().getLevel06().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel07() != null ? type.getBusinessHeirarcy().getValue().getLevel07().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel08() != null ? type.getBusinessHeirarcy().getValue().getLevel08().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel09() != null ? type.getBusinessHeirarcy().getValue().getLevel09().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel10() != null ? type.getBusinessHeirarcy().getValue().getLevel10().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel11() != null ? type.getBusinessHeirarcy().getValue().getLevel11().getBusinessName() : "-");
				plCodeList.append(type.getBusinessHeirarcy().getValue().getLevel12() != null ? type.getBusinessHeirarcy().getValue().getLevel12().getBusinessName() : "-");
				info.getValues().add(plCodeList.toString());
				plAllCodesList.add(info);
				}
			    getAllPLCodeForm.setPlCodesList(plAllCodesList);
			    getAllPLCodeForm.setDisplay("yes");
			    if(plAllCodesList.size()<1){
			    	new CitiGroupInfoProcess().validate("No Result Found");
			    }
			}catch (Exception e){
				log.debug("In Exception listPLCodes");
				log.error(e.toString(),e);
				ObjectError error=null;
				if (e instanceof ServerSOAPFaultException){
					log.error("SOAPFaultException received..!!!");
					error= new ObjectError("name",ECMConstants.ERROR_MSG_SOA);
				} else{
					error= new ObjectError("name",e.getMessage());
					
				}
				result.addError(error);
				
			}
		return "pages/jsp/search/getAllPLCode";

	}
	
	@RequestMapping(value = "/loadBusinessUnits.act", method = RequestMethod.POST)
	public @ResponseBody String loadBUnit(
			ModelMap model,
			@ModelAttribute("citiGroupInfoForm") CitiGroupInfoProcess citiGroupInfoForm,
			BindingResult result) {
		log.debug("Selected Sector in loadBUnit starts");
		String sector = citiGroupInfoForm.getSectorIdString();
		log.debug("Selected Sector in loadBUnit"+sector);
		StringBuffer  bUnitJSONSB = new StringBuffer();
		try{
		List<BusinessUnit> bUnitList = citiGroupInfoForm.getBusinessUnit(sector);
		citiGroupInfoForm.setbUnitList(bUnitList);
		bUnitJSONSB.append("[");
		 bUnitJSONSB.append("{\"item\":\"-1\",\"label\":\"ALL BUSINESS UNIT\"}");
		for (BusinessUnit bUnit : bUnitList) {
			log.debug("Selected Sector in loadBUnit"+bUnit.getBusinessName() );
			bUnitJSONSB.append(",{\"item\":\"" + bUnit.getId()
					+ "\",\"label\":\"" + bUnit.getBusinessName() + "\"}");
		}
		bUnitJSONSB.append("]");
		log.debug("Json Data: " + bUnitJSONSB.toString());
		}
		catch (Exception e) {
			log.debug("In Exception loadBUnit");
			//log.error(e,e);
			ObjectError error = new ObjectError("name",e.getMessage());
			result.addError(error);
		}
		return bUnitJSONSB.toString();
			
	}
	
	@RequestMapping(value = "/createMappingCitiGroupInfo.act", method = RequestMethod.POST)
	public ModelAndView createMapping(
			ModelMap model,
			@ModelAttribute("citiGroupInfoForm") CitiGroupInfoProcess citiGroupInfoForm,
			BindingResult result) {
		HashMap <String,String> regionList = new HashMap<String, String>();
		HashMap <String,String> sectorList = new HashMap<String, String>();
		log.info("createMapping in ManageBusinessUnitController");
		try{
			 regionList = citiGroupInfoForm.getRegionList();
			 sectorList = citiGroupInfoForm.getSectorList();
			 String message = citiGroupInfoForm.addCitiHierMaster(citiGroupInfoForm.getRegionIdString(),citiGroupInfoForm.getSectorIdString(),citiGroupInfoForm.getbUnitIdString());
		log.debug("Out Message"+message);
		if(message!=null&&!(message.equalsIgnoreCase(""))){
			log.debug("In message"+message);
			citiGroupInfoForm.validate(message);
		}		
		}
		catch (Exception e) {
			log.debug("In Exception createMapping");
			//log.error(e,e);
			ObjectError error = new ObjectError("name",e.getMessage());
			result.addError(error);
		}
		model.addAttribute("regionList", regionList);
		model.addAttribute("sectorList", sectorList);
		return new ModelAndView("c3par.admin.citiGroupInfo",
				"citiGroupInfoForm", citiGroupInfoForm);

	}
	
}
