package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;

public class BusinessManagerRejectAction extends MailAction {

Logger log = Logger.getLogger(BusinessManagerRejectAction.class);
	
private final static String ROLE_NAME = "Manager";

	@Override
	public void process(IncomingMessage message) {
		
		log.info("Inside BusinessManagerRejectAction process method ");
		
		super.processReject(message,ROLE_NAME);
		
	}
}
