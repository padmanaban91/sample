/**
 *
 */
package com.citigroup.cgti.c3par.service.admin;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.LongType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.admin.domain.DoNotSendMailList;
import com.citigroup.cgti.c3par.admin.domain.DonotSendMailProcess;
import com.citigroup.cgti.c3par.admin.domain.soc.persist.DonotSendMailServicePersistable;
import com.citigroup.cgti.c3par.model.CitiContactExtEntity;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.soa.model.ProfileEntity;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;
import com.citigroup.cgti.c3par.soa.util.SOAException;

/**
 * @author pc79439
 * 
 */
@SuppressWarnings("unchecked")
@Transactional
public class DonotSendMailServiceImpl extends BasePersistanceImpl implements DonotSendMailServicePersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(DonotSendMailServiceImpl.class);

	/*
	 * 
	 * Method to retrieve DoNotSendEmailList
	 * 
	 * @nc43495
	 */
	@Override
	@Transactional(readOnly = true)
	public List<DoNotSendMailList> getDoNotSendEmailList(DonotSendMailProcess donotsendmailprocess) {
		log.info("DonotSendMailServiceImpl :: getDoNotSendEmailList starts here ...");
		log.info("DonotSendMailServiceImpl :: getDoNotSendEmailList starts here ..."+donotsendmailprocess.getLimit());
		log.info("DonotSendMailServiceImpl :: getDoNotSendEmailList starts here ..."+donotsendmailprocess.getOffset());
		Session session = getSession();

		Criteria criteria = session.createCriteria(DoNotSendMailList.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		criteria.add(Restrictions.eq("isDeleted", "N"));
		criteria.addOrder(Order.desc("updated_date"));

		donotsendmailprocess.setRowCount(getRowCount(criteria));

		if (donotsendmailprocess.isPaginationRequired()) {
			log.info("DonotSendMailServiceImpl :: isPaginationRequired");
			addPagination(criteria, donotsendmailprocess.getOffset(),donotsendmailprocess.getLimit());
		}

		List<DoNotSendMailList> list = criteria.list();
		log.debug("DonotSendMailServiceImpl :: getDoNotSendEmailList" + list);
		if (list != null)
			log.info("DonotSendMailServiceImpl :: getDoNotSendEmailListt :: ends here ::" + list.size());
		return list;

	}

	/*
	 * The Method to save DoNotSendEmailList
	 * 
	 * @nc43495
	 */
	@Override
	public void saveDoNotSendEmailList(String soeId) {
		log.info("DonotSendMailServiceImpl :: save doNotSendEmail :: SOEID -> " + soeId);

		Session session = getSession();
		DoNotSendMailList doNotSendEmail = null;
		SQLQuery sqlQuery = session.createSQLQuery("select id from citi_contact where upper(sso_id) = '" + soeId.toUpperCase() + "'");
		sqlQuery.addScalar("id", LongType.INSTANCE);
		List<Long> citiContactlist = (List<Long>) sqlQuery.list();
		Long citiContactId = null;
		// Fetching contact id to in citi_contact table
		if (citiContactlist != null && citiContactlist.size() > 0) {
			citiContactId = citiContactlist.get(0);
		} else {
			SOADataComponent soaDataComponent = new SOADataComponent();
			ProfileInfoFactory profileInfoFactory = (ProfileInfoFactory) soaDataComponent.getServiceFactory("profileInfo");
			ProfileEntity profileEntity = new ProfileEntity();
			try {
				profileEntity.setSoeId(soeId.toUpperCase());
			} catch (SOAException e) {
				log.error(e, e);
				e.printStackTrace();
			}
			List citiContactList = null;
			try {
				citiContactList = profileInfoFactory.getRitzService()
						.getProfile(profileEntity, soeId.toUpperCase());
			} catch (RemoteException e) {
				log.error(e, e);
				e.printStackTrace();
			} catch (SOAException e) {
				log.error(e, e);
				e.printStackTrace();
			}
			Iterator it = citiContactList.iterator();
			if (it.hasNext()) {
				CitiContactExtEntity entity = (CitiContactExtEntity) it.next();
				SQLQuery insertQuery = session
						.createSQLQuery("insert into citi_contact(ID,FIRST_NAME,LAST_NAME,RITS_ID,PHONE,EMAIL,SSO_ID,EMPLOYEE_TYPE,GEID,EMPLOYEE_STATUS,SUPERVISOR_GEID,SUPERVISOR_FIRST_NAME,SUPERVISOR_LAST_NAME) "
								+ " values(seq_citi_contact.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?) ");
				insertQuery.setString(0, entity.getFirstName());
				insertQuery.setString(1, entity.getLastName());
				insertQuery.setString(2, entity.getRitsId());
				insertQuery.setString(3, entity.getPhone());
				insertQuery.setString(4, entity.getEmail());
				insertQuery.setString(5, entity.getSsoId());
				insertQuery.setString(6, entity.getEmployeeType());
				insertQuery.setString(7, entity.getGeId());
				insertQuery.setString(8, entity.getEmployeeStatus());
				insertQuery.setString(9, entity.getSupervisorGeId());
				insertQuery.setString(10, entity.getSupervisorFirstName());
				insertQuery.setString(11, entity.getSupervisorLastName());
				insertQuery.executeUpdate();

				List<Long> list = (List<Long>) sqlQuery.list();
				if (list != null && !list.isEmpty()) {
					citiContactId = list.get(0);
					log.debug("Insertion into CitiContact table done:" + insertQuery);
				}
			}
		}

		List<DoNotSendMailList> list = (List<DoNotSendMailList>) session.createQuery("from DoNotSendMailList dlist where upper(dlist.soeID)=upper('" + soeId + "') ").list();
		// Updating SOEID incase of soft delete
		if (list != null && list.size() > 0) {
			log.info("save doNotSendEmail :: UpdateContact");
			doNotSendEmail = list.get(0);
			doNotSendEmail.setCitiContactId(citiContactId);
			doNotSendEmail.setIsDeleted("N");
			doNotSendEmail.setUpdated_date(new Date());

		} else {
			// Saving contact to table DO_NOT_SEND_LIST
			log.info("save doNotSendEmail :: SaveContact");
			doNotSendEmail = new DoNotSendMailList();
			doNotSendEmail.setCitiContactId(citiContactId);
			doNotSendEmail.setSoeID(soeId.toUpperCase());
			doNotSendEmail.setIsDeleted("N");
			doNotSendEmail.setUpdated_date(new Date());
			doNotSendEmail.setCreated_date(new Date());
		}
		session.saveOrUpdate(doNotSendEmail);

		SQLQuery updateQuery = session.createSQLQuery("update generic_lookup set GENERIC_LOOKUP.VALUE1 = 'Y' where DEFINITION_ID in (select id from GENERIC_LOOKUP_DEFS where name ='DO_NOT_SEND_LIST_MODIFIED')");
		updateQuery.executeUpdate();
		log.debug("update on generic lookup for do no send list modified:" + updateQuery);

		log.info("DonotSendMailServiceImpl :: save doNotSendEmail :: ends here");
	}

	/**
	 * The method to delete DoNotSendEmailList
	 * 
	 * @nc43495
	 * 
	 */
	@Override
	public void deleteDoNotSendEmailList(List<String> soeIdList) {
		log.info("Delete DoNotSendEmailList starts here ...");
		Session session = getSession();
		StringBuffer ssoId = new StringBuffer();
		int i = 0;
		// Fetching SOEID's
		for (String soeId : soeIdList) {
			if (i > 0) {
				ssoId.append(",");
			}
			ssoId.append("'" + soeId.toUpperCase().replace(",", "','") + "'");
			i++;
		}

		SQLQuery sqlQuery = session.createSQLQuery("update do_not_send_list set is_deleted = 'Y' where upper(sso_id) in (" + ssoId.toString() + ")");
		sqlQuery.executeUpdate();
		SQLQuery updateQuery = session.createSQLQuery("update generic_lookup set GENERIC_LOOKUP.VALUE1 = 'Y' where DEFINITION_ID in (select id from GENERIC_LOOKUP_DEFS where name ='DO_NOT_SEND_LIST_MODIFIED')");
		updateQuery.executeUpdate();

		log.debug("update on generic lookup for do no send list modified delete:" + updateQuery);
		log.info("Delete DoNotSendEmailList ends here ..." + sqlQuery);
	}
}