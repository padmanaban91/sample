/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.reports.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.citigroup.cgti.c3par.reports.dao.RequestReportDAO;
import com.citigroup.cgti.c3par.reports.reportInterface.ReportException;
import com.mentisys.util.logging.Logger;



/**
 * The Class DBUtil.
 *
 * @author pkadam
 */
public class DBUtil {

    /** The Constant log. */
    static private final Logger log = Logger.getLogger("reports", RequestReportDAO.class);

    /**
     * Gets the connection.
     *
     * @param jndiName the jndi name
     * @return the connection
     */
    public static Connection getConnection(String jndiName){
	Connection connection = null;
	try {
	    InitialContext ctx = new InitialContext();
	    DataSource source = (DataSource) ctx.lookup(jndiName);
	    if (null != source) {
		connection = source.getConnection();
	    }
	} catch (Exception e) {
	    log.error("Failed to obtain a database connection to '{0}'", 
		    new Object[]{jndiName}, e);
	}
	return connection;
    }

    /**
     * Close statement.
     *
     * @param stmt the stmt
     */
    public static void closeStatement(Statement stmt) {
	try {
	    if (stmt != null)
		stmt.close();
	}catch(SQLException se){
	    log.warning("Error closing the SQL Statement ",new Object[]{stmt});
	}		
    }

    /**
     * Close result set.
     *
     * @param rs the rs
     */
    public static void closeResultSet(ResultSet rs) {
	try {
	    if (rs != null)
		rs.close();
	}catch(SQLException se){
	    log.warning("Error closing the Result set",new Object[]{rs});
	}		
    }

    /**
     * Close connection.
     *
     * @param con the con
     */
    public static void closeConnection(Connection con) {
	try {
	    if (con != null && !con.isClosed())
		con.close();
	}catch(SQLException se){
	    log.warning("Error closing the Connection",new Object[]{con});
	}		
    }

    /**
     * Gets the row count.
     *
     * @param jndiName the jndi name
     * @param sqlStatement the sql statement
     * @return the row count
     * @throws ReportException the report exception
     */
    public static long getRowCount(String jndiName, String sqlStatement) throws ReportException {
	StringBuffer sb = new StringBuffer();
	sb.append("select count(*) from (");
	sb.append(sqlStatement).append(") dyna_table");

	Connection connection = getConnection(jndiName);
	ResultSet rs = null ;
	Statement stmt = null;
	try{
	    stmt = connection.createStatement();
	    rs = stmt.executeQuery(sb.toString());
	    while(rs.next()){
		return rs.getLong(1);
	    }

	    throw new ReportException("Error retriving the number of records");
	}catch(Exception e){
	    throw new ReportException("Unable to retrive value from the database");
	}finally{
	    closeStatement(stmt);
	    closeResultSet(rs);
	    closeConnection(connection);
	}		
    }

    /**
     * Table exists.
     *
     * @param jndiName the jndi name
     * @param tableName the table name
     * @param closeConnection the close connection
     * @return true, if successful
     * @throws ReportException the report exception
     */
    public static boolean tableExists(String jndiName, String tableName, boolean closeConnection) throws ReportException {
	Connection connection = DBUtil.getConnection(jndiName);
	return tableExists(connection, tableName, closeConnection);
    }

    /**
     * Table exists.
     *
     * @param jndiName the jndi name
     * @param tableName the table name
     * @return true, if successful
     * @throws ReportException the report exception
     */
    public static boolean tableExists(String jndiName, String tableName) throws ReportException {
	return tableExists(jndiName, tableName, true);
    }

    /**
     * Table exists.
     *
     * @param connection the connection
     * @param tableName the table name
     * @param closeConnection the close connection
     * @return true, if successful
     * @throws ReportException the report exception
     */
    public static boolean tableExists(Connection connection,String tableName, boolean closeConnection) throws ReportException {
	try {
	    Statement stmt = connection.createStatement();
	    ResultSet rs = stmt.executeQuery("Select count(*) from "+tableName);
	    return true;
	}catch(Exception e){
	    return false;
	} finally {
	    if (closeConnection)
		closeConnection(connection);
	}
    }

    /**
     * Drop table.
     *
     * @param connection the connection
     * @param tableName the table name
     * @param closeConnection the close connection
     * @throws ReportException the report exception
     */
    public static void dropTable(Connection connection, String tableName, boolean closeConnection) throws ReportException {
	String command = ("Drop table " + tableName);
	try{
	    Statement stmt = connection.createStatement();
	    stmt.executeUpdate(command);
	}catch(Exception e){
	    throw new ReportException("Could not delete the table " + tableName);
	} finally {
	    if(closeConnection)
		DBUtil.closeConnection(connection);
	}		
    }

    /**
     * Drop table.
     *
     * @param jndiName the jndi name
     * @param tableName the table name
     * @throws ReportException the report exception
     */
    public static void dropTable(String jndiName, String tableName) throws ReportException {
	Connection connection = null;
	try{
	    connection = DBUtil.getConnection(jndiName);
	    dropTable(connection, tableName, true);
	}catch(Exception e){
	    throw new ReportException("Could not delete the table " + tableName);
	} finally {
	    if(connection != null)
		DBUtil.closeConnection(connection);
	}	
    }
}
