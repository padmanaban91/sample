/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.webtier.sessionmgmt;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;


/**
 * A factory for creating SessionMgmtComponent objects.
 *
 * @author pkadam
 * 
 * This factory creates instances of SessionValidator and CorruptSessionResponseHandler
 * type. The factory uses the information provided in a properties file named
 * SessionMgmtComponentRegistry.properties. The file should be available thru the classpath.
 * 
 * The properties file contains mapping entries of type
 * check.<struts-action-url>=<SessionValidator-class-name>
 * response.<struts-action-url>=<url-within-application>
 * 
 * check.<struts-action-url> relates the action in the request. To perform the necessary
 * validation an instance of session validator classname specified as value is used.
 * 
 * response.<struts-action-url> relates to the response to be generated if session
 * is found corrupt. If corrupt the response is the URL specified as value of this property.
 */
public class SessionMgmtComponentFactory {

    /** The inited. */
    private boolean inited = false ;

    /** The factory. */
    private static SessionMgmtComponentFactory factory ;

    /** The bundle. */
    private ResourceBundle bundle ;

    /** The session validator instances. */
    private final Map sessionValidatorInstances = new HashMap();

    /** The session corrupt response pairs. */
    private final Map sessionCorruptResponsePairs = new HashMap();

    /** The default validator. */
    private SessionValidator defaultValidator = new DefaultSessionValidator();

    /** The corrupt session response handler. */
    private CorruptSessionResponseHandler corruptSessionResponseHandler = null ;

    /** The log. */
    private static Logger log = Logger.getLogger(SessionMgmtComponentFactory.class);

    /**
     * Instantiates a new session mgmt component factory.
     *
     * @param bundle the bundle
     */
    protected SessionMgmtComponentFactory(ResourceBundle bundle) {
	this.bundle = bundle ;
    }

    /**
     * Gets the single instance of SessionMgmtComponentFactory.
     *
     * @return single instance of SessionMgmtComponentFactory
     */
    public synchronized static SessionMgmtComponentFactory getInstance() {
	if(factory == null) {
	    ResourceBundle bundle = ResourceBundle.getBundle("SessionMgmtComponentRegistry");
	    factory = new SessionMgmtComponentFactory(bundle);
	}

	return factory ;
    }

    /**
     * Inits the.
     */
    public synchronized void init() {
	Enumeration keys = bundle.getKeys();

	while(keys.hasMoreElements()) {
	    String key = (String) keys.nextElement();
	    String value = bundle.getString(key);

	    if(key.startsWith("check")) {
		String actionPart = key.substring(6);

		try {
		    Class rpClass = Class.forName(value);
		    SessionValidator validator = (SessionValidator) rpClass.newInstance();
		    sessionValidatorInstances.put(actionPart, validator);
		} catch (Exception e) {
		    log.error("Error Initializing Session Mgmt Validator [" + key + ", " + value + "]." + e);

		    System.exit(0);
		}		
	    } else {
		if (key.startsWith("response")) {
		    String actualKey = key.substring(9);

		    sessionCorruptResponsePairs.put(actualKey, value);
		}
	    }
	}

	inited = true ;
    }

    /**
     * Gets the session validator.
     *
     * @param request the request
     * @return the session validator
     */
    public synchronized SessionValidator getSessionValidator(HttpServletRequest request) {
	// if this is not initialized, initialize it first.
	if(! inited) init();

	String servletPath = request.getServletPath();

	// get a validator for the given servlet path
	SessionValidator validator = (SessionValidator) sessionValidatorInstances.get(servletPath) ;

	// if a validator is not defined for the servlet path,
	// then assume that validation is not required and return the default validator
	if(validator==null) {
	    // this would mean none of the registered session management parameters
	    // were found in the request. So return the default validator
	    validator = defaultValidator ;
	}

	return validator ; 
    }

    /**
     * Gets the corrupt session response handler.
     *
     * @param request the request
     * @return the corrupt session response handler
     */
    public synchronized CorruptSessionResponseHandler getCorruptSessionResponseHandler(HttpServletRequest request) {
	if(corruptSessionResponseHandler == null) {
	    corruptSessionResponseHandler = new DefaultCorruptSessionResponseHandler(sessionCorruptResponsePairs);
	}

	return corruptSessionResponseHandler ;
    }
}
