/**
 *
 */
package com.citigroup.cgti.c3par.businessjustification.service;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.internal.SessionImpl;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.businessjustification.domain.soc.persist.ApprovalReviewServicePersistable;
import com.citigroup.cgti.c3par.discussion.domain.TIRequestCommentsVO;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.mentisys.dao.DatabaseException;

@SuppressWarnings("unchecked")
@Transactional
public class ApprovalReviewServiceImpl extends BasePersistanceImpl implements
		ApprovalReviewServicePersistable {

	private static Logger log = Logger
			.getLogger(ApprovalReviewServiceImpl.class);

	@Transactional(readOnly = true)
	public HashMap<String, String> fetchRequestInfo(String requestId,
			String action) {

		log.debug("Entering into fetchRequestInfo()..");

		HashMap<String, String> reqInfo = new HashMap<String, String>();
		StringBuffer sql = new StringBuffer();

		try {

			if (action.equalsIgnoreCase("COMMENT_PREV")) {
				sql.append("select tr.id,tr.version_number from c3par.ti_request tr where ");
				sql.append("tr.process_id = (select process_id from c3par.ti_request where id ="
						+ requestId + ") ");
				sql.append("and tr.version_number = ((select version_number from c3par.ti_request where id ="
						+ requestId + ")-1) ");
			} else if (action.equalsIgnoreCase("COMMENT_NEXT")) {
				sql.append("select tr.id,tr.version_number from c3par.ti_request tr where ");
				sql.append("tr.process_id = (select process_id from c3par.ti_request where id ="
						+ requestId + ") ");
				sql.append("and tr.version_number = ((select version_number from c3par.ti_request where id ="
						+ requestId + ")+1) ");
			} else {
				sql.append("select tr.id,tr.version_number from c3par.ti_request tr where ");
				sql.append("tr.process_id = (select process_id from c3par.ti_request where id ="
						+ requestId + ") ");
				sql.append("and tr.version_number = ((select version_number from c3par.ti_request where id ="
						+ requestId + ")) ");
			}

			Session session = getSession();

			@SuppressWarnings("unchecked")
			List<Object[]> list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				reqInfo.put("REQ_ID", obj[0].toString() + "");
				reqInfo.put("VERSION_ID", obj[1].toString() + "");
				log.debug(obj[0].toString() + "==" + obj[1].toString());

			}

		} catch (Exception ex) {
			ex.printStackTrace();

		}

		log.debug("Exit from fetchRequestInfo()..");
		return reqInfo;
	}

	@Transactional(readOnly = true)
	public HashMap<String, String> extractReviewComments(long requestId)
			throws Exception {

		log.debug("Entering into extractReviewComments()..");

		HashMap<String, String> comments = new HashMap<String, String>();
		StringBuffer sql = new StringBuffer();

		Session session = getSession();

		List<Object[]> list = null;

		try {

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='PROJECT COORDINATOR' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer pcSB = new StringBuffer("");

			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {
				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				pcSB.append("\n\nSOEID: " + pc2);
				pcSB.append("\tDate: " + pc3);
				pcSB.append("\nComments: " + pc1);

			}
			if (!pcSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_PC, pcSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl  "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='DESIGN ENGINEER' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			StringBuffer deSB = new StringBuffer("");
			for (Object[] obj : list) {
				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				deSB.append("\n\nSOEID: " + pc2);
				deSB.append("\tDate: " + pc3);
				deSB.append("\nComments: " + pc1);

			}

			if (!deSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_DE, deSB.toString());

			// log.info("Design Engg Comments=" + deComments);

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl  "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='BISO'  and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer isoSB = new StringBuffer("");

			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				isoSB.append("\n\nSOEID: " + pc2);
				isoSB.append("\tDate: " + pc3);
				isoSB.append("\nComments: " + pc1);

			}
			if (!isoSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_ISO, isoSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='C3PARSYSTEMADMIN' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer saSB = new StringBuffer("");

			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				saSB.append("\n\nSOEID: " + pc2);
				saSB.append("\tDate: " + pc3);
				saSB.append("\nComments: " + pc1);

			}

			if (!saSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_SA, saSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='TPASWG' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer tpwSB = new StringBuffer("");

			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				tpwSB.append("\n\nSOEID: " + pc2);
				tpwSB.append("\tDate: " + pc3);
				tpwSB.append("\nComments: " + pc1);

			}

			if (!tpwSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_TPWG, tpwSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='Operational_Analyst' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer oaSB = new StringBuffer("");

			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {
				
				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				oaSB.append("\n\nSOEID: " + pc2);
				oaSB.append("\tDate: " + pc3);
				oaSB.append("\nComments: " + pc1);

			}
			if (!oaSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_OA, oaSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='ISTG_Chair' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer istgSB = new StringBuffer("");

			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				istgSB.append("\n\nSOEID: " + pc2);
				istgSB.append("\tDate: " + pc3);
				istgSB.append("\nComments: " + pc1);

			}
			if (!istgSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_ISTG, istgSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='Security Engineer' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer seSB = new StringBuffer("");

			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				seSB.append("\n\nSOEID: " + pc2);
				seSB.append("\tDate: " + pc3);
				seSB.append("\nComments: " + pc1);

			}

			if (!seSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_SE, seSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='Manager' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer mgrSB = new StringBuffer("");

			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				mgrSB.append("\n\nSOEID: " + pc2);
				mgrSB.append("\tDate: " + pc3);
				mgrSB.append("\nComments: " + pc1);

			}
			if (!mgrSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_MGR, mgrSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='Appsense_Implementer' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer apsSB = new StringBuffer("");
			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				apsSB.append("\n\nSOEID: " + pc2);
				apsSB.append("\tDate: " + pc3);
				apsSB.append("\nComments: " + pc1);

			}
			if (!apsSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_APPSENSE_IMPL, apsSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='Proxy_Implementer' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer prxSB = new StringBuffer("");
			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				prxSB.append("\n\nSOEID: " + pc2);
				prxSB.append("\tDate: " + pc3);
				prxSB.append("\nComments: " + pc1);

			}
			if (!prxSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_PROXY_IMPL, prxSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='OTRM' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer otrmSB = new StringBuffer("");
			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				otrmSB.append("\n\nSOEID: " + pc2);
				otrmSB.append("\tDate: " + pc3);
				otrmSB.append("\nComments: " + pc1);

			}
			if (!otrmSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_OTRM, otrmSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='MAD' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer madSB = new StringBuffer("");

			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				madSB.append("\n\nSOEID: " + pc2);
				madSB.append("\tDate: " + pc3);
				madSB.append("\nComments: " + pc1);

			}
			if (!madSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_MAD, madSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='Business User' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer businessUserSB = new StringBuffer("");
			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				businessUserSB.append("\n\nSOEID: " + pc2);
				businessUserSB.append("\tDate: " + pc3);
				businessUserSB.append("\nComments: " + pc1);

			}
			if (!businessUserSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_BUSINESS_USER,
						businessUserSB.toString());

			sql = new StringBuffer("");
			sql.append("select pc_comments.comments,cu.sso_id,to_char(pc_comments.comment_date,'yyyy-mm-dd hh24:mm:ss') "
					+ "from c3par.ti_request_comments pc_comments , c3par.c3par_users cu, c3par.role rl "
					+ "where  pc_comments.comment_type='A' and pc_comments.role_id=rl.id and rl.name='GNCC' and pc_comments.ti_request_id ="
					+ requestId
					+ "and cu.id = pc_comments.user_id order by comment_date desc");

			StringBuffer gnccSB = new StringBuffer("");

			list = null;
			list = session.createSQLQuery(sql.toString()).list();

			for (Object[] obj : list) {

				String pc1 = "";
				if(!("".equals(obj[0]) || obj[0]== null)){
				pc1 = obj[0].toString();
				}
				String pc2 = obj[1].toString();
				String pc3 = obj[2].toString();
				gnccSB.append("\n\nSOEID: " + pc2);
				gnccSB.append("\tDate: " + pc3);
				gnccSB.append("\nComments: " + pc1);

			}
			if (!gnccSB.toString().equalsIgnoreCase(""))
				comments.put(ActivityData.ROLE_GNCC, gnccSB.toString());

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		log.debug("Exit from into extractReviewComments()..");
		return comments;
	}

	@Transactional(readOnly = true)
	public int getCount(String listType, Long ti_request_id, String role)
			throws Exception {

		log.debug("Entering into getCount()..");

		String queryToExecute;
		Session session = getSession();
		int cnt = 0;

		String stmt = "select comments.id, comments.ti_request_id,  comments.comments, "
				+ "role.DISPLAY_NAME, users.SSO_ID , ti_req.version_number,comments.comment_date,comments.LOCKED "
				+ "from c3par.ti_request ti_req , c3par.TI_REQUEST_COMMENTS comments, c3par.role role, c3par.C3PAR_USERS users ";

		StringBuffer sb = new StringBuffer();
		sb.append("select count(*) cnt  from ( ");
		sb.append(stmt);
		String where = getCondition(listType, ti_request_id, role);
		if (!"".equals(where)) {
			sb.append(" WHERE ");
			sb.append(where);
		}
		String orderBy = " comments.comment_date desc";
		if (!"".equals(orderBy))
			sb.append(" ORDER BY " + orderBy);

		sb.append(" ) a ");
		queryToExecute = sb.toString();
		log.debug("Sql is :- " + queryToExecute);

		try {

			Iterator ite = session.createSQLQuery(queryToExecute).list()
					.iterator();

			while (ite.hasNext()) {

				cnt = Integer.parseInt("" + ite.next());
			}

		} catch (Exception e) {
			log.info("Exception during query :- " + e);

			throw new RemoteException(
					"Could not run query = " + queryToExecute, e);
		}

		log.debug("Exit from getCount()..");

		return cnt;
	}

	private String getCondition(String listType, Long ti_request_id, String role) {
		String conditionClause = "";
		if (listType.equalsIgnoreCase("Approval")) {
			conditionClause = " ti_req.process_id in (select a.process_id from c3par.ti_request a where a.id="
					+ ti_request_id
					+ ") "
					+
					// " and (comments.locked = 'N' or comments.locked is null) "
					// +
					"and comments.ti_request_id=ti_req.id and comments.comment_type='A' "
					+ "and comments.role_id = role.id 	and users.id = comments.user_id "
			// +"and upper(role.name) like  upper('" + role + "')"
			;
		} else if (listType.equalsIgnoreCase("Discussion")) {
			conditionClause = " comments.ti_request_id ="
					+ ti_request_id
					+ " "
					+
					// " and (comments.locked = 'N' or comments.locked is null) "
					// +
					"and comments.ti_request_id=ti_req.id and comments.comment_type='D' "
					+ "and comments.role_id = role.id 	and users.id = comments.user_id ";
		} else if (listType.equalsIgnoreCase("AllDiscussion")) {
			conditionClause = " ti_req.process_id in (select a.process_id from c3par.ti_request a where a.id="
					+ ti_request_id
					+ ") "
					+
					// " and (comments.locked = 'N' or comments.locked is null) "
					// +
					"and comments.ti_request_id=ti_req.id and comments.comment_type='D' "
					+ "and comments.role_id = role.id 	and users.id = comments.user_id ";
		}
		return conditionClause;
	}

	@Transactional(readOnly = true)
	public HashMap extractReviewInfo(long requestId) throws Exception {

		log.debug("Entering into extractReviewInfo()..");

		HashMap comments = new HashMap();

		Session session = getSession();

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		long maintenanceConnection = 0;
		try {
			String planingSQL = "select planning_id from c3par.TI_REQUEST_PLANNING_XREF where TI_REQUEST_ID="
					+ requestId;
			con =((SessionImpl) getSession()).connection();
			stmt = con.prepareStatement(planingSQL);
			rs = stmt.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					maintenanceConnection = rs.getLong(1);
				}
			}
			String sql = "";
			if (maintenanceConnection != 0) {
				sql = "select con.iss_connection_compliance, req.infoman_id, "
						+ "req.opeimp_scheduled_date,req.opeimp_completed_date, "
						+ "req.is_citi_risk_assessed,req.tpwapp_review_type, "
						+ "req.tpwapp_review_status,req.tpwapp_review_date,req.tpwapp_rejected_date,"
						+ "req.TPWAPP_TEMP_APP_DATE,req.aps_infoman_id,req.prx_infoman_id, "
						+ "req.apsimp_scheduled_date,req.apsimp_completed_date, req.prximp_scheduled_date,"
						+ " req.prximp_completed_date,req.gnccimp_scheduled_date,"
						+ " req.gnccimp_completed_date,pro.activation_exp_date,req.gncc_infoman_id, req.logging_until, req.rec_log_prd  "
						+ "from c3par.ti_request req, c3par.con_req con "
						+ ",c3par.TI_REQUEST_PLANNING_XREF plngx,ti_process pro "
						+ "where req.id = ? and con.id = plngx.planning_id "
						+ "and plngx.TI_REQUEST_ID=req.id and pro.id = req.process_id";
			} else {
				sql = "select con.iss_connection_compliance, req.infoman_id, "
						+ "req.opeimp_scheduled_date,req.opeimp_completed_date, "
						+ "req.is_citi_risk_assessed,req.tpwapp_review_type, "
						+ "req.tpwapp_review_status,req.tpwapp_review_date,req.tpwapp_rejected_date,"
						+ "req.TPWAPP_TEMP_APP_DATE ,req.aps_infoman_id, "
						+ "req.prx_infoman_id,req.apsimp_scheduled_date,req.apsimp_completed_date,"
						+ " req.prximp_scheduled_date, req.prximp_completed_date,req.gnccimp_scheduled_date,"
						+ " req.gnccimp_completed_date,pro.activation_exp_date,req.gncc_infoman_id, req.logging_until, req.rec_log_prd "
						+ "from c3par.ti_request req, c3par.con_req con,ti_process pro "
						+ "where req.id = ? and con.id = req.process_id and pro.id = req.process_id";
			}
			// log.info("Inside the lookup"+ sql + requestId);
			stmt = con.prepareStatement(sql);
			stmt.setLong(1, requestId);
			rs = stmt.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null)
						comments.put("ISSCOMPLIANCE", rs.getString(1));
					if (rs.getString(2) != null)
						comments.put("INFOMANID", Long.valueOf(rs.getLong(2)));

					Date dt = rs.getDate(3);
					if (dt != null) {
						// log.info(" dt = " + dt.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("OPSCHDATETIME", formatter.format(dt)
								+ " " + rs.getTime(3) + "");
					}

					Date dt1 = rs.getDate(4);
					if (dt1 != null) {
						// log.info(" dt = " + dt1.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("OPCOMPDATETIME", formatter.format(dt1)
								+ " " + rs.getTime(4) + "");

					}

					if (rs.getString(5) != null)
						comments.put("ACCESSRISK", rs.getString(5));
					if (rs.getString(6) != null)
						comments.put("TPREVIEWTYPE", rs.getString(6));
					if (rs.getString(7) != null)
						comments.put("TPREVIEWSTATUS", rs.getString(7));

					Date dt2 = rs.getDate(8);
					if (dt2 != null) {
						// log.info(" dt = " + dt2.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("TPREVIEWSSCHDATE", formatter.format(dt2));
					}
					Date dt3 = rs.getDate(9);
					if (dt3 != null) {
						// log.info(" dt = " + dt3.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("TPREVIEWREJDATE", formatter.format(dt3));
					}

					Date dt4 = rs.getDate(10);
					if (dt4 != null) {
						// log.info(" dt = " + dt3.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("TPREVIEWTEMPDATE", formatter.format(dt4));
					}

					if (rs.getString(11) != null)
						comments.put("APSINFOMANID",
								Long.valueOf(rs.getLong(11)));
					if (rs.getString(12) != null)
						comments.put("PRXINFOMANID",
								Long.valueOf(rs.getLong(12)));

					Date dt5 = rs.getDate(13);
					if (dt5 != null) {
						// log.info(" dt = " + dt3.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("APSSCHDATETIME", formatter.format(dt5)
								+ " " + rs.getTime(13) + "");
					}
					Date dt6 = rs.getDate(14);
					if (dt6 != null) {
						// log.info(" dt = " + dt3.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("APSCOMPDATETIME", formatter.format(dt6)
								+ " " + rs.getTime(14) + "");
					}
					Date dt7 = rs.getDate(15);
					if (dt7 != null) {
						// log.info(" dt = " + dt3.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("PRXSCHDATETIME", formatter.format(dt7)
								+ " " + rs.getTime(15) + "");
					}
					Date dt8 = rs.getDate(16);
					if (dt8 != null) {
						// log.info(" dt = " + dt3.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("PRXCOMPDATETIME", formatter.format(dt8)
								+ " " + rs.getTime(16) + "");
					}
					Date dt9 = rs.getDate(17);
					if (dt9 != null) {
						// log.info(" dt = " + dt3.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("GNCCSCHDATETIME", formatter.format(dt9)
								+ " " + rs.getTime(17) + "");
					}
					Date dt10 = rs.getDate(18);
					if (dt10 != null) {
						// log.info(" dt = " + dt3.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("GNCCCOMPDATETIME", formatter.format(dt10)
								+ " " + rs.getTime(18) + "");
					}
					Date dt11 = rs.getDate(19);
					if (dt11 != null) {
						log.debug(" dt = " + dt11.toString());
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("ACTIVATIONEXPDATE",
								formatter.format(dt11) + " " + rs.getTime(19)
										+ "");
					}
					if (rs.getString(20) != null)
						comments.put("GNCCINFOMANID",
								Long.valueOf(rs.getLong(20)));
					Date dt12 = rs.getDate(21);
					if (dt12 != null) {
						log.debug(" dt = " + dt12.toString());
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("LOGUNTILDATE", formatter.format(dt12)
								+ " " + rs.getTime(21) + "");
					}
					if (rs.getInt(22) > 0)
						comments.put("RECOMMENDEDLOGGINGPERIOD", rs.getInt(22));
				}
			}
			String supplementaryReview = "select reqRole.name as requesterRole,revRole.name as ReviewerRole from ti_req_supplement_review rsv, "
					+ "role reqRole, role revRole where rsv.requester_role = reqRole.id and rsv.reviewer_role=revRole.id  and ti_request_id="
					+ requestId + "order by reqrole.name";
			stmt = con.prepareStatement(supplementaryReview);
			rs = stmt.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null
							&& rs.getString(1).equalsIgnoreCase("BISO")) {
						comments.put("REQUESTERISOROLE", rs.getString(1));
						comments.put("REVIEWERISOROLE", "ISO");
					}
					if (rs.getString(1) != null
							&& rs.getString(1).equalsIgnoreCase(
									"Security Engineer")) {
						comments.put("REQUESTERSEROLE", rs.getString(1));
						if (rs.getString(2) != null
								&& rs.getString(2).equalsIgnoreCase("BISO"))
							comments.put("REVIEWERSEISOROLE", "ISO");
						if (rs.getString(2) != null
								&& rs.getString(2).equalsIgnoreCase("OTRM"))
							comments.put("REVIEWERSEISOOTRMROLE",
									rs.getString(2));
					}
				}
			}
			log.debug("executed successfully");
			log.info("comments:: " + comments);
		}// end of try
		catch (SQLException e) {
			throw new DatabaseException("Could not load ", e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ie) {
				log.error(ie);
			}
		}

		log.debug("Exit from extractReviewInfo()..");

		return comments;
	}

	@Transactional(readOnly = true)
	public HashMap extractReviewInfoForIP(long requestId) throws Exception {

		log.debug("Entering into extractReviewInfoForIP()..");

		HashMap comments = new HashMap();
		Session session = getSession();
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		long maintenanceConnection = 0;
		try {
			con = ((SessionImpl) getSession()).connection();
			String sql = "";

			sql = "select null, req.infoman_id, "
					+ "req.opeimp_scheduled_date,req.opeimp_completed_date, "
					+ "req.is_citi_risk_assessed,req.tpwapp_review_type, "
					+ "req.tpwapp_review_status,req.tpwapp_review_date,req.tpwapp_rejected_date,req.TPWAPP_TEMP_APP_DATE "
					+ "from c3par.ti_request req " + "where req.id = ? ";

			// log.info("Inside the lookup"+ sql + requestId);
			stmt = con.prepareStatement(sql);
			stmt.setLong(1, requestId);
			rs = stmt.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString(1) != null)
						comments.put("ISSCOMPLIANCE", rs.getString(1));
					if (rs.getString(2) != null)
						comments.put("INFOMANID", Long.valueOf(rs.getLong(2)));

					Date dt = rs.getDate(3);
					if (dt != null) {
						// log.info(" dt = " + dt.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("OPSCHDATETIME", formatter.format(dt)
								+ " " + rs.getTime(3) + "");
					}

					Date dt1 = rs.getDate(4);
					if (dt1 != null) {
						// log.info(" dt = " + dt1.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("OPCOMPDATETIME", formatter.format(dt1)
								+ " " + rs.getTime(4) + "");

					}

					if (rs.getString(5) != null)
						comments.put("ACCESSRISK", rs.getString(5));
					if (rs.getString(6) != null)
						comments.put("TPREVIEWTYPE", rs.getString(6));
					if (rs.getString(7) != null)
						comments.put("TPREVIEWSTATUS", rs.getString(7));

					Date dt2 = rs.getDate(8);
					if (dt2 != null) {
						// log.info(" dt = " + dt2.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("TPREVIEWSSCHDATE", formatter.format(dt2));
					}
					Date dt3 = rs.getDate(9);
					if (dt3 != null) {
						// log.info(" dt = " + dt3.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("TPREVIEWREJDATE", formatter.format(dt3));
					}

					Date dt4 = rs.getDate(10);
					if (dt4 != null) {
						// log.info(" dt = " + dt3.toString() );
						DateFormat formatter = new SimpleDateFormat(
								"MM/dd/yyyy");
						comments.put("TPREVIEWTEMPDATE", formatter.format(dt4));
					}
				}
			}
		}// end of try
		catch (SQLException e) {
			throw new DatabaseException("Could not load ", e);
		}

		log.debug("Exit from extractReviewInfoForIP()..");

		return comments;
	}

	@Transactional(readOnly = true)
	public List getAllDiscussions(String listType, Long ti_request_id,
			String role, int pageNum, int pageSize) throws RemoteException {
		log.debug("Entering into getAllDiscussions()..");
		
		if (pageNum == 0)
			throw new RuntimeException("Page Number should start at 1");
		List list;
		String queryToExecute;
		list = new ArrayList();
		StringBuffer sb = new StringBuffer();
		sb.append("select *  from ( select a.*, rownum rnum from ( ");
		sb.append(getQuerySelectString());
		String where = getCondition(listType, ti_request_id, role);
		if (!"".equals(where)) {
			sb.append(" WHERE ");
			sb.append(where);
		}
		String orderByClause = getOrderByClause();
		if (!"".equals(orderByClause))
			sb.append(" ORDER BY " + orderByClause);

		sb.append(" ) a where rownum <= ");
		sb.append((pageNum * pageSize) + 1);
		sb.append(" ) where rnum >= ");
		sb.append((pageNum * pageSize) - pageSize + (pageNum == 1 ? 1 : 2));
		queryToExecute = sb.toString();
		log.info("Sql is :- " + queryToExecute);

		Session session = getSession();
		
		TIRequestCommentsVO commentsVO = null;

		try {

			SQLQuery query = session.createSQLQuery(queryToExecute);
			
			ScrollableResults result = query.scroll();
			
			while(result.next()){
				
				commentsVO = new TIRequestCommentsVO();
				
				commentsVO.setApproverSoeID((String)result.get(4));
				commentsVO.setComments((String)result.get(2));
				commentsVO.setRoleName((String)result.get(3));
				Date date = (Date)result.get(6);
				commentsVO.setComment_date(date);
								
				list.add(commentsVO);				
				
			}

		} catch (Exception e) {
			log.error("Exception during query :- " + e);

			throw new RemoteException(
					"Could not run query = " + queryToExecute, e);
		}

		log.debug("Exit from getAllDiscussions()..");
		
		return list;
	}

	private String getQuerySelectString() {
		String stmt = null;
		stmt = "select comments.id, comments.ti_request_id,  comments.comments, "
				+ "role.DISPLAY_NAME, users.SSO_ID , ti_req.version_number,comments.comment_date,comments.LOCKED "
				+ "from c3par.ti_request ti_req , c3par.TI_REQUEST_COMMENTS comments, c3par.role role, c3par.C3PAR_USERS users ";
		return stmt;
	}

	private String getOrderByClause() {
		String orderByClause = "";
		orderByClause = " comments.comment_date desc";
		return orderByClause;
	}

}
