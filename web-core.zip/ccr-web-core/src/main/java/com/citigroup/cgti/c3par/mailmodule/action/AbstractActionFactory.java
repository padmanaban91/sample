package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;

import com.citigroup.cgti.c3par.oneapproval.ACVOneApprovalAction;
import com.citigroup.cgti.c3par.oneapproval.BMAOneApprovalAction;
import com.citigroup.cgti.c3par.oneapproval.GISOneApprovalAction;
import com.citigroup.cgti.c3par.oneapproval.ISOOneApprovalAction;

/**
 * 
 * @author ne36745
 *
 */
public abstract class AbstractActionFactory implements BeanFactoryAware {
	
	Logger log = Logger.getLogger(AbstractActionFactory.class);

	private BeanFactory beanFactory;
	
	protected abstract IsoApproveAction createIsoApproveAction();
	
	protected abstract GisApproveAction createGisApproveAction();
	
	protected abstract IsoApproveAction createIsoRejectAction();
	
	protected abstract GisApproveAction createGisRejectAction();
	
	protected abstract BusinessTesterRejectAction createBusinessTesterRejectAction();
	
	protected abstract BusinessOwnerRejectAction createBusinessOwnerRejectAction();
	
	protected abstract BusinessManagerRejectAction createBusinessManagerRejectAction();
	
	protected abstract DirectorRejectAction createDirectorRejectAction();
	
	protected abstract ISORejectAction createISORejectAction();
	
	protected abstract ProjectCoordinatorRejectAction createProjectCoordinatorRejectAction();
	
	protected abstract RelationshipManagerRejectAction createRelationshipManagerRejectAction();
	
	protected abstract RequestorRejectAction createRequestorRejectAction();
	
	protected abstract TechnicalContactRejectAction createTechnicalContactRejectAction();
	
	protected abstract TechnicalCoordinatorRejectAction createTechnicalCoordinatorRejectAction();
	
	protected abstract ACVApproveAction createACVApproveAction();
	
	protected abstract ACVRejectAction createACVRejectAction(); 
	
	protected abstract BMAApproveAction createBMAApproveAction(); 
	
	protected abstract BMARejectAction createBMARejectAction(); 
	
	protected abstract BMAOneApprovalAction createBMAOneApprovalAction();
	
	protected abstract ISOOneApprovalAction createISOOneApprovalAction();
	
	protected abstract GISOneApprovalAction createGISOneApprovalAction();
	
	protected abstract ACVOneApprovalAction createACVOneApprovalAction();

	
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		this.beanFactory = beanFactory;
		
	}

	/**
	 * @return the beanFactory
	 */
	public BeanFactory getBeanFactory() {
		return beanFactory;
	}

	
}
