/*
 * Created on Jul 12, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.reports.util;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.C3parThinSession;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.reports.dao.ReportMetaDAO;
import com.citigroup.cgti.c3par.reports.model.ReportMetaEntity;
import com.citigroup.cgti.c3par.reports.reportInterface.DataInitializer;
import com.citigroup.cgti.c3par.reports.reportInterface.DataRequester;
import com.citigroup.cgti.c3par.reports.reportInterface.ReportDataComponentFactory;
import com.citigroup.cgti.c3par.reports.reportInterface.ReportComponentFactory;
import com.citigroup.cgti.c3par.reports.reportInterface.ReportException;
import com.mentisys.dao.DatabaseException;


/**
 * The Class ReportsGenerator.
 *
 * @author gr61093
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ReportsGenerator {


    /** The log. */
    private static Logger log = Logger.getLogger(ReportsGenerator.class.getClass());

    /**
     * Instantiates a new reports generator.
     */
    public ReportsGenerator(){
	C3parThinSession c3parThinSession = new C3parThinSession();
	ReportMetaDAO dao = new ReportMetaDAO(c3parThinSession);
	List reportMetaEntityList = null;
	try {
	    reportMetaEntityList = dao.getAll(true);
	} catch (DatabaseException e) {
	    log.error(e,e);
	    throw new ApplicationException("Error");
	}
	Iterator iter = reportMetaEntityList.iterator();
	while (iter.hasNext()) {
	    ReportMetaEntity reportMetaEntity = (ReportMetaEntity) iter.next();
	    if(timeExpired(reportMetaEntity) && !reportMetaEntity.getReportsPackage().getName().trim().equalsIgnoreCase("CUSTOM")){
		try {
		    DBUtil.dropTable(c3parThinSession.getConnection(),"Report-" + reportMetaEntity.getId().toString(),false);
		} catch (ReportException e1) {
		    log.error(e1,e1);
		} catch (DatabaseException e1) {
		    log.error(e1,e1);
		}
		new ExecuteReport(reportMetaEntity.getId().longValue(), c3parThinSession);
	    }
	}
	log.info("Finished Processing");
    }

    /**
     * Time expired.
     *
     * @param reportMetaEntity the report meta entity
     * @return true, if successful
     */
    public boolean timeExpired(ReportMetaEntity reportMetaEntity){
	Date date = reportMetaEntity.getRefreshedTime();
	long elapsedHours = ((System.currentTimeMillis() - reportMetaEntity.getRefreshedTime().getTime())/1000)/3600 ;
	if(reportMetaEntity.getReportScheduleId().longValue()==1){
	    return true;
	}else if(reportMetaEntity.getReportScheduleId().longValue()==2){
	    if (elapsedHours > 24)
		return true;
	    else
		return false;
	}else if(reportMetaEntity.getReportScheduleId().longValue()==3){
	    if (elapsedHours > 168)
		return true;
	    else
		return false;

	}else if(reportMetaEntity.getReportScheduleId().longValue()==4){
	    return false;
	}
	return false;
    }

}



class ExecuteReport extends Thread {
    C3parThinSession c3parSession;
    long reportId;
    ReportComponentFactory reportComponentFactory;
    private static Logger log = Logger.getLogger(ExecuteReport.class.getClass());
    public ExecuteReport(long reportId, C3parThinSession c3parSession) {
	this.reportId = reportId;
	this.c3parSession = c3parSession;
	reportComponentFactory = new ReportComponentFactory(null);
	start();
    }



    /* (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    public void run() {
	try {
	    ReportDataComponentFactory reportDataComponentFactory =  reportComponentFactory.getDataComponentFactory(Long.valueOf(reportId));
	    DataRequester dataRequester = reportDataComponentFactory.getDataRequester();
	    DataInitializer dataInitializer = reportDataComponentFactory.getDataInitializer();
	    dataRequester = reportDataComponentFactory.getDataRequester();
	    dataInitializer.intialize();



	    ReportMetaEntity reportMetaEntity = dataInitializer.getReportMetaEntity();
	    reportMetaEntity.setRefreshedTime(new Date());
	    ReportMetaDAO doa = new ReportMetaDAO(c3parSession); 
	    doa.update(reportMetaEntity);

	} catch (DatabaseException e) {
	    log.error(e,e);
	} catch (ReportException e) {
	    log.error(e,e);
	} catch (Exception e) {
	    log.error(e,e);
	}
    }
}

