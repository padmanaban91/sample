package com.citigroup.cgti.c3par.communication.service;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.internal.OracleTypes;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.internal.SessionImpl;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.communication.domain.MonthViewProcess;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.MonthViewPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
@Transactional
public class MonthViewImpl extends BasePersistanceImpl implements
		MonthViewPersistable {

	private Logger log = Logger.getLogger(this.getClass().getName());

	String[] ProjectSector = { "GCB", "CTI", "ICG" };

	String procedureName = "getCMPRequestDetails_updated";
	
	String procedureForAssignedUsers ="getAllAssignedUsers";
	
	String procedureForECMDetails ="getECMDetails";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citigroup.cgti.c3par.communication.domain.soc.persist.
	 * MonthViewPersistable#getAllDetails()
	 */
	public Map<String, List<MonthViewProcess>> getAllDetails() {

		log.info("Entering into getAllDetails()..");

		Map<String, List<MonthViewProcess>> finalMap = new HashMap<String, List<MonthViewProcess>>();
		
		List<Integer> assignedUserList = null;
		
		List<MonthViewProcess> cmpRequestList = null;
		
		List<MonthViewProcess> tempCmpRequestList = null;

		for (String sectorName : ProjectSector) {
			
			cmpRequestList = new ArrayList<MonthViewProcess>();
			
			assignedUserList = getAllAssignedUsers(sectorName);
			
			for(Integer assignedUser : assignedUserList){
				
				//this.callingProcedureAndPrint(assignedUser.intValue());
				
				tempCmpRequestList = this.callingProcedure(assignedUser.intValue());
				
				if(tempCmpRequestList.size() > 0){
					
					cmpRequestList.add(tempCmpRequestList.get(0));
				}
				
				
			}

			finalMap.put(sectorName, cmpRequestList);
						
			log.debug("The sector name: "+sectorName+" and it's size:"+cmpRequestList.size());
			
			finalMap.put("ECM", this.getECMDetails());
			
			//log.debug("Sector Name:"+sectorName +" details: "+cmpRequestList);
		}

		log.info("Exit from getAllDetails()..");

		return finalMap;
	}
	
	private List<MonthViewProcess> getECMDetails(){
		
		CallableStatement callstm = null;
		MonthViewProcess monthViewProcess = null;

		Integer[] tempMonthAssignedCount = new Integer[12];
		Integer[] tempMonthCancelledCount = new Integer[12];

		List<MonthViewProcess> monthViewProcessList = null;
		
		Double[] tempMonthAvgCount = new Double[12];
				
		int tempCompletedCount;
		double tempAvgECMTimerInDays;
		
		monthViewProcessList = new ArrayList<MonthViewProcess>();

		try {

			String procedureCall = "{call " + procedureForECMDetails + "(?)}";
			callstm = ((SessionImpl)getSession()).connection().prepareCall(procedureCall);
			callstm.registerOutParameter(1, OracleTypes.CURSOR);			
			callstm.executeUpdate();
			ResultSet rs = null;
			rs = (ResultSet) callstm.getObject(1);

			int j;

			while (rs.next()) {

				j = 1;

				monthViewProcess = new MonthViewProcess();

				for (int i = 0; i < 12; i++) {		

					tempMonthAssignedCount[i] = rs.getBigDecimal(j++)
							.intValue();
					
					tempMonthCancelledCount[i] = rs.getBigDecimal(j++)
							.intValue();
					
					tempCompletedCount = rs.getBigDecimal(j++)
							.intValue();
					
					tempAvgECMTimerInDays = Double.parseDouble(this.findDays(rs.getBigDecimal(j++)));
					
					tempMonthAvgCount[i] = this.findAvg(tempAvgECMTimerInDays, tempCompletedCount);

				}
				monthViewProcess.setMonthAssignedCount(tempMonthAssignedCount);
				monthViewProcess
						.setMonthCompleteCancelCount(tempMonthCancelledCount);	
				monthViewProcess.setMonthAvgCount(tempMonthAvgCount);
				

				tempCompletedCount = rs.getBigDecimal(j++).intValue();
				
				monthViewProcess.setTotalAssignedCount(tempCompletedCount);
				monthViewProcess.setTotalCompleteCancelCount(rs.getBigDecimal(j++)
						.intValue());
				
				tempAvgECMTimerInDays = Double.parseDouble(this.findDays(rs.getBigDecimal(j)));
				
				monthViewProcess.setTotalAvg(this.findAvg(tempAvgECMTimerInDays, tempCompletedCount));
				
				

				//log.debug("The monthViewProcess Object: " + monthViewProcess.printMe());

				monthViewProcessList.add(monthViewProcess);
			}

		} catch (Exception ex) {
			log.error(ex.getMessage());
		}

		
		log.debug("Exit from callingProcedure()...");

		return monthViewProcessList;
	}
	
	public List<Integer> getAllAssignedUsers(String sectorName){
		
		log.info("Entering into getAllAssignedUsers()..");
		
		List<Integer> assignedUsersList = null;
		assignedUsersList = new ArrayList<Integer>();
		CallableStatement callstm = null;
		
		try {

			String procedureCall = "{call " + procedureForAssignedUsers + "(?, ?)}";
			callstm = ((SessionImpl)getSession()).connection().prepareCall(procedureCall);
			callstm.registerOutParameter(1, OracleTypes.CURSOR);
			callstm.setString(2, sectorName);
			callstm.executeUpdate();
			ResultSet rs=null;
			rs = (ResultSet) callstm.getObject(1);
			
			while (rs.next()) {
				assignedUsersList.add(rs.getInt(1));
			}
		}
		 catch (Exception ex) {
				log.error(ex.getMessage());
			}
		
		log.info("Exit from getAllAssignedUsers()..");
		
		return assignedUsersList;
	}

	public List<MonthViewProcess> callingProcedure(int assignedUser) {

		log.debug("Entering into callingProcedure()...");
		
		log.debug("The Assigned User:"+assignedUser);
		
		CallableStatement callstm = null;
		MonthViewProcess monthViewProcess = null;

		Integer[] tempMonthAssignedCount = new Integer[12];
		Integer[] tempMonthCancelledCount = new Integer[12];
		Double[] tempMonthAvgCount = new Double[12];
		Boolean [] tempMonthSLOCrossed = new Boolean[12];
		List<MonthViewProcess> monthViewProcessList = null;
		
		int tempCompletedCount;
		double tempAvgECMTimerInDays;
		
		monthViewProcessList = new ArrayList<MonthViewProcess>();

		try {

			String procedureCall = "{call " + procedureName + "(?, ?)}";
			callstm = ((SessionImpl)getSession()).connection().prepareCall(procedureCall);
			callstm.registerOutParameter(1, OracleTypes.CURSOR);
			callstm.setInt(2, assignedUser);
			callstm.executeUpdate();
			ResultSet rs = null;
			rs = (ResultSet) callstm.getObject(1);

			int j;

			while (rs.next()) {
				
				log.debug("Reach:1...");

				j = 1;

				monthViewProcess = new MonthViewProcess();
				monthViewProcess.setAssignedUser(""+assignedUser);
				monthViewProcess.setLastName(rs.getString(j++));
				monthViewProcess.setFirstName(rs.getString(j++));
				monthViewProcess.setRole(rs.getString(j++));
				
				log.debug("Reach:2...");

				for (int i = 0; i < 12; i++) {					
					

					tempMonthAssignedCount[i] = rs.getBigDecimal(j++)
							.intValue();
					
					tempMonthCancelledCount[i] = rs.getBigDecimal(j++)
							.intValue();
					
					tempCompletedCount = rs.getBigDecimal(j++)
							.intValue();
					
					log.debug("Reach:3...");
					
					tempAvgECMTimerInDays = Double.parseDouble(this.findDays(rs.getBigDecimal(j++)));
					
					log.debug("Reach:4...");
					
					tempMonthAvgCount[i] = this.findAvg(tempAvgECMTimerInDays, tempCompletedCount);
					
					log.debug("Reach:5...");
					
					tempMonthSLOCrossed[i] = this.isSLOCrossed(tempAvgECMTimerInDays, rs.getBigDecimal(j++));

				}
				log.debug("Reach:6...");
				monthViewProcess.setMonthAssignedCount(tempMonthAssignedCount);
				monthViewProcess
						.setMonthCompleteCancelCount(tempMonthCancelledCount);
				
				monthViewProcess.setMonthAvgCount(tempMonthAvgCount);
				monthViewProcess.setMonthSLOCrossed(tempMonthSLOCrossed);
				log.debug("Reach:7...");

				monthViewProcess.setTotalAssignedCount(rs.getBigDecimal(j++)
						.intValue());
				monthViewProcess.setTotalCompleteCancelCount(rs.getBigDecimal(j++)
						.intValue());
				
				tempAvgECMTimerInDays = Double.parseDouble(this.findDays(rs.getBigDecimal(j++)));
				
				monthViewProcess.setTotalAvg(this.findAvg(tempAvgECMTimerInDays, monthViewProcess.getTotalCompleteCancelCount()));
				
				monthViewProcess.setTotalSLOCrossed(this.isSLOCrossed(tempAvgECMTimerInDays, rs.getBigDecimal(j)));
				
				log.debug("Reach:8...");

				//log.debug("The monthViewProcess Object: " + monthViewProcess.printMe());

				monthViewProcessList.add(monthViewProcess);
			}

		} catch (Exception ex) {
			log.error(ex.getMessage());
		}

		
		log.debug("Exit from callingProcedure()...");

		return monthViewProcessList;
	}
	
	private double findAvg(double ECMTimerAvgInDays, int noOfCompletedReq){
		
		log.debug("The ECM SUM: "+ECMTimerAvgInDays +" / No of Completed Requests: "+noOfCompletedReq);
		
		double avg = 0.0;
		
		avg = ECMTimerAvgInDays/Double.parseDouble(""+noOfCompletedReq);
		
		if(Double.isNaN(avg) || Double.isInfinite(avg)){
			
			avg = 0.0;
		}
		
		avg = Double.parseDouble(new DecimalFormat("##.#").format(avg));
		
		log.debug("The returned avg: "+avg);
		
		return avg;
	}
	
	private boolean isSLOCrossed(double ECMTimerAvgInDays, BigDecimal SLODays){
		
		log.debug("The AVG: "+ECMTimerAvgInDays +" / The SLO: "+SLODays);
		
		boolean isSLOCrossed = false;
		
		if(SLODays != null){
			
			isSLOCrossed = ECMTimerAvgInDays > Double.parseDouble(""+SLODays.intValue());
		}
		
		return isSLOCrossed;
	}
	
	/*private int getRequestCountByStatus(int assignedUser, String sectorName, String startDate,String endDate, String status){
		
		
		log.debug("Entering into getRequestCountByStatus()...");
		
		
		String sqlQuery = "";
		
		if("In Progress".equalsIgnoreCase(status)){
			
			sqlQuery = "select COUNT(*) AS COUNTS from cmp_request where ASSIGNED_USER="+assignedUser+" and status='In Progress'"+" and ECM_SECTOR='"+sectorName+"'"+" and available_date BETWEEN '"+startDate+"' AND '"+endDate+"'";
			
		} else if("completed".equalsIgnoreCase(status)){

			sqlQuery = "select COUNT(*) AS COUNTS from cmp_request where ASSIGNED_USER="+assignedUser+" and status='Completed'"+" and ECM_SECTOR='"+sectorName+"'"+" and available_date BETWEEN '"+startDate+"' AND '"+endDate+"'";
		}
		
		 
		
		log.debug("The query: "+sqlQuery);
		
		SQLQuery query = this.getSession().createSQLQuery(sqlQuery);
		
		int count = 0;
		
		List tempList =	query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
		
		for (Object obj : tempList) {
			
			Map map = (Map) obj;
			
			log.debug("The map: "+map);			
						
			count = ((BigDecimal) map.get("COUNTS")).intValue();
		}
		
		
		
	
		
		
		log.debug("Exit from getRequestCountByStatus()...");
		
		return count;
	}*/
	
	
	
	private BigDecimal getAvgSLODays(int assignedUser, String sectorName,String startDate,String endDate,String status){
		
		
		log.debug("Entering into getAvgSLODays()...");
		
		String sqlQuery = "";
		
		if("In Progress".equalsIgnoreCase(status)){
			
			sqlQuery =  "select AVG(SLO_DAYS) AS AVGSLODAYS from cmp_request where ASSIGNED_USER="+assignedUser+" and status='In Progress'"+" and ECM_SECTOR='"+sectorName+"'"+" and available_date BETWEEN '"+startDate+"' AND '"+endDate+"'";
			
		} else if("completed".equalsIgnoreCase(status)){

			sqlQuery =  "select AVG(SLO_DAYS) AS AVGSLODAYS from cmp_request where ASSIGNED_USER="+assignedUser+" and status='Completed'"+" and ECM_SECTOR='"+sectorName+"'"+" and available_date BETWEEN '"+startDate+"' AND '"+endDate+"'";
		}
		
		log.debug("The query: "+sqlQuery);
		
		
		SQLQuery query = this.getSession().createSQLQuery(sqlQuery);
		
		BigDecimal 	avgSLODays = null;
		
		List tempList =	query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
		
		for (Object obj : tempList) {
			
			Map map = (Map) obj;
			
			log.debug("The map: "+map);	
			
			if(map.get("AVGSLODAYS") != null){
				
				avgSLODays = ((BigDecimal) map.get("AVGSLODAYS"));
			}					
			
		}
		
		
		log.debug("Exit from getAvgSLODays()...");
		
		return avgSLODays;
	}
	
	@SuppressWarnings("unchecked")
	public List<MonthViewProcess> getPopupDetailsDetails(int assignedUser, String sectorName,String startDate,String endDate,String status){
		
		log.debug("Entering into getPopupDetailsDetails()...");
		
		String sqlQuery = "";
		
		if("In Progress".equalsIgnoreCase(status)){
			
			sqlQuery = "select ID,ORDER_ITEM_ID,STATUS, AVAILABLE_DATE, CLOSED_DATE, ASSIGNED_GROUP,REQUEST_TYPE,TYPE_OF_CONN_INVOLVED,REQUEST_URGENCY,PROJECT_SECTOR,REGION from cmp_request where ASSIGNED_USER="+assignedUser+" and status='In Progress'"+" and ECM_SECTOR='"+sectorName+"'"+" and available_date BETWEEN '"+startDate+"' AND '"+endDate+"'";
			
		} else if("completed".equalsIgnoreCase(status)){
			
			sqlQuery = "select ID,ORDER_ITEM_ID,STATUS, AVAILABLE_DATE, CLOSED_DATE, ASSIGNED_GROUP,REQUEST_TYPE,TYPE_OF_CONN_INVOLVED,REQUEST_URGENCY,PROJECT_SECTOR,REGION from cmp_request where ASSIGNED_USER="+assignedUser+" and status in('Completed','Cancelled')"+" and ECM_SECTOR='"+sectorName+"'"+" and available_date BETWEEN '"+startDate+"' AND '"+endDate+"'";
			
		}
		log.debug("The getPopupDetailsDetails query: "+sqlQuery);
		
		List<MonthViewProcess> finalList = new ArrayList<MonthViewProcess>();
		
		SQLQuery query = this.getSession().createSQLQuery(sqlQuery);
				
		List tempList =	query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
		
		MonthViewProcess monthViewProcess =null;
		
		monthViewProcess = new MonthViewProcess();
		this.getUserInfo(assignedUser,monthViewProcess);
		finalList.add(monthViewProcess);
		
		//int requestCount = this.getRequestCountByStatus(assignedUser, sectorName, startDate, endDate,status);
		
		log.debug("avgECMTimer::"+assignedUser+"::"+sectorName+"::"+startDate+"::"+endDate+"::"+status);
		//BigDecimal avgECMTimer = this.getAvgECMTimer(assignedUser, sectorName, startDate, endDate, status);
		BigDecimal avgECMTimer = this.getAvgECMTimerUpdated(assignedUser, sectorName, startDate, endDate, status);
		BigDecimal avgSLODays = this.getAvgSLODays(assignedUser, sectorName, startDate, endDate, status);
		
		for (Object obj : tempList) {
			
			Map map = (Map) obj;
			
			log.debug("The map: "+map);
			
			monthViewProcess = new MonthViewProcess();			
			monthViewProcess.setOrderId((String)map.get("ORDER_ITEM_ID"));
			monthViewProcess.setStatus((String)map.get("STATUS"));
			//monthViewProcess.setTimeToMarket(this.findDays((BigDecimal)map.get("ECM_TIMER")));
			log.debug("calling ecm procedure ::CALCULATE_ACTIVITY_TIME::"+(BigDecimal)map.get("ID"));
			monthViewProcess.setTimeToMarket(""+findTimeToMarketDays(this.findECMDays((BigDecimal)map.get("ID")))); 
			monthViewProcess.setAvailableDate(this.dateToString((Date)map.get("AVAILABLE_DATE")));
			monthViewProcess.setClosedDate(this.dateToString((Date)map.get("CLOSED_DATE")));
			monthViewProcess.setAssignedGroup((String)map.get("ASSIGNED_GROUP"));
			monthViewProcess.setRequestType((String)map.get("REQUEST_TYPE"));
			monthViewProcess.setTypeofConnectivityInvolved((String)map.get("TYPE_OF_CONN_INVOLVED"));
			monthViewProcess.setRequestUrgency((String)map.get("REQUEST_URGENCY"));
			monthViewProcess.setProjectSector((String)map.get("PROJECT_SECTOR"));
			monthViewProcess.setRegion((String)map.get("REGION"));			
			monthViewProcess.setCrossedSLO(""+this.isSLOCrossed(Double.parseDouble(this.findDays(avgECMTimer)), avgSLODays));
			finalList.add(monthViewProcess);
		}
		
		log.debug("The finalList.size: "+finalList.size());
		
		log.debug("Exit from getPopupDetailsDetails()...");
		
		return finalList;
	}
	
	private void getUserInfo(int assignedUser, MonthViewProcess monthViewProcess){
		
		String sqlQuery = "select LAST_NAME,FIRST_NAME from C3PAR_USERS where id="+assignedUser;
		SQLQuery query = this.getSession().createSQLQuery(sqlQuery);		
		
		List tempList =	query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
		
		for (Object obj : tempList) {
			
			Map map = (Map) obj;
			
			monthViewProcess.setLastName((String)map.get("LAST_NAME"));			
			monthViewProcess.setFirstName((String)map.get("FIRST_NAME"));	
		}
		
		
	}
	
	private String findDays(BigDecimal minutes){
		
		String days = "0";
		
		try{
			
		if(minutes != null){
			
			days = Double.toString(minutes.intValue() / 60);
		}
				
		}catch(Exception ex){
			
		}
		
		log.debug("The days: "+days);
		
		return days;
	}
	
	private String findTimeToMarketDays(BigDecimal seconds){
		
		String days = "0";
		
		try{
			
		if(seconds != null){
			
			days = Double.toString(seconds.intValue() / 86400);
		}
				
		}catch(Exception ex){
			
		}
		
		log.debug("The days: "+days);
		
		return days;
	}
	
	private String dateToString(Date iDate){
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		
		if(iDate == null){
			return " ";
		}else{
			return format.format(iDate);
		}
			
	}
	
	private List<Integer> getECMUsers(){
		
		List<Integer> ecmUsersList = null;
		
		String SQLQuery = "select distinct USER_ID from ECM_QUEUE_USERS";
		
		
		SQLQuery query = this.getSession().createSQLQuery(SQLQuery);		
		
		List tempList =	query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
		
		ecmUsersList = new ArrayList<Integer>();
		
		for (Object obj : tempList) {
			
			Map map = (Map) obj;
			
			ecmUsersList.add(((BigDecimal)map.get("USER_ID")).intValue());			
				
		}
		
		log.debug("The ecmUsersList:"+ecmUsersList.size());
		
		return ecmUsersList;
	}
	
	private boolean isManagerRole(int userId){
		
		//String SQLQuery = "select NAME from SECURITY_ROLE where id=(select role_id from CMP_REQUEST_CON_XREF where id=(select id from cmp_request where assigned_user="+userId +" and rownum =1))";
		
		//String SQLQuery = "select NAME from SECURITY_ROLE where id=(select role_id from CMP_REQUEST_CON_XREF where id=(select id from cmp_request where assigned_user="+userId +" and rownum =1))";
		
		String SQLQuery = "select NAME FROM  SECURITY_ROLE  where id in(select role_id from c3par_user_role_xref where user_id ="+userId+" and role_id in (select id from SECURITY_ROLE where   name in ('ECM Manager')))";
		
		log.debug("isManagerRole :: SQLQuery:  "+SQLQuery);
		
		SQLQuery query = this.getSession().createSQLQuery(SQLQuery);		
		
		List tempList =	query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
		
		String userRole="";
		
		for (Object obj : tempList) {
			
			Map map = (Map) obj;
			
			userRole = (String)map.get("NAME");		
				
		}
		
		return "ECM Manager".equalsIgnoreCase(userRole);
		
	}
	
	private String getSectorName(int userId){
		
		String SQLQuery = "select QUEUE_NAME from ECM_QUEUE where id=(select distinct ECM_QUEUE_ID from ECM_QUEUE_USERS where USER_ID="+userId+")";		
		
		SQLQuery query = this.getSession().createSQLQuery(SQLQuery);		
		
		List tempList =	query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
		
		String sectorName="";
		
		for (Object obj : tempList) {
			
			Map map = (Map) obj;
			
			sectorName = (String)map.get("QUEUE_NAME");		
				
		}
		
		return sectorName;
		
	}
	
	public Map<String, List<MonthViewProcess>> getManagerViewDetails() {

		log.info("Entering into getManagerViewDetails()..");

		Map<String, List<MonthViewProcess>> finalMap = new HashMap<String, List<MonthViewProcess>>();
		
		List<Integer> assignedUserList = null;
		
		List<MonthViewProcess> cmpRequestList = null;
		
		List<Integer> ecmUsersList = this.getECMUsers();
		
		MonthViewProcess monthViewProcess = null;
		
		String sectorName = "";
		
		for(Integer userId : ecmUsersList){
			
			if(this.isManagerRole(userId)){
				
				sectorName = this.getSectorName(userId);
				
				assignedUserList = getAllAssignedUsers(sectorName);
				
				cmpRequestList = new ArrayList<MonthViewProcess>();
				
				monthViewProcess = new MonthViewProcess();
				
				this.getUserInfo(userId,monthViewProcess);
				
				cmpRequestList.add(monthViewProcess);
				
				for(Integer assignedUser : assignedUserList){	
					
					cmpRequestList.add(this.callingProcedure(assignedUser.intValue()).get(0));
					
				}

				finalMap.put(sectorName, cmpRequestList);
				
			}
		}
		
		finalMap.put("ECM", this.getECMDetails());
		
		log.debug("The finalMap:"+finalMap.size());
		
		log.info("Exit from getManagerViewDetails()..");

		return finalMap;
	}
	
	public void callingProcedureAndPrint(int assignedUser) {

		log.debug("Entering into callingProcedureAndPrint()...");
		
		CallableStatement callstm = null;		

		try {

			String procedureCall = "{call " + procedureName + "(?, ?)}";
			callstm = ((SessionImpl)getSession()).connection().prepareCall(procedureCall);
			callstm.registerOutParameter(1, OracleTypes.CURSOR);
			callstm.setInt(2, assignedUser);
			callstm.executeUpdate();
			ResultSet rs = null;
			rs = (ResultSet) callstm.getObject(1);

			int j;

			while (rs.next()) {

				j = 1;
				
				log.debug("The procedure result: "+rs.getString(j++)+"/"+rs.getString(j++)+"/"+rs.getString(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)	+"/"+					
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++)+"/"+
						rs.getBigDecimal(j++)+"/"+rs.getBigDecimal(j++));

				}

		} catch (Exception ex) {
			log.error(ex.getMessage());
		}

		
		log.debug("Exit from callingProcedureAndPrint()...");
		
	}
	
	
	public BigDecimal  findECMDays(BigDecimal cmpId) {

		log.debug("Entering into findECMDays :: callingProcedure()...");
		
		log.debug("The findECMDays cmpId :"+cmpId);
		BigDecimal time = null;
		CallableStatement callstm = null;
		try {
			
			String procedureCall = "{call CALCULATE_ACTIVITY_TIME(?,?,?)}";
			callstm = ((SessionImpl) getSession()).connection()
					.prepareCall(procedureCall);
			callstm.setBigDecimal(1, cmpId);
			callstm.setString(2, "ECM TIMER");
			callstm.registerOutParameter(3, OracleTypes.BIGINT);
			callstm.executeUpdate();
			time = callstm.getBigDecimal(3);
			log.debug("ECM time for cmpid::"+cmpId+"time::"+time);
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}

		return time;
		
	}
	
	private BigDecimal getAvgECMTimerUpdated(int assignedUser, String sectorName,String startDate,String endDate, String status){
		
		log.debug("Entering into getAvgECMTimerUpdated()...");
		
		Long avg = 0L;
		
		//BigDecimal id = new BigDecimal("0l");
		BigDecimal id = null;
		
		String sqlQuery = "";
		
		if("In Progress".equalsIgnoreCase(status)){
			
			sqlQuery =  "select ID from cmp_request where ASSIGNED_USER="+assignedUser+" and status='In Progress'"+" and ECM_SECTOR='"+sectorName+"'"+" and available_date BETWEEN '"+startDate+"' AND '"+endDate+"'";
			
		} else if("completed".equalsIgnoreCase(status)){

			sqlQuery =  "select ID from cmp_request where ASSIGNED_USER="+assignedUser+" and status='Completed'"+" and ECM_SECTOR='"+sectorName+"'"+" and available_date BETWEEN '"+startDate+"' AND '"+endDate+"'";
		}
		
		log.debug("The query: "+sqlQuery);
		
		SQLQuery query = this.getSession().createSQLQuery(sqlQuery);
		
		List tempList =	query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
		
		for (Object obj : tempList) {
			
			Map map = (Map) obj;
			
			log.debug("The map: "+map);	
				
			id = ((BigDecimal) map.get("ID"));
			
			CallableStatement callstmn = null;
			try {
				int time = 0;
				String procedureCall = "{call CALCULATE_ACTIVITY_TIME(?,?,?)}";
				callstmn = ((SessionImpl) getSession()).connection()
						.prepareCall(procedureCall);
				callstmn.setLong(1, id.longValue()); 
				callstmn.setString(2, "ECM TIMER");
				callstmn.registerOutParameter(3, OracleTypes.BIGINT);
				callstmn.executeUpdate();
				time = callstmn.getBigDecimal(3).intValue();
				log.debug("time::agentview::avg" + time);
				avg = avg + time;
				log.debug("sum of ecm timers::" + avg);
				} catch (SQLException ex) {
				log.error(ex, ex);
			}

		}if(tempList.size() > 0){
		avg = avg / tempList.size();
		log.debug("avg of ecm timers::" + avg);
		log.debug("setAvg::EcmTimer::" + avg);
		}
		
		log.debug("Exit from getAvgECMTimerUpdated()...");
		
		return BigDecimal.valueOf(avg);
	}
	
}