package com.citigroup.cgti.c3par.bpm.wspapi;


import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;
import javax.xml.ws.Service;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.joda.time.DateTime;
import org.kie.api.task.model.TaskSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Async;
import org.springframework.util.CollectionUtils;

import com.citigroup.cgti.c3par.Exception.OperationNotSupportedException;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleImpl;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.ManageActivityImpl;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.bpm.papiwebservice.ArgumentsBean;
import com.citigroup.cgti.c3par.bpm.papiwebservice.ArgumentsBean.Arguments;
import com.citigroup.cgti.c3par.bpm.papiwebservice.ArgumentsBean.Arguments.Entry;
import com.citigroup.cgti.c3par.bpm.papiwebservice.InstanceInfoBean;
import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.papiwebservice.PapiWebService;
import com.citigroup.cgti.c3par.bpm.papiwebservice.PapiWebService_Service;
import com.citigroup.cgti.c3par.util.C3parProperties;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.ccr.workflow.CCRWorkflowConstants;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.WorkflowResult;
import com.citigroup.cgti.ccr.workflow.database.service.WorkflowDBService;
import com.citigroup.cgti.ccr.workflow.domain.JBPMTaskRef;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;
import com.sun.xml.ws.api.message.Header;
import com.sun.xml.ws.api.message.Headers;
import com.sun.xml.ws.developer.WSBindingProvider;


public class WsPapiFacade /*extends TestCase*/{
	
    /** The log. */
    private static Logger log = Logger.getLogger(WsPapiFacade.class);
	private static final String SECURITY_NAMESPACE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
	private static final String NAME_SPACE_URI = "http://bea.com/albpm/PapiWebService";
	private static final String SERVICE_NAME = "PapiWebService";
//	private static final String WSDL_URL = "https://ccgfbpm30d.nam.nsroot.net:30906/papiws/PapiWebServiceEndpoint?wsdl";
	private static final String WSDL_URL = "https://ccgfbpm40u.nam.nsroot.net:20906/papiws/PapiWebServiceEndpoint?wsdl";
	private static final String AUTHENTICATION_ERROR_MESSAGE = "Participant could not be authenticated";
	
	@Autowired
	WorkflowUtil workflowUtil;
	
	@Autowired
	WorkflowCallServiceHelper wrkflowCallServiceHelper;
	
	private static final String ABORTEDSTATUS = "ABORTED";
	private static final String UNLOCKEDSTATUS = "UNLOCKED";
	
	@Autowired
	SessionFactory sessionFactory;
	
	@Autowired
	MailModuleImpl mailModuleImpl;
	
	@Autowired
	ManageActivityImpl manageActivityImpl;
	
	@Autowired
	ManageTIProcessImpl manageTIProcessImpl;
	
	@Autowired
	private WorkflowDBService workflowDBService;
	
	// Rename method to testPapiWebService() for running as JUnit testcase
	public void stestPapiWebService() {
//		WsPapiFacade tp = new WsPapiFacade();
		try {
			
			 // bpm_instance_id column of ti_activity_trail table for scheduled activity
			String instanceId = "/FWDataEntry#Default-1.1/637940/2@citi"; 


			System.out.println("Before completing activity.." + new Date());
			// ---------------Step 2 ends --------------------------//

			// 2.Complete the Activity --comment (3)
			// ---------------Step 2 starts --------------------------//
			completeActivity("hb26743", instanceId, "COMPLETED");
			// ---------------Step 2 ends --------------------------//
			System.out.println("After completing activity.." + new Date());

			// 3.Complete compuationWait --Uncomment only for computation wait
			// and comment above code (1,2)

			// ---------------Step 3 starts --------------------------//
			
			  instanceId = "/FWRequest#Default-1.1/637927/0@citi"; //
//			  bpm_instance_id column of ti_activity_trail table for
//			  compuationwait activity; 
			  Long tirequestId = Long.valueOf("109192"); //TiRequestId for the computationwait activity
//			  notifyBPM("gs71854",instanceId, tirequestId, ActivityName.ImplementationWait, ActivityArgName.ImplementationWaitIn);
			 
			// ---------------Step 3 ends --------------------------//

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// In Some scenarios Multiple activies will be queued at BPM INBOX, Need to
	// force to select correct activity
	private InstanceInfoBean getInstanceId(PapiWebService papiWebServicePort,
			InstanceInfoBean iib, String instanceId)
			throws OperationException_Exception {
		int counter = 0;
		log.info("iib.getActivityName() enter.."+iib.getActivityName());
		while ("Join".equals(iib.getActivityName()) || 
				iib.getActivityName().indexOf("Join")>0 ||
				"Join1".equals(iib.getActivityName()) || "UserSupport".equals(iib.getActivityName())) {
			++counter;
			instanceId = instanceId.substring(0, instanceId.lastIndexOf("/"))
					+ "/" + counter;
			iib = papiWebServicePort.processGetInstance(instanceId);
			if (counter > 30) {
				break;
			}
		}
		return iib;
	}
	@Async
	public void completeActivity(String userId, String instanceId,
			String activity_status) throws OperationException_Exception {
		log.debug("completeActivity --Start");
		log.debug("completeActivity -- activity_status"+activity_status);
		log.debug("completeActivity -- instanceId"+instanceId);
		log.debug("completeActivity -- userId"+userId);
		if (UNLOCKEDSTATUS.equals(activity_status)) {
			Map<String, Object> submitFlowParams = workflowUtil.buildWorkflowParamsForUnLock(userId, null, Long.parseLong(instanceId));
			wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, submitFlowParams, WorkflowEvent.UNLOCK, null);
		} else if(ABORTEDSTATUS.equals(activity_status)) {
			Map<String, Object> submitFlowParams = workflowUtil
					.buildWorkflowParamsForSubmit(
							ActivityDataDTO.STATUS_ABORTED, userId, null,
							null, Long.parseLong(instanceId));
			this.updateCompletedActivity(Long.parseLong(instanceId));
			wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING,
					submitFlowParams, WorkflowEvent.COMPLETE, null);
		}else{
			this.updateCompletedActivity(Long.parseLong(instanceId));
			Map<String, Object> submitFlowParams = workflowUtil
					.buildWorkflowParamsForSubmit(
							activity_status, userId, null,
							null, Long.parseLong(instanceId));
	        wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING,
			submitFlowParams, WorkflowEvent.COMPLETE, null);
		}
		log.debug("completeActivity --End");
	}
	@Async
	public void completeACVActivity(String userId, String instanceId,
			String activity_status,long activityId, long tiReqId) throws OperationException_Exception {
		log.debug("completeACVActivity --Start");
		log.debug("completeACVActivity -- activity_status"+activity_status);
		log.debug("completeACVActivity -- instanceId"+instanceId);
		log.debug("completeACVActivity -- userId"+userId);
		log.debug("completeACVActivity -- activityId"+activityId);
		log.debug("completeACVActivity -- tiReqId"+tiReqId);
		if (UNLOCKEDSTATUS.equals(activity_status)) {
			Map<String, Object> submitFlowParams = workflowUtil.buildWorkflowParamsForUnLock(userId, null, Long.parseLong(instanceId));
			wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, submitFlowParams, WorkflowEvent.UNLOCK, null);
			log.info("WsPapiFacade : unlock Activity!");
		}else{
				try {
				
				Map<String, Object> submitFlowParams = workflowUtil
						.buildWorkflowParamsForSubmit(activity_status, userId, null,
								null, Long.parseLong(instanceId));
				TaskSummary taskSummary=(TaskSummary)submitFlowParams.get(CCRWorkflowConstants.TASK_SUMMARY);
				List<Long> taskIds=workflowUtil.getTaskIdByProcessId(taskSummary.getProcessInstanceId());
				//submitFlowParams.put("IsParaleelactivity",true);
				//submitFlowParams.put("skipTaskIds",workflowUtil.getTaskIdByProcessId(taskSummary.getProcessInstanceId()));
				WorkflowResult workflowResult= wrkflowCallServiceHelper.callWorkflowService(FlowType.ACV,submitFlowParams, WorkflowEvent.COMPLETE, null);
				if(workflowResult!=null && CCRWorkflowConstants.STATUS_SUCCESS.equalsIgnoreCase(workflowResult.getStatus()) &&
						!CollectionUtils.isEmpty(taskIds)){
					workflowDBService.closeParalellActivity(taskIds);
				}
					
				//Completing Log Activity
				//log.info("WsPapiFacade : Completing Log Activity");
				//manageActivityImpl.completeActivity(activityId, userId, ActivityDataDTO.STATUS_COMPLETED);
				//Updating End Status
				log.info("WsPapiFacade : Updating End Status");
				ActivityDataDTO activityDataDTO = new ActivityDataDTO();
				activityDataDTO.setActivityCode("Active");
				activityDataDTO.setActivityStage(ActivityDataDTO.STAGE_APPROVAL);
				activityDataDTO.setActivityType(ActivityDataDTO.TYPE_APPROVAL);
				activityDataDTO.setActivityStatus(ActivityDataDTO.STATUS_COMPLETED);
				manageActivityImpl.logActivity(activityDataDTO, tiReqId, null);
				//Post Verify SOW Update
				log.info("WsPapiFacade : Post Verify SOW Update");
				String annualVerificationFlag = manageTIProcessImpl.getAnnualVerificationFlagValue(tiReqId);
				log.info("annualVerificationFlag is " + annualVerificationFlag);
				TIProcessDTO processDTO=manageTIProcessImpl.getProcessDTO(tiReqId);
				if(annualVerificationFlag!=null && !"".equals(annualVerificationFlag) && "Y".equals(annualVerificationFlag))
				{
					//Extending Expiration
					log.info("WsPapiFacade : Extending Expiration");
					manageTIProcessImpl.extendExpiration(processDTO.getId());
				} else {
					//Terminating Connection
					log.info("WsPapiFacade : Terminating Connection");
					tiReqId = manageTIProcessImpl.terminateProcess(processDTO);//CCR
					log.info("WsPapiFacade : After Terminating Connection : tiReqId : "+tiReqId);
					this.callCreateProcess(userId, tiReqId, FlowType.TERMINATION);//Process
					log.info("WsPapiFacade : Termination phase initiation completed");
				}
				log.info("WsPapiFacade : End Of Complete Activity!");
				}
				catch(Exception e){
					log.error(e,e);
				}
		}
		log.debug("completeACVActivity --End");
	}
	public void lockActivity(String userId, String taskID,
			String activity_status) throws OperationException_Exception {
		log.debug("lockActivity --Start");
		log.debug("lockActivity -- activity_status"+activity_status);
		log.debug("lockActivity -- userId"+userId);
		Map<String, Object> userFlowParams=workflowUtil.buildWorkflowParamsForLock(userId,Long.valueOf(taskID), null);
		//LOCK BJ
		wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, userFlowParams, WorkflowEvent.LOCK, null);
		log.debug("lockActivity --end");
	}
	@Async
	public void completeLoggingQueueActivity(String userId, String instanceId,
			String activity_status, String activityName) throws OperationException_Exception {
		log.debug("completeLoggingQueueActivity --Start");
		log.debug("completeLoggingQueueActivity -- activity_status"+activity_status);
		log.debug("completeLoggingQueueActivity -- userId"+userId);
		log.debug("completeLoggingQueueActivity -- activityName"+activityName);
		log.debug("completeLoggingQueueActivity -- instanceId"+instanceId);
		if (UNLOCKEDSTATUS.equals(activity_status)) {
			Map<String, Object> submitFlowParams = workflowUtil.buildWorkflowParamsForUnLock(userId, null, Long.parseLong(instanceId));
			wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, submitFlowParams, WorkflowEvent.UNLOCK, null);
		} else{
			Map<String, Object> submitFlowParams = workflowUtil
					.buildWorkflowParamsForSubmit(
							activity_status, userId, null,
							null, Long.parseLong(instanceId));
			TaskSummary taskSummary=(TaskSummary)submitFlowParams.get(CCRWorkflowConstants.TASK_SUMMARY);
			List<Long> taskIds=workflowUtil.getTaskIdByProcessId(taskSummary.getProcessInstanceId());
			/*submitFlowParams.put("IsParaleelactivity",true);
			submitFlowParams.put("skipTaskIds",workflowUtil.getTaskIdByProcessId(taskSummary.getProcessInstanceId()));*/
			WorkflowResult workflowResult= wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING,
			submitFlowParams, WorkflowEvent.COMPLETE, null);
			if(workflowResult!=null && CCRWorkflowConstants.STATUS_SUCCESS.equalsIgnoreCase(workflowResult.getStatus()) &&
					!CollectionUtils.isEmpty(taskIds)){
				workflowDBService.closeParalellActivity(taskIds);
			}
		}
		log.debug("completeLoggingQueueActivity --End");	
	}
	@Async
	public void tempApprovalActivity(String userId, String instanceId,
			String activity_status,String scheduleddDate) throws OperationException_Exception {
		log.debug("tempApprovalActivity --Start");
		log.debug("tempApprovalActivity -- activity_status"+activity_status);
		log.debug("tempApprovalActivity -- userId"+userId);
		if(scheduleddDate!=null){
		log.debug("tempApprovalActivity -- scheduleddDate"+scheduleddDate);
		}
		Map<String, Object> submitFlowParams = workflowUtil
				.buildWorkflowParamsForSubmit(
						activity_status, userId, null,
						null, Long.parseLong(instanceId));
		if (!StringUtil.isNullorEmpty(scheduleddDate)) {
			Date extendedDate = this.getExtendedDate(scheduleddDate);
			if(extendedDate!=null){
			submitFlowParams.put("scheduledDateArg",
					extendedDate);
			}
		}
        wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING,
		submitFlowParams, WorkflowEvent.COMPLETE, null);
		log.debug("tempApprovalActivity end ");
	}
	
	
	
	public enum ActivityStatus {
		REJECTED("REJECTED"),
		COMPLETED("COMPLETED"),
		ABORTED("Aborted"),
		PROVIDEINFO("PROVIDEINFO"),
		MOVED("MOVED"),
		LOGQUEUE("MOVED_TO_LOG_QUEUE"),
		RESCHEDULE("RESCHEDULED");
		private final String str;
		private ActivityStatus(String str)
		{
			this.str = str;
		}
		@Override
	    public String toString() {
	        return str;
	    }

		};
		
		public enum ActivityRejectedToRole {
			TC_ROLE("DESIGN ENGINEER"),
			BISO_ROLE("BISO"),
			OTRM_ROLE("OTRM"),
			PC_ROLE("PROJECT COORDINATOR"),
			MANAGER_ROLE("Manager"),
			MAD_ROLE("MAD"),
			APPSENSE_ROLE("Appsense_Implementer"),
			PROXY_ROLE("Proxy_Implementer"),
			GNCC_ROLE("GNCC"),
			FWIMPL_ROLE("Operational_Analyst"),
			FWIPIMPL_ROLE("Operational_Analyst_IP"),
			ACL_VARIANCE("ISTG_Chair"),
			TPASWG_ROLE("TPASWG"),
			GDEA_ROLE("Security Engineer");
			
			private final String str;
			private ActivityRejectedToRole(String str)
			{
				this.str = str;
			}
			@Override
		    public String toString() {
		        return str;
		    }

			};
	
	//Reject Activity -- rejectedToRoleName should be same name from ActivityDataDTO.java
	@Async
	public void completeActivity(String userId, String instanceId,
			ActivityStatus activity_status, ActivityRejectedToRole rejectedToRoleName) throws OperationException_Exception {
		log.debug("Provided info completeActivity --Start");
		log.debug("Provided info completeActivity -- activity_status"+activity_status);
		log.debug("Provided info completeActivity -- instanceId"+instanceId);
		log.debug("Provided info completeActivity -- userId"+userId);
		if(rejectedToRoleName!=null){
			log.debug("Provided info  completeActivity -- userId"+rejectedToRoleName.toString());
		}
		if("PROVIDEINFO".equalsIgnoreCase(activity_status.toString())){
		Map<String, Object> submitFlowParamsLock = workflowUtil.buildWorkflowParamsForUnLock(userId, null, Long.parseLong(instanceId));
		submitFlowParamsLock.put(CCRWorkflowConstants.IS_GRAB_ACTIVITY, new Boolean(true));
		wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, submitFlowParamsLock, WorkflowEvent.UNLOCK, null);
	    Map<String, Object> submitFlowParams=workflowUtil.buildWorkflowParamsForProvideInfo(rejectedToRoleName.toString(),Long.parseLong(instanceId));
		wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, submitFlowParams, WorkflowEvent.PROVIDEDINFO, null);
		}else{
			Map<String, Object> submitFlowParams=workflowUtil.buildWorkflowParamsForSubmit(
					activity_status.toString(), userId, null,
					rejectedToRoleName.toString(), Long.parseLong(instanceId));
			   wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING,
						submitFlowParams, WorkflowEvent.COMPLETE, null);
		}
		log.debug("Provided info completeActivity --End");
	}
	
	@Async
	public void rescheduleActivity(String userId, Long tiRequestId,
			String activity_status,String scheduleddDate) throws OperationException_Exception {
		log.debug("rescheduleActivity --Start");
		log.debug("rescheduleActivity -- activity_status"+activity_status);
		log.debug("rescheduleActivity -- tiRequestId"+tiRequestId);
		log.debug("rescheduleActivity -- userId"+userId);
		if(scheduleddDate!=null){
			log.debug("rescheduleActivity -- scheduleddDate"+scheduleddDate);
		}
		try{
		ApplicationContext appContext = CCRApplicationContextUtils
				.getApplicationContext();
		ManageTIProcessImpl manageTIProcess = (ManageTIProcessImpl) appContext
				.getBean("manageTIProcess");
		manageTIProcess.updateScheduleDate(tiRequestId, activity_status, this.getExtendedDate(scheduleddDate));
		mailModuleImpl.sendWorkItemNotification(tiRequestId, activity_status, null, null);
		}catch(Exception ex){
			ex.printStackTrace();
			log.debug("Error is"+ex.getMessage());
		}
		log.debug("rescheduleActivity --End");
	}

	// Complete computationWait activity
	public enum ActivityName {
		ImplementationWait("ImplementationWait"),
		AbortRollbkNotificationWait("AbortRollbkNotificationWait");
		
		private final String str;
		private ActivityName(String str)
		{
			this.str = str;
		}
		@Override
	    public String toString() {
	        return str;
	    }

		};
		public enum ActivityArgName {
			ImplementationWaitIn("ImplementationWaitIn"),
			AbortRollbkNotificationWaitIn("AbortRollbkNotificationWaitIn");
			private final String str;
			private ActivityArgName(String str)
			{
				this.str = str;
			}
			@Override
		    public String toString() {
		        return str;
		    }

		};
	public void notifyBPM(String userId, String instanceId,
			Long tirequestId,ActivityName bpmActivityName,ActivityArgName bpmActivityArg) {
		
		log.info("notifyBPM method started..");
		// Get the PapiWebServiceSession for the participant
		PapiWebService papiWebServicePort = getPapiWebServicePort(userId);
		ArgumentsBean argumentsSend = new ArgumentsBean();

		Entry e1N = new Entry();
		e1N.setKey("arg_TiRequestId");
		e1N.setValue(tirequestId.toString()); // "109141"

		Arguments argsN = new Arguments();

		argsN.getEntry().add(e1N);
		argumentsSend.setArguments(argsN);
		
			try {
				// papiWebServicePort.processSendNotification("/FWRequest#Default-1.1/637823/0",
				// "ImplementationWait", "ImplementationWaitIn", argumentsSend);
				papiWebServicePort
						.processSendNotification(instanceId, bpmActivityName.toString(),
								bpmActivityArg.toString(), argumentsSend);
			} catch (OperationException_Exception e) {
				log.error("OperationException_Exception in notifyBPM method.."+e);
				log.info("OperationException_Exception in notifyBPM method.."+e);
				e.printStackTrace();
			}
			
			log.info("notifyBPM method ended..");
	}
	
	
	//similar to User Migration link -- will run atleast 1 minute
	public enum GlobalActivityName {
		UserMigration("UserMigration"),
		ISAEdit("ISAEdit"),
		AutoPush("AutoPush");
		 
		private final String str;
		private GlobalActivityName(String str)
		{
			this.str = str;
		}
		@Override
	    public String toString() {
	        return str;
	    }

		};
		public enum GlobalActivityArgName {
			UserAdmin("/UserAdmin"),
			AutoPush("/AutoPush");
			private final String str;
			private GlobalActivityArgName(String str)
			{
				this.str = str;
			}
			@Override
		    public String toString() {
		        return str;
		    }

		};
	public void callGlobalInteractive(String userId, GlobalActivityName activityName, GlobalActivityArgName activityArgName) {
		
		log.info("callGlobalInteractive.. started with userid.."+userId);
		// Get the PapiWebServiceSession for the participant
		PapiWebService papiWebServicePort = getPapiWebServicePort(userId);
		
		try {
			Holder<ArgumentsBean> arguments = new Holder<ArgumentsBean>();
			Holder<InstanceInfoBean> instance = new Holder<InstanceInfoBean>();
			papiWebServicePort.activityExecuteApplication(activityName.toString(), activityArgName.toString(), arguments, instance);
		} catch (OperationException_Exception e1) {
			log.error("OperationException_Exception in callGlobalInteractive.. "+e1);
			log.info("OperationException_Exception in callGlobalInteractive.. "+e1);
			e1.printStackTrace();
		}
		
		log.info("callGlobalInteractive.. end");
		
	}
	
	//Creating New Process in BPM
	
	public enum CreateProcessActivity {
		FWRequest("/FWRequest"),
		FWManageUserContacts("/FWManageUserContacts"),
		FWACVRun("/FWACVRun1"),
		UserAdmin("/UserAdmin");
		private final String str;
		private CreateProcessActivity(String str)
		{
			this.str = str;
		}
		@Override
	    public String toString() {
	        return str;
	    }

	};
	public void callCreateProcess(String userId,Long tiRequestId,FlowType flowType) throws OperationException_Exception
	{
		log.debug("callCreateProcess --Start");
		log.debug("callCreateProcess -- tiRequestId"+tiRequestId);
		if(flowType!=null){
		log.debug("callCreateProcess -- flowType"+flowType.toString());
		}
		log.debug("callCreateProcess -- userId"+userId);
		
		Map<String, Object> workFlowParams=workflowUtil.buildWorkflowParamsForPlanning(tiRequestId);
		//Intiate  Planning phase
		wrkflowCallServiceHelper.callWorkflowService(flowType, workFlowParams, WorkflowEvent.CREATE, null);
		log.debug("callCreateProcess --End");
	}
	
	
	
//Creating New Process in BPM
	
	public enum CreateProcessActivityForACV {
		FWACVProcess("/FWACVProcess");
		private final String str;
		private CreateProcessActivityForACV(String str)
		{
			this.str = str;
		}
		@Override
	    public String toString() {
	        return str;
	    }

	};
	public void callCreateProcessForACV(String userId,String processType,Long processId,CreateProcessActivityForACV fwacvprocess) throws OperationException_Exception
	{
		PapiWebService papiWebServicePort = getPapiWebServicePort(userId);
		
		String argumentsSetName = "BeginIn";
		Holder<ArgumentsBean> arguments = new Holder<ArgumentsBean>();
		
		ArgumentsBean argsBean = new ArgumentsBean();
		Arguments value = new Arguments();
		Entry e = new Entry();
		if(processId!=null)
		{
			e.setKey("argInTIProcessId");
			e.setValue(processId+"");
			
			Entry e1 = new Entry();
			
			e1.setKey("argInRequestType");
			e1.setValue(processType);
			
			
			value.getEntry().add(e);
			value.getEntry().add(e1);
			argsBean.setArguments(value);
			
			arguments.value=argsBean;
		}
		
		Holder<InstanceInfoBean> instance = new Holder<InstanceInfoBean>();
		
			papiWebServicePort.processCreateInstance(fwacvprocess.toString(), argumentsSetName, arguments, instance);
		
	}
	
	
//Creating New Process in BPM
	

	public void callCreateProcessForACV(String userId,String processType,Set<Long> processIds,CreateProcessActivityForACV fwacvprocess) throws OperationException_Exception
	{
		PapiWebService papiWebServicePort = getPapiWebServicePort(userId);
		String argumentsSetName = "BeginIn";
		
		for(Long processId :processIds)
		{
			
			Holder<ArgumentsBean> arguments = new Holder<ArgumentsBean>();
			
			ArgumentsBean argsBean = new ArgumentsBean();
			Arguments value = new Arguments();
			Entry e = new Entry();
			if(processId!=null)
			{
				e.setKey("argInTIProcessId");
				e.setValue(processId+"");
				
				Entry e1 = new Entry();
				
				e1.setKey("argInRequestType");
				e1.setValue(processType);
				
				
				value.getEntry().add(e);
				value.getEntry().add(e1);
				argsBean.setArguments(value);
				
				arguments.value=argsBean;
			}
			
			Holder<InstanceInfoBean> instance = new Holder<InstanceInfoBean>();
			
			papiWebServicePort.processCreateInstance(fwacvprocess.toString(), argumentsSetName, arguments, instance);
			
			instance = null;
			arguments = null;
			argsBean = null;
			value = null;
			e = null;
			
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
		
	}
	
	public void createProcessUserEntitlement(String userId,String userToBeCreated, String userIsActive) throws OperationException_Exception
	{
		PapiWebService papiWebServicePort = getPapiWebServicePort(userId);
			
		Holder<ArgumentsBean> arguments = new Holder<ArgumentsBean>();
		
		ArgumentsBean argsBean = new ArgumentsBean();
		Arguments value = new Arguments();
		
		Entry e = new Entry();
		e.setKey("ssoId");
		e.setValue(userToBeCreated);
		value.getEntry().add(e);
		
		e = new Entry();
		e.setKey("updatable");
		e.setValue(userIsActive);
		value.getEntry().add(e);
		
		argsBean.setArguments(value);
		
		arguments.value=argsBean;
		
		Holder<InstanceInfoBean> instance = new Holder<InstanceInfoBean>();
		
		papiWebServicePort.activityExecuteApplication("ProcessUserEntitlement", CreateProcessActivity.UserAdmin.toString(), arguments, instance);
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		
	}
	
	public void isaEdit(String userId) throws OperationException_Exception
	{
		PapiWebService papiWebServicePort = getPapiWebServicePort(userId);
			
		Holder<ArgumentsBean> arguments = new Holder<ArgumentsBean>();
		
		ArgumentsBean argsBean = new ArgumentsBean();
		Arguments value = new Arguments();
		
		Entry e = new Entry();
		e.setKey("isasoeId");
		e.setValue(userId);
		value.getEntry().add(e);
		
		e = new Entry();
		e.setKey("activityStatus");
		e.setValue("APPROVED");
		value.getEntry().add(e);
		
		argsBean.setArguments(value);
		
		arguments.value=argsBean;
		
		Holder<InstanceInfoBean> instance = new Holder<InstanceInfoBean>();
		
		papiWebServicePort.activityExecuteApplication("ISAEdit", CreateProcessActivity.UserAdmin.toString(), arguments, instance);
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		
	}
	
	public void completeACVExpiration(String userId, String bpm_instance) throws OperationException_Exception
	{
		PapiWebService papiWebServicePort = getPapiWebServicePort(userId);
		String activityName = null;
		InstanceInfoBean iib = null;
			iib = papiWebServicePort.processGetInstance(bpm_instance);
			iib =  getInstanceId(papiWebServicePort,iib, bpm_instance); 
			activityName = iib.getActivityName();
			Holder<ArgumentsBean> arguments = new Holder<ArgumentsBean>();
			Holder<InstanceInfoBean> instance = new Holder<InstanceInfoBean>();
			papiWebServicePort.activityExecute(activityName, bpm_instance,arguments, instance);
//			papiWebServicePort.activityAbort(activityName, bpm_instance);
	}
	
	public void abortActivity(String userId, String bpm_instance) throws OperationException_Exception
	{
		PapiWebService papiWebServicePort = getPapiWebServicePort(userId);
		String activityName = null;
		InstanceInfoBean iib = null;
			iib = papiWebServicePort.processGetInstance(bpm_instance);
			iib =  getInstanceId(papiWebServicePort,iib, bpm_instance); 
			activityName = iib.getActivityName();
			
			papiWebServicePort.activityAbort(activityName, bpm_instance);
			
//			papiWebServicePort.activityAbortTask(activityName, taskIn, bpm_instance);
	}
	
	public boolean isInstanceExists(String userId, String bpm_instance)
	{
		PapiWebService papiWebServicePort = getPapiWebServicePort(userId);
		boolean instanceExists = true;
		try {
			papiWebServicePort.instanceCanBeProcessed(bpm_instance);
		} catch (OperationException_Exception e) {
			instanceExists = false;			
		}
		return instanceExists;
	}

	// Http Basic Authentication
	private static void addHttpBasicAuthentication(
			PapiWebService papiWebServicePort, String Username, String Password) {
		
//		log.info("addHttpBasicAuthentication.. started");
		Map<String, Object> request = ((BindingProvider) papiWebServicePort)
				.getRequestContext();
		request.put(BindingProvider.USERNAME_PROPERTY, Username);
		request.put(BindingProvider.PASSWORD_PROPERTY, Password);
//		log.info("addHttpBasicAuthentication.. end");
	}

	// UserName Token Authentication
	private static void addUserNameTokenProfile(
			PapiWebService papiWebServicePort, String userNm, String pwd){
		SOAPFactory soapFactory;
		try {
//			log.info("addUserNameTokenProfile method started..");
			soapFactory = SOAPFactory.newInstance();
			QName securityQName = new QName(SECURITY_NAMESPACE, "Security");
			SOAPElement security = soapFactory.createElement(securityQName);
			QName tokenQName = new QName(SECURITY_NAMESPACE, "UsernameToken");
			SOAPElement token = soapFactory.createElement(tokenQName);
			QName userQName = new QName(SECURITY_NAMESPACE, "Username");
			SOAPElement username = soapFactory.createElement(userQName);
			username.addTextNode(userNm);
			QName passwordQName = new QName(SECURITY_NAMESPACE, "Password");
			SOAPElement password = soapFactory.createElement(passwordQName);
			password.addTextNode(pwd);
			token.addChildElement(username);
			token.addChildElement(password);
			security.addChildElement(token);
			Header header = Headers.create(security);
			WSBindingProvider bp = (WSBindingProvider) papiWebServicePort;
			bp.setOutboundHeaders(header);
//			log.info("addUserNameTokenProfile method end..");
		} catch (SOAPException e) {
			log.error("SOAPException in addUserNameTokenProfile method.."+e);
			log.info("SOAPException in addUserNameTokenProfile method.."+e);
			e.printStackTrace();
		}

	}

	private PapiWebService getPapiWebServicePort(String userName) {
		PapiWebService papiWebServicePort = null;
		QName qName = null;
		URL url = null;
		Service service = null;
		log.info("endPointUrl:-"+C3parProperties.PAPI_SERVER_ENDPOINT);
		try {
//			log.info("getPapiWebServicePort method started.."+userName);
			qName = new QName(NAME_SPACE_URI, SERVICE_NAME);
			url = new URL(C3parProperties.PAPI_SERVER_ENDPOINT);
			//System.setProperty("https.protocols", "SSLv3");
			service = PapiWebService_Service.create(url, qName);
			papiWebServicePort = service.getPort(PapiWebService.class);
			addAuthentication(papiWebServicePort, userName.toLowerCase());
			/*log.info("getPapiWebServicePort..participant id.."
					+ papiWebServicePort.participantCurrent().getId());
			log.info("getPapiWebServicePort method end..");*/
		} catch (Exception e) {
			log.error("SOAPException in getPapiWebServicePort method.."+e);
			log.info("SOAPException in getPapiWebServicePort method.."+e);
			e.printStackTrace();
		}
		return papiWebServicePort;
	}

	private static void addAuthentication(PapiWebService papiWebServicePort,
			String userName) throws SOAPException {
		
//		log.info("addAuthentication method started..");
		
		String errorMessage = null;
		addUserNameTokenProfile(papiWebServicePort, userName, userName);
		boolean isAuthenticated = false;

		try {
			papiWebServicePort.participantCurrent().getId();
			isAuthenticated = true;
		} catch (Exception e) {
			errorMessage = e.getMessage();
		}

		if (errorMessage != null
				&& errorMessage.indexOf(AUTHENTICATION_ERROR_MESSAGE) != -1) {
			addUserNameTokenProfile(papiWebServicePort, userName, userName+ "!!");
			try {
				papiWebServicePort.participantCurrent().getId();
				isAuthenticated = true;
			} catch (Exception e) {
				errorMessage = e.getMessage();
			}
		}
		if(!isAuthenticated) 
		{
			try {
				papiWebServicePort.participantCurrent().getId();
			} catch (Exception e) {
				errorMessage = e.getMessage();
			}
	
			if (errorMessage != null
					&& errorMessage.indexOf(AUTHENTICATION_ERROR_MESSAGE) != -1) {
				addHttpBasicAuthentication(papiWebServicePort, userName, userName);
	
			}
	
			try {
				papiWebServicePort.participantCurrent().getId();
			} catch (Exception e) {
				errorMessage = e.getMessage();
			}
	
			if (errorMessage != null
					&& errorMessage.indexOf(AUTHENTICATION_ERROR_MESSAGE) != -1) {
				addHttpBasicAuthentication(papiWebServicePort, userName, userName
						+ "!!");
	
			}
		}
//		log.info("addAuthentication method ended..");
	}
	public void abortActivityManually(String user,Long instanceId,String newActivityCode) throws OperationNotSupportedException, OperationException_Exception{
		log.debug("abortActivityManually --Start");
		log.debug("abortActivityManually -- newActivityCode"+newActivityCode);
		log.debug("abortActivityManually -- instanceId"+instanceId);
		log.debug("abortActivityManually -- userId"+user);
		String activityCode=ActivityDataDTO.FORCE_FULLY_ABORTED;
		if("Aborted".equalsIgnoreCase(newActivityCode)){
			activityCode=ActivityDataDTO.STATUS_ABORTED;
		}
		Map<String, Object> submitFlowParams = workflowUtil
				.buildWorkflowParamsForSubmit(
						activityCode, user, null,
						newActivityCode, instanceId);
		submitFlowParams.put("manageBPMCode", newActivityCode);
		submitFlowParams.put("ActivityRounting", new Boolean(true));
		submitFlowParams.put(CCRWorkflowConstants.SOEID,user);
        wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING,
		submitFlowParams, WorkflowEvent.COMPLETE, null);
        log.debug("abortActivityManually --End");
         
	}
	private void updateCompletedActivity(Long taskId) {
		Session session = null;
        try {
        	 session = this.sessionFactory.openSession();
        	log.debug("updateCompletedActivity --Start");
            Criteria crit = session.createCriteria((Class)JBPMTaskRef.class);
            crit.add((Criterion)Restrictions.eq((String)"taskId", (Object)taskId));
            List list = crit.list();
            JBPMTaskRef taskRef = (JBPMTaskRef)list.get(0);
            taskRef.setActivityStatus("Completed");
            taskRef.setActivityCompletionDate(new DateTime().toDate());
            session.save((Object)taskRef);
            session.flush();
        }
        catch (Exception e) {
        	log.debug("error"+e);
            e.printStackTrace();
        }finally{
			if (session != null) {
				session.close();
			}
        }
        log.debug("updateCompletedActivity --End");
    }
	
	public Date getExtendedDate(String dateInString){
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date date=null;
		try {
			date = formatter.parse(dateInString);
			log.debug(date);
			log.debug(formatter.format(date));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return date;
	}
	
	@Async
	public void completeExceptionActivity(String userId, String instanceId,
			String activity_status,Long tiRequestId) throws OperationException_Exception {
		log.debug("completeExceptionActivity --Start");
		log.debug("completeExceptionActivity -- activity_status"+activity_status);
		log.debug("completeExceptionActivity -- instanceId"+instanceId);
		log.debug("completeExceptionActivity -- userId"+userId);
		log.debug("completeExceptionActivity -- userId"+tiRequestId);
		if (UNLOCKEDSTATUS.equals(activity_status)) {
			Map<String, Object> submitFlowParams = workflowUtil.buildWorkflowParamsForUnLock(userId, null, Long.parseLong(instanceId));
			wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, submitFlowParams, WorkflowEvent.UNLOCK, null);
		} else if(ABORTEDSTATUS.equals(activity_status)) {
			this.updateCompletedActivity(Long.parseLong(instanceId));
			Map<String, Object> submitFlowParams = workflowUtil
					.buildWorkflowParamsForSubmit(
							ActivityDataDTO.STATUS_ABORTED, userId, null,
							null, Long.parseLong(instanceId));
			wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING,
					submitFlowParams, WorkflowEvent.COMPLETE, null);
		}else{
			this.updateCompletedActivity(Long.parseLong(instanceId));
			Map<String, Object> submitFlowParams = workflowUtil
					.buildWorkflowParamsForSubmit(
							activity_status, userId, null,
							null, Long.parseLong(instanceId));
			JBPMTaskRef taskRef=workflowUtil.getLatestTaskRef(tiRequestId);
			if(taskRef!=null){
			     submitFlowParams.put("previousActivityCode", taskRef.getActivityName());
			}
	        wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING,
			submitFlowParams, WorkflowEvent.COMPLETE, null);
		}
		log.debug("completeExceptionActivity --End");
	}
}


