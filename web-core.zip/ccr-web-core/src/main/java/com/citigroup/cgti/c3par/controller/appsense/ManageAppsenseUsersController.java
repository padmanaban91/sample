package com.citigroup.cgti.c3par.controller.appsense;

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseDTO;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseUser;
import com.citigroup.cgti.c3par.appsense.domain.ManageAppsenseProcess;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.controller.firewall.BaseController;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.proxy.domain.ProxyFilter;
import com.citigroup.cgti.c3par.proxy.domain.ProxyInstance;
import com.citigroup.cgti.c3par.soa.model.ProfileEntity;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;
import com.citigroup.cgti.c3par.webtier.helper.AppsenseUtil;
import com.citigroup.cgti.c3par.webtier.helper.Util;

/*
 * @nc43495
 */
@SuppressWarnings("unchecked")
@Controller
public class ManageAppsenseUsersController extends BaseController {

	/** The log. */
	public static Logger log = Logger
			.getLogger(ManageAppsenseUsersController.class);
	

	/** The util. */
	Util util = new Util();
	
	AppsenseUtil appsenseUtil = new AppsenseUtil();

	/** The props. */
private static ResourceBundle props = ResourceBundle.getBundle(System.getProperty("ccr-application"),Locale.getDefault());

	

	

	@RequestMapping(value = "/loadAppsenseUsers.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	 public String loadOstiaApplication(ModelMap model,
				HttpServletRequest request) {

			String forwardTo = "c3par.appsense.users";
			
			log.info("ManageAppsenseProcess.loadOstiaApplication()::Starts");
			
			ManageAppsenseProcess manageAppsenseProcess = new ManageAppsenseProcess();
			AppsenseUser appSenseUser = new AppsenseUser();
			List<AppsenseUser> appsenseUserList = new ArrayList<AppsenseUser>();
			
			String tiReq = (String) request.getSession().getAttribute("tireqid");
			log.info("tiReq from SESSION===" + tiReq);
			
			Long tiRequestId = Long.valueOf(tiReq);
			
			log.info("tiRequestId===" + tiRequestId);
			
			TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
			TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
			appSenseUser.setTiProcess(tiProcess);
			appSenseUser.setTiRequest(tiRequest);
			manageAppsenseProcess.setTirequest(tiRequest);
			AppsenseDTO apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
			manageAppsenseProcess.setOffset(0);
			manageAppsenseProcess.setPageNo(1);
			manageAppsenseProcess.setLimit(5);
			
			appsenseUserList = manageAppsenseProcess.loadAppsenseUsers(apsProcess,
					manageAppsenseProcess);
			log.info("appsenseUserList--->>>" + appsenseUserList);
			
			//To calculate no of pages
			int rowCount = manageAppsenseProcess.getRowCount();
			int totalPages = 0;
			int limit = 5;
			
			if (rowCount%limit > 0) {
				totalPages = Math.round((rowCount/limit)+0.5f);
			} else {
				totalPages = Math.round(rowCount/limit);
			}
			manageAppsenseProcess.setTotalPages(totalPages);
			
			
			Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
			log.info("apsADGroupID in load action method:: " + apsADGroupID);
			if (!apsADGroupID.equals(Long.valueOf(0))) {
			    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
			    appsenseADGroup = (AppsenseADGroup) util
				    .getAppsADGroupDetails(apsADGroupID);
			    if (appsenseADGroup != null) {
			    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
					.getName());
			    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
					.getIsNew());
			    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
					    .getPolicyID());
			    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
					    .getPolicyName());
			    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
					    .getId());
			    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
					    .getIsNew());
			    }
			}
			
			log.info("appsenseUserList--->>>" + appsenseUserList);
			manageAppsenseProcess.setAppsenseUser(appSenseUser);
			manageAppsenseProcess.setAppsenseUserList(appsenseUserList);
			manageAppsenseProcess.setApsProcess(apsProcess);
			request.getSession().setAttribute("userList", appsenseUserList);
			request.getSession().removeAttribute("viewAppsense");
			model.addAttribute("appsenseData",manageAppsenseProcess);
			log.info("ManageAppsenseProcess.loadOstiaApplication()::Ends");

			isAppsenseCompleteCheck(request);
			
			return forwardTo;
	}
	
	
	@RequestMapping(value = "/paginateAppsenseUsers.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String paginateAppsense(ModelMap model, HttpServletRequest request, @ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess) {
		log.info("ManageAppsenseController:load method starts here ...");
	
		int curOffSet = manageAppsenseProcess.getOffset();
		int limit = manageAppsenseProcess.getLimit();
		int pageNo = manageAppsenseProcess.getPageNo();
		String type = (String)request.getParameter("type");
		
		log.debug("ManageAppsenseController::paginateIPs type..."+type);
		
		manageAppsenseProcess = new ManageAppsenseProcess();
		AppsenseDTO apsProcess = new AppsenseDTO();
		AppsenseUser appSenseUser = new AppsenseUser();
		List<AppsenseUser> appsenseUserList = new ArrayList<AppsenseUser>();

		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		appSenseUser.setTiProcess(tiProcess);
		appSenseUser.setTiRequest(tiRequest);
		manageAppsenseProcess.setTirequest(tiRequest);

		apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		manageAppsenseProcess.setLimit(limit);
		if ("N".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(curOffSet+manageAppsenseProcess.getLimit());
			manageAppsenseProcess.setPageNo(pageNo+1);
		} else if ("P".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(curOffSet-manageAppsenseProcess.getLimit());
			manageAppsenseProcess.setPageNo(pageNo-1);
		} else if ("X".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(limit * (pageNo-1));
			manageAppsenseProcess.setPageNo(pageNo);
		} else if ("L".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(0);
			manageAppsenseProcess.setPageNo(1);
		} else {
			manageAppsenseProcess.setOffset(0);
			manageAppsenseProcess.setPageNo(1);
		}
		
		appsenseUserList = manageAppsenseProcess.loadAppsenseUsers(apsProcess,
				manageAppsenseProcess);
		log.info("appsenseUserList--->>>" + appsenseUserList);
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}
		
		log.info("appsenseUserList--->>>" + appsenseUserList);
		manageAppsenseProcess.setAppsenseUser(appSenseUser);
		manageAppsenseProcess.setAppsenseUserList(appsenseUserList);
		manageAppsenseProcess.setApsProcess(apsProcess);
		request.getSession().setAttribute("userList", appsenseUserList);
		model.addAttribute("appsenseData", manageAppsenseProcess);
		log.info("ManageAppsenseProcess.load()::Ends");
		return "c3par.appsense.users";
	}
	
	@RequestMapping(value = "/saveADGroupName.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String saveADGroupName(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request, HttpServletResponse response) {
		log.debug("ManageAppsenseProcess::saveADGroupName methods starts...");
		String adGroupName = manageAppsenseProcess.getAppsADGroupName();
		
		String tiReq = (String) request.getSession().getAttribute("tireqid");

		log.info("tiReq from SESSION===" + tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}

		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId
				.longValue());
		
		AppsenseADGroup appsenseADGroupName = new AppsenseADGroup();
		appsenseADGroupName = (AppsenseADGroup) util
				.checkAppsADGroupName(adGroupName);
		if (appsenseADGroupName.getId() == null) {
			appsenseADGroupName.setName(manageAppsenseProcess
					.getAppsADGroupName());
			appsenseADGroupName.setPolicyID(manageAppsenseProcess
					.getAppsPolicyId());
			appsenseADGroupName.setPolicyName(manageAppsenseProcess
					.getAppsPolicyName());
			appsenseADGroupName = manageAppsenseProcess
					.storeAppsADGroup(appsenseADGroupName);
			util.updateAppsADGroupID(tiProcess.getId(),
					appsenseADGroupName.getId());
			util.updateProxyADGroupID(tiProcess.getId(),
					appsenseADGroupName.getId());
			manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroupName
					.getId());
		} else {
			appsenseADGroupName.setName(manageAppsenseProcess
					.getAppsADGroupName());
			appsenseADGroupName.setPolicyID(manageAppsenseProcess
					.getAppsPolicyId());
			appsenseADGroupName.setPolicyName(manageAppsenseProcess
					.getAppsPolicyName());
			appsenseADGroupName = manageAppsenseProcess
					.updateAppsADGroup(appsenseADGroupName);

		}

		log.debug("ManageAppsenseProcess::saveADGroupName methods ends...");
		return "forward:/loadAppsenseUsers.act";
	}
	
	
	@RequestMapping(value = "/addRitzData.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String addRitzData(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {

		log.info("ManageAppsenseProcess.addRitzsData()::Starts");
		AppsenseUser appsenseUser = manageAppsenseProcess.getAppsenseUser();

		String ssoid = manageAppsenseProcess.getSsoId();
		String devAccess = appsenseUser.getDevAccess();
		String prodAccess = appsenseUser.getPrdAccess();
		String firstName = manageAppsenseProcess.getFirstName();
		String lastName = manageAppsenseProcess.getLastName();
		String email = manageAppsenseProcess.getEmail();
		String crossEnvironmentAccess = appsenseUser
				.getCrossEnvironmentAccess();
		String localFolderAccess = appsenseUser.getLocalFolderAccess();
		/* START Print Logs */
		log.info("ManageAppsenseProcess.addRitzsData()::firstName:::"
				+ firstName);
		log.info("ManageAppsenseProcess.addRitzsData()::lastName:::" + lastName);
		log.info("ManageAppsenseProcess.addRitzsData()::email:::" + email);
		log.info("ManageAppsenseProcess.addRitzsData()::ssoid:::" + ssoid);
		log.info("ManageAppsenseProcess.addRitzsData()::devAccess:::"
				+ devAccess);
		log.info("ManageAppsenseProcess.addRitzsData()::prodAccess:::"
				+ prodAccess);
		log.info("ManageAppsenseProcess.addRitzsData()::crossEnvironmentAccess:::"
				+ crossEnvironmentAccess);
		log.info("ManageAppsenseProcess.addRitzsData()::localFolderAccess:::"
				+ localFolderAccess);
		/* END Print Logs */

		appsenseUser.getCitiContact().setFirstName(firstName);
		appsenseUser.getCitiContact().setLastName(lastName);
		appsenseUser.getCitiContact().setEmail(email);
		appsenseUser.getCitiContact().setSsoId(ssoid);
		String tiReq = (String) request.getSession().getAttribute("tireqid");

		log.info("tiReq from SESSION===" + tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}

		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId
				.longValue());
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId
				.longValue());
		appsenseUser.setTiProcess(tiProcess);
		appsenseUser.setTiRequest(tiRequest);
		
		String adGroupName = manageAppsenseProcess.getAppsADGroupName();
		
		AppsenseADGroup appsenseADGroupName = new AppsenseADGroup();
		appsenseADGroupName = (AppsenseADGroup) util
				.checkAppsADGroupName(adGroupName);
		if (appsenseADGroupName.getId() == null) {
			appsenseADGroupName.setName(manageAppsenseProcess
					.getAppsADGroupName());
			appsenseADGroupName.setPolicyID(manageAppsenseProcess
					.getAppsPolicyId());
			appsenseADGroupName.setPolicyName(manageAppsenseProcess
					.getAppsPolicyName());
			appsenseADGroupName = manageAppsenseProcess
					.storeAppsADGroup(appsenseADGroupName);
			util.updateAppsADGroupID(tiProcess.getId(),
					appsenseADGroupName.getId());
			util.updateProxyADGroupID(tiProcess.getId(),
					appsenseADGroupName.getId());
			manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroupName
					.getId());
			appsenseUser.setAppsenseADGroup(appsenseADGroupName);
		} else {
			appsenseADGroupName.setName(manageAppsenseProcess
					.getAppsADGroupName());
			appsenseADGroupName.setPolicyID(manageAppsenseProcess
					.getAppsPolicyId());
			appsenseADGroupName.setPolicyName(manageAppsenseProcess
					.getAppsPolicyName());	
			appsenseADGroupName = manageAppsenseProcess
					.updateAppsADGroup(appsenseADGroupName);
			appsenseUser.setAppsenseADGroup(appsenseADGroupName);
		}
		
		manageAppsenseProcess.storeAppsenseUser(appsenseUser);
		manageAppsenseProcess.setAppsenseUserList((List<AppsenseUser>)request.getSession().getAttribute("userList"));
		log.info("ManageAppsenseProcess.addRitzsData()::Ends");
		return "forward:/loadAppsenseUsers.act";

	}
	
	
	@RequestMapping(value = "/removeUsers.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String removeUsers(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		String tiRequestId = (String) request.getSession().getAttribute("tireqid");
        TIProcess tiProcess = manageAppsenseProcess.getTIProcess(Long.valueOf(tiRequestId));
        TIRequest tiRequest = manageAppsenseProcess.getTIRequest(Long.valueOf(tiRequestId));

		AppsenseDTO appsenseProcess = manageAppsenseProcess.getApsProcess();
		appsenseProcess.setTiProcess(tiProcess);
		appsenseProcess.setTireq(tiRequest);
		List<AppsenseUser> appsenseUserList = manageAppsenseProcess.getAppsenseUserList();
		appsenseProcess.setAppsenseUserList(appsenseUserList);
		manageAppsenseProcess.deleteAppsenseUser(appsenseProcess);
		
		appsenseUtil.resetUserDetail(manageAppsenseProcess);
		return "forward:/loadAppsenseUsers.act";
	}
	
	
	@RequestMapping(value = "/getRitzsData.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String getRitzsData(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		log.info("ManageAppsenseProcess.getRitzsData()::Starts");
		
		String forwardTo = "c3par.appsense.users";
		
		AppsenseUser appSenseUser = new AppsenseUser();
		List<AppsenseUser> appsenseUserList = new ArrayList<AppsenseUser>();
		
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		log.info("ManageAppsenseProcess.getRitzsData()::ssoid " + manageAppsenseProcess.getSsoId());
		try {
			SOADataComponent soaDataComponent = new SOADataComponent();
			ProfileInfoFactory profileInfoFactory = (ProfileInfoFactory) soaDataComponent
					.getServiceFactory("profileInfo");
			ProfileEntity profileEntity = new ProfileEntity();
			profileEntity.setSoeId(manageAppsenseProcess.getSsoId());
			List<CitiContact> citiContactList = profileInfoFactory.getRitzService()
					.getProfile(profileEntity, request.getHeader("SM_USER"));
			Iterator<CitiContact> it = citiContactList.iterator();
			log.info("ManageAppsenseProcess.getRitzsData()::citiContactList " + manageAppsenseProcess.getSsoId() 
					+ "  "+ citiContactList.size());
			while (it.hasNext()) {
				CitiContact entity = (CitiContact) it.next();
				manageAppsenseProcess.setFirstName(entity.getFirstName());
				manageAppsenseProcess.setLastName(entity.getLastName());
				manageAppsenseProcess.setEmail(entity.getEmail());	
				log.info("ManageAppsenseProcess.getRitzsData()::CitiContact Info ::: First Name"
						+ entity.getFirstName());
				log.info("ManageAppsenseProcess.getRitzsData()::CitiContact Info ::: Last Name"
						+ entity.getLastName());
				log.info("ManageAppsenseProcess.getRitzsData()::CitiContact Info ::: Email"
						+ entity.getEmail());
			}

		} catch (Exception ex) {
			log.error(ex, ex);
		}
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		appSenseUser.setTiProcess(tiProcess);
		appSenseUser.setTiRequest(tiRequest);
		manageAppsenseProcess.setTirequest(tiRequest);
		AppsenseDTO apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		manageAppsenseProcess.setOffset(0);
		manageAppsenseProcess.setPageNo(1);
		manageAppsenseProcess.setLimit(5);
		
		appsenseUserList = manageAppsenseProcess.loadAppsenseUsers(apsProcess,
				manageAppsenseProcess);
		log.info("appsenseUserList--->>>" + appsenseUserList);
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		int limit = 5;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}
		
		log.info("appsenseUserList--->>>" + appsenseUserList);
		manageAppsenseProcess.setAppsenseUser(appSenseUser);
		manageAppsenseProcess.setAppsenseUserList(appsenseUserList);
		manageAppsenseProcess.setApsProcess(apsProcess);
		request.getSession().setAttribute("userList", appsenseUserList);
		model.addAttribute("appsenseData",manageAppsenseProcess);
		log.info("ManageAppsenseProcess.loadOstiaApplication()::Ends");

		return forwardTo;
	}
	
	
	@RequestMapping(value = "/viewAppsenseUser.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String viewAppsenseUser(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		
		String forwardTo = "c3par.appsense.users";
		int index = -1;
		log.info("manageProxyAction.viewAppsenseProxy()::Starts");
		manageAppsenseProcess = new ManageAppsenseProcess();
		manageAppsenseProcess.setAppsenseUserList((List<AppsenseUser>)request.getSession().getAttribute("userList"));
		String indexId = request.getParameter("indexId");
		String curOffSet = request.getParameter("offset");
		String limit = request.getParameter("limit");
		String pageNo = request.getParameter("pageNo");
		
		log.info("manageProxyAction.viewAppsenseProxy()::Indexid::: " + indexId);
		if ((indexId != null) && !indexId.equals("null")) {
			index = Integer.valueOf(indexId).intValue();
		}

		if (index >= 0) {
				List<AppsenseUser> appsenseUserList = manageAppsenseProcess
						.getAppsenseUserList();
				AppsenseUser appsenseUser = (AppsenseUser) appsenseUserList
						.get(index);
				manageAppsenseProcess.setAppsenseUser(appsenseUser);
		}
		

		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		manageAppsenseProcess.setTirequest(tiRequest);
		
		
		manageAppsenseProcess.setOffset(Integer.valueOf(curOffSet));
		manageAppsenseProcess.setLimit(Integer.valueOf(limit));
		manageAppsenseProcess.setPageNo(Integer.valueOf(pageNo));
		
		AppsenseDTO apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		List<AppsenseUser> appsenseUserList = new ArrayList<AppsenseUser>();
		
		appsenseUserList = manageAppsenseProcess.loadAppsenseUsers(apsProcess,
				manageAppsenseProcess);
		log.info("appsenseUserList--->>>" + appsenseUserList);
		
		//To calculate no of pages
				int rowCount = manageAppsenseProcess.getRowCount();
				int totalPages = 0;
				
				if (rowCount%manageAppsenseProcess.getLimit() > 0) {
					totalPages = Math.round((rowCount/manageAppsenseProcess.getLimit())+0.5f);
				} else {
					totalPages = Math.round(rowCount/manageAppsenseProcess.getLimit());
				}
				manageAppsenseProcess.setTotalPages(totalPages);
				
				Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
				log.info("apsADGroupID in load action method:: " + apsADGroupID);
				if (!apsADGroupID.equals(Long.valueOf(0))) {
				    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
				    appsenseADGroup = (AppsenseADGroup) util
					    .getAppsADGroupDetails(apsADGroupID);
				    if (appsenseADGroup != null) {
				    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
						.getName());
				    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
						.getIsNew());
				    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
						    .getPolicyID());
				    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
						    .getPolicyName());
				    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
						    .getId());
				    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
						    .getIsNew());
				    }
				}
		
		log.info("appsenseUserList--->>>" + appsenseUserList);
		manageAppsenseProcess.setAppsenseUserList(appsenseUserList);
		manageAppsenseProcess.setApsProcess(apsProcess);
		request.getSession().setAttribute("userList", appsenseUserList);
		request.getSession().setAttribute("viewAppsense", "true");
		model.addAttribute("appsenseData",manageAppsenseProcess);
		log.info("manageProxyAction.viewAppsenseProxy()::Ends");
		return forwardTo;
	}
	
	
	 @RequestMapping(value = " /downloadXENVForm.act", method = {
				RequestMethod.GET, RequestMethod.POST })
	 public String downloadXENVForm(ModelMap model,ManageAppsenseProcess manageAppsenseProcess,
			    HttpSession session, HttpServletResponse response)
			    throws Exception {
			log.debug("AppsensePolicyAction::downloadXENVForm methods starts...");

			try {

			    String docMimeType = "application/msword";
			    URL url = session.getServletContext().getResource(
				    "/images/templatedocuments/XENV_Form.doc");
			    InputStream in = url.openStream();
			    byte[] docBytes = new byte[in.available()];
			    in.read(docBytes, 0, in.available());
			    if (docMimeType != null && docBytes != null && docBytes.length != 0) {
				java.io.OutputStream os = response.getOutputStream();
				response.setHeader("Content-Disposition",
					"attachment;filename=XENV - Access Request Form.doc");
				response.setContentType(docMimeType);
				os.write(docBytes);
			    } else {
				java.io.PrintWriter out = response.getWriter();
				response.setContentType("text/html");
				out
					.println("<HTML><BODY>There was no file attached!</BODY></HTML>");
			    }

			} catch (Exception e) {

			    log.error(e);
			    java.io.PrintWriter out = response.getWriter();
			    response.setContentType("text/html");
			    out
				    .println("<HTML><BODY>There was an error retrieving the requested file!</BODY></HTML>");
			}
			log.debug("AppsensePolicyAction::downloadXENVForm methods ends...");
			return null;
		    }
	 
	 
	 @RequestMapping(value = "/uploadUsersExcel.act", method = {
				RequestMethod.GET, RequestMethod.POST })
		public String uploadUsersExcel(
				ModelMap model,
				@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
				HttpServletRequest request) {
			
			log.info("ManageAppsenseProcess.uploadProxyFilterExcel()::Starts");
			String forwardTo = "c3par.appsense";
			String selectedTab = request.getParameter("tab");
			log.info("selectedTab:: " + selectedTab);
			try {
				String tiReq = (String) request.getSession()
						.getAttribute("tireqid");
				log.info("tiReq from SESSION===" + tiReq);
				Long tiRequestId = Long.valueOf(0);
				if (tiReq != null) {
					try {
						tiRequestId = Long.valueOf(tiReq);
					} catch (Exception e) {
						tiRequestId = Long.valueOf(0);
					}
				}
				log.info("tiRequestId===" + tiRequestId);

				ProxyFilter proxyFilter = manageAppsenseProcess.getProxyFilter();
				ProxyInstance proxyInstance = (ProxyInstance) proxyFilter
						.getProxyInstance();
				log.info("proxyInstance:: " + proxyInstance);
				TIProcess tiProcess = manageAppsenseProcess
						.getTIProcess(tiRequestId.longValue());
				log.info("tiProcess:: " + tiProcess);
				TIRequest tiRequest = manageAppsenseProcess
						.getTIRequest(tiRequestId.longValue());
				log.info("tiRequest:: " + tiRequest);
				CommonsMultipartFile file = manageAppsenseProcess
						.getUsersUploadExcelFormFile();
				log.info("file::: " + file);
				
				if (file == null 
						// || file.getFileData().length == 0
						|| file.equals("")) {
					request.setAttribute("error_log",
							"File Not Found.Pls Upload Excel File.");
				} 	else {
				
				
				// Added for Task 9224
				AppsenseADGroup appsenseADGroupName = new AppsenseADGroup();
				appsenseADGroupName.setName(manageAppsenseProcess
						.getAppsADGroupName());
				appsenseADGroupName.setPolicyID(manageAppsenseProcess
						.getAppsPolicyId());
				appsenseADGroupName.setPolicyName(manageAppsenseProcess
						.getAppsPolicyName());
				if (manageAppsenseProcess.getAppsPolicyMasterId() != null
						&& manageAppsenseProcess.getAppsPolicyMasterId()
								.longValue() != 0) {

					appsenseADGroupName.setId(manageAppsenseProcess
							.getAppsPolicyMasterId());
					appsenseADGroupName = manageAppsenseProcess
							.updateAppsADGroup(appsenseADGroupName);

				} else {

					appsenseADGroupName = manageAppsenseProcess
							.storeAppsADGroup(appsenseADGroupName);
					util.updateAppsADGroupID(tiProcess.getId(),
							appsenseADGroupName.getId());
					util.updateProxyADGroupID(tiProcess.getId(),
							appsenseADGroupName.getId());
					manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroupName
							.getId());
				}

				// End of Task 9224

	
					List<ProxyFilter> getProxyFilterReadDataList = (ArrayList<ProxyFilter>) appsenseUtil.readExcelProxyFilterFile(
							file, tiProcess, tiRequest, proxyInstance, selectedTab,
							appsenseADGroupName);
					log.info("Size of getProxyFilterReadDataList::: "
							+ getProxyFilterReadDataList.size());
					List<AppsenseUser> storedAppsUserList = new ArrayList<AppsenseUser>();
					String failureStatusMessage = "successMessage";
					
						if (appsenseUtil.isAppsenseUsersValid(getProxyFilterReadDataList)) {
							storedAppsUserList = (ArrayList<AppsenseUser>) appsenseUtil.storeAppsenseUserRecords(
									getProxyFilterReadDataList, selectedTab,
									request.getHeader("SM_USER"), manageAppsenseProcess);
							log.info("Size of Stored Proxy List::: "
									+ storedAppsUserList.size());
							appsenseUtil.writeExcelProxyFilter(storedAppsUserList, tiReq,
									selectedTab);

							failureStatusMessage = "successMessage";
					String filePath = null;
					File fileExist = null;

						for (int i = 0; i < storedAppsUserList.size(); i++) {
							AppsenseUser appsenseManageUser = (AppsenseUser) storedAppsUserList
									.get(i);
							if (appsenseManageUser.getStatus().equals("Failure")) {
								failureStatusMessage = "failureMessage";
							}
						}
						

					// Added for Task 9224
					if (failureStatusMessage.equals("successMessage")) {
						request.setAttribute(
								"success_log",
								"Upload Completed.Template data uploaded successfully. Download template and check.");
					} else if (failureStatusMessage.equals("failureMessage")) {
						request.setAttribute("success_log",
								"Upload Completed. Download the template and check for errors.");
					} else if (failureStatusMessage.equals("uploadfailed")) {
						request.setAttribute("error_log",
								"Upload Failed. Download the template and check for errors.");
					}
					

						//filePath = props.getString("XLS_FILE_WRITE_PROXY_FILTER_PATH")+ tiReq + "_manageUser.xls";
						filePath=System.getProperty("application-log-path")+ tiReq + "_manageUser.xls";
						fileExist = new File(filePath);
						if (fileExist == null || !fileExist.exists()
								|| fileExist.equals("")) {
							request.setAttribute("file_status", "false");
						} else {
							log.info("File Exists");
							request.setAttribute("file_status", "true");
						}
						request.setAttribute("fileStoredPath", tiReq
								+ "_manageUser.xls");						
						
					}
				    }
					// End of Task 9224
			} catch (Exception ex) {
				log.info("Exception occurred");
				throw new BusinessException(
						"Error ocurred while uploading the Excel");
			}
			
			log.info("ManageAppsenseProcess.uploadProxyFilterExcel()::Ends");
			return "forward:/loadAppsenseUsers.act";
		}

}
