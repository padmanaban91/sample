/**
 * 
 */
package com.citigroup.cgti.c3par.reports.util;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.context.ApplicationContext;

import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;

/**
 * @author ka58098
 *
 */
public class ClearReportTablesJob implements Job {
    private static Logger log = Logger.getLogger(ClearReportTablesJob.class);
    private ApplicationContext appContext = null;
  
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.info("Start job ::");
        appContext = CCRApplicationContextUtils.getApplicationContext();
        DropReportTablesUtil dropReportTablesUtil = (DropReportTablesUtil) appContext.getBean("dropTempTables");
        dropReportTablesUtil.clearTempTables();
        log.info("End job ::");
    }
}
