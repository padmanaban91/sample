package com.citigroup.cgti.c3par.gdw;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.citigroup.cgti.c3par.util.C3parProperties;
import com.mentisys.util.databaserealm.PasswordEncryptionException;

public class CCR_GDW_Connection {
	
//	private Connection CCRconnection;
	private Connection GDWconnection;
	
	/*public Connection getCCRConnection()
	{
		if(CCRconnection!=null)
		{
			return CCRconnection;
		}else{
			try {
				Class.forName(C3parProperties.DATABASE_JDBC_DRIVER);
				CCRconnection = DriverManager.getConnection(C3parProperties.CCR_DATABASE_URL_THIN,C3parProperties.DATABASE_USER,EncryptDBPassword.decryptDatabasePassword(C3parProperties.DATABASE_PASSWORD));
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (PasswordEncryptionException e) {
				e.printStackTrace();
			}
			return CCRconnection;
		}
	}*/
	
	public Connection getGDWConnection()
	{
		if(GDWconnection!=null)
		{
			return GDWconnection;
		}else{
			try {
				Class.forName(C3parProperties.GDW_DATABASE_JDBC_DRIVER);
				GDWconnection = DriverManager.getConnection(C3parProperties.GDW_DATABASE_URL,C3parProperties.GDW_DATABASE_USER,EncryptDBPassword.decryptDatabasePassword(C3parProperties.GDW_DATABASE_PASSWORD));
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (PasswordEncryptionException e) {
				e.printStackTrace();
			}
			return GDWconnection;
		}
	}
	
	/*public void closeCCRConnection()
	{
		if(CCRconnection!=null)
		{
			System.out.println("closing connection..");
			try {
				CCRconnection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}*/
	
	public void closeGDWConnection()
	{
		if(GDWconnection!=null)
		{
			try {
				GDWconnection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
