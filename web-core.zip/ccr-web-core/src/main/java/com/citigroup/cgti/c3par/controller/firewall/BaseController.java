package com.citigroup.cgti.c3par.controller.firewall;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.webtier.helper.DataCollectionHelper;
import com.citigroup.cgti.c3par.webtier.helper.Util;

public class BaseController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	public Long getPreviousVersionTiRequestIDForTemplate(Long processID, HttpServletRequest request) {
		FireWallRuleProcess	firewallRuleProcess = new FireWallRuleProcess();
		Long tiRequestId = 0L;
		try{
		tiRequestId = firewallRuleProcess.getPreviousVersionTIRequestForTemplate(processID);
		}
		catch(Exception e)
		{
			tiRequestId = getTirequestID(request);
			log.debug("ti request id" +tiRequestId);
			return tiRequestId;	
		}
		if(tiRequestId == 0L )
		{
			tiRequestId = getTirequestID(request);
			log.debug("tirequest id " +tiRequestId);
			return tiRequestId;
		}
		log.debug("ti request id in struts2base action" +tiRequestId);
		return tiRequestId;
	}
	
	public Long getPreviousVersionTiRequestID(Long processID, HttpServletRequest request) {
		FireWallRuleProcess	firewallRuleProcess = new FireWallRuleProcess();
		Long tiRequestId = 0L;
		try{
		tiRequestId = firewallRuleProcess.getPreviousVersionTIRequest(processID);
		}
		catch(Exception e)
		{
			tiRequestId = getTirequestID(request);
			log.debug("ti request id" +tiRequestId);
			return tiRequestId;	
		}
		if(tiRequestId == 0L )
		{
			tiRequestId = getTirequestID(request);
			log.debug("ti request id" +tiRequestId);
			return tiRequestId;	
		}
		log.debug("ti request id in struts2base action" +tiRequestId);
		return tiRequestId;
	}
	
	protected Long getTirequestID(HttpServletRequest request){

		Long tirequestId = 0L;
		if(request.getSession().getAttribute("tireqid") != null){
			tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());			
		}else if(request.getParameter("tireqid") != null){
			tirequestId = Long.valueOf(request.getParameter("tireqid").trim());			
		}else { 
			tirequestId = Long.valueOf(request.getParameter("tiRequestId"));
		}
		log.debug("getTirequestID..... "+tirequestId);
		return tirequestId;
	}
	
	protected TIRequest getTirequest(HttpServletRequest request){
		TIRequest tirequest = (TIRequest) request.getSession().getAttribute(
				"TI_REQUEST_ENTITY");
		return tirequest;
	}
	
	protected long getTiProcessId(HttpServletRequest request) {
		TIRequest tiRequestEntity = null;
		tiRequestEntity = (TIRequest) request.getSession().getAttribute(
				"TI_REQUEST_ENTITY");
		return tiRequestEntity.getTiProcess().getId();
		
	}
	
	protected void isAppsenseCompleteCheck(HttpServletRequest request) {
		String isApplicationComplete = "true";
		String isProxyComplete = "true";
		String isOstiaComplete = "true";
		String isUsersComplete = "true";
		
		DataCollectionHelper dataCollectionHelper = new DataCollectionHelper();
		if (!dataCollectionHelper.isAppApplicationTabComplete(getTiProcessId(request))) {
			isApplicationComplete = "false";
		}
		if (!dataCollectionHelper.isAppProxyFilterTabComplete(getTiProcessId(request))) {
			isProxyComplete = "false";
		}
		if (!dataCollectionHelper.isAppOstiaTabComplete(getTiProcessId(request))) {
			isOstiaComplete = "false";
		}
		if (!dataCollectionHelper.isAppUserTabComplete(getTiProcessId(request))) {
			isUsersComplete = "false";
		}
		
		request.getSession().setAttribute("isAppsenseApplicationComplete", isApplicationComplete);
		request.getSession().setAttribute("isAppsenseProxyComplete", isProxyComplete);
		request.getSession().setAttribute("isAppsenseOstiaComplete", isOstiaComplete);
		request.getSession().setAttribute("isAppsenseUsersComplete", isUsersComplete);
	}
	
	protected void isCompleteCheck(HttpServletRequest request) {
		String isFirewallRuleComplete = "true";
		String isIPDetailsComplete = "true";
		//String isFWDetailsComplete = "true";
		String isFAFComplete = "true";
		String isRFCComplete = "true";
		String isOstiaComplete = "true";
		String con_type= "";
		if(request.getSession().getAttribute("con_type") != null){
			con_type = (String) request.getSession().getAttribute("con_type");
		}
		
		long tiRequestId = getCurrentTiRequest(request).getId();
		
		log.debug("isCompleteCheck :tiRequest ---- "+tiRequestId);
		FireWallRuleProcess completeCheck = new FireWallRuleProcess();
		completeCheck.setTiRequest(tiRequestId);
		int noOfRules = completeCheck.getFirewallRulesRowCount(completeCheck);
		log.debug("isCompleteCheck :noOfRules ---- "+noOfRules);
		//Firewall Rules Tab
		if (noOfRules > 0)  {
			isFirewallRuleComplete = "false";
			isIPDetailsComplete = "false";
			//isFWDetailsComplete = "false";
			isFAFComplete = "false";
			isRFCComplete = "false";
			isOstiaComplete = "false";
			
			// IP Details Tab
			if (completeCheck.completeCheckIPDetails(completeCheck,con_type)) {
				isIPDetailsComplete = "true";
			}
			
			// FireWall Rules Tab
			if (completeCheck.completeCheckFireWallRules(completeCheck,con_type)) {
				isFirewallRuleComplete = "true";
			}
		}
		if(isRFCGenerated(request) ){
			isRFCComplete = "true";
		}else{
			isRFCComplete = "false";
		}
		/*if (noOfRules == 0)  {
			 isRFCComplete = "true";
		}*/
		//if fireflow disabled and no changes in FireWall rules
		
		if(!isFireFlowEnbled(request) && !isRuleChanged(request)){
			isFAFComplete="true";
		}
		
		//if fireflow enabled and no changes in FireWall rules and tickets are worked out
		else if(isFireFlowEnbled(request) && !isRuleChanged(request) && isFFTicketsImplemented(request)){
			isFAFComplete="true";
		}
	else{
		isFAFComplete = "false";
		isRFCComplete = "false";
		FAFRequest fafRequest=new FAFRequest();
		String conType = (String) request.getSession().getAttribute("con_type");
		fafRequest.deleteRFCFirewallRecords(getCurrentTiRequest(request).getId(), conType);
		fafRequest.resetRFCGeneratedStatus(getCurrentTiRequest(request).getId(),conType);
				
			}
		if(isRuleChanged(request)){			
			FAFRequest fafRequest=new FAFRequest();
			String conType = (String) request.getSession().getAttribute("con_type");
			fafRequest.deleteRFCFirewallRecords(getCurrentTiRequest(request).getId(), conType);
			fafRequest.resetRFCGeneratedStatus(getCurrentTiRequest(request).getId(),conType);
		}
		if(isRFCGenerated(request) ){
			isRFCComplete = "true";
		}
		if(isOstiaComplete(request)){
			isOstiaComplete = "true";
		}
//		if(getFirewallCircuitDetailsCheck()){
//			isFWDetailsComplete = "true";
//		}
		
		request.getSession().setAttribute("isFirewallRuleComplete", isFirewallRuleComplete);
		request.getSession().setAttribute("isIPDetailsComplete",isIPDetailsComplete);
		//request.getSession().setAttribute("isFWDetailsComplete",isFWDetailsComplete);
		request.getSession().setAttribute("isFAFComplete",isFAFComplete);
		request.getSession().setAttribute("isRFCComplete",isRFCComplete);
		request.getSession().setAttribute("isOstiaComplete",isOstiaComplete);
		
	}
	private boolean isOstiaComplete(HttpServletRequest request) {
		Util util=new Util();
		String con_type = (String) request.getSession().getAttribute("con_type");
		return util.isOstiaCompleted(getCurrentTiRequest(request).getId(),con_type);
	}

	private boolean isFFTicketsImplemented(HttpServletRequest request) {
		FAFRequest fafRequest=new FAFRequest();
		return fafRequest
				.isFFTicketsImplemented(getCurrentTiRequest(request).getId());
	}

	private boolean isFireFlowEnbled(HttpServletRequest request) {
		FAFRequest fafRequest=new FAFRequest();
		TIRequest tiRequest = fafRequest.getTIRequest(getCurrentTiRequest(request)
				.getId());
		String fireFlowEnabled = tiRequest.getFireflowFlag();
		return "Y".equalsIgnoreCase(fireFlowEnabled);
	}
	private boolean isRFCGenerated(HttpServletRequest request) {
		FAFRequest fafRequest=new FAFRequest();
		TIRequest tiRequest = fafRequest.getTIRequest(getCurrentTiRequest(request)
				.getId());
		String rfcGenFlag = null;
		String conType = (String) request.getSession().getAttribute("con_type");
		if ("ipReg".equalsIgnoreCase(conType)) {
			rfcGenFlag = tiRequest.getIpRfcGenFlag();
		} else {
			rfcGenFlag = tiRequest.getRfcGenFlag();
		}
		return rfcGenFlag== null || "Y".equalsIgnoreCase(rfcGenFlag);

	}
	private boolean isRuleChanged(HttpServletRequest request) {
		
		FireWallRuleProcess fireWallRuleProcess = new FireWallRuleProcess();
		String con_type = (String) request.getSession().getAttribute("con_type");
		return fireWallRuleProcess
				.isFireWallRulesHasChanged(getCurrentTiRequest(request).getId(),con_type);
		
		//**** found an issue in determining the rule change and hence retrunig the true always for time being.
	}
	
	protected TIRequest getCurrentTiRequest(HttpServletRequest request) {
		return getTirequest(request);
	}
	
}
