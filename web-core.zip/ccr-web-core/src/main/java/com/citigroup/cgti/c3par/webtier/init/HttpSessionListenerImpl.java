package com.citigroup.cgti.c3par.webtier.init;

import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.citigroup.cgti.c3par.C3parSession;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;
import com.mentisys.impl.gen.locking.dao.LockDAO;
import com.mentisys.impl.gen.locking.model.LockEntity;
import org.apache.log4j.Logger;


/**
 * The Class HttpSessionListenerImpl.
 */
public class HttpSessionListenerImpl implements HttpSessionListener
{

    /** The log. */
    private static Logger log = Logger.getLogger(HttpSessionListenerImpl.class);

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpSessionListener#sessionCreated(javax.servlet.http.HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent event)
    {
    }

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpSessionListener#sessionDestroyed(javax.servlet.http.HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent event)
    {
	C3parSession dbSession = new C3parSession() ;

	try
	{
	    // following does the getConnection() and startTransaction()
	    dbSession.init();

	    String sessionId = event.getSession().getId();
	    LockDAO dao = new LockDAO(dbSession);

	    Condition condition = new Condition();
	    OperatorExpression sessionIdExp = 
		new OperatorExpression(LockDAO.TABLE + "." + LockDAO.COLUMN_SESSIONID, Operator.EQUAL, sessionId);
	    condition.addExpression(sessionIdExp);

	    List list = dao.query(condition, false);
	    if(list != null && list.size() > 0)
	    {
		LockEntity entity = (LockEntity)list.get(0);
		dao.delete(entity);
	    }

	    dbSession.finish();
	}
	catch(DatabaseException ex)
	{
	    log.error(ex);
	    try {
		dbSession.rollback();
		dbSession.releaseConnection();

	    } catch (DatabaseException e) {
		// REVISIT : what to do here ?
		log.error(e);
	    }
	}finally{
	    try{
		dbSession.releaseConnection();
	    }catch(Exception xe){

	    }
	}
    }
}