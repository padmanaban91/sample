package com.citigroup.cgti.c3par.lookup;

import com.citigroup.cgti.c3par.model.C3parUserExtEntity;



/**
 * The Class C3parUsersExtLookup.
 */
public class C3parUsersExtLookup /*extends C3parUsersLookup*/ {

    /** The c3parlookup. */
    C3parUsersLookup c3parlookup = C3parUsersLookup.getInstance();




    /**
     * Gets the by id.
     *
     * @param id the id
     * @return the by id
     */
    synchronized public C3parUserExtEntity getById(Long id)
    {
	c3parlookup.getById(id);
	return null;

    }

    /**
     * Gets the by sso id.
     *
     * @param v the v
     * @return the by sso id
     */
    synchronized public C3parUserExtEntity getBySsoId(String v)
    {
	c3parlookup.getBySsoId(v);
	return null;
    }
}
