package com.citigroup.cgti.c3par.acl.domain.logic;

import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.acl.dao.FireFlowProcessPersistable;
import com.citigroup.cgti.c3par.domain.TIRequest;

// TODO: Auto-generated Javadoc
/**
 * The Class FireFlowProcessImpl.
 */
@SuppressWarnings("unchecked")
public class FireFlowProcessImpl implements FireFlowProcess{

    /** The log. */
    protected Logger log = Logger.getLogger(this.getClass().getName());

    /** The fire flow process persistable. */
    private FireFlowProcessPersistable fireFlowProcessPersistable ;

    /**
     * Sets the fire flow process persistable.
     *
     * @param fireFlowProcessPersistable the new fire flow process persistable
     */
    public void setFireFlowProcessPersistable(
	    FireFlowProcessPersistable fireFlowProcessPersistable) {
	this.fireFlowProcessPersistable = fireFlowProcessPersistable;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.domain.logic.FireFlowProcess#getFireFlowRequests(com.citigroup.cgti.c3par.domain.TIRequest)
     */
    @Override
    public List getFireFlowRequests(TIRequest tiRequest) {
	// TODO Auto-generated method stub
	return fireFlowProcessPersistable.getFireFlowRequests(tiRequest);
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.domain.logic.FireFlowProcess#getFireFlowRequests(long, int, int)
     */
    @Override
    public List getFireFlowRequests(long processId, int pageNo,
	    int noOfRecords) {
	return fireFlowProcessPersistable.getFireFlowRequests(processId,pageNo,noOfRecords);
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.domain.logic.FireFlowProcess#getTotalNumber(long)
     */
    public int getTotalFireFlowRequests(long processId){
	return fireFlowProcessPersistable.getTotalNumber(processId);
    }
}