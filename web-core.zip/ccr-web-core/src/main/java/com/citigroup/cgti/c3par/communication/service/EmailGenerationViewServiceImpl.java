
package com.citigroup.cgti.c3par.communication.service;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.internal.SessionImpl;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.TIActivityTrail;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestContactXref;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestNotes;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.EmailGenerationViewServicePersistable;
import com.citigroup.cgti.c3par.domain.CMPRole;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

import oracle.jdbc.OracleTypes;
@Transactional
public class EmailGenerationViewServiceImpl extends BasePersistanceImpl implements EmailGenerationViewServicePersistable {

	private static Logger log = Logger.getLogger(EmailGenerationViewServiceImpl.class);

	@Override
	@Transactional(readOnly = true)
	public List<Sector> loadSectorListByName(String regionName){
		Session session = getSession();
		log.info("EmailGenerationViewServiceImpl :: loadSectorListByName :: regionName - "+regionName);
		
		StringBuffer queryString = new StringBuffer();
		queryString.append(" select distinct sec.* from CITI_HIERARCHY_MASTER citimaster join REGION reg on citimaster.region_id = reg.id ");
		queryString.append("join SECTOR sec on citimaster.sector_id = sec.id where ");
		
		if (regionName != null && !regionName.isEmpty()) {
			queryString.append(" reg.name like '"+regionName+"' and ");
		}
		queryString.append(" sec.is_active = 'Y' group by sec.id,sec.name,sec.is_active,sec.description order by sec.name ");
		
		SQLQuery query = session.createSQLQuery(queryString.toString());
		query.addEntity("sec", Sector.class);
		
		List<Sector> sectorList = query.list();		
		if(sectorList != null)
			log.debug("EmailGenerationViewServiceImpl :: loadSectorListByName :: size ::"+sectorList.size());
		
		return sectorList;
	}

	@Override
	@Transactional(readOnly = true)
	public List<BusinessUnit> loadBusinessUnitListByName(String regionName, String sectorName){
		Session session = getSession();
		log.info("EmailGenerationViewServiceImpl :: loadSectorListByName :: regionName - "+regionName+" :: sectorName - "+sectorName);

		StringBuffer queryString = new StringBuffer();
		queryString.append(" select distinct bu.* from CITI_HIERARCHY_MASTER citimaster join REGION reg on citimaster.region_id = reg.id ");
		queryString.append(" join SECTOR sec on citimaster.sector_id = sec.id join BUSINESS_UNIT bu on citimaster.bu_id = bu.id ");
		queryString.append(" where reg.name like '"+regionName+"' and sec.name like '"+sectorName+"' and bu.is_active = 'Y' order by bu.business_name ");
		
		SQLQuery query = session.createSQLQuery(queryString.toString());
		query.addEntity("bu", BusinessUnit.class);

		List<BusinessUnit> businessUnitList = query.list();	
		if(businessUnitList != null)
			log.debug("EmailGenerationViewServiceImpl :: loadBusinessUnitListByName :: size ::"+businessUnitList.size());
		
		return businessUnitList;
	}

	@Override
	@Transactional(readOnly = true)
	public List<CMPRole> loadCMPRoles(){
		Session session = getSession();
		Criteria criteria = session.createCriteria(CMPRole.class);
		criteria.add(Restrictions.eq("isactive", "Y"));
		criteria.addOrder(Order.asc("id"));

		List<CMPRole> list = criteria.list();		
		if(list != null)
			log.debug("EmailGenerationViewServiceImpl :: loadCMPRoles :: size ::"+list.size());
		
		return list;		
	}
	
	@Override
	@Transactional(readOnly = true)
	public CMPRequest getCMPRequestDetails(String cmpReqId) {
		Session session = getSession();
		CMPRequest cmpRequest = null;
		log.info("EmailGenerationViewServiceImpl :: getCMPRequestDetails :: cmpReqId - "+cmpReqId);
		Criteria criteria = session.createCriteria(CMPRequest.class);
		criteria.add(Restrictions.eq("orderItemId", cmpReqId));
		List<CMPRequest> cmpReqList = criteria.list();
		
		try {
		 
			if (cmpReqList != null && cmpReqList.size() > 0) {
				cmpRequest = cmpReqList.get(0);
				lazyInitialize(cmpRequest.getTiactivityTrail());
				lazyInitialize(cmpRequest.getCmpRequestNotes());
				lazyInitialize(cmpRequest.getCmpRequestAttachments());
				log.debug("EmailGenerationViewServiceImpl :: getCMPRequestDetails :: size ::" + cmpReqList.size());
			}
		} catch (Exception e) {
			log.error(e, e);

		}
		
		
		CallableStatement callstm = null;
		
		if (cmpReqList != null && cmpReqList.size() > 0) {
		 
		try {
			int time = 0;
			String procedureCall = "{call CALCULATE_ACTIVITY_TIME(?,?,?)}";
			callstm = ((SessionImpl) getSession()).connection()
					.prepareCall(procedureCall);
			
			callstm.setLong(1, cmpRequest.getId()); 
			callstm.setString(2, "ECM TIMER");
			callstm.registerOutParameter(3, OracleTypes.BIGINT);
			callstm.executeUpdate();
			time = callstm.getBigDecimal(3).intValue();
			cmpRequest.setEcmTimer(Long.valueOf(time)); 
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}
		}
		return cmpRequest;
	}
	
	@Override
	@Transactional(readOnly = true)
	public CMPRequest getCMPRequestDetailsByOrderId(String cmpReqId) { 
		log.info("EmailGenerationViewServiceImpl :: getCMPRequestDetailsByOrderId :: cmpReqId - "+cmpReqId);

		Session session = getSession();
		CMPRequest cmpRequest = null;
		try {
			Criteria criteria = session.createCriteria(CMPRequest.class);
			criteria.add(Restrictions.eq("orderId", cmpReqId));

			List<CMPRequest> cmpReqList = criteria.list();
			
			if (cmpReqList != null && cmpReqList.size() > 0) {
				cmpRequest = cmpReqList.get(0);
				lazyInitialize(cmpRequest.getTiactivityTrail());
				lazyInitialize(cmpRequest.getCmpRequestNotes());
				log.debug("EmailGenerationViewServiceImpl :: getCMPRequestDetailsByOrderId :: size ::" + cmpReqList.size());
			}
		} catch (Exception e) {
			log.error(e, e);

		}
		CallableStatement callstm = null;
		try {
			int time = 0;
			String procedureCall = "{call CALCULATE_ACTIVITY_TIME(?,?,?)}";
			callstm = ((SessionImpl) getSession()).connection()
					.prepareCall(procedureCall);
			callstm.setLong(1, cmpRequest.getId()); 
			callstm.setString(2, "ECM TIMER");
			callstm.registerOutParameter(3, OracleTypes.BIGINT);
			callstm.executeUpdate();
			time = callstm.getBigDecimal(3).intValue();
			cmpRequest.setEcmTimer(Long.valueOf(time)); 
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}
		return cmpRequest;
	}

	@Override
	@Transactional(readOnly = true)
	public List<CMPRequest> getCmpReqIdsList(String assignedUser, String cmpReqId) {
		Session session = getSession();
		log.info("EmailGenerationViewServiceImpl :: getCmpReqIdsList :: assignedUserId - "+assignedUser+" :: cmpReqId - "+cmpReqId);

		Criteria criteria = session.createCriteria(CMPRequest.class);
	    criteria.createCriteria("assignedUser", "assignedUser");
		criteria.add(Restrictions.eq("assignedUser.ssoId", assignedUser));
		
		if(cmpReqId != null && !cmpReqId.isEmpty()){
			criteria.add(Restrictions.ilike("orderItemId", "%"+cmpReqId+"%"));
		}

		List<CMPRequest> cmpReqList = criteria.list();

		if(cmpReqList != null){
			log.debug("EmailGenerationViewServiceImpl :: getCmpReqIdsList :: size - " + cmpReqList.size());
		}
		
		return cmpReqList;
	}

	
	@Override
	public List<CMPRequest> getCmpReqIdSearchList(String cmpReqId) {
		Session session = getSession();
		log.info("EmailGenerationViewServiceImpl :: getCmpReqIdSearchList ::  cmpReqId - "+cmpReqId);

		Criteria criteria = session.createCriteria(CMPRequest.class);
	    
		if(cmpReqId != null && !cmpReqId.isEmpty()){
			if(cmpReqId.trim().equals("*"))
				cmpReqId = "%";
			else if(cmpReqId.trim().contains("*"))
				cmpReqId = cmpReqId.replaceAll("\\*", "%");
			criteria.add(Restrictions.ilike("orderItemId", "%"+cmpReqId+"%")); 
		}

		List<CMPRequest> cmpReqList = criteria.list();

		if(cmpReqList != null){
			log.debug("EmailGenerationViewServiceImpl :: getCmpReqIdSearchList :: size - " + cmpReqList.size());
		}
		
		return cmpReqList;
	}
	
	@Override
	@Transactional(readOnly = true)
	public C3parUser getLoginAssignedUser(String ssoId) {
		Session session = getSession();
		log.info("EmailGenerationViewServiceImpl :: getLoginAssignedUser :: ssoId - "+ssoId);

		C3parUser c3PARUser = null;
		try {
			Criteria criteria = session.createCriteria(C3parUser.class);
			criteria.add(Restrictions.eq("ssoId", ssoId));

			List<C3parUser> c3PARUserList = criteria.list();

			if (c3PARUserList != null && c3PARUserList.size() > 0) {
				c3PARUser = c3PARUserList.get(0);
				
				log.debug("EmailGenerationViewServiceImpl :: getLoginAssignedUser :: size ::" + c3PARUserList.size());
			}
		} catch (Exception e) {
			log.error(e, e);

		}
		return c3PARUser;
	}

	@Override
	public void updateCMPRequestDetails(CMPRequest cmpRequest) {
		log.debug("EmailGenerationViewServiceImpl :: updateCMPRequestDetails :: cmpRequest ::"+ cmpRequest.getOrderItemId());

		Session session = getSession();
		
		//update cmp details
		session.update(cmpRequest);

		//update cmp Contacts
		if(cmpRequest.getCmpRequestContactXrefs() != null && !cmpRequest.getCmpRequestContactXrefs().isEmpty()){
			for(CMPRequestContactXref cmpreqcontact:cmpRequest.getCmpRequestContactXrefs()){
				if(cmpreqcontact.getId() != null && cmpreqcontact.getId().longValue() > 0 && cmpreqcontact.isDisabled()){
					log.debug("EmailGenerationViewServiceImpl :: updateCMPRequestContactDetails :: Deleting contact ::"+ cmpreqcontact.getCiticontact().getSsoId());
					session.delete(cmpreqcontact);
				}else if(cmpreqcontact.getId() == null || cmpreqcontact.getId().longValue() <= 0){
					log.debug("EmailGenerationViewServiceImpl :: updateCMPRequestContactDetails :: Adding contact ::"+ cmpreqcontact.getCiticontact().getSsoId());
					session.save(cmpreqcontact);
				}
			}
		}
		
		log.debug("EmailGenerationViewServiceImpl :: updateCMPRequestDetails :: ends...");
	}

	@Override
	public void updateAddNoteDetails(CMPRequestNotes cmpRequestNotes) {
		log.debug("EmailGenerationViewServiceImpl :: updateCMPRequestDetails :: starts");
		
		try {
			Session session = getSession();
			String notes = cmpRequestNotes.getNotes();
			cmpRequestNotes.setNewNotes(Hibernate.getLobCreator(session).createClob(notes));
			session.saveOrUpdate(cmpRequestNotes);
		} catch (Exception e) {
			log.error("Exception in file upload save",e);
		}
		
		log.debug("EmailGenerationViewServiceImpl :: updateCMPRequestDetails :: ends...");
	}

	@Override
	@Transactional(readOnly = true)
	public boolean isWaitingforBusinessReply(Long cmpId,String activityCode){
		Session session = getSession();
		
		SQLQuery query = session.createSQLQuery("select count(*) cnt from  ti_activity_trail act, ti_task_type task "
				+" where act.activity_id = task.id and task.task_timer_activity = '"+ECMConstants.BUSINESS_TIMER+"' and act.activity_status = 'STARTED' "
				+" and act.cmp_id = "+cmpId+" and exists (select 1 from ti_task_type ttt where ttt.task_timer_activity = '"+ECMConstants.BUSINESS_TIMER+"' "
				+" and ttt.task_code = '"+activityCode+"') ");
		
		query.addScalar("cnt", IntegerType.INSTANCE);
		Integer isRecordAvailable = (Integer)query.uniqueResult();
		
		if(isRecordAvailable != null && isRecordAvailable.intValue() > 0)
			return true;
		else 
			return false;
	}
	
	@Override
	@Transactional(readOnly = true)
	public boolean isWaitingforECMUserReply(Long cmpId, String actCode){
		Session session = getSession();
		log.debug("Before execute query..");
		
		SQLQuery query = session.createSQLQuery("select count(*) cnt from  ti_activity_trail act, ti_task_type task "
				+" where act.activity_id = task.id and act.activity_status = 'STARTED' "
				+" and act.cmp_id = "+cmpId+" and task.task_code = '"+actCode+"' ");
		log.debug("After  execute query");
		
		query.addScalar("cnt", IntegerType.INSTANCE);
		Integer isRecordAvailable = (Integer)query.uniqueResult();
		
		if(isRecordAvailable != null && isRecordAvailable.intValue() > 0)
			return true;
		else 
			return false;
	}
	
	@Override
	@Transactional(readOnly = true)
	public int updateCMPRequestStatus(Long cmpId,String status) {
		log.debug("EmailGenerationViewServiceImpl :: updateCMPRequestStatus :: cmpId - "+cmpId+" :: status - "+cmpId);
		int id = 0;
		Session session = getSession();
		try {
			SQLQuery sqlQuery = session.createSQLQuery("update cmp_request set STATUS='"+status+"' ,UPDATED_DATE=sysdate where ID="+ cmpId);
			id = sqlQuery.executeUpdate();
		} catch (Exception e) {
			log.error(e, e);
		}
		return id;
	}

	@Override
	@Transactional(readOnly = true)
	public int transferEcmAgent(String reassignedUser, String cmpId, String userId) {
		log.debug("EmailGenerationViewServiceImpl :: transferEcmAgent :: reassignedUser - "+reassignedUser+" :: cmpId - "+cmpId+" :: userId - "+userId);
		int id = 0;
		Session session = getSession();
		try {
			String fetchUserIdQuery = "(select id from C3PAR_USERS where upper(SSO_ID)='"+reassignedUser.toUpperCase()+"')";
			SQLQuery sqlQuery = session.createSQLQuery("update cmp_request set ASSIGNED_USER="
							+ fetchUserIdQuery
							+ ",UPDATE_ASSIGNED_USER_DATE=sysdate where ORDER_ITEM_ID= '"+ cmpId + "'");
			id = sqlQuery.executeUpdate();
		} catch (Exception e) {
			log.error(e, e);
		}
		return id;
	}

	@Override
	@Transactional(readOnly = true)
	public List<Map<String, String>> getChangeRequestDetails(Long conReqId, String cmpID){
		
		Session session = getSession();
		List<Map<String, String>> changeReqList = new ArrayList<Map<String, String>>();

    	log.debug("EmailGenerationViewServiceImpl::getChangeRequestDetails:: conReqId-"+conReqId);
        
    	String query = "select rfc_id chgid,decode(install_begin_date,null,' ',install_begin_date) chgdate from rfc_Request rfc where rfc.ti_request_id = (select max(id) from ti_Request where process_id = "+conReqId +
    			") and upper(rfc_type) != upper('Generic') and rfc.rfc_id is not null and exists (select 1 from RESOLVE_IT_NOTIFY_LOG rit where rit.ti_request_id = rfc.ti_request_id and cmp_id='"+cmpID+ "')";

		SQLQuery sqlquery = session.createSQLQuery(query);
		sqlquery.addScalar("chgid",StringType.INSTANCE);
		sqlquery.addScalar("chgdate",StringType.INSTANCE);

		List<Object[]> resultrows = sqlquery.list();
		Map<String, String> changerequest = null;
		if(resultrows != null){
			for (Object[] obj : resultrows) {
				changerequest  = new HashMap<String,String>();
				changerequest.put("CHGID", (String)obj[0]);
				changerequest.put("CHGDATE", (String)obj[1]);
				
				changeReqList.add(changerequest);
			}
		}

		return changeReqList;
	}
	
	@Override
	@Transactional(readOnly = true)
	public CitiContact getAgentDetails(String ssoId) {		
		log.info("EmailGenerationViewServiceImpl: getAgentDetails: starts");
		
		Session session = getSession();
		CitiContact citiContact = null;
		
		Criteria criteria = session.createCriteria(CitiContact.class);
		criteria.add(Restrictions.eq("ssoId", ssoId));
		List<CitiContact> list = criteria.list();
		if(list != null && list.size() > 0){
			citiContact = list.get(0);			
		}

		log.info("EmailGenerationViewServiceImpl: getAgentDetails: ends");
		return citiContact;
	}	
	
	@Override
	@Transactional(readOnly = true)
	public List<TIMailAudit> getAuditTrialDetail(Long cmpId){
		log.info("EmailGenerationViewServiceImpl::getAuditTrialDetail starts");
		List<TIMailAudit> list = null;
		try{
			Session session = getSession();		
			log.debug("EmailGenerationViewServiceImpl: getAuditTrialDetail: cmpid::"+cmpId);	 
			StringBuffer queryString = new StringBuffer();
			queryString.append("select ti.* from TI_MAIL_AUDIT ti where ti.cmp_id ="+cmpId+" order by id desc");


			SQLQuery query = session.createSQLQuery(queryString.toString());
			log.debug("EmailGenerationViewServiceImpl: getAuditTrialDetail: queryString"+queryString.toString());		
			
			query.addEntity("ti",TIMailAudit.class);
			list = query.list();
			
			if(list != null && list.size() > 0){
				log.debug("EmailGenerationViewServiceImpl: getAuditTrialDetail: ends"+list.size());			
			}
			log.debug("EmailGenerationViewServiceImpl: getAuditTrialDetail: ends"+list.size());	
			
		} catch (Exception e) {
			log.error("EmailGenerationViewServiceImpl::getAuditTrialDetail exception ::" + e); 
		}
		log.debug("EmailGenerationViewServiceImpl: getAuditTrialDetail: ends"+list.size());	
		return list;
	}
	
	@Override
	@Transactional(readOnly = true)
	public void checkColourstatus(CMPRequest cmp){
		log.info("Entering EmailGenerationViewServiceImpl checkColourstatus.");
		try{
			Session session = getSession();	
			SQLQuery resolvtItquery = session
					.createSQLQuery("select Rt.Ti_Request_Id, Ta.Ti_Request_Id, cr.id,Cr.Order_Item_Id from Resolve_It_Notify_Log rt , Cmp_Request cr, Ti_Activity_Trail ta where Rt.Cmp_Request_Id = Cr.Id and Rt.Ti_Request_Id = Ta.Ti_Request_Id and cr.id ="
							+ cmp.getId());
			log.debug("EmailGenerationViewServiceImpl: Querying String::getCurrentCounts::" + resolvtItquery);
			List<Object[]> resolveItobj = resolvtItquery.list();
			log.debug("EmailGenerationViewServiceImpl: is resolveItobj::getCmpReqData::" + resolveItobj.size());
			StringBuilder sqlQuery = new StringBuilder("select * from (select * from TI_ACTIVITY_TRAIL where CMP_ID = " +cmp.getId());
			StringBuilder tiRequestId = new StringBuilder("");
			if (resolvtItquery.list().size() > 0) {
				cmp.setCheckTiId("Y");
				for(Object[] rs : resolveItobj){
					if(tiRequestId != null && tiRequestId.length() > 0){
						tiRequestId.append(", " +rs[0].toString());
					}
					else{
						tiRequestId.append(rs[0].toString());
					}					
				}
			}
			else {
				cmp.setCheckTiId("N");
			}
			if(tiRequestId != null && tiRequestId.length() > 0){
				sqlQuery.append(" union select * from TI_ACTIVITY_TRAIL where TI_REQUEST_ID in (" +tiRequestId.toString()+ ")");
			}
			sqlQuery.append(") TAT order by ID desc");
			log.debug("EmailGenerationViewServiceImpl: sqlQuery.toString()::"+ sqlQuery.toString());
			SQLQuery query1 = session.createSQLQuery(sqlQuery.toString());
			query1.addEntity("TAT", TIActivityTrail.class);
			cmp.setTiactivityTrail(query1.list());
		}
		catch(Exception e)
		{
			log.error("EmailGenerationViewServiceImpl::color status ::" + e);
		}
		log.info("Exiting EmailGenerationViewServiceImpl checkColourstatus.");
}

	@Override
	@Transactional(readOnly = true)
	public boolean checkCmpAssitanceReqFlag(Long  cmpId) {
		log.info("Entering  checkCmpAssitanceReqFlag ");
		boolean cmpAssitanceReqFlag=false;
		try{
			log.info("CMP ID: "+cmpId);
			Session session = getSession();	
			StringBuilder cmpAssitanceReqFlagQuery = new StringBuilder(   "  select act.ID  from ti_activity_trail act ,ti_task_type task  where cmp_id="+cmpId+" and "); 
			cmpAssitanceReqFlagQuery.append( "  (task.task_code='awaiting_assist_term_log' or task.task_code='awaiting_assist_term_log_no_add_inofrm_req'   ) and task.id=act.activity_id ");
			log.info("CmpAssitanceReqFlagQuery: "+cmpAssitanceReqFlagQuery);
			SQLQuery cmpAssitanceFlagQuery = session
					.createSQLQuery(cmpAssitanceReqFlagQuery.toString());
			if (cmpAssitanceFlagQuery.list().size() > 0) {
				cmpAssitanceReqFlag=true;
			}
			
		}
		catch(Exception e){
			log.error(e,e);
		}
		
		finally{
			log.info("CmpAssitanceReqFlag: "+cmpAssitanceReqFlag);
		log.info("Exiting  checkCmpAssitanceReqFlag.");
		return cmpAssitanceReqFlag;
		}
	}

	
}
