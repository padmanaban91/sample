package com.citigroup.cgti.c3par.webtier.forms.helper;

/**
 * @author rr89940
 *
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.citigroup.cgti.c3par.util.C3parProperties;



/**
 * The Class GDIRConnectorHelper.
 */
public class GDIRConnectorHelper {

    /** The str mgr invoke token. */
    private final String strMgrInvokeToken = "PBH01";

    /** The str emp details token. */
    private final String strEmpDetailsToken = "ID";

    /** The str mgr details token. */
    private final String strMgrDetailsToken = "BASIC";

    /** The str geid. */
    private final String strGEID = "GEID";

    /** The str email address. */
    private final String strEmailAddress = "EmailAddress";

    /** The str pbh. */
    private final String strPBH = "PBH_String";

    /** The log. */
    private static Logger log = Logger.getLogger(GDIRConnectorHelper.class);

    // NEED TO READ THESE TWO VARIABLES FROM System. Add these to myserver-c3par.properties
    /** The str authorisation code. */
    private final String strAuthorisationCode = C3parProperties.GDIR_AUTHORISATION_CODE;

    /** The str uri. */
    private String strURI = C3parProperties.GDIR_URI;



    /**
     * Gets the managerial hierarchy.
     *
     * @param strSOEId the str soe id
     * @return the managerial hierarchy
     * @throws Exception the exception
     */
    public List getManagerialHierarchy(String strSOEId) throws Exception{
	List mgrList = new ArrayList();
	String strMgr = null;
	String geId = null;
	strSOEId = strSOEId.toUpperCase();
	StringBuffer strBuf = new StringBuffer("");

	strBuf.append(strURI);
	log.debug("Return value from method ===>>> GEID ===>>> " + getGEIdFromSOEId(strSOEId));
	geId = getGEIdFromSOEId(strSOEId);

	strBuf.append(geId);
	strBuf.append("&AUID=");
	strBuf.append(strAuthorisationCode);
	strBuf.append("&InfoType=");
	strBuf.append(strMgrInvokeToken);
	log.debug("GDIR for Mgr Detail ==> " + strBuf.toString());

	strMgr = invokeGDIR(strBuf.toString(), 2);
	mgrList = tokenizeList(strMgr);
	return mgrList;

    }

    /**
     * Gets the manager geid.
     *
     * @param strSOEId the str soe id
     * @return the manager geid
     * @throws Exception the exception
     */
    private String getManagerGEID(String strSOEId) throws Exception{
	String mgrGEID = "";
	String strMgr = null;
	String geId = null;
	strSOEId = strSOEId.toUpperCase();
	StringBuffer strBuf = new StringBuffer("");

	strBuf.append(strURI);
	log.debug("Return value from method ===>>> GEID ===>>> " + getGEIdFromSOEId(strSOEId));
	geId = getGEIdFromSOEId(strSOEId);

	strBuf.append(geId);
	strBuf.append("&AUID=");
	strBuf.append(strAuthorisationCode);
	strBuf.append("&InfoType=");
	strBuf.append(strMgrInvokeToken);
	log.debug("GDIR for Mgr Detail ==> " + strBuf.toString());

	strMgr = invokeGDIR(strBuf.toString(), 2);
	StringTokenizer strToken = new StringTokenizer(strMgr, "-->");
	String presentToken = null;
	int iCount = 0;
	while (strToken.hasMoreTokens()) {
	    presentToken = strToken.nextToken();
	    if (iCount != 0){
		mgrGEID = presentToken;
		break;
	    }
	    iCount++;
	}
	return mgrGEID;

    }

    /**
     * Tokenize list.
     *
     * @param strMgr the str mgr
     * @return the list
     */
    private List tokenizeList(String strMgr){
	List mgrList = new ArrayList();
	StringTokenizer strToken = new StringTokenizer(strMgr, "-->");
	String presentToken = null;
	int iCount = 0;

	while (strToken.hasMoreTokens()) {
	    presentToken = strToken.nextToken();
	    if (iCount != 0)
		mgrList.add(presentToken);
	    iCount++;
	}
	return mgrList;
    }

    /**
     * Gets the gE id from soe id.
     *
     * @param strSOEId the str soe id
     * @return the gE id from soe id
     * @throws Exception the exception
     */
    public String getGEIdFromSOEId(String strSOEId) throws Exception{
	StringBuffer strBuf = new StringBuffer("");
	String strReturn = null;
	strBuf.append(strURI);
	strBuf.append(strSOEId);
	strBuf.append("&AUID=");
	strBuf.append(strAuthorisationCode);
	strBuf.append("&InfoType=");
	strBuf.append(strEmpDetailsToken);

	log.debug("GDIR for EMP Detail ==> " + strBuf.toString());

	strReturn = (String) invokeGDIR(strBuf.toString(), 1);
	return strReturn;
    }

    /**
     * Gets the mgr email from geid.
     *
     * @param strMgrGEID the str mgr geid
     * @return the mgr email from geid
     * @throws Exception the exception
     */
    public String getMgrEmailFromGEID(String strMgrGEID) throws Exception{
	StringBuffer strBuf = new StringBuffer("");
	String strReturn = null;
	strBuf.append(strURI.replaceFirst("SOEID", "GEID"));
	strBuf.append(strMgrGEID);
	strBuf.append("&AUID=");
	strBuf.append(strAuthorisationCode);
	strBuf.append("&InfoType=");
	strBuf.append(strMgrDetailsToken);

	log.debug("GDIR for Manager Detail ==> " + strBuf.toString());
	try{
	    strReturn = (String) invokeGDIR(strBuf.toString(), 3);
	} catch (Exception ex){
	    log.error("Exception in getMgrEmailFromGEID::"+ex.getMessage());
	    ex.printStackTrace();
	}
	return strReturn;
    }

    /**
     * Gets the mgr email from so eid.
     *
     * @param strSoeId the str soe id
     * @return the mgr email from so eid
     * @throws Exception the exception
     */
    public String getMgrEmailFromSOEid(String strSoeId) throws Exception{
	String strReturn = null;
	String mgrGEID = getManagerGEID(strSoeId);
	if(mgrGEID != null)
	    strReturn = getMgrEmailFromGEID(mgrGEID.trim());
	return strReturn;
    }

    /**
     * Gets the email from soe.
     *
     * @param strSOEId the str soe id
     * @return the email from soe
     */
    public String getEmailFromSOE(String strSOEId){
	return null;
    }

    /**
     * Gets the checks if is employee.
     *
     * @param strSOEId the str soe id
     * @return the checks if is employee
     */
    public boolean getIsEmployee(String strSOEId){
	boolean isEmployee = false;
	List mgrList = new ArrayList();

	try {
	    mgrList = getManagerialHierarchy(strSOEId);

	    if (mgrList != null && mgrList.size() > 0) {
		isEmployee = true;
	    }
	} catch (Exception e) {
	    log.error(e);
	    return isEmployee;
	}
	return isEmployee;
    }

    /**
     * Invoke gdir.
     *
     * @param uri the uri
     * @param iIndicator the i indicator
     * @return the string
     * @throws Exception the exception
     */
    private String invokeGDIR(String uri, int iIndicator) throws Exception{
	URL gdir = new URL(uri);
	String inputLine = null;
	String strReader = null;
	DocumentBuilderFactory factory = null;
	DocumentBuilder builder = null;
	Document document = null;
	String strOutputGEId = null;
	String strMgrList = null;
	String strMgrEmail = null;
	StringBuffer strBuf = new StringBuffer("");
	NodeList nodes = null;
	URLConnection yc = gdir.openConnection();
	BufferedReader in = new BufferedReader(new InputStreamReader(yc
		.getInputStream()));

	while ((inputLine = in.readLine()) != null) {
	    strBuf.append(inputLine);
	    inputLine = null;
	}
	in.close();

	// To solve the parsing issue. XML with this tag is not getting loaded in DOM
	strReader = strBuf.toString().substring(strBuf.toString().indexOf("<?xml"));
	strReader = strReader.trim();
	//strReader = URLEncoder.encode(strReader, "UTF-8");
	//strReader = URLDecoder.decode(strReader, "UTF-8");
	factory = DocumentBuilderFactory.newInstance();
	builder = factory.newDocumentBuilder();
	document = builder.parse(new InputSource(new StringReader(strReader)));

	switch (iIndicator) {
	case 1:
	    nodes = document.getElementsByTagName(strGEID);
	    strOutputGEId = nodes.item(0).getFirstChild().getNodeValue();
	    return strOutputGEId;
	case 2:
	    nodes = document.getElementsByTagName(strPBH);
	    strMgrList = nodes.item(0).getFirstChild().getNodeValue();
	    return strMgrList;
	case 3:
	    nodes = document.getElementsByTagName(strEmailAddress);
	    strMgrEmail = nodes.item(0).getFirstChild().getNodeValue();
	    return strMgrEmail;
	default:
	    log.debug("GDIR not invoked, indicator wrong ==> " + iIndicator);
	}

	return null;
    }

    /**
     * Checks if is manager.
     *
     * @param userId the user id
     * @param mgrId the mgr id
     * @return true, if is manager
     */
    public boolean isManager(String userId, String mgrId){
	boolean bIsManager = false;
	String strMgrGEId = null;
	List mgrList = new ArrayList();
	String strEntry = null;

	if(userId == null || mgrId==null){
	    return bIsManager;
	}else{
	    userId = userId.toUpperCase();
	    mgrId = mgrId.toUpperCase();
	}

	try {
	    mgrList = getManagerialHierarchy(userId);
	    strMgrGEId = getGEIdFromSOEId(mgrId);

	    // Contains method is not working because of issue with each
	    // entry containing spaces
	    for (int iCount = 0; iCount < mgrList.size(); iCount++) {
		strEntry = (String) mgrList.get(iCount);
		if (strEntry != null
			&& strEntry.trim().equals(strMgrGEId.trim())) {
		    bIsManager = true;
		    break;
		}
	    }
	} catch (Exception e) {
	    log.error(e, e);
	}
	return bIsManager;
    }

}