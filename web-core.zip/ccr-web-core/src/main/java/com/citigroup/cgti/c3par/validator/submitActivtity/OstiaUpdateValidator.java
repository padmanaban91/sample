package com.citigroup.cgti.c3par.validator.submitActivtity;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;

import com.citigroup.cgti.c3par.comments.domain.SubmitActivityErrors;


public class OstiaUpdateValidator implements Validator{
	
	 /** The log. */
    private static Logger log = Logger.getLogger(OstiaUpdateValidator.class);

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub
		
	}

	
	 private JdbcTemplate jdbcTemplate;


	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	 
	 /**
     * Gets the ostia update message.
     *
     * @param tiReqId the ti req id
     * @return the ostia update message
     */
    public List<ObjectError> getOstiaUpdateMessage(Long tiReqId){
	List<ObjectError> msgList=new ArrayList<ObjectError>();

	//Modified for the Prod Defect 42972 -  Ostia Update screen referring old screen By NE36745 - Starts
	try{
		//The Ostia complete check for IP Registration in Ostia Update Reconsile mode.
		ObjectError ostiaErrMsg = ostiaCompleteCheckForTA(tiReqId, "IpReg");
		if (ostiaErrMsg!=null && !ostiaErrMsg.equals("")) {			   
			msgList.add(ostiaErrMsg);
		}
		//The Ostia complete check for Firewall in Ostia Update Reconsile mode.
		ostiaErrMsg = ostiaCompleteCheckForTA(tiReqId, "firewall");
		if (ostiaErrMsg!=null && !ostiaErrMsg.equals("")) {			   
			msgList.add(ostiaErrMsg);
		}
	//Modified for the Prod Defect 42972 -  Ostia Update screen referring old screen By NE36745 - Ends
		
	    /**Relationship Certification Confirmation**/
	    List<ObjectError> certifyErrorMsg=getCertifyErrorMsg(tiReqId);
	    if(certifyErrorMsg.size()>0){
		for(int i=0;i<certifyErrorMsg.size();i++){	
		    msgList.addAll(certifyErrorMsg);
		}
	    }



	}catch(Exception ex){
	    ex.printStackTrace();
	}
	return msgList;
    }

	 /**
     * Gets the ostia error message.
     *
     * @param tiReqId the ti req id
     * @return error message for Ostia Tab in RECONCILE Mode
     */
    public List<ObjectError> getOstiaErrorMessage(Long tiReqId){
	log.debug("getOstiaErrorMessage START::");
	StringBuffer ostiaSQL=new StringBuffer();
	List<ObjectError> messageList=new ArrayList<ObjectError>();
	try{
	    ostiaSQL.append("SELECT 1 FROM C3PAR.con_ip_pair_xref a,C3PAR.con_port_xref b,C3PAR.con_riskport_ostia c, C3PAR.con_ostia_group d,C3PAR.TI_REQUEST e,C3PAR.GENERIC_LOOKUP f,C3PAR.TI_PROCESS g");
	    ostiaSQL.append(" WHERE a.id = b.ip_pair_xref_id AND b.port_id = c.port_id AND  e.ID= ");
	    ostiaSQL.append(tiReqId+" and e.PRIORITY_ID=f.ID and f.VALUE1  in ('BUSCRIT','EMER') ");
	    ostiaSQL.append(" and a.connection_request_id = e.PROCESS_ID AND g.ID=e.PROCESS_ID AND g.PROCESS_ACTIVITY_MODE in('RECONCILE') and");
	    ostiaSQL.append(" d.id(+) = c.GROUP_ID AND (d.status IS NULL OR d.status ='Incomplete')");
	    log.debug("(getOstiaErrorMessage)ostiaSQL::::::"+ostiaSQL.toString());
	    
	    SqlRowSet result  = jdbcTemplate.queryForRowSet(ostiaSQL.toString());
	    
	    if(result.next()){
	    messageList.add(new ObjectError("OSTIAERROR",new String[]{SubmitActivityErrors.OS_OSTIAERROR},null,null));
	    }
	}catch (Exception e) {
	    log.error(e,e);
	}
	log.debug("getOstiaErrorMessage END::");
	return messageList;
    }


    /**
     * Gets the certify error msg.
     *
     * @param tiReqId the ti req id
     * @return the certify error msg
     */
    private List<ObjectError> getCertifyErrorMsg(Long tiReqId){
	log.debug("getCertifyErrorMsg START::");
	StringBuffer certifySQL=new StringBuffer();
	List<ObjectError> messageList=new ArrayList<ObjectError>();
	try{
	    certifySQL.append(" SELECT 1 FROM C3PAR.TI_REQUEST A,C3PAR.TI_PROCESS B,C3PAR.RELATIONSHIP C,C3PAR.GENERIC_LOOKUP D WHERE");
	    certifySQL.append(" A.ID="+tiReqId+" AND B.ID=A.PROCESS_ID AND B.RELATIONSHIP_ID=C.ID AND D.ID=A.PRIORITY_ID AND D.VALUE1 IN('BUSCRIT','EMER') AND ");
	    certifySQL.append(" B.PROCESS_ACTIVITY_MODE IN ('RECONCILE') AND C.STATUS='NOT CERTIFIED'");

	    log.info("(getCertifyErrorMsg)certifySQL::::::"+certifySQL.toString());	
	    
	    SqlRowSet result  = jdbcTemplate.queryForRowSet(certifySQL.toString());
	    
	    if(result.next()){
	    messageList.add(new ObjectError("CERTIFICATION",new String[]{SubmitActivityErrors.OS_CERTIFICATION},null,null));
	    }
	    log.info("messageList Size::"+messageList.size());	
	}catch (Exception e) {
	    log.error(e,e);
	}
	log.debug("getCertifyErrorMsg END::");
	return messageList;
    }

    private ObjectError ostiaCompleteCheckForTA(Long tiReqId,String conType) {
		log.info("TechnialArchitectureValidator.ostiaCompleteCheck() " + tiReqId);
		ObjectError message = null;
		String isIp = "";
		if(conType.equalsIgnoreCase("IpReg"))
		{
			isIp = "rule.IS_IPREG='Y'";
		}
		else
		{
			isIp = "(rule.IS_IPREG!='Y' or rule.IS_IPREG is null)";
		}
    	try{
		String sql ="select q.id from con_fw_rule_questionnaire q,con_fw_rule rule, ti_request t "+
		"where q.updated_ti_request_id=t.id and rule.id=q.fw_rule_id and q.deleted_ti_request_id is null and q.fw_rule_id is not null and t.id=? and q.status='Incomplete' "+ 
		" and "
		+ isIp ;
		
		SqlRowSet result  = jdbcTemplate.queryForRowSet(sql,new Object[]{tiReqId});
		    log.debug("result is::" + result);
		    if (result != null && result.next()) {
		    	if(conType.equalsIgnoreCase("IpReg"))
				{
		    		message = new ObjectError("OSTIA_COMPLETE_IPReg",new String[]{SubmitActivityErrors.OS_OSTIA_COMPLETE_IPReg},null,null);
				    log.debug(" ostiaCompleteCheck message is::" + message);
				} else {
					message = new ObjectError("OSTIA_COMPLETE",new String[]{SubmitActivityErrors.OS_OSTIA_COMPLETE},null,null);
					    log.debug(" ostiaCompleteCheck message is::" + message);
				}
			
		    }
	
	} catch (Exception e) {
	    log.error(e,e);
	} 
		log.info("TechnialArchitectureValidator.ostiaCompleteCheck() ends " + message);
		return message;
	}
}
