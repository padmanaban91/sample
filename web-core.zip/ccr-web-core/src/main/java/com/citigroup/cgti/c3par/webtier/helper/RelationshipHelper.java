package com.citigroup.cgti.c3par.webtier.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.HierarchyDTO;
import com.citigroup.cgti.c3par.dao.ConnectionDAO;
import com.citigroup.cgti.c3par.dao.PlanningDAO;
import com.citigroup.cgti.c3par.dao.RelationshipCitiContactXrefDAO;
import com.citigroup.cgti.c3par.dao.RelationshipCitiLocationXrefDAO;
import com.citigroup.cgti.c3par.dao.RelationshipCitiResourceXrefDAO;
import com.citigroup.cgti.c3par.dao.RelationshipDAO;
import com.citigroup.cgti.c3par.dao.RelationshipTPContactXrefDAO;
import com.citigroup.cgti.c3par.dao.RelationshipTPLocationXrefDAO;
import com.citigroup.cgti.c3par.dao.ResourceTypeDAO;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.model.BusinessUnitEntity;
import com.citigroup.cgti.c3par.model.EntitlementInstanceEntity;
import com.citigroup.cgti.c3par.model.RelationshipCitiContactXrefEntity;
import com.citigroup.cgti.c3par.model.RelationshipCitiLocationXrefEntity;
import com.citigroup.cgti.c3par.model.RelationshipCitiResourceXrefEntity;
import com.citigroup.cgti.c3par.model.RelationshipEntity;
import com.citigroup.cgti.c3par.model.RelationshipTPContactXrefEntity;
import com.citigroup.cgti.c3par.model.RelationshipTPLocationXrefEntity;
import com.citigroup.cgti.c3par.model.ResourceTypeEntity;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;
import com.citigroup.cgti.c3par.soa.wfpprofile.PartnersSiteListType;
import com.citigroup.cgti.c3par.webtier.helper.entity.ThirdPartyManager;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Expression;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;


/**
 * The Class RelationshipHelper.
 */
public class RelationshipHelper
{

    /** The Constant REGION. */
    public static final String REGION="Region";

    /** The Constant SECTOR. */
    public static final String SECTOR="Sector";

    /** The Constant BUSINESS_UNIT. */
    public static final String BUSINESS_UNIT = "BusinessUnit";

    /** The log. */
    private static Logger log = Logger.getLogger(RelationshipHelper.class);

    //========================================================================
    /**
     * Gets the all.
     *
     * @param db_session the db_session
     * @return the all
     * @throws DatabaseException the database exception
     */
    static public List getAll(C3parSession db_session) throws DatabaseException
    {
	if(db_session == null)
	{
	    db_session = new C3parSession();
	}

	RelationshipDAO dao = new RelationshipDAO(db_session);
	Condition condition = new Condition();
	condition.addOrderByField(RelationshipDAO.COLUMN_NAME);
	List list = dao.query(condition, false);
	return list;
    }

    //========================================================================
    /* ENTITLEMENT change groupname to instanceid*/
    /**
     * Sets the business unit.
     *
     * @param db_session the db_session
     * @param relationship_id the relationship_id
     * @param bu_id the bu_id
     * @throws DatabaseException the database exception
     */
    static public void setBusinessUnit(C3parSession db_session, Long relationship_id, Long bu_id) throws DatabaseException
    {
	try
	{
	    RelationshipDAO dao = new RelationshipDAO(db_session);
	    RelationshipEntity entity = dao.get(relationship_id);
	    removeAllCitiContacts(db_session, entity);
	    removeAllCitiLocations(db_session, entity);
	    //removeBusinessUnit(db_session, entity);
	   // entity.setBusinessUnit(BusinessUnitManager.get(bu_id, db_session));
	    dao.update(entity, db_session.getArchiver());
	    /*Long ownedById = entity.getOwnedbyId();
			EntitlementXrefDAO entitlementDAO = new EntitlementXrefDAO(db_session);
			EntitlementXrefEntity entitlementEntity = entitlementDAO.get(ownedById); */
	   // SaveRelationshipAction.informAllNodesAndValidateCache(entity, "update", entity.getEntInstanceId().toString());
	}
	/*catch(ChannelClosedException ex)
	{
	    throw new DatabaseException(ex.getMessage(), ex);
	}*/
	catch(Exception ex)
	{
	    throw new DatabaseException(ex.getMessage(), ex);
	}
    }

    //========================================================================
    /**
     * Removes the business unit.
     *
     * @param db_session the db_session
     * @param relationship_id the relationship_id
     * @throws DatabaseException the database exception
     */
    static public void removeBusinessUnit(C3parSession db_session, Long relationship_id) throws DatabaseException
    {
	RelationshipDAO dao = new RelationshipDAO(db_session);
	RelationshipEntity entity = dao.get(relationship_id);
	removeBusinessUnit(db_session, entity);
    }

    //========================================================================
    /**
     * Removes the business unit.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @throws DatabaseException the database exception
     */
    static public void removeBusinessUnit(C3parSession db_session, RelationshipEntity relationship) throws DatabaseException
    {
	RelationshipDAO dao = new RelationshipDAO(db_session);
	removeAllCitiContacts(db_session, relationship);
	removeAllCitiLocations(db_session, relationship);
	//relationship.setBusinessUnit(null);
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Sets the third party.
     *
     * @param db_session the db_session
     * @param relationship_id the relationship_id
     * @param tp_id the tp_id
     * @throws DatabaseException the database exception
     */
    static public void setThirdParty(C3parSession db_session, Long relationship_id, Long tp_id) throws DatabaseException
    {
	try
	{
	    RelationshipDAO dao = new RelationshipDAO(db_session);
	    RelationshipEntity entity = dao.get(relationship_id);
	    removeAllThirdPartyContacts(db_session, entity);
	    removeAllThirdPartyLocations(db_session, entity);
	    //removeThirdParty(db_session, entity);
	    entity.setThirdParty(ThirdPartyManager.get(tp_id, db_session));
	    dao.update(entity, db_session.getArchiver());
	    /* ENTITLEMENT change groupname to sectorname*/
	    /*Long ownedById = entity.getOwnedbyId();
			EntitlementXrefDAO entitlementDAO = new EntitlementXrefDAO(db_session);
			EntitlementXrefEntity entitlementEntity = entitlementDAO.get(ownedById); */
	    //SaveRelationshipAction.informAllNodesAndValidateCache(entity, "update", entity.getEntInstanceId().toString());
	}
	/*catch(ChannelClosedException ex)
	{
	    throw new DatabaseException(ex.getMessage(), ex);
	}*/
	catch(Exception ex)
	{
	    throw new DatabaseException(ex.getMessage(), ex);
	}
    }

    //========================================================================
    /**
     * Removes the third party.
     *
     * @param db_session the db_session
     * @param relationship_id the relationship_id
     * @throws DatabaseException the database exception
     */
    static public void removeThirdParty(C3parSession db_session, Long relationship_id) throws DatabaseException
    {
	RelationshipDAO dao = new RelationshipDAO(db_session);
	RelationshipEntity entity = dao.get(relationship_id);
	removeThirdParty(db_session, entity);
    }

    //========================================================================
    /**
     * Removes the third party.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @throws DatabaseException the database exception
     */
    static public void removeThirdParty(C3parSession db_session, RelationshipEntity relationship) throws DatabaseException
    {
	RelationshipDAO dao = new RelationshipDAO(db_session);
	removeAllThirdPartyContacts(db_session, relationship);
	removeAllThirdPartyLocations(db_session, relationship);
	relationship.setThirdParty(null);
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Removes the third party contact.
     *
     * @param db_session the db_session
     * @param relationship_id the relationship_id
     * @param contact_id the contact_id
     * @throws DatabaseException the database exception
     */
    static public void removeThirdPartyContact(C3parSession db_session, Long relationship_id, Long contact_id) throws DatabaseException
    {
	RelationshipDAO dao = new RelationshipDAO(db_session);
	RelationshipEntity entity = dao.get(relationship_id);
	removeThirdPartyContact(db_session, entity, contact_id);
    }

    //========================================================================
    /**
     * Removes the third party contact.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @param contact_id the contact_id
     * @throws DatabaseException the database exception
     */
    static public void removeThirdPartyContact(C3parSession db_session, RelationshipEntity relationship, Long contact_id) throws DatabaseException
    {
	log.debug("remove third party contact. id = " + contact_id.toString());

	RelationshipTPContactXrefDAO xref_dao = new RelationshipTPContactXrefDAO(db_session);
	RelationshipDAO dao = new RelationshipDAO(db_session);

	List xrefs = relationship.getThirdPartyContact();
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipTPContactXrefEntity xref = (RelationshipTPContactXrefEntity)iter.next();
	    log.debug("relationship contact id = " + xref.getTpContactId().toString());
	    if(xref.getTpContactId().equals(contact_id))
	    {
		iter.remove();
		xref_dao.delete(xref, db_session.getArchiver());
	    }
	}
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Removes the all third party contacts.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @throws DatabaseException the database exception
     */
    static public void removeAllThirdPartyContacts(C3parSession db_session, RelationshipEntity relationship) throws DatabaseException
    {
	RelationshipTPContactXrefDAO xref_dao = new RelationshipTPContactXrefDAO(db_session);
	RelationshipDAO dao = new RelationshipDAO(db_session);

	List xrefs = relationship.getThirdPartyContact();
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipTPContactXrefEntity xref = (RelationshipTPContactXrefEntity)iter.next();
	    xref_dao.delete(xref, db_session.getArchiver());
	}
	relationship.getThirdPartyContact().clear();
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Removes the resource.
     *
     * @param db_session the db_session
     * @param relationship_id the relationship_id
     * @param resource_id the resource_id
     * @throws DatabaseException the database exception
     */
    static public void removeResource(C3parSession db_session, Long relationship_id, Long resource_id) throws DatabaseException
    {
	RelationshipDAO dao = new RelationshipDAO(db_session);
	RelationshipEntity entity = dao.get(relationship_id);
	removeResource(db_session, entity, resource_id);
    }

    //========================================================================
    /**
     * Removes the resource.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @param resource_id the resource_id
     * @throws DatabaseException the database exception
     */
    static public void removeResource(C3parSession db_session, RelationshipEntity relationship, Long resource_id) throws DatabaseException
    {
	log.debug("remove resource. id = " + resource_id.toString());

	RelationshipCitiResourceXrefDAO xref_dao = new RelationshipCitiResourceXrefDAO(db_session);
	RelationshipDAO dao = new RelationshipDAO(db_session);

	List xrefs = relationship.getResource();
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipCitiResourceXrefEntity xref = (RelationshipCitiResourceXrefEntity)iter.next();
	    log.debug("relationship resource id = " + xref.getResourceId().toString());
	    if(xref.getResourceId().equals(resource_id))
	    {
		iter.remove();
		xref_dao.delete(xref, db_session.getArchiver());
	    }
	}
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Removes the third party location.
     *
     * @param db_session the db_session
     * @param relationship_id the relationship_id
     * @param location_id the location_id
     * @throws DatabaseException the database exception
     */
    static public void removeThirdPartyLocation(C3parSession db_session, Long relationship_id, Long location_id) throws DatabaseException
    {
	RelationshipDAO dao = new RelationshipDAO(db_session);
	RelationshipEntity entity = dao.get(relationship_id);
	removeThirdPartyLocation(db_session, entity, location_id);
    }

    //========================================================================
    /**
     * Removes the third party location.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @param location_id the location_id
     * @throws DatabaseException the database exception
     */
    static public void removeThirdPartyLocation(C3parSession db_session, RelationshipEntity relationship, Long location_id) throws DatabaseException
    {
	RelationshipTPLocationXrefDAO xref_dao = new RelationshipTPLocationXrefDAO(db_session);
	RelationshipDAO dao = new RelationshipDAO(db_session);

	List xrefs = relationship.getThirdPartyLocation();
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipTPLocationXrefEntity xref = (RelationshipTPLocationXrefEntity)iter.next();
	    if(xref.getLocationId().equals(location_id))
	    {
		iter.remove();
		xref_dao.delete(xref, db_session.getArchiver());
	    }
	}
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Removes the all third party locations.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @throws DatabaseException the database exception
     */
    static public void removeAllThirdPartyLocations(C3parSession db_session, RelationshipEntity relationship) throws DatabaseException
    {
	RelationshipTPLocationXrefDAO xref_dao = new RelationshipTPLocationXrefDAO(db_session);
	RelationshipDAO dao = new RelationshipDAO(db_session);

	List xrefs = relationship.getThirdPartyLocation();
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipTPLocationXrefEntity xref = (RelationshipTPLocationXrefEntity)iter.next();
	    xref_dao.delete(xref, db_session.getArchiver());
	}
	relationship.getThirdPartyLocation().clear();
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Removes the citi contact.
     *
     * @param db_session the db_session
     * @param relationship_id the relationship_id
     * @param contact_id the contact_id
     * @throws DatabaseException the database exception
     */
    static public void removeCitiContact(C3parSession db_session, Long relationship_id, Long contact_id) throws DatabaseException
    {
	RelationshipDAO dao = new RelationshipDAO(db_session);
	RelationshipEntity entity = dao.get(relationship_id);
	removeCitiContact(db_session, entity, contact_id);
    }

    //========================================================================
    /**
     * Removes the citi contact.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @param contact_id the contact_id
     * @throws DatabaseException the database exception
     */
    static public void removeCitiContact(C3parSession db_session, RelationshipEntity relationship, Long contact_id) throws DatabaseException
    {
	log.debug("remove citi contact. id = " + contact_id.toString());

	RelationshipCitiContactXrefDAO xref_dao = new RelationshipCitiContactXrefDAO(db_session);
	RelationshipDAO dao = new RelationshipDAO(db_session);

	List xrefs = relationship.getCitiContact();
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipCitiContactXrefEntity xref = (RelationshipCitiContactXrefEntity)iter.next();
	    log.debug("relationship contact id = " + xref.getContactId().toString());
	    if(xref.getContactId().equals(contact_id))
	    {
		iter.remove();
		xref_dao.delete(xref, db_session.getArchiver());
	    }
	}
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Removes the all citi contacts.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @throws DatabaseException the database exception
     */
    static public void removeAllCitiContacts(C3parSession db_session, RelationshipEntity relationship) throws DatabaseException
    {
	RelationshipCitiContactXrefDAO xref_dao = new RelationshipCitiContactXrefDAO(db_session);
	RelationshipDAO dao = new RelationshipDAO(db_session);

	List xrefs = relationship.getCitiContact();
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipCitiContactXrefEntity xref = (RelationshipCitiContactXrefEntity)iter.next();
	    xref_dao.delete(xref, db_session.getArchiver());
	}
	relationship.getCitiContact().clear();
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Removes the citi location.
     *
     * @param db_session the db_session
     * @param relationship_id the relationship_id
     * @param location_id the location_id
     * @throws DatabaseException the database exception
     */
    static public void removeCitiLocation(C3parSession db_session, Long relationship_id, Long location_id) throws DatabaseException
    {
	RelationshipDAO dao = new RelationshipDAO(db_session);
	RelationshipEntity entity = dao.get(relationship_id);
	removeCitiLocation(db_session, entity, location_id);
    }

    //========================================================================
    /**
     * Removes the citi location.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @param location_id the location_id
     * @throws DatabaseException the database exception
     */
    static public void removeCitiLocation(C3parSession db_session, RelationshipEntity relationship, Long location_id) throws DatabaseException
    {
	RelationshipCitiLocationXrefDAO xref_dao = new RelationshipCitiLocationXrefDAO(db_session);
	RelationshipDAO dao = new RelationshipDAO(db_session);

	List xrefs = relationship.getCitiLocation();
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipCitiLocationXrefEntity xref = (RelationshipCitiLocationXrefEntity)iter.next();
	    if(xref.getLocationId().equals(location_id))
	    {
		iter.remove();
		xref_dao.delete(xref, db_session.getArchiver());
	    }
	}
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Removes the all citi locations.
     *
     * @param db_session the db_session
     * @param relationship the relationship
     * @throws DatabaseException the database exception
     */
    static public void removeAllCitiLocations(C3parSession db_session, RelationshipEntity relationship) throws DatabaseException
    {
	RelationshipCitiLocationXrefDAO xref_dao = new RelationshipCitiLocationXrefDAO(db_session);
	RelationshipDAO dao = new RelationshipDAO(db_session);

	List xrefs = relationship.getCitiLocation();
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipCitiLocationXrefEntity xref = (RelationshipCitiLocationXrefEntity)iter.next();
	    xref_dao.delete(xref, db_session.getArchiver());
	}
	relationship.getCitiLocation().clear();
	dao.update(relationship, db_session.getArchiver());
    }

    //========================================================================
    /**
     * Gets the relationships by third party.
     *
     * @param db_session the db_session
     * @param tp_id the tp_id
     * @return the relationships by third party
     * @throws DatabaseException the database exception
     */
    static public List getRelationshipsByThirdParty(C3parSession db_session, String tp_id) throws DatabaseException
    {
	if(db_session == null)
	{
	    db_session = new C3parSession();
	}

	RelationshipDAO dao = new RelationshipDAO(db_session);
	Condition condition = new Condition(true);
	Expression expr = new OperatorExpression(RelationshipDAO.COLUMN_THIRDPARTY_ID, Operator.EQUAL, tp_id);
	condition.addExpression(expr);
	//		expr = new OperatorExpression(RelationshipDAO.COLUMN_DELETED, Operator.NOT_EQUAL, "Y");
	//		condition.addExpression(expr);

	List rels = dao.query(condition, false);
	return rels;
    }

    //========================================================================
    /**
     * Find relationship by third party.
     *
     * @param db_session the db_session
     * @param tp_id the tp_id
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findRelationshipByThirdParty(C3parSession db_session, String tp_id) throws DatabaseException
    {
	/*
		if(db_session == null)
		{
			db_session = new C3parSession();
		}

		RelationshipDAO dao = new RelationshipDAO(db_session);
		Condition condition = new Condition(true);
		Expression expr = new OperatorExpression(RelationshipDAO.COLUMN_THIRDPARTY_ID, Operator.EQUAL, tp_id);
		condition.addExpression(expr);
//		expr = new OperatorExpression(RelationshipDAO.COLUMN_DELETED, Operator.NOT_EQUAL, "Y");
//		condition.addExpression(expr);

		List rels = dao.query(condition, false);
	 */
	List rels = getRelationshipsByThirdParty(db_session, tp_id);
	List result = new ArrayList(rels.size());
	Iterator iter = rels.iterator();
	while(iter.hasNext())
	{
	    RelationshipEntity rel = (RelationshipEntity)iter.next();
	    result.add(rel.getId());
	}

	log.debug("Third Party ID = " + tp_id + ", Result size = " + result.size());

	return result;
    }

    //========================================================================
    /**
     * Find relationship by third party contact.
     *
     * @param db_session the db_session
     * @param contact_id the contact_id
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findRelationshipByThirdPartyContact(C3parSession db_session, String contact_id) throws DatabaseException
    {
	if(db_session == null)
	{
	    db_session = new C3parSession();
	}

	RelationshipTPContactXrefDAO dao = new RelationshipTPContactXrefDAO(db_session);
	Condition condition = new Condition(true);
	Expression expr = new OperatorExpression(RelationshipTPContactXrefDAO.COLUMN_TPCONTACT_ID, Operator.EQUAL, contact_id);
	condition.addExpression(expr);
	//		expr = new OperatorExpression(RelationshipDAO.COLUMN_DELETED, Operator.NOT_EQUAL, "Y");
	//		condition.addExpression(expr);

	List xrefs = dao.query(condition, false);
	List result = new ArrayList(xrefs.size());
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipTPContactXrefEntity xref = (RelationshipTPContactXrefEntity)iter.next();
	    result.add(xref.getRelationshipId());
	}

	log.debug("Contact ID = " + contact_id + ", Result size = " + result.size());
	return result;
    }

    //========================================================================
    /**
     * Find relationship by third party location.
     *
     * @param db_session the db_session
     * @param location_id the location_id
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findRelationshipByThirdPartyLocation(C3parSession db_session, String location_id) throws DatabaseException
    {
	if(db_session == null)
	{
	    db_session = new C3parSession();
	}

	RelationshipTPLocationXrefDAO dao = new RelationshipTPLocationXrefDAO(db_session);
	Condition condition = new Condition(true);
	Expression expr = new OperatorExpression(RelationshipTPLocationXrefDAO.COLUMN_LOCATION_ID, Operator.EQUAL, location_id);
	condition.addExpression(expr);
	//		expr = new OperatorExpression(RelationshipDAO.COLUMN_DELETED, Operator.NOT_EQUAL, "Y");
	//		condition.addExpression(expr);

	List xrefs = dao.query(condition, false);
	List result = new ArrayList(xrefs.size());
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipTPLocationXrefEntity xref = (RelationshipTPLocationXrefEntity)iter.next();
	    result.add(xref.getRelationshipId());
	}

	log.debug("Location ID = " + location_id + ", Result size = " + result.size());
	return result;
    }

    //========================================================================
    /**
     * Gets the relationships by citi business unit.
     *
     * @param db_session the db_session
     * @param bu_id the bu_id
     * @return the relationships by citi business unit
     * @throws DatabaseException the database exception
     */
    static public List getRelationshipsByCitiBusinessUnit(C3parSession db_session, String bu_id) throws DatabaseException
    {
	if(db_session == null)
	{
	    db_session = new C3parSession();
	}

	RelationshipDAO dao = new RelationshipDAO(db_session);
	Condition condition = new Condition(true);
	Expression expr = new OperatorExpression(RelationshipDAO.COLUMN_BUSINESSUNIT_ID, Operator.EQUAL, bu_id);
	condition.addExpression(expr);

	List rels = dao.query(condition, false);
	return rels;
    }


    //========================================================================
    /**
     * Find relationship by citi business unit.
     *
     * @param db_session the db_session
     * @param bu_id the bu_id
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findRelationshipByCitiBusinessUnit(C3parSession db_session, String bu_id) throws DatabaseException
    {
	/*
		if(db_session == null)
		{
			db_session = new C3parSession();
		}

		RelationshipDAO dao = new RelationshipDAO(db_session);
		Condition condition = new Condition(true);
		Expression expr = new OperatorExpression(RelationshipDAO.COLUMN_BUSINESSUNIT_ID, Operator.EQUAL, bu_id);
		condition.addExpression(expr);
//		expr = new OperatorExpression(RelationshipDAO.COLUMN_DELETED, Operator.NOT_EQUAL, "Y");
//		condition.addExpression(expr);

		List rels = dao.query(condition, false);
	 */
	List rels = getRelationshipsByCitiBusinessUnit(db_session, bu_id);
	List result = new ArrayList(rels.size());
	Iterator iter = rels.iterator();
	while(iter.hasNext())
	{
	    RelationshipEntity rel = (RelationshipEntity)iter.next();
	    result.add(rel.getId());
	}

	log.debug("Business Unit ID = " + bu_id + ", Result size = " + result.size());

	return result;
    }

    //========================================================================
    /**
     * Find relationship by citi contact.
     *
     * @param db_session the db_session
     * @param contact_id the contact_id
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findRelationshipByCitiContact(C3parSession db_session, String contact_id) throws DatabaseException
    {
	if(db_session == null)
	{
	    db_session = new C3parSession();
	}

	RelationshipCitiContactXrefDAO dao = new RelationshipCitiContactXrefDAO(db_session);
	Condition condition = new Condition(true);
	Expression expr = new OperatorExpression(RelationshipCitiContactXrefDAO.COLUMN_CONTACT_ID, Operator.EQUAL, contact_id);
	condition.addExpression(expr);
	//		expr = new OperatorExpression(RelationshipDAO.COLUMN_DELETED, Operator.NOT_EQUAL, "Y");
	//		condition.addExpression(expr);

	List xrefs = dao.query(condition, false);
	List result = new ArrayList(xrefs.size());
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipCitiContactXrefEntity xref = (RelationshipCitiContactXrefEntity)iter.next();
	    result.add(xref.getRelationshipId());
	}

	log.debug("Contact ID = " + contact_id + ", Result size = " + result.size());
	return result;
    }

    //========================================================================
    /**
     * Find relationship by citi location.
     *
     * @param db_session the db_session
     * @param location_id the location_id
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findRelationshipByCitiLocation(C3parSession db_session, String location_id) throws DatabaseException
    {
	if(db_session == null)
	{
	    db_session = new C3parSession();
	}

	RelationshipCitiLocationXrefDAO dao = new RelationshipCitiLocationXrefDAO(db_session);
	Condition condition = new Condition(true);
	Expression expr = new OperatorExpression(RelationshipCitiLocationXrefDAO.COLUMN_LOCATION_ID, Operator.EQUAL, location_id);
	condition.addExpression(expr);
	//		expr = new OperatorExpression(RelationshipDAO.COLUMN_DELETED, Operator.NOT_EQUAL, "Y");
	//		condition.addExpression(expr);

	List xrefs = dao.query(condition, false);
	List result = new ArrayList(xrefs.size());
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipCitiLocationXrefEntity xref = (RelationshipCitiLocationXrefEntity)iter.next();
	    result.add(xref.getRelationshipId());
	}

	log.debug("Location ID = " + location_id + ", Result size = " + result.size());
	return result;
    }

    //========================================================================
    /**
     * Find relationship by citi resource.
     *
     * @param db_session the db_session
     * @param resource_id the resource_id
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findRelationshipByCitiResource(C3parSession db_session, String resource_id) throws DatabaseException
    {
	if(db_session == null)
	{
	    db_session = new C3parSession();
	}

	RelationshipCitiResourceXrefDAO dao = new RelationshipCitiResourceXrefDAO(db_session);
	Condition condition = new Condition(true);
	Expression expr = new OperatorExpression(RelationshipCitiResourceXrefDAO.COLUMN_RESOURCE_ID, Operator.EQUAL, resource_id);
	condition.addExpression(expr);
	//		expr = new OperatorExpression(RelationshipDAO.COLUMN_DELETED, Operator.NOT_EQUAL, "Y");
	//		condition.addExpression(expr);

	List xrefs = dao.query(condition, false);
	List result = new ArrayList(xrefs.size());
	Iterator iter = xrefs.iterator();
	while(iter.hasNext())
	{
	    RelationshipCitiResourceXrefEntity xref = (RelationshipCitiResourceXrefEntity)iter.next();
	    result.add(xref.getRelationshipId());
	}

	log.debug("Resource ID = " + resource_id + ", Result size = " + result.size());
	return result;
    }

    /**
     * Relationship in planning.
     *
     * @param relationshipId the relationship id
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    public static boolean relationshipInPlanning(Long relationshipId)
    throws DatabaseException
    {
	PlanningDAO planningDAO = new PlanningDAO(new C3parSession());
	Condition condition = new Condition();
	OperatorExpression activeExp = new OperatorExpression(PlanningDAO.COLUMN_STATUS,Operator.NOT_EQUAL,C3parStatusLookupNames.ACTIVE);
	condition.addExpression(activeExp);
	OperatorExpression inactiveExp = new OperatorExpression(PlanningDAO.COLUMN_STATUS,Operator.NOT_EQUAL,C3parStatusLookupNames.IN_ACTIVE);
	condition.addExpression(inactiveExp);
	OperatorExpression relationshipIdExp = new OperatorExpression(PlanningDAO.COLUMN_RELATIONSHIP_ID,Operator.EQUAL,relationshipId);
	condition.addExpression(relationshipIdExp);
	List entityList = planningDAO.query(condition, false);

	if(entityList != null && entityList.size() > 0)
	    return true;
	else
	    return false;
    }

    /**
     * Relationship in connection.
     *
     * @param relationshipId the relationship id
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    public static boolean relationshipInConnection(Long relationshipId)
    throws DatabaseException
    {
	ConnectionDAO connectionDAO = new ConnectionDAO(new C3parSession());
	Condition condition = new Condition();
	OperatorExpression relationshipIdExp = new OperatorExpression(ConnectionDAO.COLUMN_RELATIONSHIP_ID,Operator.EQUAL,relationshipId);
	condition.addExpression(relationshipIdExp);
	List entityList = connectionDAO.query(condition, false);

	if(entityList != null && entityList.size() > 0)
	    return true;
	else
	    return false;
    }


    /**
     * Refresh tp location assesment id.
     *
     * @param relationshipEntity the relationship entity
     * @param user the user
     */
    public static void refreshTPLocationAssesmentId(RelationshipEntity relationshipEntity, String user){
	RelationshipDAO relDao = new RelationshipDAO(new C3parSession()); 
	try{
	    SOADataComponent soaDataComponent = new SOADataComponent();
	    ProfileInfoFactory profileInfoFactory = (ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");
	    List tpRelLocList = relationshipEntity.getThirdPartyLocation();
	    if (tpRelLocList != null) {

		Long caspId = null;
		Long detailId = null;
		Long siteDetailId = null;
		caspId = relationshipEntity.getThirdParty().getCaspId();
		detailId = relationshipEntity.getThirdParty().getDetailId();

		PartnersSiteListType siteDetails = profileInfoFactory.getCASPService().getPartnerSiteDetails(caspId.intValue(), user, detailId);

		for(int i=0;i<tpRelLocList.size() ;i++) {
		    RelationshipTPLocationXrefEntity xrefEntity = (RelationshipTPLocationXrefEntity) tpRelLocList.get(i);
		    siteDetailId =  xrefEntity.getLocation().getSiteDetailId() ;
		    for(int j=0;j<siteDetails.getSiteUtilizationList().getSiteUtilization().size();j++){
			if(siteDetailId !=null && siteDetails.getSiteUtilizationList().getSiteUtilization().get(j).getSiteDetailID()==siteDetailId.intValue()){
			    xrefEntity.getLocation().setAssesmentId((Integer.valueOf(siteDetails.getSiteUtilizationList().getSiteUtilization().get(j).getAssessments().getAssessmentID())).toString());
			    xrefEntity.getLocation().setAsessmentDesc(new String(siteDetails.getSiteUtilizationList().getSiteUtilization().get(j).getAssessments().getAssessmentStatusDesc()));
			    break;
			}
		    }
		}
		relDao.update(relationshipEntity);
	    }
	}catch(Exception e){
	    log.error(e);
	}		
    }

    /**
     * Gets the region list.
     *
     * @param c3parSession the c3par session
     * @param entitlementList the entitlement list
     * @return the region list
     */
    public static List getRegionList(C3parSession c3parSession, List entitlementList) {
	List objList = new ArrayList();
	LookUpVO obj;
	Connection con;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	StringBuffer sql;
	StringBuffer entitlementIds = new StringBuffer();
	try {
	    if (entitlementList != null && entitlementList.size() > 0) {
		for (int i=0; i < entitlementList.size(); i++) {
		    EntitlementInstanceEntity entitlementEntity = (EntitlementInstanceEntity)entitlementList.get(i);
		    if (entitlementIds.length() <= 0) {
			entitlementIds.append(entitlementEntity.getId().toString());
		    } else {
			entitlementIds.append(","+entitlementEntity.getId().toString());
		    }
		}
	    }
	    sql = new StringBuffer("select distinct region.id,region.NAME from hierarchy_detail,hierarchy_parent_detail,region, ent_data " +
		    "where  region.IS_ACTIVE!='N' and hierarchy_detail.DATA_ID=region.ID AND hierarchy_detail.NODE_TYPE_ID=1 " +
	    "and hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID and region.id = ent_data.DATA  ");
	    if (entitlementIds.length() > 0) {
		sql.append(" and ent_data.ENTITLEMENT_INSTANCE_ID in ("+entitlementIds+")");
	    }
	    sql.append(" and ent_data.ENTITLEMENT_NODE_ID = 1 order by region.NAME ");
	    con = c3parSession.getConnection();
	    stmt = con.prepareStatement(sql.toString());
	    rs = stmt.executeQuery();
	    obj = new LookUpVO();
	    obj.setValue(0);
	    obj.setName("-- Select region --");
	    objList.add(obj);
	    if(rs!=null)
	    {
		while(rs.next())
		{
		    obj=new LookUpVO();

		    obj.setValue(rs.getLong(1));
		    obj.setName(rs.getString(2));
		    objList.add(obj);

		}
	    }
	}catch (Exception e) {
	    //
	} finally {
	    try {
		if (rs != null) rs.close();
		if (stmt != null) stmt.close();
		c3parSession.releaseConnection();
	    } catch (Exception e) {
		log.error(e);
	    }
	}
	return objList;
    }

    /**
     * Gets the sector list.
     *
     * @param c3parSession the c3par session
     * @param entitlementList the entitlement list
     * @param regionId the region id
     * @return the sector list
     */
    public static List getSectorList(C3parSession c3parSession, List entitlementList, Long regionId) {
	List objList = new ArrayList();
	LookUpVO obj;
	Connection con;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	StringBuffer sql;
	StringBuffer entitlementIds = new StringBuffer();
	try {
	    if (entitlementList != null && entitlementList.size() > 0) {
		for (int i=0; i < entitlementList.size(); i++) {
		    EntitlementInstanceEntity entitlementEntity = (EntitlementInstanceEntity)entitlementList.get(i);
		    if (entitlementIds.length() <= 0) {
			entitlementIds.append(entitlementEntity.getId().toString());
		    } else {
			entitlementIds.append(","+entitlementEntity.getId().toString());
		    }
		}
	    }
	    sql = new StringBuffer("select distinct sector.id,sector.NAME from hierarchy_detail,hierarchy_parent_detail,sector, ent_data " +
		    "where  sector.IS_ACTIVE!='N' and hierarchy_detail.DATA_ID=sector.ID AND hierarchy_detail.NODE_TYPE_ID=2 " +
		    "and hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID and hierarchy_parent_detail.PARENT_ID = (" +
		    "select hierarchy_detail.ID from  hierarchy_detail where  hierarchy_detail.NODE_TYPE_ID=1 " +
		    "and hierarchy_detail.DATA_ID=  "+regionId+") and sector.id = ent_data.DATA ");
	    if (entitlementIds.length() > 0) {
		sql.append(" and ent_data.ENTITLEMENT_INSTANCE_ID in ("+entitlementIds+")");
	    }
	    sql.append(" and ent_data.ENTITLEMENT_NODE_ID = 2 order by sector.NAME ");
	    con = c3parSession.getConnection();
	    stmt = con.prepareStatement(sql.toString());
	    rs = stmt.executeQuery();
	    obj = new LookUpVO();
	    obj.setValue(0);
	    obj.setName("-- Select sector --");
	    objList.add(obj);
	    if(rs!=null)
	    {
		while(rs.next())
		{
		    obj=new LookUpVO();

		    obj.setValue(rs.getLong(1));
		    obj.setName(rs.getString(2));
		    objList.add(obj);

		}
	    }
	}catch (Exception e) {
	    log.error(e);
	} finally {
	    try {
		if (rs != null) rs.close();
		if (stmt != null) stmt.close();
		c3parSession.releaseConnection();
	    } catch (Exception e) {
		log.error(e);
	    }
	}
	return objList;
    }

    /**
     * Gets the business unit list.
     *
     * @param c3parSession the c3par session
     * @param regionId the region id
     * @param sectorId the sector id
     * @return the business unit list
     */
    public static List getBusinessUnitList(C3parSession c3parSession, Long regionId, Long sectorId) {
	List objList = new ArrayList();
	Connection con;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	StringBuffer sql;
	log.debug("getBusinessUnitList");
	try {
		log.debug("getBusinessUnitList:Long regionId, Long sectorId :"+regionId+","+sectorId);
	   /* sql=new StringBuffer("select business_unit.id,business_unit.BUSINESS_NAME  from ");
	    sql.append("hierarchy_detail,hierarchy_parent_detail,business_unit where  business_unit.IS_ACTIVE!='N' and ");
	    sql.append("hierarchy_detail.DATA_ID=business_unit.ID AND ");
	    sql.append("hierarchy_detail.NODE_TYPE_ID=3 and ");
	    sql.append("hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID and ");
	    sql.append("hierarchy_parent_detail.PARENT_ID = ");
	    sql.append("(select hierarchy_detail.ID from  hierarchy_detail where  hierarchy_detail.NODE_TYPE_ID=2 and ");
	    sql.append("hierarchy_detail.DATA_ID=  " + sectorId.longValue()+ ") order by business_unit.BUSINESS_NAME");*/
		sql=new StringBuffer("SELECT bu.id,bu.business_name ");
		sql.append("FROM ent_data dt,");
		sql.append(" business_unit bu");
		sql.append(" WHERE dt.entitlement_instance_id IN");
		sql.append("   (SELECT entitlement_instance_id");
		sql.append("  FROM ent_data");
		sql.append("   WHERE (entitlement_node_id = 1");
		sql.append("   AND data                   = " + regionId.longValue()+ ")");
		sql.append("   OR (entitlement_node_id    = 2");
		sql.append("  AND data                   = " + sectorId.longValue()+ ")");
		sql.append("   GROUP BY entitlement_instance_id");
		sql.append("   HAVING COUNT(*) = 2");
		sql.append("   )");
		sql.append(" AND dt.entitlement_node_id=3");
		sql.append(" AND dt.rule_id            =2");
		sql.append(" AND dt.data               =bu.id");
		sql.append(" ORDER BY bu.business_name");
		log.debug("getBusinessUnitList:SQL :"+sql.toString());
	    con = c3parSession.getConnection();
	    stmt = con.prepareStatement(sql.toString());
	    rs = stmt.executeQuery();
	    if(rs!=null) {
		while(rs.next()) {
		    BusinessUnitEntity buEntity=new BusinessUnitEntity();	
		    buEntity.setId(Long.valueOf(rs.getLong(1)));
		    buEntity.setBusinessName(rs.getString(2));
		    objList.add(buEntity);
		}
	    }
	}catch (Exception e) {
	    log.error(e);
	} finally {
	    try {
		if (rs != null) rs.close();
		if (stmt != null) stmt.close();
		c3parSession.releaseConnection();
	    } catch (Exception e) {
		log.error(e);
	    }
	}
	return objList;
    }
    
    public static List getBusinessUnitHierarchyDTOList(C3parSession c3parSession, Long regionId, Long sectorId) {
    	List objList = new ArrayList();
    	Connection con;
    	PreparedStatement stmt = null;
    	ResultSet rs = null;
    	StringBuffer sql;
    	log.debug("getBusinessUnitList");
    	try {
    		log.debug("getBusinessUnitList:Long regionId, Long sectorId :"+regionId+","+sectorId);
    	   /* sql=new StringBuffer("select business_unit.id,business_unit.BUSINESS_NAME  from ");
    	    sql.append("hierarchy_detail,hierarchy_parent_detail,business_unit where  business_unit.IS_ACTIVE!='N' and ");
    	    sql.append("hierarchy_detail.DATA_ID=business_unit.ID AND ");
    	    sql.append("hierarchy_detail.NODE_TYPE_ID=3 and ");
    	    sql.append("hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID and ");
    	    sql.append("hierarchy_parent_detail.PARENT_ID = ");
    	    sql.append("(select hierarchy_detail.ID from  hierarchy_detail where  hierarchy_detail.NODE_TYPE_ID=2 and ");
    	    sql.append("hierarchy_detail.DATA_ID=  " + sectorId.longValue()+ ") order by business_unit.BUSINESS_NAME");*/
    		sql=new StringBuffer("SELECT bu.id,bu.business_name ");
    		sql.append("FROM ent_data dt,");
    		sql.append(" business_unit bu");
    		sql.append(" WHERE dt.entitlement_instance_id IN");
    		sql.append("   (SELECT entitlement_instance_id");
    		sql.append("  FROM ent_data");
    		sql.append("   WHERE (entitlement_node_id = 1");
    		sql.append("   AND data                   = " + regionId.longValue()+ ")");
    		sql.append("   OR (entitlement_node_id    = 2");
    		sql.append("  AND data                   = " + sectorId.longValue()+ ")");
    		sql.append("   GROUP BY entitlement_instance_id");
    		sql.append("   HAVING COUNT(*) = 2");
    		sql.append("   )");
    		sql.append(" AND dt.entitlement_node_id=3");
    		sql.append(" AND dt.rule_id            =2");
    		sql.append(" AND dt.data               =bu.id");
    		sql.append(" ORDER BY bu.business_name");
    		log.debug("getBusinessUnitList:SQL :"+sql.toString());
    	    con = c3parSession.getConnection();
    	    stmt = con.prepareStatement(sql.toString());
    	    rs = stmt.executeQuery();
    	    if(rs!=null) {
    		while(rs.next()) {    		    		    
    		    HierarchyDTO hierarchyDTO = new HierarchyDTO();    		
    			hierarchyDTO.setId(Long.valueOf(rs.getLong(1)));    			
    			hierarchyDTO.setName(rs.getString(2));
    		    objList.add(hierarchyDTO);
    		}
    	    }
    	}catch (Exception e) {
    	    log.error(e);
    	} finally {
    	    try {
    		if (rs != null) rs.close();
    		if (stmt != null) stmt.close();
    		c3parSession.releaseConnection();
    	    } catch (Exception e) {
    		log.error(e);
    	    }
    	}
    	return objList;
        }

    /**
     * Gets the sector for bu.
     *
     * @param dbsession the dbsession
     * @param buId the bu id
     * @return the sector for bu
     */
    public static Long  getSectorForBU(C3parSession dbsession, Long buId)
    {
	Connection con=null;
	Statement stmt =null;
	ResultSet rs=null;
	Long sectorId=null;
	try
	{
	    con=dbsession.getConnection();
	    stmt=con.createStatement();
	    String sql="select hierarchy_detail.DATA_ID from hierarchy_detail where " +
	    "hierarchy_detail.id =( select hierarchy_parent_detail.parent_id " +
	    "from hierarchy_detail,hierarchy_parent_detail where hierarchy_detail.ID=hierarchy_parent_detail.NODE_ID  " +
	    "and hierarchy_detail.NODE_TYPE_ID=3 and hierarchy_detail.DATA_ID = "+buId+")";
	    rs=stmt.executeQuery(sql);
	    if(rs!=null){
		while(rs.next())
		    sectorId=Long.valueOf(rs.getLong(1));
	    }
	}
	catch(Exception e){
	    log.error(e);
	}
	finally{
	    try {
		if (rs != null) rs.close();
		if (stmt != null) stmt.close();
		dbsession.releaseConnection();
	    } catch (Exception e) {
		log.error(e);
	    } 
	}
	return sectorId;
    }

    /**
     * Gets the region for sector.
     *
     * @param dbsession the dbsession
     * @param sectorId the sector id
     * @param entitlementId the entitlement id
     * @return the region for sector
     */
    public static Long  getRegionForSector(C3parSession dbsession, Long sectorId, Long entitlementId)
    {
	Connection con=null;
	Statement stmt =null;
	ResultSet rs=null;
	Long regionId=null;
	try
	{
	    con=dbsession.getConnection();
	    stmt=con.createStatement();
	    String sql="select hierarchy_detail.DATA_ID from hierarchy_detail, ent_data " +
	    "where hierarchy_detail.id in ( select hierarchy_parent_detail.parent_id from hierarchy_detail,hierarchy_parent_detail " +
	    "where hierarchy_detail.ID=hierarchy_parent_detail.NODE_ID  and hierarchy_detail.NODE_TYPE_ID=2 " +
	    "and hierarchy_detail.DATA_ID = "+ sectorId +") and hierarchy_detail.DATA_ID = ent_data.DATA and " +
	    "ent_data.ENTITLEMENT_NODE_ID = (select id from ent_node where entity_name = 'Region') and " +
	    "ent_data.ENTITLEMENT_INSTANCE_ID = "+ entitlementId;

	    rs=stmt.executeQuery(sql);
	    if(rs!=null){
		while(rs.next())
		    regionId=Long.valueOf(rs.getLong(1));
	    }
	}
	catch(Exception e){
	    log.error(e);
	}
	finally{
	    try {
		if (rs != null) rs.close();
		if (stmt != null) stmt.close();
		dbsession.releaseConnection();
	    } catch (Exception e) {
		log.error(e);
	    }	 
	}
	return regionId;
    }

    /**
     * Gets the entitlement instance.
     *
     * @param dbsession the dbsession
     * @param regionID the region id
     * @param sectorID the sector id
     * @param businessUnitID the business unit id
     * @param entInstIds the ent inst ids
     * @return the entitlement instance
     */
    public static  Long getEntitlementInstance(C3parSession dbsession,Long regionID,Long sectorID, Long businessUnitID, List entInstIds)
    {
	Connection con=null;
	Statement stmt=null;
	Statement stmt1 = null;
	ResultSet rs=null;
	ResultSet rs1 = null;
	Long result=Long.valueOf(0);

	try{

	    StringBuffer str=new StringBuffer();
	    StringBuffer str1 = new StringBuffer();
	    StringBuffer entitlementIds = new StringBuffer();

	    if (entInstIds != null && entInstIds.size() > 0) {
		for (int i=0; i < entInstIds.size(); i++) {
		    EntitlementInstanceEntity entitlementEntity = (EntitlementInstanceEntity)entInstIds.get(i);
		    if (entitlementIds.length() <= 0) {
			entitlementIds.append(entitlementEntity.getId().toString());
		    } else {
			entitlementIds.append(","+entitlementEntity.getId().toString());
		    }
		}
	    }

	    str1.append("select distinct e1.ENTITLEMENT_INSTANCE_ID,e1.RULE_ID from ent_data e1, ent_data e2,ent_data e3, ent_node ");  
	    str1.append(" where e1.ENTITLEMENT_NODE_ID =(select id from ent_node where entity_name = '"+REGION+"') "); 
	    str1.append(" and e2.ENTITLEMENT_NODE_ID=(select id from ent_node where entity_name = '"+SECTOR+"' ) ");
	    str1.append(" and e3.ENTITLEMENT_NODE_ID=(select id from ent_node where entity_name = '"+BUSINESS_UNIT+"' ) ");
	    str1.append("and e1.DATA = '"+regionID+"'  and e2.DATA= '"+sectorID+"' and e3.data = '"+businessUnitID+"'"); 
	    str1.append(" and e1.ENTITLEMENT_INSTANCE_ID=e2.ENTITLEMENT_INSTANCE_ID and e2.ENTITLEMENT_INSTANCE_ID=e3.ENTITLEMENT_INSTANCE_ID "); 
	    str1.append(" and e1.RULE_ID=e2.RULE_ID and e2.RULE_ID=e3.RULE_ID and e1.RULE_ID=2");
	    if (entitlementIds != null && entitlementIds.length() > 0) {
		str1.append(" AND e1.ENTITLEMENT_INSTANCE_ID IN ("+entitlementIds+")");
	    }

	    str.append(" select distinct e1.ENTITLEMENT_INSTANCE_ID,e1.RULE_ID from ent_data e1, ent_data e2,ent_node ");
	    str.append(" where e1.ENTITLEMENT_NODE_ID =(select id from ent_node where entity_name = '");
	    str.append(REGION);
	    str.append("') and e2.ENTITLEMENT_NODE_ID=(select id from ent_node where entity_name = '");
	    str.append(SECTOR);
	    str.append("') and e1.DATA = " );
	    str.append(regionID);
	    str.append(" and e2.DATA= ");
	    str.append(sectorID);
	    str.append(" and e1.ENTITLEMENT_INSTANCE_ID=e2.ENTITLEMENT_INSTANCE_ID ");
	    str.append(" and e1.RULE_ID=e2.RULE_ID and e1.RULE_ID=1");
	    if (entitlementIds != null && entitlementIds.length() > 0) {
		str.append(" AND e1.ENTITLEMENT_INSTANCE_ID IN ("+entitlementIds+")");
	    }


	    con = dbsession.getConnection();
	    stmt1 = con.createStatement();
	    rs1 = stmt1.executeQuery(str1.toString());
	    //38730: INC0007920806	Issue in creating relationship
	    if (rs1 != null) {
		if (rs1.next()) {
		    result = Long.valueOf(rs1.getLong(1));
		} else {
		    stmt = con.createStatement();
		    rs = stmt.executeQuery(str.toString());
		    if(rs!=null) {

			if (rs.next()) {
			    result = Long.valueOf(rs.getLong(1));
			}
		    }
		}
	    } else {
		stmt = con.createStatement();
		rs = stmt.executeQuery(str.toString());
		if(rs!=null) {

		    if (rs.next()) {
			result = Long.valueOf(rs.getLong(1));
		    }
		}
	    }
	}
	catch(SQLException e) {
	    log.error(e);
	}
	catch(Exception e) {
	    log.error(e);
	}
	finally{
	    try {
		if (rs1 != null) rs1.close();
		if (stmt1 != null) stmt1.close();
		if (rs != null) rs.close();
		if (stmt != null) stmt.close();
		dbsession.releaseConnection();
	    } catch (Exception e) {
		log.error(e);
	    }	 
	}

	return result;

	/* " select distinct e1.ENTITLEMENT_INSTANCE_ID from ent_data e1, ent_data e2,ent_node  where
			e1.ENTITLEMENT_NODE_ID =(select id from ent_node where entity_name = '"+
			UserEntitlementHelper.REGION+"') and e2.ENTITLEMENT_NODE_ID=(select id from ent_node where entity_name = '"+
			UserEntitlementHelper.SECTOR+"') and e1.DATA = " +regionID+" and e2.DATA= "+sectorID+
			" and e1.ENTITLEMENT_INSTANCE_ID=e2.ENTITLEMENT_INSTANCE_ID";

			StringBuffer str=new StringBuffer("select distinct e1.ENTITLEMENT_INSTANCE_ID from ent_data e1, ent_data e2,ent_node  where
			e1.ENTITLEMENT_NODE_ID =(select id from ent_node where entity_name = '"); */

    }

    /**
     * Gets the resource type by id.
     *
     * @param c3parSession the c3par session
     * @param resourceTypeId the resource type id
     * @return the resource type by id
     */
    public static ResourceTypeEntity getResourceTypeById(C3parSession c3parSession, Long resourceTypeId) {
	ResourceTypeEntity resourceTypeEntity = null;
	try {
	    ResourceTypeDAO resourceTypeDAO = new ResourceTypeDAO(c3parSession);
	    resourceTypeEntity = resourceTypeDAO.get(resourceTypeId);

	} catch(DatabaseException ex) {
	    log.error(ex);
	} catch(Exception e) {
	    log.error(e);
	}

	return resourceTypeEntity;
    }

}
