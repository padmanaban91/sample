package com.citigroup.cgti.c3par.controller.admin;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.citigroup.cgti.c3par.admin.domain.ContactPopUpProcess;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.ThirdParty;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;

@Controller
public class ThirdPartyContactPopUpController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@RequestMapping(value = "/getContactDetailsForId.act", method =  { RequestMethod.GET, RequestMethod.POST })
	public String getContactDetailsForId(ModelMap model,@RequestParam(value ="selectedId", required = false) String selectedId,@RequestParam(value ="selectedThirdParty" , required = false) Long selectedThirdParty,HttpServletRequest request) {
		log.debug("Into get third Party details contact for id");
		Long id= 0L;
		ContactPopUpProcess contactPopUpProcess = new ContactPopUpProcess();
		if(selectedId!=null){
			id = Long.parseLong(selectedId);
			log.debug("id value is"+id);
		
			ThirdPartyContact tp = contactPopUpProcess.getThirdPartyForId(id);
			Location loc = new Location();
			loc.setAddress(tp.getLocation().getAddress());
			loc.setAddress2(tp.getLocation().getAddress2());
			loc.setCity(tp.getLocation().getCity());
			loc.setCountryId(tp.getLocation().getCountryId());
			loc.setRegionId(tp.getLocation().getRegionId());
			loc.setState(tp.getLocation().getState());
			loc.setZip(tp.getLocation().getZip());
			loc.setId(tp.getLocation().getId());
			contactPopUpProcess.setTpContact(tp);
			contactPopUpProcess.setTpLocation(loc);
		}
		else{
			log.debug("empty id" +selectedThirdParty);
			ThirdPartyContact ntp = new ThirdPartyContact();
			ThirdParty thirdParty = new ThirdParty();
			thirdParty.setId(selectedThirdParty);
			ntp.setThirdParty(thirdParty);
			contactPopUpProcess.setTpContact(ntp);
			contactPopUpProcess.setTpLocation(new Location());
		}
		contactPopUpProcess.setCountry(contactPopUpProcess.getListofCountries());
		contactPopUpProcess.setRegion(contactPopUpProcess.getListOfRegions());
		model.addAttribute("contactPopUpProcess", contactPopUpProcess);
		log.debug("Out of get third party contact for id");
		return "pages/dashboard/AddThirdPartyContact";
	}
	
	@RequestMapping(value = "/saveThirdPartyContact.act", method ={ RequestMethod.GET, RequestMethod.POST })
	public String saveThirdPartyContact(ModelMap model,@ModelAttribute("contactPopUpProcess") ContactPopUpProcess contactPopUpProcess,HttpServletRequest request) {
		log.debug("Into saveThirdPartyContact");
		if(contactPopUpProcess!=null){
			log.debug("available" +contactPopUpProcess.getTpContact().getId() +contactPopUpProcess.getTpContact().getFirstName());
			log.debug("available loc" +contactPopUpProcess.getTpLocation().getId() +contactPopUpProcess.getTpLocation().getCountryId().getId() +contactPopUpProcess.getTpLocation().getRegionId().getId() );
			contactPopUpProcess.saveThirdPartyContact();
		}
		else{
			log.debug("not there");
		}
		log.debug("Out of saveThirdPartyContact");
		return "c3par.admin.thirdPartyInfo";
	}
	

	
}
