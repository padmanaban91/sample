package com.citigroup.cgti.c3par.dashboard.webtier.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.common.domain.ManageThirdPartiesProcess;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.ThirdParty;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyLocationXref;

@Controller
public class ManageThirdPartiesController {

	/** The log. */
	private static Logger log = Logger.getLogger(ManageThirdPartiesController.class);

	/**
	 * To Load the List Relation ship
	 * 
	 * @return
	 */
	@RequestMapping(value = "/manageThirdPartiesAction.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String listThirdParties(ModelMap model,@ModelAttribute("manageThirdPartiesProcess") ManageThirdPartiesProcess manageThirdPartiesProcess,HttpServletRequest request) {
		log.debug("Into listThirdParties");
		String search = "";
		Long id = 0L;
		List<ThirdPartyContact> tpContact;
		List<Location> tpLocation;
		List<Relationship> tpRelationship;
		try{
		if(manageThirdPartiesProcess == null){
			manageThirdPartiesProcess = new ManageThirdPartiesProcess(); 
		}
		else{
			if(!(manageThirdPartiesProcess.getFilter() == null || manageThirdPartiesProcess.getFilter().isEmpty())){
			search = manageThirdPartiesProcess.getFilter();
			log.debug("search value " +search);
		}
		}
		
		List<ThirdParty> tpList = manageThirdPartiesProcess.getThirdPartyList(search);
		if(request.getParameter("id")!=null){
			id = Long.parseLong(request.getParameter("id"));
			log.debug("search value for id " +id);
		}
		else{
			if(tpList.size()>0){
			id = tpList.get(0).getId();
			log.debug("search string first value" +id);
			}
		}
		if(id>0){
			tpContact = manageThirdPartiesProcess.getTpContactsForId(id);
			tpLocation = manageThirdPartiesProcess.getTpLocationsForId(id);
			tpRelationship = manageThirdPartiesProcess.getTpRelationshipForId(id);
		}
		else{
			tpContact = new ArrayList<ThirdPartyContact>();
			tpLocation = new ArrayList<Location>();
			tpRelationship = new ArrayList<Relationship>();
		}
		
		manageThirdPartiesProcess.setSelectedThirdParty(id);
		log.debug("id value" +manageThirdPartiesProcess.getSelectedThirdParty());
		manageThirdPartiesProcess.setThirdParties(tpList);
		manageThirdPartiesProcess.setTpContacts(tpContact);
		manageThirdPartiesProcess.setTpLocations(tpLocation);
		manageThirdPartiesProcess.setTpRelationship(tpRelationship);
		model.addAttribute("manageThirdPartiesProcess", manageThirdPartiesProcess);
		log.debug("Out of listThirdParties");
		}
		catch(Exception e){
			log.error(e,e);
		}
		return "c3par.admin.thirdPartyInfo";
	}
	
	@RequestMapping(value = "/deleteThirdPartyAction.act", method ={ RequestMethod.GET, RequestMethod.POST })
	public String deleteThirdParty(ModelMap model,@ModelAttribute("manageThirdPartiesProcess") ManageThirdPartiesProcess manageThirdPartiesProcess,BindingResult result,HttpServletRequest request) {
		log.debug("Into delete third Party");
		Long id = 0L;
		List<Relationship> tpRelationship = new ArrayList();
		try{
		if(manageThirdPartiesProcess == null){
			manageThirdPartiesProcess = new ManageThirdPartiesProcess(); 
		}
		if(manageThirdPartiesProcess.getSelectedThirdParty()!=null){
			id = manageThirdPartiesProcess.getSelectedThirdParty();
			log.debug("search value for tp id " +id);
		}
		if(id!=0L){
			tpRelationship = manageThirdPartiesProcess.getTpRelationshipForId(id);
		}
		if(!(tpRelationship.size()>0)){
			log.debug("list size" +tpRelationship.size());
			manageThirdPartiesProcess.deleteThirdParty(id);
		}
		else{
			result.addError(new ObjectError("cannot", "The third party is associated with relationship and hence cannot be deleted."));
		}
		listThirdParties(model,manageThirdPartiesProcess,request);
		}
		catch(Exception e){
			log.error(e,e);
			result.addError(new ObjectError("cannot", "Exception occured while deleting third party."));
			listThirdParties(model,manageThirdPartiesProcess,request);
		}
		log.debug("Out of delete third party");
		return "c3par.admin.thirdPartyInfo";
	}
	
	
	@RequestMapping(value = "/deleteThirdPartyContact.act", method ={ RequestMethod.GET, RequestMethod.POST })
	public String deleteThirdPartyContact(ModelMap model,@ModelAttribute("manageThirdPartiesProcess") ManageThirdPartiesProcess manageThirdPartiesProcess,BindingResult result,HttpServletRequest request) {
		log.debug("Into delete third Party");
		int count = 0;
		Long id=0L;
		try{
		if(manageThirdPartiesProcess == null){
			manageThirdPartiesProcess = new ManageThirdPartiesProcess(); 
		}
		if(manageThirdPartiesProcess.getSelectedId()!=null){
			log.debug("value of select " +manageThirdPartiesProcess.getSelectedId());
			id=Long.parseLong(manageThirdPartiesProcess.getSelectedId());
			count = manageThirdPartiesProcess.getTpRelationshipForContact(id);
		}
		if(!(count>0)){
			manageThirdPartiesProcess.deleteContactById(id);
			log.debug("can delete");
		}
		else{
			result.addError(new ObjectError("cannot", "The contact is associated with relationship and hence cannot be deleted."));
		}
		listThirdParties(model,manageThirdPartiesProcess,request);
		}
		catch(Exception e){
			log.error(e,e);
			result.addError(new ObjectError("cannot", "Exception occured while deleting the contact."));
			listThirdParties(model,manageThirdPartiesProcess,request);
		}
		
		log.debug("Out of delete third party");
		return "c3par.admin.thirdPartyInfo";
	}
	
	
	@RequestMapping(value = "/deleteThirdPartyLocation.act", method ={ RequestMethod.GET, RequestMethod.POST })
	public String deleteThirdPartyLocation(ModelMap model,@ModelAttribute("manageThirdPartiesProcess") ManageThirdPartiesProcess manageThirdPartiesProcess,BindingResult result,HttpServletRequest request) {
		log.debug("Into delete third Party");
		int count = 0;
		Long id=0L;
		try{
		if(manageThirdPartiesProcess == null){
			manageThirdPartiesProcess = new ManageThirdPartiesProcess(); 
		}
		if(manageThirdPartiesProcess.getSelectedId()!=null){
			log.debug("value of select " +manageThirdPartiesProcess.getSelectedId());
			id=Long.parseLong(manageThirdPartiesProcess.getSelectedId());
			count = manageThirdPartiesProcess.getTpRelationshipForLocation(id);
		}
		if(!(count>0)){
			manageThirdPartiesProcess.deleteLocationById(id);
			log.debug("can delete");
		}
		else{
			result.addError(new ObjectError("cannot", "The location is associated with relationship and hence cannot be deleted."));
		}
		listThirdParties(model,manageThirdPartiesProcess,request);
		}
		catch(Exception e){
			log.error(e,e);
			result.addError(new ObjectError("cannot", "The location is associated with relationship."));
			listThirdParties(model,manageThirdPartiesProcess,request);
		}
		
		log.debug("Out of delete third party");
		return "c3par.admin.thirdPartyInfo";
	}
	
}
