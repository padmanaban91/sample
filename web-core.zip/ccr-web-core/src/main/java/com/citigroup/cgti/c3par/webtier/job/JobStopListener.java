/**
 * 
 */
package com.citigroup.cgti.c3par.webtier.job;

import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;

/**
 * @author ka58098
 *
 */
@Component
public class JobStopListener implements ApplicationListener<ContextClosedEvent> {
    private static Logger log = Logger.getLogger(JobStopListener.class);
    private Scheduler scheduler = null;
    public static final Map<String, String> JOB_NAMES_GROUPS = CCRJobsConstants.JOB_NAMES_GROUPS;

    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
        log.info("Entering ::");
       
        try {
            deleteAllJobs();
        } catch (SchedulerException e) {
            log.error("Error has occurred onApplicationEvent method():: . Exception is " + e.getMessage());
            log.error(e.toString(), e);
        }
        log.info("Exiting ::");
    }
    public void deleteAllJobs() throws SchedulerException {
        log.info("Entering ::");
        scheduler = new StdSchedulerFactory().getScheduler();
        for (Entry<String, String> entry : JOB_NAMES_GROUPS.entrySet()) {
            try {
                log.info("Deleting the job : " + entry.getKey() + " from the jobGroup " + entry.getValue());
                boolean isDeleted = scheduler.deleteJob(entry.getKey(), entry.getValue());
                log.info("Deletion status of " + entry.getKey() + " is : " + isDeleted);
            } catch (Exception e) {
                log.error("Exception occurred while deleting the job :" + entry.getKey() + ". Exception is "
                        + e.getMessage());
                log.error(e.toString(), e);
            }
        }
        log.info("Exiting ::");
    }

}
