package com.citigroup.cgti.c3par.dashboard.webtier.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.BusinessUnitDAO;
import com.citigroup.cgti.c3par.dao.ResourceTypeDAO;
import com.citigroup.cgti.c3par.dao.lookup.ResourceTypeLookup;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.ResourceType;
import com.citigroup.cgti.c3par.model.BusinessUnitEntity;
import com.citigroup.cgti.c3par.model.ResourceTypeEntity;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.model.ManyAssociationList;
import org.apache.log4j.Logger;


/**
 * The Class ResourceTypeHelper.
 */
public class ResourceTypeHelper {

    /** The instance. */
    static private ResourceTypeHelper instance = null;

    /** The log. */
    private static Logger log = Logger.getLogger(ResourceTypeHelper.class);

    //======================================================================
    /**
     * Gets the single instance of ResourceTypeHelper.
     *
     * @return single instance of ResourceTypeHelper
     */
    synchronized static public ResourceTypeHelper getInstance()
    {
	if (instance == null)
	{
	    instance = new ResourceTypeHelper();
	}
	return instance;
    }

    //======================================================================
    /**
     * Instantiates a new resource type helper.
     */
    private ResourceTypeHelper()
    {
	super();
    }

    /**
     * Inserts Resource Type.
     *
     * @param resourceType the resource type
     * @param c3parSession the c3par session
     * @throws Exception the exception
     */
    public void add(ResourceType resourceType, C3parSession c3parSession) throws Exception {
	ResourceTypeEntity resourceTypeEntity = new ResourceTypeEntity();
	ResourceTypeDAO resourceTypeDAO = new ResourceTypeDAO(c3parSession);
	resourceTypeEntity.setName(resourceType.getName());
	resourceTypeEntity.setPerimeter(resourceType.getPerimeter());
	resourceTypeEntity.setStatus("Inactive");
	resourceTypeEntity.setCreatedBy(resourceType.getCreatedBy());
	resourceTypeEntity.setCreatedDate(new Date());
	resourceTypeDAO.insert(resourceTypeEntity);
    }

    /**
     * Updates particular Resource Type.
     *
     * @param resourceType the resource type
     * @param c3parSession the c3par session
     * @throws Exception the exception
     */
    public void update (ResourceType resourceType, C3parSession c3parSession) throws Exception {
	ResourceTypeEntity resourceTypeEntity = new ResourceTypeEntity();
	ResourceTypeDAO resourceTypeDAO = new ResourceTypeDAO(c3parSession);
	resourceTypeEntity.setPrimaryKey(resourceType.getResourceTypeId());
	resourceTypeEntity.setId(resourceType.getResourceTypeId());
	resourceTypeEntity.setName(resourceType.getName());
	resourceTypeEntity.setPerimeter(resourceType.getPerimeter());
	resourceTypeEntity.setStatus(resourceType.getStatus());
	resourceTypeEntity.setCreatedBy(resourceType.getCreatedBy());
	resourceTypeEntity.setCreatedDate(resourceType.getCreatedDate());
	resourceTypeEntity.setModifiedBy(resourceType.getCreatedBy());
	resourceTypeEntity.setModifiedDate(new Date());
	resourceTypeDAO.update(resourceTypeEntity);
    }

    /**
     * Returns All ResourceTypes.
     *
     * @param c3parSession the c3par session
     * @param perimeter TODO
     * @return resourceTypeList
     * @throws Exception the exception
     */
    public List getResourceType(C3parSession c3parSession, String perimeter) throws Exception {
	ArrayList resourceTypeList = new ArrayList();
	ArrayList resourceTypeEntityList;
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	StringBuffer strQuery = new StringBuffer("SELECT A.ID, A.NAME, A.PERIMETER, A.STATUS, A.CREATED_BY, B.FIRST_NAME || ' ' || B.LAST_NAME CREATED_BY_NAME, A.CREATED_DATE, A.MODIFIED_BY, A.MODIFIED_DATE FROM RESOURCETYPE A, C3PAR_USERS B WHERE A.CREATED_BY = B.SSO_ID");
	//		ResourceTypeLookup resourceTypeLookup = ResourceTypeLookup.getInstance();
	//		ResourceTypeDAO resourceTypeDAO = ResourceTypeDAO.createInstance(c3parSession);
	//		resourceTypeLookup.reset();
	//		resourceTypeLookup.initialize(c3parSession);
	try {
	    con = c3parSession.getConnection();
	    if ((perimeter != null) && (!"".equalsIgnoreCase(perimeter)) && (!"null".equalsIgnoreCase(perimeter))) {
		//				resourceTypeEntityList = (ArrayList)resourceTypeDAO.findByPerimeter(perimeter);
		strQuery.append(" AND upper(PERIMETER) = upper('"+perimeter+"')");

		pstmt = con.prepareStatement(strQuery.toString());
		rs = pstmt.executeQuery();
	    } else {
		//				resourceTypeEntityList = (ArrayList)resourceTypeDAO.getAll(false);
		pstmt = con.prepareStatement(strQuery.toString());
		rs = pstmt.executeQuery();
	    }

	    if (rs != null) {
		while (rs.next()) {
		    ResourceType resourceType = new ResourceType();
		    resourceType.setId(Long.valueOf(rs.getLong("ID")));
		    resourceType.setResourceTypeId(Long.valueOf(rs.getLong("ID")));
		    resourceType.setName(rs.getString("NAME"));
		    resourceType.setPerimeter(rs.getString("PERIMETER"));
		    resourceType.setStatus(rs.getString("STATUS"));
		    resourceType.setCreatedBy(rs.getString("CREATED_BY"));
		    resourceType.setCreatedByName(rs.getString("CREATED_BY_NAME"));
		    if (rs.getDate("CREATED_DATE") != null) {
			resourceType.setCreatedDate((java.util.Date)(rs.getDate("CREATED_DATE")));
		    }

		    if (rs.getString("MODIFIED_BY") != null) {
			resourceType.setModifiedBy(rs.getString("MODIFIED_BY"));
		    }
		    if (rs.getString("MODIFIED_DATE") != null) {
			resourceType.setModifiedDate((java.util.Date)(rs.getDate("MODIFIED_DATE")));
		    }
		    resourceTypeList.add(resourceType);
		}
	    }

	} catch (SQLException ex) {
	    throw new Exception(ex.getMessage());
	} finally {
	    try {
		rs.close();
		pstmt.close();
		c3parSession.releaseConnection();
	    } catch (Exception e) {
		//
	    }
	}
	return resourceTypeList;
    }

    /*Added by barun to Add and Edit location if resource type is selected Ref:IssueId-447 */
    /**
     * Gets the resource type id.
     *
     * @param c3parSession the c3par session
     * @param locationId the location id
     * @return the resource type id
     * @throws Exception the exception
     */
    public boolean getResourceTypeId(C3parSession c3parSession, Long locationId) throws Exception {

	boolean isResTypeLoc=false;
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	StringBuffer strQuery = new StringBuffer("SELECT RESOURCE_TYPE_ID FROM RES_TYP_LOC_XREF WHERE LOCATION_ID="+locationId);
	try {
	    con = c3parSession.getConnection();
	    pstmt = con.prepareStatement(strQuery.toString());
	    rs = pstmt.executeQuery();
	    if (rs.next()) {
		isResTypeLoc=true;

	    }

	} catch (Exception ex) {
	    ex.getMessage();
	} finally {
	    try {
		rs.close();
		pstmt.close();
		c3parSession.releaseConnection();
	    } catch (Exception e) {
		e.getMessage();
	    }
	}

	return isResTypeLoc;
    }
    /*Added by barun to Add and Edit location if resource type is selected Ref:IssueId-447 */
    /**
     * Gets the location.
     *
     * @param resourceTypeId the resource type id
     * @param location_id the location_id
     * @param session the session
     * @return the location
     * @throws DatabaseException the database exception
     */
    public Map getLocation (Long resourceTypeId,Long location_id ,C3parSession session) throws DatabaseException {
	Connection con = null;
	Map resourceTypeLocMap = new HashMap();
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	try{
	    con = session.getConnection();	
	    StringBuffer strQuery = new StringBuffer("select A.DEPARTMENT,A.ADDRESS,A.ADDRESS2,A.CITY,A.STATE,A.ZIP,A.REGION_ID,A.COUNTRY_ID from location A,RES_TYP_LOC_XREF B where");
	    strQuery.append(" A.ID="+location_id+" and B.RESOURCE_TYPE_ID="+resourceTypeId+" and A.ID=B.LOCATION_ID");
	    pstmt = con.prepareStatement(strQuery.toString());
	    rs = pstmt.executeQuery();
	    if (rs != null) {
		while (rs.next()) {
		    resourceTypeLocMap.put("DEPARTMENT",rs.getString("DEPARTMENT"));
		    resourceTypeLocMap.put("ADDRESS", rs.getString("ADDRESS"));
		    resourceTypeLocMap.put("ADDRESS2", rs.getString("ADDRESS2"));
		    resourceTypeLocMap.put("CITY", rs.getString("CITY"));
		    resourceTypeLocMap.put("STATE",rs.getString("STATE"));
		    resourceTypeLocMap.put("ZIP", rs.getString("ZIP"));
		    resourceTypeLocMap.put("REGION_ID", rs.getString("REGION_ID"));
		    resourceTypeLocMap.put("COUNTRY_ID", rs.getString("COUNTRY_ID"));

		}
	    }
	}catch(Exception ex){
	    log.error(ex);
	}finally {
	    try {
		rs.close();
		pstmt.close();
		session.releaseConnection();
	    } catch (Exception e) {
		//
	    }
	}
	return resourceTypeLocMap;
    }
    /*Added by barun to Add and Edit location if resource type is selected Ref:IssueId-447 */

    /**
     * Update.
     *
     * @param resMapList the res map list
     * @param c3parSession the c3par session
     * @throws Exception the exception
     */
    public void update (Map resMapList, C3parSession c3parSession) throws Exception {

	Connection con = null;
	PreparedStatement pstmt = null;
	String department=null;
	String address=null;
	String address2=null;
	String city=null;
	String state=null;
	String zip=null;
	Long ID=null;
	Long REGION_ID=null;
	Long COUNTRY_ID=null;
	try{
	    for(int i=0;i<resMapList.size();i++){

		ID=Long.valueOf((String)resMapList.get("LOCATION_ID"));
		department=(String)resMapList.get("DEPARTMENT");
		address=(String)resMapList.get("ADDRESS");
		address2=(String)resMapList.get("ADDRESS2");
		city=(String)resMapList.get("CITY");
		state=(String)resMapList.get("STATE");
		zip=(String)resMapList.get("ZIP");
		REGION_ID=Long.valueOf((String)resMapList.get("REGION_ID"));
		COUNTRY_ID=Long.valueOf((String)resMapList.get("COUNTRY_ID"));

	    }

	    StringBuffer strQuery = new StringBuffer("UPDATE LOCATION SET DEPARTMENT='"+department+"', ADDRESS='"+address+"'," +
		    " ADDRESS2='"+address2+"', CITY='"+city+"', STATE='"+state+"', ZIP='"+zip+"'," +" REGION_ID="+REGION_ID+"," +
		    " COUNTRY_ID="+COUNTRY_ID+"  where ID="+ID);

	    log.debug("QUERY is :- " + strQuery);
	    con = c3parSession.getConnection();	

	    pstmt = con.prepareStatement(strQuery.toString());
	    int j = pstmt.executeUpdate();
	    log.debug("Rows Updated :- " + j);
	}catch(Exception ex){
	    log.error(ex);
	}finally {
	    try {

		pstmt.close();
		c3parSession.releaseConnection();
	    } catch (Exception e) {
		//
	    }
	}


    }



    /**
     * Gets the contact.
     *
     * @param resourceTypeId the resource type id
     * @param session the session
     * @return the contact
     * @throws DatabaseException the database exception
     */
    public List getContact (Long resourceTypeId, C3parSession session) throws DatabaseException {
	ResourceTypeDAO resourceTypeDAO = new ResourceTypeDAO(session);
	ResourceTypeEntity resourceTypeEntity = resourceTypeDAO.get(resourceTypeId);
	if ((resourceTypeEntity == null) || (resourceTypeEntity.getCitiContact() == null)) return (new ManyAssociationList());
	return resourceTypeEntity.getCitiContact();
    }

    /**
     * Gets the location.
     *
     * @param resourceTypeId the resource type id
     * @param session the session
     * @return the location
     * @throws DatabaseException the database exception
     */
    public List getLocation (Long resourceTypeId, C3parSession session) throws DatabaseException {
	ResourceTypeDAO resourceTypeDAO = new ResourceTypeDAO(session);
	ResourceTypeEntity resourceTypeEntity = resourceTypeDAO.get(resourceTypeId);
	if ((resourceTypeEntity == null) || (resourceTypeEntity.getLocation() == null)) return (new ManyAssociationList());
	return resourceTypeEntity.getLocation();
    }

    //	=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @param dbs the dbs
     * @return the resource type entity
     * @throws DatabaseException the database exception
     */
    public ResourceTypeEntity get(Long id, DatabaseSession dbs) throws DatabaseException
    {
	ResourceTypeDAO dao = new ResourceTypeDAO(dbs);
	ResourceTypeEntity	entity = dao.get(id);

	return entity;
    }

    /**
     * Update.
     *
     * @param entity the entity
     * @param dbs the dbs
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(ResourceTypeEntity entity, C3parSession dbs) throws DatabaseException
    {
	if(entity != null)
	{
	    ResourceTypeDAO dao = new ResourceTypeDAO(dbs);
	    return dao.update(entity, dbs.getArchiver());
	}
	return null;
    }
}
