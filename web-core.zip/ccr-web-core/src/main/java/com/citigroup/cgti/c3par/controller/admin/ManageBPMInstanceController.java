package com.citigroup.cgti.c3par.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citigroup.cgti.c3par.admin.domain.ManageBPMInstanceProcess;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityBPMDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.ManageActivityImpl;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.database.service.WorkflowDBService;
import com.citigroup.cgti.ccr.workflow.domain.JBPMTaskRef;
import com.citigroup.cgti.ccr.workflow.impl.MigrationService;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;


/*
 * @nc43495
 */
@Controller
public class ManageBPMInstanceController {
	
	

	/** The log. */
	private static Logger log = Logger.getLogger(ManageBPMInstanceController.class);
	
	@Autowired
	private WorkflowDBService workflowDBService;
	
	@Autowired
	WorkflowUtil workflowUtil;
	
	@Autowired
	WsPapiFacade papiFacade;
	
	@Autowired
	ManageTIProcessImpl manageTIProcessImpl;
	
	@Autowired
	ManageActivityImpl manageActivityImpl;
	
	@Autowired
	WorkflowCallServiceHelper wrkflowCallServiceHelper;
	@Autowired
	MigrationService migrationService;
	
	//Load all activity
	@RequestMapping(value = "/loadAllActivity.act", method = {RequestMethod.GET,RequestMethod.POST})
		public String loadAllActivity(ModelMap model) {
			log.info("ManageBPMInstancesController::loadAllActivityList methods starts...");
			String forwardPage="c3par.admin.manageBPMInstances";
			ManageBPMInstanceProcess manageBPMInstanceProcess = new ManageBPMInstanceProcess();
			List<ActivityBPMDTO> resultList=manageBPMInstanceProcess.getAllActivityDetails();
			manageBPMInstanceProcess.setActivityBpm(resultList);
			model.addAttribute("load",manageBPMInstanceProcess);
			log.debug("List retreive"+manageBPMInstanceProcess.getActivityBpm().size());
			log.info("ManageBPMInstancesController::loadAllActivityList methods ends...forwardPage ==> "+forwardPage);
			
			return forwardPage;
		}
	
	
	@RequestMapping(value = "/loadActivity.act", method = {RequestMethod.GET,RequestMethod.POST})
	public @ResponseBody String loadActivity(ModelMap model,@ModelAttribute("load") ManageBPMInstanceProcess manageBPMprocess,HttpServletRequest request) {
		log.info("ManageBPMInstancesController::loadActivityList methods starts...");
		Long pID = manageBPMprocess.getProcessID();
		log.debug("Process id is"+pID);
		StringBuffer activitiesJSONSB = new StringBuffer();
		ManageBPMInstanceProcess manageBPMInstanceProcess = new ManageBPMInstanceProcess();
		if(pID != 0){
			List<ActivityBPMDTO> resultList=manageBPMInstanceProcess.getActivityDetails(pID);
			manageBPMInstanceProcess.setActivityBpm(resultList);
			activitiesJSONSB.append("[");
			activitiesJSONSB.append("{\"item\":\"\",\"label\":\"Activity to be Migrated\"}");
			for (ActivityBPMDTO objList : resultList) {
				log.debug("values" + objList.getActivityName()+ objList.getTiRequestId());
				manageBPMInstanceProcess.setTiReq(objList.getTiRequestId());
				activitiesJSONSB.append(",{\"item\":\""+objList.getBpmInstanceId()+":"+objList.getActivityTrailID()+"\",\"label\":\""+objList.getActivityName()+"\"}");
				}
			activitiesJSONSB.append("]");
			model.addAttribute("comboValues", activitiesJSONSB.toString());
			log.debug("activitiesList" + activitiesJSONSB.toString());
		}
		log.info("ManageBPMInstancesController::loadActivityList methods ends...forwardPage ==> "+activitiesJSONSB.toString());
		return activitiesJSONSB.toString();
	}
	
	
	//remove an instance
	@RequestMapping(value = "/deleteActivity.act", method = {RequestMethod.POST})
		public String deleteActivity(ModelMap model,@ModelAttribute("load") ManageBPMInstanceProcess manageBPMprocess,HttpServletRequest request) {
			log.info("ManageBPMInstancesController::deleteActivity methods starts...");
			
				try {
					Long tiRequestID = 0L;
					String instanceId = null;
					Long pID = manageBPMprocess.getProcessID();
					Long activityID = 0L;
					Long activityTrailId=0L;
					
					List<ActivityBPMDTO> resultList=manageBPMprocess.getActivityDetails(pID);
					manageBPMprocess.setActivityBpm(resultList);
					for (ActivityBPMDTO objList : resultList) {
						activityID = objList.getActivityId();
						tiRequestID=objList.getTiRequestId();
						}
					
					String str=manageBPMprocess.getActivity();
					String strArray[]=str.split(":");
					instanceId=strArray[0];
					activityTrailId=Long.valueOf(strArray[1]);
					
					manageBPMprocess.updateActivityTrail(activityTrailId);
					JBPMTaskRef taskRef=workflowUtil.getLatestTaskRefByAuditTrailId(activityTrailId);
					String c3parProcPhase=null;
					if(taskRef !=null){
						c3parProcPhase=taskRef.getPhase();
					}
					log.debug("updateActivity trail -removed");
					log.debug("DeleteActivtiy Enter ");
					/*WsPapiFacade papiFacade = new WsPapiFacade ();*/
					//JBPMTaskRef taskRef=workflowUtil.getLatestTaskRefByAuditTrailId(activityTrailId);
					 //String user = request.getRemoteUser();
					 String user = request.getHeader("SM_USER");
					workflowUtil.closeWorkItemByExceptionStatus(tiRequestID,user);
					/*if(manageBPMprocess.getNewActivity()!=null){
					papiFacade.abortActivityManually(user, taskRef.getTaskId(),workflowDBService.getTaskCodeByActivityId(Long.valueOf( manageBPMprocess.getNewActivity())));
					}*/
					log.debug("Instanceid: " + instanceId);
					log.debug("userId: " + user);
					log.debug("deleteactivity tiReqID: " +tiRequestID);
					log.debug("Before calling JBPM ...");
					String nextActivityCode = workflowDBService.getTaskCodeByActivityId(Long.valueOf( manageBPMprocess.getNewActivity()));
				
					if ("Active".equalsIgnoreCase(nextActivityCode)) {
						manageTIProcessImpl.endProcess(tiRequestID, workflowUtil.finalActivityCode(ActivityDataDTO.STATUS_COMPLETED, c3parProcPhase!=null?c3parProcPhase:null), ActivityDataDTO.STATUS_COMPLETED);
					} else if (nextActivityCode != null) {
						migrationService.initiateJBPMProcess(pID, user, null,
								nextActivityCode, tiRequestID);
					}
				//	papiFacade.notifyBPM(user, instanceId,tiRequestID, WsPapiFacade.ActivityName.AbortRollbkNotificationWait, WsPapiFacade.ActivityArgName.AbortRollbkNotificationWaitIn);
					
					log.debug("After calling JBPM ...");
						
				} catch (Exception e) {
					log.debug("DeleteActivtiy Failed ",e);
				}
				return "forward:/loadAllActivity.act";
			}
		//remove and create an instance
		@RequestMapping(value = "/removeAddInstance.act", method = {RequestMethod.GET,RequestMethod.POST})
		public String removeAddInstance(ModelMap model,@ModelAttribute("load") ManageBPMInstanceProcess manageBPMprocess,HttpServletRequest request,ManageBPMInstanceProcess manageBPMInstanceProcess) {
			log.info("ManageBPMInstanceController:removeAddInstance starta here...");
			try {
					deleteActivity(model,manageBPMprocess,request);
					//createInstance(model,manageBPMprocess,request);
						
				} catch (Exception e) {
					log.debug("Delete and Add an instance ",e);
				}
				return "forward:/loadAllActivity.act";
			}
		@RequestMapping(value = "/createMigratedInstance.act", method = {RequestMethod.GET,RequestMethod.POST})
		public String createMigratedInstance(ModelMap model,
				@ModelAttribute("load") ManageBPMInstanceProcess manageBPMprocess,
				HttpServletRequest request) {
			log.info("ManageBPMInstances:inside createInstance Migratie to JBPM -Start");
			try {
				// updating version number in ti_Activity_trail and performing
				// Autopush
				Long pID = manageBPMprocess.getProcessID();
				String user = request.getHeader("SM_USER");
				migrationService.migrateConnection(pID, user,null);
				log.info("ManageBPMInstances:inside createInstance Migratie to JBPM -End");
			} catch (Exception e) {
				log.debug("CreateInstance Failed ", e);
			}
			log.info("ManageBPMInstances:inside createInstance Migratie to JBPM -Start");
			return "forward:/loadAllActivity.act";

		}
		
	
}
