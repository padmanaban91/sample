/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.mentisys.admin.deploy.OrgResourceDeployer;
import com.mentisys.admin.deploy.OrgResourceDeployerHome;
import com.mentisys.admin.deploy.ResourceDetail;
import org.apache.log4j.Logger;


/**
 * The Class ResourceDelegator.
 */
public class ResourceDelegator {

    /** The self. */
    private static ResourceDelegator self = null;

    /** The cache home. */
    private Map cacheHome = new HashMap();

    /** The log. */
    private static Logger log = Logger.getLogger(ResourceDelegator.class);

    /**
     * Gets the resource delegator.
     *
     * @return the resource delegator
     */
    public static ResourceDelegator getResourceDelegator() {

	if (self == null)
	    self = new ResourceDelegator();

	return self;
    }

    /**
     * Adds the resource.
     *
     * @param userId the user id
     * @param firstName the first name
     * @param lastName the last name
     * @param email the email
     * @param phoneNo the phone no
     * @param pagerNo the pager no
     * @param state the state
     * @throws ResourceDelegatorException the resource delegator exception
     */
    public void addResource(String userId, String firstName, String lastName,
	    String email, String phoneNo, String pagerNo,boolean state)
    throws ResourceDelegatorException {

	OrgResourceDeployerHome orgResourceDeployerHome = null;
	OrgResourceDeployer ord = null;

	ResourceDetail theDetail = null;
	theDetail = new ResourceDetail();
	theDetail.id = userId;
	theDetail.firstName = firstName;
	theDetail.lastName = lastName;
	theDetail.emailId = email;
	theDetail.type = "user";
	if(state)
	    theDetail.state = "available";
	else
	    theDetail.state = "unavailable";
	//theDetail.state = "";
	theDetail.shared = "shared";
	theDetail.allocation = 1000;
	theDetail.usageRestriction = "non-consumable";
	theDetail.orgUnit = C3parProperties.WPE_ORGUNIT;

	Set newPositions = new HashSet();
	newPositions.add(C3parProperties.WPE_POSITION);
	try {
	    orgResourceDeployerHome = getOrgResourceDeployerHome();
	    ord = orgResourceDeployerHome.create();
	} catch (Exception InitExec) {
	    String msg = "Failed to create OrgResourceDeployer : ";
	    log.error(msg + " : " +InitExec);
	    throw new ResourceDelegatorException(msg + InitExec);
	}

	boolean userExists = false;
	try {
	    // Lets check if resource exists in WPE
	    userExists = ord.doesResourceExist(userId);
	} catch (Exception WPEExec) {
	    String msg = "ResourceDelegator.addResource() - Failed to validate User existance : ";
	    log.error(msg + " : " +WPEExec);
	    throw new ResourceDelegatorException(msg + WPEExec);
	}

	// Now lets decide what to do, based on the information that we have
	if (userExists)
	    return;
	else {
	    // User does not exist, so lets go ahead and add it
	    try {
		ord.addResource(theDetail);
		//ord.addPositionsToResource(userId, C3parProperties.WPE_ORGUNIT, newPositions);
	    } catch (Exception WPEExec) {
		String msg = "ResourceDelegator.addResource() - failed to add UserId = " + userId + " to WPE Org Model \n";
		log.error(msg + " : " + WPEExec);
		throw new ResourceDelegatorException(msg + WPEExec.toString());
	    }
	}
    }

    /**
     * Update resource.
     *
     * @param userId the user id
     * @param firstName the first name
     * @param lastName the last name
     * @param email the email
     * @param phoneNo the phone no
     * @param pagerNo the pager no
     * @param state the state
     * @throws ResourceDelegatorException the resource delegator exception
     */
    public void updateResource(String userId, String firstName, String lastName,
	    String email, String phoneNo, String pagerNo,boolean state)
    throws ResourceDelegatorException {

	OrgResourceDeployerHome orgResourceDeployerHome = null;
	OrgResourceDeployer ord = null;

	ResourceDetail theDetail = null;
	theDetail = new ResourceDetail();
	theDetail.id = userId;
	theDetail.firstName = firstName;
	theDetail.lastName = lastName;
	theDetail.emailId = email;
	theDetail.type = "user";
	if(state)
	    theDetail.state = "available";
	else
	    theDetail.state = "unavailable";
	theDetail.shared = "shared";
	theDetail.allocation = 1000;
	theDetail.usageRestriction = "non-consumable";
	theDetail.orgUnit = C3parProperties.WPE_ORGUNIT;

	Set newPositions = new HashSet();
	newPositions.add(C3parProperties.WPE_POSITION);
	try {
	    orgResourceDeployerHome = getOrgResourceDeployerHome();
	    ord = orgResourceDeployerHome.create();
	} catch (Exception InitExec) {
	    String msg = "Failed to create OrgResourceDeployer : ";
	    log.error(msg + " : " +InitExec);
	    throw new ResourceDelegatorException(msg + InitExec);
	}

	try {
	    ord.updateResource(theDetail);
	} catch (Exception WPEExec) {
	    String msg = "ResourceDelegator.addResource() - failed to add UserId = " + userId + " to WPE Org Model \n";
	    log.error(msg + " : " + WPEExec);
	    throw new ResourceDelegatorException(msg + WPEExec.toString());
	}
    }

    /**
     * Adds the resource to role.
     *
     * @param userId the user id
     * @param roleId the role id
     * @param processTypeKey the process type key
     * @throws ResourceDelegatorException the resource delegator exception
     */
    public void addResourceToRole(String userId, String roleId,	String processTypeKey)
    throws ResourceDelegatorException {

	OrgResourceDeployerHome orgResourceDeployerHome = null;
	OrgResourceDeployer ord = null;

	Set newRoles = new HashSet();
	newRoles.add(roleId);
	try {
	    orgResourceDeployerHome = getOrgResourceDeployerHome();
	    ord = orgResourceDeployerHome.create();
	} catch (Exception InitExec) {
	    String msg = "Failed to create OrgResourceDeployer : ";
	    log.error(msg + " : " +InitExec);
	    throw new ResourceDelegatorException(msg + InitExec);
	}

	boolean userRoleMatch = false;
	try {
	    // Lets check if role resource map exists
	    userRoleMatch = ord.doesRoleResourceMapExist(userId, roleId, processTypeKey);

	    if (userRoleMatch)
		return;
	    else {
		ord.addRoleToResource(userId, newRoles, processTypeKey);
	    }
	} catch (Exception WPEExec) {
	    String msg = "ResourceDelegator.addResource() - Failed to validate User existance : ";
	    log.error(msg + " : " +WPEExec);
	    throw new ResourceDelegatorException(msg + WPEExec);
	}
    }

    /**
     * Removes the role from resource.
     *
     * @param userId the user id
     * @param processTypeKey the process type key
     * @throws ResourceDelegatorException the resource delegator exception
     */
    public void removeRoleFromResource(String userId, String processTypeKey)
    throws ResourceDelegatorException {

	OrgResourceDeployerHome orgResourceDeployerHome = null;
	OrgResourceDeployer ord = null;

	Set oldRoles = new HashSet();
	try {
	    orgResourceDeployerHome = getOrgResourceDeployerHome();
	    ord = orgResourceDeployerHome.create();
	    oldRoles = ord.getRolesForResourceByProcessType(userId, processTypeKey);
	} catch (Exception InitExec) {
	    String msg = "ResourceDelegator.updateResource() - Failed to create OrgResourceDeployer : ";
	    log.error(msg + " : " +InitExec);
	    throw new ResourceDelegatorException(msg + InitExec);
	}

	// Remove the OLD Roles and add New roles
	try {

	    ord.removeRoleFromResource(userId, oldRoles, processTypeKey);
	} catch (Exception WPEExec) {
	    String msg = "ResourceDelegator.updateResource() - Failed to Update Resource : ";
	    log.error(msg + " : " +WPEExec);
	    throw new ResourceDelegatorException(msg + WPEExec);
	}
    }


    /**
     * Delete resource.
     *
     * @param userId the user id
     * @throws ResourceDelegatorException the resource delegator exception
     */
    public void deleteResource(String userId)
    throws ResourceDelegatorException {
	OrgResourceDeployerHome orgResourceDeployerHome = null;
	OrgResourceDeployer ord = null;

	Set positionSet = new HashSet();
	positionSet.add(C3parProperties.WPE_POSITION);

	try {
	    orgResourceDeployerHome = getOrgResourceDeployerHome();
	    ord = orgResourceDeployerHome.create();

	    if(ord.doesResourceExist(userId)) {
		ord.removePositionsFromResource(userId, C3parProperties.WPE_ORGUNIT, positionSet);
		ord.removeResource(userId);
	    }
	} catch (Exception InitExec) {
	    String msg = "ResourceDelegator.deleteResource() - Failed to remove resource ";
	    throw new ResourceDelegatorException(msg + InitExec);
	}
    }

    /**
     * Does resource exists.
     *
     * @param userId the user id
     * @return true, if successful
     * @throws ResourceDelegatorException the resource delegator exception
     */
    public boolean doesResourceExists(String userId) throws ResourceDelegatorException {

	boolean flag = false;
	OrgResourceDeployerHome orgResourceDeployerHome = null;
	OrgResourceDeployer ord = null;

	try {
	    orgResourceDeployerHome = getOrgResourceDeployerHome();
	    ord = orgResourceDeployerHome.create();

	    if(ord.doesResourceExist(userId)) {
		flag = true;
	    }
	} catch (Exception InitExec) {
	    String msg = "ResourceDelegator.doesResourceExists() - Failed to find  if ResourceExist";
	    throw new ResourceDelegatorException(msg + InitExec);
	}

	return flag;
    }

    /**
     * Gets the org resource deployer home.
     *
     * @return the org resource deployer home
     * @throws ResourceDelegatorException the resource delegator exception
     */
    public OrgResourceDeployerHome getOrgResourceDeployerHome()
    throws ResourceDelegatorException {

	OrgResourceDeployerHome orgResDeplHome = null;

	try {
	    if (cacheHome.containsKey(C3parProperties.WPE_ORGJNDI)) {
		orgResDeplHome = (OrgResourceDeployerHome) cacheHome.get(C3parProperties.WPE_ORGJNDI);
	    } else {
		Properties processHome_properties = new Properties();
		processHome_properties.put(Context.INITIAL_CONTEXT_FACTORY, C3parProperties.WPE_FACTORY);
		processHome_properties.put(Context.PROVIDER_URL, C3parProperties.WPE_HOST);
		Context ctx = new InitialContext(processHome_properties);
		Object objref = ctx.lookup(C3parProperties.WPE_ORGJNDI);
		Object obj = PortableRemoteObject.narrow(objref, OrgResourceDeployerHome.class);
		orgResDeplHome = (OrgResourceDeployerHome) obj;
		cacheHome.put(C3parProperties.WPE_ORGJNDI, orgResDeplHome);
		ctx.close();
	    }

	} catch (NamingException nameExc) {
	    log.error("failed to find orgResourceDeployerHome NamingException : " + nameExc);
	    throw new ResourceDelegatorException(nameExc.toString());
	} catch (Exception exec) {
	    log.error("failed to find orgResourceDeployerHome: " + exec);
	    throw new ResourceDelegatorException(exec.toString());
	}

	return orgResDeplHome;
    }

}