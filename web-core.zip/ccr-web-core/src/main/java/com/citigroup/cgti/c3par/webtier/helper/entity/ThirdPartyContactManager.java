package com.citigroup.cgti.c3par.webtier.helper.entity;

import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.citigroup.cgti.c3par.model.*;


/**
 * The Class ThirdPartyContactManager.
 */
public class ThirdPartyContactManager
{
    //=======================================================================================
    /**
     * Update.
     *
     * @param entity the entity
     * @param dbs the dbs
     * @return the long
     * @throws DatabaseException the database exception
     */
    static public Long update(ThirdPartyContactEntity entity, C3parSession dbs) throws DatabaseException
    {
	Long id = null;
	if(entity != null)
	{
	    ThirdPartyContactDAO dao = new ThirdPartyContactDAO(dbs);
	    dao.update(entity, dbs.getArchiver());
	    id = entity.getId();
	}
	return id;
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void delete(String id, C3parSession dbs) throws DatabaseException
    {
	if(id != null && id.length() > 0)
	{
	    delete(Long.valueOf(id), dbs);
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void delete(Long id, C3parSession dbs) throws DatabaseException
    {
	if(id != null)
	{
	    ThirdPartyContactEntity entity = get(id);
	    delete(entity, dbs);
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param entity the entity
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void delete(ThirdPartyContactEntity entity, C3parSession dbs) throws DatabaseException
    {
	if(entity != null)
	{
	    ThirdPartyContactDAO dao = new ThirdPartyContactDAO(dbs);
	    dao.delete(entity, dbs.getArchiver());
	}
    }

    //=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @return the third party contact entity
     * @throws DatabaseException the database exception
     */
    static public ThirdPartyContactEntity get(String id) throws DatabaseException
    {
	ThirdPartyContactEntity	entity = null;
	if(id != null && id.length() > 0)
	{
	    entity = get(Long.valueOf(id));
	}
	return entity; 
    }

    //=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @return the third party contact entity
     * @throws DatabaseException the database exception
     */
    static public ThirdPartyContactEntity get(Long id) throws DatabaseException
    {
	ThirdPartyContactEntity entity = null;
	if(id != null)
	{
	    ThirdPartyContactDAO dao = new ThirdPartyContactDAO(new C3parSession());
	    entity = dao.get(id);
	}
	return entity;	
    }
    //=======================================================================================
    /**
     * Insert.
     *
     * @param entity the entity
     * @return the long
     * @throws DatabaseException the database exception
     */
    static public Long insert(ThirdPartyContactEntity entity) throws DatabaseException
    {
	Long id = null;
	if(entity != null)
	{
	    ThirdPartyContactDAO dao = new ThirdPartyContactDAO(new C3parSession());
	    dao.insert(entity);
	    id = entity.getId();
	}
	return id;
    }

    /**
     * Creates the.
     *
     * @param firstName the first name
     * @param lastName the last name
     * @param cellPhone the cell phone
     * @param email the email
     * @param phone the phone
     * @param pager the pager
     * @return the third party contact entity
     */
    static public ThirdPartyContactEntity create(String firstName, String lastName,
	    String cellPhone, String email,
	    String phone, String pager)
    {
	ThirdPartyContactEntity entity = new ThirdPartyContactEntity();

	entity.setCellPhone(cellPhone);
	entity.setEmail(email);
	entity.setFirstName(firstName);
	entity.setLastName(lastName);;
	entity.setPhone(phone);
	entity.setPager(pager);

	// TODO Location

	return entity;
    }
}


