package com.citigroup.cgti.ccr.workflow.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.rel.SearchRelationshipImpl;
import com.citigroup.cgti.c3par.bpm.ejb.search.ISearchProcess;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.Process;
import com.citigroup.cgti.ccr.workflow.CCRWorkflowConstants;
import com.citigroup.cgti.ccr.workflow.domain.JBPMTaskRef;
import com.citigroup.cgti.ccr.workflow.domain.MigratedRecordsHistory;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;
import com.mentisys.dao.DatabaseException;

@Transactional
public class MigrationServiceScheduler {
	private static Logger log = Logger
			.getLogger(MigrationServiceScheduler.class);
	@Autowired
	MigrationService migrationServiceImpl;
	
	@Autowired
	private ISearchProcess searchProcess;
	
	@Autowired
	private SearchRelationshipImpl searchRelationshipImpl;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	WorkflowUtil workflowUtil;
	
    @Async
	public void startMigration() {
		log.info("Entering MigrationServiceScheduler startMigration. --START");
		StopWatch watch = new StopWatch();
		watch.start();
		try {
		//	migrationServiceImpl.migrateConnectionToActvity(null);
			log.debug("migrateConnectionToActvity Start");
			try {
				//One Activity --Start
			    for(String activityCode:CCRWorkflowConstants.SINGLE_ACTIVITIES){
			    	 this.startMigration(activityCode,ActivityDataDTO.STATUS_SCHEDULED);
				}
				for(String activityCode:CCRWorkflowConstants.IMPL_ACTIVITIES){
					this.startMigration(activityCode,ActivityDataDTO.STATUS_SCHEDULED);
				}
				for(String activityCode:CCRWorkflowConstants.PROVIDED_INFO_ACTIVITIES){
					this.startMigration(activityCode,ActivityDataDTO.STATUS_SCHEDULED);
				}
				for(String activityCode:CCRWorkflowConstants.LOGGING_QUEUE_ACTIVITIES){
					this.startMigration(activityCode,ActivityDataDTO.STATUS_SCHEDULED);
				}
				for(String activityCode:CCRWorkflowConstants.ACV_ACTIVITIES){
					this.startMigration(activityCode,ActivityDataDTO.STATUS_SCHEDULED);
				}
				for(String activityCode:CCRWorkflowConstants.INCOMPLETION_ACTIVITIES){
					this.startMigration("bus_jus",ActivityDataDTO.STATUS_EXPIRED);
				}
				for(String activityCode:CCRWorkflowConstants.MOVED_TO_PREVIOUS_ACTIVITIES){
					this.startMigration(activityCode,ActivityDataDTO.STATUS_SCHEDULED);
				}
				//One Activity --End
			} catch (Exception e) {
				e.printStackTrace();
				log.error("Error"+e.getMessage());
			}
			log.debug("migrateConnectionToActvity End");
		} catch (Exception e) {
			log.error("Exception in MigrationServiceScheduler :", e);
		}
		watch.stop();
		log.debug("Total execution time to run the rules: "
				+ watch.getTotalTimeMillis()/1000);
		log.info("Entering MigrationServiceScheduler startMigration. --END");
	}
	public void startMigration(String activityCode,String activityStatus) throws DatabaseException {
		log.debug("Started Migration for Activity Code is "+activityCode);
		System.out.println("Started Migration for Activity Code is "+activityCode);
		List<Object> processIds=searchProcess.getScheduledProcessByAcitivityCode(activityCode, 0,activityStatus);
		log.debug("Total Size Before Filtering"+processIds.size());
		List<Object> obpmRecords=filerMigratedRecords(processIds);
		if(CollectionUtils.isEmpty(obpmRecords)){
			return;
		}
		log.debug("Total Size After Filtering"+obpmRecords.size());
		System.out.println("Total Size After Filtering"+obpmRecords.size());
		Session session = this.sessionFactory.getCurrentSession();
		MigratedRecordsHistory migrationRecordHistory=null;
			if(obpmRecords!=null){
			for(Object processObj:obpmRecords){
				try{
				    Process proces=(Process)processObj;
					migrationRecordHistory=new MigratedRecordsHistory();
					migrationRecordHistory.setProcessId(proces.getId());
					migrationRecordHistory.setTiRequestId(proces.getTirequestid());
					migrationRecordHistory.setObpmSOEID(proces.getParticipant());
					migrationRecordHistory.setStartDate(new DateTime().toDate());
					migrationRecordHistory.setObpmActivityCode(activityCode);
					log.debug("Migration Start"+proces.getId());
					System.out.println("Need to migrate"+proces.getId());
					migrationServiceImpl.migrateConnection(proces.getId(), "SYSTEM",activityStatus);
					migrationRecordHistory.setEndData(new DateTime().toDate());
					migrationRecordHistory.setMigrated("Yes");
					JBPMTaskRef jbpmTaskRef=workflowUtil.getLatestTaskRef(proces.getTirequestid());
					if(jbpmTaskRef!=null){
						migrationRecordHistory.setJpbmActivityCode(jbpmTaskRef.getActivityName());
						migrationRecordHistory.setJbpmSOEID(jbpmTaskRef.getTaskParticipant());
					}
					log.debug("Migration End"+proces.getId());
				}catch(Exception ex){
					System.out.println("Error Occured while processing request"+processObj);
					System.out.println("Exception occured"+ex);
					if(migrationRecordHistory!=null){
					migrationRecordHistory.setMigrated("No");
					migrationRecordHistory.setEndData(new DateTime().toDate());
					migrationRecordHistory.setErrorLog(ex.getMessage());
					}
				}finally{
					if(migrationRecordHistory!=null){
					session.save(migrationRecordHistory);
					session.flush();
					}
				}
			}
			}
	}
	private List<Object> filerMigratedRecords(List<Object> processIds){
		Session session = this.sessionFactory.getCurrentSession();
		String hql ="SELECT taskRef.connectionId FROM JBPMTaskRef taskRef";
		Query query = session.createQuery(hql);
        List<Long> list =(List<Long>) query.list();
        List<Object> obpmRecords=new ArrayList<Object>();
        Query migrationQuery =session.createSQLQuery("SELECT migration.CONNECTION_ID FROM MIGRATE_RECORDS migration where migration.MIGRATED = 'N'");
        List<BigDecimal> manualMigartionLst =(List<BigDecimal>) migrationQuery.list();
        if(CollectionUtils.isEmpty(manualMigartionLst)){
        	return null;
        }
        if((list!=null && !CollectionUtils.isEmpty(list)) ||  (manualMigartionLst!=null && !CollectionUtils.isEmpty(manualMigartionLst))){
        	filterMigratedRecords(processIds, list, obpmRecords,manualMigartionLst);
        }
       if(!CollectionUtils.isEmpty(obpmRecords)) {
    	   return obpmRecords;
       }else{
    	   return null;
       }
	}
	private void filterMigratedRecords(List<Object> processIds,
			List<Long> alaredyMigartedlist, List<Object> obpmRecords,List<BigDecimal> manualMigartionLst ) {
		for(Object processObj:processIds){
			try{
			Process proces=(Process)processObj;
			System.out.println("Process ID"+proces.getId());
			log.debug("Process ID"+proces.getId());
			boolean migrated=false;
			for(Long migrateID:alaredyMigartedlist){
				//TODO:will remove this logic 
				if(migrateID == proces.getId()){
					migrated=true;
					break;
				}
			}
			//if(alaredyMigartedlist.contains(proces.getId())){
			if(migrated){
				continue;
			}
			boolean mannualBatch=false;
			for(BigDecimal migrateID:manualMigartionLst){
				//TODO:will remove this logic
				if(migrateID.longValue() == proces.getId()){
					mannualBatch=true;
					break;
				}
			}
			//if(manualMigartionLst.contains(proces.getId())){
			if(mannualBatch){
			    obpmRecords.add(proces);
			}
			}catch(Exception e){
				log.error("error in filerMigratedRecords"+e.getMessage());
				e.printStackTrace();
			}
		}
	}
	
	@Async
	public void migrateConnection(String activityCode) {
		try {
			log.debug("MigrationServiceScheduler :: migrateConnection for activityCode : "+activityCode+" Starts ");			
			    this.startMigration(activityCode,ActivityDataDTO.STATUS_SCHEDULED);
		} catch (Exception e) {
			log.error("Exception in migrateConnection :", e);
		}
		log.info("MigrationServiceScheduler :: migrateConnection for activityCode : "+activityCode+" Ends ");
	}
	
}
