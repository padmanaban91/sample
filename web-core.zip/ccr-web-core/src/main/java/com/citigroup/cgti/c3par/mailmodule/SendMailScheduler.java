package com.citigroup.cgti.c3par.mailmodule;

import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.ACTIVATION_EXPIRATION_REMINDER_30DAYS;
import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.ACTIVATION_EXPIRATION_REMINDER_7DAYS;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set; 

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule;
import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.domain.C3PARUser;
import com.citigroup.cgti.c3par.domain.ACVSummaryEmailUserVO;
import com.citigroup.cgti.c3par.domain.SupervisorEmail;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.mentisys.dao.DatabaseException;

/**
 * The Class SendMailScheduler.
 */
@SuppressWarnings({"unchecked","unused"})
public class SendMailScheduler {

    /** The mail module impl. */
    private IMailModule mailModuleImpl;
    private JdbcTemplate jdbcTemplate;
    private CCRQueries ccrQueries;

    private static final String ENTER = " Enter ";
    private static final String EXIT = " Exit ";
    private static final int SQLPARAMSIZE = 1000;
    
    
    /*
     * Instantiates a new send mail scheduler.
     */
    public SendMailScheduler() { }

    /** The log. */
    private static Logger log = Logger.getLogger(SendMailScheduler.class);

    /** The send scheduled email flag. */
    private static final String sendScheduledEmailFlag = System.getProperty("sendScheduledEmail.flag");

    
    
    public void invokeOneWeekNTPSchedules(){
    	log.debug ("Starting to invokeOneWeekNTPSchedules for Job: invokeOneWeekNTPSchedules " + ENTER);
    	 
    	
    	if("true".equalsIgnoreCase(sendScheduledEmailFlag)){
    		
    		try {
    			mailModuleImpl.sendMailToNonThirdPartyACV ( getAllNonThirdPartyACVConnections() );
    		    }
    		catch (Exception e) {
    			      log.error ("NonThirdPartyACV  mail scheduler failed "); 
    		       }
    		}
    	
    	log.debug ("invokeOneWeekNTPSchedules for Job: invokeOneWeekNTPSchedules " + EXIT);
    }
    
    
    private HashMap <String,ACVSummaryEmailUserVO> getAllNonThirdPartyACVConnections () {
    	log.debug ("Starting to getExpiredConnectionIds for Job: getExpiredConnectionIds " + ENTER);
    	
    	String queryToExecute = ccrQueries.getQueryByName(QueryConstants.NONTHIRDPARTYACVCONNECTIONS);
    	/*final StringBuilder sql = new StringBuilder (); 
    	 sql.append(" SELECT DISTINCT TP.ID   FROM  TI_PROCESS TP ");
    	 sql.append(" JOIN TI_REQUEST TR ON TR.PROCESS_ID=TP.ID ");
    	 sql.append(" JOIN TI_REQUEST_TYPE TRT ON TRT.ID=TR.TI_REQUEST_TYPE_ID ");
    	 sql.append(" JOIN TI_ACTIVITY_TRAIL TAT ON TR.ID=TAT.TI_REQUEST_ID ");
    	 sql.append(" JOIN RELATIONSHIP RS ON RS.ID = TP.ID WHERE ");
    	 sql.append(" TR.VERSION_NUMBER =TP.VERSION_NUMBER AND ");
    	 sql.append(" TRT.REQUEST_TYPE='ACV' AND ");
    	 sql.append(" TAT.ACTIVITY_STATUS = 'SCHEDULED' AND ");
    	 sql.append(" TP.ACTIVATION_EXP_DATE < SYSDATE AND ");
    	 sql.append(" RS.RELATIONSHIP_TYPE != 'THIRD_PARTY' AND " );
    	 sql.append(" TO_CHAR(TP.ACTIVATION_EXP_DATE,'DD/MM/RRRR') != TO_CHAR(SYSDATE,'DD/MM/RRRR')  ");
    			    */
    				
    	 log.debug ("Executing Query " + queryToExecute );
    	 
    	 SqlRowSet rs  =  jdbcTemplate.queryForRowSet(queryToExecute.toString());
    	 List<String> allProcessId = new ArrayList<String>();
    	
    	 while ( rs.next() ) {
    		 allProcessId.add( rs.getString(1) );
    		 log.debug ("Process ID " + rs.getString(1) );
    	  }
    	
    	 log.debug ("Done getExpiredConnectionIds for Job: getExpiredConnectionIds " + EXIT +"count"+allProcessId);
    	 return  getEmailList (allProcessId);
    }
    	
    private HashMap <String,ACVSummaryEmailUserVO> getEmailList (List<String> allProcessId) {
    	HashMap <String,ACVSummaryEmailUserVO> emailList = new HashMap <String,ACVSummaryEmailUserVO>();
     	List<String> roleNames = null;
    	List<String> processIds = null;
    	ACVSummaryEmailUserVO summaryEMailVO = null; 
    	String soeId = null; 
    	
    	log.debug ("Starting to getEmailList for Job: getEmailList " + ENTER);
    	String queryToExecute = ccrQueries.getQueryByName(QueryConstants.EMAILCONTACTSFORCONNECTIONID);
    	/*final StringBuilder sql = new StringBuilder (); 
    	sql.append(" select cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME,cc.EMAIL,RR.NAME  ");
    	sql.append(" from ti_request_planning_xref trpx, ti_request tr, con_req_citi_contact_xref crccx,planning p,citi_contact cc,role rr  ");
    	sql.append(" where tr.process_id = ? and trpx.ti_request_id = tr.id  ");
    	sql.append(" and tr.id = (select max(id) from ti_request where process_id = ?)  ");
    	sql.append(" and trpx.planning_id = p.id and crccx.request_id = p.id and crccx.citi_contact_id = cc.id and crccx.primary_contact = 'Y'  ");
    	sql.append(" and crccx.role_id=rr.id and crccx.notify_contact = 1");
    	sql.append(" UNION ");
    	sql.append(" select cc.SSO_ID,cc.FIRST_NAME,cc.LAST_NAME,cc.EMAIL,RR.NAME ");
    	sql.append(" from ti_request_planning_xref trpx, ti_request tr, CON_REQ_CIT_RQCON_XREF crcrx,planning p,citi_contact cc,role rr ");
    	sql.append(" where tr.process_id = ? and trpx.ti_request_id = tr.id ");
    	sql.append(" and tr.id = (select max(id) from ti_request where process_id = ?) ");
    	sql.append(" and trpx.planning_id = p.id and crcrx.request_id = p.id and crcrx.citi_contact_id = cc.id and crcrx.primary_contact = 'Y' ");
    	sql.append(" and crcrx.role_id=rr.id and crcrx.notify_contact = 1"); */
    	
    	log.debug ("Executing Query " + queryToExecute );
    	
    	 
    	 for (String processId:allProcessId) {
    		 SqlRowSet rs  =  jdbcTemplate.queryForRowSet(queryToExecute,new Object [] {processId,processId,processId,processId});
   	      
 	    	while ( rs.next() ) {
 	    		soeId = rs.getString(1);
 	    	if(soeId != null && !soeId.isEmpty()){
 	    		summaryEMailVO = emailList.get(soeId);
 	    		 
 	    		if (summaryEMailVO == null) {
 	    			log.debug ("Adding New SOEID: " + soeId );
 	    			summaryEMailVO = new ACVSummaryEmailUserVO (soeId,rs.getString(2),rs.getString(3),rs.getString(4),processId,rs.getString(5),rs.getString(6));
 	    			summaryEMailVO.setProcessIdVal(processId);
 	    		  }
 	    		else {
 	    		 	log.debug ("Found Existing SOEID: " + soeId );
 	    		 	summaryEMailVO.getConnRoles().add (new ACVSummaryEmailUserVO.ConnectionRole(processId,rs.getString(5),rs.getString(6)));
 	    		 	summaryEMailVO.setProcessIdVal(processId);
 	    		}	
 	    		emailList.put (soeId, summaryEMailVO );
 	    		}
 	    	}
    	}
    	log.debug ("getEmailList for Job: getExpiredConnectionIds " + EXIT);
    	return emailList;
    }

   
   
 /*   
    *//**
     * Send 7 Day activation expiration reminder mail.
     *//*
    private void send7DaysNonTPActivationExpirationReminderMail(){
		log.debug("send7DaysActivationExpirationReminderMail " + ENTER);
		
		try {
		    List requestIds = getQualifiedIdsFor7DaysActivationExpiration(false);
		    log.debug("SendMailScheduler:send7DaysActivationExpirationReminderMail: TOTAL Request Ids received: "+ requestIds.size());
		  
		    if (requestIds.size() > 0) 
		    	mailModuleImpl.sendActivationExpirationNotification(requestIds, ACTIVATION_EXPIRATION_REMINDER_7DAYS);
		    else
		    	log.debug("No Request ID's found for send7DaysActivationExpirationReminderMail " );
		} catch (Exception e){
		    log.error("Exception in send7DaysActivationExpirationReminderMail:: "+e.getMessage());
		}
		log.debug("send7DaysActivationExpirationReminderMail " + EXIT);
    }*/
    
    /**
	 * Invoke schedules.
	 *
	 */
    public void invokeSchedules(){
	log.debug("Starting to invokeSchedules for Job: scheduleAndACVExpirationMailJob " + ENTER);
	log.debug("EMail Flag: " + sendScheduledEmailFlag);
	 
	if("true".equalsIgnoreCase(sendScheduledEmailFlag)){
		log.debug("Begining to start Job scheduleAndACVExpirationMailJob ");
	    send14DayScheduledMail();
	    send7DayScheduledMail();
	    send1DayScheduledMail();
	    send7DaysActivationExpirationReminderMail();
	    send30DaysActivationExpirationReminderMail();
	} else 
	    log.debug("SendMailScheduler:invokeSchedules: NOT attempting to check/send scheduled expiration emails as the sendScheduled.email property is not set to true");
	

	 log.debug("Completed invokeSchedules " + EXIT);
    }

            
    
    /**
     * Send14 day scheduled mail.
     */
    private void send14DayScheduledMail (){
	
    	log.debug("send14DayScheduledMail " + ENTER);
	
	 try {
		 List requestIds = getQualifiedRequestIds(14,"");
		 List mailedRequestIds = null;
	     log.debug("Total Request ID's received for 14 Day Scheduled Mail:  " + requestIds.size() );

	    
	    if (requestIds.size() > 0) {
	    	mailedRequestIds = mailModuleImpl.sendScheduledNotification(requestIds);
	    	log.debug("Completed Sending Mails for 14 Day Scheduled Mail for Request ID's: " + mailedRequestIds.size());

	    	 if (mailedRequestIds.size() > 0)
	    		 updateScheduledEmailFlag(mailedRequestIds,"14");
	    	log.debug("Completed updating EMail Flag for 14 Day Scheduled Mail" );
	    }
	    else
	    	log.debug("No Request ID's found for 14 Day Scheduled Mail " );
	 
	   } catch (Exception e){
	    log.error(" Exception in send14DayScheduledMail ",e);
   	  } 
		log.debug("send14DayScheduledMail " + EXIT);
    }

    /**
     * Send7 day scheduled mail.
     */
    private void send7DayScheduledMail (){
    	log.debug("send7DayScheduledMail " + ENTER);
	
	try {
	    List requestIds = getQualifiedRequestIds(7,"14");
	    List mailedRequestIds = null;
	    log.debug("Total Request ID's received for 7 Day Scheduled Mail:  " + requestIds.size() );

	    if (requestIds.size() > 0) {
	    	mailedRequestIds = mailModuleImpl.sendScheduledNotification(requestIds);
	    	log.debug("Completed Sending Mails for 7 Day Scheduled Mail for Request ID's: " + mailedRequestIds.size());

		 log.debug("Completed Sending Mails for  7 Day Scheduled Mail " );
		
		 if (mailedRequestIds.size() > 0)
		  updateScheduledEmailFlag(mailedRequestIds,"7");
		log.debug("Completed updating EMail Flag for 7 Day Scheduled Mail" ); 
	    }
	    else
	    	log.debug("No Request ID's found for 7 Day Scheduled Mail " );
	    
		} catch (Exception e){
			log.error(" Exception in send7DayScheduledMail ",e);
		}
		log.debug("send7DayScheduledMail " + EXIT);
    }

    /**
     * Send1 day scheduled mail.
     */
    private void send1DayScheduledMail (){
    	log.debug("send1DayScheduledMail " + ENTER);
    		
	try {
	    List requestIds = getQualifiedRequestIds(2,"7");
	    List mailedRequestIds = null;
	    log.debug("Total Request ID's received for 1 Day Scheduled Mail:  " + requestIds.size() );
	 
	    if (requestIds.size() > 0) {
	    	mailedRequestIds = mailModuleImpl.sendScheduledNotification(requestIds);
	    	log.debug("Completed Sending Mails for 7 Day Scheduled Mail for Request ID's: " + mailedRequestIds.size());
		
	    	if (mailedRequestIds.size() > 0)
	    		updateScheduledEmailFlag(mailedRequestIds,"2");
		log.debug("Completed updating EMail Flag for 1 Day Scheduled Mail" );
	    }
		else
	    	log.debug("No Request ID's found for 1 Day Scheduled Mail " );
		
	} catch (Exception e){
		log.error(" Exception in send1DayScheduledMail ",e);
	}
	log.debug("send1DayScheduledMail " + EXIT);
    }

    /**
     * Send 7 Day activation expiration reminder mail.
     */
    private void send7DaysActivationExpirationReminderMail(){
		log.debug("send7DaysActivationExpirationReminderMail " + ENTER);
		
		try {
		    List requestIds = getQualifiedIdsFor7DaysActivationExpiration();
		    log.debug("SendMailScheduler:send7DaysActivationExpirationReminderMail: TOTAL Request Ids received: "+ requestIds.size());
		  
		    if (requestIds.size() > 0) 
		    	mailModuleImpl.sendActivationExpirationNotification(requestIds, ACTIVATION_EXPIRATION_REMINDER_7DAYS);
		    else
		    	log.debug("No Request ID's found for send7DaysActivationExpirationReminderMail " );
		} catch (Exception e){
		    log.error("Exception in send7DaysActivationExpirationReminderMail:: "+e.getMessage());
		}
		log.debug("send7DaysActivationExpirationReminderMail " + EXIT);
    }

    /**
     * Send 30 Day activation expiration reminder mail.
     */
    private void send30DaysActivationExpirationReminderMail(){
    	log.debug("send30DaysActivationExpirationReminderMail " + ENTER);
		try{
			List requestIds = getQualifiedIdsFor30DaysActivationExpiration();
			log.debug("SendMailScheduler: send30DaysActivationExpirationReminderMail : TOTAL Request Ids received:"+requestIds.size());
	 
			if (requestIds.size() > 0) 	
				mailModuleImpl.sendActivationExpirationNotification(requestIds,ACTIVATION_EXPIRATION_REMINDER_30DAYS);
			 else
			    	log.debug("No Request ID's found for send30DaysActivationExpirationReminderMail " );
		
		} catch (Exception e){
		    log.error("Exception in send30DaysActivationExpirationReminderMail:: "+e.getMessage());
		}
		log.debug("send30DaysActivationExpirationReminderMail " + EXIT);
    }
    
    /* Invoke reminder schedule.
     */
    public void invokeReminderSchedule() {
    	log.debug("invokeReminderSchedule for Job: approvalRemainderMailJob " + ENTER);
    	
    	
    	if("true".equalsIgnoreCase(sendScheduledEmailFlag)) {
    		log.debug (" Beginning Job approvalRemainderMailJob ");
    		sendUnApprovedMail();
    	}
    	 else 
    		log.debug("SendMailScheduler:invokeReminderSchedule: NOT attempting to check/send scheduled expiration emails as the sendScheduled.email property is not set to true");
	 
    	log.debug("invokeReminderSchedule " + EXIT);
    }
    
     
    /**
     * Invoke Expiration reminder schedule 
     */
    public void invokeReminderScheduleForExpiraion() {
    	log.debug("invokeReminderScheduleForExpiraion for Job: activityExpirationRemainderMailJob " + ENTER);
	
    	if("true".equalsIgnoreCase(sendScheduledEmailFlag)) {
    		log.debug (" Beginning Job activityExpirationRemainderMailJob ");
    		sendExpirationMail();
    	}
    	 else 
    		log.debug("SendMailScheduler:invokeReminderSchedule: NOT attempting to check/send scheduled expiration emails as the sendScheduled.email property is not set to true");
    	 
  	  log.debug("invokeReminderScheduleForExpiraion " + EXIT);
    }

    /**
     * Send email faf queue alert.
     */
    /*public void sendEmailFAFQueueAlert(){
    	log.debug("sendEmailFAFQueueAlert" + ENTER);
	
	if("true".equalsIgnoreCase(sendScheduledEmailFlag)){
	 
	    try {
		String  sql= " select SESSION_ID from faf_queue_con_requests where started_time < (sysdate - 15/(24*60)) and completed_time is null and session_id is not null " ;
		String sessionId= null;
		SqlRowSet rs = jdbcTemplate.queryForRowSet(sql);
	
		while (rs.next()){
		    if(rs.getString(1)!= null)
			sessionId = rs.getString(1);
		    break;
		}
		
		if(sessionId != null ){
		    Util util=new Util();
		    ArrayList fafReqs = new ArrayList();
		    fafReqs=util.getQueuedFAFRequests();
		    Thread fafCalculationQueueThread = new Thread(runFAFCalculationThread);
		    fafCalculationQueueThread.start();
		    mailModuleImpl.sendEmailFAFQueueAlert(fafReqs);
		  }
	    }
	    catch (Exception e) {
		log.error(e);
	    } 
 
	} else {
	    log.debug("SendMailScheduler:sendEmailFAFQueueAlert: NOT attempting to check/send FAF Alert Email as sendScheduled.email property is not set to true");
	}
	log.debug("sendEmailFAFQueueAlert" + EXIT);
    }*/

    
    /**
     * Gets the qualified request ids.
     * @param days the days
     * @param scheduledEmailFlag the scheduled email flag
     * @return the qualified request ids
     */
    private List getQualifiedRequestIds(int days,String scheduledEmailFlag){
	log.debug("SendMailScheduler:getQualifiedRequestIds:: Entered");
	 
	String scheduledEmailFlagValue;
	if(scheduledEmailFlag.equalsIgnoreCase("")){
	    scheduledEmailFlagValue = " is null ";
	} else {
	    scheduledEmailFlagValue = " = '"+scheduledEmailFlag+"'";
	}

	int excludedays = 0;
	
	if(days == 14){
	    excludedays = 7;
	} else if (days == 7){
	    excludedays = 2;
	} else {
	    excludedays = 0;
	}
	StringBuilder sql = new StringBuilder();
	sql.append(" select DISTINCT tr.id from ti_request tr ");
	sql.append(" join ti_activity_trail tat on tr.id = tat.ti_request_id join ti_task_type ttt on ttt.id = tat.activity_id ");
	sql.append(" where (tr.request_deadline - sysdate) < ?  and (tr.request_deadline - sysdate) >= ? and tr.request_deadline > sysdate ");
	sql.append(" and (tr.SCHEDULED_EMAIL_FLAG is null OR tr.SCHEDULED_EMAIL_FLAG "+scheduledEmailFlagValue+") and tat.activity_status = 'SCHEDULED' ");
	sql.append(" and ttt.task_code not in ('ver_sow','acv_exp','oa_log') ");
		
		SqlRowSet rs  =  jdbcTemplate.queryForRowSet(sql.toString(),new Object[] {days,excludedays});
		List<String> requestIds = new ArrayList();
	
		while (rs.next()) 
			requestIds.add(rs.getString(1));
	
	 
	log.debug("SendMailScheduler:getQualifiedRequestIds:: Exited");
	return requestIds;
    }

    /**
     * Send Unapproved mail.
     * 
     */
    private void sendUnApprovedMail(){
	log.debug("SendMailScheduler:sendUnApprovedMail:: Entered");
	
	StringBuilder sql = new StringBuilder();
	sql.append("SELECT DISTINCT TR.ID FROM ");
	sql.append("TI_REQUEST TR ");
	sql.append("JOIN TI_ACTIVITY_TRAIL TAT ON TR.ID=TAT.TI_REQUEST_ID ");
	sql.append("JOIN TI_TASK_TYPE TTT ON TTT.ID = TAT.ACTIVITY_ID  ");
	sql.append("JOIN GENERIC_LOOKUP_DEFS GLD  ON GLD.NAME = 'NOTIFICATION_REMAINDER_TASKS' ");
	sql.append("JOIN GENERIC_LOOKUP GL ON GLD.ID= GL.DEFINITION_ID ");
	sql.append("JOIN GENERIC_LOOKUP_DEFS GLD2  ON GLD2.NAME = 'APPROVAL_REMAINDER_DAYS' ");
	sql.append("JOIN GENERIC_LOOKUP GL2 ON GLD2.ID= GL2.DEFINITION_ID ");
	sql.append("WHERE ");
	sql.append("TAT.ACTIVITY_STATUS = 'SCHEDULED' AND ");
	sql.append("GL.VALUE1 = TTT.TASK_CODE AND ");
	sql.append("TTT.TASK_CODE NOT IN ('oa_log') AND ");
	sql.append("REMAINDER(FLOOR(SYSDATE-TRUNC(TAT.ACTIVITY_STARTDATE)),GL2.VALUE2)=0 ");
	sql.append("AND FLOOR(SYSDATE-TRUNC(TAT.ACTIVITY_STARTDATE)) != 0 ");

	Map data = new HashMap();
	List dataList = null;
	log.debug("SendMailScheduler:sendUnApprovedMail:: SQL::"+sql.toString());
	
	
	try {
			SqlRowSet rs  =  jdbcTemplate.queryForRowSet(sql.toString());
			List<String> requestIds = new ArrayList();
			
			while (rs.next()) 
				requestIds.add(rs.getString(1));
			
				mailModuleImpl.sendScheduledNotification(requestIds);
				log.debug("SendMailScheduler:sendUnApprovedMail: TOTAL Request Ids received:"+requestIds.size());
		
	      
	    } catch (Exception e) {
		log.error(e);
	    }
		    log.debug("SendMailScheduler:sendUnApprovedMail:: Exited");
	   }
    
        
    /**
     * Send un approved mail.
     *
     */
    private void sendExpirationMail(){
		log.debug("SendMailScheduler:sendExpirationMail:: Entered");
	
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT  DISTINCT TRX.ID, TTTX.TASK FROM ");
		sql.append("TI_REQUEST TRX ");
		sql.append("JOIN TI_ACTIVITY_TRAIL TATX ON TRX.ID=TATX.TI_REQUEST_ID ");
		sql.append("JOIN TI_TASK_TYPE TTTX ON TTTX.ID = TATX.ACTIVITY_ID  ");
		sql.append("WHERE ");
		sql.append("TATX.ACTIVITY_STATUS = 'EXPIRED' AND ");
		sql.append("TRX.ID IN( ");
		sql.append("SELECT TR.ID FROM ");
		sql.append("TI_REQUEST TR ");
		sql.append("JOIN TI_ACTIVITY_TRAIL TAT ON TR.ID=TAT.TI_REQUEST_ID ");
		sql.append("JOIN TI_TASK_TYPE TTT ON TTT.ID = TAT.ACTIVITY_ID  ");
		sql.append("JOIN GENERIC_LOOKUP_DEFS GLD  ON GLD.NAME = 'EXPIRATION_REMAINDER_TASKS' ");
		sql.append("JOIN GENERIC_LOOKUP GL ON GLD.ID= GL.DEFINITION_ID ");
		sql.append("JOIN GENERIC_LOOKUP_DEFS GLD2  ON GLD2.NAME = 'EXPIRATION_REMAINDER_DAYS' ");
		sql.append("JOIN GENERIC_LOOKUP GL2 ON GLD2.ID= GL2.DEFINITION_ID ");
		sql.append("WHERE ");
		sql.append("TAT.ACTIVITY_STATUS = 'SCHEDULED' AND ");
		sql.append("GL.VALUE1 = TTT.TASK_CODE ");
		sql.append("AND REMAINDER(FLOOR(SYSDATE-TRUNC(TAT.ACTIVITY_STARTDATE)),GL2.VALUE2)=0 ");
		sql.append(")");
			  
		log.debug("SendMailScheduler:sendExpirationMail:: SQL:: " + sql.toString());
		
		try {
			SqlRowSet rs  =  jdbcTemplate.queryForRowSet(sql.toString());
			Map<String,String> data = new HashMap();
			
			while (rs.next()) 
				data.put(rs.getString(1) , rs.getString(2));
			 
		 if ( data.isEmpty() )
			 log.debug("Could Not find Expiration Connection for Notification ");
		 else 
			 mailModuleImpl.sendScheduledExpirationNotification(data);
			 
			
			} catch (Exception e) {
		    log.error(e);
		}
	  
		log.debug("SendMailScheduler:sendExpirationMail:: Exited");
    }
     

    /**
     * Gets the qualified ids for 7 activation expiration.
     *
     * @return the qualified ids for activation expiration
     */
    private List getQualifiedIdsFor7DaysActivationExpiration(){
	log.debug("SendMailScheduler: getQualifiedIdsFor7DaysActivationExpiration :: Entered");
	List requestIds = new ArrayList();
	StringBuilder sql = new StringBuilder (); 
	sql.append("SELECT DISTINCT TR.ID FROM TI_PROCESS TP ");
	sql.append(	"JOIN TI_REQUEST TR ON TR.PROCESS_ID=TP.ID ");
	sql.append(	"JOIN TI_REQUEST_TYPE TRT ON TRT.ID=TR.TI_REQUEST_TYPE_ID ");
	sql.append(	"JOIN TI_ACTIVITY_TRAIL TAT ON TR.ID=TAT.TI_REQUEST_ID ");
	sql.append(	"JOIN GENERIC_LOOKUP_DEFS GLD  ON GLD.NAME = 'ACV_REMAINDER_NOTIFICATION' ");
	sql.append(	"JOIN GENERIC_LOOKUP GL ON GLD.ID= GL.DEFINITION_ID ");
	//Commented below join as it is totally incorrect. It is blocking all 7 day reminders in production
	//sql.append(	"JOIN RELATIONSHIP RS ON RS.ID = TP.ID ");
	sql.append(	"JOIN RELATIONSHIP RS ON RS.ID = TP.RELATIONSHIP_ID ");
	sql.append(	"WHERE TR.VERSION_NUMBER =TP.VERSION_NUMBER AND ");
	sql.append(	"TRT.REQUEST_TYPE='ACV' AND ");
	sql.append(	"TAT.ACTIVITY_STATUS = 'SCHEDULED' AND ");
	sql.append(	"TP.ACTIVATION_EXP_DATE < SYSDATE AND ");
	sql.append(	"(SYSDATE-TP.ACTIVATION_EXP_DATE) < 91 AND ");
	sql.append(	" RS.RELATIONSHIP_TYPE = 'THIRD_PARTY' AND " );
	sql.append(	"(REMAINDER((TRUNC(SYSDATE) - TRUNC(TP.ACTIVATION_EXP_DATE)),GL.VALUE2)=0 OR ");
	sql.append(	"(TRUNC(SYSDATE) - TRUNC(TP.ACTIVATION_EXP_DATE)) = 0)");
	
	Map data = new HashMap();
	List dataList = null;
	log.debug("SendMailScheduler: getQualifiedIdsFor7DaysActivationExpiration :: SQL::"+sql);
	try {
	    data = runQuery(sql.toString(), 1, "SELECT");
	} catch (Exception e) {
	    log.error(e);
	}
	int counter = 1;
	if (data != null && data.size() > 0) {
	    while (counter <= data.size()) {
		dataList = (ArrayList) data.get(Integer.valueOf(counter));
		if (dataList != null && dataList.size() > 0) {
		    requestIds.add((String) dataList.get(0));
		}
		counter = counter+1;
	    }
	}
	log.debug("SendMailScheduler: getQualifiedIdsFor7DaysActivationExpiration :: Exited");
	return requestIds;
    }

    /**
     * Gets the qualified ids for 30 activation expiration.
     *
     * @return the qualified ids for activation expiration
     */
    private List getQualifiedIdsFor30DaysActivationExpiration(){
	log.debug("SendMailScheduler: getQualifiedIdsFor30DaysActivationExpiration :: Entered");
	List requestIds = new ArrayList();

	 StringBuilder sql = new StringBuilder (); 
	 sql.append("SELECT DISTINCT TR.ID FROM TI_PROCESS TP ");
	 sql.append("JOIN TI_REQUEST TR ON TR.PROCESS_ID=TP.ID ");
	 sql.append("JOIN TI_REQUEST_TYPE TRT ON TRT.ID=TR.TI_REQUEST_TYPE_ID ");
	 sql.append("JOIN TI_ACTIVITY_TRAIL TAT ON TR.ID=TAT.TI_REQUEST_ID ");
	 sql.append("JOIN GENERIC_LOOKUP_DEFS GLD  ON GLD.NAME = 'ACV_REMAINDER_ESCALATION_NOTIFICATION' ");
	 sql.append("JOIN GENERIC_LOOKUP GL ON GLD.ID= GL.DEFINITION_ID ");
	//Commented below join as it is totally incorrect. It is blocking all 7 day reminders in production
	 //sql.append("JOIN RELATIONSHIP RS ON RS.ID = TP.ID WHERE ");
	 sql.append("JOIN RELATIONSHIP RS ON RS.ID = TP.RELATIONSHIP_ID WHERE ");
	 sql.append("TR.VERSION_NUMBER =TP.VERSION_NUMBER AND ");
	 sql.append("TRT.REQUEST_TYPE='ACV' AND ");
	 sql.append("TAT.ACTIVITY_STATUS = 'SCHEDULED' AND ");
	 sql.append("TP.ACTIVATION_EXP_DATE < SYSDATE AND ");
	 sql.append("RS.RELATIONSHIP_TYPE = 'THIRD_PARTY' AND " );
	 sql.append("TO_CHAR(TP.ACTIVATION_EXP_DATE,'DD/MM/RRRR') != TO_CHAR(SYSDATE,'DD/MM/RRRR') AND ");
	 sql.append("REMAINDER((TRUNC(SYSDATE) - TRUNC(TP.ACTIVATION_EXP_DATE)),GL.VALUE2)=0");
	Map data = new HashMap();
	List dataList = null;
	log.debug("SendMailScheduler: getQualifiedIdsFor30DaysActivationExpiration :: SQL:: "+sql);
	try {
	    data = runQuery(sql.toString(), 1, "SELECT");
	} catch (Exception e) {
	    log.error(e);
	}
	int counter = 1;
	if (data != null && data.size() > 0) {
	    while (counter <= data.size()) {
		dataList = (ArrayList) data.get(Integer.valueOf(counter));
		if (dataList != null && dataList.size() > 0) {
		    requestIds.add((String) dataList.get(0));
		}
		counter = counter+1;
	    }
	}
	log.debug("SendMailScheduler: getQualifiedIdsFor30DaysActivationExpiration :: Exited");
	return requestIds;
    }

    /**
     * Gets the requester email.
     *
     * @param tiRequestId the ti request id
     * @param testMode the test mode
     * @return the requester email
     */
    private String getRequesterEmail(String tiRequestId,String testMode) {
	log.debug("SendMailScheduler:getRequesterEmail:: Entered");
	String sql =
		"SELECT CU.EMAIL,CU.SSO_ID FROM "+
		"TI_REQUEST TR  "+
		"JOIN C3PAR_USERS CU ON TR.USER_ID = CU.ID "+
		"WHERE "+
		" nvl(CU.IS_TERMINATED,' ') != 'TE' AND "+
		"TR.ID = "+tiRequestId;

	Map data = new HashMap();
	String ownerEmail = "";
	List dataList = null;
	log.debug("SendMailScheduler:getRequesterEmail:: SQL:: " + sql);
	try {
	    data = runQuery(sql, 2, "SELECT");
	} catch (Exception e) {
	    log.error(e);
	}
	int counter = 1;
	if (data != null && data.size() > 0) {
	    while (counter <= data.size()) {
		dataList = (ArrayList) data.get(Integer.valueOf(counter));
		if (dataList != null && dataList.size() > 0) {
		    if("true".equalsIgnoreCase(testMode)){
			ownerEmail=(String) dataList.get(1)+MailModuleConstants.EMAIL_ADDRESS_SEPERATOR;
			break;
		    } else {
			ownerEmail=(String) dataList.get(0)+MailModuleConstants.EMAIL_ADDRESS_SEPERATOR;
			break;
		    }
	    	}
	    }
	}
	log.debug("SendMailScheduler:getRequesterEmail:: Exited");
	return ownerEmail;
    }

    /**
     * Update scheduled email flag.
     *
     * @param List of TiRequestId
     * @param flagValue the flag value
     * @return Updated Row count
     */
    private int[] updateScheduledEmailFlag(List tiRequestIds,String flagValue){
	log.debug("updateScheduledEmailFlag:: Entered");
	
	String sql = "update ti_request set SCHEDULED_EMAIL_FLAG = '" + flagValue + "' where id IN (";
	int results[] = null;
	
	try {
		 String sqls[] = getSQLForBatch (tiRequestIds,sql);
		 results = jdbcTemplate.batchUpdate(sqls);
     
		} catch (Exception e) {
			log.error(e);
		}
	log.debug("SendMailScheduler:updateScheduledEmailFlag:: Exited");
	return results;
    }
   
    
    private  String[] getSQLForBatch(List<String> values,String sql) {
        StringBuilder params = null;
        Object temp[] = null;	     
        String str = null;
        String sqls[] = null;
       
      if (values != null && values.size() > 0) {
        List<Object[]> list =	getArrayofObjectsForSQL (values);
        sqls = new String[list.size()];  
        
         for (int i=0; i < list.size() ;i++) {
       	  params = new StringBuilder();
       	  temp = list.get(i);
       	  
       	  for (int j=0; j < temp.length;j++) 
       		params.append("'" + temp[j] + "',");
       	  	
       	  	str =  params.toString();
       	  	sqls[i]  = sql + (str.substring(0, (str.length() - 1))) + ")";
       	    log.debug ("getSQLForBatch SQL: "+  sqls[i]);
         }
      }
      return sqls;
   }
           
    
    private  List<Object[]> getArrayofObjectsForSQL (List<String> values) {
    	Object src[] = values.toArray(); 
    	
    	if (src.length <= SQLPARAMSIZE) { 
    		List<Object[]> list = new ArrayList<Object[]> (1);
    		list.add(src);
    		return ( list ); 
    	}

    	int index = 0;
    	Object dest[] = null;
    	int count =   src.length / SQLPARAMSIZE;

    	if ((src.length % SQLPARAMSIZE) == 0)  
         	 count = count - 1; 
    	List<Object[]>   list = new ArrayList<Object[]>(count + 1); 
    	
    	for (int i=0;i < count;i++) {
    		dest = new Object[SQLPARAMSIZE];
    		System.arraycopy(src, index, dest, 0, SQLPARAMSIZE);
    		index = index + SQLPARAMSIZE;
    		list.add( dest);
    	}
    	
    	dest = new Object[src.length  - index];
    	System.arraycopy(src, index, dest, 0, (src.length  - index));
    	list.add( dest);
    	
    	return list;
    }

       
  
    /**
     * Run query.
     *
     * @param statement the statement
     * @param columns the columns
     * @param type the type
     * @param c3parSession the c3par session
     * @param isTransaction the is transaction
     * @return the map
     * @throws Exception the exception
     */
    private Map runQuery(String statement, int columns, String type) throws Exception {

    if (type.toUpperCase().equals("SELECT")) {
	    Map data = null;
	    List dataList = null;
	    int counter = 0;
	    int rowId = 0;
	    SqlRowSet result = null;
	 
	    try {
		
		result = jdbcTemplate.queryForRowSet(statement);
		
		while (result.next()) {
		    if (data == null)
			data = new HashMap();
		    rowId = rowId + 1;
		    counter = 1;
		    dataList = new ArrayList();
		    dataList.add(result.getString(counter));
		    data.put(Integer.valueOf(rowId), dataList);
		  
		    while (counter < columns) {
			counter = counter + 1;
			dataList.add(result.getString(counter));
		    	}
			}
	    } catch (Exception e) {
	    	log.error(e);
	    } 
	    return data;
	} else if (type.toUpperCase().equals("DML")) {
	    try {
	    	jdbcTemplate.update(statement);
	    } catch (Exception e) {
	    		log.error(e);
	    }  
	    return null;
	}
	return null;
    }

    /**
     * Gets the mail module impl.
     *
     * @return the mail module impl
     */
    public IMailModule getMailModuleImpl() {
	return mailModuleImpl;
    }

    /**
     * Sets the mail module impl.
     *
     * @param mailModuleImpl the new mail module impl
     */
    public void setMailModuleImpl(IMailModule mailModuleImpl) {
	this.mailModuleImpl = mailModuleImpl;
    }

    /** The run faf calculation thread. */
    /*private Runnable runFAFCalculationThread = new Runnable() {
	public void run() {
	    try {
		print("Entered in run method for runFAFCalculationThread");
		calculateQueuedFAF();
		print("Returned in run method for runFAFCalculationThread");
	    } catch (InterruptedException ix) {
		print("runFAFCalculationThread interrupted!");
	    } catch (Exception x) {
		print("runFAFCalculationThread threw an Exception!!!\n" + x);
		log.error(x);
	    }
	}
    };*/

    /**
     * Prints the.
     *
     * @param msg the msg
     */
    private static void print(String msg) {
	String name = Thread.currentThread().getName();
	log.debug(name + ": " + msg);
    }

    /**
     * Calculate queued faf.
     *
     * @throws Exception the exception
     */
    /*private void calculateQueuedFAF() throws Exception {
	Util util=new Util();
	List list = util.getFAFRequestsWithFlagQ();
	Iterator listIter = list.iterator();
	while(listIter.hasNext()){
	    HashMap hh = (HashMap)listIter.next();
	    computeNSendMail(hh);
	}
    }*/

    /**
     * Compute n send mail.
     *
     * @param hh the hh
     * @throws Exception the exception
     */
    /*private void computeNSendMail(HashMap hh) throws Exception{
	Util util=new Util();
	String reportType=null;
	String reqType= (String)hh.get("REQ_TYPE");
	Long conReqId = Long.valueOf((String)hh.get("CON_REQ_ID"));
	String sendMailFlag= (String)hh.get("SEND_MAIL_FLAG");
	String retValue=null;
	if("calculate".equals(reqType)){
	    reportType="FAF";
	    retValue= util.updateFAFQueue(conReqId,reqType);
	}else if("terminatefaf".equals(reqType)){
	    reportType="FAF";
	    retValue= util.updateFAFQueue(conReqId,reqType);
	}else if("recalculate".equals(reqType)){
	    reportType="FAF";
	    retValue= util.updateFAFQueue(conReqId,reqType);
	}else if("insertintofafstate".equals(reqType)){
	    reportType="FAF";
	    retValue= util.updateFAFQueue(conReqId,reqType);
	    if("true".equalsIgnoreCase(retValue)){
		util.updateFafFlagInPortMaster(conReqId);
	    }
	}
	else if("generatepaf".equals(reqType)){
	    reportType="PAF";
	    retValue= util.generatePafReview(conReqId);
	}else if("recalculatepaf".equals(reqType)){
	    reportType="PAF";
	    retValue= util.recalculatePAF(conReqId);
	}else if("insertintopafstate".equals(reqType)){
	    reportType="PAF";
	    retValue= util.insertIntoPafState(conReqId);
	}else if("generateaaf".equals(reqType)){
	    reportType="AAF";
	    retValue= util.generateAafReview(conReqId);
	}else if("recalculateaaf".equals(reqType)){
	    reportType="AAF";
	    retValue= util.recalculateAAF(conReqId);
	}else if("insertintoaafstate".equals(reqType)){
	    reportType="AAF";
	    retValue= util.insertIntoAafState(conReqId);
	}else if("terminatepaf".equals(reqType)){
	    reportType="PAF";
	    retValue= util.generateTerminatePAF(conReqId);
	}else if("terminateaaf".equals(reqType)){
	    reportType="AAF";
	    retValue= util.generateTerminateAAF(conReqId);
	}
	if (("calculate".equals(reqType)) || ("terminatefaf".equals(reqType))
		|| "recalculate".equals(reqType)) {

	    Long tiRequestId = util.getLatestTiRequestId(conReqId);
	    List rfcRequestList = rfc.storeRFCRequest(tiRequestId,
		    RFCRequestDTO.RFC_CREATE_TYPE_AUTO);
	    String aclVarianceFlag = rfc.getACLVarianceFlag(tiRequestId);
	    if (aclVarianceFlag != null
		    && aclVarianceFlag.equalsIgnoreCase("N")) {
		rfc.storeRFCRequestStatus(tiRequestId, rfcRequestList);
	    }
	}
	if("Y".equals(sendMailFlag) && "true".equals(retValue)){
	    mailModuleImpl.sendEmailFAFCompletion(conReqId,reportType);
	} //else if("N".equals(sendMailFlag)){
	Thread.sleep(20000);
	if(util.isComputationWait(conReqId)){
	    if(util.isOutputComputationsComplete(conReqId))
		Util.writeMessage(conReqId);
	}
	print("Removed "+conReqId);
    }*/



	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}



	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	public CCRQueries getCcrQueries() {
		return ccrQueries;
	}


	public void setCcrQueries(CCRQueries ccrQueries) {
		this.ccrQueries = ccrQueries;
	}
	
	public void accessFormRemainder() {
		try {
			log.info("SendMailScheduler: accessFormRemainder: starts");
			
			String role = "";		
			
			StringBuilder requestorName = new StringBuilder("");
			StringBuilder primaryOwnerName = new StringBuilder("");
			StringBuilder secondaryOwnerName = new StringBuilder("");
			StringBuilder isoName = new StringBuilder("");
			StringBuilder toAddress = new StringBuilder("");
			StringBuilder ccAddress = new StringBuilder("");
			
			String sqlQuery = "select CMP.ID, CMP.ORDER_ITEM_ID, CMP.CCR_ID, CMP.BUSINESS_JUSTIFICATION, TT.TASK_CODE" +
					" from CMP_REQUEST CMP" +
					" join TI_ACTIVITY_TRAIL ACT on ACT.CMP_ID = CMP.ID" +
					" join TI_TASK_TYPE TT on TT.ID = ACT.ACTIVITY_ID" +
					" where ACT.ACTIVITY_ID in (select ID from TI_TASK_TYPE where TASK_CODE in ('awaiting_additional_info', 'awaiting_additional_info_assign', 'awaiting_paf_faf_verify'))" +
					" and ACT.ACTIVITY_STATUS = 'SCHEDULED'" +
					" and ACT.ACTIVITY_STARTDATE <= (systimestamp - interval '24' hour)" +
					" and (CMP.ACCESS_FORM_REMAINDER_DATE is null or CMP.ACCESS_FORM_REMAINDER_DATE <= (systimestamp - interval '24' hour))";
			
			SqlRowSet rs = jdbcTemplate.queryForRowSet(sqlQuery);
			List<Map<String, String>> list = new ArrayList<Map<String,String>>();
			List<CmpRequestDTO> cmpRequestDTOList = new ArrayList<CmpRequestDTO>();
			
			log.debug("SendMailScheduler: accessFormRemainder: oustside");
			
			while(rs.next()){
				
				log.debug("SendMailScheduler: accessFormRemainder: inside");
				
				Map<String, String> map = new HashMap<String, String>();
				
				map.put("ID", rs.getString("ID"));
				map.put("ORDER_ITEM_ID", rs.getString("ORDER_ITEM_ID"));
				map.put("CCR_ID", rs.getString("CCR_ID"));
				map.put("TASK_CODE", rs.getString("TASK_CODE"));
				map.put("BUSINESS_JUSTIFICATION", rs.getString("BUSINESS_JUSTIFICATION"));
				
				list.add(map);
			}
			
			log.debug("SendMailScheduler: accessFormRemainder: List size: " +list.size());
			
			for (Map<String, String> map : list) {
				
				CmpRequestDTO cmpRequestDTO = new CmpRequestDTO();
				
				sqlQuery = "select CC.FIRST_NAME, CC.LAST_NAME, CC.SSO_ID, CC.EMAIL, CR.NAME" +
						" from CMP_REQUEST_CON_XREF CX" +
						" join CITI_CONTACT CC on CC.ID = CX.CITI_CONTACT_ID" +
						" join CMP_ROLE CR on CR.ID = CX.ROLE_ID" +
						" where CX.CMP_ID = " +map.get("ID");
				
				rs = jdbcTemplate.queryForRowSet(sqlQuery);
				
				while(rs.next()){
					
					role = rs.getString("NAME");
					
					if("Requestor".equalsIgnoreCase(role)){
	                	if(requestorName.length() < 1){
	                		requestorName.append(rs.getString("FIRST_NAME")+ " " +rs.getString("LAST_NAME"));
	                		toAddress.append(rs.getString("EMAIL"));
	                	}
	                	else{
	                		requestorName.append(", " +rs.getString("FIRST_NAME")+ " " +rs.getString("LAST_NAME"));
	                		toAddress.append("; " +rs.getString("EMAIL"));
	                	}
	                }
	                else if("Business_Owner".equalsIgnoreCase(role)){
	                	if(primaryOwnerName.length() < 1){
	                		primaryOwnerName.append(rs.getString("FIRST_NAME")+ " " +rs.getString("LAST_NAME"));
	                	}
	                	else{
	                		primaryOwnerName.append(", " +rs.getString("FIRST_NAME")+ " " +rs.getString("LAST_NAME"));
	                	}
	                	if(ccAddress.length() < 1){
	                		ccAddress.append(rs.getString("EMAIL"));
	                	}
	                	else{
	                		ccAddress.append("; " +rs.getString("EMAIL"));
	                	}
	                }
	                else if("Sec_Business_Owner".equalsIgnoreCase(role)){
	                	if(secondaryOwnerName.length() < 1){
	                		secondaryOwnerName.append(rs.getString("FIRST_NAME")+ " " +rs.getString("LAST_NAME"));
	                	}
	                	else{
	                		secondaryOwnerName.append(", " +rs.getString("FIRST_NAME")+ " " +rs.getString("LAST_NAME"));
	                	}
	                	if(ccAddress.length() < 1){
	                		ccAddress.append(rs.getString("EMAIL"));
	                	}
	                	else{
	                		ccAddress.append("; " +rs.getString("EMAIL"));
	                	}
	                }
	                else if("BISO".equalsIgnoreCase(role)){
	                	if(isoName.length() < 1){
	                		isoName.append(rs.getString("FIRST_NAME")+ " " +rs.getString("LAST_NAME"));
	                	}
	                	else{
	                		isoName.append(", " +rs.getString("FIRST_NAME")+ " " +rs.getString("LAST_NAME"));
	                	}
	                	if(ccAddress.length() < 1){
	                		ccAddress.append(rs.getString("EMAIL"));
	                	}
	                	else{
	                		ccAddress.append("; " +rs.getString("EMAIL"));
	                	}
	                }
	                else {
	                	if(ccAddress.length() < 1){
	                		ccAddress.append(rs.getString("EMAIL"));
	                	}
	                	else{
	                		ccAddress.append("; " +rs.getString("EMAIL"));
	                	}	                
	                }
				}
				
				cmpRequestDTO.setRequestorName(requestorName.toString());
				cmpRequestDTO.setPrimaryOwnerName(primaryOwnerName.toString());
				cmpRequestDTO.setSecondaryOwnerName(secondaryOwnerName.toString());
				cmpRequestDTO.setIsoName(isoName.toString());
				cmpRequestDTO.setToAddresses(toAddress.toString());
				cmpRequestDTO.setCcAddresses(ccAddress.toString());
				
				cmpRequestDTO.setCmpId(map.get("ORDER_ITEM_ID"));
				cmpRequestDTO.setCcrId(map.get("CCR_ID"));
				cmpRequestDTO.setBj(map.get("BUSINESS_JUSTIFICATION"));
				cmpRequestDTO.setChooseEmail(map.get("TASK_CODE"));
				
				cmpRequestDTOList.add(cmpRequestDTO);
			}
			
			for (CmpRequestDTO cmpRequestDTO : cmpRequestDTOList) {
				
				String chooseEmail = "";
				
				if("awaiting_additional_info".equalsIgnoreCase(cmpRequestDTO.getChooseEmail())){
					chooseEmail = "REQ_ASSIGNED_NEED_MORE_INFO_REMAINDER";
				}
				else if("awaiting_additional_info_assign".equalsIgnoreCase(cmpRequestDTO.getChooseEmail())){
					chooseEmail = "NEED_MORE_INFO_AFTER_ASSIGNED_REMAINDER";
				}
				else if("awaiting_paf_faf_verify".equalsIgnoreCase(cmpRequestDTO.getChooseEmail())){
					chooseEmail = "PAF_FAF_VERIFICATION_REMAINDER";
				}
				
				mailModuleImpl.sendEcmEmailViewGeneration(chooseEmail, cmpRequestDTO);
				
				sqlQuery = "update CMP_REQUEST" +
						" set ACCESS_FORM_REMAINDER_DATE = systimestamp" +
						" where ORDER_ITEM_ID = '" +cmpRequestDTO.getCmpId()+ "'";
				
				jdbcTemplate.update(sqlQuery);
				
			}
			
			log.info("SendMailScheduler: accessFormRemainder: ends");						
		}
		
		catch (Exception e) {
			log.error("SendMailScheduler: accessFormRemainder: Exception: " +e.getMessage(), e);
		}
	}
 }