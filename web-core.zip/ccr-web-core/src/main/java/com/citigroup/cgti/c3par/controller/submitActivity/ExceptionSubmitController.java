package com.citigroup.cgti.c3par.controller.submitActivity;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.kie.api.task.model.TaskSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.comments.domain.ExceptionProcess;
import com.citigroup.cgti.ccr.workflow.CCRWorkflowConstants;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;
import com.citigroup.cgti.inbox.service.InboxService;

/*
 * @sr60958
 */

@Controller
public class ExceptionSubmitController {

	private static Logger log = Logger.getLogger(ExceptionSubmitController.class);
	@Autowired
	private InboxService inboxService;
	@Autowired
	WsPapiFacade papiFacade;
	@Autowired
    WorkflowCallServiceHelper wrkflowCallServiceHelper;
    @Autowired
    WorkflowUtil workflowUtil;

	@RequestMapping(value = "/exceptionLoad.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String load(ModelMap model, @ModelAttribute("exceptionProcess") ExceptionProcess exceptionProcess,
			BindingResult result, HttpSession session, HttpServletRequest request) {
		log.info("ExceptionController load method begins here ...");
		String data = "";
		try {
			ExceptionProcess exceptionProcess1 = new ExceptionProcess();
			session = request.getSession();
			String ssoId = request.getHeader("SM_USER");
			String activityName = request.getParameter("forward");
			String connectionId = request.getParameter("processId");
			String taskId = request.getParameter("taskId");
			String tiRequestId = request.getParameter("tiRequestId");
			lockActivity(ssoId,Long.parseLong(tiRequestId),Long.parseLong(taskId));
			exceptionProcess1.setConnectionId(connectionId);
			exceptionProcess1.setTaskId(taskId);
			exceptionProcess1.setTiRequestId(tiRequestId);
			data = inboxService.getExceptionMessage(activityName, connectionId);
			exceptionProcess1.setErrorMessage(data);
			model.addAttribute("exceptionProcess", exceptionProcess1);
			return "pages/submitActivity/Exception";
		} catch (Exception e) {
			log.error("Error has occured in Exceptionload :: " + e.toString());
		}
		log.info("ExceptionController load method ends here ...");
		return null;
	}
	private void lockActivity(String ssoId, Long tiRequestId, Long workItemId) {
        log.info("Entering Lock Activity ::"+ssoId+" "+tiRequestId+" "+workItemId);
        Map<String, Object> userFlowParams = new HashMap<String, Object>();
        TaskSummary taskSummary = workflowUtil.getTaskSummary(workItemId);
        userFlowParams.put("soeid", ssoId);
        userFlowParams.put(CCRWorkflowConstants.TASK_SUMMARY, taskSummary);
        log.info(" process instance id ==" + taskSummary.getProcessInstanceId());
        wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, userFlowParams, WorkflowEvent.LOCK,
                tiRequestId);
        log.info("Exiting::");
    }

	@RequestMapping(value = "/exceptionSubmit.act", method = { RequestMethod.GET, RequestMethod.POST })
	public void exceptionActivitysubmit(ModelMap model,
			@ModelAttribute("exceptionProcess") ExceptionProcess exceptionProcess, BindingResult result,
			HttpSession session, HttpServletRequest request) {
		log.info("ExceptionController submit method begins here ...");
		WorkflowEvent workflowEvent = null;
		try {
			if (exceptionProcess.getExceptionOption() != null) {
				Long tiRequestId = Long.parseLong(exceptionProcess.getTiRequestId());
				String workItemId = exceptionProcess.getTaskId();
				String ssoId = request.getHeader("SM_USER");
				log.info(" tiRequestId :: " + tiRequestId + " workItemId ::" + workItemId);
				if ((exceptionProcess.getExceptionOption()).equals("Unlock")) {
					papiFacade.completeExceptionActivity(ssoId, workItemId, CCRWorkflowConstants.UNLOCKEDSTATUS,
							tiRequestId);
				} else if ((exceptionProcess.getExceptionOption()).equals("Revert")) {
					papiFacade.completeExceptionActivity(ssoId, workItemId, CCRWorkflowConstants.REVERTSTATUS,
							tiRequestId);
				} else {
					papiFacade.completeExceptionActivity(ssoId, workItemId, CCRWorkflowConstants.ABORTEDSTATUS,
							tiRequestId);
				}
				log.info("Workflow event" + workflowEvent);

			}
		} catch (Exception e) {
			log.error("Error has occured in Exceptionload :: " + e.toString());
		}
		log.info("ExceptionController submit method ends here ...");

	}

}
