/**
 * File FrameworkConstants.java
 *
 * Created  on Aug 4, 2005
 *
 * Copyright (c) 2002,2003, 2004, 2005 by JONE. All Rights Reserved. Confidential.
 */
package com.citigroup.cgti.c3par.util;


/**
 * Contains constants for the framework module that are common to both
 * web and ejb tier components.
 *
 * @author: IJIS Devlopment Team
 * @version	1.0
 */
public final class FrameworkConstants {


    /** The Constant MSG_USER_MESSAGE. */
    public static final String MSG_USER_MESSAGE = "information";

    /**
     * Constant to indicate the warning message. A user may or may not ignore
     * such a message.
     */
    public static final String MSG_USER_WARNING = "warning";

    /**
     * Constant that indicates an error that the user needs to correct.
     */
    public static final String MSG_USER_ERROR = "usererror";

    /**
     * Constant that indicates development time error message.
     */
    public static final String MSG_APP_ERROR = "apperror";

    /**
     * Constant that indicates system level error and the user will not be
     * able to rectify it.
     */
    public static final String MSG_SYSTEM_ERROR = "syserror";

    /** Constants for displaying the number of rows to be displayed in the search result pages. */
    public static final int SEARCH_RESULT_PAGE_SIZE = 10;

    /** Constant to indicate the previous direction in paging screens. */
    public static final String PREVIOUS = "PREV";

    /** Constant to indicate the next direction in paging screens. */
    public static final String NEXT = "NEXT";

    /** Constant to indicate that user has opted for all the search items. */
    public static final String ALL = "ALL";

    /** Constant to indicate the back screens. */
    public static final String BACK = "BACK";

    /** Used for painting the light shade in the multi-line display screens. */
    public static final String LIGHT_SHADE = "lightshade";

    /** Used for painting a different light shade in the multi-line display screens. */
    public static final String LIGHT_SHADE2 = "lightshade2";

    // Form Context variables
    /** Constant for Display Form Context. */
    public static final String FORM_CTXT_DISPLAY = "D";

    /** Constant for Add Form Context. */
    public static final String FORM_CTXT_ADD = "A";

    /** Constant for Edit Form Context. */
    public static final String FORM_CTXT_EDIT = "E";

    /** Constant for Search Form Context. */
    public static final String FORM_CTXT_SEARCH_FORM = "SF";

    /** Constant for Search List Form Context. */
    public static final String FORM_CTXT_SEARCH_LIST = "SL";

    /** Constant for Delete Form Context. */
    public static final String FORM_CTXT_DELETE = "DLT";

    /** Constant for Reset User Form Context. */
    public static final String FORM_CTXT_RESETUSER = "RU";

    /** Constant for Change Password for User Admin Form Context. */
    public static final String FORM_CTXT_CHANGEPASSWD = "CP";

    /** Constant for Resequence Form Context. */
    public static final String FORM_CTXT_RESEQUENCE = "RSQ";

    /** Constant for Back Form Context. */
    public static final String FORM_CTXT_BACK = "B";

    /** Constant for Registration Form Context. */
    public static final String FORM_CTXT_REGISTRATION = "REG";

    /** Constant for Registration Form Context. */
    public static final String FORM_CTXT_TRANS_REGISTRATION = "TRANS_REG";

    /** Constant for Title Form Context. */
    public static final String FORM_CTXT_TITLE = "T";

    /** Constant for Finish Form Context. */
    public static final String FORM_CTXT_FINISH = "F";

    /** Constant for Adding in Session Form Context. */
    public static final String FORM_CTXT_ADD_IN_SESSION = "ADD_IN_SESSION";

    /** Constant for Redirecting to summary page Form Context. */
    public static final String FORM_CTXT_SUMMARY = "FORM_CTXT_SUMMARY";

    /** Default Country code. */
    public static final String DEFAULT_COUNTRY = "US";

    /** Default State code. */
    public static final String DEFAULT_STATE = "NH";

    /** Default User Type. */
    public static final String DEFAULT_USERTYPE = "D";

    // Constances used by the tabHandler JSP tag and JSP pages.
    /** Constant for Individual Owner Tab in Search Owners screen. */
    public static final String TABCTX_IND = "IND";

    /** Signifies a User type of DOS. */
    public static final String USR_TYPE_DOS = "D";

    /** Signifies a User type of Muni Agent. */
    public static final String USR_TYPE_MUNI = "M";

    /** Generic IP Address for Dialup Users. */
    public static final String DIALUP_IPADDRESS = "999.999.999.999";

    /** Error Constant for Remote Interface lookup failure. */
    public static final String REMOTE_LOOKUP_FAILED =
	"framework.remotelookup.failed";

    /** Represents true as string constant. */
    public static final String IND_TRUE = "true";

    /** Represents false as string constant. */
    public static final String IND_FALSE = "false";

    /** Represent credit card processing state - Sale Pending. */
    public static final String CC_SALE_PENDING = "SP";

    /** Represent credit card processing state - Sale Completed. */
    public static final String CC_SALE_COMPLETED = "SC";

    /** Represent credit card processing state - Void Pending. */
    public static final String CC_VOID_PENDING = "VP";

    /** Represent credit card processing state - Void Completed. */
    public static final String CC_VOID_COMPLETED = "VC";

    /** Represents code for commmisionors office. */
    public static final String COMMISSIONER_OFFICE = "3955";

    /** Represents code for IRP location. */
    public static final String IRP_LOCATION = "3004";

    /** Represents code for title bureau. */
    public static final String TITLE_BUREAU = "6001";

    /** Represents code for STATE Location. */
    public static final String STATE_LOCATION = "3001";

    /** A new line constant. */
    public static final String NEW_LINE = "\n";

    /** A tab character constant. */
    public static final String TAB_CHAR = "\t";

    /** A single space character. */
    public static final char SPACE_CHAR = ' ';

    /** A single space character. */
    public static final String PERCENTAGE = "%";

    /** A period character. */
    public static final String PERIOD = ".";

    /** Represents Under Score Character. */
    public static final String UNDER_SCORE = "_";

    /** Represents Path Character. */
    public static final String PATH_SEPARATOR = "/";

    /** A String containing one space. */
    public static final String SPACE = " ";

    /** A String containing two spaces. */
    public static final String SPACE2 = "  ";

    /** A String containing three spaces. */
    public static final String SPACE3 = "   ";

    /** A String containing four spaces. */
    public static final String SPACE4 = "    ";

    /** Blank value constant *. */
    public static final String EMPTY_STRING = "";

    /** A comma character. */
    public static final String COMMA = ",";

    /** Tilda character *. */
    public static final String TILDA = "~";

    /** Colon character *. */
    public static final String COLON = ":";

    /** Constant for form name in being used in struts-config.xml file */
    public static final String CORPORATION_FORM = "corporationForm";

    /** Constant for form name in being used in struts-config.xml file */
    public static final String VEHICLE_FORM = "vehicleForm";

    /** Constant for form name in being used in struts-config.xml file */
    public static final String PERSON_FORM = "personForm";

    /** Constant for form name in being used in struts-config.xml file */
    public static final String REGISTRATION_FORM = "registrationForm";

    /** Constant for form name in being used in struts-config.xml file */
    public static final String PLATE_FORM = "plateForm";

    /** Constant for form name in being used in
     * struts-config-registration.xml file */
    public static final String OVERWT_INSTATE_DECAL_FORM =
	"overWtInStateDecalForm";

    /** Constant for form name in being used in struts-config.xml file */
    public static final String CARRIER_REG_FORM = "carrierRegistrationForm";

    /** Constant for form name in being used in struts-config.xml file */
    public static final String CANCEL_FORM = "cancelForm";

    /** Constant for Y indicator. */
    public static final String IND_Y = "Y";

    /** Constant for Y indicator. */
    public static final String IND_YES_LONG = "Yes";

    /** Constant for N indicator. */
    public static final String IND_N = "N";

    /** Constant for N indicator. */
    public static final String IND_NO_LONG = "No";

    /** Represents Daemon Status as Idle. */
    public static final String DAEMON_STATUS_IDLE = "I";

    /** Represents Daemon Status as Active. */
    public static final String DAEMON_STATUS_ACTIVE = "A";

    /** The Spots request definations bind file name. */
    public static final String SPOTS_REQ_DEF_BIND =
	"SPOTSRequestDefinitionsBind";

    /** The Vendor request definations bind file name. */
    public static final String VENDOR_REQ_DEF_BIND =
	"VendorRequestDefinitionsBind";

    /** Shopping Cart Record Type indicating agent batch shopping cart record. */
    public static final String SHC_RECTYPE_AGENT_BATCH = "A";

    /** Shopping Cart Record Type indicating payment adjustment shop cart record. */
    public static final String SHC_RECTYPE_PAYMENT_ADJ = "P";

    /** Shopping Cart Record Type indicating typical shopping cart record. */
    public static final String SHC_RECTYPE_SHOPPING_CART = "S";

    /** Shopping Cart Record Type indicating that only violations information needs to be posted by Transaction Dispatcher. */
    public static final String SHC_RECTYPE_VIOLATIONS = "V";

    /** Shopping Cart Record Type indicating that only names information needs to be posted by Transaction Dispatcher. */
    public static final String SHC_RECTYPE_NAMES = "N";

    /** Represents numeric zero as String. */
    public static final String NUMERIC_ZERO = "0";

    /** Represents numeric zero as Character. */
    public static final char NUMERIC_ZERO_CHAR = '0';

    /** Constant to be used where '1' is required - like in Sequence of Primary Owner. */
    public static final String NUMERIC_ONE = "1";

    /** Represents numeric 2 as String. */
    public static final String NUMERIC_TWO = "2";

    /** Represents numeric -1 as String. */
    public static final String NUMERIC_MINUS_ONE = "-1";

    /** Represents MAXMS Query Message Type. */
    public static final String MAXMS_MSG_TYPE_QUERY = "Query";

    /** Represents MAXMS Transaction Message Type. */
    public static final String MAXMS_MSG_TYPE_TRANS = "Transaction";

    /** Represents MAXMS Other Message Type. */
    public static final String MAXMS_MSG_TYPE_OTHER = "Other";

    /** Represents MAXMS Result Message Type. */
    public static final String MAXMS_MSG_TYPE_RESULT = "Result";

    /** Represents MAXMS Error Message Type. */
    public static final String MAXMS_MSG_TYPE_ERROR = "Error";

    /** Represents XML file extension. */
    public static final String FILE_EXTN_XML = ".xml";

    /** Message Key to display BaseException error messages. */
    public static final String APPERR_TYPE_MESSAGE = "framework.apperror2";

    /** Constant for String data type used in file generation. */
    public static final String DATA_TYPE_STRING = "S";

    /** Constant for  Date data type used in file generation. */
    public static final String DATA_TYPE_DATE = "D";

    /** Constant for  Number data type used in file generation. */
    public static final String DATA_TYPE_NUMBER = "N";

    /** Constant for  HEX data type used in file generation. */
    public static final String DATA_TYPE_HEX = "H";

    /** The Constant MSG_TYPE_TRANSACTION. */
    public static final String MSG_TYPE_TRANSACTION = "Transaction";

    /** Constant to format single decal. */
    public static final int FORMAT_SINGLE_DECAL = 1;

    /** Constant to format double decal. */
    public static final int FORMAT_DOUBLE_DECAL = 2;

    /** Constant to format overweight decal. */
    public static final int FORMAT_OVERWT_DECAL = 3;

    /** The display value for the blank row. */
    public static final String BLANK_ROW_DISPLAY_VALUE = "";

    /**
     * String constant for single quote.
     */
    public static final String SINGLE_QUOTE = "'";

    /**
     * Indciates that this daemon is timer based but it runs with in
     * the office hours as defined in GlobalParam.properties
     */
    public static final String DMN_TYPE_LIMITED_TIMER = "L";

    /**
     * Indciates that this daemon is timer based and will continue to
     * run always. There are no office hour restrictions
     */
    public static final String DMN_TYPE_PERM_TIMER = "P";

    /**
     * Indciates that this daemon will run once every day. The run time
     * of such daemons is defined in GlobalParam.properties
     */
    public static final String DMN_TYPE_DAILY_FIXED = "F";

    /**
     * Indciates that this daemon will be scheduled by the user.
     */
    public static final String DMN_TYPE_USER_SCHEDULED = "U";

    /** Indicates that user scheduled daemon status is as pending. */
    public static final String DMN_SCHEDULED_STATUS_PENDING = "P";

    /** Indicates that user scheduled daemon status as complete. */
    public static final String DMN_SCHEDULED_STATUS_COMPLETE = "C";

    /** Name of the field that is used during the supervisor override functionality. */
    public static final String SUP_MODE_FLD_NAME = "superMode";

    /** Indicates cancel supervisor override mode (user clicked cancel). */
    public static final String SUP_MODE_CANCEL = "cancel";


    /**
     * Message Key used in case where a User's Password is empty.
     * This key is kept here as it is used both from Web as well as EJB Tier
     */
    // ERROR: The Password can not be blank.
    public static final String VLD_USER_PASSWORD_EMPTY =
	"admin.user.password.empty";

    /**
     * Message Key used in case where the Password length is
     * either less than 7 or more than 15 characters.
     * This key is kept here as it is used both from Web as well as EJB Tier
     */
    // ERROR: A Password must be between 7 and 15 characters long.
    public static final String VLD_USER_PASSWORD_LENGTH_ERROR =
	"admin.user.passwordlength.error";

    /**
     * Message Key used in case where the Password contains other than
     * all Alpha or Numeric characters.
     * This key is kept here as it is used both from Web as well as EJB Tier
     */
    // ERROR: A Password must only contain Alpha or Numeric characters.
    public static final String VLD_USER_PASSWORD_CHAR_ERROR =
	"admin.user.passwordchar.error";

    /**
     * Message Key used in case where the Password does not confirm.
     * This key is kept here as it is used both from Web as well as EJB Tier
     */
    // ERROR: The Password did not confirm. Please try again.
    public static final String VLD_USER_PASSWORD_NOTCONFIRMED =
	"admin.user.password.unconfirmed";

    /**
     * Message Key used in case where a User's Password Expiration Date is empty.
     * This key is kept here as it is used both from Web as well as EJB Tier
     */
    // ERROR: The Password Expiration Date can not be blank.
    public static final String VLD_USER_PASSWD_EXPIRY_EMPTY =
	"admin.user.passwdexpiry.empty";


}
