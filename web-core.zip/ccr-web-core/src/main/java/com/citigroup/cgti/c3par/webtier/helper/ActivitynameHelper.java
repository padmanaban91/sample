/*
 * Created on Feb 1, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.webtier.helper;

import com.mentisys.bfc.maintenance.MaintenanceNames;
import com.mentisys.bfc.termination.TerminationNames;


/**
 * The Class ActivitynameHelper.
 *
 * @author dr97938
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ActivitynameHelper {
    // PROCESS NAMES
    /** The Constant PLANNING_PROCESS. */
    static public final String PLANNING_PROCESS = "PLANNING";

    /** The Constant ACTIVATION_PROCESS. */
    static public final String ACTIVATION_PROCESS = "ACTIVATION";

    /** The Constant MAINTENANCE_PROCESS. */
    static public final String MAINTENANCE_PROCESS = "MAINTENANCE";

    /** The Constant TERMINATION_PROCESS. */
    static public final String TERMINATION_PROCESS = "TERMINATION";

    /**
     * Find process for activity name.
     *
     * @param activityName the activity name
     * @return the string
     */
    public static String findProcessForActivityName(String activityName)
    {
	String process=PLANNING_PROCESS;

	if(
		activityName.equalsIgnoreCase(TerminationNames.REVIEW_CONNECTION_MAKE_CHANGES))
	{
	    process = TERMINATION_PROCESS;
	}
	else if(activityName.equalsIgnoreCase(MaintenanceNames.UPDATE_TECHNICAL_ARCHITECTURE) ||
		activityName.equalsIgnoreCase(MaintenanceNames.REWORK_DESIGN_DOCUMENT) || 
		activityName.equalsIgnoreCase(MaintenanceNames.SIGN_OFF_DETAILED_DESIGN) ||
		activityName.equalsIgnoreCase(MaintenanceNames.UPDATE_SECURITY_CERTIFICATION))
	{
	    process = MAINTENANCE_PROCESS;
	}

	return process; 
    }

}
