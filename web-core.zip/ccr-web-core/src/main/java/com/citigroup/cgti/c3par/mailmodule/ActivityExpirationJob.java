/**
 * 
 */
package com.citigroup.cgti.c3par.mailmodule;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.context.ApplicationContext;

import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;

/**
 * @author ka58098
 *
 */
public class ActivityExpirationJob implements Job {
    private static Logger log = Logger.getLogger(ActivityExpirationJob.class);
    private ApplicationContext appContext = null;
  
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.info("Start job ::");
        appContext = CCRApplicationContextUtils.getApplicationContext();
        SendMailScheduler sendMailScheduler = (SendMailScheduler) appContext.getBean("sendMailScheduler");
        sendMailScheduler.invokeReminderScheduleForExpiraion();
        log.info("End job ::");
    }
}
