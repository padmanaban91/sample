package com.citigroup.cgti.c3par.controller.submitActivity;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.Port;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.webtier.helper.FAFReviewThread;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.citigroup.cgti.ccr.workflow.domain.JBPMTaskRef;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

/*
 * @nc43495
 */
@Controller
public class IPRegSubmitController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(IPRegSubmitController.class);
	Util util=new Util();
	
	@Autowired
	WsPapiFacade papiFacade;
	
	@Autowired
	WorkflowUtil workflowUtil;

	@RequestMapping(value = "/loadIPREGSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(ModelMap model,@ModelAttribute("ipRegSubProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session){
		log.info("IPREG Submit Controller load method starts here...");
		
		String tiReq = (String)session.getAttribute("tireqid");
		String actId = (String)session.getAttribute("activityid");
		
		Long tiReqId = Long.valueOf(0);
		Long activityId = Long.valueOf(0);
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		if(actId!=null){
		    try{activityId=Long.valueOf(actId);}catch(Exception e){activityId = Long.valueOf(0);}
		}
		log.debug("tiReq:"+tiReq+"ActivityId"+activityId);
		
		String taskId = (String) session.getAttribute("taskId");
		if(StringUtil.isNullorEmpty(actId)){
			activityId = workflowUtil.getAuditTrailId(activityId, taskId);
		}
		submitActivityProcess = new SubmitActivityProcess();
		
		//supplementary review roles display
		HashMap<String,String> roles = submitActivityProcess.findInstanceId(tiReqId, activityId);
		submitActivityProcess.setRoles(roles);
		List<LookUpVO> supReviewRole = submitActivityProcess.getSupReviewRoles((String)roles.get("ROLE"));
		log.debug("IPREG Submit Controller:"+supReviewRole.size());
		submitActivityProcess.setSupReviewRoles(supReviewRole);
		
		//set activity role
		submitActivityProcess.setActivityRole((String)roles.get("ROLE"));
		session.setAttribute("activityRole",submitActivityProcess.getActivityRole());
		log.debug("activity role:"+submitActivityProcess.getActivityRole());
		
		/*//setInstanceID
		String instanceId = (String)roles.get("INST_ID");
		session.setAttribute("instanceID", instanceId);
		log.debug("instanceId"+instanceId);*/
		
		// setTaskID
		log.debug("*********taskId************" + taskId);
		
		//Approval comments display
		String role = (String)roles.get("ROLE");
		submitActivityProcess.setTiReqCmtsList(submitActivityProcess.getComments(tiReqId, role, "A"));
		
		//Discussion comments display
		submitActivityProcess.setDiscussCmtsList(submitActivityProcess.getComments(tiReqId, role, "D"));
		
		//Template data display
		FireWallRuleProcess fireWallRuleProcess = new FireWallRuleProcess();
		List<IPAddress> objectIPList = fireWallRuleProcess.getObjectIPList(
				tiReqId, "IP");
		List<Port> objectPortList = fireWallRuleProcess.getObjectPortList(
				tiReqId, "IP");
		submitActivityProcess.setIpRegObjectIPList(objectIPList);
		submitActivityProcess.setIpRegObjectPortList(objectPortList);
		
		model.addAttribute("ipRegSubProcess", submitActivityProcess);
		
		return "c3par.ipRegSubmit";
	}
	
	
	@RequestMapping(value = "/submitIPREGSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String submit(ModelMap model,@ModelAttribute("ipRegSubProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request) {
	log.info("IPREG Submit Controller:Save method starts here...");
	
	try {
		formSubmit(submitActivityProcess,result,session,request);
		log.debug("IPREG Submit PAPI Enter ");
		
		//WsPapiFacade papiFacade = new WsPapiFacade ();
		
		String taskId = (String)session.getAttribute("taskId");
		String userId  = request.getHeader("SM_USER");
		String nextSelectedAction = submitActivityProcess.getCurrentAction();
		String tiReq = (String)session.getAttribute("tireqid");
		String nextRole = null;
		log.debug("taskId: " + taskId +"action"+nextSelectedAction);
		log.debug("userId: " + userId);
		
		log.debug("Before calling PAPI For BJ Submit");
		
		if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getProvideInfoRole());
		}else {
			nextRole = util.moveToActivity(submitActivityProcess.getCurrentRole());
		}
		
		log.debug("Selected role:"+nextRole);
		
		if ("UNLOCKED".equals( nextSelectedAction ) || "COMPLETED".equals( nextSelectedAction ) ) {
			papiFacade.completeActivity(userId, taskId, nextSelectedAction); 
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("REJECTED".equalsIgnoreCase(nextSelectedAction)){
			log.debug("inside Rejected scenario..."+nextSelectedAction);
			papiFacade.completeActivity(userId, taskId,"REJECTED");
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.completeActivity(userId, taskId, WsPapiFacade.ActivityStatus.PROVIDEINFO,WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("RESCHEDULED".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.rescheduleActivity(userId, Long.valueOf(tiReq),"ipregimpl_schedule_user_notification",submitActivityProcess.getIpRegOpAnalystScheduleDate());
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
	} catch (OperationException_Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return "forward:/defaultInboxView.act";
		
	}
	
	
	//data collection
    private void formSubmit(SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session,
			HttpServletRequest request)throws Exception{
    	log.debug("IPREG Submit Controller form Submit begins...");
    	
    	String messgXML = (String)request.getSession().getAttribute("MESSAGEXML");
		log.info("messgXML::"+messgXML);
		
		String tiReq = (String)session.getAttribute("tireqid");
		
		submitActivityProcess.setActivityRole((String)session.getAttribute("activityRole"));
		log.debug("activity role inside form submit:"+submitActivityProcess.getActivityRole());
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );
		
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		
		//Getting request type
		TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
		
		if(submitActivityProcess.getCurrentAction()==null){
			submitActivityProcess.setCurrentAction(ActivityData.STATUS_COMPLETED);
		}
		
		if(submitActivityProcess.getCurrentRole()==null){
			submitActivityProcess.setCurrentRole(submitActivityProcess.getActivityRole());
		}

		log.info("Request Parameters::"+request.getParameterNames());
		log.info("Request current role="+request.getParameter("currentRole"));
		log.info("current action =" + submitActivityProcess.getCurrentAction());
		log.info("current role=" + submitActivityProcess.getCurrentRole());
		log.info("comments = " + submitActivityProcess.getComments());
		

		String ssoID = request.getHeader("SM_USER");
		
		TiRequestComments tiReqComments = new TiRequestComments();
		tiReqComments.setTiRequest(tiRequest);
		tiReqComments.setComments(submitActivityProcess.getComments());
		tiReqComments.setRoleName(submitActivityProcess.getActivityRole());
		tiReqComments.setApproverSoeID(ssoID);
		
		//update IP Reg implementation data in ti_request table
		
		StringBuffer schTsmp = new StringBuffer();
		StringBuffer compTsmp = new StringBuffer();
		
		//reschedule date
		if(submitActivityProcess.getIpRegOpAnalystScheduleDate() !=null && !submitActivityProcess.getIpRegOpAnalystScheduleDate().isEmpty()){
			schTsmp.append(submitActivityProcess.getIpRegOpAnalystScheduleDate());
		}else{
			schTsmp.append("");
		}
		
		
		//completed date
		if(submitActivityProcess.getIpRegOpAnalystCompletedDate()!=null && !submitActivityProcess.getIpRegOpAnalystCompletedDate().isEmpty()
			&& submitActivityProcess.getIpRegOpAnalystCompletedTime()!=null && !submitActivityProcess.getIpRegOpAnalystCompletedTime().isEmpty()){
			compTsmp.append(submitActivityProcess.getIpRegOpAnalystCompletedDate());
			compTsmp.append(" ");
			compTsmp.append(submitActivityProcess.getIpRegOpAnalystCompletedTime());
		}else{
			compTsmp.append("");
		}
		
		
		log.debug("update information:"+schTsmp.toString()+"completed date"+compTsmp.toString()+"infoman id"+submitActivityProcess.getChangeNumber());
	
		submitActivityProcess.ipRegopAnalystUpdate(tiReqId, submitActivityProcess.getChangeNumber(), schTsmp.toString(), compTsmp.toString());
		
		if(ActivityData.STATUS_COMPLETED.equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
	    TIProcess tiProcess = submitActivityProcess.getProcessData(tiReqId.longValue());
	    
		if(ActivityData.IS_NEW.equals(tiProcess.getProcessActivityMode()) || ActivityData.IS_REWORK.equals(tiProcess.getProcessActivityMode())){
		    insertFAFQueueRequest(request,tiProcess.getId(),"insertintofafstate");
		}
		}
		
		//updating tiRequest comments
		if(!"PROVIDEINFO".equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
			submitActivityProcess.addComments(tiReqComments, "A", "save");
		}else {
			submitActivityProcess.addComments(tiReqComments, "D", "save");
		}
			
    }
    
    
    public void insertFAFQueueRequest(HttpServletRequest request, Long connectionRequestId, String requestType)
    	    throws Exception {
    		log.debug("TIRequestCommentsAction.insertFAFQueueRequest() START");
    		Util util=new Util();
    		if("all".equals(requestType)){
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculate","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculatepaf","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculateaaf","N");
    		} else if("terminateall".equals(requestType)){
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminatefaf","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminateaaf","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminatepaf","N");
    		} else {
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),requestType,"N");
    		}
    		FAFReviewThread.getInstance().startThread(request);
    		FAFReviewThread.getInstance().notifyThread();
    		log.debug("TIRequestCommentsAction.insertFAFQueueRequest() END");
    	    }
}
