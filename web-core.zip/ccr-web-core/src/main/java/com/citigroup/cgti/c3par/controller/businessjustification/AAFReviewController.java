package com.citigroup.cgti.c3par.controller.businessjustification;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.appsense.domain.ManageAppsenseProcess;
import com.citigroup.cgti.c3par.appsense.webtier.forms.AAFReviewForm;
import com.citigroup.cgti.c3par.businessjustification.domain.AAFReviewProcess;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiHierarchyXref;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.webtier.helper.FAFReviewThread;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class AAFReviewController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@Autowired
	AAFReviewProcess reviewProcess;

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/aafreviewload.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String aafReviewLoad(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		log.debug("Entering into aafReviewLoad()..");

		String result = "c3par.waitImgAAF";
		
		request.getSession().removeAttribute("AAFNoHeader");

		Long connectionId;
		Map<String, Object> implInfo = new HashMap<String, Object>();

		if (request.getParameter("processId") != null) {
			connectionId = Long.valueOf(request.getParameter("processId"));
			request.getSession().setAttribute("processId", connectionId);
		}else {

			connectionId = Long.valueOf(request.getSession()
					.getAttribute("processId").toString());
		}
		log.info("connectionId:: " + connectionId);
		if (connectionId != null) {
			if (!"".equals(connectionId)) {

				request.setAttribute("OriginalConnectionRequestId",
						connectionId);

			}
		}
		log.info("Before calling the function for generation of AAF Review ");
		String retValue = "";

		Long tirequestId = Long.valueOf(request.getSession()
				.getAttribute("tireqid").toString());

		log.info("tirequestId:: in aafReviewLoad::" + tirequestId);

		TIRequest tirequest = getReviewProcess().getTIRequestDetails(
				tirequestId);

		log.debug("The tirequest id: " + tirequest.getId());

		Util util = new Util();

		String requestType = null;

		if (tirequest.getTiRequestType() != null
				&& tirequest.getTiRequestType().getName() != null) {
			requestType = tirequest.getTiRequestType().getName();
			log.debug(" Request Type :: " + requestType);
			// Delete AAF is generated for Termination phase
			if (requestType != null
					&& requestType.equalsIgnoreCase("Terminate")) {
				retValue = util.queueFAFRequest(connectionId,
						request.getHeader("SM_USER"), "terminateaaf", "Y");
				FAFReviewThread.getInstance().notifyThread();
			} else {
				retValue = util.queueFAFRequest(connectionId,
						request.getHeader("SM_USER"), "generateaaf", "Y");
				FAFReviewThread.getInstance().notifyThread();
			}
		}
		if (!"true".equals(retValue)) {
			log.error(retValue);
			throw new ApplicationException(
					"Error During Generation of AAF Review Page! Please contact System Administrator.");
		}
		log.info("Successfully completed the generation of AAF Review ");
		log.info("Business details are getting executed");
		AAFReviewForm aafReviewForm = new AAFReviewForm();

		Long planningId = getReviewProcess().getPlanningId(tirequestId);
		Planning planning = getReviewProcess().getPlanningDetails(planningId);

		// }

		Relationship relationship = tirequest.getTiProcess()
				.getRelationshipId();

		request.setAttribute("relationshipid", relationship.getId());
		request.setAttribute("relationshipname", relationship.getName());

		if (relationship.getRelcitiHierarchyXrefs() != null) {
			RelCitiHierarchyXref relXref = (RelCitiHierarchyXref) relationship
					.getRelcitiHierarchyXrefs().get(0);

			if (relXref.getCitiHierarchyMaster() != null) {
				CitiHierarchyMaster citiMaster = relXref
						.getCitiHierarchyMaster();
				BusinessUnit bu = citiMaster.getBusinessUnit();
				request.setAttribute("buname", bu.getBusinessName());

			}
		}

		aafReviewForm.setBusinessDetails(util.getBusinessDetails1(connectionId,
				planning, "aaf"));

		ArrayList<HashMap<String, String>> initialList = util
				.getQueuedFAFRequests();

		ArrayList<ArrayList<String>> list = new ArrayList<ArrayList<String>>();

		ArrayList<String> changedList = null;

		for (HashMap<String, String> map : initialList) {

			changedList = new ArrayList<String>();

			changedList.add(map.get("WAITLIST_NO"));
			changedList.add(map.get("CON_REQ_ID"));
			changedList.add(map.get("REQ_TYPE"));
			changedList.add(map.get("STATUS"));

			list.add(changedList);

		}

		model.addAttribute("FAFRquestList", list);

		aafReviewForm.setFafqueueReqs(initialList);
		
		ArrayList<HashMap<String, String>> contactList = aafReviewForm
				.getBusinessDetails().getBusinessContacts();

		ArrayList<ArrayList<String>> finalList = new ArrayList<ArrayList<String>>();

		ArrayList<String> changedContactList = null;

		
		model.addAttribute("BusinessContactList", finalList);

		Long versionID = aafReviewForm.getBusinessDetails().getVersionId();
		if (versionID == null) {
			versionID = Long.valueOf(0);
		}
		String rationale = util.getRationaleByVersion(connectionId, versionID,
				"AAF");
		request.setAttribute("rationale", rationale);
		Map<String, String> sowAndCmp = util.getCMPAndSOWByVersion(
				connectionId, versionID, "AAF");
		
		log.debug("sowAndCmp is NULL: "+(null ==sowAndCmp));

		// Added by Uma - Spl Instr Starts
		implInfo = util.getImplementationInfo(connectionId, versionID, "aaf");
		log.debug("Review  Data --- " + implInfo.size());
		if (implInfo.size() > 0) {
			aafReviewForm.setApsSplInstruction((String) implInfo
					.get("SPL_INSTR"));
			aafReviewForm.setApsCompletionDate((String) implInfo
					.get("COMPLETION_DATE"));
			aafReviewForm.setApsInfomanId((Long) implInfo.get("INFOMAN_ID"));
			log.info("Implementation info -- Special Instruction-- "
					+ implInfo.get("SPL_INSTR"));
			log.info("Implementation info -- Completion Date-- "
					+ implInfo.get("COMPLETION_DATE"));
			log.info("Implementation info -- Infoman Id-- "
					+ implInfo.get("INFOMAN_ID"));

		}
		// Added by Uma - Spl Instr Ends
		// Added for 3908

		AppsenseADGroup appsenseADGroup = (AppsenseADGroup) util
				.getAppsenseADGroupName(connectionId, "AAF");
		if (appsenseADGroup != null) {
			log.info("AD Group Name:: " + appsenseADGroup.getName()
					+ " / Policy Id:: " + appsenseADGroup.getPolicyID() + "/"
					+ "Policy Name::: " + appsenseADGroup.getPolicyName());

		}

		request.setAttribute("current_versionID_aaf", versionID);

		model.addAttribute("aafReviewForm", aafReviewForm);

		this.getAppSenseData(request, connectionId);
		
		if( null != request.getParameter("action") && "loadNoHdr".equalsIgnoreCase(request.getParameter("action"))){
			
			result = "/pages/jsp/review/waitImgAAF";
		}

		log.debug("Exit from aafReviewLoad()..");

		return result;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/aafreviewcalculate.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String aafReviewCalculate(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		log.debug("Entering into aafReviewCalculate()..");

		String result = "c3par.aafManageReview";

		Long connectionId;
		Map<String,Object> implInfo = new HashMap<String,Object>();

		if (request.getParameter("processId") != null) {
			connectionId = Long.valueOf(request.getParameter("processId"));
		} else {

			connectionId = Long.valueOf(request.getSession()
					.getAttribute("processId").toString());
		}

		log.info("connectionId:: " + connectionId);
		if (connectionId != null) {
			if (!"".equals(connectionId)) {

				request.setAttribute("OriginalConnectionRequestId",
						connectionId);
			}
		}
		AAFReviewForm aafReviewForm = new AAFReviewForm();
		Long processId = connectionId;
		log.info("processId===" + processId);
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}
		log.info("tiRequestId===" + tiRequestId);

		Long tirequestId = Long.valueOf(request.getSession()
				.getAttribute("tireqid").toString());

		log.info("tirequestId:: in aafReviewLoad::" + tirequestId);

		TIRequest tirequest = getReviewProcess().getTIRequestDetails(
				tirequestId);

		log.debug("The tirequest id: " + tirequest.getId());

		Util util = new Util();

		Long planningId = getReviewProcess().getPlanningId(tirequestId);
		Planning planning = getReviewProcess().getPlanningDetails(planningId);

		Relationship relationship = tirequest.getTiProcess()
				.getRelationshipId();

		request.setAttribute("relationshipid", relationship.getId());
		request.setAttribute("relationshipname", relationship.getName());
		
		if (relationship.getRelcitiHierarchyXrefs() != null) {
			RelCitiHierarchyXref relXref = (RelCitiHierarchyXref) relationship
					.getRelcitiHierarchyXrefs().get(0);

			if (relXref.getCitiHierarchyMaster() != null) {
				CitiHierarchyMaster citiMaster = relXref
						.getCitiHierarchyMaster();
				BusinessUnit bu = citiMaster.getBusinessUnit();
				request.setAttribute("buname", bu.getBusinessName());

			}
		}

		aafReviewForm.setBusinessDetails(util.getBusinessDetails1(connectionId,
				planning, "aaf"));
		Long versionID = aafReviewForm.getBusinessDetails().getVersionId();
		if (versionID == null) {
			versionID = Long.valueOf(0);
		}
		request.setAttribute("current_versionID_aaf", versionID);
		log.info("version Id in calculate::" + versionID);

		FAFRequest fafRequest = new FAFRequest();
		String currentBusinessJustification = fafRequest.getOrigBusJustification(connectionId, versionID);
		
		request.setAttribute("currBusJustfi",currentBusinessJustification);
		
		Map<String,String> sowAndCmp = util.getCMPAndSOWByVersion(processId,versionID,"AAF");
		String CMPReview = sowAndCmp.get("CMP");
		String SOWReview = sowAndCmp.get("SOW");

		request.setAttribute("CMPReview", CMPReview);

		request.setAttribute("SOWReview", SOWReview);

		// Added by Uma - spl Instr Starts
		implInfo = util.getImplementationInfo(connectionId, versionID, "aaf");
		log.debug("Review  Data --- " + implInfo.size());
		if (implInfo.size() > 0) {
			aafReviewForm.setApsSplInstruction((String) implInfo
					.get("SPL_INSTR"));
			aafReviewForm.setApsCompletionDate((String) implInfo
					.get("COMPLETION_DATE"));
			aafReviewForm.setApsInfomanId((Long) implInfo.get("INFOMAN_ID"));
			log.info("Implementation info -- Special Instruction-- "
					+ implInfo.get("SPL_INSTR"));
			log.info("Implementation info -- Completion Date-- "
					+ implInfo.get("COMPLETION_DATE"));
			log.info("Implementation info -- Infoman Id-- "
					+ implInfo.get("INFOMAN_ID"));

		}
		// Added by Uma - spl Instr Starts
		// Added for 3908
		AppsenseADGroup appsenseADGroup = (AppsenseADGroup) util
				.getAppsenseADGroupName(processId, "AAF");
		if (appsenseADGroup != null) {
			log.info("AD Group Name:: " + appsenseADGroup.getName()
					+ " / Policy Id:: " + appsenseADGroup.getPolicyID() + "/"
					+ "Policy Name::: " + appsenseADGroup.getPolicyName());

			request.setAttribute("appsenseADGGroupName",
					appsenseADGroup.getName());
			request.setAttribute("appsenseADGGroupPolicyId",
					appsenseADGroup.getPolicyID());
			request.setAttribute("appsenseADGGroupPolicyName",
					appsenseADGroup.getPolicyName());

		}
		
		ArrayList<HashMap<String, String>> contactList = aafReviewForm
				.getBusinessDetails().getBusinessContacts();

		ArrayList<ArrayList<String>> finalList = new ArrayList<ArrayList<String>>();

		ArrayList<String> changedContactList = null;

		for (HashMap<String, String> map : contactList) {

			changedContactList = new ArrayList<String>();

			changedContactList.add(map.get("ROLE_NAME"));
			changedContactList.add(map.get("CONTACT_NAME"));
			changedContactList.add(map.get("CONTACT_GEID"));

			finalList.add(changedContactList);

		}

		model.addAttribute("BusinessContactList", finalList);

		model.addAttribute("aafReviewForm", aafReviewForm);

		request.getSession().setAttribute("aafReviewForm", aafReviewForm);

		this.getAppSenseData(request, connectionId);

		log.debug("Exit from aafReviewCalculate()..");

		return result;
	}

	@SuppressWarnings("unchecked")
	private void getAppSenseData(HttpServletRequest request,
			Long OriginalConnectionRequestId) {

		Util util = new Util();

		Long tirequestId = Long.valueOf(request.getSession()
				.getAttribute("tireqid").toString());

		log.info("tirequestId:: in aafReviewLoad::" + tirequestId);

		TIRequest tirequest = getReviewProcess().getTIRequestDetails(
				tirequestId);

		String connectionName = tirequest.getTiProcess().getProcessName();

		request.setAttribute("connectionName", connectionName);

		Long versionId = (Long) request.getAttribute("current_versionID_aaf");
		if (versionId == null) {
			versionId = Long.valueOf(0);
		}
		List<String> appsenseRecordData = util.getData_Appsense(
				OriginalConnectionRequestId, versionId);
		request.setAttribute("appsenseRecordData", appsenseRecordData);

		String appsense_implementer = util.getCurrentProcess_status(
				OriginalConnectionRequestId, versionId,
				ActivityData.ACTIVITY_APPSENSE_IMP);
		request.setAttribute("appsense_implementer", appsense_implementer);

		Long id = null;
		if (tirequest != null) {
			id = tirequest.getId();
		}
		if (id != null) {
			request.setAttribute("highRiskFlagAppsense",
					util.isAppsenseHighRisk(id) == true ? "Yes" : "No");
		} else {
			request.setAttribute("highRiskFlagAppsense", "No");
		}

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/aafreviewrecalculate.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String aafReviewRecalculate(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		log.debug("Entering into aafReviewRecalculate()..");

		String result = "c3par.waitImgAAF";

		Long connectionId;
		Map<String,Object> implInfo = new HashMap<String,Object>();

		if (request.getParameter("processId") != null) {
			connectionId = Long.valueOf(request.getParameter("processId"));
		} else {

			connectionId = Long.valueOf(request.getSession()
					.getAttribute("processId").toString());
		}
		log.info("connectionId:: " + connectionId);
		if (connectionId != null) {
			if (!"".equals(connectionId)) {

				request.setAttribute("OriginalConnectionRequestId",
						connectionId);

			}
		}
		log.info("Before calling the function for generation of AAF Review ");
		String retValue = "";

		Long tirequestId = Long.valueOf(request.getSession()
				.getAttribute("tireqid").toString());

		log.info("tirequestId:: in aafReviewLoad::" + tirequestId);

		TIRequest tirequest = getReviewProcess().getTIRequestDetails(
				tirequestId);

		log.debug("The tirequest id: " + tirequest.getId());

		Util util = new Util();

		String requestType = null;

		if (tirequest.getTiRequestType() != null
				&& tirequest.getTiRequestType().getName() != null) {
			requestType = tirequest.getTiRequestType().getName();
			log.debug(" Request Type :: " + requestType);
			// Delete AAF is generated for Termination phase
			if (requestType != null
					&& requestType.equalsIgnoreCase("Terminate")) {
				retValue = util.queueFAFRequest(connectionId,
						request.getHeader("SM_USER"), "terminateaaf", "Y");
				FAFReviewThread.getInstance().notifyThread();
			} else {
				retValue = util.queueFAFRequest(connectionId,
						request.getHeader("SM_USER"), "recalculateaaf", "Y");
				FAFReviewThread.getInstance().notifyThread();
			}
		}
		if (!"true".equals(retValue)) {
			log.error(retValue);
			throw new ApplicationException(
					"Error During Generation of AAF Review Page! Please contact System Administrator.");
		}
		log.info("Successfully completed the generation of AAF Review ");
		log.info("Business details are getting executed");
		AAFReviewForm aafReviewForm = new AAFReviewForm();

		Long planningId = getReviewProcess().getPlanningId(tirequestId);
		Planning planning = getReviewProcess().getPlanningDetails(planningId);

		Relationship relationship = tirequest.getTiProcess()
				.getRelationshipId();

		request.setAttribute("relationshipid", relationship.getId());
		request.setAttribute("relationshipname", relationship.getName());

		if (relationship.getRelcitiHierarchyXrefs() != null) {
			RelCitiHierarchyXref relXref = (RelCitiHierarchyXref) relationship
					.getRelcitiHierarchyXrefs().get(0);

			if (relXref.getCitiHierarchyMaster() != null) {
				CitiHierarchyMaster citiMaster = relXref
						.getCitiHierarchyMaster();
				BusinessUnit bu = citiMaster.getBusinessUnit();
				request.setAttribute("buname", bu.getBusinessName());

			}
		}

		aafReviewForm.setBusinessDetails(util.getBusinessDetails1(connectionId,
				planning, "aaf"));
		aafReviewForm.setFafqueueReqs(util.getQueuedFAFRequests());
		Long versionID = aafReviewForm.getBusinessDetails().getVersionId();
		if (versionID == null) {
			versionID = Long.valueOf(0);
		}
		
		FAFRequest fafRequest = new FAFRequest();
		String currentBusinessJustification = fafRequest.getOrigBusJustification(connectionId, versionID);
		
		request.setAttribute("currBusJustfi",currentBusinessJustification);
		
		
		
		String rationale = util.getRationaleByVersion(connectionId, versionID,
				"AAF");
		request.setAttribute("rationale", rationale);
		Map<String,String> sowAndCmp = util.getCMPAndSOWByVersion(connectionId,versionID,"AAF");
		String CMPReview = sowAndCmp.get("CMP");
		String SOWReview = sowAndCmp.get("SOW");

		request.setAttribute("CMPReview", CMPReview);

		request.setAttribute("SOWReview", SOWReview);
		
		log.debug("sowAndCmp is NULL: "+(null==sowAndCmp));

		// Added by Uma - Spl Instr Starts
		implInfo = util.getImplementationInfo(connectionId, versionID, "aaf");
		log.debug("Review  Data --- " + implInfo.size());
		if (implInfo.size() > 0) {
			aafReviewForm.setApsSplInstruction((String) implInfo
					.get("SPL_INSTR"));
			aafReviewForm.setApsCompletionDate((String) implInfo
					.get("COMPLETION_DATE"));
			aafReviewForm.setApsInfomanId((Long) implInfo.get("INFOMAN_ID"));
			log.info("Implementation info -- Special Instruction-- "
					+ implInfo.get("SPL_INSTR"));
			log.info("Implementation info -- Completion Date-- "
					+ implInfo.get("COMPLETION_DATE"));
			log.info("Implementation info -- Infoman Id-- "
					+ implInfo.get("INFOMAN_ID"));

		}
		// Added by Uma - Spl Instr Ends
		// Added for 3908

		AppsenseADGroup appsenseADGroup = (AppsenseADGroup) util
				.getAppsenseADGroupName(connectionId, "AAF");
		if (appsenseADGroup != null) {
			log.info("AD Group Name:: " + appsenseADGroup.getName()
					+ " / Policy Id:: " + appsenseADGroup.getPolicyID() + "/"
					+ "Policy Name::: " + appsenseADGroup.getPolicyName());

		}

		request.setAttribute("current_versionID_aaf", versionID);

		model.addAttribute("aafReviewForm", aafReviewForm);

		this.getAppSenseData(request, connectionId);

		log.debug("Exit from aafReviewRecalculate()..");
		return result;

	}

	@RequestMapping(value = "/aafreviewexport.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody String aafReviewExport(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		log.debug("Entering into aafReviewExport()..");

		AAFReviewForm aafReviewForm = (AAFReviewForm) request.getSession()
				.getAttribute("aafReviewForm");

		Long connectionId;

		if (request.getParameter("processId") != null) {
			connectionId = Long.valueOf(request.getParameter("processId"));
		} else {

			connectionId = Long.valueOf(request.getSession()
					.getAttribute("processId").toString());
		}

		Long processId = connectionId;
		log.info("processId===" + processId);
		Long versionID = aafReviewForm.getBusinessDetails().getVersionId();
		if (versionID == null) {
			versionID = Long.valueOf(0);
		}
		log.info("version Id::: " + versionID);
		Long version_export_id = null;

		String status = request.getParameter("status");
		log.info("Status::: " + status);
		if (status.equals("current")) {
			version_export_id = versionID;
		} else if (status.equals("previous")) {
			version_export_id = Long.valueOf(versionID.longValue() - 1);
		}

		Util util = new Util();
		Long tiRequestId = util.getTIRequestIdForVersion(processId,
				version_export_id.intValue());

		ManageAppsenseProcess appsenseProcess = new ManageAppsenseProcess();
		String aaf = appsenseProcess.getAppsenseAccessFormText(tiRequestId, processId,
				version_export_id);
		log.debug("aaf string: " + aaf);
		aaf = aaf.replaceAll("\n", "\r\n");

		model.addAttribute("aafString", aaf);

		aafReviewForm.setAafString(aaf);

		// Added for task 45182 ends
		log.info("tiRequestId===" + tiRequestId);
		response.setContentType("text/plain; charset=utf-8");
		response.setHeader("Content-Disposition", "attachment; filename="
				+ processId + "-" + versionID + ".txt");

		request.setAttribute("current_versionID_aaf", versionID);

		model.addAttribute("aafReviewForm", aafReviewForm);

		this.getAppSenseData(request, connectionId);

		log.debug("Exit from aafReviewExport()..");

		return aaf;

	}

	@RequestMapping(value = "/aafreviewexportall.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody String aafReviewExportAll(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		log.debug("Entering into aafReviewExportAll()..");		

		Long connectionId;

		if (request.getParameter("processId") != null) {
			connectionId = Long.valueOf(request.getParameter("processId"));
		} else {

			connectionId = Long.valueOf(request.getSession()
					.getAttribute("processId").toString());
		}

		Long processId = connectionId;
		log.info("processId===" + processId);

		AAFReviewForm aafReviewForm = (AAFReviewForm) request.getSession()
				.getAttribute("aafReviewForm");

		String tiReq = (String) request.getSession().getAttribute("tireqid");

		log.info("tiReq from SESSION===" + tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
			try {
				tiRequestId = Long.valueOf(tiReq);
			} catch (Exception e) {
				tiRequestId = Long.valueOf(0);
			}
		}

		ManageAppsenseProcess appsenseProcess = new ManageAppsenseProcess();
		String aaf = appsenseProcess.getAllAppsenseAccessFormText(tiRequestId, processId);
		aaf = aaf.replaceAll("\n", "\r\n");
		log.debug("aaf export all string" + aaf);
		aafReviewForm.setAafString(aaf);
		log.info("tiRequestId===" + tiRequestId);
		response.setContentType("text/plain; charset=utf-8");
		response.setHeader("Content-Disposition", "attachment; filename="
				+ processId + ".txt");

		model.addAttribute("aafReviewForm", aafReviewForm);

		model.addAttribute("aaf", aaf);

		this.getAppSenseData(request, connectionId);

		log.debug("Exit from aafReviewExportAll()..");
		
		return aaf;

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/aafreviewfilters.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String aafReviewFilters(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		log.debug("Entering into aafReviewFilters()..");

		String result = "c3par.aafManageReview";

		List<Object> combinationList = new ArrayList<Object>();
		
		Util util = new Util();

		Long connectionId;

		if (request.getParameter("processId") != null) {
			connectionId = Long.valueOf(request.getParameter("processId"));
		} else {

			connectionId = Long.valueOf(request.getSession()
					.getAttribute("processId").toString());

			request.setAttribute("OriginalConnectionRequestId", connectionId);
		}

		Long processId = connectionId;
		log.info("processId===" + processId);

		AAFReviewForm aafReviewForm = (AAFReviewForm) request.getSession()
				.getAttribute("aafReviewForm");

		log.info("processId===" + processId);
		Long versionID = aafReviewForm.getBusinessDetails().getVersionId();

		log.info("versionID:: " + versionID);
		if (versionID == null) {
			versionID = Long.valueOf(0);
		}
		log.info("version Id::: " + versionID);

		String type = (String) request.getParameter("setValue");
		log.info("type:: " + type);
		String appsenseType = (String) request.getParameter("apsTypes");
		log.info("selected appsenseType::" + appsenseType);
		Long combType = null;
		String[] temp = appsenseType.split(",");
		for (String element : temp) {
			log.info("temp:: " + element);
			if (element.equals("1")) {
				if (type != null) {
					if (type.equals("addFilters")) {
						combType = Long.valueOf(1);
						combinationList.add(getReviewProcess()
								.getApsNonNetworkCombination(processId,
										versionID, combType, Long.valueOf(1)));
					} else if (type.equals("deleteFilters")) {
						combType = Long.valueOf(3);
						combinationList.add(getReviewProcess()
								.getApsNonNetworkCombination(processId,
										versionID, combType, Long.valueOf(1)));
					}
				}
				request.setAttribute("displayNonNetworkFilter",
						"displayNonNetworkFilter");
			} else if (element.equals("2")) {
				if (type != null) {
					if (type.equals("addFilters")) {
						combType = Long.valueOf(1);
						combinationList.addAll(getReviewProcess()
								.getApsNetworkCombFilter(processId, versionID,
										combType, Long.valueOf(2)));
					} else if (type.equals("deleteFilters")) {
						combType = Long.valueOf(3);
						combinationList.addAll(getReviewProcess()
								.getApsNetworkCombFilter(processId, versionID,
										combType, Long.valueOf(2)));
					}
				}
				request.setAttribute("displayNetworkFilter",
						"displayNetworkFilter");
			} else if (element.equals("3")) {
				if (type != null) {
					if (type.equals("addFilters")) {
						combType = Long.valueOf(1);
						combinationList.add(getReviewProcess()
								.getApsUserCombination(processId, versionID,
										combType, Long.valueOf(3)));
					} else if (type.equals("deleteFilters")) {
						combType = Long.valueOf(3);
						combinationList.add(getReviewProcess()
								.getApsUserCombination(processId, versionID,
										combType, Long.valueOf(3)));
					}
				}
				request.setAttribute("displayUserFilter", "displayUserFilter");
			}
		}
		if (temp.length == 3) {
			request.setAttribute("displayNetworkFilter", "displayAllFilter");
		}
		log.info("size of comb List:: " + combinationList.size());
		log.info("displayNetworkFilter::: "
				+ request.getAttribute("displayNetworkFilter"));
		aafReviewForm.setCombinationList(combinationList);
		request.setAttribute("current_versionID_aaf", versionID);
		
		ArrayList<HashMap<String, String>> contactList = aafReviewForm
				.getBusinessDetails().getBusinessContacts();

		ArrayList<ArrayList<String>> finalList = new ArrayList<ArrayList<String>>();

		ArrayList<String> changedContactList = null;

		for (HashMap<String, String> map : contactList) {

			changedContactList = new ArrayList<String>();

			changedContactList.add(map.get("ROLE_NAME"));
			changedContactList.add(map.get("CONTACT_NAME"));
			changedContactList.add(map.get("CONTACT_GEID"));

			finalList.add(changedContactList);

		}
		
		Long tirequestId = Long.valueOf(request.getSession()
				.getAttribute("tireqid").toString());

		log.info("tirequestId:: in aafReviewFilters::" + tirequestId);

		TIRequest tirequest = getReviewProcess().getTIRequestDetails(
				tirequestId);
		
		Relationship relationship = tirequest.getTiProcess()
				.getRelationshipId();

		request.setAttribute("relationshipid", relationship.getId());
		request.setAttribute("relationshipname", relationship.getName());

		if (relationship.getRelcitiHierarchyXrefs() != null) {
			RelCitiHierarchyXref relXref = (RelCitiHierarchyXref) relationship
					.getRelcitiHierarchyXrefs().get(0);

			if (relXref.getCitiHierarchyMaster() != null) {
				CitiHierarchyMaster citiMaster = relXref
						.getCitiHierarchyMaster();
				BusinessUnit bu = citiMaster.getBusinessUnit();
				request.setAttribute("buname", bu.getBusinessName());

			}
		}
		
		FAFRequest fafRequest =  new FAFRequest();
		String currentBusinessJustification = fafRequest.getOrigBusJustification(connectionId, versionID);
		
		request.setAttribute("currBusJustfi",currentBusinessJustification);
		
		Map<String,String> sowAndCmp = util.getCMPAndSOWByVersion(processId,versionID,"AAF");
		String CMPReview = sowAndCmp.get("CMP");
		String SOWReview = sowAndCmp.get("SOW");

		request.setAttribute("CMPReview", CMPReview);

		request.setAttribute("SOWReview", SOWReview);
		

		model.addAttribute("BusinessContactList", finalList);

		model.addAttribute("aafReviewForm", aafReviewForm);

		this.getAppSenseData(request, connectionId);

		log.debug("Exit from aafReviewFilters()..");
		return result;

	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/aafreview.act", method = {RequestMethod.GET, RequestMethod.POST })	
	
	private String review(ModelMap model, HttpServletRequest request,
			HttpServletResponse response){
		log.info("Entering into review()...");
		
		String forwardTo ="c3par.aafManageReview";	 	
		HttpSession session = request.getSession();
		Util util = new Util();
		
		Long connectionId;

		if (request.getParameter("processId") != null) {
			connectionId = Long.valueOf(request.getParameter("processId"));
		} else {

			connectionId = Long.valueOf(request.getSession()
					.getAttribute("processId").toString());
		}
		
		log.info("connectionId:: " + connectionId);
		if (connectionId != null) {
			if (!"".equals(connectionId)) {

				request.setAttribute("OriginalConnectionRequestId",
						connectionId);

			}
		}

		Long processId = connectionId;
		log.info("processId===" + processId);		
		
		String reviewStatus = (String)request.getParameter("statusMode");
		log.info("reviewStatus::: "+reviewStatus);
		String tiReq = (String)request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION==="+tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
		    try {
			tiRequestId = Long.valueOf(tiReq);
		    } catch (Exception e) {
			tiRequestId = Long.valueOf(0);
		    }
		}
		log.info("tiRequestId==="+tiRequestId);
		
		
		AAFReviewForm aafReviewForm = (AAFReviewForm) request.getSession()
				.getAttribute("aafReviewForm");
		
		Long versionID = aafReviewForm.getBusinessDetails().getVersionId();

		log.info("versionID:: " + versionID);
		if (versionID == null) {
			versionID = Long.valueOf(0);
		}
		log.info("version Id::: " + versionID);		
		
		if(reviewStatus.equals("ReviewPrevious") && versionID != null && versionID.longValue() > 1 ){
		    versionID = Long.valueOf(versionID.longValue() -1);
		} else if( reviewStatus.equals("ReviewCurrent")){
		    versionID = util.getLatestVersionIdForAAFReview(connectionId);
		}
		String rationale = util.getRationaleByVersion(processId,versionID,"AAF");		
		
		//Added by Uma - Spl Instr  Starts
		Map implInfo=new HashMap();
		implInfo=util.getImplementationInfo(processId,versionID, "aaf");
		log.debug("Review  Data --- "+implInfo.size());
		if(implInfo.size()>0){
		    aafReviewForm.setApsSplInstruction((String)implInfo.get("SPL_INSTR"));
		    aafReviewForm.setApsCompletionDate((String)implInfo.get("COMPLETION_DATE"));
		    aafReviewForm.setApsInfomanId((Long)implInfo.get("INFOMAN_ID"));
		    log.info("Implementation info -- Special Instruction-- "+implInfo.get("SPL_INSTR"));
		    log.info("Implementation info -- Completion Date-- "+implInfo.get("COMPLETION_DATE"));
		    log.info("Implementation info -- Infoman Id-- "+implInfo.get("INFOMAN_ID"));

		}
		
		Long tirequestId = Long.valueOf(request.getSession()
				.getAttribute("tireqid").toString());

		log.info("tirequestId:: in aafReview::" + tirequestId);

		TIRequest tirequest = getReviewProcess().getTIRequestDetails(
				tirequestId);

		log.debug("The tirequest id: " + tirequest.getId());
		
		Long planningId = getReviewProcess().getPlanningId(tirequestId);
		Planning planning = getReviewProcess().getPlanningDetails(planningId);

		Relationship relationship = tirequest.getTiProcess()
				.getRelationshipId();

		request.setAttribute("relationshipid", relationship.getId());
		request.setAttribute("relationshipname", relationship.getName());

		if (relationship.getRelcitiHierarchyXrefs() != null) {
			RelCitiHierarchyXref relXref = (RelCitiHierarchyXref) relationship
					.getRelcitiHierarchyXrefs().get(0);

			if (relXref.getCitiHierarchyMaster() != null) {
				CitiHierarchyMaster citiMaster = relXref
						.getCitiHierarchyMaster();
				BusinessUnit bu = citiMaster.getBusinessUnit();
				request.setAttribute("buname", bu.getBusinessName());

			}
		}
		
		
		aafReviewForm.setBusinessDetails(util.getBusinessDetails1(connectionId,planning,"aaf",reviewStatus,versionID));
		//request.setAttribute("displayFilter", "review");
		aafReviewForm.setCombinationList(null);
		//Added for 3908	
		AppsenseADGroup appsenseADGroup = (AppsenseADGroup)util.getAppsenseADGroupName(processId,"AAF");
		if(appsenseADGroup != null){
		    log.info("AD Group Name:: "+appsenseADGroup.getName() +" / Policy Id:: "+appsenseADGroup.getPolicyID()+"/"+"Policy Name::: "+appsenseADGroup.getPolicyName());
		   
		}
		
		request.setAttribute("current_versionID_aaf", versionID);
		
		FAFRequest fafRequest = new FAFRequest();
		String currentBusinessJustification = fafRequest.getOrigBusJustification(connectionId, versionID);
		
		request.setAttribute("currBusJustfi",currentBusinessJustification);
		
		Map<String,String> sowAndCmp = util.getCMPAndSOWByVersion(processId,versionID,"AAF");
		String CMPReview = sowAndCmp.get("CMP");
		String SOWReview = sowAndCmp.get("SOW");

		request.setAttribute("CMPReview", CMPReview);

		request.setAttribute("SOWReview", SOWReview);
		
		this.getAppSenseData(request, connectionId);
		
		log.info("Exit from review()...");
		return forwardTo;
	    }

    public AAFReviewProcess getReviewProcess() {
        return reviewProcess;
    }

    public void setReviewProcess(AAFReviewProcess reviewProcess) {
        this.reviewProcess = reviewProcess;
    }

}
