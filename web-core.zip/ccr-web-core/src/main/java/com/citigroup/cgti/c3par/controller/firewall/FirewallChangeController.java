package com.citigroup.cgti.c3par.controller.firewall;

import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_BACKOUTPLAN;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_BASICINFO;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_CHANGETASK;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_DESCRIPTION;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_NETINFO;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_NETWORKDATA;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_REASON;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_TESTPLAN;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_TESTPLAN_PROXY;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_BACKOUTPLAN_PROXY;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_DESCRIPTION_PROXY;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FirewallChangeProcess;
import com.citigroup.cgti.c3par.fw.domain.ServiceNowMessageError;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetail;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetailAnswer;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCLookup;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class FirewallChangeController extends BaseController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@RequestMapping(value = "/listChangeRequests.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String listChangeRequests(HttpServletRequest request, ModelMap model) {
		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();

		if (request.getSession().getAttribute("fromPage") != null) {
			firewallChangeProcess.setFromPage((String) request.getSession()
					.getAttribute("fromPage"));
		} else {
			String fromPage = request.getParameter("fromPage");
			request.getSession().setAttribute("fromPage", fromPage);
			firewallChangeProcess.setFromPage(fromPage);
		}

		boolean isReview = false;
		String action = request.getParameter("action");
		log.info("action::: " + action);

		if (request.getSession().getAttribute("reviewing") != null) {
			isReview = true;
		}

		log.info("isREVIEW MODE:" + isReview);

		TIRequest tiRequestEntity = (TIRequest) request.getSession()
				.getAttribute("TI_REQUEST_ENTITY");

		String requestType = null;
		if (tiRequestEntity.getTiRequestType() != null
				&& tiRequestEntity.getTiRequestType().getName() != null) {
			requestType = tiRequestEntity.getTiRequestType().getName();
			log.debug(" Request Type :: " + requestType);
			if (requestType != null
					&& requestType.equalsIgnoreCase("Terminate")) {
				log.debug("Setting DisplayMode to Edit for Termination Cycle");
				request.getSession().setAttribute("displayMode", "Edit");
			}
		}
		FAFRequest fafRequest = new FAFRequest();

		TIRequest tiRequest = fafRequest.getTIRequest(tiRequestEntity.getId());

		String conType = request.getParameter("con_type");
		if (conType == null || conType.isEmpty()
				|| conType.trim().equalsIgnoreCase("")) {
			conType = (String) request.getSession().getAttribute("con_type");
		} else {
			request.getSession().setAttribute("con_type", conType);
		}

		String rfcGenFlag = "";
		if (conType != null && conType.equalsIgnoreCase("ipReg")) {
			rfcGenFlag = tiRequest.getIpRfcGenFlag();
		} else {
			rfcGenFlag = tiRequest.getRfcGenFlag();
		}

		if (rfcGenFlag != null) {
			request.getSession().setAttribute("rfcGenFlag", rfcGenFlag);
		} else {
			request.getSession().setAttribute("rfcGenFlag", "No RFC");
		}

		String fafComplete = (String) request.getSession().getAttribute(
				"isFAFComplete");

		String forward = (String) request.getSession().getAttribute("forward");
		if (forward != null && forward.equals("tec_arc")) {
			request.getSession().setAttribute("displayRFCMode", "Edit");
		}

		if ("true".equalsIgnoreCase(fafComplete)) {
			if (!isReview && "rfcReview".equalsIgnoreCase(action)
					&& rfcGenFlag != null && "N".equals(rfcGenFlag)) {

				String status = firewallChangeProcess.storeRfc(
						tiRequestEntity.getId(), conType);
				log.debug("FirewallChangeController.RFCStatus " + status);

				if (status != null && status.trim().equals("SUCCESS")) {
					request.getSession().setAttribute("rfcGenFlag", "true");
				}

			}
		}

		String snURL;

		String con_type = "";
		Util util = new Util();
		String selTab = request.getParameter("sel_tab");
		if (selTab != null) {
			request.getSession().setAttribute("selected_Tab",
					util.getSelectedTab(null, selTab, null));
		}
		String tab = (String) request.getSession().getAttribute("selected_Tab");
		log.debug("selected tab" + tab);
		if ("Implementation".equalsIgnoreCase(tab)) {
			con_type = "";
			log.debug(" Impl ConnectionType :: " + con_type);
		} else {
			con_type = (String) request.getSession().getAttribute("con_type");
			if (!"ipReg".equalsIgnoreCase(con_type)) {
				con_type = "Firewall";
			}
			log.debug(" Connection :: " + con_type);
		}
		List rfcRequestList = new ArrayList();
		if (tiRequestEntity.getTiProcess() != null) {
			rfcRequestList = firewallChangeProcess.getRFCRequestList(
					tiRequestEntity.getTiProcess().getId(), con_type);
			request.getSession().setAttribute("RFC_REQUEST_LIST",
					rfcRequestList);
		}
		snURL = firewallChangeProcess.getSnUrl();

		if (rfcRequestList != null && !rfcRequestList.isEmpty()) {
			for (Object object : rfcRequestList) {
				RFCRequest rfcRequest = (RFCRequest) object;
				log.debug(" rfcRequest.getRfcId() in FirewallChangeController :: " + rfcRequest.getRfcId());
				if(rfcRequest.getRfcId()!=null && !"".equals(rfcRequest.getRfcId()) && "ByPassed".equals(rfcRequest.getRfcId()))
				{
					request.getSession().setAttribute("SNOW_BY_PASS","Y");
				}
				
				
				rfcRequest.setHasError(firewallChangeProcess
						.hasSNOWErrorMsg(rfcRequest.getId()));
				rfcRequest.setSnURL(snURL);

				RFCDetail rfc = rfcRequest.getInstallStartDate();

				// Install Start Date format change, the format should be dd-mm-yyyy.
				if (null != rfc) {

					List<RFCDetailAnswer> rfcanswers = rfc
							.getRfcDetailAnswerList();

					String tempDate = null;
					String formattedDate = null;

					for (RFCDetailAnswer ans : rfcanswers) {

						tempDate = ans.getAnswer();
						
						if (tempDate != null && !"".equals(tempDate) && tempDate.length() >= 10) {
							if ("-".equals(String.valueOf(tempDate.charAt(4)))) {
								
								formattedDate = tempDate.substring(5, 7) + "/";
								formattedDate = formattedDate+tempDate.substring(8, 10) + "/";
								
								formattedDate = formattedDate
										+ tempDate.substring(0, 4);

								ans.setAnswer(formattedDate);
							}
						}

					}
				}

			}
		}

		firewallChangeProcess.setRfcRequests(rfcRequestList);

		isCompleteCheck(request);

		model.addAttribute("firewallChangeProcess", firewallChangeProcess);

		return "c3par.fwchange.list";

	}

	@RequestMapping(value = "/changeBasicInfo.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String changeBasicInfo(HttpServletRequest request, ModelMap model) {
		log.info("FirewallChangeController.changeBasicInfo()::Starts");
		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();
		RFCRequest selectedReq = null;

		if (request.getParameter("con_type") == null
				|| request.getParameter("con_type").isEmpty()) {
			selectedReq = (RFCRequest) request.getSession().getAttribute(
					"selectedReq");
		} else {
			String rfcId = request.getParameter("id");

			log.info("FirewallChangeController.changeBasicInfo():: with id = "
					+ rfcId);
			List<RFCRequest> rfcRequestList = (List<RFCRequest>) request
					.getSession().getAttribute("RFC_REQUEST_LIST");
			if (rfcId != null && rfcRequestList != null
					&& !rfcRequestList.isEmpty()) {
				for (RFCRequest rfcRequest : rfcRequestList) {
					if (Long.valueOf(rfcId).equals(rfcRequest.getId())) {
						selectedReq = rfcRequest;
						break;
					}
				}
			}

			request.getSession().setAttribute("selectedReq", selectedReq);
		}

		String conType = (String) request.getSession().getAttribute("con_type");

		String isIPReg = "";
		if (conType != null && conType.equalsIgnoreCase("ipReg")) {
			isIPReg = "Y";
		} else {
			isIPReg = "N";
		}

		if (selectedReq != null && selectedReq.getId() != null) {

			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_BASICINFO, isIPReg);

			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_CHANGETASK, isIPReg);

			String tempDate = "";
			String formattedDate = "";
			// Install Start Date format change, the format should be
			// dd-mm-yyyy.
			if (selectedReq != null
					&& selectedReq.getInstallStartDate() != null
					&& selectedReq.getInstallStartDate()
							.getRfcDetailAnswerList() != null
					&& !selectedReq.getInstallStartDate()
							.getRfcDetailAnswerList().isEmpty()) {
				List<RFCDetailAnswer> startDateAnswerList = selectedReq
						.getInstallStartDate().getRfcDetailAnswerList();

				for (RFCDetailAnswer ans : startDateAnswerList) {

					tempDate = ans.getAnswer();
					
					if (tempDate != null && !"".equals(tempDate) && tempDate.length() >= 10) {

						if ("-".equals(String.valueOf(tempDate.charAt(4)))) {

							formattedDate = tempDate.substring(8, 10) + "-";
							formattedDate = formattedDate
									+ tempDate.substring(5, 7) + "-";
							formattedDate = formattedDate
									+ tempDate.substring(0, 4);
							ans.setAnswer(formattedDate);
						}
					}
				}
			}
			// Install End Date format change, the format should be dd-mm-yyyy.
			if (selectedReq != null
					&& selectedReq.getInstallEndDate() != null
					&& selectedReq.getInstallEndDate().getRfcDetailAnswerList() != null
					&& !selectedReq.getInstallEndDate()
							.getRfcDetailAnswerList().isEmpty()) {
				List<RFCDetailAnswer> endDateAnswerList = selectedReq
						.getInstallEndDate().getRfcDetailAnswerList();

				for (RFCDetailAnswer ans : endDateAnswerList) {

					tempDate = ans.getAnswer();
					if (tempDate != null && !"".equals(tempDate) && tempDate.length() >= 10) {

						if ("-".equals(String.valueOf(tempDate.charAt(4)))) {

							formattedDate = tempDate.substring(8, 10) + "-";
							formattedDate = formattedDate
									+ tempDate.substring(5, 7) + "-";
							formattedDate = formattedDate
									+ tempDate.substring(0, 4);

							ans.setAnswer(formattedDate);
						}
					}
				}
			}
			firewallChangeProcess.setRfcRequest(selectedReq);
		}

		log.info("FirewallChangeController.changeBasicInfo()::Ends");

		model.addAttribute("firewallChangeProcess", firewallChangeProcess);

		return "c3par.fwchange.basicinfo";

	}

	@RequestMapping(value = "/changeNetInfo.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String changeNetInfo(HttpServletRequest request, ModelMap model) {
		log.info("FirewallChangeController.changeNetInfo()::Starts");
		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();
		RFCRequest selectedReq = (RFCRequest) request.getSession()
				.getAttribute("selectedReq");
		String conType = (String) request.getSession().getAttribute("con_type");

		String isIPReg = "";
		if (conType != null && conType.equalsIgnoreCase("ipReg")) {
			isIPReg = "Y";
		} else {
			isIPReg = "N";
		}
		if (selectedReq != null && selectedReq.getId() != null) {

			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_NETINFO, isIPReg);

			firewallChangeProcess.setRfcRequest(selectedReq);
		}

		log.info("FirewallChangeController.changeNetInfo()::Ends");

		model.addAttribute("firewallChangeProcess", firewallChangeProcess);

		return "c3par.fwchange.netinfo";

	}

	@RequestMapping(value = "/changeNetworkInfo.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String changeNetworkInfo(HttpServletRequest request, ModelMap model) {
		log.info("FirewallChangeController.changeNetInfo()::Starts");
		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();
		RFCRequest selectedReq = (RFCRequest) request.getSession()
				.getAttribute("selectedReq");
		String conType = (String) request.getSession().getAttribute("con_type");

		String isIPReg = "";
		if (conType != null && conType.equalsIgnoreCase("ipReg")) {
			isIPReg = "Y";
		} else {
			isIPReg = "N";
		}
		if (selectedReq != null && selectedReq.getId() != null) {

			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_NETWORKDATA, isIPReg);

			firewallChangeProcess.setRfcRequest(selectedReq);
		}

		log.info("FirewallChangeController.changeNetInfo()::Ends");

		model.addAttribute("firewallChangeProcess", firewallChangeProcess);

		return "c3par.fwchange.networkinfo";

	}

	@RequestMapping(value = "/changeReason.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String changeReason(HttpServletRequest request, ModelMap model) {
		log.info("FirewallChangeController.changeNetInfo()::Starts");
		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();
		RFCRequest selectedReq = (RFCRequest) request.getSession()
				.getAttribute("selectedReq");
		String conType = (String) request.getSession().getAttribute("con_type");

		String isIPReg = "";
		if (conType != null && conType.equalsIgnoreCase("ipReg")) {
			isIPReg = "Y";
		} else {
			isIPReg = "N";
		}
		if (selectedReq != null && selectedReq.getId() != null) {

			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_REASON, isIPReg);

			firewallChangeProcess.setRfcRequest(selectedReq);
		}

		log.info("FirewallChangeController.changeNetInfo()::Ends");

		model.addAttribute("firewallChangeProcess", firewallChangeProcess);

		return "c3par.fwchange.reason";

	}

	@RequestMapping(value = "/changeDescription.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String changeDescription(HttpServletRequest request, ModelMap model) {
		log.info("FirewallChangeController.changeNetInfo()::Starts");
		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();
		RFCRequest selectedReq = (RFCRequest) request.getSession()
				.getAttribute("selectedReq");
		String conType = (String) request.getSession().getAttribute("con_type");

		String isIPReg = "";
		if (conType != null && conType.equalsIgnoreCase("ipReg")) {
			isIPReg = "Y";
		} else {
			isIPReg = "N";
		}
		if (selectedReq != null && selectedReq.getId() != null
				&& "Proxy".equalsIgnoreCase(selectedReq.getRfcRequestType())) {
			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_DESCRIPTION_PROXY, isIPReg);
			firewallChangeProcess.setRfcRequest(selectedReq);
		} else {
			selectedReq.setDisplayType("display");
			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_DESCRIPTION, isIPReg);

			firewallChangeProcess.setRfcRequest(selectedReq);
		}

		log.info("FirewallChangeController.changeNetInfo()::Ends");

		model.addAttribute("firewallChangeProcess", firewallChangeProcess);

		return "c3par.fwchange.description";

	}

	@RequestMapping(value = "/changeBackoutPlan.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String changeBackoutPlan(HttpServletRequest request, ModelMap model) {
		log.info("FirewallChangeController.changeNetInfo()::Starts");
		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();
		RFCRequest selectedReq = (RFCRequest) request.getSession()
				.getAttribute("selectedReq");
		String conType = (String) request.getSession().getAttribute("con_type");
		String isIPReg = "";
		if (conType != null && conType.equalsIgnoreCase("ipReg")) {
			isIPReg = "Y";
		} else {
			isIPReg = "N";			
		}
	
		if (selectedReq != null && selectedReq.getId() != null
				&& "Proxy".equalsIgnoreCase(selectedReq.getRfcRequestType())) {
			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_BACKOUTPLAN_PROXY, isIPReg);
			firewallChangeProcess.setRfcRequest(selectedReq);
		} else {
			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_BACKOUTPLAN, isIPReg);
			firewallChangeProcess.setRfcRequest(selectedReq);
		}		
		log.info("FirewallChangeController.changeNetInfo()::Ends");
		model.addAttribute("firewallChangeProcess", firewallChangeProcess);
		return "c3par.fwchange.backoutplan";

	}

	@RequestMapping(value = "/changeTestPlan.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String changeTestPlan(HttpServletRequest request, ModelMap model) {
		log.info("FirewallChangeController.changeNetInfo()::Starts");
		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();
		RFCRequest selectedReq = (RFCRequest) request.getSession()
				.getAttribute("selectedReq");
		String conType = (String) request.getSession().getAttribute("con_type");

		String isIPReg = "";
		if (conType != null && conType.equalsIgnoreCase("ipReg")) {
			isIPReg = "Y";
		} else {
			isIPReg = "N";
		}
		if (selectedReq != null && selectedReq.getId() != null
				&& "Proxy".equalsIgnoreCase(selectedReq.getRfcRequestType())) {
			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_TESTPLAN_PROXY, isIPReg);
			firewallChangeProcess.setRfcRequest(selectedReq);
		} else {
			selectedReq = firewallChangeProcess.getRFCDetails(selectedReq,
					SECTION_TESTPLAN, isIPReg);

			firewallChangeProcess.setRfcRequest(selectedReq);
		}

		log.info("FirewallChangeController.changeNetInfo()::Ends");

		model.addAttribute("firewallChangeProcess", firewallChangeProcess);

		return "c3par.fwchange.testplan";

	}

	@RequestMapping(value = "/changeImpl.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String changeImpl(HttpServletRequest request, ModelMap model) {
		log.info("FirewallChangeController.changeImpl()::Starts");
		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();
		RFCRequest selectedReq = (RFCRequest) request.getSession()
				.getAttribute("selectedReq");
		String conType = (String) request.getSession().getAttribute("con_type");
		selectedReq.setTiRequest(getTirequest(request));
		String isIPReg = "";
		if (conType != null && conType.equalsIgnoreCase("ipReg")) {
			isIPReg = "Y";
		} else {
			isIPReg = "N";
		}
		if (selectedReq != null && selectedReq.getId() != null
				&& "Proxy".equalsIgnoreCase(selectedReq.getRfcRequestType())) {
			String fafInfo = firewallChangeProcess
					.getProxyAccessFormTextByRFC(selectedReq);
			firewallChangeProcess.setFafInfo(fafInfo.replaceAll("\n", " <br>"));
			firewallChangeProcess.setRfcRequest(selectedReq);
		} else {
			String fafInfo = firewallChangeProcess
					.getFirewallAccessFormTextByRFC(selectedReq);
			firewallChangeProcess.setFafInfo(fafInfo.replaceAll("\n", " <br>"));
			firewallChangeProcess.setRfcRequest(selectedReq);
		}

		log.info("FirewallChangeController.changeImpl()::Ends");

		model.addAttribute("firewallChangeProcess", firewallChangeProcess);

		return "c3par.fwchange.implplan";

	}

	@RequestMapping(value = "/changeError.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String changeError(HttpServletRequest request, ModelMap model) {
		log.info("FirewallChangeController.changeImpl()::Starts");
		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();
		RFCRequest selectedReq = (RFCRequest) request.getSession()
				.getAttribute("selectedReq");
		String conType = (String) request.getSession().getAttribute("con_type");

		String isIPReg = "";
		if (conType != null && conType.equalsIgnoreCase("ipReg")) {
			isIPReg = "Y";
		} else {
			isIPReg = "N";
		}
		if (selectedReq != null && selectedReq.getId() != null) {

			List<ServiceNowMessageError> servError = firewallChangeProcess
					.getSNOWErrorMsg(selectedReq.getId());
			firewallChangeProcess.setServiceNowMessageErrors(servError);
			firewallChangeProcess.setRfcRequest(selectedReq);
		}

		log.info("FirewallChangeController.changeImpl()::Ends");

		model.addAttribute("firewallChangeProcess", firewallChangeProcess);

		return "c3par.fwchange.error";

	}

	@RequestMapping(value = "/addNewChangeRecord.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String addNewChangeRecord(HttpServletRequest request, ModelMap model) {

		log.info("RfcReviewAction.addNewChangeRecord()::Starts");

		TIRequest tiRequestEntity = (TIRequest) request.getSession()
				.getAttribute("TI_REQUEST_ENTITY");

		FirewallChangeProcess firewallChangeProcess = new FirewallChangeProcess();
		firewallChangeProcess.setTiRequest(tiRequestEntity);

		String conType = (String) request.getSession().getAttribute("con_type");
		Map<String, String> locationMap = new HashMap<String, String>();
		List<RFCRequest> rfcRequestList = (List<RFCRequest>) request
				.getSession().getAttribute("RFC_REQUEST_LIST");

		RFCRequest rfcRequest1 = new RFCRequest();
		locationMap = firewallChangeProcess.getLocation();
		rfcRequest1.setLocationMap(locationMap);
		rfcRequest1.setRequestRuleTypeMap(firewallChangeProcess
				.getRequestRuleType());
		rfcRequest1.setCreate_type(RFCRequestDTO.RFC_CREATE_TYPE_MANUAL);

		firewallChangeProcess.setRfcRequest(rfcRequest1);

		firewallChangeProcess.setRfcRequests(rfcRequestList);

		if (request.getSession().getAttribute("fromPage") != null) {
			firewallChangeProcess.setFromPage((String) request.getSession()
					.getAttribute("fromPage"));
		}

		request.setAttribute("addnew", "true");
		model.addAttribute("firewallChangeProcess", firewallChangeProcess);

		log.info("RfcReviewAction.addNewChangeRecord()::Ends");

		return "c3par.fwchange.list";
	}

	@RequestMapping(value = "/storeManualChange.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String storeManualChange(
			HttpServletRequest request,
			ModelMap model,
			@ModelAttribute("firewallChangeProcess") FirewallChangeProcess firewallChangeProcess) {
		log.info(" ManageRFCImpl : storeManualRFC()  :Starts ");

		try {
			RFCRequest rfcRequest = firewallChangeProcess.getRfcRequest();
			TIRequest tiRequestEntity = (TIRequest) request.getSession()
					.getAttribute("TI_REQUEST_ENTITY");

			String isIpReg = "";
			final ActivityData activityData = (ActivityData) request
					.getSession().getAttribute("workflowActivityData");
			String activityName = activityData.getActivityName();
			if (activityName != null && !"".equals(activityName.trim())) {
				if (activityName.equals("Firewall Implementation")) {
					isIpReg = "N";
				} else {
					isIpReg = "Y";
				}
			}
			String rfcId = rfcRequest.getRfcId();
			TIRequest tiRequest = new TIRequest();
			tiRequest.setId(tiRequestEntity.getId());
			rfcRequest.setTiRequest(tiRequest);
			RFCRequestDTO rfcRequestDTO = new RFCRequestDTO();
			if (rfcId != null) {
				rfcRequestDTO.setRfcId(rfcId);
			}
			rfcRequestDTO.setTiRequestId(tiRequest.getId());
			rfcRequestDTO.setCreateType(RFCRequestDTO.RFC_CREATE_TYPE_MANUAL);
			rfcRequestDTO.setShortDescription(rfcRequest.getShortDesc());
			rfcRequestDTO.setLocation(rfcRequest.getLocationId());
			rfcRequestDTO.setInstallDate(rfcRequest.getInstallDateTime());
			rfcRequestDTO.setIsIpReg(isIpReg);
			rfcRequestDTO.setRequestType(rfcRequest.getRequestType());
			long id = firewallChangeProcess
					.storeManualChangeRecord(rfcRequestDTO);

			rfcRequest.setId(id);
			RFCLookup rfcLookup = (RFCLookup) firewallChangeProcess
					.getRFCLookup("BRIEF_DESCRIPTION");
			RFCDetail rfcDetail = new RFCDetail();
			rfcDetail.setRfcLookup(rfcLookup);
			rfcDetail.setRfcRequest(rfcRequest);
			rfcDetail.setSelected(true);
			RFCDetailAnswer rfcDetailAnswer = new RFCDetailAnswer();
			rfcDetailAnswer.setAnswer(rfcRequest.getShortDesc());
			rfcDetailAnswer.setRfcDetail(rfcDetail);
			List<RFCDetailAnswer> rfcDetailAnswerList = new ArrayList<RFCDetailAnswer>();
			rfcDetailAnswerList.add(rfcDetailAnswer);
			rfcDetail.setRfcDetailAnswerList(rfcDetailAnswerList);

			firewallChangeProcess.addRFCDetail(rfcDetail);

			// installDate
			rfcRequest.setId(id);
			rfcLookup = (RFCLookup) firewallChangeProcess
					.getRFCLookup("INSTALL_DATE");
			rfcDetail = new RFCDetail();
			rfcDetail.setRfcLookup(rfcLookup);
			rfcDetail.setRfcRequest(rfcRequest);
			rfcDetail.setSelected(true);
			rfcDetailAnswer = new RFCDetailAnswer();
			rfcDetailAnswer.setAnswer(rfcRequest.getInstallDateTime());
			rfcDetailAnswer.setRfcDetail(rfcDetail);
			rfcDetailAnswerList = new ArrayList<RFCDetailAnswer>();
			rfcDetailAnswerList.add(rfcDetailAnswer);
			rfcDetail.setRfcDetailAnswerList(rfcDetailAnswerList);

			firewallChangeProcess.addRFCDetail(rfcDetail);

		} catch (Exception e) {
			log.error(e, e);
			e.printStackTrace();
		}

		log.info(" ManageRFCImpl : storeManualRFC()  :Ends ");
		return "forward:/listChangeRequests.act";

	}

	@RequestMapping(value = "/rescheduleChange.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String rescheduleChange(
			HttpServletRequest request,
			ModelMap model,
			@ModelAttribute("firewallChangeProcess") FirewallChangeProcess firewallChangeProcess) {

		log.info("RfcReviewAction.loadRFCBasicInfo()::Starts");

		String rfcId = request.getParameter("id");

		log.info("RfcReviewAction.loadRFCBasicInfo():: with id = " + rfcId);
		List<RFCRequest> rfcRequestList = (List<RFCRequest>) request
				.getSession().getAttribute("RFC_REQUEST_LIST");

		if (rfcId != null && rfcRequestList != null
				&& !rfcRequestList.isEmpty()) {
			for (RFCRequest rfcRequest : rfcRequestList) {
				if (Long.valueOf(rfcId).equals(rfcRequest.getId())) {
					rfcRequest.setReschedule(true);
					firewallChangeProcess.setRfcRequest(rfcRequest);
					// break;
				} else {
					rfcRequest.setReschedule(false);
				}
			}
		}
		
		
		
		if (request.getSession().getAttribute("fromPage") != null) {
			firewallChangeProcess.setFromPage((String) request.getSession()
					.getAttribute("fromPage"));
		}
		firewallChangeProcess.setRfcRequests(rfcRequestList);
		model.addAttribute("firewallChangeProcess", firewallChangeProcess);
		log.info("RfcReviewAction.loadRFCBasicInfo()::Ends");

		return "c3par.fwchange.list";
	}

	@RequestMapping(value = "/rescheduleSave.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String rescheduleSave(
			HttpServletRequest request,
			ModelMap model,
			@ModelAttribute("firewallChangeProcess") FirewallChangeProcess firewallChangeProcess) {

		log.info("RfcReviewAction.loadRFCBasicInfo()::Starts");

		RFCRequest selectedReq = null;

		String rfcId = request.getParameter("id");

		String date = request.getParameter("installDate");

		log.info("RfcReviewAction.loadRFCBasicInfo():: with id = " + rfcId);
		List<RFCRequest> rfcRequestList = (List<RFCRequest>) request
				.getSession().getAttribute("RFC_REQUEST_LIST");
		if (rfcId != null && rfcRequestList != null
				&& !rfcRequestList.isEmpty()) {
			for (RFCRequest rfcRequest : rfcRequestList) {
				if (Long.valueOf(rfcId).equals(rfcRequest.getId())) {
					selectedReq = rfcRequest;
					break;
				}
			}
		}

		RFCDetail rfcDetail = firewallChangeProcess.getRFCDetail(
				Long.valueOf(rfcId), "INSTALL_DATE");

		if (rfcDetail != null) {
			selectedReq.setInstallDateTime(date);
			rfcDetail.setSelected(true);

			if (rfcDetail.getRfcDetailAnswerList() != null
					&& rfcDetail.getRfcDetailAnswerList().size() > 0) {
				RFCDetailAnswer rfcDetailAnswer = rfcDetail
						.getRfcDetailAnswerList().get(0);
				rfcDetailAnswer.setAnswer(selectedReq.getInstallDateTime());
			}

			firewallChangeProcess.updateRFCDetail(rfcDetail);
		} else {
			selectedReq.setInstallDateTime(date);
			RFCLookup rfcLookup = (RFCLookup) firewallChangeProcess
					.getRFCLookup("INSTALL_DATE");
			rfcDetail = new RFCDetail();
			rfcDetail.setRfcLookup(rfcLookup);
			rfcDetail.setRfcRequest(selectedReq);
			rfcDetail.setSelected(true);
			RFCDetailAnswer rfcDetailAnswer = new RFCDetailAnswer();
			rfcDetailAnswer.setAnswer(selectedReq.getInstallDateTime());
			rfcDetailAnswer.setRfcDetail(rfcDetail);
			List<RFCDetailAnswer> rfcDetailAnswerList = new ArrayList<RFCDetailAnswer>();
			rfcDetailAnswerList.add(rfcDetailAnswer);
			rfcDetail.setRfcDetailAnswerList(rfcDetailAnswerList);

			firewallChangeProcess.addRFCDetail(rfcDetail);
		}

		log.info("RfcReviewAction.loadRFCBasicInfo()::Ends");
		return "forward:/listChangeRequests.act";
	}

	@RequestMapping(value = "/cancelChange.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String cancelChange(
			HttpServletRequest request,
			ModelMap model,
			@ModelAttribute("firewallChangeProcess") FirewallChangeProcess firewallChangeProcess) {

		log.info("RfcReviewAction.loadRFCBasicInfo()::Starts");

		RFCRequest selectedReq = null;

		String rfcId = request.getParameter("id");

		log.info("RfcReviewAction.loadRFCBasicInfo():: with id = " + rfcId);
		List<RFCRequest> rfcRequestList = (List<RFCRequest>) request
				.getSession().getAttribute("RFC_REQUEST_LIST");
		if (rfcId != null && rfcRequestList != null
				&& !rfcRequestList.isEmpty()) {
			for (RFCRequest rfcRequest : rfcRequestList) {
				if (Long.valueOf(rfcId).equals(rfcRequest.getId())) {
					selectedReq = rfcRequest;
					break;
				}
			}
		}

		if (selectedReq != null && selectedReq.getId() != null) {

			Long chgNum = selectedReq.getId();

			firewallChangeProcess.cancelChange(chgNum);

		}

		log.info("RfcReviewAction.loadRFCBasicInfo()::Ends");
		return "forward:/listChangeRequests.act";
	}

	protected void isCompleteCheck(Long tiReqId, HttpServletRequest request) {
		String isRFCComplete = "false";

		if (isRFCGenerated(tiReqId, request)) {
			isRFCComplete = "true";
		}
		request.getSession().setAttribute("isRFCComplete", isRFCComplete);

	}

	private boolean isRFCGenerated(Long tiReqId, HttpServletRequest request) {
		FAFRequest fafRequest = new FAFRequest();
		TIRequest tiRequest = fafRequest.getTIRequest(tiReqId);
		String rfcGenFlag = tiRequest.getRfcGenFlag();
		if (null != rfcGenFlag) {
			return "Y".equalsIgnoreCase(rfcGenFlag);
		} else {
			return Boolean.valueOf((String) request.getSession().getAttribute(
					"isRFCComplete"));
		}
	}

}
