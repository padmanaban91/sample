/**
 * 
 */
package com.citigroup.cgti.c3par.scheduler;

import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleImpl;
import com.citigroup.cgti.c3par.webtier.helper.CSIUtil;

/**
 * @author bv49858
 *
 */
public class CSIApplicationSynchScheduler {
	
	private static Logger log = Logger.getLogger(CSIApplicationSynchScheduler.class);
	private JdbcTemplate jdbcTemplateCCR;
	private CSIUtil csiUtil;
	private MailModuleImpl mailModuleImpl;
	
	private static final String sendScheduledEmailFlag = System.getProperty("sendScheduledEmail.flag");

	public JdbcTemplate getJdbcTemplateCCR() {
		return jdbcTemplateCCR;
	}


	public void setJdbcTemplateCCR(JdbcTemplate jdbcTemplateCCR) {
		this.jdbcTemplateCCR = jdbcTemplateCCR;
	}


	public CSIUtil getCsiUtil() {
		return csiUtil;
	}


	public void setCsiUtil(CSIUtil csiUtil) {
		this.csiUtil = csiUtil;
	}


	public MailModuleImpl getMailModuleImpl() {
		return mailModuleImpl;
	}


	public void setMailModuleImpl(MailModuleImpl mailModuleImpl) {
		this.mailModuleImpl = mailModuleImpl;
	}


	public void synchCSIApplication() {
		log.info("Entering CSIApplicationSynchScheduler synchCSIApplication.");
		try {
			if("true".equalsIgnoreCase(sendScheduledEmailFlag)) {
				log.debug("isWebService : " +csiUtil.isWebServiceFlag());
				csiUtil.refreshCSIValuesInTIApplication(getCSIApplications(false), null, csiUtil.isWebServiceFlag());
				//Notifying to Business via mails
				mailModuleImpl.notificationForDecommissionedApp(csiUtil.getProcessIdsByTiApplicationID());
			}
		} catch (Exception e) {
			log.error("Exception in synchCSIApplication :",e);
		}
		log.info("Exiting CSIApplicationSynchScheduler synchCSIApplication.");
	}
	
	//Flag True to get Decommissioned Applications and False to get non-decommissioned CSI application
	private Set<String> getCSIApplications(boolean isDecommissionedFlag){
		log.info("Entering CSIApplicationSynchScheduler getCSIApplications.");
		StringBuilder query = new StringBuilder();
		//query.append("SELECT * FROM ( ");
    	query.append("SELECT DISTINCT application_id ");
    	query.append("FROM ti_application ");
    	if(!isDecommissionedFlag) {
    		query.append("WHERE is_decommissioned NOT LIKE 'Y' ");
    	} else {
    		query.append("WHERE is_decommissioned LIKE 'Y' ");
    	}
    	query.append("AND is_csi             ='Y' ");
    	query.append("AND application_id    IS NOT NULL ");
    	//query.append("ORDER BY application_id DESC ");
    	//query.append(") WHERE rownum <= 50 ");
    	Set<String> applicationIdList = new HashSet<String>();
		try {
			SqlRowSet rs = jdbcTemplateCCR.queryForRowSet(query.toString());
			while ( rs.next() ) {
				applicationIdList.add( rs.getString(1));
			}
		} catch (InvalidResultSetAccessException e) {
			log.error("InvalidResultSetAccessException in getCSIApplications",e);
		} catch (DataAccessException e) {
			log.error("DataAccessException in getCSIApplications",e);
		}
    	log.debug("Application Id List Size: "+applicationIdList.size());
    	log.info("Exiting CSIApplicationSynchScheduler getCSIApplications.");
    	return applicationIdList;
	}
}
