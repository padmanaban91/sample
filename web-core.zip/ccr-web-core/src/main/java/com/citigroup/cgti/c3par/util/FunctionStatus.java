package com.citigroup.cgti.c3par.util;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;


/**
 * The Class FunctionStatus.
 */
public class FunctionStatus {

    /** The instance. */
    static private FunctionStatus instance = null;

    /**
     * Gets the single instance of FunctionStatus.
     *
     * @return FunctionStatus instance
     */
    static synchronized public FunctionStatus getInstance() {
	if (instance == null) {
	    instance = new FunctionStatus();
	}
	return instance;
    }

    /**
     * Overriden constructor for default constructor.
     */
    private FunctionStatus() {
	//
    }

    /**
     * Sets the status.
     *
     * @param session the session
     * @param strFunctionName the str function name
     * @param strParentFunctionName the str parent function name
     * @param iFlag the i flag
     * @throws Exception the exception
     */
    public void setStatus (HttpSession session, String strFunctionName, String strParentFunctionName, String iFlag) throws Exception {
	boolean bComplete = false;
	ArrayList functionList = (ArrayList)session.getAttribute("FUNCTION_LIST");
	if ((functionList == null) || (functionList.size() <= 0)) {
	    throw new Exception("Invalid Session");
	}

	functionList = (childFunctions (functionList, functionList, strFunctionName, iFlag));
	if (functionList != null) {
	    session.setAttribute("FUNCTION_LIST", functionList);
	}
    }

    /**
     * Child functions.
     *
     * @param functionList the function list
     * @param parentFunctionList the parent function list
     * @param strFunctionID the str function id
     * @param iFlag the i flag
     * @return the array list
     */
    public ArrayList childFunctions (ArrayList functionList, ArrayList parentFunctionList, String strFunctionID, String iFlag) {
	if (functionList != null) {
	    for (int i=0; i<functionList.size();i++) {
		HashMap map = (HashMap)functionList.get(i);
		String strCurrentFunctionID = (String)map.get("function_id");
		if (strFunctionID.equals(strCurrentFunctionID)){
		    map.put("function_status", iFlag);
		    break;
		} else if (map.containsKey("child") && (map.get("child") != null)) {
		    childFunctions (((ArrayList)map.get("child")),parentFunctionList, strFunctionID, iFlag);
		}
	    }
	}
	return parentFunctionList;
    }

}
