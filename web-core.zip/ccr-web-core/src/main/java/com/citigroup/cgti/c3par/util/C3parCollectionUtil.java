/*
 * Created on Mar 27, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.util;

import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;


/**
 * The Class C3parCollectionUtil.
 *
 * @author gr61093
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class C3parCollectionUtil {

    /**
     * Search.
     *
     * @param list the list
     * @param key the key
     * @param c the c
     * @return the int
     */
    public static int search(List list, Object key, Comparator c) {
	ListIterator i = list.listIterator();
	int cmp = -1;
	while (i.hasNext()) {
	    cmp = c.compare(i.next(), key);
	    if (cmp == 0){
		return i.previousIndex();
	    }else if(cmp == -2){
		return cmp;
	    }
	}
	return cmp;
    }
}
