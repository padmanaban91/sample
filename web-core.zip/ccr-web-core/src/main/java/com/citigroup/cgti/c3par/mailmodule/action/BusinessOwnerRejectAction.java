package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;
import java.util.List;

import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;

public class BusinessOwnerRejectAction extends MailAction {

Logger log = Logger.getLogger(BusinessOwnerRejectAction.class);
	
private final static String ROLE_NAME = "Business_Owner";
	@Override
	public void process(IncomingMessage message) {

		log.info("Inside BusinessOwnerRejectAction process method ");
		
		super.processReject(message,ROLE_NAME);
		
	}
	
}
