package com.citigroup.cgti.c3par.mailmodule;

import java.io.IOException;

import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

public class IncomingMessage {
	
	Logger log = Logger.getLogger(IncomingMessage.class);
	
	String environment;
	String processId;
	int version;
	String action;
	String entity;
	String comments;
	String referenceNo;
	MimeMessage rawMessage;
	Address from_address;
	String email;
	String ssoId;
	String body;
	Long mailID;
	
	
	public IncomingMessage(MimeMessage message) {
		this.rawMessage = message;
		parse();
	}
	
	/**
	 * 
	 */
	private void parse() {
		// TODO Auto-generated method stub
		String subject = null;
		
		try {
			// DEV:1234.3:ISO:Approve
			//Prod example :23423.3:ISO:Approve
			
			subject = rawMessage.getSubject();
			log.debug("Subject: "+subject);
			String[] subjectArr = subject.split(":");
			environment = subjectArr[0];
			String connection[] = subjectArr[1].split("\\.");
			processId = connection[0];
			version = new Integer(connection[1]);
			entity = subjectArr[2];
			action = subjectArr[3];
			
			log.debug("MIME Type: "+rawMessage.getContentType());
			
			// Parse the content - to get comments and Reference Id
			try {
				body = getText(rawMessage);
			} catch (IOException e) {
				e.printStackTrace();
			}
			log.debug("body: "+body);
			if (body != null) {
				referenceNo = body.substring(0, body.indexOf("\n"));
				referenceNo = referenceNo.split(":")[1].trim();
				comments = body.substring(body.indexOf("comments below:>")+"comments below:>".length());
				if (comments != null && !comments.isEmpty()) {
					comments = comments.trim();
				} else {
					comments = body;
				}
				
				log.debug("Reference No: "+referenceNo);
				log.debug("Comments: "+comments);
			}
			
			// only one from address must be there. we will take the first
			from_address = rawMessage.getFrom()[0];
			
			// to get the email 
			if (from_address != null) {
				email = from_address.toString();
				//to get the ssoid
				if (email.indexOf("<") != -1 && email.indexOf("@") != -1) {
					ssoId = email.substring((email.indexOf("<")+1),email.indexOf("@"));
				}
			}
			
		} catch (MessagingException e) {
			log.error(e,e);
			e.printStackTrace();
		} 
		
	}
	
	/**
	 * 
	 * @param p
	 * @return
	 * @throws MessagingException
	 * @throws IOException
	 */
	private String getText(Part p) throws
		    MessagingException, IOException {
		if (p.isMimeType("text/plain")) {
		String s = (String)p.getContent();
		return s;
		}
		
		if (p.isMimeType("multipart/alternative")) {
		// prefer plain text over html text
		Multipart mp = (Multipart)p.getContent();
		String text = null;
		for (int i = 0; i < mp.getCount(); i++) {
		    Part bp = mp.getBodyPart(i);
		    if (bp.isMimeType("text/html")) {
		        if (text == null)
		            text = getText(bp);
		        continue;
		    } else if (bp.isMimeType("text/plain")) {
		        String s = getText(bp);
		        if (s != null)
		            return s;
		    } else {
		        return getText(bp);
		    }
		}
		return text;
		} else if (p.isMimeType("multipart/*")) {
		Multipart mp = (Multipart)p.getContent();
		for (int i = 0; i < mp.getCount(); i++) {
		    String s = getText(mp.getBodyPart(i));
		    if (s != null)
		        return s;
		}
		}

		return null;
	}
	
	/**
	 * 
	 * @param p
	 * @return
	 * @throws MessagingException
	 * @throws IOException
	 */
	private String getText(MimeMessage p) throws
    MessagingException, IOException {
		if (p.isMimeType("text/plain")) {
		String s = (String)p.getContent();
		return s;
		}
		
		if (p.isMimeType("multipart/alternative")) {
			// prefer plain text over html text
		Multipart mp = (Multipart)p.getContent();
		String text = null;
		for (int i = 0; i < mp.getCount(); i++) {
		    Part bp = mp.getBodyPart(i);
		    if (bp.isMimeType("text/html")) {
		        if (text == null)
		            text = getText(bp);
		        continue;
		    } else if (bp.isMimeType("text/plain")) {
		        String s = getText(bp);
		        if (s != null)
		            return s;
		    } else {
		        return getText(bp);
		    }
		}
		return text;
		} else if (p.isMimeType("multipart/*")) {
		Multipart mp = (Multipart)p.getContent();
		for (int i = 0; i < mp.getCount(); i++) {
		    String s = getText(mp.getBodyPart(i));
		    if (s != null)
		        return s;
		}
		}
		
		return null;
	}

	/**
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * @return the processId
	 */
	public String getProcessId() {
		return processId;
	}

	/**
	 * @param processId the processId to set
	 */
	public void setProcessId(String processId) {
		this.processId = processId;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the entity
	 */
	public String getEntity() {
		return entity;
	}

	/**
	 * @param entity the entity to set
	 */
	public void setEntity(String entity) {
		this.entity = entity;
	}

	/**
	 * @return the rawMessage
	 */
	public MimeMessage getRawMessage() {
		return rawMessage;
	}

	/**
	 * @param rawMessage the rawMessage to set
	 */
	public void setRawMessage(MimeMessage rawMessage) {
		this.rawMessage = rawMessage;
	}

	/**
	 * @return the from_address
	 */
	public Address getFrom_address() {
		return from_address;
	}

	/**
	 * @param fromAddress the from_address to set
	 */
	public void setFrom_address(Address fromAddress) {
		from_address = fromAddress;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the referenceNo
	 */
	public String getReferenceNo() {
		return referenceNo;
	}

	/**
	 * @param referenceNo the referenceNo to set
	 */
	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the ssoId
	 */
	public String getSsoId() {
		return ssoId;
	}

	/**
	 * @param ssoId the ssoId to set
	 */
	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public Long getMailID() {
		return mailID;
	}

	public void setMailID(Long mailID) {
		this.mailID = mailID;
	}	
}
