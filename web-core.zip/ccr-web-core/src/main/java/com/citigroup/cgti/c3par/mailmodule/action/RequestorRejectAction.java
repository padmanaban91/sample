package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;
import java.util.List;

import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;

public class RequestorRejectAction extends MailAction {

Logger log = Logger.getLogger(RequestorRejectAction.class);
	
private final static String ROLE_NAME = "Requestor";
	@Override
	public void process(IncomingMessage message) {
		
		log.info("Inside RequestorRejectAction process method ");
		
		super.processReject(message,ROLE_NAME);

		
	}
}
