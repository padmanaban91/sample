package com.citigroup.cgti.ccr.workflow.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityBPMDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.ManageActivityImpl;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.bpm.ejb.rel.SearchRelationshipImpl;
import com.citigroup.cgti.c3par.bpm.ejb.search.ISearchProcess;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.Process;
import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.citigroup.cgti.ccr.workflow.CCRWorkflowConstants;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.WorkflowResult;
import com.citigroup.cgti.ccr.workflow.database.service.WorkflowDBService;
//import com.citigroup.cgti.ccr.workflow.init.WsPapiFacade;
//import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.ccr.workflow.model.RequestControlsBPM;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;
import com.mentisys.dao.DatabaseException;

@Component
@Transactional
public class MigrationServiceImpl implements MigrationService{
	
	private static Logger log = Logger.getLogger(MigrationServiceImpl.class);
	
	@Autowired
	private WorkflowDBService workflowDBService;
	
	@Autowired
	WorkflowUtil workflowUtil;
	
	@Autowired
	WsPapiFacade papiFacade;
	
	@Autowired
	ManageTIProcessImpl manageTIProcessImpl;
	
	@Autowired
	ManageActivityImpl manageActivityImpl;
	
	@Autowired
	WorkflowCallServiceHelper wrkflowCallServiceHelper;
	
	@Autowired
	private SearchRelationshipImpl searchRelationshipImpl;
	
	@Autowired
	private ISearchProcess searchProcess;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private CommonServicePersistable commonServicePersistable;
	
	@Autowired
	private AdminServicePersistable adminServicePersistable;

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, timeout=1200) 
	public boolean migrateConnection(Long pID,String soeid,String status) throws Exception {
		log.info("Executing MigrationServiceImpl -- Start");
		log.info("Migration Start"+pID);
		System.out.println("Migration Start"+pID);
		try {
		//	ManageBPMInstanceProcess manageBPMInstanceProcess = new ManageBPMInstanceProcess();
			if (pID != 0) {
				Boolean isMigrationCompleted = workflowUtil
						.isProcessAlreadyMigrated(pID);
				if (!isMigrationCompleted) {
					WorkflowResult workflowResult = null;
					//List<ActivityBPMDTO> resultList = commonServicePersistable.getActivity(pID);
					if(StringUtil.isNullorEmpty(status)){
						status=ActivityDataDTO.STATUS_SCHEDULED;
					}
					List<ActivityBPMDTO> resultList = commonServicePersistable.getActivityByStatus(pID,status);
					List<ActivityBPMDTO> incompletionExpiredList = new ArrayList<ActivityBPMDTO>();
					if (this.isExpiredAndMoveToPreviousActivity(resultList)) {
						/*resultList = commonServicePersistable
								.getActivityByStatus(pID, "EXPIRED");*/
						//Change the status of Incompletion Expired work items
						incompletionExpiredList = commonServicePersistable
								.getActivityByStatus(pID,ActivityDataDTO.STATUS_SCHEDULED);
						resultList = commonServicePersistable
								.getActivityByStatus(pID,ActivityDataDTO.STATUS_EXPIRED);
					}
					/*if(!StringUtil.isNullorEmpty(status) && ActivityDataDTO.STATUS_SCHEDULED.equalsIgnoreCase(status)){
						incompletionExpiredList = commonServicePersistable
								.getActivityByStatus(pID,ActivityDataDTO.STATUS_SCHEDULED);
					}*/
					List<ActivityBPMDTO> providedInfoResultList = commonServicePersistable
							.getActivityByStatus(pID, ActivityDataDTO.STATUS_PROVIDEINFO);
					for (ActivityBPMDTO activityBPMDTO : !CollectionUtils
							.isEmpty(providedInfoResultList) ? providedInfoResultList
							: resultList) {
						workflowResult = initiateJBPMProcess(pID, soeid,
								activityBPMDTO,null,null);
						break;
					}
					/*lockMigratedConnection(
							!CollectionUtils.isEmpty(providedInfoResultList) ? providedInfoResultList
									: resultList, workflowResult, pID);*/
					if (!CollectionUtils.isEmpty(providedInfoResultList)) {
						this.initiateProvidedInfoTask(pID, soeid, resultList,
								providedInfoResultList);
						/*this.lockMigratedConnection(resultList, workflowResult,
								pID);*/
					}
					if(!CollectionUtils.isEmpty(incompletionExpiredList)){
						changeIncompletionAcitvityStatus(soeid,incompletionExpiredList);
					}
				}else{
					log.info("Process Already Migrated"+pID);
				}
			}}catch(Exception e){
				log.debug("error message"+e.getStackTrace());	
				throw e;
		    }
		log.info("Migration Start"+pID);
		log.info("Executing MigrationServiceImpl -- End");
		return false;
	}

	private void changeIncompletionAcitvityStatus(String soeid, List<ActivityBPMDTO> incompletionExpiredList)
			throws Exception {
		//if ("EXPIRED".equalsIgnoreCase(providedInfo)) {
			for (ActivityBPMDTO inCompletionActivity : incompletionExpiredList) {
				this.manageActivityImpl.completeActivity(
						inCompletionActivity.getActivityTrailID()
								.longValue(), soeid,
						CCRWorkflowConstants.MIGRATED);
			}
		//}
	}

	public WorkflowResult initiateJBPMProcess(Long pID, String soeid,
			ActivityBPMDTO activityBPMDTO,String activityCode,Long tiRequestId) throws Exception {
		WorkflowResult workflowResult;
		Map<String, String> activityCodes = new HashMap<String,String>();
		if(activityBPMDTO!=null){
		this.manageActivityImpl.completeActivity(activityBPMDTO
				.getActivityTrailID().longValue(), soeid,
				CCRWorkflowConstants.MIGRATED);
		log.debug("values name and tirquestid"
				+ activityBPMDTO.getActivityName()
				+ activityBPMDTO.getTiRequestId());
		log.debug("Process Id" + pID);
		log.debug("user id" + activityBPMDTO.getUserid());
		activityCodes = workflowDBService
				.getActivityCodeAndInstanceId(pID,
						String.valueOf(activityBPMDTO
								.getActivityId()));
	    }else{
	    	activityCodes.put("taskCode", activityCode);
	    	activityCodes.put("activityStage", this.getActivityStageBytaskCode(activityCode));
	    }
		Map<String, Object> workFlowParams = workflowUtil
				.buildWorkflowParamsForPlanning(activityBPMDTO!=null?activityBPMDTO
						.getTiRequestId():tiRequestId);
		RequestControlsBPM requestControl = (RequestControlsBPM) workFlowParams
				.get(CCRWorkflowConstants.REQUESTCONTROLBPM);
		requestControl.setActivityCode(activityCodes
				.get(CCRWorkflowConstants.TASK_CODE));
		requestControl.setActivityStage(activityCodes
				.get(CCRWorkflowConstants.ACTIVITY_STAGE));
		workFlowParams.put(
				CCRWorkflowConstants.ACTIVITYROUNTING,
				new Boolean(true));
		TIProcessDTO tIProcessDTO = manageTIProcessImpl
				.getProcessDTO(activityBPMDTO!=null?activityBPMDTO
						.getTiRequestId():tiRequestId);
		FlowType flowType = null;
		if (CCRWorkflowConstants.MAINTENANCE
				.equalsIgnoreCase(tIProcessDTO.getTiReqType())) {
			flowType = FlowType.MAINTENANCE;
		} else if (CCRWorkflowConstants.TERMINATION
				.equalsIgnoreCase(tIProcessDTO.getTiReqType())) {
			flowType = FlowType.TERMINATION;
		} else if (CCRWorkflowConstants.ACV
				.equalsIgnoreCase(tIProcessDTO.getTiReqType())) {
			flowType = FlowType.ACV;
		} else {
			flowType = FlowType.PLANNING;
		}
		if(CCRWorkflowConstants.ACV
				.equalsIgnoreCase(tIProcessDTO.getTiReqType())){
		Map<String, Object> workFlowParamsACV=workflowUtil.buildWorkflowParamsForACV(pID,"ACV");
		workFlowParamsACV.put(CCRWorkflowConstants.ACTIVITYROUNTING,new Boolean(true));
		workFlowParamsACV.put("tiRequestId",activityBPMDTO!=null? activityBPMDTO.getTiRequestId():tiRequestId);
		if("tmp_exp".equalsIgnoreCase(activityCodes.get(CCRWorkflowConstants.TASK_CODE))){
			workFlowParamsACV.put("requestType", "TEMP_APP");
		}
		workflowResult = wrkflowCallServiceHelper
				.callWorkflowService(flowType, workFlowParamsACV,
						WorkflowEvent.CREATE, null);
		}else{
		workflowResult = wrkflowCallServiceHelper
				.callWorkflowService(flowType, workFlowParams,
						WorkflowEvent.CREATE, null);
		}
		log.debug("Result "+workflowResult.getStatus());
		return workflowResult;
	}

	private void initiateProvidedInfoTask(Long pID, String soeid,
			List<ActivityBPMDTO> resultList,
			List<ActivityBPMDTO> providedInfoResultList) throws Exception,
			OperationException_Exception {
		if(!CollectionUtils.isEmpty(providedInfoResultList)){
			for (ActivityBPMDTO activityBPMDTO :resultList) {
				if(activityBPMDTO.getProvidedInfoActivityId()!=0){
					for(ActivityBPMDTO provideInfoDto:providedInfoResultList){
						if(provideInfoDto.getActivityTrailID()==activityBPMDTO.getProvidedInfoActivityId()){
							this.manageActivityImpl.completeActivity(activityBPMDTO
									.getActivityTrailID().longValue(), soeid,
									CCRWorkflowConstants.MIGRATED);
							Map<String, String> activityCodes = workflowDBService
									.getActivityCodeAndInstanceId(pID,
											String.valueOf(provideInfoDto.getActivityId()));
							Map<String, String> rejectedRolesMap = workflowDBService
									.getActivityCodeAndInstanceId(pID,
											String.valueOf(activityBPMDTO.getActivityId()));
							Util util=new Util();
							String provideInfoRole = CCRWorkflowConstants.PROVIDEINFO_ACTIVYT_ROLE_MAP.get(rejectedRolesMap.get("taskCode"));
							log.debug("ProvideInfoRole"+provideInfoRole);
							String nextRole = util.moveToActivity(provideInfoRole);
							String activityCode = activityCodes.get("taskCode");
							Map<String,Long> taskIds = workflowUtil
									.getWorkItemsByTiRequestId(activityBPMDTO.getTiRequestId());
							Long taskId=taskIds.get(activityCode);
							log.debug("taskId moving to providedinfo"+provideInfoRole);
							papiFacade.completeActivity(soeid,  String.valueOf(taskId), WsPapiFacade.ActivityStatus.PROVIDEINFO,WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
						}
					}
				}
			}
		}
	}

	private void lockMigratedConnection(List<ActivityBPMDTO> resultList,
			WorkflowResult workflowResult,Long pID) {
		log.info("Executing lockMigratedConnection -- Start");
		if(workflowResult!=null && CCRWorkflowConstants.STATUS_SUCCESS.equalsIgnoreCase(workflowResult.getStatus())){
			//AdminProcess adminProcess = new AdminProcess();
			for (ActivityBPMDTO activityBPMDTO : resultList) {
				if (activityBPMDTO.getUserid() != null){
					System.out.println("Locking with user id"+activityBPMDTO.getUserid());
					try{
					Map<String,Long> taskIds = workflowUtil
							.getWorkItemsByTiRequestId(activityBPMDTO.getTiRequestId());
					Map<String, String> activityCodes = workflowDBService
							.getActivityCodeAndInstanceId(pID,
									String.valueOf(activityBPMDTO
											.getActivityId()));
					String activityCode = activityCodes.get("taskCode");
                    if(CCRWorkflowConstants.LOGGING_QUEUE_ACTIVITIES.contains(activityCode) ||
                    		CCRWorkflowConstants.ACV_ACTIVITIES.contains(activityCode) || CCRWorkflowConstants.INCOMPLETION_ACTIVITIES.contains(activityCode)){
                    	break;
                    }
					if(activityCode==null){
						continue;
					}
					Long taskId=taskIds.get(activityCode);
					if(taskId==null || taskId == 0){
						continue;
					}
					C3parUser c3parUser = adminServicePersistable
							.retrieveC3parUser(activityBPMDTO
									.getUserid());
					if(c3parUser==null){
						return;
					}
						
					papiFacade.lockActivity(c3parUser.getSsoId(),
							String.valueOf(taskId), null);
					System.out.println("Locking with user id"+activityBPMDTO.getUserid()+"Sucessful");
					}catch(Exception e){
						log.debug("error message"+e.getStackTrace());
					}
				}
			}
		}
		log.info("Executing lockMigratedConnection -- End");
	}

	@Override
	public boolean migrateConnectionToActvity(String newActivity) {
		log.debug("migrateConnectionToActvity Start");
		try {
			List taskList = searchRelationshipImpl.getTaskList();
			//One Activity --Start
		     for(String activityCode:CCRWorkflowConstants.SINGLE_ACTIVITIES){
				startMigration(activityCode,"SCHEDULED");
			}
			for(String activityCode:CCRWorkflowConstants.IMPL_ACTIVITIES){
				startMigration(activityCode,"SCHEDULED");
			}
			for(String activityCode:CCRWorkflowConstants.PROVIDED_INFO_ACTIVITIES){
				startMigration(activityCode,"SCHEDULED");
			}
			//One Activity --End
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error"+e.getMessage());
		}
		log.debug("migrateConnectionToActvity End");
		return false;
	}

	public void startMigration(String activityCode,String activityStatus) throws DatabaseException {
		log.debug("Started Migration for Activity Code is "+activityCode);
		System.out.println("Started Migration for Activity Code is "+activityCode);
		List<Object> processIds=searchProcess.getScheduledProcessByAcitivityCode(activityCode, 0,activityStatus);
		log.debug("Total Size is"+processIds.size());
		System.out.println("Total Size is"+processIds.size());
		Session session = this.sessionFactory.getCurrentSession();
		for(Object processObj:processIds){
			try{
				Process proces=(Process)processObj;
				log.debug("Migration Start"+proces.getId());
				System.out.println("Need to migrate"+proces.getId());
				this.migrateConnection(proces.getId(), "SYSTEM",activityStatus);
				log.debug("Migration End"+proces.getId());
			}catch(Exception ex){
				System.out.println("Error Occured while processing request"+processObj);
				System.out.println("Exception Occuired"+ex);
			}
		}
	}

	private boolean isExpiredAndMoveToPreviousActivity(List<ActivityBPMDTO> activityList ){
		for(ActivityBPMDTO activityBPMDto:activityList){
			if(activityBPMDto.getActivityId() == 56 || 
					activityBPMDto.getActivityId() == 54 || activityBPMDto.getActivityId() == 51 ||
					activityBPMDto.getActivityId() == 52 || activityBPMDto.getActivityId() == 50 ){
				return true;
			}
		}
		return false;
	}
	private String getActivityStageBytaskCode(String taskCode){
		String activityStage=null;
		if(taskCode.equalsIgnoreCase("bus_jus")||taskCode.equalsIgnoreCase("tec_arc")) {
			activityStage="DC";
			taskCode="bus_jus";
		}else if(taskCode.equalsIgnoreCase("bu_mgr_app")||taskCode.equalsIgnoreCase("iso_app")||taskCode.equalsIgnoreCase("otrm_app")){
			activityStage="AP";
		}else if(taskCode.equalsIgnoreCase("han_rfc_exc_proxy") || taskCode.equalsIgnoreCase("ope_ipreg_imp") || taskCode.equalsIgnoreCase("ope_imp")||taskCode.equalsIgnoreCase("appsense_imp")||taskCode.equalsIgnoreCase("proxy_imp")||taskCode.equalsIgnoreCase("gncc_imp")||taskCode.equalsIgnoreCase("han_rfc_exc")){
			activityStage="IM";
		}else if(taskCode.equalsIgnoreCase("act_con")){
			activityStage="VA";
		}else {
			activityStage="";
		}
		return activityStage; 
	}
}
