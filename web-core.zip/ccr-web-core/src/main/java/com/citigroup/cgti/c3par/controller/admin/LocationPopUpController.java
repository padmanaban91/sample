package com.citigroup.cgti.c3par.controller.admin;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.citigroup.cgti.c3par.admin.domain.LocationPopUpProcess;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnitLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.ResourceTypeLocXref;
import com.citigroup.cgti.c3par.relationship.domain.ThirdParty;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyLocationXref;

@Controller
public class LocationPopUpController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@RequestMapping(value = "/getLocationDetailsForId.act", method =  { RequestMethod.GET, RequestMethod.POST })
	public String getLocationDetailsForId(ModelMap model,@RequestParam(value ="selectedId", required = false) String selectedId,
			@RequestParam(value ="requestType", required = false) String requestType, HttpServletRequest request) {
		
			log.debug("LocationPopUpController :: getLocationDetailsForId :: requestType - "+requestType);
			Long id= 0L;			
			LocationPopUpProcess locationPopUpProcess = new LocationPopUpProcess();
			locationPopUpProcess.setRequestType(requestType);
			
			if(selectedId != null){
				id = Long.parseLong(selectedId);
				log.debug("LocationPopUpController :: getLocationDetailsForId :: id - "+id);
				Location loc = locationPopUpProcess.getLocation(id);
				locationPopUpProcess.setLocation(loc);
			}else{
				ThirdPartyLocationXref tplocxref = new ThirdPartyLocationXref();
				BusinessUnitLocationXref bulocxref = new BusinessUnitLocationXref();
				ResourceTypeLocXref reslocxref = new ResourceTypeLocXref();
				
				if(requestType != null && requestType.equalsIgnoreCase("ThirdParty")){
					String selThirdParty = request.getParameter("selectedThirdParty");
					Long selectedThirdParty = Long.valueOf(selThirdParty);
					log.debug("LocationPopUpController :: getLocationDetailsForId :: location id empty ::selectedThirdParty "+selectedThirdParty);	
					
					ThirdParty thirdParty = new ThirdParty();
					thirdParty.setId(selectedThirdParty);
					tplocxref.setThirdParty(thirdParty);
				}else if(requestType != null && requestType.equalsIgnoreCase("BusinessUnit")){
					String selBusinessUnit = request.getParameter("selectedBusinessUnit");
					Long selectedBusinessUnit = Long.valueOf(selBusinessUnit);
					log.debug("LocationPopUpController :: getLocationDetailsForId :: location id empty ::selectedBusinessUnit "+selectedBusinessUnit);	
					
					BusinessUnit businessUnit = new BusinessUnit();
					businessUnit.setId(selectedBusinessUnit);
					bulocxref.setBusinessUnit(businessUnit);
				}else if(requestType != null && requestType.equalsIgnoreCase("ResourceType")){
					String selResourceType = request.getParameter("selectedResourceType");
					Long selectedResourceType = Long.valueOf(selResourceType);
					log.debug("LocationPopUpController :: getLocationDetailsForId :: location id empty ::selectedResourceType "+selectedResourceType);	
					
					ResourceType resourceType = new ResourceType();
					resourceType.setId(selectedResourceType);
					reslocxref.setResourceType(resourceType);
				}
				
				locationPopUpProcess.setLocation(new Location());
				locationPopUpProcess.setTpLocXref(tplocxref);
				locationPopUpProcess.setBuLocXref(bulocxref);
				locationPopUpProcess.setResTypeLocXref(reslocxref);
			}
			locationPopUpProcess.setCountry(locationPopUpProcess.getListofCountries());
			locationPopUpProcess.setRegion(locationPopUpProcess.getListOfRegions());
			model.addAttribute("locationPopUpProcess", locationPopUpProcess);
			
			return "pages/dashboard/AddLocationPopup";
		}
	
	@RequestMapping(value = "/saveLocationDetails.act", method ={ RequestMethod.GET, RequestMethod.POST })
	public String saveLocationDetails(ModelMap model,@ModelAttribute("locationPopUpProcess") LocationPopUpProcess locationPopUpProcess,HttpServletRequest request) {
		log.debug("LocationPopUpController :: saveLocationDetails :: method starts ");
		
		if(locationPopUpProcess!=null){
			log.debug("LocationPopUpController :: saveLocationDetails :: loc details "+locationPopUpProcess.getLocation().getId() +locationPopUpProcess.getLocation().getCity());
			locationPopUpProcess.saveLocationDetails();
		}else{
			log.debug("LocationPopUpController :: saveLocationDetails :: not there");
		}
		
		return "pages/dashboard/AddLocationPopup";
	}
}
