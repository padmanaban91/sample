/*
 * Created on May 31, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.reports.util;

import java.util.Enumeration;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.citigroup.cgti.c3par.reports.reportInterface.DataResetter;
import com.citigroup.cgti.c3par.reports.reportImpl.SQLStmt.ReportDataComponentFactory;
import com.mentisys.util.logging.Logger;



/**
 * The Class SessionHandler.
 *
 * @author Gerald Robinson
 * 
 * </br>
 * <h1>Description</h1>
 * This implementation provides the necessary cleanup capability once the session is invalidated.
 */
public class SessionHandler implements HttpSessionListener {

    /** The Constant log. */
    static private final Logger log = Logger.getLogger("reports", Util.class);

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpSessionListener#sessionCreated(javax.servlet.http.HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent arg0) {


	// TODO Auto-generated method stub

    }
    /* (non-Javadoc)
     * @see javax.servlet.http.HttpSessionListener#sessionDestroyed(javax.servlet.http.HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent sessionEvent) {
	HttpSession session = sessionEvent.getSession();
	Enumeration enum1 = session.getAttributeNames();
	while(enum1.hasMoreElements()) {
	    String attrName = (String) enum1.nextElement();
	    Object o = session.getAttribute(attrName);

	    if(o instanceof ReportDataComponentFactory) {
		DataResetter resetter = null ;
		ReportDataComponentFactory rdcf = (ReportDataComponentFactory) o;
		try {
		    resetter = rdcf.getDataResetter();
		    if(rdcf.getDataInitializer().getReportMetaEntity().getReportsPackage().getName().trim().equalsIgnoreCase("CUSTOM") ||
			    rdcf.getDataInitializer().getReportMetaEntity().getReportSchedule().getType().trim().equals("ON_DEMAND")){
			resetter.deleteTable();
		    }
		} catch(Exception e) {
		    log.warning("Temporary table could not be cleaned when the User session got invalidated. TableName " + resetter.getTemporaryTable(), new Object[] {e});
		}
	    }
	}
    }
}
