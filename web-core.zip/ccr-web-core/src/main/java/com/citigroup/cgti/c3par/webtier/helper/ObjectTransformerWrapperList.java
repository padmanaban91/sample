package com.citigroup.cgti.c3par.webtier.helper ;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Logger;



/**
 * The Class ObjectTransformerWrapperList.
 */
public class ObjectTransformerWrapperList implements List {

    /** The transformable object list. */
    private List transformableObjectList ;

    /** The transformed object map. */
    private Map transformedObjectMap = new HashMap();

    /** The transformed object array. */
    private Object[] transformedObjectArray ;

    /** The log. */
    private static Logger log = Logger.getLogger(ObjectTransformerWrapperList.class);

    /** The transformer. */
    private Transformer transformer ;

    /**
     * Instantiates a new object transformer wrapper list.
     *
     * @param transformableObjectList the transformable object list
     * @param transformer the transformer
     */
    public ObjectTransformerWrapperList (List transformableObjectList, Transformer transformer) {
	if(transformableObjectList != null) {
	    this.transformableObjectList = transformableObjectList ;
	}
	else {
	    this.transformableObjectList = new ArrayList(0);
	}

	this.transformer = transformer ;
	this.transformedObjectArray = new Object[this.transformableObjectList.size() + 4];
    }

    /* (non-Javadoc)
     * @see java.util.List#get(int)
     */
    public Object get(int objAtPos) {
	Object o = null ;

	checkToResize(objAtPos);

	// check is the object was transformed earlier
	if((o = transformedObjectArray[objAtPos]) == null) {
	    // this means the object at that index was never transformed.
	    // hence it should be transformed
	    o = transformer.transform(transformableObjectList.get(objAtPos));

	    // put it into the transformed object cache
	    transformedObjectArray[objAtPos] = o;
	} else {
	    // nothing to do here. Atleast for now.
	}

	return o;
    }

    /* (non-Javadoc)
     * @see java.util.List#size()
     */
    public int size() {
	return transformableObjectList.size();
    }

    /* (non-Javadoc)
     * @see java.util.List#remove(int)
     */
    public Object remove(int index) {
	// get the object at the given index
	Object o = transformedObjectArray[index] ;

	// move the elements in the array from right to left 
	System.arraycopy(transformedObjectArray, index+1, transformedObjectArray, index, transformedObjectArray.length-index-1);

	// fill the last element with null
	transformedObjectArray[transformedObjectArray.length-1] = null ;

	transformableObjectList.remove(index);

	return o ;
    }

    /* (non-Javadoc)
     * @see java.util.List#isEmpty()
     */
    public boolean isEmpty() {
	return transformableObjectList.isEmpty() ;
    }

    /* (non-Javadoc)
     * @see java.util.List#iterator()
     */
    public Iterator iterator() {
	return new OwnerListObjectIterator();
    }

    /* (non-Javadoc)
     * @see java.util.List#toArray()
     */
    public Object[] toArray() {
	int count = transformableObjectList.size();
	Object[] container = new Object[count];
	System.arraycopy(transformedObjectArray, 0, container, 0, count);
	return container ;
    }

    /* (non-Javadoc)
     * @see java.util.List#clear()
     */
    public void clear() {
	for(int i=0;i<transformedObjectArray.length;i++) {
	    transformedObjectArray[i] = null ;
	}
    }

    /**
     * Check to resize.
     *
     * @param index the index
     */
    private void checkToResize(int index) {
	// whats the size of the original list
	int size = transformableObjectList.size() ;

	// whats the size of the transformed object array
	int arrLen = transformedObjectArray.length; 

	// if the requested index is not available in the array but exists in the original list
	// then resize the array
	if(index >= arrLen && index < size) {
	    Object[] newArray = new Object[size + 4];

	    System.arraycopy(transformedObjectArray, 0, newArray, 0, arrLen);

	    transformedObjectArray = newArray ;
	}
    }

    /* (non-Javadoc)
     * @see java.util.List#set(int, java.lang.Object)
     */
    public Object set(int index, Object objToSet) {
	// set the object in the transformable object list
	transformableObjectList.set(index, objToSet);

	// transform objToSet to the corresponding element in transformedObjectArray 
	transformedObjectArray[index] = transformer.transform(objToSet) ;

	return transformedObjectArray[index] ;
    }

    /**
     * Gets the wrapped list.
     *
     * @return the wrapped list
     */
    public List getWrappedList() {
	return transformableObjectList ;
    }

    /* (non-Javadoc)
     * @see java.util.List#contains(java.lang.Object)
     */
    public boolean contains(Object arg0) {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#toArray(T[])
     */
    public Object[] toArray(Object[] arg0) {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#add(java.lang.Object)
     */
    public boolean add(Object addObj) {
	return transformableObjectList.add(addObj);
    }

    /* (non-Javadoc)
     * @see java.util.List#remove(java.lang.Object)
     */
    public boolean remove(Object arg0) {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#containsAll(java.util.Collection)
     */
    public boolean containsAll(Collection arg0) {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#addAll(java.util.Collection)
     */
    public boolean addAll(Collection arg0) {
	return transformableObjectList.addAll(arg0);
    }

    /* (non-Javadoc)
     * @see java.util.List#addAll(int, java.util.Collection)
     */
    public boolean addAll(int arg0, Collection arg1) {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#removeAll(java.util.Collection)
     */
    public boolean removeAll(Collection arg0) {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#retainAll(java.util.Collection)
     */
    public boolean retainAll(Collection arg0) {
	throw new UnsupportedOperationException();
    }


    /* (non-Javadoc)
     * @see java.util.List#add(int, java.lang.Object)
     */
    public void add(int arg0, Object arg1) {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#indexOf(java.lang.Object)
     */
    public int indexOf(Object arg0) {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#lastIndexOf(java.lang.Object)
     */
    public int lastIndexOf(Object arg0) {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#listIterator()
     */
    public ListIterator listIterator() {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#listIterator(int)
     */
    public ListIterator listIterator(int arg0) {
	throw new UnsupportedOperationException();
    }

    /* (non-Javadoc)
     * @see java.util.List#subList(int, int)
     */
    public List subList(int arg0, int arg1) {
	throw new UnsupportedOperationException();
    }

    /**
     * The Class OwnerListObjectIterator.
     */
    public class OwnerListObjectIterator implements Iterator {

	/** The curr. */
	private int curr = 0 ;

	/** The size. */
	private int size = transformableObjectList.size();

	/* (non-Javadoc)
	 * @see java.util.Iterator#hasNext()
	 */
	public boolean hasNext() {
	    return (curr < size ? true : false ); 
	}

	/* (non-Javadoc)
	 * @see java.util.Iterator#next()
	 */
	public Object next() {
	    return get(curr ++ ); 
	}

	/* (non-Javadoc)
	 * @see java.util.Iterator#remove()
	 */
	public void remove() {
	    ObjectTransformerWrapperList.this.remove(--curr);
	    size = transformableObjectList.size();
	}
    }


    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
	List l = new ArrayList();
	l.add("cba");
	l.add("zyx");
	l.add("itic");
	l.add("puorgitic");

	ObjectTransformerWrapperList myList = new ObjectTransformerWrapperList(l, new StringReverser());

	for(int i=0;i<myList.size();i++)
	    log.debug("Reversed " + myList.get(i));


	Iterator it = myList.iterator();
	while(it.hasNext()) {
	    log.debug("Item >> " + it.next());
	}


	Object ar[] = myList.toArray();
	for (Object element : ar)
	    log.debug("Reversed " + element);

	myList.remove(3);
	myList.remove(1);


	Iterator it1 = myList.iterator();
	while(it1.hasNext()) {
	    log.debug("Item >> " + it1.next());
	}


	Iterator u = l.iterator();
	while(u.hasNext()) {
	    log.debug("Item >> " + u.next());
	}

    }

    /**
     * The Class StringReverser.
     */
    private static class StringReverser implements Transformer {

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.webtier.helper.transformer.Transformer#transform(java.lang.Object)
	 */
	public Object transform (Object obj) {
	    Object returnValue = obj ;

	    if(obj instanceof String) {
		String s = (String) obj ;

		returnValue = new StringBuffer(s).reverse().toString(); 
	    }

	    return returnValue ;
	}
    }
}