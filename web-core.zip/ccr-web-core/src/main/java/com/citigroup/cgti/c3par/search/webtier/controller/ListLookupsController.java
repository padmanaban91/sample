package com.citigroup.cgti.c3par.search.webtier.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.admin.domain.ListLookupProcess;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.GenericLookupDef;

@Controller
public class ListLookupsController {

	/** The log. */
	private static Logger log = Logger.getLogger(ListLookupsController.class);
	
	private ListLookupProcess listLookupProcess;
	  
	public ListLookupProcess getListLookupProcess() {
		return listLookupProcess;
	}
 
	public void setListLookupProcess(ListLookupProcess listLookupProcess) {
		this.listLookupProcess = listLookupProcess;
	}

	/**
	 * To Load the List Lookup Data Screen
	 * 
	 * @return
	 */
	@RequestMapping(value = "/listLookupsController.act", method =  { RequestMethod.GET, RequestMethod.POST })
	public String listManageLookupData(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		log.debug(" Enter::listLookupsController methods starts...");
		Map<Long, String> lookupTypeObj = new HashMap<Long, String>();
		ListLookupProcess listLookupProcess = new ListLookupProcess(); 
		List<GenericLookupDef> lookupDTOList = listLookupProcess.getListLookupData();

		for (GenericLookupDef genLooupListObj : lookupDTOList) {
     	lookupTypeObj.put(genLooupListObj.getId(),genLooupListObj.getName());

		}
		 
		model.addAttribute("listLookupProcess", listLookupProcess);
		model.addAttribute("lookupTypeList", lookupTypeObj);

		log.debug("listLookupsController methods End...");
		return "c3par.admin.lookupData";
	}

	/**
	 * To Load the Add Look up Data Screen
	 * 
	 * @return
	 */
	@RequestMapping(value = "/addLookupsController.act",method =  { RequestMethod.GET, RequestMethod.POST })
	public String addManageLookupData(ModelMap model,
			@ModelAttribute("listLookupProcess") ListLookupProcess listLookupProcess) {

		listLookupProcess = new ListLookupProcess();
		Map<Long, String> lookupTypeObj = new HashMap<Long, String>();

		List<GenericLookupDef> lookupDTOList = listLookupProcess.getListLookupData();

		for (GenericLookupDef genLooupListObj : lookupDTOList) {
     	lookupTypeObj.put(genLooupListObj.getId(),genLooupListObj.getName());

		}
	 
		model.addAttribute("listLookupProcess", listLookupProcess);
		model.addAttribute("lookupTypeList", lookupTypeObj);

		log.debug("End Look up data listLookupsController methods End...");
		return "c3par.admin.lookupData.add";

	}

	/**
	 * To Load the Add Look up Data Screen
	 * 
	 * @return
	 */
	@RequestMapping(value = "/loadEditLookupsController.act", method =  { RequestMethod.GET, RequestMethod.POST })
	public String loadEditLookupData(ModelMap model,
			@ModelAttribute("listLookupProcess") ListLookupProcess listLookupProcess,
			HttpServletRequest request, HttpServletResponse response) {

		String lookUpValue = request.getParameter("lookUpValue");
		
		log.debug("lookUpValue End Look up data listLookupsController methods End...111"+lookUpValue);
		String lookUpID = request.getParameter("lookUpID");

		listLookupProcess.setLookupValue(lookUpValue);

		listLookupProcess.setIds(lookUpID);
		model.addAttribute("listLookupProcess", listLookupProcess);

		log.debug("End Look up data listLookupsController methods End...111");
		return "c3par.admin.lookupData.edit";

	}

	/**
	 * To Search the List Lookup Data
	 * 
	 * @return
	 */
	
	@RequestMapping(value = "/searchListLookUpData.act", method =  { RequestMethod.GET, RequestMethod.POST })
	public String searchListLookupData(ModelMap model,
			@ModelAttribute("listLookupProcess") ListLookupProcess listLookupProcess) {
		log.debug("Start Search List Lookup data.......");

		Map<Long, String> lookupTypeObj = new HashMap<Long, String>();

		List<GenericLookupDef> lookupDTOList = listLookupProcess.getListLookupData(); 

		for (GenericLookupDef genLooupListObj : lookupDTOList) {
			lookupTypeObj.put(genLooupListObj.getId(),genLooupListObj.getName());
		}

		List<ListLookupProcess>  lookupExportDataList = listLookupProcess.getListLookupDataDefList(listLookupProcess.getLookupDefId(),listLookupProcess.getLookupValue());
		log.debug("lookupExportDataList ......."+lookupExportDataList.size());

		listLookupProcess.setLookupDefs(lookupExportDataList);
		model.addAttribute("listLookupProcess", listLookupProcess);
		model.addAttribute("lookupTypeList", lookupTypeObj);
		return "c3par.admin.lookupData";
	}

	/**
	 * To Save the List Lookup Data
	 * 
	 * @return
	 */
	@RequestMapping(value = "/saveListLookUpData.act", method = RequestMethod.POST)
	public String saveListLookupData(ModelMap model,
			@ModelAttribute("listLookupProcess") ListLookupProcess listLookupProcess, BindingResult result) {
		log.debug("Start Search List Lookup data.......");
		       boolean validationFailed = false; 
				Map<Long, String> lookupTypeObj = new HashMap<Long, String>();
                String forward="";
				List<GenericLookupDef> lookupDTOList = listLookupProcess.getListLookupData();

				for (GenericLookupDef genLooupListObj : lookupDTOList) {
		     	lookupTypeObj.put(genLooupListObj.getId(),genLooupListObj.getName());

				}
		     	log.info("******************Map Details*****************8"+lookupTypeObj);
				List<ObjectError> errlist = new ArrayList<ObjectError>();
		  		
		  		if ((listLookupProcess.getLookupDefId()==null) || ("".equals(listLookupProcess.getLookupValue()))){
		  			log.debug("Add Look uP id validation inside");
		  	        errlist.add(new ObjectError("listLookupProcess.lookupDefId",new String[] { "admin.lookupValue" },new String[]{""},"") );
		  	        validationFailed = true;
		  	        
		  	        
		  	        forward="c3par.admin.lookupData.add";
		  		}
		  		if (listLookupProcess.getLookupValue()==null || "".equals(listLookupProcess.getLookupValue() )) {
		  			
		  			log.debug("Add Look uP value validation inside");
		  	        errlist.add(new ObjectError("listLookupProcess.lookupValue",new String[] { "admin.value" },new String[]{""},"") );
		  	        validationFailed = true;
		  	        forward="c3par.admin.lookupData.add";
		  		}
		  		
		  		//if(lookupTypeObj.get(listLookupProcess.getLookupDefId()) .equalsIgnoreCase("Protocol"))
			//	{
					if (listLookupProcess.getLookupValue1()==null || "".equals(listLookupProcess.getLookupValue1() ) ) {
						log.debug("Add Look uP value1 validation inside");
						errlist.add(new ObjectError("listLookupProcess.lookupValue1",new String[] { "admin.value1" },new String[]{""},"") );
						validationFailed = true;
						forward="c3par.admin.lookupData.add";
					}
				//}
		  		if (!validationFailed) {
		  		//	if(lookupTypeObj.get(listLookupProcess.getLookupDefId()) .equalsIgnoreCase("Protocol"))
		  		//		{
						listLookupProcess.saveLookUpData(listLookupProcess.getLookupDefId(),listLookupProcess.getLookupValue(),listLookupProcess.getLookupValue1());
						listLookupProcess.setLookupValue1("");
		  		/*		}
		  			else
		  				{
		  				listLookupProcess.saveLookUpData(listLookupProcess.getLookupDefId(),listLookupProcess.getLookupValue());
		  				}
		  			*/
		  			listLookupProcess.setLookupDefId(0L);
		  			listLookupProcess.setLookupValue("");
		  			forward="c3par.admin.lookupData";
		  		}
		  			


		  		
		  	/*	if (!validationFailed) {
					listLookupProcess.saveLookUpData(listLookupProcess.getLookupDefId(),
					listLookupProcess.getLookupValue());
					listLookupProcess.setLookupValue("");
					listLookupProcess.setLookupDefId(0L);
					forward="c3par.admin.lookupData";
		  		}*/
		  		
		  		for (ObjectError error : errlist) {
		  			result.addError(error);
		  		}
		 
			    model.addAttribute("lookupTypeList", lookupTypeObj);
				model.addAttribute("listLookupProcess", listLookupProcess);
				return forward; 
	}
	
	@RequestMapping(value = "/updateListLookUpData.act", method = RequestMethod.POST)
	public String updateListLookupData(ModelMap model,
			@ModelAttribute("listLookupProcess")ListLookupProcess listLookupProcess, BindingResult result,HttpServletRequest request) {
		log.debug("Start Search List Lookup data.......");
		boolean validationFailed = false; 
				Map<Long, String> lookupTypeObj = new HashMap<Long, String>();
				List<ObjectError> errlist = new ArrayList<ObjectError>();
				List<GenericLookupDef> lookupDTOList = listLookupProcess.getListLookupData();
               String forward="";
				for (GenericLookupDef genLooupListObj : lookupDTOList) {
		     	lookupTypeObj.put(genLooupListObj.getId(),genLooupListObj.getName());

				}
				log.info("******************Map Details*****************8"+lookupTypeObj);
		  		if (listLookupProcess.getLookupValue()==null || "".equals(listLookupProcess.getLookupValue() )) {
		  	        errlist.add(new ObjectError("listLookupProcess.lookupValue",new String[] { "admin.value" },new String[]{""},"") );
		  	        validationFailed = true;
		  	      forward= "c3par.admin.lookupData.edit";
		  		}
		  		
				String lookUpId = (String)request.getSession().getAttribute("LOOK_UP_ID_SESSION");
				Long lookUpDefID = (Long)request.getSession().getAttribute("LOOK_UP_DEF_ID_SESSION");
			 
				/*if(lookupTypeObj.get(listLookupProcess.getLookupDefId()) .equalsIgnoreCase("Protocol"))
				{*/
					if (listLookupProcess.getLookupValue1()==null || "".equals(listLookupProcess.getLookupValue1() ) ) {
						log.debug("Edit Look uP value1 validation inside");
						errlist.add(new ObjectError("listLookupProcess.lookupValue1",new String[] { "admin.value1" },new String[]{""},"") );
						validationFailed = true;
						forward="c3par.admin.lookupData.edit";
					}
				//}
				
				
				
				if (!validationFailed) {
			// listLookupProcess.updateLookUpData(lookUpDefID,Long.parseLong(lookUpId),listLookupProcess.getLookupValue());
			// if(lookupTypeObj.get(listLookupProcess.getLookupDefId()) .equalsIgnoreCase("Protocol"))
			//	{
				 listLookupProcess.updateLookUpData(lookUpDefID,Long.parseLong(lookUpId),listLookupProcess.getLookupValue(),listLookupProcess.getLookupValue1());
				listLookupProcess.setLookupValue1("");
				/*}
			else
				{
				listLookupProcess.updateLookUpData(lookUpDefID,Long.parseLong(lookUpId),listLookupProcess.getLookupValue());
				}*/
			 listLookupProcess.setLookupValue(""); 
			 listLookupProcess.setLookupDefId(0L); 
			 forward="c3par.admin.lookupData";
				}
				for (ObjectError error : errlist) {
		  			result.addError(error);
		  		}
	     model.addAttribute("lookupTypeList", lookupTypeObj);
		model.addAttribute("listLookupProcess", listLookupProcess);
		return forward; 
	}


	/**
	 * To Modify the List Lookup Data
	 * 
	 * @return
	 */
	 
	@RequestMapping(value = "/editListLookUpData.act", method = RequestMethod.POST)
	public String editListLookupData(ModelMap model,
			@ModelAttribute("listLookupProcess") ListLookupProcess listLookupProcess,HttpServletRequest request) {
		log.debug("Start Search List Lookup data.......");
	 
		String lookUpid=request.getParameter("lookUpidVal"); 
		request.getSession().setAttribute("LOOK_UP_ID_SESSION",
				lookUpid);
	 	List<GenericLookup> lookUpList=listLookupProcess.getListLookupDataById(Long.parseLong(lookUpid));
    	for(GenericLookup lookUpListObj:lookUpList){
    		listLookupProcess.setLookupDefId(lookUpListObj.getDefinitionId());
			listLookupProcess.setLookupValue(lookUpListObj.getValue1());
			listLookupProcess.setLookupValue1(lookUpListObj.getValue2());
		 	request.getSession().setAttribute("LOOK_UP_DEF_ID_SESSION",lookUpListObj.getGenericLookupDef().getId());
		}

		model.addAttribute("listLookupProcess", listLookupProcess);
		return "c3par.admin.lookupData.edit";
	} 
	
	
	/**
	 * To Cancel the Edit Lookup Data Screen
	 * 
	 * @return
	 */
	@RequestMapping(value = "/cancelLookupsController.act", method = RequestMethod.POST)
	public String cancelEditLookupData(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		
		ListLookupProcess listLookupProcess = new ListLookupProcess();
		log.debug(" Enter::listLookupsController methods starts...");
		Map<Long, String> lookupTypeObj = new HashMap<Long, String>();

		List<GenericLookupDef> lookupDTOList = listLookupProcess.getListLookupData();

		for (GenericLookupDef genLooupListObj : lookupDTOList) {
     	lookupTypeObj.put(genLooupListObj.getId(),genLooupListObj.getName());

		}
       
		model.addAttribute("listLookupProcess", listLookupProcess);
		model.addAttribute("lookupTypeList", lookupTypeObj);

		log.debug("listLookupsController methods End...");
		return "c3par.admin.lookupData";

	}

}
