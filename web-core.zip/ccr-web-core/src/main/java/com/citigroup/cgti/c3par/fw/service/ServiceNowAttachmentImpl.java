package com.citigroup.cgti.c3par.fw.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringWriter;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.xmlbeans.impl.util.Base64;



//import com.sun.xml.internal.messaging.saaj.util.Base64;



public class ServiceNowAttachmentImpl {
public static void main(String[] args) throws IOException {
	
	String arg = args[0]; //"C:\\soa\\serviceNow\\ccr\\ccr_service_now_prod.jks#PARTITION#JCEKS#PARTITION#ccr_147460#PARTITION#false#PARTITION#https://servicemanagement.uat.citigroup.net/addattachment.do?SOAP#PARTITION#CCR#PARTITION#wgC424Pl#PARTITION#CHG0000035242#PARTITION#74691-1.txt:text/plain#PARTITION#74691-1.txt#PARTITION#C:/hari/";
	String params[] = arg.split("#PARTITION#");
	
	System.out.println(params[0]);
	
        System.setProperty("javax.net.ssl.trustStore", params[0]);
  	    System.setProperty("javax.net.ssl.trustStoreType", params[1]);
  	    System.setProperty("javax.net.ssl.trustStorePassword", params[2]);
        System.setProperty("com.sun.net.ssl.checkRevocation", params[3]);
        

        String wsURL = params[4];
        
        File file = new File(params[10]+params[9]);
		FileInputStream fin = new  FileInputStream(file);
		byte fileContent[] = new byte[(int)file.length()];
		fin.read(fileContent);
		try
		{
			attachmentToChangeRequestTicket(params[7], params[8],new String(Base64.encode(fileContent)),wsURL,params[5],params[6]);
//			attachmentToChangeRequestTicket(params[7], params[8],Base64Bytes.byteArrayToBase64(fileContent,false),wsURL,params[5],params[6]);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
        
		
	}
	
	public static String attachmentToChangeRequestTicket(String incidentNumber,String filename, String payload,String url,String userId,String pwd) throws Exception
	{
		System.out.println("ServiceNow Request eventID is : "+incidentNumber+ "name :"+ filename);
		return ((sendRequest(getChangeRequestAttachement(incidentNumber,filename, payload),url,userId,pwd)));
	}
	
	private static String getChangeRequestAttachement(String incidentNumber,String filename, String payload) {
		return
		"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:add=\"http://www.service-now.com/addattachment\">"+
			"<soapenv:Header/>"+
			"<soapenv:Body>"+
			"<add:attach>"+
			"<!--Optional:-->"+
			"<add:number>"+incidentNumber+"</add:number>"+
			"<!--Optional:-->"+
			"<add:name>"+filename+"</add:name>"+
			"<!--Optional:-->"+
			"<add:payload>"+payload+"</add:payload>"+
			"</add:attach>"+
			"</soapenv:Body>"+
			"</soapenv:Envelope>";
		}
	
	private static String sendRequest(String message,String url,String servicenow_connect_username,String servicenow_connect_password) throws Exception
    {
          
          System.out.println(message); 
          String xmlResponse = "";
          SOAPConnection soapConnection = null;
          try
          {
                SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
                soapConnection = soapConnectionFactory.createConnection();
                MessageFactory messageFactory = MessageFactory.newInstance();
                SOAPMessage soapMessage = messageFactory.createMessage();
                SOAPPart soapPart = soapMessage.getSOAPPart();
                ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(message.getBytes("UTF-8"));
                soapPart.setContent(new StreamSource(byteArrayInputStream));
                soapMessage.saveChanges();
                /*String servicenow_connect_username = "CCR";
				String servicenow_connect_password = "wgC424Pl";*/
				
				
				String authorization = new String (Base64.encode((servicenow_connect_username+":"+servicenow_connect_password).getBytes()));
				
//				String authorization = Base64Bytes.byteArrayToBase64(((servicenow_connect_username+":"+servicenow_connect_password).getBytes()),false);
				
	            soapMessage.getMimeHeaders().addHeader("Authorization", "Basic "+authorization); 
				SOAPMessage responseSOAPMessage = soapConnection.call(soapMessage,url);
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				Source source = responseSOAPMessage.getSOAPPart().getContent();
				StringWriter stringWriter = new StringWriter(512);
				StreamResult streamResult = new StreamResult(stringWriter);
				transformer.transform(source,streamResult);
				xmlResponse = stringWriter.toString();
				System.out.println("ServiceNow Response XML is"+xmlResponse);
          }catch(Exception e)
          {
                e.printStackTrace();
                throw e;
          }finally
          {
                if(soapConnection != null)
                      soapConnection.close();
          }
          return xmlResponse;
    }

}
