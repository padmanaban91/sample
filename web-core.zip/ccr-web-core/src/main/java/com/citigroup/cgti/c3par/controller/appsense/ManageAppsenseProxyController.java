package com.citigroup.cgti.c3par.controller.appsense;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseApplication;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseDTO;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseUser;
import com.citigroup.cgti.c3par.appsense.domain.ManageAppsenseProcess;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiResource;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.controller.firewall.BaseController;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.proxy.domain.ProxyFilter;
import com.citigroup.cgti.c3par.proxy.domain.ProxyInstance;
import com.citigroup.cgti.c3par.proxy.domain.ProxyProcess;
import com.citigroup.cgti.c3par.webtier.helper.AppsenseUtil;
import com.citigroup.cgti.c3par.webtier.helper.LookupNameHelper;
import com.citigroup.cgti.c3par.webtier.helper.Util;

/*
 * @nc43495
 */
@SuppressWarnings("unchecked")
@Controller
public class ManageAppsenseProxyController extends BaseController {

	/** The log. */
	public static Logger log = Logger
			.getLogger(ManageAppsenseProxyController.class);
	

	/** The util. */
	Util util = new Util();
	
	AppsenseUtil appsenseUtil = new AppsenseUtil();

	/** The props. */
	 private static ResourceBundle props = ResourceBundle.getBundle(System.getProperty("ccr-application"),Locale.getDefault());
	

	@RequestMapping(value = "/loadAppsenseProxy.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String loadAppsenseProxy(ModelMap model, HttpServletRequest request) {
		log.info("ManageAppsenseController:load method starts here ...");
	
		ManageAppsenseProcess manageAppsenseProcess = new ManageAppsenseProcess();
		ProxyFilter proxyFilter = new ProxyFilter();
		ProxyProcess proxyProcess = new ProxyProcess();
		List<ProxyFilter> proxyFilterList = new ArrayList<ProxyFilter>();
		
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("loadProxyFilter:tiReq from SESSION===" + tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
		    try {
			tiRequestId = Long.valueOf(tiReq);
		    } catch (Exception e) {
			tiRequestId = Long.valueOf(0);
		    }
		}
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);;
		manageAppsenseProcess.setTirequest(tiRequest);
		
		manageAppsenseProcess.setOffset(0);
		manageAppsenseProcess.setPageNo(1);
		manageAppsenseProcess.setLimit(5);
		
		proxyProcess = manageAppsenseProcess.getProxyProcess(tiRequest.getTiProcess().getId());
		proxyFilterList = manageAppsenseProcess.loadProxyFilters(manageAppsenseProcess);
		proxyFilter.setTiRequest(tiRequest);
		proxyFilter.setTiProcess(tiProcess);
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		int limit = 5;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		manageAppsenseProcess.setProxyFilterList(proxyFilterList);
		manageAppsenseProcess.setProxyFilter(proxyFilter);

		request.getSession().setAttribute("proxyFilterList",manageAppsenseProcess.getProxyFilterList() );
		manageAppsenseProcess.setProxyProcess(proxyProcess);
		
		Long id = util.getLookupId(LookupNameHelper.RIGHT_PLACEMENT);
		
		manageAppsenseProcess.setProxyInstanceList(util
				.getProxyInstanceName("appsense", "BASIC", null, id));
		
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}
		
		model.addAttribute("appsenseData", manageAppsenseProcess);
		request.getSession().setAttribute("viewIndex", "edit");
		request.getSession().removeAttribute("viewAppsense");
		isAppsenseCompleteCheck(request);
		
		log.info("ManageAppsenseProcess.load()::Ends");
		return "c3par.appsense.proxy";
	}
	
	
	
	public String loadProxyData(ModelMap model, HttpServletRequest request, ManageAppsenseProcess manageAppsenseProcess) {
		log.info("ManageAppsenseController:load method starts here ...");
	
		ProxyProcess proxyProcess = new ProxyProcess();
		List<ProxyFilter> proxyFilterList = new ArrayList<ProxyFilter>();
		
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("loadProxyFilter:tiReq from SESSION===" + tiReq);
		Long tiRequestId = Long.valueOf(0);
		if (tiReq != null) {
		    try {
			tiRequestId = Long.valueOf(tiReq);
		    } catch (Exception e) {
			tiRequestId = Long.valueOf(0);
		    }
		}
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);;
		manageAppsenseProcess.setTirequest(tiRequest);
		
		proxyProcess = manageAppsenseProcess.getProxyProcess(tiRequest.getTiProcess().getId());
		proxyFilterList = manageAppsenseProcess.loadProxyFilters(manageAppsenseProcess);
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		int limit = 5;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		manageAppsenseProcess.setProxyFilterList(proxyFilterList);

		request.getSession().setAttribute("proxyFilterList",manageAppsenseProcess.getProxyFilterList() );
		manageAppsenseProcess.setProxyProcess(proxyProcess);
		
		Long id = util.getLookupId(LookupNameHelper.RIGHT_PLACEMENT);
		
		manageAppsenseProcess.setProxyInstanceList(util
				.getProxyInstanceName("appsense", "BASIC", null, id));
		
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}
		
		model.addAttribute("appsenseData", manageAppsenseProcess);
		request.getSession().setAttribute("viewIndex", "edit");
		request.getSession().removeAttribute("viewAppsense");
		isAppsenseCompleteCheck(request);
		
		log.info("ManageAppsenseProcess.load()::Ends");
		return "c3par.appsense.proxy";
	}
	
	@RequestMapping(value = "/paginateAppsenseProxy.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String paginateAppsenseProxy(ModelMap model, HttpServletRequest request, @ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess) {
		log.info("ManageAppsenseController:load method starts here ...");
	
		int curOffSet = manageAppsenseProcess.getOffset();
		int limit = manageAppsenseProcess.getLimit();
		int pageNo = manageAppsenseProcess.getPageNo();
		String type = (String)request.getParameter("type");
		
		log.debug("ManageAppsenseController::paginateIPs type..."+type);
		
		manageAppsenseProcess = new ManageAppsenseProcess();
		ProxyFilter proxyFilter = new ProxyFilter();
		ProxyProcess proxyProcess = new ProxyProcess();
		List<ProxyFilter> proxyFilterList = new ArrayList<ProxyFilter>();

		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		manageAppsenseProcess.setTirequest(tiRequest);

		manageAppsenseProcess.setLimit(limit);
		if ("N".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(curOffSet+manageAppsenseProcess.getLimit());
			manageAppsenseProcess.setPageNo(pageNo+1);
		} else if ("P".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(curOffSet-manageAppsenseProcess.getLimit());
			manageAppsenseProcess.setPageNo(pageNo-1);
		} else if ("X".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(limit * (pageNo-1));
			manageAppsenseProcess.setPageNo(pageNo);
		} else if ("L".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(0);
			manageAppsenseProcess.setPageNo(1);
		} else {
			manageAppsenseProcess.setOffset(0);
			manageAppsenseProcess.setPageNo(1);
		}
		
		proxyProcess = manageAppsenseProcess.getProxyProcess(tiRequest.getTiProcess().getId());
		proxyFilterList = manageAppsenseProcess.loadProxyFilters(manageAppsenseProcess);
		proxyFilter.setTiRequest(tiRequest);
		proxyFilter.setTiProcess(tiProcess);
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		manageAppsenseProcess.setProxyFilterList(proxyFilterList);
		manageAppsenseProcess.setProxyFilter(proxyFilter);

		request.getSession().setAttribute("proxyFilterList",manageAppsenseProcess.getProxyFilterList() );
		manageAppsenseProcess.setProxyProcess(proxyProcess);
		
		Long id = util.getLookupId(LookupNameHelper.RIGHT_PLACEMENT);
		
		manageAppsenseProcess.setProxyInstanceList(util
				.getProxyInstanceName("appsense", "BASIC", null, id));
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}
		
		model.addAttribute("appsenseData", manageAppsenseProcess);
		request.getSession().setAttribute("viewIndex", "edit");
		
		log.debug("session attribute:"+request.getParameter("selectedTab"));

		log.info("ManageAppsenseProcess.load()::Ends");
		return "c3par.appsense.proxy";
	}
	
	
	
	@RequestMapping(value = "/addResourceApsProxy.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String addResourceApsProxy(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		
		log.info("ManageAppsenseProcess.addResource()::Starts");
		String forwardTo = "c3par.appsense.proxy";
		
		int curOffSet = manageAppsenseProcess.getOffset();
		int limit = manageAppsenseProcess.getLimit();
		int pageNo = manageAppsenseProcess.getPageNo();
		
		List<ProxyFilter> selProxyFilterList = manageAppsenseProcess.getProxyFilterList();
		
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		

		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);;
		manageAppsenseProcess.setTirequest(tiRequest);
		
		manageAppsenseProcess.setOffset(curOffSet);
		manageAppsenseProcess.setPageNo(pageNo);
		manageAppsenseProcess.setLimit(limit);
		ProxyProcess proxyProcess = new ProxyProcess();
		List<ProxyFilter> proxyFilterList = new ArrayList<ProxyFilter>();
		
		proxyProcess = manageAppsenseProcess.getProxyProcess(tiRequest.getTiProcess().getId());
		proxyFilterList = manageAppsenseProcess.loadProxyFilters(manageAppsenseProcess);
		
		if (selProxyFilterList!= null && proxyFilterList != null) {
			for (ProxyFilter selProxyFilter : selProxyFilterList) {
				if (selProxyFilter.isSelected()) {
					for (ProxyFilter proxyFilter : proxyFilterList) {
						if (selProxyFilter.getId() != null && selProxyFilter.getId().equals(proxyFilter.getId())) {
							proxyFilter.setSelected(true);
						}
					}
				}
			}
		}
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		manageAppsenseProcess.setProxyFilterList(proxyFilterList);

		request.getSession().setAttribute("proxyFilterList",manageAppsenseProcess.getProxyFilterList() );
		manageAppsenseProcess.setProxyProcess(proxyProcess);
		
		Long id = util.getLookupId(LookupNameHelper.RIGHT_PLACEMENT);
		
		manageAppsenseProcess.setProxyInstanceList(util
				.getProxyInstanceName("appsense", "BASIC", null, id));
		

		if (request.getSession().getAttribute(
				"COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY") != null) {
			log.debug("CSI selected ");
			CitiResource citiResourceEntity = (CitiResource) request
					.getSession().getAttribute(
							"COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY");
			manageAppsenseProcess.setIpResourceId(Long.valueOf(citiResourceEntity
					.getCwhiId()));
			log.debug("ManageAppsenseProcess.addResource()::getName "
					+ citiResourceEntity.getName());

			manageAppsenseProcess.getProxyFilter().getApplication()
					.setApplicationID(Long.valueOf(citiResourceEntity.getCwhiId()));
			if ((citiResourceEntity.getName() == null)
					|| citiResourceEntity.getName()
							.equalsIgnoreCase("NULL")) {
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setApplicationName("");
			} else {
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setApplicationName(citiResourceEntity.getName());
			}
			if ((citiResourceEntity.getFunctionalityDescription() == null)
					|| citiResourceEntity.getFunctionalityDescription()
							.equalsIgnoreCase("NULL")) {
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setFunction("");
			} else {
				manageAppsenseProcess
						.getProxyFilter()
						.getApplication()
						.setFunction(
								citiResourceEntity
										.getFunctionalityDescription());
			}
			manageAppsenseProcess.getProxyFilter().getApplication()
					.setAppOwnerFullName(citiResourceEntity.getOwner());
			if ((citiResourceEntity.getOwnerid() == null)
					|| citiResourceEntity.getOwnerid().equalsIgnoreCase(
							"NULL")) {
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setAppOwnerGEID("");
			} else {
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setAppOwnerGEID(citiResourceEntity.getOwnerid());
			}
			
			if ((citiResourceEntity.getClassification() == null)
					|| citiResourceEntity.getClassification().equalsIgnoreCase(
							"NULL")) {
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setSecClassification("");
			} else {
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setSecClassification(citiResourceEntity.getClassification());
			}
			
			if ((citiResourceEntity.getPersonalDataIndicator() == null)
					|| citiResourceEntity.getPersonalDataIndicator().equalsIgnoreCase(
							"NULL")) {
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setPersonaDataIndicator("");
			} else {
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setPersonaDataIndicator(citiResourceEntity.getPersonalDataIndicator());
			}
			
			if (manageAppsenseProcess.getProxyFilter().getApplication()
					.getIsCSI() != null
					&& manageAppsenseProcess.getProxyFilter()
							.getApplication().getIsCSI()
							.equalsIgnoreCase("Y")
					&& request.getSession().getAttribute("APP_OWNER_EMAIL") != null) {
				manageAppsenseProcess
						.getProxyFilter()
						.getApplication()
						.setAppOwnerEmail(
								(String) request.getSession().getAttribute(
										"APP_OWNER_EMAIL"));
			} else {
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setAppOwnerEmail(null);
			}
			// added for new columns Start
			if (manageAppsenseProcess.getProxyFilter().getApplication()
					.getIsCSI() != null
					&& manageAppsenseProcess.getProxyFilter()
							.getApplication().getIsCSI()
							.equalsIgnoreCase("Y")) {
				if (request.getSession().getAttribute("APP_MGR_EMAIL") != null) {
					String managerEmail = (String) request.getSession()
							.getAttribute("APP_MGR_EMAIL");
					manageAppsenseProcess.getProxyFilter().getApplication()
							.setAppManagerEmail(managerEmail);
					log.debug("managerEmail for proxy ManageAppsenseProcess: "
							+ managerEmail);
				}
				if (request.getSession().getAttribute("APP_MGR_FULL_NAME") != null) {
					String appManagerFullName = (String) request
							.getSession().getAttribute("APP_MGR_FULL_NAME");
					manageAppsenseProcess.getProxyFilter().getApplication()
							.setAppManagerFullName(appManagerFullName);
					log.debug("appManagerFullName for proxy ManageAppsenseProcess: "
							+ appManagerFullName);
				}
				if (request.getSession().getAttribute("APP_MGR_GEID") != null) {
					String appManagerGEID = (String) request.getSession()
							.getAttribute("APP_MGR_GEID");
					manageAppsenseProcess.getProxyFilter().getApplication()
							.setAppManagerGEID(appManagerGEID);
					log.debug("appManagerGEID for proxy ManageAppsenseProcess: "
							+ appManagerGEID);
				}
			} 
			// added for new columns end
			manageAppsenseProcess.getProxyFilter().getApplication()
					.setIsDevice("N");
			manageAppsenseProcess.getProxyFilter().getApplication()
					.setIsCSI("Y");
			request.getSession().removeAttribute("viewIndex");
			request.setAttribute("addApplication", "true");
			log.debug("Application Name -- :" +manageAppsenseProcess.getProxyFilter().getApplication().getApplicationName());
		
			} else {
				manageAppsenseProcess.getProxyFilter().getApplication()
				.setAppManagerEmail(null);
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setAppManagerFullName(null);
				manageAppsenseProcess.getProxyFilter().getApplication()
						.setAppManagerGEID(null);
			}
				
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}


		request.setAttribute("CSI", "CSI");
		request.getSession().removeAttribute(
				"COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY");
		model.addAttribute("appsenseData", manageAppsenseProcess);
		log.info("ManageAppsenseProcess.addResource()::Ends");
		return forwardTo;
	}
	
	
	@RequestMapping(value = "/addProxyFilter.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String addProxyFilter(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request, BindingResult bresult) {
		log.info("ManageAppsenseProcess.addProxyFilter() :: Starts...");
		try {
			String urlProxy = manageAppsenseProcess.getProxyFilter().getUrl();
			if (urlProxy == null
					|| (urlProxy != null && urlProxy.trim().equals(""))) {
				throw new BusinessException("Please provide URL data.");
			}
			ProxyProcess proxyProcess = manageAppsenseProcess.getProxyProcess();
			proxyProcess.setProxyFilterList(manageAppsenseProcess
					.getProxyFilterList());
			ProxyFilter proxyFilter = manageAppsenseProcess.getProxyFilter();
			String tiReq = (String) request.getSession().getAttribute("tireqid");
	
			log.info("tiReq from SESSION===" + tiReq);
			Long tiRequestId = Long.valueOf(0);
			if (tiReq != null) {
				try {
					tiRequestId = Long.valueOf(tiReq);
				} catch (Exception e) {
					tiRequestId = Long.valueOf(0);
				}
			}
			proxyFilter.setAction("Add");
			TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId
					.longValue());
			TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId
					.longValue());
			proxyFilter.setTiProcess(tiProcess);
			proxyFilter.setTiRequest(tiRequest);
			
			String adGroupName = manageAppsenseProcess.getAppsADGroupName();
			
			AppsenseADGroup appsenseADGroupName = new AppsenseADGroup();
			appsenseADGroupName = (AppsenseADGroup) util
					.checkAppsADGroupName(adGroupName);
			if (appsenseADGroupName.getId() == null) {
				appsenseADGroupName.setName(manageAppsenseProcess
						.getAppsADGroupName());
				appsenseADGroupName.setPolicyID(manageAppsenseProcess
						.getAppsPolicyId());
				appsenseADGroupName.setPolicyName(manageAppsenseProcess
						.getAppsPolicyName());
				appsenseADGroupName = manageAppsenseProcess
						.storeAppsADGroup(appsenseADGroupName);
				util.updateAppsADGroupID(tiProcess.getId(),
						appsenseADGroupName.getId());
				util.updateProxyADGroupID(tiProcess.getId(),
						appsenseADGroupName.getId());
				manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroupName
						.getId());
				proxyFilter.setAppsenseADGroup(appsenseADGroupName);
			} else {
				appsenseADGroupName.setName(manageAppsenseProcess
						.getAppsADGroupName());
				appsenseADGroupName.setPolicyID(manageAppsenseProcess
						.getAppsPolicyId());
				appsenseADGroupName.setPolicyName(manageAppsenseProcess
						.getAppsPolicyName());	
				appsenseADGroupName = manageAppsenseProcess
						.updateAppsADGroup(appsenseADGroupName);
				proxyFilter.setAppsenseADGroup(appsenseADGroupName);
			}
			
	
			
			manageAppsenseProcess.storeProxyFilter(proxyFilter);
		} catch (BusinessException e) {
			log.error("Business Exception Occured... - "+e.getMessage());
			bresult.addError(new ObjectError("appsenseData.proxyFilter", e.getMessage()));
			return loadProxyData(model, request, manageAppsenseProcess);
		}  catch (ApplicationException e) {
			log.error("Application Exception Occured... - "+e.getMessage());
			bresult.addError(new ObjectError("appsenseData.proxyFilter", e.getMessage()));
			return loadProxyData(model, request, manageAppsenseProcess);
		}
		log.info("ManageAppsenseProcess.addProxyFilter() :: Ends...");
		return "forward:/loadAppsenseProxy.act";
	}

	@RequestMapping(value = "/removeProxyFilter.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String removeProxyFilter(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		ProxyProcess proxyProcess = manageAppsenseProcess.getProxyProcess();
		List<ProxyFilter> proxyFilterList = manageAppsenseProcess.getProxyFilterList();
		proxyProcess.setProxyFilterList(proxyFilterList);
		manageAppsenseProcess.deleteProxyFilter(proxyProcess);
		return "forward:/loadAppsenseProxy.act";
	}

	
	@RequestMapping(value = "/getProxyInstanceData.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody void getProxyInstanceData(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request, HttpServletResponse response) {

		Long proxyId = null;
		String proxyRegion = null;
		String proxyPortNumber = null;
		Integer index = null;
		GenericLookup lookup = new GenericLookup();
		List<String> proxyInstanceData = null;
		log.info("ManageAppsenseProcess.getProxyInstanceData()::Starts");
		
		ProxyInstance proxyInstance = new ProxyInstance();
		
		Long id = util.getLookupId(LookupNameHelper.RIGHT_PLACEMENT);
		List proxyInstanceList = util
				.getProxyInstanceName("appsense", "BASIC", null, id);
		
		log.debug("proxyyyyy:"+proxyInstanceList);
		
		index = Integer.valueOf(request.getParameter("proxyId"));
		
		LookUpVO lookupVO = (LookUpVO) proxyInstanceList.get(index.intValue());
		
		if (id != null)
			lookup.setId(id);
		else
			throw new BusinessException(
					"Right Placement value should not be null.");
		proxyId = Long.valueOf(lookupVO.getValue());
		proxyInstanceData = util.getProxyInstanceData(proxyId);
		log.debug("proxyinstance++:"+proxyInstanceData.toString());
		if (proxyInstanceData.get(0) != null) {
			proxyRegion = proxyInstanceData.get(0).toString();
		}
		if (proxyInstanceData.get(1) != null) {
			proxyPortNumber = proxyInstanceData.get(1).toString();
		}
		proxyInstance.setRegion(proxyRegion);
		proxyInstance.setPortNumber(proxyPortNumber);
		proxyInstance.setRightPlacement(lookup);
		proxyInstance.setRecordType("BASIC");
		try {
			response.setContentType("text/xml");
			response.setHeader("Cache-Control", "no-cache");
			response.getWriter().write(
					appsenseUtil.convertArrayListToXML((ArrayList<String>) proxyInstanceData));
		} catch (IOException ioe) {
			log.debug("Exception thrown while returning the region "
					+ ioe.getMessage());
		}
		log.info("ManageAppsenseProcess.getProxyInstanceData()::Ends");
	}
	
	
	
	@RequestMapping(value = "/addApplication.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String addApplication(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		log.info("ManageProxyAction.addApplication()::Starts");
		ProxyProcess proxyProcess = manageAppsenseProcess.getProxyProcess();
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		
		List<ProxyFilter> proxyFilterList = manageAppsenseProcess.getProxyFilterList();
		proxyProcess.setProxyFilterList(proxyFilterList);
		
		
		Application application = manageAppsenseProcess.getProxyFilter().getApplication();
		
		proxyProcess.setTiProcess(tiProcess);
		proxyProcess.setTiReq(tiRequest);
		proxyProcess.setPrxInst(manageAppsenseProcess.getProxyFilter().getProxyInstance());
		
		application = manageAppsenseProcess.storeApplication(application);
		if (application != null) {
			log.debug("ManageProxyAction.addApplication() updateProxyFilter");
			manageAppsenseProcess.updateProxyFilter(proxyProcess, application);
		}

		log.info("ManageProxyAction.addApplication()::Ends");
		return "forward:/loadAppsenseProxy.act";

	}

	@RequestMapping(value = "/removeApplication.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String removeApplication(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		log.info("ManageAppsenseProcess.removeApplication()::Starts");
		ProxyProcess proxyProcess = manageAppsenseProcess.getProxyProcess();
		
		manageAppsenseProcess.updateProxyFilter(proxyProcess, null);

		log.info("ManageAppsenseProcess.removeApplication()::Ends");
		return "forward:/loadAppsenseProxy.act";

	}

	@RequestMapping(value = "/cancelApplication.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String cancelApplication(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		String forwardTo = "c3par.appsense";
		log.info("ManageAppsenseProcess.cancelApplication()::Starts");
		
		Application application = manageAppsenseProcess.getProxyFilter()
				.getApplication();
		application.setIsCSI("");
		application.setApplicationName("");
		application.setAppOwnerFullName("");
		application.setAppOwnerGEID("");
		application.setFunction("");
		
		log.info("ManageAppsenseProcess.cancelApplication()::Ends");
		return "forward:/loadAppsenseProxy.act";
	}

	
	@RequestMapping(value = "/uploadProxyFilterExcel.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String uploadProxyFilterExcel(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess, BindingResult bResult,
			HttpServletRequest request) {
		
		log.info("ManageAppsenseProcess.uploadProxyFilterExcel()::Starts");
		String forwardTo = "c3par.appsense";
		String selectedTab = request.getParameter("tab");
		log.info("selectedTab:: " + selectedTab);
		try {
			
			String tiReq = (String) request.getSession()
					.getAttribute("tireqid");
			log.info("tiReq from SESSION===" + tiReq);
			Long tiRequestId = Long.valueOf(0);
			if (tiReq != null) {
				try {
					tiRequestId = Long.valueOf(tiReq);
				} catch (Exception e) {
					tiRequestId = Long.valueOf(0);
				}
			}
			log.info("tiRequestId===" + tiRequestId);

			ProxyFilter proxyFilter = manageAppsenseProcess.getProxyFilter();
			ProxyInstance proxyInstance = (ProxyInstance) proxyFilter
					.getProxyInstance();
			log.info("proxyInstance:: " + proxyInstance);
			TIProcess tiProcess = manageAppsenseProcess
					.getTIProcess(tiRequestId.longValue());
			log.info("tiProcess:: " + tiProcess);
			TIRequest tiRequest = manageAppsenseProcess
					.getTIRequest(tiRequestId.longValue());
			log.info("tiRequest:: " + tiRequest);
			CommonsMultipartFile file = manageAppsenseProcess
					.getUsersUploadExcelFormFile();
			log.info("file::: " + file);
			// Added for Task 9224

			AppsenseADGroup appsenseADGroupName = new AppsenseADGroup();
			appsenseADGroupName.setName(manageAppsenseProcess
					.getAppsADGroupName());
			appsenseADGroupName.setPolicyID(manageAppsenseProcess
					.getAppsPolicyId());
			appsenseADGroupName.setPolicyName(manageAppsenseProcess
					.getAppsPolicyName());
			if (manageAppsenseProcess.getAppsPolicyMasterId() != null
					&& manageAppsenseProcess.getAppsPolicyMasterId()
							.longValue() != 0) {
				appsenseADGroupName.setId(manageAppsenseProcess
						.getAppsPolicyMasterId());
				appsenseADGroupName = manageAppsenseProcess
						.updateAppsADGroup(appsenseADGroupName);

			} else {
				appsenseADGroupName = manageAppsenseProcess
						.storeAppsADGroup(appsenseADGroupName);
				util.updateAppsADGroupID(
						tiProcess.getId(),
						appsenseADGroupName.getId());
				util.updateProxyADGroupID(
						tiProcess.getId(),
						appsenseADGroupName.getId());
				manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroupName
						.getId());
			}

			// End of Task 9224

			
				List<ProxyFilter> getProxyFilterReadDataList = (ArrayList<ProxyFilter>) appsenseUtil.readExcelProxyFilterFile(
						file, tiProcess, tiRequest, proxyInstance, selectedTab,
						appsenseADGroupName);
				log.info("Size of getProxyFilterReadDataList::: "
						+ getProxyFilterReadDataList.size());
				List<ProxyFilter> storedProxyFilterList = new ArrayList<ProxyFilter>();
				List<AppsenseUser> storedAppsUserList = new ArrayList<AppsenseUser>();
				String failureStatusMessage = "successMessage";
				if (selectedTab != null && selectedTab.equals("proxy")) {
					storedProxyFilterList = (ArrayList<ProxyFilter>) appsenseUtil.storeProxyFilterRecords(
							getProxyFilterReadDataList, manageAppsenseProcess,
							selectedTab);
					log.info("Size of Stored Proxy List::: "
							+ storedProxyFilterList.size());
					appsenseUtil.writeExcelProxyFilter(storedProxyFilterList, tiReq,
							selectedTab);
				
				if (selectedTab != null && selectedTab.equals("manageUser")) {
					if (appsenseUtil.isAppsenseUsersValid(getProxyFilterReadDataList)) {
						storedAppsUserList = (ArrayList<AppsenseUser>) appsenseUtil.storeAppsenseUserRecords(
								getProxyFilterReadDataList, selectedTab,
								request.getHeader("SM_USER"), manageAppsenseProcess);
						log.info("Size of Stored Proxy List::: "
								+ storedAppsUserList.size());
						appsenseUtil.writeExcelProxyFilter(storedAppsUserList, tiReq,
								selectedTab);
						failureStatusMessage = "successMessage";
					} else {
						appsenseUtil.writeExcelProxyFilter(getProxyFilterReadDataList,
								tiReq, selectedTab);
						failureStatusMessage = "uploadfailed";
					}

				}
				String filePath = null;
				File fileExist = null;

					for (int i = 0; i < storedProxyFilterList.size(); i++) {
						ProxyFilter proxyFilterStatus = (ProxyFilter) storedProxyFilterList
								.get(i);
						if (proxyFilterStatus.getStatus().equals("Failure")) {
							failureStatusMessage = "failureMessage";
						}
					}
				// Added for Task 9224
				if (failureStatusMessage.equals("successMessage")) {
					request.setAttribute(
							"success_log",
							"Upload Completed.Template data uploaded successfully. Download template and check.");
				} else if (failureStatusMessage.equals("failureMessage")) {
					request.setAttribute("success_log",
							"Upload Completed. Download the template and check for errors.");
				} else if (failureStatusMessage.equals("uploadfailed")) {
					request.setAttribute("error_log",
							"Upload Failed. Download the template and check for errors.");
				}

				request.setAttribute("selectedTab", selectedTab);
				if (selectedTab != null && selectedTab.equals("proxy")) {
					//filePath = props.getString("XLS_FILE_WRITE_PROXY_FILTER_PATH")+ tiReq + "_proxyApp.xls";
					filePath=System.getProperty("application-log-path")+ tiReq + "_proxyApp.xls";
					fileExist = new File(filePath);
					if (fileExist == null || !fileExist.exists()
							|| fileExist.equals("")) {
						request.setAttribute("file_status", "false");
					} else {
						log.info("File Exists");
						request.setAttribute("file_status", "true");
					}
					request.setAttribute("fileStoredPath", tiReq
							+ "_proxyApp.xls");
					
				}
				// End of Task 9224
			}
		} catch (Exception ex) {
			log.info("Exception occurred");
			bResult.addError(new ObjectError("excel","Error ocurred while uploading the Excel"));
		}
		log.info("ManageAppsenseProcess.uploadProxyFilterExcel()::Ends");
		return "forward:/loadAppsenseProxy.act";
	}
	
	
	@RequestMapping(value = "/viewAppsenseProxy.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String viewAppsenseProxy(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		
		String forwardTo = "c3par.appsense.proxy";
		int index = -1;
		log.info("manageProxyAction.viewAppsenseProxy()::Starts");
		String curOffSet = request.getParameter("offset");
		String limit = request.getParameter("limit");
		String pageNo = request.getParameter("pageNo");
		
		log.debug("ManageAppsenseController:load offset "+curOffSet);
		log.debug("ManageAppsenseController:load limit "+limit);
		
		manageAppsenseProcess = new ManageAppsenseProcess();
		List<ProxyFilter> proxyFilterList = null;
		
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		manageAppsenseProcess.setTirequest(tiRequest);
		
		manageAppsenseProcess.setOffset(Integer.valueOf(curOffSet));
		manageAppsenseProcess.setLimit(Integer.valueOf(limit));
		manageAppsenseProcess.setPageNo(Integer.valueOf(pageNo));
		
		ProxyProcess proxyProcess = manageAppsenseProcess.getProxyProcess(tiRequest.getTiProcess().getId());
		proxyFilterList = manageAppsenseProcess.loadProxyFilters(manageAppsenseProcess);
		
		
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		
		if (rowCount%manageAppsenseProcess.getLimit() > 0) {
			totalPages = Math.round((rowCount/manageAppsenseProcess.getLimit())+0.5f);
		} else {
			totalPages = Math.round(rowCount/manageAppsenseProcess.getLimit());
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		manageAppsenseProcess.setProxyFilterList(proxyFilterList);
		
		Long id = util.getLookupId(LookupNameHelper.RIGHT_PLACEMENT);
		
		manageAppsenseProcess.setProxyInstanceList(util
				.getProxyInstanceName("appsense", "BASIC", null, id));
		
		request.getSession().setAttribute("proxyFilterList",manageAppsenseProcess.getProxyFilterList() );
		manageAppsenseProcess.setProxyProcess(proxyProcess);
		
		String indexId = request.getParameter("indexId");
		log.info("manageProxyAction.viewAppsenseProxy()::Indexid::: " + indexId);
		if ((indexId != null) && !indexId.equals("null")) {
			index = Integer.valueOf(indexId).intValue();
		}

		if (index >= 0) {
			log.info("index ---- " + index);
				proxyFilterList = manageAppsenseProcess
						.getProxyFilterList();
				ProxyFilter proxyFilter = (ProxyFilter) proxyFilterList
						.get(index);
				if (proxyFilter.getApplication() == null) {
					proxyFilter.setApplication(new Application());
				}
				manageAppsenseProcess.setProxyFilter(proxyFilter);
			
		}
		
		Long apsADGroupID = util.getAppsADGroupID(tiProcess.getId());
		log.info("apsADGroupID in load action method:: " + apsADGroupID);
		if (!apsADGroupID.equals(Long.valueOf(0))) {
		    AppsenseADGroup appsenseADGroup = new AppsenseADGroup();
		    appsenseADGroup = (AppsenseADGroup) util
			    .getAppsADGroupDetails(apsADGroupID);
		    if (appsenseADGroup != null) {
		    	manageAppsenseProcess.setAppsADGroupName(appsenseADGroup
				.getName());
		    	manageAppsenseProcess.setAppsADGroupStatus(appsenseADGroup
				.getIsNew());
		    	manageAppsenseProcess.setAppsPolicyId(appsenseADGroup
				    .getPolicyID());
		    	manageAppsenseProcess.setAppsPolicyName(appsenseADGroup
				    .getPolicyName());
		    	manageAppsenseProcess.setAppsPolicyMasterId(appsenseADGroup
				    .getId());
		    	manageAppsenseProcess.setAppsPolicyStatus(appsenseADGroup
				    .getIsNew());
		    }
		}
		request.getSession().setAttribute("viewAppsense", "true");
		model.addAttribute("appsenseData", manageAppsenseProcess);
		log.info("manageProxyAction.viewAppsenseProxy()::Ends");
		return forwardTo;
	}

}
