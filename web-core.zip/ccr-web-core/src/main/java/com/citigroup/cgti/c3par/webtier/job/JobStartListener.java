/**
 * 
 */
package com.citigroup.cgti.c3par.webtier.job;

import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.quartz.CronExpression;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextStartedEvent;
import org.springframework.stereotype.Component;

import com.citigroup.cgti.c3par.fw.service.ServiceNowMessageJob;
import com.citigroup.cgti.c3par.gdw.CitiContactRefreshJob;
import com.citigroup.cgti.c3par.gdw.CitiContactUpdateJob;
import com.citigroup.cgti.c3par.mailmodule.ACVExpirationMailJob;
import com.citigroup.cgti.c3par.mailmodule.AccessFormRemainderJob;
import com.citigroup.cgti.c3par.mailmodule.ActivityExpirationJob;
import com.citigroup.cgti.c3par.mailmodule.ApprovalRemainderMailJob;
import com.citigroup.cgti.c3par.mailmodule.OneWeekNTPJob;
import com.citigroup.cgti.c3par.reports.util.ClearReportTablesJob;
import com.citigroup.cgti.c3par.scheduler.ACVInitiateJob;
import com.citigroup.cgti.c3par.scheduler.CSIApplicationSynchJob;
import com.citigroup.cgti.ccr.workflow.impl.MigrationServiceJob;

/**
 * @author ka58098
 *
 */
@Component
public class JobStartListener implements ApplicationListener<ContextStartedEvent> {
    private static Logger log = Logger.getLogger(JobStartListener.class);
    private ApplicationContext context = null;
    private Scheduler scheduler = null;
    public static final Map<String, String> JOB_NAMES_GROUPS = CCRJobsConstants.JOB_NAMES_GROUPS;
    
    @Autowired 
    JobStopListener jobstopListener;

    @Override
    public void onApplicationEvent(ContextStartedEvent event) {
        log.info("Entering ::");
        context = event.getApplicationContext();
        JobCronExpression jobCronExpression = (JobCronExpression) context.getBean(CCRJobsConstants.JOB_CRONEXPRESSION);
        try {
            //jobstopListener. deleteAllJobs();
            startAllJobs(jobCronExpression);
        } catch (SchedulerException e) {
            log.error("Error has occurred onApplicationEvent method():: . Exception is " + e.getMessage());
            log.error(e.toString(), e);

        }
        log.info("Exiting ::");

    }
       public void startAllJobs(JobCronExpression jobCronExpression) throws SchedulerException {
        log.info("Entering : ");
        scheduler = new StdSchedulerFactory().getScheduler();
        for (Entry<String, String> entry : JOB_NAMES_GROUPS.entrySet()) {
            String jobName = entry.getKey();
            String jobGroup = entry.getValue();
            JobDetail jobDetail = null;
            CronTrigger cronTrigger = null;
            CronExpression cexp = null;
            
            try {
            
                switch (jobName) {

                    case CCRJobsConstants.MIGRATION_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, MigrationServiceJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.MIGRATION_TRIGGER,
                                CCRJobsConstants.MIGRATION_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getMigrationServiceJob());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for : " + CCRJobsConstants.MIGRATION_JOB + " : " + cexp);

                        break;
                   
                    case CCRJobsConstants.ACV_INITIATE_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, ACVInitiateJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.ACV_INITIATE_TRIGGER,
                                CCRJobsConstants.ACV_INITIATE_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getAcvInitiateJob());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for : " + CCRJobsConstants.ACV_INITIATE_JOB + " : " + cexp);
                        
                        break;
                    
                    case CCRJobsConstants.ACCESSFORM_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, AccessFormRemainderJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.ACCESSFORM_TRIGGER,
                                CCRJobsConstants.ACCESSFORM_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getAccessFormRemainderJob());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for : " + CCRJobsConstants.ACCESSFORM_JOB + ": " + cexp);

                        break;
                    
                    case CCRJobsConstants.APPROVALFORM_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, ApprovalRemainderMailJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.APPROVALFORM_TRIGGER,
                                CCRJobsConstants.APPROVALFORM_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getApprovalRemainderMailJob());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :  " + CCRJobsConstants.APPROVALFORM_JOB + ": " + cexp);
                        
                        break;
                    
                    case CCRJobsConstants.ACTIVITY_EXPIRY_JOB:

                        jobDetail = new JobDetail(jobName, jobGroup, ActivityExpirationJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.ACTIVITY_EXPIRY_TRIGGER,
                                CCRJobsConstants.ACTIVITY_EXPIRY_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getActivityExpirationRemainderMailJob());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :   " + CCRJobsConstants.ACTIVITY_EXPIRY_JOB + ": " + cexp);
                        
                        break;
                    
                    case CCRJobsConstants.CITI_CONTACT_UPDATE_JOB:

                        jobDetail = new JobDetail(jobName, jobGroup, CitiContactUpdateJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.CITI_CONTACT_UPDATE_TRIGGER,
                                CCRJobsConstants.CITI_CONTACT_UPDATE_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getCitiContactUpdateJob());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :   " + CCRJobsConstants.CITI_CONTACT_UPDATE_JOB + ": " + cexp);
                        
                        break;
                    
                    case CCRJobsConstants.CITI_CONTACT_REFRESH_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, CitiContactRefreshJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.CITI_CONTACT_REFRESH_TRIGGER,
                                CCRJobsConstants.CITI_CONTACT_REFRESH_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getCitiContactRefreshJob());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :   "  + CCRJobsConstants.CITI_CONTACT_REFRESH_JOB + ": " + cexp);

                        break;
                    
                    case CCRJobsConstants.CLEAR_REPORT_TABLES_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, ClearReportTablesJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.CLEAR_REPORT_TABLES_TRIGGER,
                                CCRJobsConstants.CLEARREPORT_TABLES_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getClearReportTablesJob());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :   "  + CCRJobsConstants.CLEAR_REPORT_TABLES_JOB + ": " + cexp);
                        
                        break;
                    
                    case CCRJobsConstants.USER_GROUP_DETAIL_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, UserGroupDetailJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.USER_GROUP_DETAIL_TRIGGER,
                                CCRJobsConstants.USER_GROUP_DETAIL_TRIGGER_GROUP);

                        cexp = new CronExpression(jobCronExpression.getJobDetailUserGroup());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :   " + CCRJobsConstants.USER_GROUP_DETAIL_JOB + ": " + cexp);

                        break;

                    case CCRJobsConstants.CSI_APPLICATION_SYNCH_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, CSIApplicationSynchJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.CSI_APPLICATION_SYNCH_TRIGGER,
                                CCRJobsConstants.CSI_APPLICATION_SYNCH_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getCsiApplicationSynchJob());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :   " + CCRJobsConstants.CSI_APPLICATION_SYNCH_JOB + ": "
                                + cexp);

                        break;
                    
                    case CCRJobsConstants.ACV_EXPIRY_MAIL_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, ACVExpirationMailJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.ACV_EXPIRY_MAIL_TRIGGER,
                                CCRJobsConstants.ACV_EXPIRY_MAIL_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getScheduleAndACVExpirationMailJob());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :   " + CCRJobsConstants.ACV_EXPIRY_MAIL_JOB + ": " + cexp);
                        
                        break;

                    case CCRJobsConstants.RFC_NETINFO_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, RFCNetInfoJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.RFC_NETINFO_TRIGGER,
                                CCRJobsConstants.RFC_NETINFO_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getRfcNetInfoScheduler());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :   "  + CCRJobsConstants.RFC_NETINFO_JOB + ": " + cexp);
                        
                        break;
                    
                    case CCRJobsConstants.PURGE_LOG_TEXT_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, ServiceNowMessageJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.PURGE_LOG_TEXT_TRIGGER,
                                CCRJobsConstants.PURGE_LOG_TEXT_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getJobDetailSN());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :   "  + CCRJobsConstants.PURGE_LOG_TEXT_JOB + ": " + cexp);
                        
                        break;

                    case CCRJobsConstants.ONE_WEEK_NTP_JOB:
                        jobDetail = new JobDetail(jobName, jobGroup, OneWeekNTPJob.class);
                        cronTrigger = new CronTrigger(CCRJobsConstants.ONE_WEEK_NTP_TRIGGER,
                                CCRJobsConstants.ONE_WEEK_NTP_TRIGGER_GROUP);
                        cexp = new CronExpression(jobCronExpression.getJobDetail1WeekNTP());
                        cronTrigger.setCronExpression(cexp);
                        log.info("Cron Expression for :   "  + CCRJobsConstants.ONE_WEEK_NTP_JOB + ": " + cexp);
                        
                        break;

                    default:
                        log.info(" default block : No case mathced for job"+entry.getKey());
                        
                        break;
                }
                log.debug("Scheduling  job   : " + entry.getKey() + " from the jobGroup " + entry.getValue());
                scheduler.scheduleJob(jobDetail, cronTrigger);
                log.info("Scheduled  job   : " + entry.getKey() + " from the jobGroup " + entry.getValue());
            } catch (Exception e) {
                log.error("Exception occurred while scheduling  the job :" + entry.getKey() + ". Exception is "
                        + e.getMessage());
                log.error(e.toString(), e);
            }
        }
        scheduler.start();
        log.info("Scheduler started for all jobs :Exiting ::");

    }

}
