package com.citigroup.cgti.c3par.webtier.controller.admin;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.admin.domain.MigrateBPMProcess;
import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.ccr.workflow.impl.MigrationServiceScheduler;

@Controller
public class MigrateBPMController {
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@Autowired
	private AdminServicePersistable adminServicePersistable;
	
	@Autowired
	MigrationServiceScheduler migrationServiceScheduler;
	
	@RequestMapping(value = "/loadMigrateBPM.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadMigrateBPM(@ModelAttribute("migrateBPMProcess") MigrateBPMProcess migrateBPMProcess,
			ModelMap model) {
		log.info("MigrateBPMController :: loadMigrateBPM starts ");
		migrateBPMProcess.setActivityNameList(adminServicePersistable.getActivityNameList());
		migrateBPMProcess.setSelectedActivityName("");
		migrateBPMProcess.setSelectedActivityName("Selected");
		model.addAttribute("migrateBPMProcess", migrateBPMProcess);
		log.info("MigrateBPMController :: loadMigrateBPM ends ");
		return "c3par.admin.migrateBPM";
	}

	@RequestMapping(value = "/saveMigrateBPM.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String saveMigrateBPM(@ModelAttribute("migrateBPMProcess") MigrateBPMProcess migrateBPMProcess,
			BindingResult result, HttpServletRequest request) {
		log.info("MigrateBPMController :: saveMigrateBPM starts ");
		String activityName = migrateBPMProcess.getSelectedActivityName();
		log.info("MigrateBPMController :: saveMigrateBPM : activityName :"+activityName);
		migrationServiceScheduler.startMigration();
		log.info("MigrateBPMController :: loadMigrateBPM ends ");
		return "forward:/logon.act";
	}

}
