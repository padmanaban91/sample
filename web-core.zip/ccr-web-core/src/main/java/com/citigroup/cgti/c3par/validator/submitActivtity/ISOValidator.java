package com.citigroup.cgti.c3par.validator.submitActivtity;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;

import com.citigroup.cgti.c3par.comments.domain.SubmitActivityErrors;

/*
 * @nc43495
 */
public class ISOValidator implements Validator{
	
	/** The log. */
    private static Logger log = Logger.getLogger(ISOValidator.class);
	
	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub
		
	}
    
    private JdbcTemplate jdbcTemplate;
    
    public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/**
     * Gets the iSO message.
     *
     * @param tiReqId the ti req id
     * @return the iSO message
     */
    public List<ObjectError> getISOMessage(Long tiReqId){
	List<ObjectError> techList=new ArrayList<ObjectError>();
	try{
	    //Document(Technical Notification 1, Technical Notification 2) Upload Message
	    List<ObjectError> docMessage=getDocumentUploadMessage(tiReqId);
	    if(docMessage.size()>0){
		for(int i=0;i<docMessage.size();i++){	
		    techList.addAll(docMessage);
		}
	    }
	}catch(Exception ex){
	    ex.printStackTrace();
	}
	return techList;
    }

    /**
     * Gets the document upload message.
     *
     * @param tiReqId the ti req id
     * @return the document upload message
     * @throws Exception the exception
     * @returns Document Upload Messages.
     */
    private List<ObjectError> getDocumentUploadMessage(Long tiReqId){
    log.debug("ISOValidator getDocumentUploadMessage...");
    
	StringBuffer docSQL=new StringBuffer();
	
	List<ObjectError> messageList=new ArrayList<ObjectError>();
	
	try {
	    docSQL.append(" SELECT b.ID FROM TI_DOC_META_DATA A, ti_process B, relationship C, ti_process_type D, ti_request E  WHERE a.connection_id = b.id  " +
	    		"AND b.relationship_id = c.id and c.relationship_type = 'U_TURN'  and b.process_type_id = d.id  and d.process_type = 'Connection'" +
	    		"AND A.DOC_TYPE     ='Technical Notification 1' AND b.ID=e.process_id AND e.id = ? INTERSECT  SELECT b.ID " +
	    		"FROM TI_DOC_META_DATA A, ti_process B, relationship C, ti_process_type D, ti_request E  WHERE a.connection_id = b.id  " +
	    		"AND b.relationship_id = c.id and c.relationship_type = 'U_TURN'  and b.process_type_id = d.id  and d.process_type = 'Connection' " +
	    		"AND A.DOC_TYPE     ='Technical Notification 2' AND b.ID=e.process_id AND e.id = ?");
	    
	    SqlRowSet result  = jdbcTemplate.queryForRowSet(docSQL.toString(),new Object[]{Long.valueOf(tiReqId),Long.valueOf(tiReqId)});
	    
	    if(!result.next()){
	    	
	    docSQL=new StringBuffer();	
	    docSQL.append("select a.id from ti_request a, ti_process b, relationship c where a.process_id = b.id and b.relationship_id = c.id and c.relationship_type = 'U_TURN' and a.id = ?");
		
	    SqlRowSet result1  = jdbcTemplate.queryForRowSet(docSQL.toString(),new Object[]{Long.valueOf(tiReqId)});
	    
		if(result1.next()){
			messageList.add(new ObjectError("ISO_DOCUMENT",new String[]{SubmitActivityErrors.ISO_DOCUMENT},null,null));
		}
	    }
	    
	    log.info("messageList Size::"+messageList.size());	

	}catch (Exception e) {
	    log.error(e,e);
	}
	return messageList;
    }

   
}
