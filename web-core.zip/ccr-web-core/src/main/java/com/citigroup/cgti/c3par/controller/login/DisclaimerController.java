package com.citigroup.cgti.c3par.controller.login;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.citigroup.cgti.c3par.util.C3parProperties;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class DisclaimerController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(DisclaimerController.class);
	
	@RequestMapping(value = "/disclaimer.act")
	public String disclaimer(HttpServletRequest request){
		log.info("DisclaimerController starts here..");
		String loginpage = (String)request.getSession().getAttribute("login_page");
		if(loginpage!=null){
			 String userId = request.getHeader("SM_USER");
		    request.getSession().removeAttribute("login_page");
		    // Health Check Login trial
		    if (null != userId) {
			String passwd1 = userId + "!!";
			userId = userId.toLowerCase();
			Util util = new Util();
			boolean allowcheck = util.allowHealthCheckUser(userId, passwd1);
			if(!allowcheck){
			    return "forward:/logout.act";
			}

		    }
		}

		if(C3parProperties.SITE_IS_IN_MAINTENANCE.equals("TRUE")){

		    return "c3par.sitemaintenance";
		}
		return "c3par.disclaimer";
	}
	
}
