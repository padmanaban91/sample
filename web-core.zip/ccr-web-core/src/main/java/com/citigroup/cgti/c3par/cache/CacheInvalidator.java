/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.cache;

import com.mentisys.cache.CMComponentFactory;

//import com.mentisys.cache.InvalidateCacheEvent;

// pkadam: This was the class/utility used by the application components to indicate that
// other server instances should revalidate their cache. Instead of removing the class
// the code was just commented out.
//
// For details : see JMSDCMComponent notes.

/**
 * The Class CacheInvalidator.
 *
 * @author pkadam
 */
@SuppressWarnings( { "unused" })
public class CacheInvalidator {

    /** The Constant factory. */
    private static final CMComponentFactory factory = new CMComponentFactory();

    /**
     * Invalidate business unit cache.
     */
    public static void invalidateBusinessUnitCache() {

	//		factory.getCacheManagementEventPublisher().publish(new InvalidateCacheEvent("BusinessUnit"));
    }

    /**
     * Invalidate generic lookup.
     */
    public static void invalidateGenericLookup() {

	//		factory.getCacheManagementEventPublisher().publish(new InvalidateCacheEvent("GenericLookup"));
    }

    /**
     * Invalidate c3par users.
     */
    public static void invalidateC3parUsers() {

	//		factory.getCacheManagementEventPublisher().publish(new InvalidateCacheEvent("C3parUsers"));
    }
}
