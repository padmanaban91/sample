/*
 * Created on May 27, 2005
 *
 */
package com.citigroup.cgti.c3par.reports.reportInterface;

import com.citigroup.cgti.c3par.reports.model.DataSourceEntity;



/**
 * The Interface DataResetter.
 *
 * @author Gerald Robinson
 * 
 * </br>
 * <h1>Description</h1>
 * This interface provides method(s) to perform reset functionality.
 */
public interface DataResetter {

    /**
     * This method returns the temporary table name to be reset. It may return a null value
     * in case temp table is not set.
     * 
     * @return String
     */
    public String getTemporaryTable() ;

    /**
     * This method must perform reset functionality.
     *
     * @throws ReportException the report exception
     */
    public void reset() throws ReportException;

    /**
     * This method must perform delete functionality.
     *
     * @throws ReportException the report exception
     */
    public void deleteTable() throws ReportException;

    /**
     * This method returns the DataSourceEntity instance for this DataResetter.
     *
     * @return - DataSourceEntity
     */
    public DataSourceEntity getDataSourceEntity();
}
