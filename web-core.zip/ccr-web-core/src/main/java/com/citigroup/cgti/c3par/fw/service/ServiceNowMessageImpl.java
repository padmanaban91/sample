/**
 *
 */
package com.citigroup.cgti.c3par.fw.service;

import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.RFC_REQ_TYPE_FIREWALL;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.RFC_REQ_TYPE_PROXY;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_BASICINFO;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_CHANGETASK;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_CHANGETASK_PROXY;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_CHANGETASK_PROXY_PAC;
import static com.citigroup.cgti.c3par.soa.vc.util.RFCConstants.SECTION_CHANGETASK_PROXY_PAC_NAM;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.ASSIGNMENT_GROUP;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CHANGE_CATEGORY;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CHANGE_NUMBER;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CHANGE_REQUEST_CODE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CHANGE_TASK_CODE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CLASSIFICATION;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CONFIGITEM;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.CT_CREATE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.DESCRIPTION;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.DIRECTOR_APPROVAL_MAIL;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.END_DATE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.HEADER;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.ID;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.INSTRUCTION;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.MSG_TYPE_OUTBOUND;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.NONMADDATORY;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.SEQUENCE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.SERVICE_NOW;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.SOURCE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.START_DATE;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.SYSTEM_ID;
import static com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants.TITLE;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.StringWriter;
import java.sql.Blob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.impl.util.Base64;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.AccessFormText;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.ServiceNowMessageError;
import com.citigroup.cgti.c3par.fw.domain.ServiceNowMessageLog;
import com.citigroup.cgti.c3par.fw.domain.ServiceNowMessageText;
import com.citigroup.cgti.c3par.fw.domain.soc.persist.ServiceNowMessageLogPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.sn.ServiceNowSoap;
import com.citigroup.cgti.c3par.snow.forms.ServiceNowAttachment;
import com.citigroup.cgti.c3par.soa.vc.dao.RFCPersistable;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetail;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetailAnswer;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.soa.vc.logic.RFCService;
import com.citigroup.cgti.c3par.soa.vc.util.RFCUtil;

import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfDataField;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfDataFieldGroup;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfString;
import net.nsroot.eur.servicesolutions.cate.integration.DataField;
import net.nsroot.eur.servicesolutions.cate.integration.DataFieldGroup;
import net.nsroot.eur.servicesolutions.cate.integration.DataForm;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentItem;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentSystem;
import net.nsroot.eur.servicesolutions.cate.integration.OrderSystem;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescriptionDocument;

//import weblogic.utils.encoders.Base64Bytes;

/**
 * @author nc43495 
 * 
 */

@SuppressWarnings("unchecked")
@Transactional
public class ServiceNowMessageImpl extends BasePersistanceImpl implements ServiceNowMessageLogPersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(ServiceNowMessageImpl.class);
	
	RFCUtil rfcUtil = null;

	RFCPersistable rfcPersistable = null;
	
	private RFCService rfc;
	
	private javax.xml.ws.Service snService;
	
	private ServiceNowSoap snAttach;
	
	private AccessFormText accessFormTextGenerator;
	
	public RFCUtil getRfcUtil() {
		return rfcUtil;
	}

	public void setRfcUtil(RFCUtil rfcUtil) {
		this.rfcUtil = rfcUtil;
	}

	public RFCPersistable getRfcPersistable() {
		return rfcPersistable;
	}

	public void setRfcPersistable(RFCPersistable rfcPersistable) {
		this.rfcPersistable = rfcPersistable;
	}

	public RFCService getRfc() {
		return rfc;
	}

	public void setRfc(RFCService rfc) {
		this.rfc = rfc;
	}

	public AccessFormText getAccessFormTextGenerator() {
		return accessFormTextGenerator;
	}

	public void setAccessFormTextGenerator(AccessFormText accessFormTextGenerator) {
		this.accessFormTextGenerator = accessFormTextGenerator;
	}

	private ServiceNowAttachment snow_attachment;
	
	public ServiceNowAttachment getSnow_attachment() {
		return snow_attachment;
	}

	public void setSnow_attachment(ServiceNowAttachment snow_attachment) {
		this.snow_attachment = snow_attachment;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public  void saveServiceNowMessage(ServiceNowMessageLog serviceNowMessage) {
		log.info("Entered saveServiceNowMessage");
		getHibernateTemplate().save(serviceNowMessage);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false)
	public void updateServiceNowMessage(ServiceNowMessageLog serviceNowMessage) {
		log.info("Entered updateServiceNowMessage");
		try {
			Long rfcId = serviceNowMessage.getRfcReqId();
			String SNNumber = serviceNowMessage.getSnNumber();
			Long messageLogId = serviceNowMessage.getId();
			/*
			if(SNNumber!=null && SNNumber.toUpperCase().indexOf("CHG")!=-1)
			{
				RFCRequest rfc = new RFCRequest();
				rfc.setId(rfcId);
				rfc.setRfcId(SNNumber);
				rfcPersistable.updateRFCRequest(rfc);
			}
			*/
			List<ServiceNowMessageError> serviceNowMessageErrors = serviceNowMessage.getServiceNowMessageErrorsList();
			
			ServiceNowMessageText nowMessageText = null;
			if (serviceNowMessage.getServiceNowMessageText() != null && serviceNowMessage.getServiceNowMessageText().size() > 0) {
				nowMessageText = serviceNowMessage.getServiceNowMessageText().get(0);
			}
			
			Session session = getSession();
			ServiceNowMessageLog serviceNowMessage1 = (ServiceNowMessageLog) session.get(ServiceNowMessageLog.class, serviceNowMessage.getId());
			
			if(serviceNowMessage1!=null){
				log.info("saveServiceNowMessage saveServiceNowMessage :"+ messageLogId);
				this.saveServiceNowMessage(serviceNowMessage);
			}else{
				log.info("updateServiceNowMessage SNNumber :"+ SNNumber);
				log.info("updateServiceNowMessage rfcId :"+ rfcId);
				log.info("updateServiceNowMessage messageLogId :"+ messageLogId);
				
				
				serviceNowMessage.setRfcReqId(rfcId);
				serviceNowMessage.setSnNumber(SNNumber);
				serviceNowMessage.setId(messageLogId);
				serviceNowMessage.setUpdated_date(new Date());
				
				if (serviceNowMessage.getServiceNowMessageText() != null) {
					serviceNowMessage.getServiceNowMessageText().add(nowMessageText);
				} else {
					serviceNowMessage.setServiceNowMessageText(new ArrayList<ServiceNowMessageText>());
				}
				getHibernateTemplate().update(serviceNowMessage);
				if (serviceNowMessageErrors != null && serviceNowMessageErrors.size() > 0) {
					for (ServiceNowMessageError serviceNowMessageError : serviceNowMessageErrors) {
						getHibernateTemplate().saveOrUpdate(serviceNowMessageError);
					}
					//getHibernateTemplate().saveOrUpdate(serviceNowMessageErrors);
				}
			}
			
			
			try {
				if(SNNumber!=null && SNNumber.toUpperCase().indexOf("CHG")!=-1)
				{
					SQLQuery query = getSession().createSQLQuery("update RFC_REQUEST  set RFC_ID = '"+SNNumber+"' where id = "+serviceNowMessage.getRfcReqId());
					query.executeUpdate();
				}
			} catch (Exception e)		 {
					log.error(e,e);
				e.printStackTrace();
			}

			if (serviceNowMessage.getSnNumber()!=null && serviceNowMessage.getSnNumber().toUpperCase().indexOf(CHANGE_REQUEST_CODE) != -1)
			{
				String rfcType = getRFCType(rfcId);
				log.info("updateServiceNowMessage rfcType :"+ rfcType);
				
				boolean isBuscrit = rfcUtil.isBuscritConnection(serviceNowMessage.getTiRequestID());
				if(isBuscrit){
					sendEmailAttachmentToServiceNow(serviceNowMessage);
				}

				if(rfcType != null && rfcType.equalsIgnoreCase("Firewall")){
					createServiceNowTask(serviceNowMessage,rfcType,"");
				}else if(rfcType != null && rfcType.equalsIgnoreCase("Proxy")){
					createServiceNowTask(serviceNowMessage,rfcType,SECTION_CHANGETASK_PROXY);
					
					if(isProxyPACFILE(rfcId)){
						createServiceNowTask(serviceNowMessage,rfcType,SECTION_CHANGETASK_PROXY_PAC);

						if(isProxyPACFILENAMRegion(rfcId)){
						//createServiceNowTask(serviceNowMessage,rfcType,SECTION_CHANGETASK_PROXY_PAC_NAM);
						}
					}
				}
				
				sendAccessFormStringAttachmentToServiceNow(serviceNowMessage,rfcType);	
			}
		} catch (Exception e)		 {
			log.error(e,e);
			e.printStackTrace();
		}
		log.info("End updateServiceNowMessage");
	}
	
	public void purgeLogText(){		
		log.info("ServiceMessageImpl:PurgeLogText:Purge blob data older than a 30days");
		Query query = getSession().createSQLQuery("update SERVICENOW_MESSAGE_TEXT set MESSAGE_TEXT = null,UPDATED_DATE=SYSDATE " +
				" where UPDATED_DATE >((SYSDATE) - 30) and MESSAGE_TEXT is not null");
		query.executeUpdate();
	}
	
	@Override
	 @Transactional(readOnly = true)
	public ServiceNowMessageLog findServiceNowMessageLogByID(Long id) {	
		ServiceNowMessageLog snowMsgLog = null;
		Query query = getSession().createQuery("from ServiceNowMessageLog where id=" + id);
		snowMsgLog = (ServiceNowMessageLog) query.uniqueResult();
		
		return snowMsgLog;
	}
	
	/**
	 * 
	 * @param serviceNowMessage
	 */
	private void sendAccessFormStringAttachmentToServiceNow(ServiceNowMessageLog serviceNowMessage,String rfcType) {
		log.info("ServiceMessageImpl :: sendAccessFormStringAttachmentToServiceNow :: starts");
		try{
			/*
			 RFCRequest rfcRequest = new RFCRequest();
             rfcRequest.setId(serviceNowMessage.getRfcReqId());
            
             RFCRequest implFAF = rfcRequest;
             FAFRequest fafreq = new FAFRequest();
             implFAF = fafreq.getRFCDetails(rfcRequest,IMPLEMENTATIONPLAN,RFC_REQ_TYPE_FIREWALL);
             
             String faf_string = null;
             
             if(implFAF != null){
            	 faf_string=displayAnswers(implFAF.getImplementationPlan());
            	 faf_string = faf_string.replaceAll("\n", "\r\n");
             }
			*/
             RFCRequest rfcRequest = rfc.getRFCRequest(serviceNowMessage.getRfcReqId());
             
             String accessform_string = null, msgName = null;

 			//retrieve the access form string based on the change type (firewall, proxy, etc)
             if(rfcType != null && rfcType.equalsIgnoreCase("Proxy")){
            	 accessform_string = accessFormTextGenerator.getProxyAccessFormTextByRFC(rfcRequest);            	 
             }else{
            	 accessform_string = accessFormTextGenerator.getFirewallAccessFormTextByRFC(rfcRequest);   
             }
             accessform_string = accessform_string.replaceAll("\n", "\r\n");
        	 
        	 log.debug("ServiceNowMessageImpl :: sendAccessFormStringAttachmentToServiceNow :: accessFormTextGenerator :: "+accessform_string);
        	 
			byte mailContent[] = accessform_string.getBytes();

	        snow_attachment.setSnow_attachement_type("@FILE_NAME@:text/plain");
	        
			String wsURL = snow_attachment.getSnow_attachement_url();
			String nameSpace = snow_attachment.getSnow_attachement_name_space();
			String serviceName = snow_attachment.getSnow_attachement_service_nam();
			
			//get file names based on the change type (firewall, proxy, etc)
            if(rfcType != null && rfcType.equalsIgnoreCase("Proxy")){
            	msgName = getPAFFileName(serviceNowMessage.getTiRequestID(),serviceNowMessage.getSnNumber());
            }else{
            	msgName = getFAFFileName(serviceNowMessage.getTiRequestID(),serviceNowMessage.getSnNumber());
            }
            
			String payLoad = new String(Base64.encode(mailContent));
			log.info(msgName);
			String fileName = snow_attachment.getSnow_attachement_type().replace("@FILE_NAME@", msgName);
			log.info(fileName);
			File f = new File(snow_attachment.getSnow_attachment_temp_dir()+msgName);
			
			if(f.exists())
			{
				f.delete();
			}else{
				f.createNewFile();
			}
			
			FileWriter fw = new FileWriter(f.getAbsolutePath());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(accessform_string);
			bw.close();
			
			//sendServiceNowAttachmentRequest(serviceNowMessage.getSnNumber(),fileName,payLoad,wsURL,nameSpace,serviceName);
			String soapRequest =  snow_attachment.getSnow_attachement_soap_content().replace("@CHANGE_TASK_NUMBER@", serviceNowMessage.getSnNumber()).replace("@FILENAME@", fileName).replace("@PAY_LOAD@", payLoad);
			sendServiceNowAttachmentRequest(soapRequest,wsURL);
			
			/*String soapData = getSNOWParams(wsURL,serviceNowMessage.getSnNumber(),fileName);
			log.info("soapData.."+soapData);*/
			
			
			/*Runtime.getRuntime().exec(snow_attachment.getSnow_attachment_java_path()+" -cp ServiceNowAttachmentImpl "
					+" "+"\""+snow_attachment.getSnow_attachement_truststore_path()+"\""
					+" "+"\""+snow_attachment.getSnow_attachement_truststore_type()+"\""
					+" "+"\""+snow_attachment.getSnow_attachement_truststore_password()+"\""
					+" "+"\""+snow_attachment.getSnow_attachement_truststore_revocation_check()+"\""
					+" "+"\""+wsURL+"\""
					+" "+"\""+snow_attachment.getSnow_attachement_wsdl_user()+"\""
					+" "+"\""+snow_attachment.getSnow_attachement_wsdl_password()+"\"" 
					+" "+"\""+serviceNowMessage.getSnNumber()+"\""
					+" "+"\""+fileName+"\""
					+" "+"\""+msgName+"\""	
					+" "+"\""+snow_attachment.getSnow_attachment_temp_dir()+"\""
			);*/
			
			
			/*String str = snow_attachment.getSnow_attachment_java_path()+" -cp "+snow_attachment.getSnow_attachment_class()+" com.citigroup.cgti.c3par.fw.service.ServiceNowAttachmentImpl "+
					snow_attachment.getSnow_attachement_truststore_path()+"#PARTITION#"+
					snow_attachment.getSnow_attachement_truststore_type()+"#PARTITION#"+
					snow_attachment.getSnow_attachement_truststore_password()+"#PARTITION#"+
					snow_attachment.getSnow_attachement_truststore_revocation_check()+"#PARTITION#"+
					wsURL+"#PARTITION#"+
					snow_attachment.getSnow_attachement_wsdl_user()+"#PARTITION#"+
					snow_attachment.getSnow_attachement_wsdl_password()+"#PARTITION#"+ 
					serviceNowMessage.getSnNumber()+"#PARTITION#"+
					fileName+"#PARTITION#"+
					msgName+"#PARTITION#"+	
					snow_attachment.getSnow_attachment_temp_dir();
			
			log.info("str..."+str);
		*/
/*
			try {
			      String line;
			      Process p = Runtime.getRuntime().exec(str);
			      BufferedReader bri = new BufferedReader
			        (new InputStreamReader(p.getInputStream()));
			      BufferedReader bre = new BufferedReader
			        (new InputStreamReader(p.getErrorStream()));
			      while ((line = bri.readLine()) != null) {
			    	  log.debug(line);
			      }
			      bri.close();
			      while ((line = bre.readLine()) != null) {
			    	  log.debug(line);
			      }
			      bre.close();
			      //p.waitFor();
			      log.debug("Done... FAF Attached");
			    }
			    catch (Exception e) {
			      log.error(e,e);
			    }		
			
			*/
		}catch(Exception e){
			log.error(e,e);
		}
		log.info("ServiceMessageImpl :: sendAccessFormStringAttachmentToServiceNow :: ends");
	}
	
	public void sendAccessFormToSNOW(ServiceNowMessageLog serviceNowMessage,String rfcType)
	{
		sendAccessFormStringAttachmentToServiceNow(serviceNowMessage,rfcType);
	}

	public void sendEmailAttachmentToSNOW(ServiceNowMessageLog serviceNowMessage)
	{
		sendEmailAttachmentToServiceNow(serviceNowMessage);
	}
	
	private void sendEmailAttachmentToServiceNow(ServiceNowMessageLog serviceNowMessage) {
		log.info("ServiceMessageImpl :: sendEmailAttachmentToServiceNow :: starts");
		try{
			byte mailContent[] = rfcUtil.getTIDocMetaData(serviceNowMessage.getTiRequestID(),DIRECTOR_APPROVAL_MAIL);
			
			
			snow_attachment.setSnow_attachement_type("@FILE_NAME@:application/vnd.ms-outlook");
			String wsURL = snow_attachment.getSnow_attachement_url();
			String nameSpace = snow_attachment.getSnow_attachement_name_space();
			String serviceName = snow_attachment.getSnow_attachement_service_nam();
			String msgName = "DirApp"+getDateString()+".msg";
			String fileName = snow_attachment.getSnow_attachement_type().replace("@FILE_NAME@", msgName);
			String payLoad = new String(Base64.encode(mailContent));
			
			
			File f = new File(snow_attachment.getSnow_attachment_temp_dir()+msgName);
			
			if(f.exists())
			{
				f.delete();
			}else{
				f.createNewFile();
			}
			
			FileWriter fw = new FileWriter(f.getAbsolutePath());
			BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(f.getAbsolutePath()));
	        output.write(mailContent);
	        output.close();

			//BufferedWriter bw = new BufferedWriter(fw);
			//bw.write(mailContent);
			//bw.close();			
			//sendServiceNowAttachmentRequest(serviceNowMessage.getSnNumber(),fileName,payLoad,wsURL,nameSpace,serviceName);
			String soapRequest =  snow_attachment.getSnow_attachement_soap_content().replace("@CHANGE_TASK_NUMBER@", serviceNowMessage.getSnNumber()).replace("@FILENAME@", fileName).replace("@PAY_LOAD@", payLoad);
			sendServiceNowAttachmentRequest(soapRequest,wsURL);
			/*String str= snow_attachment.getSnow_attachment_java_path()+" -cp "+snow_attachment.getSnow_attachment_class()+" com.citigroup.cgti.c3par.fw.service.ServiceNowAttachmentImpl "+
					snow_attachment.getSnow_attachement_truststore_path()+"#PARTITION#"+
					snow_attachment.getSnow_attachement_truststore_type()+"#PARTITION#"+
					snow_attachment.getSnow_attachement_truststore_password()+"#PARTITION#"+
					snow_attachment.getSnow_attachement_truststore_revocation_check()+"#PARTITION#"+
					wsURL+"#PARTITION#"+
					snow_attachment.getSnow_attachement_wsdl_user()+"#PARTITION#"+
					snow_attachment.getSnow_attachement_wsdl_password()+"#PARTITION#"+ 
					serviceNowMessage.getSnNumber()+"#PARTITION#"+
					fileName+"#PARTITION#"+
					msgName+"#PARTITION#"+	
					snow_attachment.getSnow_attachment_temp_dir();
			log.debug("command from director email..."+str);
			*/
			//Process proc = Runtime.getRuntime().exec(str);	
			
			/*try {
			      String line;
			      Process p = Runtime.getRuntime().exec(str);
			      BufferedReader bri = new BufferedReader
			        (new InputStreamReader(p.getInputStream()));
			      BufferedReader bre = new BufferedReader
			        (new InputStreamReader(p.getErrorStream()));
			      while ((line = bri.readLine()) != null) {
			    	  log.debug(line);
			      }
			      bri.close();
			      while ((line = bre.readLine()) != null) {
			    	  log.debug(line);
			      }
			      bre.close();
			      //p.waitFor();
			      log.debug("Done... Director Approval Mail Attached");
			    }
			    catch (Exception e) {
			      log.error(e,e);
			    }
*/
			
		}catch(Exception e){
			log.error("Error in sendEmailAttachmentToServiceNow method");
			log.error(e,e);
		}
		log.info("ServiceMessageImpl :: sendEmailAttachmentToServiceNow :: ends");
	}
	
	public String getSNOWParams(String wsURL, String changeNumber,String fileName)
	{
		StringBuffer sb = new StringBuffer();
		sb.append("ServiceNowAttachmentImpl");
		sb.append(" ");
		sb.append("\""+snow_attachment.getSnow_attachement_truststore_path()+"\"");
		sb.append(" ");
		sb.append("\""+snow_attachment.getSnow_attachement_truststore_type()+"\"");
		sb.append(" ");
		sb.append("\""+snow_attachment.getSnow_attachement_truststore_password()+"\"");
		sb.append(" ");
		sb.append("\""+snow_attachment.getSnow_attachement_truststore_revocation_check()+"\"");
		sb.append(" ");
		sb.append("\""+wsURL+"\"");
		sb.append(" ");
		sb.append("\""+snow_attachment.getSnow_attachement_wsdl_user()+"\"");
		sb.append(" ");
		sb.append("\""+snow_attachment.getSnow_attachement_wsdl_password()+"\"");
		sb.append(" ");
		sb.append("\""+changeNumber+"\"");
		sb.append(" ");
		sb.append("\""+fileName+"\"");
		sb.append(" ");
		
		
		return sb.toString();
	}
	
	//Method was commented out for 46302 since it returned error even when the attachement was successful.
	//Entire log has been attached in the task
	//Error Message:com.sun.xml.ws.streaming.XMLStreamReaderException: unexpected XML tag. expected: {http://www.service-now.com/addattachment}attachResponse but found: {http://www.service-now.com/AddAttachment}attachResponse
	/*private void sendServiceNowAttachmentRequest(String snNumber, String fileName, String payLoad, String url, String nameSpace, String serviceName) {
		
		URL wsdlLocation = null;
		try {
			wsdlLocation = new URL(url);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try{
		QName service = new QName(nameSpace, serviceName); 
		
		this.snService = new ServiceNowAddattachment(wsdlLocation,service);
		snAttach = snService.getPort(ServiceNowSoap.class);
		BindingProvider bp = (BindingProvider) snAttach;
	    bp.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, snow_attachment.getSnow_attachement_wsdl_user());
	    bp.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, snow_attachment.getSnow_attachement_wsdl_password());

		Holder<String> responseCode = new Holder<String>();
		Holder<String> responseMessage = new Holder<String>();
		
		snAttach.attach(snNumber, fileName, payLoad, responseCode, responseMessage);
		if(responseCode.value != null && responseMessage.value != null){
			log.debug("response message" + responseMessage.value);
		}
		}
		catch(Exception e){
			log.error(e,e);
		}
	}*/

	private String sendServiceNowAttachmentRequest(String soapRequestMessage,String url) throws Exception {   
		log.info("ServiceMessageImpl :: sendServiceNowAttachmentRequest :: starts");
		String xmlResponse = "";
		SOAPConnection soapConnection = null;
		try
		{
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			soapConnection = soapConnectionFactory.createConnection();
			MessageFactory messageFactory = MessageFactory.newInstance();
			SOAPMessage soapMessage = messageFactory.createMessage();
			
			SOAPPart soapPart = soapMessage.getSOAPPart();
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(soapRequestMessage.getBytes("UTF-8"));
			soapPart.setContent(new StreamSource(byteArrayInputStream));
			soapMessage.saveChanges();
			String servicenow_connect_username = snow_attachment.getSnow_attachement_wsdl_user();
			String servicenow_connect_password = snow_attachment.getSnow_attachement_wsdl_password();
			
			String authorization = new String(Base64.encode(((servicenow_connect_username+":"+servicenow_connect_password).getBytes())));
			
			soapMessage.getMimeHeaders().addHeader("Authorization", "Basic "+authorization); 
			SOAPMessage responseSOAPMessage = soapConnection.call(soapMessage,url);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			Source source = responseSOAPMessage.getSOAPPart().getContent();
			StringWriter stringWriter = new StringWriter(512);
			StreamResult streamResult = new StreamResult(stringWriter);
			transformer.transform(source,streamResult);
			xmlResponse = stringWriter.toString();
			log.info("ServiceMessageImpl :: sendServiceNowAttachmentRequest :: xmlResponse ==> "+xmlResponse);
		}catch(Exception e){
			log.error("Error in sendServiceNowAttachmentRequest method");
			log.error(e,e);
		}finally{
			if(soapConnection != null)
				soapConnection.close();
		}
		log.info("ServiceMessageImpl :: sendServiceNowAttachmentRequest :: ends");
		return xmlResponse;
	}
	
	private void createServiceNowTask(ServiceNowMessageLog serviceNowMessage,String rfcType,String CHANGE_TASK_TYPE) {
		log.info("ServiceNowMessageImpl :: createServiceNowTask starts :: rfcType - "+rfcType+" :: CHANGE_TASK_TYPE - "+CHANGE_TASK_TYPE);
		try{
			String serviceNowCreateTask = null;
			
			ServiceNowMessageLog snowMessageLog = new ServiceNowMessageLog();
			snowMessageLog.setTiRequestID(serviceNowMessage.getTiRequestID());
			snowMessageLog.setType(CHANGE_TASK_CODE);
			snowMessageLog.setUpdated_date(new Date());
			List<ServiceNowMessageText> snowMsgTextList = new ArrayList<ServiceNowMessageText>();
			ServiceNowMessageText snowMsgText = new ServiceNowMessageText();
			snowMsgText.setMessageType(MSG_TYPE_OUTBOUND);
			snowMsgText.setCreated_date(new Date());
			snowMsgText.setUpdated_date(new Date());
			snowMsgTextList.add(snowMsgText);
			snowMessageLog.setServiceNowMessageText(snowMsgTextList);
			
			getHibernateTemplate().save(snowMessageLog);
			
			ServiceNowMessageLog newSNowMsgLog = (ServiceNowMessageLog) getHibernateTemplate().get(ServiceNowMessageLog.class, snowMessageLog.getId());
			
			if(rfcType != null && rfcType.equalsIgnoreCase("Firewall")){
				serviceNowCreateTask = getServiceNowChangeTaskXml(serviceNowMessage.getTiRequestID(), serviceNowMessage.getRfcReqId(), serviceNowMessage.getSnNumber(), newSNowMsgLog);
			}else if(rfcType != null && rfcType.equalsIgnoreCase("Proxy")){
				serviceNowCreateTask = getServiceNowProxyChangeTaskXml(serviceNowMessage.getTiRequestID(), serviceNowMessage.getRfcReqId(), serviceNowMessage.getSnNumber(), newSNowMsgLog,CHANGE_TASK_TYPE);
			}
			
			//log.info("createServiceNowTask XML ==>"+serviceNowCreateTask);
			Blob msgText = Hibernate.getLobCreator(getSession()).createBlob(serviceNowCreateTask.getBytes());
			List<ServiceNowMessageText> newSNowMsgTextList = newSNowMsgLog.getServiceNowMessageText();
			for(ServiceNowMessageText newSNowMsgText:newSNowMsgTextList){
				newSNowMsgText.setMessageText(msgText);
			}
			getHibernateTemplate().saveOrUpdate(newSNowMsgLog);
			
			ServiceNowQueueSenderImpl serviceNowQueueSenderImpl = new ServiceNowQueueSenderImpl();
			serviceNowQueueSenderImpl.sendMesage(serviceNowCreateTask);			
		}catch(Exception ex){
			log.error("Error while Sending ServieNow ChangeRequest");
			log.error(ex, ex);
		}
		log.info("ServiceNowMessageImpl :: createServiceNowTask ends");
	}
	
    private String getServiceNowChangeTaskXml(Long tiReqId, Long rfcReqId, String changeRequestNumber, ServiceNowMessageLog snowMessageLog) {
        String temp = "";
        log.info("ServiceNowMessageImpl :: getServiceNowChangeTaskXml starts");
        try{
			   Session session = getSession();			   
			   RFCRequest rfcReq = (RFCRequest) session.get(RFCRequest.class, rfcReqId);			   
			   PurchaseOptionDescriptionDocument podDoc = PurchaseOptionDescriptionDocument.Factory.newInstance();			
			   PurchaseOptionDescription pod = podDoc.addNewPurchaseOptionDescription();
               
			   /*PurchaseOrderDocument purchaseOrderDocument = PurchaseOrderDocument.Factory.newInstance();
               PurchaseOrder purchaseOrder = purchaseOrderDocument.addNewPurchaseOrder();
               ArrayOfPurchaseOptionDescription arrayOfPurchaseOptionDescription =purchaseOrder.addNewPurchaseOptions();
               
               PurchaseOptionDescription pod = arrayOfPurchaseOptionDescription.addNewPurchaseOptionDescription();*/
               OrderSystem os = pod.addNewOrderSystem();
               os.setSystemID(SYSTEM_ID);
               
               StringBuffer mappingRef = new StringBuffer();
               mappingRef.append(rfcReqId);
               mappingRef.append("-");
               if(rfcReq.getRfcLocationID() != null){
                     mappingRef.append(rfcReq.getRfcLocationID().getFwLocation());
               }else{
                     mappingRef.append("");
               }
               mappingRef.append("-");
               mappingRef.append(tiReqId);
               mappingRef.append("-");
               mappingRef.append(snowMessageLog.getId());
               /*mappingRef.append("-");
               mappingRef.append(VERSION);*/
               
               os.setMappingReference(mappingRef.toString());
               FulfilmentSystem ffs = pod.addNewFulfilmentSystem();
               ffs.setSystemID(SERVICE_NOW);
               FulfilmentItem ffi = pod.addNewFulfilmentItem();
               ffi.setFulfilmentItemName(CT_CREATE);
               DataForm df = ffi.addNewDataForm();
               //df.setVersion(VERSION_1);
               df.setIsDetached(false);
               
               ArrayOfDataFieldGroup dfgs= df.addNewDataFieldGroups();
               
               DataFieldGroup dfg = dfgs.addNewDataFieldGroup();
               dfg.setName(HEADER);
               
               ArrayOfDataField dfs = dfg.addNewDataFields();
               
               DataField dfield = dfs.addNewDataField();
               dfield.setName(CHANGE_NUMBER);
               ArrayOfString str = dfield.addNewValues();
               str.addValue(changeRequestNumber);
               //dfield.setValues(str);
 
               String fafCount = "", changeCategory = "", classification = "", assignment_group = "", implementation_title = "", implementation_des = "" , faf_string="";
               
               RFCRequest rfcRequest = new RFCRequest();
               FAFRequest fafreq = new FAFRequest();
               rfcRequest.setId(rfcReqId);
               
               RFCRequest implDate = rfcRequest;
               //RFCRequest implFAF = rfcRequest;
               implDate = fafreq.getRFCDetails(rfcRequest,SECTION_BASICINFO,RFC_REQ_TYPE_FIREWALL);
               rfcRequest = fafreq.getRFCDetails(rfcRequest,SECTION_CHANGETASK,RFC_REQ_TYPE_FIREWALL);
               //implFAF = fafreq.getRFCDetails(rfcRequest,IMPLEMENTATIONPLAN,RFC_REQ_TYPE_FIREWALL);
               
               rfcRequest.setTiRequest(rfcReq.getTiRequest());
               rfcRequest.setIsIpReg(rfcReq.getIsIpReg());
               rfcRequest.setRfcLocationID(rfcReq.getRfcLocationID());
               rfcRequest.setRequestType(rfcReq.getRequestType());
              
               if(rfcRequest != null){
                     implementation_title = getRFCAnswer(rfcRequest.getImplementationTitle());                       
                     implementation_des = getRFCAnswer(rfcRequest.getImplementationDescription());
                     classification = getRFCAnswer(rfcRequest.getSnowClassification());
                     changeCategory = getRFCAnswer(rfcRequest.getSnowChangeCategory());
                     assignment_group = getRFCAnswer(rfcRequest.getSnowAssignmentGroup());
                     fafCount = getRFCAnswer(rfcRequest.getFafCombinationsCount());
                     //faf_string=displayAnswers(implFAF.getImplementationPlan());
                     faf_string = accessFormTextGenerator.getFirewallAccessFormTextByRFC(rfcRequest);
                     log.debug("ServiceNowMessageImpl :: getServiceNowChangeTaskXml :: accessFormTextGenerator :: "+faf_string);
               }
                     
               DataField dfield2 = dfs.addNewDataField();
               dfield2.setName(TITLE);
               ArrayOfString str2 = dfield2.addNewValues();
               str2.addValue(implementation_title);
               //dfield2.setValues(str2);
               
               DataField dfield3 = dfs.addNewDataField();
               dfield3.setName(DESCRIPTION);
               ArrayOfString str3 = dfield3.addNewValues();
               str3.addValue(implementation_des);
               //dfield3.setValues(str3);
               
               DataField dfield4 = dfs.addNewDataField();
               dfield4.setName(ASSIGNMENT_GROUP);
               ArrayOfString str4 = dfield4.addNewValues();
               str4.addValue(assignment_group);
               //dfield4.setValues(str4);
               
               DataField dfield5 = dfs.addNewDataField();
               dfield5.setName(CHANGE_CATEGORY);
               ArrayOfString str5 = dfield5.addNewValues();
               str5.addValue(changeCategory);
               //dfield5.setValues(str5);
               
               DataFieldGroup dfg2 = dfgs.addNewDataFieldGroup();
               dfg2.setName(NONMADDATORY);
               ArrayOfDataField dfs2 = dfg2.addNewDataFields();
               
               DataField dfield11 = dfs2.addNewDataField();
               dfield11.setName(CLASSIFICATION);
               ArrayOfString str11 = dfield11.addNewValues();
               str11.addValue(classification);
               //dfield11.setValues(str11);
               
               DataField dfield12 = dfs2.addNewDataField();
               dfield12.setName(SEQUENCE);
               ArrayOfString str12 = dfield12.addNewValues();
               str12.addValue(fafCount);
               //dfield12.setValues(str12);
               
               DataField dfield13 = dfs2.addNewDataField();
               dfield13.setName(START_DATE);
               ArrayOfString str13 = dfield13.addNewValues();
               str13.addValue(getRFCAnswer(implDate.getInstallStartDate()));
               //dfield13.setValues(str13);
               
               DataField dfield14 = dfs2.addNewDataField();
               dfield14.setName(END_DATE);
               ArrayOfString str14 = dfield14.addNewValues();
               str14.addValue(getRFCAnswer(implDate.getInstallEndDate()));
               //dfield14.setValues(str14);
               
               DataFieldGroup dfg3 = dfgs.addNewDataFieldGroup();
               dfg3.setName(INSTRUCTION);
               ArrayOfDataField dfs3 = dfg3.addNewDataFields();
               
               DataField dfield21 = dfs3.addNewDataField();
               dfield21.setName(TITLE);
               ArrayOfString str21 = dfield21.addNewValues();
               str21.addValue(getRFCAnswer(implDate.getShortDescription()));
               //dfield21.setValues(str21);
               
               DataField dfield22 = dfs3.addNewDataField();
               dfield22.setName(DESCRIPTION);
               ArrayOfString str22 = dfield22.addNewValues();
               str22.addValue(faf_string);
               //dfield22.setValues(str22);
               
               temp = podDoc.toString();
              /* temp = temp.replaceAll(PURCHASE_OPTION_DES, PURCHASE_OPTION_DES_1);
               temp = temp.replaceAll(PURCHASE_ORDER, "");
               temp = temp.replaceAll(PURCHASE_OPTIONS,"");
               temp = temp.replaceAll(PURCHASE_OPTIONS_END,"");
               temp = temp.replaceAll(PURCHASE_ORDER_END,"");
               temp = temp.trim();
               temp = XML_HEADER + temp;*/
        }catch(Exception e){
			log.error("Error while Preparing RequestXML for ServieNow ChangeTask");
            log.error(e,e);
        }
        log.info("ServiceNowMessageImpl :: getServiceNowChangeTaskXml ends");
        return temp;         
    }

    private String getServiceNowProxyChangeTaskXml(Long tiReqId, Long rfcReqId, String changeRequestNumber, ServiceNowMessageLog snowMessageLog,String CHANGE_TASK_TYPE) {
        String temp = "";
        log.info("ServiceNowMessageImpl :: getServiceNowProxyChangeTaskXml starts");
        try{
			   Session session = getSession();			   
			   RFCRequest rfcReq = (RFCRequest) session.get(RFCRequest.class, rfcReqId);			   
			   PurchaseOptionDescriptionDocument podDoc = PurchaseOptionDescriptionDocument.Factory.newInstance();			
			   PurchaseOptionDescription pod = podDoc.addNewPurchaseOptionDescription();
               
               OrderSystem os = pod.addNewOrderSystem();
               os.setSystemID(SYSTEM_ID);
               
               StringBuffer mappingRef = new StringBuffer();
               mappingRef.append(rfcReqId);
               mappingRef.append("-");
               if(rfcReq.getRfcLocationID() != null){
                     mappingRef.append(rfcReq.getRfcLocationID().getFwLocation());
               }else{
                     mappingRef.append("");
               }
               mappingRef.append("-");
               mappingRef.append(tiReqId);
               mappingRef.append("-");
               mappingRef.append(snowMessageLog.getId());
               
               os.setMappingReference(mappingRef.toString());
               FulfilmentSystem ffs = pod.addNewFulfilmentSystem();
               ffs.setSystemID(SERVICE_NOW);
               FulfilmentItem ffi = pod.addNewFulfilmentItem();
               ffi.setFulfilmentItemName(CT_CREATE);
               DataForm df = ffi.addNewDataForm();
               df.setIsDetached(false);
               
               ArrayOfDataFieldGroup dfgs= df.addNewDataFieldGroups();
               
               DataFieldGroup dfg = dfgs.addNewDataFieldGroup();
               dfg.setName(HEADER);
               
               ArrayOfDataField dfs = dfg.addNewDataFields();
               
               DataField dfield = dfs.addNewDataField();
               dfield.setName(CHANGE_NUMBER);
               ArrayOfString str = dfield.addNewValues();
               str.addValue(changeRequestNumber);
 
               String pafCount = "", changeCategory = "", classification = "", assignment_group = "", implementation_title = "", implementation_des = "" , paf_string="";
               int counter = 0;
               
               RFCRequest rfcRequest = new RFCRequest();
               FAFRequest fafreq = new FAFRequest();
               rfcRequest.setId(rfcReqId);
               
               RFCRequest implDate = rfcRequest;
               implDate = fafreq.getRFCDetails(rfcRequest,SECTION_BASICINFO,RFC_REQ_TYPE_PROXY);
               rfcRequest = fafreq.getRFCDetails(rfcRequest,CHANGE_TASK_TYPE,RFC_REQ_TYPE_PROXY);
               
               rfcRequest.setTiRequest(rfcReq.getTiRequest());
               rfcRequest.setIsIpReg(rfcReq.getIsIpReg());
               rfcRequest.setRfcLocationID(rfcReq.getRfcLocationID());
               rfcRequest.setRequestType(rfcReq.getRequestType());
              
               if(rfcRequest != null){
                     implementation_title = getRFCAnswer(rfcRequest.getImplementationTitle());                       
                     implementation_des = getRFCAnswer(rfcRequest.getImplementationDescription());
                     classification = getRFCAnswer(rfcRequest.getSnowClassification());
                     changeCategory = getRFCAnswer(rfcRequest.getSnowChangeCategory());
                     assignment_group = getRFCAnswer(rfcRequest.getSnowAssignmentGroup());
                     pafCount = getRFCAnswer(rfcRequest.getPafCombinationsCount());
                     paf_string = accessFormTextGenerator.getProxyAccessFormTextByRFC(rfcRequest);
                     log.debug("ServiceNowMessageImpl :: getServiceNowProxyChangeTaskXml :: accessFormTextGenerator :: "+paf_string);
               }
                     
               DataField dfield2 = dfs.addNewDataField();
               dfield2.setName(TITLE);
               ArrayOfString str2 = dfield2.addNewValues();
               str2.addValue(implementation_title);
               
               DataField dfield3 = dfs.addNewDataField();
               dfield3.setName(DESCRIPTION);
               ArrayOfString str3 = dfield3.addNewValues();
               str3.addValue(implementation_des);
               
               DataField dfield4 = dfs.addNewDataField();
               dfield4.setName(ASSIGNMENT_GROUP);
               ArrayOfString str4 = dfield4.addNewValues();
               str4.addValue(assignment_group);
               
               DataField dfield5 = dfs.addNewDataField();
               dfield5.setName(CHANGE_CATEGORY);
               ArrayOfString str5 = dfield5.addNewValues();
               str5.addValue(changeCategory);
               
               DataFieldGroup dfg2 = dfgs.addNewDataFieldGroup();
               dfg2.setName(NONMADDATORY);
               ArrayOfDataField dfs2 = dfg2.addNewDataFields();
               
               DataField dfield11 = dfs2.addNewDataField();
               dfield11.setName(CLASSIFICATION);
               ArrayOfString str11 = dfield11.addNewValues();
               str11.addValue(classification);
               
               DataField dfield12 = dfs2.addNewDataField();
               dfield12.setName(SEQUENCE);
               ArrayOfString str12 = dfield12.addNewValues();
               str12.addValue(pafCount);
               
               DataField dfield13 = dfs2.addNewDataField();
               dfield13.setName(START_DATE);
               ArrayOfString str13 = dfield13.addNewValues();
               str13.addValue(getRFCAnswer(implDate.getInstallStartDate()));
               
               DataField dfield14 = dfs2.addNewDataField();
               dfield14.setName(END_DATE);
               ArrayOfString str14 = dfield14.addNewValues();
               str14.addValue(getRFCAnswer(implDate.getInstallEndDate()));

               if(CHANGE_TASK_TYPE != null && CHANGE_TASK_TYPE.equalsIgnoreCase(SECTION_CHANGETASK_PROXY_PAC_NAM)) {
                   log.debug("ServiceNowMessageImpl :: getServiceNowProxyChangeTaskXml :: SnowChangeTaskDeviceId ");
					counter = 0;
					DataFieldGroup dfgArra[] = null;
					
					ArrayOfDataField arrDFa[] = null;
					
					ArrayOfString arrStra[] = null;
					ArrayOfString arrStr2a[] = null;
					
					DataField dataFlda[] = null;
					DataField dataFld2a[] = null;
					
					if(rfcRequest.getSnowChangeTaskDeviceId() != null){
		                log.debug("ServiceNowMessageImpl :: getServiceNowProxyChangeTaskXml :: getSnowChangeTaskDeviceId ");
						RFCDetail rfcDetail = rfcRequest.getSnowChangeTaskDeviceId();
						List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
						dfgArra = new DataFieldGroup[rfcDtlAnswers.size()];
						arrDFa = new ArrayOfDataField[rfcDtlAnswers.size()];
						arrStra = new ArrayOfString[rfcDtlAnswers.size()];
						arrStr2a = new ArrayOfString[rfcDtlAnswers.size()];
						dataFlda = new DataField[rfcDtlAnswers.size()];
						dataFld2a = new DataField[rfcDtlAnswers.size()];
						if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
							for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
								snowAddDeviceIds(dfgs, rfcAns, "NetInfo_Name",dfgArra[counter],arrDFa[counter],arrStra[counter],arrStr2a[counter],dataFlda[counter],
										dataFld2a[counter],CONFIGITEM,SOURCE,ID);
								counter=counter+1;
							}
						}				
					}	
               }
               if(CHANGE_TASK_TYPE != null && !CHANGE_TASK_TYPE.equalsIgnoreCase(SECTION_CHANGETASK_PROXY_PAC) 
            		   			&& !CHANGE_TASK_TYPE.equalsIgnoreCase(SECTION_CHANGETASK_PROXY_PAC_NAM)){
                   log.debug("ServiceNowMessageImpl :: getServiceNowProxyChangeTaskXml :: adding paf string in task instruction ");
                   
	               DataFieldGroup dfg3 = dfgs.addNewDataFieldGroup();
	               dfg3.setName(INSTRUCTION);
	               ArrayOfDataField dfs3 = dfg3.addNewDataFields();
	               
	               DataField dfield21 = dfs3.addNewDataField();
	               dfield21.setName(TITLE);
	               ArrayOfString str21 = dfield21.addNewValues();
	               str21.addValue(getRFCAnswer(implDate.getShortDescription()));
	               
	               DataField dfield22 = dfs3.addNewDataField();
	               dfield22.setName(DESCRIPTION);
	               ArrayOfString str22 = dfield22.addNewValues();
	               str22.addValue(paf_string);
               }
               
               temp = podDoc.toString();
        }catch(Exception e){
			log.error("ServiceNowMessageImpl :: getServiceNowProxyChangeTaskXml :: Error while Preparing RequestXML for ServieNow ChangeTask");
            log.error(e,e);
        }
        log.info("ServiceNowMessageImpl :: getServiceNowProxyChangeTaskXml ends");
        return temp;         
    }

	private void snowAddDeviceIds(ArrayOfDataFieldGroup dfgs, RFCDetailAnswer rfcDetailsAns, String impacted,DataFieldGroup dfgArr
						,ArrayOfDataField arrDF,ArrayOfString arrStr,ArrayOfString arrStr2,DataField dfld,DataField dfld2,String att1,String att2,String att3){
		
		//log.info("appInstance:-"+rfcDetailsAns.getAnswer());
		dfgArr = dfgs.addNewDataFieldGroup();
		dfgArr.setName(att1);
		arrDF = dfgArr.addNewDataFields();
		
		
		dfld = arrDF.addNewDataField();
		dfld.setName(att2);
		arrStr = dfld.addNewValues();
		arrStr.addValue(impacted);
		//dfield41_2.setValues(str41_2);
		
		dfld2 = arrDF.addNewDataField();
		dfld2.setName(att3);
		arrStr2 = dfld2.addNewValues();
		arrStr2.addValue(rfcDetailsAns.getAnswer());
		//dfield41_app_2.setValues(str41_app_2);
	}

	private String getRFCAnswer(RFCDetail rfcDetail)
    {
		String separator = System.getProperty( "line.separator" );
		
    	if(rfcDetail != null)
    	{
	    	List<RFCDetailAnswer> rda = rfcDetail.getRfcDetailAnswerList();
			RFCDetailAnswer rfcDetailAns = (RFCDetailAnswer)rda.get(0);
			StringBuilder lines = new StringBuilder((rfcDetailAns.getAnswer().replaceAll("\\\\n", separator)).replaceAll("\n", separator));
			return lines.toString();
    	}
    	return "";    	
    }
	
	 public String displayAnswers(RFCDetail rfcDetail)
	    {
		 StringBuilder faf_String = new StringBuilder();
		 String separator = System.getProperty( "line.separator" );
	    	if(rfcDetail!=null)
	    	{
		    	List<RFCDetailAnswer> rda = rfcDetail.getRfcDetailAnswerList();
				for(RFCDetailAnswer ans : rda)
				{
					if(ans.getTemplateKey()!=null)
					{
//							faf_String.append(ans.getTemplateKey().getPositionValue());
//							faf_String.append(". ");
							faf_String.append(ans.getTemplateKey().getDescription());
							faf_String.append("\\n");
							faf_String.append(ans.getAnswer());							
					}else{
						faf_String.append(ans.getAnswer());
					}
				}
	    	}else{
	    		log.info("No record found..");
	    	}
	    	StringBuilder lines = new StringBuilder((faf_String.toString().replaceAll("\\\\n", separator)).replaceAll("\n", separator));
	    	return lines.toString();
	    }

	private String getDateString(){
		SimpleDateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy");
		return dateformat.format(new Date());
	}

	@Override
	public String getServiceNowCTXml(Long tiReqId, Long rfcReqId,
			String changeRequestNumber, ServiceNowMessageLog snowMessageLog) {
		// TODO Auto-generated method stub
		return getServiceNowChangeTaskXml(tiReqId, rfcReqId, changeRequestNumber, snowMessageLog);
	}

	private String getFAFFileName(Long tiRequestID, String snNum) {
        SQLQuery query = getSession().createSQLQuery("select TR.PROCESS_ID,TR.VERSION_NUMBER,cfl.LOCATION,rr.REQUEST_TYPE from ti_request tr join rfc_request rr on rr.ti_request_id=tr.id "+
                    "join con_fw_location cfl on rr.location_id=cfl.id and tr.id="+tiRequestID+ " and rr.rfc_id='"+snNum+ "'");
        query.addScalar("PROCESS_ID", LongType.INSTANCE);
        query.addScalar("VERSION_NUMBER", LongType.INSTANCE);
        query.addScalar("LOCATION", StringType.INSTANCE);
        query.addScalar("REQUEST_TYPE", StringType.INSTANCE);

        List<Object[]> rows = query.list();
        String process_id = "", version_no = "", location ="", rfcrequestType = "", requestType = "";
        if(rows != null){
              for (Object[] obj : rows) {
                    process_id = String.valueOf((Long)obj[0]);
                    version_no = String.valueOf((Long)obj[1]);
                    location =  String.valueOf((String)obj[2]);
                    rfcrequestType =  String.valueOf((String)obj[3]);
                    if(rfcrequestType != null && "D".equalsIgnoreCase(rfcrequestType)){
                    	requestType = "DELETE";
                    }else if(rfcrequestType != null && "M".equalsIgnoreCase(rfcrequestType)){
                    	requestType = "MODIFY";
                    }else{
                    	requestType = "ADD";
                    }
              }
        }
        
        return process_id+"-"+version_no+"-"+location+"-"+requestType+".txt";
	}

	private String getPAFFileName(Long tiRequestID, String snNum) {
        SQLQuery query = getSession().createSQLQuery("select TR.PROCESS_ID,TR.VERSION_NUMBER,cpl.LOCATION from ti_request tr join rfc_request rr on rr.ti_request_id=tr.id "+
                    " join con_proxy_location cpl on rr.proxy_location_id=cpl.id and tr.id="+tiRequestID+" and rr.rfc_id='"+snNum+ "' ");
        query.addScalar("PROCESS_ID", LongType.INSTANCE);
        query.addScalar("VERSION_NUMBER", LongType.INSTANCE);
        query.addScalar("LOCATION", StringType.INSTANCE);

        List<Object[]> rows = query.list();
        String process_id = "", version_no = "", location ="";
        if(rows != null){
              for (Object[] obj : rows) {
                    process_id = String.valueOf((Long)obj[0]);
                    version_no = String.valueOf((Long)obj[1]);
                    location =  String.valueOf((String)obj[2]);
                    //requestType =  "A".equalsIgnoreCase(String.valueOf((String)obj[3]))?"ADD":"DELETE";
              }
        }
        
        return process_id+"-"+version_no+"-"+location+".txt";
	}
	private String getRFCType(Long rfcId) {
		log.info("ServiceNowMessageImpl : getRFCType : Starts");
        SQLQuery query = getSession().createSQLQuery("select rfc_type from rfc_request where id="+rfcId);
        query.addScalar("rfc_type", StringType.INSTANCE);

	    String rfcType = (String) query.uniqueResult();
	   
		log.info("ServiceNowMessageImpl : getRFCType : Ends");
		return rfcType;
	}

	private boolean isProxyPACFILE(Long rfcId) {
		log.info("ServiceNowMessageImpl : isProxyPACFILE : Starts");
		
		StringBuffer queryStr = new StringBuffer();
		queryStr.append(" SELECT distinct PRXINST.RECORD_TYPE RECORD_TYPE ");
		queryStr.append(" FROM rfc_request RFC ");
		queryStr.append(" JOIN TI_REQUEST TIR ON TIR.ID = RFC.TI_REQUEST_ID ");
		queryStr.append(" JOIN con_proxy_location CPL ON CPL.ID = RFC.PROXY_LOCATION_ID ");
		queryStr.append(" JOIN prx_paf_history paf ON PAF.TI_REQUEST_ID = TIR.ID ");
		queryStr.append(" JOIN PRX_INSTANCE_MASTER PRXINST ON PAF.PROXY_INST_MST_ID = PRXINST.ID ");
		queryStr.append(" WHERE PRXINST.record_type = 'PACFILE' ");
		queryStr.append(" and decode(PRXINST.region,'ASIAPAC','ASPAC','MEXICO','LATAM',PRXINST.region) = cpl.location and rfc.id = "+rfcId);
		
        SQLQuery query = getSession().createSQLQuery(queryStr.toString());
        query.addScalar("RECORD_TYPE", StringType.INSTANCE);

        List<String> list = (List<String>)query.list();

		if(list == null || list.isEmpty() || list.size() <= 0){		
			return false;
		}
		else{ 
			return true; 
		}
	}

	private boolean isProxyPACFILENAMRegion(Long rfcId) {
		log.info("ServiceNowMessageImpl : isProxyPACFILE : Starts");
		
		StringBuffer queryStr = new StringBuffer();
		queryStr.append(" SELECT distinct CPL.LOCATION LOCATION ");
		queryStr.append(" FROM rfc_request RFC ");
		queryStr.append(" JOIN TI_REQUEST TIR ON TIR.ID = RFC.TI_REQUEST_ID ");
		queryStr.append(" JOIN con_proxy_location CPL ON CPL.ID = RFC.PROXY_LOCATION_ID ");
		queryStr.append(" JOIN prx_paf_history paf ON PAF.TI_REQUEST_ID = TIR.ID ");
		queryStr.append(" JOIN PRX_INSTANCE_MASTER PRXINST ON PAF.PROXY_INST_MST_ID = PRXINST.ID ");
		queryStr.append(" WHERE PRXINST.record_type = 'PACFILE' and CPL.LOCATION = 'NA' ");
		queryStr.append(" and decode(PRXINST.region,'ASIAPAC','ASPAC','MEXICO','LATAM',PRXINST.region) = cpl.location and rfc.id = "+rfcId);
		
        SQLQuery query = getSession().createSQLQuery(queryStr.toString());
        query.addScalar("LOCATION", StringType.INSTANCE);

        List<String> list = (List<String>)query.list();

		if(list == null || list.isEmpty() || list.size() <= 0){		
			return false;
		}
		else{ 
			return true; 
		}
	}
}