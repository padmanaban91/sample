package com.citigroup.cgti.c3par.webtier.helper;

import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.decisionservice.TiRequestDTO;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;



/**
 * 
 * @author ne36745
 *
 */
public class RiskExecutionThread {

    /** riskExecutionThread */
    private static RiskExecutionThread riskExecutionThread =null;

    /** The firewallRuleProcess. */
    private FireWallRuleProcess firewallRuleProcess;
    
    /**
     * @return the firewallRuleProcess
     */
    public FireWallRuleProcess getFirewallRuleProcess() {
	return firewallRuleProcess;
    }

    /**
     * @param firewallRuleProcess the firewallRuleProcess to set
     */
    public void setFirewallRuleProcess(FireWallRuleProcess firewallRuleProcess) {
	this.firewallRuleProcess = firewallRuleProcess;
    }

    /** The log. */
    private static Logger log = Logger.getLogger(RiskExecutionThread.class);

  
    /**
     * The Class RiskRuleThread.
     */
    private class RiskRuleThread extends Thread {

	/**
	 * 
	 */
	private Long tiRequestId;
	
	/**
	 * 
	 */
	private TiRequestDTO tiRequestDTO;
	
	/*
	 * 
	 */
	private String userId;

	/**
	 * 
	 * @param tiRequestId
	 * @param tiRequestDTO
	 */
	public RiskRuleThread (Long tiRequestId, TiRequestDTO tiRequestDTO, String userId){
	    super();
	    this.tiRequestId=tiRequestId;
	    this.tiRequestDTO = tiRequestDTO;
	    this.userId = userId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	public void run() {
	    try {
		print("Entered in run method for runFAFComputationThread");
		executeRiskForRules(this.tiRequestId, this.tiRequestDTO, this.userId);
		print("Returned in run method for runFAFComputationThread");
	    } catch (InterruptedException ix) {
		print("runFAFComputationThread interrupted!");
	    } catch (Exception x) {
		print("runFAFComputationThread threw an Exception!!!\n" + x);
		log.error(x);
	    }
	}
    }

    /**
     * Start thread.
     *
     * @param request the request
     */
    public synchronized void  startThread(Long tiRequestId, TiRequestDTO tiRequestDTO, String userId){
    	RiskRuleThread riskRuleThread=new RiskRuleThread(tiRequestId, tiRequestDTO, userId);
    	riskRuleThread.start();
    }

  
   /**
    * 
    */
    private RiskExecutionThread() {
	super();
    }

    /**
     * 
     * @return
     */
    public static synchronized RiskExecutionThread getInstance(){
	if(riskExecutionThread ==null){
	    riskExecutionThread =new RiskExecutionThread();
	}
	return riskExecutionThread ;
    }
  

    /**
     * 
     * @param tiRequestId
     * @param tiRequestDTO
     * @throws Exception
     */
    private void executeRiskForRules(Long tiRequestId, TiRequestDTO tiRequestDTO, String userId) throws Exception {
    	firewallRuleProcess = new FireWallRuleProcess();
    	TIRequest tiRequest = new TIRequest();
		tiRequest.setId(tiRequestId);
    	//firewall rules
		List<Long> firewallRuleIds = firewallRuleProcess.rulesExistsWithOlderBaseline(tiRequestId,"N");
		if (firewallRuleIds != null && firewallRuleIds.size() > 0) {
		firewallRuleProcess.updateRiskExecutionStatus(tiRequestId, "P", userId,"firewall");
		for (Long ruleId : firewallRuleIds) {
			firewallRuleProcess.executeRiskRules(ruleId, tiRequest, tiRequestDTO, false, "FWREEXEC");
		}
		firewallRuleProcess.updateRiskExecutionStatus(tiRequestId, "Y", userId,"firewall");
		}
		
		
		//IP Reg rules
		List<Long> iPRegRuleIds = firewallRuleProcess.rulesExistsWithOlderBaseline(tiRequestId,"Y");
		if (iPRegRuleIds != null && iPRegRuleIds.size() > 0) {
			firewallRuleProcess.updateRiskExecutionStatus(tiRequestId, "P", userId,"IPReg");
		for (Long ruleId : iPRegRuleIds) {
			firewallRuleProcess.executeRiskRules(ruleId, tiRequest, tiRequestDTO, false, "IPREEXEC");
		}
		firewallRuleProcess.updateRiskExecutionStatus(tiRequestId, "Y", userId,"IPReg");
		}
		
		Thread.sleep(20000);
		print("Removed "+tiRequestId);
    }

    /**
     * 
     * @param msg
     */
    private static void print(String msg) {
	String name = Thread.currentThread().getName();
	log.debug(name + ": " + msg);
    }

 
}
