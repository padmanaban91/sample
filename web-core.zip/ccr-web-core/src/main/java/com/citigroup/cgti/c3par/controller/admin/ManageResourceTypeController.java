package com.citigroup.cgti.c3par.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.admin.domain.ManageResourceTypeProcess;
import com.citigroup.cgti.c3par.common.domain.ResourceType;

/*
 * @nc43495
 */
@Controller
public class ManageResourceTypeController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(ManageResourceTypeController.class);
	
	/*
	 * The method to load resource type list 
	 */
	@RequestMapping(value = "/loadManageResourceType.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(ModelMap model){
		log.info("ManageResourceTypeController:load starts here..");
		ManageResourceTypeProcess manageResourceType = new ManageResourceTypeProcess();
		List<ResourceType> list = manageResourceType.getResourceType();
		manageResourceType.setResourceTypeList(list);
		model.addAttribute("resTypeList",manageResourceType);
		log.info("ManageResourceTypeController:load ends here..");
		return "c3par.admin.resourceType";
	}
	
	/*
	 * The method to add new resource type
	 */
	@RequestMapping(value = "/addResourceType.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String add(ModelMap model,@ModelAttribute("resTypeList") ManageResourceTypeProcess manageResourceType,HttpServletRequest request,BindingResult result){
		log.info("ManageResourceTypeController:add starts here..");
		//String user = request.getRemoteUser();
		String user = request.getHeader("SM_USER");
		if(manageResourceType.getResType().getName().isEmpty() && manageResourceType.getResType().getName() == null){
			result.addError(new ObjectError("manageResourceType.name",new String[]{"admin.resourceType.name"},null,null));
		}else{
			manageResourceType.addResourceType(manageResourceType.getResType(),user);
		}
		log.info("ManageResourceTypeController:add ends here..");
		return "forward:/loadManageResourceType.act";
	}
	
	/*
	 * The method to update existing resource type
	 */
	@RequestMapping(value = "/updateResourceType.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String update(ModelMap model,@ModelAttribute("resTypeList") ManageResourceTypeProcess manageResourceType,HttpServletRequest request ){
		log.info("ManageResourceTypeController:update starts here..");
		String user = request.getHeader("SM_USER");
		String status=request.getParameter("status");
		String[] selectedID=manageResourceType.getSelectedID();
		for(String id:selectedID){
			manageResourceType.updateResourceType(id,status,user);
			log.debug("selected id's:"+id);
		}
		log.info("ManageResourceTypeController:update ends here..");
		return "forward:/loadManageResourceType.act";
	}
	
	

}
