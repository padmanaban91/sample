package com.citigroup.cgti.c3par.webtier.controller.communication;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.communication.domain.CMPRequestContactXref;
import com.citigroup.cgti.c3par.communication.domain.EcmQueue;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueUsers;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueViewProcess;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetail;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetailAnswer;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.user.domain.C3parUserHierarchyXref;




@Controller
public class EcmQueueViewController {

	
	private static Logger log = Logger.getLogger(EcmQueueViewController.class);

	@RequestMapping(value = "/loadEcmQueueController.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String loadEcmQueueView(ModelMap model, @ModelAttribute("ecmqueueViewProcess") EcmQueueViewProcess ecmqueueViewProcess
									,HttpServletRequest request) {
				log.info("loadECMQueueController::loadECMQueue methods starts...");
			
			    
				List<EcmQueue>  ecmQueue = ecmqueueViewProcess.selectQueueDetails(ecmqueueViewProcess);
				
				ecmqueueViewProcess.setEcmQueue(ecmQueue);
				log.info("ecmQueue size------------->"+ecmQueue.size());
				
				model.addAttribute("ecmqueueViewProcess",ecmqueueViewProcess);
				return "c3par.communication.ecmQueueView";
	} 
	
	

 	@RequestMapping(value = "/selectEcmQueueViewDetail.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String selectEcmQueueView(ModelMap model, @ModelAttribute("ecmqueueViewProcess") EcmQueueViewProcess ecmqueueViewProcess
									,HttpServletRequest request,BindingResult result){ 
				log.info("Entering into selectEcmQueueViewDetail()..");
				
				try{
					String ecmqueueId = (String) request.getParameter("ecmQueueId");
					String ecmqueueName = (String) request.getParameter("ecmQueueName");
					log.debug("ecmqueueId::" + ecmqueueId);
					ecmqueueViewProcess.setEcmQueueId(Long.valueOf(ecmqueueId));
					ecmqueueViewProcess.setEcmQueueName(ecmqueueName);
					ecmqueueViewProcess.setEcmDisplayName(ecmqueueName);
					
					List<Sector>  secList = ecmqueueViewProcess.selectSectorList();
					ecmqueueViewProcess.setSecList(secList);
					
					
					List<Long> selectedSectors =new ArrayList<Long>();
					selectedSectors = ecmqueueViewProcess.selectedEcmSector(Long.valueOf(ecmqueueId));
					log.debug("selectedSectors::" + selectedSectors.size());
					ecmqueueViewProcess.setSelectedSectors(selectedSectors);
					
					log.debug("sector size ::"+ ecmqueueViewProcess.getSecList().size());
					List <EcmQueueUsers> ecmUserRolelist =  ecmqueueViewProcess.ecmUserRoleList(Long.valueOf(ecmqueueId));
					ecmqueueViewProcess.setEcmQueueUsersList(ecmUserRolelist);
					
					
				
					//List <EcmQueueUsers> ecmUserRolelistdata = new ArrayList<EcmQueueUsers>();
					//ecmqueueViewProcess.getEcmQueueUsersList().get(0).getC3parUser().getUserRoleList().get(0).getSecurityRole().getName();
					
					
					log.debug("ecmUserRolelist size ::"+ ecmqueueViewProcess.getEcmQueueUsersList().size());
					
					
					
					
				}catch (Exception e) {
					log.debug("In Exception initialize");
					//log.error(e,e);
					ObjectError error = new ObjectError("name",e.getMessage());
					result.addError(error);
				}
				
				log.debug("ecmqueueViewProcess for edit :: end");
				model.addAttribute("ecmqueueViewProcess",ecmqueueViewProcess);
				
		return "c3par.communication.ecmQueueViewEdit";
	}

 	
	@RequestMapping(value = "/saveEcmQueueViewDetail.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String saveEcmQueueViewDetail(ModelMap model, @ModelAttribute("ecmqueueViewProcess") EcmQueueViewProcess ecmqueueViewProcess
									,HttpServletRequest request,BindingResult result){ 
				log.info("Entering into saveEcmQueueViewDetail()..");
				
				String forwardTo = "redirect:/loadEcmQueueController.act";
				
				try{
					
					String ecmqueueId = (String) request.getParameter("ecmQueueId");
					log.debug("ecmqueueId::" + ecmqueueId);
					ecmqueueViewProcess.setEcmQueueId(Long.valueOf(ecmqueueId));
					ecmqueueViewProcess.updateEcmQueueViewDetails(ecmqueueViewProcess);
					
					
				}catch (Exception e) {
					log.debug("In Exception initialize");
					//log.error(e,e);
					ObjectError error = new ObjectError("name",e.getMessage());
					result.addError(error);
				}
				
				log.debug("ecmqueueViewProcess for save :: end");
				model.addAttribute("ecmqueueViewProcess",ecmqueueViewProcess);
				
		return forwardTo;
	}

		
}
