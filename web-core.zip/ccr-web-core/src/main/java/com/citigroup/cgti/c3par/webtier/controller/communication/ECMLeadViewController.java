package com.citigroup.cgti.c3par.webtier.controller.communication;

import java.sql.Clob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestContactXref;
import com.citigroup.cgti.c3par.communication.domain.CmpConnectionDetail;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.communication.domain.EcmLeadQueue;
import com.citigroup.cgti.c3par.communication.domain.EcmLeadViewProcess;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueUsers;

@Controller
public class ECMLeadViewController {

	private static Logger log = Logger.getLogger(ECMLeadViewController.class);

	@Autowired
	IMailModule mailModuleImpl;

	@RequestMapping(value = "/leadViewController.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadLeadView(
			ModelMap model,
			@ModelAttribute("ecmLeadViewProcess") EcmLeadViewProcess ecmLeadViewProcess,
			HttpServletRequest request) {
		log.info("EcmLeadViewController::loadLeadView methods starts...");
		System.out
				.println("ECMLeadViewController::loadLeadView methods starts...");

		String orderBy = "asc";
		if (null != request.getParameter("orderBy")) {  
			orderBy = (String) request.getParameter("orderBy");
		}
		String sortingColumnName = null;
		if (null != request.getParameter("columnName")) {
			sortingColumnName = (String) request.getParameter("columnName");
			String sortingColumnNameInSession = (String)request.getSession().getAttribute("selectedColumnName");
			log.debug("sortingColumnName.." + sortingColumnName);
			if(sortingColumnName.equalsIgnoreCase(sortingColumnNameInSession))
			{
				ecmLeadViewProcess.setSameColumnSelected("true");
			}
		}
		log.debug("Now iam: " + request.getParameter("type")); 
		if (null != request.getParameter("type")) {
			String actionType = (String) request.getParameter("type");
			log.debug("What action performed.." + actionType);
			if ("L".equals(actionType) || "FI".equals(actionType)
					|| "P".equals(actionType) || "N".equals(actionType)
					|| "LA".equals(actionType)) {
				log.debug("I am from pagination..");
				orderBy = (String) request.getSession().getAttribute("OrderBy");
				sortingColumnName = (String) request.getSession().getAttribute(
						"ColumnName");
			}
		}
		String temp = sortingColumnName;
		request.getSession().setAttribute("selectedColumnName", sortingColumnName);
		sortingColumnName = this.columnNameConversion(sortingColumnName);

		log.debug("sortby:" + orderBy);
		log.debug("columnName:" + sortingColumnName);

		ecmLeadViewProcess.setOrderBy(orderBy);
		ecmLeadViewProcess.setSortingColumnName(sortingColumnName);

		String soeId = request.getHeader("SM_USER");
		log.debug("soeId::loadAgentView::" + soeId);
		ecmLeadViewProcess.setSoeId(soeId.toUpperCase());

		// Pagination

		String type = (String) request.getParameter("type");
		log.debug("loadAgentView::type::" + type);
		int curOffSet = ecmLeadViewProcess.getOffset();
		log.debug("ecmLeadViewProcess.getOffset()::"
				+ ecmLeadViewProcess.getOffset());
		int limit = ecmLeadViewProcess.getLimit();
		log.debug("ecmLeadViewProcess.getLimit()::"
				+ ecmLeadViewProcess.getLimit());
		int pageNo = ecmLeadViewProcess.getPageNo();
		log.debug("ecmLeadViewProcess.getPageNo()::"
				+ ecmLeadViewProcess.getPageNo());

		int recordStartCount = ecmLeadViewProcess.getRecordStartCount();
		log.debug("ecmLeadViewProcess.getRecordStartCount()::"
				+ ecmLeadViewProcess.getRecordStartCount());

		int recordEndCount = ecmLeadViewProcess.getRecordEndCount();
		log.debug("ecmLeadViewProcess.getRecordEndCount()::"
				+ ecmLeadViewProcess.getRecordEndCount());

		int totalRecords = ecmLeadViewProcess.getTotalRecords();
		log.debug("ecmLeadViewProcess.getTotalRecords()::"
				+ ecmLeadViewProcess.getTotalRecords());

		if (ecmLeadViewProcess.getOffset() == 0
				&& ecmLeadViewProcess.getLimit() == 0
				&& ecmLeadViewProcess.getPageNo() == 0) {
			ecmLeadViewProcess.setOffset(0);
			ecmLeadViewProcess.setLimit(20);
			// ecmLeadViewProcess.setPageNo(1);
			ecmLeadViewProcess.setRecordStartCount(1);
			ecmLeadViewProcess.setRecordEndCount(20);
		} else {
			int remainder = (ecmLeadViewProcess.getTotalRecords() % (ecmLeadViewProcess
					.getLimit()));
			if ("N".equalsIgnoreCase(type)) {
				ecmLeadViewProcess.setOffset(curOffSet
						+ ecmLeadViewProcess.getLimit());
				if ((ecmLeadViewProcess.getTotalRecords() <= (ecmLeadViewProcess
						.getRecordEndCount() + ecmLeadViewProcess.getLimit()))) {
					ecmLeadViewProcess.setRecordEndCount(ecmLeadViewProcess
							.getTotalRecords());
				} else {
					ecmLeadViewProcess.setRecordEndCount((ecmLeadViewProcess
							.getRecordEndCount() + ecmLeadViewProcess
							.getLimit()));
				}

				ecmLeadViewProcess.setRecordStartCount(ecmLeadViewProcess
						.getOffset() + 1);
				log.debug("recordEndCount+limit::loadAgentView::"
						+ (ecmLeadViewProcess.getRecordEndCount() + ecmLeadViewProcess
								.getLimit()));
			} else if ("P".equalsIgnoreCase(type)) {
				ecmLeadViewProcess.setOffset(curOffSet
						- ecmLeadViewProcess.getLimit());
				if (ecmLeadViewProcess.getRecordEndCount() == ecmLeadViewProcess
						.getTotalRecords()) {

					if (remainder == 0) {
						ecmLeadViewProcess
								.setRecordEndCount((ecmLeadViewProcess
										.getRecordEndCount() - ecmLeadViewProcess
										.getLimit()));
					} else{
						ecmLeadViewProcess.setRecordEndCount((ecmLeadViewProcess.getRecordEndCount()-remainder ));
        	   		}

				} else {
					ecmLeadViewProcess.setRecordEndCount((ecmLeadViewProcess
							.getRecordEndCount() - ecmLeadViewProcess
							.getLimit()));
				}
				ecmLeadViewProcess.setRecordStartCount(ecmLeadViewProcess
						.getOffset() + 1);
				log.debug("recordEndCount-limit::loadAgentView::"
						+ (ecmLeadViewProcess.getRecordEndCount() - ecmLeadViewProcess
								.getLimit()));
			} else if ("L".equalsIgnoreCase(type)) {
				ecmLeadViewProcess.setOffset(0);
				ecmLeadViewProcess.setRecordStartCount(1);
				if ((ecmLeadViewProcess.getTotalRecords() <= (ecmLeadViewProcess
						.getLimit()))) {
					ecmLeadViewProcess.setRecordEndCount(ecmLeadViewProcess
							.getTotalRecords());
				} else {
					ecmLeadViewProcess.setRecordEndCount(ecmLeadViewProcess
							.getLimit());
				}
				ecmLeadViewProcess.setLimit(ecmLeadViewProcess.getLimit());
			} else if ("FI".equalsIgnoreCase(type)) {
				log.debug("insie FI");
				ecmLeadViewProcess.setOffset(0);
				ecmLeadViewProcess.setRecordStartCount(1);
				if ((ecmLeadViewProcess.getTotalRecords() <= ecmLeadViewProcess
						.getLimit())) {
					ecmLeadViewProcess.setRecordEndCount(ecmLeadViewProcess
							.getTotalRecords());
				} else {
					ecmLeadViewProcess.setRecordEndCount(ecmLeadViewProcess
							.getLimit());
				}
			} else if ("LA".equalsIgnoreCase(type)) {
				log.debug("insie LA");

				log.debug("remainder::" + remainder);
				if (remainder == 0) {
					log.debug("inside reminder if equal to 0");

					ecmLeadViewProcess.setRecordStartCount(ecmLeadViewProcess
							.getTotalRecords()
							- ecmLeadViewProcess.getLimit()
							+ 1);
					ecmLeadViewProcess.setRecordEndCount(ecmLeadViewProcess
							.getTotalRecords());
					ecmLeadViewProcess.setOffset((ecmLeadViewProcess
							.getTotalRecords())
							- ((ecmLeadViewProcess.getLimit())));
				}
				if (remainder >= 1) {
					log.debug("inside reminder if greater than 1");

					ecmLeadViewProcess.setRecordStartCount((ecmLeadViewProcess
							.getTotalRecords()) - (remainder - 1));
					ecmLeadViewProcess.setRecordEndCount(ecmLeadViewProcess
							.getTotalRecords());
					ecmLeadViewProcess.setOffset((ecmLeadViewProcess
							.getTotalRecords()) - (remainder));
				}
			} else {
				ecmLeadViewProcess.setOffset(0);
				ecmLeadViewProcess.setPageNo(1);
			}
		}

		if (request.getParameter("errMsg") != null) {
			ecmLeadViewProcess.setErrorMessage("Invalid CCR ID");
		}
		if(request.getParameter("cmpId") != null && !request.getParameter("cmpId").trim().isEmpty()){			
			ecmLeadViewProcess.setErrorMessage("Ecm Agent cannot be assigned due to invalid user.");
		}

		log.debug("loadAgentView::limit::" + limit);
		List<CMPRequest> resolveITMessage = ecmLeadViewProcess
				.selectLeadDetails(ecmLeadViewProcess,ecmLeadViewProcess.getSectorId());
		ecmLeadViewProcess.setResolveITMessage(resolveITMessage);
		  
		ecmLeadViewProcess.setCmpSectorList(ecmLeadViewProcess.loadCmpSectorList());
		if(null != resolveITMessage) {
            log.info("resolveITMessage size------------->"
                            + resolveITMessage.size());
    }
     else {
            log.info("resolveITMessage size------------->NULL");
    }
		 if(ecmLeadViewProcess.getResolveITMessage()!=null && ecmLeadViewProcess.getResolveITMessage().size() <= 0)
			{
		    	
			 ecmLeadViewProcess.setRecordStartCount(0); 
			 ecmLeadViewProcess.setRecordEndCount(0);
			 ecmLeadViewProcess.setTotalRecords(0);
			}
		    if(ecmLeadViewProcess.getResolveITMessage()!=null && ecmLeadViewProcess.getResolveITMessage().size() > 0 && type == null || type == "" )
		    {
		    	
		    	if(ecmLeadViewProcess.getResolveITMessage().size() <= ecmLeadViewProcess.getLimit() )
		    	{
		    		ecmLeadViewProcess.setRecordEndCount(ecmLeadViewProcess.getResolveITMessage().size());
		    }}



		request.setAttribute("orderBy", ecmLeadViewProcess.getOrderBy());

		request.getSession().setAttribute("OrderBy",
				ecmLeadViewProcess.getOrderBy());
		request.getSession().setAttribute("ColumnName",
				ecmLeadViewProcess.getSortingColumnName());
		request.getSession().setAttribute("SelectedColumnName",temp);

		ecmLeadViewProcess.setAssignedUserArr(null);
		ecmLeadViewProcess.setSelectedColumnName(temp);
		
		ecmLeadViewProcess.setUrgencyList(ecmLeadViewProcess
				.loadGenericLookupByName("SLO_Days"));
		model.addAttribute("ecmLeadViewProcess", ecmLeadViewProcess);
		model.addAttribute("SelectedColumnName", temp); 
		log.debug("Selected column::"+temp);
		return getAgentList(model, ecmLeadViewProcess, request);

	} 
 
	@RequestMapping(value = "/searchEcmUsersListController.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String searchInEcmUsers(
			ModelMap model,
			@ModelAttribute("ecmLeadViewProcess") EcmLeadViewProcess ecmLeadViewProcess,
			HttpServletRequest request) {
		log.info("EcmLeadViewController::searchInEcmUsers methods starts...");

		return "c3pAr.communication.ecmLeadView";
	}

	@RequestMapping(value = "/saveAssignedUser.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String saveAssignedUsers(
			ModelMap model,
			@ModelAttribute("ecmLeadViewProcess") EcmLeadViewProcess ecmLeadViewProcess,
			HttpServletRequest request) {
		log.info("Entering into saveAssignedUsers()..");

		String forwardTo = "redirect:/leadViewController.act";

		String cmpReqId = (String) request.getParameter("cmpReqId");
		log.debug("cmpReqId::" + cmpReqId);
		String[] cmpReqIdArray = cmpReqId.split(",");

		String assignedTo = (String) request.getParameter("assignedTo");
		log.debug("assignedTo::" + assignedTo);
		String[] assignedToArray = assignedTo.split(",");

		String sloDays = (String) request.getParameter("sloVal");
		log.debug("sloDays::" + sloDays);
		String[] sloDaysArray = sloDays.split(",");
		log.debug("sloDaysArray::" + sloDaysArray);
		
		String leadComments = (String) request.getParameter("commentsVal");
		log.debug("leadComments::" + leadComments);
		String[] commentsValArray = leadComments.split(",");
		log.debug("commentsValArray::" + commentsValArray);

		String userId = request.getHeader("SM_USER");

		boolean isUpdated = false;
		
		boolean validUser = false;
		String cmpId="";
		
		for (int i = 0; i < cmpReqIdArray.length; i++) {			
			if(assignedToArray[i] != null && !assignedToArray[i].trim().isEmpty() ){
				validUser = ecmLeadViewProcess.checkValidUser(assignedToArray[i]);
				log.info("validUser:: "+validUser);						
				if(!validUser){
					if(cmpId.isEmpty())
						cmpId = cmpReqIdArray[i];
					else
						cmpId =","+cmpReqIdArray[i];
				}
			}
		}
		log.info("validUser::cmpId "+cmpId);		
		if(cmpId.isEmpty()){
			for (int i = 0; i < cmpReqIdArray.length; i++) {			
				if(assignedToArray[i] != null && !assignedToArray[i].trim().isEmpty() ){
								isUpdated = ecmLeadViewProcess.updateAssignedEcmUser(
										cmpReqIdArray[i], assignedToArray[i],
										Long.parseLong(sloDaysArray[i]), userId,commentsValArray[i]);
					
								log.debug("saveAssignedUsers :: Controller ::citi contact info by Assign Cotacts sso Id ::"
										+ assignedToArray[i]);
								log.debug("isUpdated:" + isUpdated);
								if (isUpdated) {
									this.sendEmailNotificationToAgent(cmpReqIdArray[i],
											assignedToArray[i], userId, ecmLeadViewProcess);
								}
					}
	
				}
		}
		log.info("cmpId:: "+cmpId);		
		log.info("Exit from saveAssignedUsers()..");
		return "redirect:/leadViewController.act?cmpId="+cmpId;
	}

	private String columnNameConversion(String inputStr) {

		log.debug("The inputStr: " + inputStr);

		String result = "assignedUser";

		if ("DATE ACTIVE".equals(inputStr)) {

			result = "availableDate";
		} else if ("REQUEST TYPE".equals(inputStr)) {

			result = "typeofConnectivityInvolved";
		} else if ("REGION".equals(inputStr)) {

			result = "region";
		} else if ("SECTOR".equals(inputStr)) {

			result = "projectSector";
		}

		return result;
	}

	@RequestMapping(value = "/showConnDetail.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String showConnectionDetails(
			ModelMap model,
			@ModelAttribute("ecmLeadViewProcess") EcmLeadViewProcess ecmLeadViewProcess,
			HttpServletRequest request) {
		log.info("CmpConnectionDetailController::getCmpConnectionDetails method starts");
		String connectionId = request.getParameter("ccrId");
		log.info("connectionId:: " + connectionId);

		String bpmForward = "show_Detail";
		String fun_code = "showDetail";
		String bpmActivityId = "";
		String phase = null;
		String taskCode = null;
		String participantId = null;
		Long id = null;
		String ssoId = (String) request.getHeader("SM_USER");

		// CmpConnectionDetail cmpConnectionDetail = new CmpConnectionDetail();
		List<CmpConnectionDetail> processList = ecmLeadViewProcess
				.getProcessList(connectionId);

		if (processList != null && processList.size() > 0) {
			for (CmpConnectionDetail processDetail : processList) {
				id = processDetail.getTirequestid();
				phase = processDetail.getPhase();
				taskCode = processDetail.getTaskCode();
				bpmActivityId = processDetail.getBpmActivityId();
				participantId = processDetail.getParticipant();

			}
		}
		if (id != null) {
			return "forward:/bpmIntegrationAction.act?fun_code=showDetail&tireqid="
					+ id
					+ "&PHASE="
					+ phase
					+ "&forward=show_Detail&taskCodeId="
					+ taskCode
					+ "&tiRequestId="
					+ id
					+ "&ssoId="
					+ ssoId
					+ "&bpmActivityId="
					+ bpmActivityId
					+ "&participantId="
					+ participantId + "&ecmView=true";
		} else {
			return "forward:/leadViewController.act?errMsg=true";
		}

	}

	@RequestMapping(value = "/getAgentList.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String getAgentList(
			ModelMap model,
			@ModelAttribute("ecmLeadViewProcess") EcmLeadViewProcess ecmLeadViewProcess,
			HttpServletRequest request) {
		log.debug("inside list method of lead queue");
		String soeId = request.getHeader("SM_USER");
		String teamQueueSectorId = ecmLeadViewProcess.getTeamQueueSectorId();
		log.debug("teamQueueSectorId "+teamQueueSectorId);
		List<String> queueName = new ArrayList<String>();
		List<EcmQueueUsers> ecmQueueUsers=ecmLeadViewProcess.retrieveC3parUser(soeId).getEcmQueueUsersList();
		if(ecmQueueUsers!=null && ecmQueueUsers.size()>0){
			for(EcmQueueUsers ecmQueueUser : ecmQueueUsers){
				queueName.add(ecmQueueUser.getEcmQueue().getQueueName());
			}
		}
		ecmLeadViewProcess.setQueueName(queueName);
		ecmLeadViewProcess.setLeadId(soeId);
		List<EcmLeadQueue> completeTeamQueueList =  ecmLeadViewProcess.getAgentListForSector(soeId);
		if(completeTeamQueueList.size()>0){
			StringBuffer sb=new StringBuffer("'");
			for(EcmLeadQueue ecmLeadQueue:completeTeamQueueList){
				sb.append(ecmLeadQueue.getAgentID()+"', '");
			}
			String str=sb.toString();
			str=str.substring(0,str.length()-3);
			completeTeamQueueList=removeSupportTeamMembers(completeTeamQueueList,ecmLeadViewProcess,str);
		}
			List<String> ecmSectorList = new ArrayList<String>();
	
			List<EcmLeadQueue> sectorBasedteamQueueList = new ArrayList<EcmLeadQueue>();
			boolean isSelectorSelected = false;
	        for(EcmLeadQueue ecmLeadQueue:completeTeamQueueList)
	
	        {
	                if(!ecmSectorList.contains(ecmLeadQueue.getSector()))
	                        ecmSectorList.add(ecmLeadQueue.getSector());
	                
	               if(ecmLeadQueue.getSector().equalsIgnoreCase(teamQueueSectorId))
	               {
	            	   sectorBasedteamQueueList.add(ecmLeadQueue);
	            	   isSelectorSelected = true;
	               }
	        }
	        ecmLeadViewProcess.setTeamQueueSectorList(ecmSectorList);
	        if(isSelectorSelected)
	        {
	        	ecmLeadViewProcess.setTeamQueue(sectorBasedteamQueueList);
	        }
	        else
	        {
	        	ecmLeadViewProcess.setTeamQueue(completeTeamQueueList);
	        }

		ecmLeadViewProcess.setDateForLeadQueue(ecmLeadViewProcess
				.getdateForHeader());
		ecmLeadViewProcess.setComments(null);
		model.addAttribute("ecmLeadViewProcess", ecmLeadViewProcess);
		return "c3pAr.communication.ecmLeadView";
	}

	private List<EcmLeadQueue> removeSupportTeamMembers(List<EcmLeadQueue> completeTeamQueueList,
			EcmLeadViewProcess ecmLeadViewProcess, String str) {
		List<String> supportUserslist=ecmLeadViewProcess.getSupportTeamUsersList(str);
		List<EcmLeadQueue> finalTeamQueueList=new ArrayList<EcmLeadQueue>();
		if(supportUserslist.size()>0){
			for(EcmLeadQueue ecmLeadQueue:completeTeamQueueList){
				if(!supportUserslist.contains(ecmLeadQueue.getAgentID())){
					finalTeamQueueList.add(ecmLeadQueue);
				}
			}
		}
		else{
			finalTeamQueueList=completeTeamQueueList;
		}
		return finalTeamQueueList;
	}

	@RequestMapping(value = "/addToDoNotAssign.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String addToDoNotAssign(
			ModelMap model,
			@ModelAttribute("ecmLeadViewProcess") EcmLeadViewProcess ecmLeadViewProcess,
			HttpServletRequest request) {
		log.debug("inside list method of lead queue");
		String soeId = request.getHeader("SM_USER");
		log.debug("soeid" + soeId);
		ecmLeadViewProcess.setLeadId(soeId);
		ecmLeadViewProcess.addAgentToDoNotAssign(ecmLeadViewProcess);
		model.addAttribute("ecmLeadViewProcess", ecmLeadViewProcess);
		return "forward:/leadViewController.act";
	}

	private CMPRequest getCMPRequestDetails(String cmpReqId,
			EcmLeadViewProcess ecmLeadViewProcess) {

		log.debug("The cmpReqId: " + cmpReqId);
		return ecmLeadViewProcess.getCMPRequestDetails(cmpReqId);

	}

	private void sendEmailNotificationToAgent(String cmpReqId, String AssignTo,
			String userId, EcmLeadViewProcess ecmLeadViewProcess) {

		log.debug("Entering into sendEmailNotificationToAgent()...");

		CmpRequestDTO dto = new CmpRequestDTO();

		String mailTemplateName = "REQ_ASSIGNED_TO_ECM_AGENT";

		CitiContact citiContact = ecmLeadViewProcess
				.getCitiContactDetails(AssignTo);
		
		 

		// Agent Info
		dto.setAgentName(citiContact.getFirstName() + " "
				+ citiContact.getLastName());
		dto.setAgentEmail(citiContact.getEmail());
		dto.setAgentPhone(citiContact.getPhone());
		dto.setToAddresses(citiContact.getEmail());

		citiContact = ecmLeadViewProcess.getCitiContactDetails(userId);

		// Lead Info
		dto.setLeadName(citiContact.getFirstName() + " "
				+ citiContact.getLastName());
		dto.setLeadEmail(citiContact.getEmail());
		dto.setLeadPhone(citiContact.getPhone());
		dto.setSsoId(citiContact.getSsoId());
		 

		CMPRequest cmpRequest = this.getCMPRequestDetails(cmpReqId,
				ecmLeadViewProcess);

		CmpRequestDTO cmpRequestDTO = this.convertToDTO(cmpRequest, dto);

		mailModuleImpl.sendEcmEmailViewGeneration(mailTemplateName,
				cmpRequestDTO);

		log.debug("Exit frm sendEmailNotificationToAgent()...");

	}

	private CmpRequestDTO convertToDTO(CMPRequest cmpRequest, CmpRequestDTO dto)  {
		
		StringBuilder ccAddress = new StringBuilder("");		

		dto.setCmpId(cmpRequest.getOrderItemId());
		dto.setOrderId(cmpRequest.getOrderId());
		dto.setStep(cmpRequest.getTypeofConnectivityInvolved() + ": "
				+ cmpRequest.getRequestType());
		dto.setOrderBy(cmpRequest.getOrderByUser());
		dto.setOrderFor(cmpRequest.getOrderForUser());
		dto.setLoggedDate(this.dateFormatChange(cmpRequest.getAvailableDate()));
		dto.setDueDate(this.dateFormatChange(this.findDueDate(
				cmpRequest.getUpdateAssignedUserDate(), cmpRequest.getSloDays())));
		dto.setBj(cmpRequest.getBusinessjustification());
		dto.setCmpRequestId(cmpRequest.getId());
		
		if (cmpRequest != null && cmpRequest.getCmpRequestNotes() != null) {
			if (cmpRequest.getCmpRequestNotes().get(0).getNewNotes() != null) {
				Clob clob = cmpRequest.getCmpRequestNotes().get(0).getNewNotes();
				String wholeClob;
				try {
					wholeClob = clob.getSubString(1, (int) clob.length());
					dto.setLeadComments(wholeClob);
				} catch (Exception e) {
					log.error("Exception occurred while converting the clob into string : " + e.toString());
					log.error(e.toString(), e);
				}
			}
		}
		
		
		if (ccAddress.length() < 1) {
			 ccAddress.append(dto.getLeadEmail());
			} else {
			ccAddress.append("; "+ dto.getLeadEmail());
		}
		
		for (CMPRequestContactXref cmpRequestContactXref : cmpRequest
				.getCmpRequestContactXrefs()) {
			String role = cmpRequestContactXref.getRole().getName();
			if(role != null && role.length() > 0 && cmpRequestContactXref.getCiticontact() != null){
			
				if ("Requestor".equalsIgnoreCase(role)) {					
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				}else if ("Business_Owner".equalsIgnoreCase(role)) {					
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else if ("Sec_Business_Owner".equalsIgnoreCase(role)) {					
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else if ("BISO".equalsIgnoreCase(role)) {					
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				} else {
					if (ccAddress.length() < 1) {
						ccAddress.append(cmpRequestContactXref.getCiticontact()
								.getEmail());
					} else {
						ccAddress
								.append("; "
										+ cmpRequestContactXref.getCiticontact()
												.getEmail());
					}
				}
			}
		}
		log.debug("The CC address list in ECMLeadViewController is "+ccAddress.toString()); 
		dto.setCcAddresses(ccAddress.toString());
		return dto;
	}

	private Date findDueDate(Date assignedDate, Long SLODays) {

		Date dueDate = null;

		log.debug("The assignedDate:" + assignedDate + " and SLODays:"
				+ SLODays.intValue());

		if (assignedDate != null && SLODays != null) {

			try {

				Calendar calendar = Calendar.getInstance();
				calendar.setTime(assignedDate);

				for (int i = 0; i < SLODays.intValue(); i++) {

					calendar.add(Calendar.DATE, 1);
					if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
							|| Calendar.DAY_OF_WEEK == Calendar.SUNDAY) {
						calendar.add(Calendar.DATE, 2);
					}
				}

				dueDate = calendar.getTime();

			} catch (Exception ex) {
				log.error(ex.getMessage());
			}

		}

		return dueDate;
	}

	private Date dateFormatChange(Date inputDate) {

		Date fomattedDate = null;

		try {

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

			if (inputDate != null) {

				fomattedDate = sdf.parse(sdf.format(inputDate));
			}

		} catch (Exception ex) {
			log.error(ex.getMessage());
		}

		return fomattedDate;

	}

}
