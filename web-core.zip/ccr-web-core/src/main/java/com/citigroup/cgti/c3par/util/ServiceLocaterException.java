/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.util;


/**
 * The Class ServiceLocaterException.
 *
 * @author pkadam
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ServiceLocaterException extends Exception {

    /**
     * Instantiates a new service locater exception.
     */
    public ServiceLocaterException() {
	super();
	// TODO Auto-generated constructor stub
    }

    /**
     * Instantiates a new service locater exception.
     *
     * @param arg0 the arg0
     */
    public ServiceLocaterException(String arg0) {
	super(arg0);
	// TODO Auto-generated constructor stub
    }

    /**
     * Instantiates a new service locater exception.
     *
     * @param arg0 the arg0
     * @param arg1 the arg1
     */
    public ServiceLocaterException(String arg0, Throwable arg1) {
	super(arg0, arg1);
	// TODO Auto-generated constructor stub
    }

    /**
     * Instantiates a new service locater exception.
     *
     * @param arg0 the arg0
     */
    public ServiceLocaterException(Throwable arg0) {
	super(arg0);
	// TODO Auto-generated constructor stub
    }
}
