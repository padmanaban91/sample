package com.citigroup.cgti.c3par.dashboard.webtier.helper;

import java.sql.ResultSet;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.citigroup.cgti.c3par.dao.BusinessUnitDAO;
import com.citigroup.cgti.c3par.model.BusinessUnitEntity;
import com.citigroup.cgti.c3par.webtier.helper.FieldValidator;
import com.mentisys.dao.AccessObject;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;
import com.mentisys.model.ManyAssociationList;


/**
 * The Class SearchBusinessUnit.
 */
public class SearchBusinessUnit extends AccessObject 
{

    /** The user id. */
    private Long userId;

    /**
     * Instantiates a new search business unit.
     *
     * @param session the session
     * @param rsession the rsession
     */
    public SearchBusinessUnit(DatabaseSession session, HttpSession rsession)
    {
	super(session);
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#loadModelReferences(java.lang.Object)
     */
    protected void loadModelReferences(Object obj)
    throws DatabaseException 
    {}

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#createModel(java.sql.ResultSet)
     */
    protected Object createModel(ResultSet rs)
    throws DatabaseException 
    {
	BusinessUnitEntity buEntity = new BusinessUnitEntity();
	buEntity.setReferencesLoaded(false);
	buEntity.setId(getLongFromResultSet(rs, BusinessUnitDAO.COLUMN_ID));
	buEntity.setPrimaryKey(buEntity.getId());
	buEntity.setBusinessName(getStringFromResultSet(rs, BusinessUnitDAO.COLUMN_BUSINESSNAME));
	buEntity.setCostCenter(getStringFromResultSet(rs, BusinessUnitDAO.COLUMN_COSTCENTER));
	buEntity.setDescription(getStringFromResultSet(rs, BusinessUnitDAO.COLUMN_DESCRIPTION));
	buEntity.setSector(CommonCode.getSector(getLongFromResultSet(rs, BusinessUnitDAO.COLUMN_SECTOR_ID)));
	return buEntity;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString() 
    {
	String stmt = null;

	stmt = "SELECT DISTINCT  "
	    + getQualifiedColumnName(BusinessUnitDAO.TABLE, BusinessUnitDAO.COLUMN_ID, true)
	    + getQualifiedColumnName(BusinessUnitDAO.TABLE, BusinessUnitDAO.COLUMN_BUSINESSNAME, true)
	    + getQualifiedColumnName(BusinessUnitDAO.TABLE, BusinessUnitDAO.COLUMN_COSTCENTER, true)
	    + getQualifiedColumnName(BusinessUnitDAO.TABLE, BusinessUnitDAO.COLUMN_DESCRIPTION, true)
	    + getQualifiedColumnName(BusinessUnitDAO.TABLE, BusinessUnitDAO.COLUMN_SECTOR_ID, false);

	stmt = stmt + getFromClause(new String[]{BusinessUnitDAO.TABLE});

	return stmt;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getWhereExpression(com.mentisys.dao.query.Condition)
     */
    protected String getWhereExpression(Condition c) 
    {
	StringBuffer buf = new StringBuffer();
	buf.append(c.getWhereExpression());
	return buf.toString();
    }


    /**
     * Run query.
     *
     * @param businessUnitName the business unit name
     * @param userId the user id
     * @param sectorId the sector id
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List runQuery(String businessUnitName, Long userId, Long sectorId)
    throws DatabaseException 
    {
	Condition condition = new Condition();

	if(businessUnitName != null)
	{
	    if (FieldValidator.isValidString(businessUnitName.trim())) {
		OperatorExpression businessUnitNameLike = 
		    new OperatorExpression(BusinessUnitDAO.COLUMN_BUSINESSNAME, Operator.LIKE, businessUnitName.trim());
		condition.addExpression(businessUnitNameLike);
	    }
	}

	if (sectorId != null) {
	    OperatorExpression sectorIdExp = 
		new OperatorExpression(BusinessUnitDAO.COLUMN_SECTOR_ID, Operator.EQUAL, sectorId);
	    condition.addExpression(sectorIdExp);
	}

	this.userId = userId;

	condition.addOrderByField("UPPER(" + BusinessUnitDAO.COLUMN_BUSINESSNAME+ ")");
	return query(condition, false);		
    }

    /**
     * Gets the location.
     *
     * @param buId the bu id
     * @param session the session
     * @return the location
     * @throws DatabaseException the database exception
     */
    public static List getLocation(Long buId, DatabaseSession session)
    throws DatabaseException
    {
	BusinessUnitDAO dao = new BusinessUnitDAO(session);
	BusinessUnitEntity buEntity = dao.get(buId);

	return buEntity.getLocation();
    }

    /**
     * Gets the contact.
     *
     * @param buId the bu id
     * @param session the session
     * @return the contact
     * @throws DatabaseException the database exception
     */
    public static List getContact(Long buId, DatabaseSession session)
    throws DatabaseException
    {
	BusinessUnitDAO dao = new BusinessUnitDAO(session);
	BusinessUnitEntity buEntity = dao.get(buId);
	if ((buEntity == null) || (buEntity.getCitiContact() == null)) return (new ManyAssociationList());
	return buEntity.getCitiContact();
    }

}
