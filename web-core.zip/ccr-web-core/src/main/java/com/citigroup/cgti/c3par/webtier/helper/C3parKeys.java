/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  [2002-2003] Mentisys, Inc.  All rights reserved.
 * The contents of this material are confidential and proprietary to
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.webtier.helper;


/**
 * The Class C3parKeys.
 *
 * @author mnrao
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class C3parKeys 
{

    /** The Constant CONNECTION_STATUS_IN_COMPLETE. */
    public static final String CONNECTION_STATUS_IN_COMPLETE="In Complete";
}
