package com.citigroup.cgti.c3par.fw.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.type.StringType;

import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleDestinationIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleSourceIP;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRulePolicy;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.Port;
import com.citigroup.cgti.c3par.fw.service.SubnetUtils.SubnetInfo;
 
/**
 * 
 * @author ne36745
 *
 */
public class FirewallRuleValidator {
	 /** The log. */
    private static Logger log = Logger
	    .getLogger(FirewallRuleValidator.class);
    
    /*
       	Validating IPs and Ports
		Formatting IPs and Ports
		Check Duplicates inside list of Source IPs
		Check Duplicates inside list of Dest IPs
		Check Duplicates inside list of Source IPs/Dest IPs
		Check Duplicates inside list of Ports
		Check whether Rule Modified or not
		Validate the IP with Network Zone
		Check Duplicate Rule within TIrequest
		Check - IP cannot exists with two different network zones
     */

    private Session session;
    
    private Pattern pattern;
    private Matcher matcher;
    
    //To validate 
    private Set<String> portSet = new HashSet<String>();
    private Set<Long> policySet = new HashSet<Long>();
    private Set<Long> numericIPs = new HashSet<Long>();
    
    private List<IpPortContainer> sourceIPList = new ArrayList<IpPortContainer>();
    private List<IpPortContainer> destIPList = new ArrayList<IpPortContainer>();
    private Set<String> portServiceSet = new HashSet<String>();
    
    private StringBuffer errorMessages = new StringBuffer();
    
    private List<String> validationErrors = new ArrayList<String>();
    
    private List<IpPortContainer> ipList = new ArrayList<IpPortContainer>();
    
    private HashMap<Long, Long> tpaSubnetMap = new HashMap<Long, Long>();
    private HashMap<Long, Long> ofacSubnetMap = new HashMap<Long, Long>();
    
    private static final String IPADDRESS_PATTERN_SINGLE = 
		"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
    
    private static final String IPADDRESS_PATTERN_RANGE = 
		"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])"+
		"\\-"+
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
    
    private static final String IPADDRESS_PATTERN_SUBNET = 
    	"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])"+
		"\\/"+
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
 
    private static final String PORT_PATTERN = "^[0-9]+$";
    private static final String PORT_RANGE_PATTERN = "^([0-9]+)\\-([0-9]+)$";
    
 
   /**
	 * @return the errorMessages
	 */
	public StringBuffer getErrorMessages() {
		return errorMessages;
	}


	/**
	 * @param errorMessages the errorMessages to set
	 */
	public void setErrorMessages(StringBuffer errorMessages) {
		this.errorMessages = errorMessages;
	}

	/**
	 * @return the validationErrors
	 */
	public List<String> getValidationErrors() {
		return validationErrors;
	}


	/**
	 * @param validationErrors the validationErrors to set
	 */
	public void setValidationErrors(List<String> validationErrors) {
		this.validationErrors = validationErrors;
	}

	
	/**
	 * @return the session
	 */
	public Session getSession() {
		return session;
	}


	/**
	 * @param session the session to set
	 */
	public void setSession(Session session) {
		this.session = session;
	}



	private String addToIPContainerList(Long ipAddress, Long NAT, String IPAddress) {
		for (IpPortContainer ipPortContainer : ipList) {
			if (IpPortContainer.SINGLE.equals(ipPortContainer.getType()) 
					&& ipPortContainer.getSingle().equals(ipAddress)
					&& ipPortContainer.getNat().equals(NAT)) {
				return ipPortContainer.getIpAddress();
			}
			if (IpPortContainer.RANGE.equals(ipPortContainer.getType()) 
					&& ipPortContainer.getStart().longValue() <= ipAddress.longValue() 
					&& ipPortContainer.getEnd().longValue() >= ipAddress.longValue()) {
				return ipPortContainer.getIpAddress();
			}
		}
		IpPortContainer container = new IpPortContainer();
		container.setSingle(ipAddress);
		container.setNat(NAT);
		container.setType(IpPortContainer.SINGLE);
		container.setIpAddress(IPAddress);
		ipList.add(container);
		return null;
	}
	
	private String addToIPContainerList(Long start, Long end, Long NAT, String IPAddress) {
		for (IpPortContainer ipPortContainer : ipList) {
			if (IpPortContainer.SINGLE.equals(ipPortContainer.getType()) 
					&& start.longValue() <= ipPortContainer.getSingle().longValue() 
					&& end.longValue() >= ipPortContainer.getSingle().longValue()
					&& ipPortContainer.getNat().equals(NAT)) {
				return ipPortContainer.getIpAddress();
			}
			if (IpPortContainer.RANGE.equals(ipPortContainer.getType()) 
					&& ((start.longValue() <= ipPortContainer.getStart().longValue() 
					&& end.longValue() >= ipPortContainer.getStart().longValue()
					&& ipPortContainer.getNat().equals(NAT)) ||
					(start.longValue() <= ipPortContainer.getEnd().longValue() 
					&& end.longValue() >= ipPortContainer.getEnd().longValue()
					&& ipPortContainer.getNat().equals(NAT)))) {
				return ipPortContainer.getIpAddress();
			}
		}
		IpPortContainer container = new IpPortContainer();
		container.setStart(start);
		container.setEnd(end);
		container.setNat(NAT);
		container.setType(IpPortContainer.RANGE);
		container.setIpAddress(IPAddress);
		ipList.add(container);
		return null;
	}
	
	/*private boolean addToIPContainerList(String object) {
		for (IpPortContainer ipPortContainer : ipList) {
			if (IpPortContainer.OBJECT.equals(ipPortContainer.getType()) 
					&& ipPortContainer.getObject().equals(object)) {
				return false;
			}
		}
		IpPortContainer container = new IpPortContainer();
		container.setObject(object);
		container.setType(IpPortContainer.OBJECT);
		ipList.add(container);
		return true;
	}*/
	
	private boolean checkNetworkZone(Long ipAddress, Long nwZone) {
		for (IpPortContainer ipPortContainer : ipList) {
			if (IpPortContainer.SINGLE.equals(ipPortContainer.getType()) 
					&& ipPortContainer.getSingle().equals(ipAddress) && !nwZone.equals(ipPortContainer.getNwZone())) {
				return true;
			}
			if (IpPortContainer.RANGE.equals(ipPortContainer.getType()) 
					&& ipPortContainer.getStart().longValue() <= ipAddress.longValue() 
					&& ipPortContainer.getEnd().longValue() >= ipAddress.longValue() 
					&& !nwZone.equals(ipPortContainer.getNwZone())) {
				return true;
			}
		}
		return false;
	}
	
	private boolean checkNetworkZone(Long start, Long end, Long nwZone) {
		for (IpPortContainer ipPortContainer : ipList) {
			if (IpPortContainer.SINGLE.equals(ipPortContainer.getType()) 
					&& start.longValue() <= ipPortContainer.getSingle().longValue() 
					&& end.longValue() >= ipPortContainer.getSingle().longValue()
					 && !nwZone.equals(ipPortContainer.getNwZone())) {
				return true;
			}
			if (IpPortContainer.RANGE.equals(ipPortContainer.getType()) 
					&& ((start.longValue() <= ipPortContainer.getStart().longValue() 
					&& end.longValue() >= ipPortContainer.getStart().longValue()) ||
					(start.longValue() <= ipPortContainer.getEnd().longValue() 
							&& end.longValue() >= ipPortContainer.getEnd().longValue()))
							 && !nwZone.equals(ipPortContainer.getNwZone())) {
				return true;
			}
		}
		return false;
	}
	
	/*private boolean checkNetworkZone(String object, Long nwZone) {
		for (IpPortContainer ipPortContainer : ipList) {
			if (IpPortContainer.OBJECT.equals(ipPortContainer.getType()) 
					&& ipPortContainer.getObject().equals(object) && !nwZone.equals(ipPortContainer.getNwZone())) {
				return true;
			}
		}
		return false;
	}*/
	
	
	/**
    * Validate ip address with regular expression
    * @param ip ip address for validation
    * @return true valid ip address, false invalid ip address
    */
    public boolean validateIP(final String ip){
      if (ip.indexOf("-") != -1) {
    	  pattern = Pattern.compile(IPADDRESS_PATTERN_RANGE);
      } else if (ip.indexOf("/") != -1) {
    	  pattern = Pattern.compile(IPADDRESS_PATTERN_SUBNET);
      } else {
    	  pattern = Pattern.compile(IPADDRESS_PATTERN_SINGLE);
      }
	  matcher = pattern.matcher(ip);
	  return matcher.matches();	    	    
    }
    
    /**
     * Validate ip address with regular expression
     * @param ip ip address for validation
     * @return true valid ip address, false invalid ip address
     */
     public boolean isANYIPorPort(final String ip){
       return (ip.equalsIgnoreCase("*") || ip.equalsIgnoreCase("ANY"));
     }
    
    
     /**
     * Gets the formatted ip.
     *
     * @param ip the ip
     * @return the formatted ip
     */
    public String getFormattedIP(String ip){

		StringTokenizer ipTokenizer = new StringTokenizer(ip,".");
		String formattedIP = "";
	
		while (ipTokenizer.hasMoreTokens()) {
	
		    formattedIP = formattedIP + ".";
		    formattedIP = formattedIP + getPaddedNumber((String)ipTokenizer.nextToken());
		}
	
		return formattedIP.substring(1);
    }
    
    /**
     * Gets the padded number.
     *
     * @param nonpaddednumber the nonpaddednumber
     * @return the padded number
     */
    public String getPaddedNumber(String nonpaddednumber){
		String paddedNumber = "";
		if(nonpaddednumber != null && !nonpaddednumber.equals("")){
		    switch(nonpaddednumber.length()){
		    case 1:
			paddedNumber = "00" + nonpaddednumber;
			break;
	
		    case 2:
			paddedNumber = "0" + nonpaddednumber;
			break;
	
		    case 3:
			paddedNumber = nonpaddednumber;
			break;
	
		    default:
			break;
	
		    }
		}
	
		return paddedNumber;
    }
    
    /**
     * Check ip. Added for #10494
     * will have to move to Util 
     * @param sip the sip
     * @return true, if successful
     */

    public static boolean checkIp(String sip) {
		if(sip==null | "".equals(sip))
		    return false;
		String[] parts = sip.split("\\.");
		for (String s : parts) {
		    int i = 0;
		    try {
			i = Integer.parseInt(s);
		    } catch (NumberFormatException e) {
			return false;
	
		    }
		    if (i < 0 || i > 255) {
			return false;
		    }
		}
		return true;
    }
    
    public void getTPASubnetMaster() {
    	Session session = getSession();
    	
    	List<SubnetInfo> subnetInfoList = new ArrayList<SubnetInfo>();
    	
		SQLQuery query = session.createSQLQuery("select ip_address from ti_tpa_subnet_master " +
				"where is_active = 'Y'");
		query.addScalar("ip_address", StringType.INSTANCE);
		List<String> subnetList = (List<String>)query.list();
		SubnetUtils subnetUtils = null;
		if (subnetList!= null && !subnetList.isEmpty()) {
			for (String subnet : subnetList) {
				if (subnet != null && subnet.indexOf("/") != -1) 	{
					try {
			    		//Subnet Calculation
			    		subnetUtils = new SubnetUtils(subnet.trim());
			    		subnetInfoList.add(subnetUtils.getInfo());
		    		} catch(IllegalArgumentException e) {
		    		}
	    	 	} else if (subnet != null) {
	    	 		Long start = convertIPaddressToInteger(subnet.trim());
	        		Long end = convertIPaddressToInteger(subnet.trim());
	        		tpaSubnetMap.put(start, end);
	    	 	}
			}
		}
		log.debug("tpaSubnetMap---->"+tpaSubnetMap);
		log.debug("subnetInfoList---->"+subnetInfoList);
		if (subnetInfoList != null && !subnetInfoList.isEmpty()) {
    		for (SubnetInfo subnetInfo : subnetInfoList) {
    			Long start = convertIPaddressToInteger(subnetInfo.getLowAddress());
        		Long end = convertIPaddressToInteger(subnetInfo.getHighAddress());
        		tpaSubnetMap.put(start, end);
    		}
    	}
		log.debug("tpaSubnetMap---->"+tpaSubnetMap);
    }
    public void getOfacSubnetMaster() {
    	Session session = getSession();
    	
    	List<SubnetInfo> subnetInfoList = new ArrayList<SubnetInfo>();
    	
		SQLQuery query = session.createSQLQuery("select ip_address from TI_OFAC_SUBNET_MASTER " +
				"where is_active = 'Y'");//query needs to cahnge
		query.addScalar("ip_address", StringType.INSTANCE);
		List<String> subnetList = (List<String>)query.list();
		SubnetUtils subnetUtils = null;
		if (subnetList!= null && !subnetList.isEmpty()) {
			for (String subnet : subnetList) {
				if (subnet != null && subnet.indexOf("/") != -1) 	{
					try {
			    		//Subnet Calculation
			    		subnetUtils = new SubnetUtils(subnet.trim());
			    		subnetInfoList.add(subnetUtils.getInfo());
		    		} catch(IllegalArgumentException e) {
		    		}
	    	 	} else if (subnet != null) {
	    	 		Long start = convertIPaddressToInteger(subnet.trim());
	        		Long end = convertIPaddressToInteger(subnet.trim());
	        		ofacSubnetMap.put(start, end);
	    	 	}
			}
		}
		log.debug("ofacSubnetMap---->"+ofacSubnetMap);
		log.debug("subnetInfoList---->"+subnetInfoList);
		if (subnetInfoList != null && !subnetInfoList.isEmpty()) {
    		for (SubnetInfo subnetInfo : subnetInfoList) {
    			Long start = convertIPaddressToInteger(subnetInfo.getLowAddress());
        		Long end = convertIPaddressToInteger(subnetInfo.getHighAddress());
        		ofacSubnetMap.put(start, end);
    		}
    	}
		log.debug("tpaSubnetMap---->"+tpaSubnetMap);
    }
    
    
    
    private boolean isTPA(Long ipAddress)  {
    	if (tpaSubnetMap != null) {
	    	Set<Entry<Long,Long>>  entrySetMap = tpaSubnetMap.entrySet();
	    	
	    	for (Entry<Long,Long> entry : entrySetMap) {
	    		if (entry.getKey().longValue() <= ipAddress.longValue()
	    				&& entry.getValue().longValue() >= ipAddress.longValue()) {
	    			return true;
	    		}
	    	}
    	}
    	return false;
    }
    
    private boolean isTPA(Long start, Long end)  {
    	if (tpaSubnetMap != null) {
	    	Set<Entry<Long,Long>>  entrySetMap = tpaSubnetMap.entrySet();
	    	
	    	for (Entry<Long,Long> entry : entrySetMap) {
	    		if ((entry.getKey().longValue() <= start.longValue()
	    				&& entry.getValue().longValue() >= start.longValue())
	    				|| (entry.getKey().longValue() <= end.longValue()
	    	    				&& entry.getValue().longValue() >= end.longValue())) {
	    			return true;
	    		}
	    	}
    	}
    	return false;
    }
    private boolean isOFAC(Long ipAddress)  {
    	if (ofacSubnetMap != null) {
	    	Set<Entry<Long,Long>>  entrySetMap = ofacSubnetMap.entrySet();
	    	
	    	for (Entry<Long,Long> entry : entrySetMap) {
	    		if (entry.getKey().longValue() <= ipAddress.longValue()
	    				&& entry.getValue().longValue() >= ipAddress.longValue()) {
	    			return true;
	    		}
	    	}
    	}
    	return false;
    }
    
    private boolean isOFAC(Long start, Long end)  {
    	if (ofacSubnetMap != null) {
	    	Set<Entry<Long,Long>>  entrySetMap = ofacSubnetMap.entrySet();
	    	
	    	for (Entry<Long,Long> entry : entrySetMap) {
	    		if ((entry.getKey().longValue() <= start.longValue()
	    				&& entry.getValue().longValue() >= start.longValue())
	    				|| (entry.getKey().longValue() <= end.longValue()
	    	    				&& entry.getValue().longValue() >= end.longValue())) {
	    			return true;
	    		}
	    	}
    	}
    	return false;
    }
    
    
    public IPAddress formatIPAddress(IPAddress ipAddress) throws BusinessException {
    	log.debug("formatIPAddress "+ ipAddress.getIpAddress());
    	if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
    		log.debug("formatIPAddress Subnet Calculation"+ ipAddress.getIpAddress());
    		SubnetUtils subnetUtils = null;
    		try {
    		//Subnet Calculation
    		subnetUtils = new SubnetUtils(ipAddress.getIpAddress());
    		} catch(IllegalArgumentException e) {
    			validationErrors.add(e.getMessage());
    			return ipAddress;
    		}
    		ipAddress.setFormattedIP(getFormattedIP(subnetUtils.getInfo().getAddress())
    				+ipAddress.getIpAddress().substring(ipAddress.getIpAddress().indexOf("/")));//ipAddress
    		ipAddress.setNoOfHost(subnetUtils.getInfo().getAddressCount());//noofhost
    		ipAddress.setBroadCastAddress(subnetUtils.getInfo().getBroadcastAddress());//broadcast
    		ipAddress.setEndIP(subnetUtils.getInfo().getHighAddress());//End
    		ipAddress.setStartIP(subnetUtils.getInfo().getLowAddress());//Start
    		ipAddress.setFormattedEndIP(getFormattedIP(subnetUtils.getInfo().getHighAddress()));//End
    		ipAddress.setFormattedStartIP(getFormattedIP(subnetUtils.getInfo().getLowAddress()));//Start
    		ipAddress.setSubnet(subnetUtils.getInfo().getNetmask()); //subnet
    	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
    		log.debug("formatIPAddress IP Range"+ ipAddress.getIpAddress());
    		//IP Range
    		String ipRange[] = ipAddress.getIpAddress().split("-");
    		String startIP = ipRange[0];
    		String endIP = ipRange[1];
    		String formattedStartIP = getFormattedIP(startIP);
    		String formattedEndIP = getFormattedIP(endIP);
    		ipAddress.setFormattedIP(formattedStartIP+"-"+formattedEndIP);
    		ipAddress.setStartIP(startIP);
    		ipAddress.setFormattedStartIP(formattedStartIP);
    		ipAddress.setEndIP(formattedEndIP);
    		ipAddress.setFormattedEndIP(formattedEndIP);
    		
    		Long start = convertIPaddressToInteger(startIP);
    		Long end = convertIPaddressToInteger(endIP);
    		
    		ipAddress.setNoOfHost((end.intValue()-start.intValue()));
    	} else if (ipAddress.getIpAddress() != null) {
    		log.debug("formatIPAddress Single IP"+ ipAddress.getIpAddress());
    		//Single IP
    		ipAddress.setFormattedIP(getFormattedIP(ipAddress.getIpAddress()));
    		
    	}
    	return ipAddress;
    }
    
    /*
     * To Validate and Format the IP Address
     * Subnet Calculation
     * IP Range
     */
    /**
     * 
     * @param ipAddress
     * @return
     */
    public IPAddress validateAndFormatIPAddress(IPAddress ipAddress, String NAT, String broadAccessIP) throws BusinessException {
    	    
    	log.debug("validateAndFormatIPAddress "+ ipAddress.getIpAddress());
    	if ("Y".equalsIgnoreCase(ipAddress.getTemplateFlag())) {
    		/*if (!addToIPContainerList(ipAddress.getIpAddress())) {
    			log.debug("There is a duplicate IP Object found - "
	    			   +ipAddress.getIpAddress());
    			validationErrors.add("There is a duplicate IP Object found - "
	    			    +ipAddress.getIpAddress());
    			return ipAddress;
    		}*/
    		return ipAddress;
    	} else if (!validateIP(ipAddress.getIpAddress())) {
    		if (isANYIPorPort(ipAddress.getIpAddress())) {
    			ipAddress.setIpAddress(broadAccessIP);
    			ipAddress.setAnyIP("Y");
    		} else  {
	    		log.debug("This IP Address - "
	    			    + ipAddress.getIpAddress() + " is not valid");
	    		validationErrors.add("This IP Address - "
	    			    + ipAddress.getIpAddress() + " is not valid");
	    		return ipAddress;
    		}
    	}    	
    	Long NATvalue = 0L;
    	
    	if (NAT != null && validateIP(NAT)) {
    		NATvalue = convertIPaddressToInteger(NAT);
    	}
    	
    	if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
    		log.debug("validateAndFormatIPAddress Subnet Calculation"+ ipAddress.getIpAddress());
    		SubnetUtils subnetUtils = null;
    		try {
    		//Subnet Calculation
    		subnetUtils = new SubnetUtils(ipAddress.getIpAddress());
    		if (subnetUtils != null && subnetUtils.getInfo() != null && !subnetUtils.getInfo().getAddress().equals(subnetUtils.getInfo().getNetworkAddress())) {
    			log.debug(ipAddress.getIpAddress()+" is not a valid Subnet IP Address. The valid Subnet IP Address is " + subnetUtils.getInfo().getNetworkAddress() + "/"+ ipAddress.getIpAddress().split("/")[1]);
    			validationErrors.add(ipAddress.getIpAddress()+" is not a valid Subnet IP Address. The valid Subnet IP Address is " + subnetUtils.getInfo().getNetworkAddress() + "/"+ ipAddress.getIpAddress().split("/")[1]);
    			return ipAddress;
    		 }
    		} catch(IllegalArgumentException e) {
    			validationErrors.add(e.getMessage());
    			return ipAddress;
    		}
    		ipAddress.setFormattedIP(getFormattedIP(subnetUtils.getInfo().getAddress())
    				+ipAddress.getIpAddress().substring(ipAddress.getIpAddress().indexOf("/")));//ipAddress
    		ipAddress.setNoOfHost(subnetUtils.getInfo().getAddressCount());//noofhost
    		ipAddress.setBroadCastAddress(subnetUtils.getInfo().getBroadcastAddress());//broadcast
    		ipAddress.setEndIP(subnetUtils.getInfo().getHighAddress());//End
    		ipAddress.setStartIP(subnetUtils.getInfo().getLowAddress());//Start
    		ipAddress.setFormattedEndIP(getFormattedIP(subnetUtils.getInfo().getHighAddress()));//End
    		ipAddress.setFormattedStartIP(getFormattedIP(subnetUtils.getInfo().getLowAddress()));//Start
    		ipAddress.setSubnet(subnetUtils.getInfo().getNetmask()); //subnet
    		
    		Long start = convertIPaddressToInteger(subnetUtils.getInfo().getLowAddress());
    		Long end = convertIPaddressToInteger(subnetUtils.getInfo().getHighAddress());
    		
    		if (isTPA(start,end)) {
    			ipAddress.setTpaFlag("Y");
    			ipAddress.setOfacFlag("N");
    		} else {
    			if(isOFAC(start, end)){
    				ipAddress.setOfacFlag("Y");
    			}
    			else{
    				ipAddress.setOfacFlag("N");
    			}
    			ipAddress.setTpaFlag("N");
    		}
    		
    		//for (Long i = start; i<=end; i++) {
    		String res = addToIPContainerList(start, end,NATvalue,ipAddress.getIpAddress());
			if (res != null) {
				log.debug("There is a duplicate IP Address - "+res
	    			    + " found from the IP Range -"+ipAddress.getIpAddress());
				validationErrors.add("There is a duplicate IP Address "+res
	    			    + " found from the IP Range -"+ipAddress.getIpAddress());
				return ipAddress;
			}
    		//}
    		
    	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
    		log.debug("validateAndFormatIPAddress IP Range"+ ipAddress.getIpAddress());
    		//IP Range
    		String ipRange[] = ipAddress.getIpAddress().split("-");
    		String startIP = ipRange[0];
    		String endIP = ipRange[1];
    		String formattedStartIP = getFormattedIP(startIP);
    		String formattedEndIP = getFormattedIP(endIP);
    		ipAddress.setFormattedIP(formattedStartIP+"-"+formattedEndIP);
    		ipAddress.setStartIP(startIP);
    		ipAddress.setFormattedStartIP(formattedStartIP);
    		ipAddress.setEndIP(formattedEndIP);
    		ipAddress.setFormattedEndIP(formattedEndIP);
    		
    		Long start = convertIPaddressToInteger(startIP);
    		Long end = convertIPaddressToInteger(endIP);
    		
    		ipAddress.setNoOfHost((end.intValue()-start.intValue())+1);
    		
    		if (isTPA(start,end)) {
    			ipAddress.setTpaFlag("Y");
    		} else {
    			if(isOFAC(start, end)){
    				ipAddress.setOfacFlag("Y");
    			}
    			else{
    				ipAddress.setOfacFlag("N");
    			}
    			ipAddress.setTpaFlag("N");
    		}
    		
    		if (end <= start) {
    			log.debug("This is not a Valid IP Range - "+ipAddress.getIpAddress());
    			validationErrors.add("This is not a Valid IP Range - "+ipAddress.getIpAddress());
    			return ipAddress;
    		}
    		
    		//for (Long i = start; i<=end; i++) {
    		String res = addToIPContainerList(start, end,NATvalue,ipAddress.getIpAddress());
    			if (res != null) {
    				log.debug("There is a duplicate IP Address - "+res
    	    			    + " found from the IP Range -"+ipAddress.getIpAddress());
    				validationErrors.add("There is a duplicate IP Address "+res
    	    			    + " found from the IP Range -"+ipAddress.getIpAddress());
    				return ipAddress;
    			}
    		//}
    	} else if (ipAddress.getIpAddress() != null) {
    		log.debug("validateAndFormatIPAddress Single IP"+ ipAddress.getIpAddress());
    		
    		if (isTPA(convertIPaddressToInteger(ipAddress.getIpAddress()))) {
    			ipAddress.setTpaFlag("Y");
    		} else {
    			if(isOFAC(convertIPaddressToInteger(ipAddress.getIpAddress()))){
    				ipAddress.setOfacFlag("Y");
    			}
    			else{
    				ipAddress.setOfacFlag("N");
    			}
    			ipAddress.setTpaFlag("N");
    		}
    		
    		//Single IP
    		ipAddress.setFormattedIP(getFormattedIP(ipAddress.getIpAddress()));
    		String res = addToIPContainerList(convertIPaddressToInteger(ipAddress.getIpAddress()),NATvalue,ipAddress.getIpAddress());
			if (res != null) {
				log.debug("There is a duplicate IP Address - "+res
	    			    + " found from the IP Range -"+ipAddress.getIpAddress());
				validationErrors.add("There is a duplicate IP Address "+res
	    			    + " found from the IP Range -"+ipAddress.getIpAddress());
				return ipAddress;
			}
    	}
    	log.debug("validateAndFormatIPAddress numeric IPs "+numericIPs);
    	return ipAddress;
    }
    
    /*
     * To Validate NAT IP
     */
    /**
     * 
     * @param ipAddress
     * @return
     */
    public void validateNATIP(String natIP) {
    	    
    	log.debug("validateNATIP "+ natIP);
    	if (natIP!= null && !natIP.isEmpty()) {
	    	if (!validateIP(natIP)) {
	    		log.debug("This NAT IP Address - "
	    			    + natIP + " is not valid");
	    		validationErrors.add("This NAT IP Address - "
	    			    + natIP + " is not valid");
	    	}
    	}
    }

    public void validateIPRegSourceIP(IPAddress ipAddress) {    	
    	log.debug("validateIPRegSourceIP==>"+ ipAddress.getIpAddress());
    	Session session = getSession(); 
    	String ipAddressStr = "";
    	if(ipAddress!= null && ipAddress.getIpAddress() != null){
    		ipAddressStr = ipAddress.getIpAddress().trim();
    	}
    	SQLQuery query = session.createSQLQuery("select acl from ip_acl_assignment_master " +
    			"where acl = '" +ipAddressStr+ "'");

		query.addScalar("acl", StringType.INSTANCE);
		List<String> accessType = (List<String>)query.list();
		
		if(accessType == null || accessType.isEmpty() || accessType.size() <= 0){		
			validationErrors.add("Please select an IP Reg ACL by double clicking the Source IP textbox");
		}
    }
    
    /*
     * To Validate the port number
     * Port Range
     */
    /**
     * 
     * @param port
     * @throws BusinessException
     */
    public Port validatePort(Port port) throws BusinessException {
    	
    	if ((port.getProtocol().equalsIgnoreCase("TCP")
    			|| port.getProtocol().equalsIgnoreCase("UDP"))) {
    		String portString = null;
    		if (!IsPort(port.getPortNumber())) {
    			if (isANYIPorPort(port.getPortNumber())) {
    				port.setPortNumber("1-65535");
        		} else  {
        			log.debug("Port Number - "
    	    			    + port.getPortNumber() + " is not valid");
    	    		validationErrors.add("Port Number - "
    	    			    + port.getPortNumber() + " is not valid");
    	    		return port;
        		}
    		}
    		String portNumber = port.getPortNumber();
    		if (portNumber.indexOf("-") != -1) {
    			String[] portRange = portNumber.split("-");
    			Long startPort = Long.valueOf(portRange[0]);
    			Long endPort = Long.valueOf(portRange[1]);
    			port.setPortCount((endPort - startPort)+1);
    			if (endPort <= startPort) {
    				log.debug("This is not a valid Port Range - "+ portNumber);
    				validationErrors.add("This is not a valid Port Range - "+ portNumber);
    				return port;
    			}
    			for (Long i=startPort; i<=endPort;i++) {
    				portString = port.getProtocol()+i.toString();
    				if (!portSet.add(portString)) {
    		    		log.debug("There is a duplicate Port - "
    		    			    + port.getProtocol()+" - "+port.getPortNumber() + " found");
    		    		validationErrors.add("There is a duplicate Port - "
    		    			    + port.getProtocol()+" - "+port.getPortNumber() + " found");
    		    		return port;
    		    	}
    			}
    		} else {
    			portString = port.getProtocol()+port.getPortNumber();
    			if (!portSet.add(portString)) {
    	    		log.debug("There is a duplicate Port - "
    	    			    + port.getProtocol()+" - "+port.getPortNumber() + " found");
    	    		validationErrors.add("There is a duplicate Port - "
    	    			    + port.getProtocol()+" - "+port.getPortNumber() + " found");
    	    		return port;
    	    	}
    		}
    		
    	} else if(port.getProtocol().equalsIgnoreCase("ICMP")) {
    		String portString = null;
    		portString =port.getProtocol()+port.getControlMsgId();
    		if (!portSet.add(portString)) {
        		log.debug("There is a duplicate Port - "
        			    + port.getProtocol()+" - "+port.getPortNumber() + " found");
        		validationErrors.add("There is a duplicate Port - "
        			    + port.getProtocol()+" - "+port.getPortNumber() + " found");
        		return port;
        	}
    	} else {
    		String portString = null;
    		portString = port.getProtocol()+port.getPortNumber();
    		if (!portSet.add(portString)) {
        		log.debug("There is a duplicate Port - "
        			    + port.getProtocol()+" - "+port.getPortNumber() + " found");
        		validationErrors.add("There is a duplicate Port - "
        			    + port.getProtocol()+" - "+port.getPortNumber() + " found");
        		return port;
        	}
    	}
    	log.debug("validatePort Portset "+portSet);
    	return port;
    }
    
    /*
     * To Validate the Policy
     */
    /**
     * 
     * @param port
     * @throws BusinessException
     */
    public void validatePolicies(FirewallPolicy firewallPolicy) throws BusinessException {
    	
    	
    	if (firewallPolicy != null && firewallPolicy.getId() != null && firewallPolicy.getId().longValue() > 0) {
    		if (!policySet.add(firewallPolicy.getId())) {
        		log.debug("There is a duplicate Firewall Policy - "
        			    + firewallPolicy.getName()+" - found");
        		validationErrors.add("There is a duplicate Firewall Policy - "
        			    + firewallPolicy.getName()+" - found");
        	}
    	}
    		
    	log.debug("validatePolicies policySet "+policySet);
    }
    
    /*
     * The same IP cannot exists with two different network zones in the different rules in the TIRequest
     */
    /**
     * 
     * @param fireWallRule
     * @throws BusinessException
     */
    public void validateNetworkZonesWithIP(FireWallRule fireWallRule, Long currentRuleId) throws BusinessException {
    	Long srcNWZone = null;
        Long dstNWZone = null;
        String srcNWZoneName = null;
        String dstNWZoneName = null;
        
        if (fireWallRule.getSourceNetworkZone() != null) {
        	srcNWZone = fireWallRule.getSourceNetworkZone().getId();
        	srcNWZoneName = fireWallRule.getSourceNetworkZone().getName();
        }
        if (fireWallRule.getDestinationNetworkZone() != null) {
        	dstNWZone = fireWallRule.getDestinationNetworkZone().getId();
        	dstNWZoneName = fireWallRule.getDestinationNetworkZone().getName();
        }
        
        List<FireWallRuleSourceIP> sourceIPs = fireWallRule.getSourceIPs();
    	if (sourceIPs != null && !sourceIPs.isEmpty()) {
    	    for (FireWallRuleSourceIP fireWallRuleSourceIP : sourceIPs) {
    	    	if (fireWallRuleSourceIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleSourceIP.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRuleSourceIP.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
    	    	if (fireWallRuleSourceIP.getIpAddress() != null && "Y".equalsIgnoreCase(fireWallRuleSourceIP.getIpAddress().getTemplateFlag())) {
    	    		/*if (checkNetworkZone(fireWallRuleSourceIP.getIpAddress().getIpAddress(), srcNWZone)) {
    	    			validationErrors.add("This IP Object - "+fireWallRuleSourceIP.getIpAddress().getIpAddress()+
        						" already exists in Rule Number - "+fireWallRule.getRuleNumber()+
        						" with Different Network Zone - "+srcNWZoneName);
    	    		}*/
     	    	} else if (fireWallRuleSourceIP.getIpAddress() != null && fireWallRuleSourceIP.getIpAddress().getFormattedIP() != null) {
    	    		IPAddress ipAddress = fireWallRuleSourceIP.getIpAddress();
    	    		if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
    	        		log.debug("validateNetworkZonesWithIP Subnet Calculation"+ ipAddress.getIpAddress());
    	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
    	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
    	        		//for (Long i = start; i<=end; i++) {
    	        			if (checkNetworkZone(start,end,srcNWZone)) {
    	        				validationErrors.add("This IP Address - "+fireWallRuleSourceIP.getIpAddress().getIpAddress()+
    	        						" already exists in Rule Number - "+fireWallRule.getRuleNumber()+
    	        						" with Different Network Zone - "+srcNWZoneName);
    	        			}
    	        		//}
    	        	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
    	        		log.debug("validateNetworkZonesWithIP IP Range"+ ipAddress.getIpAddress());
    	        		//IP Range
    	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
    	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
    	        		//for (Long i = start; i<=end; i++) {
    	        		if (checkNetworkZone(start,end,srcNWZone)) {
    	        				validationErrors.add("This IP Address - "+fireWallRuleSourceIP.getIpAddress().getIpAddress()+
    	        						" already exists in Rule Number - "+fireWallRule.getRuleNumber()+
    	        						" with Different Network Zone - "+srcNWZoneName);
    	        			}
    	        		//}
    	        	} else if (ipAddress.getIpAddress() != null) {
    	        		log.debug("validateNetworkZonesWithIP Single IP"+ ipAddress.getIpAddress());
    	        		//Single IP
    	        		Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
    	        		if (checkNetworkZone(convIP,srcNWZone)) {
	        				validationErrors.add("This IP Address - "+fireWallRuleSourceIP.getIpAddress().getIpAddress()+
	        						" already exists in Rule Number - "+fireWallRule.getRuleNumber()+
	        						" with Different Network Zone - "+srcNWZoneName);
	        			}
    	        	}
    	    	}
    	    }
    	}
    	
    	
    	List<FireWallRuleDestinationIP> destinationIPs = fireWallRule
		.getDestinationIPs();
    	if (destinationIPs != null && !destinationIPs.isEmpty()) {
    	    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : destinationIPs) {
    	    	if (fireWallRuleDestinationIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
    	    	if (fireWallRuleDestinationIP.getIpAddress() != null && "Y".equalsIgnoreCase(fireWallRuleDestinationIP.getIpAddress().getTemplateFlag())) {
    	    		/*if (checkNetworkZone(fireWallRuleDestinationIP.getIpAddress().getIpAddress(), dstNWZone)) {
    	    			validationErrors.add("This IP Object - "+fireWallRuleDestinationIP.getIpAddress().getIpAddress()+
        						" already exists in Rule Number - "+fireWallRule.getRuleNumber()+
        						" with Different Network Zone - "+dstNWZoneName);
    	    		}*/
     	    	} else if (fireWallRuleDestinationIP.getIpAddress() != null && fireWallRuleDestinationIP.getIpAddress().getFormattedIP() != null) {
    	    		IPAddress ipAddress = fireWallRuleDestinationIP.getIpAddress();
    	    		if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
    	        		log.debug("validateNetworkZonesWithIP Subnet Calculation"+ ipAddress.getIpAddress());
    	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
    	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
    	        		//for (Long i = start; i<=end; i++) {
    	        		if (checkNetworkZone(start,end,dstNWZone)) {
    	        				validationErrors.add("This IP Address - "+fireWallRuleDestinationIP.getIpAddress().getIpAddress()+
    	        						" already exists in Rule Number - "+fireWallRule.getRuleNumber()+
    	        						" with Different Network Zone - "+dstNWZoneName);
    	        			}
    	        		//}
    	        	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
    	        		log.debug("validateNetworkZonesWithIP IP Range"+ ipAddress.getIpAddress());
    	        		//IP Range
    	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
    	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
    	        		//for (Long i = start; i<=end; i++) {
    	        		if (checkNetworkZone(start,end,dstNWZone)) {
    	        				validationErrors.add("This IP Address - "+fireWallRuleDestinationIP.getIpAddress().getIpAddress()+
    	        						" already exists in Rule Number - "+fireWallRule.getRuleNumber()+
    	        						" with Different Network Zone - "+dstNWZoneName);
    	        			}
    	        		//}
    	        	} else if (ipAddress.getIpAddress() != null) {
    	        		log.debug("validateNetworkZonesWithIP Single IP"+ ipAddress.getIpAddress());
    	        		//Single IP
    	        		Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
    	        		if (checkNetworkZone(convIP,dstNWZone)) {
	        				validationErrors.add("This IP Address - "+fireWallRuleDestinationIP.getIpAddress().getIpAddress()+
	        						" already exists in Rule Number - "+fireWallRule.getRuleNumber()+
	        						" with Different Network Zone - "+dstNWZoneName);
	        			}
    	        	}
    	    	}
    	    }
    	}
    	
        
    }
    
    /*
     * To Validate the Duplicate Rule in the TIRequest
     */
    /**
     * 
     * @param fireWallRule
     * @throws BusinessException
     */
    public void validateforDuplicateRules(FireWallRule fireWallRule, Long currentRuleId) throws BusinessException {
    	List<IpPortContainer> existingSourceIPs = new ArrayList<IpPortContainer>();
    	List<IpPortContainer> existingDestinationIPs = new ArrayList<IpPortContainer>();
        Set<String> existingPortSet = new HashSet<String>();
        Set<Long> existingPolicySet = new HashSet<Long>();
        IpPortContainer container = null;
        
        List<FireWallRuleSourceIP> sourceIPs = fireWallRule.getSourceIPs();
        if (sourceIPs != null && !sourceIPs.isEmpty()) {
     	    for (FireWallRuleSourceIP fireWallRuleSourceIP : sourceIPs) {
     	    	if (fireWallRuleSourceIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleSourceIP.getDeletedTIRequest().getId() != null && fireWallRuleSourceIP.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
     	    	if (fireWallRuleSourceIP.getIpAddress() != null && "Y".equalsIgnoreCase(fireWallRuleSourceIP.getIpAddress().getTemplateFlag())) {
     	    		List<IpPortContainer> ipContainerList = getTemplateIPSet(getIPsforTemplateObject(
     	    				fireWallRuleSourceIP.getIpAddress().getId(), 
     	    				fireWallRuleSourceIP.getObjRuleID(), "N", fireWallRule.getTiRequest().getId()), null);
     	    		existingSourceIPs.addAll(ipContainerList);
     	    	} else if (fireWallRuleSourceIP.getIpAddress() != null && fireWallRuleSourceIP.getIpAddress().getFormattedIP() != null) {
     	    		IPAddress ipAddress = fireWallRuleSourceIP.getIpAddress();
     	    		if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
     	        		log.debug("getSourceIPSet Subnet Calculation"+ ipAddress.getIpAddress());
     	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
     	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
     	        		//for (Long i = start; i<=end; i++) {
     	        		container = new IpPortContainer();
		        		container.setStart(start);
		        		container.setEnd(end);
		        		container.setType(IpPortContainer.RANGE);
		        		existingSourceIPs.add(container);
     	        		//}
     	        	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
     	        		log.debug("getSourceIPSet IP Range"+ ipAddress.getIpAddress());
     	        		//IP Range
     	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
     	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
     	        		//for (Long i = start; i<=end; i++) {
     	        		container = new IpPortContainer();
		        		container.setStart(start);
		        		container.setEnd(end);
		        		container.setType(IpPortContainer.RANGE);
		        		existingSourceIPs.add(container);
     	        		//}
     	        	} else if (ipAddress.getIpAddress() != null) {
     	        		log.debug("getSourceIPSet Single IP"+ ipAddress.getIpAddress());
     	        		//Single IP
     	        		Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
     	        		container = new IpPortContainer();
     	        		container.setSingle(convIP);
     	        		container.setType(IpPortContainer.SINGLE);
     	        		existingSourceIPs.add(container);
     	        	}
     	    	}
     	    }
     	}
    	
    	
    	List<FireWallRuleDestinationIP> destinationIPs = fireWallRule
		.getDestinationIPs();
    	 if (destinationIPs != null && !destinationIPs.isEmpty()) {
 		    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : destinationIPs) {
 		    	if (fireWallRuleDestinationIP.getDeletedTIRequest() != null 
      	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId() != null 
      	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId().longValue() >= 0) {
      	    		continue;
      	    	}
 		    	if (fireWallRuleDestinationIP.getIpAddress() != null && "Y".equalsIgnoreCase(fireWallRuleDestinationIP.getIpAddress().getTemplateFlag())) {
 		    		List<IpPortContainer> ipContainerList = getTemplateIPSet(getIPsforTemplateObject(
 		    				fireWallRuleDestinationIP.getIpAddress().getId(), 
 		    				fireWallRuleDestinationIP.getObjRuleID(), "N", fireWallRule.getTiRequest().getId()), null);
 		    		existingDestinationIPs.addAll(ipContainerList);
     	    	} else if (fireWallRuleDestinationIP.getIpAddress() != null && fireWallRuleDestinationIP.getIpAddress().getFormattedIP() != null) {
 		    		IPAddress ipAddress = fireWallRuleDestinationIP.getIpAddress();
 		    		if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
 		        		log.debug("getDestinationIPSet Subnet Calculation"+ ipAddress.getIpAddress());
 		        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
 		        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
 		        		//for (Long i = start; i<=end; i++) {
 		        		container = new IpPortContainer();
 		        		container.setStart(start);
 		        		container.setEnd(end);
 		        		container.setType(IpPortContainer.RANGE);
 		        		existingDestinationIPs.add(container);
 		        		//}
 		        	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
 		        		log.debug("getDestinationIPSet IP Range"+ ipAddress.getIpAddress());
 		        		//IP Range
 		        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
 		        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
 		        		//for (Long i = start; i<=end; i++) {
 		        		container = new IpPortContainer();
 		        		container.setStart(start);
 		        		container.setEnd(end);
 		        		container.setType(IpPortContainer.RANGE);
 		        		existingDestinationIPs.add(container);
 		        		//}
 		        	} else if (ipAddress.getIpAddress() != null) {
 		        		log.debug("getDestinationIPSet Single IP"+ ipAddress.getIpAddress());
 		        		//Single IP
 		        		Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
      	        		container = new IpPortContainer();
      	        		container.setSingle(convIP);
      	        		container.setType(IpPortContainer.SINGLE);
      	        		existingDestinationIPs.add(container);
 		        	}
 		    	}
 		    }
 		}
    	
    	List<FireWallRulePort> ports = fireWallRule.getPorts();
    	
    	if (ports != null && !ports.isEmpty()) {
    	    for (FireWallRulePort fireWallRulePort : ports) {
    	    	if (fireWallRulePort.getDeletedTIRequest() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
    	    	if (fireWallRulePort.getPort() != null && "Y".equalsIgnoreCase(fireWallRulePort.getPort().getTemplateFlag())) {
    	    		Set<String> tmpPortsSet = getTemplatePortSetWithServiceName(getPortsforTemplateObject(
		    				fireWallRulePort.getPort().getId(), 
		    				fireWallRulePort.getObjRuleID(), "N", fireWallRule.getTiRequest().getId()));
		    		existingPortSet.addAll(tmpPortsSet);
     	    	} else {
	    	    	String portString = null;
	    	    	if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("ICMP")) {
	    	    		portString = fireWallRulePort.getPort().getProtocol()+fireWallRulePort.getPort().getControlMsgId();
	    	    	} else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("TCP") || 
	    	    			fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("UDP")) { 
	    	    		portString =  fireWallRulePort.getPort().getProtocol()+fireWallRulePort.getPort().getPortNumber()+
	    	    				fireWallRulePort.getServiceName();
	    	    	} else {
	    	    		portString = fireWallRulePort.getPort().getProtocol()+fireWallRulePort.getPort().getPortNumber();
	    	    	}
	    	    	existingPortSet.add(portString);
     	    	}
    	    }
    	}
        
    	List<FirewallRulePolicy> policies = fireWallRule.getPolicies();
    	if (policies != null && !policies.isEmpty()) {
    	    for (FirewallRulePolicy firewallRulePolicy : policies) {
    	    	if (firewallRulePolicy.getDeletedTIRequest() != null 
     	    			&& firewallRulePolicy.getDeletedTIRequest().getId() != null 
     	    			&& firewallRulePolicy.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
    	    	
    	    	if (firewallRulePolicy.getFirewallPolicy() != null 
     	    			&& firewallRulePolicy.getFirewallPolicy().getId() != null 
     	    			&& firewallRulePolicy.getFirewallPolicy().getId().longValue() >= 0) {	
    	    		existingPolicySet.add(firewallRulePolicy.getFirewallPolicy().getId());
    	    	log.debug("getPolicySet Policy"+ firewallRulePolicy.getFirewallPolicy().getId());
    	    	}
    	    }
    	}
    	
    	if (compareIPList(existingSourceIPs, sourceIPList) && compareIPList(existingDestinationIPs,destIPList)
    			&& existingPortSet.equals(portServiceSet) && existingPolicySet.equals(policySet)) {
    			log.debug("There is a rule exists with the same details - Rule Number "
	    			    +fireWallRule.getRuleNumber());
    			validationErrors.add("There is a rule exists with the same details - Rule Number "
	    			    +fireWallRule.getRuleNumber());
    	} 
    }
    
    /**
     * 
     * @param fireWallRule
     * @throws BusinessException
     */
    public boolean isRuleModified(FireWallRule before, FireWallRule after) throws BusinessException {
    	
    	List<IpPortContainer> bfrsourceIPSet = getIPsNATSetForRule(getIPsforRule(before.getId(), "S", "N", before.getTiRequest().getId()));
    	List<IpPortContainer> bfrdestIPSet = getIPsNATSetForRule(getIPsforRule(before.getId(), "D", "N", before.getTiRequest().getId()));
    	Set<String> bfrportSet = getPortSet(getPortsforRule(before.getId(), "N", before.getTiRequest().getId()));
    	Set<Long> bfrPolicySet = getPolicySet(before.getPolicies(), false);
    	
    	List<IpPortContainer> aftsourceIPSet = getIPNATSetForUnsavedRuleS(after.getSourceIPs(), after.getTiRequest().getId());
    	List<IpPortContainer> aftdestIPSet = getIPNATSetForUnsavedRuleD(after.getDestinationIPs(), after.getTiRequest().getId());
    	Set<String> aftportSet = getPortSetWithTemplates(after.getPorts(), after.getTiRequest().getId());
    	Set<Long> aftPolicySet = getPolicySet(after.getPolicies(), true);
        
    	log.debug("is Rule Modified Before Sort");
    	log.debug(bfrsourceIPSet);
    	log.debug(aftsourceIPSet);
    	log.debug(bfrdestIPSet);
    	log.debug(aftdestIPSet);
    	log.debug(bfrportSet);
    	log.debug(aftportSet);
    	
    	Collections.sort(bfrsourceIPSet);
    	Collections.sort(aftsourceIPSet);
    	Collections.sort(bfrdestIPSet);
    	Collections.sort(aftdestIPSet);
    	
    	log.debug("is Rule Modified After Sort");
    	log.debug(bfrsourceIPSet);
    	log.debug(aftsourceIPSet);
    	log.debug(bfrdestIPSet);
    	log.debug(aftdestIPSet);
    	log.debug(bfrportSet);
    	log.debug(aftportSet);
    	
    	if (!(bfrsourceIPSet.equals(aftsourceIPSet) && bfrdestIPSet.equals(aftdestIPSet)
    			&& bfrportSet.equals(aftportSet))) {
    		after.setIpPortModified(true);
    	}
    	
    	if (bfrsourceIPSet.equals(aftsourceIPSet) && bfrdestIPSet.equals(aftdestIPSet)
    			&& bfrportSet.equals(aftportSet) && bfrPolicySet.equals(aftPolicySet) && before.getRuleType().equalsIgnoreCase(after.getRuleType())){
    		log.debug("There are no changes to save");
			//throw new BusinessException("There are no changes to save");
    		return false;
    	}
    	return true;
    }
    
    /**
     * 
     * @param fireWallRule
     * @throws BusinessException
     */
    public void createSetsForCurrentRule(FireWallRule curRule) {
    	if (curRule.getSourceIPs() != null && curRule.getSourceIPs().size() > 0 && curRule.getSourceNetworkZone() != null) {
    		sourceIPList = getSourceIPSet(curRule.getSourceIPs(), curRule.getSourceNetworkZone().getId(), curRule.getTiRequest().getId());
    		ipList.addAll(sourceIPList);
    	}
    	if (curRule.getDestinationIPs() != null && curRule.getDestinationIPs().size() > 0 && curRule.getDestinationNetworkZone() != null) {
    		destIPList = getDestinationIPSet(curRule.getDestinationIPs(), curRule.getDestinationNetworkZone().getId(), curRule.getTiRequest().getId());
    		ipList.addAll(destIPList);
    	}
    	if (curRule.getPorts()!= null && curRule.getPorts().size() > 0) {
    		portServiceSet = getPortSetWithServiceName(curRule.getPorts(), curRule.getTiRequest().getId());
    	}
    	if (curRule.getPolicies()!= null && curRule.getPolicies().size() > 0) {
    		policySet = getPolicySet(curRule.getPolicies(), false);
    	}
    }
    
    private List<IpPortContainer> getTemplateIPSet(List<FireWallRuleIP> tempIPs, Long nwZoneId) {
    	List<IpPortContainer> existingNumericIPs = new ArrayList<IpPortContainer>();
    	IpPortContainer container = null;
     	if (tempIPs != null && !tempIPs.isEmpty()) {
     	    for (FireWallRuleIP fireWallRuleSourceIP : tempIPs) {
     	    	if (fireWallRuleSourceIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleSourceIP.getDeletedTIRequest().getId() != null && fireWallRuleSourceIP.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
     	    	 if (fireWallRuleSourceIP.getIpAddress() != null && fireWallRuleSourceIP.getIpAddress().getFormattedIP() != null) {
     	    		IPAddress ipAddress = fireWallRuleSourceIP.getIpAddress();
     	    		if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
     	        		log.debug("getSourceIPSet Subnet Calculation"+ ipAddress.getIpAddress());
     	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
     	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
     	        		//for (Long i = start; i<=end; i++) {
     	        		container = new IpPortContainer();
		        		container.setStart(start);
		        		container.setEnd(end);
		        		container.setType(IpPortContainer.RANGE);
		        		container.setNwZone(nwZoneId);
		        		existingNumericIPs.add(container);
     	        		//}
     	        	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
     	        		log.debug("getSourceIPSet IP Range"+ ipAddress.getIpAddress());
     	        		//IP Range
     	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
     	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
     	        		//for (Long i = start; i<=end; i++) {
     	        		container = new IpPortContainer();
		        		container.setStart(start);
		        		container.setEnd(end);
		        		container.setType(IpPortContainer.RANGE);
		        		container.setNwZone(nwZoneId);
		        		existingNumericIPs.add(container);
     	        		//}
     	        	} else if (ipAddress.getIpAddress() != null) {
     	        		log.debug("getSourceIPSet Single IP"+ ipAddress.getIpAddress());
     	        		//Single IP
     	        		Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
     	        		container = new IpPortContainer();
     	        		container.setSingle(convIP);
     	        		container.setType(IpPortContainer.SINGLE);
     	        		container.setNwZone(nwZoneId);
     	        		existingNumericIPs.add(container);
     	        	}
     	    	}
     	    }
     	}
     	return existingNumericIPs;
    }
    
    private List<IpPortContainer> getSourceIPSet(List<FireWallRuleSourceIP> sourceIPs, Long nwZoneId, Long tiRequestID) {
    	List<IpPortContainer> existingNumericIPs = new ArrayList<IpPortContainer>();
    	IpPortContainer container = null;
     	if (sourceIPs != null && !sourceIPs.isEmpty()) {
     	    for (FireWallRuleIP fireWallRuleSourceIP : sourceIPs) {
     	    	if (fireWallRuleSourceIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleSourceIP.getDeletedTIRequest().getId() != null && fireWallRuleSourceIP.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
     	    	if (fireWallRuleSourceIP.getIpAddress() != null && "Y".equalsIgnoreCase(fireWallRuleSourceIP.getIpAddress().getTemplateFlag())) {
     	    		List<IpPortContainer> ipContainerList = getTemplateIPSet(getIPsforTemplateObject(
     	    				fireWallRuleSourceIP.getIpAddress().getId(), 
     	    				fireWallRuleSourceIP.getObjRuleID(), "N", tiRequestID), nwZoneId);
		    		existingNumericIPs.addAll(ipContainerList);
     	    	} else if (fireWallRuleSourceIP.getIpAddress() != null 
     	    			&& fireWallRuleSourceIP.getIpAddress().getFormattedIP() != null) {
     	    		IPAddress ipAddress = fireWallRuleSourceIP.getIpAddress();
     	    		if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
     	        		log.debug("getSourceIPSet Subnet Calculation"+ ipAddress.getIpAddress());
     	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
     	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
     	        		//for (Long i = start; i<=end; i++) {
     	        		container = new IpPortContainer();
		        		container.setStart(start);
		        		container.setEnd(end);
		        		container.setType(IpPortContainer.RANGE);
		        		container.setNwZone(nwZoneId);
		        		existingNumericIPs.add(container);
     	        		//}
     	        	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
     	        		log.debug("getSourceIPSet IP Range"+ ipAddress.getIpAddress());
     	        		//IP Range
     	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
     	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
     	        		//for (Long i = start; i<=end; i++) {
     	        		container = new IpPortContainer();
		        		container.setStart(start);
		        		container.setEnd(end);
		        		container.setType(IpPortContainer.RANGE);
		        		container.setNwZone(nwZoneId);
		        		existingNumericIPs.add(container);
     	        		//}
     	        	} else if (ipAddress.getIpAddress() != null) {
     	        		log.debug("getSourceIPSet Single IP"+ ipAddress.getIpAddress());
     	        		//Single IP
     	        		Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
     	        		container = new IpPortContainer();
     	        		container.setSingle(convIP);
     	        		container.setType(IpPortContainer.SINGLE);
     	        		container.setNwZone(nwZoneId);
     	        		existingNumericIPs.add(container);
     	        	}
     	    	}
     	    }
     	}
     	return existingNumericIPs;
    }
    
    private List<IpPortContainer> getDestinationIPSet(List<FireWallRuleDestinationIP> destinationIPs, Long nwZoneId, Long tiRequestID) {
    	List<IpPortContainer> existingNumericIPs = new ArrayList<IpPortContainer>();
    	IpPortContainer container = null;
	    if (destinationIPs != null && !destinationIPs.isEmpty()) {
		    for (FireWallRuleIP fireWallRuleDestinationIP : destinationIPs) {
		    	if (fireWallRuleDestinationIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
		    	if (fireWallRuleDestinationIP.getIpAddress() != null && "Y".equalsIgnoreCase(fireWallRuleDestinationIP.getIpAddress().getTemplateFlag())) {
		    		List<IpPortContainer> ipContainerList = getTemplateIPSet(getIPsforTemplateObject(
		    				fireWallRuleDestinationIP.getIpAddress().getId(), 
		    				fireWallRuleDestinationIP.getObjRuleID(), "N", tiRequestID), nwZoneId);
		    		existingNumericIPs.addAll(ipContainerList);
     	    	} else if (fireWallRuleDestinationIP.getIpAddress() != null && fireWallRuleDestinationIP.getIpAddress().getFormattedIP() != null) {
		    		IPAddress ipAddress = fireWallRuleDestinationIP.getIpAddress();
		    		if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
		        		log.debug("getDestinationIPSet Subnet Calculation"+ ipAddress.getIpAddress());
		        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
		        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
		        		//for (Long i = start; i<=end; i++) {
		        		container = new IpPortContainer();
		        		container.setStart(start);
		        		container.setEnd(end);
		        		container.setType(IpPortContainer.RANGE);
		        		container.setNwZone(nwZoneId);
		        		existingNumericIPs.add(container);
		        		//}
		        	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
		        		log.debug("getDestinationIPSet IP Range"+ ipAddress.getIpAddress());
		        		//IP Range
		        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
		        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
		        		//for (Long i = start; i<=end; i++) {
		        		container = new IpPortContainer();
		        		container.setStart(start);
		        		container.setEnd(end);
		        		container.setType(IpPortContainer.RANGE);
		        		container.setNwZone(nwZoneId);
		        		existingNumericIPs.add(container);
		        		//}
		        	} else if (ipAddress.getIpAddress() != null) {
		        		log.debug("getDestinationIPSet Single IP"+ ipAddress.getIpAddress());
		        		//Single IP
		        		Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
     	        		container = new IpPortContainer();
     	        		container.setSingle(convIP);
     	        		container.setType(IpPortContainer.SINGLE);
     	        		container.setNwZone(nwZoneId);
     	        		existingNumericIPs.add(container);
		        	}
		    	}
		    }
		}
	    return existingNumericIPs;
    }
    
       
    public Set<String> getPortSetWithTemplates(List<FireWallRulePort> ports, Long tiRequestID) {
    	Set<String> existingPortSet = new HashSet<String>();
    	if (ports != null && !ports.isEmpty()) {
    	    for (FireWallRulePort fireWallRulePort : ports) {
    	    	/*if (fireWallRulePort.getDeletedTIRequest() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}*/
    	    	if (fireWallRulePort.getPort() != null && "Y".equalsIgnoreCase(fireWallRulePort.getPort().getTemplateFlag())) {
    	    		Set<String> tmpPortsSet = getPortSet(getPortsforTemplateObject(
		    				fireWallRulePort.getPort().getId(), 
		    				fireWallRulePort.getObjRuleID(), "N", tiRequestID));
		    		existingPortSet.addAll(tmpPortsSet);
     	    	} else {
	    	    	String portString = null;
	    	    	if("Y".equalsIgnoreCase(fireWallRulePort.getPort().getTemplateFlag())) {
	    	    		portString = fireWallRulePort.getPort().getPortNumber();
	    	    	} else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("ICMP")) {
	    	    		portString = fireWallRulePort.getPort().getProtocol()
	    	    							+fireWallRulePort.getPort().getControlMsgId();
	    	    	} else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("TCP") || 
	    	    			fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("UDP")) { 
	    	    		portString = fireWallRulePort.getPort().getProtocol()+fireWallRulePort.getPort().getPortNumber();
	    	    	} else {
	    	    		portString = fireWallRulePort.getPort().getProtocol()+fireWallRulePort.getPort().getPortNumber();
	    	    	}
	    	    	existingPortSet.add(portString);
	    	    	log.debug("getPortSet Port"+ portString);
     	    	}
    	    }
    	}
    	return existingPortSet;
    }
    
    public Set<String> getPortSet(List<FireWallRulePort> ports) {
    	Set<String> existingPortSet = new HashSet<String>();
    	if (ports != null && !ports.isEmpty()) {
    	    for (FireWallRulePort fireWallRulePort : ports) {
    	    	if (fireWallRulePort.getDeletedTIRequest() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
    	    	String portString = null;
    	    	if("Y".equalsIgnoreCase(fireWallRulePort.getPort().getTemplateFlag())) {
    	    		portString = fireWallRulePort.getPort().getPortNumber();
    	    	} else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("ICMP")) {
    	    		portString = fireWallRulePort.getPort().getProtocol()
    	    							+fireWallRulePort.getPort().getControlMsgId();
    	    	} else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("TCP") || 
    	    			fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("UDP")) { 
    	    		portString = fireWallRulePort.getPort().getProtocol()+fireWallRulePort.getPort().getPortNumber();
    	    	} else {
    	    		portString = fireWallRulePort.getPort().getProtocol()+fireWallRulePort.getPort().getPortNumber();
    	    	}
    	    	existingPortSet.add(portString);
    	    	log.debug("getPortSet Port"+ portString);
    	    }
    	}
    	return existingPortSet;
    }
    
    private List<IpPortContainer> getIPsNATSetForRule(List<FireWallRuleIP> sourceIPs) {
    	List<IpPortContainer> existingNumericIPs = new ArrayList<IpPortContainer>();
    	IpPortContainer container = null;
     	if (sourceIPs != null && !sourceIPs.isEmpty()) {
     	    for (FireWallRuleIP fireWallRuleSourceIP : sourceIPs) {
     	    	
     	    	if (fireWallRuleSourceIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleSourceIP.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRuleSourceIP.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
     	    	 if (fireWallRuleSourceIP.getIpAddress() != null && fireWallRuleSourceIP.getIpAddress().getFormattedIP() != null) {
     	    		IPAddress ipAddress = fireWallRuleSourceIP.getIpAddress();
     	    		if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
     	        		log.debug("getSourceIPNAMSet Subnet Calculation"+ ipAddress.getIpAddress());
     	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
     	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
     	        		if (fireWallRuleSourceIP.getNAT() != null && fireWallRuleSourceIP.getNAT().length() > 0) {
		        			Long nat = convertIPaddressToInteger(fireWallRuleSourceIP.getNAT());
			        		container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setNat(nat);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		} else {
		        			container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		}
     	        	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
     	        		log.debug("getSourceIPNAMSet IP Range"+ ipAddress.getIpAddress());
     	        		//IP Range
     	        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
     	        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
     	        		if (fireWallRuleSourceIP.getNAT() != null && fireWallRuleSourceIP.getNAT().length() > 0) {
		        			Long nat = convertIPaddressToInteger(fireWallRuleSourceIP.getNAT());
			        		container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setNat(nat);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		} else {
		        			container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		}
     	        	} else if (ipAddress.getIpAddress() != null) {
     	        		log.debug("getSourceIPNAMSet Single IP"+ ipAddress.getIpAddress());
     	        		//Single IP
     	        		if (fireWallRuleSourceIP.getNAT() != null && fireWallRuleSourceIP.getNAT().length() > 0) {
	     	        		Long nat = convertIPaddressToInteger(fireWallRuleSourceIP.getNAT());
	     	        		Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
	     	        		container = new IpPortContainer();
	     	        		container.setSingle(convIP);
	     	        		container.setNat(nat);
	     	        		container.setType(IpPortContainer.SINGLE);
	     	        		existingNumericIPs.add(container);
     	        		} else {
     	        			Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
         	        		container = new IpPortContainer();
         	        		container.setSingle(convIP);
         	        		container.setType(IpPortContainer.SINGLE);
         	        		existingNumericIPs.add(container);
     	        		}
     	        	}
     	    	}
     	    }
     	}
     	return existingNumericIPs;
    }
    
    private List<IpPortContainer> getIPNATSetForUnsavedRuleD(List<FireWallRuleDestinationIP> destinationIPs, Long tiRequestID) {
    	List<IpPortContainer> existingNumericIPs = new ArrayList<IpPortContainer>();
    	IpPortContainer container = null;
	    if (destinationIPs != null && !destinationIPs.isEmpty()) {
		    for (FireWallRuleIP fireWallRuleDestinationIP : destinationIPs) {
		    	/*if (fireWallRuleDestinationIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}*/
		    	if (fireWallRuleDestinationIP.getIpAddress() != null && "Y".equalsIgnoreCase(fireWallRuleDestinationIP.getIpAddress().getTemplateFlag())) {
		    		List<IpPortContainer> ipContainerList = getIPsNATSetForRule(getIPsforTemplateObject(
 	        				fireWallRuleDestinationIP.getIpAddress().getId(), 
 	        				fireWallRuleDestinationIP.getObjRuleID(), "N", tiRequestID));
		    		existingNumericIPs.addAll(ipContainerList);
     	    	} else if (fireWallRuleDestinationIP.getIpAddress() != null && fireWallRuleDestinationIP.getIpAddress().getFormattedIP() != null) {
		    		IPAddress ipAddress = fireWallRuleDestinationIP.getIpAddress();
		    		if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
		        		log.debug("getDestinationIPNAMSet Subnet Calculation"+ ipAddress.getIpAddress());
		        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
		        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
		        		if (fireWallRuleDestinationIP.getNAT() != null && fireWallRuleDestinationIP.getNAT().length() > 0) {
		        			Long nat = convertIPaddressToInteger(fireWallRuleDestinationIP.getNAT());
			        		container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setNat(nat);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		} else {
		        			container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		}
		        	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
		        		log.debug("getDestinationIPNAMSet IP Range"+ ipAddress.getIpAddress());
		        		//IP Range
		        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
		        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
		        		if (fireWallRuleDestinationIP.getNAT() != null && fireWallRuleDestinationIP.getNAT().length() > 0) {
		        			Long nat = convertIPaddressToInteger(fireWallRuleDestinationIP.getNAT());
			        		container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setNat(nat);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		} else {
		        			container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		}
		        	} else if (ipAddress.getIpAddress() != null) {
		        		log.debug("getDestinationIPNAMSet Single IP"+ ipAddress.getIpAddress());
		        		//Single IP
		        		if (fireWallRuleDestinationIP.getNAT() != null && fireWallRuleDestinationIP.getNAT().length() > 0) {
	     	        		Long nat = convertIPaddressToInteger(fireWallRuleDestinationIP.getNAT());
	     	        		Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
	     	        		container = new IpPortContainer();
	     	        		container.setSingle(convIP);
	     	        		container.setNat(nat);
	     	        		container.setType(IpPortContainer.SINGLE);
	     	        		existingNumericIPs.add(container);
     	        		} else {
     	        			Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
         	        		container = new IpPortContainer();
         	        		container.setSingle(convIP);
         	        		container.setType(IpPortContainer.SINGLE);
         	        		existingNumericIPs.add(container);
     	        		} 	        	
		        	}
		    	}
		    }
		}
	    return existingNumericIPs;
    }
    
    private List<IpPortContainer> getIPNATSetForUnsavedRuleS(List<FireWallRuleSourceIP> sourceIPs, Long tiRequestID) {
    	List<IpPortContainer> existingNumericIPs = new ArrayList<IpPortContainer>();
    	IpPortContainer container = null;
	    if (sourceIPs != null && !sourceIPs.isEmpty()) {
		    for (FireWallRuleSourceIP fireWallRuleDestinationIP : sourceIPs) {
		    	/*if (fireWallRuleDestinationIP.getDeletedTIRequest() != null 
     	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRuleDestinationIP.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}*/
		    	if (fireWallRuleDestinationIP.getIpAddress() != null && "Y".equalsIgnoreCase(fireWallRuleDestinationIP.getIpAddress().getTemplateFlag())) {
		    		List<IpPortContainer> ipContainerList = getIPsNATSetForRule(getIPsforTemplateObject(
 	        				fireWallRuleDestinationIP.getIpAddress().getId(), 
 	        				fireWallRuleDestinationIP.getObjRuleID(), "N", tiRequestID));
		    		existingNumericIPs.addAll(ipContainerList);
     	    	} else if (fireWallRuleDestinationIP.getIpAddress() != null && fireWallRuleDestinationIP.getIpAddress().getFormattedIP() != null) {
		    		IPAddress ipAddress = fireWallRuleDestinationIP.getIpAddress();
		    		if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("/") != -1) {
		        		log.debug("getDestinationIPNAMSet Subnet Calculation"+ ipAddress.getIpAddress());
		        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
		        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
		        		if (fireWallRuleDestinationIP.getNAT() != null && fireWallRuleDestinationIP.getNAT().length() > 0) {
		        			Long nat = convertIPaddressToInteger(fireWallRuleDestinationIP.getNAT());
			        		container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setNat(nat);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		} else {
		        			container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		}
		        	} else if (ipAddress.getIpAddress() != null && ipAddress.getIpAddress().indexOf("-") != -1) {
		        		log.debug("getDestinationIPNAMSet IP Range"+ ipAddress.getIpAddress());
		        		//IP Range
		        		Long start = convertIPaddressToInteger(ipAddress.getStartIP());
		        		Long end = convertIPaddressToInteger(ipAddress.getEndIP());
		        		if (fireWallRuleDestinationIP.getNAT() != null && fireWallRuleDestinationIP.getNAT().length() > 0) {
		        			Long nat = convertIPaddressToInteger(fireWallRuleDestinationIP.getNAT());
			        		container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setNat(nat);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		} else {
		        			container = new IpPortContainer();
			        		container.setStart(start);
			        		container.setEnd(end);
			        		container.setType(IpPortContainer.RANGE);
			        		existingNumericIPs.add(container);
		        		}
		        	} else if (ipAddress.getIpAddress() != null) {
		        		log.debug("getDestinationIPNAMSet Single IP"+ ipAddress.getIpAddress());
		        		//Single IP
		        		if (fireWallRuleDestinationIP.getNAT() != null && fireWallRuleDestinationIP.getNAT().length() > 0) {
	     	        		Long nat = convertIPaddressToInteger(fireWallRuleDestinationIP.getNAT());
	     	        		Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
	     	        		container = new IpPortContainer();
	     	        		container.setSingle(convIP);
	     	        		container.setNat(nat);
	     	        		container.setType(IpPortContainer.SINGLE);
	     	        		existingNumericIPs.add(container);
     	        		} else {
     	        			Long convIP = convertIPaddressToInteger(ipAddress.getIpAddress());
         	        		container = new IpPortContainer();
         	        		container.setSingle(convIP);
         	        		container.setType(IpPortContainer.SINGLE);
         	        		existingNumericIPs.add(container);
     	        		} 	        	
		        	}
		    	}
		    }
		}
	    return existingNumericIPs;
    }
    
    public Set<String> getPortSetWithServiceName(List<FireWallRulePort> ports, Long tiRequestID) {
    	Set<String> existingPortSet = new HashSet<String>();
    	if (ports != null && !ports.isEmpty()) {
    	    for (FireWallRulePort fireWallRulePort : ports) {
    	    	if (fireWallRulePort.getDeletedTIRequest() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
    	    	if (fireWallRulePort.getPort() != null && "Y".equalsIgnoreCase(fireWallRulePort.getPort().getTemplateFlag())) {
    	    		Set<String> tmpPortsSet = getTemplatePortSetWithServiceName(getPortsforTemplateObject(
		    				fireWallRulePort.getPort().getId(), 
		    				fireWallRulePort.getObjRuleID(), "N", tiRequestID));
		    		existingPortSet.addAll(tmpPortsSet);
     	    	} else {
	    	    	String portString = null;
	    	    	if("Y".equalsIgnoreCase(fireWallRulePort.getPort().getTemplateFlag())) {
	    	    		portString = fireWallRulePort.getPort().getPortNumber();
	    	    	} else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("ICMP")) {
	    	    		portString = fireWallRulePort.getPort().getProtocol()
	    	    							+fireWallRulePort.getPort().getControlMsgId();
	    	    	} else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("TCP") || 
	    	    			fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("UDP")) { 
	    	    		portString = fireWallRulePort.getPort().getProtocol()
						+fireWallRulePort.getPort().getPortNumber()+fireWallRulePort.getServiceName();
	    	    	} else {
	    	    		portString = fireWallRulePort.getPort().getProtocol()
	    	    								+fireWallRulePort.getPort().getPortNumber();
	    	    	}
	    	    	existingPortSet.add(portString);
	    	    	log.debug("getPortSetWithServiceName Port"+ portString);
     	    	}
    	    }
    	}
    	return existingPortSet;
    }
    
    public Set<Long> getPolicySet(List<FirewallRulePolicy> policies, boolean includeDeleted) {
    	Set<Long> existingPolicySet = new HashSet<Long>();
    	if (policies != null && !policies.isEmpty()) {
    	    for (FirewallRulePolicy firewallRulePolicy : policies) {
    	    	if (!includeDeleted && firewallRulePolicy.getDeletedTIRequest() != null 
     	    			&& firewallRulePolicy.getDeletedTIRequest().getId() != null 
     	    			&& firewallRulePolicy.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
    	    	
    	    	if (firewallRulePolicy.getFirewallPolicy() != null 
     	    			&& firewallRulePolicy.getFirewallPolicy().getId() != null 
     	    			&& firewallRulePolicy.getFirewallPolicy().getId().longValue() >= 0) {	
    	    		existingPolicySet.add(firewallRulePolicy.getFirewallPolicy().getId());
    	    	log.debug("getPolicySet Policy"+ firewallRulePolicy.getFirewallPolicy().getId());
    	    	}
    	    }
    	}
    	return existingPolicySet;
    }
    
    public Set<String> getTemplatePortSetWithServiceName(List<FireWallRulePort> ports) {
    	Set<String> existingPortSet = new HashSet<String>();
    	if (ports != null && !ports.isEmpty()) {
    	    for (FireWallRulePort fireWallRulePort : ports) {
    	    	if (fireWallRulePort.getDeletedTIRequest() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId() != null 
     	    			&& fireWallRulePort.getDeletedTIRequest().getId().longValue() >= 0) {
     	    		continue;
     	    	}
    	    	String portString = null;
    	    	if("Y".equalsIgnoreCase(fireWallRulePort.getPort().getTemplateFlag())) {
    	    		portString = fireWallRulePort.getPort().getPortNumber();
    	    	} else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("ICMP")) {
    	    		portString = fireWallRulePort.getPort().getProtocol()
    	    							+fireWallRulePort.getPort().getControlMsgId();
    	    	} else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("TCP") || 
    	    			fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("UDP")) { 
    	    		portString = fireWallRulePort.getPort().getProtocol()
					+fireWallRulePort.getPort().getPortNumber()+fireWallRulePort.getServiceName();
    	    	} else {
    	    		portString = fireWallRulePort.getPort().getProtocol()
    	    								+fireWallRulePort.getPort().getPortNumber();
    	    	}
    	    	existingPortSet.add(portString);
    	    	log.debug("getPortSetWithServiceName Port"+ portString);
    	    }
    	}
    	return existingPortSet;
    }
    
    /**
     * 
     * @param str
     * @return
     */
    private static long convertIPaddressToInteger(String str) {
    	long val = 0;
    	  
    	  /** The number of bits in the prefix. */
    	 int prefix_len;
        int i=0, stop;
        int addr[] = new int[4];
        
        prefix_len = 32;

        if (str.length() > 0) {
          if (str.indexOf('.') < 0) {
            // it's in binary string notation
            if (str.charAt(0) == '"') {
              str = str.substring(1, str.length()-1);
            }
            val = 0;
            for (int j=0; j<str.length(); j++) {
              if (str.charAt(j) == '1') {
                val += (long)(1 << (31-j));
              }
            }
            prefix_len = str.length();
            return val;
          }
        } else {
          prefix_len = 0;
          val = (long)0;
          return val;
        }

        // dotted-quad notation

        if (str.charAt(0) == '"') { // there are quotes around the IP address
          i = 1;
          stop = str.length()-1;
        } else { // no quotes
          stop = str.length();
        }

        // parse and convert the a.b.c.d part
        for (int p=0; p<4; p++) {
          addr[p] = 0;
          while (i<stop && str.charAt(i) != '.' && str.charAt(i) != '/') {
            addr[p] = addr[p]*10 + Character.getNumericValue(str.charAt(i));
            i++;
          }
          if (p < 3) {
            i++;
          }
        }
        // parse and convert the prefix (if it exists)
        if (i<stop && str.charAt(i) == '/') {
          i++;
          prefix_len = 0;
          while (i < stop) {
            prefix_len= prefix_len*10 + Character.getNumericValue(str.charAt(i));
            i++;
          }
        }

        // convert a.b.c.d address to a single integer
        val = addr[0]*(long)16777216 + addr[1]*65536 + addr[2]*256 + addr[3];
        return val;
      }
    
    /**
     * 
     * @param val
     * @return
     */
    private static String val2str(long val) {
        String str;
        int a = 255, b = 255, c = 255, d = 255;
        int A,B,C,D;

        a <<= 24;
        b <<= 16;
        c <<= 8;

        A = (int)((val & a) >> 24);
        B = (int)((val & b) >> 16);
        C = (int)((val & c) >> 8);
        D = (int)(val & d);

        str = A + "." + B + "." + C + "." + D;

        return str;
      }
    
    
    private boolean IsPort(String value)
    {
        if (value == null || value.isEmpty())
            return false;
        
        if (value.indexOf("-") != -1) {
        	pattern = Pattern.compile(PORT_RANGE_PATTERN);
        	matcher = pattern.matcher(value);

             if (matcher.matches())
             {
            	 String[] values = value.split("-");
                 try
                 {
                     if (Integer.parseInt(values[1]) > Integer.parseInt(values[0]) && 
                    		 (Integer.parseInt(values[0]) < 65536 && Integer.parseInt(values[1]) < 65536)) {
                         return true;
                     }
                 }
                 catch (Exception e)
                 {
                 }
             }
        } else {
        	pattern = Pattern.compile(PORT_PATTERN);
        	 matcher = pattern.matcher(value);

             if (matcher.matches())
             {
                 try
                 {
                     if (Integer.parseInt(value) < 65536) {
                         return true;
                     }
                 }
                 catch (Exception e)
                 {
                 }
             }
        }
       

        return false;
    }
    
    private boolean compareIPList(List<IpPortContainer> list1, List<IpPortContainer> list2) {
    	System.out.println("-------------------");
		System.out.println(list1);
		System.out.println(list2);
		System.out.println("-------------------");
		List<String> srcObjList = new ArrayList<String>();
		List<String> dstObjList = new ArrayList<String>();
		for (IpPortContainer portContainer : list1) {
			if ("O".equalsIgnoreCase(portContainer.getType())) {
				srcObjList.add(portContainer.getObject());
			}
		}
		for (IpPortContainer portContainer : list2) {
			if ("O".equalsIgnoreCase(portContainer.getType())) {
				dstObjList.add(portContainer.getObject());
			}
		}
		
    	List<Long> srcList = new ArrayList<Long>();
		for (IpPortContainer portContainer : list1) {
			if ("R".equalsIgnoreCase(portContainer.getType())) {
				srcList.add(portContainer.getStart());
				srcList.add(portContainer.getEnd());
			}
		}
		
		List<Long> dstList = new ArrayList<Long>();
		for (IpPortContainer portContainer : list2) {
			if ("R".equalsIgnoreCase(portContainer.getType())) {
				dstList.add(portContainer.getStart());
				dstList.add(portContainer.getEnd());
			}
		}
		
		//Sort the Source and Dest List After Adding Ranges
		if (srcList != null && srcList.size() > 0) {
			Collections.sort(srcList);
		}
		if (dstList!= null && dstList.size() > 0) {
			Collections.sort(dstList);
		}
		
		List<Long> srcListAfterRange = new ArrayList<Long>();
		List<Long> dstListAfterRange = new ArrayList<Long>();
		
		Long last = null;
		boolean skipNext = false;
		if (srcList != null && srcList.size() > 0) {
			for (Long i : srcList) {
				
				if (skipNext) {
					last = i;
					continue;
				}
				
				if (last != null && last+1 == i) {
					skipNext = true;
				} else if (last != null) {
					srcListAfterRange.add(last);
				}
				last = i;
			}
			srcListAfterRange.add(last);
		}
		
		last = null;
		skipNext = false;
		if (dstList!= null && dstList.size() > 0) {
			for (Long i : dstList) {
				
				if (skipNext) {
					last = i;
					continue;
				}
				
				if (last != null && last+1 == i) {
					skipNext = true;
				} else if (last != null) {
					dstListAfterRange.add(last);
				}
				last = i;
			}
			dstListAfterRange.add(last);
		}
		
		for (IpPortContainer portContainer : list1) {
			if ("S".equalsIgnoreCase(portContainer.getType())) {
				srcListAfterRange.add(portContainer.getSingle());
			} 
		}
		
		for (IpPortContainer portContainer : list2) {
			if ("S".equalsIgnoreCase(portContainer.getType())) {
				dstListAfterRange.add(portContainer.getSingle());
			} 
		}
		
		if (srcListAfterRange!= null && srcListAfterRange.size() > 0) {
			Collections.sort(srcListAfterRange);
		}
		if (dstListAfterRange != null && dstListAfterRange.size() > 0) {
			Collections.sort(dstListAfterRange);
		}
		
		List<Long> srcListProcessed = new ArrayList<Long>();
		List<Long> dstListProcessed = new ArrayList<Long>();
		
		last = null;
		if (srcListAfterRange!= null && srcListAfterRange.size() > 0) {
			for (Long i : srcListAfterRange) {
			
				if (last != null && last+1 == i) {
				
				} else if (last != null) {
					srcListProcessed.add(last);
				}
				last = i;
			}
			srcListProcessed.add(last);
		}
		
		last = null;
		if (dstListAfterRange != null && dstListAfterRange.size() > 0) {
			for (Long i : dstListAfterRange) {
				
				if (last != null && last+1 == i) {
				} else if (last != null) {
					dstListProcessed.add(last);
				}
				last = i;
			}
			dstListProcessed.add(last);
		}
		System.out.println("-------------------");
		System.out.println(srcListProcessed);
		System.out.println(dstListProcessed);
		System.out.println("-------------------");
		return (srcListProcessed.equals(dstListProcessed) && srcObjList.equals(dstObjList));
    }
    
    @SuppressWarnings("unchecked")
	public List<FireWallRuleIP> getIPsforTemplateObject(Long ipId, Long ruleId, String forFAF, Long tiReqId) {
    	Session session = getSession();
    	List<FireWallRuleIP> firewallRuleIPs = (List<FireWallRuleIP>)
    	session.getNamedQuery("getIPsforTemplateObject")
    	.setLong(0, ipId)
    	.setLong(1, ruleId)
    	.setString(2, forFAF)
    	.setLong(3, tiReqId).list();
    	return firewallRuleIPs;
    }
    
    @SuppressWarnings("unchecked")
	public List<FireWallRuleIP> getIPsforRule(Long ruleId, String ipFlag, String forFAF, Long tiReqId) {
    	Session session = getSession();
    	List<FireWallRuleIP> firewallRuleIPs = (List<FireWallRuleIP>)
    	session.getNamedQuery("getIPsforRule")
    	.setLong(0, ruleId)
    	.setString(1, ipFlag)
    	.setString(2, forFAF)
    	.setLong(3, tiReqId).list();
    	return firewallRuleIPs;
    }
    @SuppressWarnings("unchecked")
	public List<FireWallRulePort> getPortsforTemplateObject(Long ipId, Long ruleId, String forFAF, Long tiReqId) {
    	Session session = getSession();
    	List<FireWallRulePort> firewallRulePorts = (List<FireWallRulePort>)
    	session.getNamedQuery("getPortsforTemplateObject")
    	.setLong(0, ipId)
    	.setLong(1, ruleId)
    	.setString(2, forFAF)
    	.setLong(3, tiReqId).list();
    	return firewallRulePorts;
    }
    
    @SuppressWarnings("unchecked")
	public List<FireWallRulePort> getPortsforRule(Long ruleId, String forFAF, Long tiReqId) {
    	Session session = getSession();
    	List<FireWallRulePort> firewallRulePorts = (List<FireWallRulePort>)
    	session.getNamedQuery("getPortsforRule")
    	.setLong(0, ruleId)
    	.setString(1, forFAF)
    	.setLong(2, tiReqId).list();
    	return firewallRulePorts;
    }
}


