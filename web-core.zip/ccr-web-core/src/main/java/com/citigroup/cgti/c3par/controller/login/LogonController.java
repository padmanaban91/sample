package com.citigroup.cgti.c3par.controller.login;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.citigroup.cgti.c3par.common.domain.AdminProcess;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.user.domain.C3parUserRoleXref;

@Controller
public class LogonController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(LogonController.class);
	
	private WebApplicationContext ctx = null;
	
	//@RequestMapping(value = "/logon.act")
	public String login(HttpServletRequest request){
		log.info("LogonController starts here..");
		String forward = "pages/jsp/Administration/DeactivatedUserMessage";
		String remoteUser = request.getHeader("SM_USER");

		HttpSession session = request.getSession();
		String forwardTo = request.getParameter("forwardTo");
		if (session.getAttribute("LOADED_USER_INFO") == null 
			|| "".equals(session.getAttribute("LOADED_USER_INFO").toString().trim())) {

		    boolean admin = false;
		    boolean readonly = false;
		    Set sessionRole = new HashSet();
		    System.out.println("loading user started"+request.getHeader("SM_USER").toLowerCase());
		    // load the role details from the database
		    AdminProcess adminProcess = new AdminProcess();
		    C3parUser c3parUser = adminProcess.retrieveC3parUser(request.getHeader("SM_USER").toLowerCase());
		    if(c3parUser != null && "Y".equalsIgnoreCase(c3parUser.getActive()))
		    {
		
		    	List<C3parUserRoleXref> extUserRoleList = null;
				
				extUserRoleList = c3parUser.getUserRoleList();
				
				if (extUserRoleList != null && !extUserRoleList.isEmpty()) {
					for (C3parUserRoleXref c3parUserRoleXrefExt : extUserRoleList) {
						if ( c3parUserRoleXrefExt.getSecurityRole()!= null) {
							String roleId = c3parUserRoleXrefExt.getSecurityRole().getName();
						    log.debug("roleId::" + sessionRole);
						    sessionRole.add(roleId);
						    if(roleId.equalsIgnoreCase("C3PARSYSTEMADMIN"))
							admin = true;
						    if(roleId.equalsIgnoreCase("ISS"))
						    {
							admin = true;
							readonly = true;
						    }
						}
					}
				}



			log.debug("sessionRole.size()::" + sessionRole.size());
			if((sessionRole.size() >= 1))
			{
				if(sessionRole.contains("ECM Agent") && session.getAttribute("forwardToBC") == null){
					log.debug("into it");
					forward = "forward:/agentViewController.act";
				}
				else if  (session.getAttribute("forwardToBC") !=null ){
			    	if( !session.getAttribute("forwardToBC").toString().isEmpty()){
			    		log.debug("into else if");
			    	forward =session.getAttribute("forwardToBC").toString();
			    	}
			    } else if (forwardTo != null && "bpm".equalsIgnoreCase(forwardTo)) {
					removeSessionAttributes(session);
					forward = "pages/jsp/bpm/logonRedirectToBpm";
					log.debug("forwarding to bpm...");
			    }
			    	else {
				String bpmForward = request.getParameter("forward");
				log.debug("bpmForward::" + bpmForward);
				if (bpmForward != null && !"".equals(bpmForward)) {
					log.debug("forwarding to bpmIntegrationAction:");
				    forward = "forward:/bpmIntegrationAction.act";
				} else if(sessionRole.contains("C3PARSECURITYADMIN")) {
				    forward="c3par.security.admin";
				} else {
//				    forward = "forward:/listMyTaskListAction.do";
					forward="c3par.security.admin";
				}
			    }
			    session.setAttribute("IS_ADMIN", Boolean.valueOf(admin));
			    session.setAttribute("MAIN_ROLE", sessionRole);
			    session.setAttribute("ROLE", sessionRole);
			    session.setAttribute("READ_ONLY", Boolean.valueOf(readonly));
			    session.setAttribute("USER_NAME", c3parUser.getLastName() + ", " + c3parUser.getFirstName());
			}
		    } else {
				log.debug("Guest User coming here for entitlements (manager review or request/update entitlements)");
				Set guestRole = new HashSet();
				guestRole.add("GuestRole");
				List roleList = new ArrayList();
				roleList.add("GuestRole");
	
				session.setAttribute("IS_ADMIN", Boolean.FALSE);
				session.setAttribute("MAIN_ROLE", guestRole);
				session.setAttribute("ROLE", guestRole);
				session.setAttribute("READ_ONLY", Boolean.FALSE);
				session.setAttribute("USER_NAME", "Guest: " + remoteUser);
	
				String bpmForward = request.getParameter("forward");
				log.debug("bpmForward::" + bpmForward);
				if (bpmForward != null && !"".equals(bpmForward)) {
				    forward = "forward:/bpmIntegrationAction.act";
				} 
		    }

		    session.setAttribute("LOADED_USER_INFO", "LOADED_USER_INFO");
		} else {
		    if (forwardTo != null && "bpm".equalsIgnoreCase(forwardTo)) {
			removeSessionAttributes(session);
			forward = "pages/jsp/bpm/logonRedirectToBpm";
			log.debug("forwarding to bpm...");
		    } else {
			String bpmForward = request.getParameter("forward");
			log.debug("bpmForward::" + bpmForward);
			if (bpmForward != null && !"".equals(bpmForward)) {
			    forward = "forward:/bpmIntegrationAction.act";
			} else if(((Set)session.getAttribute("MAIN_ROLE")).contains("C3PARSECURITYADMIN")) {
				forward="c3par.security.admin";
			} else {
//			    forward = "forward:/listMyTaskListAction.do";
				forward="c3par.security.admin";
			}
		    }
		}

		log.info("LogonController ends here.."+forward);
		return forward;
	}
	
	/**
     * Removes the session attributes.
     *
     * @param session the session
     */
    public void removeSessionAttributes(HttpSession session){
	session.removeAttribute("called_function");
    }
	
    
    /**
	 * Gets the context.
	 *
	 * @param servletContext the servlet context
	 * @return the context
	 */
	protected WebApplicationContext getContext(ServletContext servletContext) {
		log.debug("getContext(): Start");
		if (ctx == null) {
			log.debug("Getting Spring  Context ....");
			ctx = WebApplicationContextUtils.getWebApplicationContext(servletContext);
			log.debug("Getting Spring  Context ....");
		}
		log.debug("getContext(): End");
		return ctx;
	}

	/**
	 * Gets the bean.
	 *
	 * @param request the request
	 * @param strManager the str manager
	 * @return the bean
	 */
	protected Object getBean(HttpServletRequest request, String strManager) {
		log.debug("getService(): Start");
		Object mgr = ((getContext(request.getSession().getServletContext())).getBean(strManager));
		log.debug("getService(): End");
		return mgr;
	}
}
