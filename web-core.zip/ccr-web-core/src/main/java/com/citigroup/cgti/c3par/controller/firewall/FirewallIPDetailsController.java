package com.citigroup.cgti.c3par.controller.firewall;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiResource;
import com.citigroup.cgti.c3par.common.domain.Application;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleApplication;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.IPDetailsRequest;
import com.citigroup.cgti.c3par.webtier.helper.CSIUtil;

@Controller
public class FirewallIPDetailsController extends BaseController {
	
	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@Autowired
	private CSIUtil csiUtil;
	
	@RequestMapping(value = "/loadIPDetails.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String loadIPDetails(HttpServletRequest request, ModelMap model) {
		log.info("FirewallIPDetailsController::loadIPDetails methods starts...");
		IPDetailsRequest ipDetailsRequest = new IPDetailsRequest();
			
			TIRequest tiRequest = null;
	        String requestType =  null;
	        tiRequest = getTirequest(request);
	        if (tiRequest.getTiRequestType() != null
	                    && tiRequest.getTiRequestType().getName() != null) {
	              requestType = tiRequest.getTiRequestType().getName() ;
	              log.debug(" Request Type :: " + requestType);
	              if (requestType != null
	                          && requestType.equalsIgnoreCase("Terminate")) {
	                    log.debug("Setting DisplayMode to View for Termination Cycle");
	                    request.getSession().setAttribute("displayMode", "View");
	              }
	        }	
			Long processID = tiRequest.getTiProcess().getId();
			ipDetailsRequest.setTiRequest(getPreviousVersionTiRequestID(processID, request));
			ipDetailsRequest.setTiProcess(processID);
			ipDetailsRequest.setOffset(0);
			ipDetailsRequest.setPageNo(1);
			ipDetailsRequest.setLimit(10);
			String con_type = (String) request.getSession().getAttribute("con_type");
			log.debug(" ConnectionType :: " + con_type);
			if("ipReg".equalsIgnoreCase(con_type))
			{
				ipDetailsRequest.setIsIpReg("Y");
				log.debug(" IPRegistration :: " + con_type);
			}else
			{
				ipDetailsRequest.setIsIpReg("N");
				log.debug(" Firewall :: " + con_type);
			}
			List<FireWallRuleIP> ipDetails = ipDetailsRequest.loadIPDetails();
			
			int rowCount = ipDetailsRequest.getRowCount();
			
			//To calculate no of pages
			int totalPages = 0;
			int limit = 10;
			
			if (rowCount%limit > 0) {
				totalPages = Math.round((rowCount/limit)+0.5f);
			} else {
				totalPages = Math.round(rowCount/limit);
			}
			
			ipDetailsRequest.setTotalPages(totalPages);
		
			ipDetailsRequest.setIpAddressList(ipDetails);
			if (requestType != null
					&& requestType.equalsIgnoreCase("Maintain")) {
			//CSIUtil csiUtil = new CSIUtil();
			log.debug("isWebService : " +csiUtil.isWebServiceFlag());
			log.debug("processID : " +processID);
			csiUtil.refreshCSIValuesInTIApplication(csiUtil.getTiApplicationIdsForGivenProcessId(processID),request.getHeader("SM_USER"),csiUtil.isWebServiceFlag());
			}
			isCompleteCheck(request);
			model.addAttribute("ipDetailsRequest", ipDetailsRequest);
			log.info("FirewallIPDetailsController::loadIPDetails methods ends...");
			return "c3par.ipdetail.listips";	
		}
	
	/*
     * To List the IP Details in the IP Details
     * This will list max 5 IPs. 
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/paginateIPs.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String paginateIPs(HttpServletRequest request, ModelMap model, @ModelAttribute("ipDetailsRequest") IPDetailsRequest ipDetailsRequest) {
	    log.info("FirewallIPDetailsController::paginateIPs methods starts...");
		
	    TIRequest tiRequest = getTirequest(request);
	    Long processID = tiRequest.getTiProcess().getId();
		String type = (String)request.getParameter("type");
		
		log.debug("FirewallIPDetailsController::paginateIPs type..."+type);
		
		String con_type = (String) request.getSession().getAttribute("con_type");
		log.debug(" ConnectionType :: " + con_type);
		
		int curOffSet = ipDetailsRequest.getOffset();
		int limit = ipDetailsRequest.getLimit();
		int pageNo = ipDetailsRequest.getPageNo();
		
		String filterType = ipDetailsRequest.getFilterType();
		String filterText = ipDetailsRequest.getFilterText();
	
		ipDetailsRequest = new IPDetailsRequest();
		ipDetailsRequest.setTiRequest(getPreviousVersionTiRequestID(processID, request));
		ipDetailsRequest.setTiProcess(processID);
		ipDetailsRequest.setLimit(limit);
		ipDetailsRequest.setFilterText(filterText);
		ipDetailsRequest.setFilterType(filterType);
		
		if("ipReg".equalsIgnoreCase(con_type))
		{
			ipDetailsRequest.setIsIpReg("Y");
			log.debug(" IPRegistration :: " + con_type);
		}else
		{
			ipDetailsRequest.setIsIpReg("N");
			log.debug(" Firewall :: " + con_type);
		}

		if ("N".equalsIgnoreCase(type)) {
			ipDetailsRequest.setOffset(curOffSet+ipDetailsRequest.getLimit());
			ipDetailsRequest.setPageNo(pageNo+1);
		} else if ("P".equalsIgnoreCase(type)) {
			ipDetailsRequest.setOffset(curOffSet-ipDetailsRequest.getLimit());
			ipDetailsRequest.setPageNo(pageNo-1);
		} else if ("X".equalsIgnoreCase(type)) {
			ipDetailsRequest.setOffset(limit * (pageNo-1));
			ipDetailsRequest.setPageNo(pageNo);
		} else if ("L".equalsIgnoreCase(type)) {
			ipDetailsRequest.setOffset(0);
			ipDetailsRequest.setPageNo(1);
		} else {
			ipDetailsRequest.setOffset(0);
			ipDetailsRequest.setPageNo(1);
		}
		
		List<FireWallRuleIP> ipAddressList = ipDetailsRequest.loadIPDetails();
		
		int rowCount = ipDetailsRequest.getRowCount();
		
		int totalPages = 0;
		
		if (limit!=0 && rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}	
		
		ipDetailsRequest.setTotalPages(totalPages);
	
		ipDetailsRequest.setIpAddressList(ipAddressList);
		model.addAttribute("ipDetailsRequest", ipDetailsRequest);
		log.info("FirewallIPDetailsController::paginateIPs methods ends...");
		return "pages/jsp/fw/IPDetails";
    }
	
	 /*
     * To view the applications for the ip(s)
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/viewApplications.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String viewApplications(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallIPDetailsController::viewApplications methods starts...");
    	String result = "pages/jsp/fw/ApplicationPopup";
    	TIRequest tiRequest = getTirequest(request);
	    Long processID = tiRequest.getTiProcess().getId();
		IPDetailsRequest applicationDetails = new IPDetailsRequest();
		String con_type = (String) request.getSession().getAttribute("con_type");
		log.debug(" ConnectionType :: " + con_type);
		if("ipReg".equalsIgnoreCase(con_type))
		{
			applicationDetails.setIsIpReg("Y");
			log.debug(" IPRegistration :: " + con_type);
		}else
		{
			applicationDetails.setIsIpReg("N");
			log.debug(" Firewall :: " + con_type);
		}
		 applicationDetails.setTiRequest(getPreviousVersionTiRequestID(processID, request));
		 applicationDetails.setDeviceTypeList(applicationDetails.getDeviceTypes());
		 //Three Types : IP, IP_RULE, RULE
		 String fromScreen = request.getParameter("fromScreen");
		 log.debug("FirewallIPDetailsController:viewApplications:fromScreen ---- "+fromScreen);
		 
		 if (!"APP".equalsIgnoreCase(fromScreen)) {
			request.getSession().removeAttribute("SEL_RULE");
	    	request.getSession().removeAttribute("SEL_IPS");
		 }
		 
		 if ("APP".equalsIgnoreCase(fromScreen)) {
			 result = "pages/jsp/fw/ApplicationDetails";
			 applicationDetails.setSelectedRuleId((Long)request.getSession().getAttribute("SEL_RULE"));
			 applicationDetails.setSelectedIPs((List<Long>)request.getSession().getAttribute("SEL_IPS"));
			 log.debug("FirewallIPDetailsController:viewApplications:Selcted Rule"+applicationDetails.getSelectedRuleId());
			 log.debug("FirewallIPDetailsController:viewApplications:Selcted IPs"+applicationDetails.getSelectedIPs());
		 } else if ("RULE".equalsIgnoreCase(fromScreen)) {
			 String ruleId = request.getParameter("ruleId");
			 request.getSession().setAttribute("SEL_RULE", Long.valueOf(ruleId));
			 log.debug("FirewallIPDetailsController:viewApplications:Selcted Rule"+ruleId);
			 applicationDetails.setSelectedRuleId(Long.valueOf(ruleId));
		 } else if ("IP".equalsIgnoreCase(fromScreen))  {
			 String ipId = request.getParameter("ipId");
	    	 List<Long> selectedIPs = new ArrayList<Long>();
	    	 if (ipId != null && ipId.indexOf(":") != -1) {
	    		 String[] ipArray = ipId.split(":");
	    		 for (String ip : ipArray) {
	    			 selectedIPs.add(Long.valueOf(ip));
	    		 }
	    	 } else if (ipId != null) {
	    		 selectedIPs.add(Long.valueOf(ipId));
	    	 }
	    	 request.getSession().setAttribute("SEL_IPS", selectedIPs);
			 log.debug("FirewallIPDetailsController:viewApplications:Selcted IPs"+selectedIPs);
			 applicationDetails.setSelectedIPs(selectedIPs);
		 } else if ("RULE_IP".equalsIgnoreCase(fromScreen))  {
			 String ruleId = request.getParameter("ruleId");
			 request.getSession().setAttribute("SEL_RULE", Long.valueOf(ruleId));
			 log.debug("FirewallIPDetailsController:viewApplications:Selcted Rule"+ruleId);
			 applicationDetails.setSelectedRuleId(Long.valueOf(ruleId));
			 
	    	 String ipId = request.getParameter("ipId");
	    	 List<Long> selectedIPs = new ArrayList<Long>();
	    	 if (ipId != null && ipId.indexOf(":") != -1) {
	    		 String[] ipArray = ipId.split(":");
	    		 for (String ip : ipArray) {
	    			 selectedIPs.add(Long.valueOf(ip));
	    		 }
	    	 } else if (ipId != null) {
	    		 selectedIPs.add(Long.valueOf(ipId));
	    	 }
	    	 request.getSession().setAttribute("SEL_IPS", selectedIPs);
			 log.debug("FirewallIPDetailsController:viewApplications:Selcted IPs"+selectedIPs);
			 applicationDetails.setSelectedIPs(selectedIPs);
		 }
		 applicationDetails.setOffset(0);
		 applicationDetails.setPageNo(1);
		 applicationDetails.setLimit(10);
		 
		 List<FirewallRuleApplication> firewallRuleApplications 
		 					= applicationDetails.getFirewallRuleApplications();
		 
		 int rowCount = applicationDetails.getRowCount();
			
		//To calculate no of pages
	 	int totalPages = 0;
		int limit = 10;
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}	
		
		applicationDetails.setTotalPages(totalPages);
			
		applicationDetails.setFirewallRuleAppList(firewallRuleApplications);
		model.addAttribute("applicationDetails", applicationDetails);
		log.info("FirewallIPDetailsController::viewApplications methods ends...");
		return result;
    }
    
    /*
     * To Paginate the Applications
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/paginateApplications.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String paginateApplications(HttpServletRequest request, ModelMap model, @ModelAttribute("applicationDetails") IPDetailsRequest applicationDetails) {
	    log.info("FirewallIPDetailsController::paginateApplications methods starts...");
		
	    TIRequest tiRequest = getTirequest(request);
	    Long processID = tiRequest.getTiProcess().getId();
		String type = (String)request.getParameter("type");
		
		log.debug("FirewallIPDetailsController::paginateApplications type..."+type);
		
		int curOffSet = applicationDetails.getOffset();
		int limit = applicationDetails.getLimit();
		int pageNo = applicationDetails.getPageNo();
	
		 List<Long> selectedIPs = applicationDetails.getSelectedIPs();
		 Long selectedRuleId = applicationDetails.getSelectedRuleId();
		 log.debug("FirewallIPDetailsController::Selcted IPs"+selectedIPs);
		 
		 applicationDetails = new IPDetailsRequest();
		 String con_type = (String) request.getSession().getAttribute("con_type");
			log.debug(" ConnectionType :: " + con_type);
			if("ipReg".equalsIgnoreCase(con_type))
			{
				applicationDetails.setIsIpReg("Y");
				log.debug(" IPRegistration :: " + con_type);
			}else
			{
				applicationDetails.setIsIpReg("N");
				log.debug(" Firewall :: " + con_type);
			}
		 applicationDetails.setTiRequest(getPreviousVersionTiRequestID(processID, request));
		 applicationDetails.setSelectedIPs(selectedIPs);
		 applicationDetails.setSelectedRuleId(selectedRuleId);
		 applicationDetails.setDeviceTypeList(applicationDetails.getDeviceTypes());
		 
		 applicationDetails.setLimit(limit);
		
		if ("N".equalsIgnoreCase(type)) {
			applicationDetails.setOffset(curOffSet+applicationDetails.getLimit());
			applicationDetails.setPageNo(pageNo+1);
		} else if ("P".equalsIgnoreCase(type)) {
			applicationDetails.setOffset(curOffSet-applicationDetails.getLimit());
			applicationDetails.setPageNo(pageNo-1);
		} else if ("X".equalsIgnoreCase(type)) {
			applicationDetails.setOffset(limit * (pageNo-1));
			applicationDetails.setPageNo(pageNo);
		} else if ("L".equalsIgnoreCase(type)) {
			applicationDetails.setOffset(0);
			applicationDetails.setPageNo(1);
		} else {
			applicationDetails.setOffset(0);
			applicationDetails.setPageNo(1);
		}
		
		 List<FirewallRuleApplication> firewallRuleApplications 
			= applicationDetails.getFirewallRuleApplications();

		int rowCount = applicationDetails.getRowCount();
		
		//To calculate no of pages
		int totalPages = 0;
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		
		applicationDetails.setTotalPages(totalPages);
		
		applicationDetails.setFirewallRuleAppList(firewallRuleApplications);
		
		model.addAttribute("applicationDetails", applicationDetails);
		
		log.info("FirewallIPDetailsController::paginateApplications methods ends...");
		return "pages/jsp/fw/ApplicationDetails";
    }
	
	
	 /*
     * To add the application to the ip.
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/addFWApplication.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String addFWApplication(HttpServletRequest request, ModelMap model, @ModelAttribute("applicationDetails") IPDetailsRequest applicationDetails) {
    	log.info("FirewallIPDetailsController::addApplication methods starts...");
    	List<Long> selectedIPs = applicationDetails.getSelectedIPs();
    	Long selectedRuleId = applicationDetails.getSelectedRuleId();
    	IPDetailsRequest addApplication = new IPDetailsRequest();
	    log.debug("FirewallIPDetailsController::Selcted IPs"+selectedIPs);
	    log.debug("FirewallIPDetailsController::Selcted Ruleid"+selectedRuleId);
	    addApplication.setSelectedIPs(selectedIPs);
	    addApplication.setSelectedRuleId(selectedRuleId);
	    addApplication.setDeviceTypeList(addApplication.getDeviceTypes());
	    model.addAttribute("addApplication", addApplication);
		log.info("FirewallIPDetailsController::addApplication methods ends...");
		return "/pages/jsp/fw/AddApplication";
    }
	
	/*
     * To add the application to the ip.
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/viewApplication.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String viewApplication(HttpServletRequest request, ModelMap model, @ModelAttribute("applicationDetails") IPDetailsRequest applicationDetails) {
    	log.info("FirewallIPDetailsController::editApplication methods starts...");
    	String editIndex = request.getParameter("EditIndexId");
    	request.setAttribute("EditIndexId", editIndex);
    	List<Long> selectedIPs = applicationDetails.getSelectedIPs();
    	Long selectedRuleId = applicationDetails.getSelectedRuleId();
    	IPDetailsRequest addApplication = new IPDetailsRequest();
	    log.debug("FirewallIPDetailsController::Selcted IPs"+selectedIPs);
	    FirewallRuleApplication firewallRuleApplication = addApplication.getFirewallRuleApplication(Long.valueOf(editIndex));
	    addApplication.setApplication(firewallRuleApplication.getApplication());
	    addApplication.setSelectedIPs(selectedIPs);
	    addApplication.setSelectedRuleId(selectedRuleId);
	    addApplication.setDeviceTypeList(addApplication.getDeviceTypes());
	    
	    if (firewallRuleApplication.getApplication() != null 
	    		&& "Y".equalsIgnoreCase(firewallRuleApplication.getApplication().getIsCSI())) {
	    	request.setAttribute("CSI","CSI");
	    	
	    	 if (addApplication.getApplication() != null && "YES".equalsIgnoreCase(addApplication.getApplication().getVaFlag())) {
	 	    	addApplication.setBiso_VA_Yes(addApplication.getApplication().getVaNumber());
	 	     } else if (addApplication.getApplication() != null && "NO".equalsIgnoreCase(addApplication.getApplication().getVaFlag())) { 
	 	    	addApplication.setBiso_VA_No(addApplication.getApplication().getVaNumber());
	 	    	if (addApplication.getApplication().getVaSchDate() != null) {
	 	    	addApplication.setBiso_VA_Date(addApplication.getApplication().getVaSchDate().toString());
	 	    	}
	 	     } else if (addApplication.getApplication() != null && "NR".equalsIgnoreCase(addApplication.getApplication().getVaFlag())) {
	 	    	addApplication.setBiso_VA_NR_Comments(addApplication.getApplication().getVaComments());
	 	     }
	    }
		model.addAttribute("addApplication", addApplication);
		log.info("FirewallIPDetailsController::editApplication methods ends...");
		return "pages/jsp/fw/AddApplication";
    }
    
    /*
     * To add the application to the ip.
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/removeApplications.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String removeApplications(HttpServletRequest request, ModelMap model, @ModelAttribute("applicationDetails") IPDetailsRequest applicationDetails) {
    	log.info("FirewallIPDetailsController::removeApplications methods starts...");
    	TIRequest tiRequest = getTirequest(request);
 		applicationDetails.setTiRequest(tiRequest.getId());
    	applicationDetails.deleteFirewallRuleApplications();
		log.info("FirewallIPDetailsController::removeApplications methods ends...");
		return "forward:/viewApplications.act?fromScreen=APP";
    }
	
	 /*
     * To save the application
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/saveApplication.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String saveApplication(HttpServletRequest request, ModelMap model, @ModelAttribute("addApplication") IPDetailsRequest addApplication) {
    	log.info("FirewallIPDetailsController::saveApplication methods starts...");
    	List<Long> selectedIPs = addApplication.getSelectedIPs();
    	Long selectedRuleId = addApplication.getSelectedRuleId();
    	
    	TIRequest tiRequest = getTirequest(request);
		addApplication.setTiRequest(tiRequest.getId());
		addApplication.setTiProcess(tiRequest.getTiProcess().getId());
		
		
		String con_type = (String) request.getSession().getAttribute("con_type");
		log.debug(" ConnectionType :: " + con_type);
		if("ipReg".equalsIgnoreCase(con_type))
		{
			addApplication.setIsIpReg("Y");
			log.debug(" IPRegistration :: " + con_type);
		}else
		{
			addApplication.setIsIpReg("N");
			log.debug(" Firewall :: " + con_type);
		}
		
		Application application = addApplication.getApplication();
		application = loadApplicationDetails(application, addApplication, request);
		List<FirewallRuleApplication> firewallRuleApplications =
			new ArrayList<FirewallRuleApplication>();
		IPAddress ipAddress = null;
		FirewallRuleApplication firewallRuleApplication = null;
		if (selectedRuleId != null && selectedRuleId.longValue() > 0
				&& selectedIPs!= null && selectedIPs.size() >0) {
    		FireWallRule fireWallRule = new FireWallRule();
    		fireWallRule.setId(selectedRuleId);
    		log.debug("FirewallIPDetailsController:saveApplication:Selcted Ruleid"+selectedRuleId);
    		log.debug("FirewallIPDetailsController:saveApplication:selectedIPs"+selectedIPs);
    		for (Long ip : selectedIPs) {
	    		ipAddress = new IPAddress();
	    		ipAddress.setId(ip);
    			firewallRuleApplication = new FirewallRuleApplication();
    			firewallRuleApplication.setFireWallRule(fireWallRule);
    			firewallRuleApplication.setApplication(application);
        		firewallRuleApplication.setIpAddress(ipAddress);
        		firewallRuleApplication.setTiRequest(tiRequest);
        		firewallRuleApplication.setUpdatedTIRequest(tiRequest);
        		firewallRuleApplications.add(firewallRuleApplication);
    		}
		} else if (selectedRuleId != null && selectedRuleId.longValue() > 0) {
    		List<IPAddress> ipAddressList = addApplication.getIPsByFirewallRuleId();
    		FireWallRule fireWallRule = new FireWallRule();
    		fireWallRule.setId(selectedRuleId);
    		log.debug("FirewallIPDetailsController:saveApplication:Selcted Ruleid"+selectedRuleId);
    		for (IPAddress ipAddr : ipAddressList) {
    			firewallRuleApplication = new FirewallRuleApplication();
    			firewallRuleApplication.setFireWallRule(fireWallRule);
    			firewallRuleApplication.setApplication(application);
        		firewallRuleApplication.setIpAddress(ipAddr);
        		firewallRuleApplication.setTiRequest(tiRequest);
        		firewallRuleApplication.setUpdatedTIRequest(tiRequest);
        		firewallRuleApplications.add(firewallRuleApplication);
    		}
    	} else {
    		log.debug("FirewallIPDetailsController:saveApplication:selectedIPs"+selectedIPs);
			for (Long ip : selectedIPs) {
	    		ipAddress = new IPAddress();
	    		ipAddress.setId(ip);
	    		addApplication.setIpAddress(ipAddress);
	    		List<FireWallRule> firewallRules  = addApplication.getFirewallRulesByIPId();
	    		for (FireWallRule fireWallRule : firewallRules) {
	    			firewallRuleApplication = new FirewallRuleApplication();
	    			firewallRuleApplication.setFireWallRule(fireWallRule);
	    			firewallRuleApplication.setApplication(application);
	        		firewallRuleApplication.setIpAddress(ipAddress);
	        		firewallRuleApplication.setTiRequest(tiRequest);
	        		firewallRuleApplication.setUpdatedTIRequest(tiRequest);
	        		firewallRuleApplications.add(firewallRuleApplication);
	    		}
	    	}
    	}
		
    	addApplication.setFirewallRuleAppList(firewallRuleApplications);   	
    	addApplication.saveFirewallRuleApplications();	
		log.info("FirewallIPDetailsController::saveApplication methods ends...");						
		return "forward:/viewApplications.act?fromScreen=APP";
    }
	
	
	 /*
     * To add the application to the ip.
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/loadCSIDetails.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String loadCSIDetails(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallIPDetailsController::loadCSIDetails methods starts...");
    	Long selectedRuleId = null;
    	List<Long> selectedIPs = null;
    	
    	if (request.getSession().getAttribute("SEL_IPS") != null) {
    		selectedIPs = (ArrayList<Long>)request.getSession().getAttribute("SEL_IPS");
    	}
    	if (request.getSession().getAttribute("SEL_RULE") != null) {
    		selectedRuleId = (Long)request.getSession().getAttribute("SEL_RULE");
    	}
    	
    	request.setAttribute("CSI","CSI");
    	IPDetailsRequest addApplication = new IPDetailsRequest();
	    log.debug("FirewallIPDetailsController::Selcted IPs"+selectedIPs);
	    addApplication.setSelectedIPs(selectedIPs);
	    addApplication.setSelectedRuleId(selectedRuleId);
	    addApplication.setDeviceTypeList(addApplication.getDeviceTypes());
	    addApplication.setApplication(new Application());
	    addApplication.getApplication().setIsDevice("N");
	    addApplication.getApplication().setIsCSI("Y");
	    if(request.getSession().getAttribute("COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY")!=null ){
	    	CitiResource citiResourceEntity = (CitiResource)request.getSession().
		    						getAttribute("COM_CITIGROUP_CGTI_C3PAR_CITI_RESOURCE_ENTITY");
		    addApplication.getApplication().setApplicationID(Long.valueOf(citiResourceEntity.getCwhiId()));
		    addApplication.getApplication().setApplicationName(citiResourceEntity.getName());
		    addApplication.getApplication().setFunction(citiResourceEntity.getFunctionalityDescription());
		    addApplication.getApplication().getAppOwner().setFullName(citiResourceEntity.getOwner());
		    if(citiResourceEntity.getClassification() != null){
		    	addApplication.getApplication().setSecClassification(citiResourceEntity.getClassification());
		    }
		    addApplication.getApplication().setPerDataIndicator(citiResourceEntity.getPersonalDataIndicator());
		    if((citiResourceEntity.getOwnerid()== null) || citiResourceEntity.getOwnerid().equalsIgnoreCase("NULL")) {
		    	addApplication.getApplication().getAppOwner().setGeid("");
		    } else {
		    	addApplication.getApplication().getAppOwner().setGeid(citiResourceEntity.getOwnerid());
		    }
		}
	    model.addAttribute("addApplication",addApplication);
		log.info("FirewallIPDetailsController::loadCSIDetails methods ends...");
		return "pages/jsp/fw/AddApplication";
    }
	
	/*
     * To save the application
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/editApplication.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String editApplication(HttpServletRequest request, ModelMap model, @ModelAttribute("addApplication") IPDetailsRequest addApplication) {
    	log.info("FirewallIPDetailsController::editApplication methods starts...");
    	List<Long> selectedIPs = addApplication.getSelectedIPs();
    	Long selectedRuleId = addApplication.getSelectedRuleId();
    	List<Long> selectedRuleIds = new ArrayList<Long>();
    	
    	String con_type = (String) request.getSession().getAttribute("con_type");
		log.debug(" ConnectionType :: " + con_type);
		if("ipReg".equalsIgnoreCase(con_type))
		{
			addApplication.setIsIpReg("Y");
			log.debug(" IPRegistration :: " + con_type);
		}else
		{
			addApplication.setIsIpReg("N");
			log.debug(" Firewall :: " + con_type);
		}
    	
		TIRequest tiRequest = getTirequest(request);
	    Long processID = tiRequest.getTiProcess().getId();
		addApplication.setTiRequest(tiRequest.getId());
		addApplication.setTiProcess(processID);
		IPAddress ipAddress = null;
		Application application = addApplication.getApplication();
		application = loadApplicationDetails(application, addApplication, request);
				
		if (selectedRuleId != null && selectedRuleId.longValue() > 0
				&& selectedIPs!= null && selectedIPs.size() >0) {
    		selectedRuleIds.add(selectedRuleId);
		} else if (selectedRuleId != null && selectedRuleId.longValue() > 0) {
    		List<IPAddress> ipAddressList = addApplication.getIPsByFirewallRuleId();
    		FireWallRule fireWallRule = new FireWallRule();
    		fireWallRule.setId(selectedRuleId);    		
    		for (IPAddress ipAddr : ipAddressList) {    			
    			selectedIPs.add(ipAddr.getId());
    		}
    		selectedRuleIds.add(selectedRuleId);
    	} else {
    		for (Long ip : selectedIPs) {
	    		ipAddress = new IPAddress();
	    		ipAddress.setId(ip);
	    		addApplication.setIpAddress(ipAddress);
	    		List<FireWallRule> firewallRules  = addApplication.getFirewallRulesByIPId();
	    		for (FireWallRule fireWallRule : firewallRules) {	    			
	    			selectedRuleIds.add(fireWallRule.getId());	    			
	    		}
    		}
    	}
		log.debug("FirewallIPDetailsController:editApplication:Selcted Ruleid"+selectedRuleIds);
		log.debug("FirewallIPDetailsController:editApplication:selectedIPs"+selectedIPs);
		
		application = addApplication.checkApplicationExists(application);
		addApplication.editFirewallRuleApplications(application, selectedIPs, selectedRuleIds);
		log.info("FirewallIPDetailsController::editApplication methods ends...");						
		return "forward:/viewApplications.act?fromScreen=APP";
    }
    
	
	//To Load the Application Details
    /**
     * 
     * @param application
     * @return
     */
    private Application loadApplicationDetails(Application application, IPDetailsRequest addApplication, HttpServletRequest request) {
		if (application != null && application.getDeviceTypeId() != null && application.getDeviceTypeId().longValue() == 0) {
		    application.setDeviceTypeId(null);
		}
	
		if (application != null && application.getApplicationID() != null && application.getApplicationID().longValue() == 0) {
		    application.setApplicationID(null);
		}
	
		if ((application != null) && !application.isEmpty()) {
		    if (application.getAppOwner() != null) {
				application.setAppOwnerFullName(application.getAppOwner().getFullName());
				application.setAppOwnerEmail(application.getAppOwner().getEmailAddress());
				application.setAppOwnerGEID(application.getAppOwner().getGeid());
				if(application.getIsCSI()!= null && application.getIsCSI().equalsIgnoreCase("Y")
					&& request.getSession().getAttribute("APP_OWNER_EMAIL") != null) {
				    application.setAppOwnerEmail((String)request.getSession().getAttribute("APP_OWNER_EMAIL"));
				} else {
				    application.setAppOwnerEmail(null);
				}
		    }
		    log.debug("FirewallIPDetailsController::loadApplicationDetails ....VAFLAG"+application.getVaFlag());
	
		    if(application.getVaFlag()!=null && application.getVaFlag().equalsIgnoreCase("YES")){
		    	 log.debug("FirewallIPDetailsController::loadApplicationDetails ....VANO"+addApplication.getBiso_VA_Yes());
		    	 application.setVaNumber(addApplication.getBiso_VA_Yes());
		    }
		    if(application.getVaFlag()!=null && application.getVaFlag().equalsIgnoreCase("NO")){
				if(addApplication.getBiso_VA_No()!=null){
					log.debug("FirewallIPDetailsController::loadApplicationDetails ....VANO"+addApplication.getBiso_VA_No());
				    application.setVaNumber(addApplication.getBiso_VA_No());
				}
				if (addApplication.getBiso_VA_Date()!=null){
					log.debug("FirewallIPDetailsController::loadApplicationDetails ....VADATE"+addApplication.getBiso_VA_Date());
				    application.setVaSchDate(new Date(addApplication.getBiso_VA_Date()));
				}
		    }
		    if(application.getVaFlag()!=null && application.getVaFlag().equalsIgnoreCase("NR")){
				if (addApplication.getBiso_VA_NR_Comments()!=null){
				    application.setVaComments(addApplication.getBiso_VA_NR_Comments());
				}
		    }
	
		    if(application.getIsCSI()!= null && application.getIsCSI().equalsIgnoreCase("Y")){
	
				if(request.getSession().getAttribute("APP_MGR_EMAIL") != null) {
				    String managerEmail = (String)request.getSession().getAttribute("APP_MGR_EMAIL");
				    application.setAppManagerEmail(managerEmail);
				    log.debug("managerEmail : "+managerEmail);
				}
				if(request.getSession().getAttribute("APP_MGR_FULL_NAME") != null){
				    String appManagerFullName = (String)request.getSession().getAttribute("APP_MGR_FULL_NAME");
				    application.setAppManagerFullName(appManagerFullName);
				    log.debug("appManagerFullName : "+appManagerFullName);
				}
				if(request.getSession().getAttribute("APP_MGR_GEID") != null){
				    String appManagerGEID = (String)request.getSession().getAttribute("APP_MGR_GEID");
				    application.setAppManagerGEID(appManagerGEID);
				    log.debug("appManagerGEID : "+appManagerGEID);
				}
		    }else {
				application.setAppOwnerEmail(null);
				application.setAppManagerGEID(null);
				application.setAppManagerFullName(null);
		    }
		}
		return application;
    }
    
    @RequestMapping(value = "/getIpDetlsCompleteFlag.act", method = { RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody String getIpDetlsCompleteFlag(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallIPDetailsController.getIpDetlsCompleteFlag.starts");
    	String isIPDetailsComplete = "FALSE";
    	TIRequest tiRequestEntity = null;
    	String con_type= "";
		if(request.getSession().getAttribute("con_type") != null){
			con_type = (String) request.getSession().getAttribute("con_type");
		}
		
    	FireWallRuleProcess completeCheck = new FireWallRuleProcess();
    	if(request.getSession().getAttribute("TI_REQUEST_ENTITY") != null){
    		tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
    		log.debug("FirewallIPDetailsController.getIpDetlsCompleteFlag.tirequestid::"+tiRequestEntity.getId());
    		completeCheck.setTiRequest(tiRequestEntity.getId());
    		
    		// IP Details Tab
    		if (completeCheck.completeCheckIPDetails(completeCheck,con_type)) {
    			log.debug("Inside completeCheckIPDetails block::");
    			isIPDetailsComplete = "TRUE";
    		}
    	}
    	log.debug("FirewallIPDetailsController.getIpDetlsCompleteFlag.isIPDetailsComplete::"+isIPDetailsComplete);
    	
	    log.info("FirewallIPDetailsController.getIpDetlsCompleteFlag.ends");
	    
	    return isIPDetailsComplete;
		
    }
	
	}
