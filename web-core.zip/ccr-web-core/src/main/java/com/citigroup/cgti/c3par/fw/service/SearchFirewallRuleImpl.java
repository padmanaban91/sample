package com.citigroup.cgti.c3par.fw.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.IPRegACL;
import com.citigroup.cgti.c3par.fw.domain.PersonalObject;
import com.citigroup.cgti.c3par.fw.domain.PersonalObjectIP;
import com.citigroup.cgti.c3par.fw.domain.PersonalObjectPort;
import com.citigroup.cgti.c3par.fw.domain.Port;
import com.citigroup.cgti.c3par.fw.domain.SearchFirewallRuleRequest;
import com.citigroup.cgti.c3par.fw.domain.soc.persist.SearchFirewallRulePersistable;
import com.citigroup.cgti.c3par.util.C3parStaticNames;

/**
 * 
 * @author ne36745
 *
 */
public class SearchFirewallRuleImpl extends FirewallRuleProcessImpl implements
		SearchFirewallRulePersistable {
	
	 /** The log. */
	private static Logger log = Logger.getLogger(SearchFirewallRuleImpl.class);
    
    @SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
    public List<PersonalObject> listPersonalObjectIPs(SearchFirewallRuleRequest searchFirewallRuleRequest) {
    	Session session = getSession();
		Criteria criteria = session.createCriteria(PersonalObject.class);
		
    	if (searchFirewallRuleRequest.getFilterText()!= null
    			&& !searchFirewallRuleRequest.getFilterText().isEmpty()) {
    		criteria.add(Restrictions.ilike("objectName", searchFirewallRuleRequest.getFilterText(),
				    MatchMode.ANYWHERE));
    	}
    	criteria.add(Restrictions.eq("type", "IP"));
    	criteria.add(Restrictions.ne("isDeleted", "Y"));
    	
    	criteria.addOrder(Order.asc("id"));
    	searchFirewallRuleRequest.setRowCount(getRowCount(criteria));
		addPagination(criteria, searchFirewallRuleRequest.getOffset(), 10);
    	List<PersonalObject> personalObjects = (List<PersonalObject>)criteria.list();
    	return personalObjects;
    }
    
    
    @Transactional(readOnly = true)
    public List<IPRegACL> getIpRegACL(SearchFirewallRuleRequest fwRuleProcess) {
   	   log.info("FireWallRuleProcessImpl::getIPRegACL methods starts..."+fwRuleProcess.getTiRequest());
   	   
   	   Session session = getSession();
   	   String userType = "";
   	   String filterText = "";
   	   if(C3parStaticNames.THIRD_PARTY.equals(fwRuleProcess.getRelationshipType())){
   		   userType="EXTERNAL";
   	   }
   	   else{
   		   userType="INTERNAL";
   	   }
   	   if(fwRuleProcess.getFilterText() != null && !fwRuleProcess.getFilterText().isEmpty()){
   		filterText = fwRuleProcess.getFilterText();  
   	   }
   	   String sql = "select distinct ID, ACL, USER_TYPE  from IP_ACL_ASSIGNMENT_MASTER where IS_ACTIVE = 'Y' and USER_TYPE = '" +userType+ "' and ACL like '%" +filterText+ "%' ORDER BY UPPER(ACL)";
  		
  	  log.debug("IPDetailsServiceImpl::loadIPDetails query - >"+sql.toString());
   	  SQLQuery query = session.createSQLQuery(sql.toString());
   	  
   	  query.addScalar("id", LongType.INSTANCE);
   	  query.addScalar("acl", StringType.INSTANCE);
   	  query.addScalar("user_type", StringType.INSTANCE);
   	  
   	  int rowCount = getRowCount(sql.toString());
   	  fwRuleProcess.setRowCount(rowCount);
   	  addPagination(query, fwRuleProcess.getOffset(), 10);
   		
   	 // List<IPAddress> list = query.list();
  	 List<IPRegACL> ipList = new ArrayList<IPRegACL>();
  	 IPRegACL ipACL = null;
  	   
  	  
 	 List<Object[]> rows = (List<Object[]>)query.list();
 	
 	 if(rows != null){
 		for (Object[] obj : rows) {
 			ipACL = new IPRegACL();
 			ipACL.setId((Long)obj[0]);
 			ipACL.setAccessType((String)obj[1]);
 			ipACL.setUserType((String)obj[2]);
 			ipList.add(ipACL);
 		}
 	 }
  	 
  	
   	  log.info("FireWallRuleProcessImpl::getIPRegACL methods ends...");
   	  return ipList;
      }
     
    
    @SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
    public List<PersonalObject> listPersonalObjectPorts(SearchFirewallRuleRequest searchFirewallRuleRequest) {
    	Session session = getSession();
		Criteria criteria = session.createCriteria(PersonalObject.class);
		
    	if (searchFirewallRuleRequest.getFilterText()!= null
    			&& !searchFirewallRuleRequest.getFilterText().isEmpty()) {
    		criteria.add(Restrictions.ilike("objectName", searchFirewallRuleRequest.getFilterText(),
				    MatchMode.ANYWHERE));
    	}
    	criteria.add(Restrictions.eq("type", "PRT"));
    	criteria.add(Restrictions.ne("isDeleted", "Y"));
    	
    	criteria.addOrder(Order.asc("id"));
    	searchFirewallRuleRequest.setRowCount(getRowCount(criteria));
		addPagination(criteria, searchFirewallRuleRequest.getOffset(), 10);
    	List<PersonalObject> personalObjects = (List<PersonalObject>)criteria.list();
    	return personalObjects;
    }

    @Override
    public void savePersonalObjects(SearchFirewallRuleRequest searchFirewallRuleRequest) {
	    	identifyExisitingIPs(searchFirewallRuleRequest.getPersonalObject());
	    	getHibernateTemplate().saveOrUpdate(searchFirewallRuleRequest.getPersonalObject());
    }
    
    @Override
    public void savePersonalObjectsPort(SearchFirewallRuleRequest searchFirewallRuleRequest) {
    		identifyExisitingPorts(searchFirewallRuleRequest.getPersonalObject());
	    	getHibernateTemplate().saveOrUpdate(searchFirewallRuleRequest.getPersonalObject());
    }
    
    @Override
    @Transactional(readOnly = true)
    public PersonalObject validatePersonalObject(PersonalObject personalObject) {
    	FirewallRuleValidator firewallRuleValidator = new FirewallRuleValidator();
    	for (PersonalObjectIP personalObjectIP : personalObject.getPersonalObjectIPs()) {
    		IPAddress orgIPAddress =  firewallRuleValidator.validateAndFormatIPAddress(personalObjectIP.getIpAddress(), 
    				personalObjectIP.getNAT(), null);
    		personalObjectIP.setIpAddress(orgIPAddress);
    	}
    	personalObject.getValidationErrors().addAll(firewallRuleValidator.getValidationErrors());
    	if (isObjectAlreadyExists(personalObject.getObjectName())) {
    		personalObject.getValidationErrors().add("Object Name already exists");
    	}
    	return personalObject;
    }
    
    @Override
    @Transactional(readOnly = true)
    public PersonalObject validatePersonalObjectPort(PersonalObject personalObject) {
    	FirewallRuleValidator firewallRuleValidator = new FirewallRuleValidator();
    	for (PersonalObjectPort personalObjectPort : personalObject.getPersonalObjectPorts()) {
    		Port port =  firewallRuleValidator.validatePort(personalObjectPort.getPort());
    		personalObjectPort.setPort(port);
    	}
    	personalObject.getValidationErrors().addAll(firewallRuleValidator.getValidationErrors());
    	if (isObjectAlreadyExists(personalObject.getObjectName())) {
    		personalObject.getValidationErrors().add("Object Name already exists");
    	}
    	return personalObject;
    }
    
    private boolean isObjectAlreadyExists(String objectName) {
    	String queryString = "select count(*) as count from personal_objects where " +
    			"upper(object_name) = upper('"+objectName+"')";
    	
    	SQLQuery sqlquery =  getSession().createSQLQuery(queryString);
    	sqlquery.addScalar("count", IntegerType.INSTANCE);
    	Integer count  = (Integer)sqlquery.uniqueResult();
    	
    	if (count != null && count.intValue() > 0) {
    		return true;
    	} else {
    		return false;
    	}
    }
    
    @SuppressWarnings("unchecked")
	private void identifyExisitingIPs(PersonalObject personalObject) {
    	
    	List<IPAddress> ipAddress = null;
    	Session session = getSession();
    	for (PersonalObjectIP personalObjectIP : personalObject.getPersonalObjectIPs()) {
    		
    		if (!(personalObjectIP.getId() != null
    				&& personalObjectIP.getId().longValue() > 0)) {
    			IPAddress orgIPAddress = personalObjectIP.getIpAddress();
    			
    			if (orgIPAddress.getIpAddress().indexOf("-") != -1) {
					ipAddress = (List<IPAddress>) session.createQuery(
						    "from IPAddress ip where ip.formattedStartIP = '"
							    + orgIPAddress.getFormattedStartIP() + "' and ip.formattedEndIP = '"
								    + orgIPAddress.getFormattedEndIP() + "'").list();
				} else if (orgIPAddress.getIpAddress().indexOf("/") != -1) {
					ipAddress = (List<IPAddress>) session.createQuery(
						    "from IPAddress ip where ip.ipAddress = '"
							    + orgIPAddress.getIpAddress() + "' and ip.formattedStartIP = '"
							    + orgIPAddress.getFormattedStartIP() + "' and ip.formattedEndIP = '"
								    + orgIPAddress.getFormattedEndIP() + "'").list();
				} else {
						ipAddress = (List<IPAddress>) session.createQuery(
							    "from IPAddress ip where ip.formattedIP = '"
								    + orgIPAddress.getFormattedIP() + "'").list();
					}
    			
    			 if (ipAddress != null && !ipAddress.isEmpty()) {
    				 personalObjectIP.setIpAddress(ipAddress.get(0));
    			 } else {
    				 personalObjectIP.setIpAddress(orgIPAddress);
    				 getHibernateTemplate().save(orgIPAddress);
    			 }
    			
				}
    		}
    }
    
    @SuppressWarnings("unchecked")
	private void identifyExisitingPorts(PersonalObject personalObject) {
    	
    	List<Port> port = null;
    	Session session = getSession();
    	for (PersonalObjectPort personalObjectPort : personalObject.getPersonalObjectPorts()) {
    		if (!(personalObjectPort.getId() != null
    				&& personalObjectPort.getId().longValue() > 0)) {
    			StringBuffer queryStr = new StringBuffer();
    			queryStr.append("from Port pt where pt.portNumber = '"
							+ personalObjectPort.getPort().getPortNumber() +
							"' and pt.protocol = '"
							+ personalObjectPort.getPort().getProtocol()+
							"' and pt.flowOfData = '"
							+ personalObjectPort.getPort().getFlowOfData()+"'");
		
				    if (personalObjectPort.getPort().getControlMsgId() != null
					    && personalObjectPort.getPort().getControlMsgId()
						    .longValue() > 0) {
					queryStr.append(" and pt.controlMsgId = '"
						+ personalObjectPort.getPort().getControlMsgId()
						+ "'");
				    }
    			
				    	port = (List<Port>) session.createQuery(
						    queryStr.toString()).list();
					    if (port != null && !port.isEmpty()) {
					    	personalObjectPort.setPort(port.get(0));
					    } else {
					    	 getHibernateTemplate().save(personalObjectPort.getPort());
					    }
    			
				}
    		}
    }
    
    @Override
    @Transactional(readOnly = true)
    public PersonalObject findPersonalObject(SearchFirewallRuleRequest searchFirewallRuleRequest) {
    	
    	return (PersonalObject)getSession().createQuery("from PersonalObject where id="
    						+searchFirewallRuleRequest.getObjectId()).uniqueResult();
    }
    

}
