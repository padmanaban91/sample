/**
 *
 */
package com.citigroup.cgti.c3par.reports.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.type.DoubleType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.reports.domain.FirewallReport;
import com.citigroup.cgti.c3par.reports.domain.RiskRatingReport;
import com.citigroup.cgti.c3par.reports.domain.soc.persist.RiskRatingReportServicePersistable;

/**
 * @author pc79439
 * 
 */
@SuppressWarnings("unchecked")
@Transactional
public class RiskRatingReportServiceImpl extends BasePersistanceImpl implements
		RiskRatingReportServicePersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(RiskRatingReportServiceImpl.class);

	//get result for the report - Risk Rating Dashboard -> RiskRating by Vendor ParentID
	//													-> RiskRating by Vendor CASPID
	//													-> RiskRating by Vendor DetailID
	@Override
	@Transactional(readOnly = true)
	public List<RiskRatingReport> getVendorList(String vendorName, String type, String export){
		Session session = getSession();
		log.debug("Into getVendorList method");
		String parent_name_search = "";
		String casp_name_search = "";
		String detail_name_search = "";
		if(vendorName!=null){
		parent_name_search = "where thp.parent_id in (select parent_id from third_party where thp.parent_name like UPPER('%"+vendorName.trim()+"%')) ";
		casp_name_search = "where thp.casp_id in (select casp_id from third_party where thp.name like UPPER('%"+vendorName.trim()+"%')) ";
		detail_name_search = "where thp.detail_id in (select detail_id from third_party where thp.name like UPPER('%"+vendorName.trim()+"%')) ";
		}
		String parent_columns = "thp.parent_id tid, thp.parent_name name from ";
		String casp_columns ="thp.casp_id tid, thp.name name from ";
		String detail_columns = "thp.detail_id tid, thp.name name from ";
		StringBuilder condition = new StringBuilder("");
		
  		condition.append("select b.srr,b.name,qw.crc,v.cpc,d.cp,b.tpi ");
  		if("casp".equalsIgnoreCase(type) || "detail".equalsIgnoreCase(type)){
  			condition.append(",b.pid ");
  		}
  		if("detail".equalsIgnoreCase(type)){
  			condition.append(",b.cid ");
  		}
  		//risk column 
  		condition.append("from ((select  round(sum(a.cr),2) srr,a.name name,a.tpi ");
  		if("casp".equalsIgnoreCase(type) || "detail".equalsIgnoreCase(type)){
  			condition.append(",a.pid ");
  		}
  		if("detail".equalsIgnoreCase(type)){
  			condition.append(",a.cid ");
  		}
  		condition.append("from (select cfrq.calculated_risk cr, ");
  		if("parent".equalsIgnoreCase(type)){
  			condition.append("thp.parent_id tpi, thp.parent_name name ");
  		}else if("casp".equalsIgnoreCase(type)){
  			condition.append("thp.casp_id tpi, thp.name name,thp.parent_id pid ");
  		}else if("detail".equalsIgnoreCase(type)){
  			condition.append("thp.detail_id tpi, thp.name name,thp.parent_id pid,thp.casp_id cid ");
  		}
  		condition.append("from third_party thp join relationship r on thp.id=r.third_party_id "+
  				"join ti_process tp on tp.relationship_id=r.id "+
  				"join ti_request tr on tp.id=tr.process_id "+
  				"join con_fw_rule cfr on cfr.ti_request_id=tr.id "+
  				"join con_fw_rule_questionnaire cfrq on cfrq.fw_rule_id=cfr.id and cfrq.deleted_ti_request_id is null and cfr.deleted_ti_request_id is null ");
  		if(vendorName != null && "parent".equalsIgnoreCase(type)){
  			condition.append(parent_name_search);
  		}else if(vendorName != null && "casp".equalsIgnoreCase(type)){
  			condition.append(casp_name_search);
  		}else if(vendorName != null && "detail".equalsIgnoreCase(type)){
  			condition.append(detail_name_search);
  		}
		condition.append(")a group by  a.tpi,a.name ");
		if("casp".equalsIgnoreCase(type) || "detail".equalsIgnoreCase(type)){
			condition.append(",a.pid ");	
		}if("detail".equalsIgnoreCase(type)){
			condition.append(",a.cid ");
		}	
		condition.append("order by sum(a.cr) desc)b ");
  		
  		//port count
  		condition.append("join (select sum(port.port_count) cpc,port.tid from (select distinct port.port_count,port.port_number, ");
  		if("parent".equalsIgnoreCase(type)){
  			condition.append(parent_columns);
  		}else if("casp".equalsIgnoreCase(type)){
  			condition.append(casp_columns);
  		}else if("detail".equalsIgnoreCase(type)){
  			condition.append(detail_columns);
  		}
  		condition.append("third_party thp join relationship r on thp.id=r.third_party_id "+
  				"join ti_process tp on tp.relationship_id=r.id "+
  				"join ti_request tr on tp.id=tr.process_id "+
  				"join con_fw_rule cfr on cfr.ti_request_id=tr.id "+
  				"join con_fw_rule_port prt ON cfr.id = prt.rule_id "+ 
  				"join con_port_lookup port  ON prt.PORT_id = port.id and cfr.deleted_ti_request_id is null and prt.deleted_ti_request_id is null ");
		if(vendorName != null  && "parent".equalsIgnoreCase(type)){
			condition.append(parent_name_search);
  		}else if(vendorName != null  && "casp".equalsIgnoreCase(type)){
  			condition.append(casp_name_search);
  		}else if(vendorName != null  && "detail".equalsIgnoreCase(type)){
  			condition.append(detail_name_search);
  		}
  		condition.append(") port group by port.tid)v on v.tid = b.tpi ");
  		
		//ip count
		condition.append("JOIN (SELECT SUM(sour.asd) cp,sour.tid FROM (SELECT distinct case when cim.no_of_host is null then 1 else cim.no_of_host end asd,cim.ip_address, ");
  		if("parent".equalsIgnoreCase(type)){
  			condition.append(parent_columns);
  		}else if("casp".equalsIgnoreCase(type)){
  			condition.append(casp_columns);
  		}else if("detail".equalsIgnoreCase(type)){
  			condition.append(detail_columns);
  		}
		condition.append("third_party thp join relationship r on thp.id=r.third_party_id "+
				"join ti_process tp on tp.relationship_id =r.id JOIN ti_request tr ON tp.id=tr.process_id "+
				"JOIN con_fw_rule cfr ON cfr.ti_request_id=tr.id "+
				"join con_fw_rule_source_ip cfsi on cfsi.rule_id=cfr.id "+
				"join con_ip_master cim on cfsi.ip_id=cim.id  "+
				"join resourcetype r on r.id=cfr.src_nwzone_id and r.perimeter = 'Internal' "+
				"and cfr.deleted_ti_request_id is null and cfsi.deleted_ti_request_id is null ");	
		if(vendorName != null  && "parent".equalsIgnoreCase(type)){
			condition.append(parent_name_search);
  		}else if(vendorName != null  && "casp".equalsIgnoreCase(type)){
  			condition.append(casp_name_search);
  		}else if(vendorName != null  && "detail".equalsIgnoreCase(type)){
  			condition.append(detail_name_search);
  		}
		condition.append("UNION SELECT DISTINCT  case when cima.no_of_host is null then 1	else cima.no_of_host end asdf,cima.ip_address, ");
  		if("parent".equalsIgnoreCase(type)){
  			condition.append(parent_columns);
  		}else if("casp".equalsIgnoreCase(type)){
  			condition.append(casp_columns);
  		}else if("detail".equalsIgnoreCase(type)){
  			condition.append(detail_columns);
  		}
		condition.append("third_party thp join relationship r on thp.id=r.third_party_id "+
			"join ti_process tp on tp.relationship_id =r.id JOIN ti_request tr ON tp.id=tr.process_id "+
			"JOIN con_fw_rule cfr ON cfr.ti_request_id=tr.id "+
			"join con_fw_rule_destination_ip cfdi on cfdi.rule_id=cfr.id "+
			"join con_ip_master cima on cfdi.ip_id=cima.id  "+
			"join resourcetype r on r.id=cfr.dst_nwzone_id and r.perimeter = 'Internal' "+
			"and cfr.deleted_ti_request_id is null and cfdi.deleted_ti_request_id is null ");
		if(vendorName != null  && "parent".equalsIgnoreCase(type)){
			condition.append(parent_name_search);
  		}else if(vendorName != null  && "casp".equalsIgnoreCase(type) ){
  			condition.append(casp_name_search);
  		}else if(vendorName != null  && "detail".equalsIgnoreCase(type)){
  			condition.append(detail_name_search);
  		}
		condition.append(") sour GROUP BY sour.tid)d ON d.tid = v.tid ");
		
		//risk port count
		condition.append("join (select count(w.risk_code) crc,w.tid from (select  distinct rd.risk_code, ");
		if("parent".equalsIgnoreCase(type)){
  			condition.append(parent_columns);
  		}else if("casp".equalsIgnoreCase(type)){
  			condition.append(casp_columns);
  		}else if("detail".equalsIgnoreCase(type)){
  			condition.append(detail_columns);
  		}				
		condition.append("third_party thp join relationship r on thp.id=r.third_party_id "+
		"join ti_process tp on tp.relationship_id=r.id "+
		"join ti_request tr on tp.id=tr.process_id "+
		"join con_fw_rule cfr on cfr.ti_request_id=tr.id "+ 
		"join con_fw_rule_questionnaire cfrq on cfrq.fw_rule_id=cfr.id "+ 
		"join con_fw_rule_ostia_question cfroq on cfroq.fw_rule_qnnaire_id=cfrq.id "+ 
		"join ostia_question oq on cfroq.question_id=oq.id "+
		"join risk_definition rd on oq.risk_definition_id=rd.id and rd.risk_code not in ('NO_RISK','RISK_GENERIC') and cfr.deleted_ti_request_id is null "+
		"and cfroq.deleted_ti_request_id is null and cfrq.deleted_ti_request_id is null ");
		if(vendorName != null && "parent".equalsIgnoreCase(type)){
			condition.append(parent_name_search);
		}else if(vendorName != null && "casp".equalsIgnoreCase(type)){
			condition.append(casp_name_search);
		}else if(vendorName != null && "detail".equalsIgnoreCase(type)){
			condition.append(detail_name_search);
		}
		condition.append(")w group by  w.tid )qw  on v.tid = qw.tid )where b.srr is not null order by b.srr desc "); 
  		SQLQuery sqlQuery = session.createSQLQuery(condition.toString());	
  		sqlQuery.addScalar("srr", DoubleType.INSTANCE);
		sqlQuery.addScalar("name", StringType.INSTANCE);
		sqlQuery.addScalar("crc", LongType.INSTANCE);
		sqlQuery.addScalar("cpc", LongType.INSTANCE);
		sqlQuery.addScalar("cp", LongType.INSTANCE);
		sqlQuery.addScalar("tpi", LongType.INSTANCE);
		if("casp".equalsIgnoreCase(type) || "detail".equalsIgnoreCase(type)){
		sqlQuery.addScalar("pid",LongType.INSTANCE);
		}
		if("detail".equalsIgnoreCase(type)){
		sqlQuery.addScalar("cid",LongType.INSTANCE);
		}
		if("N".equalsIgnoreCase(export)){
		sqlQuery.setMaxResults(50);
		}
		log.debug("query for vendor based list "+sqlQuery);
		List<Object[]> resultList =sqlQuery.list();
		List<RiskRatingReport> vendorRiskList = new ArrayList<RiskRatingReport>();
		RiskRatingReport vrr;
		if(resultList!= null){
			for(Object[] rs :resultList) {
				vrr = new RiskRatingReport();
				vrr.setRiskRating(((Double) rs[0]));
				vrr.setVendorName(((String)rs[1]));
				vrr.setRiskPortCount(((Long) rs[2]));
				vrr.setPortCount(((Long) rs[3]));
				vrr.setIpCount(((Long) rs[4]));
				if("parent".equalsIgnoreCase(type)){
				vrr.setParentId(((Long) rs[5]));
				}
				if("casp".equalsIgnoreCase(type)){
					vrr.setCaspId(((Long) rs[5]));
					vrr.setParentId(((Long) rs[6]));
		  		}
				if("detail".equalsIgnoreCase(type)){
		  			vrr.setDetailId(((Long) rs[5]));
		  			vrr.setParentId(((Long) rs[6]));
		  			vrr.setCaspId(((Long) rs[7]));
		  		}
				vendorRiskList.add(vrr);
			}
		}
		log.debug("list size" +vendorRiskList.size());
		return vendorRiskList; 
	}

	//get result for the report - Risk Rating Dashboard -> RiskRating by Connection
	@Override
	@Transactional(readOnly = true)
	public List<RiskRatingReport> getConnLevelList(String connId, String export){
		Session session = getSession();
		log.debug("Into  getConnLevelList method");
		
		StringBuilder condition = new StringBuilder("");
		condition.append("select b.srr,b.conn_id,qw.crc,v.cpc,b.pname,d.cp tipc,b.pid,b.cid,b.did from "+ 
				 "((select  round(sum(a.cr),2) srr, a.conn_id,a.pname,a.pid,a.cid,a.did from "+
				 "(select cfrq.calculated_risk cr, "+
				 "tp.id conn_id,tp.process_name pname,thp.parent_id pid,thp.casp_id cid,thp.detail_id did from third_party thp "+ 
  				"join relationship r on thp.id=r.third_party_id "+
  				"join ti_process tp on tp.relationship_id=r.id "+ 
				 "join ti_request tr on tp.id=tr.process_id "+
				 "join con_fw_rule cfr on cfr.ti_request_id=tr.id "+
				 "join con_fw_rule_questionnaire cfrq on cfrq.fw_rule_id=cfr.id and cfrq.deleted_ti_request_id is null and cfr.deleted_ti_request_id is null "); 
		if(connId != null && !connId.isEmpty()){ 
			condition.append("where tp.id="+connId.trim()+" ");
		}
		condition.append(") a "+
				 "group by  a.conn_id,a.pname,a.pid,a.cid,a.did  order by sum(a.cr) desc )b "+
				 "join "+
				 "(select sum(port.port_count) cpc,port.tid from "+ 
				 "(select distinct port.port_count,port.port_number,tp.id tid from ti_process tp "+  
				 "join ti_request tr on tp.id=tr.process_id "+
				 "join con_fw_rule cfr on cfr.ti_request_id=tr.id "+
				 "join con_fw_rule_port prt ON cfr.id = prt.rule_id "+ 
				 "join con_port_lookup port  ON prt.PORT_id = port.id and cfr.deleted_ti_request_id is null and prt.deleted_ti_request_id is null ");
		 if(connId != null && !connId.isEmpty()){
				condition.append("where tp.id="+connId.trim()+"  ");
		 }
				
		 condition.append(") port group by port.tid )v on v.tid = b.conn_id join (select count(w.risk_code) crc,w.con_id,w.pname pname "+
					"from (select  distinct rd.risk_code, "+
					"tp.id con_id, tp.process_name pname "+ 
					"from ti_process tp "+
					"join ti_request tr on tp.id=tr.process_id "+
					"join con_fw_rule cfr on cfr.ti_request_id=tr.id "+ 
					"join con_fw_rule_questionnaire cfrq on cfrq.fw_rule_id=cfr.id "+ 
					"join con_fw_rule_ostia_question cfroq on cfroq.fw_rule_qnnaire_id=cfrq.id "+ 
					"join ostia_question oq on cfroq.question_id=oq.id "+
					"join risk_definition rd on oq.risk_definition_id=rd.id and rd.risk_code not in ('NO_RISK','RISK_GENERIC') and cfr.deleted_ti_request_id is null "+
					"and cfroq.deleted_ti_request_id is null and cfrq.deleted_ti_request_id is null ");
		if(connId != null && !connId.isEmpty()){
			condition.append("where tp.id="+connId.trim() );
		}
		condition.append(" )w group by  w.con_id,w.pname)qw  on v.tid = qw.con_id JOIN (SELECT SUM(sour.asd) cp,sour.tid FROM "+
					"(SELECT distinct case when cim.no_of_host is null then 1 else cim.no_of_host end asd,tp.id tid,cim.ip_address "+
					"FROM ti_process tp JOIN ti_request tr ON tp.id=tr.process_id "+
					"JOIN con_fw_rule cfr ON cfr.ti_request_id=tr.id "+
					"join con_fw_rule_source_ip cfsi on cfsi.rule_id=cfr.id "+
					"join con_ip_master cim on cfsi.ip_id=cim.id  "+
					"join resourcetype r on r.id=cfr.src_nwzone_id and r.perimeter = 'Internal' "+
					"and cfr.deleted_ti_request_id is null and cfsi.deleted_ti_request_id is null ");	
		if(connId != null && !connId.isEmpty()){
			condition.append("where tp.id="+connId.trim() );
		}
		condition.append("UNION SELECT DISTINCT  case when cima.no_of_host is null then 1	else cima.no_of_host end asdf,tp.id tid,cima.ip_address "+
				"FROM ti_process tp JOIN ti_request tr ON tp.id=tr.process_id "+
				"JOIN con_fw_rule cfr ON cfr.ti_request_id=tr.id "+
				"join con_fw_rule_destination_ip cfdi on cfdi.rule_id=cfr.id "+
				"join con_ip_master cima on cfdi.ip_id=cima.id  "+
				"join resourcetype r on r.id=cfr.dst_nwzone_id and r.perimeter = 'Internal' "+
				"and cfr.deleted_ti_request_id is null and cfdi.deleted_ti_request_id is null "); 
		if(connId != null && !connId.isEmpty()){
			condition.append("where tp.id="+connId.trim() );
		}
		condition.append(") sour GROUP BY sour.tid)d ON d.tid = qw.con_id )where b.srr is not null order by b.srr desc ");
		SQLQuery sqlQuery = session.createSQLQuery(condition.toString());
		sqlQuery.addScalar("srr", DoubleType.INSTANCE);
		sqlQuery.addScalar("conn_id", LongType.INSTANCE);
		sqlQuery.addScalar("crc", LongType.INSTANCE);
		sqlQuery.addScalar("cpc", LongType.INSTANCE);
		sqlQuery.addScalar("pname",StringType.INSTANCE);
		sqlQuery.addScalar("tipc", LongType.INSTANCE);
		sqlQuery.addScalar("pid", LongType.INSTANCE);
		sqlQuery.addScalar("cid", LongType.INSTANCE);
		sqlQuery.addScalar("did", LongType.INSTANCE);
		if("N".equalsIgnoreCase(export) || export == null){
			sqlQuery.setMaxResults(50);
		}
		
		log.debug("query for connection based list "+sqlQuery);
		
		List<Object[]> resultList =sqlQuery.list();
		List<RiskRatingReport> connRiskList = new ArrayList<RiskRatingReport>();
		RiskRatingReport crr;
		if(resultList!= null){
			for(Object[] rs :resultList) {
				crr = new RiskRatingReport();
				crr.setRiskRating(((Double) rs[0]));
				crr.setConnId(((Long) rs[1]));
				crr.setRiskPortCount(((Long) rs[2]));
				crr.setPortCount(((Long) rs[3]));
				crr.setConnName(((String) rs[4])); 
				crr.setIpCount((Long) rs[5]);
				crr.setParentId((Long) rs[6]);
				crr.setCaspId((Long) rs[7]);
				crr.setDetailId((Long) rs[8]);
				connRiskList.add(crr);
			}
		}
		log.debug("list size for conn Level" +connRiskList.size()); 
		return connRiskList; 
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<FirewallReport> getFirewallApplications(String name, String export){
		Session session = getSession();
		log.debug("Into  getFirewallApplications method");
		
		StringBuffer qry = new StringBuffer();
		
		 qry.append("select distinct tr.process_id, tr.version_number, tp.PROCESS_NAME, cfp.id policy_id, cfp.POLICY_NAME, cf.firewall_name, cfp.FW_TYPE,  "); 
		 qry.append("ta.application_id, ta.application_name, ta.IS_CSI, Cnts.TI_REQUEST_ID, Cnts.Project_Coordinator, Cnts.Technical_Coordinator, Cnts.ISO, Cnts.Requestor,  "); 
		 qry.append("Cnts.Business_Owner, Cnts.Business_Tester, Cnts.Business_Manager, Cnts.Business_User, Cnts.Director,TA.app_owner_full_name,bu.business_name,s.name "); 
		 qry.append("from ti_process tp, ti_request tr, con_fw_rule cfr, con_fw_rule_application cfra, con_fw_rule_policy cfrp, "); 
		 qry.append("con_fw_policy cfp, con_firewall cf, ti_application ta,rel_citi_hierarchy_xref RCHX,SECTOR S, BUSINESS_UNIT BU,citi_hierarchy_master chm,( "); 
		 qry.append("SELECT  "); 
		 qry.append("TI_REQUEST_ID "); 
		 qry.append(",Listagg(Project_Coordinator, '; ')Within Group (Order By ROLE_ID) As Project_Coordinator "); 
		 qry.append(",Listagg(Technical_Coordinator, '; ')Within Group (Order By ROLE_ID) As Technical_Coordinator "); 
		 qry.append(",Listagg(ISO, '; ')Within Group (Order By ROLE_ID) As ISO "); 
		 qry.append(",Listagg(Requestor, '; ')Within Group (Order By ROLE_ID) As Requestor "); 
		 qry.append(",Listagg(Business_Owner, '; ')Within Group (Order By ROLE_ID) As Business_Owner "); 
		 qry.append(",Listagg(Business_Tester, '; ')Within Group (Order By ROLE_ID) As Business_Tester "); 
		 qry.append(",Listagg(Business_Manager, '; ')Within Group (Order By ROLE_ID) As Business_Manager "); 
		 qry.append(",Listagg(Business_User, '; ')Within Group (Order By ROLE_ID) As Business_User "); 
		 qry.append(",Listagg(Director, '; ')Within Group (Order By ROLE_ID) As Director "); 
		 qry.append("FROM  "); 
		 qry.append("( "); 
		 qry.append("SELECT DISTINCT xCnt.TI_REQUEST_ID,xCnt.ROLE_ID "); 
		 qry.append(",CASE WHEN xCnt.ROLE_ID = 1 THEN FIRST_NAME ||' '|| LAST_NAME ||'('|| SSO_ID ||')' Else Null  End As Project_Coordinator "); 
		 qry.append(",CASE WHEN xCnt.ROLE_ID = 4 THEN FIRST_NAME ||' '|| LAST_NAME ||'('|| SSO_ID ||')' Else Null  End As Technical_Coordinator "); 
		 qry.append(",CASE WHEN xCnt.ROLE_ID = 3 THEN FIRST_NAME ||' '|| LAST_NAME ||'('|| SSO_ID ||')' Else Null  End As ISO "); 
		 qry.append(",CASE WHEN xCnt.ROLE_ID = 28 THEN FIRST_NAME ||' '|| LAST_NAME ||'('|| SSO_ID ||')' Else Null  End As Requestor "); 
		 qry.append(",CASE WHEN xCnt.ROLE_ID = 32 THEN FIRST_NAME ||' '|| LAST_NAME ||'('|| SSO_ID ||')' Else Null  End As Business_Owner "); 
		 qry.append(",CASE WHEN xCnt.ROLE_ID = 33 THEN FIRST_NAME ||' '|| LAST_NAME ||'('|| SSO_ID ||')' Else Null  End As Business_Tester "); 
		 qry.append(",CASE WHEN xCnt.ROLE_ID = 24 THEN FIRST_NAME ||' '|| LAST_NAME ||'('|| SSO_ID ||')' Else Null  End As Business_Manager "); 
		 qry.append(",CASE WHEN xCnt.ROLE_ID = 41 THEN FIRST_NAME ||' '|| LAST_NAME ||'('|| SSO_ID ||')' Else Null  End As Business_User "); 
		 qry.append(",CASE WHEN xCnt.ROLE_ID = 39 THEN FIRST_NAME ||' '|| LAST_NAME ||'('|| SSO_ID ||')' Else Null  End As Director "); 
		 qry.append("FROM ( "); 
		 qry.append("SELECT DISTINCT TI_REQUEST_ID, Citi_Contact_ID, ROLE_ID, PRIMARY_CONTACT, NOTIFY_CONTACT "); 
		 qry.append("FROM TI_REQUEST_PLANNING_XREF R_Ref "); 
		 qry.append("JOIN TI_REQUEST Req ON R_Ref.TI_REQUEST_ID=Req.ID "); 
		 qry.append("JOIN TI_PROCESS Con ON Con.ID = Req.PROCESS_ID "); 
		 qry.append("JOIN RELATIONSHIP Rel ON Rel.ID = Con.RELATIONSHIP_ID AND Rel.relationship_type <> 'THIRD_PARTY' "); 
		 qry.append("JOIN CON_REQ_CIT_RQCON_XREF Cnt_R ON R_Ref.planning_id = Cnt_R.request_id  "); 
		 qry.append("UNION "); 
		 qry.append("SELECT DISTINCT TI_REQUEST_ID, Citi_Contact_ID, ROLE_ID, PRIMARY_CONTACT, NOTIFY_CONTACT "); 
		 qry.append("FROM TI_REQUEST_PLANNING_XREF R_Ref "); 
		 qry.append("JOIN TI_REQUEST Req ON R_Ref.TI_REQUEST_ID=Req.ID "); 
		 qry.append("JOIN TI_PROCESS Con ON Con.ID = Req.PROCESS_ID "); 
		 qry.append("JOIN RELATIONSHIP Rel ON Rel.ID = Con.RELATIONSHIP_ID AND Rel.relationship_type = 'THIRD_PARTY' "); 
		 qry.append("JOIN CON_REQ_CITI_CONTACT_XREF Cnt_R ON R_Ref.planning_id = Cnt_R.request_id  "); 
		 qry.append("JOIN CITI_CONTACT Cnt ON Cnt_R.citi_contact_id = Cnt.ID "); 
		 qry.append(")xCnt "); 
		 qry.append("JOIN CITI_CONTACT Cnt ON xCnt.citi_contact_id = Cnt.ID "); 
		 qry.append(")SUB  "); 
		 qry.append("GROUP BY TI_REQUEST_ID "); 
		 qry.append(") Cnts "); 
		 qry.append("where "); 
		 qry.append("tp.id = tr.process_id and "); 
		 qry.append("tr.id = cfr.ti_request_id and cfr.deleted_ti_request_id is null "); 
		 qry.append("and cfr.id = cfra.rule_id and cfra.deleted_ti_request_id is null "); 
		 qry.append("and cfr.id = cfrp.rule_id and cfrp.deleted_ti_request_id is null "); 
		 qry.append("and cfrp.policy_id = cfp.id and cfp.id = cf.policy_id "); 
		 qry.append("and cfra.application_id = ta.id and ta.is_csi = 'Y'  and tr.ID = Cnts.TI_REQUEST_ID "); 
		 qry.append("AND  tp.relationship_id = rchx.relationship_id "); 
		 qry.append("and rchx.citi_hierarchy_master_id = chm.id "); 
		 qry.append("and chm.bu_id = bu.id and chm.sector_id=s.id "); 
		 qry.append("and upper(cf.firewall_name) like('"+name.toUpperCase()+"') "); 

		SQLQuery sqlQuery = session.createSQLQuery(qry.toString());
		sqlQuery.addScalar("process_id", LongType.INSTANCE);
		sqlQuery.addScalar("version_number",LongType.INSTANCE);
		sqlQuery.addScalar("PROCESS_NAME",StringType.INSTANCE);
		sqlQuery.addScalar("policy_id", LongType.INSTANCE);
		sqlQuery.addScalar("POLICY_NAME",StringType.INSTANCE);
		sqlQuery.addScalar("firewall_name", StringType.INSTANCE);
		sqlQuery.addScalar("FW_TYPE",StringType.INSTANCE);
		sqlQuery.addScalar("application_id",StringType.INSTANCE);
		sqlQuery.addScalar("application_name", StringType.INSTANCE);
		sqlQuery.addScalar("IS_CSI", StringType.INSTANCE);
		sqlQuery.addScalar("TI_REQUEST_ID", LongType.INSTANCE);
		sqlQuery.addScalar("Project_Coordinator",StringType.INSTANCE);
		sqlQuery.addScalar("Technical_Coordinator", StringType.INSTANCE);
		sqlQuery.addScalar("ISO",StringType.INSTANCE);
		sqlQuery.addScalar("Requestor", StringType.INSTANCE);
		sqlQuery.addScalar("Business_Owner", StringType.INSTANCE);
		sqlQuery.addScalar("Business_Tester",StringType.INSTANCE);
		sqlQuery.addScalar("Business_Manager", StringType.INSTANCE);
		sqlQuery.addScalar("Business_User",StringType.INSTANCE);
		sqlQuery.addScalar("Director", StringType.INSTANCE);
		/*
		 * Start - 20160112- Added as per change requested by Sonali Khandekar 
		 * "Applications by Firewall Name - Report modification"
		 */
		sqlQuery.addScalar("APP_OWNER_FULL_NAME", StringType.INSTANCE);
		sqlQuery.addScalar("BUSINESS_NAME", StringType.INSTANCE);
		sqlQuery.addScalar("NAME", StringType.INSTANCE);
		/*
		 * Stop - 20160112- Added as per change requested by Sonali Khandekar 
		 * "Applications by Firewall Name - Report modification"
		 */
		if("N".equalsIgnoreCase(export) || export == null){
			sqlQuery.setMaxResults(50);
		}
		
		log.debug("query for connection based list "+sqlQuery);
		
		List<Object[]> resultList =sqlQuery.list();
		List<FirewallReport> firewallReports = new ArrayList<FirewallReport>();
		FirewallReport crr;
		if(resultList!= null) {
			for(Object[] rs :resultList) {
				crr = new FirewallReport();
				crr.setConnectionId(((Long) rs[0]));
				crr.setVersionNumber(((Long) rs[1]));
				crr.setConnectionName(((String) rs[2]));
				crr.setPolicyId(((Long) rs[3]));
				crr.setPolicyName(((String) rs[4]));
				crr.setFirewall(((String) rs[5]));
				crr.setFirewallType(((String) rs[6]));
				crr.setIsCSI(((String) rs[7]));
				crr.setApplicationId(((String) rs[8]));
				crr.setApplicationName(((String) rs[9]));
				crr.setTiRequestId(((Long) rs[10]));
				crr.setProjectCordinator(((String) rs[11]));
				crr.setTechnicalCoordinator(((String) rs[12]));
				crr.setIso(((String) rs[13]));
				crr.setRequester(((String) rs[14]));
				crr.setBusinessOwner(((String) rs[15]));
				crr.setBusinessTester(((String) rs[16]));
				crr.setBusinessManager(((String) rs[17]));
				crr.setBusinessUser(((String) rs[18]));
				crr.setDirector(((String) rs[19]));
				/*
				 * Start - 20160112- Added as per change requested by Sonali Khandekar 
				 * "Applications by Firewall Name - Report modification"
				 */
				crr.setCsiOwnerName(((String) rs[20]));
				crr.setBusinessUnit(((String) rs[21]));
				crr.setSector(((String) rs[22]));
				/*
				 * Stop - 20160112- Added as per change requested by Sonali Khandekar 
				 * "Applications by Firewall Name - Report modification"
				 */
				firewallReports.add(crr);
			}
		}
		log.debug("list size for conn Level" +firewallReports.size()); 
		return firewallReports; 
	}

}
