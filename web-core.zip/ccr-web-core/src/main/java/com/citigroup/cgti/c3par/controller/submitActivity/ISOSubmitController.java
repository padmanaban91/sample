package com.citigroup.cgti.c3par.controller.submitActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiHierarchyXref;
import com.citigroup.cgti.c3par.validator.submitActivtity.ISOValidator;
import com.citigroup.cgti.c3par.webtier.helper.Util;

/*
 * @nc43495
 */
@Controller
public class ISOSubmitController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(ISOSubmitController.class);
	
	Util util=new Util();
	
	@Autowired
	@Qualifier("isoValidator") 
	private ISOValidator validator;
	
	@Autowired
	WsPapiFacade papiFacade;

	@RequestMapping(value = "/loadISOSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(ModelMap model,@ModelAttribute("isoProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request){
		log.info("ISOSubmitController  load method starts here...");
		
		String tiReq = (String)session.getAttribute("tireqid");
		String actId = (String)session.getAttribute("activityid");
		
		Long tiReqId = Long.valueOf(0);
		Long activityId = Long.valueOf(0);
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		if(actId!=null){
		    try{activityId=Long.valueOf(actId);}catch(Exception e){activityId = Long.valueOf(0);}
		}
		log.debug("tiReq:"+tiReq+"ActivityId"+activityId);
		
		//Validation messages display
		List<ObjectError> isoValidator = validator.getISOMessage(tiReqId);
		
		for (ObjectError error : isoValidator) {
			result.addError(error);
		}
		
		request.setAttribute("errorMsg", result.getAllErrors());
		
		if (result.getAllErrors() != null && !result.getAllErrors().isEmpty()){
			if (result.getAllErrors().size() == 1
					&& (result.getAllErrors().get(0) == null || result.getAllErrors().get(0).getCode() == null 
					|| result.getAllErrors().get(0).getCode().isEmpty())) {
				request.setAttribute("errorMsgCount", 0);
			} else {
			request.setAttribute("errorMsgCount", result.getAllErrors().size());
			}
		}else{
			request.setAttribute("errorMsgCount", 0);
		}
		
		
		
		log.debug("error log:"+isoValidator+"count:"+ result.getErrorCount()+""+result.getAllErrors().size());
		
		submitActivityProcess = new SubmitActivityProcess();
		
		TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
		
		//supplementary review roles display
		HashMap<String,String> roles = submitActivityProcess.findInstanceId(tiReqId, activityId);
		submitActivityProcess.setRoles(roles);
		List<LookUpVO> supReviewRole = submitActivityProcess.getSupReviewRoles((String)roles.get("ROLE"));
		log.debug("ISOSubmitController...:"+supReviewRole.size());
		submitActivityProcess.setSupReviewRoles(supReviewRole);
		
		//set activity role
		submitActivityProcess.setActivityRole((String)roles.get("ROLE"));
		session.setAttribute("activityRole",submitActivityProcess.getActivityRole());
		log.debug("activity role:"+submitActivityProcess.getActivityRole());
		
		/*//setInstanceID
		String instanceId = (String)roles.get("INST_ID");
		session.setAttribute("instanceID", instanceId);
		log.debug("instanceId"+instanceId);*/
		
		// setTaskID
		String taskId = (String) session.getAttribute("taskId");
		log.debug("*********taskId************" + taskId);

		//Approval comments display
		String role = (String)roles.get("ROLE");
		submitActivityProcess.setTiReqCmtsList(submitActivityProcess.getComments(tiReqId, role, "A"));
		
		//Discussion comments display
		submitActivityProcess.setDiscussCmtsList(submitActivityProcess.getComments(tiReqId, role, "D"));
		
		//Check Uturn
		session.setAttribute("ISUTURN", submitActivityProcess.isUTurnConnection(tiReqId));
		log.info("ISUTURN == " + session.getAttribute("ISUTURN"));
		
		
		//Check mad
		if (tiRequest.getTiProcess()!= null) {
			 String busUnitName = null;
			if (tiRequest.getTiProcess().getRelationshipId().getRelcitiHierarchyXrefs() != null) {
				RelCitiHierarchyXref relXref = tiRequest.getTiProcess().getRelationshipId().getRelcitiHierarchyXrefs().get(0) ;
				if(relXref.getCitiHierarchyMaster() !=null) { 
				CitiHierarchyMaster citiMaster = relXref.getCitiHierarchyMaster();
				 BusinessUnit bu = citiMaster.getBusinessUnit();
				  busUnitName = bu.getBusinessName();
				}
			}
		
		List<LookUpVO> supReviewRoleIso = submitActivityProcess.getSupReviewRoles();
	    List<String> supReviewRoleRemoved = new ArrayList<String>();
	    List<LookUpVO> finalSuppRole = new ArrayList<LookUpVO>();
	    log.debug("Business Unit Name  :: " + busUnitName);
	    boolean busUnitFlag=false;
	    boolean supReviewFlag=false;
	    if(busUnitName!=null)
		busUnitFlag=busUnitName.equalsIgnoreCase(ActivityData.BUSINESS_UNIT_MAD);
	    if (supReviewRole.size() > 0) {
		for(int i=0;i<supReviewRoleIso.size();i++){			
		    LookUpVO supReviewLookup=(LookUpVO)supReviewRoleIso.get(i);
		    if (busUnitFlag && supReviewLookup.getName().equalsIgnoreCase(ActivityData.ROLE_OTRM)) {
		    	supReviewRoleRemoved.add(supReviewLookup.getName());//supReviewRole.remove(i);
		    }else if (busUnitFlag && supReviewLookup.getName().equalsIgnoreCase(ActivityData.ROLE_MAD)) {
		    	supReviewRoleRemoved.add(supReviewLookup.getName());//supReviewRole.remove(i);
		    }else if(!busUnitFlag && supReviewLookup.getName().equalsIgnoreCase(ActivityData.ROLE_MAD)){
		    	supReviewRoleRemoved.add(supReviewLookup.getName());//supReviewRole.remove(i);
		    }
		    
		}
		
	    }
	    if(supReviewRoleRemoved.size()>0){
		supReviewFlag=true;
		for(int i=0;i<supReviewRoleIso.size();i++){
		    LookUpVO supReviewLookup=(LookUpVO)supReviewRoleIso.get(i);
		    /*if(supReviewRoleRemoved.contains(supReviewLookup.getName())){
		    	supReviewRoleRemoved.remove(supReviewLookup.getName());
		    }*/
		    if(!supReviewRoleRemoved.contains(supReviewLookup.getName())){
		    	LookUpVO lookUp = new LookUpVO();
		    	lookUp.setName(supReviewRoleIso.get(i).getName());
		    	lookUp.setValue(supReviewRoleIso.get(i).getValue());
		    	finalSuppRole.add(lookUp) ;
		    	log.debug("supplementary role removed:"+finalSuppRole.size());
		    }
		}

	    }
	    if(supReviewFlag){
	    	submitActivityProcess.setSupReviewRoles(finalSuppRole);
	    }
		}
		
		log.debug("supplementary role received:"+submitActivityProcess.getSupReviewRoles());
		
		model.addAttribute("isoProcess", submitActivityProcess);
	
		return "c3par.isoSubmit";
	}
	
	@RequestMapping(value = "/saveISOSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String save(ModelMap model,@ModelAttribute("isoProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request) throws Exception{
	log.info("ISOSubmitController:Save method starts here...");
	formSubmit(submitActivityProcess,result,session,request);
	return "forward:/logon.act?forwardTo=bpm";
		
	}
	
	
	@RequestMapping(value = "/submitISOSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String submit(ModelMap model,@ModelAttribute("isoProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request){
	log.info("ISOSubmitController:Save method starts here...");
	
	try {
		formSubmit(submitActivityProcess,result,session,request);
		log.debug("ISOSubmitController Submit PAPI Enter ");
		
		//WsPapiFacade papiFacade = new WsPapiFacade ();
		
		String taskId = (String)session.getAttribute("taskId");
		String userId  = request.getHeader("SM_USER");
		String nextSelectedAction = submitActivityProcess.getCurrentAction();
		String nextRole = null;
		
		log.debug("taskId: " + taskId +"action"+nextSelectedAction);
		log.debug("userId: " + userId);
		log.debug("Before calling PAPI For BJ Submit");
		

		if("REJECTED".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getRejectRole());
		}else if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getProvideInfoRole());
		}else {
			nextRole = util.moveToActivity(submitActivityProcess.getCurrentRole());
		}
		
		log.debug("Selected role:"+nextRole);
		
		if ("UNLOCKED".equals( nextSelectedAction ) || "COMPLETED".equals( nextSelectedAction ) ) {
			papiFacade.completeActivity(userId, taskId, nextSelectedAction); 
			return "forward:/logon.act?forwardTo=bpm";
		}
		
		if("REJECTED".equalsIgnoreCase(nextSelectedAction)){
			log.debug("inside Rejected scenario..."+nextSelectedAction);
			papiFacade.completeActivity(userId, taskId, WsPapiFacade.ActivityStatus.REJECTED, WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
			return "forward:/logon.act?forwardTo=bpm";
		}
		
		if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.completeActivity(userId, taskId, WsPapiFacade.ActivityStatus.PROVIDEINFO,WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
			return "forward:/logon.act?forwardTo=bpm";
		}
	} catch (OperationException_Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return "forward:/logon.act?forwardTo=bpm";
		
	}
	
	
	//data collection
    private void formSubmit(SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session,
			HttpServletRequest request)throws Exception{
    	log.debug("ISOSubmitController form Submit begins...");
    	String messgXML = (String)request.getSession().getAttribute("MESSAGEXML");
		log.info("messgXML::"+messgXML);
		
		String tiReq = (String)session.getAttribute("tireqid");
		
		submitActivityProcess.setActivityRole((String)session.getAttribute("activityRole"));
		log.debug("activity role inside form submit:"+submitActivityProcess.getActivityRole());
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );
		
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		
		//Getting request type
		TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
		
		if(submitActivityProcess.getCurrentAction()==null){
			submitActivityProcess.setCurrentAction(ActivityData.STATUS_COMPLETED);
		}
		
		if(submitActivityProcess.getCurrentRole()==null){
			submitActivityProcess.setCurrentRole(submitActivityProcess.getActivityRole());
		}
		
		//Planning id for ISO Text update
		Long planningId = submitActivityProcess.getPlanningId(tiReqId);

		 if(submitActivityProcess.getBiso_assess_risk()!=null && submitActivityProcess.getBiso_assess_risk().equalsIgnoreCase("OTHER")){
			 submitActivityProcess.setBiso_assess_risk(submitActivityProcess.getBiso_assess_risk_other());
		 }
		 
		 
		 if(submitActivityProcess.getIssConnectionCompliance() !=null && !submitActivityProcess.getIssConnectionCompliance().isEmpty()){
			 submitActivityProcess.setIssConnectionCompliance(submitActivityProcess.getIssConnectionCompliance());
		 }
		 
		 //Update con_req table 
		 submitActivityProcess.isoInformationUpdate(tiReqId,submitActivityProcess.getIssConnectionCompliance(),
				 submitActivityProcess.getBiso_assess_risk(),planningId);
				

		log.info("Request Parameters::"+request.getParameterNames());
		log.info("Request current role="+request.getParameter("currentRole"));
		log.info("current action =" + submitActivityProcess.getCurrentAction());
		log.info("current role=" + submitActivityProcess.getCurrentRole());
		log.info("comments = " + submitActivityProcess.getComments());
		

		String ssoID = request.getHeader("SM_USER");
		
		TiRequestComments tiReqComments = new TiRequestComments();
		tiReqComments.setTiRequest(tiRequest);
		tiReqComments.setComments(submitActivityProcess.getComments());
		tiReqComments.setRoleName(submitActivityProcess.getActivityRole());
		tiReqComments.setApproverSoeID(ssoID);
		
		submitActivityProcess.deleteSupReviewRoles(tiReqId,submitActivityProcess.getActivityRole());
		submitActivityProcess.insertSupReviewRoles(tiReqId,submitActivityProcess.getActivityRole(),submitActivityProcess.getSelectedSupReviewRoles());

		//updating tiRequest comments
		if(!"PROVIDEINFO".equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
			submitActivityProcess.addComments(tiReqComments, "A", "save");
		}else {
			submitActivityProcess.addComments(tiReqComments, "D", "save");
		}
		
		
			
    }
}
