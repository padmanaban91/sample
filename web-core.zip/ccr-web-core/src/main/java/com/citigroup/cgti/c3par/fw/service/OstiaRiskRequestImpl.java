package com.citigroup.cgti.c3par.fw.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.DoubleType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleImpl;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleOstiaAnswer;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleOstiaQuestion;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestion;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.PossibleAnswers;
import com.citigroup.cgti.c3par.fw.domain.RequestOstiaQuestion;
import com.citigroup.cgti.c3par.fw.domain.RequestQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.RiskDefinition;
import com.citigroup.cgti.c3par.fw.domain.soc.persist.OstiaRiskPersistable;
import com.citigroup.cgti.c3par.util.StringUtil;

/**
 * @author bs45969
 *
 */
@Transactional
public class OstiaRiskRequestImpl extends FirewallRuleProcessImpl implements
		OstiaRiskPersistable {
	
	 /** The log. */
    private static Logger log = Logger.getLogger(OstiaRiskRequestImpl.class);
    
    private MailModuleImpl mailModuleImpl;
    
	/**
	 * @return the mailModuleImpl
	 */
	public MailModuleImpl getMailModuleImpl() {
		return mailModuleImpl;
	}
	/**
	 * @param mailModuleImpl the mailModuleImpl to set
	 */
	public void setMailModuleImpl(MailModuleImpl mailModuleImpl) {
		this.mailModuleImpl = mailModuleImpl;
	}
	
	@Override
	public List<RiskDefinition> findRiskDefinitions(
			FireWallRuleProcess fireWallRuleProcess) {

		List<FirewallRuleOstiaQuestion> answers = findFirewallRuleOstiaAnswers(fireWallRuleProcess.getTiRequest(),fireWallRuleProcess.getIsIpReg());
		List<RiskDefinition> allDefinitions = new ArrayList<RiskDefinition>();
		for (FirewallRuleOstiaQuestion answer : answers) {
			allDefinitions.add(answer.getOstiaQuestion().getRiskDefinition());
		}
		List<RequestOstiaQuestion> req_questions = findRequestOstiaAnswers(fireWallRuleProcess.getTiRequest());
		for (RequestOstiaQuestion req_question : req_questions) {
			allDefinitions.add(req_question.getOstiaQuestion().getRiskDefinition());
		}
		Set<RiskDefinition> set = new HashSet<RiskDefinition>(allDefinitions);
		allDefinitions = new ArrayList<RiskDefinition>(set);
		return allDefinitions;

	}
	private List<RequestOstiaQuestion> findRequestOstiaAnswers(long tiRequest) {
		Session session = getSession();
		Criteria criteria = session
				.createCriteria(RequestOstiaQuestion.class);
		criteria.createCriteria("updatedTIRequest", "updatedTIRequest");
		criteria.createCriteria("requestQuestionnaire", "requestQuestionnaire");		
			criteria.add(Restrictions.eq("updatedTIRequest.id",
					tiRequest));
			criteria.add(Restrictions.isNull("requestQuestionnaire.deletedTIRequest"));
		criteria.add(Restrictions.isNull("deletedTIRequest"));
		List<RequestOstiaQuestion> ostiaQuestions = criteria
		.list();
		return ostiaQuestions;
	}
	public List<FirewallRuleOstiaQuestion> findFirewallRuleOstiaAnswers(
			long tiRequest, String isIpReg) {
		Session session = getSession();
		Criteria criteria = session
				.createCriteria(FirewallRuleOstiaQuestion.class);
		criteria.createCriteria("updatedTIRequest", "updatedTIRequest");
		criteria.createCriteria("firewallRuleQuestionnaire", "firewallRuleQuestionnaire");	
		criteria.add(Restrictions.eq("updatedTIRequest.id",
				tiRequest));
		criteria.add(Restrictions.isNull("firewallRuleQuestionnaire.deletedTIRequest"));
		criteria.createCriteria("firewallRuleQuestionnaire.firewallRule",
		"firewallRule");
		if (isIpReg.equalsIgnoreCase("Y")) {
			log.debug("IP" +isIpReg);
			
			criteria.add(Restrictions.eq("firewallRule.isIpReg", "Y"));
		}
		else{
			log.debug("FIREWALL" +isIpReg);
			criteria.add(Restrictions.sqlRestriction("(IS_IPREG is null or IS_IPREG != 'Y')"));
		}
		//To cut loose the No Risk
		criteria.createCriteria("ostiaQuestion",
				"ostiaQuestion");
		criteria.createCriteria("ostiaQuestion.riskDefinition",
		"riskDefinition");
		criteria.add(Restrictions.ne("riskDefinition.riskCode",
				"NO_RISK"));
		criteria.add(Restrictions.isNull("deletedTIRequest"));
		List<FirewallRuleOstiaQuestion> answers = criteria.list();
		return answers;
	}
	@Override
	public List<FirewallRuleQuestionnaire> findFirewallRuleQuestionnaires(
			FireWallRuleProcess fireWallRuleProcess) {
		boolean ruleTirequset = false;
		Session session = getSession();
		Criteria criteria = session
				.createCriteria(FirewallRuleQuestionnaire.class);
		criteria.createCriteria("updatedTIRequest", "updatedTIRequest");

		if (fireWallRuleProcess.getTiRequest() != 0) {
			criteria.add(Restrictions.eq("updatedTIRequest.id",
					fireWallRuleProcess.getTiRequest()));

		}
		if (!StringUtil.isNullorEmpty(fireWallRuleProcess.getPolicy())) {
			if (!ruleTirequset) {
				criteria.createCriteria("firewallRule", "firewallRule");
			}
			ruleTirequset = true;

			criteria.createCriteria("firewallRule.policy", "policy");
			criteria.add(Restrictions.ilike("policy.name", fireWallRuleProcess
					.getPolicy(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fireWallRuleProcess.getPolicyGroup())) {
			if (!ruleTirequset) {
				criteria.createCriteria("firewallRule", "firewallRule");
			}
			ruleTirequset = true;
			criteria.createCriteria("firewallRule.policyGroup", "policyGroup");
			criteria.add(Restrictions.ilike("policyGroup.name",
					fireWallRuleProcess.getPolicyGroup(), MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fireWallRuleProcess.getSourceZone())
				) {
			if (!ruleTirequset) {
				criteria.createCriteria("firewallRule", "firewallRule");
			}
			ruleTirequset = true;
			criteria.createCriteria("firewallRule.sourceNetworkZone",
					"sourceNetworkZone");
			criteria.createCriteria("firewallRule.destinationNetworkZone",
					"destinationNetworkZone");
			Criterion srcZone = Restrictions.ilike("sourceNetworkZone.name",
					fireWallRuleProcess.getSourceZone(), MatchMode.ANYWHERE);
			Criterion dstZone = Restrictions.ilike(
					"destinationNetworkZone.name", fireWallRuleProcess
							.getDestinationZone(), MatchMode.ANYWHERE);
			criteria.add(Restrictions.or(srcZone, dstZone));
		}
		if (!StringUtil.isNullorEmpty(fireWallRuleProcess.getSourceIPAddress())) {
			if (!ruleTirequset) {
				criteria.createCriteria("firewallRule", "firewallRule");
			}
			ruleTirequset = true;
			criteria.createCriteria("firewallRule.sourceIPs", "sourceIPs");
			criteria.createCriteria("sourceIPs.ipAddress", "sourceIP");
			criteria.add(Restrictions.ilike("sourceIP.ipAddress",
					fireWallRuleProcess.getSourceIPAddress(),
					MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fireWallRuleProcess
				.getDestinationIPAddress())) {
			if (!ruleTirequset) {
				criteria.createCriteria("firewallRule", "firewallRule");
			}
			ruleTirequset = true;
			criteria.createCriteria("firewallRule.destinationIPs",
					"destinationIPs");
			criteria
					.createCriteria("destinationIPs.ipAddress", "destinationIP");
			criteria.add(Restrictions.ilike("destinationIP.ipAddress",
					fireWallRuleProcess.getDestinationIPAddress(),
					MatchMode.ANYWHERE));
		}
		if (!StringUtil.isNullorEmpty(fireWallRuleProcess.getPortNumber())) {
			if (!ruleTirequset) {
				criteria.createCriteria("firewallRule", "firewallRule");
			}
			ruleTirequset = true;
			criteria.createCriteria("firewallRule.ports", "ports");
			criteria.createCriteria("ports.port", "port");
			criteria.add(Restrictions.eq("port.portNumber", fireWallRuleProcess
					.getPortNumber()));
		}
		
		if (!StringUtil.isNullorEmpty(fireWallRuleProcess.getStatus())) {
			criteria.add(Restrictions.eq("status", fireWallRuleProcess
					.getStatus()));
		} else if (!StringUtil.isNullorEmpty(fireWallRuleProcess.getFilterText())) {
			if ("bypassed".equalsIgnoreCase(fireWallRuleProcess.getFilterText())) {
				criteria.add(Restrictions.eq("status", "RiskCheckBypassed"));
			} else if ("norisk".equalsIgnoreCase(fireWallRuleProcess.getFilterText())) {
				criteria.add(Restrictions.eq("status", "ReviewNotRequired"));
			} else if ("risknotdone".equalsIgnoreCase(fireWallRuleProcess.getFilterText())) {
				criteria.add(Restrictions.eq("status", "RiskCheckNotDone"));
			} else {
				criteria.add(Restrictions.ne("status", "ReviewNotRequired"));
				criteria.add(Restrictions.ne("status", "RiskCheckBypassed"));
				criteria.add(Restrictions.ne("status", "RiskCheckNotDone"));
			}
		} else {
			criteria.add(Restrictions.ne("status", "ReviewNotRequired"));
			criteria.add(Restrictions.ne("status", "RiskCheckBypassed"));
			criteria.add(Restrictions.ne("status", "RiskCheckNotDone"));
		}
		
		//Ostia IP Reg filter
		if(!StringUtil.isNullorEmpty(fireWallRuleProcess.getIsIpReg()))
		{
			log.debug("Inside");
		if (!ruleTirequset) {
			criteria.createCriteria("firewallRule", "firewallRule");
			}
			ruleTirequset = true;
		if (fireWallRuleProcess.getIsIpReg().equalsIgnoreCase("Y")) {
			log.debug("IP" +fireWallRuleProcess.getIsIpReg());
			
			criteria.add(Restrictions.eq("firewallRule.isIpReg", "Y"));
		}
		else{
			log.debug("FIREWALL" +fireWallRuleProcess.getIsIpReg());
			criteria.add(Restrictions.sqlRestriction("(IS_IPREG is null or IS_IPREG != 'Y')"));
		}
		}
		
		if (!StringUtil.isNullorEmpty(fireWallRuleProcess.getRiskCode())) {
			criteria.createCriteria("firewallRuleOstiaAnswers", "firewallRuleOstiaAnswers");
			criteria.createCriteria("firewallRuleOstiaAnswers.ostiaQuestion",
					"ostiaQuestion");
			criteria.createCriteria("ostiaQuestion.riskDefinition",
			"riskDefinition");
			criteria.add(Restrictions.eq("riskDefinition.riskCode",
					fireWallRuleProcess.getRiskCode()));

		} 
	/*	if (ruleTirequset) {
			if (fireWallRuleProcess.getTiRequest() != 0) {
				criteria.createCriteria("firewallRule.tiRequest", "tiRequest");
				criteria.add(Restrictions.eq("tiRequest.id",
						fireWallRuleProcess.getTiRequest()));
			}
		}*/

		criteria.add(Restrictions.isNull("deletedTIRequest"));
		criteria.add(Restrictions.isNotNull("firewallRule"));

		if (fireWallRuleProcess.isPaginationRequired()) {
			fireWallRuleProcess.setRowCount(getRowCount(criteria));
			addPagination(criteria, fireWallRuleProcess.getFirstResult(),
					fireWallRuleProcess.getMaxResult());
		}
		
		criteria.addOrder(Order.desc("id"));
		List<FirewallRuleQuestionnaire> firewallRuleQuestionnaires = criteria
				.list();
		return firewallRuleQuestionnaires;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FirewallRuleOstiaQuestion> findFirewallRuleOstiaAnswers(
			FireWallRuleProcess fireWallRuleProcess) {
		Session session = getSession();
		List<FirewallRuleOstiaQuestion> list = new ArrayList<FirewallRuleOstiaQuestion>();
		list = (List<FirewallRuleOstiaQuestion>) session
				.createQuery(
						"from FirewallRuleOstiaQuestion obj where obj.deletedTIRequest is null and obj.firewallRuleQuestionnaire.id = ? order by ostiaQuestion.riskDefinition.riskCode,id desc")
				.setLong(
						0,
						fireWallRuleProcess.getFirewallRuleQuestionnaire()
								.getId()).list();
		if (list == null || list.isEmpty()) {
			FirewallRuleQuestionnaire firewallRuleQuestionnaire = (FirewallRuleQuestionnaire) session
					.createQuery(
							"from FirewallRuleQuestionnaire rule where rule.id="
									+ fireWallRuleProcess
											.getFirewallRuleQuestionnaire()
											.getId()).uniqueResult();
			List<RiskDefinition> definitions = firewallRuleQuestionnaire
					.getQuestionnaire().getRiskDefinitions();
			for (RiskDefinition definition : definitions) {
				List<OstiaQuestion> ostiaQuestions = definition
						.getOstiaQuestions();
				for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
					FirewallRuleOstiaQuestion firewallRuleOstiaQuestion = new FirewallRuleOstiaQuestion();
					firewallRuleOstiaQuestion
							.setFirewallRuleQuestionnaire(firewallRuleQuestionnaire);
					firewallRuleOstiaQuestion.setOstiaQuestion(ostiaQuestion);
					list.add(firewallRuleOstiaQuestion);
				}

			}

		}else{
		/*	for(FirewallRuleOstiaQuestion ruleOstiaQuestion:list){
				
			}*/
		}
		return list;
	}

	@Override
	public void updateAnswer(FireWallRuleProcess fireWallRuleProcess) {
			boolean isCompleted=true;
			List<FirewallRuleOstiaQuestion> answers = fireWallRuleProcess.getFirewallRuleOstiaAnswers();
			TIRequest request=new TIRequest();
			request.setId(fireWallRuleProcess.getTiRequest());
			for(FirewallRuleOstiaQuestion fwquestion:answers){
				Set<String> selectedanswers = fwquestion.getAnswersValue();
				Set<FirewallRuleOstiaAnswer> firewallRuleOstiaAnswers = fwquestion.getAnswers();
				
				Map<String,FirewallRuleOstiaAnswer> existinganswers= fwquestion.getAnswersValueExists();
				Set<FirewallRuleOstiaAnswer> newfirewallRuleOstiaAnswers = new LinkedHashSet<FirewallRuleOstiaAnswer>();
				if(fwquestion.getOstiaQuestion().getAnswerType().equalsIgnoreCase("TEXT")){
					if(!StringUtil.isNullorEmpty(fwquestion.getTextAnswer())){						
						fwquestion.setStatus("Completed");	
					}else{
						fwquestion.setStatus("Incomplete");		
						isCompleted=false;
					}
				
				}
				if(fwquestion.getOstiaQuestion().getAnswerType().equalsIgnoreCase("SELECT")){
					if((!StringUtil.isNullorEmpty(fwquestion.getSingleAnswer()))  && (!fwquestion.getSingleAnswer().equalsIgnoreCase("other") || (fwquestion.getSingleAnswer().equalsIgnoreCase("other") && !StringUtil.isNullorEmpty(fwquestion.getOtherText())))){
						fwquestion.setStatus("Completed");						
					}else{
						fwquestion.setStatus("Incomplete");	
						isCompleted=false;
					}
				}
				if(fwquestion.getOstiaQuestion().getAnswerType().equalsIgnoreCase("MULTISELECT")){
					if (fwquestion.getAnswersValue() != null && (!fwquestion.getAnswersValue().isEmpty() && !"[]".equals(fwquestion.getAnswersValue().toString()))) {
						fwquestion.setStatus("Completed");		

						boolean notMatched=true;
						
						for (String selectedanswer:selectedanswers) {
							if(!StringUtil.isNullorEmpty(selectedanswer)){
								FirewallRuleOstiaAnswer firewallRuleOstiaAnswer=existinganswers.get(selectedanswer);
								if(firewallRuleOstiaAnswer ==null ){
									FirewallRuleOstiaAnswer newAnswer=new FirewallRuleOstiaAnswer();
									newAnswer.setAnswer(selectedanswer);
									if(selectedanswer.equalsIgnoreCase("other")){
										newAnswer.setOtherText(fwquestion.getOtherText());
									}
									newAnswer.setUpdatedTIRequest(request);
									newAnswer.setFirewallRuleOstiaQuestion(fwquestion);
									newfirewallRuleOstiaAnswers.add(newAnswer);
								}else{
									if(selectedanswer.equalsIgnoreCase("other")){
										firewallRuleOstiaAnswer.setOtherText(fwquestion.getOtherText());
									}									
									firewallRuleOstiaAnswer.setUpdatedTIRequest(request);
									firewallRuleOstiaAnswer.setDeletedTIRequest(null);
								}		
							}
						
						}
						if(firewallRuleOstiaAnswers !=null && !firewallRuleOstiaAnswers.isEmpty()){
							for(FirewallRuleOstiaAnswer anwered:firewallRuleOstiaAnswers){
								notMatched=true;
								for (String selectedanswer:selectedanswers) {
									if(anwered.getAnswer().equalsIgnoreCase(selectedanswer)){
										notMatched=false;
									}
								}
								if(notMatched){
									anwered.setDeletedTIRequest(request);
								}
							}
						}
						
					}else{
						fwquestion.setStatus("Incomplete");	
						if(firewallRuleOstiaAnswers !=null && !firewallRuleOstiaAnswers.isEmpty()){
							for(FirewallRuleOstiaAnswer anwered:firewallRuleOstiaAnswers){							
								
									anwered.setDeletedTIRequest(request);

							}
						}
						isCompleted=false;
					}
				}
				if(firewallRuleOstiaAnswers ==null || firewallRuleOstiaAnswers.isEmpty()){
					fwquestion.setAnswers(new LinkedHashSet<FirewallRuleOstiaAnswer>());
				}
				fwquestion.getAnswers().addAll(newfirewallRuleOstiaAnswers);
			}
			if(isCompleted){
				updateFirewallRuleQuestionnaire(fireWallRuleProcess.getFirewallRuleQuestionnaire().getId(),"Completed");
			}else{
				updateFirewallRuleQuestionnaire(fireWallRuleProcess.getFirewallRuleQuestionnaire().getId(),"Incomplete");
			}
			
			for (FirewallRuleOstiaQuestion firewallRuleOstiaQuestion : fireWallRuleProcess.getFirewallRuleOstiaAnswers()) {
				getHibernateTemplate().saveOrUpdate(firewallRuleOstiaQuestion);
			}
			
			
		/*getHibernateTemplate().saveOrUpdate(
				fireWallRuleProcess.getFirewallRuleOstiaAnswers());*/

	}

	@Override
	public void cloneFirewallRuleOstiaAnswers(Long cloneFrom, List<Long> cloneTo) {
		Session session = getSession();
		String sql = "Update CON_FW_RULE_OSTIA_ANSWER toAns set toAns.answer = ( "+
		                "Select fromAns.answer "+
		                "From CON_FW_RULE_OSTIA_ANSWER  fromAns "+
		                "Where fromAns.fw_rule_qnnaire_id=:questionnaireId "+
		                    "And toAns.question_id=fromAns.question_id "+
		                ") "+
		"Where toAns.fw_rule_qnnaire_id in (:questionnaireList)";
		
		String sql1 = "Update CON_FW_RULE_OSTIA_ANSWER toAns set toAns.status = ( "+
        "Select fromAns.status "+
        "From CON_FW_RULE_OSTIA_ANSWER  fromAns "+
        "Where fromAns.fw_rule_qnnaire_id=:questionnaireId "+
            "And toAns.question_id=fromAns.question_id "+
        ") "+
        "Where toAns.fw_rule_qnnaire_id in (:questionnaireList)";
		
		

		
		Query query = session
		.createSQLQuery(sql).setLong("questionnaireId", cloneFrom)
		.setParameterList("questionnaireList", cloneTo);
		int resultedNo =query.executeUpdate();
		Query query1 = session
		.createSQLQuery(sql1).setLong("questionnaireId", cloneFrom)
		.setParameterList("questionnaireList", cloneTo);
		resultedNo =query1.executeUpdate();

/*		FirewallRuleQuestionnaire source = findFirewallRuleQuestionnaire(cloneFrom);
		List<FirewallRuleOstiaQuestion> sourceAnswers = source
				.getFirewallRuleOstiaAnswers();
		List<FirewallRuleQuestionnaire> targetsToUpdate = new ArrayList<FirewallRuleQuestionnaire>();
		for (Long targetId : cloneTo) {
			FirewallRuleQuestionnaire target = findFirewallRuleQuestionnaire(targetId);
			List<FirewallRuleOstiaQuestion> answers = target
					.getFirewallRuleOstiaAnswers();
			target.setStatus("Completed");
			for (FirewallRuleOstiaQuestion targetAnswer : answers) {
				for (FirewallRuleOstiaQuestion sourceAnswer : sourceAnswers) {
					if(targetAnswer.getOstiaQuestion().getId()==sourceAnswer.getOstiaQuestion().getId()){
						targetAnswer.setAnswer(sourceAnswer.getAnswer());
						targetAnswer.setStatus(sourceAnswer.getStatus());
					}
				}
				if(StringUtil.isNullorEmpty(targetAnswer.getAnswer())){
					target.setStatus("Incomplete");
				}

			}
			targetsToUpdate.add(target);
		}
		getHibernateTemplate().saveOrUpdateAll(targetsToUpdate);*/
	
		
	}
	@Override
	public void updateAnswer(List<Long> cloneTo) {
		try {
			for(Long to:cloneTo){
				FirewallRuleQuestionnaire firewallRuleQuestionnaire=findFirewallRuleQuestionnaire(to);
				boolean isCompleted=true;
				 List<FirewallRuleOstiaQuestion> answers=firewallRuleQuestionnaire.getFirewallRuleOstiaAnswers();
					for(FirewallRuleOstiaQuestion fwquestion:answers){
						
						try {
							if(fwquestion.getOstiaQuestion().getAnswerType().equalsIgnoreCase("TEXT")){
								if(StringUtil.isNullorEmpty(fwquestion.getTextAnswer())){						
									isCompleted=false;
								}
							
							}
							if(fwquestion.getOstiaQuestion().getAnswerType().equalsIgnoreCase("SELECT")){
								if(!((!StringUtil.isNullorEmpty(fwquestion.getSingleAnswer()))  && (!fwquestion.getSingleAnswer().equalsIgnoreCase("other") || (fwquestion.getSingleAnswer().equalsIgnoreCase("other") && !StringUtil.isNullorEmpty(fwquestion.getOtherText()))))){
									isCompleted=false;					
								}
							}
							if(fwquestion.getOstiaQuestion().getAnswerType().equalsIgnoreCase("MULTISELECT")){
								if (fwquestion.getAnswersValue() == null || fwquestion.getAnswersValue().isEmpty()) {
									isCompleted=false;
									
								}
							}
						} catch (Exception e) {
							log.error(e.getMessage());
							e.printStackTrace();
						}

					}
					if(isCompleted){
						updateFirewallRuleQuestionnaire(to,"Completed");
					}else{
						updateFirewallRuleQuestionnaire(to,"Incomplete");
					}

			}
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
	}
	

	@Override
	public void updateAnswer(FirewallRuleQuestionnaire firewallRuleQuestionnaire) {
		try {
			boolean isCompleted=true;
			List<FirewallRuleOstiaQuestion> answers=firewallRuleQuestionnaire.getFirewallRuleOstiaAnswers();
			for(FirewallRuleOstiaQuestion fwquestion:answers){
				
				try {
					if(fwquestion.getOstiaQuestion().getAnswerType().equalsIgnoreCase("TEXT")){
						if(StringUtil.isNullorEmpty(fwquestion.getTextAnswer())){						
							isCompleted=false;
						}
					
					}
					if(fwquestion.getOstiaQuestion().getAnswerType().equalsIgnoreCase("SELECT")){
						if(!((!StringUtil.isNullorEmpty(fwquestion.getSingleAnswer()))  && (!fwquestion.getSingleAnswer().equalsIgnoreCase("other") || (fwquestion.getSingleAnswer().equalsIgnoreCase("other") && !StringUtil.isNullorEmpty(fwquestion.getOtherText()))))){
							isCompleted=false;					
						}
					}
					if(fwquestion.getOstiaQuestion().getAnswerType().equalsIgnoreCase("MULTISELECT")){
						if (fwquestion.getAnswersValue() == null || fwquestion.getAnswersValue().isEmpty()) {
							isCompleted=false;
							
						}
					}
				} catch (Exception e) {
					log.error(e.getMessage());
					e.printStackTrace();
				}

			}
			if(isCompleted){
				updateFirewallRuleQuestionnaire(firewallRuleQuestionnaire.getId(),"Completed");
			}else{
				updateFirewallRuleQuestionnaire(firewallRuleQuestionnaire.getId(),"Incomplete");
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
	}
	  /**
     * 
     */
    @SuppressWarnings("unchecked")
	@Override
    public String saveOstiaQuestionnaire(FireWallRule firewallRule, OstiaQuestionnaire ostiaQuestionnaire, TIRequest tiRequest, boolean deleteFlag) {
    	log.info("saveOstiaQuestionnaire Starts.......");
    	Session session=getSession();
    	String ret = "";
    	if (deleteFlag) {
    		List<FirewallRuleQuestionnaire> firewallRuleQuestionnaires = null;
        	if (firewallRule != null) {
        		log.debug("deleteOstiaQuestionnaire - firewallRule ID......."+firewallRule.getId());
        		firewallRuleQuestionnaires = (List<FirewallRuleQuestionnaire>)session.createQuery("from FirewallRuleQuestionnaire where firewallRule.id = "
    					+firewallRule.getId()).list();
        		if (firewallRuleQuestionnaires != null) {
    	    	log.debug("firewallRuleQuestionnaires size   --------->"+firewallRuleQuestionnaires.size());
        		}
        	}
    		if (firewallRuleQuestionnaires != null && !firewallRuleQuestionnaires.isEmpty()) {
    			log.debug("deleteOstiaQuestionnaire - to delete all.......");
	    		for (FirewallRuleQuestionnaire ruleQuestionnaire : firewallRuleQuestionnaires) {
	    			ruleQuestionnaire.setDeletedTIRequest(tiRequest);
	    			ruleQuestionnaire.setUpdated_date(new Date());
	    			session.save(ruleQuestionnaire);
	    		}
	    		//session.saveOrUpdate(firewallRuleQuestionnaires);
    		}
    	} else {
	    	List<FirewallRuleQuestionnaire> firewallRuleQuestionnaires = null;
	    	if (firewallRule != null) {
	    		log.debug("saveOstiaQuestionnaire - firewallRule ID......."+firewallRule.getId());
	    		firewallRuleQuestionnaires = (List<FirewallRuleQuestionnaire>)session.createQuery("from FirewallRuleQuestionnaire where firewallRule.id = "
						+firewallRule.getId()+" and  deletedTIRequest is null").list();
	    		if (firewallRuleQuestionnaires != null) {
		    	log.debug("firewallRuleQuestionnaires size   --------->"+firewallRuleQuestionnaires.size());
	    		}
	    	}
	    	
	    	if (ostiaQuestionnaire != null && ostiaQuestionnaire.getRiskDefinitions() != null 
	    			&& !ostiaQuestionnaire.getRiskDefinitions().isEmpty()) {
	    		log.debug("saveOstiaQuestionnaire - Ostia RDs Available.......");
	    		
		    	boolean exists = false;
		    	
		    	if (firewallRuleQuestionnaires != null && !firewallRuleQuestionnaires.isEmpty()) {
		    		exists = true;
		    	}
		    	Set<String> riskCodes = new HashSet<String>();
		    	
		    	List<RiskDefinition> orgRiskDefinitions = ostiaQuestionnaire.getRiskDefinitions();
	    		for (RiskDefinition definition : orgRiskDefinitions) {
	    			riskCodes.add(definition.getRiskCode());
	    		}
		    	
		    	ostiaQuestionnaire = isOstiaQuestionnaireExists(ostiaQuestionnaire);
		    	log.debug("saveOstiaQuestionnaire - exists......."+exists);
		    	
		    	String baselineName = ostiaQuestionnaire.getBaselineName();
		    	ret = baselineName;
		    	if (exists) {
		    		for (FirewallRuleQuestionnaire ruleQuestionnaire : firewallRuleQuestionnaires) {
		    			Set<String> extRiskCodes = getFWRiskCodes(ruleQuestionnaire.getId());
		    			if (!baselineName.equals(ruleQuestionnaire.getBaselineName())
		    					|| !extRiskCodes.equals(riskCodes) || "RiskCheckNotDone".equalsIgnoreCase(ruleQuestionnaire.getStatus())) {
		    				log.debug("saveOstiaQuestionnaire - questionnaire to be updated.......");
		    				String extBaselineName = ruleQuestionnaire.getBaselineName();
		    				String extBaselineReportUrl = ruleQuestionnaire.getBaselineReportUrl();
		    				if (!baselineName.equals(ruleQuestionnaire.getBaselineName())) {
		    					ruleQuestionnaire.setLastBaselineName(extBaselineName);
		    					ruleQuestionnaire.setLastBaselineReportUrl(extBaselineReportUrl);
		    				}
			    			ruleQuestionnaire.setBaselineName(ostiaQuestionnaire.getBaselineName());
			    			ruleQuestionnaire.setBaselineReportUrl(ostiaQuestionnaire.getBaselineReportUrl());
			    			ruleQuestionnaire.setRuleExecutionDate(new Date());
			    			ruleQuestionnaire.setFirewallRule(firewallRule);
			    			ruleQuestionnaire.setQuestionnaire(ostiaQuestionnaire);
			    			ruleQuestionnaire.setUpdatedTIRequest(tiRequest);
			    			if (riskCodes != null && riskCodes.size() > 0 && riskCodes.contains("NO_RISK")) {
			    				ruleQuestionnaire.setStatus("ReviewNotRequired");
				    		} else {
				    			ruleQuestionnaire.setStatus("Incomplete");
				    		}
			    			
			    			List<FirewallRuleOstiaQuestion> firewallRuleOstiaAnswersNew 
			    						= checkOstiaAnswerExists(ruleQuestionnaire, riskCodes, tiRequest);
			    			ruleQuestionnaire.getFirewallRuleOstiaAnswers().addAll(firewallRuleOstiaAnswersNew);
			    			List<FirewallRuleOstiaQuestion> firewallRuleOstiaQuestions = ruleQuestionnaire.getFirewallRuleOstiaAnswers();
			    			
			    			if (firewallRuleOstiaQuestions != null && !firewallRuleOstiaQuestions.isEmpty()) {
				    			for (FirewallRuleOstiaQuestion firewallRuleOstiaQuestion : firewallRuleOstiaQuestions) {
				    				if (firewallRuleOstiaQuestion!= null) {
					    				firewallRuleOstiaQuestion.setUpdated_date(new Date());
					    				if(firewallRuleOstiaQuestion != null && !checkOstiaAnswerExists(firewallRuleOstiaQuestion, 
					    						orgRiskDefinitions)) {
					    					firewallRuleOstiaQuestion.setDeletedTIRequest(tiRequest);
					    					log.debug("saveOstiaQuestionnaire - question will be deleted......."+firewallRuleOstiaQuestion.getId());
					    				}
				    				}
				    	    	}
			    			} else {
			    				FirewallRuleOstiaQuestion firewallRuleOstiaQuestion = null;
			    	        	List<FirewallRuleOstiaQuestion> firewallRuleOstiaAnswersList = new ArrayList<FirewallRuleOstiaQuestion>();
			    	        		List<RiskDefinition> riskDefinitions = ostiaQuestionnaire.getRiskDefinitions();
			    	        		for (RiskDefinition definition : riskDefinitions) {
			    	        			if (!riskCodes.contains(definition.getRiskCode())) {
			    	        				continue;
			    	        			}
			    	            		 List<OstiaQuestion> ostiaQuestions  = definition.getOstiaQuestions();
			    	            	    	for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
			    	        	    			firewallRuleOstiaQuestion =  new FirewallRuleOstiaQuestion();
			    	        	    			firewallRuleOstiaQuestion.setOstiaQuestion(ostiaQuestion);
			    	        	    			firewallRuleOstiaQuestion.setAnswers(null);
			    	        	    			firewallRuleOstiaQuestion.setFirewallRuleQuestionnaire(ruleQuestionnaire);
			    	        	    			firewallRuleOstiaQuestion.setUpdatedTIRequest(tiRequest);
			    	            	    		firewallRuleOstiaAnswersList.add(firewallRuleOstiaQuestion);
			    	            	    	}
			    	            		}
			    	        		ruleQuestionnaire.setFirewallRuleOstiaAnswers(firewallRuleOstiaAnswersList);
			    			}
			    			ruleQuestionnaire.setUpdated_date(new Date());
			    			session.saveOrUpdate(ruleQuestionnaire);
		    			} /*else {
		    				if (ruleQuestionnaire != null && "RiskCheckNotDone".equalsIgnoreCase(ruleQuestionnaire.getStatus())) {
		    					ruleQuestionnaire.setUpdated_date(new Date());
		    					ruleQuestionnaire.setStatus("Incomplete");
		    					getHibernateTemplate().saveOrUpdate(ruleQuestionnaire);
		    				}
		    			}*/
			    	}
		    	} else {
		    		log.debug("saveOstiaQuestionnaire - New Questionnaire will be added.......");
		    		FirewallRuleQuestionnaire firewallRuleQuestionnaire = new FirewallRuleQuestionnaire();
		    		firewallRuleQuestionnaire.setType("Default");
		    		firewallRuleQuestionnaire.setStatus("Incomplete");
		    		firewallRuleQuestionnaire.setBaselineName(ostiaQuestionnaire.getBaselineName());
		    		firewallRuleQuestionnaire.setBaselineReportUrl(ostiaQuestionnaire.getBaselineReportUrl());
		    		firewallRuleQuestionnaire.setFirewallRule(firewallRule);
		    		firewallRuleQuestionnaire.setQuestionnaire(ostiaQuestionnaire);
		    		firewallRuleQuestionnaire.setUpdatedTIRequest(tiRequest);
		    		firewallRuleQuestionnaire.setRuleExecutionDate(new Date());
		    		firewallRuleQuestionnaire.setCalculatedRisk(0D);
		    		
		    		if (riskCodes != null && riskCodes.size() > 0 && riskCodes.contains("NO_RISK")) {
		    			firewallRuleQuestionnaire.setStatus("ReviewNotRequired");
		    		} else {
		    			firewallRuleQuestionnaire.setStatus("Incomplete");
		    		}
		    		
		    		FirewallRuleOstiaQuestion firewallRuleOstiaQuestion = null;
		        	List<FirewallRuleOstiaQuestion> firewallRuleOstiaAnswersList = new ArrayList<FirewallRuleOstiaQuestion>();
		        	log.debug("saveOstiaQuestionnaire - New Questionnaire will be added.......");
		        	log.debug("saveOstiaQuestionnaire - New Questionnaire will be added......."+riskCodes);
		        		List<RiskDefinition> riskDefinitions = ostiaQuestionnaire.getRiskDefinitions();
		        		for (RiskDefinition definition : riskDefinitions) {
		        			if (!riskCodes.contains(definition.getRiskCode())) {
		        				continue;
		        			}
		        			log.debug("saveOstiaQuestionnaire - New Questionnaire will be added......."+definition.getOstiaQuestions());
		            		 List<OstiaQuestion> ostiaQuestions  = definition.getOstiaQuestions();
		            	    	for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
		        	    			firewallRuleOstiaQuestion =  new FirewallRuleOstiaQuestion();
		        	    			firewallRuleOstiaQuestion.setOstiaQuestion(ostiaQuestion);
		        	    			firewallRuleOstiaQuestion.setAnswers(null);
		        	    			firewallRuleOstiaQuestion.setStatus("Incomplete");
		        	    			firewallRuleOstiaQuestion.setFirewallRuleQuestionnaire(firewallRuleQuestionnaire);
		        	    			firewallRuleOstiaQuestion.setUpdatedTIRequest(tiRequest);
		            	    		firewallRuleOstiaAnswersList.add(firewallRuleOstiaQuestion);
		            	    	}
		            		}
		        	firewallRuleQuestionnaire.setFirewallRuleOstiaAnswers(firewallRuleOstiaAnswersList);
		        	firewallRuleQuestionnaire.setUpdated_date(new Date());
		        	log.debug("saveOstiaQuestionnaire - firewallRuleOstiaAnswersList...."+firewallRuleOstiaAnswersList.size());
		    		getHibernateTemplate().save(firewallRuleQuestionnaire);
		    	}
	    	} else {
	    		log.debug("saveOstiaQuestionnaire - No Risk Definitions.......");
	    		if (firewallRuleQuestionnaires != null && !firewallRuleQuestionnaires.isEmpty()) {
		    		for (FirewallRuleQuestionnaire ruleQuestionnaire : firewallRuleQuestionnaires) {
		    			ruleQuestionnaire.setDeletedTIRequest(tiRequest);
		    			ruleQuestionnaire.setUpdated_date(new Date());
		    			ruleQuestionnaire.setCalculatedRisk(0D);
		    			session.save(ruleQuestionnaire);
		    		}
		    	//	session.saveOrUpdate(firewallRuleQuestionnaires); 
	    		}
	    	}
		} 
    	log.info("saveOstiaQuestionnaire Ends......."+ret);
    	return ret;
    }
    
    /**
     * 
     */
    @SuppressWarnings("unchecked")
    @Override
	public String saveRequestOstiaQuestionnaire(OstiaQuestionnaire ostiaQuestionnaire, TIRequest tiRequest) {
    	log.info("saveRequestOstiaQuestionnaire Starts.......");
    	
    	List<RequestQuestionnaire> requestQuestionnaires = null;
    	Session session=getSession();
    	System.out.println("Flush Mode is"+session.getFlushMode());
    	if (tiRequest != null) {
    		log.debug("saveRequestOstiaQuestionnaire - tirequest ID......."+tiRequest.getId());
    		requestQuestionnaires = (List<RequestQuestionnaire>)session.createQuery("from RequestQuestionnaire where tiRequest.id = "
					+tiRequest.getId()+" and  deletedTIRequest is null").list();
    		if (requestQuestionnaires != null) {
	    	log.debug("requestQuestionnaires size   --------->"+requestQuestionnaires.size());
    		}
    	}
    	String ret = "";
    	if (ostiaQuestionnaire != null && ostiaQuestionnaire.getRiskDefinitions() != null 
    			&& !ostiaQuestionnaire.getRiskDefinitions().isEmpty()) {
    		log.debug("saveRequestOstiaQuestionnaire - Ostia RDs Available.......");
    		
	    	boolean exists = false;
	    	
	    	if (requestQuestionnaires != null && !requestQuestionnaires.isEmpty()) {
	    		exists = true;
	    	}
	    	Set<String> riskCodes = new HashSet<String>();
	    	
	    	List<RiskDefinition> orgRiskDefinitions = ostiaQuestionnaire.getRiskDefinitions();
    		for (RiskDefinition definition : orgRiskDefinitions) {
    			riskCodes.add(definition.getRiskCode());
    		}
	    	
    		log.debug("saveRequestOstiaQuestionnaire - Risk Definitions......."+riskCodes);
    		
    		
	    	ostiaQuestionnaire = isOstiaQuestionnaireExists(ostiaQuestionnaire);
	    	log.debug("saveRequestOstiaQuestionnaire - exists......."+exists);
	    	
	    	String baselineName = ostiaQuestionnaire.getBaselineName();
	    	ret = baselineName;
	    	if (exists) {
	    		for (RequestQuestionnaire ruleQuestionnaire : requestQuestionnaires) {
	    			Set<String> extRiskCodes = getReqRiskCodes(ruleQuestionnaire.getId());
	    			if (!baselineName.equalsIgnoreCase(ruleQuestionnaire.getBaselineName())
	    					|| !extRiskCodes.equals(riskCodes)) {
	    				log.debug("saveOstiaQuestionnaire - questionnaire to be updated.......");
	    				String extBaselineName = ruleQuestionnaire.getBaselineName();
	    				String extBaselineReportUrl = ruleQuestionnaire.getBaselineReportUrl();
		    			ruleQuestionnaire.setLastBaselineName(extBaselineName);
		    			ruleQuestionnaire.setLastBaselineReportUrl(extBaselineReportUrl);
		    			ruleQuestionnaire.setBaselineName(ostiaQuestionnaire.getBaselineName());
		    			ruleQuestionnaire.setBaselineReportUrl(ostiaQuestionnaire.getBaselineReportUrl());
		    			ruleQuestionnaire.setRuleExecutionDate(new Date());
		    			ruleQuestionnaire.setQuestionnaire(ostiaQuestionnaire);
		    			ruleQuestionnaire.setTiRequest(tiRequest);
		    			ruleQuestionnaire.setUpdated_date(new Date());
		    			
		    			if (riskCodes != null && riskCodes.size() > 0 && riskCodes.contains("NO_RISK")) {
		    				ruleQuestionnaire.setStatus("ReviewNotRequired");
			    		} else {
			    			ruleQuestionnaire.setStatus("Completed");
			    		}
		    			
		    			List<RequestOstiaQuestion> requestQuestionsNew 
						= checkOstiaAnswerExists(ruleQuestionnaire, riskCodes, tiRequest);
						ruleQuestionnaire.getRequestOstiaQuestions().addAll(requestQuestionsNew);
						List<RequestOstiaQuestion> requestOstiaQuestions = ruleQuestionnaire.getRequestOstiaQuestions();
						
						if (requestOstiaQuestions != null && !requestOstiaQuestions.isEmpty()) {
			    			for (RequestOstiaQuestion requestOstiaQuestion : requestOstiaQuestions) {
			    				if (requestOstiaQuestion!= null) {
			    					requestOstiaQuestion.setUpdated_date(new Date());
				    				if(requestOstiaQuestion != null && !checkOstiaAnswerExists(requestOstiaQuestion, 
				    						orgRiskDefinitions)) {
				    					requestOstiaQuestion.setDeletedTIRequest(tiRequest);
				    					log.debug("saveRequestOstiaQuestionnaire - question will be deleted......."+requestOstiaQuestion.getId());
				    				}
			    				}
			    	    	}
						} else {
							RequestOstiaQuestion requestOstiaQuestion = null;
							List<RequestOstiaQuestion> requestOstiaQuestionsList = new ArrayList<RequestOstiaQuestion>();
				        	List<RiskDefinition> riskDefinitions = ostiaQuestionnaire.getRiskDefinitions();
			        		for (RiskDefinition definition : riskDefinitions) {
			        			if (!riskCodes.contains(definition.getRiskCode())) {
			        				continue;
			        			}
			            		 List<OstiaQuestion> ostiaQuestions  = definition.getOstiaQuestions();
			            	    	for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
			            	    		requestOstiaQuestion =  new RequestOstiaQuestion();
			            	    		requestOstiaQuestion.setOstiaQuestion(ostiaQuestion);
			            	    		requestOstiaQuestion.setRequestQuestionnaire(ruleQuestionnaire);
			            	    		requestOstiaQuestion.setUpdatedTIRequest(tiRequest);
			            	    		requestOstiaQuestionsList.add(requestOstiaQuestion);
			            	    	}
			            		}
			        		ruleQuestionnaire.setRequestOstiaQuestions(requestOstiaQuestionsList);
			        		session.save(ruleQuestionnaire);
						}
		    			
						//session.saveOrUpdate(ruleQuestionnaire);
	    			}
		    	}
	    	} else {
	    		log.debug("saveRequestOstiaQuestionnaire - New Questionnaire will be added.......");
	    		RequestQuestionnaire requestQuestionnaire = new RequestQuestionnaire();
	    		requestQuestionnaire.setType("Default");
	    		if (riskCodes != null && riskCodes.size() > 0 && riskCodes.contains("NO_RISK")) {
	    			requestQuestionnaire.setStatus("ReviewNotRequired");
	    		} else {
	    			requestQuestionnaire.setStatus("Completed");
	    		}
	    		requestQuestionnaire.setBaselineName(ostiaQuestionnaire.getBaselineName());
	    		requestQuestionnaire.setBaselineReportUrl(ostiaQuestionnaire.getBaselineReportUrl());
	    		requestQuestionnaire.setQuestionnaire(ostiaQuestionnaire);
	    		requestQuestionnaire.setTiRequest(tiRequest);
	    		requestQuestionnaire.setRuleExecutionDate(new Date());
	    		requestQuestionnaire.setUpdated_date(new Date());
	        	
	    		RequestOstiaQuestion requestOstiaQuestion = null;
				List<RequestOstiaQuestion> requestOstiaQuestionsList = new ArrayList<RequestOstiaQuestion>();
	        	List<RiskDefinition> riskDefinitions = ostiaQuestionnaire.getRiskDefinitions();
        		for (RiskDefinition definition : riskDefinitions) {
        			if (!riskCodes.contains(definition.getRiskCode())) {
        				continue;
        			}
            		 List<OstiaQuestion> ostiaQuestions = definition.getOstiaQuestions();
            	     for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
        	    		requestOstiaQuestion =  new RequestOstiaQuestion();
        	    		requestOstiaQuestion.setOstiaQuestion(ostiaQuestion);
        	    		requestOstiaQuestion.setStatus("Completed");
        	    		requestOstiaQuestion.setRequestQuestionnaire(requestQuestionnaire);
        	    		requestOstiaQuestion.setUpdatedTIRequest(tiRequest);
        	    		requestOstiaQuestionsList.add(requestOstiaQuestion);
            	    }
            	}
        		requestQuestionnaire.setRequestOstiaQuestions(requestOstiaQuestionsList);
        		log.debug("saveRequestOstiaQuestionnaire - requestOstiaQuestionsList......."+requestOstiaQuestionsList.size());
        		session.save(requestQuestionnaire);
	    	}
    	} else {
    		log.debug("saveRequestOstiaQuestionnaire - No Risk Definitions.......");
    		if (requestQuestionnaires != null && !requestQuestionnaires.isEmpty()) {
	    		for (RequestQuestionnaire ruleQuestionnaire : requestQuestionnaires) {
	    			ruleQuestionnaire.setDeletedTIRequest(tiRequest);
	    			ruleQuestionnaire.setUpdated_date(new Date());
	    			session.saveOrUpdate(ruleQuestionnaire);
	    		}
	    		//session.saveOrUpdate(requestQuestionnaires);
    		}
    	}
    	log.info("saveRequestOstiaQuestionnaire Ends......."+ret);
    	return ret;
    }
    
    /**
     * 
     * @param ostiaQuestionnaire
     * @return
     */
    @SuppressWarnings("unchecked")
	private OstiaQuestionnaire isOstiaQuestionnaireExists(OstiaQuestionnaire ostiaQuestionnaire) {
    	log.info("isOstiaQuestionnaireExists Starts.......");
    	Session session = getSession();
    	OstiaQuestionnaire ostiaQuestionnaireExt = null;
    	if (ostiaQuestionnaire != null) {
    	    List<OstiaQuestionnaire> ostiaQuestionnaires = 
    	    	(List<OstiaQuestionnaire>)session.createQuery("from OstiaQuestionnaire where code = '"
    	    					+ostiaQuestionnaire.getCode()+"'").list();
    		
    	    String oldBaselineName = sendEmailOnBaseLineChange(ostiaQuestionnaire);
    	    
    	    if (ostiaQuestionnaires != null && !ostiaQuestionnaires.isEmpty()) {
    	    	ostiaQuestionnaireExt = ostiaQuestionnaires.get(0);
    	    	/*ostiaQuestionnaireExt.setDescription(ostiaQuestionnaire.getDescription());
    	    	ostiaQuestionnaireExt.setBaselineName(ostiaQuestionnaire.getBaselineName());
    	    	ostiaQuestionnaireExt.setBaselineReportUrl(ostiaQuestionnaire.getBaselineReportUrl());
    	    	log.debug("isOstiaQuestionnaireExists Starts.......updated "+ostiaQuestionnaireExt.getId());
    	    	getHibernateTemplate().update(ostiaQuestionnaireExt);*/
    	    } else {
    	    	session.save(ostiaQuestionnaire);
    	    	log.debug("isOstiaQuestionnaireExists Starts.......created "+ostiaQuestionnaire.getId());
    	    	ostiaQuestionnaireExt = ostiaQuestionnaire;
    	    }
    	    for (RiskDefinition definition : ostiaQuestionnaire.getRiskDefinitions()) {
    	    	definition = isRiskDefinitionExists(definition, ostiaQuestionnaireExt, oldBaselineName);
    	    	definition.setQuestionnaire(ostiaQuestionnaireExt);
        	}
    	}
    	log.info("isOstiaQuestionnaireExists Ends.......");
    	return ostiaQuestionnaireExt;
    }
    
    /**
     * 
     * @param ostiaQuestionnaire
     */
    @SuppressWarnings("unchecked")
	private String sendEmailOnBaseLineChange(OstiaQuestionnaire ostiaQuestionnaire) {
    	log.info("isOstiaQuestionnaireExists Starts.......");
    	Session session = getSession();
    	String oldBaseLine = null;
    	 List<OstiaQuestionnaire> ostiaQuestionnaires = 
 	    	(List<OstiaQuestionnaire>)session.createQuery("from OstiaQuestionnaire where baselineName = '"+ostiaQuestionnaire.getBaselineName()+"'").list();
    	 
    	 if (ostiaQuestionnaires == null || ostiaQuestionnaires.isEmpty()) {
    		 //Send Mail
    		 ostiaQuestionnaires = 
    	 	    	(List<OstiaQuestionnaire>)session.createQuery("from OstiaQuestionnaire where code in ('NETWORK_QNNAIRE','REQUEST_QNNAIRE')").list();
    		 
    		 if (ostiaQuestionnaires != null && !ostiaQuestionnaires.isEmpty()) {
    			 oldBaseLine = "";
    			 String newBaseLine = ostiaQuestionnaire.getBaselineName();
    			 
    			 try {
    			 session.createSQLQuery("{ call COPY_HISTORY_OSTIA }").executeUpdate();
    			 } catch (Exception e) {
    				 e.printStackTrace();
    				 log.error(e, e);
    			 }
    			 
    			 for (OstiaQuestionnaire questionnaire : ostiaQuestionnaires) {
    				 oldBaseLine = questionnaire.getBaselineName();
	    			 questionnaire.setDescription(ostiaQuestionnaire.getDescription());
	    			 questionnaire.setBaselineName(ostiaQuestionnaire.getBaselineName());
	    			 questionnaire.setBaselineReportUrl(ostiaQuestionnaire.getBaselineReportUrl());
	    			 questionnaire.setNotificationSent("Y");
	    			 questionnaire.setNotificationSentDate(new Date());
	    			 session.saveOrUpdate(questionnaire);
    			 }
    			// session.saveOrUpdate(ostiaQuestionnaires);
    			 try {
					mailModuleImpl.sendEmailOnBaseLineChange(oldBaseLine, newBaseLine);
				} catch (Exception e) {
					e.printStackTrace();
				}
    		 }
    	 }
    	 return oldBaseLine;
    }
    
    /**
     * 
     * @param riskDefinition
     * @return
     */
    @SuppressWarnings("unchecked")
	private RiskDefinition isRiskDefinitionExists(RiskDefinition riskDefinition, OstiaQuestionnaire ostiaQuestionnaire, String oldBaselineName) {
    	log.info("isRiskDefinitionExists Starts.......");
    	System.out.println("isRiskDefinitionExists RiskDefinition......."+riskDefinition.getRiskCode());
    	Session session = getSession();
    	List<RiskDefinition> definitions = (List<RiskDefinition>)session.createQuery("from RiskDefinition where riskCode = '"
				+riskDefinition.getRiskCode()+"' and questionnaire.id = "+
						+ostiaQuestionnaire.getId()).list();
    	
    	RiskDefinition riskDefinitionExt = null;
    	
    	if (definitions != null && !definitions.isEmpty()) {
    		System.out.println("isRiskDefinitionExists RiskDefinition available......."+riskDefinition.getRiskCode());
    		riskDefinitionExt = definitions.get(0);
    		riskDefinitionExt.setRiskDescription(riskDefinition.getRiskDescription());
    		riskDefinitionExt.setRiskRating(riskDefinition.getRiskRating());
    		session.update(riskDefinitionExt);
    	} else {
    		System.out.println("isRiskDefinitionExists RiskDefinition not available......."+riskDefinition.getRiskCode());
    		session.save(riskDefinition);
	    	riskDefinitionExt = riskDefinition;
	    }
    	List<OstiaQuestion> ostiaQuestions  = riskDefinition.getOstiaQuestions();
    	List<OstiaQuestion> existingOstiaQuestions  = riskDefinitionExt.getOstiaQuestions();
    	List<OstiaQuestion> updatedOstiaQuestions = new ArrayList<OstiaQuestion>();
    	List<OstiaQuestion> deletedOstiaQuestions = new ArrayList<OstiaQuestion>();
    	if (ostiaQuestions != null && !ostiaQuestions.isEmpty()) {
	    	for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
	    		ostiaQuestion = isOstiaQuestionExists(ostiaQuestion, riskDefinitionExt);
	    		ostiaQuestion.setRiskDefinition(riskDefinitionExt);
	    		updatedOstiaQuestions.add(ostiaQuestion);
	    	}
    	}
    	
    	if (oldBaselineName != null) {
    		log.debug("Baseline Changed------------------");
	    	if (ostiaQuestions != null && !ostiaQuestions.isEmpty()
	    			&& existingOstiaQuestions != null && !existingOstiaQuestions.isEmpty()) {
	    		for (OstiaQuestion existingOstiaQuestion : existingOstiaQuestions) {
	    			if (existingOstiaQuestion.getQuestionControlNumber() != null) {
	    				boolean deleted = true;
		    			for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
		    	    		if (ostiaQuestion.getQuestionControlNumber() != null
		    	    				&& existingOstiaQuestion.getQuestionControlNumber().equalsIgnoreCase(ostiaQuestion.getQuestionControlNumber())) {
		    	    			deleted = false;
		    	    			break;
		    	    		}
		    	    	}
		    			if (deleted) {
		    				deletedOstiaQuestions.add(existingOstiaQuestion);
		    			}
	    			}
		    	}
	    	}
	    	if (deletedOstiaQuestions != null && !deletedOstiaQuestions.isEmpty()) {
	    		log.debug("Baseline Changed and questions removed------------------");
	    		RiskDefinition definition = new RiskDefinition();
	    		definition.setRiskCode(riskDefinitionExt.getRiskCode()+"_"+oldBaselineName);
	    		definition.setOstiaQuestions(deletedOstiaQuestions);
	    		definition.setRiskDescription(riskDefinitionExt.getRiskDescription());
	    		definition.setRiskRating(riskDefinitionExt.getRiskRating());
	    		definition.setQuestionnaire(ostiaQuestionnaire);
	    		session.save(definition);
	    	}
    	}
    	riskDefinitionExt.setOstiaQuestions(updatedOstiaQuestions);
    	
    	log.info("isRiskDefinitionExists Ends.......");
    	return riskDefinitionExt;
    }
    
    /**
     * 
     * @param ostiaQuestion
     * @return
     */
    @SuppressWarnings("unchecked")
	private OstiaQuestion isOstiaQuestionExists(OstiaQuestion ostiaQuestion, RiskDefinition riskDefinition) {
    	log.info("isOstiaQuestionExists Starts.......");
    	Session session = getSession();
    	List<OstiaQuestion> ostiaQuestions = (List<OstiaQuestion>)session.createQuery("from OstiaQuestion where " +
    			" questionControlNumber = '"+
    			ostiaQuestion.getQuestionControlNumber()+"'"+
    			" and riskDefinition.id = "+
    			riskDefinition.getId()).list();

    	OstiaQuestion ostiaQuestionExt = null;
    	if (ostiaQuestions != null && !ostiaQuestions.isEmpty()) {
    		ostiaQuestionExt = ostiaQuestions.get(0);
    		ostiaQuestionExt.setQuestion(ostiaQuestion.getQuestion());
    		ostiaQuestionExt.setAnswerType(ostiaQuestion.getAnswerType());
    		ostiaQuestionExt.setHint(ostiaQuestion.getHint());
    		session.update(ostiaQuestionExt);
    	}  else {
    		session.save(ostiaQuestion);
	    	//ostiaQuestion.setRiskDefinition(riskDefinition);
	    	ostiaQuestionExt = ostiaQuestion;
	    }
    	
    	List<PossibleAnswers> updatedPossibleAnswersList = new ArrayList<PossibleAnswers>(); 
    	List<PossibleAnswers> possibleAnswersList = ostiaQuestion.getPossibleAnswers();
    	if (possibleAnswersList != null && !possibleAnswersList.isEmpty()) {
	    	for (PossibleAnswers possibleAnswers : possibleAnswersList) {
	    		possibleAnswers = isPossibleAnswersExists(possibleAnswers, ostiaQuestionExt);
	    		updatedPossibleAnswersList.add(possibleAnswers);
	    	}
    	}
    	
    	/*if (extpossibleAnswersList != null && extpossibleAnswersList.size() > 0) {
	    	// To Delete the possible Answers those are removed from Team Server 
	    	List<PossibleAnswers> updatedPossibleAnswersList = new ArrayList<PossibleAnswers>(); 
	    	if (extpossibleAnswersList != null && !extpossibleAnswersList.isEmpty()) {
	    		for (PossibleAnswers possibleAnswers : extpossibleAnswersList) {
	    			if (checkPossibleAnswersExists(fromRuleEngine, possibleAnswers)) {
	    				updatedPossibleAnswersList.add(possibleAnswers);
	    			}
	    		}
	    	}
	    	ostiaQuestionExt.setPossibleAnswers(updatedPossibleAnswersList);
    	}*/
    	ostiaQuestionExt.setPossibleAnswers(updatedPossibleAnswersList);
    	log.info("isOstiaQuestionExists Ends.......");
    	return ostiaQuestionExt;
    }
    
    /**
     * 
     * @param possibleAnswers
     * @return
     */
    @SuppressWarnings("unchecked")
	private PossibleAnswers isPossibleAnswersExists(PossibleAnswers possibleAnswers, OstiaQuestion ostiaQuestion) {
    	log.info("isPossibleAnswersExists Starts.......");
    	Session session = getSession();
    	List<PossibleAnswers> possibleAnswersList = (List<PossibleAnswers>)session.createQuery("from PossibleAnswers where " +
    			" ostiaQuestion.id = "+ ostiaQuestion.getId() +" and optionsGroupName = '"+
    			possibleAnswers.getOptionsGroupName()+"' and answer = '"+possibleAnswers.getAnswer()+"'").list();
    	if (possibleAnswersList != null && !possibleAnswersList.isEmpty()) {
    		possibleAnswers = possibleAnswersList.get(0);
    	} else {
    		possibleAnswers.setOstiaQuestion(ostiaQuestion);
    		session.save(possibleAnswers);
	    }
    	log.info("isPossibleAnswersExists Ends.......");
    	return possibleAnswers;
    }
    
    private boolean checkPossibleAnswersExists(List<PossibleAnswers> possibleAnswersList, PossibleAnswers possibleAnswer) {
    	for (PossibleAnswers possibleAnswers : possibleAnswersList) {
    		if (possibleAnswers != null && possibleAnswer != null 
    				&& possibleAnswer.getOstiaQuestion() != null && possibleAnswers.getOstiaQuestion() != null
    				&& possibleAnswer.getOptionsGroupName().equals(possibleAnswers.getOptionsGroupName())
    				&& possibleAnswer.getOstiaQuestion().getId().equals(possibleAnswers.getOstiaQuestion().getId())
    				&& possibleAnswer.getAnswer().equals(possibleAnswers.getAnswer())) {
    					return true;
    				}
    	}
    	return false;
    }
    
    /**
     * 
     * @param ruleQuestionnaire
     * @param tiRequest
     * @return
     */
    @SuppressWarnings("unchecked")
	private List<FirewallRuleOstiaQuestion> checkOstiaAnswerExists(FirewallRuleQuestionnaire ruleQuestionnaire, 
    					Set<String> riskCodes, TIRequest tiRequest) {
    	log.info("checkOstiaAnswerExists Starts.......");
    	Session session = getSession();
    	FirewallRuleOstiaQuestion firewallRuleOstiaQuestion = null;
    	List<FirewallRuleOstiaQuestion> firewallRuleOstiaAnswersList = new ArrayList<FirewallRuleOstiaQuestion>();
    	if (ruleQuestionnaire!= null) {
    		List<RiskDefinition> riskDefinitions = ruleQuestionnaire.getQuestionnaire().getRiskDefinitions();
    		for (RiskDefinition definition : riskDefinitions) {
    			if (!riskCodes.contains(definition.getRiskCode())) {
    				continue;
    			}
        		 List<OstiaQuestion> ostiaQuestions  = definition.getOstiaQuestions();
        	    	for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
        	    		List<FirewallRuleOstiaQuestion> firewallRuleOstiaQuestions 
        	    					= (List<FirewallRuleOstiaQuestion>)session.createQuery("from FirewallRuleOstiaQuestion where " +
        	    							" deletedTIRequest is null and ostiaQuestion.id = "+ostiaQuestion.getId()+
        	    							" and firewallRuleQuestionnaire.id = "+ruleQuestionnaire.getId()).list();
        	    		
        	    		if (firewallRuleOstiaQuestions != null && !firewallRuleOstiaQuestions.isEmpty()) {
        	    			//firewallRuleOstiaAnswer = firewallRuleOstiaAnswers.get(0);
        	    		} else {
        	    			firewallRuleOstiaQuestion =  new FirewallRuleOstiaQuestion();
        	    			firewallRuleOstiaQuestion.setOstiaQuestion(ostiaQuestion);
        	    			firewallRuleOstiaQuestion.setAnswers(null);
        	    			firewallRuleOstiaQuestion.setStatus("Incomplete");
        	    			firewallRuleOstiaQuestion.setFirewallRuleQuestionnaire(ruleQuestionnaire);
        	    			firewallRuleOstiaQuestion.setUpdatedTIRequest(tiRequest);
        	    		}
        	    		firewallRuleOstiaAnswersList.add(firewallRuleOstiaQuestion);
        	    	}
        		}
         	}
    	log.info("firewallRuleOstiaAnswersList ......."+firewallRuleOstiaAnswersList.size());
    	log.info("checkOstiaAnswerExists Ends.......");
    	return firewallRuleOstiaAnswersList;
    }
    
    @SuppressWarnings("unchecked")
	private Set<String> getFWRiskCodes(Long id) {
    	Set<String> riskCodes = new HashSet<String>();
    	List<FirewallRuleOstiaQuestion> firewallRuleOstiaQuestions 
		= (List<FirewallRuleOstiaQuestion>)getSession().createQuery("from FirewallRuleOstiaQuestion where " +
				" deletedTIRequest is null "+
				" and firewallRuleQuestionnaire.id = "+id).list();
    	if (firewallRuleOstiaQuestions != null && !firewallRuleOstiaQuestions.isEmpty()) {
			for (FirewallRuleOstiaQuestion firewallRuleOstiaQuestion : firewallRuleOstiaQuestions) {
				if (firewallRuleOstiaQuestion.getOstiaQuestion() != null
						&& firewallRuleOstiaQuestion.getOstiaQuestion().getRiskDefinition() != null) {
					riskCodes.add(firewallRuleOstiaQuestion.getOstiaQuestion().getRiskDefinition().getRiskCode());
				}
			}
		} 
    	return riskCodes;
    }
    
    @SuppressWarnings("unchecked")
	private Set<String> getReqRiskCodes(Long id) {
    	Set<String> riskCodes = new HashSet<String>();
    	List<RequestOstiaQuestion> firewallRuleOstiaQuestions 
		= (List<RequestOstiaQuestion>)getSession().createQuery("from RequestOstiaQuestion where " +
				" deletedTIRequest is null "+
				" and requestQuestionnaire.id = "+id).list();
    	if (firewallRuleOstiaQuestions != null && !firewallRuleOstiaQuestions.isEmpty()) {
			for (RequestOstiaQuestion firewallRuleOstiaQuestion : firewallRuleOstiaQuestions) {
				if (firewallRuleOstiaQuestion.getOstiaQuestion() != null
						&& firewallRuleOstiaQuestion.getOstiaQuestion().getRiskDefinition() != null) {
					riskCodes.add(firewallRuleOstiaQuestion.getOstiaQuestion().getRiskDefinition().getRiskCode());
				}
			}
		} 
    	return riskCodes;
    }
       	
    /**
     * 
     * @param firewallRuleOstiaQuestion
     * @param ostiaQuestionnaire
     * @return
     */
    private boolean checkOstiaAnswerExists(FirewallRuleOstiaQuestion firewallRuleOstiaQuestion, 
    		List<RiskDefinition> orgRiskDefinitions) {
    	log.info("checkOstiaAnswerExists2 Starts .......");
    	if (firewallRuleOstiaQuestion.getOstiaQuestion() != null
    			&& firewallRuleOstiaQuestion.getOstiaQuestion().getRiskDefinition() != null) {
	    	String questionControlNumber =  firewallRuleOstiaQuestion.getOstiaQuestion().getQuestionControlNumber();
	    	String riskCode = firewallRuleOstiaQuestion.getOstiaQuestion().getRiskDefinition().getRiskCode();
	    	for (RiskDefinition definition : orgRiskDefinitions) {
	    		if (riskCode.equalsIgnoreCase(definition.getRiskCode())) {
	    		 List<OstiaQuestion> ostiaQuestions  = definition.getOstiaQuestions();
	    	    	for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
	    	    		if (ostiaQuestion.getQuestionControlNumber().equals(questionControlNumber)) {
	    	    			return true;
	    	    		}
	    	    	}
	    		}
	     	}
    	}
    	log.info("checkOstiaAnswerExists2 Ends .......");
    	return false;
    }
    
    /**
     * 
     * @param ruleQuestionnaire
     * @param tiRequest
     * @return
     */
    private List<RequestOstiaQuestion> checkOstiaAnswerExists(RequestQuestionnaire requestQuestionnaire, 
    					Set<String> riskCodes, TIRequest tiRequest) {
    	log.info("checkOstiaAnswerExists Starts.......");
    	Session session = getSession();
    	RequestOstiaQuestion requestOstiaQuestion = null;
    	List<RequestOstiaQuestion> requestOstiaQuestionList = new ArrayList<RequestOstiaQuestion>();
    	if (requestQuestionnaire!= null) {
    		List<RiskDefinition> riskDefinitions = requestQuestionnaire.getQuestionnaire().getRiskDefinitions();
    		 if (riskDefinitions != null) {
    			 log.info("checkOstiaAnswerExists.....riskDefinitions ......."+riskDefinitions.size());
    		 } else {
    			 log.info("checkOstiaAnswerExists.....riskDefinitions .......empty");
    		 }
    		for (RiskDefinition definition : riskDefinitions) {
    			if (!riskCodes.contains(definition.getRiskCode())) {
    				continue;
    			}
        		 List<OstiaQuestion> ostiaQuestions  = definition.getOstiaQuestions();
        		 if (ostiaQuestions != null) {
        			 log.info("checkOstiaAnswerExists.....ostiaQuestions for "+definition.getRiskCode()+" ......."+ostiaQuestions.size());
        		 } else {
        			 log.info("checkOstiaAnswerExists.....ostiaQuestions for "+definition.getRiskCode()+".......empty");
        		 }
        	    	for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
        	    		List<RequestOstiaQuestion> firewallRuleOstiaQuestions 
        	    					= (List<RequestOstiaQuestion>)session.createQuery("from RequestOstiaQuestion where " +
        	    							" deletedTIRequest is null and ostiaQuestion.id = "+ostiaQuestion.getId()+
        	    							" and requestQuestionnaire.id = "+requestQuestionnaire.getId()).list();
        	    		
        	    		if (firewallRuleOstiaQuestions != null && !firewallRuleOstiaQuestions.isEmpty()) {
        	    			//firewallRuleOstiaAnswer = firewallRuleOstiaAnswers.get(0);
        	    		} else {
        	    			requestOstiaQuestion =  new RequestOstiaQuestion();
        	    			requestOstiaQuestion.setOstiaQuestion(ostiaQuestion);
        	    			requestOstiaQuestion.setRequestQuestionnaire(requestQuestionnaire);
        	    			requestOstiaQuestion.setStatus("Completed");
        	    			requestOstiaQuestion.setUpdatedTIRequest(tiRequest);
        	    		}
        	    		requestOstiaQuestionList.add(requestOstiaQuestion);
        	    	}
        		}
         }
    	log.info("requestOstiaQuestionList ......."+requestOstiaQuestionList.size());
    	log.info("checkOstiaAnswerExists Ends.......");
    	return requestOstiaQuestionList;
    }
    
    /**
     * 
     * @param firewallRuleOstiaQuestion
     * @param ostiaQuestionnaire
     * @return
     */
    private boolean checkOstiaAnswerExists(RequestOstiaQuestion requestOstiaQuestion, 
    		List<RiskDefinition> orgRiskDefinitions) {
    	log.info("checkOstiaAnswerExists2 Starts .......");
    	if (requestOstiaQuestion.getOstiaQuestion() != null
    			&& requestOstiaQuestion.getOstiaQuestion().getRiskDefinition() != null) {
	    	String questionControlNumber =  requestOstiaQuestion.getOstiaQuestion().getQuestionControlNumber();
	    	String riskCode = requestOstiaQuestion.getOstiaQuestion().getRiskDefinition().getRiskCode();
	    	for (RiskDefinition definition : orgRiskDefinitions) {
	    		if (riskCode.equalsIgnoreCase(definition.getRiskCode())) {
	    		 List<OstiaQuestion> ostiaQuestions  = definition.getOstiaQuestions();
	    	    	for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
	    	    		if (ostiaQuestion.getQuestionControlNumber().equals(questionControlNumber)) {
	    	    			return true;
	    	    		}
	    	    	}
	    		}
	     	}
    	}
    	log.info("checkOstiaAnswerExists2 Ends .......");
    	return false;
    }
    	
    
    @Override
	public FirewallRuleQuestionnaire findFirewallRuleQuestionnaire(Long id) {
    	log.info("findFirewallRuleQuestionnaire Starts .......");
		Session session = getSession();
		FirewallRuleQuestionnaire firewallRuleQuestionnaire = (FirewallRuleQuestionnaire) session
		.createQuery(
				"from FirewallRuleQuestionnaire rule where rule.id="
						+ id).uniqueResult();
		lazyInitialize(firewallRuleQuestionnaire.getFirewallRuleOstiaAnswers());
		//session.close();
		log.info("findFirewallRuleQuestionnaire Ends .......");
		return firewallRuleQuestionnaire;
	}
    
	@Override
	public Long addUserFirewallRuleQuestionnaire(FirewallRuleQuestionnaire firewallRuleQuestionnaireTarget) {
		
		/*FirewallRuleQuestionnaire firewallRuleQuestionnaire = (FirewallRuleQuestionnaire) session
		.createQuery(
				"from FirewallRuleQuestionnaire rule where rule.id="
						+ id).uniqueResult();
		FirewallRuleQuestionnaire firewallRuleQuestionnaireTarget=new FirewallRuleQuestionnaire();
	BeanUtils.copyProperties(firewallRuleQuestionnaire, firewallRuleQuestionnaireTarget);*/
	firewallRuleQuestionnaireTarget.setId(null);
	firewallRuleQuestionnaireTarget.setType("User");
	firewallRuleQuestionnaireTarget.setStatus("Incomplete");
	firewallRuleQuestionnaireTarget.getUserQuestionnaire();
	/*log.info("User Questionnaire Name : +++++++++++++++++++++++++++++++++++++++ "+firewallRuleQuestionnaireTarget.getUserQuestionnaire());*/
	log.info("User Questionnaire Name New : +++++++++++++++++++++++++++++++++++++++ "+ firewallRuleQuestionnaireTarget.getUserQuestionnaire());	
	List<FirewallRuleOstiaQuestion> answers=firewallRuleQuestionnaireTarget.getFirewallRuleOstiaAnswers();
		for(FirewallRuleOstiaQuestion answer:answers){
			answer.setId(null);
			answer.setAnswers(null);
			answer.setStatus("Incomplete");
			answer.setSingleAnswer(null);
			answer.setOtherText(null);
			answer.setTextAnswer(null);
		}
		return (Long) getHibernateTemplate().save(firewallRuleQuestionnaireTarget);
		
	}

	@Override
	public void updateFirewallRuleQuestionnaire(
			long fwQuestionnaireId,String status) {
		String hql=" update FirewallRuleQuestionnaire set status=? where id= ?";
		
		Session session = getSession();
		session.createQuery(hql)
	    .setString(0,status)
	    .setLong(1,fwQuestionnaireId).executeUpdate();
	
		
	}
	@Override
	public HashMap<String,List<FirewallRuleOstiaQuestion>> findFirewallRuleOstiaMapAnswers(
			FireWallRuleProcess fireWallRuleProcess) {
		Session session = getSession();
		List<FirewallRuleOstiaQuestion> list = new ArrayList<FirewallRuleOstiaQuestion>();

		
		String queryString = " select risk.risk_code as riskcode, answer.* "+
		 " from CON_FW_RULE_OSTIA_QUESTION answer, "+
		 " ostia_question  osques,risk_definition risk "+
		 " where answer.FW_RULE_QNNAIRE_ID = "+fireWallRuleProcess.getFirewallRuleQuestionnaire().getId()+
         " and answer.QUESTION_ID = osques.ID " + 
		 " and osques.RISK_DEFINITION_ID = risk.id";
	
		//log.info("ostiaMap query " +queryString.toString());
		//log.info("Osita Test Rule Id : " +fireWallRuleProcess.getRuleId());
		//log.info("Osita Test Rule Id : " +fireWallRuleProcess.getFirewallRuleQuestionnaire().getId());
		
		SQLQuery query =  session.createSQLQuery(queryString);
		
		query.addScalar("riskcode", StringType.INSTANCE);
		query.addEntity("answer", FirewallRuleOstiaQuestion.class);
		
		   List<Object[]> rows = query.list();
		   
		   HashMap<String,List<FirewallRuleOstiaQuestion>> ostiaMap = new HashMap<String,List<FirewallRuleOstiaQuestion>>();
		 
		   if(rows != null){
			   for (Object[] obj : rows) {
				    String riskCode = (String)obj[0];
					   if (ostiaMap.containsKey(riskCode)) {
						   ostiaMap.get(riskCode).add((FirewallRuleOstiaQuestion) obj[1]);
					   } else {
						   list = new ArrayList<FirewallRuleOstiaQuestion>();
						   list.add((FirewallRuleOstiaQuestion) obj[1]);
						   ostiaMap.put(riskCode, list);
					   }
				     
		   }
		   
		  
		   //log.info("ostiaMap" +ostiaMap.toString());
		   }
		   
		/*list = (List<FirewallRuleOstiaAnswer>) session
				.createQuery(
						"from FirewallRuleOstiaAnswer obj where obj.firewallRuleQuestionnaire.id = ? order by id desc")
				.setLong(
						0,
						fireWallRuleProcess.getFirewallRuleQuestionnaire()
								.getId()).list();*/
		   
		if (rows == null || rows.isEmpty()) { 
			 //log.info("inside rows****************");
			FirewallRuleQuestionnaire firewallRuleQuestionnaire = (FirewallRuleQuestionnaire) session
					.createQuery(
							"from FirewallRuleQuestionnaire rule where rule.id="
									+ fireWallRuleProcess
											.getFirewallRuleQuestionnaire()
											.getId()).uniqueResult();
	
				List<RiskDefinition> definitions = firewallRuleQuestionnaire
				.getQuestionnaire().getRiskDefinitions();
				
				//Map<String,FirewallRuleOstiaAnswer> ostiaMap = new HashMap<String,FirewallRuleOstiaAnswer>();
				 
				for (RiskDefinition definition : definitions) {
					List<OstiaQuestion> ostiaQuestions = definition
							.getOstiaQuestions();
					
					for (OstiaQuestion ostiaQuestion : ostiaQuestions) {
						FirewallRuleOstiaQuestion firewallRuleOstiaAnswer = new FirewallRuleOstiaQuestion();
						firewallRuleOstiaAnswer
								.setFirewallRuleQuestionnaire(firewallRuleQuestionnaire);
						firewallRuleOstiaAnswer.setOstiaQuestion(ostiaQuestion);
						list.add(firewallRuleOstiaAnswer);
					}
					ostiaMap.put(definition.getRiskCode(),  list);
					//log.info("ostiaMap" +ostiaMap.toString());
				}
	 		}
		return ostiaMap;
	}
	@Override
	public void cloneFirewallRuleQuestionnaire(
			List<FirewallRuleQuestionnaire> list) {
		for(FirewallRuleQuestionnaire firewallRuleQuestionnaire:list){
			updateFirewallRuleQuestionnaire(firewallRuleQuestionnaire);
		}
	}
	@Override
	public void updateFirewallRuleQuestionnaire(
			FirewallRuleQuestionnaire firewallRuleQuestionnaire) {
		Session session = getSession();
		session.saveOrUpdate(firewallRuleQuestionnaire);
	
	}
	@Override
	public FirewallRuleQuestionnaire findFWQuestionnaireByRuleId(Long ruleId) {
		log.info("findFWQuestionnaireByRuleId Starts .......");
		Session session = getSession();
		FirewallRuleQuestionnaire firewallRuleQuestionnaire = (FirewallRuleQuestionnaire) session
		.createQuery(
				"from FirewallRuleQuestionnaire obj where obj.type=? and obj.deletedTIRequest is null and obj.firewallRule.id=?").setString(0,"Default").setLong(1,ruleId).uniqueResult();
		if(firewallRuleQuestionnaire!=null){
			lazyInitialize(firewallRuleQuestionnaire.getFirewallRuleOstiaAnswers());	
		}
		
		//session.close();
		log.info("findFWQuestionnaireByRuleId Ends .......");
		return firewallRuleQuestionnaire;
	}
	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	public boolean isRisk(Long ruleId) {
		log.info("isRisk Starts .......");
		Session session = getSession();
		List<FirewallRuleQuestionnaire> firewallRuleQuestionnaire = session
		.createQuery("from FirewallRuleQuestionnaire obj where obj.type=? and obj.deletedTIRequest is null and obj.status not in ('ReviewNotRequired') and obj.firewallRule.id=?")
		.setString(0,"Default").setLong(1,ruleId).list();
		//lazyInitialize(firewallRuleQuestionnaire.getFirewallRuleOstiaAnswers());
		//session.close();
		log.info("isRisk Ends ......."+ruleId+">"+(firewallRuleQuestionnaire!=null && !firewallRuleQuestionnaire.isEmpty()));
		return (firewallRuleQuestionnaire!=null && !firewallRuleQuestionnaire.isEmpty());
	}
	
	@Override
	public List<Long> rulesExistsWithOlderBaseline(Long tiRequestId,String isIpReg) {
		Session session = getSession();
		StringBuffer sqlQueryString= new StringBuffer("select rule.id ruleId from con_fw_rule rule left outer join con_fw_rule_questionnaire qn  " +
				" on qn.fw_rule_id = rule.id and rule.deleted_ti_request_id is null and qn.deleted_ti_request_id is null " +
				" join ostia_questionnaire ost on qn.questionnaire_id = ost.id and qn.baseline_name <> ost.baseline_name " +
				" where rule.updated_ti_request_id = "+tiRequestId);
		
		
			if("Y".equalsIgnoreCase(isIpReg)) {
				sqlQueryString.append(" and rule.IS_IPREG = 'Y'");
				log.debug("inside Y" +isIpReg);
			}
			else if("N".equalsIgnoreCase(isIpReg) || isIpReg.isEmpty()) {
				sqlQueryString.append(" and (rule.IS_IPREG = 'N' or rule.IS_IPREG is null)");
				log.debug("inside N" + isIpReg);
			}
			SQLQuery query = session.createSQLQuery(sqlQueryString.toString());
			log.debug("message" +query);
			query.addScalar("ruleId", LongType.INSTANCE);
			List<Long> ruleIds = (List<Long>)query.list();
		
		
		return ruleIds;
	}
	
	@Override
	public List<Long> getTIRequestsinRiskExecutionQueue() {
		Session session = getSession();
		
		SQLQuery query = session.createSQLQuery("select id from ti_request where risk_exec_status = 'P'");
		query.addScalar("id", LongType.INSTANCE);
		List<Long> tiRequestIds = (List<Long>)query.list();
		
		return tiRequestIds;
	}
	
	@Override
	public boolean isRiskExecutionInProgress(Long tiRequestId) {
		Session session = getSession();
		boolean inProgress = false;
		SQLQuery query = session.createSQLQuery("select id from ti_request where risk_exec_status = 'P' and id = "+tiRequestId);
		query.addScalar("id", LongType.INSTANCE);
		List<Long> tiRequestIds = (List<Long>)query.list();
		
		
		if (tiRequestIds != null && !tiRequestIds.isEmpty()) {
			inProgress = true;
		}
		
		return inProgress;
	}
	
	
	/*public boolean isIPRegRiskRule(Long tiRequestId) {
		Session session=getSession();
		boolean isIPRegRisk=false;
		SQLQuery query=session.createSQLQuery("select cfr.id from con_fw_rule cfr,faf_fw_rule ffr where cfr.IS_IPREG='Y' and cfr.id= ffr.con_fw_rule_id and cfr.UPDATED_TI_REQUEST_ID= "+tiRequestId);
		query.addScalar("cfr.id", LongType.INSTANCE);
		List<Long> tiRequestIds = (List<Long>)query.list();
		if(tiRequestIds !=null && !tiRequestIds.isEmpty()) {
			isIPRegRisk = true;
		}
		return isIPRegRisk;
		
	}
	*/
	@Override
	public void updateRiskExecutionStatus(Long tiRequestId, String status, String userId,String ruleType) {
		Session session = getSession();
		SQLQuery query = session.createSQLQuery("update ti_request set risk_exec_status = '"+status+"' where id = "+tiRequestId);
		query.executeUpdate();
		
		try {
			String task_code="";
			if("IPReg".equalsIgnoreCase(ruleType)) {
				task_code="risk_re_exec_ip";
			}else
			{
				task_code="risk_re_exec";
				
			}
			if ("P".equals(status)) {
				query = session.createSQLQuery("insert into c3par.ti_activity_trail (id,ti_request_id,activity_id,activity_status,user_role_id,user_id,lockedby,activity_startdate,activity_mode) values " +
						" (c3par.seq_ti_activity_trail.nextval,"+tiRequestId+",(select id from c3par.ti_task_type where task_code = '"+task_code+"'),'"+ActivityData.STATUS_STARTED+
						" ',(select id from c3par.role where name='"+ActivityData.ROLE_DE+"'),(select id from c3par.c3par_users where sso_id = '"+userId+"'),(select id from c3par.c3par_users where sso_id = '"+userId+"'),sysdate,'"+ActivityData.IS_NEW+"')");
				query.executeUpdate();
					
			} else {
				query = session.createSQLQuery("update c3par.ti_activity_trail set activity_status = '"+ActivityData.STATUS_COMPLETED+"',activity_enddate = sysdate  " +
						" where activity_id=(select id from c3par.ti_task_type where task_code = '"+task_code+"') " +
						" and ti_request_id = "+tiRequestId);
				query.executeUpdate();
			}
		}catch (Exception e) {
			e.printStackTrace();
			log.error(e, e);
		}
	}
	
	@Override
	public void riskExecutionHistory(Long tiRequestId, String userId, String baselineName,Long ruleId,String isIpReg) {
		try {
			String task_code="";
			if(isIpReg != null && isIpReg.equalsIgnoreCase("Y")) {
				task_code="risk_exec_ip";
			}else
			{
				task_code="risk_exec";
				
			}
			
			if (userId == null || userId.indexOf("REEXEC") == -1) {
				Session session  = getSession();
				SQLQuery sqlQuery = session.createSQLQuery("select id from c3par.ti_activity_trail " +
						" where activity_id=(select id from c3par.ti_task_type where task_code = '"+task_code+"') " +
						" and ti_request_id = "+tiRequestId +
						" and id in (select act_trail_id from ti_risk_audit_trail where ti_request_id = "+tiRequestId+
						" and baseline_name = '"+baselineName+"') order by id desc");
				
				sqlQuery.addScalar("id", LongType.INSTANCE);
				List<Long> actIds =  (List<Long>)sqlQuery.list();
				
				if (actIds.size() > 0) {
					sqlQuery = session.createSQLQuery("update c3par.ti_activity_trail set activity_status = '"+ActivityData.STATUS_COMPLETED+"',activity_enddate = sysdate  " +
							" where activity_id=(select id from c3par.ti_task_type where task_code = '"+task_code+"') " +
							" and ti_request_id = "+tiRequestId);
					sqlQuery.executeUpdate();
					
					
					Long activityId = actIds.get(0);
					
					String query = "select id from ti_risk_audit_trail where ti_request_id = "+tiRequestId+" and act_trail_id = "+activityId+
									" and baseline_name = '"+baselineName+"' and tuple_number = "+ruleId+" order by id desc";
					
					sqlQuery = session.createSQLQuery(query);
					sqlQuery.addScalar("id", LongType.INSTANCE);
					List<Long> riskAudIds =  (List<Long>)sqlQuery.list();
					
					if (riskAudIds.size() > 0) {
						Long id = riskAudIds.get(0);
						query = "update ti_risk_audit_trail set updated_date = sysdate where id = "+id;
						session.createSQLQuery(query).executeUpdate();
					} else {
						query = "insert into ti_risk_audit_trail (id, ti_request_id, act_trail_id, baseline_name,tuple_number, created_date,updated_date) values" +
								" (seq_ti_risk_audit_trail.nextval,"+tiRequestId+","+activityId+",'"+baselineName+"',"+ruleId+",sysdate, sysdate)";
						session.createSQLQuery(query).executeUpdate();
						
					}
					
					
				} else {
					Long id = (Long)session.createSQLQuery("select c3par.seq_ti_activity_trail.nextval id from dual").addScalar("id",LongType.INSTANCE).uniqueResult();
					
					sqlQuery = session.createSQLQuery("insert into c3par.ti_activity_trail (id,ti_request_id,activity_id,activity_status,user_role_id,user_id,lockedby,activity_startdate,activity_enddate,activity_mode) values " +
							" ("+id+","+tiRequestId+",(select id from c3par.ti_task_type where task_code = '"+task_code+"'),'"+ActivityData.STATUS_COMPLETED+
							" ',(select id from c3par.role where name='"+ActivityData.ROLE_DE+"'),(select id from c3par.c3par_users where sso_id = '"+userId+"'),(select id from c3par.c3par_users where sso_id = '"+userId+"'),sysdate,sysdate,'"+ActivityData.IS_NEW+"')");
					sqlQuery.executeUpdate();
					
					String query = "insert into ti_risk_audit_trail (id, ti_request_id, act_trail_id, baseline_name,tuple_number, created_date,updated_date) values" +
					" (seq_ti_risk_audit_trail.nextval,"+tiRequestId+","+id+",'"+baselineName+"',"+ruleId+",sysdate, sysdate)";
					session.createSQLQuery(query).executeUpdate();
				}
			} else if (userId != null && userId.indexOf("REEXEC") != -1) {
				
				task_code="";
				if("IPREEXEC".equalsIgnoreCase(userId)) {
					task_code="risk_re_exec_ip";
				}else
				{
					task_code="risk_re_exec";
					
				}
				
				Session session  = getSession();
				SQLQuery sqlQuery = session.createSQLQuery("select id from c3par.ti_activity_trail " +
						" where activity_id=(select id from c3par.ti_task_type where task_code = '"+task_code+"') " +
						" and ti_request_id = "+tiRequestId + " order by id desc");
				
				sqlQuery.addScalar("id", LongType.INSTANCE);
				List<Long> actIds =  (List<Long>)sqlQuery.list();
				if (actIds.size() > 0) {
					Long activityId = actIds.get(0);
					String query = "insert into ti_risk_audit_trail (id, ti_request_id, act_trail_id, baseline_name,tuple_number, created_date,updated_date) values" +
					" (seq_ti_risk_audit_trail.nextval,"+tiRequestId+","+activityId+",'"+baselineName+"',"+ruleId+",sysdate,sysdate)";
					session.createSQLQuery(query).executeUpdate();
				}
			}
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - "+e.getMessage());
		}
	}
	@Override
	public Double getRiskForCurrentCycle(Long tiRequestId,String conType) {
		Session session = getSession();
		Double total=null;
		String fw="";
		log.debug("tiReq" +tiRequestId);
		if("ipReg".equalsIgnoreCase(conType)){
			fw="and (IS_IPREG = 'Y') ";
		}
		else{
			fw="and (IS_IPREG is null or IS_IPREG != 'Y') ";
		}
		SQLQuery query = session.createSQLQuery("select nvl(round(sum(a.cr),2),0) rr from (select cfr.calculated_risk cr "+
			 "from ti_request tr join con_fw_rule cf on tr.id=cf.updated_ti_request_id "+
			 "join con_fw_rule_questionnaire cfr on cfr.fw_rule_id=cf.id "+
			 "where tr.ID="+tiRequestId+" and cfr.DELETED_TI_REQUEST_ID is null and cf.DELETED_TI_REQUEST_ID is null "+fw+" )a");
			 query.addScalar("rr", DoubleType.INSTANCE);
			 log.debug("querry" +query);
			total= (Double) query.uniqueResult();
		return total;
	}
	
	@Override
	public void updateFirewallRuleQuestionnaire(Long fireWallRuleId) {
		Session session = getSession();
		Integer i= Integer.valueOf(0) ,count = Integer.valueOf(0);
		String tableName = "", perimeter = "",relType = "";
		double logValue = 0d;
		try {
		SQLQuery relQuery = session.createSQLQuery("select relationship_type rt from relationship where "+
							"id =(select relationship_id from ti_process where id= (select process_id from ti_request where "+ 
							"id=(select ti_request_id from con_fw_rule where id="+fireWallRuleId+" ))) ");
		relType=(String) relQuery.addScalar("rt",StringType.INSTANCE).uniqueResult();	
		
		if("THIRD_PARTY".equalsIgnoreCase(relType)){
		SQLQuery query = session.createSQLQuery("select src_nwzone_id a from con_fw_rule where id="+fireWallRuleId+" and "+
				"(src_nwzone_id in (select id from resourcetype where name in ('3rd Party/CEP','Internet','DMZ','Untrusted Citigroup')) or dst_nwzone_id in (select id from resourcetype where name in ('3rd Party/CEP','Internet','DMZ','Untrusted Citigroup')))"+
				"and  src_obj_id is null and dst_obj_id is null and prt_obj_id is null and "+
				"((select perimeter from resourcetype where id=src_nwzone_id) != (select perimeter from resourcetype where id=dst_nwzone_id)) ");
		i=(Integer) query.addScalar("a",IntegerType.INSTANCE).uniqueResult();
		log.debug("i value" +i);
		if(i!=null && i>0){ 
			SQLQuery query1 = session.createSQLQuery("select perimeter a from resourcetype where id="+i);
			perimeter=(String) query1.addScalar("a",StringType.INSTANCE).uniqueResult();	
			if("INTERNAL".equalsIgnoreCase(perimeter)){
			tableName = "join con_fw_rule_source_ip cfra on cfr.id=cfra.rule_id ";
			}else{
				tableName = "join con_fw_rule_destination_ip cfra on cfr.id=cfra.rule_id ";	
			}
			count = (Integer) session.createSQLQuery("select sum(case when cima.no_of_host is null then 1 "+
												"else cima.no_of_host end ) tot,cfr.id id "+
												"from con_fw_rule cfr "+tableName+
												"join con_ip_master cima on cfra.ip_id = cima.id "+
												"and cfr.id="+fireWallRuleId+" and cfra.deleted_ti_request_id is null "+
												"and cfr.deleted_ti_request_id is null group by cfr.id ").addScalar("tot",IntegerType.INSTANCE).uniqueResult();
			
			if(count >0 && count !=null ){
			logValue = Math.log10(count) +1;
			log.debug("count" +count+ "logarithm value" +logValue);
			}
		}
		int res = session.createSQLQuery("update con_fw_rule_questionnaire cfrq set calculated_risk = "+
						"(select nvl(sum(a.rr* "+logValue+"),0) from (select  distinct "+
						"rd.risk_code, "+
						"rd.risk_rating rr from con_fw_rule cfr "+
						"join con_fw_rule_questionnaire cfrq on cfrq.fw_rule_id=cfr.id "+
						"join con_fw_rule_ostia_question cfroq on cfroq.fw_rule_qnnaire_id=cfrq.id "+
						"join ostia_question oq on cfroq.question_id=oq.id "+
						"join risk_definition rd on oq.risk_definition_id=rd.id and rd.risk_code!='NO_RISK' "+
						"and cfroq.deleted_ti_request_id is null and cfrq.deleted_ti_request_id is null and cfr.deleted_ti_request_id is null "+
						"where cfr.id="+fireWallRuleId+" )a) where cfrq.fw_rule_id="+fireWallRuleId).executeUpdate();
		log.debug("result of update" +res);
		}
		}
		catch(Exception e){
			log.error(e,e);
			e.printStackTrace();
		}
	}
	@Override
	public Double getRiskForConn(Long processId,String conType) {
		Session session = getSession();
		Double total=null;
		String fw="";
		if("ipReg".equalsIgnoreCase(conType)){
			fw="and (IS_IPREG = 'Y') ";
		}
		else{
			fw="and (IS_IPREG is null or IS_IPREG != 'Y') ";
		}
		SQLQuery query = session.createSQLQuery("select nvl(round(sum(a.cr),2),0) rr from "+
			"(select cfrq.calculated_risk cr "+
			"from ti_process tp "+ 
			"join ti_request tr on tp.id=tr.process_id "+
			"join con_fw_rule cfr on cfr.ti_request_id=tr.id "+
			"join con_fw_rule_questionnaire cfrq on cfrq.fw_rule_id=cfr.id "+
			"and cfrq.deleted_ti_request_id is null and cfr.deleted_ti_request_id is null "+ 
			fw+"where tp.id="+processId+ ") a ");
		log.debug("connection Query" +query);
		 query.addScalar("rr", DoubleType.INSTANCE);
		 log.debug("querry............." +query);
	
		total= (Double) query.uniqueResult();
		log.debug("totallllll value" +total);
	
	return total;
	}
	@Override
	public Long getIPForConn(Long tiProcessId, String conType) {
		Session session = getSession();
		Long total=null;
		String fw="";
		if("ipReg".equalsIgnoreCase(conType)){
			fw="and (IS_IPREG = 'Y') ";
		}
		else{
			fw="and (IS_IPREG is null or IS_IPREG != 'Y') ";
		}
		SQLQuery query = session.createSQLQuery("SELECT nvl(SUM(sour.asd),0) cp FROM "+
					"(SELECT distinct case when cim.no_of_host is null then 1 else cim.no_of_host end asd,tp.id tid,cim.ip_address "+
					"FROM ti_process tp JOIN ti_request tr ON tp.id=tr.process_id "+
					"JOIN con_fw_rule cfr ON cfr.ti_request_id=tr.id "+
					"join con_fw_rule_source_ip cfsi on cfsi.rule_id=cfr.id "+
					"join con_ip_master cim on cfsi.ip_id=cim.id  "+
					"join resourcetype r on r.id=cfr.src_nwzone_id and r.perimeter = 'Internal' "+
					"and cfr.deleted_ti_request_id is null and cfsi.deleted_ti_request_id is null "+fw+" where tp.id= "+tiProcessId+" "+
					"UNION SELECT DISTINCT  case when cima.no_of_host is null then 1 else cima.no_of_host end asdf,tp.id tid,cima.ip_address "+
					"FROM ti_process tp JOIN ti_request tr ON tp.id=tr.process_id "+
					"JOIN con_fw_rule cfr ON cfr.ti_request_id=tr.id "+
					"join con_fw_rule_destination_ip cfdi on cfdi.rule_id=cfr.id "+
					"join con_ip_master cima on cfdi.ip_id=cima.id "+
					"join resourcetype r on r.id=cfr.dst_nwzone_id and r.perimeter = 'Internal' "+
					"and cfr.deleted_ti_request_id is null and cfdi.deleted_ti_request_id is null "+fw+" where tp.id= "+tiProcessId+" )sour" );
					query.addScalar("cp", LongType.INSTANCE);
					 log.debug("ip count query" +query);
				
					total= (Long) query.uniqueResult();
					
					return total;
	}
	
}
	