package com.citigroup.cgti.c3par.controller.businessjustification;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule;
import com.citigroup.cgti.c3par.businessjustification.domain.UploadDocumentsProcess;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.webtier.bean.WorkflowDocumentBean;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.mentisys.bfc.util.DocumentHelper;

@Controller
public class UploadDocumentsController {

	private static Logger log = Logger
			.getLogger(UploadDocumentsController.class);
	
	@Autowired
	IMailModule mailModuleImpl;
	
	@RequestMapping(value = "/uploadDocumentsFormInitialize.act", method = RequestMethod.GET)
	public ModelAndView initialize(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("uploadDocumentsForm") UploadDocumentsProcess uploadDocumentsForm) {
			C3parSession c3parSession = null;
		try {
			Util util = new Util();
			String tiRequestId = null;
			TIRequest reqEnty = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
			tiRequestId = String.valueOf(request.getSession().getAttribute("tireqid"));
			log.debug("uploadDocumentsForm.getUploadedDocs()"+tiRequestId);
			{
				String isPrvNext ="none";
				ActivityData activityData = util.getCurrentActivitybyTiRequestId(
						(String) request.getSession().getAttribute("tireqid"),
						null, null);
				String relationshipType = reqEnty.getTiProcess().getRelationshipId().getRelationshipType();
				String taskCode = new Util().getTaskCode(activityData.getId());
				log.debug("Doc Drop down list size Relationship: "+ relationshipType);
				log.debug("Doc Drop down list size taskCode: "+ taskCode);
				log.debug("Doc Drop down list size activityData: "+activityData.getId());
				List<String> doctypeList = new Util().getDocumentDropdownList(relationshipType,taskCode);
				getUploadedDocumentList(uploadDocumentsForm,request,isPrvNext);
				c3parSession = new C3parSession();
				List<WorkflowDocumentBean> docList = (List<WorkflowDocumentBean>)DocumentHelper.getDocumentList_Request(tiRequestId,c3parSession.getConnection());
				for (WorkflowDocumentBean doc :docList){
					log.debug("UploadDocumentAction"+doc.getName());
					log.debug("UploadDocumentAction"+doc.getType());
					log.debug("UploadDocumentAction"+doc.getDate());
					
				}
				Integer version = util.getProcessVersionNumber(tiRequestId);
				Integer currVersion= version;
				log.debug("UploadDocumentAction "+version);
				log.debug("UploadDocumentAction "+currVersion);
				uploadDocumentsForm.setVersionNo(version);
				uploadDocumentsForm.setCurrVersionNo(currVersion);
				uploadDocumentsForm.setUploadedDocs(docList);
				uploadDocumentsForm.setDocDropDownList(doctypeList);
				model.addAttribute("doctypeList", doctypeList);
				 log.debug("Doc list size : "+ docList.size());
				 
		    }
			
			log.debug("uploadDocumentsForm.getUploadedDocs()"+ uploadDocumentsForm.getUploadedDocs().size());
			
		} catch (Exception e) {
			log.error(e);
		} finally {
		if (c3parSession != null) {
		    c3parSession.releaseConnection();
			}
	    }
		return new ModelAndView("c3par.uploaddoc", "uploadDocumentsForm",
				uploadDocumentsForm);
	}

	
	@RequestMapping(value = "/uploadDocumentsFormUpload.act", method = RequestMethod.POST)
	public ModelAndView uploadDoc(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("uploadDocumentsForm") UploadDocumentsProcess uploadDocumentsForm,
			BindingResult result) {
		log.info("uploadDoc in uploaddocumentcontroller Starts");
		
		String selectedDocName = request.getParameter("docType");
		boolean isItDirectorApproval = false;
		
		if(null != selectedDocName && "Director Approval".equalsIgnoreCase(selectedDocName)){
			
			isItDirectorApproval= true;
		}

		CommonsMultipartFile file = uploadDocumentsForm.getDocForUpload();

		String fileName = file.getOriginalFilename();
		fileName = fileName.replace("\'", "");
		String tiRequestId = null;

		if (request.getSession().getAttribute("tireqid") != null) {
			tiRequestId = String.valueOf(request.getSession().getAttribute("tireqid"));
			log.debug("UploadDocumentsAction:tirequid as param::" + tiRequestId);
		}

		TIRequest reqEnty = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
		tiRequestId = reqEnty.getId().toString();
		Long id = reqEnty.getTiProcess().getId();
		log.debug("UploadDocumentsAction:reviewing is null and tirequid ::"+ tiRequestId);

		log.debug("UploadDocumentsAction :: Content type of uploaded document  - "+ file.getName() + " is - " + file.getContentType());
		boolean isInValidFileExtension = false;
		String extension = null;
		Util util = new Util();
		if (file != null && file.getName() != null) {
			int pos = fileName.lastIndexOf(".");
			if (pos > 0) {
				extension = fileName.substring(pos + 1, fileName.length());
				log.debug("File Name : " + fileName + " Extension is :: "+ extension);
				isInValidFileExtension = util.isInValidFileExtension(extension);
			}
		}
		
		log.debug("isInValidFileExtension: "+isInValidFileExtension+" isItDirectorApproval: "+isItDirectorApproval);
		String activityName = util.getCurrentActivitybyTiRequestId(tiRequestId,	null, null).getActivityName();
		log.debug("activityName" + activityName);
		try {
			if (file == null || file.equals("")) {

				uploadDocumentsForm.validate("Document Exception has occurred. Please check the file content");

			} else if (isInValidFileExtension ) {

				uploadDocumentsForm.validate("Document Type Exception has occurred. Please check the file type");

			} else {
				String processId = id.toString();
				log.debug("Document Type"+ uploadDocumentsForm.getDocType());			
				int mid = fileName.lastIndexOf(".");
				String ext = fileName.substring(mid + 1, fileName.length());
				log.debug("extension " + ext);
				if(isItDirectorApproval && !ext.equalsIgnoreCase("msg")){
					
					uploadDocumentsForm.validate("Document Type Exception has occurred. Please check the file type");
				}
				
				if (!ext.equalsIgnoreCase("xls")&& uploadDocumentsForm.getDocType().equals("Bulk Firewall Rules")) {
					log.debug("Document Type error");
					uploadDocumentsForm.validate("Document Type Exception has occurred. Please check the file type");
				}		
				C3parSession c3parSession = null;
				try {
					
					c3parSession = new C3parSession();
					
						DocumentHelper.uploadDocumentForTiRequest(
								uploadDocumentsForm.getDocType(), processId,
								tiRequestId, activityName, file.getBytes(),
								fileName, file.getContentType(), request.getHeader("SM_USER"), reqEnty
										.getVersionNumber().intValue());
						List<WorkflowDocumentBean> docList = (List<WorkflowDocumentBean>) DocumentHelper.getDocumentList_Request(tiRequestId,c3parSession.getConnection());
						uploadDocumentsForm.setUploadedDocs(docList);

					} catch (Exception e) {
						uploadDocumentsForm	.validate("Exception has occurred. Cannot upload file");
					} finally {
						if (c3parSession != null) {
						    c3parSession.releaseConnection();
							}
					    }	
			}
			getUploadedDocumentList(uploadDocumentsForm,request,"none");	
		} catch (Exception e) {
			log.debug("In Exception initialize");
			log.error(e, e);
			ObjectError error = new ObjectError("name",	e.getMessage());
			result.addError(error);
		}
		
		ActivityData activityData = util.getCurrentActivitybyTiRequestId(
				(String) request.getSession().getAttribute("tireqid"),
				null, null);
		String relationshipType = reqEnty.getTiProcess().getRelationshipId().getRelationshipType();
		String taskCode = new Util().getTaskCode(activityData.getId());
		log.debug("Doc Drop down list size Relationship: "+ relationshipType);
		log.debug("Doc Drop down list size taskCode: "+ taskCode);
		log.debug("Doc Drop down list size activityData: "+activityData.getId());
		List<String> doctypeList = new Util().getDocumentDropdownList(relationshipType,taskCode);
		uploadDocumentsForm.setDocDropDownList(doctypeList);
		model.addAttribute("doctypeList", doctypeList);
		
		log.info("uploadDoc in uploaddocumentcontroller Ends");
		return new ModelAndView("c3par.uploaddoc", "uploadDocumentsForm",
				uploadDocumentsForm);
	}
	
	/**
	 * Navigation to Previous Version
	 * @param model
	 * @param request
	 * @param uploadDocumentsForm
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/uploadDocumentsFormPrevious.act", method = RequestMethod.POST)
	public ModelAndView uploadDocPrevious(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("uploadDocumentsForm") UploadDocumentsProcess uploadDocumentsForm,
			BindingResult result) {
			log.info("uploadDocPrevious in uploaddocumentcontroller Starts"+uploadDocumentsForm.getVersionNo().intValue());
			log.info("uploadDocPrevious in uploaddocumentcontroller Starts"+uploadDocumentsForm.getCurrVersionNo().intValue());
			TIRequest reqEnty = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
			try{			
			 List<WorkflowDocumentBean> list = getUploadedDocumentList(uploadDocumentsForm,request,"prev");
			 if(list != null){
				 uploadDocumentsForm.setUploadedDocs(list);
			 }else{
				 uploadDocumentsForm.setUploadedDocs(new ArrayList());
			 }
			 
			 log.debug("Doc list size : "+ list.size());
			 
			}catch (Exception e) {
				log.debug("In Exception initialize");
				log.error(e, e);
				ObjectError error = new ObjectError("name", "Previous version of Documents cannot be displayed." );
				result.addError(error);
			}
			ActivityData activityData = new Util().getCurrentActivitybyTiRequestId(
					(String) request.getSession().getAttribute("tireqid"),
					null, null);
			String relationshipType = reqEnty.getTiProcess().getRelationshipId().getRelationshipType();
			String taskCode = new Util().getTaskCode(activityData.getId());
			log.debug("Doc Drop down list size Relationship: "+ relationshipType);
			log.debug("Doc Drop down list size taskCode: "+ taskCode);
			log.debug("Doc Drop down list size activityData: "+activityData.getId());
			List<String> doctypeList = new Util().getDocumentDropdownList(relationshipType,taskCode);
			uploadDocumentsForm.setDocDropDownList(doctypeList);
			model.addAttribute("doctypeList", doctypeList);
			
			log.info("uploadDocPrevious in uploaddocumentcontroller Ends");
			return new ModelAndView("c3par.uploaddoc", "uploadDocumentsForm",
					uploadDocumentsForm);
	    }	    
		
	/**
	 * Navigation to Next Version
	 * @param model
	 * @param request
	 * @param uploadDocumentsForm
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/uploadDocumentsFormNext.act", method = RequestMethod.POST)
	public ModelAndView uploadDocNext(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("uploadDocumentsForm") UploadDocumentsProcess uploadDocumentsForm,
			BindingResult result) {
		log.info("uploadDocNext in uploaddocumentcontroller Starts");
		log.info("uploadDocNext in uploaddocumentcontroller Startss"+uploadDocumentsForm.getVersionNo().intValue());
		log.info("uploadDocNext in uploaddocumentcontroller Starts"+uploadDocumentsForm.getCurrVersionNo().intValue());
		
		TIRequest reqEnty = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
		try {
			List<WorkflowDocumentBean> list = getUploadedDocumentList(uploadDocumentsForm, request,
					"next");
			if (list != null) {
				uploadDocumentsForm.setUploadedDocs(list);
			} else {
				uploadDocumentsForm.setUploadedDocs(new ArrayList());
			}

			log.debug("Doc list size : " + list.size());
		}catch (Exception e) {
			log.debug("In Exception initialize");
			log.error(e, e);
			ObjectError error = new ObjectError("name", "Next version of Documents cannot be displayed." );
			result.addError(error);
		}
		ActivityData activityData = new Util().getCurrentActivitybyTiRequestId(
				(String) request.getSession().getAttribute("tireqid"),
				null, null);
		String relationshipType = reqEnty.getTiProcess().getRelationshipId().getRelationshipType();
		String taskCode = new Util().getTaskCode(activityData.getId());
		log.debug("Doc Drop down list size Relationship: "+ relationshipType);
		log.debug("Doc Drop down list size taskCode: "+ taskCode);
		log.debug("Doc Drop down list size activityData: "+activityData.getId());
		List<String> doctypeList = new Util().getDocumentDropdownList(relationshipType,taskCode);
		uploadDocumentsForm.setDocDropDownList(doctypeList);
		model.addAttribute("doctypeList", doctypeList);
		
		log.info("uploadDocNext in uploaddocumentcontroller Ends");
		return new ModelAndView("c3par.uploaddoc", "uploadDocumentsForm",
				uploadDocumentsForm);
	}    

	/**
	 * Get List of documents 
	 * @param uploadDocumentsForm
	 * @param request
	 * @param isPrvNext
	 * @return
	 * @throws Exception 
	 */
	public List<WorkflowDocumentBean> getUploadedDocumentList(
			UploadDocumentsProcess uploadDocumentsForm,
			HttpServletRequest request, String isPrvNext) throws Exception {

		log.info("getUploadedDocumentList in uploaddocumentcontroller Starts");
		C3parSession c3parSession = null;
		Util util = new Util();
		Integer version = uploadDocumentsForm.getVersionNo();
		Integer currVersion = uploadDocumentsForm.getCurrVersionNo();
		log.debug("Version and currversion in the uploaddocform:" + version
				+ "'-'" + currVersion +"-"+isPrvNext);
		Integer key = 0;
		Long tiReqId = null;
		List<WorkflowDocumentBean> docList = new ArrayList<WorkflowDocumentBean>();
		try {
			String tiRequestId = String.valueOf(request.getSession().getAttribute("tireqid"));
			TIRequest tiRequest = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
			if (version == null && tiRequest != null) {
				version = util.getProcessVersionNumber(tiRequestId);
				currVersion = version;
				key = currVersion;
				log.debug("Version and currversion in the TiRequestEntity :"
						+ version + "'-'" + currVersion);
			}
			if (currVersion == null) {
				currVersion = version;
			}
			if (version != null && currVersion != null) {

				if ("prev".equals(isPrvNext)) {
					key = currVersion - 1;
				} else if ("next".equals(isPrvNext)){
					key = currVersion + 1;
				}
				log.debug("Version and currversion in the TiRequestEntity  :"
						+ version + "'-'" + currVersion);
				if (key.equals(1)&& version.intValue()>1) {
					request.setAttribute("preVersion", "true");
					request.setAttribute("nextVersion", "false");
					log.debug("key == 1 prever nextver true false");
					uploadDocumentsForm.setCurrVersionNo(key);
				}
				if (key.intValue() == version.intValue()) {
					request.setAttribute("preVersion", "false");
					request.setAttribute("nextVersion", "true");
					log.debug("key == version prever nextver false true");
					uploadDocumentsForm.setCurrVersionNo(key);
				}
				if (key.intValue() > 1 && key.intValue() < version.intValue()) {
					request.setAttribute("preVersion", "false");
					request.setAttribute("nextVersion", "false");
					uploadDocumentsForm.setCurrVersionNo(key);
					log.debug("key > 1 and key < version prever nextver false false");
				}

				uploadDocumentsForm.setVersionNo(version);
				tiReqId = util.getTIRequestIdForVersion(tiRequest.getTiProcess().getId(), key);
				log.debug("UploadDocument.getUploadedDocumentList.tireqid::"
						+ tiReqId);
				c3parSession = new C3parSession();
				docList = (List<WorkflowDocumentBean>) DocumentHelper.getMetaDataList_TiRequest(tiReqId.toString(), null,c3parSession.getConnection());
			} else {
				request.setAttribute("preVersion", "true");
				request.setAttribute("nextVersion", "true");
			}
			log.debug("key currversion version :-'" + key + "'-'" + currVersion
					+ "'-'" + version);
		} catch (Exception ex) {
			throw ex;
		} finally {
			if (c3parSession != null) {
			    c3parSession.releaseConnection();
				}
		    }
		log.info("getUploadedDocumentList in uploaddocumentcontroller Ends");

		return docList;
	}
	
	/**
	 * Method to Delete the document
	 * @param model
	 * @param request
	 * @param uploadDocumentsForm
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/uploadDocumentsFormDelete.act", method = { RequestMethod.GET, RequestMethod.POST})
	public ModelAndView deleteDoc(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("uploadDocumentsForm") UploadDocumentsProcess uploadDocumentsForm,
			BindingResult result) {
			TIRequest reqEnty = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
			C3parSession c3parSession = null;
			try{
			log.debug("deleteDoc starts in uploadDocumentController");
			String tiRequestId = String.valueOf(request.getSession().getAttribute("tireqid"));
			log.debug("tiRequestId"+tiRequestId);
			String contentId = uploadDocumentsForm.getDocBean().getDocContentId();
			log.debug("contentId"+contentId);
			c3parSession = new C3parSession();
			DocumentHelper.deleteDocument(c3parSession, contentId,tiRequestId);
			c3parSession = new C3parSession();
			List<WorkflowDocumentBean> docList = (List<WorkflowDocumentBean>)DocumentHelper.getDocumentList_Request(tiRequestId, c3parSession.getConnection());
			uploadDocumentsForm.setUploadedDocs(docList);
			getUploadedDocumentList(uploadDocumentsForm,request,"none");	
			log.debug("deleteDoc ends in uploadDocumentController");
		    }
			catch (Exception e) {
				log.debug("In Exception initialize");
				log.error(e, e);
				ObjectError error = new ObjectError("name", "Document Deletion failed." );
				result.addError(error);
			} finally {
				if (c3parSession != null) {
				    c3parSession.releaseConnection();
					}
			    }
			ActivityData activityData = new Util().getCurrentActivitybyTiRequestId(
					(String) request.getSession().getAttribute("tireqid"),
					null, null);
			String relationshipType = reqEnty.getTiProcess().getRelationshipId().getRelationshipType();
			String taskCode = new Util().getTaskCode(activityData.getId());
			log.debug("Doc Drop down list size Relationship: "+ relationshipType);
			log.debug("Doc Drop down list size taskCode: "+ taskCode);
			log.debug("Doc Drop down list size activityData: "+activityData.getId());
			List<String> doctypeList = new Util().getDocumentDropdownList(relationshipType,taskCode);
			uploadDocumentsForm.setDocDropDownList(doctypeList);
			model.addAttribute("doctypeList", doctypeList);
			
			 return new ModelAndView("c3par.uploaddoc", "uploadDocumentsForm",
						uploadDocumentsForm);
	}
	
	/**
	 * Method to view Documents
	 * @param model
	 * @param request
	 * @param uploadDocumentsForm
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/uploadDocumentsFormView.act", method = { RequestMethod.GET, RequestMethod.POST})
	public ModelAndView viewDoc(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("uploadDocumentsForm") UploadDocumentsProcess uploadDocumentsForm, HttpServletResponse response) throws IOException {
		TIRequest reqEnty = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
		C3parSession c3parSession = null;
	try {
		log.debug("viewDoc starts in UploadDocumentsController");
		byte[] docBytes = null;
		String docMimeType = null;
		String contentId = request.getParameter("docBeanContentId");
		log.debug("contentId  "+contentId);
		docMimeType =  request.getParameter("docBeanMimetype");
		log.debug("docMimeType  "+docMimeType);
		String docName =  request.getParameter("docBeanName");
		log.debug("docName  "+docName);
		c3parSession = new C3parSession();
		docBytes = DocumentHelper.getContent(contentId, c3parSession.getConnection());				

		if (docMimeType != null && docBytes != null
			&& docBytes.length != 0) {
		    java.io.OutputStream os = response.getOutputStream();
		    response.setContentType(docMimeType);
		    response.setHeader("Content-Disposition", "attachment; filename="+docName);
		    os.write(docBytes);
		} else {
		    java.io.PrintWriter out = response.getWriter();
		    response.setContentType("text/html");
		    out.println("<HTML><BODY>There was no file attached!</BODY></HTML>");
		}
		getUploadedDocumentList(uploadDocumentsForm,request,"none");	
		log.debug("viewDoc ends in UploadDocumentsController");
	    } catch (Exception e) {
		log.error(e,e);
		java.io.PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out	.println("<HTML><BODY>There was an error retrieving the requested file!</BODY></HTML>");
	    } finally {
			if (c3parSession != null) {
			    c3parSession.releaseConnection();
				}
	    }
	ActivityData activityData = new Util().getCurrentActivitybyTiRequestId(
			(String) request.getSession().getAttribute("tireqid"),
			null, null);
	String relationshipType = reqEnty.getTiProcess().getRelationshipId().getRelationshipType();
	String taskCode = new Util().getTaskCode(activityData.getId());
	log.debug("Doc Drop down list size Relationship: "+ relationshipType);
	log.debug("Doc Drop down list size taskCode: "+ taskCode);
	log.debug("Doc Drop down list size activityData: "+activityData.getId());
	List<String> doctypeList = new Util().getDocumentDropdownList(relationshipType,taskCode);
	uploadDocumentsForm.setDocDropDownList(doctypeList);
	model.addAttribute("doctypeList", doctypeList);
	
	    return null;
}
	
	/**
	 * Validating to sent mail for director approval
	 * @param model
	 * @param request
	 * @param uploadDocumentsForm
	 * @param result
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/uploadDocumentsFormMail.act", method = RequestMethod.POST)
	public ModelAndView sendMail(
			ModelMap model,
			HttpServletRequest request,
			@ModelAttribute("uploadDocumentsForm") UploadDocumentsProcess uploadDocumentsForm,
			BindingResult result, HttpServletResponse response)
			throws IOException {

		log.info("sendMail Starts in UploadDocumentsController");
		Util util = new Util();
		ModelAndView fwd = initialize(model,request,uploadDocumentsForm);
		TIRequest reqEnty = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
		try {
			HttpSession session = request.getSession();
			TIRequest tiRequest = (TIRequest) request.getSession()
					.getAttribute("TI_REQUEST_ENTITY");

			String planningId = "";
			long processTypeID = 0;
			Long tiRequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());
			log.info("tiRequestId in action :: " + tiRequestId);
			if (tiRequestId == null || tiRequestId == 0) {
				log.info("tiRequestId in action :: " + tiRequestId);
				tiRequestId = tiRequest.getId();
			}
			Long id = tiRequest.getTiProcess().getId();
			processTypeID = util.getProcessTypeID(tiRequestId);
			log.info("processTypeID in action :: " + processTypeID);
			if (processTypeID == 1) {
				planningId = String.valueOf(util.getPlanningIdForTiRequestId(tiRequestId));
				log.info("planningId in action :: " + planningId);
			} else if (processTypeID == 2) {
				log.info("planningId in ip detail:: " + id.toString());
				planningId = id.toString();
				log.info("planningId in action :: " + planningId);
			}
			// EMER- BUSCRIT DOCUMENT UPLOAD CHANGES Starts
			String mailSentDate = util
					.getDirectorApprovalMailSentDate(planningId);
			log.info("mailSentDate in action :: " + mailSentDate);
			if (mailSentDate != null)
				session.setAttribute("DirApprovalMailDate", mailSentDate);

			if (planningId != null) {
				boolean sendErrorFlag = sendDirectorApprovalMail(Long.valueOf(planningId), request);
				if (!sendErrorFlag) {
					boolean updateFlag = util.updateDirectorApprovalMailFlag(Long.valueOf(planningId));
					if (updateFlag) {
						sendErrorFlag = false;
					} else {
						sendErrorFlag = true;
					}
				} else {
					uploadDocumentsForm
							.validate("Director Approval Mail was not sent Successfully.Please try again.");
				}
			}
			getUploadedDocumentList(uploadDocumentsForm,request,"none");	
		} catch (Exception e) {
			log.debug("In Exception initialize");
			log.error(e, e);
			ObjectError error = new ObjectError("name", e.getMessage());
			result.addError(error);
		}
		ActivityData activityData = util.getCurrentActivitybyTiRequestId(
				(String) request.getSession().getAttribute("tireqid"),
				null, null);
		String relationshipType = reqEnty.getTiProcess().getRelationshipId().getRelationshipType();
		String taskCode = new Util().getTaskCode(activityData.getId());
		log.debug("Doc Drop down list size Relationship: "+ relationshipType);
		log.debug("Doc Drop down list size taskCode: "+ taskCode);
		log.debug("Doc Drop down list size activityData: "+activityData.getId());
		List<String> doctypeList = new Util().getDocumentDropdownList(relationshipType,taskCode);
		uploadDocumentsForm.setDocDropDownList(doctypeList);
		model.addAttribute("doctypeList", doctypeList);
		log.info("sendMail Ends in UploadDocumentsController");
		return fwd;

	}
	
	/**
	 * Sends mail for directorApproval
	 * @param primaryId
	 * @param request
	 * @return
	 * @throws Exception
	 */
	 private boolean sendDirectorApprovalMail(Long primaryId,HttpServletRequest request)throws Exception{
			log.info("sendDirectorApprovalMail Starts in UploadDocumentsController");
			boolean sendErrorFlag=false;			
			Util util=new Util();
			String relationShipType=util.getRelationshipType(primaryId);
			sendErrorFlag=mailModuleImpl.sendDirectorApprovalEmail(primaryId,relationShipType);
			request.setAttribute("sendApprovalMailFlag", "Mail Sent Successfully for the director Approval");
			log.info("sendDirectorApprovalMail Ends in UploadDocumentsController");
			return sendErrorFlag;
		    }
}
