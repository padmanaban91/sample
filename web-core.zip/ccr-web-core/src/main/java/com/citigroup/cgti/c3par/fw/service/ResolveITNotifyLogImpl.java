/**
 *
 */
package com.citigroup.cgti.c3par.fw.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.type.LongType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.fw.domain.ResolveITNotifyLog;
import com.citigroup.cgti.c3par.fw.domain.soc.persist.ResolveITRequestPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.soa.vc.util.ResolveITUtil;
import com.citigroup.cgti.c3par.webtier.bean.WorkflowDocumentBean;

/**
 * @author gs71854
 * 
 */
@SuppressWarnings("unchecked")
@Transactional
public class ResolveITNotifyLogImpl extends BasePersistanceImpl implements ResolveITRequestPersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(ResolveITNotifyLogImpl.class);

	ResolveITUtil resolveITUtil;
	
	public ResolveITUtil getResolveITUtil() {
		return resolveITUtil;
	}

	public void setResolveITUtil(ResolveITUtil resolveITUtil) {
		this.resolveITUtil = resolveITUtil;
	}

	@Override
	public void saveResolveITNotifyLog(ResolveITNotifyLog resolveITNotifyLog) {
		getHibernateTemplate().save(resolveITNotifyLog);
	}
	
	@Override
	public ResolveITNotifyLog findTicketLog(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResolveITNotifyLog findTicketLogByCMPID(String cmpID) {	
		ResolveITNotifyLog resolveObj = null;
		Query query = getSession().createQuery("from ResolveITNotifyLog where cmpID='" + cmpID + "'");
		resolveObj = (ResolveITNotifyLog) query.uniqueResult();
		return resolveObj;
	}
	
	@Override
	public void updateResolveITNotifyLog(ResolveITNotifyLog resolveITNotifyLog) {
		getHibernateTemplate().update(resolveITNotifyLog);
		
	}

	@Override
	@Transactional(readOnly = true)
	public List<ResolveITNotifyLog> getResolveITNotifyLogList() {
				Query query = getSession().createQuery("from ResolveITNotifyLog where tiRequestID is null and cmpID is not null");
		List<ResolveITNotifyLog> list =  query.list();		
		return list;
	}

	@Override
	@Transactional(readOnly = true)
	public List<ResolveITNotifyLog> getResolveITNotifyLogList(String searchString) {
		Query query = getSession().createQuery("from ResolveITNotifyLog where tiRequestID is null and cmpID like '%"+searchString+"%'");
		List<ResolveITNotifyLog> list =  query.list();		
		return list;
	}
	
	public String getComments(final Long tiReqId){		
		return resolveITUtil.getComments(tiReqId);		
	}

	@Override
	public ResolveITNotifyLog findTicketLogByTiReqId(Long tiRequestId) {	
		ResolveITNotifyLog resolveObj = null;
		Query query = getSession().createQuery("from ResolveITNotifyLog where tiRequestID=" + tiRequestId);
		resolveObj = (ResolveITNotifyLog) query.uniqueResult();
		return resolveObj;
	}
	
	@Override
	public void updateTiRequestCMP(String cmpID, String tiRequestId){
		log.info("Entered in Update TiRequest based on CMP ID ::::::>>> "+cmpID+" TiRequest ID :::>>>"+tiRequestId);
		
		Long tiRequest_Id=0L;
		tiRequest_Id=Long.parseLong(tiRequestId);
		if(cmpID != null && cmpID.length() > 0){
			log.info("Entered in updateTiRequestCMP Method the cmpId is >>>>>::::::"+cmpID);
			StringBuffer queryString = new StringBuffer();
			queryString.append("update resolve_it_notify_log set ti_request_id = " + tiRequest_Id + " where cmp_id = '"+ cmpID+"'");
			SQLQuery query = getSession().createSQLQuery(queryString.toString());
			int rows = query.executeUpdate();
			//Added for updating multiple cmp id for ccr id
			if(rows > 0){
				Long processId = 0L;
				int count = 0;
				String fetchUserIdQuery = "select process_id from ti_request where id="
						+ tiRequestId + "";
				SQLQuery sq = getSession().createSQLQuery(fetchUserIdQuery);
				sq.addScalar("process_id", LongType.INSTANCE);
				processId = (Long) sq.uniqueResult();
				if (processId > 0) {
					String sql = "update cmp_request set ccr_id='"
							+ processId.toString() + "' where order_id='" + cmpID
							+ "'";
					log.info("sql:: " + sql);
					SQLQuery query1 = getSession().createSQLQuery(sql);
					count = query1.executeUpdate();

				}
			}
			
			log.info("Completed the query and executed row status ::: >>>>>>"+query +"Row :>>>"+rows);
		}else if(cmpID == null){
			log.info("Entered in updateTiRequestCMP method to remove the tirequest ID");
			SQLQuery updateQuery = getSession().createSQLQuery("update resolve_it_notify_log set ti_request_id = null where ti_request_id = "+tiRequest_Id);
			updateQuery.executeUpdate();
			Long processId = 0L;
			int count = 0;
			String fetchUserIdQuery = "select process_id from ti_request where id="
					+ tiRequestId + "";
			SQLQuery sq = getSession().createSQLQuery(fetchUserIdQuery);
			sq.addScalar("process_id", LongType.INSTANCE);
			processId = (Long) sq.uniqueResult();
			if (processId > 0) {
				String sql = "update cmp_request set ccr_id = null where ccr_id='" + processId+ "'";
				log.info("sql:: " + sql);
				SQLQuery query1 = getSession().createSQLQuery(sql);
				count = query1.executeUpdate();
		}
		}
	}
	@Override
	public void deleteUploadedDocument(String tiRequestId, String docType){
		log.info("Entered in deleteUploadedDocument :::: TiRequest ID :::>>>"+tiRequestId);
		List uploadedDocs = new ArrayList(); 
		try{ 
			com.mentisys.bfc.util.DocumentHelper.getAllDocumentsForTiRequest(uploadedDocs, tiRequestId);
			if(uploadedDocs != null && uploadedDocs.size() > 0){
				for(int count=0;count<uploadedDocs.size();count++){
					WorkflowDocumentBean docMetaData = (WorkflowDocumentBean)uploadedDocs.get(count);
					if(docMetaData.getType() != null && docMetaData.getType().equalsIgnoreCase(docType)){
						com.mentisys.bfc.util.DocumentHelper.deleteDocument(new C3parSession(), docMetaData.getDocContentId(),tiRequestId);
					}
				}
			}
		}catch(Exception e){
			
		}
		log.info("Completed the query ::: >>>>>> deleteUploadedDocument");
	}
	
	//Method added to Show Multiple CMP Details @nc43495
	@Override
	@Transactional(readOnly = true)
	public List<ResolveITNotifyLog> getCMPDetails(String searchString) {
		Query query = getSession().createQuery("from ResolveITNotifyLog where cmpID in ("+searchString+")");
		List<ResolveITNotifyLog> list =  query.list();		
		return list;
	}
}