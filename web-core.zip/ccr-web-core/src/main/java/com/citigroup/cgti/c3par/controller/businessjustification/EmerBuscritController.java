package com.citigroup.cgti.c3par.controller.businessjustification;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule;
import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.businessjustification.domain.EmerBuscritProcess;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.domain.Template;
import com.citigroup.cgti.c3par.ip.helper.IPRegHelper;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetailAnswer;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.soa.vc.logic.RFCService;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class EmerBuscritController extends BusJusBaseController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@Autowired
	RFCService rfc;

	@Autowired
	IMailModule mailModuleImpl;

	@Autowired
	EmerBuscritProcess emerBuscritProcess;

	@RequestMapping(value = "/emerbuscritload.act", method = RequestMethod.GET)
	public String emerBuscritLoad(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		log.debug("Entering into emerBuscritLoad()..");

		String result = "c3par.planning.emer.buscrit.questions";

		Long tirequestId = Long.valueOf(request.getSession()
				.getAttribute("tireqid").toString());

		log.info("tirequestId:: in emerBuscritLoad::" + tirequestId);

		TIRequest tirequest = getEmerBuscritProcess().getTIRequestDetails(tirequestId);

		BusinessJustificationProcess busjusProcess = new BusinessJustificationProcess();
		Long planningId = busjusProcess.getPlanningId(tirequest.getId());
		ConnectionRequest conreq = busjusProcess.getConnectionRequest(planningId);

		//completion check
		completionCheck(request, conreq, tirequest) ;
		
		log.debug("The tirequest id: " + tirequest.getId());

		if ( tirequest.getPriority() != null && ! tirequest.getPriority().getValue1().trim().equals("BAU")) {

			try {

				TIRequest tiRequest = new TIRequest();
				tiRequest.setId(tirequest.getId());
				String isActiveTemplate = "Y";
				RFCRequest rfcRequest = rfc.getEMERGenericRFCRequest(tiRequest,
						isActiveTemplate);
				if (rfcRequest != null) {

					if (rfcRequest.getDescription() != null
							&& rfcRequest.getDescription().getId() == null) {
						rfcRequest.getDescription().setRfcRequest(
								new RFCRequest());
						rfcRequest.getDescription().getRfcRequest()
								.setId(rfcRequest.getId());
						if (rfcRequest.getDescription()
								.getRfcDetailAnswerList().isEmpty()) {
							log.debug("RFCDetail id is null so get the questions from template table.");
							List<Template> templateList = rfc.getEmerQuestions(
									"DESC_EMERBUSCRIT_QUESTIONAIRE", "Y");
							if (templateList != null && !templateList.isEmpty()) {
								rfcRequest
										.getDescription()
										.setRfcDetailAnswerList(
												new ArrayList<RFCDetailAnswer>());
								for (Template template : templateList) {
									RFCDetailAnswer rfcDetailAnswer = new RFCDetailAnswer();
									rfcDetailAnswer.setTemplateKey(template);
									rfcDetailAnswer.setRfcDetail(rfcRequest
											.getDescription());
									rfcRequest.getDescription()
											.getRfcDetailAnswerList()
											.add(rfcDetailAnswer);

									log.debug("Answer List size: "
											+ rfcRequest.getDescription()
													.getRfcDetailAnswerList()
													.size());
									log.debug("Answer List : "
											+ rfcRequest.getDescription()
													.getRfcDetailAnswerList());

								}
								emerBuscritProcess.setRfcRequest(rfcRequest);
								model.addAttribute("rfcList", rfcRequest
										.getDescription()
										.getRfcDetailAnswerList());
								request.getSession().setAttribute(
										"rfcRequestObj", rfcRequest);
							}
						}
					} else if (rfcRequest.getDescription()
							.getRfcDetailAnswerList() != null) {
						log.debug("Check if any questions are activated except than saved/retrieved template:");
						List<Template> templateList = rfc.getEmerQuestions(
								"DESC_EMERBUSCRIT_QUESTIONAIRE", "Y");
						List<RFCDetailAnswer> answerList = rfcRequest
								.getDescription().getRfcDetailAnswerList();
						if (templateList != null && !templateList.isEmpty()) {
							for (Template template : templateList) {
								boolean find = false;
								for (RFCDetailAnswer rfcDetailAnswer : answerList) {
									if (rfcDetailAnswer.getTemplateKey()
											.getId().longValue() == template
											.getId().longValue()) {
										find = true;
										break;
									}
								}
								if (!find) {
									RFCDetailAnswer newRFCDetailAnswer = new RFCDetailAnswer();
									newRFCDetailAnswer.setTemplateKey(template);
									newRFCDetailAnswer.setRfcDetail(rfcRequest
											.getDescription());
									rfcRequest.getDescription()
											.getRfcDetailAnswerList()
											.add(newRFCDetailAnswer);
									emerBuscritProcess
											.setRfcRequest(rfcRequest);

								}
							}

							emerBuscritProcess.setRfcRequest(rfcRequest);
							model.addAttribute("rfcList", rfcRequest
									.getDescription().getRfcDetailAnswerList());

							request.getSession().setAttribute("rfcRequestObj",
									rfcRequest);
						}
					}
				} else {
					throw new ApplicationException(
							"RFC Details are not initialized plz check with System Administrator");
				}

			} catch (Exception ex) {
				log.error(ex, ex);
			}

			model.addAttribute("emerBuscritProcess", emerBuscritProcess);

			connectionCompleteCheck(request, "EmerBuscritInformation");
		}

		log.debug("Exit from emerBuscritLoad()..");

		return result;
	}

	@RequestMapping(value = "/emerbuscritsave.act", method = RequestMethod.POST)
	public String emerBuscritSave(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		log.debug("Entering into emerBuscritSave()..");

		String result = "c3par.planning.emer.buscrit.questions";
		
		Long tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());
		TIRequest tirequest = getEmerBuscritProcess().getTIRequestDetails(tirequestId);

		log.debug("The tirequest id: " + tirequest.getId());

		if ( tirequest.getPriority() != null && ! tirequest.getPriority().getValue1().trim().equals("BAU")) {
			this.save(model, request, response);	
			connectionCompleteCheck(request, "EmerBuscritInformation");
		
		}

		BusinessJustificationProcess busjusProcess = new BusinessJustificationProcess();
		Long planningId = busjusProcess.getPlanningId(tirequest.getId());
		ConnectionRequest conreq = busjusProcess.getConnectionRequest(planningId);

		//completion check
		completionCheck(request, conreq, tirequest) ;
		
		log.debug("Exit from emerBuscritSave()..");

		return result;
	}

	private void save(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {

		log.debug("Entering into save()..");

		RFCRequest rfcRequest = (RFCRequest) request.getSession().getAttribute(
				"rfcRequestObj");
		if (null != rfcRequest) {

			@SuppressWarnings("unchecked")
			List<RFCDetailAnswer> answerList = rfcRequest.getDescription().getRfcDetailAnswerList();

			if (null != answerList) {

				for (RFCDetailAnswer answer : answerList) {

					/*log.debug("The Question: "
							+ answer.getTemplateKey().getDescription());
					log.debug("The Answer: "
							+ request.getParameter(answer.getTemplateKey()
									.getDescription()));*/
					answer.setAnswer(request.getParameter(answer.getTemplateKey().getDescription()));

				}

			} else {
				log.debug("answerList is NULL..");
			}

			rfc.addRFCDetail(rfcRequest.getDescription());

			model.addAttribute("rfcList", rfcRequest.getDescription().getRfcDetailAnswerList());

		} else {
			log.debug("rfcRequest is NULL..");
		}

		log.debug("Exit from save()..");

	}

	@RequestMapping(value = "/emerbuscritcontinue.act", method = RequestMethod.POST)
	public String emerBuscritContinue(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		log.debug("Entering into emerBuscritContinue()..");

		String result = "redirect:/loadFirewallRules.act";
		
		Long tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());
		TIRequest tirequest = getEmerBuscritProcess().getTIRequestDetails(tirequestId);

		log.debug("The tirequest id: " + tirequest.getId());

		if ( tirequest.getPriority() != null && ! tirequest.getPriority().getValue1().trim().equals("BAU")) {
			this.save(model, request, response);	
			connectionCompleteCheck(request, "EmerBuscritInformation");		
		}

		BusinessJustificationProcess busjusProcess = new BusinessJustificationProcess();
		Long planningId = busjusProcess.getPlanningId(tirequest.getId());
		ConnectionRequest conreq = busjusProcess.getConnectionRequest(planningId);

		//completion check
		completionCheck(request, conreq, tirequest) ;
		
		log.debug("Exit from emerBuscritContinue()..");

		return result;
	}

	private boolean sendDirectorApprovalMail(Long primaryId,
			HttpServletRequest request) {
		log.info("EmerBuscritInformationAction ::sendDirectorApprovalMail Sending Director Approval Email Starts");
		boolean sendErrorFlag = false;
		try {

			String relationShipType = getEmerBuscritProcess()
					.getRelationshipType(primaryId);
			sendErrorFlag = mailModuleImpl.sendDirectorApprovalEmail(primaryId,
					relationShipType);
		} catch (Exception ex) {
			log.error(ex, ex);
			sendErrorFlag = true;
		}
		request.setAttribute("sendApprovalMailFlag",
				"Mail Sent Successfully for the director Approval");
		log.info("EmerBuscritInformationAction ::sendDirectorApprovalMail ::  Sending Director Approval Email Ends");
		return sendErrorFlag;
	}

	@RequestMapping(value = "/emerbuscritmail.act", method = RequestMethod.POST)
	public String emerBuscritSendMail(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		log.debug("Entering into emerBuscritSendMail()..");

		String result = "c3par.planning.emer.buscrit.questions";
		
		Long tirequestId = Long.valueOf(request.getSession()
				.getAttribute("tireqid").toString());

		log.info("tirequestId:: in emerBuscritLoad::" + tirequestId);

		TIRequest tirequest = getEmerBuscritProcess().getTIRequestDetails(
				tirequestId);

		log.debug("The tirequest id: " + tirequest.getId());

		if ( tirequest.getPriority() != null && ! tirequest.getPriority().getValue1().trim().equals("BAU")) {

		this.save(model, request, response);
		
		Long planningId = getEmerBuscritProcess().getPlanningId(tirequestId);
		Planning planning = getEmerBuscritProcess().getPlanningDetails(
				planningId);

		Long primaryId = planning.getId();
		
		Util util =new Util();

		if (planning != null) {

			if (primaryId != null) {

				boolean sendErrorFlag = false;
				boolean directorPresent = getEmerBuscritProcess()
						.isDirectorPresent(primaryId);
				if (directorPresent) {
					sendErrorFlag = sendDirectorApprovalMail(primaryId, request);

					log.debug("sendErrorFlag:" + sendErrorFlag);
				}
				if (directorPresent && sendErrorFlag) {
					request.setAttribute("sendApprovalMailFlag",
							"Not able to send Director Approval Mail");
				} else if (!directorPresent) {
					request.setAttribute(
							"sendApprovalMailFlag",
							"Please add Director in the contacts(should be an Employee, Primary Contact and Notify flag as enabled) page and then click on 'Send Approval Email'");
				} else {
					
					boolean updateFlag = false;
					try{
						
					updateFlag = util.updateDirectorApprovalMailFlag(planningId);
					
					}catch(Exception ex){
						
					}
							
					if (updateFlag) {
						sendErrorFlag = false;
					} else {
						sendErrorFlag = true;
						request.setAttribute("sendApprovalMailFlag",
								"Director Approval Mail was not sent. Please try again.");
					}
				}

			} else {
				request.setAttribute("sendApprovalMailFlag",
						"Provide correct data to send Director Approval Email");
				log.info("Provide Data to send Director Approval Email ");
			}
		}

		connectionCompleteCheck(request, "EmerBuscritInformation");

		BusinessJustificationProcess busjusProcess = new BusinessJustificationProcess();
		ConnectionRequest conreq = busjusProcess.getConnectionRequest(planningId);

		//completion check
		completionCheck(request, conreq, tirequest) ;
		
		}

		log.debug("Exit from emerBuscritSendMail()..");

		return result;
	}

	public RFCService getRfc() {
		return rfc;
	}

	public void setRfc(RFCService rfc) {
		this.rfc = rfc;
	}

	public EmerBuscritProcess getEmerBuscritProcess() {
		return emerBuscritProcess;
	}

	public void setEmerBuscritProcess(EmerBuscritProcess emerBuscritProcess) {
		this.emerBuscritProcess = emerBuscritProcess;
	}

	protected void connectionCompleteCheck(HttpServletRequest request,
			String stepName) {
		log.info("Entering into connectionCompleteCheck()..");
		
		IPRegHelper ipRegHelper = new IPRegHelper();
		@SuppressWarnings("unchecked")
		ArrayList<HashMap<String, String>> functionList = (ArrayList<HashMap<String, String>>) request.getSession().getAttribute(
				"FUNCTION_LIST");
		String path[] = IPRegHelper.CONN_PATH.split("~");

		try {
			if ((stepName.equals("EmerBuscritInformation")))
				ipRegHelper.setStatus(functionList, ipRegHelper
						.getEmerBuscritFunctionId(), ipRegHelper
						.convertBooleanToString(this
								.isEmerBuscritInformationComplete(request)),
						path);

		} catch (Exception e) {
			log.error(e);
		}
		log.info("Exit from connectionCompleteCheck()..");

	}

	public boolean isEmerBuscritInformationComplete(HttpServletRequest request) {

		RFCRequest rfcRequest = (RFCRequest) request.getSession().getAttribute(
				"rfcRequestObj");
		if (null != rfcRequest) {

			@SuppressWarnings("unchecked")
			List<RFCDetailAnswer> answerList = rfcRequest.getDescription()
					.getRfcDetailAnswerList();

			for (RFCDetailAnswer rfcDetailAnswer : answerList) {
				if (rfcDetailAnswer.getAnswer() == null
						|| (rfcDetailAnswer.getAnswer() != null && rfcDetailAnswer
								.getAnswer().isEmpty())) {
					return false;
				}
			}
			return true;

		} else {
			return false;
		}
	}

}
