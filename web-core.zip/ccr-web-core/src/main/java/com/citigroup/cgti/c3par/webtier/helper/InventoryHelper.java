package com.citigroup.cgti.c3par.webtier.helper;


import java.util.Date;
import java.util.Iterator;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.ConnectionDAO;
import com.citigroup.cgti.c3par.dao.PlanningDAO;
import com.citigroup.cgti.c3par.model.CitiContactXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionCitiContactXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionEntity;
import com.citigroup.cgti.c3par.model.ConnectionFirewallDetailsEntity;
import com.citigroup.cgti.c3par.model.ConnectionRequestEntity;
import com.citigroup.cgti.c3par.model.ConnectionFacilitiesAffectedXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionProjectJustificationXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionResourceXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionTPContactXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionTPServiceXrefEntity;
import com.citigroup.cgti.c3par.model.FacilitiesAffectedXrefEntity;
import com.citigroup.cgti.c3par.model.MaintenanceEntity;
import com.citigroup.cgti.c3par.model.PlanningEntity;
import com.citigroup.cgti.c3par.model.ProjectJustificationXrefEntity;
import com.citigroup.cgti.c3par.model.ResourceXrefEntity;
import com.citigroup.cgti.c3par.model.TPContactXrefEntity;
import com.citigroup.cgti.c3par.model.TPServiceXrefEntity;
//import com.citigroup.cgti.c3par.model.ConnectionIPXrefEntity;
//import com.citigroup.cgti.c3par.model.SetIPDetailXrefEntity;
//import com.citigroup.cgti.c3par.model.RequestIPXrefEntity;
import com.citigroup.cgti.c3par.model.PortFirewallXrefEntity;

import com.citigroup.cgti.c3par.model.FirewallDetailsEntity;

import com.citigroup.cgti.c3par.model.CitiLocationEntity;
import com.citigroup.cgti.c3par.model.CommonLookupDataEntity;
import com.citigroup.cgti.c3par.model.DocumentMetaDataEntity;
import com.citigroup.cgti.c3par.model.MaterialBillEntity;
//import com.citigroup.cgti.c3par.model.NetworkHostEntity;
import com.citigroup.cgti.c3par.model.NetworkConnectionEntity;
import com.citigroup.cgti.c3par.model.PortEntity;
//import com.citigroup.cgti.c3par.model.HostPortXrefEntity;

import com.citigroup.cgti.c3par.model.IPDetailEntity;
import com.citigroup.cgti.c3par.model.IPPairEntity;

import com.citigroup.cgti.c3par.webtier.helper.DocumentHelper;

import com.mentisys.dao.DatabaseException;
import org.apache.log4j.Logger;


/*
 * CONFIDENTIAL  AND PROPRIETARY
 */

/**
 * The Class InventoryHelper.
 */
public class InventoryHelper
{

    /** The log. */
    private static Logger log = Logger.getLogger(InventoryHelper.class);

    /**
     * Transform to inventory.
     *
     * @param planningEntity the planning entity
     * @return the connection entity
     */
    public static ConnectionEntity transformToInventory(PlanningEntity planningEntity)
    {
	ConnectionEntity connectionEntity = new ConnectionEntity();
	fillConnection(planningEntity, connectionEntity);
	connectionEntity.setConnectionRequestId(planningEntity.getId());
	connectionEntity.setReadyDate(new Date());
	return connectionEntity;
    }

    /**
     * Update connection inventory.
     *
     * @param maintenance the maintenance
     * @return the connection entity
     * @throws DatabaseException the database exception
     */
    public static ConnectionEntity updateConnectionInventory(MaintenanceEntity maintenance)
    throws DatabaseException
    {
	ConnectionEntity connection = maintenance.getConnection();
	if(connection == null)
	{
	    connection = ConnectionDAO.createInstance(new C3parSession()).get(maintenance.getConnectionId());
	}

	PlanningEntity planning = maintenance.getPlanning();
	if(planning == null)
	{
	    planning = (PlanningEntity)PlanningDAO.createInstance(new C3parSession()).get(maintenance.getPlanningId());
	}
	fillConnection(planning, connection);

	return connection;
    }

    /**
     * Fill maintanance with connection data.
     *
     * @param maintenanceEntity the maintenance entity
     * @param connectionEntity the connection entity
     */
    static public void fillMaintananceWithConnectionData(MaintenanceEntity maintenanceEntity, ConnectionEntity connectionEntity)
    {
    }

    /**
     * Transfer maintenance to connection.
     *
     * @param maintenanceEntity the maintenance entity
     */
    static public void transferMaintenanceToConnection(MaintenanceEntity maintenanceEntity)
    {
    }

    /**
     * Fill connection.
     *
     * @param planningEntity the planning entity
     * @param connectionEntity the connection entity
     */
    public static void fillConnection(PlanningEntity planningEntity, ConnectionEntity connectionEntity)
    {

	// All lookups
	connectionEntity.setLookup(planningEntity.getLookup());

	// Map business case
	connectionEntity.setRationale(planningEntity.getRationale());
	connectionEntity.setBenefit(planningEntity.getBenefit());
	connectionEntity.setSemiAnnualEntitlementReview(planningEntity.getSemiAnnualEntitlementReview());
	connectionEntity.setTpTrainingAwarnessProgram(planningEntity.getTpTrainingAwarnessProgram());
	connectionEntity.setCitiPolicyAdherence(planningEntity.getCitiPolicyAdherence());
	connectionEntity.setAccessCitiGlobalNetwork(planningEntity.getAccessCitiGlobalNetwork());
	connectionEntity.setPlcode(planningEntity.getPlcode());
	connectionEntity.setEstimatedRevenueGenerated(planningEntity.getEstimatedRevenueGenerated());
	connectionEntity.setEstimatedCostSaving(planningEntity.getEstimatedCostSaving());
	connectionEntity.setSponsorBusinessConsulted(planningEntity.getSponsorBusinessConsulted());
	connectionEntity.setExportLicenseCordinator(planningEntity.getExportLicenseCordinator());

	connectionEntity.clearProjectJustifications();
	Iterator it = planningEntity.getProjectJustifications().iterator();
	while(it.hasNext())
	{
	    ProjectJustificationXrefEntity xrefEntity = (ProjectJustificationXrefEntity)it.next();
	    ConnectionProjectJustificationXrefEntity cxrefEntity = new ConnectionProjectJustificationXrefEntity();
	    cxrefEntity.setConnection(connectionEntity);
	    cxrefEntity.setProjectJustification(xrefEntity.getProjectJustification());
	    connectionEntity.getProjectJustifications().add(cxrefEntity);
	}

	connectionEntity.clearFacilitiesAffected();
	it = planningEntity.getFacilitiesAffected().iterator();
	while(it.hasNext())
	{
	    FacilitiesAffectedXrefEntity xrefEntity = (FacilitiesAffectedXrefEntity)it.next();
	    ConnectionFacilitiesAffectedXrefEntity cxrefEntity = new ConnectionFacilitiesAffectedXrefEntity();
	    cxrefEntity.setConnection(connectionEntity);
	    cxrefEntity.setFacilitiesAffected(xrefEntity.getFacilitiesAffected());
	    connectionEntity.getFacilitiesAffected().add(cxrefEntity);
	}
	connectionEntity.setCobRedundancyRequired(planningEntity.getCobRedundancyRequired());

	// Connection basic information
	connectionEntity.setName(planningEntity.getConnectionName());
	connectionEntity.setNetCon(planningEntity.getNetCon());
	connectionEntity.setRequestDate(planningEntity.getPlannedActivateDate());

	connectionEntity.clearServices();
	it = planningEntity.getServices().iterator();
	while(it.hasNext())
	{
	    TPServiceXrefEntity xrefEntity = (TPServiceXrefEntity)it.next();
	    ConnectionTPServiceXrefEntity cxrefEntity = new ConnectionTPServiceXrefEntity();
	    cxrefEntity.setConnection(connectionEntity);
	    cxrefEntity.setService(xrefEntity.getService());
	    connectionEntity.getServices().add(cxrefEntity);
	}

	// Citigroup contacts
	connectionEntity.clearCitiContacts();
	it = planningEntity.getCitiContacts().iterator();
	while(it.hasNext())
	{
	    CitiContactXrefEntity xrefEntity = (CitiContactXrefEntity)it.next();
	    ConnectionCitiContactXrefEntity cxrefEntity = new ConnectionCitiContactXrefEntity();
	    cxrefEntity.setConnection(connectionEntity);
	    cxrefEntity.setRole(xrefEntity.getRole());
	    cxrefEntity.setCitiContact(xrefEntity.getCitiContact());
	    cxrefEntity.setPrimaryContact(xrefEntity.getPrimaryContact());
	    connectionEntity.getCitiContacts().add(cxrefEntity);
	}

	// Third party contacts
	connectionEntity.clearTpContacts();
	it = planningEntity.getTpContacts().iterator();
	while(it.hasNext())
	{
	    TPContactXrefEntity xrefEntity = (TPContactXrefEntity)it.next();
	    ConnectionTPContactXrefEntity cxrefEntity = new ConnectionTPContactXrefEntity();
	    cxrefEntity.setConnection(connectionEntity);
	    cxrefEntity.setRole(xrefEntity.getRole());
	    cxrefEntity.setTpContact(xrefEntity.getTpContact());
	    connectionEntity.getTpContacts().add(cxrefEntity);
	}

	// Resource
	connectionEntity.clearResources();
	it = planningEntity.getResources().iterator();
	while(it.hasNext())
	{
	    ResourceXrefEntity xrefEntity = (ResourceXrefEntity)it.next();
	    ConnectionResourceXrefEntity cxrefEntity = new ConnectionResourceXrefEntity();
	    cxrefEntity.setConnection(connectionEntity);
	    cxrefEntity.setResource(xrefEntity.getResource());
	    connectionEntity.getResources().add(cxrefEntity);
	}

	// Technical Architecture
	connectionEntity.clearMaterialBills();
	connectionEntity.getMaterialBills().addAll(planningEntity.getMaterialBill());
	//connectionEntity.clearHosts();
	//connectionEntity.getHosts().addAll(planningEntity.getHosts());
	/*  	connectionEntity.clearIpPairs();
  		connectionEntity.getIpPairs().addAll(planningEntity.getIpPairs());


		connectionEntity.clearIps();
		ConnectionIPXrefEntity connectionIPXrefEntity = null;
		Iterator ipListIter = planningEntity.getIps().iterator();
		while(ipListIter.hasNext()){
			RequestIPXrefEntity requestIPXref = (RequestIPXrefEntity)ipListIter.next();
			connectionIPXrefEntity = new ConnectionIPXrefEntity();
			connectionIPXrefEntity.setIp(requestIPXref.getIp());
			connectionEntity.getIps().add(connectionIPXrefEntity);
		}
	 */

	// Firewall
	connectionEntity.clearFirewalls();
	connectionEntity.getFirewalls().addAll(planningEntity.getFirewalls());



	// security review comments
	connectionEntity.setSecurityReviewComments(planningEntity.getSecurityReviewComment());
	connectionEntity.setIssConnectionCompliance(planningEntity.getIssConnectionCompliance());

	// Sponsor review comments
	connectionEntity.setSponsorReviewComments(planningEntity.getSponsorReviewComments());

	// Approve detailed design comment
	connectionEntity.setApproveDesignComments(planningEntity.getApproveDetailDesignComment());

	// Procurement & Network
	connectionEntity.setProcurementDate(planningEntity.getProcurementDate());
	connectionEntity.setProcurementComments(planningEntity.getProcurementComments());
	connectionEntity.setIntegrationStatusComments(planningEntity.getIntegrationStatusComments());

	//SystemAdmin comments
	connectionEntity.setSystemAdminComments(planningEntity.getSystemAdminComments());

	// Activate comments
	connectionEntity.setActivateConComments(planningEntity.getActivateConnectionComment());

	// Others
	connectionEntity.setRelationship(planningEntity.getRelationship());
	connectionEntity.setStatus(C3parStatusLookupNames.ACTIVE);
	connectionEntity.setRequesterId(planningEntity.getRequesterId());

	connectionEntity.setOperationalAnalystComments(planningEntity.getOperationalAnalystComments());
	connectionEntity.setIstgComments(planningEntity.getIstgComments());
	connectionEntity.setInfomanId(planningEntity.getInfomanId());
	connectionEntity.setOpAnalystScheduleDate(planningEntity.getOpAnalystScheduleDate());
	connectionEntity.setOpAnalystCompletedDate(planningEntity.getOpAnalystCompletedDate());

	ConnectionFirewallDetailsEntity connectionFirewallDetailsEntity = new ConnectionFirewallDetailsEntity();


    }


    /**
     * Transfrom connection2 planning.
     *
     * @param connection the connection
     * @param db_session the db_session
     * @return the planning entity
     * @throws DatabaseException the database exception
     */
    static public PlanningEntity transfromConnection2Planning(ConnectionEntity connection, C3parSession db_session)
    throws DatabaseException
    {
	//		C3parSession db_session = new C3parSession();
	PlanningEntity planning = new PlanningEntity();

	planning.setConnectionName(connection.getName());
	planning.setStatus(connection.getStatus());
	planning.setRequesterId(connection.getRequesterId());
	planning.setRationale(connection.getRationale());
	planning.setBenefit(connection.getBenefit());
	planning.setPlcode(connection.getPlcode());
	planning.setRequireNetworkAccess(connection.getRequireNetworkAccess());
	planning.setEstimatedRevenueGenerated(connection.getEstimatedRevenueGenerated());
	planning.setEstimatedCostSaving(connection.getEstimatedCostSaving());
	planning.setCobRedundancyRequired(connection.getCobRedundancyRequired());
	planning.setSemiAnnualEntitlementReview(connection.getSemiAnnualEntitlementReview());
	planning.setIssConnectionCompliance(connection.getIssConnectionCompliance());
	planning.setCitiPolicyAdherence(connection.getCitiPolicyAdherence());
	planning.setAccessCitiGlobalNetwork(connection.getAccessCitiGlobalNetwork());
	planning.setTpTrainingAwarnessProgram(connection.getTpTrainingAwarnessProgram());
	planning.setSponsorBusinessConsulted(connection.getSponsorBusinessConsulted());
	planning.setExportLicenseCordinator(connection.getExportLicenseCordinator());
	planning.setSecurityReviewComment(connection.getSecurityReviewComments());
	planning.setSponsorReviewComments(connection.getSponsorReviewComments());
	planning.setActivateConnectionComment(connection.getActivateConComments());
	planning.setApproveDetailDesignComment(connection.getApproveDesignComments());
	planning.setSystemAdminComments(connection.getSystemAdminComments());
	planning.setIntegrationStatusComments(connection.getIntegrationStatusComments());
	planning.setProcurementDate(connection.getProcurementDate());
	planning.setProcurementComments(connection.getProcurementComments());
	planning.setPlannedActivateDate(connection.getRequestDate());

	planning.setRelationship(connection.getRelationship());

	planning.setProcurementOptional(Boolean.TRUE);

	CommonLookupDataEntity con_lookup = connection.getLookup();
	CommonLookupDataEntity lookup = new CommonLookupDataEntity();
	lookup.setClassificationId(con_lookup.getClassificationId());
	lookup.setConnectionTypeId(con_lookup.getConnectionTypeId());
	lookup.setCustomerDataId(con_lookup.getCustomerDataId());
	lookup.setExpDataFeqId(con_lookup.getExpDataFeqId());
	lookup.setCitigroupDataId(con_lookup.getCitigroupDataId());
	lookup.setExpDataInfoSizeId(con_lookup.getExpDataInfoSizeId());
	lookup.setCriticalityId(con_lookup.getCriticalityId());
	planning.setLookup(lookup);

	// duplicate network connection
	NetworkConnectionEntity	con_net_con = connection.getNetCon();
	NetworkConnectionEntity	net_con = new NetworkConnectionEntity();

	net_con.setSplitTunneling(con_net_con.getSplitTunneling());
	net_con.setSplitTunnelingReason(con_net_con.getSplitTunnelingReason());
	net_con.setVirusContainmentStrategy(con_net_con.getVirusContainmentStrategy());
	net_con.setAccessContainmentStrategy(con_net_con.getAccessContainmentStrategy());

	//Firewall change by Gerald
	//****************************
	/*		net_con.setPrimaryFirewallName(con_net_con.getPrimaryFirewallName());
		net_con.setPrimaryPhyConAddress(con_net_con.getPrimaryPhyConAddress());
		net_con.setPrimaryCircuitId(con_net_con.getPrimaryCircuitId());
		net_con.setPrimaryBandwidth(con_net_con.getPrimaryBandwidth());
		net_con.setSecondaryFirewallName(con_net_con.getSecondaryFirewallName());
		net_con.setSecondaryPhyConAddress(con_net_con.getSecondaryPhyConAddress());
		net_con.setSecondaryCircuitId(con_net_con.getSecondaryCircuitId());
		net_con.setSecondaryBandwidth(con_net_con.getSecondaryBandwidth());*/
	//****************************

	net_con.setTpLocationId(con_net_con.getTpLocationId());

	CitiLocationEntity con_loc = con_net_con.getCitiLocation();
	CitiLocationEntity loc = new CitiLocationEntity();
	if(con_loc!=null){
	    loc.setAddress1(con_loc.getAddress1());
	    loc.setAddress2(con_loc.getAddress2());
	    loc.setCity(con_loc.getCity());
	    loc.setCounty(con_loc.getCounty());
	    loc.setRegion(con_loc.getRegion());
	    loc.setCountry(con_loc.getCountry());
	    loc.setRemsId(con_loc.getRemsId());
	    loc.setPrimaryId(con_loc.getPrimaryId());
	    net_con.setCitiLocation(loc);

	}

	planning.setNetCon(net_con);


	//		planning.setNetCon(connection.getNetCon());

	//		planning.setProjectJustifications(connection.getProjectJustifications());


	//Firewall change by Gerald
	//****************************
	Iterator firewall_iter = connection.getFirewalls().iterator();
	while(firewall_iter.hasNext())
	{
	    FirewallDetailsEntity firewall = new FirewallDetailsEntity();
	    FirewallDetailsEntity con_firewall = (FirewallDetailsEntity)firewall_iter.next();

	    firewall.setPrimaryFirewallName(con_firewall.getPrimaryFirewallName());
	    firewall.setPrimaryPhyConAddress(con_firewall.getPrimaryPhyConAddress());
	    firewall.setPrimaryCircuitId(con_firewall.getPrimaryCircuitId());
	    firewall.setPrimaryBandwidth(con_firewall.getPrimaryBandwidth());
	    firewall.setSecondaryFirewallName(con_firewall.getSecondaryFirewallName());
	    firewall.setSecondaryPhyConAddress(con_firewall.getSecondaryPhyConAddress());
	    firewall.setSecondaryCircuitId(con_firewall.getSecondaryCircuitId());
	    firewall.setSecondaryBandwidth(con_firewall.getSecondaryBandwidth());

	    planning.addToFirewalls(firewall);
	}
	//****************************





	Iterator just_iter = connection.getProjectJustifications().iterator();
	while(just_iter.hasNext())
	{
	    ProjectJustificationXrefEntity xref = new ProjectJustificationXrefEntity();
	    ConnectionProjectJustificationXrefEntity con_xref = (ConnectionProjectJustificationXrefEntity)just_iter.next();
	    xref.setRequest(planning);
	    xref.setProjectJustification(con_xref.getProjectJustification());
	    planning.addToProjectJustifications(xref);
	}


	//		planning.setFacilitiesAffected(connection.getFacilitiesAffected());
	Iterator facil_iter = connection.getFacilitiesAffected().iterator();
	while(facil_iter.hasNext())
	{
	    FacilitiesAffectedXrefEntity xref = new FacilitiesAffectedXrefEntity();
	    ConnectionFacilitiesAffectedXrefEntity con_xref = (ConnectionFacilitiesAffectedXrefEntity)facil_iter.next();
	    xref.setRequest(planning);
	    xref.setFacilitiesAffected(con_xref.getFacilitiesAffected());
	    planning.addToFacilitiesAffected(xref);
	}

	//		planning.setCitiContacts(connection.getCitiContacts());
	Iterator citi_iter = connection.getCitiContacts().iterator();
	while(citi_iter.hasNext())
	{
	    CitiContactXrefEntity xref = new CitiContactXrefEntity();
	    ConnectionCitiContactXrefEntity con_xref = (ConnectionCitiContactXrefEntity)citi_iter.next();
	    xref.setRequest(planning);
	    xref.setCitiContact(con_xref.getCitiContact());
	    xref.setRole(con_xref.getRole());
	    xref.setPrimaryContact(con_xref.getPrimaryContact());
	    planning.addToCitiContacts(xref);
	}

	//		planning.setTpContacts(connection.getTpContacts());
	Iterator tp_iter = connection.getTpContacts().iterator();
	while(tp_iter.hasNext())
	{
	    TPContactXrefEntity xref = new TPContactXrefEntity();
	    ConnectionTPContactXrefEntity con_xref = (ConnectionTPContactXrefEntity)tp_iter.next();
	    xref.setRequest(planning);
	    xref.setTpContact(con_xref.getTpContact());
	    xref.setRole(con_xref.getRole());
	    planning.addToTpContacts(xref);
	}

	//		planning.setResources(connection.getResources());
	Iterator res_iter = connection.getResources().iterator();
	while(res_iter.hasNext())
	{
	    ResourceXrefEntity xref = new ResourceXrefEntity();
	    ConnectionResourceXrefEntity con_xref = (ConnectionResourceXrefEntity)res_iter.next();
	    xref.setRequest(planning);
	    xref.setResource(con_xref.getResource());
	    planning.addToResources(xref);
	}

	//		planning.setServices(connection.getServices());
	Iterator serv_iter = connection.getServices().iterator();
	while(serv_iter.hasNext())
	{
	    TPServiceXrefEntity xref = new TPServiceXrefEntity();
	    ConnectionTPServiceXrefEntity con_xref = (ConnectionTPServiceXrefEntity)serv_iter.next();
	    xref.setRequest(planning);
	    xref.setService(con_xref.getService());
	    planning.addToServices(xref);
	}


	//		planning.setMaterialBill(connection.getMaterialBills());
	Iterator material_iter = connection.getMaterialBills().iterator();
	while(material_iter.hasNext())
	{
	    MaterialBillEntity bill = new MaterialBillEntity();
	    MaterialBillEntity con_bill = (MaterialBillEntity)material_iter.next();

	    bill.setItem(con_bill.getItem());
	    bill.setOneTimeCost(con_bill.getOneTimeCost());
	    bill.setMonthlyCost(con_bill.getMonthlyCost());
	    bill.setSerialNumber(con_bill.getSerialNumber());

	    planning.addToMaterialBill(bill);
	}




	planning.setOperationalAnalystComments(connection.getOperationalAnalystComments());
	planning.setIstgComments(connection.getIstgComments());
	planning.setInfomanId(connection.getInfomanId());
	planning.setOpAnalystScheduleDate(connection.getOpAnalystScheduleDate());
	planning.setOpAnalystCompletedDate(connection.getOpAnalystCompletedDate());




	//		planning.setMaterialBill(connection.getMaterialBills());
	//		ConnectionRequestEntity con_req = ConnectionRequestDAO.createInstance(db_session).get(connection.getConnectionRequestId(), false);
	//		ConnectionRequestDAO.createInstance(db_session).loadDocumentReferences(con_req);

	//		Iterator doc_iter = con_req.getDocument().iterator();
	//		while(doc_iter.hasNext())
	//		{
	//			DocumentMetaDataEntity con_doc = (DocumentMetaDataEntity)doc_iter.next();
	//			DocumentMetaDataEntity doc = cloneDocument(con_doc, db_session);
	//			planning.addToDocument(doc);
	//		}

	//		planning.setHosts(connection.getHosts());

	/*		Iterator it = connection.getIps().iterator();

		IPDetailEntity con_ipDetailEntity = null;
		IPDetailEntity ipDetailEntity = null;

		RequestIPXrefEntity requestIPXref = new RequestIPXrefEntity();

		while(it.hasNext())
		{
			ConnectionIPXrefEntity connectionIPXref = (ConnectionIPXrefEntity)it.next();
			con_ipDetailEntity = connectionIPXref.getIp();
			ipDetailEntity = new IPDetailEntity();

			ipDetailEntity.setIp(con_ipDetailEntity.getIp());
			ipDetailEntity.setType(con_ipDetailEntity.getType());

			ipDetailEntity.setStartIP(con_ipDetailEntity.getStartIP());
			ipDetailEntity.setEndIP(con_ipDetailEntity.getEndIP());
			ipDetailEntity.setSubnet(con_ipDetailEntity.getSubnet());
			ipDetailEntity.setNoOfHost(con_ipDetailEntity.getNoOfHost());
			ipDetailEntity.setBroadCastAddress(con_ipDetailEntity.getBroadCastAddress());
			ipDetailEntity.setIpDestination(con_ipDetailEntity.getIpDestination());


			requestIPXref.setIp(ipDetailEntity);

			planning.addToIps(requestIPXref);
		}



		it = connection.getIpPairs().iterator();
		IPPairEntity con_ipPairEntity = null;
		IPPairEntity ipPairEntity = null;
		while(it.hasNext())
		{
			con_ipPairEntity = (IPPairEntity)it.next();
			ipPairEntity = new IPPairEntity();
			ipPairEntity.setName(con_ipPairEntity.getName());
			ipPairEntity.setResourceId(con_ipPairEntity.getResourceId());
			ipPairEntity.setNATAddress(con_ipPairEntity.getNATAddress());
			Iterator port_iter = con_ipPairEntity.getPorts().iterator();
			while(port_iter.hasNext())
			{
				PortEntity port = new PortEntity();
				PortEntity con_port = (PortEntity)port_iter.next();
				port.setApplicationName(con_port.getApplicationName());
				port.setPortNumber(con_port.getPortNumber());
				port.setProtocol(con_port.getProtocol());
				port.setFlowOfData(con_port.getFlowOfData());
				port.setAnswers(con_port.getAnswers());


				Iterator portfirewall_iter = con_port.getFirewalls().iterator();
				while(portfirewall_iter.hasNext()){
					PortFirewallXrefEntity portFirewallXref = new PortFirewallXrefEntity();
					PortFirewallXrefEntity con_portFirewallXref = (PortFirewallXrefEntity)portfirewall_iter.next();
					portFirewallXref.setFirewall(con_portFirewallXref.getFirewall());
					port.addToFirewalls(portFirewallXref);
				}

				if(con_port.getJustification()!=null && !con_port.getJustification().trim().equals(""))
					port.setJustification(con_port.getJustification());
				ipPairEntity.addToPorts(port);
			}
			Iterator ip_iter = con_ipPairEntity.getIps().iterator();
			while(ip_iter.hasNext()){
				SetIPDetailXrefEntity setIPDetailXrefEntity = new SetIPDetailXrefEntity();
				SetIPDetailXrefEntity con_setIPDetailXrefEntity = (SetIPDetailXrefEntity)ip_iter.next();
				setIPDetailXrefEntity.setIp(con_setIPDetailXrefEntity.getIp());
				ipPairEntity.addToIps(setIPDetailXrefEntity);
			}
			planning.addToIpPairs(ipPairEntity);
		}
	 */



	/*Iterator hosts_iter = connection.getHosts().iterator();
		while(hosts_iter.hasNext())
		{
			NetworkHostEntity host = new NetworkHostEntity();
			NetworkHostEntity con_host = (NetworkHostEntity)hosts_iter.next();
			host.setAntiVirus(con_host.getAntiVirus());
			host.setNetworkSegment(con_host.getNetworkSegment());
			host.setContainmentStrategy(con_host.getContainmentStrategy());
			host.setHostName(con_host.getHostName());
			host.setAdministrativeAccess(con_host.getAdministrativeAccess());
			host.setAuditLogging(con_host.getAuditLogging());
			host.setAuditLoggingCitiControlled(con_host.getAuditLoggingCitiControlled());
			host.setAuthenticationControl(con_host.getAuthenticationControl());
			host.setIntrusionDetectionMechanism(con_host.getIntrusionDetectionMechanism());
			host.setControlEnvironment(con_host.getControlEnvironment());
			host.setResourceId(con_host.getResourceId());

			host.setOperatingSystem(con_host.getOperatingSystem());

			Iterator port_iter = con_host.getPorts().iterator();
			while(port_iter.hasNext())
			{
				HostPortXrefEntity xref = new HostPortXrefEntity();
				PortEntity port = new PortEntity();
				HostPortXrefEntity con_xref = (HostPortXrefEntity)port_iter.next();
				PortEntity con_port = con_xref.getPort();

				port.setApplicationName(con_port.getApplicationName());
				port.setPortNumber(con_port.getPortNumber());
				port.setProtocol(con_port.getProtocol());
				port.setFlowOfData(con_port.getFlowOfData());


				if(con_port.getJustification()!=null && !con_port.getJustification().trim().equals(""))
					port.setJustification(con_port.getJustification());

				xref.setPort(port);
				host.addToPorts(xref);
			}

			planning.addToHosts(host);
		}*/

	/*	private	Date	readyDate;
	private	String	comments; */
	/*	private	Long	connectionRequestId; */

	// --------- Planning ----------
	/*	private	Boolean	integrationCompleted; */

	return planning;
    }

    /**
     * Clone document.
     *
     * @param doc the doc
     * @param db_session the db_session
     * @return the document meta data entity
     * @throws DatabaseException the database exception
     */
    static protected DocumentMetaDataEntity cloneDocument(DocumentMetaDataEntity doc, C3parSession db_session)
    throws DatabaseException
    {
	DocumentMetaDataEntity cloned_doc = new DocumentMetaDataEntity();
	cloned_doc.setName(doc.getName());
	cloned_doc.setType(doc.getType());
	cloned_doc.setContentType(doc.getContentType());

	db_session.updateEntity(cloned_doc);

	try
	{
	    byte [] content = DocumentHelper.getDocument(doc.getId(), db_session);
	    DocumentHelper.saveDocument(cloned_doc.getId(), content, db_session);
	}
	catch(Exception e)
	{

	    log.error(e);
	    throw new DatabaseException("Failed to clone document", e);
	}

	return cloned_doc;
    }



    /**
     * Fill connection with planning data.
     *
     * @param planningEntity the planning entity
     * @param connectionEntity the connection entity
     */
    static protected void fillConnectionWithPlanningData(PlanningEntity planningEntity, ConnectionEntity connectionEntity)
    {
    }

    /**
     * Fill connection with request data.
     *
     * @param requestEntity the request entity
     * @param connectionEntity the connection entity
     */
    static protected void fillConnectionWithRequestData(ConnectionRequestEntity requestEntity, ConnectionEntity connectionEntity)
    {
    }

}
