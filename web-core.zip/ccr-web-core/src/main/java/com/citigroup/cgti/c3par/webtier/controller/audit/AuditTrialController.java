package com.citigroup.cgti.c3par.webtier.controller.audit;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.audit.domain.AuditTrailProcess;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.common.domain.AuditLog;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditResponse;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class AuditTrialController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.
	 * ActionMapping, org.apache.struts.action.ActionForm,
	 * javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */

	@RequestMapping(value = "/auditTrailController.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadConnection(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		log.debug("Entering into loadConnection");
		String forward = "c3par.review.audit_trail";

		String processType = request.getParameter("type");

		Util util = new Util();

		String selTab = request.getParameter("sel_tab");

		if (selTab != null) {
			request.getSession().setAttribute("selected_Tab",
					util.getSelectedTab(null, selTab, null));
		}

		AuditTrailProcess auditTrailProcess = new AuditTrailProcess();
		log.debug("auditTrialProcess.getTiProcess()::"
				+ auditTrailProcess.getTiProcess());

		if ((auditTrailProcess.getTiProcess() == null)
				|| (auditTrailProcess.getTiProcess().longValue() == 0)) {

			log.debug("process id inside loadConnection::"
					+ request.getParameter("processId"));
			String strProcessId = request.getParameter("processId");
			log.debug("strProcessId::" + strProcessId);

			try {
				auditTrailProcess.setTiProcess1(new TIProcess());
				auditTrailProcess.getTiProcess1().setId(
						Long.valueOf(strProcessId));
				auditTrailProcess.setTiProcess1(auditTrailProcess
						.getAuditTrail(auditTrailProcess.getTiProcess1()));
			} catch (Exception e) {
				this.log.error(e);
			}
		}

		model.addAttribute("AuditTrailProcess", auditTrailProcess);
		log.debug("Exiting from loadConnection");
		return forward;
	}

	@RequestMapping(value = "/loadEMailAuditTrailList.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadEMailAuditTrailList(
			ModelMap model,
			@ModelAttribute("AuditTrailProcess") AuditTrailProcess auditTrailProcess,
			HttpServletRequest request) {
		log.debug("ManageAuditTrailControlller::loadEMailAuditTrailList methods starts...");
		String forwardPage = "c3par.review.mail_audit_trail";

		Long processID = 0L;
		Long tirequestId = Long.valueOf(request.getParameter("tiRequestId"));

		TIRequest tirequest = auditTrailProcess
				.getTIRequestDetails(tirequestId);

		Util util = new Util();

		String selTab = request.getParameter("sel_tab");

		if (selTab != null) {
			request.getSession().setAttribute("selected_Tab",
					util.getSelectedTab(null, selTab, null));
		}
		if (tirequest != null) {
			processID = tirequest.getTiProcess().getId();

		}

		auditTrailProcess.setTiProcess(processID);

		List<TIMailAudit> tiMailAudit = auditTrailProcess
				.getEMailAuditTrailList();
		auditTrailProcess.setTiMailAuditList(tiMailAudit);

		model.addAttribute("AuditTrailProcess", auditTrailProcess);
		log.debug("ManageAuditTrailControlller::loadEMailAuditTrailList methods ends...forwardPage ==> "
				+ forwardPage);

		return forwardPage;
	}

	@RequestMapping(value = "/loadEMailAuditTrail.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadEMailAuditTrail(
			ModelMap model,
			@ModelAttribute("AuditTrailProcess") AuditTrailProcess auditTrailProcess,
			HttpServletRequest request) {
		log.debug("ManageAuditTrailControlller::loadEMailAuditTrail methods starts...");
		String forwardPage = "pages/audit/emailAuditTrail";

		Long auditTrailID = 0L;
		if (request.getParameter("mailAuditTrailID") != null) {
			auditTrailID = Long.valueOf(request
					.getParameter("mailAuditTrailID"));
			log.debug("ManageAuditTrailControlller::loadEMailAuditTrail:: mailAuditTrailID ==> "
					+ auditTrailID);
		}
		auditTrailProcess.setEmailAuditTrailID(auditTrailID);
		TIMailAudit tiMailAudit = auditTrailProcess.getEMailAuditTrail();
		auditTrailProcess.setTiMailAudit(tiMailAudit);

		model.addAttribute("AuditTrailProcess", auditTrailProcess);
		log.debug("ManageAuditTrailControlller::loadEMailAuditTrail methods ends..."
				+ forwardPage);

		return forwardPage;
	}

	@RequestMapping(value = "/loadResponseEMailAuditTrail.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadResponseEMailAuditTrail(
			ModelMap model,
			@ModelAttribute("AuditTrailProcess") AuditTrailProcess auditTrailProcess,
			HttpServletRequest request) {
		log.debug("ManageAuditTrailControlller::loadResponseEMailAudit methods starts...");
		String forwardPage = "pages/audit/emailAuditTrailResponse";
		auditTrailProcess = new AuditTrailProcess();

		Long auditTrailID = 0L;
		if (request.getParameter("resMailID") != null) {
			auditTrailID = Long.valueOf(request.getParameter("resMailID"));
			log.debug("ManageAuditTrailControlller::loadResponseEMailAuditTrail:: mailAuditTrailID ==> "
					+ auditTrailID);
		}
		auditTrailProcess.setEmailAuditTrailID(auditTrailID);
		TIMailAuditResponse tiMailAuditRes = auditTrailProcess
				.getResponseEMailAuditTrail();
		auditTrailProcess.setTiMailAuditResponse(tiMailAuditRes);
		model.addAttribute("AuditTrailProcess", auditTrailProcess);
		log.debug("ManageAuditTrailControlller::loadResponseEMailAuditTrail methods ends..."
				+ forwardPage);

		return forwardPage;
	}

	@RequestMapping(value = "/loadAdminChangesDetail.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadAdminChangesDetail(
			ModelMap model,
			@ModelAttribute("AuditTrailProcess") AuditTrailProcess auditTrailProcess,
			HttpServletRequest request) {
		log.debug("ManageAuditTrailControlller::LoadAdminChangesDetail method starts ... ");
		String forwardPage = "c3par.review.mail_audit_trail_adminChanges";
		AuditLog auditLog = new AuditLog();

		Long tirequestId = Long.valueOf(request.getParameter("tiRequestId"));

		TIRequest tirequest = auditTrailProcess
				.getTIRequestDetails(tirequestId);

		Long processID = 0L;
		Util util = new Util();

		String selTab = request.getParameter("sel_tab");

		if (selTab != null) {
			request.getSession().setAttribute("selected_Tab",
					util.getSelectedTab(null, selTab, null));
		}

		if (tirequest != null) {
			processID = tirequest.getTiProcess().getId();

		}

		auditTrailProcess.setTiRequest(tirequestId);
		auditTrailProcess.setTiProcess(processID);

		List<AuditLog> auditLogList = auditTrailProcess
				.getAdminChangeDetails(processID);
		auditTrailProcess.setAuditLogList(auditLogList);

		model.addAttribute("AuditTrailProcess", auditTrailProcess);
		log.debug("ManageAuditTrailControlller::LoadAdminChangesDetail method ends ....");
		return forwardPage;
	}

	@RequestMapping(value = "/loadContactDetails.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadContactDetails(
			ModelMap model,
			@ModelAttribute("AuditTrailProcess") AuditTrailProcess auditTrailProcess,
			HttpServletRequest request) {
		log.debug("ManageAuditTrailControlller:LoadContactDetails method starts...");
		String forwardPage = "pages/audit/viewContactDetails";

		String contact = request.getParameter("contactID");
		String objName = request.getParameter("objName");
		String entry = request.getParameter("entry");
		Long contactID = Long.valueOf(contact);
		List<ContactDetailsDTO> contactList = auditTrailProcess
				.getContactsDetails(contactID, objName, entry);
		auditTrailProcess.setContactDetailsList(contactList);
		model.addAttribute("AuditTrailProcess", auditTrailProcess);
		log.debug("ManageAuditTrailControlller:LoadContactDetails method ends"
				+ contactList);
		return forwardPage;
	}

	@RequestMapping(value = "/loadRelationshipDetails.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadRelationshipDetails(
			ModelMap model,
			@ModelAttribute("AuditTrailProcess") AuditTrailProcess auditTrailProcess,
			HttpServletRequest request) {
		log.debug("ManageAuditTrailControlller:loadRelationshipDetails method starts...");
		String forwardPage = "pages/audit/viewRelationshipDetails";

		String relationID = request.getParameter("relationID");
		Long rID = Long.valueOf(relationID);
		List<RelationshipDTO> relationDetailsList = auditTrailProcess
				.getRelationshipDetails(rID);
		auditTrailProcess.setRelationDetailsList(relationDetailsList);
		model.addAttribute("AuditTrailProcess", auditTrailProcess);
		log.debug("ManageAuditTrailControlller:loadRelationshipDetails method ends"
				+ relationDetailsList);
		return forwardPage;
	}
}
