/**
 *
 */
package com.citigroup.cgti.c3par.communication.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.communication.domain.CMPDoNotAssign;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CmpConnectionDetail;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.communication.domain.ECMUserSearchProcess;
import com.citigroup.cgti.c3par.communication.domain.EcmLeadQueue;
import com.citigroup.cgti.c3par.communication.domain.EcmLeadViewProcess;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueUsers;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.CMPRequestPersistable;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.EcmLeadViewPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.relationship.domain.DsmtSgmntSector;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

/**
 * @author eg41091
 * 
 */
@Transactional
public class EcmLeadViewImpl extends BasePersistanceImpl implements
		EcmLeadViewPersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(EcmLeadViewImpl.class);
	
	private CMPRequestPersistable cmpRequestPersistable;

	private DataSource dataSource;

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public CMPRequestPersistable getCmpRequestPersistable() {
		return cmpRequestPersistable;
	}

	public void setCmpRequestPersistable(CMPRequestPersistable cmpRequestPersistable) {
		this.cmpRequestPersistable = cmpRequestPersistable;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public List<CMPRequest> selectLeadDetails(EcmLeadViewProcess ecmLeadViewProcess,String sectorId) { 
		log.info("EcmLeadViewImpl::selectLeadDetails starts>>>");
		List<CMPRequest> rslvitMsg = null;
		Session session = getSession();		
		C3parUser c3parUser = null;	
		if(sectorId==null||sectorId.equals("")){ 
			
			Query query = session.createQuery("from C3parUser where upper(ssoId) = ?").setString(0, ecmLeadViewProcess.getSoeId());
			
			List<C3parUser> list = (List<C3parUser>)query.list();		
			if (list != null && list.size() > 0) {
				c3parUser = list.get(0);
				lazyInitialize(c3parUser.getEcmQueueUsersList());
			}
			
			List<String> sectorList = new ArrayList<String>();

			List<EcmQueueUsers> ecmQueueUsers = c3parUser.getEcmQueueUsersList();
			EcmQueueUsers ecmQueueUser;
			if (ecmQueueUsers != null && !ecmQueueUsers.isEmpty()) {
				ecmQueueUser = ecmQueueUsers.get(0);
						sectorList.add(ecmQueueUser.getEcmQueue().getQueueName());
						log.info("ecmQueueUser>>>>" + ecmQueueUser.getEcmQueue().getDisplayName());
			}
			
			log.info("sectorList>>>>" + sectorList);
			log.debug("sectorList.size(): "+sectorList.size()); 
			
			String sortingColumnName = ecmLeadViewProcess.getSortingColumnName();
			try {

				Criteria cre = session.createCriteria(CMPRequest.class); 
				//cre.add(Restrictions.in("ecmSector", sectorList));
				cre.add(Restrictions.isNull("assignedUser"));
				cre.add(Restrictions.eq("status", ECMConstants.APPROVED).ignoreCase());
				ecmLeadViewProcess.setTotalRecords(cre.list().size());  
				log.info("ecmLeadViewProcess..."+ecmLeadViewProcess.getTotalRecords());
				addPagination(cre, ecmLeadViewProcess.getOffset(), ecmLeadViewProcess.getLimit());
				log.info("ecmLeadViewProcess.222.."+ecmLeadViewProcess.getTotalRecords()+"--"+ecmLeadViewProcess.getOrderBy());
				log.debug("Column Name passed: "+ecmLeadViewProcess.getSortingColumnName());
				
				if(ecmLeadViewProcess.getOrderBy() != null && ecmLeadViewProcess.getSortingColumnName() != null){
					
					if("asc".equals(ecmLeadViewProcess.getOrderBy())){
						if (sortingColumnName != null
								&& !sortingColumnName.equals("")
								&& sortingColumnName
										.equals("typeofConnectivityInvolved")) {
							cre.addOrder(Order.asc("typeofConnectivityInvolved"))
									.addOrder(Order.asc("requestType"));
							log.debug("inside AgentViewImpl:typeofConnectivityInvolved "
									+ sortingColumnName);
						} else {
						cre.addOrder(Order.asc(ecmLeadViewProcess.getSortingColumnName()));
						}
					} else if("desc".equals(ecmLeadViewProcess.getOrderBy())){
						cre.addOrder(Order.desc(ecmLeadViewProcess.getSortingColumnName()));
					}
					
				} 
				rslvitMsg = (List<CMPRequest>) cre.list();
				System.out.println("CMPRequest>>>>" + rslvitMsg.size());
				log.info("CMPRequest>>>>" + rslvitMsg.size());

			} catch (Exception e) {
				log.error("EcmLeadViewImpl::selectLeadDetail>>> " + e);
			}
			
		
		}else{
			  
			
          Query query = session.createQuery("from C3parUser where upper(ssoId) = ?").setString(0, ecmLeadViewProcess.getSoeId());
			
			List<C3parUser> list = (List<C3parUser>)query.list();		
			if (list != null && list.size() > 0) {
				c3parUser = list.get(0);
				lazyInitialize(c3parUser.getEcmQueueUsersList());
			}
			
			List<String> sectorList = new ArrayList<String>();

			List<EcmQueueUsers> ecmQueueUsers = c3parUser.getEcmQueueUsersList();
			EcmQueueUsers ecmQueueUser;
			if (ecmQueueUsers != null && !ecmQueueUsers.isEmpty()) {
				ecmQueueUser = ecmQueueUsers.get(0);
						sectorList.add(ecmQueueUser.getEcmQueue().getQueueName());
						log.info("ecmQueueUser>>>>" + ecmQueueUser.getEcmQueue().getDisplayName());
			}
			
			log.info("sectorList>>>>" + sectorList);
			log.debug("sectorList.size(): "+sectorList.size()); 
			
			String sortingColumnName = ecmLeadViewProcess.getSortingColumnName();
			try {

				Criteria cre = session.createCriteria(CMPRequest.class); 
				//cre.add(Restrictions.in("ecmSector", sectorList));
				cre.add(Restrictions.isNull("assignedUser"));
				cre.add(Restrictions.eq("status", ECMConstants.APPROVED).ignoreCase());
				cre.add(Restrictions.eq("ecmSector", sectorId));
			 
				ecmLeadViewProcess.setTotalRecords(cre.list().size());  
				log.info("ecmLeadViewProcess..."+ecmLeadViewProcess.getTotalRecords());
				addPagination(cre, ecmLeadViewProcess.getOffset(), ecmLeadViewProcess.getLimit());
				log.info("ecmLeadViewProcess.222.."+ecmLeadViewProcess.getTotalRecords()+"--"+ecmLeadViewProcess.getOrderBy());
				log.debug("Column Name passed: "+ecmLeadViewProcess.getSortingColumnName());
				
				if(ecmLeadViewProcess.getOrderBy() != null && ecmLeadViewProcess.getSortingColumnName() != null){
					
					if("asc".equals(ecmLeadViewProcess.getOrderBy())){
						if (sortingColumnName != null
								&& !sortingColumnName.equals("")
								&& sortingColumnName
										.equals("typeofConnectivityInvolved")) {
							cre.addOrder(Order.asc("typeofConnectivityInvolved"))
									.addOrder(Order.asc("requestType"));
							log.debug("inside AgentViewImpl:typeofConnectivityInvolved "
									+ sortingColumnName);
						} else {
						cre.addOrder(Order.asc(ecmLeadViewProcess.getSortingColumnName()));
						}
					} else if("desc".equals(ecmLeadViewProcess.getOrderBy())){
						cre.addOrder(Order.desc(ecmLeadViewProcess.getSortingColumnName()));
					}
					
				} 
				rslvitMsg = (List<CMPRequest>) cre.list();
				System.out.println("CMPRequest>>>>" + rslvitMsg.size());
				log.info("CMPRequest>>>>" + rslvitMsg.size());

			} catch (Exception e) {
				log.error("EcmLeadViewImpl::selectLeadDetail>>> " + e);
			}
			
		
	
		
		}
		return rslvitMsg;
	}

	@SuppressWarnings("unchecked")
	public List<EcmLeadViewProcess> selectEcmUsers(String searchEcmuserCriter) {

		log.info("EcmLeadViewImpl::selectEcmUsers starts>>>"); 
		List<EcmLeadViewProcess> ecmProcessList = null;
		List<String> ecmUserArrList = new ArrayList<String>();

		List<EcmLeadViewProcess> finalList = new ArrayList<EcmLeadViewProcess>();
		try {

			Session session = getSession();

			StringBuilder queryString = new StringBuilder();
			queryString
					.append(" select  usrs.last_name,usrs.first_name,usrs.sso_id,cdna.is_locked,cdna.comments from C3PAR_USERS usrs, C3PAR_USER_ROLE_XREF userRole, cmp_do_not_assign cdna ");
			queryString
					.append(" where usrs.ID = userRole.USER_ID and userRole.ROLE_ID = (select id from security_role where name = 'ECM Agent') ");
			queryString.append(" and usrs.is_Active = 'Y' and cdna.agent_id(+)=usrs.sso_id ");
			if (searchEcmuserCriter != null
					&& searchEcmuserCriter.trim().length() > 0) {
				queryString.append(" and (UPPER(usrs.last_name) like UPPER('%"
						+ searchEcmuserCriter
						+ "%') or UPPER(usrs.first_name)  like UPPER('%"
						+ searchEcmuserCriter + "%') or UPPER(usrs.sso_id) like UPPER('%"
						+ searchEcmuserCriter + "%')) ");
			}
			queryString.append(" order by usrs.last_name ");

			log.info("ecmUserArrList queryString value-->"
					+ queryString.toString());

			SQLQuery query = session.createSQLQuery(queryString.toString());
			ecmProcessList = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();
			// List<C3parUser> ecmUsersList = query.list();
			log.info("ecmUserArrList concated value-->" + ecmUserArrList);

			EcmLeadViewProcess ecmLeadViewProcess = null;

			for (Object obj : ecmProcessList) {
				Map map = (Map) obj;

				finalList.add(new EcmLeadViewProcess(
						(String) map.get("SSO_ID"), (String) map
								.get("LAST_NAME"), (String) map
								.get("FIRST_NAME"),(String) map
								.get("IS_LOCKED"),(String) map
								.get("COMMENTS")));
			}

		} catch (Exception e) {
			log.error("EcmLeadViewImpl::selectEcmUsers>>> " + e);
		}

		return ecmProcessList;
	}
	
	@Override
	@Transactional(readOnly = true)
	public boolean updateAssignedEcmUser(String cmpReqId, String AssignTo ,Long sloDays,String userId,String leadComments) {
		log.info("Entering into updateAssignedEcmUser()..");		
		int result = 0;
		Integer contactId = 0;
		try {
			Session session = getSession();
				String fetchUserIdQuery = "(select id from C3PAR_USERS where SSO_ID='"+AssignTo+"'),";			
				String queryString = "update cmp_request set assigned_user="+fetchUserIdQuery+"UPDATE_ASSIGNED_USER_DATE = sysdate,status='In Progress',slo_days = "+sloDays+" where ID="+cmpReqId;
				log.info("queryString>>>"+queryString);
				SQLQuery query = session.createSQLQuery(queryString);			
				result = query.executeUpdate();
				
				String ldComments = "insert into cmp_request_notes values (SEQ_CMP_REQUEST_NOTES.nextval,"+cmpReqId+",'"+leadComments+"',sysdate,'ECM','','' )";
				log.info("leadComments queryString>>>"+ldComments);
				SQLQuery leadCommentQuery = session.createSQLQuery(ldComments);				
				result = leadCommentQuery.executeUpdate();
			
				//cmpRequestPersistable.cmpActivityTrail(Long.valueOf(cmpReqId), userId, ECMConstants.ASSIGN_AGENT_TASK_CODE, ECMConstants.STATUS_STARTED);	
			
				CitiContact agent = cmpRequestPersistable.getUserIdForSsoId(AssignTo);
			
				String checkUserContact = "(select id from CMP_REQUEST_CON_XREF where citi_contact_id="+agent.getId()+" and cmp_id="+cmpReqId+" and role_id =(select id from cmp_role where name='design_engineer'))";
				log.info("queryString>>>"+checkUserContact);
				SQLQuery query1 = session.createSQLQuery(checkUserContact);
				
				contactId =(Integer) query1.addScalar("id", IntegerType.INSTANCE).uniqueResult();
				
				if(contactId==null || contactId<= 0){
								
						String contact = "insert into CMP_REQUEST_CON_XREF values (seq_cmp_request_con_xref.nextval,"+cmpReqId+",(select id from cmp_role where name='design_engineer'),"+agent.getId()+" )";
						log.info("queryString>>>"+contact);
						SQLQuery query3 = session.createSQLQuery(contact);				
						result = query3.executeUpdate();
					}
			} catch (Exception e) {					
				log.error("EcmLeadViewImpl::updateAssignedEcmUser>>> " + e);
			}		
		log.info("Exit from updateAssignedEcmUser()..");				
		return result==1? true:false;		
	}


	@Override
	@Transactional(readOnly = true)
	public List<EcmLeadQueue> getAgentListForSector(String soeid) {
		log.info("Into getAgentListForSector method");
		
		List<EcmLeadQueue> teamQueueList = new ArrayList<EcmLeadQueue>();
		EcmLeadQueue teamQueue;
		
		try {
			Session session = getSession();
			
			StringBuilder queue = new StringBuilder(); 

					
			
			queue.append("select distinct cu.SSO_ID soeid,eq.queue_name sector ");
			queue.append(",nvl((select listagg(r.NAME,',') within group (order by r.NAME)from C3PAR_USER_ROLE_XREF curx1,security_role r where curx1.user_id=cr.assigned_user and ");
			queue.append("curx1.ROLE_ID in (select id from security_role where name  in ('ECM Agent','ECM Lead','ECM Manager')) and r.id=curx1.role_id ),'none') role,cu.FIRST_NAME firstname,cu.LAST_NAME lastname ");
			queue.append(",nvl((select count(ASSIGNED_USER) from CMP_REQUEST cmp where  cmp.ASSIGNED_USER=cr.ASSIGNED_USER  and   upper(cmp.STATUS) not in (upper('Cancelled'),upper('Completed')) ),0) total ");
			queue.append(",nvl((select count(ASSIGNED_USER) from CMP_REQUEST cmp where to_date(cmp.UPDATE_ASSIGNED_USER_DATE)<to_date(sysdate) and cmp.ASSIGNED_USER=cr.ASSIGNED_USER  and   upper(cmp.STATUS) not in (upper('Cancelled'),upper('Completed')) ),0) inQueue "); 
			queue.append(",nvl((select count(request_type) from CMP_REQUEST cmp where request_type='Assistance Request' and cmp.ASSIGNED_USER=cr.ASSIGNED_USER ");
			queue.append("and  to_date(UPDATE_ASSIGNED_USER_DATE)=to_date(sysdate) ),0) assist ");
			queue.append(",nvl(z.a1,0) bau,nvl(y.b1,0) buscrit,nvl((select count(UPDATE_ASSIGNED_USER_DATE) from cmp_request cr1 where cr1.ASSIGNED_USER=cr.ASSIGNED_USER ");
			queue.append("and UPDATE_ASSIGNED_USER_DATE between (Select TRUNC(sysdate, 'IW') FROM_DATE From dual) ");	
			queue.append("and (select NEXT_DAY(TRUNC(sysdate,'IW'),'SUNDAY') TO_DATE from dual) and   upper(cr1.STATUS) not in (upper('Cancelled'),upper('Completed')) ),0) weekCount,nvl(cdna.is_locked,'N') lockedBy,nvl(cdna.COMMENTS, ' ') comments ");
			queue.append("from C3PAR_USERS cu "); 
			queue.append("left join cmp_request cr on cr.ASSIGNED_USER=cu.id ");
			queue.append("join ECM_QUEUE_USERS equ on equ.user_id =cu.id ");
			queue.append("join ecm_queue eq on equ.ecm_queue_id=eq.id ");
			queue.append("left join ecm_queue_users equ1 on equ.ECM_QUEUE_ID= equ1.ecm_queue_id and equ1.USER_ID=cu.id ");
			queue.append("left outer join  (select count(request_urgency) a1,ASSIGNED_USER a3 "); 
			queue.append("from CMP_REQUEST c where REQUEST_URGENCY='BAU' and to_date(UPDATE_ASSIGNED_USER_DATE)=to_date(sysdate) ");
			queue.append("group by ASSIGNED_USER)z on z.a3=cr.ASSIGNED_USER ");
			queue.append("left join (select count(request_urgency) b1,ASSIGNED_USER b3 ");
			queue.append("from CMP_REQUEST c where REQUEST_URGENCY !='BAU' ");
			queue.append("and  to_date(UPDATE_ASSIGNED_USER_DATE)=to_date(sysdate) ");
			queue.append("group by ASSIGNED_USER)y on y.b3=cr.ASSIGNED_USER ");
			queue.append("left join CMP_DO_NOT_ASSIGN cdna on cdna.AGENT_ID=cu.SSO_ID ");
		//	queue.append("and   cr.STATUS not in ('Cancelled') ");
			queue.append("group by cr.ASSIGNED_USER,cu.FIRST_NAME,cu.LAST_NAME,cu.SSO_ID,z.a1,y.b1,cdna.IS_LOCKED, cdna.comments,eq.queue_name ");
			queue.append("order by cu.last_name asc ");
			log.info("queryString>>>"+queue);
			SQLQuery query = session.createSQLQuery(queue.toString());
			query.addScalar("soeid", StringType.INSTANCE);
			query.addScalar("sector", StringType.INSTANCE);
			query.addScalar("role", StringType.INSTANCE);
			query.addScalar("firstname", StringType.INSTANCE);
			query.addScalar("lastname", StringType.INSTANCE);
			query.addScalar("total", LongType.INSTANCE);
			query.addScalar("inQueue", LongType.INSTANCE);
			query.addScalar("assist", LongType.INSTANCE);
			query.addScalar("bau", LongType.INSTANCE);
			query.addScalar("buscrit", LongType.INSTANCE);
			query.addScalar("weekCount", LongType.INSTANCE);
			query.addScalar("lockedBy", StringType.INSTANCE);
			query.addScalar("comments", StringType.INSTANCE);
			
			
			List<Object[]> list= query.list();
			
			if(list.size() >0 ){
				for (Object[] list1 : list){
					teamQueue = new EcmLeadQueue();
					teamQueue.setAgentID(list1[0].toString());
					teamQueue.setSector(list1[1].toString());
					teamQueue.setRole(list1[2].toString());
					teamQueue.setAgentName(list1[3].toString() +" "+ list1[4].toString());
					teamQueue.setTotalInQueue((Long) list1[5]);
					teamQueue.setInQueue((Long) list1[6]);
					teamQueue.setIsAssitance((Long) list1[7]);
					teamQueue.setIsBAU((Long) list1[8]);
					teamQueue.setIsBusCrit((Long) list1[9]);
					teamQueue.setAssignedThisWeek((Long) list1[10]);
					teamQueue.setIsLocked(list1[11].toString());
					teamQueue.setComments(list1[12].toString());
					if("Y".equalsIgnoreCase(list1[11].toString())){
						log.debug("dfs" +teamQueue.getIsLocked());
						teamQueue.setSelected(true);
					}
					teamQueueList.add(teamQueue);
					
					log.debug("list val : " +list1[0] +list1[2]);
				}
			}
			
			
		} catch (Exception e) {
			log.error(e,e);
		}
		log.info("Out of getAgentListForSector method");
		return teamQueueList;
		
	}

	@Override
	public void addAgentToDoNotAssign(EcmLeadViewProcess ecm) {
		log.info("Into addAgentToDoNotAssign method");
		try{
			Session session = getSession();
			List<EcmLeadQueue> ecmList = (List<EcmLeadQueue>)ecm.getTeamQueue();
			CMPDoNotAssign dna ;
			if (ecmList != null && ecmList.size() > 0) {
				log.debug("user list:"+ecmList.size());
				for (EcmLeadQueue ecm1 : ecmList) {
					
						dna= (CMPDoNotAssign) session.createQuery("from CMPDoNotAssign dlist where upper(dlist.agentId)=upper('" +ecm1.getAgentID()+ "') ").uniqueResult();
						if(dna != null ){
							
							log.debug("val" +dna.getIsLocked());
							if (!ecm1.isSelected() && "Y".equalsIgnoreCase(dna.getIsLocked())) {
								log.debug("inside if");
								dna.setIsLocked("N");
								dna.setLockDate(new Date());
								dna.setLeadId(ecm.getLeadId());
								dna.setComments(ecm.getComments());
							}
							if (ecm1.isSelected() && "N".equalsIgnoreCase(dna.getIsLocked())) {
								log.debug("inside if of no");
								dna.setIsLocked("Y");
								dna.setLockDate(new Date());
								dna.setLeadId(ecm.getLeadId());
								dna.setComments(ecm.getComments());
							}
						}else{
							log.debug("into it");
							if (ecm1.isSelected()) {
							log.debug("inside else");
							dna = new CMPDoNotAssign();
							dna.setAgentId(ecm1.getAgentID());
							dna.setLeadId(ecm.getLeadId());
							dna.setComments(ecm.getComments());
							dna.setLockDate(new Date()); 
							dna.setIsLocked("Y");
						}
						if(dna != null){
							getHibernateTemplate().saveOrUpdate(dna);
						}
					}
				}
			} 
		}
		catch(Exception e){
			log.error(e,e);
		}
		log.info("End addAgentToDoNotAssign method");
	}
	
	@Transactional(readOnly = true)
	public List<CmpConnectionDetail> getProcessList(String ccrId) {
		log.info("CmpConnectionDetailsImpl.getProcessList method started: ");	
		Session session = getSession();
		List<CmpConnectionDetail> processList = new ArrayList<CmpConnectionDetail>();		
		try{
			String queryString ="SELECT  DISTINCT "+
					"PROC.ID AS ID,PROC.VERSION_NUMBER AS VERSION_NUMBER, "+ 
					"PROC.ID ||'.'|| PROC.VERSION_NUMBER AS DISPLAY_ID , "+ 
					"PROCESS_NAME AS NAME,T.ACTIVITY_TYPE AS STATUS, "+ 
					"CASE WHEN REQTY.REQUEST_TYPE = 'Create' THEN 'Planning' "+  
					"WHEN REQTY.REQUEST_TYPE = 'Maintain' THEN 'Maintenance' "+  
					"WHEN UPPER(REQTY.REQUEST_TYPE) = 'ACV' THEN 'ACV' "+  
					"WHEN REQTY.REQUEST_TYPE = 'ManageContacts' THEN 'Maintain Contacts' "+				 
					"WHEN REQTY.REQUEST_TYPE = 'Terminate' THEN 'Termination' END AS PHASE, "+  
					"T.ACTIVITY_MODE AS TYPE, "+  
					"CASE WHEN PROC.PROCESS_TYPE_ID = 1 THEN 'Connection' "+  
					"WHEN PROC.PROCESS_TYPE_ID = 2 THEN 'IPRegistration' END AS TI_PROCESS, "+  
					"CASE WHEN t.activity_type= 'PROVIDEINFO' THEN role_info.name "+ 
					"ELSE  role_app.name END as role,g_l.value1 as priority,lockedby_user.sso_id participant, "+  
					"req.id req_id, t.bpm_instance_id bpmInstanceId,task_type.albpm_activity_id albpmActivityId, task_type.task  task, tpt.BPM_PROCESS_NAME bpmProcessName,task_type.task_code taskcode "+ 
					"FROM "+ 
					"C3PAR.TI_PROCESS PROC "+
					"JOIN  C3PAR.TI_PROCESS_TYPE TPT ON PROC.PROCESS_TYPE_ID=TPT.ID "+ 
					"JOIN C3PAR.TI_REQUEST REQ ON PROC.ID = REQ.PROCESS_ID AND PROC.VERSION_NUMBER=REQ.VERSION_NUMBER "+  
					"JOIN C3PAR.TI_REQUEST_TYPE REQTY ON REQ.TI_REQUEST_TYPE_ID = REQTY.ID  "+
					"JOIN C3PAR.TI_ACTIVITY_TRAIL T ON REQ.ID=T.TI_REQUEST_ID  "+         
					"LEFT JOIN C3PAR.ROLE  ROLE_APP ON ROLE_APP.ID = T.USER_ROLE_ID  "+
					"LEFT JOIN C3PAR.ROLE  ROLE_INFO ON ROLE_INFO.ID = T.INFOUSER_ROLE_ID "+
					"JOIN C3PAR.TI_TASK_TYPE TASK_TYPE ON TASK_TYPE.ID = T.ACTIVITY_ID "+
					"JOIN C3PAR.GENERIC_LOOKUP G_L ON G_L.ID = REQ.PRIORITY_ID "+
					"LEFT JOIN C3PAR.C3PAR_USERS LOCKEDBY_USER ON LOCKEDBY_USER.ID=T.LOCKEDBY "+
					"JOIN C3PAR.RELATIONSHIP REL ON REL.ID=PROC.RELATIONSHIP_ID "+
					"JOIN REL_CITI_HIERARCHY_XREF RELXREF ON REL.ID=RELXREF.RELATIONSHIP_ID "+
					"JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=RELXREF.CITI_HIERARCHY_MASTER_ID "+  
					"LEFT JOIN C3PAR.CO_LOOKUP_DATA L ON L.ID = REL.LOOKUP_ID "+
					"LEFT JOIN C3PAR.THIRD_PARTY THP ON REL.THIRD_PARTY_ID = THP.ID AND REL.RELATIONSHIP_TYPE ='THIRD_PARTY' "+
					"LEFT JOIN BUSINESS_UNIT BU ON CITIMASTER.BU_ID=BU.ID "+
					"LEFT JOIN (SELECT R.ID RELID,S1.ID SECID FROM C3PAR.RELATIONSHIP R  "+
					"JOIN REL_CITI_HIERARCHY_XREF RELXREF ON R.ID=RELXREF.RELATIONSHIP_ID "+
					"JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=RELXREF.CITI_HIERARCHY_MASTER_ID "+
					"JOIN SECTOR S1 ON CITIMASTER.SECTOR_ID=S1.ID)SECT ON SECT.RELID=REL.ID "+
					"LEFT JOIN (SELECT R.ID RELID, R1.ID REGID FROM "+
					"C3PAR.RELATIONSHIP R "+
					"JOIN REL_CITI_HIERARCHY_XREF RELXREF ON R.ID=RELXREF.RELATIONSHIP_ID "+
					"JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=RELXREF.CITI_HIERARCHY_MASTER_ID "+
					"JOIN REGION R1 ON CITIMASTER.REGION_ID=R1.ID)REG ON REG.RELID=REL.ID "+
					"LEFT JOIN C3PAR_USERS REQ_SSO ON REQ_SSO.ID=REQ.USER_ID "+
					"WHERE PROC.IS_DELETED = 'N' AND "+
					"T.ACTIVITY_STATUS IN('SCHEDULED','END') AND PROC.ID ='"+ccrId+"' ";
			
			SQLQuery sqlquery = session.createSQLQuery(queryString.toString());
			sqlquery.addScalar("ID", LongType.INSTANCE);
			sqlquery.addScalar("VERSION_NUMBER", LongType.INSTANCE);
			sqlquery.addScalar("DISPLAY_ID", StringType.INSTANCE);
			sqlquery.addScalar("NAME", StringType.INSTANCE);
			sqlquery.addScalar("STATUS", StringType.INSTANCE);
			sqlquery.addScalar("PHASE", StringType.INSTANCE);
			sqlquery.addScalar("TYPE", StringType.INSTANCE);
			sqlquery.addScalar("TI_PROCESS", StringType.INSTANCE);
			sqlquery.addScalar("role", StringType.INSTANCE);
			sqlquery.addScalar("priority", StringType.INSTANCE);
			sqlquery.addScalar("participant", StringType.INSTANCE);
			sqlquery.addScalar("req_id", LongType.INSTANCE);
			sqlquery.addScalar("bpmInstanceId", StringType.INSTANCE);
			sqlquery.addScalar("albpmActivityId", StringType.INSTANCE);
			sqlquery.addScalar("task", StringType.INSTANCE);
			sqlquery.addScalar("bpmProcessName", StringType.INSTANCE);
			sqlquery.addScalar("taskcode", StringType.INSTANCE);			

			List<Object[]> resultList = sqlquery.list();			
			processList = new ArrayList<CmpConnectionDetail>();
			CmpConnectionDetail cmpConnectionDetail = null;
			if(resultList!= null){
				for(Object[] result : resultList) {	

						
						cmpConnectionDetail = new CmpConnectionDetail();
						cmpConnectionDetail.setId((Long)result[0]);						
						cmpConnectionDetail.setVersion_number(Long.valueOf((Long)result[1]));						
						cmpConnectionDetail.setDisplay_id((String)result[2]);
						cmpConnectionDetail.setName((String)result[3]);
						cmpConnectionDetail.setStatus((String)result[4]);
						cmpConnectionDetail.setPhase((String)result[5]);
						cmpConnectionDetail.setType((String)result[6]);
						cmpConnectionDetail.setTiProcess((String)result[7]);
						cmpConnectionDetail.setRole((String)result[8]);
						cmpConnectionDetail.setPriority((String)result[9]);
						cmpConnectionDetail.setParticipant((String)result[10]);
						cmpConnectionDetail.setTirequestid(Long.valueOf((Long)result[11]));						
						cmpConnectionDetail.setBmpInstanceId((String)result[12]);
						cmpConnectionDetail.setBpmActivityId((String)result[13]);
						cmpConnectionDetail.setTaskName((String)result[14]);
						cmpConnectionDetail.setBpmProcessName((String)result[15]);
						cmpConnectionDetail.setTaskCode((String)result[16]);
						processList.add(cmpConnectionDetail);
					
					}
			}
			
		}catch(Exception e){
			log.info("Exception:: "+e);
		}
		log.info("Size of process List"+processList.size());
		return processList;
	}

	@Override
	public String getdateForHeader() {
		log.info("Into getdateForHeader method");
		Session session = getSession();
		String dateForHeader = "";
		 try{
				Object[] obj =  (Object[]) session.createSQLQuery("select to_char(sysdate, 'DAY') day ,to_char(sysdate,'MON dd,YYYY')date1 from dual").addScalar("day", StringType.INSTANCE).addScalar("date1", StringType.INSTANCE).uniqueResult();
				if(obj != null){
					log.debug("date val" +obj[0]+obj[1]);
				dateForHeader = obj[0] + ", " +obj[1];
				}
				
		 }
		 catch(Exception e){
			 
		 }
		 log.info("Out of getdateForHeader method");
		return dateForHeader;
	}	
	
	@Transactional(readOnly = true)
	public CMPRequest getCMPRequestDetails(String cmpReqId){
		
		log.debug("Entering into getCMPRequestDetails()..");	
		
		log.debug("The passed cmpReqId:"+cmpReqId);	
		
		Session session = getSession();	
		
		Query query = session.createQuery("from CMPRequest where id = ?").setLong(0, Long.parseLong(cmpReqId));
		
		List<CMPRequest> list = (List<CMPRequest>)query.list();	
		
		log.debug("The list size: "+list.size());
		
		log.debug("Exit from getCMPRequestDetails()..");		
		
		return  (CMPRequest) list.get(0);
	}

	@Override
	@Transactional(readOnly = true)
	public List<ECMUserSearchProcess> searchEcmUsers(String searchEcmuserCriter) {
		log.info("EcmLeadViewImpl::selectEcmUsers starts>>>"); 
		List<ECMUserSearchProcess> ecmProcessList = null;
		List<String> ecmUserArrList = new ArrayList<String>(); 

		List<ECMUserSearchProcess> finalList = new ArrayList<ECMUserSearchProcess>();
		try {

			Session session = getSession();

			StringBuilder queryString = new StringBuilder();
			queryString
					.append(" select  usrs.last_name,usrs.first_name,usrs.sso_id,cdna.is_locked,cdna.comments from C3PAR_USERS usrs, C3PAR_USER_ROLE_XREF userRole, cmp_do_not_assign cdna ");
			queryString
					.append(" where usrs.ID = userRole.USER_ID and userRole.ROLE_ID = (select id from security_role where name = 'ECM Agent') ");
			queryString
					.append(" and usrs.is_Active = 'Y' and cdna.agent_id(+)=usrs.sso_id ");
			queryString
					.append("and usrs.sso_id not in(select distinct(usrs.sso_id) from C3PAR_USERS usrs, C3PAR_USER_ROLE_XREF userRole ");
			queryString
					.append("where usrs.ID = userRole.USER_ID and userRole.ROLE_ID in (select id from security_role where name in ('Support Agent','C3PARSYSTEMADMIN')) and usrs.is_Active = 'Y')");    
			if (searchEcmuserCriter != null
					&& searchEcmuserCriter.trim().length() > 0) {
				queryString.append(" and (UPPER(usrs.last_name) like UPPER('%"
						+ searchEcmuserCriter
						+ "%') or UPPER(usrs.first_name)  like UPPER('%"
						+ searchEcmuserCriter + "%') or UPPER(usrs.sso_id) like UPPER('%"
						+ searchEcmuserCriter + "%')) ");
			}
			queryString.append(" order by usrs.last_name ");

			log.info("ecmUserArrList queryString value-->"
					+ queryString.toString());

			SQLQuery query = session.createSQLQuery(queryString.toString());
			ecmProcessList = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();
			// List<C3parUser> ecmUsersList = query.list();
			log.info("ecmUserArrList concated value-->" + ecmUserArrList);

			EcmLeadViewProcess ecmLeadViewProcess = null;

			for (Object obj : ecmProcessList) {
				Map map = (Map) obj;

				finalList.add(new ECMUserSearchProcess(
						(String) map.get("SSO_ID"), (String) map
								.get("LAST_NAME"), (String) map
								.get("FIRST_NAME"),(String) map
								.get("IS_LOCKED"),(String) map
								.get("COMMENTS")));
			}

		} catch (Exception e) {
			log.error("EcmLeadViewImpl::selectEcmUsers>>> " + e);
		}

		return ecmProcessList;
	}
	
	@Transactional(readOnly = true)
	public boolean checkValidUser(String ssoid) {
		log.debug("checkValidUser method starts");
		Session session = getSession();
		log.debug("checkValidUser :: ssoid:: " + ssoid);
		boolean validUser = false;
							
			Query query = session.createQuery("from C3parUser where upper(ssoId) = ?").setString(0, ssoid.toUpperCase());
			
			List<C3parUser> list = (List<C3parUser>)query.list();
			if (list != null && list.size() > 0) {
				validUser=true;
			}
			log.debug("checkValidUser method ends"+validUser);
			return validUser;		
	}
	
	//to get All CMP Request Sectors
		@Override
		@Transactional(readOnly = true)
		public List<String> getCMPSectorList(){
			Session session = getSession();
        	StringBuffer queryString = new StringBuffer();
		 	queryString.append("select distinct ECM_SECTOR from CMP_REQUEST where ECM_SECTOR is not null");
		 	SQLQuery query = session.createSQLQuery(queryString.toString());  
	    	List<String> list = query.list();	
			if(list != null)
				log.debug("CMP Request Sectors :: CMP Request Sectors :: size ::"+list.size()); 
		 	return list;
		}
		
		@Override
		@Transactional(readOnly = true)
		public List<String> getSupportTeamUsersList(String soeIds){
			Session session = getSession();
        	StringBuffer queryString = new StringBuffer();
		 	queryString.append("select distinct cu.sso_id soeid from c3par_users cu, security_role sr, c3par_user_role_xref curx where cu.sso_id in ("+soeIds+") and cu.id=curx.user_id and sr.id=curx.role_id and sr.name in ('Support Agent','C3PARSYSTEMADMIN')");
		 	SQLQuery query = session.createSQLQuery(queryString.toString());  
	    	List<String> list = query.list();	
			if(list != null)
				log.debug("getSupportTeamUsersList :: List size ::"+list.size()); 
			else{
				// As Query List is null, so returning the empty list to this method  
				list=new ArrayList<String>();
			}
		 	return list;
		}
		 @Override
	        public List<Sector> getProjectSectorList() {
	            List<Sector> projectSectorList = new ArrayList<Sector>();
	            Criteria crit = getSession().createCriteria(Sector.class).add(Restrictions.eq("isactive", "Y"));
	            projectSectorList=crit.list();
	            
	           
	            return projectSectorList;
	        }
		 
		 @SuppressWarnings("rawtypes")
		 @Override
		 @Transactional(readOnly = true)
	     public List<DsmtSgmntSector> getDsmtSgmntSectorList() {
		     log.debug("Fetching DsmtSgmntSectors Starts..");
	         List<DsmtSgmntSector> projectSectorList = new ArrayList<DsmtSgmntSector>();
	         String fetchSGmntQuery= "SELECT MAN_SEGID, NAME, ID, HIER_LEVEL from DSMT_SGMNT_SECTOR DSGMT, SECTOR SEC WHERE SEC.ID=DSGMT.SECTOR_ID"; 
	         log.info("Query for fetching DsmtSgmntSectors: "+fetchSGmntQuery);  
	         try {
	             Session session = getSession();
	             SQLQuery query = session.createSQLQuery(fetchSGmntQuery);  
	             query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
	             List data = query.list();
	             for(Object object : data){
	            	Map row = (Map)object;
	            	DsmtSgmntSector dsmtSgmntSector = new DsmtSgmntSector();
	            	dsmtSgmntSector.setManSegId(row.get("MAN_SEGID").toString());
	            	dsmtSgmntSector.setSectorName(row.get("NAME").toString());
	            	projectSectorList.add(dsmtSgmntSector);
	            }
            } catch(Exception exception){
            	log.error("Exception occured while fetching DsmtSgmntSectors: "+exception.toString());
            	log.error(exception.toString(), exception);
            }
            log.debug("Fetching DsmtSgmntSectors Ends..");      
            return projectSectorList;
        }
		 
		 @Override
		    @Transactional(readOnly = true)
		    public boolean updateAssignedEcmUser(String cmpReqId, String AssignTo ,Long sloDays,String userId,String leadComments,String projectSector) {
		        log.info("Entering into updateAssignedEcmUser()..");        
		        int result = 0;
		        Integer contactId = 0;
		        try {
		            Session session = getSession();
		                String fetchUserIdQuery = "(select id from C3PAR_USERS where SSO_ID='"+AssignTo+"'),";          
		                String queryString = "update cmp_request set assigned_user="+fetchUserIdQuery+"UPDATE_ASSIGNED_USER_DATE = sysdate,status='In Progress',slo_days = "+sloDays+", PROJECT_SECTOR='"+projectSector+"' where ID="+cmpReqId;
		                log.info("queryString>>>"+queryString);
		                SQLQuery query = session.createSQLQuery(queryString);           
		                result = query.executeUpdate();
		                
		                String ldComments = "insert into cmp_request_notes values (SEQ_CMP_REQUEST_NOTES.nextval,"+cmpReqId+",'"+leadComments+"',sysdate,'ECM','','' )";
		                log.info("leadComments queryString>>>"+ldComments);
		                SQLQuery leadCommentQuery = session.createSQLQuery(ldComments);             
		                result = leadCommentQuery.executeUpdate();
		            
		                //cmpRequestPersistable.cmpActivityTrail(Long.valueOf(cmpReqId), userId, ECMConstants.ASSIGN_AGENT_TASK_CODE, ECMConstants.STATUS_STARTED); 
		            
		                CitiContact agent = cmpRequestPersistable.getUserIdForSsoId(AssignTo);
		            
		                String checkUserContact = "(select id from CMP_REQUEST_CON_XREF where citi_contact_id="+agent.getId()+" and cmp_id="+cmpReqId+" and role_id =(select id from cmp_role where name='design_engineer'))";
		                log.info("queryString>>>"+checkUserContact);
		                SQLQuery query1 = session.createSQLQuery(checkUserContact);
		                
		                contactId =(Integer) query1.addScalar("id", IntegerType.INSTANCE).uniqueResult();
		                
		                if(contactId==null || contactId<= 0){
		                                
		                        String contact = "insert into CMP_REQUEST_CON_XREF values (seq_cmp_request_con_xref.nextval,"+cmpReqId+",(select id from cmp_role where name='design_engineer'),"+agent.getId()+" )";
		                        log.info("queryString>>>"+contact);
		                        SQLQuery query3 = session.createSQLQuery(contact);              
		                        result = query3.executeUpdate();
		                    }
		            } catch (Exception e) {                 
		                log.error("EcmLeadViewImpl::updateAssignedEcmUser>>> " + e);
		            }       
		        log.info("Exit from updateAssignedEcmUser()..");                
		        return result==1? true:false;       
		    }
	
}