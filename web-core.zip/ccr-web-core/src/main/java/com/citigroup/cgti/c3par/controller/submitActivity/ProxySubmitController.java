package com.citigroup.cgti.c3par.controller.submitActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.proxy.domain.ProxyInstance;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.webtier.helper.FAFReviewThread;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

/*
 * @nc43495
 */
@Controller
public class ProxySubmitController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(ProxySubmitController.class);
	Util util=new Util();
	
	@Autowired
	WsPapiFacade papiFacade;
	
	@Autowired
	WorkflowUtil workflowUtil;

	@RequestMapping(value = "/loadProxySubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(ModelMap model,@ModelAttribute("proxySubmitProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session){
		log.info("Proxy Submit Controller load method starts here...");
		
		String tiReq = (String)session.getAttribute("tireqid");
		String actId = (String)session.getAttribute("activityid");
		
		Long tiReqId = Long.valueOf(0);
		Long activityId = Long.valueOf(0);
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		if(actId!=null){
		    try{activityId=Long.valueOf(actId);}catch(Exception e){activityId = Long.valueOf(0);}
		}
		log.debug("tiReq:"+tiReq+"ActivityId"+activityId);
		String taskId = (String) session.getAttribute("taskId");
		if(StringUtil.isNullorEmpty(actId)){
			activityId = workflowUtil.getAuditTrailId(activityId, taskId);
		}
		submitActivityProcess = new SubmitActivityProcess();
		
		//supplementary review roles display
		HashMap<String,String> roles = submitActivityProcess.findInstanceId(tiReqId, activityId);
		submitActivityProcess.setRoles(roles);
		List<LookUpVO> supReviewRole = submitActivityProcess.getSupReviewRoles((String)roles.get("ROLE"));
		log.debug("Proxy Submit Controller:"+supReviewRole.size());
		submitActivityProcess.setSupReviewRoles(supReviewRole);
		
		//set activity role
		submitActivityProcess.setActivityRole((String)roles.get("ROLE"));
		session.setAttribute("activityRole",submitActivityProcess.getActivityRole());
		log.debug("activity role:"+submitActivityProcess.getActivityRole());
		
		/*//setInstanceID
		String instanceId = (String)roles.get("INST_ID");
		session.setAttribute("instanceID", instanceId);
		log.debug("instanceId"+instanceId);*/
		
		// setTaskID
		log.debug("*********taskId************" + taskId);
		
		TIProcess tiProcess = null;
		try {
			tiProcess = submitActivityProcess.getProcessData(tiReqId.longValue());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<ProxyInstance> instances = submitActivityProcess.getProxyInstancesToModify(tiProcess.getId());
		submitActivityProcess.setProxyInstanceList(instances);
		
		List<ProxyInstance> PACs = submitActivityProcess.getPACToModify(tiProcess.getId());
		for(ProxyInstance PAC : PACs){
		    ProxyInstance instance = submitActivityProcess.getInstanceforPAC(PAC.getId());
		    if(instance != null){
			instance.setIsNew(submitActivityProcess.isPACLocked(instance.getId()) || instances.contains(instance)?"N":"Y");
		    }
			
		    else
			instance = new ProxyInstance();
		    PAC.setParentProxy(instance);		  
		}
		submitActivityProcess.setPACList(PACs);
		
		
		
		//Approval comments display
		String role = (String)roles.get("ROLE");
		submitActivityProcess.setTiReqCmtsList(submitActivityProcess.getComments(tiReqId, role, "A"));
		
		//Discussion comments display
		submitActivityProcess.setDiscussCmtsList(submitActivityProcess.getComments(tiReqId, role, "D"));
		
		model.addAttribute("proxySubmitProcess", submitActivityProcess);
		
		return "c3par.proxySubmit";
	}
	
	@RequestMapping(value = "/saveProxySubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String save(ModelMap model,@ModelAttribute("proxySubmitProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request) throws Exception{
	log.info("Proxy Submit Controller:Save method starts here...");
	formSubmit(submitActivityProcess,result,session,request);
	return "forward:/logon.act?forwardTo=bpm";
		
	}
	
	@RequestMapping(value = "/submitProxySubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String submit(ModelMap model,@ModelAttribute("proxySubmitProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request){
	log.info("Proxy Submit Controller:Save method starts here...");
	
	try {
		formSubmit(submitActivityProcess,result,session,request);
		log.debug("Proxy Submit PAPI Enter ");
		
		//WsPapiFacade papiFacade = new WsPapiFacade ();
		
		String taskId = (String)session.getAttribute("taskId");
		String userId  = request.getHeader("SM_USER");
		String nextSelectedAction = submitActivityProcess.getCurrentAction();
		String tiReq = (String)session.getAttribute("tireqid");
		String nextRole = null;
		log.debug("taskId: " + taskId +"action"+nextSelectedAction);
		log.debug("userId: " + userId);
		
		log.debug("Before calling PAPI For BJ Submit");
		
		if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getProvideInfoRole());
		}else {
			nextRole = util.moveToActivity(submitActivityProcess.getCurrentRole());
		}
		
		log.debug("Selected role:"+nextRole);
		
		if ("UNLOCKED".equals( nextSelectedAction ) || "COMPLETED".equals( nextSelectedAction ) ) {
			papiFacade.completeActivity(userId, taskId, nextSelectedAction); 
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("REJECTED".equalsIgnoreCase(nextSelectedAction)){
			log.debug("inside Rejected scenario..."+nextSelectedAction);
			papiFacade.completeActivity(userId, taskId,"REJECTED");
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.completeActivity(userId, taskId, WsPapiFacade.ActivityStatus.PROVIDEINFO,WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("RESCHEDULED".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.rescheduleActivity(userId, Long.valueOf(tiReq),"prximpl_schedule_user_notification",submitActivityProcess.getPrxImpScheduleDate());
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
	} catch (OperationException_Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return "forward:/defaultInboxView.act";
		
	}
	
	
	//data collection
    private void formSubmit(SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session,
			HttpServletRequest request)throws Exception{
    	log.debug("Proxy Submit Controller form Submit begins...");
    	
    	String messgXML = (String)request.getSession().getAttribute("MESSAGEXML");
		log.info("messgXML::"+messgXML);
		
		String tiReq = (String)session.getAttribute("tireqid");
		
		submitActivityProcess.setActivityRole((String)session.getAttribute("activityRole"));
		log.debug("activity role inside form submit:"+submitActivityProcess.getActivityRole());
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );
		
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		
		//Getting request type
		TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
		
		if(submitActivityProcess.getCurrentAction()==null){
			submitActivityProcess.setCurrentAction(ActivityData.STATUS_COMPLETED);
		}
		
		if(submitActivityProcess.getCurrentRole()==null){
			submitActivityProcess.setCurrentRole(submitActivityProcess.getActivityRole());
		}

		log.info("Request Parameters::"+request.getParameterNames());
		log.info("Request current role="+request.getParameter("currentRole"));
		log.info("current action =" + submitActivityProcess.getCurrentAction());
		log.info("current role=" + submitActivityProcess.getCurrentRole());
		log.info("comments = " + submitActivityProcess.getComments());
		

		String ssoID = request.getHeader("SM_USER");
		
		TiRequestComments tiReqComments = new TiRequestComments();
		tiReqComments.setTiRequest(tiRequest);
		tiReqComments.setComments(submitActivityProcess.getComments());
		tiReqComments.setRoleName(submitActivityProcess.getActivityRole());
		tiReqComments.setApproverSoeID(ssoID);
		
		//update Proxy implementation data in ti_request table
		
		StringBuffer schTsmp = new StringBuffer();
		StringBuffer compTsmp = new StringBuffer();
		
		
		//reschedule date
		if(submitActivityProcess.getPrxImpScheduleDate()!=null && !submitActivityProcess.getPrxImpScheduleDate().isEmpty()){
			schTsmp.append(submitActivityProcess.getPrxImpScheduleDate());
		}else{
			schTsmp.append("");
		}
		
		
		//completed date
		if(submitActivityProcess.getPrxImpCompletedDate()!=null && !submitActivityProcess.getPrxImpCompletedDate().isEmpty()
			&& submitActivityProcess.getPrxImpCompletedTime()!=null && !submitActivityProcess.getPrxImpCompletedTime().isEmpty()){
			compTsmp.append(submitActivityProcess.getPrxImpCompletedDate());
			compTsmp.append(" ");
			compTsmp.append(submitActivityProcess.getPrxImpCompletedTime());
		}else{
			compTsmp.append("");
		}
		
		
		log.debug("update information:"+schTsmp.toString()+"completed date"+compTsmp.toString()+"infoman id");
	
		submitActivityProcess.proxyImpUpdate(tiReqId,schTsmp.toString(), compTsmp.toString());
		
		//update PAC
		if (submitActivityProcess.getPACList()!=null  && submitActivityProcess.getPACList().size() >0) {
		List<ProxyInstance> allInstancesAndPACList = new ArrayList<ProxyInstance>();
		List<ProxyInstance> instancesList = new ArrayList<ProxyInstance>();
		List<ProxyInstance> PACList = new ArrayList<ProxyInstance>();
		
		PACList = submitActivityProcess.getPACList();
		for(ProxyInstance instanceAndPAC : PACList){
		    instancesList.add(instanceAndPAC.getParentProxy());		   
		}
		allInstancesAndPACList.addAll(instancesList);
		allInstancesAndPACList.addAll(PACList);
		/*String message = submitActivityProcess.validateProxyInstance(
			allInstancesAndPACList);
		
		if (message != null && !message.equalsIgnoreCase("")) {
		    session.setAttribute("bpmSubmitMessage", message);
		    throw new BusinessException(message);
		}else {
		    if(session.getAttribute("bpmSubmitMessage")!=null){
			session.removeAttribute("bpmSubmitMessage");
		    }
		}*/
		}
	
	
	//update ProxyinstanceList
		 if (submitActivityProcess.getProxyInstanceList()!=null  && submitActivityProcess.getProxyInstanceList().size() >0) {


				for(int i=0;i<submitActivityProcess.getProxyInstanceList().size();i++){
				    ProxyInstance proxyInstance=(ProxyInstance)submitActivityProcess.getProxyInstanceList().get(i);
				    String recordType=proxyInstance.getRecordType();
				    if(recordType!=null && "STANDARD".equalsIgnoreCase(recordType)){
					proxyInstance.setRecordType("BASIC");
				    }
				}
				
				/*String messag = submitActivityProcess.validateProxyInstance(
						submitActivityProcess.getProxyInstanceList());
				if (messag != null && !messag.equalsIgnoreCase("")) {
				    session.setAttribute("bpmSubmitMessage", messag);
				    throw new BusinessException(messag);
				}else {
				    if(session.getAttribute("bpmSubmitMessage")!=null){
					session.removeAttribute("bpmSubmitMessage");
				    }
				}*/

	    }



		
		if(ActivityData.STATUS_COMPLETED.equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
	    TIProcess tiProcess = submitActivityProcess.getProcessData(tiReqId.longValue());
	    
		if(ActivityData.IS_NEW.equals(tiProcess.getProcessActivityMode()) || ActivityData.IS_REWORK.equals(tiProcess.getProcessActivityMode())){
		    insertFAFQueueRequest(request,tiProcess.getId(),"insertintopafstate");
		}
		}
		
		//updating tiRequest comments
		if(!"PROVIDEINFO".equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
			submitActivityProcess.addComments(tiReqComments, "A", "save");
		}else {
			submitActivityProcess.addComments(tiReqComments, "D", "save");
		}
			
    }
    
    public void insertFAFQueueRequest(HttpServletRequest request, Long connectionRequestId, String requestType)
    	    throws Exception {
    		log.debug("TIRequestCommentsAction.insertFAFQueueRequest() START");
    		Util util=new Util();
    		if("all".equals(requestType)){
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculate","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculatepaf","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculateaaf","N");
    		} else if("terminateall".equals(requestType)){
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminatefaf","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminateaaf","N");
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminatepaf","N");
    		} else {
    		    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),requestType,"N");
    		}
    		FAFReviewThread.getInstance().startThread(request);
    		FAFReviewThread.getInstance().notifyThread();
    		log.debug("TIRequestCommentsAction.insertFAFQueueRequest() END");
    	    }
}
