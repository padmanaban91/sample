package com.citigroup.cgti.c3par.webtier.helper.entity;

import com.mentisys.dao.DatabaseException;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.citigroup.cgti.c3par.model.*;


/**
 * The Class LocationManager.
 */
public class LocationManager
{
    //=======================================================================================
    /**
     * Insert.
     *
     * @param entity the entity
     * @param dbSession the db session
     * @return the long
     * @throws DatabaseException the database exception
     */
    static public Long insert(LocationEntity entity, C3parSession dbSession) throws DatabaseException
    {
	Long id = null;
	if(entity != null)
	{
	    LocationDAO dao = new LocationDAO(dbSession);
	    dao.insert(entity, dbSession.getArchiver());
	    id = entity.getId();
	}
	return id;
    }

    //=======================================================================================
    /**
     * Update.
     *
     * @param entity the entity
     * @param dbSession the db session
     * @return the long
     * @throws DatabaseException the database exception
     */
    static public Long update(LocationEntity entity, C3parSession dbSession) throws DatabaseException
    {
	Long id = null;
	if(entity != null)
	{
	    LocationDAO dao = new LocationDAO(dbSession);
	    dao.update(entity, dbSession.getArchiver());
	    id = entity.getId();
	}
	return id;
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param dbSession the db session
     * @throws DatabaseException the database exception
     */
    static public void delete(String id, C3parSession dbSession) throws DatabaseException
    {
	if(id != null && id.length() > 0)
	{
	    LocationManager.delete(Long.valueOf(id), dbSession);
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param dbSession the db session
     * @throws DatabaseException the database exception
     */
    static public void delete(Long id, C3parSession dbSession) throws DatabaseException
    {
	if(id != null)
	{
	    LocationEntity entity = LocationManager.get(id, dbSession);
	    LocationManager.delete(entity, dbSession);
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param entity the entity
     * @param dbSession the db session
     * @throws DatabaseException the database exception
     */
    static public void delete(LocationEntity entity, C3parSession dbSession) throws DatabaseException
    {
	if(entity != null)
	{
	    LocationDAO dao = new LocationDAO(dbSession);
	    dao.delete(entity, dbSession.getArchiver());
	}
    }

    //=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @param dbSession the db session
     * @return the location entity
     * @throws DatabaseException the database exception
     */
    static public LocationEntity get(String id, C3parSession dbSession) throws DatabaseException
    {
	LocationEntity	entity = null;
	if(id != null && id.length() > 0)
	{
	    entity = LocationManager.get(Long.valueOf(id), dbSession);
	}
	return entity;
    }

    //=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @param dbSession the db session
     * @return the location entity
     * @throws DatabaseException the database exception
     */
    static public LocationEntity get(Long id, C3parSession dbSession) throws DatabaseException
    {
	LocationEntity	entity = null;
	if(id != null)
	{
	    LocationDAO dao = new LocationDAO(dbSession);
	    entity = dao.get(id);
	}
	return entity;	
    }
}


