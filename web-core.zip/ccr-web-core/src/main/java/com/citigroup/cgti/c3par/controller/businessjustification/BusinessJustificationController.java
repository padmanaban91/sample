package com.citigroup.cgti.c3par.controller.businessjustification;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.domain.VirtualConnReason;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiHierarchyXref;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetail;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetailAnswer;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCLookup;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class BusinessJustificationController extends BusJusBaseController{

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@RequestMapping(value = "/loadBusinessCase.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String loadBusinessCase(HttpServletRequest request, ModelMap model,@ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess,BindingResult result) {
		log.info("BusinessJustificationController :: loadBusinessCase starts ");
		String selTab = request.getParameter("sel_tab");
		String errMsg=request.getParameter("errorMsg");
		log.info(" error messge value :: "+errMsg);
		
		Util util=new Util();
		if(selTab != null){
			request.getSession().setAttribute("selected_Tab", util.getSelectedTab(null, selTab,null));
		}
		String con_type = request.getParameter("con_type"); 
		if(con_type != null){
			request.getSession().setAttribute("con_type", con_type);
		}
		if(busjusProcess==null || !(busjusProcess instanceof BusinessJustificationProcess)){
			busjusProcess = new BusinessJustificationProcess();
		}
		Long tiRequestId = getTirequestID(request);		
		Long planningId = busjusProcess.getPlanningId(tiRequestId);
		log.info("BusinessJustificationController :: loadBusinessCase :: tirequestId "+tiRequestId.longValue()+" :: planningId :: "+planningId);
		
		TIRequest tirequest = busjusProcess.getTIRequestDetails(tiRequestId);
		busjusProcess.setOldrelationshipID(tirequest.getTiProcess().getRelationshipId().getId());
		//Planning planning = busjusProcess.getPlanningDetails(planningId);
		ConnectionRequest conreq = busjusProcess.getConnectionRequest(planningId);
		
		if(conreq != null){
			List<VirtualConnReason> virconreasonlst = conreq.getVirtualConnReasons();
			if(virconreasonlst != null){
				String virConReason[] = new String[virconreasonlst.size()];
				int count = 0;
				for(VirtualConnReason virconreason:virconreasonlst){
					virConReason[count] = String.valueOf(virconreason.getGenericLookup().getId());
					log.info("BusinessJustificationController :: loadBusinessCase :: virConReason "+virConReason[count]);
					count++;
				}	
				busjusProcess.setVirtualConnReasons(virConReason);			
			}
		}
		if(tirequest.getVersionNumber().intValue() > 1){
			busjusProcess.setCurrBusJustfi(busjusProcess.getConnectionBusinessJustification(tirequest.getTiProcess().getId(), tiRequestId));
		}
		busjusProcess.setTirequest(tirequest);
		//busjusProcess.setPlanning(planning);
		busjusProcess.setConreq(conreq);
		
		//completion check
		completionCheck(request, conreq, tirequest) ;
		
		List<RelCitiHierarchyXref> relcitihierxrefs = tirequest.getTiProcess().getRelationshipId().getRelcitiHierarchyXrefs();
		for(RelCitiHierarchyXref relcitihierxref:relcitihierxrefs){
			busjusProcess.setSectorName(relcitihierxref.getCitiHierarchyMaster().getSector().getName());
			busjusProcess.setBusinessUnitName(relcitihierxref.getCitiHierarchyMaster().getBusinessUnit().getBusinessName());
		}
		if(errMsg!=null && !errMsg.isEmpty()){
			log.info(" inside the set error message");
			ObjectError	error= new ObjectError("name",errMsg);
			result.addError(error);
		}
		
		busjusProcess = loadBusinessCaseDropDowns(busjusProcess);
		//copy contacts from relationship contacts table (first time)
		busjusProcess.copyContactsFromRelationship(tiRequestId);
		
		model.addAttribute("busjusProcess",busjusProcess);
		log.info("BusinessJustificationController :: loadBusinessCase :: ends ");
		
		return "c3par.businessjustification.businessCase";
	}
	
	private BusinessJustificationProcess loadBusinessCaseDropDowns(BusinessJustificationProcess busjusProcess){

		busjusProcess.setDetailedInfoList(busjusProcess.getGenericLookupDropDown("DETAILED_INFORMATION"));
		busjusProcess.setClassificationList(busjusProcess.getGenericLookupDropDown("Classification"));
		busjusProcess.setConestimateList(busjusProcess.getGenericLookupDropDown("CONNECTION_ESTIMATE"));
		busjusProcess.setReasonforVirConList(busjusProcess.getGenericLookupDropDown("ReasonsForVirtuConn"));
		
		return busjusProcess;
	}

	@RequestMapping(value = "/updateResolveITTirequestId.act", method = { RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody String updateResolveITTirequestId(HttpServletRequest request, @ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess, ModelMap model) {
		log.info("BusinessJustificationController ::updateResolveITTirequestId :: start ");
		
		String tiRequestID = (String) request.getSession().getAttribute("tireqid");		
		busjusProcess.updateTiRequestCMP(null,tiRequestID);
		
		return "";
	}
	
	@RequestMapping(value = "/saveBusinessCase.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String saveBusinessCaseDetails(HttpServletRequest request, @ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess,ModelMap model) {
		String forwardTo = "c3par.businessjustification.businessCase";
		String action = request.getParameter("action");	
		log.info("BusinessJustificationController :: saveBusinessCaseDetails :: start "+action);
		
		if(busjusProcess.getTirequest() == null 
				|| busjusProcess.getTirequest().getId() == null
				|| busjusProcess.getTirequest().getId().longValue() <= 0){
			log.debug("BusinessJustificationController :: saveBusinessCaseDetails :: busjusProcess.getTirequest() == null ");
			Long tirequestId = getTirequestID(request);
			tirequestId = getTirequestID(request);
			TIRequest tirequest = busjusProcess.getTIRequestDetails(tirequestId);	
			busjusProcess.setTirequest(tirequest);
		}
		
		if(action != null && (action.equalsIgnoreCase("save") || action.equalsIgnoreCase("continue"))){		
			//update tirequest and connection_request table data
			busjusProcess.updateBusinessCaseInfo(busjusProcess.getTirequest(), busjusProcess.getConreq(), busjusProcess.getVirtualConnReasons());
			//update tirequestid in resolve_it_notify_log table
			String cmp_idList=busjusProcess.getTirequest().getCmpId();
			if(cmp_idList != null && cmp_idList.length() > 0){
				String[] multiCMP_Id;
				if(cmp_idList.indexOf(",")!= -1){
					log.debug("Multiple CMP ID >>>>");
					multiCMP_Id = cmp_idList.split(",");
				}
				else{
					log.debug("Single CMP ID >>>>"+cmp_idList);
					multiCMP_Id = new String[]{cmp_idList};
				}
				for(String cmp_id : multiCMP_Id){
					log.debug("Cab Approval Code >>>> :: "+cmp_id);
					busjusProcess.updateTiRequestCMP(cmp_id,String.valueOf(busjusProcess.getTirequest().getId()));
				}
			}
			//delete the cmp document
			String serviceNowID = busjusProcess.getTirequest().getSnowId();
			if(serviceNowID != null  && serviceNowID.trim().length() > 0){
				busjusProcess.deleteUploadedDocument(String.valueOf(busjusProcess.getTirequest().getId()), "CMP Document");
			}
			
			//Multiple CAB Approval Code				
			if(busjusProcess.getConreq().getCapappGroupCode() != null){	
				
				String cabApprovalCodes = busjusProcess.getConreq().getCapappGroupCode();
				log.debug("BusinessJustificationController :: saveBusinessCaseDetails :: cabApprovalCodes - "+cabApprovalCodes);
				if(cabApprovalCodes != null && cabApprovalCodes.length() > 0){
					
					String [] multiCabAppCode= null;
					if(cabApprovalCodes.indexOf(",")!= -1){
					multiCabAppCode = cabApprovalCodes.split(",");
					}
					else{
						multiCabAppCode = new String[]{cabApprovalCodes};
					}
					for(String printCabCode : multiCabAppCode){
						log.debug("Cab Approval Code >>>> :: "+printCabCode);
					}

					RFCRequest rfcRequest= busjusProcess.getGenericRFCRequest(busjusProcess.getTirequest());
					
					RFCDetail rfcDetail= rfcRequest.getMultiCABAppCode();			
					
					if(rfcDetail != null){
				    	log.debug("Inside the insertMultiple CAb Approval Detail block:rfcDetail not null");
						if(rfcDetail.getId() != null){
						    log.info(":: RFC Detail ID:: "+rfcDetail.getId());
						    int multipleCABApprovalRowsDeleted = busjusProcess.deleteRFCDetailAnswer(rfcDetail);
						    log.info("No of Records deleted in rfc_detail_answers table before insert = "+multipleCABApprovalRowsDeleted);
						}
						
						rfcDetail.setRfcRequest(rfcRequest);
						List<RFCDetailAnswer> rfcDetailAnswerList = new ArrayList<RFCDetailAnswer>();
						if(multiCabAppCode.length > 0){
							for(String element : multiCabAppCode) {
								log.info("RFCDetailAnswer Cab Approval code in array >>>>>:: " + element);
								RFCDetailAnswer rfcDetailAnswer = new RFCDetailAnswer();
								rfcDetailAnswer.setAnswer(element);
								rfcDetailAnswer.setRfcDetail(rfcDetail);
								rfcDetailAnswerList.add(rfcDetailAnswer);
							    }
						}
						rfcDetail.setRfcDetailAnswerList(rfcDetailAnswerList);
	
						busjusProcess.addRFCDetail(rfcDetail);
						log.info("Succesfully inserted selected CAB Approval code details with detail id "+rfcDetail.getId());
					}else{ 
						rfcDetail=new RFCDetail();
						RFCLookup rfclookup=busjusProcess.getRFCLookup("CAB_APPROVAL");
						rfcDetail.setRfcLookup(rfclookup);

						rfcDetail.setRfcRequest(rfcRequest);
						List<RFCDetailAnswer> rfcDetailAnswerList = new ArrayList<RFCDetailAnswer>();
						if(multiCabAppCode.length > 0){
							for(String element : multiCabAppCode) {
								log.info("RFCDetailAnswer Cab Approval code in array >>>>>:: " + element);
								RFCDetailAnswer rfcDetailAnswer = new RFCDetailAnswer();
								rfcDetailAnswer.setAnswer(element);
								rfcDetailAnswer.setRfcDetail(rfcDetail);
								rfcDetailAnswerList.add(rfcDetailAnswer);
							    }
						}
						rfcDetail.setRfcDetailAnswerList(rfcDetailAnswerList);
	
						busjusProcess.addRFCDetail(rfcDetail);
						log.info("Succesfully inserted selected CAB Approval code details with detail id "+rfcDetail.getId());
					}
				}				
			}
			
		}else if(action != null && action.equalsIgnoreCase("saUpdate")){
			Long oldRelationdId = busjusProcess.getOldrelationshipID();
			Long tiRequestId = busjusProcess.getTirequest().getId();
			Long relationId = busjusProcess.getTirequest().getTiProcess().getRelationshipId().getId();
			String soeId = (String)request.getSession().getAttribute("ssoId");
			try {
				busjusProcess.updateBusinessCaseBySA(relationId, oldRelationdId, tiRequestId, soeId);
				String msg = "Relationship Id updated to "+relationId;
				request.setAttribute("msg_saupdate", msg);
				log.debug("BusinessJustificationController :: saveBusinessCaseDetails :: saUpdate :: Relationship ID: "+relationId);
			} catch (Exception e) {
				log.error(e);
				e.printStackTrace();
			}			
		} else if (action.equals("obtainCabApprvCode")) {
			if (request.getSession().getAttribute("CAB_APPRV_CODE") != null) {
				String cabApprvCode = (String) request.getSession().getAttribute("CAB_APPRV_CODE");
				log.debug("cabApprvCode::" + cabApprvCode);
				busjusProcess.getConreq().setCapappGroupCode(cabApprvCode);
				request.getSession().removeAttribute("CAB_APPRV_CODE");
			}
		} else if (action.equals("obtainCMPId")) {
			if (request.getSession().getAttribute("CMP_ID") != null) {
				String cmp_id = (String) request.getSession().getAttribute("CMP_ID");
				HashSet cmpSet=new HashSet();
				StringBuffer cmpBuffer= new StringBuffer();
				String selectedCmp=busjusProcess.getTirequest().getCmpId();
				if(selectedCmp!=null && !selectedCmp.isEmpty() && selectedCmp.length()>0){					
					String cmpId[]=selectedCmp.split(",");
					for(String cmp:cmpId){
						if(cmpSet.add(cmp)){
							cmpBuffer.append(cmp+",");
						}
					}
				}
				if(cmp_id!=null && !cmp_id.isEmpty() && cmp_id.length()>0){					
					String cmpId[]=cmp_id.split("\\,");
					for(String cmp:cmpId){
						if(cmpSet.add(cmp)){
							cmpBuffer.append(cmp+",");
						}
					}
				}
				log.debug("obtainCMPId::" + cmpBuffer.toString());
				if(cmpBuffer.lastIndexOf(",") != -1 && cmpBuffer.length() > 1){
					cmpBuffer = new StringBuffer(cmpBuffer.substring(0, cmpBuffer.length()-1 ));
				}
				busjusProcess.getTirequest().setCmpId(cmpBuffer.toString());
				request.getSession().removeAttribute("CMP_ID");
			}
		} else if (action.equals("removeCMPId")) {
				busjusProcess.updateTiRequestCMP(null,String.valueOf(busjusProcess.getTirequest().getId()));
				busjusProcess.getTirequest().setCmpId(null);
		}

		if(action != null && action.equalsIgnoreCase("continue")){
			forwardTo = "forward:/loadConnectionBasicInfo.act";
		}else{
			busjusProcess = loadBusinessCaseDropDowns(busjusProcess);
		}

		model.addAttribute("busjusProcess",busjusProcess);
		
		return forwardTo;
	}

	@RequestMapping(value = "/loadConnectionBasicInfo.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String loadConnectionBasicInfo(HttpServletRequest request, @ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess,ModelMap model) {

		log.info("BusinessJustificationController :: loadConnectionBasicInfo :: start ");
		
		if(busjusProcess == null){
			log.debug("BusinessJustificationController :: loadConnectionBasicInfo :: busjusProcess == null ");
			busjusProcess = new BusinessJustificationProcess();
		}		
		
		log.debug("BusinessJustificationController :: loadConnectionBasicInfo :: busjusProcess.getTirequest() == null ");
		Long tirequestId = getTirequestID(request);
		tirequestId = getTirequestID(request);
		TIRequest tirequest = busjusProcess.getTIRequestDetails(tirequestId);	
		busjusProcess.setTirequest(tirequest);
		Long planningId = busjusProcess.getPlanningId(busjusProcess.getTirequest().getId());
		ConnectionRequest conreq = busjusProcess.getConnectionRequest(planningId);
		
		if(busjusProcess.getPlanning() == null){
			log.debug("BusinessJustificationController :: loadConnectionBasicInfo :: busjusProcess.getPlanning() == null ");
			Planning planning = busjusProcess.getPlanningDetails(planningId);
			busjusProcess.setPlanning(planning);
		}	

		//completion check
		completionCheck(request, conreq, tirequest) ;
		
	    RFCRequest rfcRequest= busjusProcess.getGenericRFCRequest(busjusProcess.getTirequest());
	    
		busjusProcess.setConnectionName(busjusProcess.getTirequest().getTiProcess().getProcessName());
		if(busjusProcess.getPlanning().getDontImplBeforeDate() != null){
			SimpleDateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy");
			busjusProcess.setDonotimplDate(dateformat.format(busjusProcess.getPlanning().getDontImplBeforeDate()));
		}
		busjusProcess.setAffectedBusiness(getAffectedBusinessDetail(rfcRequest));
		
		busjusProcess.setPriorityList(busjusProcess.getGenericLookupDropDown("Process Priority"));
		busjusProcess.setAffectedBusinessList(busjusProcess.getGenericLookupDropDown("AFFECTED_BUSINESS"));
		
		return "c3par.businessjustification.connectionBasicInfo";
	}
	
	@RequestMapping(value = "/saveConnectionBasicInfo.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String saveConnectionBasicInfo(HttpServletRequest request, @ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess,ModelMap model) {

		String action = request.getParameter("action");	
		String forwardTo = "";
		log.info("BusinessJustificationController :: saveConnectionBasicInfo :: start - "+action);
		
		if(busjusProcess == null){
			busjusProcess = new BusinessJustificationProcess();
		}

		if(busjusProcess.getTirequest() == null 
				|| busjusProcess.getTirequest().getId() == null
				|| busjusProcess.getTirequest().getId().longValue() <= 0){
			log.info("BusinessJustificationController :: saveConnectionBasicInfo :: busjusProcess.getTirequest() == null ");
			
			Long tirequestId = getTirequestID(request);
			TIRequest tirequest = busjusProcess.getTIRequestDetails(tirequestId);	
			busjusProcess.setTirequest(tirequest);
		}
		 Util util = new Util();
		 Calendar cal=Calendar.getInstance();
		if(busjusProcess.getTirequest().getPriority()!=null){
			String priority=util.getPriority(busjusProcess.getTirequest().getPriority().getId());
			log.debug("priority" +priority );
			String priorityDeadline=util.checkRequestDeadLineDate(priority);
			
			TIRequest tiReq =busjusProcess.getTIRequestDetails(busjusProcess.getTirequest().getId());
			cal.setTime(tiReq.getCreated_date());
			//log.info(" time before trunc "+cal.getTime());
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.HOUR,19);
			if(priorityDeadline!=null){
			    cal.add(Calendar.MINUTE,Integer.valueOf(priorityDeadline).intValue());
			}else{
			    cal.add(Calendar.MINUTE,0);
			}
			 log.info(" time before setting request deadline "+cal.getTime());
		}
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
		
		if(action != null && (action.equalsIgnoreCase("save") || action.equalsIgnoreCase("continue"))){
			
		    if(busjusProcess.getTirequest().getPriority() != null && busjusProcess.getTirequest().getPriority().getValue1().trim().equals("BAU")){				
				//Delete RFCDetailAnswerlist based on priority change
				RFCRequest rfcRequest = busjusProcess.getEMERGenericRFCRequest(busjusProcess.getTirequest(), null);
				if (rfcRequest != null && rfcRequest.getDescription() != null && rfcRequest.getDescription().getId() != null) {
					busjusProcess.deleteRFCDetail(rfcRequest.getDescription());
				}
		    }
		    //update ConnectionBasicInfo Details		   
			String donotimplDate = "";
			if(busjusProcess.getDonotimplDate() != null){
				donotimplDate = busjusProcess.getDonotimplDate();
			}
		    busjusProcess.updateConnectionBasicInfo(busjusProcess.getTirequest().getId(), busjusProcess.getTirequest().getPriority().getId(), 
		    		donotimplDate,busjusProcess.getTirequest().getVtTicketNo(),cal.getTime());
		    // affected business changes
		    insertAffectedBusinessDetail(busjusProcess);
		    
		    if(busjusProcess.getTirequest() != null 
		    		&& (C3parStaticNames.CITI_CON.equalsIgnoreCase(busjusProcess.getTirequest().getTiProcess().getRelationshipId().getRelationshipType())
		    				|| C3parStaticNames.U_TURN.equalsIgnoreCase(busjusProcess.getTirequest().getTiProcess().getRelationshipId().getRelationshipType()))){
		    	forwardTo = "redirect:/loadRequesterContacts.act";
		    }else {
		    	forwardTo = "redirect:/loadTargetContacts.act";
		    }
		    //Added for refreshing menu
		    Long tirequestId = Long.valueOf(request.getSession()
					.getAttribute("tireqid").toString());			

			TIRequest tirequest = busjusProcess.getTIRequestDetails(tirequestId);
			
		    request.getSession().setAttribute("TI_REQUEST_ENTITY", tirequest);
		    
		} else if("saUpdate".equals(action)){
			String oldConnectionName = busjusProcess.getTirequest().getTiProcess().getProcessName();
			Long tiReqId = getTirequestID(request);
			String connectionName = busjusProcess.getConnectionName();
			String soeId = (String)request.getSession().getAttribute("ssoId");			
			try {
				log.debug("BusinessJustificationController :: saveConnectionBasicInfo :: oldConnectionName "+oldConnectionName
						+" :: connectionName "+connectionName+" :: tiReqId "+tiReqId+" :: soeId "+soeId);
				
				busjusProcess.updateConnectionBasicInfoBySA(connectionName, oldConnectionName, tiReqId, soeId);
				String msg = "Connection Name updated to "+connectionName;
				request.setAttribute("msg_saupdate", msg);
				forwardTo = "forward:/loadConnectionBasicInfo.act";
			} catch(Exception e) {
				log.error(e);
				e.printStackTrace();
			}
		}
		log.info("BusinessJustificationController :: saveConnectionBasicInfo :: forwardTo - "+forwardTo);
		return forwardTo;
	}
	
	
	


	
	
	
	private Long getTirequestID(HttpServletRequest request){

		Long tirequestId = 0L;
		if(request.getSession().getAttribute("tireqid") != null){
			tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());			
		}else if(request.getParameter("tireqid") != null){
			tirequestId = Long.valueOf(request.getParameter("tireqid").trim());			
		}else { //if(request.getParameter("tiRequestId") != null){
			tirequestId = Long.valueOf(request.getParameter("tiRequestId"));
		}
		log.info("BusinessJustificationController :: getTirequestID :: tirequestId - "+tirequestId);
		return tirequestId;
	}
	
    private void insertAffectedBusinessDetail(BusinessJustificationProcess busjusProcess){
		try {	
		    if (busjusProcess.getAffectedBusiness() != null) {

				RFCRequest rfcRequest = busjusProcess.getGenericRFCRequest(busjusProcess.getTirequest());				
				String [] affBArray = busjusProcess.getAffectedBusiness();
				
				if (rfcRequest != null && rfcRequest.getAffectedBusiness() != null) {	
					log.debug("Inside the insertAffectedBusinessDetail block:");
					RFCDetail rfcDetail= rfcRequest.getAffectedBusiness();
					
					// deleting the records before go for insert the selected affected business
					
					if(rfcDetail != null){
						log.debug("Inside the insertAffectedBusinessDetail block:rfcDetail not null");
						if(rfcDetail.getId() != null){
						    log.info(":: RFC Detail ID:: "+rfcDetail.getId());
							int affectedBusinessRowsDeleted = busjusProcess.deleteRFCDetailAnswer(rfcDetail);
							log.info("No of Records deleted in rfc_detail_answers table before insert = "+affectedBusinessRowsDeleted);
							
							log.info(" RFC Request ID::"+ rfcDetail.getRfcRequest().getId() + ":: RFC Lookup ID::"
							+ rfcDetail.getRfcLookup().getId() + ":: RFC Detail ID:: "+rfcDetail.getId());
						}
						rfcDetail.setRfcRequest(rfcRequest);
						List<RFCDetailAnswer> rfcDetailAnswerList = new ArrayList<RFCDetailAnswer>();
				
						if (affBArray.length > 0) {
						    for (String element : affBArray) {
						    	log.info("RFCDetailAnswer in array " + element);
								RFCDetailAnswer rfcDetailAnswer = new RFCDetailAnswer();
								rfcDetailAnswer.setAnswer(element);
								rfcDetailAnswer.setRfcDetail(rfcDetail);
								rfcDetailAnswerList.add(rfcDetailAnswer);
							}
						}				
						rfcDetail.setRfcDetailAnswerList(rfcDetailAnswerList);
						
						busjusProcess.addRFCDetail(rfcDetail);
						
						log.info("Succesfully inserted selected affected business details with detail id "+rfcDetail.getId());
					}
				}else{
				
					log.debug("Inside the insertAffectedBusinessDetail block:");
					RFCDetail rfcDetail = new RFCDetail();
					RFCLookup rfclookup = busjusProcess.getRFCLookup("AFFECTED_BUSINESS");
					rfcDetail.setRfcLookup(rfclookup);
					rfcDetail.setRfcRequest(rfcRequest);
					
					List<RFCDetailAnswer> rfcDetailAnswerList = new ArrayList<RFCDetailAnswer>();
				
					if (affBArray.length > 0) {
					    for (String element : affBArray) {
							log.info("RFCDetailAnswer in array " + element);
							RFCDetailAnswer rfcDetailAnswer = new RFCDetailAnswer();
							rfcDetailAnswer.setAnswer(element);
							rfcDetailAnswer.setRfcDetail(rfcDetail);
							rfcDetailAnswerList.add(rfcDetailAnswer);
					    }
					}
					rfcDetail.setRfcDetailAnswerList(rfcDetailAnswerList);
					busjusProcess.addRFCDetail(rfcDetail);
	
	    			log.info("Succesfully inserted selected affected business details with detail id "+rfcDetail.getId());    		    
				}
		    }
		} catch (ArithmeticException e) {
			log.error(e, e);
		}
    }
    
}
