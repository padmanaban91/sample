package com.citigroup.cgti.c3par.webtier.helper;


/**
 * The Class GenericHelper.
 */
public class GenericHelper {

    /**
     * Chk is null.
     *
     * @param str the str
     * @return true, if successful
     */
    public boolean chkIsNull(String str) {
	boolean isNull=false;
	if(str==null)
	    isNull=true;
	else if(str.length()==0)
	    isNull=true;
	return isNull;
    }

    /**
     * Chk is zero.
     *
     * @param id the id
     * @return true, if successful
     */
    public boolean chkIsZero(Long id) {
	boolean isZero=false;
	if(id==null)
	    isZero=true;
	else if(id.longValue()==0)
	    isZero=true;
	return isZero;

    }

    /**
     * Convert boolean to string.
     *
     * @param value the value
     * @return the string
     */
    public String convertBooleanToString(boolean  value) {
	return value?"true":"false";
    }

}
