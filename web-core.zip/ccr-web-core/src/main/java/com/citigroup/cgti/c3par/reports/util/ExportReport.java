package com.citigroup.cgti.c3par.reports.util;

import java.util.Iterator;
import java.util.List;
import java.util.Collection;
import java.util.Date;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.citigroup.cgti.c3par.reports.reportInterface.ReportData;
import com.citigroup.cgti.c3par.reports.reportInterface.DataRequester;

import com.citigroup.cgti.c3par.webtier.helper.DateConversionHelper;
import org.apache.log4j.Logger;


/**
 * The Class ExportReport.
 */
public class ExportReport
{

    /** The log. */
    private static Logger log = Logger.getLogger(ExportReport.class);

    /**
     * Export.
     *
     * @param data_requester the data_requester
     * @param title the title
     * @param request the request
     * @param response the response
     */
    static public void export(DataRequester data_requester, String title, HttpServletRequest request, HttpServletResponse response)
    {
	try
	{
	    List columns = data_requester.getColumns();
	    Date today = new Date();
	    PrintWriter writer = response.getWriter();
	    response.setBufferSize(16 * 1024);
	    response.setContentType("application/vnd.ms-excel");
	    response.addHeader("Content-Disposition", "attachment; filename="+title+".xls");
	    // Stream out the start of the html page

	    writer.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
	    writer.println("<link href=\"" + request.getContextPath() + "/jsp/pager/ExportExcel.css\" rel=\"stylesheet\" type=\"text/css\">");
	    writer.println("<html xmlns:o=\"urn:schemas-microsoft-com:office:office\"");
	    writer.println("xmlns:x=\"urn:schemas-microsoft-com:office:excel\"");
	    writer.println("xmlns=\"http://www.w3.org/TR/REC-html40\">");
	    writer.println(" <head>");
	    writer.println("<meta http-equiv=Content-Type content=\"text/html; charset=windows-1252\">");
	    writer.println("<meta name=ProgId content=Excel.Sheet>");
	    writer.println(" <meta name=Generator content=\"Microsoft Excel 11\">");
	    writer.println(" <style id=\"STI_5961_Styles\">");
	    //writer.println(" <!--");
	    writer.println(" table");
	    writer.println(" {mso-displayed-decimal-separator:\"\\.\";");
	    writer.println("  mso-displayed-thousand-separator:\"\\,\";}");
	    writer.println(" .xlGeneral");
	    writer.println(" {padding-top:1px;");
	    writer.println(" padding-right:1px;");
	    writer.println(" padding-left:1px;");
	    writer.println(" mso-ignore:padding;");
	    writer.println(" color:windowtext;");
	    writer.println("  font-size:10.0pt;");
	    writer.println(" font-weight:400;");
	    writer.println(" font-style:normal;");
	    writer.println(" text-decoration:none;");
	    writer.println(" font-family:Arial;");
	    writer.println(" mso-generic-font-family:auto;");
	    writer.println(" mso-font-charset:0;");
	    writer.println(" mso-number-format:General;");
	    writer.println(" text-align:general;");
	    writer.println(" vertical-align:bottom;");
	    writer.println(" mso-background-source:auto;");
	    writer.println(" mso-pattern:auto;");
	    writer.println(" white-space:nowrap;}");
	    writer.println(".date {mso-number-format:\"yyyy\\-mm\\-dd\\ hh\\:mm\\:ss\\.SSS\\;\\@\"}");
	    writer.println("</style>");

	    writer.println("<title>" + title + "</title>");
	    writer.println("</head><body> <div id=\"STI_5961\" align=center x:publishsource=\"Excel\"");
	    writer.println("<table  x:str  class=\"export_table\" border=\"1\">");
	    // write the title and date
	    writer.println("<tr class=\"export_title_row\"><td class=\"export_title_cell\" colspan=\"" + columns.size() + "\"><big><b>Title: " + title + "</b></big></td></tr>");
	    writer.println("<tr class=\"export_date_row\"><td class=\"export_date_cell\" colspan=\"" + columns.size() + "\"><b>Report Date: ");
	    writer.println(DateConversionHelper.getIntToMonth(today.getMonth()) + "-" + today.getDate() + "-" + (today.getYear() + 1900)); 			
	    writer.println("</b></td></tr>");
	    writer.println("<tr><td></td></tr>");



	    writer.println("<tr class=\"export_header_row\" bgcolor=\"eeee00\">");


	    // get the columns, and prepare the table headers  
	    //			List columns = data_requester.getColumns();
	    Iterator col_iter = columns.iterator();
	    while(col_iter.hasNext())
	    {
		writer.println("<th class=\"export_header_cell\">" + (String)col_iter.next() + "</th>");
	    }
	    writer.println("</tr>");


	    int	batch_size = 25;
	    String objStr;
	    String className;
	    long report_rows = data_requester.getRowCount();
	    long report_batches = report_rows / batch_size + 1;
	    for(int batch_count = 0; batch_count < report_batches; ++batch_count)
	    {
		ReportData report_data = data_requester.getData(batch_count * batch_size, batch_size);
		Collection rows = report_data.getDataValue().values();

		Iterator row_iter = rows.iterator();
		while(row_iter.hasNext())
		{
		    List values = (List)row_iter.next();
		    writer.println("<tr class=\"export_body_row\">");				

		    Iterator value_iter = values.iterator();
		    while(value_iter.hasNext())
		    {
			Object object = value_iter.next();
			objStr =(object != null) ? object.toString():"";
			if(objStr.indexOf("-")>0 && objStr.indexOf(":")>0){
			    className = "x:num class=\"date\"";							
			}else{
			    className = "class=\"export_body_cell\"";
			}
			String tad = "<td valign=\"top\" "+className+" >" + objStr + "</td>";
			writer.println(tad);
		    }       

		    writer.println("</tr");
		}				
	    }
	    writer.println("</table></div></body></html>");
	    response.flushBuffer();
	}
	catch(Exception e)
	{
	    log.error("Exception occured during Export: " + e);
	}
    }
}

