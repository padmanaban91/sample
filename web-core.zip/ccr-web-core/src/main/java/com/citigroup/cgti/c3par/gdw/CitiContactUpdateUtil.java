package com.citigroup.cgti.c3par.gdw;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule;
import com.citigroup.cgti.c3par.bpm.ejb.useradmin.GDWUser;


public class CitiContactUpdateUtil{
	
    private JdbcTemplate jdbcTemplateCCR;
    private JdbcTemplate jdbcTemplateGDW;
    private IMailModule mailModuleImpl;
	Logger log = Logger.getLogger(this.getClass().getName());
	
    /** The send scheduled email flag. */
    private static final String sendScheduledEmailFlag = System.getProperty("sendScheduledEmail.flag");
	
	
	public void setJdbcTemplateCCR(JdbcTemplate jdbcTemplateCCR) {
		this.jdbcTemplateCCR = jdbcTemplateCCR;
	}


	public void setJdbcTemplateGDW(JdbcTemplate jdbcTemplateGDW) {
		this.jdbcTemplateGDW = jdbcTemplateGDW;
	}


	public void setMailModuleImpl(IMailModule mailModuleImpl) {
		this.mailModuleImpl = mailModuleImpl;
	}
	
	public void synchCCR_GDW()
	{
		
		/*1. Last GDW Job Run Date to be stored in server_constants
		 *2. query gdw_users table to fetch all employees that were terminated between last_run_date and today
		 *3. Get active employees from citi_contact
		 *3. Check if those employees exists in citi_contacts table. 
		 *4. if yes then update that employee/contact as 'T' in the citi_contact table
		 *5. Check if those manager exists in citi_contacts table. 
		 *6. if no then insert in the citi_contact table
		 *7. copy the contact to history table
		 *8. Check the LEVEL of terminated employee's manager. If LEVEL is > 6 and manager is 'A' then proceed with replacement in CON_REQ_CITI_CONTACT_XREF 
		 *9. send email to new target contact
		 *10. record the new last_run_datetime  
		 * 
		 * */
		//This Job is scheduled to run on Node2. We are 
		
		//Commenting out as the WAS is now has Quartz to take care of load balancing.
    	/*if("true".equalsIgnoreCase(sendScheduledEmailFlag)) {
    		return;
    	}*/
		/*1. Last GDW Job Run Date to be stored in server_constants*/
		String newLastRunDateStr = convertDateToString(new Date());
		String lastRunDateQuery = "select value2 as gdw_last_run_date from generic_lookup where value1 = 'GDW_JOB_LAST_RUN_DATE'";
		String gdwLastRunDateStr = jdbcTemplateCCR.queryForObject(lastRunDateQuery, String.class);
	    log.info("Last GDW Job Ran on -->"+gdwLastRunDateStr);
	    
	    
	    /*2. query gdw_users table to fetch all employees that were terminated between last_run_date and today into gdwUsersList*/
		String terminatedGDWUsersQuery = "select userdata.*, gdw.email manageerEmailId, gdw.employee_status managerEmpStatus,gdw.firstname managerfirstname,gdw.lastname managerlastname from rdspr.gdw_user gdw, " +
				"(SELECT SOEID, GEID, EMPLOYEE_STATUS,  SUPERVISOR_GEID managerGEID, BO_EMP_TERM_DATE " +
				"from rdspr.gdw_user where EMPLOYEE_STATUS='T' and BO_EMP_TERM_DATE > ? and BO_EMP_TERM_DATE < sysdate) userdata " +
				"where gdw.GEID (+)= userdata.managerGEID";

		List<GDWUser> gdwUsersList = new ArrayList<GDWUser>();
		List<Map<String, Object>> rows = jdbcTemplateGDW.queryForList(terminatedGDWUsersQuery,gdwLastRunDateStr);
		log.info(rows.size());
		for (Map row : rows) {
			GDWUser gdwUser = new GDWUser();
			gdwUser.setSoeid((String) row.get("SOEID"));
			gdwUser.setGeid((String) row.get("GEID"));
			gdwUser.setEmployee_status((String)row.get("EMPLOYEE_STATUS"));
			gdwUser.setSupervisor_geid((String)row.get("managerGEID"));
			gdwUser.setBo_emp_term_date((Date)row.get("BO_EMP_TERM_DATE"));
			/*using email attribute as place holder for supervisor email*/
			gdwUser.setEmail((String)row.get("manageerEmailId"));
			/*using supervisor_name attribute as place holder for supervisorEmployeeStatus*/
			gdwUser.setSupervisor_name((String)row.get("managerEmpStatus"));			
			//supervisor first and last name
			gdwUser.setSupervisor_firstname((String)row.get("managerfirstname"));
			gdwUser.setSupervisor_lastname((String)row.get("managerlastname"));
			
			//log.info("GDW Terminated User --->"+gdwUser.getSoeid());
			gdwUsersList.add(gdwUser);
		}
		
		/*3. Get active employees from citi_contact in ccrUserList*/
		List<String> ccrUserList = new ArrayList<String>();
		String activeCCRUsersQuery = "select geid from citi_contact where employee_status = 'A'" ;
		ccrUserList = jdbcTemplateCCR.queryForList(activeCCRUsersQuery,String.class) ;
		log.info("active ccr users in citi contact -->"+ccrUserList.size());
		//log.info("active ccr users in citi contact -->"+ccrUserList);
		
		
		//final Map<String,GDWUser> employeesSelectedForUpdate = new HashMap();
		final ArrayList<GDWUser> employeesSelectedForUpdate = new ArrayList();
		final Map<String,GDWUser> managerSelectedForInsert = new HashMap();
		
				
		for (GDWUser terminatedEmp : gdwUsersList){
			String terminatedUser = terminatedEmp.getGeid();

	//		 3. compare 2 lists and check if ccrUserList contain terminated emp
			if (ccrUserList.contains(terminatedUser)) {
				String terminatedEmpManager = terminatedEmp.getSupervisor_geid().trim();
				log.info("employee geid "+ terminatedUser + " is terminated and will be updated in citi_contacts");
				log.info("emp manager geId from gdwUsersList " +terminatedEmpManager);
				//4. if yes then update that employee/contact as 'T' in the citi_contact table
				//prepare the list of employees that need to be updated
				//employeesSelectedForUpdate.put(terminatedEmp, terminatedEmps);
				employeesSelectedForUpdate.add(terminatedEmp);
				
				//Also find out whether terminated employees manager is available in citi_contact. If not we will add him to list of managers to be inserted
				//Preparing list of missing manager's to be inserted
				//20-Jun-14 : PRD defect. Inserting more than 1000 manages in CCR
				//20-Jun-14 : Moved this condition within the ccrUserList.contains(terminatedUser) if condition. This will ensure that only missing managers related to CCR users are updated.
				if (ccrUserList.contains(terminatedEmpManager)) {
					  log.info("manager geid "+ terminatedEmpManager + " is existing in citi_contacts");	
					}else{
						log.info("manager geid "+ terminatedEmpManager + " is missing in citi_contacts > "+ terminatedEmp.getSoeid());
						if (terminatedEmpManager != null && !terminatedEmpManager.isEmpty())
								managerSelectedForInsert.put(terminatedEmpManager, terminatedEmp);
		
					}
				}		

				
			}
			
		
		//updating citi_contacts table now using bulk update function of jdbcTemplate
		if (employeesSelectedForUpdate != null && employeesSelectedForUpdate.size() > 0) {
			batchUpdateTerminatedEmployees(employeesSelectedForUpdate);
		}

		//Preparing for bulk insertion of missing managers in citi_contacts table
	if (managerSelectedForInsert != null && managerSelectedForInsert.size() > 0) {
		
		log.info("size of managerSelectedForInsert = "+managerSelectedForInsert.size() );
			
		ArrayList<String> paramList = new ArrayList<String>();
		paramList.addAll(managerSelectedForInsert.keySet());
		log.info("list of ids = "+paramList);
		
		Map paramMap = Collections.singletonMap("ids", paramList);

	    String sql = "select firstname,lastname,rits_id,email,soeid,employee_class,geId,employee_status,supervisor_geid from rdspr.gdw_user where geid in (:ids)";
	    
	    
	    RowMapper<GDWUser> gdwUserMapper = new RowMapper<GDWUser>() {  
	        public GDWUser mapRow(ResultSet rs, int rowNum) throws SQLException {
	        	GDWUser gdwUserFromMapper = new GDWUser();
	        	gdwUserFromMapper.setFirstname(rs.getString("firstname"));
	        	gdwUserFromMapper.setLastname(rs.getString("lastname"));
	        	gdwUserFromMapper.setRits_id(rs.getString("rits_id"));
	        	gdwUserFromMapper.setEmail(rs.getString("email"));
	        	gdwUserFromMapper.setSoeid(rs.getString("soeid"));
	        	gdwUserFromMapper.setEmployee_class("");
	        	gdwUserFromMapper.setGeid(rs.getString("geId"));
	        	gdwUserFromMapper.setEmployee_status(rs.getString("employee_status"));
	        	gdwUserFromMapper.setSupervisor_geid(rs.getString("supervisor_geid"));
	            return gdwUserFromMapper;
	            
	        }
	    };
	    
	    NamedParameterJdbcTemplate nameParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplateGDW.getDataSource());
	    final List<GDWUser> detailOfMissingManagers = nameParameterJdbcTemplate.query(sql, paramMap, gdwUserMapper);
	    
	    log.info("detailOfMissingManagers size "+ detailOfMissingManagers.size());
	    
       /*inserting the supervisor that are not present/missing in citi_contacts*/
	    batchInsertManagers(detailOfMissingManagers);
	}
   
	/* send the list of terminated contacts to check if manager level is greater than 6*/
    /* 20-JUN-2014 : PROD Issue fix
     * We should not do this check for all the terminated users. We are interested only users that are present in citi_contacts.
     * So we should not pass gdwUsersList. We should be passing employeesSelectedForUpdate*/
	    isManagerValid(employeesSelectedForUpdate);
	
	
	    //finally replace the terminated contacts with their supervisor id
	    final String procedureCall = "{call c3par.CITI_CONTACT_HISTORY()}";
	    Connection conn;
		try {
			conn = jdbcTemplateCCR.getDataSource().getConnection();
	
	    CallableStatement callableStat = conn.prepareCall(procedureCall);
	    callableStat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    //send email
		sendEmailToNewSupervisor();
	
    //update the Last Run Time in generic_lookup
    
	String updateLastRunDateQuery = "update generic_lookup set value2 = ? where value1 = 'GDW_JOB_LAST_RUN_DATE'";
	int lastRunDateUpdated = jdbcTemplateCCR.update(updateLastRunDateQuery, newLastRunDateStr);
	log.info("number of rows updated "+lastRunDateUpdated+" Last run date will be updated to "+newLastRunDateStr);
	
	}
	
private void batchUpdateTerminatedEmployees(final List<GDWUser> employeeToBeUpdated){
	
	//log.info("employeeToBeUpdated -->"+employeeToBeUpdated);
	
	String updateEmpStatusInCitiContactsQuery = "UPDATE C3PAR.CITI_CONTACT SET EMPLOYEE_STATUS=? , SUPERVISOR_GEID=?, EMPLOYEE_TERMINATION_DATE= ?, " +
			"supervisor_email=?, GEID=?,updated_date=sysdate,supervisor_limit = 'NO', LATEST_SUPERVISOR_GEID=?,SUPERVISOR_FIRST_NAME=?,SUPERVISOR_LAST_NAME=? WHERE geid=?";

	try {
		//log.info("date "+employeeToBeUpdated.getBo_emp_term_date());
		
		int[] noofRowsUpdated = jdbcTemplateCCR.batchUpdate(updateEmpStatusInCitiContactsQuery, new BatchPreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1,employeeToBeUpdated.get(i).getEmployee_status());
				ps.setString(2, employeeToBeUpdated.get(i).getSupervisor_geid());

				if (employeeToBeUpdated.get(i).getBo_emp_term_date() != null) {
					ps.setDate(3, new java.sql.Date(employeeToBeUpdated.get(i).getBo_emp_term_date().getTime()));
				} else {
					ps.setDate(3,null);
				}
				ps.setString(4,employeeToBeUpdated.get(i).getEmail());
				ps.setString(5,employeeToBeUpdated.get(i).getGeid());
				log.info("Employee being updated => "+employeeToBeUpdated.get(i).getGeid());
				ps.setString(6,employeeToBeUpdated.get(i).getSupervisor_geid());
				ps.setString(7,employeeToBeUpdated.get(i).getSupervisor_firstname());
				ps.setString(8,employeeToBeUpdated.get(i).getSupervisor_lastname());
				ps.setString(9,employeeToBeUpdated.get(i).getGeid());
			}
			
			@Override
			public int getBatchSize() {
				// TODO Auto-generated method stub
				 return employeeToBeUpdated.size();
			}
		});
		log.info("Total number of rows update "+noofRowsUpdated.length);
	} catch (DataAccessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
}


	private void batchInsertManagers(final List<GDWUser> detailOfMissingManagers) {
		
		String dynamicInsert = "INSERT INTO C3PAR.CITI_CONTACT (ID,FIRST_NAME,LAST_NAME,RITS_ID,EMAIL,SSO_ID,EMPLOYEE_TYPE,GEID,EMPLOYEE_STATUS,SUPERVISOR_GEID,LATEST_SUPERVISOR_GEID,CREATED_DATE,UPDATED_DATE,SUPERVISOR_LIMIT) " +
	               " values " +
	               "(c3par.seq_CITI_CONTACT.nextval,?,?,?,?,?,?,?,?,?,?,sysdate,sysdate,'NO')";

			int[] noofRowsInserted = jdbcTemplateCCR.batchUpdate(dynamicInsert, new BatchPreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement pstmt, int i) throws SQLException {
					
					        pstmt.setString(1, detailOfMissingManagers.get(i).getFirstname());
					        pstmt.setString(2, detailOfMissingManagers.get(i).getLastname());
					        pstmt.setString(3, detailOfMissingManagers.get(i).getRits_id());
					        pstmt.setString(4, detailOfMissingManagers.get(i).getEmail());
					        pstmt.setString(5, detailOfMissingManagers.get(i).getSoeid());
					        pstmt.setString(6, detailOfMissingManagers.get(i).getEmployee_class());
					        pstmt.setString(7, detailOfMissingManagers.get(i).getGeid());
					        pstmt.setString(8, detailOfMissingManagers.get(i).getEmployee_status());
					        pstmt.setString(9, detailOfMissingManagers.get(i).getSupervisor_geid());
					        pstmt.setString(10, detailOfMissingManagers.get(i).getSupervisor_geid());
				}
				
				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					 return detailOfMissingManagers.size();
				}
			});
			log.info("Total number of rows inserted "+noofRowsInserted.length);
	}

	private java.sql.Date convertStringToDate(String terminationDate){
		
		if (terminationDate==null || terminationDate.length() < 1) return null;
		
		java.sql.Date sqldate = null;
		try {
			Date date = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse(terminationDate);
			 sqldate = new java.sql.Date(date.getTime());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqldate;
		
	}
	
	private String convertDateToString(Date date){
	// Create an instance of SimpleDateFormat used for formatting 
	// the string representation of date (month/day/year)
	DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");

	System.out.println("Report Date: " + df.format(date));

	return df.format(date);

	
	}
	private void isManagerValid(List<GDWUser> employeesSelectedForUpdate) {
		
		log.info("Entering isManagerValid........");
		String existingSupervisorId = null;
		String existingSupervisorStatus = null;
		String newActiveSupervisorId = null;
		String terminatedEmpGeId = null;
				
		for(GDWUser user:employeesSelectedForUpdate){
			terminatedEmpGeId = user.getGeid();
			existingSupervisorId = user.getSupervisor_geid();
			existingSupervisorStatus = user.getSupervisor_name();
			log.info("terminatedEmpGeId => "+terminatedEmpGeId +" existingSupervisorId => "+existingSupervisorId + " existingSupervisorStatus "+existingSupervisorStatus);
			if("T".equals(existingSupervisorStatus)){
				newActiveSupervisorId = getActiveManager(existingSupervisorId);
				if (newActiveSupervisorId != null && newActiveSupervisorId.length() > 0){
					int recordsUpdated = jdbcTemplateCCR.update("Update citi_contact set latest_supervisor_geid = ?, updated_date = sysdate where geId = ?", newActiveSupervisorId,user.getGeid());
					log.info("Existing supervisor "+existingSupervisorId+" is terminated, replacing him with "+newActiveSupervisorId +". Rows updated "+recordsUpdated);
					existingSupervisorId = newActiveSupervisorId;
				}else{
					int recordsUpdated = jdbcTemplateCCR.update("Update citi_contact set supervisor_limit = 'NF', updated_date = sysdate where geId = ?", user.getGeid());
					log.info("Unable to find any active supervisor for Employee "+terminatedEmpGeId+". Supervisor_Limit column set to NF");
		
				}
			}
			
			int level = getManagerLevel(existingSupervisorId);
			if (level < 6){
				//update the latest_supervisor_geId column to LH
				int recordsUpdated = jdbcTemplateCCR.update("Update citi_contact set supervisor_limit = 'LH', updated_date = sysdate where geId = ?", user.getGeid());
				log.info("Supervisor Level is less than 6. Limit Hit for employee "+terminatedEmpGeId+" . Rows updated "+recordsUpdated);
				//log.info("Supervisor Level is less than 6. Limit Hit for employee "+terminatedEmpGeId+" . Rows updated ");
			}
		}
		log.info("Exiting isManagerValid......");
		
		
	}
	
	private int getManagerLevel(String managerGeId){
		String managerLevelQuery = "select max(LEVEL) from rdspr.gdw_user start with geid=? connect by nocycle prior supervisor_geid = geid";
		List<Map<String,Object>> managerLevel = jdbcTemplateGDW.queryForList(managerLevelQuery,managerGeId);
		return managerLevel!=null?managerLevel.size():0;
	}
	
	private String getActiveManager(String managerGeId){
		
		log.info("Entering getActiveManager........");
		String getActiveManagerQuery = "select SUPERVISOR_GEID,employee_status from rdspr.gdw_user where geid = ?";
		String managerStatus = "T";
		String tempMgrGeId = managerGeId;
		int count = 1;
		while ("T".equals(managerStatus) && count <= 3){
			Map<String,Object> managerStatusMap = jdbcTemplateGDW.queryForMap(getActiveManagerQuery, tempMgrGeId);
			managerStatus = (String) managerStatusMap.get("employee_status");
			count++;
			tempMgrGeId = (String) managerStatusMap.get("SUPERVISOR_GEID");
			log.info("tempMgrGeId =>"+tempMgrGeId);
		} 
		
		log.info("Exiting getActiveManager......");
		
		return tempMgrGeId;
	}
	
	private void sendEmailToNewSupervisor(){
		String newManagersQuery = "Select Cc.geId, Cc.First_Name||', '||Cc.Last_Name Term_Emp_Name,Tir.Id Req_Id,Tir.Process_Id Ccr_Id, " +
				"Cc.Latest_Supervisor_Geid,Cc.Supervisor_Email supervisor_email, Role.Display_Name UserRole, Mgr.First_Name||', '||Mgr.Last_Name Supervisor_Name " +
				"From Audit_Log Al, Citi_Contact Cc, History_Con_Citi_Contact Cch, Role, Ti_Request Tir,Citi_Contact Mgr " +
				"Where To_Char(Al.Created_Date, 'mm/DD/RRRR') =  To_Char(Sysdate, 'mm/DD/RRRR') " +
				"And Al.User_Soe_Id = 'system' And Upper(Al.Old_Display_Value) = Upper(Cc.Sso_Id) And Cc.Supervisor_Limit = 'NO' And Cc.Employee_Status = 'T' " +
				"And Al.Old_Value = Cch.Id And Role.Id = Cch.Role_Id And Al.Ti_Request_Id = Tir.Id And Cc.Latest_Supervisor_Geid = Mgr.Geid order by mgr.geId";
		//String newManagersQuery = "select geid,supervisor_geid,supervisor_email from citi_contact where sso_id = 'GS71854'";
		
		List<GDWUser> users = new ArrayList<GDWUser>();
	    List<Map<String, Object>> rows = jdbcTemplateCCR.queryForList(newManagersQuery);
	
	    for (Map row : rows) {
			GDWUser user = new GDWUser();
			user.setGeid((String)(row.get("geId")));
			user.setFull_name((String)(row.get("Term_Emp_Name")));
			user.setFciid_1((String)row.get("Req_Id").toString());
			user.setFciid_2((String)row.get("Ccr_Id").toString());
			user.setSupervisor_geid((String)row.get("Latest_Supervisor_Geid"));
			user.setEmail((String) row.get("supervisor_email"));
			user.setDepartment_code((String) row.get("UserRole"));
			user.setDirect_manager1_name((String) row.get("Supervisor_Name"));
			users.add(user);
		}
	    
	    if(users !=null && users.size() > 0)
		{
			try {
			    log.info("email List "+ users.size());
				log.info("sending email To "+ users.get(0).getEmail());
				mailModuleImpl.sendEmailToSupervisorList(users);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			log.info("No employess to send email");
		}
		
	    	
		
	}

	public void updateGEID() {

		Set<String> ccrUserList = new HashSet<String>();
		String activeCCRUsersQuery = "select distinct sso_id from c3par.citi_contact where supervisor_first_name is null and supervisor_geid is  null and sso_id is not null";
		ccrUserList = new HashSet<String>(jdbcTemplateCCR.queryForList(
				activeCCRUsersQuery, String.class));
		log.info("active ccr users in citi contact -->" + ccrUserList.size());
		List<GDWUser> gdwUsersList = new ArrayList<GDWUser>();
		for (String geid : ccrUserList) {

			String terminatedGDWUsersQuery = "select SOEID,supervisor_geid from rdspr.gdw_user where upper(SOEID) =upper(?)";
			List<Map<String, Object>> rows = jdbcTemplateGDW.queryForList(
					terminatedGDWUsersQuery, geid);// ,new Object[]{ccrUserList}
			log.info(rows.size());
			for (Map row : rows) {
				GDWUser gdwUser = new GDWUser();
				gdwUser.setSoeid((String) row.get("SOEID"));
				gdwUser.setSupervisor_geid((String) row.get("supervisor_geid"));
				// gdwUser.setFirstname((String) row.get("FIRSTNAME"));
				// gdwUser.setLastname((String)row.get("LASTNAME"));

				gdwUsersList.add(gdwUser);
			}

			// updating citi_contacts table now using bulk update function of
			// jdbcTemplate

		}
		if (gdwUsersList != null && gdwUsersList.size() > 0) {
			batchUpdateGEID(gdwUsersList);
		}

	}

	public void updateName() {

		Set<String> ccrUserList = new HashSet<String>();
		String activeCCRUsersQuery = "select distinct supervisor_geid from c3par.citi_contact where supervisor_first_name is null and supervisor_geid is not null";
		ccrUserList = new HashSet<String>(jdbcTemplateCCR.queryForList(
				activeCCRUsersQuery, String.class));
		log.info("active ccr users in citi contact -->" + ccrUserList.size());
		List<GDWUser> gdwUsersList = new ArrayList<GDWUser>();
		for (String geid : ccrUserList) {

			String terminatedGDWUsersQuery = "select geid,FIRSTNAME,LASTNAME from rdspr.gdw_user where geid =?";
			List<Map<String, Object>> rows = jdbcTemplateGDW.queryForList(
					terminatedGDWUsersQuery, geid);// ,new Object[]{ccrUserList}
			log.info(rows.size());
			for (Map row : rows) {
				GDWUser gdwUser = new GDWUser();
				gdwUser.setGeid((String) row.get("geid"));

				gdwUser.setFirstname((String) row.get("FIRSTNAME"));
				gdwUser.setLastname((String) row.get("LASTNAME"));

				gdwUsersList.add(gdwUser);
			}

			// updating citi_contacts table now using bulk update function of
			// jdbcTemplate

		}
		if (gdwUsersList != null && gdwUsersList.size() > 0) {
			batchUpdateName(gdwUsersList);
		}

	}

	private void batchUpdateName(final List<GDWUser> employeeToBeUpdated) {

		// log.info("employeeToBeUpdated -->"+employeeToBeUpdated);

		String updateEmpStatusInCitiContactsQuery = "UPDATE C3PAR.CITI_CONTACT SET supervisor_first_name=?,supervisor_last_name=? WHERE supervisor_geid=?";

		try {
			// log.info("date "+employeeToBeUpdated.getBo_emp_term_date());

			int[] noofRowsUpdated = jdbcTemplateCCR.batchUpdate(
					updateEmpStatusInCitiContactsQuery,
					new BatchPreparedStatementSetter() {

						@Override
						public void setValues(PreparedStatement ps, int i)
								throws SQLException {
							ps.setString(1, employeeToBeUpdated.get(i)
									.getFirstname());
							ps.setString(2, employeeToBeUpdated.get(i)
									.getLastname());

							ps.setString(3, employeeToBeUpdated.get(i)
									.getGeid());
						}

						@Override
						public int getBatchSize() {
							// TODO Auto-generated method stub
							return employeeToBeUpdated.size();
						}
					});
			log.info("Total number of rows update " + noofRowsUpdated.length);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void batchUpdateGEID(final List<GDWUser> employeeToBeUpdated) {

		// log.info("employeeToBeUpdated -->"+employeeToBeUpdated);

		String updateEmpStatusInCitiContactsQuery = "UPDATE C3PAR.CITI_CONTACT SET supervisor_geid=? WHERE upper(sso_id)=upper(?)";

		try {
			// log.info("date "+employeeToBeUpdated.getBo_emp_term_date());

			int[] noofRowsUpdated = jdbcTemplateCCR.batchUpdate(
					updateEmpStatusInCitiContactsQuery,
					new BatchPreparedStatementSetter() {

						@Override
						public void setValues(PreparedStatement ps, int i)
								throws SQLException {
							/*
							 * ps.setString(1,employeeToBeUpdated.get(i).getFirstname
							 * ()); ps.setString(2,
							 * employeeToBeUpdated.get(i).getLastname());
							 */
							ps.setString(1, employeeToBeUpdated.get(i)
									.getSupervisor_geid());
							ps.setString(2, employeeToBeUpdated.get(i)
									.getSoeid());
						}

						@Override
						public int getBatchSize() {
							// TODO Auto-generated method stub
							return employeeToBeUpdated.size();
						}
					});
			log.info("Total number of rows update " + noofRowsUpdated.length);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	
	
	
	
	/**
	 * 
	 */
	//Get the list of connections with target contacts level less than 5
	public void getLevelForExistingIds(){
		
		log.info("Into getLevelForExistingIds method ");
		
		Set<String> geidList = new HashSet<String>();
		final List<String> gdwUsersList = new ArrayList<String>();
		
		//Get the list of contacts being used in existing connections
		String contactIds = "select distinct geid from c3par.citi_contact where id in ( "+
							"select distinct citi_contact_id from c3par.con_req_citi_contact_xref "+
							"union "+ 
							"select distinct citi_contact_id from c3par.con_req_cit_rqcon_xref) and geid is not null";
		geidList = new HashSet<String>(jdbcTemplateCCR.queryForList(
				contactIds, String.class));
		
		for (String geid : geidList) {
			//Get the level of the contact from GDW database
			String levelQuery = "select max(LEVEL) from rdspr.gdw_user start with geid=? connect by nocycle prior supervisor_geid = geid ";
			List<Map<String,Object>> level = jdbcTemplateGDW.queryForList(levelQuery, geid);
			log.debug("level in gdw" +level+ "geid" +geid);
			if(level!=null && level.size() < 5){
				gdwUsersList.add(geid);
			}
		}
			
		//Insert the GEID's of contacts whose level is less than 5 into a temp table
		 final String insertIntoTempTable = "INSERT INTO C3PAR.TEMP_CONTACT_LEVEL values (?)";
	       
			log.debug("insert sql:" +insertIntoTempTable);
			try{
				int[] noofRowsInserted = jdbcTemplateCCR.batchUpdate(insertIntoTempTable, new BatchPreparedStatementSetter() {
					
				 
					public void setValues(PreparedStatement pstmt, int i) throws SQLException {
						        pstmt.setString(1, gdwUsersList.get(i));
						        
					}
					
				 
					public int getBatchSize() {
						 return gdwUsersList.size();
					}
				});
				
				log.debug("No of rows inserted in temp table" +noofRowsInserted.length);
	
			}
			catch (DataAccessException e) {
				log.error(e, e);
			}
			
			//Get the connection ID,role ID,SSO ID of connections having contact less 5
			String existingConnList = "select distinct tp.id as CCRID, tr.version_number version ,r.display_name as role,cc.sso_id as SOEID, "
						+" CASE crccx.primary_contact WHEN 'Y' THEN 'Yes' ELSE 'No' END AS PRIMARYCONTACT,  "
						+" CASE crccx.notify_contact WHEN '1' THEN 'Yes' ELSE 'No' END AS NOTIFYCONTACT "
						+" from c3par.ti_request tr  "
						+" join c3par.ti_process tp on tp.id=tr.process_id  "
						+" join c3par.TI_REQUEST_PLANNING_XREF TRPX on tr.id=trpx.ti_request_id " 
						+" join c3par.planning p on p.id=trpx.planning_id  "
						+" join c3par.con_req_citi_contact_xref crccx on p.id=crccx.REQUEST_ID " 
						+" join c3par.citi_contact cc on crccx.citi_contact_id= cc.id  "
						+" join c3par.temp_contact_level tcl on tcl.contact_id=cc.geid  "
						+" join c3par.role r on r.id = crccx.role_id and crccx.role_id not in(39) "
						+" union "
						+" select distinct tp.id as CCRID, tr.version_number version ,r.display_name as role,cc.sso_id as SOEID, "
						+" CASE crccx.primary_contact WHEN 'Y' THEN 'Yes' ELSE 'No' END AS PRIMARYCONTACT,  "
						+" CASE crccx.notify_contact WHEN '1' THEN 'Yes' ELSE 'No' END AS NOTIFYCONTACT "
						+" from c3par.ti_request tr  "
						+" join c3par.ti_process tp on tp.id=tr.process_id " 
						+" join c3par.TI_REQUEST_PLANNING_XREF TRPX on tr.id=trpx.ti_request_id " 
						+" join c3par.planning p on p.id=trpx.planning_id  "
						+" join C3PAR.con_req_cit_rqcon_xref crccx on p.id=crccx.REQUEST_ID " 
						+" join c3par.citi_contact cc on crccx.citi_contact_id= cc.id  "
						+" join c3par.temp_contact_level tcl on tcl.contact_id=cc.geid  "
						+" join c3par.role r on r.id = crccx.role_id and crccx.role_id not in(39) ";
			
			List<Map<String, Object>> dd = jdbcTemplateCCR.queryForList(existingConnList);
			log.debug("No of connections having contact level <5" +dd.size());
			
			log.info("getLevelForExistingIds method ends");
	
	}
	
	

}
