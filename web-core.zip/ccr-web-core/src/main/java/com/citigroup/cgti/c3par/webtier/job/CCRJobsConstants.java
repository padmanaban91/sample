/**
 * 
 */
package com.citigroup.cgti.c3par.webtier.job;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author ka58098
 *
 */
public interface CCRJobsConstants {
	public static final String MIGRATION_JOB = "migrationServiceJob";
	public static final String MIGRATION_JOB_GROUP = "migrationServiceJobGroup";
	public static final String MIGRATION_TRIGGER = "migrationServiceTrigger";
	public static final String MIGRATION_TRIGGER_GROUP = "migrationServiceTriggerGroup";
	public static final String ACV_INITIATE_JOB = "acvInitiateJob";
	public static final String ACV_INITIATE_JOB_GROUP = "acvInitiateJobGroup";
	public static final String ACV_INITIATE_TRIGGER = "acvInitiateTrigger";
	public static final String ACV_INITIATE_TRIGGER_GROUP = "acvInitiateTriggerGroup";
	public static final String ACCESSFORM_JOB = "accessFormRemainderJob";
	public static final String ACCESSFORM_JOB_GROUP = "accessFormRemainderJobGroup";
	public static final String ACCESSFORM_TRIGGER = "accessFormRemainderTrigger";
	public static final String ACCESSFORM_TRIGGER_GROUP = "accessFormRemainderGroup";
	public static final String APPROVALFORM_JOB = "approvalRemainderJob";
	public static final String APPROVALFORM_JOB_GROUP = "approvalRemainderJobGroup";
	public static final String APPROVALFORM_TRIGGER = "approvalRemainderTrigger";
	public static final String APPROVALFORM_TRIGGER_GROUP = "approvalRemainderTriggerGroup";
	public static final String ACTIVITY_EXPIRY_JOB = "activityExpirationJob";
	public static final String ACTIVITY_EXPIRY_JOB_GROUP = "activityExpirationJobGroup";
	public static final String ACTIVITY_EXPIRY_TRIGGER = "activityExpirationTrigger";
	public static final String ACTIVITY_EXPIRY_TRIGGER_GROUP = "activityExpirationTriggerGroup";
	public static final String CITI_CONTACT_UPDATE_JOB = "citiContactUpdateJob";
	public static final String CITI_CONTACT_UPDATE_JOB_GROUP = "citiContactUpdateJobGroup";
	public static final String CITI_CONTACT_UPDATE_TRIGGER = "citiContactUpdateTrigger";
	public static final String CITI_CONTACT_UPDATE_TRIGGER_GROUP = "citiContactUpdateTriggerGroup";
	public static final String CITI_CONTACT_REFRESH_JOB = "citiContactRefreshJob";
	public static final String CITI_CONTACT_REFRESH_JOB_GROUP = "citiContactRefreshJobGroup";
	public static final String CITI_CONTACT_REFRESH_TRIGGER = "citiContactRefreshTrigger";
	public static final String CITI_CONTACT_REFRESH_TRIGGER_GROUP = "citiContactRefreshTriggerGroup";
	public static final String CLEAR_REPORT_TABLES_JOB = "clearReportTablesJob";
	public static final String CLEAR_REPORT_TABLES_JOB_GROUP = "clearReportTablesJobGroup";
	public static final String CLEAR_REPORT_TABLES_TRIGGER = "clearReportTablesTrigger";
	public static final String CLEARREPORT_TABLES_TRIGGER_GROUP = "clearReportTablesGroup";
	public static final String USER_GROUP_DETAIL_JOB = "userGroupDetailJob";
	public static final String USER_GROUP_DETAIL_JOB_GROUP = "userGroupDetailJobGroup";
	public static final String USER_GROUP_DETAIL_TRIGGER = "userGroupDetailTrigger";
	public static final String USER_GROUP_DETAIL_TRIGGER_GROUP = "userGroupDetailGroup";
	public static final String CSI_APPLICATION_SYNCH_JOB = "csiApplicationSynchJob";
	public static final String CSI_APPLICATION_SYNCH_JOB_GROUP = "csiApplicationSynchJobGroup";
	public static final String CSI_APPLICATION_SYNCH_TRIGGER = "csiApplicationSynchTrigger";
	public static final String CSI_APPLICATION_SYNCH_TRIGGER_GROUP = "csiApplicationSynchTriggerGroup";
	public static final String ACV_EXPIRY_MAIL_JOB = "acvExpirationMailJob";
	public static final String ACV_EXPIRY_MAIL_JOB_GROUP = "acvExpirationMailJobGroup";
	public static final String ACV_EXPIRY_MAIL_TRIGGER = "acvExpirationMailTrigger";
	public static final String ACV_EXPIRY_MAIL_TRIGGER_GROUP = "acvExpirationMailTriggerGroup";
	public static final String RFC_NETINFO_JOB = "rfcNetInfoJob";
	public static final String RFC_NETINFO_JOB_GROUP = "rfcNetInfoJobGroup";
	public static final String RFC_NETINFO_TRIGGER = "rfcNetInfoTrigger";
	public static final String RFC_NETINFO_TRIGGER_GROUP = "rfcNetInfoTriggerGroup";
	public static final String PURGE_LOG_TEXT_JOB = "purgeLogTextJob";
	public static final String PURGE_LOG_TEXT_JOB_GROUP = "purgeLogTextJobGroup";
	public static final String PURGE_LOG_TEXT_TRIGGER = "purgeLogTextTrigger";
	public static final String PURGE_LOG_TEXT_TRIGGER_GROUP = "purgeLogTextTriggerGroup";
	public static final String ONE_WEEK_NTP_JOB = "oneWeekNTPJob";
	public static final String ONE_WEEK_NTP_JOB_GROUP = "oneWeekNTPJobGroup";
	public static final String ONE_WEEK_NTP_TRIGGER = "oneWeekNTPTrigger";
	public static final String ONE_WEEK_NTP_TRIGGER_GROUP = "oneWeekNTPTriggerGroup";
	public static final String JOB_CRONEXPRESSION = "jobCronExpression";

	@SuppressWarnings("serial")
    public static final Map<String, String> JOB_NAMES_GROUPS = Collections
			.unmodifiableMap(new LinkedHashMap<String, String>() {
				{
					put(MIGRATION_JOB, MIGRATION_JOB_GROUP);
					put(ACV_INITIATE_JOB, ACV_INITIATE_JOB_GROUP);
					put(ACCESSFORM_JOB, ACCESSFORM_JOB_GROUP);
					put(APPROVALFORM_JOB, APPROVALFORM_JOB_GROUP);
					put(ACTIVITY_EXPIRY_JOB, ACTIVITY_EXPIRY_JOB_GROUP);
					put(CITI_CONTACT_UPDATE_JOB, CITI_CONTACT_UPDATE_JOB_GROUP);
					put(CITI_CONTACT_REFRESH_JOB, CITI_CONTACT_REFRESH_JOB_GROUP);
					put(ACV_EXPIRY_MAIL_JOB, ACV_EXPIRY_MAIL_JOB_GROUP);
					put(PURGE_LOG_TEXT_JOB, PURGE_LOG_TEXT_JOB_GROUP);
					put(CSI_APPLICATION_SYNCH_JOB, CSI_APPLICATION_SYNCH_JOB_GROUP);
					put(ONE_WEEK_NTP_JOB, ONE_WEEK_NTP_JOB_GROUP);
					put(CLEAR_REPORT_TABLES_JOB, CLEAR_REPORT_TABLES_JOB_GROUP);
					put(RFC_NETINFO_JOB, RFC_NETINFO_JOB_GROUP);
					put(USER_GROUP_DETAIL_JOB, USER_GROUP_DETAIL_JOB_GROUP);
				}
			});
	

}
