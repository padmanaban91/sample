package com.citigroup.cgti.c3par.fw.fireflow.exception;

public class FireflowSSLProtocolIntializationError extends Error {

	public FireflowSSLProtocolIntializationError() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FireflowSSLProtocolIntializationError(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FireflowSSLProtocolIntializationError(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FireflowSSLProtocolIntializationError(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
