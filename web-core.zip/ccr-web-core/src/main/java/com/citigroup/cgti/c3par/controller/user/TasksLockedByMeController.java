package com.citigroup.cgti.c3par.controller.user;

import java.io.StringReader;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.citigroup.cgti.c3par.bpm.ejb.search.domain.GeneralSearchAttributes;
import com.citigroup.cgti.c3par.search.domain.SearchProcess;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class TasksLockedByMeController {

	private Logger log = Logger.getLogger(this.getClass().getName());

	@RequestMapping(value = "/loadMyTasksController.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadMyTasks(ModelMap model, HttpServletRequest request,
			@ModelAttribute("SearchProcess") SearchProcess searchProcess,
			BindingResult result) {
		log.debug("Entering into loadMyTasks::");
		loadMyTasks(false, model, request, searchProcess, result);

		log.debug("Exiting from loadMyTasks::");
		return "c3par.mytasks.on.main.menu";
	}

	private String loadMyTasks(boolean isExport, ModelMap model,
			HttpServletRequest request, SearchProcess searchProcess,
			BindingResult result) {
		log.info("TasksLockedByMeController::loadMyTasks method starts changed");

		GeneralSearchAttributes generalSearchAttributes = new GeneralSearchAttributes();

		if (searchProcess == null) {
			searchProcess = new SearchProcess();
		}
		List lst = null;
		try {
			if (request.getParameter("result") != null
					&& !request.getParameter("result").trim().equals("")) {
				log.debug("Result:loadMyTasks::"
						+ request.getParameter("result"));
				DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
						.newInstance();
				DocumentBuilder docBuilder = docBuilderFactory
						.newDocumentBuilder();
				InputSource is = new InputSource(new StringReader(request
						.getParameter("result").trim()));
				Document doc = docBuilder.parse(is);
				NodeList nl = doc.getElementsByTagName("BpmInstance");
				String status = getNodeValue("Status", nl);
				String instanceId = getNodeValue("InstanceId", nl);
				String errorMessage = getNodeValue("ErrorMessage", nl);
				String pageNo = request.getParameter("pageNumber");
				log.debug("status:loadMyTasks::" + status + "pageNo:" + pageNo
						+ "instanceId:" + instanceId);
				if ("Successful".equalsIgnoreCase(status.trim())
						&& !"".equalsIgnoreCase(status.trim())) {
					Util util = new Util();
					util.unlockActivity(instanceId.trim());
				} else {
					searchProcess.setUnlockErrorMsg(getNodeValue(
							"ExceptionMessage", nl));
					searchProcess
							.validate("Tasks -"
									+ searchProcess.getBmpInstanceId()
									+ "ErrorMessage");

				}
				if (pageNo != null && !pageNo.trim().equals("")) {
					searchProcess.setPageNo(new Integer(pageNo.trim()));
				}

			}

			if (request.getSession().getAttribute("ssoId") != null
					&& !((String) request.getSession().getAttribute("ssoId"))
							.isEmpty()) {
				generalSearchAttributes.setRequesterSOEId((String) request
						.getSession().getAttribute("ssoId"));
				log.debug("ssoid from sesssion:"
						+ request.getSession().getAttribute("ssoId"));
			}
			if (generalSearchAttributes.getRequesterSOEId() == null
					|| generalSearchAttributes.getRequesterSOEId().isEmpty()) {
				generalSearchAttributes.setRequesterSOEId(request.getHeader("SM_USER"));
			}
			searchProcess.setGeneralSearchAttributes(generalSearchAttributes);
			searchProcess.setSearchType("MY_TASK");
			if (searchProcess.getPageNo() == null
					|| searchProcess.getPageNo() == 0) {
				log.debug("Page size is null");
				searchProcess.setPageNo(1);
			}

			log.debug("generalSearchAttributes.getRequesterSOEId():"
					+ generalSearchAttributes.getRequesterSOEId());
			Integer totalPages = searchProcess.getSearchRecordCount();
			searchProcess.setPageSize(10);
			if (isExport) {
				// get all results for export
				searchProcess.setPageSize(totalPages);
			}
			log.debug("TasksLockedByMeController::loadMytasks.totalPages:"
					+ totalPages);
			if (totalPages.intValue() == 0) {
				totalPages = 0;
			} else if (totalPages.intValue() / 10 == 0) {
				totalPages = 1;
			} else if (totalPages.intValue() % 10 > 0) {
				totalPages = totalPages.intValue() / 10 + 1;
			} else if (totalPages.intValue() % 10 == 0) {
				totalPages = totalPages.intValue() / 10;
			}
			log.debug("TasksLockedByMeController::loadMyTasks method:totalpages:"
					+ totalPages);
			searchProcess.setTotalPages(totalPages);

			lst = searchProcess.getProcessList();
			searchProcess.setProcessList(lst);

			request.getSession().setAttribute("PROCESSLIST", lst);
			request.getSession().setAttribute("TOTALPAGES", totalPages);

			if (searchProcess.getTotalPages() == null
					|| (searchProcess.getTotalPages() != null && searchProcess
							.getTotalPages().intValue() == 0)) {
				searchProcess.setPageNo(0);
			}
			log.debug("TasksLockedByMeController::loadMyTasks method :After getting processing List");

		} catch (Exception ex) {

			log.error(ex, ex);
			ObjectError error = new ObjectError("name",
					"Exception has occurred");
			result.addError(error);

		}
		model.addAttribute("processList", lst);
		model.addAttribute("searchProcess", searchProcess);
		log.info("TasksLockedByMeController::loadMyTasks method ends ");
		return "c3par.mytasks.on.main.menu";
	}

	private String getNodeValue(String tagName, NodeList nodes) {
		for (int x = 0; x < nodes.getLength(); x++) {
			Node node = nodes.item(x);
			NodeList childNodes = node.getChildNodes();
			for (int y = 0; y < childNodes.getLength(); y++) {
				Node data = childNodes.item(y);
				System.out.println("NodeName:" + data.getNodeName());
				if (data.getNodeName().equalsIgnoreCase(tagName)) {
					return data.getTextContent();
				}
			}
		}
		return "";
	}

	@RequestMapping(value = "/loadexportMyTasks.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String exportMyTasks(ModelMap model, HttpServletRequest request,
			SearchProcess searchProcess, BindingResult result) {
		loadMyTasks(true, model, request, searchProcess, result);
		return "pages/user/exportMyTask";
	}
}
