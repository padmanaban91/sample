package com.citigroup.cgti.c3par.relationship.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnitLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiContXref;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiHierarchyXref;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.RelReqCitiContactXref;
import com.citigroup.cgti.c3par.relationship.domain.RelReqCitiLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.RelThirdPartyContXref;
import com.citigroup.cgti.c3par.relationship.domain.RelTpLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.RelationshipProcess;
import com.citigroup.cgti.c3par.relationship.domain.ResourceTypeLocXref;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.relationship.domain.ThirdParty;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.soc.persist.RelationshipServicePersistable;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.util.C3parStaticNames;

/**
 * @author pc79439
 * 
 */
@SuppressWarnings({ "unchecked", "unused" })
@Transactional
public class RelationshipServiceImpl extends BasePersistanceImpl implements RelationshipServicePersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(RelationshipServiceImpl.class);
	public static final String TI_REQUEST_ID="tiRequestId";
	public static final String COUNT="count";
	public static final String PROCESSNAME="processName";
	public static final String STATUS="status";
	public static final String ID="id";
	public static final String TAR_RES_TYPE="targetResourceTypeId";
	public static final String REQ_RES_TYPE="sourceResourceTypeId";
	@Override
	@Transactional(readOnly = true)
	public List<Relationship> getRelationshipList(RelationshipProcess relationshipProcess) {
		Session session = getSession();
		Criteria criteria = session.createCriteria(Relationship.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.addOrder(Order.asc("id"));
		relationshipProcess.setRowCount(getRowCount(criteria));
		
		if(relationshipProcess.isPaginationRequired()){
			addPagination(criteria, relationshipProcess.getOffset(), relationshipProcess.getLimit());
		}
		List<Relationship> list = criteria.list();
		
		if(list != null)
			log.debug("RelationshipServiceImpl :: getRelationshipList :: size ::"+list.size());
		
		return list;
	}

	@Override
	@Transactional(readOnly = true)
	public List<Region> getRegionList(){
		Session session = getSession();
		Criteria criteria = session.createCriteria(Region.class);
		criteria.add(Restrictions.eq("isactive", "Y"));
		criteria.addOrder(Order.asc("id"));

		List<Region> list = criteria.list();		
		if(list != null)
			log.debug("RelationshipServiceImpl :: getRegionList :: size ::"+list.size());
		
		return list;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<Sector> getSectorList(String regionIDs){
		Session session = getSession();
		
		StringBuffer queryString = new StringBuffer();
		queryString.append(" select distinct sec.* from CITI_HIERARCHY_MASTER citimaster join SECTOR sec on citimaster.sector_id = sec.id where");
		if (regionIDs != null && !regionIDs.isEmpty() && !"ALL".equalsIgnoreCase(regionIDs)) {
			queryString.append(" citimaster.region_id in ("+regionIDs+") and ");
		}
		queryString.append(" sec.is_active = 'Y' group by sec.id,sec.name,sec.is_active,sec.description order by sec.name ");
		
		SQLQuery query = session.createSQLQuery(queryString.toString());
		query.addEntity("sec", Sector.class);
		
		List<Sector> list = query.list();		
		if(list != null)
			log.debug("RelationshipServiceImpl :: getSectorList :: size ::"+list.size());
		
		return list;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<BusinessUnit> getBusinessUnitList(String regionIDs, Long sectorID){
		Session session = getSession();

		StringBuffer queryString = new StringBuffer();
		queryString.append(" select distinct bu.* from CITI_HIERARCHY_MASTER citimaster join BUSINESS_UNIT bu on citimaster.bu_id = bu.id ");
		queryString.append(" where citimaster.region_id in("+regionIDs+") and citimaster.sector_id = "+sectorID+" and bu.is_active = 'Y' order by bu.business_name ");
		
		SQLQuery query = session.createSQLQuery(queryString.toString());
		query.addEntity("bu", BusinessUnit.class);

		List<BusinessUnit> list = query.list();	
		if(list != null)
			log.debug("RelationshipServiceImpl :: getBusinessUnitList :: size ::"+list.size());
		
		return list;
	}	
	
	@Transactional(readOnly = true)
	public List<ResourceType> getResourceTypeByPerimeter(String perimeter){
		Session session = getSession();

		Criteria criteria = session.createCriteria(ResourceType.class);
		criteria.add(Restrictions.eq("status", "Active"));
		criteria.add(Restrictions.ne("name", "Template"));
		criteria.add(Restrictions.ne("name", "Port Template"));
		criteria.add(Restrictions.ne("name", "IP Template"));
		criteria.add(Restrictions.ne("name", "IP Reg ACL"));
		criteria.add(Restrictions.eq("perimeter", perimeter));
		criteria.addOrder(Order.asc("id"));

		List<ResourceType> list = criteria.list();
		if(list != null)
			log.debug("RelationshipServiceImpl :: getResourceTypeByPerimeter :: size ::"+list.size());
		
		return list;
	}

	@Transactional(readOnly = true)
	public ResourceType getResourceTypeByName(String resTypeName){
		Session session = getSession();
		
		ResourceType resType = null;
		Criteria criteria = session.createCriteria(ResourceType.class);
		criteria.add(Restrictions.eq("status", "Active"));
		criteria.add(Restrictions.eq("name", resTypeName));

		List<ResourceType> list = criteria.list();
		if(list != null && list.size() > 0){
			resType = list.get(0);
			log.debug("RelationshipServiceImpl :: getResourceTypeByName :: size ::"+list.size());
		}
		
		return resType;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<Region> getRegionForIds(String regionIds) {		
		Session session = getSession();
		
		SQLQuery query = session.createSQLQuery("select reg.* from region reg where reg.id in ("+regionIds+")");
		query.addEntity("reg", Region.class);
		
		List<Region> reglist = query.list();		
		if(reglist != null)
			log.debug("RelationshipServiceImpl :: getSectorList :: size ::"+reglist.size());
		
		return reglist;
	}
	
	@Override
	@Transactional(readOnly = true)
	public Sector getSectorForId(Long sectorId){
		Session session = getSession();
		Sector sec = (Sector) session.get(Sector.class, sectorId);
		
		return sec;
	}
	
	@Override
	@Transactional(readOnly = true)
	public BusinessUnit getBusinessUnitForId(Long businessUnitId){
		Session session = getSession();
		BusinessUnit bu = (BusinessUnit) session.get(BusinessUnit.class, businessUnitId);
		
		return bu;
	}

	@Override
	@Transactional(readOnly = true)
	public ResourceType getResourceType(Long resourceTypeId){
		Session session = getSession();
		ResourceType restypeid = (ResourceType) session.get(ResourceType.class, resourceTypeId);
		
		return restypeid;
	}

    @Override
    public Long saveRelationshipDetails(Relationship relationship){
    	Long relationshipId = 0L;
    	log.info(" relationship name ::"+relationship.getName());
    	if(relationship != null && (relationship.getId() == null || relationship.getId().longValue() == 0)){
    		relationshipId = (Long) getHibernateTemplate().save(relationship);
    	}
    	log.info("RelationshipServiceImpl :: saveRelationshipDetails :: relationshipId ::"+relationshipId);
    	return relationshipId;
    }
    
    @Override
	public Long getRelationshipId(Long tiRequestId) {
    	List<Long> resultList=null;
    	try{
    	Session session = getSession();
    	SQLQuery sqlQuery=session.createSQLQuery(QueryConstants.RELATIONSHIP_ID);
    	sqlQuery.setLong("tiRequestId", tiRequestId);
    	sqlQuery.addScalar("relId", LongType.INSTANCE);
    	resultList=sqlQuery.list();
    	if(!CollectionUtils.isEmpty(resultList))
    		return resultList.get(0);
    	}catch(Exception ex){
    		log.error("Error has occurred in getRelationshipId():: "+ex.toString());
    	}
    	return null;
	}
    
    private boolean isRecordAvailable(Long tiRequestId,String query){
    	Integer isRecordAvailable;
    	try{
    		Session session = getSession();
    		SQLQuery sqlQuery=session.createSQLQuery(query);
        	sqlQuery.setLong(TI_REQUEST_ID, tiRequestId);
        	sqlQuery.addScalar(COUNT, IntegerType.INSTANCE);
        	log.info("isRecordAvailable sqlQuery value :: "+sqlQuery.toString());
        	isRecordAvailable = (Integer)sqlQuery.uniqueResult();
    		if(isRecordAvailable != null && isRecordAvailable.intValue() > 0)
    			return true;
    	}catch(Exception ex){
		log.error("Error has occurred in isRecordAvailable():: "+ex.toString());
    	}
    	return false;
    }
    @Override
	public boolean relationshipBusValidation(Long tiRequestId){
    	try{
    		if(isRecordAvailable(tiRequestId,QueryConstants.CHECK_VERSION))
    			return true;
    		if(isRecordAvailable(tiRequestId,QueryConstants.CON_FW_RULE))
    			return true;
    		if(isRecordAvailable(tiRequestId,QueryConstants.PROXY_FILTER))
    			return true;
    		if(isRecordAvailable(tiRequestId,QueryConstants.ACL_VARIANCE))
    			return true;
    		if(isRecordAvailable(tiRequestId,QueryConstants.APS_APPSENSE))
    			return true;
    		
    	}catch(Exception ex){
		log.error("Error has occurred in relationshipBusValidation():: "+ex.toString());
    	}
    	return false;
	}
    @Override
    public CitiHierarchyMaster getcitiHierarchyMaster(Long regId, Long secId, Long buId){
		Session session = getSession();

		Criteria criteria = session.createCriteria(CitiHierarchyMaster.class);	
	    criteria.createCriteria("region", "region");
	    criteria.add(Restrictions.eq("region.id", regId));
	    criteria.createCriteria("sector", "sector");
	    criteria.add(Restrictions.eq("sector.id", secId));
	    criteria.createCriteria("businessUnit", "businessUnit");
	    criteria.add(Restrictions.eq("businessUnit.id", buId));
	    
		List<CitiHierarchyMaster> list = criteria.list();
		if(list != null && list.size() > 0){
			log.debug("RelationshipServiceImpl :: getcitiHierarchyMaster :: size ::"+list.size());
			return list.get(0);
		}
		
		return null;
    }
    
    @Override
    public void saveRegSecBuForRel(Long relId, String regionIds, Long secId, Long buId){
    	Session session = getSession();
		log.info("RelationshipServiceImpl :: saveRegSecBuForRel :: relId -"+relId+":: regionIds -"+regionIds+":: secId -"+secId+":: buId -"+buId);
    	
    	List<Region> reglist = getRegionForIds(regionIds);    	
    	Relationship rel = (Relationship) session.get(Relationship.class, relId);
    	
    	for(Region reg:reglist){
    		CitiHierarchyMaster citihiermas = getcitiHierarchyMaster(reg.getId(), secId, buId);
    		if(citihiermas != null){
    			boolean isNew = true;
    			
    			if(rel.getRelcitiHierarchyXrefs() != null){
	    			for(RelCitiHierarchyXref relcitiHierarchyXrefs:rel.getRelcitiHierarchyXrefs()){
	    				CitiHierarchyMaster existingcitihiermas = relcitiHierarchyXrefs.getCitiHierarchyMaster();
	    				
	    				if(existingcitihiermas.getRegion().getId().longValue() == citihiermas.getRegion().getId().longValue()
	    						&& existingcitihiermas.getSector().getId().longValue() == citihiermas.getSector().getId().longValue()
	    	    						&& existingcitihiermas.getBusinessUnit().getId().longValue() == citihiermas.getBusinessUnit().getId().longValue()){
	    					isNew = false;
	    					break;
	    				}
	    			}
    			}
    			if(isNew){
	    			RelCitiHierarchyXref relxref = new RelCitiHierarchyXref();
	    			relxref.setCitiHierarchyMaster(citihiermas);
	    			relxref.setRelationship(rel);
	    			
	    			Long relxrefid = (Long) getHibernateTemplate().save(relxref);
	    			log.info("RelationshipServiceImpl :: saveRegSecBuForRel :: relxrefid ::"+relxrefid);
    			}
    		}
    	}   	
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean validateRegSecBu(String regionIds, Long secId, Long buId){
    	log.info("ManageRelationshipAction::RelationshipServiceImpl::validateRegSecBu starts...");
		Session session = getSession();
		
		int regCount = 0;
		if(regionIds != null){
			regCount = regionIds.split(",").length;
		}
		
		SQLQuery query = session.createSQLQuery("select count(*) as count from CITI_HIERARCHY_MASTER where region_id in ("+regionIds+") and sector_id = "+secId+" and bu_id = "+buId+" having count(*) = "+regCount);
		query.addScalar("count", IntegerType.INSTANCE);
		Integer isRecordAvailable = (Integer)query.uniqueResult();
		
		if(isRecordAvailable != null && isRecordAvailable.intValue() > 0)
			return true;
		else 
			return false;
    }
    
    @Override
    @Transactional(readOnly = true)
    public Relationship getRelationship(Long relId){
		Session session = getSession();
		Relationship rel =   (Relationship) session.createQuery( "from Relationship rel where rel.id=" + relId).uniqueResult();
		if(rel != null && rel.getRequesterId() != null && rel.getRequesterId().length() > 0){
			C3parUser usr =   (C3parUser) session.createQuery( "from C3parUser usr where upper(usr.ssoId)=upper(?) ").setString(0,rel.getRequesterId()).uniqueResult();
			rel.setRequesterName(usr.getFirstName()+" "+usr.getLastName());
		}
		return rel;
    }
    
    @Override
    @Transactional(readOnly = true)
	public TIProcess getConnectionDetails(Long conId) {
    	Session session = getSession();
    	TIProcess tiProcess=null;
    	try{
    		tiProcess =   (TIProcess) session.createQuery( "from TIProcess tiProcess where tiProcess.id=" + conId).uniqueResult();
    	}catch(Exception e){
    		log.error("Error has occurred in getConnectionDetails method :: "+e.toString());
    	}
    	return tiProcess;
	}

	@Override
	@Transactional(readOnly = true)
	public List getProcessName(Long tiRequestId) {
		List resultList = null;
		try {
			Session session = getSession();
			resultList = session.createSQLQuery(QueryConstants.CONNECTION_NAME).setLong(TI_REQUEST_ID, tiRequestId)
					.list();

		} catch (Exception e) {
			log.error("Error has occurred  in getProcessName method ::" + e.toString());
		}
		return resultList;
	}

	@Override
	public void updateConnectionName(String connectionName, Long conId) {
		try {
			Session session = getSession();
			session.createQuery(QueryConstants.UPDATE_CONNECTION_NAME).setString(PROCESSNAME, connectionName)
					.setLong(ID, conId).executeUpdate();

		} catch (Exception e) {
			log.error("Error has occurred  in updateConnectionName method ::" + e.toString());
		}
	}
	@Override
	public void updateRelationshipStatus(Long relId, String status){
		try {
			Session session = getSession();
			session.createQuery(QueryConstants.UPDATE_RELATIONSHIP_STATUS).setString(STATUS, status)
					.setLong(ID, relId).executeUpdate();

		} catch (Exception e) {
			log.error("Error has occurred  in updateRelationshipStatus method ::" + e.toString());
		}
	}
    @Override
    @Transactional(readOnly = true)
    public List<RelCitiHierarchyXref> getRelationshipCitiHierarchy(Long relId){
		Session session = getSession();
		List<RelCitiHierarchyXref> lst =  (List<RelCitiHierarchyXref>)session.createQuery( "from RelCitiHierarchyXref xref where xref.relationship.id=" + relId).list();
		
		return lst;    	
    }

    @Override
    @Transactional(readOnly = true)
    public String getRelationshipStatus(Long relId){
    	String relStatus = "";

		StringBuffer statusSQL = new StringBuffer();
		statusSQL.append("select rel.STATUS relstatus from RELATIONSHIP rel where rel.ID = " + relId);
    	SQLQuery query = getSession().createSQLQuery(statusSQL.toString());
    	query.addScalar("relstatus",StringType.INSTANCE);
    	relStatus = String.valueOf(query.uniqueResult());
    	
    	return relStatus;
    }
    
    @Override
    public void updateRelationshipDetails(Relationship relationship,String regionIds, Long secId, Long buId){
    			
		if(relationship.getRelationshipType() != null && !relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.U_TURN) ){
			relationship.setUturnThirdParty(null);
		}
		
		Relationship oldRelationship = getHibernateTemplate().load(Relationship.class, relationship.getId());
        getHibernateTemplate().merge(relationship);

    	SQLQuery query1 = getSession().createSQLQuery("delete from REL_CITI_HIERARCHY_XREF where RELATIONSHIP_ID = "+relationship.getId());
		int rows = query1.executeUpdate();
		log.debug("RelationshipServiceImpl::delete REL_CITI_HIERARCHY_XREF - "+rows); 
		
		log.debug("RelationshipServiceImpl::updateRelationshipDetails... ");  
		
    }
    
    @Override
    public void deleteRelationshipDetails(Relationship relationship){
		Session session = getSession();

    	SQLQuery query = getSession().createSQLQuery("delete from REL_CITI_HIERARCHY_XREF where RELATIONSHIP_ID = "+relationship.getId());
		int rows = query.executeUpdate();
		log.debug("RelationshipServiceImpl::deleteRelationshipDetails....REL_CITI_HIERARCHY_XREF - "+rows); 
		
    	SQLQuery query1 = getSession().createSQLQuery("delete from RELATIONSHIP where ID = "+relationship.getId());
		rows = query1.executeUpdate();
		log.debug("RelationshipServiceImpl::deleteRelationshipDetails....RELATIONSHIP - "+rows);  	
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean isRelationshipUsedInCon(Relationship relationship){
    	log.info("RelationshipServiceImpl::isRelationshipUsedInCon starts...");
		Session session = getSession();
		
		SQLQuery query = session.createSQLQuery("select count(*) as count from TI_PROCESS where RELATIONSHIP_ID = "+relationship.getId());
		query.addScalar("count", IntegerType.INSTANCE);
		Integer isRecordAvailable = (Integer)query.uniqueResult();
		
		if(isRecordAvailable != null && isRecordAvailable.intValue() > 0)
			return true;
		else 
			return false;
    }
    @Override
	public void updateResourceType(Long relId, Long sourceResourceTypeId, Long targetResourceTypeId) {
    	try{
    	Session session=getSession();
    	int i=session.createQuery(QueryConstants.UPDATE_RESOURCE_TYPE).setLong(ID,relId).setLong(REQ_RES_TYPE, sourceResourceTypeId).setLong(TAR_RES_TYPE, targetResourceTypeId).executeUpdate();
    	log.info("update resource type value ::"+i);
    	}catch(Exception e){
    		log.error("Error has occurred while update resource type in relationship table::"+e.toString());
    	}
	}
    @Override
    public boolean updateRelResourceType(Long relId, String relName, Long sourceResourceTypeId, Long targetResourceTypeId){
    	log.info("RelationshipServiceImpl::updateRelResourceType starts...");
    	boolean isSuccess = true;
		Session session = getSession();

		String newRelationShipTypeName = null;
		String newSourceRelationShipTypeName = null;
		String RelationShipName = null;
		String oldRelationShipType = null;
		String oldSourceRelationShipType = null;
		
    	String resourceTypeNameSQL = "Select a.name as Name1, b.name as Name2 from ResourceType a, ResourceType b where a.id="+targetResourceTypeId+" and b.id="+sourceResourceTypeId;
    	log.debug("RelationshipServiceImpl::updateRelResourceType:: resourceTypeNameSQL-"+resourceTypeNameSQL);

		SQLQuery query = session.createSQLQuery(resourceTypeNameSQL);
		query.addScalar("Name1", StringType.INSTANCE);
		query.addScalar("Name2", StringType.INSTANCE);
		List<Object[]> rows = query.list();
  	  
		if(rows != null){
			for (Object[] obj : rows) {
				newRelationShipTypeName = (String)obj[0];
				newSourceRelationShipTypeName = (String)obj[1];
			}
		}
    	
    	String relationshipSQL = "Select a.name as Name1, b.name as Name2, c.name as Name3 from Relationship a, ResourceType b , ResourceType c where a.requester_resource_type_id = c.id and a.target_resource_type_id=b.id and a.id="+relId;
    	log.debug("RelationshipServiceImpl::updateRelResourceType:: relationshipSQL-"+relationshipSQL);

		SQLQuery query1 = session.createSQLQuery(relationshipSQL);
		query.addScalar("Name1", StringType.INSTANCE);
		query.addScalar("Name2", StringType.INSTANCE);
		query.addScalar("Name3", StringType.INSTANCE);
		List<Object[]> rows1 = query1.list();
  	  
		if(rows1 != null){
			for (Object[] obj : rows1) {
				RelationShipName = (String)obj[0];
				oldRelationShipType = (String)obj[1];
				oldSourceRelationShipType = (String)obj[2];
			}
		}

		if (RelationShipName == null) {
			RelationShipName = relName;
		}
		//if (relName == null) {
			RelationShipName = getNewRelationshipName(RelationShipName, oldRelationShipType, newRelationShipTypeName, oldSourceRelationShipType, newSourceRelationShipTypeName);
		//} else {
		//	RelationShipName = relName;
		//}

    	String relationshipUpdateSQL = "update Relationship set TARGET_RESOURCE_TYPE_ID = "+targetResourceTypeId+", name = '"+RelationShipName+"', REQUESTER_RESOURCE_TYPE_ID="+sourceResourceTypeId+" where ID = "+relId;
    	log.debug("RelationshipServiceImpl::updateRelResourceType:: relationshipUpdateSQL-"+relationshipUpdateSQL);

		SQLQuery query2 = session.createSQLQuery(relationshipUpdateSQL);
		query2.executeUpdate();
  	  
    	String conipmasterSrcUpdateSQL = "update c3par.con_ip_xref cix set cix.resource_type = "+targetResourceTypeId
				+  "where cix.id in ( SELECT cix.id FROM c3par.relationship r, c3par.con_req cr, c3par.con_ip_xref cix, "
				+ " c3par.con_ip_master cim  WHERE r.id IN ("+relId+") "
				+ " AND r.id = cr.relationship_id AND cr.id = cix.connection_request_id   AND cix.ip_id = cim.id "
				+ " AND (cix.resource_type = cr.target_resource_type))";
    	log.debug("ManageRelationshipAction::RelationshipServiceImpl::updateRelResourceType:: conipmasterSrcUpdateSQL-"+conipmasterSrcUpdateSQL);

		SQLQuery query3 = session.createSQLQuery(conipmasterSrcUpdateSQL);
		query3.executeUpdate();
  	  
    	String conipmasterTarUpdateSQL = "update c3par.con_ip_xref cix set cix.resource_type = "+sourceResourceTypeId
				+ " where cix.id in (SELECT cix.id FROM c3par.relationship r, c3par.con_req cr, c3par.con_ip_xref cix, c3par.con_ip_master cim"
				+ " WHERE r.id IN ("+relId+") AND r.id = cr.relationship_id   AND cr.id = cix.connection_request_id "
				+ " AND cix.ip_id = cim.id AND (cix.resource_type = cr.source_resource_type  ))";
    	log.debug("ManageRelationshipAction::RelationshipServiceImpl::updateRelResourceType:: conipmasterTarUpdateSQL-"+conipmasterTarUpdateSQL);

		SQLQuery query4 = session.createSQLQuery(conipmasterTarUpdateSQL);
		query4.executeUpdate();
  	  
    	String conreqUpdateSQL="update c3par.con_req cr set cr.target_resource_type = "+targetResourceTypeId+", cr.source_resource_type="+sourceResourceTypeId+" where cr.id in "
				+ "	(select cr.id from c3par.relationship r,c3par.con_req cr "
				+ " where r.id in ("+relId+") and r.id = cr.relationship_id)";
    	log.debug("ManageRelationshipAction::RelationshipServiceImpl::updateRelResourceType:: conreqUpdateSQL-"+conreqUpdateSQL);

		SQLQuery query5 = session.createSQLQuery(conreqUpdateSQL);
		query5.executeUpdate();
    	  
    	return isSuccess;
    }
    
	private String getNewRelationshipName(String RelationshipName, String oldResType, String newResType, String oldSourceResType, String newSourceResType) {
		String NewRelationshipName = null;
		if (!newSourceResType.equalsIgnoreCase(C3parStaticNames.RESOURCE_TYPE_THIRD_PARTY)) {
			int index = 0;
			int index1 = 0;
			int index2 = 0;
			String currentString = "-" + newSourceResType + "-" + newResType;
			StringBuffer strBuff = new StringBuffer(RelationshipName);
			log.debug("getNewRelationshipName::RelationshipName :- " + RelationshipName);
			if (RelationshipName != null && newResType != null) {
				index = RelationshipName.trim().lastIndexOf(
						"-" + oldSourceResType + "-" + oldResType);
				index1 = RelationshipName.trim().lastIndexOf(
						"-" + oldSourceResType);
				index2 = RelationshipName.trim().lastIndexOf("-" + oldResType);
				if (index > 0) {
					strBuff.replace(index, strBuff.length(), currentString);
				} else if (index1 > 0) {
					strBuff.replace(index1, strBuff.length(), currentString);
				} else if (index2 > 0) {
					strBuff.replace(index2, strBuff.length(), currentString);
				} else {
					strBuff.append(currentString);
				}
				NewRelationshipName = strBuff.toString();
			}
			log.debug("getNewRelationshipName::NewRelationshipName :- " + NewRelationshipName);
		} else {
			int index = 0;
			if (RelationshipName != null && newResType != null) {
				index = RelationshipName.trim().lastIndexOf("-" + oldResType);
				if (index > 0) {
					NewRelationshipName = RelationshipName.substring(0, index)
					+ "-" + newResType;
				} else {
					NewRelationshipName = RelationshipName + "-" + newResType;
				}
			}
			log.debug("getNewRelationshipName::NewRelationshipName :- " + NewRelationshipName);
		}
		return NewRelationshipName;
	}

    @Override
	public Long isRelationShipNameUnique(Relationship relationship) {
		log.debug("RelationshipServiceImpl :: isRelationShipNameUnique :: starts");
		Session session = getSession();

		StringBuilder queryString = new StringBuilder();
		queryString.append(" select rel.id relID from RELATIONSHIP rel where upper(rel.name) = '"+relationship.getName().toUpperCase()+"'");
		
		if(relationship.getId() != null && relationship.getId().longValue() > 0){
			queryString.append(" and rel.id != "+relationship.getId());
		}
		log.debug("RelationshipServiceImpl :: isRelationShipNameUnique :: queryString - "+queryString.toString());
		SQLQuery query =  session.createSQLQuery(queryString.toString());
		query.addScalar("relID", LongType.INSTANCE);
		List<Long> relIdList = (List<Long>)query.list();
		Long relId = 0L;
		
		if(relIdList != null && !relIdList.isEmpty() && relIdList.size() > 0){
			relId = relIdList.get(0);
		}
		log.debug("RelationshipServiceImpl :: isRelationShipNameUnique :: relId - "+relId+" :: relationshipName - "+relationship.getName().toUpperCase());
		
		return relId;
	}
	
	@Override
	@Transactional(readOnly = true)
	public void loadRelationshipReferences(RelationshipProcess relationshipProcess){
		log.debug("RelationshipServiceImpl::loadRelationshipReferences:: starts");
		Session session = getSession();
		
		Relationship relationship = relationshipProcess.getRelationship();
		Long relationshipId = relationship.getId();
		
		//1. load Requester contacts
		Criteria criteria = session.createCriteria(RelReqCitiContactXref.class);
		criteria.createCriteria("relationship", "relationship");			
	    criteria.add(Restrictions.eq("relationship.id", relationshipId));
	    
		List<RelReqCitiContactXref> reqContactList = criteria.list();	
		if (reqContactList != null) {
			log.debug("Requester Citi Contacts :"+reqContactList.size());
		}
		relationshipProcess.setRelReqCitiContactXrefList(reqContactList);

		//2. load Target contacts
		criteria = session.createCriteria(RelCitiContXref.class);
		criteria.createCriteria("relationship", "relationship");			
	    criteria.add(Restrictions.eq("relationship.id", relationshipId));
	    
		List<RelCitiContXref> tarContactList = criteria.list();	
		if (tarContactList != null) {
			log.debug("Target Citi Contacts :"+tarContactList.size());
		}
		relationshipProcess.setRelCitiContXrefList(tarContactList);

		//3. load ThirdParty contacts
		StringBuilder queryString = new StringBuilder();
		queryString.append(" select tpconxref.* from RELATIONSHIP rel, REL_TP_CONT_XREF tpconxref, THIRD_PARTY tp, TP_CONTACT tpcon ");
		queryString.append(" where rel.id = tpconxref.relationship_id and rel.third_party_id = tp.id and tp.id = tpcon.thirdparty_id ");
		queryString.append(" and tpcon.id = tpconxref.tp_contact_id and rel.id = "+relationshipId.longValue());
		
		SQLQuery query =  session.createSQLQuery(queryString.toString());
		query.addEntity("tpconxref",RelThirdPartyContXref.class);
		
		List<RelThirdPartyContXref> reqTPlist = query.list();		
		if (reqTPlist != null) {
			log.debug("ThirdParty Contacts :"+reqTPlist.size());
		}
		relationshipProcess.setRequesterThirdPartyContacts(reqTPlist);

		//4. load UTurn ThirdParty contacts
		queryString = new StringBuilder();
		queryString.append(" select tpconxref.* from RELATIONSHIP rel, REL_TP_CONT_XREF tpconxref, THIRD_PARTY tp, TP_CONTACT tpcon ");
		queryString.append(" where rel.id = tpconxref.relationship_id and rel.uturn_third_party_id = tp.id and tp.id = tpcon.thirdparty_id ");
		queryString.append(" and tpcon.id = tpconxref.tp_contact_id and rel.id = "+relationshipId.longValue());
		
		query =  session.createSQLQuery(queryString.toString());
		query.addEntity("tpconxref",RelThirdPartyContXref.class);
		
		List<RelThirdPartyContXref> tarTPlist = query.list();		
		if (tarTPlist != null) {
			log.debug("UTurn ThirdParty Contacts :"+tarTPlist.size());
		}
		relationshipProcess.setTargetThirdPartyContacts(tarTPlist);

		//5. load ThirdParty Locations
		queryString = new StringBuilder();
		queryString.append(" select loc.* from RELATIONSHIP rel, REL_TP_LOC_XREF tplocxref, THIRD_PARTY tp, TP_LOC_XREF tploc, LOCATION loc ");
		queryString.append(" where rel.id = tplocxref.relationship_id and rel.third_party_id = tp.id and tp.id = tploc.thirdparty_id ");
		queryString.append(" and tploc.location_id = tplocxref.location_id and loc.id = tploc.location_id and rel.id = "+relationshipId.longValue());
		
		query =  session.createSQLQuery(queryString.toString());
		query.addEntity("loc",Location.class);
		
		List<Location> reqTPLocList = query.list();		
		if (reqTPLocList != null) {
			log.debug("ThirdParty Locations :"+reqTPLocList.size());
		}
		relationshipProcess.setRequesterThirdPartyLocations(reqTPLocList);

		//6. load UTurn ThirdParty Locations
		queryString = new StringBuilder();
		queryString.append(" select loc.* from RELATIONSHIP rel, REL_TP_LOC_XREF tplocxref, THIRD_PARTY tp, TP_LOC_XREF tploc, LOCATION loc ");
		queryString.append(" where rel.id = tplocxref.relationship_id and rel.uturn_third_party_id = tp.id and tp.id = tploc.thirdparty_id ");
		queryString.append(" and tploc.location_id = tplocxref.location_id and loc.id = tploc.location_id and rel.id = "+relationshipId.longValue());
		
		query =  session.createSQLQuery(queryString.toString());
		query.addEntity("loc",Location.class);
		
		List<Location> tarTPLocList = query.list();		
		if (tarTPLocList != null) {
			log.debug(" UTurn ThirdParty Locations :"+tarTPLocList.size());
		}
		relationshipProcess.setTargetThirdPartyLocations(tarTPLocList);
		
		//7. load Requester Locations
		criteria = session.createCriteria(RelReqCitiLocationXref.class);
		criteria.createCriteria("relationship", "relationship");			
	    criteria.add(Restrictions.eq("relationship.id", relationshipId));
	    
		List<RelReqCitiLocationXref> reqcitiloclist = criteria.list();	
		if (reqcitiloclist != null) {
			log.debug("Requester Citi Locations :"+reqcitiloclist.size());
		}
		relationshipProcess.setRelReqCitiLocXrefList(reqcitiloclist);

		//8. load Target Locations
		criteria = session.createCriteria(RelCitiLocationXref.class);
		criteria.createCriteria("relationship", "relationship");			
	    criteria.add(Restrictions.eq("relationship.id", relationshipId));
	    
		List<RelCitiLocationXref> citlocxref = criteria.list();	
		if (citlocxref != null) {
			log.debug("Target Citi Locations :"+citlocxref.size());
		}
		relationshipProcess.setRelCitiLocXrefList(citlocxref);
	}
	
	@Override
	public void deleteRelationshipReferences(Relationship relationship){

		Long relationshipId = relationship.getId();
		
		log.debug("RelationshipServiceImpl::deleteRelationshipReferences:: relid - "+relationshipId);
		
		if(relationshipId != null && relationshipId.longValue() > 0){
			//1. delete requester contacts
	    	SQLQuery query = getSession().createSQLQuery("delete from REL_REQ_CITI_CONT_XREF where RELATIONSHIP_ID = "+relationship.getId());
			int rows = query.executeUpdate();
			log.debug("RelationshipServiceImpl::delete REL_REQ_CITI_CONT_XREF - "+rows); 

			//2. delete target contacts
			query = getSession().createSQLQuery("delete from REL_CITI_CONT_XREF where RELATIONSHIP_ID = "+relationship.getId());
			rows = query.executeUpdate();
			log.debug("RelationshipServiceImpl::delete REL_CITI_CONT_XREF - "+rows);

			//3. delete third party / uturn third party contacts
			query = getSession().createSQLQuery("delete from REL_TP_CONT_XREF where RELATIONSHIP_ID = "+relationship.getId());
			rows = query.executeUpdate();
			log.debug("RelationshipServiceImpl::delete REL_TP_CONT_XREF - "+rows);

			//4. delete third party requester / target locations
			query = getSession().createSQLQuery("delete from REL_TP_LOC_XREF where RELATIONSHIP_ID = "+relationship.getId());
			rows = query.executeUpdate();
			log.debug("RelationshipServiceImpl::delete REL_TP_LOC_XREF - "+rows);

			//5. delete citi requester locations
			query = getSession().createSQLQuery("delete from REL_REQ_CITI_LOC_XREF where RELATIONSHIP_ID = "+relationship.getId());
			rows = query.executeUpdate();
			log.debug("RelationshipServiceImpl::delete REL_REQ_CITI_LOC_XREF - "+rows);

			//6. delete citi target locations
			query = getSession().createSQLQuery("delete from REL_CITI_LOC_XREF where RELATIONSHIP_ID = "+relationship.getId());
			rows = query.executeUpdate();
			log.debug("RelationshipServiceImpl::delete REL_CITI_LOC_XREF - "+rows);
			
			//6. delete other tables
			query = getSession().createSQLQuery("delete from REL_CITI_RES_XREF where RELATIONSHIP_ID = "+relationship.getId());
			rows = query.executeUpdate();
			log.debug("RelationshipServiceImpl::delete REL_CITI_RES_XREF - "+rows);

			query = getSession().createSQLQuery("delete from REL_PJ_XREF where RELATIONSHIP_ID = "+relationship.getId());
			rows = query.executeUpdate();
			log.debug("RelationshipServiceImpl::delete REL_PJ_XREF - "+rows);

			query = getSession().createSQLQuery("delete from REL_FAC_XREF where RELATIONSHIP_ID = "+relationship.getId());
			rows = query.executeUpdate();
			log.debug("RelationshipServiceImpl::delete REL_FAC_XREF - "+rows);

			query = getSession().createSQLQuery("delete from REL_TP_SVC_XREF where RELATIONSHIP_ID = "+relationship.getId());
			rows = query.executeUpdate();
			log.debug("RelationshipServiceImpl::delete REL_TP_SVC_XREF - "+rows);
		}
	}

	@Override
	public boolean saveRelationshipReferences(RelationshipProcess relprocess){

		log.debug("RelationshipServiceImpl :: saveRelationshipReferences :: method starts");
		
		if(relprocess.getRelationship() != null){
			//Delete the reference table (contact, location, third party contact, third party location) data before save / update 
			deleteRelationshipReferences(relprocess.getRelationship());
			
			Relationship relationship = getRelationship(relprocess.getRelationship().getId());

			Long rowId = 0L;
			Role role = null;
			CitiContact citicontact = null;
			ThirdPartyContact tpcontact = null;
			Location location = null;
			
			RelReqCitiContactXref relReqContact = null;
			RelCitiContXref relTarContact = null;
			RelThirdPartyContXref tpContactXref = null;
			RelTpLocationXref reltpLocXref = null;
			RelReqCitiLocationXref relReqCitiLocationXref = null;
			RelCitiLocationXref relCitiLocationXref = null;

			//1. save requester contacts
			List<RelReqCitiContactXref> reqContactList = relprocess.getRelReqCitiContactXrefList();
			if(reqContactList != null && !reqContactList.isEmpty()){				
				for(RelReqCitiContactXref reqContact:reqContactList){
					role = getRole(reqContact.getRole().getId());
					citicontact = getCitiContact(reqContact.getContactId().getSsoId());
					
					relReqContact = new RelReqCitiContactXref();
					relReqContact.setRelationship(relationship);
					relReqContact.setRole(role);
					relReqContact.setContactId(citicontact);
					
					rowId = (Long) getHibernateTemplate().save(relReqContact);
					log.debug("RelationshipServiceImpl :: saveRelationshipReferences :: RelReqCitiContactXref :: rowId-"+rowId);
				}
			}

			//2. save target contacts
			List<RelCitiContXref> tarContactList = relprocess.getRelCitiContXrefList();
			if(tarContactList != null && !tarContactList.isEmpty()){
				for(RelCitiContXref tarContact:tarContactList){
					role = getRole(tarContact.getRole().getId());
					citicontact = getCitiContact(tarContact.getContactId().getSsoId());
					
					relTarContact = new RelCitiContXref();
					relTarContact.setRelationship(relationship);
					relTarContact.setRole(role);
					relTarContact.setContactId(citicontact);
					
					rowId = (Long) getHibernateTemplate().save(relTarContact);
					log.debug("RelationshipServiceImpl :: saveRelationshipReferences :: RelCitiContXref :: rowId-"+rowId);
				}
			}

			//3. save third party contacts
			List<RelThirdPartyContXref> reqTPContactList = relprocess.getRequesterThirdPartyContacts();
			if(reqTPContactList != null && !reqTPContactList.isEmpty()){
				for(RelThirdPartyContXref reqTPContact:reqTPContactList){
					role = getRole(reqTPContact.getRole().getId());
					tpcontact = getThirdPartyContact(reqTPContact.getThirdPartyContact().getId());
					
					tpContactXref = new RelThirdPartyContXref();
					tpContactXref.setRelationship(relationship);
					tpContactXref.setRole(role);
					tpContactXref.setThirdPartyContact(tpcontact);
					
					rowId = (Long) getHibernateTemplate().save(tpContactXref);
					log.debug("RelationshipServiceImpl :: saveRelationshipReferences :: RelThirdPartyContXref - Requester :: rowId-"+rowId);
				}
			}
			
			//4. save uturn third party contacts
			List<RelThirdPartyContXref> tarTPContactList = relprocess.getTargetThirdPartyContacts();
			if(tarTPContactList != null && !tarTPContactList.isEmpty()){
				for(RelThirdPartyContXref tarTPContact:tarTPContactList){
					role = getRole(tarTPContact.getRole().getId());
					tpcontact = getThirdPartyContact(tarTPContact.getThirdPartyContact().getId());
					
					tpContactXref = new RelThirdPartyContXref();
					tpContactXref.setRelationship(relationship);
					tpContactXref.setRole(role);
					tpContactXref.setThirdPartyContact(tpcontact);
					
					rowId = (Long) getHibernateTemplate().save(tpContactXref);
					log.debug("RelationshipServiceImpl :: saveRelationshipReferences :: RelThirdPartyContXref - Target :: rowId-"+rowId);
				}
			}
			
			//5. save third party locations
			List<Location> reqTPLocationsList = relprocess.getRequesterThirdPartyLocations();
			if(reqTPLocationsList != null && !reqTPLocationsList.isEmpty()){
				for(Location reqTPLocation:reqTPLocationsList){
					location = getLocation(reqTPLocation.getId());
					
					reltpLocXref = new RelTpLocationXref();
					reltpLocXref.setRelationship(relationship);
					reltpLocXref.setLocation(location);
					
					rowId = (Long) getHibernateTemplate().save(reltpLocXref);
					log.debug("RelationshipServiceImpl :: saveRelationshipReferences :: Location - Requester :: rowId-"+rowId);
				}
			}
			
			//6. save uturn third party locations
			List<Location> tarTPLocationsList = relprocess.getTargetThirdPartyLocations();
			if(tarTPLocationsList != null && !tarTPLocationsList.isEmpty()){
				for(Location tarTPLocation:tarTPLocationsList){
					location = getLocation(tarTPLocation.getId());
					
					reltpLocXref = new RelTpLocationXref();
					reltpLocXref.setRelationship(relationship);
					reltpLocXref.setLocation(location);
					
					rowId = (Long) getHibernateTemplate().save(reltpLocXref);
					log.debug("RelationshipServiceImpl :: saveRelationshipReferences :: Location - Target :: rowId-"+rowId);
				}
			}
			
			//7. save requester locations
			List<RelReqCitiLocationXref> relReqCitiLocXrefList = relprocess.getRelReqCitiLocXrefList();
			if(relReqCitiLocXrefList != null && !relReqCitiLocXrefList.isEmpty()){
				for(RelReqCitiLocationXref relReqCitiLoc:relReqCitiLocXrefList){
					location = getLocation(relReqCitiLoc.getLocation().getId());
					
					relReqCitiLocationXref = new RelReqCitiLocationXref();
					relReqCitiLocationXref.setRelationship(relationship);
					relReqCitiLocationXref.setLocation(location);
					
					rowId = (Long) getHibernateTemplate().save(relReqCitiLocationXref);
					log.debug("RelationshipServiceImpl :: saveRelationshipReferences :: relReqCitiLocationXref :: rowId-"+rowId);
				}
			}
			
			//8. load target locations
			List<RelCitiLocationXref> relCitiLocXrefList = relprocess.getRelCitiLocXrefList();
			if(relCitiLocXrefList != null && !relCitiLocXrefList.isEmpty()){
				for(RelCitiLocationXref relCitiLoc:relCitiLocXrefList){
					location = getLocation(relCitiLoc.getLocation().getId());
					
					relCitiLocationXref = new RelCitiLocationXref();
					relCitiLocationXref.setRelationship(relationship);
					relCitiLocationXref.setLocation(location);
					
					rowId = (Long) getHibernateTemplate().save(relCitiLocationXref);
					log.debug("RelationshipServiceImpl :: saveRelationshipReferences :: relCitiLocationXref :: rowId-"+rowId);
				}
			}
		}
		return true;
	}

	@Override
	@Transactional(readOnly = true)
	public CitiContact getCitiContact(String ssoeId){
		Session session = getSession();
		log.debug("RelationshipServiceImpl :: loadCitiContacts1 :: ssoeId ::"+ssoeId);
		CitiContact contact = null;
		
		Criteria criteria = session.createCriteria(CitiContact.class);		    
	    criteria.add(Restrictions.eq("ssoId", ssoeId));
	    
		List<CitiContact> contactlist = criteria.list();
		if(contactlist != null && contactlist.size() > 0){
			contact = contactlist.get(0);
		}		
		return contact;
    }

	@Override
	public CitiContact getCitiContact(CitiContact citiContact){
		Session session = getSession();
		log.debug("RelationshipServiceImpl :: loadCitiContacts2 :: citiContact.getSsoId() ::"+citiContact.getSsoId());
		CitiContact contact = null;
		
		contact = getCitiContact(citiContact.getSsoId());

		if(contact == null || contact.getId().longValue() <= 0){
			Long id = (Long)getHibernateTemplate().save(citiContact);
			citiContact.setId(id);	
			
			return citiContact;
		}
		return contact;
    }

	@Override
	@Transactional(readOnly = true)
	public Role getRole(Long roleId){
		Session session = getSession();
		log.debug("RelationshipServiceImpl :: getRole :: roleId - "+roleId);
		
		Role role = null;
		Criteria criteria = session.createCriteria(Role.class);
		criteria.add(Restrictions.eq("id", roleId)); 
	 
		List<Role> rolelist = criteria.list();
		
		if(rolelist != null && rolelist.size() > 0){
			role = rolelist.get(0);
		}
		return role;
	}

	@Override
	@Transactional(readOnly = true)
	public List<Role> getRoleList(){
		Session session = getSession();

		Criteria criteria = session.createCriteria(Role.class);
		criteria.add(Restrictions.eq("iscontact", "Y"));
		criteria.add(Restrictions.eq("citi", "N"));
		 
		criteria.addOrder(Order.asc("id"));

		List<Role> rolelist = criteria.list();
		if(rolelist != null){
			log.debug("RelationshipServiceImpl :: getRoleList :: size - "+rolelist.size());
		}
		
		return rolelist;
	}

	@Override
	@Transactional(readOnly = true)
	public Location getLocation(Long locationId){
		log.debug("RelationshipServiceImpl :: getLocation :: locationId - "+locationId);
		Session session = getSession();
		Location loc = (Location) session.get(Location.class, locationId);
		
		return loc;		
	}

	@Override
	@Transactional(readOnly = true)
	public ThirdPartyContact getThirdPartyContact(Long Id){
		log.debug("RelationshipServiceImpl :: getThirdPartyContact :: Id - "+Id);
		Session session = getSession();
		ThirdPartyContact tpcontact = (ThirdPartyContact) session.get(ThirdPartyContact.class, Id);
		
		return tpcontact;				
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<ThirdPartyContact> loadThirdPartyContacts(Long thirdPartyId){
		Session session = getSession();
	
		Criteria criteria = session.createCriteria(ThirdPartyContact.class);	
		criteria.createCriteria("thirdParty", "thirdParty");			
	    criteria.add(Restrictions.eq("thirdParty.id", thirdPartyId));
	
		List<ThirdPartyContact> tplist = criteria.list();
		if(tplist != null && tplist.size() > 0){
			log.debug("RelationshipServiceImpl :: loadThirdPartyContacts :: size - "+tplist.size());
		}
	
		return tplist;
	}

	@Override
	@Transactional(readOnly = true)
	public List<Location> loadThirdPartyLocations(Long thirdPartyId){
		Session session = getSession();		
		List<ThirdPartyLocationXref> tplocations =  (List<ThirdPartyLocationXref>) session.createQuery( "from ThirdPartyLocationXref where thirdParty.id=" + thirdPartyId).list();
		
		List<Location> locations = new ArrayList<Location>();
		if(tplocations != null && tplocations.size() > 0){
			log.debug("RelationshipServiceImpl :: loadThirdPartyLocationXref :: size ::"+tplocations.size());
			for(ThirdPartyLocationXref tploc:tplocations){
				locations.add(tploc.getLocation());
			}
		}		
		return locations;
	}

	@Override
	public GenericLookup getCountryCode(String countryName){	
		Session session = getSession();
		GenericLookup gl = null;
		SQLQuery query = session.createSQLQuery("select gl.* from generic_lookup gl where gl.value1 = '"+countryName+"' " +
									" and definition_id = (select id from generic_lookup_defs where upper(name)='COUNTRY') ");
		query.addEntity("gl", GenericLookup.class);
		
		List<GenericLookup> gllist = query.list();
		
		if(gllist != null){
			log.debug("RelationshipServiceImpl :: getCountryCode :: size ::"+gllist.size());
			gl = gllist.get(0);
		}
		
		return gl;		
	}
	
	@Transactional(readOnly = true)
	public ThirdParty getThirdParty(Long tpId){
		log.debug("RelationshipServiceImpl :: getThirdParty :: tpId - "+tpId);
		Session session = getSession();
		ThirdParty tp = (ThirdParty) session.get(ThirdParty.class, tpId);
		
		return tp;				
	}

	@Override
	public Long saveLocation(Location location) {
		log.debug("RelationshipServiceImpl :: saveLocation");
		
		Long id = 0L;
    	if(location != null){
    		id = (Long) getHibernateTemplate().save(location);
    	}
    	log.info("RelationshipServiceImpl :: saveLocation :: location Id -"+id);
    	 
	    return id;	    
	}

	@Override
	public void deleteBuLocXref(Long locationId, Long buId) {		
		log.debug("RelationshipServiceImpl :: deleteBuLocXref"); 
		Session session = getSession();

    	SQLQuery query = session.createSQLQuery("delete from BU_LOC_XREF where LOCATION_ID = "+locationId+" and BUSINESS_UNIT_ID = "+buId);
		int rows = query.executeUpdate();
		
		log.info("RelationshipServiceImpl :: deleteBuLocXref :: deleteBuLocXref -"+rows);
	}

	@Override
	@Transactional(readOnly = true)
	public List<BusinessUnitLocationXref> searchBusinessUnitLocation(Long businessUnitId) {	
		log.debug("RelationshipServiceImpl :: searchBusinessUnitLocation :: businessUnitId - "+businessUnitId);
		
		List<BusinessUnitLocationXref> businessUnitLocList = null;
		try{
			Session session = getSession();			
			
			Criteria criteria = session.createCriteria(BusinessUnitLocationXref.class);
			criteria.createCriteria("businessUnit", "businessUnit");
		    criteria.add(Restrictions.eq("businessUnit.id", businessUnitId));
		    
		    businessUnitLocList = criteria.list();
			
		    if(businessUnitLocList != null && businessUnitLocList.size() > 0){
				log.debug("RelationshipServiceImpl :: searchBusinessUnitLocation :: size ::"+businessUnitLocList.size());
				return businessUnitLocList; 
			}
		}catch (HibernateException e){	
	    	log.error(e,e);
	    }
		return businessUnitLocList; 
	}

	@Override
	@Transactional(readOnly = true)
	public List<ResourceTypeLocXref> searchResourceTypeLocXref(Long resourceTypeId) {
		log.debug("RelationshipServiceImpl :: searchResourceTypeLocXref :: resourceTypeId - "+resourceTypeId);
		
		Session session = getSession();
		List<ResourceTypeLocXref> resourceTypeLocLocList=null;
		
		try{		
			Criteria criteria = session.createCriteria(ResourceTypeLocXref.class);	
			criteria.createCriteria("resourceType", "resourceType");
		    criteria.add(Restrictions.eq("resourceType.id", resourceTypeId));
		    
			resourceTypeLocLocList = criteria.list();
			if(resourceTypeLocLocList != null && resourceTypeLocLocList.size() > 0){
				log.debug("RelationshipServiceImpl :: searchResourceTypeLocXref :: size - "+resourceTypeLocLocList.size());
				return resourceTypeLocLocList; 
			}
		}catch (HibernateException e){	
	    	log.error(e,e);
	    }
		return resourceTypeLocLocList; 
	}
}