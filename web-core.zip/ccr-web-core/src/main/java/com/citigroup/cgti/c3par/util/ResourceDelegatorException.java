/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.util;


/**
 * The Class ResourceDelegatorException.
 */
public class ResourceDelegatorException extends Exception {

    /**
     * Instantiates a new resource delegator exception.
     */
    public ResourceDelegatorException() {

	super();
    }

    /**
     * Instantiates a new resource delegator exception.
     *
     * @param message the message
     */
    public ResourceDelegatorException(String message) {

	super(message);
    }

    /**
     * Instantiates a new resource delegator exception.
     *
     * @param message the message
     * @param cause the cause
     */
    public ResourceDelegatorException(String message, Throwable cause) {

	super(message, cause);
    }

    /**
     * Instantiates a new resource delegator exception.
     *
     * @param cause the cause
     */
    public ResourceDelegatorException(Throwable cause) {

	super(cause);
    }
}
