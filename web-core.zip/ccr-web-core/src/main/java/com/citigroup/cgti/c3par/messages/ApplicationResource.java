package com.citigroup.cgti.c3par.messages;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.springframework.context.ResourceLoaderAware;
import org.springframework.context.support.AbstractMessageSource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

public class ApplicationResource extends AbstractMessageSource implements ResourceLoaderAware  {
	
	private ResourceLoader resourceLoader;
	
	private final Map<String, Map<String, String>> properties = new HashMap<String, Map<String, String>>();
	
	private JdbcTemplate jdbcTemplate;
	
    public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	public ApplicationResource(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
    	System.out.println("ApplicationResource :: constructor");
        reload();
    }

	@Override
    protected MessageFormat resolveCode(String code, Locale locale) {
        String msg = getText(code, locale);
        MessageFormat result = createMessageFormat(msg, locale);
        return result;
    }

    @Override
    protected String resolveCodeWithoutArguments(String code, Locale locale) {
        return getText(code, locale);
    }

    @Override
    public void setResourceLoader(ResourceLoader resourceLoader) {
        this.resourceLoader = (resourceLoader != null ? resourceLoader : new DefaultResourceLoader());
    }
    
    private String getText(String code, Locale locale) {
    	System.out.println("ApplicationResource :: getText()-"+code+" :: getLanguage-"+locale.getLanguage());
        Map<String, String> localized = properties.get(code);
        String textForCurrentLanguage = null;
        if (localized != null) {
            textForCurrentLanguage = localized.get(locale.getLanguage());
            if (textForCurrentLanguage == null) {
                textForCurrentLanguage = localized.get(Locale.ENGLISH.getLanguage());
            }
        }
        
        if (textForCurrentLanguage==null) {
        	System.out.println("ApplicationResource :: Fallback to properties message - "+code);
            try {
                textForCurrentLanguage = getParentMessageSource().getMessage(code, null, locale);
            } catch (Exception e) {
            	System.out.println("ApplicationResource :: Cannot find message with code: " + code);
            }
        }
        return textForCurrentLanguage != null ? textForCurrentLanguage : code;
    }

    public void reload() {
    	System.out.println("ApplicationResource :: reload()");
        properties.clear();
        properties.putAll(loadTexts());
    }

    protected Map<String, Map<String, String>> loadTexts() {
    	System.out.println("ApplicationResource :: loadTexts");
        Map<String, Map<String, String>> m = new HashMap<String, Map<String, String>>();
        StringBuilder sb = new StringBuilder("select * from APPLICATION_RESOURCES");
        SqlRowSet rs = jdbcTemplate.queryForRowSet(sb.toString());
      
        while(rs.next()){
        	System.out.println("ApplicationResource :: MESSAGE_KEY - "+rs.getString("MESSAGE_KEY")
        			+" :: MESSAGE_VALUE - "+rs.getString("MESSAGE_VALUE")
        			+" :: LOCALE - "+rs.getString("LOCALE"));
        	
        	Map<String, String> v = null;
        	if(m.containsKey(rs.getString("MESSAGE_KEY"))){
        		System.out.println("ApplicationResource :: key already exists - "+rs.getString("MESSAGE_KEY"));
        		v = m.get(rs.getString("MESSAGE_KEY"));
        	}else{
        		v = new HashMap<String, String>();        		
        	}  
        	
            v.put(rs.getString("LOCALE"), rs.getString("MESSAGE_VALUE"));
            m.put(rs.getString("MESSAGE_KEY"), v); 
        }
    	System.out.println("ApplicationResource :: loadTexts - size"+m.size());
        return m;
    }


}
