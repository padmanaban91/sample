package com.citigroup.cgti.ccr.workflow.impl;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityBPMDTO;
import com.citigroup.cgti.ccr.workflow.WorkflowResult;

public interface MigrationService {
    public boolean migrateConnection(Long pID,String soeid,String activityStatus) throws Exception;
    public boolean migrateConnectionToActvity(String newActivity);
    public WorkflowResult initiateJBPMProcess(Long pID, String soeid,
			ActivityBPMDTO activityBPMDTO,String activityCode,Long tiRequestId) throws Exception;
}
