package com.citigroup.cgti.c3par.mailmodule.action;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.kie.api.task.model.TaskSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;
import com.citigroup.cgti.ccr.workflow.CCRWorkflowConstants;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

public class GisRejectAction extends MailAction {

    Logger log = Logger.getLogger(GisRejectAction.class);

    private final static String ROLE = "OTRM";
    private final static String PC_ROLE = "PC_ROLE";
    private final static String STATUS = "REJECTED";
    private static final String SUCCESS = "Successful";
    private static final String FAILURE = "Failed";
    @Autowired
    WsPapiFacade papiFacade;
    @Autowired
    WorkflowCallServiceHelper wrkflowCallServiceHelper;
    @Autowired
    WorkflowUtil workflowUtil;

    @Override
    public void process(IncomingMessage message) {
        log.info("Process method of IsoApproveAction --------------------");

        Long processId = null;

        if (message != null && message.getProcessId() != null) {
            processId = Long.parseLong(message.getProcessId().trim());
        }
        Long tiRequestId = getTIRequestID(processId);
        String ssoId = message.getSsoId();
        if (checkReferenceNumber(message.getReferenceNo(), tiRequestId, ssoId)) {

            String instanceId = null;
            /*
             * SqlRowSet rs = getJdbcTemplate().queryForRowSet(
             * "select bpm_instance_id from ti_activity_trail "+
             * " where bpm_instance_id is not null and ti_request_id = (select max(id) from ti_request where process_id = "
             * +processId+") and activity_status = 'SCHEDULED'");
             * 
             * if (rs.next()) { instanceId = rs.getString(1); }
             */
            // message.setSsoId("hb26743");
            instanceId = getInstanceId(processId);
            log.debug("Before calling PAPI --------------------------- " + instanceId);
            Long userId = getUserID(message.getSsoId());

            try {
                String nextAction = toCheckActivity(processId, tiRequestId, ssoId);
                log.info(" nextAction value:: " + nextAction);
                Map<String, Object> userFlowParams = new HashMap<String, Object>();
                if (nextAction != null && "UNLOCK".equals(nextAction)) {
                    sendAckMail(message.getAction(), message.getSsoId(), processId, FAILURE, message.getEntity());
                    update(message.getMailID(), message.getReferenceNo(), "N",
                            "Activity is already locked by someone.");
                } else if (nextAction != null && "LOCK".equals(nextAction)) {
                    TaskSummary taskSummary = workflowUtil.getTaskSummary(Long.parseLong(instanceId));
                    userFlowParams.put("soeid", ssoId);
                    userFlowParams.put(CCRWorkflowConstants.TASK_SUMMARY, taskSummary);
                    wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, userFlowParams, WorkflowEvent.LOCK,
                            tiRequestId);
                    addComments(message.getComments(), tiRequestId, ROLE, userId);
                    papiFacade.completeActivity(userId.toString(), instanceId, WsPapiFacade.ActivityStatus.REJECTED,
                            WsPapiFacade.ActivityRejectedToRole.valueOf(PC_ROLE));
                    // papiFacade.completeActivity(message.getSsoId(),
                    // instanceId,
                    // WsPapiFacade.ActivityStatus.REJECTED,
                    // WsPapiFacade.ActivityRejectedToRole.PC_ROLE);
                    sendAckMail(message.getAction(), message.getSsoId(), processId, SUCCESS, message.getEntity());
                    update(message.getMailID(), message.getReferenceNo(), "Y", "Action completed successfully");
                }else{

                    sendAckMail(message.getAction(), message.getSsoId(), processId, FAILURE, message.getEntity());
                    update(message.getMailID(), message.getReferenceNo(), "N","Activity is already locked by someone.");
                
                }

            } catch (OperationException_Exception e) {
                log.error("Exception Occured");
                log.error(e, e);
                sendAckMail(message.getAction(), message.getSsoId(), processId, FAILURE, message.getEntity());
                update(message.getMailID(), message.getReferenceNo(), "N", getExceptionMessage(e));
                e.printStackTrace();
            }
        } else {
            sendAckMail(message.getAction(), message.getSsoId(), processId, FAILURE, message.getEntity());
            update(message.getMailID(), message.getReferenceNo(), "N",
                    "The response Email from the user is not authorized");
            log.debug("Refernce ID not matching " + message.getReferenceNo());
        }

        log.info("End of Process method of GISRejectAction --------------------");
    }

}
