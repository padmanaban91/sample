package com.citigroup.cgti.c3par.controller.submitActivity;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.validator.submitActivtity.GISMADValidator;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

/*
 * @nc43495
 */
@Controller
public class GIS_MADSubmitController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(GIS_MADSubmitController.class);
	
	Util util=new Util();
	
	@Autowired
	@Qualifier("GISMADValidator") 
	private GISMADValidator validator;
	
	@Autowired
	WsPapiFacade papiFacade;
	
	@Autowired
	WorkflowUtil workflowUtil;
	
	@RequestMapping(value = "/loadGISSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(ModelMap model,@ModelAttribute("gisProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session
			,HttpServletRequest request){
		log.info("ISOSubmitController  load method starts here...");
		
		String tiReq = (String)session.getAttribute("tireqid");
		String actId = (String)session.getAttribute("activityid");
		
		Long tiReqId = Long.valueOf(0);
		Long activityId = Long.valueOf(0);
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		if(actId!=null){
		    try{activityId=Long.valueOf(actId);}catch(Exception e){activityId = Long.valueOf(0);}
		}
		log.debug("tiReq:"+tiReq+"ActivityId"+activityId);
		String taskId = (String) session.getAttribute("taskId");
		if(StringUtil.isNullorEmpty(actId)){
			activityId = workflowUtil.getAuditTrailId(activityId, taskId);
		}
		
		submitActivityProcess = new SubmitActivityProcess();
		//supplementary review roles display
		HashMap<String,String> roles = submitActivityProcess.findInstanceId(tiReqId, activityId);
		submitActivityProcess.setRoles(roles);
		List<LookUpVO> supReviewRole = submitActivityProcess.getSupReviewRoles((String)roles.get("ROLE"));
		log.debug("GISSubmitController...:"+supReviewRole.size());
		submitActivityProcess.setSupReviewRoles(supReviewRole);
		
		//RISO Approval List
		List<GenericLookup> risoApprovalList = submitActivityProcess.getRISOEmail();
		log.debug("GIS Mad Controller...:"+risoApprovalList.size());
		submitActivityProcess.setRisoApprovalList(risoApprovalList);
		log.debug("GIS Mad Controller:"+submitActivityProcess.getRisoApprovalList());
		
		//RISO TEMP APPROVAL REASONS		
		List<GenericLookup> tempApprovalReasonList = submitActivityProcess.getTempApprovalReasons();
		log.debug("GIS Mad Controller Temp Approval Reasons...:"+tempApprovalReasonList.size());
		submitActivityProcess.setTempApprovalReasonsList(tempApprovalReasonList);
		log.debug("GIS Mad Controller Temp Approval Reasons:: "+submitActivityProcess.getTempApprovalReasonsList());
		
		//set activity role
		submitActivityProcess.setActivityRole((String)roles.get("ROLE"));
		session.setAttribute("activityRole",submitActivityProcess.getActivityRole());
		log.debug("activity role:"+submitActivityProcess.getActivityRole());
		
		/*//setInstanceID
		String instanceId = (String)roles.get("INST_ID");
		session.setAttribute("instanceID", instanceId);
		log.debug("instanceId"+instanceId);*/
		
		// setTaskID
		log.debug("*********taskId************" + taskId);

		//Approval comments display
		String role = (String)roles.get("ROLE");
		submitActivityProcess.setTiReqCmtsList(submitActivityProcess.getComments(tiReqId, role, "A"));
		
		//Discussion comments display
		submitActivityProcess.setDiscussCmtsList(submitActivityProcess.getComments(tiReqId, role, "D"));
		
		//Activity code
		String activityCode = (String)request.getParameter("activityCode");		
		submitActivityProcess.setTiprocessDTO(null);
		submitActivityProcess.setRequestID(Long.valueOf(tiReqId));
		TIProcessDTO objprocessDTO = submitActivityProcess.getTiprocessDTO();
		log.debug("objprocessDTO : " + objprocessDTO);
		if(objprocessDTO!=null)
		{
			log.debug("FirewallType : " + objprocessDTO.getFirewallType());
			log.debug("ProxyType : " + objprocessDTO.getProxyType());
			log.debug("ProxyRegion : " + objprocessDTO.getProxyRegion());			
			log.debug("IsACLVariance : " + objprocessDTO.getIsACLVariance());
			log.debug("AppsenseType() : " + objprocessDTO.getAppsenseType());
			log.debug("IsIPReg : " + objprocessDTO.getIsIPReg());
		}
		
		session.setAttribute("TPASWGRSTATUS", submitActivityProcess.getTPASWGReviewStatus());
		session.setAttribute("TPASWGRTYPE", submitActivityProcess.getTPASWGReviewType());
		
		model.addAttribute("gisProcess", submitActivityProcess);
		
		if("mad_app".equalsIgnoreCase(activityCode)){
			return "c3par.madSubmit";
		}
		
		return "c3par.gisSubmit";
	}
	
	@RequestMapping(value = "/saveGISSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String save(ModelMap model,@ModelAttribute("gisProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request) throws Exception{
	log.info("GISSubmitController:Save method starts here...");
	formSubmit(submitActivityProcess,result,session,request);
	return "forward:/logon.act?forwardTo=bpm";
		
	}
	
	@RequestMapping(value = "/sendRisoEmail.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String sendEmail(ModelMap model,@ModelAttribute("gisProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request) throws Exception{
		log.info("Saving form here...");
		formSubmit(submitActivityProcess,result,session,request);
		log.info("GIS Submit Controller:Send mail method starts here...");
		
		String tiReq = (String)session.getAttribute("tireqid");
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );
		
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		
		CitiContact risoContact = submitActivityProcess.getUserIdForSsoId(submitActivityProcess.getRisoSSOID().toUpperCase());
		//Send email
		submitActivityProcess.sendRisoEmail(tiReqId,submitActivityProcess.getComments(), risoContact);
		 
		return "redirect:/loadGISSubmit.act";
	}
	
	
	@RequestMapping(value = "/submitGISSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String submit(ModelMap model,@ModelAttribute("gisProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request) {
	log.info("GISSubmitController:submit method starts here...");
	
	try {
		formSubmit(submitActivityProcess,result,session,request);
		log.debug("GISSubmitController Submit PAPI Enter ");
		
		//WsPapiFacade papiFacade = new WsPapiFacade ();
		
		String taskId = (String)session.getAttribute("taskId");
		String userId  = request.getHeader("SM_USER");
		String nextSelectedAction = submitActivityProcess.getCurrentAction();
		String nextRole = null;
		
		log.debug("taskId: " + taskId +"action"+nextSelectedAction);
		log.debug("userId: " + userId);
		log.debug("Before calling PAPI For BJ Submit");
		
		String tiReq = (String)session.getAttribute("tireqid");
		
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );	
		
		if(tiReq!=null){ 
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
			
		log.info("GIS submit : tiReqId=" + tiReqId ); 
		
		ApplicationContext appContext = CCRApplicationContextUtils.getApplicationContext();
		ManageTIProcessImpl manageTIProcess=(ManageTIProcessImpl)appContext.getBean("manageTIProcess");
		
		log.info("Bypass ServiceNow Flag : "+submitActivityProcess.isBypassServiceNow());
		log.info("FirewallType Flag : "+submitActivityProcess.getFirewallType());
		log.info("ProxyType Flag : "+submitActivityProcess.getProxyType());		
		log.info("AppsenseType Flag : "+submitActivityProcess.getAppsenseType());
		log.info("IsIPReg Flag : "+submitActivityProcess.getIsIPReg());
		log.info("IsACLVariance Flag : "+submitActivityProcess.getIsACLVariance());
		
		if(((submitActivityProcess.getFirewallType()==null || "".equals(submitActivityProcess.getFirewallType())) && 
		(submitActivityProcess.getProxyType()!=null && !"".equals(submitActivityProcess.getProxyType()))) || 
		((submitActivityProcess.getProxyType()==null || "".equals(submitActivityProcess.getProxyType())) && 
		(submitActivityProcess.getFirewallType()!=null && !"".equals(submitActivityProcess.getFirewallType())))
		&& submitActivityProcess.getAppsenseType()!=null && submitActivityProcess.getAppsenseType().equals("No")
		&& submitActivityProcess.getIsIPReg()!=null && submitActivityProcess.getIsIPReg().equals("No")
		&& submitActivityProcess.getIsACLVariance()!=null && submitActivityProcess.getIsACLVariance().equals("No"))
		{
			if(submitActivityProcess.isBypassServiceNow()==true)
				manageTIProcess.updateByPassSNOWFlag(tiReqId, "Y");
			else
				manageTIProcess.updateByPassSNOWFlag(tiReqId, "N");
		}
		if("TEMP_APPROVED".equalsIgnoreCase(nextSelectedAction)){
			
			/*
			List<ObjectError> risoApprovalList = validator.getRisoApprovalDocument(tiReqId);
			
			log.debug("GIS submit : risoApprovalList : size "+risoApprovalList.size());
			
			for (ObjectError error : risoApprovalList) {
				result.addError(error);
			}
			*/
			request.setAttribute("errorMsg", result.getAllErrors());
			if (result.getAllErrors() != null && !result.getAllErrors().isEmpty()){
				if (result.getAllErrors().size() == 1
						&& (result.getAllErrors().get(0) == null || result.getAllErrors().get(0).getCode() == null 
						|| result.getAllErrors().get(0).getCode().isEmpty())) {
					request.setAttribute("errorMsgCount", 0);
				} else {
				request.setAttribute("errorMsgCount", result.getAllErrors().size());
				}
				//redirecting to error page
				load(model,submitActivityProcess,result,session,request);
				return "c3par.gisSubmit";
			}else{
				request.setAttribute("errorMsgCount", 0);
			}
			 
			//log.debug("error risoApprovalList log:"+risoApprovalList+"count:"+ result.getErrorCount());
			
			
			
		}
		
		
		
		
		if("REJECTED".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getRejectRole());
		}else if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getProvideInfoRole());
		}else if("MOVED".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getMovedRole());
		}else {
			nextRole = util.moveToActivity(submitActivityProcess.getCurrentRole());
		}
		
		log.debug("Selected role:"+nextRole);
		
		if ("UNLOCKED".equals( nextSelectedAction ) || "COMPLETED".equals( nextSelectedAction ) ) {
			papiFacade.completeActivity(userId, taskId, nextSelectedAction); 
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("REJECTED".equalsIgnoreCase(nextSelectedAction)){
			log.debug("inside Rejected scenario..."+nextSelectedAction);
			papiFacade.completeActivity(userId, taskId, WsPapiFacade.ActivityStatus.REJECTED, WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.completeActivity(userId, taskId, WsPapiFacade.ActivityStatus.PROVIDEINFO,WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("MOVED".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.completeActivity(userId, taskId, WsPapiFacade.ActivityStatus.MOVED,WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("MOVED_TO_LOG_QUEUE".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.completeActivity(userId, taskId,"MOVED_TO_LOG_QUEUE");
			return "forward:/defaultInboxView.act";
			//return "forward:/logon.act?forwardTo=bpm";
		}
		
		if("DEFERRED".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.completeActivity(userId, taskId,"DEFERRED");
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("TEMP_APPROVED".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.tempApprovalActivity(userId, taskId,"TEMP_APPROVED",submitActivityProcess.getReviewTempDate());
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
	 } catch (OperationException_Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	return "forward:/defaultInboxView.act";
		
	}
	
	
	//data collection
    private void formSubmit(SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session,
			HttpServletRequest request)throws Exception{
    	log.debug("GISSubmitController form Submit begins...");
    	String messgXML = (String)request.getSession().getAttribute("MESSAGEXML");
		log.info("messgXML::"+messgXML);
		
		String tiReq = (String)session.getAttribute("tireqid");
		
		submitActivityProcess.setActivityRole((String)session.getAttribute("activityRole"));
		log.debug("activity role inside form submit:"+submitActivityProcess.getActivityRole());
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );
		
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		
		//Getting request type
		TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
		
		if(submitActivityProcess.getCurrentAction()==null){
			submitActivityProcess.setCurrentAction(ActivityData.STATUS_COMPLETED);
		}
		
		if(submitActivityProcess.getCurrentRole()==null){
			submitActivityProcess.setCurrentRole(submitActivityProcess.getActivityRole());
		}
		
		//update ValidUntil and TPASWG date
		String sbfTempAppDateTime1 ="";
		String sbfSchDateTime1 ="";
		
		if(submitActivityProcess.getReviewTempDate() !=null && !submitActivityProcess.getReviewTempDate().isEmpty()){
			sbfTempAppDateTime1= submitActivityProcess.getReviewTempDate();
		}else{
			sbfTempAppDateTime1="";
		}
		

		if(submitActivityProcess.getReviewSchDate() != null && !submitActivityProcess.getReviewSchDate().isEmpty()){
			sbfSchDateTime1 =submitActivityProcess.getReviewSchDate() ; 
		}else{
			sbfSchDateTime1 ="";
		}
		
		String raNo = "";
		String tempAppReason="";
		
		if(submitActivityProcess.getRaReNumber() !=null && !submitActivityProcess.getRaReNumber().isEmpty()){
			raNo= submitActivityProcess.getRaReNumber();
		}else{
			raNo="";
		}
		

		if(submitActivityProcess.getTempApprovalReason() !=null && !submitActivityProcess.getTempApprovalReason().isEmpty()){
			tempAppReason= submitActivityProcess.getTempApprovalReason();
		}else{
			tempAppReason="";
		}
		

		
		
		
		submitActivityProcess.tpwgUpdate(tiReqId, submitActivityProcess.getTpwReviewType(), "",sbfSchDateTime1, "", sbfTempAppDateTime1);
		submitActivityProcess.updateRisoDetails(tiReqId, tempAppReason, raNo);
		
		
		//Updating logging queue details
		 if(submitActivityProcess.getCurrentAction()!=null
				    && "MOVED_TO_LOG_QUEUE".equalsIgnoreCase(submitActivityProcess.getCurrentAction())) {
			 	String logUntil = "";
			 	
			 	if(submitActivityProcess.getReviewHoldDate() == null){
			 		logUntil= null;
			 	}else{
			 		logUntil = submitActivityProcess.getReviewHoldDate();
			 	}
			 	
		    	int recommendedLoggingPeriod = 0;
		    	
		    	if(submitActivityProcess.getRecommendedLoggingPeriod() == 0){
		    		recommendedLoggingPeriod= 0;
		    	}else{
		    		recommendedLoggingPeriod = submitActivityProcess.getRecommendedLoggingPeriod();
		    	}
		    	
		    	submitActivityProcess.updateLoggingDetails(tiReqId, logUntil, recommendedLoggingPeriod);
		    	log.debug("inside update logging queue details:"+logUntil+""+recommendedLoggingPeriod);
		  }
		 
		 //Update Ostia question
		 if(!(submitActivityProcess.getCurrentAction()!=null && (submitActivityProcess.getCurrentAction().trim().equalsIgnoreCase(ActivityData.ACTIVITY_ABORTED)))
				 || submitActivityProcess.getCurrentAction().trim().equalsIgnoreCase("REJECTED") ||
				 	submitActivityProcess.getCurrentAction().trim().equalsIgnoreCase("PROVIDEINFO") ||
				 	submitActivityProcess.getCurrentAction().trim().equalsIgnoreCase("UNLOCKED")){					
			 		submitActivityProcess.updateOstiaQuestionairre(tiReqId);
		}

		log.info("Request Parameters::"+request.getParameterNames());
		log.info("Request current role="+request.getParameter("currentRole"));
		log.info("current action =" + submitActivityProcess.getCurrentAction());
		log.info("current role=" + submitActivityProcess.getCurrentRole());
		log.info("comments = " + submitActivityProcess.getComments());
		

		String ssoID = request.getHeader("SM_USER");
		
		TiRequestComments tiReqComments = new TiRequestComments();
		tiReqComments.setTiRequest(tiRequest);
		tiReqComments.setComments(submitActivityProcess.getComments());
		tiReqComments.setRoleName(submitActivityProcess.getActivityRole());
		tiReqComments.setApproverSoeID(ssoID);
		
		submitActivityProcess.deleteSupReviewRoles(tiReqId,submitActivityProcess.getActivityRole());
		submitActivityProcess.insertSupReviewRoles(tiReqId,submitActivityProcess.getActivityRole(),submitActivityProcess.getSelectedSupReviewRoles());

		//updating tiRequest comments
		if(!"PROVIDEINFO".equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
			submitActivityProcess.addComments(tiReqComments, "A", "save");
		}else {
			submitActivityProcess.addComments(tiReqComments, "D", "save");
		}
		
		
			
    }
}
