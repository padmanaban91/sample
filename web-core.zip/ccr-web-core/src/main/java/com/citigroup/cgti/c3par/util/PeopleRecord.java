package com.citigroup.cgti.c3par.util;

public class PeopleRecord {
	private String soeid;
	private String infoManName;
	private String reporterPhone;
	private String error;

	public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

	public String getInfoManName() {
		return infoManName;
	}

	public void setInfoManName(String infoManName) {
		this.infoManName = infoManName;
	}

	public String getReporterPhone() {
		return reporterPhone;
	}

	public void setReporterPhone(String reporterPhone) {
		this.reporterPhone = reporterPhone;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}
}
