package com.citigroup.cgti.c3par.webtier.controller.communication;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.communication.domain.ECMUserSearchProcess;

@Controller
public class EcmUserSearhController {
	private static Logger log = Logger.getLogger(EcmUserSearhController.class);
	
	
	@RequestMapping(value = "/searchEcmUsers.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String loadEcmUsers(ModelMap model, @ModelAttribute("ecmUserSearchProcess") ECMUserSearchProcess ecmUserSearchProcess
									,HttpServletRequest request) {
				log.info("EcmUsersearchController::SearchEcmUsers methods starts...");
				String searchText = request.getParameter("searchText");
				//TO get the Identification from which functionality Ecm User popup.
				String searchFrom ="";
				searchFrom=request.getParameter("searchFrom"); 
				String fieldName = request.getParameter("fieldName");
			
				List<ECMUserSearchProcess> ecmUsersList = ecmUserSearchProcess.selectEcmUsers(searchText);  
				 
					 ecmUserSearchProcess.setAssignedUser(fieldName);
					 if(searchFrom!=null){ 
					 
					 ecmUserSearchProcess.setSearchFrom(searchFrom);  
					 }else{
						 
						  ecmUserSearchProcess.setSearchFrom("");   
					 }
					 ecmUserSearchProcess.setItemValueList(ecmUsersList);
				model.addAttribute("ecmUserSearchProcess",ecmUserSearchProcess); 
				log.info("EcmUsersearchController::SearchEcmUsers::methods Ends ");
				return "pages/communication/searchInEcmUsers";   
	}
 
	
}
