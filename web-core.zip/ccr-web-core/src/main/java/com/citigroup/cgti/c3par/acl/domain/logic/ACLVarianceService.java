package com.citigroup.cgti.c3par.acl.domain.logic;

import com.citigroup.cgti.c3par.acl.domain.ACLVariance;
import com.citigroup.cgti.c3par.domain.TIProcess;


/**
 * The Interface ACLVariancePersistable.
 */
public interface ACLVarianceService {


    /**
     * Gets the aCL variance data.
     *
     * @param tiProcess the ti process
     * @return the aCL variance data
     */
    public ACLVariance getACLVarianceData(TIProcess tiProcess);
    
    /**
     * Gets the aCL variance.
     *
     * @param tiProcess the ti process
     * @return the aCL variance
     */
    public ACLVariance getACLVariance(TIProcess tiProcess);

    /**
     * Store acl variance.
     *
     * @param aclVariance the acl variance
     */
    public void storeACLVariance(ACLVariance aclVariance);

    /**
     * Delete acl variance.
     *
     * @param aclVariance the acl variance
     */
    public void deleteACLVariance(ACLVariance aclVariance);


    /**
     * Update acl variance.
     *
     * @param aclVariance the acl variance
     */
    public void updateACLVariance(ACLVariance aclVariance);
}