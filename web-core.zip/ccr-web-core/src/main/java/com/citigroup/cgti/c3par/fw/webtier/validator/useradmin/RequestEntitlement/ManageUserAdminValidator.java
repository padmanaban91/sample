package com.citigroup.cgti.c3par.fw.webtier.validator.useradmin.RequestEntitlement;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.citigroup.cgti.c3par.common.domain.AdminProcess;

public class ManageUserAdminValidator implements Validator {
	
	private static Logger log = Logger.getLogger(ManageUserAdminValidator.class);

	@Override
	public boolean supports(Class<?> paramClass) {
		return AdminProcess.class.equals(paramClass);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		 
		log.debug("Entering into validate method of req enti");
		
		AdminProcess adminProcess = (AdminProcess)obj; 
		if (adminProcess.getC3parUser().getSsoId() == null 
				|| adminProcess.getC3parUser().getSsoId().isEmpty()) {		
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "c3parUser.ssoId", "valid");			
		}
		
		if (adminProcess.getC3parUser().getFirstName() == null 
				|| adminProcess.getC3parUser().getFirstName().isEmpty()) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "c3parUser.firstName", "valid");			
		}
		
		if (adminProcess.getC3parUser().getLastName() == null 
				|| adminProcess.getC3parUser().getLastName().isEmpty()) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "c3parUser.lastName", "valid");			
		}
		
		if (adminProcess.getC3parUser().getEmail() == null 
				|| adminProcess.getC3parUser().getEmail().isEmpty()) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "c3parUser.email", "valid");			
		}
		
		if (adminProcess.getC3parUser().getEmployeeType() == null 
				|| adminProcess.getC3parUser().getEmployeeType().isEmpty()) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "c3parUser.employeeType", "valid");			
		}
		
		 log.debug("Exiting from validate method of req enti");		
	}
}
