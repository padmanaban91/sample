package com.citigroup.cgti.c3par.webtier.controller.admin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.admin.domain.ManageTpaMasterDTO;
import com.citigroup.cgti.c3par.admin.service.ManageTpaMasterService;
import com.citigroup.cgti.c3par.appsense.domain.TpaSubnetMaster;
import com.citigroup.cgti.c3par.fw.service.SubnetUtils;

@Controller
public class ManageSubnetMasterListController {

	private Logger log = Logger.getLogger(this.getClass().getName());

	@Autowired
	ManageTpaMasterService manageTpaMasterService;

	@RequestMapping(value = "/searchManageTpaMaster.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String searchManageTpaMaster(ModelMap model,
			@ModelAttribute("manageTpaMasterProcess") ManageTpaMasterDTO manageTpaMasterDTO, BindingResult result) {
		String forward = "c3par.useradmin.manageTpaMaster";
		boolean addError = false;
		boolean noResult = false;

		try {
			List<ManageTpaMasterDTO> manageTpaMasterDTOList = new ArrayList<ManageTpaMasterDTO>();
			manageTpaMasterDTO.setManageTpaMasterDTOList(manageTpaMasterDTOList);
			if (manageTpaMasterDTO.getSearchIp() != null && manageTpaMasterDTO.getSearchIp().trim().length() > 0) {
				String ipAddress = manageTpaMasterDTO.getSearchIp();
				log.info("*******Given Search IP Address*********" + ipAddress);
				log.info("Inside Search Ip methods starts...");
				
				List<TpaSubnetMaster> tpaSubnetMasterList = manageTpaMasterService.getIpDetails(ipAddress);
				ManageTpaMasterDTO manageTpaMaster = null;
				if (tpaSubnetMasterList.size() > 0) {
					for (TpaSubnetMaster tpaSubnetMaster : tpaSubnetMasterList) {
						manageTpaMaster = new ManageTpaMasterDTO();
						manageTpaMaster.setIpAddress(tpaSubnetMaster.getIpAddress());
						manageTpaMaster.setStartIPAddress(tpaSubnetMaster.getStartIPAddress());
						manageTpaMaster.setEndIPAddress(tpaSubnetMaster.getEndIPAddress());
						manageTpaMaster.setSubnet(tpaSubnetMaster.getSubnet());
						manageTpaMaster.setNoOfHost(tpaSubnetMaster.getNoOfHost());
						manageTpaMaster.setBroadCastAddress(tpaSubnetMaster.getBroadCastAddress());
						manageTpaMaster.setCreatedBy(tpaSubnetMaster.getCreatedBy());
						manageTpaMaster.setUpdatedBy(tpaSubnetMaster.getUpdatedBy());
						manageTpaMaster.setCreated_date(tpaSubnetMaster.getCreated_date());
						manageTpaMaster.setUpdated_date(tpaSubnetMaster.getUpdated_date());
						manageTpaMasterDTOList.add(manageTpaMaster);
					}
					manageTpaMasterDTO.setManageTpaMasterDTOList(manageTpaMasterDTOList);
				} else {
					log.info("Inside else : No search result for the given criteria : "
							+ manageTpaMasterDTO.getSearchIp());
					noResult = true;
				}
			} else {
				log.info("****************Else part****************");
				addError = true;
			}
		} catch (Exception e) {
			log.info("*****Exception:****** " + e);
			addError = true;
		}
		if (addError) {
			log.info("ManageSubnetMasterListController::searchManageTpaMaster:: Ip Address Empty");
			result.addError(new ObjectError("manageTpaMasterDTO.ipAddress", new String[] { "admin.IPAddressEmpty" },
					null, null));
		}
		if (noResult) {
			log.info("ManageSubnetMasterListController::searchManageTpaMaster:: No Records found...");
			result.addError(new ObjectError("manageTpaMasterDTO.ipAddress", new String[] { "admin.NoIPSearchResult" },
					null, null));

		}
		model.addAttribute("manageTpaMasterProcess", manageTpaMasterDTO);
		return forward;
	}

	@RequestMapping(value = "/loadManageTpaMaster.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadManageTpaMaster(ModelMap model,
			@ModelAttribute("manageTpaMasterProcess") ManageTpaMasterDTO manageTpaMasterDTO, BindingResult result) {
		log.debug("ManageSubnetMasterListController::manageTpaMaster methods starts...");
		String forward = "c3par.useradmin.manageTpaMaster";
		return forward;
	}

	@RequestMapping(value = "/deleteManageTpaMaster.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String editManageTpaMaster(ModelMap model,
			@ModelAttribute("manageTpaMasterProcess") ManageTpaMasterDTO manageTpaMasterDTO, BindingResult result,
			HttpServletRequest request) {
		boolean addError = false;
		boolean delResult = false;
		String updatedUser = request.getHeader("SM_USER");
		try {
			List<ManageTpaMasterDTO> manageTpaMasterDTOList = manageTpaMasterDTO.getManageTpaMasterDTOList();

			if (manageTpaMasterDTOList != null && manageTpaMasterDTOList.size() > 0) {
				Iterator<ManageTpaMasterDTO> iterator = manageTpaMasterDTOList.iterator();
				while (iterator.hasNext()) {
					ManageTpaMasterDTO dto1 = iterator.next();
					log.info("ManageTPAController::deleteManageTPAList" + dto1.getIpAddress() + "------"
							+ dto1.isSelected());
					if (dto1.isSelected()) {
						manageTpaMasterService.deleteManageTpaMasterList(dto1.getIpAddress(), updatedUser);
						delResult = true;
						log.info("*****************Remove IP Address:" + dto1.getIpAddress());
						iterator.remove();
					}
				}

			}

			manageTpaMasterDTO.setIpAddress("");
			manageTpaMasterDTO.setDeleteIp("");
			log.info("***********IPList Size : " + manageTpaMasterDTO.getManageTpaMasterDTOList().size());
			model.addAttribute("manageTpaMasterDTO", manageTpaMasterDTO);
		} catch (Exception e) {
			log.info("*****Exception:****** " + e);
			addError = true;
		}
		if (addError) {
			System.out
					.println("ManageSubnetMasterListController::deleteManageTpaMaster:: Ip Address cannot be deleted");
			result.addError(
					new ObjectError("manageTpaMasterDTO.ipAddress", new String[] { "admin.notdeleteIp" }, null, null));
		}
		if (delResult) {
			log.info("ManageSubnetMasterListController::deleteManageTpaMaster:: Ip Address deleted");
			result.addError(
					new ObjectError("manageTpaMasterDTO.startIPAddress", new String[] { "admin.deletedIP" }, null, null));
		} else {
			log.info("ManageSubnetMasterListController::deleteManageTpaMaster:: No IP Selected");
			result.addError(
					new ObjectError("manageTpaMasterDTO.ipAddress", new String[] { "admin.noIpSelected" }, null, null));
		}
		return "c3par.useradmin.manageTpaMaster";
	}

	@RequestMapping(value = "/saveManageTpaMaster.act", method = { RequestMethod.POST })
	public String saveManageTpaMaster(ModelMap model,
			@ModelAttribute("manageTpaMasterProcess") ManageTpaMasterDTO manageTpaMasterDTO, BindingResult result,
			HttpServletRequest request) {
		log.info("************Save Tpa Master******************");
		boolean addError = false;
		boolean invalidIPError = false;
		boolean duplicateIp = false;
		boolean addedIp = false;
		boolean subnetIPError = false;
		SubnetUtils subnetUtils = null;
		String IP_ADDRESS = "(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})";
		String SLASH_FORMAT = IP_ADDRESS + "/(\\d{1,3})";
		Pattern addressPattern = Pattern.compile(IP_ADDRESS);
		Pattern cidrPattern = Pattern.compile(SLASH_FORMAT);
		log.info("*******Given IP Address*********" + manageTpaMasterDTO.getIpAddress());
		try {
			if (manageTpaMasterDTO.getIpAddress() != null && manageTpaMasterDTO.getIpAddress().trim().length() > 0) {

				List<TpaSubnetMaster> tpaSubnetMasterList = manageTpaMasterService
						.getExactIpDetails(manageTpaMasterDTO.getIpAddress());
				if (tpaSubnetMasterList.size() > 0) {
					log.info("*****Inside tpaSubnetMasterList.size()>0 block:****** ");
					duplicateIp = true;
				} else {
					Matcher ipMatcher = addressPattern.matcher(manageTpaMasterDTO.getIpAddress());
					Matcher subnetMatcher = cidrPattern.matcher(manageTpaMasterDTO.getIpAddress());
					if (subnetMatcher.matches() && manageTpaMasterDTO.getSelectedType().equals("Subnet")) {
						subnetUtils = new SubnetUtils(manageTpaMasterDTO.getIpAddress());
						manageTpaMasterDTO.setStartIPAddress(subnetUtils.getInfo().getLowAddress());
						manageTpaMasterDTO.setEndIPAddress(subnetUtils.getInfo().getHighAddress());
						manageTpaMasterDTO.setSubnet(subnetUtils.getInfo().getAddress());
						manageTpaMasterDTO.setNoOfHost(Long.valueOf(subnetUtils.getInfo().getAddressCount()));
						manageTpaMasterDTO.setBroadCastAddress(subnetUtils.getInfo().getBroadcastAddress());
						manageTpaMasterDTO.setCreatedBy(request.getHeader("SM_USER"));
						manageTpaMasterService.saveManageTpaMasterList(manageTpaMasterDTO);
						addedIp = true;
					} else if (ipMatcher.matches() && manageTpaMasterDTO.getSelectedType().equals("Individual")) {
						manageTpaMasterDTO.setStartIPAddress(manageTpaMasterDTO.getIpAddress());
						manageTpaMasterDTO.setEndIPAddress(manageTpaMasterDTO.getIpAddress());
						manageTpaMasterDTO.setSubnet(null);
						manageTpaMasterDTO.setNoOfHost(1L);
						manageTpaMasterDTO.setBroadCastAddress(null);
						manageTpaMasterDTO.setCreatedBy(request.getHeader("SM_USER"));
						manageTpaMasterService.saveManageTpaMasterList(manageTpaMasterDTO);
						addedIp = true;
					} else {
						log.info("****************Invalid ip part****************");
						invalidIPError = true;

					}
				}
			} else {
				log.info("****************Else part****************");
				addError = true;
			}
		} catch (IllegalArgumentException ex) {
			log.info("*****Exception block:****** " + ex.getMessage());
			subnetIPError = true;
		} catch (Exception e) {
			log.info("*****Exception block:****** " + e);
			invalidIPError = true;
		}
		if (addError) {
			log.info("ManageSubnetMasterListController::saveManageTpaMaster:: Ip Address Empty");
			result.addError(new ObjectError("manageTpaMasterDTO.ipAddress", new String[] { "admin.IPAddressEmpty" },
					null, null));
		}
		if (invalidIPError) {
			log.info("ManageSubnetMasterListController::saveManageTpaMaster:: Ip Address invalid");
			result.addError(
					new ObjectError("manageTpaMasterDTO.ipAddress", new String[] { "admin.invalidIP" }, null, null));
		}
		if (duplicateIp) {
			log.info(
					"ManageSubnetMasterListController::saveManageTpaMaster:: Invalid or Duplicate IP Address...");
			result.addError(
					new ObjectError("manageTpaMasterDTO.ipAddress", new String[] { "admin.DuplicateIP" }, null, null));
		}
		if (addedIp) {
			log.info(
					"ManageSubnetMasterListController::saveManageTpaMaster:: IP Address added successfully...");
			result.addError(
					new ObjectError("manageTpaMasterDTO.startIPAddress", new String[] { "admin.IPAdd" }, null, null));
		}
		
		if (subnetIPError) {
			log.info(
					"ManageSubnetMasterListController::saveManageTpaMaster:: Subnet Mask Bits out of range...");
			result.addError(
					new ObjectError("manageTpaMasterDTO.startIPAddress", new String[] { "admin.SubnetIPError" }, null, null));
		}

		manageTpaMasterDTO.setIpAddress(null);
		manageTpaMasterDTO.setStartIPAddress(null);
		manageTpaMasterDTO.setEndIPAddress(null);
		manageTpaMasterDTO.setSubnet(null);
		manageTpaMasterDTO.setNoOfHost(null);
		manageTpaMasterDTO.setBroadCastAddress(null);
		manageTpaMasterDTO.setCreatedBy(null);
		manageTpaMasterDTO.setDeleteIp(null);
		model.addAttribute("manageTpaMasterProcess", manageTpaMasterDTO);

		return "c3par.useradmin.manageTpaMaster";
	}
	
	/*method to initialize the size of Collection using WebDataBinder*/
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    binder.setAutoGrowCollectionLimit(1500);
	}


}
