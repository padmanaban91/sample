package com.citigroup.cgti.c3par.persistance;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.dialect.Dialect;
import org.hibernate.id.Configurable;
import org.hibernate.id.PersistentIdentifierGenerator;
import org.hibernate.id.TableGenerator;
import org.hibernate.type.Type;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.internal.util.config.ConfigurationHelper;


/**
 * An <tt>IdentifierGenerator</tt> that uses a database
 * table with a particular key to store the last generated value. It is not
 * intended that applications use this strategy directly. 
 * However, it may be used to build other (efficient) 
 * strategies. The returned type is <tt>Long</tt>.<br>
 * <br>
 * The hi value MUST be fetched in a seperate transaction
 * to the <tt>Session</tt> transaction so the generator must 
 * be able to obtain a new connection and commit it. Hence 
 * this implementation may not be used when Hibernate is 
 * fetching connections from an application server datasource 
 * or when the user is supplying connections.<br>
 * <br>
 * The returned value is of type <tt>Long</tt>.<br>
 * <br>
 * Mapping parameters supported: table, column, wherecolumn, wherecolumnvalue
 * 
 * @see TableHiLoGenerator
 * @author Sudeep Subhedar
 */
public class KeyGenerator extends TableGenerator implements PersistentIdentifierGenerator, Configurable {

    /** The column parameter. */
    public static final String COLUMN = "column";

    /** The table parameter. */
    public static final String TABLE = "table";

    /** The Constant WHERECOLUMN. */
    public static final String WHERECOLUMN = "wherecolumn";

    /** The Constant WHERECOLUMNVALUE. */
    public static final String WHERECOLUMNVALUE = "wherecolumnvalue";

    /** The Constant log. */
    private static final Log log = LogFactory.getLog(TableGenerator.class);

    /** The table name. */
    private String tableName;

    /** The column name. */
    private String columnName;

    /** The where column name. */
    private String whereColumnName;

    /** The where column value. */
    private String whereColumnValue;

    /** The query. */
    private String query;

    /** The update. */
    private String update;

    /* (non-Javadoc)
     * @see org.hibernate.id.TableGenerator#configure(org.hibernate.type.Type, java.util.Properties, org.hibernate.dialect.Dialect)
     */
    public void configure(Type type, Properties params, Dialect dialect) {

	this.tableName = ConfigurationHelper.getString(TABLE, params, "hibernate_unique_key");
	this.columnName = ConfigurationHelper.getString(COLUMN, params, "next_hi");
	this.whereColumnName = ConfigurationHelper.getString(WHERECOLUMN, params, "entity");
	this.whereColumnValue = ConfigurationHelper.getString(WHERECOLUMNVALUE, params, "Test");
	String schemaName = params.getProperty(SCHEMA);
	if ( schemaName!=null && tableName.indexOf(".")<0 ) 
	    tableName = schemaName + '.' + tableName;

	query = "select " + columnName + " from " + tableName+ " where "+whereColumnName+ " = ?";
	update = "update " + tableName + " set " + columnName + " = ? where " + columnName + " = ?"+" and "+whereColumnName+ " = ?";
    }

    /* (non-Javadoc)
     * @see org.hibernate.id.TableGenerator#generate(org.hibernate.engine.SessionImplementor, java.lang.Object)
     */
    public synchronized Serializable generate(SessionImplementor session, Object object) throws HibernateException {

	// This has to be done using a different connection to the
	// containing transaction because the new hi value must
	// remain valid even if the containing transaction rolls
	// back
	Connection conn  = session.connection();
	int result;
	int rows;
	try {
	    if ( conn.getAutoCommit() ) conn.setAutoCommit(false);

	    do {
		// The loop ensures atomicity of the
		// select + update even for no transaction
		// or read committed isolation level

		PreparedStatement qps = conn.prepareStatement(query);
		try {
		    qps.setString( 1, whereColumnValue );
		    ResultSet rs = qps.executeQuery();
		    if ( !rs.next() ) {
			String err = "could not read the next key value - you need to populate the table: " + tableName;
			log.error(err);
			throw new HibernateException(err);
		    }
		    result = rs.getInt(1);
		    rs.close();
		}
		catch (SQLException sqle) {
		    log.error("could not read th next key value", sqle);
		    throw sqle;
		}
		finally {
		    qps.close();
		}

		PreparedStatement ups = conn.prepareStatement(update);
		try {
		    ups.setInt( 1, result + 1 );
		    ups.setInt( 2, result );
		    ups.setString( 3, whereColumnValue );
		    rows = ups.executeUpdate();
		}
		catch (SQLException sqle) {
		    log.error("could not update the next key value in: " + tableName, sqle);
		    throw sqle;
		}
		finally {
		    ups.close();
		}
	    }
	    while (rows==0);

	    conn.commit();

	    return Long.valueOf(result);

	} catch (SQLException e) {
	    throw new HibernateException(e);
	}
	finally {
		 try {
	    	   session.connection().close();
	    	  } catch (SQLException e) {
	    	   e.printStackTrace();
	    	   log.debug("could not update the next key value in: " + tableName +e);
	    	   throw new HibernateException(e);
	    	  }	
	}
    }


    /* (non-Javadoc)
     * @see org.hibernate.id.TableGenerator#sqlCreateStrings(org.hibernate.dialect.Dialect)
     */
    public String[] sqlCreateStrings(Dialect dialect) throws HibernateException {
	return new String[] {
		"create table " + tableName + " ( " + columnName + " " + dialect.getTypeName(Types.INTEGER) + " )",
		"insert into " + tableName + " values ( 0 )"
	};
    }

    /**
     * Sql drop string.
     *
     * @param dialect the dialect
     * @return the string
     */
    public String sqlDropString(Dialect dialect) {
	//return "drop table " + tableName + dialect.getCascadeConstraintsString();
	StringBuffer sqlDropString = new StringBuffer()
	.append("drop table ");
	if ( dialect.supportsIfExistsBeforeTableName() ) sqlDropString.append("if exists ");
	sqlDropString.append(tableName)
	.append( dialect.getCascadeConstraintsString() );
	if ( dialect.supportsIfExistsAfterTableName() ) sqlDropString.append(" if exists");   
	return sqlDropString.toString();
    }

    /* (non-Javadoc)
     * @see org.hibernate.id.TableGenerator#generatorKey()
     */
    public Object generatorKey() {
	return tableName;
    }

}
