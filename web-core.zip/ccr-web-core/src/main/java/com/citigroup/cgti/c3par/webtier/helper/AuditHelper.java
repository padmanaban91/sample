package com.citigroup.cgti.c3par.webtier.helper;

import java.util.Date;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.RelationshipAuditDAO;
import com.citigroup.cgti.c3par.model.RelationshipAuditEntity;

import com.mentisys.dao.DatabaseException;
import com.mentisys.model.Entity;


/**
 * The Class AuditHelper.
 */
public class AuditHelper
{

    /** The Constant ACTION_ADD. */
    public static final String ACTION_ADD = "Added";

    /** The Constant ACTION_MOD. */
    public static final String ACTION_MOD = "Modified";

    /** The Constant ACTION_DEL. */
    public static final String ACTION_DEL = "Deleted";

    /**
     * Do audit.
     *
     * @param db_session the db_session
     * @param user_name the user_name
     * @param entity the entity
     * @param comment the comment
     * @throws DatabaseException the database exception
     */
    public static void doAudit(C3parSession db_session, String user_name, Entity entity, String comment) throws DatabaseException
    {
	if(db_session == null)
	{
	    db_session = new C3parSession();
	}
	RelationshipAuditEntity auditEntity = new RelationshipAuditEntity();

	auditEntity.setEntityId(entity.getId());
	auditEntity.setEntityName(entity.getEntityName());
	auditEntity.setModifiedBy(user_name);
	auditEntity.setDateChanged(new Date());

	RelationshipAuditDAO dao = new RelationshipAuditDAO(db_session);
	dao.insert(auditEntity);
    }

}

