package com.citigroup.cgti.c3par.controller.businessjustification;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.util.CollectionUtils;

import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiContactXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiReqConXref;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.RelationshipProcess;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetail;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetailAnswer;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.webtier.helper.C3parStatusLookupNames;
import com.citigroup.cgti.c3par.webtier.helper.Util;

public class BusJusBaseController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	public void completionCheck(HttpServletRequest request, ConnectionRequest conreq, TIRequest tirequest) {
		String relationship="false", businessCase = "false", conBasicInfo = "false", emerbuscrit = "false", citicontact = "false";

		BusinessJustificationProcess busjusProcess = new BusinessJustificationProcess();

		if(isRelationshipCompleted(conreq,tirequest)){
			relationship = "true";
		}
		
		if(isBusincessCaseCompleted(conreq,tirequest)){
			businessCase = "true";
		}
		
		if(isConnectionBasicInfoCompleted(busjusProcess, conreq, tirequest)){
			conBasicInfo = "true";
		}
		
		if(isEmerBuscritInformationComplete(busjusProcess, conreq, tirequest)){
			emerbuscrit = "true";
		}

		if(isCitiContactsCompleted(busjusProcess, conreq, tirequest)){
			citicontact = "true";
		}
		request.getSession().setAttribute("isRelationshipComplete", relationship);
		request.getSession().setAttribute("isbusinessCaseComplete", businessCase);
		request.getSession().setAttribute("isconBasicInfoComplete", conBasicInfo);
		request.getSession().setAttribute("isemerbuscritComplete", emerbuscrit);
		request.getSession().setAttribute("isciticontactComplete", citicontact);
		
    }
	
	private boolean isRelationshipCompleted(ConnectionRequest conreq, TIRequest tirequest){
		RelationshipProcess proces=new RelationshipProcess();
		Relationship relationship = tirequest.getTiProcess().getRelationshipId();
		if (relationship != null) {
			if (C3parStaticNames.CITI_IP.equalsIgnoreCase(relationship.getRelationshipType())
					|| C3parStaticNames.IP_TEMPLATE
							.equalsIgnoreCase(relationship.getRelationshipType())
					|| C3parStaticNames.TEMPLATE_OBJ
							.equalsIgnoreCase(relationship.getRelationshipType())
					|| C3parStaticNames.CITI_CON
							.equalsIgnoreCase(relationship.getRelationshipType())) {
				if (relationship.getRequesterResourceType() == null
						|| relationship.getRequesterResourceType().getId() == null
						|| relationship.getRequesterResourceType().getId().longValue() == 0) {
						return false;
				}
				if(!proces.isValidateThridPartyConts(relationship.getId(), relationship.getRelationshipType(), null,null))
				return false;
			}
			
			if (C3parStaticNames.THIRD_PARTY
							.equalsIgnoreCase(relationship.getRelationshipType())) {
				if (relationship.getTargetResourceType() == null
								|| relationship.getTargetResourceType().getId() == null
								|| relationship.getTargetResourceType().getId()
										.longValue() == 0) {
					return false;
					
				}
				
				if(CollectionUtils.isEmpty(relationship.getRelThirdPartyContXref())){
					return false;
				}
				
			}
			
		}
		if ((relationship.getRelationshipType() != null) && (C3parStaticNames.THIRD_PARTY
				.equalsIgnoreCase(relationship.getRelationshipType())
				|| C3parStaticNames.U_TURN
						.equalsIgnoreCase(relationship.getRelationshipType()))) {
			if (relationship.getThirdParty()== null || relationship.getThirdParty().getId()==null) {
				return false;
			}
			if (C3parStaticNames.U_TURN
					.equalsIgnoreCase(relationship.getRelationshipType())) {
				if (relationship.getUturnThirdParty()== null || relationship.getUturnThirdParty().getId()== 0) {
					return false;
				}
				if(!proces.isValidateThridPartyConts(relationship.getId(), relationship.getRelationshipType(), relationship.getThirdParty().getId(), relationship.getUturnThirdParty().getId()))
					return false;
			}
			if(C3parStaticNames.THIRD_PARTY.equalsIgnoreCase(relationship.getRelationshipType()))
			if(!proces.isValidateThridPartyConts(relationship.getId(), relationship.getRelationshipType(), relationship.getThirdParty().getId(), null))
				return false;
		}
		
		if(relationship!=null &&  CollectionUtils.isEmpty(relationship.getRelcitiHierarchyXrefs())){
			return false;	
		}
		
		
		if ((relationship.getRelationshipType() != null)
				&& C3parStaticNames.U_TURN.equalsIgnoreCase(relationship.getRelationshipType())) {
			if(relationship.getThirdParty()==null || relationship.getUturnThirdParty()==null ){
				return false;
			}
			
			
			if ((relationship.getThirdParty().getCaspId() == null || relationship.getUturnThirdParty().getCaspId() == null)
					|| (relationship.getThirdParty().getDetailId() == null
							|| relationship.getUturnThirdParty().getDetailId() == null
							)
					|| (relationship.getThirdParty().getParentId() == null
							|| relationship.getUturnThirdParty().getParentId() == null
							)) {
				return false;
			}
		}
		
		if ((relationship.getRelationshipType() != null) && C3parStaticNames.U_TURN
				.equalsIgnoreCase(relationship.getRelationshipType())) {
			if ((relationship.getThirdParty().getCaspId() != null
					&& relationship.getUturnThirdParty().getCaspId() != null
					&& relationship.getThirdParty().getCaspId()
							.longValue() == relationship.getUturnThirdParty().getCaspId()
									.longValue())
					&& (relationship.getThirdParty().getDetailId() != null
							&& relationship.getUturnThirdParty().getDetailId() != null
							&& relationship.getThirdParty().getDetailId()
									.longValue() == relationship.getUturnThirdParty()
											.getDetailId().longValue())
					&& (relationship.getThirdParty().getParentId() != null
							&& relationship.getUturnThirdParty().getParentId() != null
							&& relationship.getThirdParty().getParentId()
									.longValue() == relationship.getUturnThirdParty()
											.getParentId().longValue())) {
				return false;
			}
		}
		if(relationship!=null && relationship.getId()!=null && C3parStatusLookupNames.NOT_CERTIFIED.equals(relationship.getStatus())){
			proces.updateRelationshipStatus(relationship.getId(), C3parStatusLookupNames.CERTIFIED);
		}
		return true;
	}
	
	
	private boolean isBusincessCaseCompleted(ConnectionRequest conreq, TIRequest tirequest){
		
		Relationship relationship = tirequest.getTiProcess().getRelationshipId();

		if (C3parStaticNames.CITI_CON.equalsIgnoreCase(relationship.getRelationshipType())) {
			if( conreq.getRationale()!= null &&  conreq.getRationale().length()!= 0 
				&& conreq.getColookup() != null && conreq.getColookup().getCustomerDataId() != null && conreq.getColookup().getCustomerDataId().longValue() != 0 
				&& conreq.getColookup().getCitigroupDataId() != null && conreq.getColookup().getCitigroupDataId().longValue() != 0
				&& conreq.getConnectivityEstimate() !=null && conreq.getConnectivityEstimate().length() !=0
				&& (((tirequest.getCmpId() != null && tirequest.getCmpId().length() != 0)&& (conreq.getDetailedInfo() != null && conreq.getDetailedInfo().length() != 0))
						|| (tirequest.getSnowId() != null && tirequest.getSnowId().length() != 0))
				&& (conreq.getPlcode() != null && conreq.getPlcode().length() != 0)) {
					return true;
				} else {
					return false;
				}
		} else if(C3parStaticNames.U_TURN.equalsIgnoreCase(relationship.getRelationshipType())){
			if( conreq.getRationale()!= null &&  conreq.getRationale().length()!= 0 
				&& conreq.getColookup() != null && conreq.getColookup().getCustomerDataId() != null && conreq.getColookup().getCustomerDataId().longValue() != 0 
				&& conreq.getColookup().getCitigroupDataId() != null && conreq.getColookup().getCitigroupDataId().longValue() != 0
				&& conreq.getConnectivityEstimate() !=null && conreq.getConnectivityEstimate().length() !=0
				&& (((tirequest.getCmpId() != null && tirequest.getCmpId().length() != 0)&& (conreq.getDetailedInfo() != null && conreq.getDetailedInfo().length() != 0))
						|| (tirequest.getSnowId() != null && tirequest.getSnowId().length() != 0))
				&& (conreq.getPlcode() != null && conreq.getPlcode().length() != 0)) {
				return true;
			} else {
				return false;
			}
		}else { 
			if(	conreq.getRationale() != null &&  conreq.getRationale().length()!= 0 
				&& conreq.getColookup() != null && conreq.getColookup().getCustomerDataId() != null && conreq.getColookup().getCustomerDataId().longValue() != 0
				&& conreq.getColookup().getCitigroupDataId() != null && conreq.getColookup().getCitigroupDataId().longValue() != 0
				&& (conreq.getConforcustclient() != null && !conreq.getConforcustclient() .isEmpty())
				&& (conreq.getDirectAccessByThirdparty() != null && !conreq.getDirectAccessByThirdparty() .isEmpty()) 
				&& conreq.getConnectivityEstimate() !=null && conreq.getConnectivityEstimate().length() !=0
				&& (((tirequest.getCmpId() != null && tirequest.getCmpId().length() != 0)&& (conreq.getDetailedInfo() != null && conreq.getDetailedInfo().length() != 0))
						|| (tirequest.getSnowId() != null && tirequest.getSnowId().length() != 0))
				&& (conreq.getPlcode() != null && conreq.getPlcode().length() != 0)) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	private boolean isConnectionBasicInfoCompleted(BusinessJustificationProcess busjusProcess, ConnectionRequest conreq, TIRequest tirequest){
		
		if(tirequest.getTiProcess().getProcessName() == null || tirequest.getTiProcess().getProcessName().isEmpty() )
		{
			log.debug("tirequest.getTiProcess().getProcessName() :: null");			
			return false;
		}

		RFCRequest rfcRequest= busjusProcess.getGenericRFCRequest(tirequest);
		String[] affectedBusiness = getAffectedBusinessDetail(rfcRequest);

		if(affectedBusiness == null || affectedBusiness.length == 0){
			log.debug("affectedBusiness == null	");
			return false;
		}

		return true;
	}

	private boolean isCitiContactsCompleted(BusinessJustificationProcess busjusProcess, ConnectionRequest conreq, TIRequest tirequest){
		Long planningId = busjusProcess.getPlanningId(tirequest.getId());
		
		Util util= new Util();
		boolean isDESelected = false;
		boolean isBISOSelected = false;
		boolean isPrjCrdSelected = false;
		boolean isDIRSelected = false;
		boolean hasNotify = false;
		boolean isRequestorSelected=false;
		boolean isBusinessOwner=false;
		boolean isBusinessTester=false;
		String priority ="";
		/*String empType=util.getEmployeeTypeFromC3parUsers(tirequest.getTiProcess().getId());
		if(empType!=null && empType.equalsIgnoreCase("E")){
			isBusMgrSelected = true;
		}*/
		
		Relationship relationship = tirequest.getTiProcess().getRelationshipId();
		List<ContactDetailsDTO> citiconlist = new ArrayList<ContactDetailsDTO>();
		
		if(C3parStaticNames.U_TURN.equalsIgnoreCase(relationship.getRelationshipType()) || C3parStaticNames.CITI_CON.equalsIgnoreCase(relationship.getRelationshipType())){
			List<ConReqCitiReqConXref> requesterContacts = busjusProcess.getRequesterContactsList(planningId);

			for (ConReqCitiReqConXref requesterContact : requesterContacts) {
				ContactDetailsDTO contact = new ContactDetailsDTO();
				
				contact.setRole(requesterContact.getRole().getDisplayName());
				contact.setPrimaryContact(requesterContact.getPrimaryContact());
				contact.setIsreject(requesterContact.getIsreject());
				contact.setNotifyContact(requesterContact.getNotifyContact());
				
				citiconlist.add(contact);
	    	}
			
		}else{
			List<ConReqCitiContactXref> targetContacts = busjusProcess.getTargetContactsList(planningId);

			for (ConReqCitiContactXref targetContact : targetContacts) {
				ContactDetailsDTO contact = new ContactDetailsDTO();

				contact.setRole(targetContact.getRole().getDisplayName());
				contact.setPrimaryContact(targetContact.getPrimaryContact());
				contact.setIsreject(targetContact.getIsreject());
				contact.setNotifyContact(targetContact.getNotifyContact());
				
				citiconlist.add(contact);
	    	}
		}
		
		Iterator it = null;
		priority = tirequest.getPriority().getValue1();
		
		for(ContactDetailsDTO citicontact:citiconlist){
			
			String roleName=citicontact.getRole();
			
			log.debug("Inside Iterator Role name ::"+roleName+ ", isPrimary() ::"+citicontact.getPrimaryContact()+", getIsreject :: "+citicontact.getIsreject());
			
			if(isDESelected == false && roleName!=null && roleName.trim().equals("Technical Coordinator") && citicontact.getPrimaryContact().equalsIgnoreCase("Y") && (citicontact.getIsreject() == null || citicontact.getIsreject().equalsIgnoreCase("N"))){
				isDESelected = true;
			}else if(isBISOSelected == false && roleName!=null && roleName.trim().equals("ISO") && citicontact.getPrimaryContact().equalsIgnoreCase("Y") && (citicontact.getIsreject() == null || citicontact.getIsreject().equalsIgnoreCase("N"))){
				isBISOSelected = true;
			}else if(isPrjCrdSelected == false && roleName!=null && roleName.trim().equals("Project Coordinator") && citicontact.getPrimaryContact().equalsIgnoreCase("Y") && (citicontact.getIsreject() == null || citicontact.getIsreject().equalsIgnoreCase("N"))){
				isPrjCrdSelected = true;
			}else if(isDIRSelected == false && roleName!= null && roleName.trim().equalsIgnoreCase("Director") && citicontact.getPrimaryContact().equalsIgnoreCase("Y") && (citicontact.getIsreject() == null || citicontact.getIsreject().equalsIgnoreCase("N"))){
				isDIRSelected = true;
			}else if(isRequestorSelected == false && roleName!= null && roleName.trim().equalsIgnoreCase("Requestor") && citicontact.getPrimaryContact().equalsIgnoreCase("Y") && (citicontact.getIsreject() == null || citicontact.getIsreject().equalsIgnoreCase("N"))){
				isRequestorSelected = true;
			}else if(isBusinessOwner == false && roleName!= null && roleName.trim().equalsIgnoreCase("Business Owner") && citicontact.getPrimaryContact().equalsIgnoreCase("Y") && (citicontact.getIsreject() == null || citicontact.getIsreject().equalsIgnoreCase("N"))){
				isBusinessOwner = true;
			}else if(isBusinessTester == false && roleName!= null && roleName.trim().equalsIgnoreCase("Business Tester") && citicontact.getPrimaryContact().equalsIgnoreCase("Y") && (citicontact.getIsreject() == null || citicontact.getIsreject().equalsIgnoreCase("N"))){
				isBusinessTester = true;
			}

			if ("Y".equals(citicontact.getNotifyContact())) {
				hasNotify = true;
			}
		}

		log.debug("isDESelected ::"+isDESelected+ ", isBISOSelected ::"+isBISOSelected+", isDIRSelected :: "+isDIRSelected+", isPrjCrdSelected :: "+isPrjCrdSelected
				+", hasNotify :: "+hasNotify+", isRequestorSelected :: "+isRequestorSelected+", isBusinessOwner :: "+isBusinessOwner+", isBusinessOwner :: "+isBusinessOwner);
		
		if(C3parStaticNames.EMER.equalsIgnoreCase(priority) || C3parStaticNames.BUSCRIT.equalsIgnoreCase(priority)){
			if(isDESelected && isBISOSelected && isDIRSelected && isPrjCrdSelected && hasNotify && isRequestorSelected && isBusinessOwner && isBusinessOwner)
				return true;
			else
				return false;
		}else{
			if(isDESelected && isBISOSelected && hasNotify && isPrjCrdSelected && isRequestorSelected && isBusinessOwner && isBusinessTester)
				return true;
			else
				return false;
		}
	}
	
	private boolean isEmerBuscritInformationComplete(BusinessJustificationProcess busjusProcess, ConnectionRequest conreq, TIRequest tirequest)
	{
		RFCRequest rfcRequest= busjusProcess.getEMERGenericRFCRequest(tirequest, "Y");
		 if( rfcRequest != null && rfcRequest.getDescription() != null && rfcRequest.getDescription().getRfcDetailAnswerList() != null){
			 List<RFCDetailAnswer> rfcDetailAnswerList = rfcRequest.getDescription().getRfcDetailAnswerList();
			 boolean noAnswer = true;
			 for (RFCDetailAnswer rfcDetailAnswer : rfcDetailAnswerList) {
				 noAnswer = false;
				 if(rfcDetailAnswer.getAnswer() == null || (rfcDetailAnswer.getAnswer() != null && rfcDetailAnswer.getAnswer().isEmpty())){
					 return false;
				 }
			 }
			 log.info("isEmerBuscritInformationComplete :: " + noAnswer);
			return !noAnswer;
		} else {
			 return false;
		}
	}
	
    protected String[] getAffectedBusinessDetail(RFCRequest rfcRequest) {
    	
    	String []affBArray = null;
		try{
		    if(rfcRequest != null){			
				if(rfcRequest.getAffectedBusiness() != null){
				    RFCDetail affectedBusinessDetail = rfcRequest.getAffectedBusiness();
				    if(affectedBusinessDetail != null){
						List<RFCDetailAnswer> rfcAnswerList = affectedBusinessDetail.getRfcDetailAnswerList();
						Iterator<RFCDetailAnswer> rfcAnsItr = rfcAnswerList.iterator();
						affBArray = new String[rfcAnswerList.size()];
						int counter = 0;
						
						while (rfcAnsItr.hasNext()) {
						    RFCDetailAnswer rfcAns = (RFCDetailAnswer) rfcAnsItr.next();
						    if(rfcAns.getAnswer() != null){
							log.info("RFCDetailAnswer " + rfcAns.getAnswer());
							affBArray[counter] = rfcAns.getAnswer().toString();
							counter = counter+1;
						    }
						}
						log.debug("RFCDetailAnswer in array size" + affBArray.length);
				    }
				}
		    }
		} catch (Exception e) {
		    log.error(e, e);
		}
		return affBArray;
    }

}
