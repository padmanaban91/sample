package com.citigroup.cgti.c3par.controller.firewallpoc;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.decisionservice.DecisionServiceSoapFault;
import com.citigroup.cgti.c3par.decisionservice.TiRequestDTO;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestion;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.Port;
import com.citigroup.cgti.c3par.fw.domain.PossibleAnswers;
import com.citigroup.cgti.c3par.fw.domain.RiskDefinition;
import com.citigroup.cgti.c3par.fw.domain.soc.riskreview.RiskReviewExternalizable;
import com.citigroup.cgti.c3par.fwpoc.domain.FirewallRulepocProcess;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;





@Controller 
public class FirewallRuleControllerpoc {
	
	
   // @Autowired
    private RiskReviewExternalizable riskReviewExternalizable;
    
	
	private Logger log = Logger.getLogger(this.getClass().getName());
	
    @RequestMapping(value = "/addNewRulePagePoc", method = RequestMethod.GET)
	public String addNewRulePage(Model model) { 
    	log.info("FirewallRuleController :: addNewRulePagepoc initated");
		FirewallRulepocProcess firewallruleprocess = new FirewallRulepocProcess();	
		model.addAttribute("firewallruleprocess",firewallruleprocess);
		log.info("FirewallRuleController :: addNewRulePagepoc started");
		return "pages/jsp/fw/addNewFireWallRulePoc";
	}	
	 
	
	@RequestMapping(value = "/saveFirewallRulepoc",  method = {
			RequestMethod.GET, RequestMethod.POST })
	public String saveFirewallRuleDetails( Model model,@ModelAttribute("firewallruleprocess") FirewallRulepocProcess firewallruleprocess, BindingResult result, HttpServletRequest request) {
		
		log.info("saveFirewallRulepoc Calling iLog Rule Engine......................");
		
		Enumeration names = request.getParameterNames();
		String value;
		String name;
		while(names.hasMoreElements()){
			name = (String)names.nextElement();
			value = request.getParameter(name);
			log.debug("Name: "+ name +" Value: "+ value);
		}
		
		String relationshipType = null;
		String sourceResourceType = null;
		String targetResourceType = null;
		String requestPriority = null;
		String region = null;
		String sector = null;
		String businessUnit = null;
		String thirdParty = null;
		String uturnThirdParty = null;
		String connectionType = null;
		String broadAccessFlag = null;
		String tpaFlag = null;
		String sourceNetworkZone = null;
		String destinationNetworkZone = null;
		
		boolean otherPortExist = false;
		otherPortExist = firewallruleprocess.getFirewallRulepoc().isOtherPortExist();
		log.debug("is Other Port Exis::::"+ otherPortExist );
		log.debug("is Other Port Exis::::"+ firewallruleprocess.getFirewallRulepoc().isOtherPortExist());
		
		
		
		broadAccessFlag = firewallruleprocess.getFirewallRulepoc().getTpa();
		tpaFlag = firewallruleprocess.getFirewallRulepoc().getBroadAccess();
		sourceResourceType = firewallruleprocess.getFirewallRulepoc().getSourceResourceType();
		targetResourceType =  firewallruleprocess.getFirewallRulepoc().getTargetResourceType();
		relationshipType = firewallruleprocess.getFirewallRulepoc().getRelationshipType();
		
		if (relationshipType != null && relationshipType.equalsIgnoreCase("THIRD_PARTY")) {
			thirdParty = "THIRD_PARTY";
		}
		if (relationshipType != null && relationshipType.equalsIgnoreCase("U_TURN")) {
			uturnThirdParty = "U_TURN";
		}
		
		sourceNetworkZone = firewallruleprocess.getFirewallRulepoc().getSourceZone();
		destinationNetworkZone = firewallruleprocess.getFirewallRulepoc().getDestinationZone();
		
		
		log.debug("relationshipType: "+relationshipType);
		log.debug("sourceResourceType: "+sourceResourceType);
		log.debug("targetResourceType: "+targetResourceType);
		log.debug("requestPriority: "+requestPriority);
		log.debug("region: "+region);
		log.debug("sector: "+sector);
		log.debug("businessUnit: "+businessUnit);
		log.debug("thirdParty: "+thirdParty);
		log.debug("uturnThirdParty: "+uturnThirdParty);
		log.debug("connectionType: "+connectionType);
		log.debug("broadAccessFlag: "+broadAccessFlag);
		log.debug("tpaFlag: "+tpaFlag);
		log.debug("sourceNetworkZone: "+sourceNetworkZone);
		log.debug("destinationNetworkZone: "+destinationNetworkZone);
		
		/*
		FirewallRuleDTO firewallRuleDTO=new FirewallRuleDTO();
		ruleRequestHelper.ruleRequestMapping(firewallRuleDTO, firewallruleprocess);
		rulesService.executeRules(firewallRuleDTO);
		*/
		//firewallruleprocess.setFirewallRule(firewallRuleDTO);
		//ostiaQuestionnaireMap = riskReviewExternalizable.executeRiskRules(rule, tiRequestDTO, tiRequest.getId());
		
		
		FireWallRule fireWallRule = new FireWallRule();
		
		
		ResourceType srcResourceType = new ResourceType();
		srcResourceType.setName(sourceNetworkZone);
		fireWallRule.setSourceNetworkZone(srcResourceType);
		
		ResourceType destResourceType = new ResourceType();
		destResourceType.setName(destinationNetworkZone);
		fireWallRule.setDestinationNetworkZone(destResourceType);
		
		fireWallRule.setRiskSourceIPs(new ArrayList<FireWallRuleIP>());
		FireWallRuleIP fireWallRuleSourceIP = null;
		
		for (int i = 0; i < firewallruleprocess.getFirewallRulepoc().getSourceIPs().size(); i++) {
			log.debug("sourceIPs::"+firewallruleprocess.getFirewallRulepoc().getSourceIPs().get(i));
			fireWallRuleSourceIP = new FireWallRuleIP();
			IPAddress ipAddress = new IPAddress();
			fireWallRuleSourceIP.setIpAddress(ipAddress);
			fireWallRuleSourceIP.getIpAddress().setIpAddress(firewallruleprocess.getFirewallRulepoc().getSourceIPs().get(i).toString());
			fireWallRuleSourceIP.getIpAddress().setTpaFlag(firewallruleprocess.getFirewallRulepoc().getTpa());
			fireWallRuleSourceIP.getIpAddress().setAnyIP("Y");
			fireWallRule.getRiskSourceIPs().add(fireWallRuleSourceIP);
		}
		
		fireWallRule.setRiskDestinationIPs(new ArrayList<FireWallRuleIP>());
		FireWallRuleIP fireWallRuleDestinationIP = null;
		for (int i = 0; i < firewallruleprocess.getFirewallRulepoc().getDestinationIPs().size(); i++) {
			log.debug("destinationiPs::"+firewallruleprocess.getFirewallRulepoc().getDestinationIPs().get(i));
			fireWallRuleDestinationIP = new FireWallRuleIP();
			IPAddress ipAddress = new IPAddress();
			fireWallRuleDestinationIP.setIpAddress(ipAddress);
			fireWallRuleDestinationIP.getIpAddress().setIpAddress(firewallruleprocess.getFirewallRulepoc().getDestinationIPs().get(i).toString());
			fireWallRuleDestinationIP.getIpAddress().setTpaFlag(firewallruleprocess.getFirewallRulepoc().getTpa());
			fireWallRuleDestinationIP.getIpAddress().setAnyIP("Y");
			fireWallRule.getRiskDestinationIPs().add(fireWallRuleDestinationIP); 
		}
		
		fireWallRule.setRiskPorts(new ArrayList<FireWallRulePort>());
		FireWallRulePort firewallRulePort = null;
		log.debug(">>>>>>PortSize::"+firewallruleprocess.getFirewallRulepoc().getPortNumbers().size());
		//log.debug(">>>>>>OtherPortSize::"+firewallruleprocess.getFirewallRulepoc().getOtherPorts().size());
		
		for (int i = 0; i < firewallruleprocess.getFirewallRulepoc().getPortNumbers().size(); i++) {
				log.debug("PortSProtocol::"+firewallruleprocess.getFirewallRulepoc().getProtocols().get(i));
				log.debug("PortNumber::"+firewallruleprocess.getFirewallRulepoc().getPortNumbers().get(i));
			//	log.debug("OtherPort::"+firewallruleprocess.getFirewallRulepoc().getOtherPorts().get(i));
				firewallRulePort = new FireWallRulePort();
				Port port = new Port();
				
				port.setProtocol(firewallruleprocess.getFirewallRulepoc().getProtocols().get(i).toString());
				port.setPortNumber(firewallruleprocess.getFirewallRulepoc().getPortNumbers().get(i).toString());
				firewallRulePort.setPort(port);
				if( firewallruleprocess.getFirewallRulepoc().getOtherPorts()!=null && i < firewallruleprocess.getFirewallRulepoc().getOtherPorts().size()){
				    firewallRulePort.setDefaultService(firewallruleprocess.getFirewallRulepoc().getOtherPorts()
							.get(i)!=null?"Y":"N");
				}else{
					firewallRulePort.setDefaultService("N");
				}
				fireWallRule.getRiskPorts().add(firewallRulePort);
		}
		fireWallRule.setBoardAccess(firewallruleprocess.getFirewallRulepoc().getBroadAccess());
		fireWallRule.setTpa(firewallruleprocess.getFirewallRulepoc().getTpa());
		TiRequestDTO tiRequestDTO = new TiRequestDTO();
		tiRequestDTO.setRelationshipType(relationshipType);
		tiRequestDTO.setSourceResourceType(sourceResourceType);
		tiRequestDTO.setTargetResourceType(targetResourceType);
		tiRequestDTO.setRequestPriority(requestPriority); 
		tiRequestDTO.setRegion(region);
		tiRequestDTO.setSector(sector); 
		tiRequestDTO.setBusinessUnit(businessUnit);
		tiRequestDTO.setConnectionType(connectionType);
		tiRequestDTO.setThirdParty(thirdParty);
		tiRequestDTO.setUturnThirdParty(uturnThirdParty);  
		
		
		fireWallRule.setId(new Long(210));
		TIRequest tiRequest = new TIRequest(); 
		TIProcess tiProcess = new TIProcess();
		tiProcess.setId(new Long(2426)); 
		tiRequest.setId(new Long(2480));
		tiRequest.setTiProcess(tiProcess);
		fireWallRule.setTiRequest(tiRequest);
		log.info("Connection ID:......................");
		log.debug("ConnectionID::::::::::::::::::::::::::"+fireWallRule.getTiRequest().getTiProcess().getId()+"TIR:"
				+fireWallRule.getTiRequest().getId()+"~FWR:"+fireWallRule.getId());
		 
		log.info("Before Calling iLog Rule Engine......................");
		//Connection ID : 77876 
		// TI Request ID : 236548L 
		//Rule ID : 332742
		HashMap<String, OstiaQuestionnaire> ostiaQuestionnaireMap = null;
		
	  
		try {
			log.info("Calling iLog Rule Engine Exection......................");
			fireWallRule.setDrools(true);
			ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
			CCRBeanFactory ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
			ostiaQuestionnaireMap = riskReviewExternalizable.executeRiskRules(fireWallRule, tiRequestDTO, 210L);
			
			
		} catch (DecisionServiceSoapFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info("After Calling iLog Rule Engine......................");
		
		
		OstiaQuestionnaire ostiaQuestionnaire = null;
		//ostiaQuestionnaire = ostiaQuestionnaireMap.get("REQUEST");
		ostiaQuestionnaire = ostiaQuestionnaireMap.get("FWRULE");
		firewallruleprocess.setRequestOstiaQuestionnaires(ostiaQuestionnaireMap.get("REQUEST"));
		firewallruleprocess.setOstiaQuestionnaires(ostiaQuestionnaire);
		log.info("Firewall Rule Engine Output......................");
		
		
		List<RiskDefinition> riskDefinitionList = ostiaQuestionnaire.getRiskDefinitions();
		log.debug("Risk Definintion started ......................"+riskDefinitionList.size());
		for (RiskDefinition riskDefinition : riskDefinitionList) {
			riskDefinition.getRiskCode();
			riskDefinition.getRiskDescription();
			riskDefinition.getRiskRating();
			log.debug("Risk Definintion List FWRule....Risk Code ::"+riskDefinition.getRiskCode()+":: Ris Description ::"+riskDefinition.getRiskDescription()+"::Risk Rating "+riskDefinition.getRiskRating());
			List<OstiaQuestion> ostiaQuestionList = riskDefinition.getOstiaQuestions();
			
			log.debug("Ostia Questionaire started ......................"+ostiaQuestionList.size());
			
			for (OstiaQuestion ostiaQuestion : ostiaQuestionList) {
				ostiaQuestion.getQuestion();
				ostiaQuestion.getHint();
				ostiaQuestion.getAnswerType();
				ostiaQuestion.getQuestionControlNumber();
				List<PossibleAnswers> possibleAnswersList = ostiaQuestion.getPossibleAnswers();
				for(PossibleAnswers possibleAnswers: possibleAnswersList){
					possibleAnswers.getOptionsGroupName();
					possibleAnswers.getAnswer();
					
				}
				
				log.debug("Ostia Question ::"+ostiaQuestion.getQuestion()+"::Hint"+ostiaQuestion.getHint()+"::Answer Type ::"+ostiaQuestion.getAnswerType());
			}
		}
		
		
		
		/*ostiaQuestionnaire = null;
		ostiaQuestionnaire = ostiaQuestionnaireMap.get("REQUEST");
		List<RiskDefinition> riskDefinitionLists = ostiaQuestionnaire.getRiskDefinitions();
		log.debug("Risk Definintion Request started ......................"+riskDefinitionLists.size());
		for (RiskDefinition riskDefinition : riskDefinitionList) {
			riskDefinition.getRiskCode();
			riskDefinition.getRiskDescription();
			riskDefinition.getRiskRating();
			log.debug("Risk Definintion List Request ....Risk Code ::"+riskDefinition.getRiskCode()+":: Ris Description ::"+riskDefinition.getRiskDescription()+"::Risk Rating "+riskDefinition.getRiskRating());
			List<OstiaQuestion> ostiaQuestionList = riskDefinition.getOstiaQuestions();
			
			log.debug("Ostia Questionaire started ......................"+ostiaQuestionList.size());
			
			for (OstiaQuestion ostiaQuestion : ostiaQuestionList) { 
				
			
				ostiaQuestion.getQuestion();
				ostiaQuestion.getHint(); 
				ostiaQuestion.getAnswerType();
				
				log.debug("Ostia Question ::"+ostiaQuestion.getQuestion()+"::Hint"+ostiaQuestion.getHint()+"::Answer Type ::"+ostiaQuestion.getAnswerType());
			}
		}
		
		*/
		model.addAttribute("firewallruleprocess", firewallruleprocess);
		return "pages/jsp/fw/questionareFireWallRule";
		
	}
	
	@RequestMapping(value = "/showviewQuestionarePage", method = RequestMethod.POST)
	public String showviewQuestionarePage(Model model) { 
		log.info("FirewallRuleController :: showviewQuestionarePage");
		FirewallRulepocProcess firewallruleprocess = new FirewallRulepocProcess();	
		model.addAttribute("firewallruleprocess",firewallruleprocess);
		log.info("FirewallRuleController :: showviewQuestionarePage started:::::::::::::::::");
		return "pages/jsp/fw/questionareFireWallRule";
	}
	
	@RequestMapping(value = "/saveOstiaQuestionnaire", method = RequestMethod.POST)
	public String saveOstiaQuestionnaireDetails( Model model,@ModelAttribute("firewallruleprocess") FirewallRulepocProcess firewallruleprocess, BindingResult result) {
		
		log.info("FirewallRuleController 		:: saveOstiaQuestionnaire ::");
		log.info("------------------------------------------------------------------------------------------------------------------");
		log.info("								RULE OUTPUT::");
		log.info("------------------------------------------------------------------------------------------------------------------");
		log.info("PORT_80:					::");
		
		
		//System.out.println("Single Answer1 					::"+firewallruleprocess.getFirewallRulepoc().getOstiaQuestionSingleAnswer1());
		//System.out.println("Text Answer1			::"+firewallruleprocess.getFirewallRulepoc().getOstiaQuestionTextAnswer1());
		
		 
		
		//System.out.println("RISK_GENERIC:				::");
		
		//System.out.println("Single Answer 2					::"+firewallruleprocess.getFirewallRulepoc().getOstiaQuestionSingleAnswer2());
		//System.out.println("Text Answer 2			::"+firewallruleprocess.getFirewallRulepoc().getOstiaQuestionTextAnswer2());
		
		model.addAttribute("firewallruleprocess", firewallruleprocess);
		return "pages/jsp/fw/addQuestionnaireSuccess";
		
	}
	
	
}
