package com.citigroup.cgti.c3par.controller.search;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.search.domain.SearchProcess;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

@Controller
public class SearchController  {

	private static final long serialVersionUID = 1L;
	private final String PROCESSLIST = "PROCESSLIST";
	private final String TOTALPAGES = "TOTALPAGES";
	private final String TIREQID = "tireqid";
	private final String SEARCHFORM = "SEARCHFORM";
	private final static String GENERIC_SEARCH_COLUMN_NAMES= "ID, Name, Activity, Phase, Type, TI Process, Priority, Participant \n";

	@Autowired
	WsPapiFacade papiFacade;
	
	@Autowired
	AdminServicePersistable adminServicePersistable;
	
	@Autowired
	ManageTIProcessImpl manageTIProcessImpl;

	/** The log. */
	private static Logger log = Logger.getLogger(SearchController.class);

	/**
	 * onLoad
	 * 
	 * @return load_search
	 */
	
	@RequestMapping(value = "/loadSearch.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String onLoad(ModelMap model,HttpServletRequest request) {
		log.info("SearchAction.onLoad method starts ");
		SearchProcess searchProcess = new SearchProcess();
		try {
			
			searchProcess.setSearchType("GENERAL");
			searchProcess.setProcessList(new ArrayList());
			searchProcess.setProxyInstList(new ArrayList());
			searchProcess.setTptList(new ArrayList());
			searchProcess.setBuList(new ArrayList());
			searchProcess.setSectorList(new ArrayList());
			searchProcess.setProxyRegionList(new ArrayList());
			searchProcess.setTaskActivityList(new ArrayList());
			searchProcess.setPageNo(0);
			searchProcess.setTotalPages(0);
			log.debug("jfghj" +searchProcess.getPageNo() +searchProcess.getTotalPages() +searchProcess.getPageSize());
			request.getSession().setAttribute("PROCESSLIST", new ArrayList());
			request.getSession().setAttribute("TOTALPAGES", Integer.valueOf(0));
			
		} catch (Exception ex) {
			//addActionError("Exception Occurred");
			log.error(ex, ex);
		}
		model.addAttribute("searchProcess", searchProcess);
		log.info("SearchAction.onLoad method ends ");
		return "c3par.loadSearch.new";
	}
	
	@RequestMapping(value = "/loadSectorListForSearch.act", method = { RequestMethod.GET, RequestMethod.POST })
	public  String loadSectorList(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.loadSectorList method starts ");
		try {
			String searchType= searchProcess.getSearchType();
            if(searchType != null&& searchType.equalsIgnoreCase("SEARCH_BY_CONTACT")){
            	searchProcess.getGeneralSearchAttributes().setRegion(searchProcess.getSearchByContactAttributes().getRegion());
                    log.debug("region of SearchByContact:"+searchProcess.getSearchByContactAttributes().getRegion());
            }
            searchProcess.setSectorList(searchProcess.getSectorList());
            searchProcess.setPageSize(10);

            searchProcess.setProxyRegionList(new ArrayList());
            searchProcess.setProxyInstList(new ArrayList());

			if (request.getSession().getAttribute("PROCESSLIST")!= null) {
				log
						.debug("SearchAction.loadSectorList method :Getting ProcessList form Session");
				searchProcess.setProcessList((List) request.getSession().getAttribute("PROCESSLIST"));
			} else {
				log
						.debug("SearchAction.loadSectorList method :setting ProcessList to emptty list");
				searchProcess.setProcessList(new ArrayList());
			}

			if (request.getSession().getAttribute("TOTALPAGES") != null) {
				log
						.debug("SearchAction.loadSectorList method :Getting TOTALPAGES form Session");
				searchProcess.setTotalPages( (Integer) request.getSession().getAttribute("TOTALPAGES"));
			} else {
				log
						.debug("SearchAction.loadSectorList method :setting TOTALPAGES to empty list");
				searchProcess.setTotalPages(Integer.valueOf(0));
			}
		} catch (Exception ex) {
			log.error(ex, ex);
		}
		model.addAttribute("searchProcess", searchProcess);
		log.info("SearchAction.loadSectorList method ends ");
		
		return "c3par.loadSearch.new";
	}
	
	@RequestMapping(value = "/searchResult.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String searchResult(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.searchResult method starts ");
		try {
			if (searchProcess.getPageNo() == null || searchProcess.getPageNo() == 0) {
				log.debug("Page size is null");
				searchProcess.setPageNo(1);
			}
			String requestType = request.getParameter("type");
			log.debug("req type" +requestType);
			if("P".equalsIgnoreCase(requestType)){
				searchProcess.setPageNo(searchProcess.getPageNo()-1);
			}else if ("N".equalsIgnoreCase(requestType)){
				searchProcess.setPageNo(searchProcess.getPageNo()+1);
			}
			searchProcess.setPageSize(10);
			int recCnt = searchProcess.getSearchRecordCount();
			Integer totalPages = recCnt;
			if (totalPages.intValue() == 0) {
				totalPages = 0;
			} else if (totalPages.intValue() / 10 == 0) {
				totalPages = 1;
			} else if (totalPages.intValue() % 10 > 0) {
				totalPages = totalPages.intValue() / 10 + 1;
			} else if (totalPages.intValue() % 10 == 0) {
				totalPages = totalPages.intValue() / 10;
			}
			log.debug("jfghjddd" +searchProcess.getPageNo() +searchProcess.getTotalPages() +searchProcess.getPageSize());
			log.debug("SearchAction.searchResult method:totalpages:"
					+ totalPages);
			searchProcess.setTotalPages(totalPages);
			if(totalPages.intValue() == 0){
				searchProcess.setNoResultsFound(true);
			}

			List lst = searchProcess.getProcessList(recCnt);
			searchProcess.setProcessList(lst);
			/*log.debug("SearchAction.searchResult method:processlist:" + lst);*/
			log.debug("jfghjgggg" +searchProcess.getPageNo() +searchProcess.getTotalPages() +searchProcess.getPageSize() +lst.size());
			request.getSession().setAttribute("PROCESSLIST", lst);
			request.getSession().setAttribute("TOTALPAGES", totalPages);

			if (searchProcess.getTotalPages() == null 
					|| (searchProcess.getTotalPages() != null  &&  searchProcess.getTotalPages().intValue()== 0)) {
				searchProcess.setPageNo(0);
			}
			log
					.debug("SearchAction.searchResult method :After getting processing List");
			log
					.debug("SearchAction.searchResult method :getSector Code is:'"
							+ searchProcess.getGeneralSearchAttributes()
									.getRegion() + "'");

			searchProcess.setProxyRegionList(new ArrayList());
			searchProcess.setProxyInstList(new ArrayList());
			searchProcess.setTaskActivityList(new ArrayList());
			request.getSession().setAttribute("SEARCHFORM", searchProcess);
			model.addAttribute("searchProcess", searchProcess);
			model.addAttribute("processList", lst);
		} catch (Exception ex) {
			//addActionError("Exception Occurred");
			log.error(ex, ex);
		}
		log.info("SearchAction.searchResult method ends ");
		
		return "c3par.loadSearch.new";
	}
	
	@RequestMapping(value = "/loadBuListForSearch.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadBuList(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.loadBuList method starts ");
		try {
			searchProcess.setBuList(searchProcess.getBuList());
			searchProcess.setPageSize(10);

			searchProcess.setProxyRegionList(new ArrayList());
			searchProcess.setProxyInstList(new ArrayList());

			if (request.getSession().getAttribute("PROCESSLIST")!= null) {
				log
						.debug("SearchAction.loadSectorList method :Getting ProcessList form Session");
				searchProcess.setProcessList((List) request.getSession().getAttribute("PROCESSLIST"));
			} else {
				log
						.debug("SearchAction.loadSectorList method :setting ProcessList to emptty list");
				searchProcess.setProcessList(new ArrayList());
			}

			if (request.getSession().getAttribute("TOTALPAGES") != null) {
				log
						.debug("SearchAction.loadSectorList method :Getting TOTALPAGES form Session");
				searchProcess.setTotalPages( (Integer) request.getSession().getAttribute("TOTALPAGES"));
			} else {
				log
						.debug("SearchAction.loadSectorList method :setting TOTALPAGES to empty list");
				searchProcess.setTotalPages(Integer.valueOf(0));
			}
		} catch (Exception ex) {
			//addActionError("Exception Occurred");
			log.error(ex, ex);
		}
		model.addAttribute("searchProcess", searchProcess);
		log.info("SearchAction.loadBuList method ends ");
		return "c3par.loadSearch.new";
	}
	
	@RequestMapping(value = "/loadTptListForSearch.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadTptList(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.loadTptList method starts ");
		try {
			searchProcess.setTptList(searchProcess.getTptList());
			searchProcess.setPageSize(10);

			searchProcess.setProxyRegionList(new ArrayList());
			searchProcess.setProxyInstList(new ArrayList());

			if (searchProcess.getTotalPages() == null 
					|| (searchProcess.getTotalPages() != null  &&  searchProcess.getTotalPages().intValue()== 0)) {
				searchProcess.setPageNo(0);
			}

			if (request.getSession().getAttribute("PROCESSLIST")!= null) {
				log
						.debug("SearchAction.loadSectorList method :Getting ProcessList form Session");
				searchProcess.setProcessList((List) request.getSession().getAttribute("PROCESSLIST"));
			} else {
				log
						.debug("SearchAction.loadSectorList method :setting ProcessList to emptty list");
				searchProcess.setProcessList(new ArrayList());
			}

			if (request.getSession().getAttribute("TOTALPAGES") != null) {
				log
						.debug("SearchAction.loadSectorList method :Getting TOTALPAGES form Session");
				searchProcess.setTotalPages( (Integer) request.getSession().getAttribute("TOTALPAGES"));
			} else {
				log
						.debug("SearchAction.loadSectorList method :setting TOTALPAGES to empty list");
				searchProcess.setTotalPages(Integer.valueOf(0));
			}
		} catch (Exception ex) {
			//addActionError("Exception Occurred");
			log.error(ex, ex);
		}
		model.addAttribute("searchProcess", searchProcess);
		log.info("SearchAction.loadTptList method ends ");
		return "c3par.loadSearch.new";
	}
	
	@RequestMapping(value = "/updateConnection.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String updateConnection(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.updateConnection method starts ");
		long tireqId = 0;
		TIProcessDTO tiProcessDTO = null;
		try {
			
			if (request.getParameter(TIREQID) != null) {

				searchProcess.setTiprocessDTO(null);
				searchProcess.setRequestID(Long.valueOf(request.getParameter(TIREQID).trim()));
				tiProcessDTO = searchProcess.getTiprocessDTO();
				if (request.getHeader("SM_USER") != null && ! request.getHeader("SM_USER").trim().equals(""))
				{
					String requesterSOEId =  request.getHeader("SM_USER").trim().toLowerCase();
					log.debug("Requester ID: " + requesterSOEId);
					tiProcessDTO.setRequestorSOEId(requesterSOEId);
				}
				log.debug("Before Update the connection");
				if (searchProcess.getManageTIProcess() != null) {
					tireqId = searchProcess.getManageTIProcess()
							.updateProcess(tiProcessDTO);
				}
				log
						.debug("SearchAction.updateConnection method tireqid after update conn:"
								+ tireqId);
			}
			if( tireqId != 0){
				log
				.info("SearchAction.updateConnection method before send to bpm:"
						+ tireqId);
				 //WsPapiFacade papiCall = new WsPapiFacade();
				papiFacade.callCreateProcess(tiProcessDTO.getRequestorSOEId(), tireqId, FlowType.MAINTENANCE);
				    String orderId = (String) request.getParameter("orderId");
				    if(orderId != null)  {  
				    	HttpSession session = request.getSession();
					    int count = searchProcess.updateCmpId(orderId, tireqId);
					    log.info("count:: " +count);
					    session.removeAttribute("orderId");
				    }
			}
			model.addAttribute("searchProcess", searchProcess);	
		} catch (Exception ex) {
			log.error(ex, ex);
			String errorMsg = ex.toString();
			errorMsg = (errorMsg.lastIndexOf(":") != -1)? errorMsg.substring(errorMsg.lastIndexOf(":")+1) : errorMsg;
			log.error("errorMsg.."+errorMsg);
		}
		
		log.info("SearchAction.updateConnection method ends ");
		//return "forward:/logon.act?forwardTo=bpm";
		return "forward:/defaultInboxView.act";
	}
	
	
	@RequestMapping(value = "/terminateConnection.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String terminateConnection(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.terminateConnection method starts ");
		TIProcessDTO tiProcessDTO = null;
		try {
			long tireqId = 0;
			if (request.getParameter(TIREQID) != null) {

				searchProcess.setTiprocessDTO(null);
				searchProcess.setRequestID(Long.valueOf(request.getParameter(TIREQID).trim()));
				tiProcessDTO = searchProcess.getTiprocessDTO();
				if (request.getHeader("SM_USER") != null && !request.getHeader("SM_USER").trim().equals(""))
				{
					String requesterSOEId = request.getHeader("SM_USER").trim().toLowerCase();
					log.debug("Requester ID: " + requesterSOEId);
					tiProcessDTO.setRequestorSOEId(requesterSOEId);
				}
				log.debug("Before Termination the connection");
				
				if (searchProcess.getManageTIProcess() != null) {
					tireqId = searchProcess.getManageTIProcess()
							.terminateProcess(tiProcessDTO);
				}
				log
						.debug("SearchAction.terminateConnection method tireqid after terminate conn:"
								+ tireqId);
			}
			if( tireqId != 0){
				log
				.debug("SearchAction.terminateConnection method before send to bpm:"
						+ tireqId);
				
				//WsPapiFacade papiCall = new WsPapiFacade();
			    //papiCall.callCreateProcess(tiProcessDTO.getRequestorSOEId(), tireqId, WsPapiFacade.CreateProcessActivity.FWRequest);
				papiFacade.callCreateProcess(tiProcessDTO.getRequestorSOEId(), tireqId, FlowType.TERMINATION);
				
				StringBuffer tireqIdJSONSB = new StringBuffer();
			    tireqIdJSONSB.append("[");
			    tireqIdJSONSB.append("{\"tireqid\":\""+tireqId+"\",\"userActionType\":\"Terminate\",\"error\":\"NOERROR\"}");
			    tireqIdJSONSB.append("]");
			    request.setAttribute("JSONRESULT", tireqIdJSONSB.toString());
			    String orderId = (String) request.getParameter("orderId");
			    if(orderId != null)  {  
			    	HttpSession session = request.getSession();
				    int count = searchProcess.updateCmpId(orderId, tireqId);
				    log.info("count:: " +count);
				    session.removeAttribute("orderId");
			    }
			}
			model.addAttribute("searchProcess", searchProcess);
				
		} catch (Exception ex) {
			//addActionError("Exception Occurred");
			log.error(ex, ex);
			String errorMsg = ex.toString();
			errorMsg = (errorMsg.lastIndexOf(":") != -1)? errorMsg.substring(errorMsg.lastIndexOf(":")+1) : errorMsg;
			StringBuffer tireqIdJSONSB = new StringBuffer();
		    tireqIdJSONSB.append("[");
		    tireqIdJSONSB.append("{\"tireqid\":\"ZERO\",\"userActionType\":\"Terminate\",\"error\":\""+errorMsg+"\"}");
		    tireqIdJSONSB.append("]");
		    request.setAttribute("JSONRESULT", tireqIdJSONSB.toString());
		}
		
		log.info("SearchAction.terminateConnection method ends ");
	//	return "forward:/logon.act?forwardTo=bpm";
		return "forward:/defaultInboxView.act";
	}
	
	@RequestMapping(value = "/manageUsrContactsConn.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String manageUsrContactsConn(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.manageContactConnection method starts ");
		TIProcessDTO tiProcessDTO = null;
		try {
			long tireqId = 0;
			if (request.getParameter(TIREQID) != null) {

				searchProcess.setTiprocessDTO(null);
				searchProcess.setRequestID(Long.valueOf(request.getParameter(TIREQID).trim()));
				tiProcessDTO = searchProcess.getTiprocessDTO();
				if(request.getSession().getAttribute("ssoId")!= null ){
					tiProcessDTO.setRequestorSOEId((String)request.getSession().getAttribute("ssoId"));
				}
				log.debug("SearchAction.manageContactConnection:Before manageContactConnection the connection");
				if (searchProcess.getManageTIProcess() != null) {
					tireqId = searchProcess.getManageTIProcess()
							.manageUserContactsProcess(tiProcessDTO);
				}
				log
						.debug("SearchAction.manageContactConnection method tireqid after update conn:"
								+ tireqId);
			}
			if( tireqId != 0){
				//WsPapiFacade papiCall = new WsPapiFacade();
			   // papiCall.callCreateProcess(tiProcessDTO.getRequestorSOEId(), tireqId,WsPapiFacade.CreateProcessActivity.FWManageUserContacts);
				log
				.debug("SearchAction.manageUsrContactsConn method before send to bpm:"
						+ tireqId);
				
				StringBuffer tireqIdJSONSB = new StringBuffer();
			    tireqIdJSONSB.append("[");
			    tireqIdJSONSB.append("{\"tireqid\":\""+tireqId+"\",\"userActionType\":\"ManageContacts\",\"error\":\"NOERROR\"}");
			    tireqIdJSONSB.append("]");
			    request.setAttribute("JSONRESULT", tireqIdJSONSB.toString());
			}
			model.addAttribute("searchProcess", searchProcess);	
		} catch (Exception ex) {
			//addActionError("Exception Occurred");
			log.error(ex, ex);
			String errorMsg = ex.toString();
			errorMsg = (errorMsg.lastIndexOf(":") != -1)? errorMsg.substring(errorMsg.lastIndexOf(":")+1) : errorMsg;
			StringBuffer tireqIdJSONSB = new StringBuffer();
		    tireqIdJSONSB.append("[");
		    tireqIdJSONSB.append("{\"tireqid\":\"ZERO\",\"userActionType\":\"ManageContacts\",\"error\":\""+errorMsg+"\"}");
		    tireqIdJSONSB.append("]");
		    request.setAttribute("JSONRESULT", tireqIdJSONSB.toString());
		}
		
		log.info("SearchAction.manageUsrContactsConn method ends ");
		return "forward:/logon.act?forwardTo=bpm";
	}
	
	@RequestMapping(value = "/showDetail.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String showDetail(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.showDetail method starts ");
		ActivityData activityData = null;
		TIRequest tiRequest = new TIRequest();
		String phase = null;
		String tireqid = null;
		String activityId = null;
		String instanceId = null;
		Util util = new Util();
		Long userId = null;
		String taskId = null;
		
		try {
			if(searchProcess == null){
				searchProcess = new SearchProcess();
			}
			String selTab = request.getParameter("sel_tab");
			if(selTab != null){
				request.getSession().setAttribute("selected_Tab", util.getSelectedTab(null, selTab, null));
			}
			searchProcess.setParticipate(false);
			log.debug("SearchAction.showDetail.ErrorMessage::"+request.getParameter("ErrorMessage"));
			if(request.getParameter("ErrorMessage") != null && !request.getParameter("ErrorMessage").trim().equals("")){
				String status = request.getParameter("Status");
				instanceId = request.getParameter("InstanceId");
				String errorMessage = request.getParameter("ErrorMessage");
				phase = request.getParameter("PHASE");
				tireqid = request.getParameter("tireqid");
				log.debug("SearchAction.showDetail.errorMessage::"+errorMessage+"::status::"+status+
						"InstanceId:"+instanceId+"phase:"+phase+"tireqid:"+tireqid);
				
				if("Failure".equalsIgnoreCase(status.trim()) && !"".equalsIgnoreCase(status.trim())){
					searchProcess.setUnlockErrorMsg(errorMessage);
				}
			}
			if (request.getParameter(TIREQID) != null || tireqid != null) {//tirequestid is needed
				String lcl_phase = request.getParameter("PHASE");
				if(lcl_phase == null ||(lcl_phase != null && lcl_phase.equals(""))){
					lcl_phase = phase ;
				}
				if(lcl_phase != null && "Maintain Contacts".equalsIgnoreCase(lcl_phase.trim())){
					request.getSession().setAttribute("bususr_mcontact", "YES");
				}else{
					request.getSession().removeAttribute("bususr_mcontact");
				}
				String lcl_activityId = request.getParameter("bpmActivityId");
				if(lcl_activityId == null ||(lcl_activityId != null && lcl_activityId.equals(""))){
					//lcl_activityId = activityId ;//Need get from bpm.
				}
				if( lcl_activityId != null){
					searchProcess.setBpmActivityId(lcl_activityId);
				}
				String lcl_taskCode = request.getParameter("taskCodeId");
				if(lcl_taskCode == null ||(lcl_taskCode != null && lcl_taskCode.equals(""))){
					lcl_taskCode = activityId ;
				}
				if( lcl_taskCode != null){
					searchProcess.setTaskCode(lcl_taskCode);
				}
				log.debug("lcl_taskName:"+request.getParameter("taskCodeId"));
				log.debug("bpmActivityId:"+request.getParameter("bpmActivityId"));
				String lcl_instanceId = request.getParameter("bmpInstanceId");
				if(lcl_instanceId == null ||(lcl_instanceId != null && lcl_instanceId.equals(""))){
					lcl_instanceId = instanceId ;
				}
				if( lcl_instanceId != null ){
					searchProcess.setBmpInstanceId(lcl_instanceId);
				}
				log.debug("bmpInstanceId:"+request.getParameter("bmpInstanceId")+"::"+lcl_instanceId);
				String lcl_tireqid = request.getParameter(TIREQID);
				if(lcl_tireqid == null ||(lcl_tireqid != null && lcl_tireqid.equals(""))){
					lcl_tireqid = tireqid;
				}
				Map<String,String> activityDtls = null;
				activityDtls = util.getAcivityDetails(Long.valueOf(lcl_tireqid.trim()));
				if(activityDtls!=null && activityDtls.get("ACTIVITY_ID")!=null){
					searchProcess.setActivityId(activityDtls.get("ACTIVITY_ID"));
				}
				log.debug("lcl_instanceId:"+lcl_instanceId);
				log.debug("lcl_activityId:"+lcl_activityId);
				if(lcl_instanceId == null || lcl_activityId == null){
					//activityDtls = util.getAcivityDetails(Long.valueOf(lcl_tireqid.trim()));
					if(activityDtls != null){
						if(activityDtls.containsKey("BPM_INSTANCE_ID")){
							searchProcess.setBmpInstanceId(activityDtls.get("BPM_INSTANCE_ID"));
						}
						if(activityDtls.containsKey("ALBPM_ACTIVITY_ID")){
							searchProcess.setBpmActivityId(activityDtls.get("ALBPM_ACTIVITY_ID"));
						}
					}
				}
				lcl_tireqid = lcl_tireqid.trim();
				//tiRequest = searchProcess.getTIRequestDetails(lcl_tireqid);
				tiRequest.setId(Long.valueOf(lcl_tireqid.trim()));
				/*request.getSession().removeAttribute("TI_REQUEST_ENTITY");
				request.getSession().setAttribute("TI_REQUEST_ENTITY",
						tiRequestEntity);
				*/
				activityData = util.getCurrentActivitybyTiRequestId(lcl_tireqid,
						lcl_taskCode,null);
				
							
				log.debug("SearchAction:showDetail:status:"+activityData.getActivityName()+"role:"+activityData.getDisplayRole()+"role:"+activityData.getActivityStage());
				
				request.getSession().setAttribute("workflowActivityData", activityData);
				request.getSession().setAttribute("currentActivityData", activityData);
				request.getSession().setAttribute("forward", activityData.getEncodedAlbpmActivity());
				request.getSession().setAttribute("activityName", activityData.getActivityName());
				request.getSession().setAttribute("activityStage", activityData.getActivityStage());
				request.getSession().setAttribute("tireqid",lcl_tireqid);
				

				searchProcess.setTiprocessDTO(null);
				searchProcess.setRequestID(Long.valueOf(lcl_tireqid));
				TIProcessDTO tiProcessDTO = searchProcess.getTiprocessDTO();
				searchProcess.setActivityStage(activityData.getActivityStage());
				
				
				String SSOID = (String)request.getSession().getAttribute("ssoId");
				log.debug("SSOID:"+SSOID);
				if (!StringUtil.isNullorEmpty(SSOID)){
					userId = adminServicePersistable.getUserId(SSOID);
					log.debug("userId:"+userId);
				}
				request.getSession().setAttribute("userId", userId);
				
				log.debug("userId:"+userId);
				log.debug("searchProcess.getBpmActivityId():"+searchProcess.getBpmActivityId());
				log.debug("searchProcess.getBmpInstanceId():"+searchProcess.getBmpInstanceId());
				log.debug("activityData.getEncodedAlbpmActivity():"+activityData.getEncodedAlbpmActivity());
				log.debug("activityData.getBpmInstanceId():"+activityData.getBpmInstanceId());
				if((searchProcess.getBpmActivityId()!=null && (((ActivityDataDTO.Activity_PC_INT_ACV).equalsIgnoreCase(searchProcess.getBpmActivityId())) || 
						((ActivityDataDTO.Activity_ISO_INT_ACV).equalsIgnoreCase(searchProcess.getBpmActivityId())) ||
						((ActivityDataDTO.Activity_TC_INT_ACV).equalsIgnoreCase(searchProcess.getBpmActivityId())) ||
						((ActivityDataDTO.Activity_ADMIN_INT_ACV).equalsIgnoreCase(searchProcess.getBpmActivityId())) ||
						((ActivityDataDTO.Activity_BU_INT_ACV).equalsIgnoreCase(searchProcess.getBpmActivityId())) ||
						((ActivityDataDTO.Activity_VER_SOW).equalsIgnoreCase(searchProcess.getBpmActivityId())) ||
						((ActivityDataDTO.Activity_TC_EXT_ACV).equalsIgnoreCase(searchProcess.getBpmActivityId())) || 
						((ActivityDataDTO.Activity_PC_EXT_ACV).equalsIgnoreCase(searchProcess.getBpmActivityId())) ||
						((ActivityDataDTO.Activity_ISO_EXT_ACV).equalsIgnoreCase(searchProcess.getBpmActivityId())) ||
						((ActivityDataDTO.Activity_BU_EXT_ACV).equalsIgnoreCase(searchProcess.getBpmActivityId())) ||
						((ActivityDataDTO.Activity_ADMIN_EXT_ACV).equalsIgnoreCase(searchProcess.getBpmActivityId()))) && searchProcess.getBmpInstanceId()==null) || 
						(activityData.getEncodedAlbpmActivity()!=null && (ActivityDataDTO.Activity_VER_SOW).equalsIgnoreCase(activityData.getEncodedAlbpmActivity()) 
						&& activityData.getBpmInstanceId()==null))	{						
					Map<String,String> taskIdDetails = manageTIProcessImpl.getTaskIdDetailsForACVInGlblSrch(Long.valueOf(lcl_tireqid),SSOID);
					if(taskIdDetails!=null)	{
						taskId = (String)taskIdDetails.get("taskId");
						log.debug("SearchAction:showDetail:taskId:"+taskId);
						activityData.setBpmInstanceId(taskId);
						searchProcess.setBmpInstanceId(taskId);
					}
				}
								
				List<String> userRoles = util.getUserRoles(SSOID);
				log.debug("SearchAction:showDetail:userRoles:"+userRoles);
				if(userRoles.indexOf("ECM") != -1){
					searchProcess.setECM(true);
				}
				log.debug("SearchAction:showDetail:ECM:"+searchProcess.isECM());
				
				log.debug("participantId:"+request.getParameter("participantId"));
				String lcl_participantId = request.getParameter("participantId");
				if(lcl_participantId != null && !lcl_participantId.isEmpty() && SSOID.equals(lcl_participantId)){
					request.getSession().setAttribute("displayMode","Edit");
					log.debug("Display Mode set to edit");
				}
				log.debug("tiProcessDTO.getBusJusParticipants:"+tiProcessDTO.getBusJusParticipants());
				log.debug("tiProcessDTO.getTecArcParticipants:"+tiProcessDTO.getTecArcParticipants());
				request.setAttribute("SUPPREVIEWROLES", tiProcessDTO
						.getSuppReviewRoles());
				if(request.getParameter("PREVIOUS") != null && "TRUE".equalsIgnoreCase(request.getParameter("PREVIOUS").trim())){
					request.getSession().setAttribute(SEARCHFORM, searchProcess);
				}
				log.debug("ti pro val" +searchProcess.getTiprocessDTO().getVendorAggregate());
			}
			model.addAttribute("searchProcess", searchProcess);
			log.info("SearchAction.showDetail method ends ");
		} catch (Exception ex) {
			log.error(ex, ex);
		}
		return "c3par.search.on.main.menu.showdetails.new";
	}
	
	@RequestMapping(value = "/exportSearchResult.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String exportSearchResult(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.exportSearchResult method starts ");
		try {
			if (searchProcess.getPageNo() == null || searchProcess.getPageNo() == 0) {
				log.debug("Page size is null");
				searchProcess.setPageNo(1);
			}
			//searchForm.setPageSize(10);

			Integer totalPages = searchProcess.getSearchRecordCount();
			searchProcess.setPageSize(totalPages);
			log.debug("SearchAction.exportSearchResult method:totalpages:"
					+ totalPages);
			searchProcess.setTotalPages(totalPages);
			if(totalPages.intValue() == 0){
				searchProcess.setNoResultsFound(true);
			}

			List lst = searchProcess.getProcessList();
			searchProcess.setProcessList(lst);
			
			request.getSession().setAttribute("PROCESSLIST", lst);
			request.getSession().setAttribute("TOTALPAGES", totalPages);

			if (searchProcess.getTotalPages() == null 
					|| (searchProcess.getTotalPages() != null  &&  searchProcess.getTotalPages().intValue()== 0)) {
				searchProcess.setPageNo(0);
			}
			log
					.debug("SearchAction.exportSearchResult method :After getting processing List");
			log
					.debug("SearchAction.exportSearchResult method :getSector Code is:'"
							+ searchProcess.getGeneralSearchAttributes()
									.getRegion() + "'");

			searchProcess.setProxyRegionList(new ArrayList());
			searchProcess.setProxyInstList(new ArrayList());
			searchProcess.setTaskActivityList(new ArrayList());
			model.addAttribute("searchProcess", searchProcess);
			
		} catch (Exception ex) {
			//addActionError("Exception Occurred");
			log.error(ex, ex);
		}
		log.info("SearchAction.exportSearchResult method ends ");
		
		return "pages/jsp/search/exportSearchResults";
	}
	
	@RequestMapping(value = "/loadProxyRegionForSearch.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadProxyRegion(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.loadProxyRegion method starts ");
		try {

			log
					.debug("SearchAction.loadProxyRegion method searchForm.getSearchType():"
							+ searchProcess.getSearchType());
			searchProcess.setProxyRegionList(searchProcess.getProxyRegionList());
			searchProcess.setPageSize(10);

			searchProcess.setProxyRegionList(new ArrayList());
			searchProcess.setProxyInstList(new ArrayList());
			
			if (request.getSession().getAttribute("PROCESSLIST")!= null) {
				log
						.debug("SearchAction.loadSectorList method :Getting ProcessList form Session");
				searchProcess.setProcessList((List) request.getSession().getAttribute("PROCESSLIST"));
			} else {
				log
						.debug("SearchAction.loadSectorList method :setting ProcessList to emptty list");
				searchProcess.setProcessList(new ArrayList());
			}

			if (request.getSession().getAttribute("TOTALPAGES") != null) {
				log
						.debug("SearchAction.loadSectorList method :Getting TOTALPAGES form Session");
				searchProcess.setTotalPages( (Integer) request.getSession().getAttribute("TOTALPAGES"));
			} else {
				log
						.debug("SearchAction.loadSectorList method :setting TOTALPAGES to empty list");
				searchProcess.setTotalPages(Integer.valueOf(0));
			}
			
		} catch (Exception ex) {
			//addActionError("Exception Occurred");
			log.error(ex, ex);
		}
		log.info("SearchAction.loadProxyRegion method ends ");
		return "c3par.loadSearch.new";
	}
	
	@RequestMapping(value = "/loadProxyInstanceNameForSearch.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadProxyInstanceName(ModelMap model,HttpServletRequest request, @ModelAttribute("searchProcess") SearchProcess searchProcess) {
		log.info("SearchAction.loadProxyInstanceName method starts ");
		try {
			searchProcess.setProxyInstList(searchProcess.getProxyInstList());
			searchProcess.setPageSize(10);

			searchProcess.setProxyRegionList(new ArrayList());
			searchProcess.setProxyInstList(new ArrayList());

			if (request.getSession().getAttribute("PROCESSLIST")!= null) {
				log
						.debug("SearchAction.loadSectorList method :Getting ProcessList form Session");
				searchProcess.setProcessList((List) request.getSession().getAttribute("PROCESSLIST"));
			} else {
				log
						.debug("SearchAction.loadSectorList method :setting ProcessList to emptty list");
				searchProcess.setProcessList(new ArrayList());
			}

			if (request.getSession().getAttribute("TOTALPAGES") != null) {
				log
						.debug("SearchAction.loadSectorList method :Getting TOTALPAGES form Session");
				searchProcess.setTotalPages( (Integer) request.getSession().getAttribute("TOTALPAGES"));
			} else {
				log
						.debug("SearchAction.loadSectorList method :setting TOTALPAGES to empty list");
				searchProcess.setTotalPages(Integer.valueOf(0));
			}
		} catch (Exception ex) {
			//addActionError("Exception Occurred");
			log.error(ex, ex);
		}
		log.info("SearchAction.loadProxyInstanceName method ends ");
		return "c3par.loadSearch.new";
	}	
	

}
