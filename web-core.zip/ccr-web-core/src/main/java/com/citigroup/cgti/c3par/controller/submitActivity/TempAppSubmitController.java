package com.citigroup.cgti.c3par.controller.submitActivity;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.ManageActivityImpl;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

/*
 * @nc43495
 */
@Controller
public class TempAppSubmitController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(TempAppSubmitController.class);
	Util util=new Util();
	
	@Autowired
	WsPapiFacade papiFacade;
	
	@Autowired
	ManageTIProcessImpl manageTIProcessImpl;

	@Autowired
	ManageActivityImpl manageActivityImpl;
	
	@Autowired
	WorkflowUtil workflowUtil;

	@RequestMapping(value = "/loadTempAppSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(ModelMap model,@ModelAttribute("tempAppProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session){
		log.info("TempApproval Expiration Submit Controller load method starts here...");
		
		String tiReq = (String)session.getAttribute("tireqid");
		String actId = (String)session.getAttribute("activityid");
		
		Long tiReqId = Long.valueOf(0);
		Long activityId = Long.valueOf(0);
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		if(actId!=null){
		    try{activityId=Long.valueOf(actId);}catch(Exception e){activityId = Long.valueOf(0);}
		}
		log.info("tiReq:"+tiReq+"ActivityId"+activityId);
		String taskId = (String) session.getAttribute("taskId");
		if(StringUtil.isNullorEmpty(actId)){
			activityId = workflowUtil.getAuditTrailId(activityId, taskId);
		}
		submitActivityProcess = new SubmitActivityProcess();
		
		//supplementary review roles display
		HashMap<String,String> roles = submitActivityProcess.findInstanceId(tiReqId, activityId);
		submitActivityProcess.setRoles(roles);
		List<LookUpVO> supReviewRole = submitActivityProcess.getSupReviewRoles((String)roles.get("ROLE"));
		log.info("TempApproval Expiration Submit Controller:"+supReviewRole.size());
		submitActivityProcess.setSupReviewRoles(supReviewRole);
		
		//set activity role
		submitActivityProcess.setActivityRole((String)roles.get("ROLE"));
		session.setAttribute("activityRole",submitActivityProcess.getActivityRole());
		log.info("activity role:"+submitActivityProcess.getActivityRole());
		
		/*//setInstanceID
		String instanceId = (String)roles.get("INST_ID");
		session.setAttribute("instanceID", instanceId);
		log.info("instanceId"+instanceId);*/
		
		// setTaskID
		log.info("*********taskId************" + taskId);
		
		//Approval comments display
		String role = (String)roles.get("ROLE");
		submitActivityProcess.setTiReqCmtsList(submitActivityProcess.getComments(tiReqId, role, "A"));
		
		//Discussion comments display
		submitActivityProcess.setDiscussCmtsList(submitActivityProcess.getComments(tiReqId, role, "D"));
		
		model.addAttribute("tempAppProcess", submitActivityProcess);
		
		return "c3par.tempAppExp";
	}
	
	@RequestMapping(value = "/saveTempAppSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String save(ModelMap model,@ModelAttribute("tempAppProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request) throws Exception{
	log.info("TempApproval Expiration Submit Controller:Save method starts here...");
	formSubmit(submitActivityProcess,result,session,request);
	return "forward:/logon.act?forwardTo=bpm";
		
	}
	
	@RequestMapping(value = "/sendEmailTempApp.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String sendEmail(ModelMap model,@ModelAttribute("tempAppProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request){
		log.info("TempApproval Expiration Submit Controller:Send mail method starts here...");
		
		String tiReq = (String)session.getAttribute("tireqid");
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );
		
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		
		//Send email
		submitActivityProcess.sendCommentsEmail(tiReqId, "tmp_exp", submitActivityProcess.getComments(), submitActivityProcess.getExtendedDate());
		
		//Update date
		submitActivityProcess.tpwgtempAppDateUpdate(tiReqId);
		
		return "forward:/logon.act?forwardTo=bpm";
	}
	
	@RequestMapping(value = "/submitTempApp.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String submit(ModelMap model,@ModelAttribute("tempAppProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request){
	log.info("TempApproval Expiration Submit Controller:Save method starts here...");
	
	try {
		formSubmit(submitActivityProcess,result,session,request);
		log.info("TempApproval Expiration Submit PAPI Enter ");
		
		//WsPapiFacade papiFacade = new WsPapiFacade ();
		
		String taskId = (String)session.getAttribute("taskId");
		String userId  = request.getHeader("SM_USER");
		String nextSelectedAction = submitActivityProcess.getCurrentAction();
		String nextRole = null;
		log.info("taskId: " + taskId +"action"+nextSelectedAction);
		log.info("userId: " + userId);
		
		String tiReq = (String)session.getAttribute("tireqid");		
		Long tiReqId = Long.valueOf(0);
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		log.info("tiReqId: " + tiReqId);
		
		String actId = (String)session.getAttribute("activityid");	
		Long activityId = Long.valueOf(0);	
		if(actId!=null){
		    try{activityId=Long.valueOf(actId);}catch(Exception e){activityId = Long.valueOf(0);}
		}	
		log.info("activityId: " + activityId);
		
		log.info("Before calling PAPI For BJ Submit");
		
		if("REJECTED".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getRejectRole());
		}else if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getProvideInfoRole());
		}else {
			nextRole = util.moveToActivity(submitActivityProcess.getCurrentRole());
		}
		
		log.info("Selected role:"+nextRole);
		
		ActivityDataDTO activityDataDTO = new ActivityDataDTO();
		
		if ("UNLOCKED".equals( nextSelectedAction )) {
			log.info("inside UNLOCKED scenario..."+nextSelectedAction);
			papiFacade.completeActivity(userId, taskId, nextSelectedAction);
			return "forward:/defaultInboxView.act";
		}
		
		if("Extend".equalsIgnoreCase(nextSelectedAction)){
			log.info("inside Extend scenario..."+nextSelectedAction);
			papiFacade.tempApprovalActivity(userId, taskId,ActivityDataDTO.STATUS_EXTENDED,submitActivityProcess.getExtendedDate());
			//Updating End Status
			log.info("inside Extend scenario : Updating End Status");
			activityDataDTO.setActivityCode("Active");
			activityDataDTO.setActivityStage(ActivityDataDTO.STAGE_APPROVAL);
			activityDataDTO.setActivityType(ActivityDataDTO.TYPE_APPROVAL);
			activityDataDTO.setActivityStatus(ActivityDataDTO.STATUS_COMPLETED);
			manageActivityImpl.logActivity(activityDataDTO, tiReqId, null);
			log.info("inside Extend scenario : Updating End Status Completed!");
			return "forward:/defaultInboxView.act";
		}
		
		if("Approve".equalsIgnoreCase(nextSelectedAction)){
			log.info("inside Approve scenario..."+nextSelectedAction);
			papiFacade.completeActivity(userId, taskId,ActivityDataDTO.STATUS_COMPLETED);
			log.info("inside Approve scenario : Updating End Status");			
			activityDataDTO.setActivityCode("Active");
			activityDataDTO.setActivityStage(ActivityDataDTO.STAGE_APPROVAL);
			activityDataDTO.setActivityType(ActivityDataDTO.TYPE_APPROVAL);
			activityDataDTO.setActivityStatus(ActivityDataDTO.STATUS_COMPLETED);
			manageActivityImpl.logActivity(activityDataDTO, tiReqId, null);
			log.info("inside Approve scenario : Updating End Status Completed!");
			return "forward:/defaultInboxView.act";
		}
		
		if("Terminate".equalsIgnoreCase(nextSelectedAction)){
			log.info("inside Terminate scenario..."+nextSelectedAction);
			papiFacade.completeActivity(userId, taskId,ActivityDataDTO.ACTIVITY_TERMINATED);
			log.info("inside Terminate scenario : Updating End Status");
			activityDataDTO.setActivityCode("Active");
			activityDataDTO.setActivityStage(ActivityDataDTO.STAGE_APPROVAL);
			activityDataDTO.setActivityType(ActivityDataDTO.TYPE_APPROVAL);
			activityDataDTO.setActivityStatus(ActivityDataDTO.STATUS_COMPLETED);
			manageActivityImpl.logActivity(activityDataDTO, tiReqId, null);
			log.info("inside Terminate scenario : Terminating Process");
			TIProcessDTO processDTO=manageTIProcessImpl.getProcessDTO(tiReqId);
			tiReqId = manageTIProcessImpl.terminateProcess(processDTO);
			log.info("inside Terminate scenario : Terminating Process Completed");
			papiFacade.callCreateProcess(userId, tiReqId, FlowType.TERMINATION);//Process
			log.info("inside Terminate scenario : Terminating Flow created!");
			return "forward:/defaultInboxView.act";
		}
	} catch (OperationException_Exception e) {
		log.debug("Operation Exception Occured in submit in TempApproval Expiration Submit Controller"+e.getMessage());
	} catch (Exception e) {
		log.debug("Exception Occured in submit in TempApproval Expiration Submit Controller"+e.getMessage());
	}
	
	return "forward:/defaultInboxView.act";
		
	}
	
	
	//data collection
    private void formSubmit(SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session,
			HttpServletRequest request)throws Exception{
    	log.info("TempApproval Expiration Submit Controller form Submit begins...");
    	String messgXML = (String)request.getSession().getAttribute("MESSAGEXML");
		log.info("messgXML::"+messgXML);
		
		String tiReq = (String)session.getAttribute("tireqid");
		
		submitActivityProcess.setActivityRole((String)session.getAttribute("activityRole"));
		log.info("activity role inside form submit:"+submitActivityProcess.getActivityRole());
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );
		
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		
		//Getting request type
		TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
		
		if(submitActivityProcess.getCurrentAction()==null){
			submitActivityProcess.setCurrentAction(ActivityData.STATUS_COMPLETED);
		}
		
		if(submitActivityProcess.getCurrentRole()==null){
			submitActivityProcess.setCurrentRole(submitActivityProcess.getActivityRole());
		}

		log.info("Request Parameters::"+request.getParameterNames());
		log.info("Request current role="+request.getParameter("currentRole"));
		log.info("current action =" + submitActivityProcess.getCurrentAction());
		log.info("current role=" + submitActivityProcess.getCurrentRole());
		log.info("comments = " + submitActivityProcess.getComments());
		

		String ssoID = request.getHeader("SM_USER");
		
		TiRequestComments tiReqComments = new TiRequestComments();
		tiReqComments.setTiRequest(tiRequest);
		tiReqComments.setComments(submitActivityProcess.getComments());
		tiReqComments.setRoleName(submitActivityProcess.getActivityRole());
		tiReqComments.setApproverSoeID(ssoID);
		
		//Update date
		if("Approve".equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
			submitActivityProcess.tpwgtempAppDateUpdate(tiReqId);
		}
		
		//updating tiRequest comments
		if(!"PROVIDEINFO".equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
			submitActivityProcess.addComments(tiReqComments, "A", "save");
		}else {
			submitActivityProcess.addComments(tiReqComments, "D", "save");
		}
			
    }
}
