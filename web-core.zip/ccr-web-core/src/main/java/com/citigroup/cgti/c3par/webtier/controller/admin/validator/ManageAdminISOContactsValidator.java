package com.citigroup.cgti.c3par.webtier.controller.admin.validator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.c3par.webtier.controller.admin.ManageAdminControllerProcess;

public class ManageAdminISOContactsValidator implements Validator {

    private static Logger log = Logger.getLogger(ManageAdminISOContactsValidator.class);

    public boolean supports(Class<?> paramClass) {
        return ManageAdminControllerProcess.class.equals(paramClass);
    }

    @Autowired
    private AdminServicePersistable adminServicePersistable;

    public AdminServicePersistable getAdminServicePersistable() {
        return adminServicePersistable;
    }

    public void setAdminServicePersistable(AdminServicePersistable adminServicePersistable) {
        this.adminServicePersistable = adminServicePersistable;
    }

    @Override
    public void validate(Object obj, Errors errors) {
        log.debug("Validate ISO Enter::loadISOContactsList methods starts...");
        ManageAdminControllerProcess isoProcessObj = (ManageAdminControllerProcess) obj;
        if (isoProcessObj.getIsoContacts().getSoeID().isEmpty()) {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "isoContacts.soeID", "valid");
        }
        log.debug("Validate ISO Ends::loadISOContactsList methods Ends...");
    }

}
