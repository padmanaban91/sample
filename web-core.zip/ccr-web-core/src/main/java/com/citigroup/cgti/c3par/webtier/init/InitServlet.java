/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright © 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.webtier.init;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Set;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;
import org.jgroups.ChannelException;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.ContextLoader;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.gdw.EncryptDBPassword;
import com.citigroup.cgti.c3par.util.PasswordEncryptDecrypt;
import com.citigroup.cgti.c3par.util.SynchronizeGenericLookup;
import com.citigroup.cgti.c3par.webtier.helper.LookupsManager;
import com.ibm.websphere.management.AdminService;
import com.ibm.websphere.management.AdminServiceFactory;
import com.mentisys.dao.KeyGenerator;
import com.mentisys.util.databaserealm.RealmProperties;

/**
 * The Class InitServlet.
 *
 * @author pkadam
 * 
 *         This servlet initializes the LockManagement component. It specifies a
 *         custom unlocking policy and uses the database persistence handling
 *         component.
 * 
 *         This also set the KeyGenerator cache size to 1.
 */
public class InitServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final String ENV_DEV="DEV";
    private static final String ENV_PAT="PAT";
    private static final String ENV_UAT="UAT";
    private static final String ENV_PRD="PRD";
    private static final String ENV_COB="COB";
    
    private static final String APP_DEV="application-dev";
    private static final String APP_PAT="application-pat";
    private static final String APP_UAT="application-uat";
    private static final String APP_PRD="application-prd";
    private static final String APP_COB="application-cob";
    
    private static final String LOG4J_DEV_PROPERTIES="/WEB-INF/classes/log4j-dev.properties";
    private static final String LOG4J_PAT_PROPERTIES="/WEB-INF/classes/log4j-pat.properties";
    private static final String LOG4J_UAT_PROPERTIES="/WEB-INF/classes/log4j-uat.properties";
    private static final String LOG4J_PRD_PROPERTIES="/WEB-INF/classes/log4j-prd.properties";
    private static final String LOG4J_COB_PROPERTIES="/WEB-INF/classes/log4j-cob.properties";
    private static final String SOA_KEYSTORE_UAT="/WEB-INF/certs/uat/ccr_147460.jks";
    private static final String SOA_KEYSTORE_PRD="/WEB-INF/certs/prd/ccr_147460.jks";
    
    public static final String CCR_APPLICATION="ccr-application";
    public static final String ENVIRONMENT_BEAN = "environment";
    public static final String SOA_KEYSTORE_PATH="soa-keystore_path";
    
    public Environment environment=null;
    public ServletContext sc=null;
    
    public void log(String logMessage){
      System.out.println("InitServlet : "+logMessage);  
    }
    
    public void init(ServletConfig config) throws ServletException {
        try {
            log("Set Key Generator cache size to 1");
            KeyGenerator.getInstance().setCacheSize(1);
            String roleName = config.getInitParameter("LockManagerAdminRoleName");
            log("roleName from init parameter : " + roleName);
            roleName = (roleName == null || roleName.trim().length() == 0 ? "C3PARSYSTEMADMIN" : roleName.trim());
            log("Instantiating unlocking policy. Using Role : " + roleName);

            ApplicationContext context = ContextLoader.getCurrentWebApplicationContext();
            environment= (Environment) context.getBean(ENVIRONMENT_BEAN);
            String environmentValue = environment.getValue();
            log("The envirnment variable value is " + environmentValue);
            sc = config.getServletContext();
            String log4jProperties = null;
            String applicationProperties = null;
            String soaKeystorePath=null;
            readWebsphereEnvVariable();
            System.setProperty("org.quartz.properties", "/WEB-INF/quartz-db.properties");
            if (ENV_DEV.equals(environmentValue)) {
                log4jProperties = LOG4J_DEV_PROPERTIES;
                applicationProperties = APP_DEV;
                soaKeystorePath=SOA_KEYSTORE_UAT;
            } else if (ENV_PAT.equals(environmentValue)) {
                log4jProperties = LOG4J_PAT_PROPERTIES;
                applicationProperties = APP_PAT;
                soaKeystorePath=SOA_KEYSTORE_UAT;
            } else if (ENV_UAT.equals(environmentValue)) {
                log4jProperties = LOG4J_UAT_PROPERTIES;
                applicationProperties = APP_UAT;
                soaKeystorePath=SOA_KEYSTORE_UAT;
            } else if (ENV_COB.equals(environmentValue)) {
                log4jProperties = LOG4J_COB_PROPERTIES;
                applicationProperties = APP_COB;
                soaKeystorePath=SOA_KEYSTORE_UAT;
            } else if (ENV_PRD.equals(environmentValue)) {
                log4jProperties = LOG4J_PRD_PROPERTIES;
                applicationProperties = APP_PRD;
                soaKeystorePath=SOA_KEYSTORE_PRD;
            }
            log("log4jProperties value : "+log4jProperties + " and applicationProperties value : "+applicationProperties);

            System.setProperty(CCR_APPLICATION, applicationProperties);
            
            log("System property has been set as : " + System.getProperty(CCR_APPLICATION));
            
            System.setProperty(SOA_KEYSTORE_PATH, new StringBuilder(sc.getRealPath("/")).append(soaKeystorePath).toString());

            if (log4jProperties == null) {
                log("*** No log4j-properties-location init param, so initializing log4j with BasicConfigurator");
                BasicConfigurator.configure();
            } else {
            	 String webAppPath = sc.getRealPath("/");
            	 String log4jProp = new StringBuilder(webAppPath).append(log4jProperties).toString();
                 File file = new File(log4jProp);
                 if (file.exists()) {
                     log("Initializing log4j with: " + log4jProp);
                     PropertyConfigurator.configure(log4jProp);
                 } else {
                     log("*** " + log4jProp + " file not found, so initializing log4j with BasicConfigurator");
                     BasicConfigurator.configure();
                 }
                log("Log4j properties successfully configured..!!!");
            }
            
            LookupsManager.resetRoleLookup(new C3parSession());
            log("Going to encrypt the database password");
            RealmProperties.encryptDatabasePassword();
            EncryptDBPassword.encryptDatabasePassword();
            PasswordEncryptDecrypt passwordEncryptDecrypt = new PasswordEncryptDecrypt();
            passwordEncryptDecrypt.encryptPropertyValue("SSL_PWD");
            passwordEncryptDecrypt.encryptPropertyValue("ALGOSEC_PWD");
            
            writeCmpXslFile();
            log("Going to initialize multicast");
            try {
                SynchronizeGenericLookup lookup = new SynchronizeGenericLookup();
                lookup.initialize();
            } catch (ChannelException ex) {
                log("Exception when trying to init() :- " + ex);
                //throw ex;
            }

        } catch (Exception e) {
            log("Lock Management Persistence Handler could not be set. An exception occured." + e);
            e.printStackTrace();
            throw new ServletException(e);
        }
    }


    /**
     * Invoke batch process.
     *//*
    private void invokeBatchProcess(){
	if(C3parProperties.BATCH_PROCESS_INVOKED.equals("FALSE")){
	    try{
		//PortAppJustification portAppJustification = new PortAppJustification();
		//portAppJustification.invokeTheBatchProcess();

		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		new ObjectOutputStream(outStream).writeObject(C3parProperties.BATCH_PROCESS_INVOKED);
		String status = "TRUE";
		InputStream stream = new FileInputStream(C3parProperties.CONFIG_DIRECTORY + "/" + System.getProperty("weblogic.Name") + "-c3par.properties");

		Properties configProp = new Properties();
		configProp.load(stream);
		configProp.put("BATCH_PROCESS_INVOKED", status);
		OutputStream outFileStream = new FileOutputStream(C3parProperties.CONFIG_DIRECTORY + "/" + System.getProperty("weblogic.Name") + "-c3par.properties");
		configProp.save(outFileStream, "This has been generated by c3par application, please don't modify");
	    }catch(Exception e){
		log("Exception when trying to invoke invokeBatchProcess :- " + e);
	    }
	}
    }*/
    
    private void writeCmpXslFile() throws IOException{
        FileOutputStream fileOuputStream=null;
        try{
          String webAppPath = sc.getRealPath("/");
          String cmpXslPath = new StringBuilder(webAppPath).append("/WEB-INF/xsl/CmpDetails.xsl").toString();
          log("cmpXslPath ::"+cmpXslPath);
          fileOuputStream = new FileOutputStream(cmpXslPath,false); 
          fileOuputStream.write(environment.getCmpXsl());
          log("File creation completed.");
        }catch(Exception ex){
            log("Exception when trying to write Cmp Xsl file :- " + ex.toString());
            ex.printStackTrace();
        }
        finally{
            fileOuputStream.close();  
        }
        
    }
    private void readWebsphereEnvVariable(){
        log(" Inside  readWebsphereEnvVariable");
           AdminService as = AdminServiceFactory.getAdminService(); 
           try {
               String server = as.getProcessName();
               log(" Server name value is :: "+server);
               String mBeanName = "*:*,type=AdminOperations,process=" + server;
               Set result = as.queryNames(new javax.management.ObjectName(mBeanName) , null);  
               String server_root_Path =  (String) as.invoke((javax.management.ObjectName)result.iterator().next(),"expandVariable",
                                          new Object[]{"${SERVER_LOG_ROOT}"},
                                          new String[]{"java.lang.String"})+"/";
               log("*********************SERVER_LOG_ROOT*************************** : "+server_root_Path);
               System.setProperty("application-log-path", server_root_Path);
           } catch (Exception e) {
            log("Exception occured while reading SERVER_LOG_ROOT : "+e.toString());
            e.printStackTrace();
           }

    }
}
