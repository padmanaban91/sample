package com.citigroup.cgti.c3par.controller.relationship;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.citigroup.cgti.c3par.bpm.ejb.domain.LookupDTO;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.SearchRelationshipProcess;

@Controller
public class SearchRelationshipController {

	/** The log. */
	private static Logger log = Logger.getLogger(SearchRelationshipController.class);

	public static String PORT_RES_TYPE = "Port Template";
	public static String IP_RES_TYPE = "IP Template";
	public static String THIRD_RES_TYPE = "3rd Party/CEP";

	/**
	 * To Load the List Relation ship
	 */
	@RequestMapping(value = "/loadRelationshipListController.act", method =  { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView listRelationship(ModelMap model,@ModelAttribute("searchRelationshipProcess") SearchRelationshipProcess searchRelationshipProcess
							,HttpServletRequest request) {
		log.debug("Start Load RelationShip .....");
		List<String> ospList = new ArrayList<String>();
		ospList.add("Other");
		ospList.add("Help Desk/Call Center");
		ospList.add("Infrastructure Support");
		ospList.add("Loan Operations");
		ospList.add("Software Development & Maintenance"); 

		List<String> connectivityExistsRadioList = new ArrayList<String>();
		connectivityExistsRadioList.add("Yes");
		connectivityExistsRadioList.add("No");
		connectivityExistsRadioList.add("N/A");

		String fromPage = request.getParameter("fromPage");
		if(fromPage != null && fromPage.equalsIgnoreCase("saveRelationship")){
			 searchRelationshipProcess = new SearchRelationshipProcess();	
			 
			 //clear session values 
			 request.getSession().removeAttribute("VALIDATION_ERROR_LIST");
			 
			 request.getSession().removeAttribute("CITI_CONTACT_ASSIGN_TO");
			 request.getSession().removeAttribute("CITI_LOCATION_ASSIGN_TO");
			 
			 request.getSession().removeAttribute("CITI_LOCATION_REQ");
			 request.getSession().removeAttribute("CITI_LOCATION_TAR");
			 request.getSession().removeAttribute("CITI_LOCATION_ALL");
			 
			 request.getSession().removeAttribute("CITI_TP_CONTACT_ASSIGN_TO");
			 request.getSession().removeAttribute("CITI_TP_CONTACT_LIST");
			 
			 request.getSession().removeAttribute("CITI_TP_LOCATION_ASSIGN_TO");
			 request.getSession().removeAttribute("CITI_TP_LOCATIONS");
			 request.getSession().removeAttribute("CITI_TP_LOCATIONS_ASSIGNED");

			 request.getSession().removeAttribute("ASSIGN_TO");
			 request.getSession().removeAttribute("THIRD_PARTY_LIST");
			 request.getSession().removeAttribute("ALL_THIRD_PARTY_LIST");
			 request.getSession().removeAttribute("THIRD_PARTY_DETAIL_LIST");
			 request.getSession().removeAttribute("THIRD_PARTY_ID");
			 request.getSession().removeAttribute("TARGET_THIRD_PARTY_ID");
		}
		 if(searchRelationshipProcess == null){
			 searchRelationshipProcess = new SearchRelationshipProcess();
			 searchRelationshipProcess.setOffset(0);
			 searchRelationshipProcess.setPageNo(1);
			 searchRelationshipProcess.setLimit(20);
			 log.debug("no form available");
		 } 
		 
		 searchRelationshipProcess=pageNumber(0,20,0,request,searchRelationshipProcess);
		 List<Relationship> relationships = searchRelationshipProcess.getListOfRelationship();
		 int totalPages = pagination(searchRelationshipProcess.getLimit(),searchRelationshipProcess);	
		 log.debug("pages" +totalPages); 
		 
	     
	 	searchRelationshipProcess.setTotalPages(totalPages);		
		searchRelationshipProcess.setRelationshipList1(relationships);
		searchRelationshipProcess.setBusUnitList(new ArrayList<BusinessUnit>());
		searchRelationshipProcess.setBusUnitListTp(new ArrayList<BusinessUnit>());
		searchRelationshipProcess.setThirdPartyList(new ArrayList());
		searchRelationshipProcess.setTargetResourceTypeList(searchRelationshipProcess.getResourceList());
		searchRelationshipProcess.setRequesterResourceTypeList(searchRelationshipProcess.getResourceList());
		searchRelationshipProcess.setDataClassiList(searchRelationshipProcess.getDatClassificationList());
        
		List<Long> classiDataList = new ArrayList<Long>();
		List<Long> resourceTypeDataList = new ArrayList<Long>();
		List<Long> thirdPartyDataList = new ArrayList<Long>();
		List<BusinessUnit> businessUnitDataList = new ArrayList<BusinessUnit>();
		List<LookupDTO> lookupDTOList = searchRelationshipProcess.getDatClassificationList();
		for (LookupDTO lookupDTOListObj : lookupDTOList) {
			classiDataList.add(lookupDTOListObj.getValue());
		}

		List<ResourceType> resourceTypeList = searchRelationshipProcess.getResourceList();
		for (ResourceType resourceTypeListObj : resourceTypeList) {
			resourceTypeDataList.add(resourceTypeListObj.getId());
		}		
		
		String orderId = (String)request.getParameter("orderId");
		log.info("orderId in SearchRelationshipController::: "+orderId);
		if(orderId!=null){
			HttpSession session = request.getSession();
			session.setAttribute("orderId", orderId);
			//searchRelationshipProcess.setCmpOrderId(orderId);
		}
	
		model.addAttribute("connectivityExistsRadioList",connectivityExistsRadioList);
		model.addAttribute("resourceTypeDataList", resourceTypeDataList);
		model.addAttribute("classiDataList", classiDataList);
		model.addAttribute("thirdPartyDataList", thirdPartyDataList);
		model.addAttribute("businessUnitDataList", businessUnitDataList);
		model.addAttribute("serviceProvidedDataList", ospList);
		model.addAttribute("searchRelationshipProcess", searchRelationshipProcess);

		log.debug("End Load RelationShip.......");

		return new ModelAndView("c3par.relationship.listRelationship",
				"searchRelationshipProcess", searchRelationshipProcess);
	}

	 
	@RequestMapping(value = "/ajaxSearchThirdPartyRelationshipListController.act", method =  { RequestMethod.GET, RequestMethod.POST })
	// To load third party search filter
	public @ResponseBody String searchThirdParty(ModelMap model,@ModelAttribute("searchRelationshipProcess") SearchRelationshipProcess searchRelationshipProcess,HttpServletRequest request) {
		log.info("SearchRelationshipAction::searchThirdParty method starts...");
		List<LookupDTO> tpList = searchRelationshipProcess.getThirdPartyList1();
		searchRelationshipProcess.setThirdPartyList(tpList);
		StringBuffer firewallGroupJSONSB = new StringBuffer();
		firewallGroupJSONSB.append("["); 
		firewallGroupJSONSB
				.append("{\"item\":\"\",\"label\":\"---Select---\"}");
		for (LookupDTO sector : tpList) {
			firewallGroupJSONSB.append(",{\"item\":\"" + sector.getValue()
					+ "\",\"label\":\"" + sector.getName() + "\"}");
		}
		firewallGroupJSONSB.append("]");
		request.setAttribute("comboValues", firewallGroupJSONSB.toString());
		log.info("ManageRelationshipAction::loadSector method ends...");
		return firewallGroupJSONSB.toString();
	}

	@RequestMapping(value = "/ajaxSearchBuFilterRelationshipListController.act",  method =  { RequestMethod.GET, RequestMethod.POST })
	// To load business unit filter
	public @ResponseBody String searchBuFilter(ModelMap model,@ModelAttribute("searchRelationshipProcess") SearchRelationshipProcess searchRelationshipProcess,HttpServletRequest request) {
		log.info("SearchRelationshipAction::searchBuFilter method starts...");
		List<BusinessUnit> bulist = searchRelationshipProcess.getBusiUnitList();
		searchRelationshipProcess.setBusUnitList(bulist);
		StringBuffer firewallGroupJSONSB = new StringBuffer();
		firewallGroupJSONSB.append("[");
		firewallGroupJSONSB
				.append("{\"item\":\"\",\"label\":\"---Select---\"}");
		for (BusinessUnit bu : bulist) {
			firewallGroupJSONSB.append(",{\"item\":\"" + bu.getId()
					+ "\",\"label\":\"" + bu.getBusinessName() + "\"}");
		}
		firewallGroupJSONSB.append("]");
		request.setAttribute("comboValues", firewallGroupJSONSB.toString());
		log.info("SearchRelationshipAction::searchBuFilter method ends...");
		return firewallGroupJSONSB.toString();
	}

	@RequestMapping(value = "/ajaxsearchBuFilterForTpRelationshipListController.act", method =  { RequestMethod.GET, RequestMethod.POST })
	// To load business unit filter in thirty party search screen
	public @ResponseBody String searchBuFilterForTp(ModelMap model,@ModelAttribute("searchRelationshipProcess") SearchRelationshipProcess searchRelationshipProcess,HttpServletRequest request) {
		log.info("SearchRelationshipAction::searchBuFilter method starts...");
		List<BusinessUnit> bulist = searchRelationshipProcess
				.getBusiUnitListForTp();
		searchRelationshipProcess.setBusUnitListTp(bulist);
		StringBuffer firewallGroupJSONSB = new StringBuffer();
		firewallGroupJSONSB.append("[");
		firewallGroupJSONSB
				.append("{\"item\":\"\",\"label\":\"---Select---\"}");
		for (BusinessUnit bu : bulist) {
			firewallGroupJSONSB.append(",{\"item\":\"" + bu.getId()
					+ "\",\"label\":\"" + bu.getBusinessName() + "\"}");
		}
		firewallGroupJSONSB.append("]");
		request.setAttribute("comboValues", firewallGroupJSONSB.toString());
		log.info("SearchRelationshipAction::searchBuFilter method ends...");
		return firewallGroupJSONSB.toString();
	}
    // For Pagination
	 public int pagination(int limit,SearchRelationshipProcess searchRelationshipProcess){
			log.info("Inside ManageRelationshipAction : pagination methods starts here ...");
			int rowCount = searchRelationshipProcess.getRowCount();		
			int totalPages = 0;		
			if (rowCount%limit > 0) {
				totalPages = Math.round((rowCount/limit)+0.5f);
			} else {
				totalPages = Math.round(rowCount/limit);
			}	
			log.info("Inside ManageRelationshipAction : pagination methods ends here ..."+totalPages);
			return totalPages;
	}
	 
	 //For page number
	  public SearchRelationshipProcess pageNumber(int curOffSet,int limit,int pageNo,HttpServletRequest request,SearchRelationshipProcess searchRelationshipProcess){
			log.info("Inside ManageRelationshipAction : pageNumber methods starts here ...");
			String type = (String)request.getParameter("pageType");
			log.debug("type Search RelationShip......." + type);
			if(searchRelationshipProcess != null){
				curOffSet = searchRelationshipProcess.getOffset();		
				limit = searchRelationshipProcess.getLimit();		
				pageNo = searchRelationshipProcess.getPageNo();  
			}
			//searchRelationshipProcess = new SearchRelationshipProcess();
			searchRelationshipProcess.setLimit(limit);
			searchRelationshipProcess.setPaginationRequired(true);
			if (type != null && "N".equalsIgnoreCase(type)) {
				searchRelationshipProcess.setOffset(curOffSet+searchRelationshipProcess.getLimit());
				searchRelationshipProcess.setPageNo(pageNo+1);  
			} else if (type != null && "P".equalsIgnoreCase(type)) {
				searchRelationshipProcess.setOffset(curOffSet-searchRelationshipProcess.getLimit());
				searchRelationshipProcess.setPageNo(pageNo-1);
			} else if (type != null && "X".equalsIgnoreCase(type)) {
				searchRelationshipProcess.setOffset(limit * (pageNo-1));
				searchRelationshipProcess.setPageNo(pageNo);
			} else if ("L".equalsIgnoreCase(type)) {
				searchRelationshipProcess.setOffset(0);
				searchRelationshipProcess.setPageNo(1);
			}else {
				searchRelationshipProcess.setOffset(0);
				searchRelationshipProcess.setPageNo(1);
				searchRelationshipProcess.setLimit(20);
			}
			log.info("Inside ManageAdminAction : pageNumber methods ends here ...");
			return searchRelationshipProcess;
	}
}
