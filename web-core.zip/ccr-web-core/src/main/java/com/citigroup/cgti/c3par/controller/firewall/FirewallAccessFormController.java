package com.citigroup.cgti.c3par.controller.firewall;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequestInfo;
import com.citigroup.cgti.c3par.fw.domain.FafFireflowTicket;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiHierarchyXref;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;

@Controller
public class FirewallAccessFormController extends BaseController {
	
	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	private static final String FF_TICKETS = "ticketsInSession";
	private static final String FF_REQUEST_INFO = "fafrequestinfo";
	private static final String FAF_TECH_ARCH_PAGE = "techArchPage";
	private static final String FAF_IMPL_PAGE = "implPage";
	private static final String VIEW_REQUESTED = "requested";
	private static final String VIEW_WO_GENERATED = "WOGenerated";
	private static final String FILTER_ADD = "add";
	private static final String FILTER_DELETE = "delete";
	private static final String CURRENT = "current";
	private static final String PREVIOUS = "previous";
	private static final String NEXT = "next";
	private static final String SELECTED = "selected";
	private static final String EXPORT_LIST = "EXPORT_LIST";

	
	@RequestMapping(value = "/listTickets.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String listTickets(HttpServletRequest request, ModelMap model) {
		log.info("In FirewallAccessFormController: listTickets() ");
		String fromPage = request.getParameter("fromPage");
		FAFRequest fafRequest = new FAFRequest();
		if (fromPage != null && !fromPage.isEmpty()) {
			fafRequest.setFromPage(fromPage);
		}
		fafRequest.setStartIndex(0);
		fafRequest.setPageNo(1);
		fafRequest.setPageLimit(5);
		try {
			
			log.debug("In FirewallAccessFormController: listTickets() "+fafRequest.getFafVersionSelected());
			log.debug("In FirewallAccessFormController: listTickets() "+getCurrentTiRequest(request).getId());
			if (fafRequest.getFafVersionSelected() == 0) {
				fafRequest.setFafVersionSelected(getCurrentTiRequest(request).getId());
				fafRequest.setCurrentVersion(getCurrentTiRequest(request).getId());
			}
			fafRequest.setPlanningVersion(fafRequest.getPlanningTIRequest(getTiProcessId(request)).getId());
			fafRequest.setPreviousRequired(isPreviousRequired(fafRequest));
			fafRequest.setNextRequired(isNextRequired(fafRequest));
			
			setRelationshipType(fafRequest.getPlanningVersion(), fafRequest);
			fafRequest.setTiRequest(fafRequest.getFafVersionSelected());
			TIRequest  fafreq=fafRequest.getTIRequest(fafRequest.getFafVersionSelected());
			if ( "Y".equalsIgnoreCase(fafreq.getFireflowFlag())) {
				fafRequest.setViewType(VIEW_WO_GENERATED);
				fafRequest.setType("N");
				
			} else if ( "N".equalsIgnoreCase(fafreq.getFireflowFlag())) {
				fafRequest.setViewType(VIEW_REQUESTED);
				fafRequest.setType("N");				
			}
			String con_type = "",isIPReg = "N";
			
			if ("implPage".equalsIgnoreCase(fromPage)) {
	        	request.getSession().setAttribute("con_type", (String)request.getParameter("con_type"));
	        }
			
			if(request.getSession().getAttribute("con_type") != null){
				con_type = (String) request.getSession().getAttribute("con_type");
				
				if(con_type != null && con_type.equalsIgnoreCase("ipReg")){
					isIPReg = "Y";
				}
			}
			
			fafRequest.setFaFCycles(fafRequest
					.getAllCyclesAndVersion(getTiProcessId(request),fafRequest.getIsIPReg()));
			
			fafRequest.setPaginationRequired(true);
			if (isCCRComputationRequired(request, fafRequest)) {
				fafRequest.generateFAF(getCurrentTiRequest(request).getId(),isIPReg);
			}
			setRelationshipType(fafRequest.getFafVersionSelected(), fafRequest);
			isCompleteCheck(request);
			polulateFAFRequestInfo(fafRequest, request);
			retrieveRuleDetails(fafRequest, request);
			fafRequest.setCombinationTypes(getCombinationTypes());
			fafRequest.setViews(getViews());
			request.getSession().setAttribute(FF_TICKETS, fafRequest.getFafFireflowTickets());
			model.addAttribute("fafRequest", fafRequest);
			request.setAttribute("startIndex", fafRequest.getStartIndex());
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - " + e.getMessage());
		}
		model.addAttribute("appList",fafRequest.getFafRequestInfo().getApplicationList());
		model.addAttribute("buContactList",fafRequest.getFafRequestInfo().getBusinessContacts());
		return "c3par.faf.listTickets";
	}
	
	
	@RequestMapping(value = "/versionChange.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String versionChange(HttpServletRequest request, ModelMap model, @ModelAttribute("fafRequest") FAFRequest fafRequest) {
		log.info("In FirewallAccessFormController: listTickets() ");
		fafRequest.setStartIndex(0);
		fafRequest.setPageNo(1);
		fafRequest.setPageLimit(5);
		try {
			
			log.debug("In FirewallAccessFormController: listTickets() "+fafRequest.getFafVersionSelected());
			log.debug("In FirewallAccessFormController: listTickets() "+getCurrentTiRequest(request).getId());
			if (fafRequest.getFafVersionSelected() == 0) {
				fafRequest.setFafVersionSelected(getCurrentTiRequest(request).getId());
				fafRequest.setCurrentVersion(getCurrentTiRequest(request).getId());
			}
			fafRequest.setPlanningVersion(fafRequest.getPlanningTIRequest(getTiProcessId(request)).getId());
			fafRequest.setPreviousRequired(isPreviousRequired(fafRequest));
			fafRequest.setNextRequired(isNextRequired(fafRequest));
			setRelationshipType(fafRequest.getPlanningVersion(), fafRequest);
			fafRequest.setTiRequest(fafRequest.getFafVersionSelected());
			TIRequest  fafreq=fafRequest.getTIRequest(fafRequest.getFafVersionSelected());
			if ( "Y".equalsIgnoreCase(fafreq.getFireflowFlag())) {
				fafRequest.setViewType(VIEW_WO_GENERATED);
				fafRequest.setType("N");
				
			} else if ( "N".equalsIgnoreCase(fafreq.getFireflowFlag())) {
				fafRequest.setViewType(VIEW_REQUESTED);
				fafRequest.setType("N");				
			}
			
			if (fafRequest.getType() == null || fafRequest.getType().isEmpty()) {
				fafRequest.setType("N");
			}
			
			String con_type = "",isIPReg = "N";
			if(request.getSession().getAttribute("con_type") != null){
				con_type = (String) request.getSession().getAttribute("con_type");
				
				if(con_type != null && con_type.equalsIgnoreCase("ipReg")){
					isIPReg = "Y";
				}
			}
			
			fafRequest.setFaFCycles(fafRequest
					.getAllCyclesAndVersion(getTiProcessId(request),fafRequest.getIsIPReg()));
			
			fafRequest.setPaginationRequired(true);
			if (isCCRComputationRequired(request, fafRequest)) {
				fafRequest.generateFAF(getCurrentTiRequest(request).getId(),isIPReg);
			}
			setRelationshipType(fafRequest.getFafVersionSelected(), fafRequest);
			isCompleteCheck(request);
			polulateFAFRequestInfo(fafRequest, request);
			retrieveRuleDetails(fafRequest, request);
			fafRequest.setCombinationTypes(getCombinationTypes());
			fafRequest.setViews(getViews());
			request.getSession().setAttribute(FF_TICKETS, fafRequest.getFafFireflowTickets());
			model.addAttribute("fafRequest", fafRequest);
			request.setAttribute("startIndex", fafRequest.getStartIndex());
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - " + e.getMessage());
		}
		return "c3par.faf.listTickets";
	}
	
	@RequestMapping(value = "/paginateTickets.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String paginateTickets(HttpServletRequest request, ModelMap model, @ModelAttribute("fafRequest") FAFRequest fafRequest) {
		log.info("In FirewallAccessFormController: listTickets() ");
		
		
		if (NEXT.equalsIgnoreCase(fafRequest.getPageFlow())) {
			fafRequest.setPageNo(fafRequest.getPageNo()+1);
			fafRequest.setStartIndex(fafRequest.getPageLimit()+fafRequest.getStartIndex());
		}
		else if (PREVIOUS.equalsIgnoreCase(fafRequest.getPageFlow())) {
			fafRequest.setPageNo(fafRequest.getPageNo()-1);
			fafRequest.setStartIndex(fafRequest.getStartIndex()-fafRequest.getPageLimit());
		}
		else
		{
			fafRequest.setPageNo(1);
			fafRequest.setStartIndex(0);
		}
		
		if (fafRequest.getPageLimit() <= 0) {
			fafRequest.setPageLimit(5);
		}
		
		fafRequest.setCombinationTypes(getCombinationTypes());
		fafRequest.setViews(getViews());
		try {
			
			log.debug("In FirewallAccessFormController: listTickets() "+fafRequest.getFafVersionSelected());
			log.debug("In FirewallAccessFormController: listTickets() "+getCurrentTiRequest(request).getId());
			if (fafRequest.getFafVersionSelected() == 0) {
				fafRequest.setFafVersionSelected(getCurrentTiRequest(request).getId());
				fafRequest.setCurrentVersion(getCurrentTiRequest(request).getId());
			}
			fafRequest.setPlanningVersion(fafRequest.getPlanningTIRequest(getTiProcessId(request)).getId());
			fafRequest.setPreviousRequired(isPreviousRequired(fafRequest));
			fafRequest.setNextRequired(isNextRequired(fafRequest));
			setRelationshipType(fafRequest.getPlanningVersion(), fafRequest);
			fafRequest.setTiRequest(fafRequest.getFafVersionSelected());
			TIRequest  fafreq=fafRequest.getTIRequest(fafRequest.getFafVersionSelected());
			if ( "Y".equalsIgnoreCase(fafreq.getFireflowFlag())) {
				fafRequest.setViewType(VIEW_WO_GENERATED);
				//fafRequest.setType("N");
				
			} else if ( "N".equalsIgnoreCase(fafreq.getFireflowFlag())) {
				fafRequest.setViewType(VIEW_REQUESTED);
				//fafRequest.setType("N");
			}
			
			if (fafRequest.getType() == null || fafRequest.getType().isEmpty()) {
				fafRequest.setType("N");
			}
			
			String con_type = "",isIPReg = "N";
			if(request.getSession().getAttribute("con_type") != null){
				con_type = (String) request.getSession().getAttribute("con_type");
				
				if(con_type != null && con_type.equalsIgnoreCase("ipReg")){
					isIPReg = "Y";
				}
			}
			
			fafRequest.setFaFCycles(fafRequest
					.getAllCyclesAndVersion(getTiProcessId(request),fafRequest.getIsIPReg()));
			
			fafRequest.setPaginationRequired(true);
			if (isCCRComputationRequired(request, fafRequest)) {
				fafRequest.generateFAF(getCurrentTiRequest(request).getId(),isIPReg);
			}
			setRelationshipType(fafRequest.getFafVersionSelected(), fafRequest);
			isCompleteCheck(request);
			polulateFAFRequestInfo(fafRequest, request);
			retrieveRuleDetails(fafRequest, request);
			request.getSession().setAttribute(FF_TICKETS, fafRequest.getFafFireflowTickets());
			model.addAttribute("fafRequest", fafRequest);
			request.setAttribute("startIndex", fafRequest.getStartIndex());
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - " + e.getMessage());
		}
		return "c3par.faf.listTickets";
	}
	
	public void setRelationshipType(Long tiRequestID, FAFRequest fafRequest) {
		FireWallRuleProcess fwRuleProcess = new FireWallRuleProcess();
		ArrayList relationshipDetails = (ArrayList) fwRuleProcess
				.getTIReqeustRelationshipDetails(tiRequestID);
		fafRequest.setRelationshipType(String.valueOf(relationshipDetails
				.get(2)));

	}
	
	public boolean isTicketCreationRequired(HttpServletRequest request, String fromPage, FAFRequest fafRequest) {

		if (FAF_TECH_ARCH_PAGE.equalsIgnoreCase(fromPage)  && (fafRequest.getFafVersionSelected()==getCurrentTiRequest(request).getId().longValue())
				&& (isRuleChanged(request) || isTicketNotCreated(request))) {
			return true;
		}
		return false;
	}
	
	private boolean isTicketNotCreated(HttpServletRequest request) {
		FafFireflowTicket fafFireflowTicket = new FafFireflowTicket();
		return fafFireflowTicket.isTicketsToBeCreated(getCurrentTiRequest(request)
				.getId());

	}

	private boolean isRuleChanged(HttpServletRequest request) {
		FireWallRuleProcess fireWallRuleProcess = new FireWallRuleProcess();
		String con_type = (String) request.getSession().getAttribute("con_type");
		
		return fireWallRuleProcess
				.isFireWallRulesHasChanged(getCurrentTiRequest(request).getId(), con_type);

	}

	private boolean isCCRComputationRequired(HttpServletRequest request, FAFRequest fafRequest) {
		boolean isCCRComputationRequired = false;
		HttpSession session = request.getSession();
		String displayMode = (String)session.getAttribute("displayMode");
		if(displayMode == null){
			displayMode = "";
		}
		TIRequest tiRequestEntity = getTirequest(request);
		
		String requestType =  "";
		if (tiRequestEntity.getTiRequestType() != null
				&& tiRequestEntity.getTiRequestType().getName() != null) {
			requestType = tiRequestEntity.getTiRequestType().getName();
			if(requestType == null){ requestType = ""; }
			log.debug(" Request Type :: " + requestType);
		}		
		if (FAF_TECH_ARCH_PAGE.equalsIgnoreCase(fafRequest.getFromPage()) && isRuleChanged(request) && (displayMode.equalsIgnoreCase("Edit") || requestType.equalsIgnoreCase("Terminate") )) {
			isCCRComputationRequired = true;
		}
		log.debug("isCCRComputationRequired ==>"+isCCRComputationRequired+", fromPage ==>"+fafRequest.getFromPage()+", displayMode ==>"+displayMode+", requestType ==>"+requestType+", isRuleChanged() ==>"+isRuleChanged(request));
		return isCCRComputationRequired;
	}
	
	private FAFRequest polulateFAFRequestInfo(FAFRequest fafRequest, HttpServletRequest request) {

		BusinessJustificationProcess busjusProcess = new BusinessJustificationProcess();
		
		Long tirequestId = getTirequestID(request);
		
		Long planningId = busjusProcess.getPlanningId(tirequestId);
		
		TIRequest tirequest = busjusProcess.getTIRequestDetails(tirequestId);
		
		ConnectionRequest conreq = busjusProcess.getConnectionRequest(planningId);
		
		log.info("In Action:ManageFAFAction: polulateFAFRequestInfo() called ");
		FAFRequestInfo fafRequestInfo = new FAFRequestInfo();
		
		String requestType =  null;
		if (tirequest.getTiRequestType() != null
				&& tirequest.getTiRequestType().getName() != null) {
			requestType = tirequest.getTiRequestType().getName();
			log.debug(" Request Type :: " + requestType);
			if (requestType != null
					&& requestType.equalsIgnoreCase("Terminate")) {
				log.debug("Setting DisplayMode to Edit for Termination Cycle");
				request.getSession().setAttribute("displayMode", "Edit");
			}
		}
		
		
		Long connectionRequestId = conreq.getId();

		log
				.debug("In Action:ManageFAFAction: polulateFAFRequestInfo() TiRequest Id is: "
						+ tirequest.getId()
						+ "\t connectionRequestId is "
						+ conreq.getId());
		fafRequestInfo.setOriginalConnectionRequestId(connectionRequestId);
		fafRequestInfo.setConnectionName(conreq.getConnectionName());
		fafRequestInfo.setTiRequest(fafRequest.getTiRequest());

		String buName = "";
		String relationshipName = "";
		String relationshipId = "";
		String currBusJustfication = "";
		String con_type = (String) request.getSession().getAttribute("con_type");
		String isIpReg = "";
		if("ipReg".equalsIgnoreCase(con_type)){
			 isIpReg = "Y";
		}else{
			isIpReg = "N";
		}
		
		Relationship relationship = tirequest.getTiProcess().getRelationshipId();
		
		if (relationship != null) {
			if (relationship.getRelcitiHierarchyXrefs() != null && relationship.getRelcitiHierarchyXrefs().size() > 0) {
				RelCitiHierarchyXref relXref = (RelCitiHierarchyXref)relationship.getRelcitiHierarchyXrefs().get(0);
				if(relXref.getCitiHierarchyMaster() !=null && relXref.getCitiHierarchyMaster().getBusinessUnit() != null) {
	                buName = relXref.getCitiHierarchyMaster().getBusinessUnit().getBusinessName();
	                log.debug("ManageFafAction:CitiHierMaster:"+buName);
				}
			}
			if (relationship.getName() != null) {
				relationshipName = relationship.getName();
			}
			if (relationship.getId() != null) {
				relationshipId = relationship.getId() + "";
			}
		}
		if (conreq != null) {
			
			if (conreq.getRationale() != null) {
				currBusJustfication = conreq.getRationale();
			}
		}
		fafRequestInfo.setRationale(currBusJustfication);
		fafRequestInfo.setBuName(buName);
		fafRequestInfo.setRelationshipId(relationshipId);
		fafRequestInfo.setRelationshipName(relationshipName);
		fafRequestInfo.setIsIpReg(isIpReg);
		fafRequest.setFafRequestInfo(fafRequest.populateFAFRequestInfo(fafRequestInfo,isIpReg));
		request.getSession().setAttribute(FF_REQUEST_INFO, fafRequest.getFafRequestInfo());
		log.info("In Action:ManageFAFAction: End of polulateFAFRequestInfo() ");
		return fafRequest;
	}
	
	private FAFRequest retrieveRuleDetails(FAFRequest fafRequest, HttpServletRequest request) {
		log.info("In Action:ManageFAFAction: retrieveRuleDetails() ");
		String con_type = (String) request.getSession().getAttribute("con_type");
		String isIpReg = "";
		if("ipReg".equalsIgnoreCase(con_type)){
			 isIpReg = "Y";
		}else{
			isIpReg = "N";
		}
		fafRequest.setIsIPReg(isIpReg);
		log.debug(" retrieveRuleDetails ==> con_type :: " + con_type + ", isIpReg :: " + isIpReg);
		fafRequest.setFafFireflowTickets(fafRequest.findFafFireflowTickets(isIpReg));
		
		if(fafRequest.getSourceIPAddress() != null){
			fafRequest.setSourceIPAddress(fafRequest.getSourceIPAddress().trim());
		}
		if(fafRequest.getDestinationIPAddress() != null){
			fafRequest.setDestinationIPAddress(fafRequest.getDestinationIPAddress().trim());
		}
		if(fafRequest.getPortNumber() != null){
			fafRequest.setPortNumber(fafRequest.getPortNumber().trim());
		}
		if(fafRequest.getSourceZone() != null){
			fafRequest.setSourceZone(fafRequest.getSourceZone().trim());
		}
		if(fafRequest.getPolicyGroup() != null){
			fafRequest.setPolicyGroup(fafRequest.getPolicyGroup().trim());
		}
		if(fafRequest.getPolicy() != null){
			fafRequest.setPolicy(fafRequest.getPolicy().trim());
		}
		
		fafRequest.setFirstResult(fafRequest.getStartIndex());
		fafRequest.setMaxResult(fafRequest.getPageLimit());

		
		if (VIEW_REQUESTED.equalsIgnoreCase(fafRequest.getViewType())) {
			fafRequest.setRequestedRules(fafRequest
					.findRequestedRulesByRequest());
			log
					.info("In Action:ManageFAFAction: retrieveRuleDetails() viewType is: "
							+ fafRequest.getViewType());

		}
		if (VIEW_WO_GENERATED.equalsIgnoreCase(fafRequest.getViewType())) {
			fafRequest.setRecommendedRules(fafRequest
					.findRecommendedRulesByRequest());
			log
					.info("In Action:ManageFAFAction: retrieveRuleDetails(): viewType is: "
							+ fafRequest.getViewType());

		}
		int rowCount = fafRequest.getRowCount();
		int totalPages = Math.round((rowCount / 5) + 0.5f);
		fafRequest.setTotalPages(totalPages);
		return fafRequest;

	}
	
	

	public Map<String, String> getViews() {
		// TODO Auto-generated method stub
		Map<String, String> tirequests = new LinkedHashMap<String, String>();
		//get Valid cycles which has FAF in chronological order
		tirequests.put("requested", "Requested");
		tirequests.put("WOGenerated", "WO Generated");

		return tirequests;

	}

	public Map<String, String> getCombinationTypes() {
		// TODO Auto-generated method stub
		Map<String, String> tirequests = new LinkedHashMap<String, String>();
		//get Valid cycles which has FAF in chronological order
		tirequests.put("A", "Add");
		tirequests.put("D", "Delete");
		tirequests.put("N", "All");

		return tirequests;
	}
	
	
	/**
	 * Creates the ticket.
	 * 
	 * @return the string
	 */
	@RequestMapping(value = "/createTicket.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String createTicket(HttpServletRequest request, ModelMap model, @ModelAttribute("fafRequest") FAFRequest fafRequest) {
		try {
			log.info("In Action:ManageFAFAction: createTicket() ");
			if (fafRequest.getFafVersionSelected() == 0) {
				fafRequest.setFafVersionSelected(getCurrentTiRequest(request).getId());
				fafRequest.setCurrentVersion(getCurrentTiRequest(request).getId());
			}
			fafRequest.setPlanningVersion(fafRequest.getPlanningTIRequest(getTiProcessId(request)).getId());
			fafRequest.setFafRequestInfo((FAFRequestInfo) request.getSession()
					.getAttribute(FF_REQUEST_INFO));
			log
					.info("In Action:ManageFAFAction: createTicket() Connection Id is: "
							+ fafRequest.getFafRequestInfo()
									.getOriginalConnectionRequestId());
			log
					.info("In Action:ManageFAFAction: createTicket() Connection Name is: "
							+ fafRequest.getFafRequestInfo()
									.getConnectionName());
			FafFireflowTicket ticket = new FafFireflowTicket();
			ticket.setFafRequestInfo(fafRequest.getFafRequestInfo());
			try {
				ticket.createFireflowTicket(getCurrentTiRequest(request).getId(),request.getCookies());
			} catch (Exception e) {
				//addFieldError("firewallRuleProcess.fireWallRule", e.getMessage());
			}
			fafRequest.setPaginationRequired(true);
			polulateFAFRequestInfo(fafRequest, request);
			retrieveRuleDetails(fafRequest, request);
			
			
			request.getSession().setAttribute(FF_TICKETS, fafRequest.getFafFireflowTickets());
			log.info("In Action:ManageFAFAction: End of createTicket() ");

		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - " + e.getMessage());
		}
		return "list";
	}

	@RequestMapping(value = "/exportFaf.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String exportFaf(HttpServletRequest request,HttpServletResponse response, ModelMap model, @ModelAttribute("fafRequest") FAFRequest fafRequest) {
		try {
			log.info("In Export Method isObject Expandable::::>>>>> "+fafRequest.getIsObjExpandable());
			if (fafRequest.getFafVersionSelected() == 0) {
				fafRequest.setFafVersionSelected(getCurrentTiRequest(request).getId());
				fafRequest.setCurrentVersion(getCurrentTiRequest(request).getId());
			}
			fafRequest.setPlanningVersion(fafRequest.getPlanningTIRequest(getTiProcessId(request)).getId());
			fafRequest.setTiRequest(fafRequest.getFafVersionSelected());
			fafRequest.setPaginationRequired(false);
			
			String faf = "";
			String con_type = "",isIPReg = "N";
			if(request.getSession().getAttribute("con_type") != null){
				con_type = (String) request.getSession().getAttribute("con_type");
				
				if(con_type != null && con_type.equalsIgnoreCase("ipReg")){
					isIPReg = "Y";
				}
			}
			
			TIRequest request1 = fafRequest.getTIRequest(fafRequest
					.getTiRequest());
			
			
			if("N".equalsIgnoreCase(isIPReg)){
				faf = fafRequest.getFirewallAccessFormText(request1.getId(), request1.getTiProcess().getId(), Long.valueOf(request1.getVersionNumber()),fafRequest.getIsObjExpandable());	
			}
			else{
				faf = fafRequest.getIPRegistrationAccessFormText(request1.getId(), request1.getTiProcess().getId(), Long.valueOf(request1.getVersionNumber()),fafRequest.getIsObjExpandable());
			}
			faf = faf.replaceAll("\n", "\r\n");
			fafRequest.setFafString(faf);
			log.debug("faf string" +faf);
			//Added for task 45182 ends
			
			request.getSession().setAttribute(FF_TICKETS, fafRequest.getFafFireflowTickets());
			
			response.setContentType("text/plain; charset=utf-8");
			response.setHeader("Content-Disposition", "attachment; filename="
					+ request1.getTiProcess().getId() + "-"
					+ request1.getVersionNumber() + ".txt");
			//PrintWriter pw = new PrintWriter (response.getOutputStream());
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - " + e.getMessage());
		}
		return "pages/jsp/fw/fafExport";
	}
	
	public String exportBasedOnType(String expOption, HttpServletRequest request,HttpServletResponse response, ModelMap model, FAFRequest fafRequest) {
		
		try {
			String con_type = "",isIPReg = "N", faf = "";
			if(request.getSession().getAttribute("con_type") != null){
				con_type = (String) request.getSession().getAttribute("con_type");
				
				if(con_type != null && con_type.equalsIgnoreCase("ipReg")){
					isIPReg = "Y";
				}
			}
			TIRequest tiRequestEntity = (TIRequest) request.getSession().getAttribute(
			"TI_REQUEST_ENTITY");
			
			//Added for 46297 starts
			if("N".equalsIgnoreCase(isIPReg)){
				faf = fafRequest.getAllFirewallAccessFormText(getCurrentTiRequest(request).getId(), tiRequestEntity.getTiProcess().getId(), expOption,fafRequest.getIsObjExpandable());
			}
			else{
				faf = fafRequest.getAllIPRegistrationAccessFormText(getCurrentTiRequest(request).getId(), tiRequestEntity.getTiProcess().getId(), expOption,fafRequest.getIsObjExpandable());
			}
			faf = faf.replaceAll("\n", "\r\n");
			//Added for 46297 ends
			fafRequest.setFafString(faf);
			log.debug("faf string" +faf);
			TIRequest tiRequest = fafRequest.getTIRequest(getCurrentTiRequest(request).getId());
			response.setContentType("text/plain; charset=utf-8");
			if("All".equalsIgnoreCase(expOption)){
			response.setHeader("Content-Disposition", "attachment; filename="
					+ tiRequest.getTiProcess().getId() + ".txt");
			}
			else{
			response.setHeader("Content-Disposition", "attachment; filename=All_Implemented_Rules_for_"
					+ tiRequest.getTiProcess().getId() + ".txt");
			}
			
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - " + e.getMessage());
		}
		return "exportAll";
	}
	
	@RequestMapping(value = "/exportAllFaf.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String exportAllFaf(HttpServletRequest request,HttpServletResponse response, ModelMap model, @ModelAttribute("fafRequest") FAFRequest fafRequest) {
		exportBasedOnType("All", request, response, model, fafRequest);
		return "pages/jsp/fw/fafExportAll";
		
	}
	
	@RequestMapping(value = "/exportImplRulesFaf.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String exportImplRulesFaf(HttpServletRequest request,HttpServletResponse response, ModelMap model, @ModelAttribute("fafRequest") FAFRequest fafRequest) {
		exportBasedOnType("Impl",request, response, model, fafRequest);
		return "pages/jsp/fw/fafExportAll";
		
	}
	
	@RequestMapping(value = "/viewIPObject.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String viewIPObject(HttpServletRequest request,HttpServletResponse response, ModelMap model) {
		FAFRequest fafRequest = new FAFRequest();
		fafRequest.setRuleID(Long.valueOf(request.getParameter("ruleID")));
		fafRequest.setIpID(Long.valueOf(request.getParameter("ipID")));
		if (request.getParameter("fafVersionSelected") != null) {
			fafRequest.setFafVersionSelected(Long.valueOf(request.getParameter("fafVersionSelected")));
		}
		TIRequest tiRequestEntity = null;
		tiRequestEntity = (TIRequest) request.getSession().getAttribute(
				"TI_REQUEST_ENTITY");
		fafRequest.setFireWallRuleIPs(fafRequest.getIPsforTemplateObject(fafRequest.getIpID(), fafRequest.getRuleID(), "N", tiRequestEntity.getId()));
		model.addAttribute("fafRequest", fafRequest);		
		return "pages/jsp/fw/ipobjectDetails";
		
	}
	
	@RequestMapping(value = "/viewPortObject.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String viewPortObject(HttpServletRequest request,HttpServletResponse response, ModelMap model) {
		FAFRequest fafRequest = new FAFRequest();
		fafRequest.setRuleID(Long.valueOf(request.getParameter("ruleID")));
		fafRequest.setPortID(Long.valueOf(request.getParameter("portID")));
		if (request.getParameter("fafVersionSelected") != null) {
			fafRequest.setFafVersionSelected(Long.valueOf(request.getParameter("fafVersionSelected")));
		}
		TIRequest tiRequestEntity = null;
		tiRequestEntity = (TIRequest) request.getSession().getAttribute(
				"TI_REQUEST_ENTITY");
		fafRequest.setFireWallRulePorts(fafRequest.getPortsforTemplateObject(fafRequest.getPortID(), fafRequest.getRuleID(), "N", tiRequestEntity.getId()));
		model.addAttribute("fafRequest", fafRequest);
		return "pages/jsp/fw/portobjectDetails";
		
	}
	
	
	private boolean isNextRequired(FAFRequest fafRequest) {

		if (fafRequest.getFafVersionSelected() != fafRequest.getCurrentVersion()) {
			return true;
		}
		return false;
	}

	private boolean isPreviousRequired(FAFRequest fafRequest) {
		log
				.debug("In Action:ManageFAFAction: isPreviousRequired(): planningVersion is: "
						+ fafRequest.getPlanningVersion()
						+ "\tSelected fafVersionis: "
						+ fafRequest.getFafVersionSelected());
		if (fafRequest.getFafVersionSelected() != fafRequest.getPlanningVersion()) {
			log
					.debug("In Action:ManageFAFAction: isPreviousRequired(): Selected fafVersionis: "
							+ fafRequest.getFafVersionSelected());
			return true;
		}
		return false;

	}
	
	
}
