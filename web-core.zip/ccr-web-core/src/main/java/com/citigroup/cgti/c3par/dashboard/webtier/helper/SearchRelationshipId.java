package com.citigroup.cgti.c3par.dashboard.webtier.helper;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.citigroup.cgti.c3par.ScenarioNames;
import com.citigroup.cgti.c3par.dao.CommonLookupDataDAO;
import com.citigroup.cgti.c3par.dao.EntitlementInstanceDAO;
//import com.citigroup.cgti.c3par.dao.EntitlementXrefDAO;
import com.citigroup.cgti.c3par.dao.RelationshipDAO;
import com.citigroup.cgti.c3par.lookup.C3parUsersLookup;
import com.citigroup.cgti.c3par.model.C3parUsersEntity;
import com.citigroup.cgti.c3par.model.EntitlementInstanceEntity;
import com.citigroup.cgti.c3par.model.RelationshipEntity;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.webtier.helper.C3parStatusLookupNames;
import com.citigroup.cgti.c3par.webtier.helper.FieldValidator;
import com.mentisys.dao.AccessObject;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Expression;
import com.mentisys.dao.query.JoinExpression;
//import com.mentisys.dao.query.LogicalExpression;
//import com.mentisys.dao.query.LogicalOperator;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;


/**
 * The Class SearchRelationshipId.
 */
public class SearchRelationshipId extends AccessObject
{

    /** The user id. */
    private Long userId;

    /** The is admin. */
    private boolean isAdmin;

    /**
     * Instantiates a new search relationship id.
     *
     * @param session the session
     */
    public SearchRelationshipId(DatabaseSession session)
    {
	super(session);
	isAdmin = true;
    }

    /**
     * Instantiates a new search relationship id.
     *
     * @param session the session
     * @param rsession the rsession
     */
    public SearchRelationshipId(DatabaseSession session, HttpSession rsession)
    {
	super(session);
	isAdmin = CommonCode.isAdmin(rsession);
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#loadModelReferences(java.lang.Object)
     */
    protected void loadModelReferences(Object obj)
    throws DatabaseException
    {}

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#createModel(java.sql.ResultSet)
     */
    protected Object createModel(ResultSet rs)
    throws DatabaseException
    {
	RelationshipEntity relEntity = new RelationshipEntity();
	relEntity.setReferencesLoaded(false);
	relEntity.setId(getLongFromResultSet(rs, RelationshipDAO.COLUMN_ID));
	relEntity.setPrimaryKey(relEntity.getId());
	relEntity.setName(getStringFromResultSet(rs, RelationshipDAO.COLUMN_NAME));
	return relEntity;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	String stmt = null;

	stmt = "SELECT DISTINCT  "
	    + getQualifiedColumnName(RelationshipDAO.TABLE, RelationshipDAO.COLUMN_ID, true)
	    + getQualifiedColumnName(RelationshipDAO.TABLE, RelationshipDAO.COLUMN_NAME, false);
	/* Entitlement change SECTORDAO.TABLE instead of EntitlementXrefDAO.TABLE */
	/* if(!isAdmin)
			stmt = stmt + getFromClause(new String[]{RelationshipDAO.TABLE, EntitlementXrefDAO.TABLE, CommonLookupDataDAO.TABLE });
		else */
	stmt = stmt + getFromClause(new String[]{RelationshipDAO.TABLE, CommonLookupDataDAO.TABLE,EntitlementInstanceDAO.TABLE });

	return stmt;
    }
    /* ENTITLEMENT remove all the three lines in if(!isAdmin) and replace them with  get the sectors the user is assoaciated with and use SectorDAO.id in (getsectors(userid)) */
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getWhereExpression(com.mentisys.dao.query.Condition)
     */
    protected String getWhereExpression(Condition c)
    {
	StringBuffer buf = new StringBuffer();
	buf.append(c.getWhereExpression());
	buf.append(" AND " + EntitlementInstanceDAO.COLUMN_INACTIVE+ " = 'N'" );

	if(!isAdmin)
	{
	   /* //String groupId = CommonCode.getGroupId(this.userId);
	    //buf.append(" AND " + EntitlementXrefDAO.COLUMN_ENTITYNAME + " = '" + RelationshipEntity.ENTITY + "'");
	    //buf.append(" AND " + EntitlementXrefDAO.COLUMN_GROUP_ID + " = " + groupId );
	    List entInstEntities = CommonCode.getEntitlementInstance(this.userId); 
	    String instids =convertListToString(entInstEntities);
	    //if there are no ids 'in' operator  throws sql excep.so default to null if no entitlements are found
	    if(instids!=null && instids.length()==0)
		instids=null;
	    buf.append(" AND "+RelationshipDAO.COLUMN_ENTINSTANCEID+" IN ("+instids+")");*/
	}

	return buf.toString();
    }

    /* ENTITLEMENT  runQuery() remove join for ji between relationship and entitlement and add join between rel,businessunit,sector   */
    /**
     * Run query.
     *
     * @param attributes the attributes
     * @param userId the user id
     * @param connectionId the connection id
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List runQuery(RelationshipSearchAttributes attributes, Long userId, Long connectionId)
    throws DatabaseException
    {
	Condition condition = new Condition();
	if(connectionId != null)
	{
	    OperatorExpression connectionIdExp =
		new OperatorExpression(RelationshipDAO.TABLE + "." + RelationshipDAO.COLUMN_ID, Operator.EQUAL, connectionId);
	    condition.addExpression(connectionIdExp);
	}
	//		else
	//		{
	String relationshipType = attributes.getRelationshipType();
	String processType = attributes.getProcessType();
	if (FieldValidator.isValidString(relationshipType)) {
	    if (C3parStaticNames.CITI_CON.equalsIgnoreCase(relationshipType)||C3parStaticNames.CITI_IP.equalsIgnoreCase(relationshipType)) {
		if ((processType != null) && (!"null".equals(processType)) && (!"".equals(processType))) {
		    if (ScenarioNames.PROCESS_TYPE_CONNECTION.equalsIgnoreCase(processType)) {
			OperatorExpression relationshipTypeLike =
			    new OperatorExpression(RelationshipDAO.COLUMN_RELATIONSHIPTYPE, Operator.EQUAL, C3parStaticNames.CITI_CON);
			condition.addExpression(relationshipTypeLike);
		    } else {
			OperatorExpression relationshipTypeLike =
			    new OperatorExpression(RelationshipDAO.COLUMN_RELATIONSHIPTYPE, Operator.EQUAL, C3parStaticNames.CITI_IP);
			condition.addExpression(relationshipTypeLike);
		    }
		} else {
		    OperatorExpression relationshipTypeLike =
			new OperatorExpression(RelationshipDAO.COLUMN_RELATIONSHIPTYPE, Operator.LIKE, C3parStaticNames.THIRD_PARTY);
		    condition.addExpression(relationshipTypeLike);
		}
	    } else {
		OperatorExpression relationshipTypeLike =
		    new OperatorExpression(RelationshipDAO.COLUMN_RELATIONSHIPTYPE, Operator.LIKE, C3parStaticNames.THIRD_PARTY);
		condition.addExpression(relationshipTypeLike);
	    }
	} else {
	    if ((processType != null) && (!"null".equals(processType)) && (!"".equals(processType))) {
		if (ScenarioNames.PROCESS_TYPE_CONNECTION.equalsIgnoreCase(processType)) {
		    OperatorExpression relationshipTypeLike =
			new OperatorExpression(RelationshipDAO.COLUMN_RELATIONSHIPTYPE, Operator.NOT_EQUAL, C3parStaticNames.CITI_IP);
		    condition.addExpression(relationshipTypeLike);

		} else {
		    OperatorExpression relationshipTypeLike =
			new OperatorExpression(RelationshipDAO.COLUMN_RELATIONSHIPTYPE, Operator.NOT_EQUAL, C3parStaticNames.CITI_CON);
		    condition.addExpression(relationshipTypeLike);
		}
	    }
	}

	Long buId = attributes.getBusinessUnitId();
	if (buId != null) {
	    OperatorExpression buidLike =
		new OperatorExpression(RelationshipDAO.COLUMN_BUSINESSUNIT_ID, Operator.EQUAL, buId);
	    condition.addExpression(buidLike);
	}

	Long thirdPartyId = attributes.getThirdPartyId();
	if (thirdPartyId != null) {
	    OperatorExpression thirdPartyIdLike =
		new OperatorExpression(RelationshipDAO.COLUMN_THIRDPARTY_ID, Operator.EQUAL, thirdPartyId);
	    condition.addExpression(thirdPartyIdLike);
	}

	Long requesterResourceTypeId = attributes.getRequesterResourceTypeId();
	if (requesterResourceTypeId != null) {
	    OperatorExpression requesterResourceTypeLike =
		new OperatorExpression(RelationshipDAO.COLUMN_REQUESTERRESOURCETYPE_ID, Operator.EQUAL, requesterResourceTypeId);
	    condition.addExpression(requesterResourceTypeLike);
	}

	Long targetResourceTypeId = attributes.getTargetResourceTypeId();
	if (targetResourceTypeId != null) {
	    OperatorExpression targetResourceTypeLike =
		new OperatorExpression(RelationshipDAO.COLUMN_TARGETRESOURCETYPE_ID, Operator.EQUAL, targetResourceTypeId);
	    condition.addExpression(targetResourceTypeLike);
	}

	String connectionName = attributes.getRelationshipName();
	if (FieldValidator.isValidString(connectionName)) {
	    OperatorExpression connectionNameLike =
		new OperatorExpression(RelationshipDAO.TABLE + "." + RelationshipDAO.COLUMN_NAME, Operator.LIKE, connectionName.trim());
	    condition.addExpression(connectionNameLike);
	}

	String ospName = attributes.getOspServiceName();
	if (FieldValidator.isValidString(ospName)) {
	    OperatorExpression ospNameLike =
		new OperatorExpression(RelationshipDAO.COLUMN_OSPSERVICENAME, Operator.LIKE, ospName.trim());
	    condition.addExpression(ospNameLike);
	}

	String status = attributes.getStatus();
	if (FieldValidator.isValidString(status)) {
	    OperatorExpression statusLike =
		new OperatorExpression(RelationshipDAO.COLUMN_STATUS, Operator.EQUAL, status.trim());
	    condition.addExpression(statusLike);
	}

	String ssoId = attributes.getSsoId();
	if(FieldValidator.isValidString(ssoId)) {
	    OperatorExpression createdByExp =
		new OperatorExpression(RelationshipDAO.COLUMN_REQUESTERID, Operator.EQUAL, ssoId.toLowerCase());
	    condition.addExpression(createdByExp);

	}

	addBooleanFilter(attributes.getConnectivityExists(), condition, RelationshipDAO.COLUMN_CONNECTIVITYEXISTS);
	addBooleanFilter(attributes.getAccessCitiData(), condition, RelationshipDAO.COLUMN_ACCESSCITIDATA);
	addBooleanFilter(attributes.getAccessCustomerData(), condition, RelationshipDAO.COLUMN_ACCESSCUSTOMERDATA);
	addBooleanFilter(attributes.getOspServiceProvided(), condition, RelationshipDAO.COLUMN_ISOUTSOURCEPROVIDER);

	//			String processType = (String)session.getAttribute("PROCESS_TYPE");


	//		}

	if(!isAdmin)
	{
	    //JoinExpression j1 = new JoinExpression(RelationshipDAO.TABLE, RelationshipDAO.COLUMN_OWNEDBY_ID, EntitlementXrefDAO.TABLE, EntitlementXrefDAO.COLUMN_ID, false);
	    JoinExpression j2 = new JoinExpression(RelationshipDAO.TABLE, RelationshipDAO.COLUMN_LOOKUP_ID, CommonLookupDataDAO.TABLE, CommonLookupDataDAO.COLUMN_ID, false);
	    //LogicalExpression exp = new LogicalExpression(LogicalOperator.AND, j1, j2);
	    condition.addExpression(j2);
	}
	else
	{
	    JoinExpression j1 = new JoinExpression(RelationshipDAO.TABLE, RelationshipDAO.COLUMN_LOOKUP_ID, CommonLookupDataDAO.TABLE, CommonLookupDataDAO.COLUMN_ID, false);
	    condition.addExpression(j1);
	}
	JoinExpression j3 = new JoinExpression(RelationshipDAO.TABLE, RelationshipDAO.COLUMN_ENTINSTANCEID, EntitlementInstanceDAO.TABLE, EntitlementInstanceDAO.COLUMN_ID, false);
	condition.addExpression(j3);

	this.userId = userId;

	condition.addOrderByField("UPPER(" + RelationshipDAO.TABLE + "." + RelationshipDAO.COLUMN_NAME + ")");



	return query(condition, false);
    }

    /**
     * Adds the boolean filter.
     *
     * @param id the id
     * @param cond the cond
     * @param col the col
     */
    protected void addBooleanFilter(Long id, Condition cond, String col)
    {
	if(id != null && id.longValue() > 0)
	{
	    Expression expr;
	    if(id.longValue() == 1)
	    {
		expr = new OperatorExpression(col, Operator.EQUAL, "Y");
	    }
	    else
	    {
		expr = new OperatorExpression(col, Operator.EQUAL, "N");
	    }
	    cond.addExpression(expr);
	}
    }

    /**
     * Adds the boolean filter.
     *
     * @param bool the bool
     * @param cond the cond
     * @param col the col
     */
    protected void addBooleanFilter(Boolean bool, Condition cond, String col)
    {
	if(bool != null)
	{
	    Expression expr;
	    if(bool.booleanValue())
	    {
		expr = new OperatorExpression(col, Operator.EQUAL, "Y");
	    }
	    else
	    {
		expr = new OperatorExpression(col, Operator.EQUAL, "N");
	    }
	    cond.addExpression(expr);
	}
    }

    /**
     * Convert list to string.
     *
     * @param entInstEntities the ent inst entities
     * @return the string
     */
    protected String  convertListToString(List entInstEntities) 
    {
	List instIds=new ArrayList();
	if(entInstEntities!=null){
	    Iterator itr=entInstEntities.iterator();
	    while(itr.hasNext()){
		EntitlementInstanceEntity entEntity=(EntitlementInstanceEntity)itr.next();
		instIds.add(entEntity.getId());
	    }
	}	
	StringBuffer  str=new StringBuffer();
	if(instIds!=null)
	{
	    for(int i=0;i<instIds.size();i++)
	    {
		str.append((Long)instIds.get(i));
		if(i!=instIds.size()-1)
		    str.append(",");

	    }

	}
	return (str.toString());

    }


}
