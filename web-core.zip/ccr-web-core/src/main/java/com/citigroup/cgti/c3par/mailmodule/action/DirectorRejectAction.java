package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;
import java.util.List;

import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;

public class DirectorRejectAction extends MailAction {

Logger log = Logger.getLogger(DirectorRejectAction.class);
	
private final static String ROLE_NAME = "Director";

	@Override
	public void process(IncomingMessage message) {
		
		log.info("Inside DirectorRejectAction process method ");
		
		super.processReject(message,ROLE_NAME);
		
	}
}
