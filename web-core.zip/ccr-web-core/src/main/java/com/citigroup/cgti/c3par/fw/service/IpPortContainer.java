package com.citigroup.cgti.c3par.fw.service;

public class IpPortContainer implements Comparable<IpPortContainer> {
	public IpPortContainer() {
		
	}
	
	public final static String SINGLE = "S";
	
	public final static String RANGE = "R";
	
	public final static String OBJECT = "O";
	
	private String type;
	
	private Long start;
	
	private Long end;
	
	private Long single;
	
	private Long nat;
	
	private Long nwZone;
	
	private String object;
	
	private String ipAddress;
	
	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * @return the start
	 */
	public Long getStart() {
		return start;
	}

	/**
	 * @param start the start to set
	 */
	public void setStart(Long start) {
		this.start = start;
	}

	/**
	 * @return the end
	 */
	public Long getEnd() {
		return end;
	}

	/**
	 * @param end the end to set
	 */
	public void setEnd(Long end) {
		this.end = end;
	}

	/**
	 * @return the single
	 */
	public Long getSingle() {
		return single;
	}

	/**
	 * @param single the single to set
	 */
	public void setSingle(Long single) {
		this.single = single;
	}

	/**
	 * @return the object
	 */
	public String getObject() {
		return object;
	}

	/**
	 * @param object the object to set
	 */
	public void setObject(String object) {
		this.object = object;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the nat
	 */
	public Long getNat() {
		return nat;
	}

	/**
	 * @param nat the nat to set
	 */
	public void setNat(Long nat) {
		this.nat = nat;
	}

	/**
	 * @return the nwZone
	 */
	public Long getNwZone() {
		return nwZone;
	}

	/**
	 * @param nwZone the nwZone to set
	 */
	public void setNwZone(Long nwZone) {
		this.nwZone = nwZone;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((end == null) ? 0 : end.hashCode());
		result = prime * result + ((nat == null) ? 0 : nat.hashCode());
		result = prime * result
				+ ((nwZone == null) ? 0 : nwZone.hashCode());
		result = prime * result
				+ ((object == null) ? 0 : object.hashCode());
		result = prime * result
				+ ((single == null) ? 0 : single.hashCode());
		result = prime * result + ((start == null) ? 0 : start.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IpPortContainer other = (IpPortContainer) obj;
		if (end == null) {
			if (other.end != null)
				return false;
		} else if (!end.equals(other.end))
			return false;
		if (nat == null) {
			if (other.nat != null)
				return false;
		} else if (!nat.equals(other.nat))
			return false;
		if (nwZone == null) {
			if (other.nwZone != null)
				return false;
		} else if (!nwZone.equals(other.nwZone))
			return false;
		if (object == null) {
			if (other.object != null)
				return false;
		} else if (!object.equals(other.object))
			return false;
		if (single == null) {
			if (other.single != null)
				return false;
		} else if (!single.equals(other.single))
			return false;
		if (start == null) {
			if (other.start != null)
				return false;
		} else if (!start.equals(other.start))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IpPortContainer [end=" + end + ", nat=" + nat + ", nwZone="
				+ nwZone + ", object=" + object + ", single=" + single
				+ ", start=" + start + ", type=" + type + "]";
	}
	
	@Override
	public int compareTo(IpPortContainer compareipPortContainer) {
		if (this.hashCode() == compareipPortContainer.hashCode()) {
			return 0;
		} else if (this.hashCode() < compareipPortContainer.hashCode()) {
			return -1;
		} else {
			return 1;
		}
	}

}
