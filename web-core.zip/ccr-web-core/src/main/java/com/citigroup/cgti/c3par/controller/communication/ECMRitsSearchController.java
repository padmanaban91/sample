package com.citigroup.cgti.c3par.controller.communication;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.businessjustification.domain.SearchInRitsProcess;
import com.citigroup.cgti.c3par.soa.model.ProfileEntity;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;


/**
 * The Class ECMRitsSearchController.
 */
@Controller
public class ECMRitsSearchController {

    /** The log. */
    private static Logger log = Logger.getLogger(ECMRitsSearchController.class);   

    @RequestMapping(value = "/loadECMRitsSearch.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(HttpServletRequest request, ModelMap model){
		log.info("ECMRitsSearchController :: load :: starts here..");
		SearchInRitsProcess searchInRitsProcess = new SearchInRitsProcess();
		Long indexId = new Long(request.getParameter("indexId"));
		log.debug("ECMRitsSearchController :: load :: indexId - "+indexId);
		searchInRitsProcess.setCitiContact(new CitiContact());
		searchInRitsProcess.getCitiContact().setId(indexId);
		model.addAttribute("searchInRitsProcess",searchInRitsProcess);
		return "pages/communication/ECMRitsSearch";
	}
    
    @RequestMapping(value = "/ecmRitsSearch.act", method = {RequestMethod.GET,RequestMethod.POST})
   	public String ecmRitsSearch(ModelMap model,@ModelAttribute("searchInRitsProcess") SearchInRitsProcess searchInRitsProcess,HttpServletRequest request
   			,BindingResult result){
		log.info("ECMRitsSearchController :: ecmRitsSearch :: starts here..");
   		  		
   		try {
   		    SOADataComponent soaDataComponent = new SOADataComponent();
   		    ProfileInfoFactory profileInfoFactory = (ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");

   		    ProfileEntity profileEntity = new ProfileEntity();
   		    if(searchInRitsProcess.getCitiContact().getGeId() != null && !searchInRitsProcess.getCitiContact().getGeId().trim().equals("")){
   		    	profileEntity.setGeId(searchInRitsProcess.getCitiContact().getGeId());
   		    } else if(searchInRitsProcess.getCitiContact().getSsoId() != null && !searchInRitsProcess.getCitiContact().getSsoId().trim().equals("")){
   		    	profileEntity.setSoeId(searchInRitsProcess.getCitiContact().getSsoId());
   			} else if(searchInRitsProcess.getCitiContact().getRitsId() != null && !searchInRitsProcess.getCitiContact().getRitsId().trim().equals("")){
   		    	profileEntity.setGeId(searchInRitsProcess.getCitiContact().getRitsId());
   			} else{
   				if(searchInRitsProcess.getCitiContact().getFirstName() != null && !searchInRitsProcess.getCitiContact().getFirstName().trim().equals("")){
   					profileEntity.setFirstName(searchInRitsProcess.getCitiContact().getFirstName());
   				}
   				profileEntity.setLastName(searchInRitsProcess.getCitiContact().getLastName());
   		    }

   		    List<CitiContact> citiContactList = profileInfoFactory.getRitzService().getProfile(profileEntity, request.getHeader("SM_USER"));
   		    
   		    searchInRitsProcess.setCitiContactList(citiContactList);
		 
   		    model.addAttribute("searchInRitsProcess",searchInRitsProcess);
   		 
   		} catch(Exception e) {
   		    log.error(e, e);
   		}
		log.info("ECMRitsSearchController :: ecmRitsSearch :: ends here..");
		
   		return "pages/communication/ECMRitsSearch";
   	}
}