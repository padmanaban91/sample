package com.citigroup.cgti.c3par.connection.domain.logic;

import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.connection.domain.ConnectionFirewallPolicyLookUp;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIPXref;
import com.citigroup.cgti.c3par.domain.logic.C3parServiceFacade;


/**
 * The Interface TechnicalArchitectureLookupFacade.
 */
@SuppressWarnings( { "unchecked" })
public interface TechnicalArchitectureLookupFacade  extends C3parServiceFacade {

    /**
     * Lookup method for Active Resource Types for the given perimeter.
     *
     * @param perimeter the perimeter
     * @return the resource type objs
     */
    List getResourceTypeObjs(String perimeter);

    /**
     * Gets the resource type objs name.
     *
     * @param resourceTypeName the resource type name
     * @return the resource type objs name
     */
    List getResourceTypeObjsName(String resourceTypeName);

    /**
     * Load ip xref.
     *
     * @param id the id
     * @return the connection ip xref
     */
    ConnectionIPXref loadIPXref(Long id);

    /**
     * Load ip xref for ip id.
     *
     * @param id the id
     * @param connectionRequestId the connection request id
     * @return the connection ip xref
     */
    ConnectionIPXref loadIPXrefForIpId(Long id, Long connectionRequestId);

    /**
     * Gets the connection fw policy look up.
     *
     * @param filterMap the filter map
     * @return the connection fw policy look up
     */
    ConnectionFirewallPolicyLookUp getConnectionFWPolicyLookUP (Map filterMap);

    /**
     * Gets the check point firewalls.
     *
     * @param id the id
     * @return the check point firewalls
     */
    List getCheckPointFirewalls(Long id);
}
