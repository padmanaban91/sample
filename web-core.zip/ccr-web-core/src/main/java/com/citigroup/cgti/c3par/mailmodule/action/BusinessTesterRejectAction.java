package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;
import java.util.List;

import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;

public class BusinessTesterRejectAction extends MailAction {

Logger log = Logger.getLogger(BusinessTesterRejectAction.class);

private final static String ROLE_NAME = "Business_Tester";

	@Override
	public void process(IncomingMessage message) {
		
		log.info("Inside BusinessTesterRejectAction process method ");
		
		super.processReject(message,ROLE_NAME);
		
	}
	
}
