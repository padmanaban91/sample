package com.citigroup.cgti.c3par.communication.service;

import java.math.BigDecimal;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.communication.domain.ManagerViewProcess;

import com.citigroup.cgti.c3par.communication.domain.soc.persist.ManagerViewPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
@Transactional
public class ManagerViewImpl extends BasePersistanceImpl implements ManagerViewPersistable {
	
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	String[] ProjectSector = {"CTI","GCB","ICG"};

	
	

	public Map<String, List<ManagerViewProcess>> getAllDetails() {
		
		log.info("Entering into getAllDetails()..");
		
		Map<String, List<ManagerViewProcess>> dataMap = new HashMap<String, List<ManagerViewProcess>>();		
		
		List<ManagerViewProcess> dataList = null; 
		
		ManagerViewProcess managerViewProcess = null;
		
		List<String> assignedUserList = null;
		
		List<String> userInfoList = null;
		
		List<Integer> statusList = null;
		
		
		
		
		
		for(String sector: ProjectSector){
			
			log.info("The Sector Name: "+sector);
			
			dataList = new ArrayList<ManagerViewProcess>();
			//Fetching assigned users for the sector
			assignedUserList = this.getAssignedUsersForSector(sector);
			
			for(String userId :assignedUserList){
				
				//Getting user information
				userInfoList = this.getUserInfo(userId);
				
				managerViewProcess = new ManagerViewProcess();
				//User Last name, First name Info
				if(userInfoList != null && userInfoList.size() > 0){
					
					managerViewProcess.setLastName((String)userInfoList.get(0));
					managerViewProcess.setFirstName((String)userInfoList.get(1));
				} else {
					managerViewProcess.setLastName("");
					managerViewProcess.setFirstName("");
				}
				
				//Role Info	
				String rolename = "";				
				List<String> roleList = this.getUserRole(userId);
				if( roleList != null && roleList.size() > 1) {
					
					rolename = roleList.get(0);
				}
				managerViewProcess.setRole(rolename);
				
				//status Info
				
				statusList = this.getStatus(userId);
				if( statusList != null && statusList.size() > 0) {
				
					managerViewProcess.setByAppStatusCount(statusList.get(0));
					managerViewProcess.setByCancStatusCount(statusList.get(1));
					managerViewProcess.setByCompStatusCount(statusList.get(2));
					
				}
				
				
				dataList.add(managerViewProcess);
				
				userInfoList = null;
			}
			
			dataMap.put(sector, dataList);
		}
		
		
		log.info("Exit from getAllDetails()..");
		
		return dataMap;
	}
	
	
	
	
	/**
	 * @param projectSector - name of the sector.
	 * @return - list of assigned user for the sector.
	 */
	@SuppressWarnings({ "unchecked" })
	private List<String> getAssignedUsersForSector(String projectSector){
		
		log.info("Entering into getAssignedUsersForSector()..");
		
		List<String> assignedUserList = new ArrayList<String>();
		
		Session session = getSession();
		
		String sqlQuery = "select distinct assigned_user from  cmp_request where assigned_user is not null and project_sector='"+projectSector+"'";
		
		log.info("AssignedUsersForSector Query:"+sqlQuery);
		
		List<BigDecimal> bigDecimalList  = session.createSQLQuery(sqlQuery).list();
		
		for(BigDecimal obj: bigDecimalList){
			
			assignedUserList.add(obj.toString());
		}
		
		log.info("The assignedUserList size : "+assignedUserList.size());
		
		log.info("Exit from getAssignedUsersForSector()..");
		
		return assignedUserList;
		
	}
	
	/**
	 * @param userId - The assigned user id.
	 * @return - list of user information.
	 */
	
	private List<String> getUserInfo(String userId){
		
		log.info("Entering into getUserInfo()..");		
		
		List<String> assignedUserList = new ArrayList<String>();
		
		if(! "".equals(userId)){			
		
		Session session = getSession();
		
		int id = Integer.parseInt(userId);
		
		String sqlQuery = "select last_name, first_name from C3PAR_USERS where id="+id;		
		
		log.info("UserInfo Query:"+sqlQuery);
		
		List tempList =  session.createSQLQuery(sqlQuery).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).list();
		
		for(Object obj: tempList){
			
			Map map = (Map) obj;
			assignedUserList.add((String)map.get("LAST_NAME"));
			assignedUserList.add((String)map.get("FIRST_NAME"));
		}
		
		
		} else {
			log.debug("The userid is not valid.");
		}
		log.debug("The UserInfoList size: "+assignedUserList.size());
		
		log.info("Exit from getUserInfo()..");
		
		return assignedUserList;
		
	}
	/**
	 * @param userId - The assigned user id.
	 * @return - the list of roles of assigned user.
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	private List<String> getUserRole(String userId){
		
		log.info("Entering into getUserRole()..");		
		
		List<String> userRolerList = null;
		
		if(! "".equals(userId)){			
		
		Session session = getSession();
		
		int id = Integer.parseInt(userId);
		
		String sqlQuery = "select name from SECURITY_ROLE where id = (select role_id from c3par_process_role_xref where id="+userId+")";
		
		log.info("UserRole Query:"+sqlQuery);
		
		userRolerList = session.createSQLQuery(sqlQuery).list();
		
		
		} else {
			log.debug("The userid is not valid.");
		}
		log.info("UserRoleList size:"+userRolerList.size());
		
		log.info("Exit from getUserRole()..");
		
		return userRolerList;
		
	}
	
	@SuppressWarnings({ "unchecked", "unused" })
	private List<Integer> getStatus(String userId){
		
		log.info("Entering into getStatus()..");		
		
		//userRolerList
		List<Integer> statusList = new ArrayList<Integer>();
		Integer count;
		Session session = getSession();
		
		String sqlApprovedQueryStatus = "select count(*) from cmp_request where assigned_user="+userId+" and status='Approved' ";
		count = ( (BigDecimal) session.createSQLQuery(sqlApprovedQueryStatus).list().get(0)).intValue();
		
		statusList.add(count);
		
		String sqlCompletedQueryStatus = "select count(*) from cmp_request where assigned_user="+userId+" and status='Completed' ";
		count = ( (BigDecimal) session.createSQLQuery(sqlCompletedQueryStatus).list().get(0)).intValue();
		
		statusList.add(count);
		
		String sqlCancellededQueryStatus = "select count(*) from cmp_request where assigned_user="+userId+" and status='Cancelled' ";
		count = ( (BigDecimal) session.createSQLQuery(sqlCancellededQueryStatus).list().get(0)).intValue();
		
		statusList.add(count);
		
		
		log.info("Exit from getStatus()..");
		
		return statusList;
		
	}




	@Override
	public Map<String, List<ManagerViewProcess>> getDetails() {
		// TODO Auto-generated method stub
		return null;
	}
		
	
	

}