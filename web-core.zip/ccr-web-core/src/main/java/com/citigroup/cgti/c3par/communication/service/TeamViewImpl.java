package com.citigroup.cgti.c3par.communication.service;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.internal.SessionImpl;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.TIActivityTrail;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueUsers;
import com.citigroup.cgti.c3par.communication.domain.TeamViewProcess;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.EmailGenerationViewServicePersistable;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.TeamViewPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

import oracle.jdbc.OracleTypes;
@Transactional
public class TeamViewImpl extends BasePersistanceImpl implements
		TeamViewPersistable {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	private EmailGenerationViewServicePersistable emailGenViewServicePersistable;

	public EmailGenerationViewServicePersistable getEmailGenViewServicePersistable() {
		return emailGenViewServicePersistable;
	}

	public void setEmailGenViewServicePersistable(
			EmailGenerationViewServicePersistable emailGenViewServicePersistable) {
		this.emailGenViewServicePersistable = emailGenViewServicePersistable;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public List<CMPRequest> getTeamViewCmpReqData(
			TeamViewProcess teamViewProcess) {

		Session session = getSession();
		C3parUser c3parUser = null;
		StringBuffer sectorlist = new StringBuffer(); 
		boolean assignedUserCr = false;
		String sortingColumnName =  teamViewProcess.getSortingColumnName();
		log.info("sortingColumnNameed..." + sortingColumnName);
		String orderBy = teamViewProcess.getOrderBy();
		Query query = session.createQuery(
				"from C3parUser where upper(ssoId) = ?").setString(0,
				teamViewProcess.getTeam().toUpperCase());

		List<C3parUser> list = (List<C3parUser>) query.list();
		if (list != null && list.size() > 0) {
			c3parUser = list.get(0);
			lazyInitialize(c3parUser.getEcmQueueUsersList());
		}
		List<String> sectorList = new ArrayList<String>();
		log.debug("c3parUser::getTeamViewCmpReqData::" + c3parUser);
		List<EcmQueueUsers> ecmQueueUsersList = c3parUser
				.getEcmQueueUsersList();
		if (ecmQueueUsersList != null && !ecmQueueUsersList.isEmpty()) {
			for (EcmQueueUsers ecmQueueUsers : ecmQueueUsersList) {
				if (ecmQueueUsers != null
						&& ecmQueueUsers.getEcmQueue().getQueueName() != null) {
					sectorList.add(ecmQueueUsers.getEcmQueue().getQueueName());
				}
			}
		}
		log.debug("sectorList::EcmQueueUsers::TeamView::" + sectorList);
		log.debug("sectorList.size():EcmQueueUsers::TeamView:: "
				+ sectorList.size());
		List<CMPRequest> rslvitMsg = null;
		try {
			session = getSession();
			Criteria cre = session.createCriteria(CMPRequest.class);
			//cre.add(Restrictions.in("ecmSector", sectorList));
			cre.add(Restrictions.isNotNull("assignedUser"));
			cre.add(Restrictions.eq("status", "In Progress"));
			
			log.debug("SectorFiler::EcmQueueUsers::TeamView::" +  teamViewProcess.getSectorFiler());
			log.debug("SectorList::EcmQueueUsers::TeamView::" +  teamViewProcess.getSectorList());
			
			if (teamViewProcess.getSectorFiler() != null 
					&& !teamViewProcess.getSectorFiler().isEmpty()) {				
				cre.add(Restrictions.eq("ecmSector", teamViewProcess.getSectorFiler()));
			}
			
			if (teamViewProcess.getLastNameFiler() != null 
					&& !teamViewProcess.getLastNameFiler().isEmpty()) {
				cre.createCriteria("assignedUser", "assignedUser"); 
				assignedUserCr = true;
				cre.add(Restrictions.eq("assignedUser.lastName", teamViewProcess.getLastNameFiler()));
			}
			

			teamViewProcess.setTotalRecords(cre.list().size());
			log.info("TeamViewProcess..." + teamViewProcess.getTotalRecords());
			if(sortingColumnName != "CURRENT STATUS"){
			addPagination(cre, teamViewProcess.getOffset(),
					teamViewProcess.getLimit());
			}
			log.debug("OrderBy passed: " + teamViewProcess.getOrderBy());
			log.debug("Column Name passed: "
					+ teamViewProcess.getSortingColumnName());

			if (teamViewProcess.getOrderBy() != null
					&& teamViewProcess.getSortingColumnName() != null) {

				if ("asc".equals(teamViewProcess.getOrderBy())) {

					if (teamViewProcess.getSortingColumnName() != null
							&& !teamViewProcess.getSortingColumnName()
									.isEmpty()
							&& teamViewProcess.getSortingColumnName().equals(
									"typeofConnectivityInvolved")) {
						cre.addOrder(Order.asc("typeofConnectivityInvolved"))
								.addOrder(Order.asc("requestType"));
						log.debug("inside asc TeamViewImpl:typeofConnectivityInvolved "
								+ teamViewProcess.getSortingColumnName());

					} else if (teamViewProcess.getSortingColumnName() != null
							&& !teamViewProcess.getSortingColumnName()
							.isEmpty()
							&& teamViewProcess.getSortingColumnName().equals(
									"LAST NAME")) {
						if (!assignedUserCr) {
							cre.createCriteria("assignedUser", "assignedUser");
						}
						cre.addOrder(Order.asc("assignedUser.lastName"));
						log.debug("inside asc TeamViewImpl:assignedUser.lastName ");

					} else {
						if(sortingColumnName != "CURRENT STATUS"){
						cre.addOrder(Order.asc(teamViewProcess
								.getSortingColumnName()));
						}
					}

				} else if ("desc".equals(teamViewProcess.getOrderBy())) {

					if (teamViewProcess.getSortingColumnName() != null
							&& !teamViewProcess.getSortingColumnName()
									.isEmpty()
							&& teamViewProcess.getSortingColumnName().equals(
									"typeofConnectivityInvolved")) {
						cre.addOrder(Order.desc("typeofConnectivityInvolved"))
								.addOrder(Order.desc("requestType"));
						log.debug("inside desc TeamViewImpl:typeofConnectivityInvolved "
								+ teamViewProcess.getSortingColumnName());
					} else if (teamViewProcess.getSortingColumnName() != null
							&& !teamViewProcess.getSortingColumnName()
							.isEmpty()
							&& teamViewProcess.getSortingColumnName().equals(
									"LAST NAME")) {
						if (!assignedUserCr) {
							cre.createCriteria("assignedUser", "assignedUser");
						}
						cre.addOrder(Order.desc("assignedUser.lastName"));
						log.debug("inside desc TeamViewImpl:assignedUser.lastName ");

					} else {
						if(sortingColumnName != "CURRENT STATUS"){
						cre.addOrder(Order.desc(teamViewProcess
								.getSortingColumnName()));
						}
					}

				}

			}
			rslvitMsg = (List<CMPRequest>) cre.list();
			for (CMPRequest cmp : rslvitMsg) {
				SQLQuery resolvtItquery = session
						.createSQLQuery("select Rt.Ti_Request_Id, cr.id,Cr.Order_Item_Id from Resolve_It_Notify_Log rt , Cmp_Request cr, Ti_Activity_Trail ta where Rt.Cmp_Request_Id = Cr.Id and Rt.Ti_Request_Id = Ta.Ti_Request_Id and cr.id ="
								+ cmp.getId());
				log.debug("Querying String::getCurrentCounts::"
						+ resolvtItquery);
				List<Object[]> resolveItobj = resolvtItquery.list();
				log.debug("is resolveItobj::getCmpReqData::"
						+ resolveItobj.size());
				
				StringBuilder sqlQuery = new StringBuilder("select * from (select * from TI_ACTIVITY_TRAIL where CMP_ID = " +cmp.getId());
				StringBuilder tiRequestId = new StringBuilder("");

				if (resolvtItquery.list().size() > 0) {
					cmp.setCheckTiId("Y");
					
					for(Object[] rs : resolveItobj){
						if(tiRequestId != null && tiRequestId.length() > 0){
							tiRequestId.append(", " +rs[0].toString());
						}
						else{
							tiRequestId.append(rs[0].toString());
						}					
					}
				}
				else {
					cmp.setCheckTiId("N");
				}
				
				if(tiRequestId != null && tiRequestId.length() > 0){
					sqlQuery.append(" union select * from TI_ACTIVITY_TRAIL where TI_REQUEST_ID in (" +tiRequestId.toString()+ ")");
				}
				sqlQuery.append(") TAT order by ID desc");
				log.debug("sqlQuery.toString()::"+ sqlQuery.toString());
				SQLQuery query1 = session.createSQLQuery(sqlQuery.toString());
				query1.addEntity("TAT", TIActivityTrail.class);
				cmp.setTiactivityTrail(query1.list());
				
				List<TIActivityTrail> tiActivityList = (List<TIActivityTrail>)query1.list(); 
				log.debug("scmp.getOrderItemId()::2"+cmp.getOrderItemId());
	            if(tiActivityList != null && !tiActivityList.isEmpty()){
	            	if(tiActivityList.get(0)!=null){
	            		log.debug("scmp.getOrderItemId():3:"+cmp.getOrderItemId());
	            		if(tiActivityList.get(0).getActivity()!=null){
	            			if(tiActivityList.get(0).getActivity().getTask()!=null){
	                    cmp.setCurrentStatus(tiActivityList.get(0).getActivity().getTask());
	            	}
	            		}
	            	}
	            }
	            log.debug("scmp.getOrderItemId()::"+cmp.getCurrentStatus());
	            
				lazyInitialize(cmp.getCmpRequestNotes());
				 log.debug("<<<<slazyInitialize>>>");
				if (cmp.getCcrId() != null && !cmp.getCcrId().isEmpty()) {
					if(cmp.getCcrId().indexOf(".") > 0){
						cmp.setCcrId(cmp.getCcrId().substring(0, cmp.getCcrId().indexOf(".")));
					}
					cmp.setChangeRequestDetails(emailGenViewServicePersistable
							.getChangeRequestDetails(Long.valueOf(cmp
									.getCcrId().trim()),cmp.getOrderId()));
				}
				CallableStatement callstm = null;
				try {
					int time = 0;
					String procedureCall = "{call CALCULATE_ACTIVITY_TIME(?,?,?)}";
					callstm = ((SessionImpl) getSession()).connection()
							.prepareCall(procedureCall);
					callstm.setLong(1, cmp.getId());
					callstm.setString(2, "ECM TIMER");
					callstm.registerOutParameter(3, OracleTypes.BIGINT);
					callstm.executeUpdate();
					time = callstm.getBigDecimal(3).intValue();
					cmp.setEcmTimer(Long.valueOf(time));
				} catch (SQLException ex) {
					log.error(ex.getMessage());
				}
			}
			log.debug("sortingColumnName::::"+sortingColumnName);
			if (sortingColumnName.equals("CURRENT STATUS") && rslvitMsg.size() > 0) {
				log.debug("sortingColumnName:::"+sortingColumnName);
				if ("desc".equals(orderBy)) {
	            Collections.sort(rslvitMsg, new Comparator<CMPRequest>() {
	    public int compare(final CMPRequest cmp1, final CMPRequest cmp2) {
	    	if(cmp2.getCurrentStatus() !=null && cmp1.getCurrentStatus() != null){
	        return cmp1.getCurrentStatus().compareTo(cmp2.getCurrentStatus());
	    	}else
	    	return 0;
	    }
	   } );
	   
	    }else{
	    	Collections.sort(rslvitMsg, new Comparator<CMPRequest>() {
	    	    public int compare(final CMPRequest cmp1, final CMPRequest cmp2) {
	    	    	if(cmp2.getCurrentStatus() !=null && cmp1.getCurrentStatus() != null){
	    	        return cmp2.getCurrentStatus().compareTo(cmp1.getCurrentStatus());
	    	    	}else
	    	    	return 0;
	    	    }
	    	   } );
	    	
	    }
				if (rslvitMsg != null)
					log.debug("team view :: getCmpData :: size ::" + rslvitMsg.size()+"and total records-->"+ teamViewProcess.getTotalRecords());	
				
				List<CMPRequest> tempCmpList = new ArrayList<CMPRequest>();
				int count = 0;
				for(CMPRequest tempRequest: rslvitMsg) {
					
					if( teamViewProcess.getOffset() <= count &&  (teamViewProcess.getOffset() + teamViewProcess.getLimit()) >= count ) {
						log.debug("The Value of i..>" + count);
						tempCmpList.add(tempRequest);
					}
					count++;
				}
				
				if (tempCmpList.size() > 1) {
					log.debug("NEW CMP List Size team view..>" + tempCmpList.size());
					rslvitMsg = tempCmpList;
				}
			}

			log.debug("CMPRequest::getTeamViewCmpReqData::" + rslvitMsg.size());
			if (rslvitMsg != null)
				log.debug("TeamViewImpl :: getCmpData :: size ::"
						+ rslvitMsg.size() + teamViewProcess.getTotalRecords());
		} catch (Exception e) {
			log.error("EcmLeadViewImpl::selectLeadDetail>>> " + e);
		}

		return rslvitMsg;
	}
	
	
	public List<String> getAssignedLastNameList() {
		Session session = getSession();
		SQLQuery sqlQuery = session.createSQLQuery("select distinct usr.last_name from c3par_users usr, cmp_request cmp "+
        " where cmp.assigned_user = usr.id and cmp.assigned_user is not null and status = 'In Progress' order by usr.last_name ");
		sqlQuery.addScalar("last_name", StringType.INSTANCE);
		return sqlQuery.list();
	}
	
	public List<String> getSectorList() {
		Session session = getSession();
		SQLQuery sqlQuery = session.createSQLQuery("select distinct ECM_SECTOR from CMP_REQUEST where ECM_SECTOR is not null");
		sqlQuery.addScalar("ecm_sector", StringType.INSTANCE);
		return sqlQuery.list();
	}
	

}
