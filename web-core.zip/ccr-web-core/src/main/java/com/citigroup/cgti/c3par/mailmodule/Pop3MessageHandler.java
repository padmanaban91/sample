package com.citigroup.cgti.c3par.mailmodule;

import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;
import org.springframework.messaging.*;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.citigroup.cgti.c3par.mailmodule.action.AbstractActionFactory;
import com.citigroup.cgti.c3par.mailmodule.action.MailAction;

public class Pop3MessageHandler implements MessageHandler{
	
		Logger log = Logger.getLogger(Pop3MessageHandler.class);

	    IncomingMessage incomingMessage;
	    
	    private AbstractActionFactory factory;
	    
	    private JavaMailSenderImpl mailSender;
	    
	    private String forwardAddress;
	    
		/**
		 * @return the factory
		 */
		public AbstractActionFactory getFactory() {
			return factory;
		}

		/**
		 * @param factory the factory to set
		 */
		public void setFactory(AbstractActionFactory factory) {
			this.factory = factory;
		}
		
		public JavaMailSenderImpl getMailSender() {
			return mailSender;
		}

		public void setMailSender(JavaMailSenderImpl mailSender) {
			this.mailSender = mailSender;
		}

		public String getForwardAddress() {
			return forwardAddress;
		}

		public void setForwardAddress(String forwardAddress) {
			this.forwardAddress = forwardAddress;
		}

		@Override
		public void handleMessage(Message<?> message) throws MessagingException {
			
			MimeMessage mimeMsg = (MimeMessage) message.getPayload();
			try {
				log.debug("mimeMsg  -->"+mimeMsg);
				incomingMessage = new IncomingMessage(mimeMsg);				
				
				log.debug("Subject: " + mimeMsg.getSubject());
				log.debug("Content: " + mimeMsg.getContent().toString());
				
				MailAction action = factory.getBeanFactory().getBean(incomingMessage.getEntity()+incomingMessage.getAction(), MailAction.class);
				
				Long mailID = action.saveMail(incomingMessage.getReferenceNo(),incomingMessage.getSsoId()
									,incomingMessage.getRawMessage().getSubject(),incomingMessage.getBody());
				incomingMessage.setMailID(mailID);
		
				log.debug("Reference no :" +incomingMessage.getReferenceNo());
				log.debug("SSO ID :"+incomingMessage.getSsoId());
				log.debug("Subject from msg :" +incomingMessage.getRawMessage().getSubject());
				log.debug("Mail Body :" +incomingMessage.getBody());
						
				action.process(incomingMessage);
			
			} catch (Exception e) {
				log.error(e,e);
				forwardMessage(mimeMsg);
			} 	
		}
		
		private void forwardMessage(MimeMessage mimeMsg)  {
			log.info("forwarding the mail");
			MimeBodyPart mimeBodyPart = new MimeBodyPart();
			try {
				mimeBodyPart.setContent(mimeMsg, "message/rfc822");
			
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(mimeBodyPart);
			
			MimeMessage forward = mailSender.createMimeMessage();
			forward.setContent(multipart);
			forward.setSubject("CCR PRODUCTION EXCEPTION EMAIL");
			
			InternetAddress from = new InternetAddress("dl.is.global.ccr@imcnam.ssmb.com");
			forward.setFrom(from);
			String[] emailIds = forwardAddress.split("\\;");
			InternetAddress[] toAddresses = new InternetAddress[emailIds.length];
			for (int i = 0; i< emailIds.length; i++) {
				toAddresses[i] = new InternetAddress(emailIds[i]);
			}
			forward.setRecipients(javax.mail.Message.RecipientType.TO, toAddresses);
			mailSender.send(forward);
			} catch (javax.mail.MessagingException e) {
				log.error(e,e);
			}
			
		}
}
