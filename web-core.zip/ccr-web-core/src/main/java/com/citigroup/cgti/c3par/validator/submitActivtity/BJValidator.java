package com.citigroup.cgti.c3par.validator.submitActivtity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;

import com.citigroup.cgti.c3par.comments.domain.SubmitActivityErrors;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.RelationshipProcess;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.webtier.helper.UserEntitlementHelper;
import com.citigroup.cgti.c3par.webtier.helper.Util;

/*
 * @nc43495
 */
public class BJValidator implements Validator{
	
	/** The log. */
    private static Logger log = Logger.getLogger(BJValidator.class);
    
    private JdbcTemplate jdbcTemplate;
   
    /** The manage proxy flag. */
    private boolean manageProxyFlag = false;

    /** The manage network flag. */
    private boolean manageNetworkFlag = false;
    
    /** The IP registration flag. */
    private boolean ipRegFlag = false;

    /** The appsense policy flag. */
    private boolean appsensePolicyFlag = false;

    /** The appsense user flag. */
    private boolean appsenseUserFlag = false;

    /** The acl variance flag. */
    private boolean aclVarianceFlag = false;
    
    /** The termination request type  flag. */
    private boolean termReqTypeFlag = false;
    
	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub
		
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
    
	public List<ObjectError> getBusinessJustificationMessage(Long tiReqId){
		log.info("BJValidator starts here:getBusinessJustificationMessage");
		List<ObjectError> techList=new ArrayList<ObjectError>();
		try{
		    Util util= new Util();
		    Long conReqId=Long.valueOf(util.getPlanningIdForTiRequestId(tiReqId));
		    Long conReqId_original=getConnectionRequestId(tiReqId);
		    log.debug("TI_REQUEST_ID::::"+tiReqId+":::::CON_REQ_ID:::::"+conReqId+"::original req id::"+conReqId_original);

		    
		    
		    //Define Business Case
		    List<ObjectError> relationshipMsg=getRelationshipMessage(conReqId,tiReqId);
		    techList.addAll(relationshipMsg);
		    
		    List<ObjectError> businessCaseMsg=getBusinessCaseMessage(conReqId,tiReqId);
		    techList.addAll(businessCaseMsg);
		    
		    //Citi Contacts
		    List<ObjectError> targetContactsMsg=getCitiContactsMessage(tiReqId,conReqId);
		    techList.addAll(targetContactsMsg);

		    List<ObjectError> targetContactsNotifyMsg=getCitiContactsNotifyMessage(tiReqId,conReqId);
		    techList.addAll(targetContactsNotifyMsg);

		    //Citi Contacts for employee type for requester. If not and employee mandate Project Coordinator
		    List<ObjectError> targetContactsMsg_EMP=getIPContactsMessage_ReqEMP(tiReqId,conReqId_original);
		    techList.addAll(targetContactsMsg_EMP);

		    //Citi Contacts for employee type FOR ISO and DesingEngineer/Technical Coordinator
		    if(targetContactsMsg.size()==0){
			List<ObjectError> targetContactsMsg_EMP_MGR=getCitiContactsMessage_EMP(tiReqId,conReqId);
			 techList.addAll(targetContactsMsg_EMP_MGR);
		    }

		    List<ObjectError> emerBuscritQuestionsMessageList = getEmerBusQuestMessage(tiReqId/*,conReqId_original*/);
		    techList.addAll(emerBuscritQuestionsMessageList);

		    //Relationship Certification Confirmation
		    List<ObjectError> certifyErrorMsg=getCertifyErrorMsg(tiReqId);
		    techList.addAll(certifyErrorMsg);

		    //Connection Basic Info
		    List<ObjectError> conBasicInfoMsg=getConBasicInfoMessage(conReqId, tiReqId);
		    techList.addAll(conBasicInfoMsg);
		    
		    //Data Bulk upload
		    List<ObjectError> dataBulkRequestMsg=getDataInfoBulkRequestMessage(tiReqId,conReqId);
		    techList.addAll(dataBulkRequestMsg);

		    //DOCUMENT UPLOAD
		    List<ObjectError> documentUploadMsg=getDocumentUploadMessage(tiReqId);
		    techList.addAll(documentUploadMsg);

		    //Director Role for EMER-BUSCRIT
		    List<ObjectError> directorRoleEmpMsg = getDirectorEmpMsg(conReqId,tiReqId);
		    techList.addAll(directorRoleEmpMsg);
		    
		    //Check user entitlement available for all requester or target contacts.
		    List<ObjectError> userEntitlementMsg = getUserEntitlementMessage(tiReqId,conReqId);
		    techList.addAll(userEntitlementMsg);   
		    
		    //Check whether ISO Contacts are available in ISO Contacts List.
		    List<ObjectError> isoContactsMsg = getISOContactListCheckMessage(tiReqId,conReqId);
		    techList.addAll(isoContactsMsg);
		    
		    //Technical Notification document validation
		    List<ObjectError> docMessage=getUturnValidation(tiReqId);
		    if(docMessage.size()>0){
			for(int i=0;i<docMessage.size();i++){	
			    techList.addAll(docMessage);
			}
		    }
		   
		}catch(Exception ex){
		    ex.printStackTrace();
		}

		log.info("BJValidator ends here:getBusinessJustificationMessage"+techList.size());
		return techList;
	    }
		
	 /**
     * Gets the technial architecture message.
     *
     * @param tiReqId the ti req id
     * @return the technial architecture message
     * @returns all the messages for Technial Architecture
     */
    public List<ObjectError> getTechnialArchitectureMessage(Long tiReqId) {
    	
    log.info("BJValidator starts here:getTechnialArchitectureMessage");
	List<ObjectError> techList = new ArrayList<ObjectError>();
	try {
	    Long conReqId = getConnectionRequestId(tiReqId);
	    log.debug("TI_REQUEST_ID::::" + tiReqId + ":::::CON_REQ_ID:::::" + conReqId);

	    ObjectError completionCheck = completionCheck(conReqId, tiReqId);
	    if (!"".equals(completionCheck)) {
		techList.add(completionCheck);
	    }

	    String relationshipType = getRelationshipType(conReqId);
	    
	    if (manageNetworkFlag) {
	    	if(!termReqTypeFlag){
	    		ObjectError appCheck = ipDetailsCompleteCheck(tiReqId,"firewall");
		    	if (appCheck!=null &&!appCheck.equals("")) {
		    		
				    techList.add(appCheck);
		    	}
		    	
		    	if(!(relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)|| relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE) || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE))){
		    		ObjectError recTypeCheck = connectionResourceTypes(tiReqId, conReqId);
			    	if (recTypeCheck!=null && !recTypeCheck.equals("")) {
					    techList.add(recTypeCheck);
			    	}
		    	}
	    	}
	    	if(!termReqTypeFlag){ 
	    		ObjectError fwRlsTemplateGrpCheck = fwRulesCompleteCheck(tiReqId,"firewall");
		    	if (fwRlsTemplateGrpCheck!=null && !fwRlsTemplateGrpCheck.equals("")) {
				    techList.add(fwRlsTemplateGrpCheck);
		    	}
		    }
	    	
	    	ObjectError fafCheck = fafCompleteCheck(tiReqId, "firewall");
	    	if (fafCheck!=null && !fafCheck.equals("")) {
			    techList.add(fafCheck);
	    	}
	    	ObjectError rfcCheck = rfcCompleteCheck(tiReqId, "firewall");
	    	if (rfcCheck!=null && !rfcCheck.equals("")) {
			    techList.add(rfcCheck);
	    	}
	    	ObjectError ostiaErrMsg = ostiaCompleteCheckForTA(tiReqId, "firewall");
			if (ostiaErrMsg!=null && !ostiaErrMsg.equals("")) {			   
				techList.add(ostiaErrMsg);
			}
			
			ObjectError fwMigCheck = fwMigrationCheck(tiReqId);
	    	if (fwMigCheck!=null && !fwMigCheck.equals("")) {
			    techList.add(fwMigCheck);
	    	}
	    	
	    	ObjectError msg = deCommissionedAppCheck(tiReqId);
	    	if (msg!=null && !msg.equals("")) {
			    techList.add(msg);
	    	}
	    	
	    }
	    else{
	    	ObjectError fafCheck = fafCompleteCheck(tiReqId, "firewall");
	    	if (fafCheck!=null && !fafCheck.equals("")) {
			    techList.add(fafCheck);
	    	}
	    	ObjectError rfcCheck = rfcCompleteCheck(tiReqId, "firewall");
	    	if (rfcCheck!=null && !rfcCheck.equals("")) {
			    techList.add(rfcCheck);
	    	}
	    }
	    
	    if (ipRegFlag) {
	    	if(!termReqTypeFlag){
	    		ObjectError appCheck = ipDetailsCompleteCheck(tiReqId,"IpReg");
		    	if (appCheck!= null && !appCheck.equals("")) {
				    techList.add(appCheck);
		    	}
		    	
	    	}
	    	if(!termReqTypeFlag){ 
	    		ObjectError fwRlsTemplateGrpCheck = fwRulesCompleteCheck(tiReqId,"IpReg");
		    	if (fwRlsTemplateGrpCheck!=null && !fwRlsTemplateGrpCheck.equals("")) {
				    techList.add(fwRlsTemplateGrpCheck);
		    	}
		    }
	    	
	    	ObjectError fafCheck = fafCompleteCheck(tiReqId, "IpReg");
	    	if (fafCheck!=null && !fafCheck.equals("")) {
			    techList.add(fafCheck);
	    	}
	    	
	    	ObjectError rfcCheck = rfcCompleteCheck(tiReqId, "IpReg");
	    	if (rfcCheck!=null && !rfcCheck.equals("")) {
			    techList.add(rfcCheck);
	    	}
	    	
	    	ObjectError ostiaErrMsg = ostiaCompleteCheckForTA(tiReqId, "IpReg");
			if (ostiaErrMsg!=null && !ostiaErrMsg.equals("")) {			   
				techList.add(ostiaErrMsg);
			}
			
			ObjectError msg = deCommissionedAppCheck(tiReqId);
	    	if (msg!=null && !msg.equals("")) {
			    techList.add(msg);
	    	}
	    	
	    }
	    else{
	    	ObjectError fafCheck = fafCompleteCheck(tiReqId, "IpReg");
	    	if (fafCheck!=null && !fafCheck.equals("")) {
			    techList.add(fafCheck);
	    	}
	    	ObjectError rfcCheck = rfcCompleteCheck(tiReqId, "IpReg");
	    	if (rfcCheck!=null && !rfcCheck.equals("")) {
			    techList.add(rfcCheck);
	    	}
	    }
	    
	    /** Document(DetailedLevelDesignDocument) Upload Message **/
	    List<ObjectError> docMessage = getDocumentUploadMessageTA(tiReqId);
	    if (docMessage.size() > 0) {
			for (int i = 0; i < docMessage.size(); i++) {
			    techList.addAll(docMessage);
			}
	    }
	 	
	    //** Document(Business Requirement Spreadsheet) Upload Message **/
	    List<ObjectError> docSpreadsheetMessage = getDocumentUploadMessageSpreadsheet(tiReqId);
	    if (docSpreadsheetMessage.size() > 0) {
			for (int i = 0; i < docSpreadsheetMessage.size(); i++) {
			    techList.addAll(docSpreadsheetMessage);
			}
	    }
	    
	    /** Relationship Certification Confirmation **/
	    /*List<ObjectError> certifyCnfMsg = getCertifyConfMsg(tiReqId);
	    if (certifyCnfMsg.size() > 0) {
			for (int i = 0; i < certifyCnfMsg.size(); i++) {
			    techList.addAll(certifyCnfMsg);
			}
	    }*/

	    if (appsensePolicyFlag) {
		    ObjectError appsensePolicyTabMessage = getAppsensePolicyTabMessage(conReqId);
			if (appsensePolicyTabMessage!=null && !"".equals(appsensePolicyTabMessage)) {
			    techList.add(appsensePolicyTabMessage);
			}
			
			ObjectError appsenseUserTabMessage = getAppsenseUserTabMessage(conReqId);
			if (appsenseUserTabMessage!=null && !"".equals(appsenseUserTabMessage)) {
			    techList.add(appsenseUserTabMessage);
			}
			ObjectError appsenseOstiaTabMessage = getAppsenseOstiaTabMessage(conReqId);
			if (appsenseOstiaTabMessage!=null && !"".equals(appsenseOstiaTabMessage)) {
			    techList.add(appsenseOstiaTabMessage);
			}
	    }
	    if (manageProxyFlag) {
		    ObjectError manageProxyFilterMessage = getManageProxyFilterMessage(conReqId);
			if (manageProxyFilterMessage!=null) {
			    techList.add(manageProxyFilterMessage);
			}
			
			ObjectError manageProxySocksMessage = getManageProxySocksMessage(conReqId);
			if (manageProxySocksMessage!=null) {
			    techList.add(manageProxySocksMessage);
			}
			
			ObjectError manageProxyPlugMessage = getManageProxyPlugMessage(conReqId);
			if (manageProxyPlugMessage!=null) {
			    techList.add(manageProxyPlugMessage);
			}
			
			ObjectError manageProxyRFCMessage = getManageProxyRFCMessage(tiReqId);
			if (manageProxyRFCMessage != null) {
			    techList.add(manageProxyRFCMessage);
			}
			// Added for the task 9533
			List<ObjectError> docSockMessage = getDocumentProxyUploadMessage(conReqId, tiReqId);
			if (docSockMessage.size() > 0) {
			    for (int i = 0; i < docSockMessage.size(); i++) {
				techList.addAll(docSockMessage);
			    }
			}
	    }

	    if(aclVarianceFlag)
	    {
				List<ObjectError> docACLChangeMessage = getDocumentACLChangesUploadMessage(
						conReqId, tiReqId);
				if (docACLChangeMessage.size() > 0) {
					for (int i = 0; i < docACLChangeMessage.size(); i++) {
						techList.addAll(docACLChangeMessage);
					}

				}

			}


	    // Get Request Type
	    String reqType = getRequest_Type(conReqId);
	    log.debug("reqType::" + reqType);



	  //DOCUMENT UPLOAD
	    List<ObjectError> documentUploadMsg=getDirApprovalDocUploadMessage(tiReqId);
	    if(documentUploadMsg.size()>0){
		for(int i=0;i<documentUploadMsg.size();i++){
		    techList.addAll(documentUploadMsg);
		}
	    }

	   /* // Director Role for EMER-BUSCRIT
	    List<ObjectError> directorRoleEmpMsg = getDirectorEmpMsgTA(conReqId, tiReqId);
	    if (directorRoleEmpMsg.size() > 0) {
		for (int i = 0; i < directorRoleEmpMsg.size(); i++) {
		    techList.addAll(directorRoleEmpMsg);
		}
	    }*/

	} catch (Exception ex) { 
	    ex.printStackTrace();
	}
	 log.info("BJValidator ends here:getTechnialArchitectureMessage"+techList.size());
	return techList;
    }

  
	
		 /**
	     * Gets the connection request id.
	     *
	     * @param tiReqId the ti req id
	     * @return connection request Id
	     * @throws Exception the exception
	     */
	    private Long getConnectionRequestId(Long tiReqId)throws Exception{
		String process_id=null;
		Long conReqId=Long.valueOf(0);
		
		try {
			
		    String sql="SELECT PROCESS_ID FROM C3PAR.TI_REQUEST WHERE ID="+tiReqId;
		    SqlRowSet result  = jdbcTemplate.queryForRowSet(sql);
		    
		    if(result!=null && result.next()){
			process_id=result.getString(1);
			conReqId=Long.valueOf(process_id);
		    }
		    log.debug("Process_id is::"+process_id+"for ti_request Id::"+tiReqId);
		}catch (Exception e) {
		    log.error(e,e);
		}
		return conReqId;
	    }
	    
	    private List<ObjectError> getRelationshipMessage(Long conReqId, Long tiReqId) throws Exception{
	    	List<ObjectError> messageList = new ArrayList<ObjectError>();
	    	try{
	    		RelationshipProcess relationshipProcess = new RelationshipProcess();
	    		TIProcess tiProcess=relationshipProcess.getConnectionDetails(conReqId);
	    		if(tiProcess!=null){
	    			Relationship relationship=tiProcess.getRelationshipId();
	    			if (relationship != null) {
	    				if (C3parStaticNames.CITI_IP.equalsIgnoreCase(relationship.getRelationshipType())
	    						|| C3parStaticNames.IP_TEMPLATE
	    								.equalsIgnoreCase(relationship.getRelationshipType())
	    						|| C3parStaticNames.TEMPLATE_OBJ
	    								.equalsIgnoreCase(relationship.getRelationshipType())
	    						|| C3parStaticNames.CITI_CON
	    								.equalsIgnoreCase(relationship.getRelationshipType())) {
	    					if (relationship.getRequesterResourceType() == null
	    							|| relationship.getRequesterResourceType().getId() == null
	    							|| relationship.getRequesterResourceType().getId().longValue() == 0) {
	    						messageList.add(new ObjectError("REQUESTER",new String[]{SubmitActivityErrors.REL_RESOURCE_A},null,null));	
	    					}
	    					if(!relationshipProcess.isValidateThridPartyConts(relationship.getId(), relationship.getRelationshipType(), null,null))
	    						messageList.add(new ObjectError("REQUESTER_LOC",new String[]{SubmitActivityErrors.REL_THIRDPARTY_LOCS},null,null));	
	    				}
	    				
	    				if (C3parStaticNames.THIRD_PARTY
	    								.equalsIgnoreCase(relationship.getRelationshipType())) {
	    					if (relationship.getTargetResourceType() == null
	    									|| relationship.getTargetResourceType().getId() == null
	    									|| relationship.getTargetResourceType().getId()
	    											.longValue() == 0) {
	    						
	    						messageList.add(new ObjectError("TARGET",new String[]{SubmitActivityErrors.REL_RESOURCE_B},null,null));	
	    					}
	    					if(CollectionUtils.isEmpty(relationship.getRelThirdPartyContXref())){
	    						messageList.add(new ObjectError("REL_THIRDPARTY_CONTS",new String[]{SubmitActivityErrors.REL_THIRDPARTY_CONTS},null,null));	
	    					}
	    				}
	    				
	    			}
	    			if ((relationship.getRelationshipType() != null) && (C3parStaticNames.THIRD_PARTY
	    					.equalsIgnoreCase(relationship.getRelationshipType())
	    					|| C3parStaticNames.U_TURN
	    							.equalsIgnoreCase(relationship.getRelationshipType()))) {
	    				if (relationship.getThirdParty()== null || relationship.getThirdParty().getId()==null) {
	    					messageList.add(new ObjectError("THIRDPARTY_A",new String[]{SubmitActivityErrors.REL_THIRDPARTY_A},null,null));	
	    				}
	    				if (C3parStaticNames.U_TURN
	    						.equalsIgnoreCase(relationship.getRelationshipType())) {
	    					if (relationship.getUturnThirdParty()== null || relationship.getUturnThirdParty().getId()== 0) {
	    						messageList.add(new ObjectError("UTURN",new String[]{SubmitActivityErrors.REL_UTURN_THIRDPARTY},null,null));	
	    					}
	    				}
	    				if(!relationshipProcess.isValidateThridPartyConts(relationship.getId(), relationship.getRelationshipType(), relationship.getThirdParty().getId(), relationship.getUturnThirdParty().getId()))
	    					messageList.add(new ObjectError("REQUEST_LOC_CONS",new String[]{SubmitActivityErrors.REL_THIRDPARTY_LOCS_CONTS},null,null));	
	    			}
	    			
	    			if(relationship!=null &&  CollectionUtils.isEmpty(relationship.getRelcitiHierarchyXrefs())){
	    				messageList.add(new ObjectError("REL_BUSINESS_UNIT",new String[]{SubmitActivityErrors.REL_BUSINESS_UNIT},null,null));
	    			}
	    			if ((relationship.getRelationshipType() != null)
	    					&& C3parStaticNames.U_TURN.equalsIgnoreCase(relationship.getRelationshipType())) {
	    				
	    				if(relationship.getThirdParty()==null || relationship.getUturnThirdParty()==null ){
	    					messageList.add(new ObjectError("UTURN",new String[]{SubmitActivityErrors.REL_UTURN_THIRDPARTY},null,null));
	    				}
	    				
	    			}
	    			
	    			if ((relationship.getRelationshipType() != null) && C3parStaticNames.U_TURN
	    					.equalsIgnoreCase(relationship.getRelationshipType())) {
	    				if ((relationship.getThirdParty().getCaspId() != null
	    						&& relationship.getUturnThirdParty().getCaspId() != null
	    						&& relationship.getThirdParty().getCaspId()
	    								.longValue() == relationship.getUturnThirdParty().getCaspId()
	    										.longValue())
	    						&& (relationship.getThirdParty().getDetailId() != null
	    								&& relationship.getUturnThirdParty().getDetailId() != null
	    								&& relationship.getThirdParty().getDetailId()
	    										.longValue() == relationship.getUturnThirdParty()
	    												.getDetailId().longValue())
	    						&& (relationship.getThirdParty().getParentId() != null
	    								&& relationship.getUturnThirdParty().getParentId() != null
	    								&& relationship.getThirdParty().getParentId()
	    										.longValue() == relationship.getUturnThirdParty()
	    												.getParentId().longValue())) {
	    					messageList.add(new ObjectError("TARGET_THIRD",new String[]{SubmitActivityErrors.REL_REQ_TARGET_THIRD},null,null));
	    				}
	    			}
	    		}
	    		
	    	}catch(Exception e){
	    		log.error("Error has occurred in getRelationshipMessage method :: "+e.toString());
	    	}
	    	return messageList;
	    }
	    
	    
	    
	    /**
	     * Gets the business case message.
	     *
	     * @param conReqId the con req id
	     * @return the business case message
	     * @throws Exception the exception
	     * @returns Business Case messages
	     */
	    private List<ObjectError> getBusinessCaseMessage(Long conReqId, Long tiReqId)throws Exception{
		String detailedInformation="";;
		StringBuffer buCaseSQL=new StringBuffer();
		StringBuffer dataSQL=new StringBuffer();
		StringBuffer reasonSQL=new StringBuffer();
		List<ObjectError> messageList = new ArrayList<ObjectError>();
		SqlRowSet result = null;
		String relationshipType=getRelationshipType(conReqId);
		try {
				
		    buCaseSQL.append(" select  cr.RATIONALE,cr.BENEFIT,cr.PLCODE,cr.connectivity_estimate CONN_ESTIMATE,  crf.FACILITIES_AFFECTED_ID, cr.SEMI_ANNUAL_ENTITL_REVIEW,cr.CONN_FOR_CUST_CLIENT,cr.CITI_POLICY_ADHERENCE,cr.TP_TRAINING_AWARNESS_PRG,cr.DIRECT_ACCESSBY_THIRDPRT,cr.EXPORT_LICENSE_CORDINATOR_NEW,cr.DETAILED_INFORMATION from c3par.CON_REQ_FAC_AFF_XREF crf, c3par.con_req cr");
		    buCaseSQL.append(" where cr.id = crf.request_id (+) and cr.id = "+conReqId+" and rownum=1"); 
		    
		     result  = jdbcTemplate.queryForRowSet(buCaseSQL.toString());
		    
		    log.debug("buCaseSQL.toString()>>>>>>>>>>"+buCaseSQL.toString());

		    if(result!=null && result.next()){
			if(result.getString("RATIONALE")==null||"".equals(result.getString("RATIONALE"))){
			    messageList.add(new ObjectError("RATIONALE",new String[]{SubmitActivityErrors.BJ_RATIONALE},null,null));
			    log.debug("Business Case message is::"+messageList.size());
			}
			if(result.getString("PLCODE")==null||"".equals(result.getString("PLCODE"))){
			    messageList.add(new ObjectError("PLCODE",new String[]{SubmitActivityErrors.BJ_PLCODE},null,null));
			}
			if(result.getString("CONN_ESTIMATE")==null||"".equals(result.getString("CONN_ESTIMATE"))){
			    messageList.add(new ObjectError("CONN_ESTIMATE",new String[]{SubmitActivityErrors.BJ_CONN_ESTIMATE},null,null));
			} 
			    
			if(result.getString("DETAILED_INFORMATION")==null||"".equals(result.getString("DETAILED_INFORMATION"))){
			  detailedInformation = result.getString("DETAILED_INFORMATION");
			}
			
			if(relationshipType.equalsIgnoreCase("U_TURN")){
				
				if(result.getString("EXPORT_LICENSE_CORDINATOR_NEW")== null || "".equals(result.getString("EXPORT_LICENSE_CORDINATOR_NEW"))
						||((result.getString("EXPORT_LICENSE_CORDINATOR_NEW")!= null) && (!"Y".equalsIgnoreCase(result.getString("EXPORT_LICENSE_CORDINATOR_NEW"))&&
								!"N".equalsIgnoreCase(result.getString("EXPORT_LICENSE_CORDINATOR_NEW"))))){
					 messageList.add(new ObjectError("EXPORT_LICENSE_CORDINATOR_NEW",new String[]{SubmitActivityErrors.BJ_EXPORT_LICENSE_CORDINATOR_NEW},null,null));
				   
				}
				
			}
			
			
			if(relationshipType.equalsIgnoreCase("THIRD_PARTY")){
				
					if(result.getString("CONN_FOR_CUST_CLIENT") == null ||"".equals(result.getString("CONN_FOR_CUST_CLIENT"))
							||((result.getString("CONN_FOR_CUST_CLIENT")!= null) && (!"Y".equalsIgnoreCase(result.getString("CONN_FOR_CUST_CLIENT"))&&
									!"N".equalsIgnoreCase(result.getString("CONN_FOR_CUST_CLIENT"))))){
						 messageList.add(new ObjectError("CONN_FOR_CUST_CLIENT",new String[]{SubmitActivityErrors.BJ_CONN_FOR_CUST_CLIENT},null,null));
					}
				
					if(result.getString("DIRECT_ACCESSBY_THIRDPRT") == null ||"".equals(result.getString("DIRECT_ACCESSBY_THIRDPRT"))){
						messageList.add(new ObjectError("DIRECT_ACCESSBY_THIRDPRT",new String[]{SubmitActivityErrors.BJ_DIRECT_ACCESSBY_THIRDPRT},null,null));
					}else if(result.getString("DIRECT_ACCESSBY_THIRDPRT").trim().equalsIgnoreCase("Y")){
						reasonSQL.append("SELECT ID FROM VIRTUAL_CONN_REASON WHERE CON_REQ_ID = "+conReqId);
						result = null;
						result  = jdbcTemplate.queryForRowSet(reasonSQL.toString());
						 if(result!=null && !result.next()){
							 messageList.add(new ObjectError("VIRTUAL_CONN_REASON",new String[]{SubmitActivityErrors.BJ_VIRTUAL_CONN_REASON},null,null));
						 }
					}
			}
			
		    }
		    log.debug("messageList Size::"+messageList.size());
		   
		    dataSQL.append(" select b.CUSTOMER_DATA_ID,b.CITIGROUP_DATA_ID from con_req a,CO_LOOKUP_DATA b where a.ID=");
			dataSQL.append(conReqId+" and a.LOOKUP_ID=b.ID");
			result  = jdbcTemplate.queryForRowSet(dataSQL.toString());

			if(result!=null && result.next()){
				if(result.getString("CUSTOMER_DATA_ID")== null || "".equals(result.getString("CUSTOMER_DATA_ID"))){
					messageList.add(new ObjectError("CUSTOMER_DATA",new String[]{SubmitActivityErrors.BJ_CUSTOMER_DATA},null,null));
				    }
				    if(result.getString("CITIGROUP_DATA_ID")== null || "".equals(result.getString("CITIGROUP_DATA_ID"))){
				    messageList.add(new ObjectError("CITIGROUP_DATA",new String[]{SubmitActivityErrors.BJ_CITIGROUP_DATA},null,null));
				    
				}
			}
			log.debug("messageList Size::"+messageList.size());

			result = null;
			dataSQL=new StringBuffer();
		    dataSQL.append(" select CMP_ID, SERVICE_NOW_ID from ti_request where id = "+tiReqId);
			
		    result = jdbcTemplate.queryForRowSet(dataSQL.toString());
			String cmpID = "", serviceNowID = "";
			if(result!=null && result.next()){
				cmpID = result.getString("CMP_ID");
				serviceNowID = result.getString("SERVICE_NOW_ID");
			}
			
			if((cmpID == null || cmpID.trim().length() <= 0 ) && (serviceNowID == null || serviceNowID.trim().length() <= 0 )){
				 messageList.add(new ObjectError("CMPID_SERVICENOWID",new String[]{SubmitActivityErrors.BJ_CMPID_SERVICENOWID},null,null));
			}
		 
			if((cmpID!=null) && (detailedInformation==null)){
				 messageList.add(new ObjectError("DETAILED_INFORMATION",new String[]{SubmitActivityErrors.BJ_DETAILED_INFORMATION},null,null));
			}
			
		}catch (Exception e) {
		    log.error(e);
		}
		
		return messageList;
	    }
	    
	    

	    /**
	     * Gets the citi contacts message.
	     *
	     * @param conReqId the con req id
	     * @param connData the conn data
	     * @return the citi contacts message
	     * @throws Exception the exception
	     * @returns Target Contacts Messages.
	     */
	    private List<ObjectError> getCitiContactsMessage(Long tiReqId,Long conReqId)throws Exception{
		StringBuffer tContactsSQL=new StringBuffer();
		StringBuffer rContactsSQL=new StringBuffer();
		
		StringBuffer tContactsSQLRequestor=new StringBuffer();
		StringBuffer tContactsSQLBusinessOwner=new StringBuffer();
		StringBuffer tContactsSQLBusinessTester=new StringBuffer();
		StringBuffer rContactsSQLRequestor=new StringBuffer();
		StringBuffer rContactsSQLBusinessOwner=new StringBuffer();
		StringBuffer rContactsSQLBusinessTester=new StringBuffer();
		SqlRowSet result = null;
		
		List<ObjectError> messageList = new ArrayList<ObjectError>();
		
		String relationshipType=getRelationshipType(conReqId);
		try {
		    tContactsSQL.append("select count(*)  from role where id in ( ");
		    tContactsSQL.append(" select role_id from con_req_citi_contact_xref where  citi_contact_id is not null  and REQUEST_ID = "+conReqId+" and UPPER(primary_contact) = 'Y' and (upper(is_reject) is null or upper(is_reject) = 'N')");
		    tContactsSQL.append(" ) and role.name in('BISO','DESIGN ENGINEER','PROJECT COORDINATOR')");
		    tContactsSQL.append(" having count(*)=3");
		    log.debug("Target Contacts SQL::"+tContactsSQL.toString());
		    rContactsSQL.append("select count(*)  from role where id in ( ");
		    rContactsSQL.append(" select role_id from CON_REQ_CIT_RQCON_XREF where  citi_contact_id is not null  and REQUEST_ID = "+conReqId+" and UPPER(primary_contact) = 'Y' and (upper(is_reject) is null or upper(is_reject) = 'N')");
		    rContactsSQL.append(" ) and role.name in('BISO','DESIGN ENGINEER','PROJECT COORDINATOR') ");
		    rContactsSQL.append(" having count(*)=3");
		    log.debug("Requester Contacts SQL::"+rContactsSQL.toString());

		    // Requestor
		    tContactsSQLRequestor.append("select count(*)  from role where id in ( ");
		    tContactsSQLRequestor.append(" select role_id from con_req_citi_contact_xref where  citi_contact_id is not null  and REQUEST_ID = "+conReqId+" and UPPER(primary_contact) = 'Y' and (upper(is_reject) is null or upper(is_reject) = 'N')");
		    tContactsSQLRequestor.append(" ) and role.name in('Requestor')");
		    tContactsSQLRequestor.append(" having count(*)=1");
		    log.debug("Target Contacts SQL::"+tContactsSQLRequestor.toString());
		    
		    rContactsSQLRequestor.append("select count(*)  from role where id in ( ");
		    rContactsSQLRequestor.append(" select role_id from CON_REQ_CIT_RQCON_XREF where  citi_contact_id is not null  and REQUEST_ID = "+conReqId+" and UPPER(primary_contact) = 'Y' and (upper(is_reject) is null or upper(is_reject) = 'N')");
		    rContactsSQLRequestor.append(" ) and role.name in('Requestor')");
		    rContactsSQLRequestor.append(" having count(*)=1");
		    log.debug("Requestor Contacts SQL::"+rContactsSQLRequestor.toString());
		    
		    //Business Owner
		    tContactsSQLBusinessOwner.append("select count(*)  from role where id in ( ");
		    tContactsSQLBusinessOwner.append(" select role_id from con_req_citi_contact_xref where  citi_contact_id is not null  and REQUEST_ID = "+conReqId+" and UPPER(primary_contact) = 'Y' and (upper(is_reject) is null or upper(is_reject) = 'N')");
		    tContactsSQLBusinessOwner.append(" ) and role.name in('Business_Owner')");
		    tContactsSQLBusinessOwner.append(" having count(*)=1");
		    log.debug("Target Contacts SQL::"+tContactsSQLBusinessOwner.toString());
		    
		    rContactsSQLBusinessOwner.append("select count(*)  from role where id in ( ");
		    rContactsSQLBusinessOwner.append(" select role_id from CON_REQ_CIT_RQCON_XREF where  citi_contact_id is not null  and REQUEST_ID = "+conReqId+" and UPPER(primary_contact) = 'Y' and (upper(is_reject) is null or upper(is_reject) = 'N')");
		    rContactsSQLBusinessOwner.append(" ) and role.name in('Business_Owner')");
		    rContactsSQLBusinessOwner.append(" having count(*)=1");
		    log.debug("Requestor Contacts SQL::"+rContactsSQLBusinessOwner.toString());
		    
		    //Business Tester
		    tContactsSQLBusinessTester.append("select count(*)  from role where id in ( ");
		    tContactsSQLBusinessTester.append(" select role_id from con_req_citi_contact_xref where  citi_contact_id is not null  and REQUEST_ID = "+conReqId+" and UPPER(primary_contact) = 'Y' and (upper(is_reject) is null or upper(is_reject) = 'N')");
		    tContactsSQLBusinessTester.append(" ) and role.name in('Business_Tester')");
		    tContactsSQLBusinessTester.append(" having count(*)=1");
		    log.debug("Target Contacts SQL::"+tContactsSQLBusinessTester.toString());
		    
		    rContactsSQLBusinessTester.append("select count(*)  from role where id in ( ");
		    rContactsSQLBusinessTester.append(" select role_id from CON_REQ_CIT_RQCON_XREF where  citi_contact_id is not null  and REQUEST_ID = "+conReqId+" and UPPER(primary_contact) = 'Y' and (upper(is_reject) is null or upper(is_reject) = 'N')");
		    rContactsSQLBusinessTester.append(" ) and role.name in('Business_Tester')");
		    rContactsSQLBusinessTester.append(" having count(*)=1");
		    log.debug("Target Contacts SQL::"+rContactsSQLBusinessTester.toString());
		    
		   
		    
		    // Third Party, Template, IP and Port Template
		    
		    if(relationshipType.equalsIgnoreCase("THIRD_PARTY") || relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)|| relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE) || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)){
		    	
		    	log.debug("Validating R,BO,BT::"+relationshipType);
		    	
		    	 result  = jdbcTemplate.queryForRowSet(tContactsSQLRequestor.toString());
				if(!result.next()){
					log.debug("Validating R:"+relationshipType);
				    messageList.add(new ObjectError("CONTACTS_Requestor",new String[]{SubmitActivityErrors.BJ_CONTACTS_Requestor},null,null));
				}	
				
				 result  = jdbcTemplate.queryForRowSet(tContactsSQLBusinessOwner.toString());
				if(!result.next()){
					log.debug("Validating BO:"+relationshipType);
				    messageList.add(new ObjectError("CONTACTS_BusinessOwner",new String[]{SubmitActivityErrors.BJ_CONTACTS_BusinessOwner},null,null));
				}	
				
				result  = jdbcTemplate.queryForRowSet(tContactsSQLBusinessTester.toString());
				if(!result.next()){
					log.debug("Validating BT:"+relationshipType);
					messageList.add(new ObjectError("CONTACTS_BusinessTester",new String[]{SubmitActivityErrors.BJ_CONTACTS_BusinessTester},null,null));
				}			
		    }
		    
		    //Non Third Party and U Turn
		    if(relationshipType.equalsIgnoreCase("CITI_CON") || relationshipType.equalsIgnoreCase("U_TURN") ){
		    	log.debug("Validating R,BO,BT::"+relationshipType);
				
		    	result  = jdbcTemplate.queryForRowSet(rContactsSQLRequestor.toString());
				if(!result.next()){
					log.debug("Validating R:"+relationshipType);
				    messageList.add(new ObjectError("CONTACTS_Requestor",new String[]{SubmitActivityErrors.BJ_CONTACTS_Requestor},null,null));
				}	
				result  = jdbcTemplate.queryForRowSet(rContactsSQLBusinessOwner.toString());
				if(!result.next()){
					log.debug("Validating BO:"+relationshipType);
				    messageList.add(new ObjectError("CONTACTS_BusinessOwner",new String[]{SubmitActivityErrors.BJ_CONTACTS_BusinessOwner},null,null));
				}		
				result  = jdbcTemplate.queryForRowSet(rContactsSQLBusinessTester.toString());
				if(!result.next()){
					log.debug("Validating BT:"+relationshipType);
				    messageList.add(new ObjectError("CONTACTS_BusinessTester",new String[]{SubmitActivityErrors.BJ_CONTACTS_BusinessTester},null,null));				}
		    }	    
		    // Third Party	    
		    if(relationshipType.equalsIgnoreCase("THIRD_PARTY")){
		    result  = jdbcTemplate.queryForRowSet(tContactsSQL.toString());
			if(!result.next()){
			    messageList.add(new ObjectError("CONTACTS",new String[]{SubmitActivityErrors.BJ_CONTACTS},null,null));
			}
		    }else if(relationshipType.equalsIgnoreCase("CITI_CON")){
		    result  = jdbcTemplate.queryForRowSet(rContactsSQL.toString());
			if(!result.next()){
			    messageList.add(new ObjectError("REQCONTACTS",new String[]{SubmitActivityErrors.BJ_REQCONTACTS},null,null));
			}
		    }else if(relationshipType.equalsIgnoreCase("U_TURN")){
		    result  = jdbcTemplate.queryForRowSet(rContactsSQL.toString());
			if(!result.next()){
			    messageList.add(new ObjectError("REQCONTACTS",new String[]{SubmitActivityErrors.BJ_REQCONTACTS},null,null));
			}
		    }

		    if(isBusinessOwnerPrimaries(tiReqId, relationshipType)){
		    	messageList.add(new ObjectError("CONTACTS",new String[]{SubmitActivityErrors.BJ_BUSSINESS_OWNER},null,null));
		    }
		    
		    log.debug("messageList Size::"+messageList.size());

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }

	    /**
	     * Gets the relationship type.
	     *
	     * @param conReqId the con req id
	     * @return the relationship type
	     * @throws Exception the exception
	     */
	    private String getRelationshipType(Long conReqId)throws Exception{
		String relationshipType=null;
		try {
			
		    String sql="SELECT B.RELATIONSHIP_TYPE FROM CON_REQ A,RELATIONSHIP B WHERE A.RELATIONSHIP_ID=B.ID AND A.ID="+conReqId;
		    SqlRowSet result  = jdbcTemplate.queryForRowSet(sql);
		    if(result!=null && result.next()){
			relationshipType=result.getString(1);

		    }
		    relationshipType=(relationshipType==null)?"":relationshipType.trim();
		    log.debug("relationshipType is::"+relationshipType+"for CON_REQ Id::"+conReqId);
		}catch (Exception e) {
		    log.error(e);
		}
		return relationshipType;
	    }

	    
	    /**
	     * Gets the citi contacts message.
	     *
	     * @param conReqId the con req id
	     * @param connData the conn data
	     * @return the citi contacts message
	     * @throws Exception the exception
	     * @returns Target Contacts Messages.
	     */
	    private List<ObjectError> getCitiContactsNotifyMessage(Long tiReqId,Long conReqId)throws Exception{
		StringBuffer tContactsSQL=new StringBuffer();
		StringBuffer rContactsSQL=new StringBuffer();
		List<ObjectError> messageList=new ArrayList<ObjectError>();
		String relationshipType=getRelationshipType(conReqId);
		SqlRowSet result  = null;
		try {
		    tContactsSQL.append(" select citi_contact_id from con_req_citi_contact_xref where  citi_contact_id is not null  and REQUEST_ID = "+conReqId+" and notify_contact = 'Y'");
		    log.debug("Target Contacts SQL::"+tContactsSQL.toString());
		    rContactsSQL.append(" select citi_contact_id from CON_REQ_CIT_RQCON_XREF where  citi_contact_id is not null  and REQUEST_ID = "+conReqId+" and notify_contact = 'Y'");
		    log.debug("Requester Contacts SQL::"+rContactsSQL.toString());
		   
		    
		    if(relationshipType.equalsIgnoreCase("THIRD_PARTY")){
			result  = jdbcTemplate.queryForRowSet(tContactsSQL.toString());
			if(!result.next()){
			    messageList.add(new ObjectError("NOTIFY_CITI_CONTACTS",new String[]{SubmitActivityErrors.BJ_NOTIFY_CITI_CONTACTS},null,null));
			}
		    }else if(relationshipType.equalsIgnoreCase("CITI_CON")){
		    result  = jdbcTemplate.queryForRowSet(rContactsSQL.toString());
			if(!result.next()){
				messageList.add(new ObjectError("NOTIFY_CITI_CONTACTS",new String[]{SubmitActivityErrors.BJ_NOTIFY_CITI_CONTACTS},null,null));
			}
		    }else if(relationshipType.equalsIgnoreCase("U_TURN")){
		    result  = jdbcTemplate.queryForRowSet(rContactsSQL.toString());
			if(!result.next()){
				messageList.add(new ObjectError("NOTIFY_CITI_CONTACTS",new String[]{SubmitActivityErrors.BJ_NOTIFY_CITI_CONTACTS},null,null));
			}
		    }

		    log.debug("messageList Size::"+messageList.size());

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }
	    
	    
	    /**
	     * Gets the iP contacts message_ req emp.
	     *
	     * @param processId the process id
	     * @param connId the conn id
	     * @return the iP contacts message_ req emp
	     * @throws Exception the exception
	     * @returns Citigroup Contacts Messages for Requestor Employee Type if not Manager as Employee is Mandatory.
	     */
	    private List<ObjectError> getIPContactsMessage_ReqEMP(Long processId,Long connId)throws Exception{
		StringBuffer citiContactsSQL=new StringBuffer();
		List<ObjectError> messageList = new ArrayList<ObjectError>();
		List<ObjectError> messageList_PC=new ArrayList<ObjectError>();
		List<ObjectError> messageList_PC_EMP=new ArrayList<ObjectError>();
		SqlRowSet result  = null;
		String str="";
		int count=0;
		String relationshipType=getRelationshipType(connId);
		String tabName=null;
	    Util util= new Util();
	    Long conReqId=Long.valueOf(util.getPlanningIdForTiRequestId(processId));
		String empType = "(select user_id from ti_request where process_id="+connId+" and version_number=(select max(version_number) from ti_Request where process_id="+connId+"))";
		if(relationshipType.equalsIgnoreCase("THIRD_PARTY") || relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)|| relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE) || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)){
		    tabName="con_req_citi_contact_xref";
		}else{
		    tabName="CON_REQ_CIT_RQCON_XREF";
		}
		try {
		    citiContactsSQL.append("select employee_type from c3par_users where id in"+empType);
		    
		    result  = jdbcTemplate.queryForRowSet(citiContactsSQL.toString());
		    log.debug("result is::"+citiContactsSQL.toString());
		    if(result.next() && count==0){
			str=(String)result.getString("employee_type");
			if(str==null || (str!=null && !(str.trim().equalsIgnoreCase("Employee") || str.trim().equalsIgnoreCase("E"))))
			{
			    messageList_PC=getIPContactsMessage_ReqEMP_PC(processId,tabName,conReqId);
			    log.debug("messageList_PC::"+messageList_PC);
			    if(messageList_PC!=null && messageList_PC.size()==0)
			    {
				messageList_PC_EMP=getIPContactsMessage_ReqEMP_PC_EMP(processId,tabName,conReqId);
				if(messageList_PC_EMP!=null && messageList_PC_EMP.size()>0)
				{
					messageList.add(new ObjectError("CON_ReqEmp_PC_EMP",new String[]{SubmitActivityErrors.BJ_CON_ReqEmp_PC_EMP},null,null));
				}
			    }/*else{
			    	messageList.add(new ObjectError("CON_ReqEMP",new String[]{SubmitActivityErrors.BJ_CON_ReqEMP},null,null));	
			    }*/			    count=1;
			}
		    }
		    log.debug("messageList Size::"+messageList.size());

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }

	    
	    /**
	     * Gets the iP contacts message_ req em p_ pc.
	     *
	     * @param processId the process id
	     * @param tableName the table name
	     * @param queryMaxConnection the query max connection
	     * @return the iP contacts message_ req em p_ pc
	     * @throws Exception the exception
	     * @returns Citigroup Contacts Messages for Requestor Employee Type.
	     */
	    private List<ObjectError> getIPContactsMessage_ReqEMP_PC(Long processId,String tableName,Long conReqId)throws Exception{
		StringBuffer citiContactsSQL=new StringBuffer();
		SqlRowSet result  = null;
		List<ObjectError> messageList=new ArrayList<ObjectError>();
		
		try {
		    citiContactsSQL.append("select count(*)  from role where id in ( ");
		    citiContactsSQL.append(" select role_id from "+tableName+" where request_id="+conReqId+" and UPPER(primary_contact)='Y' and (upper(is_reject) is null or upper(is_reject) = 'N') and role_id in( ");
		    citiContactsSQL.append(" select id from role where name in('Manager'))) having count(id)=1");
		    
		    result  = jdbcTemplate.queryForRowSet(citiContactsSQL.toString());
		    log.debug("Table is >> :: "+citiContactsSQL.toString());
		    log.debug("result is::"+result);
		    if(!result.next()){
			messageList.add(new ObjectError("CON_ReqEmp_PC",new String[]{SubmitActivityErrors.BJ_CON_ReqEmp_PC},null,null));
			log.debug("no pc for non employee..");
		    }
		    log.debug("messageList Size::"+messageList.size());
		    
		    
		    

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }
	    
	    /**
	     * Gets the iP contacts message_ req em p_ p c_ emp.
	     *
	     * @param processId the process id
	     * @param tableName the table name
	     * @param queryMaxConnection the query max connection
	     * @return the iP contacts message_ req em p_ p c_ emp
	     * @throws Exception the exception
	     * @returns Citigroup Contacts Messages for Requestor Employee Type adding Project coordinator and to check emp type.
	     */
	    private List<ObjectError> getIPContactsMessage_ReqEMP_PC_EMP(Long processId,String tableName,Long conReqId)throws Exception{
		StringBuffer citiContactsSQL=new StringBuffer();
		List<ObjectError> messageList=new ArrayList<ObjectError>();
		try {
		    citiContactsSQL.append("select count(*) from citi_contact   where id in(");
		    citiContactsSQL.append(" select citi_contact_id from  "+tableName+" where request_id="+conReqId+" and UPPER(primary_contact)='Y' and (upper(is_reject) is null or upper(is_reject) = 'N') and role_id in( ");
		    citiContactsSQL.append(" select id from role where name in('Manager'))) and (UPPER(employee_type)='EMPLOYEE' or UPPER(employee_type)='E' ");
		    citiContactsSQL.append(" ) having count(*)>0");
		    
		    SqlRowSet result  = jdbcTemplate.queryForRowSet(citiContactsSQL.toString());
		   
		    log.debug("result is::"+citiContactsSQL.toString());
		    if(!result.next()){
			List<ObjectError> pcData = getIPContactsMessage_ReqEMP_PC_EMPPC(processId,tableName,conReqId);
			if(pcData!=null && pcData.size()>0)
			{
				messageList.add(new ObjectError("CON_ReqEmp_PC_CHECK",new String[]{SubmitActivityErrors.BJ_CON_ReqEmp_PC_EMP},null,null));
			    
			}
		    }
		    log.debug("messageList Size::"+messageList.size());

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }
	    
	    
	    /**
	     * Gets the iP contacts message_ req em p_ p c_ emppc.
	     *
	     * @param processId the process id
	     * @param tableName the table name
	     * @param queryMaxConnection the query max connection
	     * @return the iP contacts message_ req em p_ p c_ emppc
	     * @throws Exception the exception
	     */
	    private List<ObjectError> getIPContactsMessage_ReqEMP_PC_EMPPC(Long processId,String tableName,Long conReqId)throws Exception{
		StringBuffer citiContactsSQL=new StringBuffer();
		List<ObjectError> messageList=new ArrayList<ObjectError>();
		
		try {
		    citiContactsSQL.append("select count(*) from citi_contact   where id in(");
		    citiContactsSQL.append(" select citi_contact_id from  "+tableName+" where request_id="+conReqId+" and role_id in( ");
		    citiContactsSQL.append(" select id from role where name in('PROJECT COORDINATOR'))) and (UPPER(employee_type)='EMPLOYEE' or UPPER(employee_type)='E' ");
		    citiContactsSQL.append(" ) having count(*)>0");
		    
		    SqlRowSet result  = jdbcTemplate.queryForRowSet(citiContactsSQL.toString());
		    log.debug("result is::"+citiContactsSQL.toString());
		    if(!result.next()){
			messageList.add(new ObjectError("CON_ReqEmp_PC_CHECK",new String[]{SubmitActivityErrors.BJ_CON_ReqEmp_PC},null,null));
		    }
		    log.debug("messageList Size::"+messageList.size());

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }
	    
	    

	    /**
	     * Gets the citi contacts message_ emp.
	     *
	     * @param conReqId the con req id
	     * @param connData the conn data
	     * @return the citi contacts message_ emp
	     * @throws Exception the exception
	     * @returns Target Contacts Messages.
	     */
	    private List<ObjectError> getCitiContactsMessage_EMP(Long tiReqId,Long conReqId)throws Exception{
	    
		StringBuffer empTypeSearchSQL = new StringBuffer();
		List<ObjectError> messageList=new ArrayList<ObjectError>();
		
		String relationshipType=getRelationshipType(conReqId);
		log.debug("BusinessJustificationValidator.getCitiContactsMessage_EMP.relationshipType:'"+relationshipType+"'");
		String tabName=null;
		if(relationshipType.equalsIgnoreCase("THIRD_PARTY") || relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)|| relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE) || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)){
		    tabName="con_req_citi_contact_xref";
		}else{
		    tabName="CON_REQ_CIT_RQCON_XREF";
		}
		try {
		    empTypeSearchSQL.append("select count(*) from citi_contact   where id in(");
		    empTypeSearchSQL.append(" select citi_contact_id from  "+tabName+" where request_id="+conReqId+" and UPPER(primary_contact)='Y' and role_id in( ");
		    empTypeSearchSQL.append(" select id from role where name in('BISO'))) and (UPPER(employee_type)='EMPLOYEE' or UPPER(employee_type)='E' ");
		    empTypeSearchSQL.append(" ) having count(*)>0");
		    SqlRowSet result  = jdbcTemplate.queryForRowSet(empTypeSearchSQL.toString());
		    log.debug("empString::"+empTypeSearchSQL.toString());
		    if(!result.next()){
			messageList.add(new ObjectError("CONTACTS_EMPTYPE",new String[]{SubmitActivityErrors.BJ_CONTACTS_EMPTYPE},null,null));
		    }else{
			List<ObjectError> DEdata = getCitiContactsMessage_EMPDE(conReqId,conReqId);
			if(DEdata!=null && DEdata.size()>0)
			{
				messageList.add(new ObjectError("CONTACTS_EMPTYPE",new String[]{SubmitActivityErrors.BJ_CONTACTS_EMPTYPE},null,null));
			}
		    }

		    log.debug("messageList Size::"+messageList.size());

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }
	    
	    /**
	     * Gets the citi contacts message_ empde.
	     *
	     * @param conReqId the con req id
	     * @param queryMaxConnection the query max connection
	     * @param connData the conn data
	     * @return the citi contacts message_ empde
	     * @throws Exception the exception
	     */
	    private List<ObjectError> getCitiContactsMessage_EMPDE(Long conReqId,Long connData)throws Exception{

		StringBuffer empTypeSearchSQL = new StringBuffer();
		List<ObjectError> messageList=new ArrayList<ObjectError>();
		
		String relationshipType=getRelationshipType(connData);
		String tabName=null;
		if(relationshipType.equalsIgnoreCase("THIRD_PARTY")|| relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ) || relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE) || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)){
		    tabName="con_req_citi_contact_xref";
		}else{
		    tabName="CON_REQ_CIT_RQCON_XREF";
		}
		try {
		    empTypeSearchSQL.append("select count(*) from citi_contact   where id in(");
		    empTypeSearchSQL.append(" select citi_contact_id from  "+tabName+" where request_id="+connData+" and UPPER(primary_contact)='Y' and role_id in( ");
		    empTypeSearchSQL.append(" select id from role where name in('DESIGN ENGINEER'))) and (UPPER(employee_type)='EMPLOYEE' or UPPER(employee_type)='E' ");
		    empTypeSearchSQL.append(" ) having count(*)>0");
		    
		    SqlRowSet result  = jdbcTemplate.queryForRowSet(empTypeSearchSQL.toString());
		    log.debug("empString::"+empTypeSearchSQL.toString());
		    if(!result.next()){
		    	messageList.add(new ObjectError("CONTACTS_EMPTYPE",new String[]{SubmitActivityErrors.BJ_CONTACTS_EMPTYPE},null,null));
			}

		    log.debug("messageList Size::"+messageList.size());

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }

	    
	    public List<ObjectError> getEmerBusQuestMessage(Long tiReqId)throws Exception{
	    	log.debug("BusinessJustificationValidator:getEmerBusQuestMessage: starts");
	    	StringBuilder emerBuscritSql = new StringBuilder();
	    	List<ObjectError> messageList = new ArrayList<ObjectError>();
	    	try {
	    		
	    		String str = "SELECT GL.VALUE1 FROM TI_REQUEST TR, GENERIC_LOOKUP GL WHERE TR.ID = ?  AND  GL.ID = TR.PRIORITY_ID";
	    		SqlRowSet result0  = jdbcTemplate.queryForRowSet(str.toString(),new Object [] {Long.valueOf(tiReqId)} );
	    	    
	    	    if(result0!=null && result0.next()){
	    		log.debug("Value of the priority type::: "+result0.getString("VALUE1"));
	    		if ((result0.getString("VALUE1").equals("BUSCRIT") || result0.getString("VALUE1").equals("EMER"))){
	    			emerBuscritSql = new StringBuilder();
	    			emerBuscritSql.append("SELECT RDET.ID FROM  RFC_REQUEST RREQ,RFC_DETAIL RDET,RFC_LOOKUP RFCL  WHERE RREQ.TI_REQUEST_ID= ? "); 
	    			emerBuscritSql.append("AND RDET.RFC_REQUEST_ID = RREQ.ID AND RDET.RFC_LOOKUP_ID = RFCL.ID AND RFCL.PARAMNAME = 'DESCRIPTION_TEXT'");
		    		log.debug("BusinessJustificationValidator:getEmerBusQuestMessage: emerBuscritSql0:"+emerBuscritSql.toString());
		    		
		    		SqlRowSet result1  = jdbcTemplate.queryForRowSet(emerBuscritSql.toString(),new Object [] {Long.valueOf(tiReqId)});
		    		
		    		Long rfcDetailId = null;
		    		while(result1 !=null && result1.next()){
		    			rfcDetailId = result1.getLong(1);
		    		}
		    		if(rfcDetailId != null){
		    			log.debug("BusinessJustificationValidator:getEmerBusQuestMessage: rfcDetailId:"+rfcDetailId.longValue());
		    			emerBuscritSql = new StringBuilder();
			    		emerBuscritSql.append("SELECT RDANS.ANSWER ,TEMP.POSITION ");
			    		emerBuscritSql.append("FROM RFC_REQUEST RREQ,RFC_DETAIL RDET, RFC_DETAIL_ANSWERS RDANS,TEMPLATE TEMP ");  
			    		emerBuscritSql.append("WHERE RREQ.TI_REQUEST_ID = ? ");
			    		emerBuscritSql.append("AND RDET.RFC_REQUEST_ID = RREQ.ID AND RDANS.RFC_DETAIL_ID = RDET.ID ");
			    		emerBuscritSql.append("AND RDANS.TEMPLATE_KEY IN (SELECT ID FROM TEMPLATE TEMP ");
			    		emerBuscritSql.append("WHERE PARENT_ID = (SELECT ID FROM TEMPLATE WHERE UPPER(KEY) = ? ) ");
			    		emerBuscritSql.append("AND UPPER(ISACTIVE) = ? ) AND TEMP.ID = RDANS.TEMPLATE_KEY ORDER BY TEMP.POSITION ");
			    		log.debug("BusinessJustificationValidator:getEmerBusQuestMessage: emerBuscritSql:"+emerBuscritSql.toString());
			    		
			    		SqlRowSet result2  = jdbcTemplate.queryForRowSet(emerBuscritSql.toString(),new Object [] {Long.valueOf(tiReqId),"DESC_EMERBUSCRIT_QUESTIONAIRE","Y"});
			
			    		while(result2.next()){
			    			String answer = result2.getString(1);
			    			int position = result2.getInt(2);    			
			    			if ((answer == null || answer.equals(""))){
			    				messageList.add(new ObjectError("EMER_ERROR_MSG",new String[]{"Missing answer for name/SOE id of the approving Senior Manager in Emer Buscrit Questions."},null,null));
			    			}
			    		}
		    		}
		    		else{
		    			emerBuscritSql = new StringBuilder();
		    			emerBuscritSql.append("SELECT POSITION FROM TEMPLATE TEMP ");
		    			emerBuscritSql.append("WHERE PARENT_ID = (SELECT ID FROM TEMPLATE WHERE UPPER(KEY) = ? ) ");
		    			emerBuscritSql.append("AND UPPER(ISACTIVE) = ?");
		    			log.debug("BusinessJustificationValidator:getEmerBusQuestMessage: emerBuscritSql:"+emerBuscritSql.toString());
		    			
		    			SqlRowSet result2  = jdbcTemplate.queryForRowSet(emerBuscritSql.toString(),new Object [] {"DESC_EMERBUSCRIT_QUESTIONAIRE","Y"});
		    			
			    		while(result2.next()){
			    			int position = result2.getInt(1);    			
			    			
			    				messageList.add(new ObjectError("EMER_ERROR_MSG",new String[]{"Missing answer for Business Change in Emer Buscrit Questions."},null,null));
			    			
			    		}
		    		}
	    		}
	    		log.debug("BusinessJustificationValidator:getEmerBusQuestMessage: Error messageList Size::"+messageList.size());
	    		log.debug("BusinessJustificationValidator:getEmerBusQuestMessage: ends");
	    	    }
	    	}catch (Exception e) {
	    		log.error(e);
	    	}
	    	return messageList;
	    }
	   
	    

	    /**
	     * Gets the certify error msg.
	     *
	     * @param tiReqId the ti req id
	     * @return the certify error msg
	     */
	    private List<ObjectError> getCertifyErrorMsg(Long tiReqId){
		log.debug("getCertifyErrorMsg START::");
		StringBuffer certifySQL=new StringBuffer();
		List<ObjectError> messageList=new ArrayList<ObjectError>();
		
		try{
		    certifySQL.append(" SELECT 1 FROM C3PAR.TI_REQUEST A,C3PAR.TI_PROCESS B,C3PAR.RELATIONSHIP C,C3PAR.GENERIC_LOOKUP D WHERE");
		    certifySQL.append(" A.ID="+tiReqId+" AND B.ID=A.PROCESS_ID AND B.RELATIONSHIP_ID=C.ID AND D.ID=A.PRIORITY_ID AND D.VALUE1 IN('BUSCRIT','EMER') AND ");
		    certifySQL.append(" B.PROCESS_ACTIVITY_MODE IN ('RECONCILE') AND C.STATUS='NOT CERTIFIED'");

		    log.debug("(getCertifyErrorMsg)certifySQL::::::"+certifySQL.toString());
		    SqlRowSet result  = jdbcTemplate.queryForRowSet(certifySQL.toString());
		    if(result.next()){
			messageList.add(new ObjectError("CERTIFICATION",new String[]{SubmitActivityErrors.BJ_CERTIFICATION},null,null));
		    }
		    log.debug("messageList Size::"+messageList.size());
		}catch (Exception e) {
		    log.error(e);
		}

		log.info("getCertifyErrorMsg END::");
		return messageList;
	    }
	    
	    
	    /**
	     * Gets the con basic info message.
	     *
	     * @param conReqId the con req id
	     * @param tiReqId the ti req id
	     * @return the con basic info message
	     * @throws Exception the exception
	     * @returns Connection Basic Info Messages.
	     */
	    private List<ObjectError> getConBasicInfoMessage(Long conReqId, Long tiReqId)throws Exception{
		StringBuffer conSQL=new StringBuffer();
		List<ObjectError> messageList=new ArrayList<ObjectError>();

		StringBuffer tiReqConnSQL=new StringBuffer();
		StringBuffer affectedBusinessSql = new StringBuffer();

		try {
		    
		    conSQL.append(" SELECT a.CONNECTION_NAME ");/*, e.DONT_IMPL_BEFORE_DATE*/
		    conSQL.append(" FROM CON_REQ a, PLANNING e ");
		    conSQL.append(" WHERE a.id=" + conReqId + " and e.ID=a.ID  and rownum=1 ");
		    SqlRowSet result  = jdbcTemplate.queryForRowSet(conSQL.toString());
		    
		    log.debug("conSQL::Con Info QUERY:::"+conSQL.toString());
		    if(result!=null && result.next()){
		    	log.debug("BusinessJustificationValidator:Result is having data:");
			if(result.getString("CONNECTION_NAME")==null||"".equals(result.getString("CONNECTION_NAME"))){
			    messageList.add(new ObjectError("CONNECTION",new String[]{SubmitActivityErrors.BJ_CONNECTION},null,null));
			}
			
		    }
		    affectedBusinessSql.append("SELECT RDA.ANSWER FROM RFC_DETAIL_ANSWERS RDA, ");
		    affectedBusinessSql.append(" RFC_DETAIL RD, RFC_LOOKUP RL,RFC_REQUEST RR, TI_REQUEST TR ");
		    affectedBusinessSql.append(" WHERE TR.ID = RR.TI_REQUEST_ID AND ");
		    affectedBusinessSql.append(" RR.ID = RD.RFC_REQUEST_ID AND ");
		    affectedBusinessSql.append(" RD.ID = RDA.RFC_DETAIL_ID AND ");
		    affectedBusinessSql.append(" RL.ID = RD.RFC_LOOKUP_ID ");
		    affectedBusinessSql.append(" AND RL.PARAMNAME = 'AFFECTED_BUSINESS' AND TR.ID = "+tiReqId);
		    
		    SqlRowSet affectedBusinessResult  = jdbcTemplate.queryForRowSet(affectedBusinessSql.toString());

		    if(!affectedBusinessResult.next()){
			 messageList.add(new ObjectError("ANSWER",new String[]{SubmitActivityErrors.BJ_ANSWER},null,null));
		    }

		}catch (Exception e) {
		    log.error(e);
		}

		try {
		    
		    tiReqConnSQL.append(" SELECT c.PRIORITY_ID");
		    tiReqConnSQL.append(" FROM TI_REQUEST c ");
		    tiReqConnSQL.append(" WHERE C.ID = " + tiReqId );
		    
		    SqlRowSet tiReqResult  = jdbcTemplate.queryForRowSet(tiReqConnSQL.toString());
		    
		    log.debug("conSQL::EMER QUERY:::"+conSQL.toString());
		    if(tiReqResult!=null && tiReqResult.next()){
			if(tiReqResult.getString("PRIORITY_ID")==null||"".equals(tiReqResult.getString("PRIORITY_ID"))){
			    messageList.add(new ObjectError("PRIORITY",new String[]{SubmitActivityErrors.BJ_PRIORITY},null,null));
			}
		    }


		    log.debug("messageList Size::"+messageList.size());

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }
	    
	    
	    /**
	     * Gets the data info bulk request message.
	     *
	     * @param tiReqId the ti req id
	     * @param conReqId the con req id
	     * @return the data info bulk request message
	     * @throws Exception the exception
	     */
	    private List<ObjectError> getDataInfoBulkRequestMessage(Long tiReqId,Long conReqId)throws Exception{
		String  dataSQL=null;
		List<ObjectError> messageList=new ArrayList<ObjectError>();
		
		try {
		    dataSQL=" select count(*) from con_req where bulk_request='Y' and id="+conReqId;
		    
		    SqlRowSet result0  = jdbcTemplate.queryForRowSet(dataSQL.toString());
		    
		    if(result0!=null && result0.next()){
			if(result0.getInt(1)>0){
			    dataSQL="select COUNT(*) from TI_DOC_META_DATA WHERE TI_REQUEST_ID="+tiReqId+"AND DOC_TYPE='Bulk Firewall Rules'";
			    SqlRowSet result1  = jdbcTemplate.queryForRowSet(dataSQL.toString());
			    if(result1!=null && result1.next()){
				if(result1.getInt(1)>0){

				}else{
				    messageList.add(new ObjectError("BULKREQ",new String[]{SubmitActivityErrors.BJ_BULKREQ},null,null));
				}
			    }
			}
		    }

		    log.debug("messageList Size::"+messageList.size());

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }
	    
	    

	    /**
	     * Gets the document upload message.
	     *
	     * @param tiReqId the ti req id
	     * @return the document upload message
	     * @throws Exception the exception
	     * @returns Document Upload Messages.
	     */
	    private List<ObjectError> getDocumentUploadMessage(Long tiReqId)throws Exception{
		StringBuffer legalReviewSQL=new StringBuffer();
		List<ObjectError> messageList=new ArrayList<ObjectError>();
		Long conReqId=getConnectionRequestId(tiReqId);
		String relationshipType=getRelationshipType(conReqId);
		try {
		    legalReviewSQL.append(" SELECT a.DOC_TYPE FROM TI_DOC_META_DATA a,TI_REQUEST b WHERE a.CONNECTION_ID="+conReqId);
		    legalReviewSQL.append(" and b.ID=a.TI_REQUEST_ID and a.DOC_TYPE='Legal Review'");
		   
		    if(relationshipType.equals(C3parStaticNames.U_TURN)){
		    SqlRowSet result2  = jdbcTemplate.queryForRowSet(legalReviewSQL.toString());
			
			if(!result2.next()){
				messageList.add(new ObjectError("LEGALREVIEW",new String[]{SubmitActivityErrors.BJ_LEGALREVIEW},null,null));
			   
			}
		    }
		    	    
		    log.debug("messageList Size::"+messageList.size());
		    
		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }

	    /**
	     * Gets the director emp msg.
	     *
	     * @param conReqId the con req id
	     * @param tiReqId the ti req id
	     * @return the director emp msg
	     * @throws Exception the exception
	     */
	    private List<ObjectError> getDirectorEmpMsg(Long conReqId, Long tiReqId)throws Exception{
		List<ObjectError> messageList=new ArrayList<ObjectError>();
		String relationshipType=getRelationshipType(conReqId);
		 
	 
		StringBuffer tiReqConnSQL=new StringBuffer();
		StringBuffer tContactsSQL=new StringBuffer();
		StringBuffer rContactsSQL =  new StringBuffer();

		try {

		    String empType = "(select user_id from ti_request where process_id="+conReqId+" and version_number=(select max(version_number) from ti_Request where process_id="+conReqId+"))";

		    tContactsSQL.append("select count(*) from citi_contact where id in ( ");
		    tContactsSQL.append("select citi_contact_id from con_req_citi_contact_xref where citi_contact_id is not null and ");
		    tContactsSQL.append("request_id= "+conReqId+"  and UPPER(primary_contact)='Y' and role_id in( ");
		    tContactsSQL.append("select id from role where name ='Director')) and (UPPER(employee_type)='EMPLOYEE' or  ");
		    tContactsSQL.append("UPPER(employee_type)='E' ) having count(*)>0");

		    log.debug("Query in the tContactsSQL:: "+tContactsSQL.toString());

		    rContactsSQL.append("select count(*) from citi_contact where id in ( ");
		    rContactsSQL.append("select citi_contact_id from CON_REQ_CIT_RQCON_XREF where citi_contact_id is not null and ");
		    rContactsSQL.append("request_id= "+conReqId+"  and UPPER(primary_contact)='Y' and role_id in( ");
		    rContactsSQL.append("select id from role where name ='Director')) and (UPPER(employee_type)='EMPLOYEE' or  ");
		    rContactsSQL.append("UPPER(employee_type)='E' ) having count(*)>0");

		    log.debug("Requester Contacts SQL::"+rContactsSQL.toString());


		    tiReqConnSQL.append(" SELECT c.PRIORITY_ID,f.VALUE1 ");
		    tiReqConnSQL.append(" FROM TI_REQUEST c , GENERIC_LOOKUP f ");
		    tiReqConnSQL.append(" WHERE C.ID = " + tiReqId + " AND  f.ID=c.PRIORITY_ID ");
		    log.debug("Query in tiReqConnSQL::: "+tiReqConnSQL.toString());
		    
		    SqlRowSet result  = jdbcTemplate.queryForRowSet(tiReqConnSQL.toString());
		    
		    if(result!=null && result.next()){
			log.debug("Value of the priority type::: "+result.getString("VALUE1"));
			if ((result.getString("VALUE1").equals("BUSCRIT") || result.getString("VALUE1").equals("EMER"))){
			    log.debug("relationshipType Submit Activity "+relationshipType);
				
			    if(relationshipType.equalsIgnoreCase("THIRD_PARTY")){
				SqlRowSet tiReqResult  = jdbcTemplate.queryForRowSet(tContactsSQL.toString());
				if(!tiReqResult.next()){
				 
						
					messageList.add(new ObjectError("DIRECTOR",new String[]{SubmitActivityErrors.BJ_DIRECTOR},null,null));
					
				}
			    }else if(relationshipType.equalsIgnoreCase("CITI_CON")){
			    SqlRowSet tiReqResult  = jdbcTemplate.queryForRowSet(rContactsSQL.toString());	
				if(!tiReqResult.next()){
					 
					messageList.add(new ObjectError("DIRECTOR",new String[]{SubmitActivityErrors.BJ_DIRECTOR},null,null));
				}
			    }else if(relationshipType.equalsIgnoreCase("U_TURN")){
			    SqlRowSet tiReqResult  = jdbcTemplate.queryForRowSet(rContactsSQL.toString());	
				if(!tiReqResult.next()){
				 
					messageList.add(new ObjectError("DIRECTOR",new String[]{SubmitActivityErrors.BJ_DIRECTOR},null,null));
				}
			    }
			}
		    }

		    log.debug("BJ_director messageList Size::"+messageList.size());
		    
		    log.debug("Method Call End..........");

		}catch (Exception e) {
		    log.error(e);
		}
		return messageList;
	    }
	    
	    
	    private List<ObjectError> getUserEntitlementMessage(Long tiRequestID,Long conReqId)throws Exception{
			StringBuffer tContactsSQL=new StringBuffer();
			StringBuffer rContactsSQL=new StringBuffer();
				
			List<ObjectError> messageList=new ArrayList<ObjectError>();
			
			UserEntitlementHelper usrEntHelper = new UserEntitlementHelper();
			String relationshipType=getRelationshipType(conReqId);
			log.debug("getUserEntitlementMessage :: relationshipType ::"+relationshipType);
			try {
			    tContactsSQL.append("select distinct citicon.sso_id from con_req_citi_contact_xref targetcon join citi_contact citicon");
			    tContactsSQL.append(" on targetcon.citi_contact_id = citicon.id where citi_contact_id is not null  and REQUEST_ID = "+conReqId);
			    log.debug("getUserEntitlementMessage :: Target Contacts SQL::"+tContactsSQL.toString());
			    
			    rContactsSQL.append("select distinct citicon.sso_id from CON_REQ_CIT_RQCON_XREF reqcontact join citi_contact citicon");
			    rContactsSQL.append(" on reqcontact.citi_contact_id = citicon.id where citi_contact_id is not null  and REQUEST_ID = "+conReqId);
			    log.debug("getUserEntitlementMessage :: Requester Contacts SQL::"+rContactsSQL.toString());
		
			    // Third Party, Template, IP and Port Template	    
			    if(relationshipType.equalsIgnoreCase("THIRD_PARTY") || relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)|| relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE) || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)){
			    	SqlRowSet result  = jdbcTemplate.queryForRowSet(tContactsSQL.toString());
					while(result != null && result.next()){
						if(usrEntHelper.isUserIDExistsInCCR(result.getString(1)).equalsIgnoreCase("N")){
						    messageList.add(new ObjectError("USER_ENTITLEMET_NOT_EXIST_TARGET",new String[]{SubmitActivityErrors.BJ_USER_ENTITLEMET_NOT_EXIST_TARGET},null,null));
						    break;
						}
					}			
			    }
			    //Non Third Party and U Turn
			    if(relationshipType.equalsIgnoreCase("CITI_CON") || relationshipType.equalsIgnoreCase("U_TURN") ){
			    	SqlRowSet result  = jdbcTemplate.queryForRowSet(rContactsSQL.toString());
					while(result != null && result.next()){
						if(usrEntHelper.isUserIDExistsInCCR(result.getString(1)).equalsIgnoreCase("N")){
							messageList.add(new ObjectError("USER_ENTITLEMET_NOT_EXIST_REQUESTER",new String[]{SubmitActivityErrors.BJ_USER_ENTITLEMET_NOT_EXIST_REQUESTER},null,null));
						    break;
						}
					}			
			    }	    
			    log.debug("getUserEntitlementMessage :: messageList Size::"+messageList.size());
		
			}catch (Exception e) {
			    log.error(e);
			}
			return messageList;
	    }
	    
	  //method to validate whether ISO Contacts are available in ISO Contact List
	    private List<ObjectError> getISOContactListCheckMessage(Long tiRequestID,Long conReqId)throws Exception{
	    	
	    	StringBuilder tContactsSQL=new StringBuilder();
	    	StringBuilder rContactsSQL=new StringBuilder();
	    	StringBuilder isoContactsSQL=new StringBuilder();
	    	SqlRowSet result=null;	
	    	List<ObjectError> messageList=new ArrayList<ObjectError>();
	    	
			String relationshipType=getRelationshipType(conReqId);
	    	try {    	      
	    	    tContactsSQL.append("select distinct citicon.sso_id from con_req_citi_contact_xref targetcon join citi_contact citicon on targetcon.citi_contact_id = citicon.id ");
			    tContactsSQL.append(" join role r on targetcon.role_id = r.id where citi_contact_id is not null and r.name='BISO' and REQUEST_ID = "+conReqId);
			    log.debug("getISOContactListCheckMessage :: Target Contacts SQL::"+tContactsSQL.toString());
			    
			    rContactsSQL.append("select distinct citicon.sso_id from CON_REQ_CIT_RQCON_XREF reqcontact join citi_contact citicon on reqcontact.citi_contact_id = citicon.id ");
			    rContactsSQL.append(" join role r on reqcontact.role_id = r.id where citi_contact_id is not null and r.name='BISO' and REQUEST_ID = "+conReqId);
			    log.debug("getISOContactListCheckMessage :: Requester Contacts SQL::"+rContactsSQL.toString());
		
			       
			    // Third Party, Template, IP and Port Template connections 
			    if(relationshipType.equalsIgnoreCase("THIRD_PARTY") || relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)|| relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE) || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)){
			    	 result  = jdbcTemplate.queryForRowSet(tContactsSQL.toString());
			    }
			    //Non Third Party and U Turn connections
			    if(relationshipType.equalsIgnoreCase("CITI_CON") || relationshipType.equalsIgnoreCase("U_TURN") ){
			    	result  = jdbcTemplate.queryForRowSet(rContactsSQL.toString());
			    }	
			    StringBuilder isoContacts = new StringBuilder();
				int isoCount = 0;
				while(result != null && result.next()){
					isoContacts.append("'"+result.getString(1).toUpperCase()+"',");
					isoCount++;
				}
				//If any ISO contact added for the connection then valiate
				if(isoCount > 0){
		    		isoContactsSQL.append("select count(*) from iso_contacts ");
		    		isoContactsSQL.append(" where upper(soe_id) in (" + isoContacts.substring(0, isoContacts.length()-1) + ") and is_deleted = 'N' having count(*) = "+isoCount);
		    	    log.debug("getISOContactListCheckMessage :: ISO Contacts SQL::"+isoContactsSQL.toString());
		    	    result  = jdbcTemplate.queryForRowSet(isoContactsSQL.toString());
					//if ISO contact not in ISOContactList then add Error Message
					if(result == null || result.next() == false){
						messageList.add(new ObjectError("ISO_CONTACTS_LIST",new String[]{SubmitActivityErrors.BJ_ISO_CONTACTS_LIST},null,null));
					}
				}
	    	    log.debug("getISOContactListCheckMessage :: messageList Size::"+messageList.size());
	    	}catch (Exception e) {
	    	    log.error(e);
	    	}
	    	return messageList;
	    }
	    
	    /**
	     * Completion check.
	     *
	     * @param conReqId the con req id
	     * @return the string
	     * @throws Exception the exception
	     */
	    private ObjectError completionCheck(Long conReqId, Long tiReqId) throws Exception {
	    	
	    String relationshipType = getRelationshipType(conReqId);
	    ObjectError message = null;
		String manageProxy = null;
		String appsensePolicy = null;
		String appsenseUser = null;
		String aclVariance = null;
		
		String reqType =null;
		
		try {
		    manageProxy = "select count(*) from prx_proxy_filter where process_id=" + conReqId;

		    String firewall = "select count(*) from con_fw_rule where deleted_ti_request_id is null and ti_request_id = "+tiReqId+ "and (IS_IPREG!='Y' or IS_IPREG is null)";
		    String addIp = "select count(a.END_POINT) from con_ip_xref a, con_ip_master b, resourcetype c where a.CONNECTION_REQUEST_ID = " + conReqId + " and b.ID = a.IP_ID and c.ID = a.RESOURCE_TYPE and a.END_POINT in('A','B')";
		    String ipPair = "select count(id) from con_ip_pair_xref a where a.CONNECTION_REQUEST_ID = " + conReqId;
		    appsensePolicy = "select count(*) from aps_appsense_policy where process_id=" + conReqId + "and record_type='A'";
		    appsenseUser = "select count(*) from aps_appsense_policy where process_id=" + conReqId + "and record_type='U'";
		    aclVariance = "select 1 from acl_variance where process_id=" + conReqId;
		    String ipReg = "select count(*) from con_fw_rule where deleted_ti_request_id is null and ti_request_id = "+tiReqId+ "and IS_IPREG='Y'";
		    
		    String reqTypeSQL = "select trt.request_type from  ti_request tr, ti_request_type trt where tr.ti_request_type_id = trt.id and tr.id =  "+tiReqId;
		    String termFirewall ="select count(*) from con_fw_rule where deleted_ti_request_id is not  null and ti_request_id ="+tiReqId+ "and (IS_IPREG!='Y' or IS_IPREG is null)";
		    String termIPReg = "select count(*) from con_fw_rule where deleted_ti_request_id is not null and ti_request_id = "+tiReqId+ "and IS_IPREG='Y'";
		    
		    
			SqlRowSet reqTypeResult1  = jdbcTemplate.queryForRowSet(reqTypeSQL.toString());
			if (reqTypeResult1.next()) {
				reqType =reqTypeResult1.getString(1);
			log.debug("Request Type result is::"+ reqType);
	        }
		    
		    if (!reqType.equalsIgnoreCase("Terminate")){
		    	termReqTypeFlag = false;
			    SqlRowSet result0  = jdbcTemplate.queryForRowSet(manageProxy.toString());
			    if (result0.next()) {
				log.debug("Manage Proxy result is::" + result0.getInt(1));
				if (result0.getInt(1) > 0)
				    manageProxyFlag = true;
				else
				    manageProxyFlag = false;
	
			    }
	
			    SqlRowSet result1  = jdbcTemplate.queryForRowSet(firewall.toString());
			    if (result1.next()) {
				log.debug("Manage Network Firewall result is::" + result1.getInt(1));
				if (result1.getInt(1) > 0)
				    manageNetworkFlag = true;
				else
				    manageNetworkFlag = false;
			    }
	
			    SqlRowSet result4  = jdbcTemplate.queryForRowSet(appsensePolicy.toString());
			    if (result4.next()) {
				log.debug("	" + result4.getInt(1));
				if (result4.getInt(1) > 0)
				    appsensePolicyFlag = true;
				else
				    appsensePolicyFlag = false;
			    }
			    
			    SqlRowSet result5  = jdbcTemplate.queryForRowSet(appsenseUser.toString());
			    if (result5.next()) {
				log.debug("Appsense User result is::" + result5.getInt(1));
				if (result5.getInt(1) > 0)
				    appsenseUserFlag = true;
				else
				    appsenseUserFlag = false;
			    }
			    
			    SqlRowSet result6  = jdbcTemplate.queryForRowSet(aclVariance.toString());
			    if (result6.next()) {
				aclVarianceFlag = true;
			    }else
				aclVarianceFlag = false;
	
			    if (appsenseUserFlag) {
				if (!appsensePolicyFlag)
				    appsensePolicyFlag = true;
			    }
			    
			    
			    SqlRowSet result7  = jdbcTemplate.queryForRowSet(ipReg.toString());
			    if (result7.next()) {
				log.debug("IP Registration result is::" + result7.getInt(1));
				if (result7.getInt(1) > 0)
					ipRegFlag = true;
				else
					ipRegFlag = false;
			    }
			    	
			    
			    if (manageProxyFlag || manageNetworkFlag || appsensePolicyFlag || aclVarianceFlag || ipRegFlag) {
				log.debug("inside -- manageProxyFlag - " + manageProxyFlag
					+ "|| manageNetworkFlag - " + manageNetworkFlag
					+ "|| aclVarianceFlag - " + aclVarianceFlag
					+ "|| appsensePolicyFlag - " + appsensePolicyFlag
					+ "|| ipRegFlag - " + ipRegFlag);
			    } else {
			    	//	added for task 44559;
				    if((relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)|| relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE) || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)))
				    		{
				    		log.debug("Inside MAP MESSAGE");
				    		message = new ObjectError("COMPLETIONCHECKFORTEMPLATE",new String[]{SubmitActivityErrors.TA_COMPLETIONCHECKFORTEMPLATE},null,null);
				    		log.debug("Inside MAP MESSAGE" + message);
				    		}
				    	else{
				    			log.debug("Inside COMPLETIONCHECK MAP MESSAGE");
				    			message = new ObjectError("COMPLETIONCHECK",new String[]{SubmitActivityErrors.TA_COMPLETIONCHECK},null,null);
				    			log.debug("Inside COMPLETIONCHECK MAP MESSAGE" + message);
				    		}	
				 }				
		    }else { //Termination cycle
					log.debug("Completion Check for Request Type :: " + reqType);
					termReqTypeFlag =  true;
					SqlRowSet termResult1  = jdbcTemplate.queryForRowSet(termFirewall.toString());
					if (termResult1.next()) {
						log.debug("Manage Network Firewall for termination Cycle result is::"+ termResult1.getInt(1));
						if (termResult1.getInt(1) > 0)
							manageNetworkFlag = true;
						else
							manageNetworkFlag = false;
					} 
					SqlRowSet termResult2  = jdbcTemplate.queryForRowSet(termIPReg.toString());
					if (termResult2.next()) {
						log.debug("IP Registration for termination Cycle result is::"+ termResult2.getInt(1));
						if (termResult2.getInt(1) > 0)
							ipRegFlag = true;
						else
							ipRegFlag = false;
					} 
					else {
						log.debug("Inside MAP MESSAGE");
						message = new ObjectError("TERMINATECOMPLETIONCHECK",new String[]{SubmitActivityErrors.TA_TERMINATECOMPLETIONCHECK},null,null);
						log.debug("Inside MAP MESSAGE" + message);
					}
					
				    SqlRowSet result0  = jdbcTemplate.queryForRowSet(manageProxy.toString());
				    if (result0.next()) {
				    	log.debug("Manage Proxy result is::" + result0.getInt(1));
				    	
						if (result0.getInt(1) > 0)
						    manageProxyFlag = true;
						else
						    manageProxyFlag = false;
				    }
		    }		    
		} catch (Exception e) {
		    log.error(e);
		}
		return message;
	    }

	    private ObjectError ipDetailsCompleteCheck(Long tiReqId, String conType) throws Exception {
	    	log.info("TechnialArchitectureValidator.ipDetailsCompleteCheck() " + tiReqId);
	    	ObjectError message = null;
			boolean completed = true;
			String isIp = "";
			if(conType.equalsIgnoreCase("IpReg"))
			{
				isIp = "rule.IS_IPREG='Y'";
			}
			else
			{
				isIp = "(rule.IS_IPREG!='Y' or rule.IS_IPREG is null)";
			}
			try {
			    String sql =("select mst.ip_address "+
						" from con_ip_master mst "+  
						" left outer join con_fw_rule_source_ip sip on sip.ip_id=mst.id and sip.deleted_ti_request_id is null "+  
						" left outer join con_fw_rule rule on rule.id = sip.rule_id and rule.deleted_ti_request_id is null  "+
						" join resourcetype endA on rule.src_nwzone_id = endA.id and endA.name not in ('3rd Party/CEP','IP Reg ACL') "+ 
						" left outer join con_fw_rule_application fwrapp on fwrapp.deleted_ti_request_id is null and fwrapp.ip_id = mst.id and fwrapp.rule_id = rule.id "+  
						" where rule.ti_request_id = "+tiReqId+
						" and "
						+ isIp +
						" and (select count(*) from con_fw_rule_application fra where fra.deleted_ti_request_id is null and fra.id = fwrapp.id) <= 0 "+
						" group by mst.ip_address "+
						" union   "+
						" select mst.ip_address "+
						" from con_ip_master mst "+
						" left outer join con_fw_rule_destination_ip dip on dip.ip_id=mst.id  and dip.deleted_ti_request_id is null  "+
						" left outer join con_fw_rule rule on rule.id = dip.rule_id  and rule.deleted_ti_request_id is null  "+
						" join resourcetype endB on rule.dst_nwzone_id = endB.id and endB.name <> '3rd Party/CEP' "+ 
						" left outer join con_fw_rule_application fwrapp on fwrapp.deleted_ti_request_id is null and fwrapp.ip_id = mst.id and fwrapp.rule_id = rule.id  "+ 
						" where rule.ti_request_id = "+tiReqId+
						" and "
						+ isIp +
						" and (select count(*) from con_fw_rule_application fra where fra.deleted_ti_request_id is null and fra.id = fwrapp.id) <= 0 "+
						" group by mst.ip_address") ;
			   
						SqlRowSet result  = jdbcTemplate.queryForRowSet(sql);
			    String retValue = null;
			    if (result.next()) {
			    	completed = false;
			    }
			    
				if (!completed) {
					
					if(conType.equalsIgnoreCase("IpReg")) {
						
						message = new ObjectError("APPLICATION_IPREG",new String[]{SubmitActivityErrors.TA_APPLICATION_IPREG},null,null);
					    log.debug(" ipDetailsCompleteCheck message is::" + message);
					}
					else {
						message = new ObjectError("APPLICATION",new String[]{SubmitActivityErrors.TA_APPLICATION},null,null);
						 log.debug(" ipDetailsCompleteCheck message is::" + message);
					}
				   
				} 
		
		
			} catch (Exception e) {
			    log.error(e);
			} 
			
			return message;
	    }
	  
	    
	    private ObjectError connectionResourceTypes(Long tiReqId, Long processId) throws Exception {
	    	log.info("TechnialArchitectureValidator.connectionResourceTypes() " + tiReqId + "  " + processId);
	    	ObjectError message = null;
	    	SqlRowSet result = null;
			boolean completed = false;
			try {
			    String sql =("select rule.id from con_fw_rule rule, con_req con where "
				+" ((rule.src_nwzone_id = con.source_resource_type and rule.dst_nwzone_id = con.target_resource_type and rule.ti_request_id="+tiReqId+" and con.id="+processId+") "
				+" or (rule.dst_nwzone_id = con.source_resource_type and rule.src_nwzone_id = con.target_resource_type)) " +
				" and rule.deleted_ti_request_id is null and rule.ti_request_id="+tiReqId+" and con.id="+processId);
				
			     result  = jdbcTemplate.queryForRowSet(sql);
			    
			    if (result.next()) {
			    	completed = true;
			    }
			    
			    if (!completed) {
				   String sql1 = ("select rule1.id, rule2.id from con_fw_rule rule1, con_fw_rule rule2, con_req con where "
					+" ((rule1.src_nwzone_id = con.source_resource_type and rule2.dst_nwzone_id = con.target_resource_type "
					+" and rule1.dst_nwzone_id = rule2.src_nwzone_id) "
					+" or (rule1.dst_nwzone_id = con.source_resource_type and rule2.src_nwzone_id = con.target_resource_type "  
					+" and rule2.dst_nwzone_id = rule1.src_nwzone_id)) " +
					 " and rule1.deleted_ti_request_id is null and rule2.deleted_ti_request_id is null " +
					 " and rule1.ti_request_id="+tiReqId+" and rule2.ti_request_id="+tiReqId+" and con.id="+processId);
				    
				    result  = jdbcTemplate.queryForRowSet(sql1);
				    while (result.next()) {
				    	if (connectionResourceTypeswithIP(result.getLong(0), result.getLong(0))) {
				    		completed = true;
				    		break;
				    	}
				    }
			    }
			    
				/*if (!completed) {
					message = new ObjectError("FW_RULE_REC_TYP",new String[]{SubmitActivityErrors.TA_FW_RULE_REC_TYP},null,null);
				    log.debug(" connectionResourceTypes message is::" + message);
				} */
		
		
			} catch (Exception e) {
			    log.error(e);
			} 
			
			return message;
	    }
	  
	    private boolean connectionResourceTypeswithIP(Long rule1, Long rule2) throws Exception {
		  	
			boolean completed = false;
			try {
			    String sql = ("select ip1.ip_address, ip2.ip_address from con_ip_master ip1, con_ip_master ip2 where "
				+" ((ip1.formatted_ip = ip2.formatted_ip and ip1.no_of_host is null and ip2.no_of_host is null) "
				+" or (ip1.formatted_ip between ip2.formatted_start_ip and ip2.formatted_end_ip and ip1.no_of_host is null and ip2.no_of_host is not null) "
				+" or (ip2.formatted_ip between ip1.formatted_start_ip and ip1.formatted_end_ip and ip2.no_of_host is null and ip1.no_of_host is null) "
				+" or (((ip1.formatted_start_ip between ip2.formatted_start_ip and ip2.formatted_end_ip) "
				+" or (ip2.formatted_start_ip between ip1.formatted_start_ip and ip1.formatted_end_ip)) " 
				+" and ip1.no_of_host is not null and ip2.no_of_host is not null)) "
				+" and ip1.id in (select ip_id from con_fw_rule_destination_ip where rule_id="+ rule1 +" and deleted_ti_request_id is null) "
				+" and ip2.id in (select ip_id from con_fw_rule_source_ip where rule_id="+ rule2 +" and deleted_ti_request_id is null) "
				+" union "
				+" select ip1.ip_address, ip2.ip_address from con_ip_master ip1, con_ip_master ip2 where "
				+" ((ip1.formatted_ip = ip2.formatted_ip and ip1.no_of_host is null and ip2.no_of_host is null) "
				+" or (ip1.formatted_ip between ip2.formatted_start_ip and ip2.formatted_end_ip and ip1.no_of_host is null and ip2.no_of_host is not null) "
				+" or (ip2.formatted_ip between ip1.formatted_start_ip and ip1.formatted_end_ip and ip2.no_of_host is null and ip1.no_of_host is null) "
				+" or (((ip1.formatted_start_ip between ip2.formatted_start_ip and ip2.formatted_end_ip) "
				+" or (ip2.formatted_start_ip between ip1.formatted_start_ip and ip1.formatted_end_ip)) " 
				+" and ip1.no_of_host is not null and ip2.no_of_host is not null)) "
				+" and ip1.id in (select ip_id from con_fw_rule_destination_ip where rule_id="+ rule2 +" and deleted_ti_request_id is null) "
				+" and ip2.id in (select ip_id from con_fw_rule_source_ip where rule_id="+ rule1 +" and deleted_ti_request_id is null)");
				
			    SqlRowSet result  = jdbcTemplate.queryForRowSet(sql);
			    if (result.next()) {
			    	completed = true;
			    }
			} catch (Exception e) {
			    log.error(e);
			} 
		return completed;
	  }
	    
	    private ObjectError fwRulesCompleteCheck(Long tiReqId,String conType) throws Exception {
	    	log.info("TechnialArchitectureValidator.fwRulesCompleteCheck " + tiReqId);
	    	ObjectError message = null;
	    	 SqlRowSet result =null;
			boolean completed = true;
			String isIp = "";
			if(conType.equalsIgnoreCase("IpReg"))
			{
				isIp = "rule.IS_IPREG='Y'";
			}
			else
			{
				isIp = "(rule.IS_IPREG!='Y' or rule.IS_IPREG is null)";
			}
			try {
			    String sql =("select distinct rule.id from ti_process tp ,relationship rl, ti_request tr, con_fw_rule rule where "+ 
	    		" tp.id = tr.process_id and tp.relationship_id = rl.id "+
	    		" and "
				+ isIp +
	    		" and rl.relationship_type not in ('"+C3parStaticNames.IP_TEMPLATE+"','"+C3parStaticNames.PORT_TEMPLATE+"','"+C3parStaticNames.TEMPLATE_OBJ+"') and rule.ti_request_id = tr.id and "+ 
	    		" rule.ti_request_id =  "+tiReqId+" and rule.deleted_ti_request_id is null "+
	    		" and ((select count(*) from con_fw_rule_source_ip where rule_id = rule.id and deleted_ti_request_id is null) <= 0 "+
	    		" or (select count(*) from con_fw_rule_destination_ip where rule_id = rule.id and deleted_ti_request_id is null) <= 0 "+
	    		" or (select count(*) from con_fw_rule_port where rule_id = rule.id and deleted_ti_request_id is null) <= 0)");
			   
			     result  = jdbcTemplate.queryForRowSet(sql);
			    String retValue = null;
			    if (result.next()) {
			    	completed = false;
			    }
			    
			    if (!completed) {
			    	if(conType.equalsIgnoreCase("IpReg"))
					{
			    	message = new ObjectError("FW_RULE_COMPLETE_IPReg",new String[]{SubmitActivityErrors.TA_FW_RULE_COMPLETE_IPReg},null,null);
				    log.debug(" fwRulesCompleteCheck message is::" + message);
					} else {
					message = new ObjectError("FW_RULE_COMPLETE",new String[]{SubmitActivityErrors.TA_FW_RULE_COMPLETE},null,null);
					log.debug(" fwRulesCompleteCheck message is::" + message);
					}
				}
			    
			    completed = true;
			    
			    String sql1 = ("select distinct 1 from ti_process tp,relationship rl,ti_request tr,con_fw_rule cfr,con_fw_group cfg  "+
						" where tr.id = "+tiReqId+" and tp.id = tr.process_id and tp.relationship_id = rl.id " +
						" and rl.relationship_type not in ('"+C3parStaticNames.IP_TEMPLATE+"','"+C3parStaticNames.TEMPLATE_OBJ+"','"+C3parStaticNames.PORT_TEMPLATE+"') "+
						" and cfr.ti_request_id = tr.id and cfr.deleted_ti_request_id is NULL and cfr.policy_group_id = cfg.id "+
						" and cfg.firewall_group in ('TEMPLATE_FIREWALLGROUP') ");

			     result  = jdbcTemplate.queryForRowSet(sql1);
			    retValue = null;
			    if (result.next()) {
			    	completed = false;
			    }
			    
				if (!completed) {
					message = new ObjectError("FW_RULE_GRP_REQ",new String[]{SubmitActivityErrors.TA_FW_RULE_GRP_REQ},null,null);
				    log.debug(" fwRulesCompleteCheck message is::" + message);
				} 
		
		
			} catch (Exception e) {
			    log.error(e);
			} 
			return message;
	    }
	  
	    private ObjectError fafCompleteCheck(Long tiReqId, String type) {
			  log.info("TechnialArchitectureValidator.fafCompleteCheck() " + tiReqId);
			  ObjectError message = null;
		    	
				//if fireflow disabled and no changes in FireWall rules
				if((!isFireFlowEnbled(tiReqId) && isRuleChanged(tiReqId,type))){
					if(type.equalsIgnoreCase("IpReg")) {
						message = new ObjectError("FAF_COMPLETE_IPReg",new String[]{SubmitActivityErrors.TA_FAF_COMPLETE_IPReg},null,null);
					 
					    log.debug(" fafCompleteCheck message is::" + message);
						} else {
							message = new ObjectError("FAF_COMPLETE",new String[]{SubmitActivityErrors.TA_FAF_COMPLETE},null,null);
						   log.debug(" fafCompleteCheck message is::" + message);
					}
				}
				//if fireflow enabled and no changes in FireWall rules and tickets are worked out
				if((isFireFlowEnbled(tiReqId) &&  !isFFTicketsImplemented(tiReqId))){
					if(type.equalsIgnoreCase("IpReg")) {
						message = new ObjectError("FAF_COMPLETE_IPReg",new String[]{SubmitActivityErrors.TA_FAF_COMPLETE_IPReg},null,null);
						    log.debug(" fafCompleteCheck message is::" + message);
							} else {
								message = new ObjectError("FAF_COMPLETE",new String[]{SubmitActivityErrors.TA_FAF_COMPLETE},null,null);
							   log.debug(" fafCompleteCheck message is::" + message);
						}
				}
				log.info("TechnialArchitectureValidator.fafCompleteCheck() ends " + message);
				return message;
			}
	    
	    
	    private boolean isFFTicketsImplemented(Long tiReqId) {
			FAFRequest fafRequest=new FAFRequest();
			return fafRequest
					.isFFTicketsImplemented(tiReqId);
		}

		private boolean isFireFlowEnbled(Long tiReqId) {
			FAFRequest fafRequest=new FAFRequest();
			TIRequest tiRequest = fafRequest.getTIRequest(tiReqId);
			String fireFlowEnabled = tiRequest.getFireflowFlag();
			return "Y".equalsIgnoreCase(fireFlowEnabled);
		}

		private boolean isRuleChanged(Long tiReqId, String type) {
			FireWallRuleProcess fireWallRuleProcess = new FireWallRuleProcess();
			return fireWallRuleProcess
					.isFireWallRulesHasChanged(tiReqId, type);
			

		}
		
		
		private ObjectError rfcCompleteCheck(Long tiReqId,String conType) throws Exception {
	    	log.info("TechnialArchitectureValidator.rfcCompleteCheck() " + tiReqId);
	    	ObjectError message = null;
			
			String sql = "";
			if(conType.equalsIgnoreCase("IpReg"))
			{
				sql ="select ip_rfc_generate_flag rfc_flag from ti_request where id = ?";
			}
			else
			{
				sql = "select rfc_generate_flag rfc_flag from ti_request where id = ?";
			}
			try {
			    SqlRowSet result  = jdbcTemplate.queryForRowSet(sql,new Object[]{tiReqId});
			    String retValue = null;
			    if (result.next()) {
			    	retValue = result.getString("rfc_flag");
			    }
			    
			  //if ( !(retValue != null && "Y".equals(retValue)) ) {
	            if (retValue != null && "N".equals(retValue)) {
	            	if(conType.equalsIgnoreCase("IpReg")) {
	            		message = new ObjectError("RFC_COMPLETE_IPReg",new String[]{SubmitActivityErrors.TA_RFC_COMPLETE_IPReg},null,null);
	     			    log.debug(" rfcCompleteCheck message is::" + message);
	            	}
	            	else {
	            	message = new ObjectError("RFC_COMPLETE",new String[]{SubmitActivityErrors.TA_RFC_COMPLETE},null,null);
				    log.debug(" rfcCompleteCheck message is::" + message);
	            	}
				} 
		
		
			} catch (Exception e) {
			    log.error(e);
			}
			return message;
	    }
		
		private ObjectError ostiaCompleteCheckForTA(Long tiReqId,String conType) {
			log.info("TechnialArchitectureValidator.ostiaCompleteCheck() " + tiReqId);
			ObjectError message = null;
			
			String isIp = "";
			if(conType.equalsIgnoreCase("IpReg"))
			{
				isIp = "rule.IS_IPREG='Y'";
			}
			else
			{
				isIp = "(rule.IS_IPREG!='Y' or rule.IS_IPREG is null)";
			}
	    	try{
			String sql ="select q.id from con_fw_rule_questionnaire q,con_fw_rule rule, ti_request t,generic_lookup l "+
			"where q.updated_ti_request_id=t.id and rule.id=q.fw_rule_id and q.deleted_ti_request_id is null and q.fw_rule_id is not null and t.id=? and t.priority_id=l.id and q.status='Incomplete' "+ 
			"and l.VALUE1='BAU'"+
			" and "
			+ isIp ;
				SqlRowSet result  = jdbcTemplate.queryForRowSet(sql,new Object[]{tiReqId});
			    log.debug("result is::" + result);
			    if (result != null && result.next()) {
			    	if(conType.equalsIgnoreCase("IpReg"))
					{
			    		message = new ObjectError("OSTIA_COMPLETE_IPReg",new String[]{SubmitActivityErrors.TA_OSTIA_COMPLETE_IPReg},null,null);
					    log.debug(" ostiaCompleteCheck message is::" + message);
					} else {
						message = new ObjectError("OSTIA_COMPLETE",new String[]{SubmitActivityErrors.TA_OSTIA_COMPLETE},null,null);
						    log.debug(" ostiaCompleteCheck message is::" + message);
					}
				
			    }
		
		} catch (Exception e) {
		    log.error(e);
		} 
			log.info("TechnialArchitectureValidator.ostiaCompleteCheck() ends " + message);
			return message;
		}
		
		/**
		 * @param tiReqId
		 * @return
		 */
		private ObjectError fwMigrationCheck(Long tiReqId) {
			  log.info("TechnialArchitectureValidator.fwMigrationCheck() " + tiReqId);
				ObjectError message = null;
				
				int fwMigrationGrpCnt = 0;
				boolean completed = true;
				try {
				    String sql ="select count(cfr.id) from con_fw_rule cfr, ti_request tr " +
				    		" where cfr.policy_group_id = (select id from con_fw_group where firewall_group = " +
				    		" 'FW_RULE_MIGRATION') and tr.fireflow_flag ='Y' and cfr.is_new = 'N' and " +
				    		" cfr.ti_request_id = tr.id and tr.id ="+tiReqId;
				    
				    SqlRowSet result  = jdbcTemplate.queryForRowSet(sql);
				    String retValue = null;
				    if (result.next()) {
				    	fwMigrationGrpCnt = result.getInt(1);
				    	if(fwMigrationGrpCnt > 0)
				    	completed = false;
				    }
				    
					if (!completed) {
						message = new ObjectError("FW_RULE_MIGRATION_CHECK",new String[]{SubmitActivityErrors.TA_FW_RULE_MIGRATION_CHECK},null,null);
					    log.debug(" Fw Rule Migration Check message is::" + message);
					}
				} catch (Exception e) {
				    log.error(e);
				} 
				log.info("TechnialArchitectureValidator.fwMigrationCheck() ends " + message);
				return message;
			}
		

		 private ObjectError deCommissionedAppCheck(Long tiReqId) {
			  log.info("TechnialArchitectureValidator.rfcCompleteCheck() " + tiReqId);
			  ObjectError message = null;
			 
			  try {
				 
				  StringBuffer sql = new StringBuffer();
				  sql.append("SELECT distinct tia.application_name  ");
				  sql.append(" FROM con_fw_rule_application cfra, ti_application tia  ");
				  sql.append(" WHERE cfra.application_id = tia.id  and tia.application_id is not null ");
				  sql.append(" AND cfra.ti_request_id = ? and tia.Is_decommissioned='Y' and cfra.deleted_ti_request_id is null ");

				  SqlRowSet result  = jdbcTemplate.queryForRowSet(sql.toString(),new Object[]{tiReqId});
				  String appMessage = "";
				  while (result.next()) {
					  appMessage = appMessage + result.getString(1) + ",";
				  }
				  if(appMessage.lastIndexOf(",") != -1 && appMessage.length() > 1) appMessage = appMessage.substring(0,appMessage.length()-1 );
				  if (!appMessage.equals("")){
					  message = new ObjectError("application",new String[]{"The following applications are decomissioned [" + appMessage + "].Please remove and add other applications"},null,null);
				  }
			  }
			  catch (Exception e) {
				  log.error(e, e);
			  }  
			  return message;
		  }
		 /**
		     * Gets the Spreadsheet document upload message.
		     *
		     * @param tiReqId the ti req id
		     * @throws Exception the exception
		     * @returns Document Upload Messages.
		     */

		 private List<ObjectError> getDocumentUploadMessageSpreadsheet(Long tiReqId) throws Exception{
			 List<ObjectError> messageList = new ArrayList<ObjectError>();
			 Long conReqId = getConnectionRequestId(tiReqId);
			 String dataSQL= "select CMP_ID from ti_request where id =?";
			 String cmpID = "";
			 try {
			    SqlRowSet result0  = jdbcTemplate.queryForRowSet(dataSQL.toString(),new Object[]{tiReqId});
				if(result0!=null && result0.next()){
					cmpID = result0.getString("CMP_ID");
				}
			 	} catch (Exception e) {
				    log.error(e);
			 	}
			 String docSQL1 = "SELECT A.ID FROM TI_DOC_META_DATA A,TI_REQUEST B WHERE B.ID=A.TI_REQUEST_ID AND A.DOC_TYPE in('Business Request Spreadsheet') AND A.CONNECTION_ID= ?";
			 try {
				 if(cmpID!=null && !cmpID.equalsIgnoreCase("")){
				 SqlRowSet result1  = jdbcTemplate.queryForRowSet(docSQL1.toString(),new Object[]{conReqId});
				 if (!result1.next()) {
			    	messageList.add(new ObjectError("DOCUMENT",new String[]{SubmitActivityErrors.TA_SPREADSHEET_DOCUMENT},null,null));
				  }
				 }
			 	} catch (Exception e) {
				    log.error(e);
				}
			 return messageList;
		 	}
		 
		 /**
		     * Gets the document upload message.
		     *
		     * @param tiReqId the ti req id
		     * @return the document upload message
		     * @throws Exception the exception
		     * @returns Document Upload Messages.
		     */
		    private List<ObjectError> getDocumentUploadMessageTA(Long tiReqId) throws Exception {
			List<ObjectError> messageList = new ArrayList<ObjectError>();
			
			boolean ipPairFlag = false;
			String reqType = null;
			
			Long conReqId = getConnectionRequestId(tiReqId);
			 
		    
		    String docSQL  = (" SELECT 1 FROM CON_FW_RULE WHERE DELETED_TI_REQUEST_ID IS NULL AND (IS_IPREG!='Y' or IS_IPREG is null) AND TI_REQUEST_ID = ?" ); 
		    
			  try {
				 SqlRowSet result0  = jdbcTemplate.queryForRowSet(docSQL.toString(),new Object[]{tiReqId});
			   
			    if (result0.next()) {
				ipPairFlag = true;
			     }
			   } catch (Exception e) {
				    log.error(e);
				}
			
			    log.debug("Network Data present::" + ipPairFlag + "::For Connection Id-- " + conReqId);

			    String docSQL1 = ("SELECT A.ID FROM TI_DOC_META_DATA A,TI_REQUEST B WHERE B.ID=A.TI_REQUEST_ID AND A.DOC_TYPE in('DetailedLevelDesignDocument','FWDetailLevelDesignDocument') AND A.CONNECTION_ID= ?");  
			   
			    try {
			    if (ipPairFlag) {
			    	SqlRowSet result1  = jdbcTemplate.queryForRowSet(docSQL1.toString(),new Object[]{conReqId});
				
			    if (!result1.next()) {
			    	messageList.add(new ObjectError("DOCUMENT",new String[]{SubmitActivityErrors.TA_DOCUMENT},null,null));
				  }
			     }
			    } catch (Exception e) {
				    log.error(e);
				}
			

			    String dataSQL= " select CMP_ID, SERVICE_NOW_ID from ti_request where id =? ";
				
				String cmpID = "", serviceNowID = "";
				
			    try {
			    
			    SqlRowSet result2  = jdbcTemplate.queryForRowSet(dataSQL.toString(),new Object[]{tiReqId});
				if(result2!=null && result2.next()){
					cmpID = result2.getString("CMP_ID");
					serviceNowID = result2.getString("SERVICE_NOW_ID");
				}
			    } catch (Exception e) {
				    log.error(e);
				}
			
			
			   /*try {

				 if(cmpID != null && !cmpID.isEmpty()){
					//CMP Document
					String  cmpDocumentSQL= (" SELECT DOC_TYPE FROM TI_DOC_META_DATA WHERE TI_REQUEST_ID= ? and DOC_TYPE='Business Request Document'");
					SqlRowSet result2  = jdbcTemplate.queryForRowSet(cmpDocumentSQL.toString(),new Object[]{tiReqId});
					if(!result2.next()){
					    messageList.add(new ObjectError("CMP_DOCUMENT",new String[]{SubmitActivityErrors.TA_CMP_DOCUMENT},null,null));
					}
				}
			    log.debug("messageList Size::" + messageList.size());
			   } catch (Exception e) {
			    log.error(e);
			   } */
			   
			   //Termination Evidence Document
			   String  reqTypeQuery= (" select req.request_type type " +
					   "from ti_request tireq,ti_request_type req " +
					   "where tireq.ti_request_type_id =req.id and tireq.id = ? ");
			    try {

				   //Retrieving request type
					
					SqlRowSet result3  = jdbcTemplate.queryForRowSet(reqTypeQuery.toString(),new Object[]{tiReqId});
					if(result3!=null && result3.next()){
					reqType = result3.getString(1);
					}
					
					log.debug("messageList Size::" + messageList.size());
			    	} catch (Exception e) {
				    log.error(e);
			    	} 
					
					//Termination Evidence Document check 
					try {
						SqlRowSet result4 =null;	
					if(reqType.equalsIgnoreCase("Terminate")){
						String terminateDocQuery = (" SELECT DOC_TYPE FROM TI_DOC_META_DATA WHERE TI_REQUEST_ID= ? and DOC_TYPE='Termination Evidence Document'");
						 result4  = jdbcTemplate.queryForRowSet(terminateDocQuery.toString(),new Object[]{tiReqId});
						
					}
					
					if(result4 !=null && !result4.next()){
						messageList.add(new ObjectError("TERMINATION_EVIDENCE",new String[]{SubmitActivityErrors.TA_TERMINATION_EVIDENCE},null,null));
					}
				
			    log.debug("messageList Size::" + messageList.size());
			   } catch (Exception e) {
			    log.error(e);
			   }  
			return messageList;
		   }
		    
		    
		    /**
		     * Gets the certify conf msg.
		     *
		     * @param tiReqId the ti req id
		     * @return Confirmation message for NOT CERTIFIED RELATIONSHIP
		     */
		   /* private List<ObjectError> getCertifyConfMsg(Long tiReqId) {
			log.debug("getCertifyConfMsg START::");
			StringBuffer certifySQL = new StringBuffer();
			List<ObjectError> messageList = new ArrayList<ObjectError>();
			
			try {
			    certifySQL.append(" SELECT 1 FROM C3PAR.TI_REQUEST A,C3PAR.TI_PROCESS B,C3PAR.RELATIONSHIP C,C3PAR.GENERIC_LOOKUP D WHERE");
			    certifySQL.append(" A.ID=" + tiReqId + " AND B.ID=A.PROCESS_ID AND B.RELATIONSHIP_ID=C.ID AND D.ID=A.PRIORITY_ID AND D.VALUE1 IN('BUSCRIT','EMER') AND ");
			    certifySQL.append(" B.PROCESS_ACTIVITY_MODE IN ('NEW','REWORK') AND C.STATUS='NOT CERTIFIED'");

			    log.debug("(getOstiaConfirmationMsg)ostiaSQL::::::" + certifySQL.toString());
			    
			    SqlRowSet result =jdbcTemplate.queryForRowSet(certifySQL.toString());
			    if (result.next()) {
			    messageList.add(new ObjectError("CERTIFYCONFIRMATION",new String[]{SubmitActivityErrors.TA_CERTIFYCONFIRMATION},null,null));
			    }
			    log.debug("messageList Size::" + messageList.size());
			} catch (Exception e) {
			    log.error(e);
			} 

			log.debug("getCertifyConfMsg END::");
			return messageList;
		    }*/


		    /**
		     * Gets the appsense policy tab message.
		     *
		     * @param conReqId the con req id
		     * @return the appsense policy tab message
		     * @throws Exception the exception
		     */
		    private ObjectError getAppsensePolicyTabMessage(Long conReqId) throws Exception {
		    ObjectError message = null;
			String appsensePolicyTab = null;
			List appsensePolicyId = new ArrayList();
			
			try {
			    appsensePolicyTab = "SELECT ID FROM APS_APPSENSE_POLICY WHERE PROCESS_ID=" + conReqId + " AND RECORD_TYPE='A'";
			    SqlRowSet result =jdbcTemplate.queryForRowSet(appsensePolicyTab.toString());
			    log.debug("result is::" + result);
			    if (result.next()) {
				if (result.getString(1) != null) {
				    appsensePolicyId.add(result.getString(1));

				}
			    } else {
				log.debug("Inside MAP MESSAGE");
				message = new ObjectError("APPSENSEPOLICY",new String[]{SubmitActivityErrors.TA_APPSENSEPOLICY},null,null);
				log.debug("Inside MAP MESSAGE" + message);
			    }
			} catch (Exception e) {
			    log.error(e);
			} 
			return message;
		    }
		    
		    
		    /**
		     * Gets the appsense user tab message.
		     *
		     * @param conReqId the con req id
		     * @return the appsense user tab message
		     * @throws Exception the exception
		     */
		    private ObjectError getAppsenseUserTabMessage(Long conReqId) throws Exception {
		    ObjectError message = null;
			String appsenseUserTab = null;
			List appsenseUserId = new ArrayList();
			try {
			    appsenseUserTab = "SELECT ID FROM APS_APPSENSE_POLICY WHERE PROCESS_ID=" + conReqId + " AND RECORD_TYPE='U'";
			    SqlRowSet result =jdbcTemplate.queryForRowSet(appsenseUserTab.toString());
			    log.debug("result is::" + result);
			    if (result.next()) {
				appsenseUserId.add(result.getString(1));
			    } else {
				log.debug("Inside MAP MESSAGE");
				message = new ObjectError("APPSENSEUSER",new String[]{SubmitActivityErrors.TA_APPSENSEUSER},null,null);
				log.debug("Inside MAP MESSAGE" + message);
			    }


			} catch (Exception e) {
			    log.error(e);
			} 
			return message;
		    }
		    
		    

		    /**
		     * Gets the appsense ostia tab message.
		     *
		     * @param conReqId the con req id
		     * @return the appsense ostia tab message
		     * @throws Exception the exception
		     */
		    private ObjectError getAppsenseOstiaTabMessage(Long conReqId) throws Exception {
		    	
		    ObjectError message = null;
			String appsenseOstiaTab = null;
			int count = 0;
			int riskPort_Count = 0;
			try {
			    appsenseOstiaTab="SELECT count(*) FROM  CON_OSTIA_GROUP WHERE ID IN "+
			    "(SELECT PORT_MASTER.ostia_group_id FROM APS_PORT_MASTER PORT_MASTER WHERE PORT_MASTER.ID IN"+
			    "(SELECT aps_port_master_id FROM APS_APPSENSE_POLICY  WHERE PROCESS_ID ='"+conReqId+"'"+
			    " AND RECORD_TYPE='A' AND aps_port_master_id is not null) "+
			    "AND PORT_MASTER.ostia_group_id is not null AND PORT_MASTER.port_lookup_id IN ("+
			    "SELECT PORT.ID FROM CON_PORT_LOOKUP PORT WHERE PORT.ID IN("+
			    "SELECT PORT_MASTER1.port_lookup_id FROM APS_PORT_MASTER PORT_MASTER1 WHERE PORT_MASTER1.ID IN"+
			    "(SELECT aps_port_master_id FROM APS_APPSENSE_POLICY  WHERE PROCESS_ID ='"+conReqId+"' AND RECORD_TYPE='A'" +
			    " AND aps_port_master_id is not null )) AND port.is_blacklisted ='Y' ))" +
			    " AND (status IS NULL OR status ='Incomplete')";
			    
			    SqlRowSet result0 =jdbcTemplate.queryForRowSet(appsenseOstiaTab.toString());
			    
			    log.debug("result is::" + result0);
			    if (result0.next()) {
				count = result0.getInt(1);
				log.debug("Ostia Count " + count);
			    }
			    String riskPortSQL="SELECT count(*)FROM APS_PORT_MASTER PORT_MASTER WHERE PORT_MASTER.ID IN"+
			    "(SELECT aps_port_master_id FROM APS_APPSENSE_POLICY  WHERE PROCESS_ID ='"+conReqId+"'"+
			    "AND RECORD_TYPE='A' AND aps_port_master_id is not null) "+
			    "AND PORT_MASTER.port_lookup_id IN (SELECT PORT.ID FROM CON_PORT_LOOKUP PORT WHERE PORT.ID IN("+
			    " SELECT PORT_MASTER1.port_lookup_id FROM APS_PORT_MASTER PORT_MASTER1 WHERE PORT_MASTER1.ID IN"+
			    "(SELECT aps_port_master_id FROM APS_APPSENSE_POLICY  WHERE PROCESS_ID ='"+conReqId+"'"+
			    "AND RECORD_TYPE='A'AND aps_port_master_id is not null )) AND port.is_blacklisted ='Y') AND PORT_MASTER.ostia_group_id is NULL ";
			    
			    SqlRowSet result1 =jdbcTemplate.queryForRowSet(riskPortSQL.toString());
			    while (result1.next()) {
				riskPort_Count = result1.getInt(1);

			    }
			    if (count > 0 || riskPort_Count > 0) {
			    message = new ObjectError("APPSENSEOSTIA",new String[]{SubmitActivityErrors.TA_APPSENSEOSTIA},null,null);
				log.debug("Inside MAP MESSAGE" + message);
			    }
			} catch (Exception e) {
			    log.error(e);
			} 
			return message;
		    }
		    
		    /**
		     * Gets the manage proxy filter message.
		     *
		     * @param conReqId the con req id
		     * @return the manage proxy filter message
		     * @throws Exception the exception
		     */
		    private ObjectError getManageProxyFilterMessage(Long conReqId) throws Exception {
		    ObjectError message = null;
			String manageProxy = null;
			String manageProxyFilter = null;
			
			try {
			    manageProxy="select count(*)  from prx_proxy_filter filter where filter.proxy_inst_mst_id in" +
			    " (select id from prx_instance_master where prx_instance_master.record_type='BASIC') and "+
			    " process_id='"+conReqId+"'";
			    manageProxyFilter = " and filter.app_id is NULL";
			   
			    SqlRowSet result0 =jdbcTemplate.queryForRowSet(manageProxy.toString());
			    if (result0.next()) {
				int count = result0.getInt(1);
				log.debug("result is::" + result0.getInt(1));
				if (count > 0) {
				    String sql = manageProxy + manageProxyFilter;
				    SqlRowSet result1 =jdbcTemplate.queryForRowSet(sql);
				    if (result1.next()) {
					if (result1.getInt(1) > 0) {
					    log.debug("Inside MAP MESSAGE");
					    message = new ObjectError("PROXYFILTER",new String[]{SubmitActivityErrors.TA_PROXYFILTER},null,null);
					    log.debug("Inside MAP MESSAGE" + message);
					} else {
					    log.debug("Manage Proxy Filter present ::"+result1.getInt(1)); }
				    }
				}

			    }
			} catch (Exception e) {
			    log.error(e);
			} 
			return message;
		    }
		   
		  
		    /**
		     * Gets the director emp msg.
		     *
		     * @param conReqId the con req id
		     * @param tiReqId the ti req id
		     * @return the director emp msg
		     * @throws Exception the exception
		     */
		/*    private List<ObjectError> getDirectorEmpMsgTA(Long conReqId, Long tiReqId) throws Exception {
		    	
			StringBuffer conSQL = new StringBuffer();
			List<ObjectError> messageList = new ArrayList<ObjectError>();

			String relationshipType = getRelationshipType(conReqId);

			StringBuffer tiReqConnSQL = new StringBuffer();
			StringBuffer tContactsSQL = new StringBuffer();
			StringBuffer rContactsSQL = new StringBuffer();

			try {

			    String queryMaxConnection = " (select planning_id from ti_request_planning_xref where ti_request_id =" + tiReqId + ")";
			    String empType = "(select user_id from ti_request where process_id=" + conReqId + " and version_number=(select max(version_number) from ti_Request where process_id=" + conReqId + "))";

			    tContactsSQL.append("select count(*) from citi_contact where id in ( ");
			    tContactsSQL.append("select citi_contact_id from con_req_citi_contact_xref where citi_contact_id is not null and ");
			    tContactsSQL.append("request_id= " + queryMaxConnection + "  and UPPER(primary_contact)='Y' and role_id in( ");
			    tContactsSQL.append("select id from role where name ='Director')) and (UPPER(employee_type)='EMPLOYEE' or  ");
			    tContactsSQL.append("UPPER(employee_type)='E' ) having count(*)>0");

			    log.debug("Query in the tContactsSQL:: " + tContactsSQL.toString());

			    rContactsSQL.append("select count(*) from citi_contact where id in ( ");
			    rContactsSQL.append("select citi_contact_id from CON_REQ_CIT_RQCON_XREF where citi_contact_id is not null and ");
			    rContactsSQL.append("request_id= " + queryMaxConnection + "  and UPPER(primary_contact)='Y' and role_id in( ");
			    rContactsSQL.append("select id from role where name ='Director')) and (UPPER(employee_type)='EMPLOYEE' or  ");
			    rContactsSQL.append("UPPER(employee_type)='E' ) having count(*)>0");

			    log.debug("Requester Contacts SQL::" + rContactsSQL.toString());

			    tiReqConnSQL.append(" SELECT c.PRIORITY_ID,f.VALUE1 ");
			    tiReqConnSQL.append(" FROM TI_REQUEST c , GENERIC_LOOKUP f ");
			    tiReqConnSQL.append(" WHERE C.ID = " + tiReqId + " AND  f.ID=c.PRIORITY_ID ");
			    log.debug("Query in tiReqConnSQL::: " + tiReqConnSQL.toString());
			    
			    SqlRowSet result =jdbcTemplate.queryForRowSet(tiReqConnSQL.toString());

			    if (result != null && result.next()) {
				log.debug("Value of the priority type::: " + result.getString("VALUE1"));
				if ((result.getString("VALUE1").equals("BUSCRIT") || result.getString("VALUE1").equals("EMER"))) {
					if(relationshipType.equalsIgnoreCase("THIRD_PARTY") || relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)|| relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE) || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)){
					SqlRowSet tiReqResult = jdbcTemplate.queryForRowSet(tContactsSQL.toString());
					if (!tiReqResult.next()) {
						messageList.add(new ObjectError("DIRECTOR",new String[]{SubmitActivityErrors.TA_DIRECTOR},null,null));
					}
				    } else if (relationshipType.equalsIgnoreCase("CITI_CON")) {
				    SqlRowSet tiReqResult = jdbcTemplate.queryForRowSet(rContactsSQL.toString());
					if (!tiReqResult.next()) {
						messageList.add(new ObjectError("DIRECTOR",new String[]{SubmitActivityErrors.TA_DIRECTOR},null,null));
					}
				    } else if (relationshipType.equalsIgnoreCase("U_TURN")) {
				    	SqlRowSet tiReqResult = jdbcTemplate.queryForRowSet(rContactsSQL.toString());
					if (!tiReqResult.next()) {
						messageList.add(new ObjectError("DIRECTOR",new String[]{SubmitActivityErrors.TA_DIRECTOR},null,null));
					}
				    }
				}
			    }

			    log.debug("messageList Size::" + messageList.size());

			} catch (Exception e) {
			    log.error(e);
			} 

			return messageList;
		    }*/
		    /**
		     * Gets the document upload message.
		     *
		     * @param tiReqId the ti req id
		     * @return the document upload message
		     * @throws Exception the exception
		     * @returns Document Upload Messages.
		     */
		    private List<ObjectError> getDirApprovalDocUploadMessage(Long tiReqId)throws Exception{
			
			StringBuffer bauSQL=new StringBuffer();
			StringBuffer docSQL=new StringBuffer();
			List<ObjectError> messageList=new ArrayList<ObjectError>();
			
			try {
				bauSQL.append(" SELECT 1 FROM TI_REQUEST A,GENERIC_LOOKUP B WHERE B.VALUE1='BAU' AND A.ID=");
			    bauSQL.append(tiReqId+" AND A.PRIORITY_ID=B.ID");
			    docSQL.append(" select a.DOC_NAME from TI_DOC_META_DATA a,GENERIC_LOOKUP b,TI_REQUEST c where a.TI_REQUEST_ID=");
			    docSQL.append(tiReqId+" and a.TI_REQUEST_ID=c.ID and b.ID=c.PRIORITY_ID and b.VALUE1 in ('EMER','BUSCRIT') and a.DOC_TYPE='Director Approval'");
			    
			    SqlRowSet result0 =jdbcTemplate.queryForRowSet(bauSQL.toString());
			    if(result0.next()){
				log.debug("PRIORITY IS BAU");
			    }else{
			    SqlRowSet result1 =jdbcTemplate.queryForRowSet(docSQL.toString());
				if(!result1.next()){
					messageList.add(new ObjectError("DOCUMENT_DIRAPP",new String[]{SubmitActivityErrors.TA_DOCUMENT_DIRAPP},null,null));
				}
			    }

			    log.debug("messageList Size::"+messageList.size());

			}catch (Exception e) {
			    log.error(e);
			}
			return messageList;
		    }


		    /**
		     * Gets the request_ type.
		     *
		     * @param conReqId the con req id
		     * @return the request_ type
		     * @throws Exception the exception
		     */
		    private String getRequest_Type(Long conReqId) throws Exception {
			String relation_type_con = null;
			String reqType = null;
			try {
			    relation_type_con = "SELECT B.RELATIONSHIP_TYPE FROM CON_REQ A,RELATIONSHIP B WHERE A.RELATIONSHIP_ID=B.ID AND A.ID= " + conReqId;
			    log.debug("relation_type_con::" + relation_type_con);
			    SqlRowSet result =jdbcTemplate.queryForRowSet(relation_type_con.toString());
			    if (result.next()) {
				reqType = "ConnectionRequest";
			    } else {
				reqType = "IPRequest";
			    }

			} catch (Exception e) {
			    log.error(e);
			} 
			log.debug("getIPPairsTabMessage End::");
			return reqType;
		    }
		    
		    

		    private List<ObjectError> getDocumentACLChangesUploadMessage(Long conReqID, Long tiReq) throws Exception {
		    	log.info("conReqID ::" + conReqID + "::tiReq::" + tiReq);
		    	String aclChangeSQL=null;
		    	List<ObjectError> messageList = new ArrayList<ObjectError>();
		    	
		    	boolean aclFlag = false;
		    	String sql = null;
		    	try {
		    	    sql = "select acl_name, acl_device_routers, acl_justification from acl_variance where process_id=? and ti_request_id=? "
		    		+	" minus"
		    		+	" select acl_name, acl_device_routers, acl_justification from acl_variance where process_id=? and"
		    		+	" ti_request_id=(select max(ti_request_id) from acl_variance where process_id=? and ti_request_id != ?)";

		    	    aclChangeSQL = "select count(tdmd.doc_type) from TI_DOC_META_DATA tdmd,acl_variance acv where " +
		    	    " acv.process_id=tdmd.connection_id and tdmd.doc_type = 'ACL_Changes' and acv.process_id=? " +
		    	    " and acv.ti_request_id=? and acv.ti_request_id=tdmd.ti_request_id "+
		    	    " having count(tdmd.doc_type)>=1";
		    	    
		    	    SqlRowSet result0 =jdbcTemplate.queryForRowSet(sql.toString(),new Object[]{ Long.valueOf(conReqID), Long.valueOf(tiReq),Long.valueOf(conReqID),Long.valueOf(conReqID),Long.valueOf(tiReq)});
		    	    if (result0.next()) {
		    		aclFlag = true;
		    	    }
		    	    if (aclFlag) {
		    	    SqlRowSet result1 =jdbcTemplate.queryForRowSet(aclChangeSQL.toString(),new Object[]{Long.valueOf(conReqID),tiReq});
		    		if (!result1.next()) {
		    			messageList.add(new ObjectError("DOCUMENT_ACL_CHANGE",new String[]{SubmitActivityErrors.TA_DOCUMENT_ACL_CHANGE},null,null));
		    		}
		    	    }

		    	    log.debug("messageList Size::" + messageList.size());

		    	} catch (Exception e) {
		    	    log.error(e);
		    	} 
		    	return messageList;
		        }
		    /**
		     * Gets the document proxy upload message.
		     *
		     * @param conReqID the con req id
		     * @param tiReq the ti req
		     * @return the document proxy upload message
		     * @throws Exception the exception
		     */
		    private List<ObjectError> getDocumentProxyUploadMessage(Long conReqID, Long tiReq) throws Exception {
			log.info("conReqID ::" + conReqID + "::tiReq::" + tiReq);
			String docSQL = null;
			List<ObjectError> messageList = new ArrayList<ObjectError>();
			boolean sockFlag = false;
			String sql = null;
			try {
			    sql = "select filter.id  from prx_proxy_filter filter where filter.proxy_inst_mst_id in (select id from prx_instance_master where upper(prx_instance_master.record_type) in('SOCKS','PLUG')) and filter.process_id=" + conReqID;
			    docSQL = "select TDMA.id  from prx_proxy_filter filter,TI_DOC_META_DATA TDMA where filter.proxy_inst_mst_id " +
			    "in (select id from prx_instance_master where upper(prx_instance_master.record_type)in('SOCKS','PLUG')) and " +
			    "filter.process_id=TDMA.connection_id  AND TDMA.DOC_TYPE='ProxyDetailLevelDesignDocument' and filter.process_id="+conReqID;
			    
			    SqlRowSet result0 =jdbcTemplate.queryForRowSet(sql.toString());
			    
			    if (result0.next()) {
				sockFlag = true;
			    }
			    if (sockFlag) {
			    SqlRowSet result1 =jdbcTemplate.queryForRowSet(docSQL.toString());
			    
				if (!result1.next()) {
					messageList.add(new ObjectError("DOCUMENT_PROXY",new String[]{SubmitActivityErrors.TA_DOCUMENT_PROXY},null,null));
				}
			    }

			    log.debug("messageList Size::" + messageList.size());

			} catch (Exception e) {
			    log.error(e);
			}
			return messageList;
		    }
	
		    /**
		     * Gets the manage proxy socks message.
		     *
		     * @param conReqId the con req id
		     * @return the manage proxy socks message
		     * @throws Exception the exception
		     */
		    private ObjectError getManageProxySocksMessage(Long conReqId) throws Exception {
		    ObjectError message = null;
			String manageProxy = null;
			String manageProxySocks = null;
			
			try {
			    manageProxy="select count(*)  from prx_proxy_filter filter where filter.proxy_inst_mst_id in" +
			    " (select id from prx_instance_master where upper(prx_instance_master.record_type)=upper('SOCKS')) and "+
			    " process_id='"+conReqId+"'";
			    manageProxySocks = " and filter.app_id is NULL";
			    SqlRowSet result0 =jdbcTemplate.queryForRowSet(manageProxy.toString());
			    if (result0.next()) {
				int count = result0.getInt(1);
				log.debug("result is::" + result0.getInt(1));
				if (count > 0) {
				    String sql = manageProxy + manageProxySocks;
				    SqlRowSet result1 =jdbcTemplate.queryForRowSet(sql.toString());
				    if (result1.next()) {
					if (result1.getInt(1) > 0) {
					    log.debug("Inside Proxy Socks MAP MESSAGE");
					    message = new ObjectError("MANAGEPROXYSOCKS",new String[]{SubmitActivityErrors.TA_MANAGEPROXYSOCKS},null,null);
					    log.debug("Inside Proxy Socks MAP MESSAGE" + message);
					    log.debug("Manage Proxy Socks present ::" + result1.getInt(1));
					} else {

					}
				    }
				}
			    }
			} catch (Exception e) {
			    log.error(e);
			} 
			return message;
		    }


		    /**
		     * Gets the manage proxy plug message.
		     *
		     * @param conReqId the con req id
		     * @return the manage proxy plug message
		     * @throws Exception the exception
		     */
		    private ObjectError getManageProxyPlugMessage(Long conReqId) throws Exception {
		    ObjectError message = null;
			String manageProxy = null;
			String manageProxyPlug = null;
			
			try {
			    manageProxy="select count(*)  from prx_proxy_filter filter where filter.proxy_inst_mst_id in" +
			    " (select id from prx_instance_master where upper(prx_instance_master.record_type)=upper('PLUG')) and "+
			    " process_id='"+conReqId+"'";
			    manageProxyPlug = " and filter.app_id is NULL";
			    SqlRowSet result0 =jdbcTemplate.queryForRowSet(manageProxy.toString());
			    if (result0.next()) {
				int count = result0.getInt(1);
				log.debug("result is::" + result0.getInt(1));
				if (count > 0) {
				    String sql = manageProxy + manageProxyPlug;
				    SqlRowSet result1 =jdbcTemplate.queryForRowSet(sql.toString());
				    if (result1.next()) {
					if (result1.getInt(1) > 0) {
					    log.debug("Inside Proxy Plug MAP MESSAGE");
					    message = new ObjectError("MANAGEPROXYPLUG",new String[]{SubmitActivityErrors.TA_MANAGEPROXYPLUG},null,null);
					    log.debug("Inside Proxy Plug MAP MESSAGE" + message);

					} else {
					    log.debug("Manage Proxy Plug present ::" + result1.getInt(1));
					}
				    }
				}

			    }
			} catch (Exception e) {
			    log.error(e);
			} 
			return message;
		    }
		    
	private ObjectError getManageProxyRFCMessage(Long tireqid) throws Exception {
	    ObjectError message = null;
		
		try {	
			/*StringBuffer sb = new StringBuffer();
			sb.append(" (select PROXY_INST_MST_ID,APP_NAME,URL,DOMAIN_NAME,STATEMENT,SOURCE_IP,EXTERNAL_IP,FILE_TRANSFER,FREQUENCY,FILE_SIZE,PORT,REQUEST_TYPE,APP_ID,aps_ad_group_id, statement_redirect,INTERNET_ACCESS ");
			sb.append(" from prx_proxy_filter where ti_request_id="+tireqid.longValue()+" and UPPER(action) = 'ADD' ");
			sb.append(" minus ");
		    sb.append(" select PROXY_INST_MST_ID,APP_NAME,URL,DOMAIN_NAME,STATEMENT,SOURCE_IP,EXTERNAL_IP,FILE_TRANSFER,FREQUENCY,FILE_SIZE,PORT,REQUEST_TYPE,APP_ID,aps_ad_group_id, statement_redirect,INTERNET_ACCESS ");
		    sb.append(" from prx_paf_state where process_id=(select max(process_id) from ti_request where ti_request_id = "+tirequestid.longValue()+")) ");
			sb.append(" union ");
			sb.append(" ((select PROXY_INST_MST_ID,APP_NAME,URL,DOMAIN_NAME,STATEMENT,SOURCE_IP,EXTERNAL_IP,FILE_TRANSFER,FREQUENCY,FILE_SIZE,PORT,REQUEST_TYPE,APP_ID,aps_ad_group_id, statement_redirect,INTERNET_ACCESS ");
			sb.append(" from prx_paf_state where process_id=(select max(process_id) from ti_request where ti_request_id = "+tirequestid.longValue()+") "); 
			sb.append(" minus ");
			sb.append(" select PROXY_INST_MST_ID,APP_NAME,URL,DOMAIN_NAME,STATEMENT,SOURCE_IP,EXTERNAL_IP,FILE_TRANSFER,FREQUENCY,FILE_SIZE,PORT,REQUEST_TYPE,APP_ID,aps_ad_group_id, statement_redirect,INTERNET_ACCESS ");
			sb.append(" from prx_proxy_filter where ti_request_id="+tireqid.longValue()+" and UPPER(action) = 'ADD') ");
			sb.append(" union ");
			sb.append(" select PROXY_INST_MST_ID,APP_NAME,URL,DOMAIN_NAME,STATEMENT,SOURCE_IP,EXTERNAL_IP,FILE_TRANSFER,FREQUENCY,FILE_SIZE,PORT,REQUEST_TYPE,APP_ID,aps_ad_group_id, statement_redirect,INTERNET_ACCESS ");
			sb.append(" from prx_proxy_filter where ti_request_id="+tireqid.longValue()+" and UPPER(action) = 'DELETE' and nvl(is_deleted,'N') <> 'Y' ) ");
	
		    SqlRowSet result0 =jdbcTemplate.queryForRowSet(sb.toString());			    
		    if (result0.next()) {*/
			
		    SqlRowSet result1 =jdbcTemplate.queryForRowSet("select proxy_rfc_generate_flag from ti_request where id = "+tireqid.longValue());
		    if (result1.next()) {
		    	String proxyflag = result1.getString(1);
		    	if(proxyflag != null && proxyflag.equalsIgnoreCase("N")){
				    message = new ObjectError("MANAGEPROXYRFC",new String[]{SubmitActivityErrors.TA_MANAGEPROXYRFC},null,null);
				    log.debug("Inside Proxy MANAGEPROXYRFC MESSAGE" + message);
		    	}
		    }
		} catch (Exception e) {
		    log.error(e);
		} 
		
		return message;
    }
	
	 private List<ObjectError> getUturnValidation(Long tiReqId){
		    log.debug("ISOValidator getDocumentUploadMessage...");
		    
			StringBuffer docSQL=new StringBuffer();
			
			List<ObjectError> messageList=new ArrayList<ObjectError>();
			
			try {
			    docSQL.append(" SELECT b.ID FROM TI_DOC_META_DATA A, ti_process B, relationship C, ti_process_type D, ti_request E  WHERE a.connection_id = b.id  " +
			    		"AND b.relationship_id = c.id and c.relationship_type = 'U_TURN'  and b.process_type_id = d.id  and d.process_type = 'Connection'" +
			    		"AND A.DOC_TYPE     ='Technical Notification 1' AND b.ID=e.process_id AND e.id = ? INTERSECT  SELECT b.ID " +
			    		"FROM TI_DOC_META_DATA A, ti_process B, relationship C, ti_process_type D, ti_request E  WHERE a.connection_id = b.id  " +
			    		"AND b.relationship_id = c.id and c.relationship_type = 'U_TURN'  and b.process_type_id = d.id  and d.process_type = 'Connection' " +
			    		"AND A.DOC_TYPE     ='Technical Notification 2' AND b.ID=e.process_id AND e.id = ?");
			    
			    SqlRowSet result  = jdbcTemplate.queryForRowSet(docSQL.toString(),new Object[]{Long.valueOf(tiReqId),Long.valueOf(tiReqId)});
			    
			    if(!result.next()){
			    	
			    docSQL=new StringBuffer();	
			    docSQL.append("select a.id from ti_request a, ti_process b, relationship c where a.process_id = b.id and b.relationship_id = c.id and c.relationship_type = 'U_TURN' and a.id = ?");
				
			    SqlRowSet result1  = jdbcTemplate.queryForRowSet(docSQL.toString(),new Object[]{Long.valueOf(tiReqId)});
			    
				if(result1.next()){
					messageList.add(new ObjectError("ISO_DOCUMENT",new String[]{SubmitActivityErrors.ISO_DOCUMENT},null,null));
				}
			    }
			    
			    log.info("messageList Size::"+messageList.size());	

			}catch (Exception e) {
			    log.error(e,e);
			}
			return messageList;
		    }
		    
	 private boolean isBusinessOwnerPrimaries(final Long tiRequestId,String relationType){
			log.info("Entering BJValidator isBusinessOwnerPrimaries.");
			log.debug("Relation Type for Connection: "+relationType);
			StringBuilder query = new StringBuilder();
			query.append(" SELECT count(*) from (			 ");
			query.append(" SELECT DISTINCT 			         ");
			query.append("   upper(cc.first_name),            ");
			query.append("   upper(cc.last_name),                    ");
			query.append("   cc.goc_code,                     ");
			query.append("   cc.man_segment_id,               ");
			query.append("   cc.dsmt_region_name,             ");
			query.append("   cc.dsmt_sector_name,             ");
			query.append("   cc.dsmt_business_unit_name,      ");
			query.append("   cc.sso_id					      ");
			query.append(" FROM ti_process tp                 ");
			query.append(" JOIN ti_request tr                 ");
			query.append(" ON tp.id=tr.process_id             ");
			query.append(" JOIN ti_request_planning_xref trpx ");
			query.append(" ON trpx.ti_request_id=tr.id        ");
			query.append(" JOIN planning p                    ");
			query.append(" ON p.id=trpx.planning_id           ");
			//For Target/Requester Contacts check
			if(C3parStaticNames.THIRD_PARTY.equals(relationType) || C3parStaticNames.TEMPLATE_OBJ.equals(relationType) ||
					C3parStaticNames.IP_TEMPLATE.equals(relationType) || C3parStaticNames.PORT_TEMPLATE.equals(relationType) || 
					"TARGET".equalsIgnoreCase(relationType) ){
				query.append(" JOIN CON_REQ_CITI_CONTACT_XREF cr  "); //For TargetContact Screen
			} else {
				query.append(" JOIN CON_REQ_CIT_RQCON_XREF cr  "); 
			}
			query.append(" ON cr.request_id=p.id              ");
			query.append(" JOIN citi_contact cc               ");
			query.append(" ON cc.id=cr.citi_contact_id        ");
			query.append(" JOIN role r                        ");
			query.append(" ON cr.role_id = r.id               ");
			query.append(" WHERE r.name  = 'Business_Owner'   ");
			query.append(" AND cr.primary_contact = 'Y'    	  ");
			query.append(" AND tr.id     ="+tiRequestId+" )    ");
			log.debug("Query to get Business Owner details: "+query.toString());
			boolean flag=false;
			try {
				List<Map<String,Object>> citiContactList = jdbcTemplate.queryForList(query.toString());
				if(citiContactList!=null && citiContactList.size()>1){
					flag=true;
					log.debug("Multiple Business Owners are Primary...");
				}
			} catch (DataAccessException e) {
				log.error("Exception in BJValidator isBusinessOwnerPrimaries.",e);
			}
			log.info("Exiting BJValidator isBusinessOwnerPrimaries.");
			return flag;
		}
}
