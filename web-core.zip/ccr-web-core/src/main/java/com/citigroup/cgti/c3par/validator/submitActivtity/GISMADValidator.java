package com.citigroup.cgti.c3par.validator.submitActivtity;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;

import com.citigroup.cgti.c3par.comments.domain.SubmitActivityErrors;


/**
 * @nc43495
 */
public class GISMADValidator implements Validator {

    /** The log. */
    private static Logger log = Logger.getLogger(GISMADValidator.class);

    
    private JdbcTemplate jdbcTemplate;
    
   public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}



	/**
    * 
    * @param tiReqId
    * @return
    */
    public List<ObjectError> getRisoApprovalDocument(Long tiReqId) {
    	List<ObjectError> messageList = new ArrayList<ObjectError>();
    	    	
    	try {
				String terminateDocQuery = (" SELECT DOC_TYPE FROM TI_DOC_META_DATA WHERE TI_REQUEST_ID= ? and DOC_TYPE='RISO Approval'");
				 SqlRowSet result0  = jdbcTemplate.queryForRowSet(terminateDocQuery,new Object[]{tiReqId});
			if(!result0.next()){
				ObjectError msg = new ObjectError("RISO_Approval",new String[]{SubmitActivityErrors.RISO_Approval},null,null);
			    log.debug("message is::"+msg);
			    messageList.add(msg);
			}
		
	    log.debug("messageList Size::" + messageList.size());
	   } catch (Exception e) {
	    log.error(e,e);
	   } 
		return messageList;
   }


	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub
		
	}

	
 }
