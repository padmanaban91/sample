package com.citigroup.cgti.c3par.controller.communication;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CmpReqIdSearchProcess;
import com.citigroup.cgti.c3par.controller.relationship.ThirdPartySearchController;

@Controller
public class CmpReqIdSearchController {

	private static Logger log = Logger.getLogger(ThirdPartySearchController.class);

	@RequestMapping(value = "/loadCmpReqIdPopUp.act", method = {RequestMethod.POST, RequestMethod.GET })
	public String loadCmpReqIdPopUp(ModelMap model,	@ModelAttribute("cmpReqIdSearchProcess") CmpReqIdSearchProcess cmpReqIdSearchProcess, HttpServletRequest request) {

		cmpReqIdSearchProcess = new CmpReqIdSearchProcess();
		model.addAttribute("cmpReqIdSearchProcess", cmpReqIdSearchProcess);

		return "pages/communication/CmpReqIdSearchPopUp";
	}
	 
	@RequestMapping(value = "/loadCmpReqIdView.act", method = {RequestMethod.POST, RequestMethod.GET })
	public String loadCmpReqIdView(ModelMap model,	@ModelAttribute("cmpReqIdSearchProcess") CmpReqIdSearchProcess cmpReqIdSearchProcess, HttpServletRequest request) {
		log.debug("loadCmpReqIdView :: loadCmpReqIdView :: Start...");
		cmpReqIdSearchProcess = new CmpReqIdSearchProcess();
		model.addAttribute("cmpReqIdSearchProcess", cmpReqIdSearchProcess);

		return "c3par.communication.cmpSearchView";
	}
	

	@RequestMapping(value = "/searchCmpReqIdView.act", method = {RequestMethod.POST, RequestMethod.GET })
	public String searchCmpReqIdView(ModelMap model,@ModelAttribute("cmpReqIdSearchProcess") CmpReqIdSearchProcess cmpReqIdSearchProcess,BindingResult result, HttpServletRequest request) {
		log.debug("CmpReqIdSearchController :: searchCmpReqIdView :: Start...");
		String ssoId = request.getHeader("SM_USER");
		
		/*if ((ssoId == null || ssoId.isEmpty()) && request.getSession().getAttribute("ssoId") != null) {
			ssoId = ((String) request.getSession().getAttribute("ssoId"));
		}*/
		String cmpReqId = cmpReqIdSearchProcess.getCmpreqID();
		if(cmpReqId == null){
			cmpReqId = "";
		}
		//List<CMPRequest> cmpReqList = cmpReqIdSearchProcess.getCmpReqIdsList(ssoId, cmpReqId);
		List<CMPRequest> cmpReqList = cmpReqIdSearchProcess.getCmpReqIdSearchList(cmpReqId);

		cmpReqIdSearchProcess.setCmpReqList(cmpReqList);

		model.addAttribute("cmpIdList", cmpReqList);
		model.addAttribute("cmpReqIdSearchProcess", cmpReqIdSearchProcess);

		return "c3par.communication.cmpSearchView";
	}
	
	@RequestMapping(value = "/searchCmpReqId.act", method = {RequestMethod.POST, RequestMethod.GET })
	public String searchCmpReqId(ModelMap model,@ModelAttribute("cmpReqIdSearchProcess") CmpReqIdSearchProcess cmpReqIdSearchProcess,BindingResult result, HttpServletRequest request) {
		log.debug("CmpReqIdSearchController :: searchCmpReqId :: Start...");
		String ssoId = request.getHeader("SM_USER");
		
		if ((ssoId == null || ssoId.isEmpty()) && request.getSession().getAttribute("ssoId") != null) {
			ssoId = ((String) request.getSession().getAttribute("ssoId"));
		}
		String cmpReqId = cmpReqIdSearchProcess.getCmpreqID();
		if(cmpReqId == null){
			cmpReqId = "";
		}

		List<CMPRequest> cmpReqList = cmpReqIdSearchProcess.getCmpReqIdsList(ssoId, cmpReqId);

		cmpReqIdSearchProcess.setCmpReqList(cmpReqList);

		model.addAttribute("cmpIdList", cmpReqList);
		model.addAttribute("cmpReqIdSearchProcess", cmpReqIdSearchProcess);

		return "pages/communication/CmpReqIdSearchPopUp";
	}

	@RequestMapping(value = "/submitCmpIdDetails.act", method = RequestMethod.POST)
	public String submitCmpIdDetails(ModelMap model,@ModelAttribute("cmpReqIdSearchProcess") CmpReqIdSearchProcess cmpReqIdSearchProcess,HttpServletRequest request) {
		String selectedCmpReqId = request.getParameter("cmpIdVal");

		request.getSession().setAttribute("selectedCmpReqId",selectedCmpReqId);
		
		return "pages/dashboard/ClosePopupWindowResponse";
	}
}
