package com.citigroup.cgti.c3par.controller.firewall;

import java.beans.PropertyEditorSupport;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.fw.domain.Firewall;
import com.citigroup.cgti.c3par.fw.domain.FirewallupdateProcess;
import com.citigroup.cgti.c3par.fw.domain.admin.util.FirewallCrud;

@Controller
public class FirewallUpdateController{

	@Autowired
	FirewallCrud firewallCrud;
	private static Logger log = Logger.getLogger(FirewallUpdateController.class);
	
	
	@InitBinder
	public void binder(WebDataBinder binder) {binder.registerCustomEditor(Timestamp.class,
	    new PropertyEditorSupport() {
	        public void setAsText(String value) {
	            try {
	            	if(value == null || value.trim().length()==0)
	            		return;
	                Date parsedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(value);
	                setValue(new Timestamp(parsedDate.getTime()));
	            } catch (ParseException e) {
	                setValue(null);
	                log.error("Failed to parse timestamp",e);
	            }
	        }
	    });
	}
	
	@RequestMapping(value = "/updateFirewallDetails.act", method = { RequestMethod.GET })
	public String handleGet(ModelMap model,@ModelAttribute("firewallUpdateProcess") FirewallupdateProcess firewallUpdateProcess,
			HttpServletRequest request) {
		
		model.addAttribute("firewallUpdateProcess", firewallUpdateProcess);
		return "c3par.admin.firewallUpdate";
	}
	
	@RequestMapping(value = "/updateFirewallDetails.act", method = { RequestMethod.POST })
	public String handlePost(ModelMap model,@ModelAttribute("firewallUpdateProcess") FirewallupdateProcess firewallUpdateProcess,
			HttpServletRequest request) {
		
		String action = request.getParameter("action");
		String firewallId = request.getParameter("selectedFirewallId");
		
		log.info("****FirewallUpdateController - FirewallName"+firewallUpdateProcess.getFirewallName()+"selectedFirewallId"+firewallId);
		if(action != null && "getFirewalls".equals(action)){
			List<Firewall> firewalls = firewallCrud.findFireWalls(firewallUpdateProcess.getFirewallName());
			if(firewalls != null){
				log.info("Firewall list size"+firewalls.size());
			}
			firewallUpdateProcess.setFirewalls(firewalls);
		}else if(action != null && "updateFirewall".equals(action)){
			Firewall updatedFirewall = getMatchingFirewall(new Long(firewallId), firewallUpdateProcess.getFirewalls());
			//log.info("FireWall object values"+updatedFirewall.printMe());
			firewallCrud.updateFirewall(updatedFirewall);
		}else if(action != null && "deleteFirewall".equals(action)){
			Firewall updatedFirewall = getMatchingFirewall(new Long(firewallId), firewallUpdateProcess.getFirewalls());
			//log.info("FireWall object values"+updatedFirewall.printMe());
			firewallCrud.deleteFirewall(updatedFirewall);
		}else if(action != null && "insertFirewall".equals(action)){
			try {
				firewallCrud.insertFirewall(firewallUpdateProcess.getSelectedFirewall());
			} catch (DataAccessException e) {
				log.error("Failed to insert new firewall", e);
			} catch (Exception e) {
				log.error("Failed to insert new firewall", e);
			};
		}
		return "c3par.admin.firewallUpdate";
	}
	
	private Firewall getMatchingFirewall(Long firewallId, List<Firewall> firewalls){
		for(Firewall firewall:firewalls){
			if(firewall.getId().equals(firewallId)){
				return firewall;
			}
		}
		return null;
	}
	
	@ModelAttribute("policyList")
	protected Map<Long, String> initializeForm(ModelMap model) throws Exception {
		Map<Long, String> policyMap = firewallCrud.getFirewallPolicyMap();
		return policyMap; 
	}
}
