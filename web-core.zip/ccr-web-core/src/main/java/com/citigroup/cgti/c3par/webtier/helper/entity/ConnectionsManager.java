package com.citigroup.cgti.c3par.webtier.helper.entity;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Expression;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;
import com.mentisys.dao.query.SubExpression;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.ConnectionDAO;
import com.citigroup.cgti.c3par.dao.RelationshipDAO;
import com.citigroup.cgti.c3par.dao.TerminationDAO;
import com.citigroup.cgti.c3par.dao.MaintenanceDAO;
import com.citigroup.cgti.c3par.model.TerminationEntity;
import com.citigroup.cgti.c3par.model.RelationshipEntity;
import com.citigroup.cgti.c3par.model.MaintenanceEntity;
import com.citigroup.cgti.c3par.webtier.helper.C3parStatusLookupNames;
import org.apache.log4j.Logger;


/**
 * The Class ConnectionsManager.
 */
public class ConnectionsManager
{

    /** The log. */
    private static Logger log = Logger.getLogger(ConnectionsManager.class);

    /**
     * Gets the all.
     *
     * @return the all
     * @throws DatabaseException the database exception
     */
    static public List getAll() throws DatabaseException {
	ConnectionDAO dao = new ConnectionDAO(new C3parSession());
	Condition condition = new Condition();
	List l = dao.query(condition, false);
	return l ;
    }

    /**
     * Gets the active connections.
     *
     * @return the active connections
     * @throws DatabaseException the database exception
     */
    static public List getActiveConnections() throws DatabaseException
    {
	ConnectionDAO dao = new ConnectionDAO(new C3parSession());
	Condition condition = new Condition();
	condition.addExpression(new OperatorExpression(ConnectionDAO.COLUMN_STATUS, Operator.NOT_EQUAL, C3parStatusLookupNames.TERMINATED));
	List l = dao.query(condition, false);
	return l ;
    }

    //==============================================================================
    /**
     * Gets the terminatable connections.
     *
     * @param db_session the db_session
     * @param name the name
     * @param business_unit_id the business_unit_id
     * @param third_party_id the third_party_id
     * @param userId the user id
     * @return the terminatable connections
     * @throws DatabaseException the database exception
     */
    static public List getTerminatableConnections(C3parSession db_session, String name, 
	    Long business_unit_id, Long third_party_id,
	    String userId) 
    throws DatabaseException
    {

	List connections = new ArrayList();		

	if(db_session == null)
	{
	    db_session = new C3parSession();
	}

	log.debug("getTerminatableConnections: business_unit_id = " + business_unit_id + ", third_party_id = " + third_party_id);

	List rels = null;
	if(business_unit_id == null)
	{
	    business_unit_id = Long.valueOf(0);
	}
	if(third_party_id == null)
	{
	    third_party_id = Long.valueOf(0);
	}

	if(business_unit_id.longValue() > 0 || third_party_id.longValue() > 0)
	{
	    Condition relationship_condition = new Condition();
	    if(business_unit_id.longValue() > 0)
	    {
		relationship_condition.addExpression(new OperatorExpression(RelationshipDAO.COLUMN_BUSINESSUNIT_ID, Operator.EQUAL, business_unit_id));
	    }
	    if(third_party_id.longValue() > 0)
	    {
		relationship_condition.addExpression(new OperatorExpression(RelationshipDAO.COLUMN_THIRDPARTY_ID, Operator.EQUAL, third_party_id));
	    }
	    rels = RelationshipDAO.createInstance(db_session).query(relationship_condition, false);
	}

	List termination_requests = TerminationDAO.createInstance(db_session).getAll(false);		

	Condition condition = new Condition();
	if(name == null)
	{
	    name = "";	
	}
	condition.addExpression(new OperatorExpression(ConnectionDAO.COLUMN_NAME, Operator.LIKE, name));
	condition.addExpression(new OperatorExpression(ConnectionDAO.COLUMN_STATUS, Operator.NOT_EQUAL, C3parStatusLookupNames.TERMINATED));
	condition.addExpression(new OperatorExpression(ConnectionDAO.COLUMN_REQUESTERID, Operator.EQUAL, userId.toLowerCase()));

	Iterator iter = termination_requests.iterator();
	while(iter.hasNext())
	{
	    TerminationEntity term_request = (TerminationEntity)iter.next();
	    if(!term_request.getStatus().equals(C3parStatusLookupNames.TERMINATION_CANCELLED))
	    {
		Long term_connection_id = term_request.getConnectionId();
		condition.addExpression(new OperatorExpression(ConnectionDAO.COLUMN_ID, Operator.NOT_EQUAL, term_connection_id));
	    }
	}

	List maintenance_request = MaintenanceDAO.createInstance(db_session).getAll(false);
	iter = maintenance_request.iterator();
	while(iter.hasNext())
	{
	    MaintenanceEntity maint_request = (MaintenanceEntity)iter.next();
	    if(!C3parStatusLookupNames.MAINTENANCE_COMPLETE.equals(maint_request.getStatus()))
	    {
		Long maint_connection_id = maint_request.getConnectionId();
		condition.addExpression(new OperatorExpression(ConnectionDAO.COLUMN_ID, Operator.NOT_EQUAL, maint_connection_id));
	    }
	}

	if(rels == null) // if we don't have any filters for BU or TP...
	{
	    log.debug("getTerminatableConnections: No TP or BU selected.");
	    connections = ConnectionDAO.createInstance(db_session).query(condition, false);
	}
	else if(rels.size() > 0)
	{
	    log.debug("getTerminatableConnections: Relationships count = " + rels.size());
	    if(rels.size() == 1)
	    {
		RelationshipEntity rel = (RelationshipEntity)rels.get(0);
		condition.addExpression(new OperatorExpression(ConnectionDAO.COLUMN_RELATIONSHIP_ID, Operator.NOT_EQUAL, rel.getId()));
	    }
	    else
	    {
		SubExpression sub_expr = new SubExpression(false);

		Iterator it = rels.iterator();
		while(it.hasNext())
		{
		    RelationshipEntity rel = (RelationshipEntity)it.next();
		    Expression expr = new OperatorExpression(ConnectionDAO.COLUMN_RELATIONSHIP_ID, Operator.EQUAL, rel.getId());
		    sub_expr.add(expr);
		}

		condition.addExpression(sub_expr);
	    }
	    log.debug("EXPRESSION = " + condition.getWhereExpression());
	    connections = ConnectionDAO.createInstance(db_session).query(condition, false);
	}

	log.debug("EXPRESSION = " + condition.getWhereExpression());
	return connections;
    }


}