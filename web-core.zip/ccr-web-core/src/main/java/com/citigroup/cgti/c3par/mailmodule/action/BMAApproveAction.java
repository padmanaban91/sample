package com.citigroup.cgti.c3par.mailmodule.action;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.kie.api.task.model.TaskSummary;
import org.springframework.beans.factory.annotation.Autowired;

import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;
import com.citigroup.cgti.ccr.workflow.CCRWorkflowConstants;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

public class BMAApproveAction extends MailAction {

    Logger log = Logger.getLogger(BMAApproveAction.class);

    private final static String ROLE = "Manager";

    private final static String STATUS = "COMPLETED";
    private static final String SUCCESS = "Successful";
    private static final String FAILURE = "Failed";
    @Autowired
    WsPapiFacade papiFacade;
    @Autowired
    WorkflowCallServiceHelper wrkflowCallServiceHelper;
    @Autowired
    WorkflowUtil workflowUtil;

    @Override
    public void process(IncomingMessage message) {
        log.info("Process method of BMAApproveAction --------------------");
        Long processId = null;
        String ssoId = null;
        if (message != null && message.getProcessId() != null) {
            processId = Long.parseLong(message.getProcessId().trim());
        }
        Long tiRequestId = getTIRequestID(processId);
        ssoId = message.getSsoId();
        if (checkReferenceNumber(message.getReferenceNo(), tiRequestId, ssoId)) {
            String instanceId = null;
            // message.setSsoId("hb26743");
            instanceId = getInstanceId(processId);
            log.debug("Before calling PAPI --------------------------- " + instanceId);
            Long userId = getUserID(message.getSsoId());
            try {
                String nextAction = toCheckActivity(processId, tiRequestId, ssoId);
                log.info(" nextAction value:: " + nextAction);
                Map<String, Object> userFlowParams = new HashMap<String, Object>();
                if (nextAction != null && "UNLOCK".equals(nextAction)) {
                    sendAckMail(message.getAction(), ssoId, processId, FAILURE, message.getEntity());
                    update(message.getMailID(), message.getReferenceNo(), "N",
                            "Activity is already locked by someone.");
                } else if (nextAction != null && "LOCK".equals(nextAction)) {
                    TaskSummary taskSummary = workflowUtil.getTaskSummary(Long.parseLong(instanceId));
                    userFlowParams.put("soeid", ssoId);
                    userFlowParams.put(CCRWorkflowConstants.TASK_SUMMARY, taskSummary);
                    wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, userFlowParams, WorkflowEvent.LOCK,
                            tiRequestId);
                    addComments(message.getComments(), getTIRequestID(processId), ROLE, userId);
                    log.info(" userId : " + userId + " instanceId " + instanceId + " STATUS  " + STATUS);
                    papiFacade.completeActivity(userId.toString(), instanceId.toString(), STATUS);
                    // papiFacade.completeActivity(message.getSsoId(),
                    // instanceId,
                    // STATUS);
                    log.debug("Before calling update approve --------------------------- ");
                    sendAckMail(message.getAction(), message.getSsoId(), processId, SUCCESS, message.getEntity());
                    update(message.getMailID(), message.getReferenceNo(), "Y", "Action completed successfully");
                    log.debug("after calling update approve--------------------------- ");
                } else{
                    sendAckMail(message.getAction(), ssoId, processId, FAILURE, message.getEntity());
                    update(message.getMailID(), message.getReferenceNo(), "N","Please contact the helpdesk for further assistance.");
                }

            } catch (OperationException_Exception e) {
                log.error(e, e);
                sendAckMail(message.getAction(), message.getSsoId(), processId, FAILURE, message.getEntity());
                update(message.getMailID(), message.getReferenceNo(), "N", getExceptionMessage(e));
                e.printStackTrace();
            }
        } else {
            sendAckMail(message.getAction(), message.getSsoId(), processId, FAILURE, message.getEntity());
            update(message.getMailID(), message.getReferenceNo(), "N",
                    "The response Email from the user is not authorized");
            log.debug("Refernce ID not matching " + message.getReferenceNo());
        }

        log.info("End of Process method of BMAApproveAction --------------------");
    }

}
