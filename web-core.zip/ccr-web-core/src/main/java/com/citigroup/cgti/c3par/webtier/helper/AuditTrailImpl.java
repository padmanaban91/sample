package com.citigroup.cgti.c3par.webtier.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.ManageActivityImpl;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.domain.TIRequestType;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;


/**
 * The Class AuditTrailImpl.
 */
public class AuditTrailImpl {

    /** The c3par session. */
    private C3parSession c3parSession;

    /** The log. */
    Logger log = Logger.getLogger(ManageActivityImpl.class);

    /**
     * Gets the audit trail.
     *
     * @param tiProcess the ti process
     * @return the audit trail
     */
    public TIProcess getAuditTrail(TIProcess tiProcess) {
	this.log.debug("Start AuditTrailImpl.getAuditTrial");
	Connection con = null;
	PreparedStatement pStmt = null;
	ResultSet rs = null;
	if ((tiProcess.getId() != null) && (tiProcess.getId().longValue() != 0)) {
	    try {
		con = c3parSession.getConnection();
		StringBuffer strQuery = new StringBuffer();
		strQuery
		.append("SELECT distinct d.id, e.task Activity, decode(c.request_type,'Create','Planning','Maintain', ");
		strQuery
		.append("'Maintenance', 'Terminate', 'Termination', 'ACV', 'ACV','ManageContacts','Maintain Contacts') RequestType, f.DISPLAY_NAME ActivityRole, i.DISPLAY_NAME infoActivityRole, ");
		strQuery.append("g.sso_id UserID, ");
		strQuery.append("h.sso_id Lockedby, ");
		strQuery
		.append("d.activity_status Status, d.activity_mode ActivityMode, to_char(d.activity_startdate,'MM-DD-YYYY HH24:MI') ");
		strQuery
		.append("StartDate, to_char(d.activity_enddate,'MM-DD-YYYY HH24:MI') EndDate, a.id processId, ");
		strQuery
		.append("a.process_name processName, b.version_number versionNumber, b.id tiRequestId, d.activity_type activityType, " );
		strQuery
		.append("r.baseline_name, (select listagg(r.rule_number,',') within group (order by r.rule_number) from ti_risk_audit_trail a, " );
		strQuery
		.append("con_fw_rule r where a.tuple_number = r.id and r.deleted_ti_request_id is null and a.act_trail_id = d.id) tuple_list, d.approval_system, d.bpm_instance_id " );
		strQuery
		.append("FROM ti_process a, ti_request b, ");
		strQuery
		.append("TI_REQUEST_TYPE C, TI_ACTIVITY_TRAIL D, TI_TASK_TYPE E, ROLE F, c3par_users g, c3par_users h, ROLE i, ti_risk_audit_trail r  ");
		strQuery
		.append("WHERE a.id = b.process_id AND b.ti_request_type_id=c.id AND b.id = d.ti_request_id AND ");
		strQuery
		.append("d.activity_id = e.id AND d.user_role_id = f.id(+) AND d.INFOUSER_ROLE_ID = i.id(+) AND d.user_id = g.id(+) AND d.lockedby = h.id(+) ");
		strQuery
		.append("and d.id  = r.act_trail_id(+) ");
		strQuery
		.append("AND a.id = ? ORDER BY b.id DESC, d.id");
		log.info("strQuery::" + strQuery);
		pStmt = con.prepareStatement(strQuery.toString());
		pStmt.setLong(1, tiProcess.getId().longValue());
		rs = pStmt.executeQuery();

		if (rs != null) {
		    TIRequest tiRequest = new TIRequest();
		    tiRequest.setId(Long.valueOf(0));
		    while (rs.next()) {
			ActivityData activityData = new ActivityData();
			activityData.setActivityName(rs.getString("Activity"));
			activityData.setActivityMode(rs
				.getString("ActivityMode"));
			activityData.setUserRole(rs.getString("ActivityRole"));
			activityData.setInfoUserRole(rs.getString("infoActivityRole"));
			activityData.setUserID(rs.getString("UserID"));
			activityData.setLockedBy(rs.getString("Lockedby"));
			activityData.setActivityStatus(rs.getString("Status"));
			activityData.setActivityStartDate(rs
				.getString("StartDate"));
			activityData
			.setActivityEndDate(rs.getString("EndDate"));
			activityData.setActivityType(rs.getString("activityType"));
			activityData.setBaselineName(rs.getString("baseline_name"));
			activityData.setTupleList(rs.getString("tuple_list"));
			activityData.setApprovalSystem(rs.getString("approval_system"));
			activityData.setAlbpmActivityID(rs.getString("bpm_instance_id"));
			
			if (tiRequest.getId().longValue() == 0) {
			    tiRequest
			    .setId(Long.valueOf(rs.getLong("tiRequestId")));
			    tiRequest.setVersionNumber(rs
				    .getInt("versionNumber"));
			    TIRequestType tiRequestType = new TIRequestType();
			    tiRequestType.setName(rs.getString("RequestType"));
			    tiRequest.setTiRequestType(tiRequestType);
			    tiProcess.getTiRequestList().add(tiRequest);
			    tiProcess.setName(rs.getString("processName"));
			} else if ((tiRequest.getId().longValue() != 0)
				&& (tiRequest.getId().longValue() != rs
					.getLong("tiRequestId"))) {
			    tiRequest = new TIRequest();
			    tiRequest
			    .setId(Long.valueOf(rs.getLong("tiRequestId")));
			    tiRequest.setVersionNumber(rs
				    .getInt("versionNumber"));
			    TIRequestType tiRequestType = new TIRequestType();
			    tiRequestType.setName(rs.getString("RequestType"));
			    tiRequest.setTiRequestType(tiRequestType);
			    tiProcess.getTiRequestList().add(tiRequest);
			}
			
			if ((ActivityData.STATUS_COMPLETED.equalsIgnoreCase(activityData.getActivityStatus())
					||ActivityData.STATUS_REJECTED.equalsIgnoreCase(activityData.getActivityStatus()))
					&& (OneApprovalConstants.APPROVAL_SYSTEM_OA_FWD.equalsIgnoreCase(activityData.getApprovalSystem())
							|| OneApprovalConstants.APPROVAL_SYSTEM_OA_DEL.equalsIgnoreCase(activityData.getApprovalSystem()))) {
				String action = "DELEGATED";
				String type = "D";
				if (OneApprovalConstants.APPROVAL_SYSTEM_OA_FWD.equalsIgnoreCase(activityData.getApprovalSystem())) {
					action = "FORWARDED";
					type = "F";
				}
				String alternateApprover =  getAlternateApprover(tiProcess.getId(), tiRequest.getId(), tiRequest.getVersionNumber(), activityData.getAlbpmActivityID(), type);
				String status = activityData.getActivityStatus() + "["+action+" TO "+alternateApprover+"]";
				activityData.setActivityStatus(status);
			}

			tiRequest.getActivityDataList().add(activityData);
			
		    }
		}

	    } catch (Exception e) {
		this.log.error(e);
	    } finally {
		try {
		    if (rs != null) {
			rs.close();
		    }
		    if (pStmt != null) {
			pStmt.close();
		    }
		    if (con != null) {
			this.c3parSession.releaseConnection();
		    }
		} catch (Exception exp) {
		    this.log.error(exp);
		}
	    }
	}
	
	

	this.log.debug("End AuditTrailImpl.getAuditTrial");
	return tiProcess;
    }

    
    /**
     * 
     * @param processId
     * @param tiRequestId
     * @param version
     * @param bpmInstanceId
     * @return
     */
    private String getAlternateApprover(Long processId, Long tiRequestId, int version, String bpmInstanceId, String type) {
        String alternateApprover =  null;
		ResultSet result = null;
		PreparedStatement pstmt = null;
		Connection connection = null;		
		C3parSession c3parSession = null;
      	
		try {
      		log.debug("getAlternateApprover() Enter " );
			log.debug("tiRequestId  "  + tiRequestId);
			c3parSession = new C3parSession();
			connection = c3parSession.getConnection();

			String sql = "select contact.sso_id from oneapproval_msg_log log, citi_contact contact where log.alternate_approver = contact.geid " +
					"and log.order_id = '"+tiRequestId+"-"+bpmInstanceId+"' and log.approver_type = '"+type+"'";
			pstmt = connection.prepareStatement(sql);
			result = pstmt.executeQuery();
				
			if (result.next()) 
				alternateApprover = result.getString(1); 
				
			log.debug("alternateApprover : " + alternateApprover);
			log.debug("getAlternateApprover() End " );
      	}
		catch (Exception e) {
			log.debug("getAlternateApprover() ",e);
		}
		 finally {
				c3parSession.closeResultSet(result);
				c3parSession.closeStatement(pstmt);
				c3parSession.releaseConnection();
			}
		
		return alternateApprover;
	}

    
    
    /**
     * Gets the c3par session.
     *
     * @return the c3par session
     */
    public C3parSession getC3parSession() {
	return c3parSession;
    }

    /**
     * Sets the c3par session.
     *
     * @param session the new c3par session
     */
    public void setC3parSession(C3parSession session) {
	c3parSession = session;
    }
}
