package com.citigroup.cgti.c3par.acl.domain.logic;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.acl.dao.ACLVariancePersistable;
import com.citigroup.cgti.c3par.acl.domain.ACLVariance;
import com.citigroup.cgti.c3par.domain.TIProcess;

/**
 * The Class ACLVarianceImpl.
 */
public class ACLVarianceImpl implements ACLVarianceService{

    /** The log. */
    protected Logger log = Logger.getLogger(this.getClass().getName());

    /** The acl variance persistable. */
    ACLVariancePersistable aclVariancePersistable = null;

    /**
     * Gets the acl variance persistable.
     *
     * @return the acl variance persistable
     */
    public ACLVariancePersistable getAclVariancePersistable() {
	return aclVariancePersistable;
    }

    /**
     * Sets the acl variance persistable.
     *
     * @param aclVariancePersistable the new acl variance persistable
     */
    public void setAclVariancePersistable(ACLVariancePersistable aclVariancePersistable) {
	this.aclVariancePersistable = aclVariancePersistable;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.domain.logic.ACLVarianceService#deleteACLVariance(com.citigroup.cgti.c3par.acl.domain.ACLVariance)
     */
    @Override
    public void deleteACLVariance(ACLVariance aclVariance) {
	aclVariancePersistable.deleteACLVariance(aclVariance);

    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.domain.logic.ACLVarianceService#getACLVarianceData(com.citigroup.cgti.c3par.domain.TIProcess)
     */
    @Override
    public ACLVariance getACLVarianceData(TIProcess tiProcess) {
	return aclVariancePersistable.getACLVarianceData(tiProcess);
    }
    
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.domain.logic.ACLVarianceService#getACLVariance(com.citigroup.cgti.c3par.domain.TIProcess)
     */
    @Override
    public ACLVariance getACLVariance(TIProcess tiProcess) {
	return aclVariancePersistable.getACLVariance(tiProcess);
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.domain.logic.ACLVarianceService#storeACLVariance(com.citigroup.cgti.c3par.acl.domain.ACLVariance)
     */
    @Override
    public void storeACLVariance(ACLVariance aclVariance) {
	aclVariancePersistable.storeACLVariance(aclVariance);

    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.domain.logic.ACLVarianceService#updateACLVariance(com.citigroup.cgti.c3par.acl.domain.ACLVariance)
     */
    @Override
    public void updateACLVariance(ACLVariance aclVariance) {
	aclVariancePersistable.updateACLVariance(aclVariance);

    }
}