package com.citigroup.cgti.c3par.webtier.controller.communication;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.communication.domain.TeamViewProcess;

@Controller
public class TeamViewController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@RequestMapping(value = "/teamViewController.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String loadTeamView(ModelMap model, HttpServletRequest request,
			@ModelAttribute("teamViewProcess") TeamViewProcess teamViewProcess)
			throws Exception {

		log.debug("Entering into loadTeamView....");
		String orderBy = "asc";
		Boolean isSorting=false;
		if (null != request.getParameter("orderBy")) {
			orderBy = (String) request.getParameter("orderBy");
		}

		String sortingColumnName = null;
		if (null != request.getParameter("columnName")) {
			sortingColumnName = (String) request.getParameter("columnName");

			String sortingColumnNameInSession = (String) request.getSession()
					.getAttribute("selectedColumnName");

			if (sortingColumnName.equalsIgnoreCase(sortingColumnNameInSession)) {
				teamViewProcess.setSameColumnSelected("true");
			}
			
			isSorting=true;
		}
		log.debug("sortingColumnName::loadAgentView::" + sortingColumnName);
		if (null != request.getParameter("type")) {

			String actionType = (String) request.getParameter("type");

			log.debug("What action performed.." + actionType);

			if ("L".equals(actionType) || "FI".equals(actionType)
					|| "P".equals(actionType) || "N".equals(actionType)
					|| "LA".equals(actionType)) {

				log.debug("I am from pagination..");

				orderBy = (String) request.getSession().getAttribute("OrderBy");
				sortingColumnName = (String) request.getSession().getAttribute(
						"selectedColumnName");

			}

		}

		String temp = sortingColumnName;
		request.getSession().setAttribute("selectedColumnName",
				sortingColumnName);
		sortingColumnName = this.columnNameConversion(sortingColumnName);

		log.debug("orderBy:" + orderBy);
		log.debug("columnName:" + sortingColumnName);

		teamViewProcess.setOrderBy(orderBy);
		teamViewProcess.setSortingColumnName(sortingColumnName);

		String userId = request.getHeader("SM_USER");
		teamViewProcess.setTeam(userId);
		
		teamViewProcess.setLastNameList(teamViewProcess.getAssignedLastNameList());
		
		log.debug("loadAgentView::SectorList::" + teamViewProcess.getSectorList());

		// Pagination

		String type = (String) request.getParameter("type");
		log.debug("loadAgentView::type::" + type);
		int curOffSet = teamViewProcess.getOffset();
		int limit = teamViewProcess.getLimit();
		int sortLimit = teamViewProcess.getLimit();
		int pageNo = teamViewProcess.getPageNo();
		int recordStartCount = teamViewProcess.getRecordStartCount();
		int sortRecordStartCount = teamViewProcess.getRecordStartCount();
		int recordEndCount = teamViewProcess.getRecordEndCount();
		int sortRecordEndCount = teamViewProcess.getRecordEndCount();
		int totalRecords = teamViewProcess.getTotalRecords();
		int sortTotalRecords = teamViewProcess.getTotalRecords();
		if ((teamViewProcess.getOffset() == 0 && teamViewProcess.getLimit() == 0
				&& teamViewProcess.getPageNo() == 0) || isSorting)  {
			teamViewProcess.setOffset(0);
			teamViewProcess.setLimit(20);
			teamViewProcess.setPageNo(1);
			teamViewProcess.setRecordStartCount(1);
			teamViewProcess.setRecordEndCount(20);
			if(isSorting){
				teamViewProcess.setLimit(sortLimit);
				teamViewProcess.setRecordStartCount(1);
				teamViewProcess.setRecordEndCount(recordEndCount);
				teamViewProcess.setTotalRecords(sortTotalRecords);
			}

		} 
		
		else {
			int remainder = (teamViewProcess.getTotalRecords() % (teamViewProcess
					.getLimit()));
			if ("N".equalsIgnoreCase(type)) {
				teamViewProcess.setOffset(curOffSet
						+ teamViewProcess.getLimit());
				if ((teamViewProcess.getTotalRecords() <= (teamViewProcess
						.getRecordEndCount() + teamViewProcess.getLimit()))) {
					teamViewProcess.setRecordEndCount(teamViewProcess
							.getTotalRecords());
				} else {
					teamViewProcess.setRecordEndCount((teamViewProcess
							.getRecordEndCount() + teamViewProcess.getLimit()));
				}

				teamViewProcess
						.setRecordStartCount(teamViewProcess.getOffset() + 1);
			} else if ("P".equalsIgnoreCase(type)) {
				teamViewProcess.setOffset(curOffSet
						- teamViewProcess.getLimit());
				if (teamViewProcess.getRecordEndCount() == teamViewProcess
						.getTotalRecords()) {

					if (remainder == 0) {
						teamViewProcess.setRecordEndCount((teamViewProcess
								.getRecordEndCount() - teamViewProcess
								.getLimit()));
					} else {
						teamViewProcess.setRecordEndCount((teamViewProcess
								.getRecordEndCount() - remainder));
					}

				} else {
					teamViewProcess.setRecordEndCount((teamViewProcess
							.getRecordEndCount() - teamViewProcess.getLimit()));
				}
				teamViewProcess
						.setRecordStartCount(teamViewProcess.getOffset() + 1);
			} else if ("L".equalsIgnoreCase(type)) {
				teamViewProcess.setOffset(0);
				teamViewProcess.setRecordStartCount(1);
				if ((teamViewProcess.getTotalRecords() <= (teamViewProcess
						.getLimit()))) {
					teamViewProcess.setRecordEndCount(teamViewProcess
							.getTotalRecords());
				} else {
					teamViewProcess.setRecordEndCount(teamViewProcess
							.getLimit());
				}
				teamViewProcess.setLimit(teamViewProcess.getLimit());
			} else if ("FI".equalsIgnoreCase(type)) {
				log.debug("insie FI");
				teamViewProcess.setOffset(0);
				teamViewProcess.setRecordStartCount(1);
				if ((teamViewProcess.getTotalRecords() <= teamViewProcess
						.getLimit())) {
					teamViewProcess.setRecordEndCount(teamViewProcess
							.getTotalRecords());
				} else {
					teamViewProcess.setRecordEndCount(teamViewProcess
							.getLimit());
				}
			} else if ("LA".equalsIgnoreCase(type)) {
				if (remainder == 0) {

					teamViewProcess
							.setRecordStartCount(teamViewProcess
									.getTotalRecords()
									- teamViewProcess.getLimit() + 1);
					teamViewProcess.setRecordEndCount(teamViewProcess
							.getTotalRecords());
					teamViewProcess.setOffset((teamViewProcess
							.getTotalRecords())
							- ((teamViewProcess.getLimit())));
				}
				if (remainder >= 1) {
					teamViewProcess.setRecordStartCount((teamViewProcess
							.getTotalRecords()) - (remainder - 1));
					teamViewProcess.setRecordEndCount(teamViewProcess
							.getTotalRecords());
					teamViewProcess.setOffset((teamViewProcess
							.getTotalRecords()) - (remainder));
				}
			} else {
				teamViewProcess.setOffset(0);
				teamViewProcess.setPageNo(1);
			}
		}

		if (request.getParameter("errMsg") != null) {
			teamViewProcess.setErrorMessage("Invalid CCR ID");
		}
		String snURL;
		snURL = teamViewProcess.getSnUrl();
		teamViewProcess.setServicenowURL(snURL);
		teamViewProcess.setSelectedColumnName(temp);
		log.debug("teamViewProcess.getOrderBy(): "
				+ teamViewProcess.getOrderBy());
		log.debug("teamViewProcess.getSortingColumnName(): "
				+ teamViewProcess.getSortingColumnName());
		teamViewProcess.setCmpRequestMessageList(teamViewProcess
				.getTeamCmpReqData());
		log.debug("setting values of sector::" + userId);
		if(teamViewProcess.getCmpRequestMessageList() != null){
			if (teamViewProcess.getCmpRequestMessageList().size() <= 0) {
				log.debug("zero values for resolveItlist");
				teamViewProcess.setRecordStartCount(0);
				teamViewProcess.setRecordEndCount(0);
				teamViewProcess.setTotalRecords(0);
			}
			if (teamViewProcess.getCmpRequestMessageList().size() > 0
					&& type == null || type == "") { 
				if (teamViewProcess.getCmpRequestMessageList().size() <= teamViewProcess
						.getLimit()) {
					teamViewProcess.setRecordEndCount(teamViewProcess
							.getCmpRequestMessageList().size());
				}
			}
		}
		model.addAttribute("teamViewProcess", teamViewProcess);
		model.addAttribute("SelectedColumnName", temp);
		log.debug("Selected column::" + temp);
		request.setAttribute("orderBy", teamViewProcess.getOrderBy());
		request.getSession().setAttribute("OrderBy",
				teamViewProcess.getOrderBy());
		request.getSession().setAttribute("ColumnName",
				teamViewProcess.getSortingColumnName());
		request.getSession().setAttribute("SelectedColumnName", temp);
		log.debug("Exiting from loadTeamView");
		return "c3par.communication.teamView";
	}

	/**
	 * Sorting each column according to column Name
	 * 
	 */
	private String columnNameConversion(String inputStr) {

		log.debug("The inputStr: " + inputStr);

		String result = "assignedUser";

		if ("CMP REQ ID".equals(inputStr)) {

			result = "orderItemId";
		} else if ("DATE ASSIGNED".equals(inputStr)) {

			result = "updateAssignedUserDate";
		} else if ("REQUEST TYPE".equals(inputStr)) {

			result = "typeofConnectivityInvolved";
		} else if ("CCR ID".equals(inputStr)) {

			result = "ccrId";
		} else if ("REQUESTER NAME".equals(inputStr)) {

			result = "orderForUser";
		} else if ("REGION".equals(inputStr)) {

			result = "region";
		} else if ("SECTOR".equals(inputStr)) {

			result = "ecmSector";
		}
		else if ("CURRENT STATUS".equals(inputStr)) {

			result = "CURRENT STATUS";  
		}
		else if ("LAST NAME".equals(inputStr)) {

			result = "LAST NAME";  
		}

		return result;
	}

}
