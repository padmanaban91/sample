package com.citigroup.cgti.c3par.controller.businessjustification;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.remoting.soap.SoapFaultException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.businessjustification.domain.SearchInRitsProcess;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.gdw.CitiContactUpdate;
import com.citigroup.cgti.c3par.soa.model.ProfileEntity;
import com.citigroup.cgti.c3par.soa.soaImpl.profileInfo.ProfileInfoFactory;
import com.citigroup.cgti.c3par.soa.soaInterface.SOADataComponent;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.sun.xml.ws.fault.ServerSOAPFaultException;


/**
 * The Class SearchInRitsAction.
 */
@Controller
public class SearchInRitsController {

    /** The Constant QUERY_MESSAGE. */
    public static final String QUERY_MESSAGE = "connection.rits.querymessage" ;

    /** The Constant FORWARD_IP_SELECTION_COMPLETED. */
    public static final String FORWARD_IP_SELECTION_COMPLETED = "ip_selection_completed";

    /** The Constant ERROR_RELATIONSHIP_CITI_CONTACT_DUPLICATE. */
    public static final String ERROR_RELATIONSHIP_CITI_CONTACT_DUPLICATE = "application.legacyrelationship.relationship.citicontact.duplicate" ;

    /** The Constant CITI_CONTACT_SEQUENCE. */
    public static final String CITI_CONTACT_SEQUENCE = "seq_citi_contact" ;

    /** The log. */
    private static Logger log = Logger.getLogger(SearchInRitsController.class);   

    @RequestMapping(value = "/loadRitsSearch.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(HttpServletRequest request, ModelMap model){
		log.info("SearchInRitsController starts here..");
		SearchInRitsProcess searchInRitsProcess = new SearchInRitsProcess();
		List<Role> roleList = searchInRitsProcess.getRoles();
		searchInRitsProcess.setRoleList(roleList);
		
		TIRequest tiRequestEntity = null;
		tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
		
		if (tiRequestEntity != null && tiRequestEntity.getPriority() != null) {
			searchInRitsProcess.setPriority(tiRequestEntity.getPriority().getValue1());
		}
		
		model.addAttribute("searchInRitsProcess",searchInRitsProcess);
		log.info("SearchInRitsController ends here..");
		return "pages/businessjustification/searchInRits";
	}
    
    @RequestMapping(value = "/searchInRits.act", method = {RequestMethod.GET,RequestMethod.POST})
   	public String searchInRits(ModelMap model,@ModelAttribute("searchInRitsProcess") SearchInRitsProcess searchInRitsProcess, 
   			HttpServletRequest request, BindingResult result){
   			log.info("SearchInRitsController starts here..");
   		try {
   			int level = 0 ,directorRoleId = 0;
   		   // CitiContactUpdate ccu = (CitiContactUpdate)((WebApplicationContextUtils.getWebApplicationContext(request.getSession().getServletContext())).getBean("citiContactRefreshScheduler"));
   			CitiContactUpdate ccu = (CitiContactUpdate)CCRApplicationContextUtils.getApplicationContext().getBean("citiContactRefreshScheduler");
   		    SOADataComponent soaDataComponent = new SOADataComponent();
   		    ProfileInfoFactory profileInfoFactory =(ProfileInfoFactory)soaDataComponent.getServiceFactory("profileInfo");
   		    ProfileEntity profileEntity = new ProfileEntity();
   		    if(searchInRitsProcess.getCitiContact().getGeId() != null && !searchInRitsProcess.getCitiContact().getGeId().trim().equals(""))
   			profileEntity.setGeId(searchInRitsProcess.getCitiContact().getGeId());
   		    else if(searchInRitsProcess.getCitiContact().getSsoId() != null && !searchInRitsProcess.getCitiContact().getSsoId().trim().equals(""))
   			profileEntity.setSoeId(searchInRitsProcess.getCitiContact().getSsoId());
   		    else if(searchInRitsProcess.getCitiContact().getRitsId() != null && !searchInRitsProcess.getCitiContact().getRitsId().trim().equals(""))
   			profileEntity.setGeId(searchInRitsProcess.getCitiContact().getRitsId());
   		    else
   		    {
   			if(searchInRitsProcess.getCitiContact().getFirstName() != null && !searchInRitsProcess.getCitiContact().getFirstName().trim().equals(""))
   			    profileEntity.setFirstName(searchInRitsProcess.getCitiContact().getFirstName());

   			profileEntity.setLastName(searchInRitsProcess.getCitiContact().getLastName());
   		    }
   		    List<CitiContact> citiContactList =
   			profileInfoFactory.getRitzService().getProfile(profileEntity, request.getHeader("SM_USER"));
   		    
   		    request.getSession().setAttribute("CITI_CONTACT_LIST", citiContactList);

   			level = ccu.getContactLevel(citiContactList.get(0).getGeId());
   	  
   		    log.debug("level" +level);
   		    if( level < 5){
   		    	  directorRoleId = ccu.getRoleId();
   		    	  request.setAttribute("contactLevelLessThan5", "true");
   		    	  request.setAttribute("directorRoleId", directorRoleId);
   		    }
   		    else{
   		    	 request.setAttribute("contactLevelLessThan5", "false");
   		    	 request.setAttribute("directorRoleId", directorRoleId);
   		    }
   		 searchInRitsProcess = new SearchInRitsProcess();
   		 searchInRitsProcess.setCitiContactList(citiContactList);
   		 List<Role> roleList = searchInRitsProcess.getRoles();
		 searchInRitsProcess.setRoleList(roleList);
		 
		 TIRequest tiRequestEntity = null;
			tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
			
			if (tiRequestEntity != null && tiRequestEntity.getPriority() != null) {
				searchInRitsProcess.setPriority(tiRequestEntity.getPriority().getValue1());
			}
   		
   		model.addAttribute("searchInRitsProcess",searchInRitsProcess);
   		 
   		} catch(Exception e){
   			log.error(e.toString(), e);
   			if (e instanceof ServerSOAPFaultException){
				log.error("SOAPFaultException received..!!!");
				ObjectError	error= new ObjectError("name",ECMConstants.ERROR_MSG_SOA);
				result.addError(error);
			} else{
	   	   		List<Role> roleList = searchInRitsProcess.getRoles();
	   	 		searchInRitsProcess.setRoleList(roleList);	
   			}
			
   		}
   		log.info("SearchInRitsController ends here..");
   		return "pages/businessjustification/searchInRits";
   	}


    @RequestMapping(value = "/selectContact.act", method = {RequestMethod.GET,RequestMethod.POST})
   	public String selectContact(ModelMap model,@ModelAttribute("searchInRitsProcess") SearchInRitsProcess searchInRitsProcess, 
   			HttpServletRequest request, BindingResult result) {
    	log.debug("selectContact ----");

    	List<CitiContact> citiContactList = (List<CitiContact>)request.getSession().getAttribute("CITI_CONTACT_LIST");
	 
		 String ssoId = searchInRitsProcess.getSsoId();
		 String[] roleIds = searchInRitsProcess.getRoleIds();
		 
		 log.debug("ssoId ----"+ssoId);
		 log.debug("roleIds ----"+roleIds);
		 
		 for (CitiContact citiContact : citiContactList) {
			 if (ssoId.toUpperCase().equals(citiContact.getSsoId().toUpperCase())) {
				 CitiContact gdwCitiContact = searchInRitsProcess.getGDWDataBySSOId(citiContact.getSsoId().toUpperCase());
				 if(gdwCitiContact!=null) {
					 log.debug("Contact from GDW DB. "+gdwCitiContact);
					 citiContact.setGocCode(gdwCitiContact.getGocCode());
					 citiContact.setManSegmentId(gdwCitiContact.getManSegmentId());
					 citiContact.setDsmtRegionId(gdwCitiContact.getDsmtRegionId());
					 citiContact.setDsmtRegionName(gdwCitiContact.getDsmtRegionName());
					 citiContact.setDsmtSectorId(gdwCitiContact.getDsmtSectorId());
					 citiContact.setDsmtSectorName(gdwCitiContact.getDsmtSectorName());
					 citiContact.setDsmtBusinessUnitId(gdwCitiContact.getDsmtBusinessUnitId());
					 citiContact.setDsmtBusinessUnitName(gdwCitiContact.getDsmtBusinessUnitName());
				 }
				 request.getSession().setAttribute("RITS_CITI_CONTACT_ENTITY", citiContact);
				 break;
			 }
		 }
		
		 request.getSession().setAttribute("CITI_CONTACT_ROLEID", roleIds);

		 return "pages/common/SearchPopupCloser";	 
    }    

}