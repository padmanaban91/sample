package com.citigroup.cgti.c3par.fw.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestion;
import com.citigroup.cgti.c3par.fw.domain.OstiaQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.PossibleAnswers;
import com.citigroup.cgti.c3par.fw.domain.RiskDefinition;
import com.citigroup.cgti.c3par.rules.model.FirewallRuleDTO;
import com.citigroup.cgti.c3par.rules.model.FlagDTO;
import com.citigroup.cgti.c3par.rules.model.IpAddressDTO;
import com.citigroup.cgti.c3par.rules.model.OstiaQuestionDTO;
import com.citigroup.cgti.c3par.rules.model.OstiaQuestionnaireDTO;
import com.citigroup.cgti.c3par.rules.model.PortDTO;
import com.citigroup.cgti.c3par.rules.model.PossibleAnswersDTO;
import com.citigroup.cgti.c3par.rules.model.RiskDefinitionDTO;
import com.citigroup.cgti.c3par.rules.model.TiRequestDTO;

/**
 * @author vr56524
 *
 */
public class FirewallRuleDroolsMapper {
	
	private static final String DOUBLE_QUOTES = "";

	private static final String Y = "Y";

	private static final String N = "N";

	private static Logger log = Logger.getLogger(FirewallRuleDroolsMapper.class);

	private ManageTIProcessImpl manageTIProcess;
	
	/**
	 * @return the manageTIProcess
	 */
	public ManageTIProcessImpl getManageTIProcess() {
		return manageTIProcess;
	}

	/**
	 * @param manageTIProcess the manageTIProcess to set
	 */
	public void setManageTIProcess(ManageTIProcessImpl manageTIProcess) {
		this.manageTIProcess = manageTIProcess;
	}
	
	/** The log. */
    

	public FirewallRuleDTO convertFirewallRuleToFirewallRuleDTO(FireWallRule fireWallRule, TiRequestDTO tiRequestDTO, Long tiRequestId) {
		
		log.debug("convertFirewallRuleToFirewallRuleDTO --Start");
		FirewallRuleDTO firewallRuleDTO = new FirewallRuleDTO();
		String broadAccessFlag = manageTIProcess.getBroadAccessFlag(tiRequestId); 
		List<FlagDTO> tiRequestflagList = new ArrayList<FlagDTO>();
		FlagDTO broadFlagDTO = new FlagDTO();
		broadFlagDTO.setKey("BROAD_ACCESS");
		//TODO:will remvoe this code once testing completed
		broadFlagDTO.setValue(broadAccessFlag);
		broadFlagDTO.setTiRequest(true);
		tiRequestflagList.add(broadFlagDTO);
		tiRequestDTO.getRiskCheckFlags().addAll(tiRequestflagList);
		firewallRuleDTO.setTiRequest(tiRequestDTO);
	
		if (fireWallRule != null) {
			firewallRuleDTO.setId(fireWallRule.getId());
			firewallRuleDTO.setTransactionId("ConnectionID:"+fireWallRule.getTiRequest().getTiProcess().getId()+"TIR:"
										+fireWallRule.getTiRequest().getId()+"~FWR:"+fireWallRule.getId());
			//firewallRuleDTO.setTransactionId(fireWallRule.getTiRequest());
			if(fireWallRule.getSourceNetworkZone() != null){
				firewallRuleDTO.setSourceNetworkSegment(fireWallRule.getSourceNetworkZone().getName());
			} else {
				firewallRuleDTO.setSourceNetworkSegment(DOUBLE_QUOTES);
			}
			if(fireWallRule.getDestinationNetworkZone() != null){
				firewallRuleDTO.setDestinationNetworkSegment(fireWallRule.getDestinationNetworkZone().getName());
			} else {
				firewallRuleDTO.setDestinationNetworkSegment(DOUBLE_QUOTES);
			}
			IpAddressDTO ipAddressDTO = null;
			
			
			String tpaFlag = manageTIProcess.getTPAFlagforRule(fireWallRule.getId());
			
			String ofacFlag = manageTIProcess.getOFACFlagforRule(fireWallRule.getId());
			log.info("****************convertFirewallRuleToFirewallRuleDTO ofacFlag-******"+ofacFlag);
			
			String thirdParty = new String();
			
			if ("3rd Party/CEP".equals(tiRequestDTO.getSourceResourceType()) ||
					"3rd Party/CEP".equals(tiRequestDTO.getTargetResourceType())) {
				thirdParty = Y;
			}
			List<FlagDTO> flagList = new ArrayList<FlagDTO>();
			
			
			FlagDTO tpaFlagDTO = new FlagDTO();
			tpaFlagDTO.setKey("TPA");
			FlagDTO ofacFlagDTO = new FlagDTO();
			ofacFlagDTO.setKey("OFAC");
			if(tpaFlag.equals("N")){
			ofacFlagDTO.setValue(ofacFlag);
			}
			else{
				ofacFlagDTO.setValue("N");
			}
			//TODO:will remvoe this code once testing completed
			tpaFlagDTO.setValue(fireWallRule.isDrools()?fireWallRule.getTpa(): tpaFlag);
			//tpaFlagDTO.setValue(fireWallRule.isDrools()?fireWallRule.getOfac: tpaFlag);
			flagList.add(tpaFlagDTO);
			flagList.add(ofacFlagDTO);
			
			//TOD will remove below code 
			
			if (fireWallRule.isDrools() && "THIRD_PARTY".equalsIgnoreCase(tiRequestDTO.getRelationshipType())){
				thirdParty = Y;
			} else if(fireWallRule.isDrools()){
				thirdParty = N;
			}
			FlagDTO thridPartyFlagDTO = new FlagDTO();
			thridPartyFlagDTO.setKey("THIRD_PARTY");
			thridPartyFlagDTO.setValue(thirdParty);
			flagList.add(thridPartyFlagDTO);
			firewallRuleDTO.getRiskCheckFlags().addAll(flagList);
			firewallRuleDTO.setSourceIPAddress(new ArrayList<IpAddressDTO>());
			if (fireWallRule.getRiskSourceIPs() != null && !fireWallRule
					.getRiskSourceIPs().isEmpty()) {
				String srcTPA = N;
			    for (FireWallRuleIP fireWallRuleSourceIP : fireWallRule.getRiskSourceIPs()) {
			    	ipAddressDTO = new IpAddressDTO();
			    	ipAddressDTO.setIpAddress(fireWallRuleSourceIP.getIpAddress().getIpAddress());
			    	ipAddressDTO.setAnyIP(Y.equalsIgnoreCase(fireWallRuleSourceIP.getIpAddress().getAnyIP()) ? true : false);
			    	ipAddressDTO.setTpa(Y.equalsIgnoreCase(fireWallRuleSourceIP.getIpAddress().getTpaFlag()) ? true : false);
			    	if (ipAddressDTO.isTpa()) {
			    		srcTPA = Y;
			    	}	else {
			    		srcTPA = N;
			    	}
			    	
			    	firewallRuleDTO.getSourceIPAddress().add(ipAddressDTO);
			    }
			    FlagDTO flagDTO = new FlagDTO();
				flagDTO.setKey("SRCTPA");
				flagDTO.setValue(srcTPA);
				flagList.add(flagDTO);
				firewallRuleDTO.getRiskCheckFlags().addAll(flagList);
			} else {
				IpAddressDTO ipAddress = new IpAddressDTO();
				ipAddress.setIpAddress(DOUBLE_QUOTES);
				firewallRuleDTO.getSourceIPAddress().add(ipAddress);
			}
			firewallRuleDTO.setDestinationIPAddress(new ArrayList<IpAddressDTO>());
			if (fireWallRule.getRiskDestinationIPs() != null && !fireWallRule
					.getRiskDestinationIPs().isEmpty()) {
				String dstTPA = N;
			    for (FireWallRuleIP fireWallRuleDestinationIP : fireWallRule.getRiskDestinationIPs()) {
			    	ipAddressDTO = new IpAddressDTO();
			    	ipAddressDTO.setIpAddress(fireWallRuleDestinationIP.getIpAddress().getIpAddress());
			    	ipAddressDTO.setAnyIP(Y.equalsIgnoreCase(fireWallRuleDestinationIP.getIpAddress().getAnyIP()) ? true : false);
			    	ipAddressDTO.setTpa(Y.equalsIgnoreCase(fireWallRuleDestinationIP.getIpAddress().getTpaFlag()) ? true : false);
			    	if (ipAddressDTO.isTpa()) {
			    		dstTPA = Y;
			    	}	else {
			    		dstTPA = N;
			    	}
			    	firewallRuleDTO.getDestinationIPAddress().add(ipAddressDTO);
			    }
			    FlagDTO flagDTO = new FlagDTO();
				flagDTO.setKey("DSTTPA");
				flagDTO.setValue(dstTPA);
				flagList.add(flagDTO);
				firewallRuleDTO.getRiskCheckFlags().addAll(flagList);
			} else {
				IpAddressDTO ipAddress = new IpAddressDTO();
				ipAddress.setIpAddress(DOUBLE_QUOTES);
				firewallRuleDTO.getDestinationIPAddress().add(ipAddress);
			}
			firewallRuleDTO.setPort(new ArrayList<PortDTO>());
			if (fireWallRule.getRiskPorts() != null && !fireWallRule
					.getRiskPorts().isEmpty()) {
			    for (FireWallRulePort fireWallRulePort : fireWallRule.getRiskPorts()) {
			    	PortDTO portDTO  = new PortDTO();
			    	portDTO.setPortNumber(fireWallRulePort.getPort().getPortNumber());
			    	if (!"1-65535".equalsIgnoreCase(fireWallRulePort.getPort().getPortNumber())
			    			&& ("TCP".equalsIgnoreCase(fireWallRulePort.getPort().getProtocol())
			    			|| "UDP".equalsIgnoreCase(fireWallRulePort.getPort().getProtocol()))) {
			    		if (fireWallRulePort.getPort().getPortNumber().indexOf("-") != -1) {
			    			String[] portRange = fireWallRulePort.getPort().getPortNumber().split("-");
			    			portDTO.setStartPort(Long.valueOf(portRange[0]));
				    		portDTO.setEndPort(Long.valueOf(portRange[1]));
			    		} else {
			    			portDTO.setStartPort(Long.valueOf(fireWallRulePort.getPort().getPortNumber()));
				    		portDTO.setEndPort(Long.valueOf(fireWallRulePort.getPort().getPortNumber()));
			    		}
			    	} else {
			    		portDTO.setStartPort(0L);
			    		portDTO.setEndPort(0L);
			    	}
			    	portDTO.setProtocol(fireWallRulePort.getPort().getProtocol());
			    	portDTO.setDefaultService(Y.equalsIgnoreCase(fireWallRulePort.getDefaultService()) ? true : false);
			    	firewallRuleDTO.getPort().add(portDTO);
			    }
			}
			log.debug("------------------------------------------------------------------------------------------------------------------");
			log.debug("								INPUT::");
			log.debug("------------------------------------------------------------------------------------------------------------------");
			log.debug(DOUBLE_QUOTES);
			log.debug("CCR " + firewallRuleDTO.getTransactionId());
			log.debug(DOUBLE_QUOTES);
			log.debug("Source IP(s)::");
			log.debug("----------------------");
			for (int ipCount=0;ipCount < firewallRuleDTO.getSourceIPAddress().size();ipCount++) {
				ipAddressDTO = (IpAddressDTO)firewallRuleDTO.getSourceIPAddress().get(ipCount); 
				log.debug("IPAddress:: " + ipAddressDTO.getIpAddress() + "  is TPA:: " + ipAddressDTO.isTpa());
			}
			log.debug("----------------------");
			log.debug("Destination IP(s)::");
			log.debug("----------------------");
			for (int ipCount=0;ipCount < firewallRuleDTO.getDestinationIPAddress().size();ipCount++) {
				ipAddressDTO = (IpAddressDTO)firewallRuleDTO.getDestinationIPAddress().get(ipCount); 
				log.debug("IPAddress:: " + ipAddressDTO.getIpAddress() + "  is TPA:: " + ipAddressDTO.isTpa());
			}
			log.debug("----------------------");
			log.debug("Port(s)::");
			log.debug("----------------------");
			for (int portCount=0;portCount < firewallRuleDTO.getPort().size();portCount++) {
				PortDTO portDTO = (PortDTO)firewallRuleDTO.getPort().get(portCount); 
				log.debug("Port Number:: " + portDTO.getPortNumber() + " :: Protocol:: " + portDTO.getProtocol() + "Start :: " + portDTO.getStartPort() + " :: End:: " + portDTO.getEndPort() + " :: Default Service :: " + portDTO.isDefaultService());
			}
			log.debug(DOUBLE_QUOTES);
			log.debug(DOUBLE_QUOTES);
		} else {
			firewallRuleDTO.setSourceNetworkSegment(DOUBLE_QUOTES);
			firewallRuleDTO.setDestinationNetworkSegment(DOUBLE_QUOTES);
			
			IpAddressDTO ipAddress = new IpAddressDTO();
			ipAddress.setIpAddress(DOUBLE_QUOTES);
			firewallRuleDTO.setSourceIPAddress(new ArrayList<IpAddressDTO>());
			firewallRuleDTO.setDestinationIPAddress(new ArrayList<IpAddressDTO>());
			firewallRuleDTO.getSourceIPAddress().add(ipAddress);
			firewallRuleDTO.getDestinationIPAddress().add(ipAddress);
			
			PortDTO port = new PortDTO();
			port.setPortNumber(DOUBLE_QUOTES);
			port.setProtocol(DOUBLE_QUOTES);
			port.setStartPort(0L);
			port.setEndPort(0L);
			firewallRuleDTO.setPort(new ArrayList<PortDTO>());
			firewallRuleDTO.getPort().add(port);
		}
		log.debug("convertFirewallRuleToFirewallRuleDTO --End");
		return firewallRuleDTO;
		
	}
	public HashMap<String, OstiaQuestionnaire> convertFirewallRuleDTOToFirewallRule(FirewallRuleDTO outputFirewallRuleDTO) {
		
		HashMap<String, OstiaQuestionnaire> questionnaireMap = new HashMap<String, OstiaQuestionnaire>();
		
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("								FIREWALL RULE OUTPUT::");
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug(DOUBLE_QUOTES);
		log.debug("Risk Definition Count()"
				 + " for CCR " + outputFirewallRuleDTO.getTransactionId() + " is :: "+ outputFirewallRuleDTO.getOstiaQuestionnaires().getRiskDefinitions().size());
		log.debug(DOUBLE_QUOTES);
		for (int i=0; i < outputFirewallRuleDTO.getOstiaQuestionnaires().getRiskDefinitions().size(); i++) {
			RiskDefinitionDTO riskDefinition = (RiskDefinitionDTO)outputFirewallRuleDTO.getOstiaQuestionnaires().getRiskDefinitions().get(i);
//			log.info("Ostia Questions for Risk Definition [ " + i + "] :: "
//				+ riskDefinition.getRiskCode());
			log.debug("Number of Ostia Questions for Risk Definition [" + (i+1) + "] :: "
					+ riskDefinition.getRiskCode() + " are :: " + riskDefinition.getOstiaQuestion().size());
			log.debug("----------------------");
			for (int j=0;j < riskDefinition.getOstiaQuestion().size();j++) {
				OstiaQuestionDTO ostiaQuestion = (OstiaQuestionDTO)riskDefinition.getOstiaQuestion().get(j);
//				log.info("Ostia Question [" + j + "] :: Question Control Code :: " + ostiaQuestion.getQuestionControlNumber()
//						+ " :: Question :: " + ostiaQuestion.getQuestion() + " :: Answer Type :: " + ostiaQuestion.getAnswerType()
//						+ " :: Answer Group :: " + ostiaQuestion.getOptionsGroupName());
				log.debug("Ostia Question [" + (j+1) + "] :: Question Control Code :: " + ostiaQuestion.getQuestionControlNumber()
						+ " :: Question :: " + ostiaQuestion.getQuestion() + " :: Answer Type :: " + ostiaQuestion.getAnswerType()
						+ " :: Answer Group :: " + getPossibleAnswers(ostiaQuestion.getPossibleAnswers()));
			}
			log.debug("----------------------");
			log.debug(DOUBLE_QUOTES);
		}
		
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("								REQUEST RULE OUTPUT::");
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug(DOUBLE_QUOTES);
		log.debug("Risk Definition Count()"
				 + " for CCR " + outputFirewallRuleDTO.getTransactionId() + " is :: "+ outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires().getRiskDefinitions().size());
		log.debug(DOUBLE_QUOTES);
		if(outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires()!=null){
		for (int i=0; i < outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires().getRiskDefinitions().size(); i++) {
			RiskDefinitionDTO riskDefinition = (RiskDefinitionDTO)outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires().getRiskDefinitions().get(i);
//			log.info("Ostia Questions for Risk Definition [ " + i + "] :: "
//				+ riskDefinition.getRiskCode());
			log.debug("Number of Ostia Questions for Risk Definition [" + (i+1) + "] :: ("+riskDefinition.getRiskRating()+")"
					+ riskDefinition.getRiskCode() + " are :: " + riskDefinition.getOstiaQuestion().size());
			log.debug("----------------------");
			for (int j=0;j < riskDefinition.getOstiaQuestion().size();j++) {
				OstiaQuestionDTO ostiaQuestion = (OstiaQuestionDTO)riskDefinition.getOstiaQuestion().get(j);
//				log.info("Ostia Question [" + j + "] :: Question Control Code :: " + ostiaQuestion.getQuestionControlNumber()
//						+ " :: Question :: " + ostiaQuestion.getQuestion() + " :: Answer Type :: " + ostiaQuestion.getAnswerType()
//						+ " :: Answer Group :: " + ostiaQuestion.getOptionsGroupName());
				log.debug("Ostia Question [" + (j+1) + "] :: Question Control Code :: " + ostiaQuestion.getQuestionControlNumber()
						+ " :: Question :: " + ostiaQuestion.getQuestion() + " :: Answer Type :: " + ostiaQuestion.getAnswerType()
						+ " :: Answer Group :: " + getPossibleAnswers(ostiaQuestion.getPossibleAnswers()));
			}
			log.debug("----------------------");
			log.debug(DOUBLE_QUOTES);
		}
		}
		
		//List<OstiaQuestionnaire> ostiaQuestionnaires = new ArrayList<OstiaQuestionnaire>();
		OstiaQuestionnaire ostiaQuestionnaire = null;
		
		//FirewallRuleOstiaQuestion firewallRuleOstiaAnswer = null;
		
		//List<FirewallRuleOstiaQuestion> firewallRuleOstiaAnswers = new ArrayList<FirewallRuleOstiaQuestion>();
		
		if (outputFirewallRuleDTO.getOstiaQuestionnaires() != null
				) {
			
			OstiaQuestionnaireDTO ostiaQuestionnaireDTO 
						= outputFirewallRuleDTO.getOstiaQuestionnaires();
			List<RiskDefinitionDTO> riskDefinitionDTOs 
							= ostiaQuestionnaireDTO.getRiskDefinitions();
			
			ostiaQuestionnaire = new OstiaQuestionnaire();
			ostiaQuestionnaire.setCode(ostiaQuestionnaireDTO.getCode());
			ostiaQuestionnaire.setDescription(ostiaQuestionnaireDTO.getDescription());
			ostiaQuestionnaire.setType(ostiaQuestionnaireDTO.getType());
			ostiaQuestionnaire.setBaselineName(ostiaQuestionnaireDTO.getBaselineName());
			ostiaQuestionnaire.setBaselineReportUrl(ostiaQuestionnaireDTO.getBaselineReportUrl());
			
			ostiaQuestionnaire.setRiskDefinitions(new ArrayList<RiskDefinition>());
			RiskDefinition riskDefinition = null;
			for (RiskDefinitionDTO riskDefinitionDTO : riskDefinitionDTOs) {
				riskDefinition = new RiskDefinition();
				riskDefinition.setRiskCode(riskDefinitionDTO.getRiskCode());
				riskDefinition.setRiskDescription(riskDefinitionDTO.getRiskDescription());
				if (riskDefinitionDTO.getRiskRating() != null) {
					riskDefinition.setRiskRating(riskDefinitionDTO.getRiskRating().doubleValue());
				}
				riskDefinition.setOstiaQuestions(new ArrayList<OstiaQuestion>());
				OstiaQuestion ostiaQuestion = null;
				
				List<OstiaQuestionDTO> ostiaQuestionDTOs =  riskDefinitionDTO.getOstiaQuestion();
				Collections.reverse(ostiaQuestionDTOs);
				for (OstiaQuestionDTO ostiaQuestionDTO : ostiaQuestionDTOs) {
					ostiaQuestion = new OstiaQuestion();
					ostiaQuestion.setQuestionControlNumber(ostiaQuestionDTO.getQuestionControlNumber());
					log.debug("Question   "+ostiaQuestionDTO.getQuestion());
					log.debug("Hint  "+ostiaQuestionDTO.getHint());
					log.debug("Answer Type "+ostiaQuestionDTO.getAnswerType());
					ostiaQuestion.setQuestion(ostiaQuestionDTO.getQuestion());
					ostiaQuestion.setHint(ostiaQuestionDTO.getHint());
					ostiaQuestion.setAnswerType(ostiaQuestionDTO.getAnswerType());
					
					PossibleAnswers possibleAnswers = null;
					ostiaQuestion.setPossibleAnswers(new ArrayList<PossibleAnswers>());
					
					if ("SELECT".equalsIgnoreCase(ostiaQuestionDTO.getAnswerType())
							|| "MULTISELECT".equalsIgnoreCase(ostiaQuestionDTO.getAnswerType())) {
						List<PossibleAnswersDTO> possibleAnswersDTOs = ostiaQuestionDTO.getPossibleAnswers();
						for (PossibleAnswersDTO possibleAnswersDTO : possibleAnswersDTOs) {
							possibleAnswers = new PossibleAnswers();
							possibleAnswers.setAnswer(possibleAnswersDTO.getAnswer());
							possibleAnswers.setOptionsGroupName(possibleAnswersDTO.getOptionsGroupName());
							ostiaQuestion.getPossibleAnswers().add(possibleAnswers);
						}
					}
					
					riskDefinition.getOstiaQuestions().add(ostiaQuestion);
				}
				ostiaQuestionnaire.getRiskDefinitions().add(riskDefinition);
			}
			
		}
		questionnaireMap.put("FWRULE", ostiaQuestionnaire);
		
		ostiaQuestionnaire = null;
		
		if (outputFirewallRuleDTO.getTiRequest() != null && outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires() != null) {
			OstiaQuestionnaireDTO ostiaQuestionnaireDTO 
						= outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires();
			List<RiskDefinitionDTO> riskDefinitionDTOs 
							= ostiaQuestionnaireDTO.getRiskDefinitions();
			
			ostiaQuestionnaire = new OstiaQuestionnaire();
			ostiaQuestionnaire.setCode(ostiaQuestionnaireDTO.getCode());
			ostiaQuestionnaire.setDescription(ostiaQuestionnaireDTO.getDescription());
			ostiaQuestionnaire.setType(ostiaQuestionnaireDTO.getType());
			ostiaQuestionnaire.setBaselineName(ostiaQuestionnaireDTO.getBaselineName());
			ostiaQuestionnaire.setBaselineReportUrl(ostiaQuestionnaireDTO.getBaselineReportUrl());
			
			ostiaQuestionnaire.setRiskDefinitions(new ArrayList<RiskDefinition>());
			RiskDefinition riskDefinition = null;
			for (RiskDefinitionDTO riskDefinitionDTO : riskDefinitionDTOs) {
				riskDefinition = new RiskDefinition();
				riskDefinition.setRiskCode(riskDefinitionDTO.getRiskCode());
				riskDefinition.setRiskDescription(riskDefinitionDTO.getRiskDescription());
				riskDefinition.setOstiaQuestions(new ArrayList<OstiaQuestion>());
				OstiaQuestion ostiaQuestion = null;
				
				List<OstiaQuestionDTO> ostiaQuestionDTOs =  riskDefinitionDTO.getOstiaQuestion();
				
				for (OstiaQuestionDTO ostiaQuestionDTO : ostiaQuestionDTOs) {
					ostiaQuestion = new OstiaQuestion();
					ostiaQuestion.setQuestionControlNumber(ostiaQuestionDTO.getQuestionControlNumber());
					ostiaQuestion.setQuestion(ostiaQuestionDTO.getQuestion());
					ostiaQuestion.setHint(ostiaQuestionDTO.getHint());
					ostiaQuestion.setAnswerType(ostiaQuestionDTO.getAnswerType());
					riskDefinition.getOstiaQuestions().add(ostiaQuestion);
				}
				ostiaQuestionnaire.getRiskDefinitions().add(riskDefinition);
			}
			
		}
		questionnaireMap.put("REQUEST", ostiaQuestionnaire);
		return questionnaireMap;
	}
	
	private String getPossibleAnswers(List<PossibleAnswersDTO> possibleAnswers) {
		StringBuffer buffer = new StringBuffer();
		for (PossibleAnswersDTO possibleAnswersDTO : possibleAnswers) {
			if (possibleAnswersDTO != null) {
				buffer.append(possibleAnswersDTO.getAnswer() + " , ");
			}
		}
		return buffer.toString();
	}
}
