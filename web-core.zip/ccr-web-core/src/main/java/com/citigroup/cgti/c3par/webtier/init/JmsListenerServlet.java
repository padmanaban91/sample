/**
 * 
 */
package com.citigroup.cgti.c3par.webtier.init;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.listener.DefaultMessageListenerContainer;

import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;

/**
 * @author ka58098
 *
 */
public class JmsListenerServlet extends HttpServlet {

    private static final long serialVersionUID = -5127557128243882950L;
    private static Logger LOGGER = Logger.getLogger(JmsListenerServlet.class);

    public static final String JMS_CONTROL_BEAN = "controlJmsListener";
    public static final String RESOLVEIT_LISTENER_BEAN = "resolveIT";
    public static final String SERVICENOW_LISTENER_BEAN = "serviceNow";
    public static final String ONEAPPROVAL_LISTENER_BEAN = "listenerContainer";

    private ApplicationContext context = null;

    public void init(ServletConfig config) throws ServletException {
        try {
            context = CCRApplicationContextUtils.getApplicationContext();

            LOGGER.info("context is : " + context);
            ControlJmsListener controlJmsListener = (ControlJmsListener) context.getBean(JMS_CONTROL_BEAN);
            String resolveItJms = controlJmsListener.getResolveItJms();
            String serviceNowJms = controlJmsListener.getServiceNowJms();
            String oneApprovalJms = controlJmsListener.getOneApprovalJms();

            LOGGER.info("DB Values retreived for resolveItJms is : " + resolveItJms + " , serviceNowJms value is  "
                    + serviceNowJms + " and oneApprovalJms is : " + oneApprovalJms);

            if (resolveItJms != null) {
                startStopJms(RESOLVEIT_LISTENER_BEAN, resolveItJms);
            }
            if (serviceNowJms != null) {
                startStopJms(SERVICENOW_LISTENER_BEAN, serviceNowJms);
            }
            if (oneApprovalJms != null) {
                startStopJms(ONEAPPROVAL_LISTENER_BEAN, oneApprovalJms);
            }
            ((ConfigurableApplicationContext) context).start();
            LOGGER.info("Exiting..");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void startStopJms(String jmsName, String status) {
        LOGGER.info("Entering with jmsName : " + jmsName + " and status : " + status);
        DefaultMessageListenerContainer customRegistry = context.getBean(jmsName,
                DefaultMessageListenerContainer.class);
        LOGGER.info("customRegistry : " + customRegistry);
        if ("false".equalsIgnoreCase(status)) {
            // customRegistry.stop();
            customRegistry.shutdown();
            LOGGER.info("JMS Listener : " + jmsName + " shutdown successfully..!!!");
        } else if ("true".equalsIgnoreCase(status)) {
            customRegistry.start();
            LOGGER.info("JMS Listener : " + jmsName + " started successfully..!!!");
        }
        LOGGER.info(" JMS Listener isRunning :: " + customRegistry.isRunning());
        LOGGER.info(" JMS Listener isActive :: " + customRegistry.isActive());
        LOGGER.info("Exiting");
    }

}
