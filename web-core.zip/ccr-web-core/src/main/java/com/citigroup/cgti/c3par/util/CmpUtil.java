/**
 * 
 */
package com.citigroup.cgti.c3par.util;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.LinkedList;

import org.apache.log4j.Logger;

/**
 * @author ka58098
 *
 */
public class CmpUtil  extends FilterInputStream {
	private static Logger log = Logger.getLogger(CmpUtil.class);
    LinkedList<Integer> inQueue = new LinkedList<Integer>();
    LinkedList<Integer> outQueue = new LinkedList<Integer>();
    final byte[] search, replacement;
    public boolean flag=true;

    public CmpUtil(InputStream in, byte[] search,byte[] replacement) {
        super(in);
        log.debug(" InputStream value is::"+in);
        this.search = search;
        this.replacement = replacement;
    }

    private boolean isMatchFound() {
        Iterator<Integer> inIter = inQueue.iterator();
        for (int i = 0; i < search.length; i++)
            if (!inIter.hasNext() || search[i] != inIter.next())
                return false;
        return true;
    }

    private void readAhead() throws IOException {
        // Work up some look-ahead.
        while (inQueue.size() < search.length) {
            int next = super.read();
            inQueue.offer(next);
            if (next == -1)
                break;
        }
    }


    @Override
    public int read() throws IOException {
    	if (outQueue.isEmpty()){
            readAhead();
            if (isMatchFound()) {
                for (int i = 0; i < search.length; i++)
                	 inQueue.remove();
                for (byte b : replacement){
                	outQueue.offer((int) b);
                }
                flag=false;
                
            } else{
            	if(flag){
            		inQueue.remove();
            		return 888;
            	}else{
            		outQueue.add(inQueue.remove());
            	}
          
            }
                
        }
        return outQueue.remove();
    }

    // TODO: Override the other read methods.
}