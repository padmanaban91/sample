package com.citigroup.cgti.c3par.acv;


import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.ccr.workflow.CCRWorkflowConstants;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.WorkflowResult;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;


@Component
public class ProcessACV {
	
	private static Logger log = Logger.getLogger(ProcessACV.class);
	  
	@Autowired
	ManageTIProcessImpl manageTIProcessImpl;
	
	@Autowired
	WorkflowUtil workflowUtil;
	
	@Autowired
	WorkflowCallServiceHelper wrkflowCallServiceHelper;
	
	@Transactional(propagation = Propagation.REQUIRES_NEW, timeout=1200)
	public void intiateACVPhase(long tiProcessId,String requestType) {
		try{
		log.info("ProcessACV : intiateACVPlanningPhase : tiProcessId :"+tiProcessId);
		log.info("ProcessACV : intiateACVPlanningPhase : requestType :"+requestType);
		Map<String, Object> workFlowParams=workflowUtil.buildWorkflowParamsForACV(tiProcessId,requestType);
		WorkflowResult workResult=wrkflowCallServiceHelper.callWorkflowService(FlowType.ACV, workFlowParams, WorkflowEvent.CREATE, null);
		} catch (Exception e) {
	    	log.info("Exception in ProcessACV : intiateACVPhase :"+e);
	    	e.printStackTrace();
	    }
	}

	public void completeACVPhase(long tiProcessId, String soeId) {
		try{
		log.info("ProcessACV : completeACVPhase : tiProcessId :"+tiProcessId);
		log.info("ProcessACV : completeACVPhase : soeId :"+soeId);
		long tiRequestId=manageTIProcessImpl.getTiRequestIdForACV(tiProcessId);
		log.info("ProcessACV : completeACVPhase : tiRequestId :"+tiRequestId);			
		
		long workItemId=workflowUtil.getWorkItemByTiRequestId(tiRequestId,"ACV");
		log.info("ProcessACV : completeACVPhase : workItemId :"+workItemId);
		
		Map<String, Object> userFlowParams=workflowUtil.buildWorkflowParamsForLock(soeId, tiRequestId, null);
		userFlowParams.put(CCRWorkflowConstants.TASK_SUMMARY, workflowUtil.getTaskSummary(workItemId));
		
		//LOCK ACV
		wrkflowCallServiceHelper.callWorkflowService(FlowType.ACV, userFlowParams, WorkflowEvent.LOCK, tiRequestId);
			
		//SUBMIT ACV
		Map<String, Object> submitFlowParams=workflowUtil.buildWorkflowParamsForLock(soeId, tiRequestId, null);
		submitFlowParams.put(CCRWorkflowConstants.TASK_SUMMARY, workflowUtil.getTaskSummary(workItemId));
		submitFlowParams.put("submitAction", ActivityDataDTO.STATUS_COMPLETED);
		wrkflowCallServiceHelper.callWorkflowService(FlowType.ACV, submitFlowParams, WorkflowEvent.COMPLETE, tiRequestId);
		} catch (Exception e) {
	    	log.info("Exception in ProcessACV : completeACVPhase :"+e);
	    	e.printStackTrace();
	    }
	}
	
	public boolean updateACVFlag(long tiProcessId,String acvFlag) {
		boolean isACVFlagUpdated = false;
		try{
		log.info("ProcessACV : updateACVFlag : tiProcessId :"+tiProcessId);
		log.info("ProcessACV : updateACVFlag : acvFlag :"+acvFlag);
		long tiRequestId=manageTIProcessImpl.getTiRequestIdForACV(tiProcessId);
		log.info("ProcessACV : updateACVFlag : tiRequestId :"+tiRequestId);	
		isACVFlagUpdated = manageTIProcessImpl.verifySOWUpdate(tiRequestId,acvFlag,"");
		} catch (Exception e) {
	    	log.info("Exception in ProcessACV : updateACVFlag :"+e);
	    	e.printStackTrace();
	    	return isACVFlagUpdated;
	    }
		return isACVFlagUpdated;
	}
	
}
