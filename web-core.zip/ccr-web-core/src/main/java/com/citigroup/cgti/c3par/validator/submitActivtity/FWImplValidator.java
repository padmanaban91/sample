package com.citigroup.cgti.c3par.validator.submitActivtity;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;

import com.citigroup.cgti.c3par.comments.domain.SubmitActivityErrors;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;

public class FWImplValidator implements Validator{
	
	/** The log. */
    private static Logger log = Logger.getLogger(FWImplValidator.class);

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub
		
	}
	
	public List<ObjectError> getFirewallImplementationMessage(Long tiReqId) {
		List<ObjectError> fwImplList = new ArrayList<ObjectError>();
	 	ObjectError fireflowTicketValidationCheck = fireflowTicketValidationCheck(tiReqId);
 	
	if (fireflowTicketValidationCheck!=null && !fireflowTicketValidationCheck.equals("")) {
	    fwImplList.add(fireflowTicketValidationCheck);
	}
	return fwImplList;
   }
	
	private ObjectError fireflowTicketValidationCheck(Long tiReqId) {	  
		  log.info("fireflowTicketValidationCheck() " + tiReqId);
	  
		  ObjectError message = null;
		
		//if fireflow enabled and FF tickets are not in validate status then restrict user from moving forward
		if((isFireFlowEnbled(tiReqId) && !isFFTicketsValidated(tiReqId))){
			message = new ObjectError("FIREFLOW_TICKET_VALIDATED",new String[]{SubmitActivityErrors.FWIMPL_FIREFLOW_TICKET_VALIDATED},null,null); 
			    log.debug(" fireflow ticket validated message is::" + message);
		}
		log.info("fireflowTicketValidationCheck() ends " + message);
		return message;
}
	
	private boolean isFFTicketsValidated(Long tiReqId) {
		FAFRequest fafRequest=new FAFRequest();
		return fafRequest.isFFTicketsValidated(tiReqId);
	}

	private boolean isFireFlowEnbled(Long tiReqId) {
		FAFRequest fafRequest=new FAFRequest();
		TIRequest tiRequest = fafRequest.getTIRequest(tiReqId);
		String fireFlowEnabled = tiRequest.getFireflowFlag();
		return "Y".equalsIgnoreCase(fireFlowEnabled);
	}


}
