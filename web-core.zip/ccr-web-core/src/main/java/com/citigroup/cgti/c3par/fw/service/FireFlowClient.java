package com.citigroup.cgti.c3par.fw.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.citigroup.cgti.c3par.fw.domain.FafFireflowTicket;
import com.citigroup.cgti.c3par.fw.domain.soc.fireflow.FireflowExternalizable;

public class FireFlowClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) { 
		System.out.println("test 1");
		String xmlString = "";
		//FireFlowService svcName = getFireFlowService();
		FireflowExternalizable svcName = getFireFlowService();
	//	TIRequest tiRequest = new TIRequest();
		//tiRequest.setId(1L);
	//	svcName.getFafFireflowTicket(tiRequest);
		FafFireflowTicket ticket = new FafFireflowTicket();
		//ticket.setId(11L);
		//svcName.parseFireflowTicketXml(ticket,"");
		//svcName.createFFTicket("temp");
		System.out.println("test complete");

	}
	
	
/*	private static FAF_FireFlowTicket getFireFlowService() {
		ApplicationContext ctx = new FileSystemXmlApplicationContext("/c3parWebApp/WEB-INF/applicationContextFireflow.xml");
		FireFlowService svc = (FireFlowService) ctx.getBean("fireflowService");
		return svc;
	}
*/	
	private static FireflowExternalizable getFireFlowService() {
		ApplicationContext ctx = new FileSystemXmlApplicationContext("/c3parWebApp/WEB-INF/applicationContextFireflow.xml");
		FireflowExternalizable svc = (FireflowExternalizable) ctx.getBean("fireflowExternalizable");
		//FireFlowService svc = (FireFlowService) ctx.getBean("fireflowService");
		return svc;
	}
	

}