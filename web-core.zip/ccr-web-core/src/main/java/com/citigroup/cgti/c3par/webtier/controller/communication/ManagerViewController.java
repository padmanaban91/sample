package com.citigroup.cgti.c3par.webtier.controller.communication;

import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;




@Controller
public class ManagerViewController {
        private Logger log = Logger.getLogger(this.getClass().getName());
        
        @RequestMapping(value = "/managerViewController.act", method = { RequestMethod.GET, RequestMethod.POST})
       public String initialize(HttpServletRequest request)  {
                
                log.debug("Entering into Manager View....");
                
                log.debug("Exiting from Manager View....");
                
                return "c3par.communication.managerView";


        }
}