package com.citigroup.cgti.c3par.controller.admin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.admin.domain.DailyLoad;
import com.citigroup.cgti.c3par.admin.domain.FirewallFreeze;
import com.citigroup.cgti.c3par.admin.domain.ManageFreezeProcess;
import com.citigroup.cgti.c3par.admin.domain.VacationFreeze;
import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.validator.admin.ManageFreezeValidator;
import com.citigroup.cgti.c3par.webtier.helper.ExcelReader;

@Controller 
public class ManageFreezeController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(ManageFreezeController.class);
	
	@Autowired
	@Qualifier("manageFreezeValidator") 
	private ManageFreezeValidator validator;
	
	private SimpleDateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy"); 
	  
	@RequestMapping(value = "/loadDailyLoad.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String loadDailyLoad(ModelMap model){
		log.info("ManageFreeze:loadDailyLoad starts here..");
		ManageFreezeProcess manageFreezeProcess = new ManageFreezeProcess();
		List<DailyLoad> dailyLoadList = manageFreezeProcess.getDailyLoad();
		manageFreezeProcess.setDlList(dailyLoadList);
		model.addAttribute("dailyLoadList",manageFreezeProcess);
		log.info("ManageFreeze:loadDailyLoad ends here..");
		return "c3par.admin.dailyLoad";
		
		
	}
	
	@RequestMapping(value = "/loadFirewallLoad.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String loadFirewallLoad(ModelMap model){
		ManageFreezeProcess manageFreezeProcess = new ManageFreezeProcess();
		List<FirewallFreeze> fwList = manageFreezeProcess.getFwFreeze();
		manageFreezeProcess.setFwFreezeList(fwList);
		model.addAttribute("fwList",manageFreezeProcess);
		return "c3par.admin.firewallFreeze";
	}
	
	@RequestMapping(value = "/loadVacationFreeze.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String loadVacationFreeze(ModelMap model){
		ManageFreezeProcess manageFreezeProcess = new ManageFreezeProcess();
		List<VacationFreeze> vacFreezeList = manageFreezeProcess.getVFreeze();
		manageFreezeProcess.setvFreezeList(vacFreezeList);
		model.addAttribute("vacfreezeList", manageFreezeProcess);
		return "c3par.admin.vacationFreeze";
	}
	
	
	@RequestMapping(value = "/uploadDailyLoad.act", method ={RequestMethod.GET,RequestMethod.POST})
	public String uploadDailyLoad(ModelMap model,@ModelAttribute("dailyLoadList") ManageFreezeProcess dlList,BindingResult res,HttpServletRequest request,@RequestParam("fileUpload") CommonsMultipartFile fileUpload) {
		log.info("AdminUploadDocAction upload DailyLoad methods starts here ....");
		ManageFreezeProcess manageFreezeProcess = new ManageFreezeProcess();
		 ExcelReader excelReader = new ExcelReader();
		POIFSFileSystem fileSystem = null;
		 try {
			  	fileSystem = new POIFSFileSystem(fileUpload.getInputStream());
			  	 log.debug("upload_dailyLoad" +fileUpload.getInputStream() );
			  	//read the xls file and save the data as arraylist
			    HSSFWorkbook workBook = new HSSFWorkbook(fileSystem);
			    ArrayList resultList = (ArrayList) excelReader.parseSheet(workBook, workBook.getSheetName(0),1,5);
//			    String user = request.getRemoteUser();
			    String user = request.getHeader("SM_USER");
			    List<DailyLoad> result = parseIntoDailyLoad(resultList,user,manageFreezeProcess); 
			    //DailyloadValidation
				List<ObjectError> err = validator.dailyLoadValidation(result);
				for (ObjectError error : err) {
					res.addError(error);
				}
				if(err==null || err.isEmpty()){
					manageFreezeProcess.saveDailyLoad(result);
				}
				
			 
			    		   
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		log.info("AdminUploadDocAction upload DailyLoad methods ends here ....");
		return "forward:/loadDailyLoad.act";
	}
	
	//read data from DailyLoad list from excel 
	public List<DailyLoad> parseIntoDailyLoad(List uploadedFile,String user,ManageFreezeProcess manageFreezeProcess) {
		List<DailyLoad> xlsObj = new ArrayList<DailyLoad>();
		DailyLoad dLoad = null;
		for (int i = 0; i < uploadedFile.size(); i++) {
		ArrayList rowList = (ArrayList) uploadedFile.get(i);
		if (rowList != null) {
				
						dLoad = new DailyLoad();
						if(rowList.get(0) != null && rowList.get(0).toString()!=null && !rowList.get(0).toString().isEmpty()){
								dLoad.setId(Double.valueOf((String)rowList.get(0)).longValue());
								}else {
									dLoad.setCreatedBy(user);
								}
						if(rowList.get(1) != null && !rowList.get(1).toString().isEmpty()){
							FirewallLocation loc = manageFreezeProcess.getFirewallLocByName((String)rowList.get(1));
							dLoad.setFwLoc(loc);	
						}
						if(rowList.get(2) != null && !rowList.get(2).toString().isEmpty()){
							GenericLookup genericLookup = manageFreezeProcess.getDay((String)rowList.get(2));
							dLoad.setGenericLookup(genericLookup);
							
						}
						if(rowList.get(3) != null && !rowList.get(3).toString().isEmpty()){
							dLoad.setLoadValue(Double.valueOf((String)rowList.get(3)).longValue());
							
						}
					
						if(rowList.get(4) != null && !rowList.get(4).toString().isEmpty() && (rowList.get(4).toString().equalsIgnoreCase("Y")
								|| rowList.get(4).toString().equalsIgnoreCase("N"))){
							dLoad.setGlobalData((String)rowList.get(4));
						}
						dLoad.setUpdated_date(new Date());
						dLoad.setCreated_date(new Date());
						dLoad.setUpdatedBy(user);
						xlsObj.add(dLoad);
						
					}
	}
		return xlsObj;
}
	
	
//upload Firewall Load
	@RequestMapping(value = "/uploadFwLoad.act", method ={RequestMethod.GET,RequestMethod.POST})
	public String uploadFwLoad(ModelMap model,@ModelAttribute("fwList") ManageFreezeProcess fwFreezeList,BindingResult res,HttpServletRequest request,@RequestParam("fileUpload") CommonsMultipartFile fileUpload) {
		log.info("AdminUploadDocAction upload FirewallLoad methods starts here ....");
		ManageFreezeProcess manageFreezeProcess = new ManageFreezeProcess();
		ExcelReader excelReader = new ExcelReader();
		POIFSFileSystem fileSystem = null;
		 try {
			 	fileSystem = new POIFSFileSystem(fileUpload.getInputStream());
			 	//read the xls file and save the data as arraylist
			    HSSFWorkbook workBook = new HSSFWorkbook(fileSystem);
			    ArrayList resultList = (ArrayList) excelReader.parseSheet(workBook, workBook.getSheetName(0),1,6);
//			    String user = request.getRemoteUser();
			    String user = request.getHeader("SM_USER");
			    log.debug("Fw freeze list final check"+resultList);
			    List<FirewallFreeze> result = parseIntoFwLoad(resultList,user,manageFreezeProcess);
			    log.debug("Fw freeze list final check parse"+result);
			  //FirewallFreezeValidation
				List<ObjectError> err = validator.firewallFreezeValidation(result);
				for (ObjectError error : err) {
					res.addError(error);
				}
				if(err==null || err.isEmpty()){
				manageFreezeProcess.saveFirewallFreeze(result);
				}
			    
			    
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		log.info("AdminUploadDocAction uploadFirewall method ends here ....");
		 return "forward:/loadFirewallLoad.act";
	}
	
	
	//read data from Firewall list from excel 
	public List<FirewallFreeze> parseIntoFwLoad(List uploadedFile,String user,ManageFreezeProcess manageFreezeProcess) {
		List<FirewallFreeze> xlsObj = new ArrayList<FirewallFreeze>();
		FirewallFreeze fw = null;
		FireWallRuleProcess fireWallRuleProcess = new FireWallRuleProcess();
		for (int i = 0; i < uploadedFile.size(); i++) {
			ArrayList rowList = (ArrayList) uploadedFile.get(i);
			if (rowList != null) {
						fw = new FirewallFreeze();
						
						if(rowList.get(0) != null && rowList.get(0).toString()!=null && !rowList.get(0).toString().isEmpty()){
						fw.setId(Double.valueOf((String)rowList.get(0)).longValue());
						}else {
							fw.setCreatedBy(user);
						}
						
						if(rowList.get(1) != null && !rowList.get(1).toString().isEmpty()){
							
							FirewallPolicy policy = fireWallRuleProcess.getFirewallPolicyByName((String)rowList.get(1));
							if(policy == null){
								continue;
							}
							fw.setFwPolicy(policy);
							log.debug("Firewall policy name and id ++"+fw.getFwPolicy());
							
						}
						
						if(rowList.get(2) != null && !rowList.get(2).toString().isEmpty()){
							fw.setRegion((String) rowList.get(2));
							log.debug("Region  ----"+rowList.get(2));	
						}
						
						if(rowList.get(3) != null && !rowList.get(3).toString().isEmpty()){
							
								try {
									fw.setFreezeStartDate(dateformat.parse((String)rowList.get(3)));
								} catch (ParseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							
						}
						  
						if(rowList.get(4) != null && !rowList.get(4).toString().isEmpty()){

                       	try {
							fw.setFreezeEndDate(dateformat.parse((String)rowList.get(4)));
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						
						}
						
						if(rowList.get(5) != null && !rowList.get(5).toString().isEmpty()){
							fw.setComments((String) rowList.get(5));
								
						}
						
						fw.setUpdated_date(new Date());
						fw.setCreated_date(new Date());
						fw.setUpdatedBy(user);
						xlsObj.add(fw);
					}
	}
		return xlsObj;
}
	
	
	//upload VacationFreeze
		@RequestMapping(value = "/uploadVacationFreeze.act", method ={RequestMethod.GET,RequestMethod.POST})
		public String uploadVacationFreeze(ModelMap model,@ModelAttribute("vacfreezeList") ManageFreezeProcess vFreezeList,BindingResult res,HttpServletRequest request,@RequestParam("fileUpload") CommonsMultipartFile fileUpload) {
			log.info("AdminUploadDocAction upload Vacation freeze methods starts here ....");
			ManageFreezeProcess manageFreezeProcess=new ManageFreezeProcess();
			ExcelReader excelReader = new ExcelReader();
			POIFSFileSystem fileSystem = null;
			 try {
				 fileSystem = new POIFSFileSystem(fileUpload.getInputStream());
				 //read the xls file and save the data as arraylist
				    HSSFWorkbook workBook = new HSSFWorkbook(fileSystem);
				    ArrayList resultList = (ArrayList) excelReader.parseSheet(workBook, workBook.getSheetName(0),1,5);
//				    String user = request.getRemoteUser();
				    String user = request.getHeader("SM_USER");
				    List<VacationFreeze> result = parseIntoVacationFreeze(resultList,user,manageFreezeProcess); 
					//VacationFreezeValidation
					List<ObjectError> err = validator.vacationFreezeValidation(result);
					for (ObjectError error : err) {
						res.addError(error);
					}
					if(err==null || err.isEmpty()){
					manageFreezeProcess.saveVacationFreeze(result);
					}
				    } 
			 catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			log.info("AdminUploadDocAction upload Vacation Freeze ends here ....");
			 return "forward:/loadVacationFreeze.act";
		}
		
		//read data from VacationFreeze list from excel 
		public List<VacationFreeze> parseIntoVacationFreeze(List uploadedFile,String user,ManageFreezeProcess manageFreezeProcess) {
			List<VacationFreeze> xlsObj = new ArrayList<VacationFreeze>();
			VacationFreeze vacFreeze = null;
			for (int i = 0; i < uploadedFile.size(); i++) {
				ArrayList rowList = (ArrayList) uploadedFile.get(i);
			
				if (rowList != null) {
					
					
						vacFreeze = new VacationFreeze();
						if(rowList.get(0) != null && rowList.get(0).toString()!=null && !rowList.get(0).toString().isEmpty()){
							vacFreeze.setId(Double.valueOf((String)rowList.get(0)).longValue());
						}else {
							vacFreeze.setCreatedBy(user);
						}
						
						if(rowList.get(1) != null && !rowList.get(1).toString().isEmpty()){
							FirewallLocation loc = manageFreezeProcess.getFirewallLocByName((String)rowList.get(1));
							vacFreeze.setFwLoc(loc);
							
						}
						
						if(rowList.get(2) != null && !rowList.get(2).toString().isEmpty()){
	                        	try {
									vacFreeze.setFromDate(dateformat.parse((String)rowList.get(2)));
								} catch (ParseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
						}
						
						if(rowList.get(3) != null && !rowList.get(3).toString().isEmpty()){
								try {
									vacFreeze.setToDate(dateformat.parse((String)rowList.get(3)));
								} catch (ParseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
						}
	                     
						if(rowList.get(4) != null && !rowList.get(4).toString().isEmpty()){
							try {
								Double loadAvailable = Double.valueOf((String)rowList.get(4));
								vacFreeze.setLoadAvailable(loadAvailable.longValue()+"");
							} catch(NumberFormatException e) {
								log.error(e, e);
								continue;
							}
						}
							
							vacFreeze.setUpdatedBy(user);
							vacFreeze.setUpdated_date(new Date());
							vacFreeze.setCreated_date(new Date());
							xlsObj.add(vacFreeze);
						}
		}
			return xlsObj;
	}
	
		//Export Daily Load
		@RequestMapping(value = "/exportDailyLoad.act", method = {RequestMethod.GET,RequestMethod.POST})
		public String exportDailyLoad(ModelMap model,@ModelAttribute("dailyLoadList") ManageFreezeProcess dlList,HttpServletResponse response) {
			ExcelReader excelReader = new ExcelReader();
			
			try {
				HSSFWorkbook newWorkBook = excelReader.dailyLoadExcel(dlList.getDailyLoad());
				
				File file = File.createTempFile("DailyLoad", ".xls");	
				log.debug("DailyLoad::file Path - "+file.getAbsolutePath());
				FileOutputStream out = new FileOutputStream(file);	
				newWorkBook.write(out);
				out.close();
				
				InputStream fis = new FileInputStream(file); 
				
				response.setContentType("application/vnd.ms-excel");  
				response.setContentLength((int) file.length());  
				response.setHeader("Content-Disposition", "attachment; filename=\"" + "DailyLoad.xls" + "\"");  
				ServletOutputStream os = response.getOutputStream();  
				byte[] bufferData = new byte[1024];  
				int read=0;  
				while((read = fis.read(bufferData))!= -1){  
				os.write(bufferData, 0, read);  
				}  
				os.flush();  
				os.close();  
				fis.close();  

			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
			
		}
		
		//Export Firewall freeze
		@RequestMapping(value = "/exportFwFreeze.act",method = {RequestMethod.GET,RequestMethod.POST})
		public String exportFwFreeze(ModelMap model,@ModelAttribute("fwList") ManageFreezeProcess fwFreezeList,HttpServletResponse response) {
			ExcelReader excelReader = new ExcelReader();
			
			try {
				HSSFWorkbook newWorkBook = excelReader.fwLoadExcel(fwFreezeList.getFwFreeze());
				
				File file = File.createTempFile("FirewallFreeze", ".xls");			
				log.debug("Firewall Freeze::file Path - "+file.getAbsolutePath());
				FileOutputStream out = new FileOutputStream(file);	
				newWorkBook.write(out);
				out.close();
				
				InputStream fis = new FileInputStream(file); 
				
				response.setContentType("application/vnd.ms-excel");  
				response.setContentLength((int) file.length());  
				response.setHeader("Content-Disposition", "attachment; filename=\"" + "FirewallFreeze.xls" + "\"");  
				ServletOutputStream os = response.getOutputStream();  
				byte[] bufferData = new byte[1024];  
				int read=0;  
				while((read = fis.read(bufferData))!= -1){  
				os.write(bufferData, 0, read);  
				}  
				os.flush();  
				os.close();  
				fis.close();  

			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		//Export Vacation Freeze
		@RequestMapping(value = "/exportVacationFreeze.act", method = {RequestMethod.GET,RequestMethod.POST})
		public String exportVacationFreeze(ModelMap model,@ModelAttribute("vacfreezeList") ManageFreezeProcess vFreezeList,HttpServletResponse response) {
			
			ExcelReader excelReader = new ExcelReader();
			
			try {
				HSSFWorkbook newWorkBook = excelReader.VacationFreezeExcel(vFreezeList.getVFreeze());
				
				File file = File.createTempFile("VacationFreeze", ".xls");			
				log.debug("Vacation Freeze::file Path - "+file.getAbsolutePath());
				FileOutputStream out = new FileOutputStream(file);	
				newWorkBook.write(out);
				out.close();
				
				InputStream fis = new FileInputStream(file); 
				
				response.setContentType("application/vnd.ms-excel");  
				response.setContentLength((int) file.length());  
				response.setHeader("Content-Disposition", "attachment; filename=\"" + "VacationFreeze.xls" + "\"");  
				ServletOutputStream os = response.getOutputStream();  
				byte[] bufferData = new byte[1024];  
				int read=0;  
				while((read = fis.read(bufferData))!= -1){  
				os.write(bufferData, 0, read);  
				}  
				os.flush();  
				os.close();  
				fis.close();  

			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		
	

}
