package com.citigroup.cgti.c3par.controller.firewall;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleOstiaAnswer;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleOstiaQuestion;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.RiskDefinition;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class FirewallOstiaController extends BaseController {
	
	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	private static final String LIST = "c3par.ostia.list";
	private static final String ANSWER_TUPLE_DETAILS = "pages/jsp/fw/answersAndTupleDetails";
	private static final String ANSWER = "answer";
	private static final String TUPLE = "tuple";
	private static final String FAF_IMPL_PAGE = "implPage";
	private static final String VIEW_REQUESTED = "requested";
	private static final String RISK_DEFINITIONS = "RISK_DEFINITIONS";

	
	@RequestMapping(value = "/listFirewallOstia.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String listFirewallOstia(HttpServletRequest request, ModelMap model) {
		String fromPage = request.getParameter("fromPage");
		FireWallRuleProcess fireWallRuleProcess = new FireWallRuleProcess();
		fireWallRuleProcess.setFromPage(fromPage);
		
		log.info("list method called, fromPage ==> "+fromPage);
		
		isCompleteCheck(request);
		Util util = new Util();
		String selTab = request.getParameter("sel_tab");
		String con_type="";
		
		//Ostia-IPReg changes
		if((request.getParameter("con_type"))!=null){
			con_type=request.getParameter("con_type");
			request.getSession().setAttribute("con_type",con_type);
			
		} else{
			con_type = (String) request.getSession().getAttribute("con_type");	
		}
		
		
		log.debug(" ConnectionType :: " + con_type);
		if( con_type!= null ){
			if("ipReg".equalsIgnoreCase(con_type))
			{
				fireWallRuleProcess.setIsIpReg("Y");
				log.debug(" IPRegistration :: " + con_type);
			}else
			{
				fireWallRuleProcess.setIsIpReg("N");
				log.debug(" Firewall :: " + con_type);
			}
		}
		if(selTab != null){
			request.getSession().setAttribute("selected_Tab", util.getSelectedTab(null, selTab,null));
		}
		
		if(fireWallRuleProcess.getPageFlow() != null){
			Object riskDefinitionsObject = request.getSession().getAttribute(RISK_DEFINITIONS);
			if(riskDefinitionsObject != null){
				//log.info("**********************list method called - riskDefinitions from request.Session");
				List<RiskDefinition> riskDefinitions = (List<RiskDefinition>)riskDefinitionsObject;
				fireWallRuleProcess.setRiskDefinitions(riskDefinitions);
			}
		}else{
			//log.info("**********************list method called - riskDefinitions from DataBase");
			retrieveRiskDefinitions(fireWallRuleProcess, request);
		}
		fireWallRuleProcess.setAggregate(fireWallRuleProcess.getRiskForCurrentCycle(getCurrentTiRequest(request).getId(),con_type));
		fireWallRuleProcess.setCycleAggregate(fireWallRuleProcess.getRiskForConn(getTiProcessId(request),con_type));
		fireWallRuleProcess.setIpCount(fireWallRuleProcess.getIPForConn(getTiProcessId(request),con_type));
		
		fireWallRuleProcess.setFirstResult(0);
		fireWallRuleProcess.setPageNo(1);
		fireWallRuleProcess.setMaxResult(5);
		
		retrieveFirewallRuleQuestionnaires(fireWallRuleProcess, request);
		
		model.addAttribute("fireWallRuleProcess", fireWallRuleProcess);
		
		return LIST;
		
	}
	
	
	@RequestMapping(value = "/paginateFirewallOstia.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String paginateFirewallOstia(HttpServletRequest request, ModelMap model, @ModelAttribute("firewallRuleProcess") FireWallRuleProcess fireWallRuleProcess) {
		
		log.info("list method called, getPageFlow ==> "+fireWallRuleProcess.getPageFlow()+" "+fireWallRuleProcess.getMaxResult());
		
		
		isCompleteCheck(request);
		Util util = new Util();
		String selTab = request.getParameter("sel_tab");
		String con_type="";
		
		//Ostia-IPReg changes
		if((request.getParameter("con_type"))!=null){
			con_type=request.getParameter("con_type");
			request.getSession().setAttribute("con_type",con_type);
		} else{
			con_type = (String) request.getSession().getAttribute("con_type");	
		}
		
		if ("next".equalsIgnoreCase(fireWallRuleProcess.getPageFlow())) {
			fireWallRuleProcess.setPageNo(fireWallRuleProcess.getPageNo()+1);
			fireWallRuleProcess.setFirstResult(fireWallRuleProcess.getMaxResult()+fireWallRuleProcess.getFirstResult());
		} else if ("previous".equalsIgnoreCase(fireWallRuleProcess.getPageFlow())) {
			fireWallRuleProcess.setPageNo(fireWallRuleProcess.getPageNo()-1);
			fireWallRuleProcess.setFirstResult(fireWallRuleProcess.getFirstResult()-fireWallRuleProcess.getMaxResult());
		} else	{
			fireWallRuleProcess.setFirstResult(0);
			fireWallRuleProcess.setPageNo(1);
			if (fireWallRuleProcess.getMaxResult() < 5) {
				fireWallRuleProcess.setMaxResult(5);
			}
		}
		
		
		log.debug(" ConnectionType :: " + con_type);
		if( con_type!= null ){
			if("ipReg".equalsIgnoreCase(con_type))
			{
				fireWallRuleProcess.setIsIpReg("Y");
				log.debug(" IPRegistration :: " + con_type);
			}else
			{
				fireWallRuleProcess.setIsIpReg("N");
				log.debug(" Firewall :: " + con_type);
			}
		}
		if(selTab != null){
			request.getSession().setAttribute("selected_Tab", util.getSelectedTab(null, selTab,null));
		}
		
		if(fireWallRuleProcess.getPageFlow() != null) {
			Object riskDefinitionsObject = request.getSession().getAttribute(RISK_DEFINITIONS);
			if(riskDefinitionsObject != null){
				//log.info("**********************list method called - riskDefinitions from request.Session");
				List<RiskDefinition> riskDefinitions = (List<RiskDefinition>)riskDefinitionsObject;
				fireWallRuleProcess.setRiskDefinitions(riskDefinitions);
			}
		} else {
			//log.info("**********************list method called - riskDefinitions from DataBase");
			retrieveRiskDefinitions(fireWallRuleProcess, request);
		}
		fireWallRuleProcess.setAggregate(fireWallRuleProcess.getRiskForCurrentCycle(getCurrentTiRequest(request).getId(),con_type));
		fireWallRuleProcess.setCycleAggregate(fireWallRuleProcess.getRiskForConn(getTiProcessId(request),con_type));
		fireWallRuleProcess.setIpCount(fireWallRuleProcess.getIPForConn(getTiProcessId(request),con_type));
		
		retrieveFirewallRuleQuestionnaires(fireWallRuleProcess, request);
		
		model.addAttribute("fireWallRuleProcess", fireWallRuleProcess);
		
		return LIST;
		
	}
	
	@RequestMapping(value = "/ostiaAnswers.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String ostiaAnswers(HttpServletRequest request, ModelMap model) {
		log.info("answers method called");
		FireWallRuleProcess fireWallRuleProcess = new FireWallRuleProcess();
		fireWallRuleProcess.setTab(request.getParameter("tab"));
		String ruleId = request.getParameter("ruleId");
		fireWallRuleProcess.setRuleId(Long.valueOf(ruleId));
		String fwQnrId = request.getParameter("fwQnrId");
		fireWallRuleProcess.setFirewallRuleQuestionnaire(fireWallRuleProcess.findFirewallRuleQuestionnaire(Long.valueOf(fwQnrId)));
		fireWallRuleProcess.setFirewallRuleOstiaAnswers(fireWallRuleProcess.findFirewallRuleOstiaAnswers());
		fireWallRuleProcess.setFireWallRule(fireWallRuleProcess.findFirewallRule());
		request.getSession().setAttribute("QUES_AND_ANS", fireWallRuleProcess.getFirewallRuleOstiaAnswers());
		model.addAttribute("fireWallRuleProcess", fireWallRuleProcess);
		return "pages/jsp/fw/answersAndTupleDetails";
	}
	
	@RequestMapping(value = "/tupleDetails.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String tupleDetails(HttpServletRequest request, ModelMap model) {
		log.info("tuple details method called");
		FireWallRuleProcess fireWallRuleProcess = new FireWallRuleProcess();
		String ruleId = request.getParameter("ruleId");
		fireWallRuleProcess.setRuleId(Long.valueOf(ruleId));
		fireWallRuleProcess.setFireWallRule(fireWallRuleProcess.findFirewallRule());
		model.addAttribute("fireWallRuleProcess", fireWallRuleProcess);
		return "pages/jsp/fw/tupleDetails";
	}
	
	@RequestMapping(value = "/ruleDetails.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String ruleDetails(HttpServletRequest request, ModelMap model, @ModelAttribute("fireWallRuleProcess") FireWallRuleProcess fireWallRuleProcess) {
		log.info("answers method called");
		try {
			log.debug("Tab name:"+request.getParameter("tab"));
			String displayMode = (String)request.getSession().getAttribute("displayMode");
			if ("Edit".equalsIgnoreCase(displayMode)) {
				fireWallRuleProcess.setTiRequest(getPreviousVersionTiRequestID(getTiProcessId(request), request));
				populateQuesAndAnswers(fireWallRuleProcess.getFirewallRuleOstiaAnswers(), request);
				fireWallRuleProcess.updateAnswer();
			}
			fireWallRuleProcess.setFirewallRuleQuestionnaire(fireWallRuleProcess.findFirewallRuleQuestionnaire());
			fireWallRuleProcess.setFireWallRule(fireWallRuleProcess.findFirewallRule());
			model.addAttribute("fireWallRuleProcess", fireWallRuleProcess);
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured on retrieving rule details... - "+e.getMessage());
		}
		return "pages/jsp/fw/answersAndTupleDetails";
	}
	
	@RequestMapping(value = "/updateOstiaAnswer.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String updateOstiaAnswer(HttpServletRequest request, ModelMap model, @ModelAttribute("fireWallRuleProcess") FireWallRuleProcess fireWallRuleProcess) {
		log.info("updateOstiaAnswer method called");
		fireWallRuleProcess.setTiRequest(getCurrentTiRequest(request).getId());
		populateQuesAndAnswers(fireWallRuleProcess.getFirewallRuleOstiaAnswers(), request);
		fireWallRuleProcess.updateAnswer();
		fireWallRuleProcess.setFirewallRuleQuestionnaire(fireWallRuleProcess.findFirewallRuleQuestionnaire());
		fireWallRuleProcess.setFirewallRuleOstiaAnswers(fireWallRuleProcess.findFirewallRuleOstiaAnswers());
		request.getSession().setAttribute("QUES_AND_ANS", fireWallRuleProcess.getFirewallRuleOstiaAnswers());
		isCompleteCheck(request);
		model.addAttribute("fireWallRuleProcess",fireWallRuleProcess);
		return "pages/jsp/fw/answersAndTupleDetails";
	}
	
	@RequestMapping(value = "/addUserFirewallRuleQuestionnaire.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String addUserFirewallRuleQuestionnaire(HttpServletRequest request, ModelMap model, @ModelAttribute("fireWallRuleProcess") FireWallRuleProcess fireWallRuleProcess) {
		log.info("addUserFirewallRuleQuestionnaire method called");
		fireWallRuleProcess.setTiRequest(getCurrentTiRequest(request).getId());
		fireWallRuleProcess.setFirewallRuleQuestionnaire(fireWallRuleProcess.findFirewallRuleQuestionnaire());
		FirewallRuleQuestionnaire firewallRuleQuestionnaire=fireWallRuleProcess.findFirewallRuleQuestionnaire();
		firewallRuleQuestionnaire.setUserQuestionnaire(fireWallRuleProcess.getUserQuestionnaireName());
		log.info("User Questionnaire name in action ************" + fireWallRuleProcess.getUserQuestionnaireName());
		Long userQuestionnaireId=fireWallRuleProcess.addUserFirewallRuleQuestionnaire(firewallRuleQuestionnaire);
		fireWallRuleProcess.getFirewallRuleQuestionnaire().setId(userQuestionnaireId);
		fireWallRuleProcess.setFirewallRuleQuestionnaire(fireWallRuleProcess.findFirewallRuleQuestionnaire());
		fireWallRuleProcess.setFirewallRuleOstiaAnswers(fireWallRuleProcess.findFirewallRuleOstiaAnswers());
		request.getSession().setAttribute("QUES_AND_ANS", fireWallRuleProcess.getFirewallRuleOstiaAnswers());
		isCompleteCheck(request) ;
		model.addAttribute("fireWallRuleProcess",fireWallRuleProcess);
		return ANSWER_TUPLE_DETAILS;
	}
	
	@RequestMapping(value = "/ostiaAddQuestionnaire.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String ostiaAddQuestionnaire(HttpServletRequest request, ModelMap model, @ModelAttribute("fireWallRuleProcess") FireWallRuleProcess fireWallRuleProcess) {
		model.addAttribute("fireWallRuleProcess",fireWallRuleProcess);
		return "pages/jsp/fw/OstiaAdditionalAnswer";
	}
	
	@RequestMapping(value = "/ostiaReview.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String ostiaReview(HttpServletRequest request, ModelMap model, @ModelAttribute("fireWallRuleProcess") FireWallRuleProcess fireWallRuleProcess) {
		log.info("ostiaReview method called");
		fireWallRuleProcess.updateFirewallRuleQuestionnaire(fireWallRuleProcess.getFirewallRuleQuestionnaire().getId(),"Reviewed");
		fireWallRuleProcess.setFirewallRuleQuestionnaire(fireWallRuleProcess.findFirewallRuleQuestionnaire());
		fireWallRuleProcess.setFirewallRuleOstiaAnswers(fireWallRuleProcess.findFirewallRuleOstiaAnswers());
		request.getSession().setAttribute("QUES_AND_ANS", fireWallRuleProcess.getFirewallRuleOstiaAnswers());
		model.addAttribute("fireWallRuleProcess",fireWallRuleProcess);
		return ANSWER_TUPLE_DETAILS;
	}
	
	
	@RequestMapping(value = "/cloneOstia.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String cloneOstia(HttpServletRequest request, ModelMap model, @ModelAttribute("fireWallRuleProcess") FireWallRuleProcess fireWallRuleProcess) {
		log.info("clone method called - cloneFrom - "+ fireWallRuleProcess.getCloneFrom() + "cloneTo - " + fireWallRuleProcess.getCloneTo().toString());
		String con_type="";
		
		//Ostia-IPReg changes
		if((request.getParameter("con_type"))!=null){
			con_type=request.getParameter("con_type");
			request.getSession().setAttribute("con_type",con_type);
			
		}
		else{
			con_type = (String) request.getSession().getAttribute("con_type");	
			
		}
		TIRequest req=getCurrentTiRequest(request);
		FirewallRuleQuestionnaire sourceQuestionnaire =fireWallRuleProcess.findFirewallRuleQuestionnaire(fireWallRuleProcess.getCloneFrom());
		List<FirewallRuleOstiaQuestion> srcFirewallRuleOstiaQuestions=sourceQuestionnaire.getFirewallRuleOstiaAnswers();
		for(Long questionnaireId:fireWallRuleProcess.getCloneTo()){
			FirewallRuleQuestionnaire targetQuestionnaire =fireWallRuleProcess.findFirewallRuleQuestionnaire(questionnaireId);
			List<FirewallRuleOstiaQuestion> firewallRuleOstiaQuestions=targetQuestionnaire.getFirewallRuleOstiaAnswers();
			for(FirewallRuleOstiaQuestion firewallRuleOstiaQuestion:firewallRuleOstiaQuestions){
				for(FirewallRuleOstiaQuestion srcFirewallRuleOstiaQuestion:srcFirewallRuleOstiaQuestions){
					
					if(firewallRuleOstiaQuestion.getOstiaQuestion().getId().longValue() == srcFirewallRuleOstiaQuestion.getOstiaQuestion().getId().longValue()){
						firewallRuleOstiaQuestion.setAnswers(srcFirewallRuleOstiaQuestion.getAnswers());
						firewallRuleOstiaQuestion.setTextAnswer(srcFirewallRuleOstiaQuestion.getTextAnswer());
						firewallRuleOstiaQuestion.setSingleAnswer(srcFirewallRuleOstiaQuestion.getSingleAnswer());
						firewallRuleOstiaQuestion.setOtherText(srcFirewallRuleOstiaQuestion.getOtherText());
						firewallRuleOstiaQuestion.setStatus(srcFirewallRuleOstiaQuestion.getStatus());
						if(firewallRuleOstiaQuestion.getAnswers() !=null){
							Set<FirewallRuleOstiaAnswer> answers=firewallRuleOstiaQuestion.getAnswers();
							for(FirewallRuleOstiaAnswer answer:answers){
								answer.setFirewallRuleOstiaQuestion(firewallRuleOstiaQuestion);
								answer.setId(null);
							}
							
						}
					}
				}
				
			}
			targetQuestionnaire.setStatus(sourceQuestionnaire.getStatus());
			targetQuestionnaire.setUpdatedTIRequest(req);
			//list.add(targetQuestionnaire);
			fireWallRuleProcess.updateFirewallRuleQuestionnaire(targetQuestionnaire);
			fireWallRuleProcess.updateAnswer(targetQuestionnaire);
		}
		Object riskDefinitionsObject = request.getSession().getAttribute(RISK_DEFINITIONS);
		if(riskDefinitionsObject!= null){
			//log.info("**********************clone method called - riskDefinitions from request.Session");
			List<RiskDefinition> riskDefinitions = (List<RiskDefinition>)riskDefinitionsObject;
			fireWallRuleProcess.setRiskDefinitions(riskDefinitions);
		}
		fireWallRuleProcess.setAggregate(fireWallRuleProcess.getRiskForCurrentCycle(getCurrentTiRequest(request).getId(),con_type));
		fireWallRuleProcess.setCycleAggregate(fireWallRuleProcess.getRiskForConn(getTiProcessId(request),con_type));
		fireWallRuleProcess.setIpCount(fireWallRuleProcess.getIPForConn(getTiProcessId(request),con_type));
		retrieveFirewallRuleQuestionnaires(fireWallRuleProcess, request);
		isCompleteCheck(request);
		model.addAttribute("fireWallRuleProcess", fireWallRuleProcess);
		return LIST;
	}
	
	private void populateQuesAndAnswers(
				List<FirewallRuleOstiaQuestion> firewallRuleOstiaAnswers, HttpServletRequest request) {
			List<FirewallRuleOstiaQuestion> sessionFirewallRuleOstiaAnswers = (List<FirewallRuleOstiaQuestion>)request.getSession().getAttribute("QUES_AND_ANS");
	
			for(FirewallRuleOstiaQuestion firewallRuleOstiaQuestion:firewallRuleOstiaAnswers){
				for(FirewallRuleOstiaQuestion sessionFirewallRuleOstiaQuestion:sessionFirewallRuleOstiaAnswers){
					if(firewallRuleOstiaQuestion.getId().longValue()==sessionFirewallRuleOstiaQuestion.getId().longValue()){
						firewallRuleOstiaQuestion.setAnswers(sessionFirewallRuleOstiaQuestion.getAnswers());
					}
					
				}
			}
			
		}
	
	private void retrieveRiskDefinitions(FireWallRuleProcess fireWallRuleProcess, HttpServletRequest request) {   
		fireWallRuleProcess.setTiRequest(getPreviousVersionTiRequestID(getTiProcessId(request), request));
		fireWallRuleProcess.setPaginationRequired(false);
		List<RiskDefinition> riskDefinitions = fireWallRuleProcess.findRiskDefinitions();
		fireWallRuleProcess.setRiskDefinitions(riskDefinitions);
		request.getSession().setAttribute(RISK_DEFINITIONS,riskDefinitions);
	}

	private void retrieveFirewallRuleQuestionnaires(FireWallRuleProcess fireWallRuleProcess, HttpServletRequest request) {
		fireWallRuleProcess.setTiRequest(getPreviousVersionTiRequestID(getTiProcessId(request), request));
		fireWallRuleProcess.setPaginationRequired(true);
		fireWallRuleProcess.setFirewallRuleQuestionnaires(fireWallRuleProcess.findFirewallRuleQuestionnaires());
		int rowCount = fireWallRuleProcess.getRowCount();
		int totalPages = Math.round((rowCount / fireWallRuleProcess.getMaxResult()) + 0.5f);
		fireWallRuleProcess.setTotalPages(totalPages);
	}
	
		
}
