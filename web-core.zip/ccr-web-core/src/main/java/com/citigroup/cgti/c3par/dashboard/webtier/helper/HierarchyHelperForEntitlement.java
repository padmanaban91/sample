/*
 * Created on Apr 10, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.dashboard.webtier.helper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.citigroup.cgti.c3par.model.BusinessUnitEntity;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.C3parSession;


/**
 * The Class HierarchyHelperForEntitlement.
 *
 * @author dr97938
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class HierarchyHelperForEntitlement {

    /** The log. */
    private static Logger log = Logger.getLogger(HierarchyHelperForEntitlement.class);

    /**
     * Gets the business units for sector.
     *
     * @param sectordId the sectord id
     * @param filter the filter
     * @return the business units for sector
     */
    public List getBusinessUnitsForSector(Long sectordId,String filter)
    {
	C3parSession dbsession=new C3parSession();
	Connection con=null;
	Statement stmt =null;
	ResultSet rs=null;
	List buList=new ArrayList();
	try
	{
	    con=dbsession.getConnection();
	    stmt=con.createStatement();
	    String sql=null;
	    String bu_name ="%";
	    //hierarchy_detail.NODE_TYPE_ID=2  indicates data_id represents  sector id
	    if(filter==null ){
		//sql="select business_unit.id,business_unit.BUSINESS_NAME  from  hierarchy_detail,hierarchy_parent_detail,business_unit  where  business_unit.IS_ACTIVE!='N' and  hierarchy_detail.DATA_ID=business_unit.ID and  hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID and  hierarchy_parent_detail.PARENT_ID in (select hierarchy_parent_detail.id from  hierarchy_detail , hierarchy_parent_detail where hierarchy_detail.id=hierarchy_parent_detail.NODE_ID and   hierarchy_detail.NODE_TYPE_ID=2 and hierarchy_detail.DATA_ID= "+sectordId+")";
		sql="select business_unit.id,business_unit.BUSINESS_NAME  from hierarchy_detail,hierarchy_parent_detail,business_unit where  business_unit.IS_ACTIVE!='N' and  hierarchy_detail.DATA_ID=business_unit.ID AND hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID and  hierarchy_parent_detail.PARENT_ID =(select hierarchy_detail.ID from  hierarchy_detail where  hierarchy_detail.NODE_TYPE_ID=2 and hierarchy_detail.DATA_ID= "+sectordId+") order by business_unit.BUSINESS_NAME";
	    }
	    else{
		bu_name=filter.toUpperCase().trim();
		//sql="select business_unit.id,business_unit.BUSINESS_NAME  from  hierarchy_detail,hierarchy_parent_detail,business_unit  where  upper(business_unit.BUSINESS_NAME) like '%"+bu_name+"%' and business_unit.IS_ACTIVE!='N' and  hierarchy_detail.DATA_ID=business_unit.ID and  hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID and  hierarchy_parent_detail.PARENT_ID in (select hierarchy_parent_detail.id from  hierarchy_detail , hierarchy_parent_detail where hierarchy_detail.id=hierarchy_parent_detail.NODE_ID and   hierarchy_detail.NODE_TYPE_ID=2 and hierarchy_detail.DATA_ID= "+sectordId+")";;
		sql="select business_unit.id,business_unit.BUSINESS_NAME  from hierarchy_detail,hierarchy_parent_detail,business_unit where  upper(business_unit.BUSINESS_NAME) like '%"+bu_name+"%' and business_unit.IS_ACTIVE!='N' and  hierarchy_detail.DATA_ID=business_unit.ID AND hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID and  hierarchy_parent_detail.PARENT_ID =(select hierarchy_detail.ID from  hierarchy_detail where  hierarchy_detail.NODE_TYPE_ID=2 and hierarchy_detail.DATA_ID= "+sectordId+" )";
	    }

	    rs=stmt.executeQuery(sql);
	    if(rs!=null){
		while(rs.next()){
		    BusinessUnitEntity buEntity=new BusinessUnitEntity();	
		    buEntity.setId(Long.valueOf(rs.getLong(1)));
		    buEntity.setBusinessName(rs.getString(2));
		    buList.add(buEntity);
		}
	    }
	}
	catch(Exception e){
	    log.error(e);
	}
	finally{
	    try{
		if(rs!=null)
		    rs.close();
		if(stmt!=null)
		    stmt.close();
		if(con!=null)
		    con.close();
	    }
	    catch(SQLException e){
		log.error(e);
	    }	
	}
	return buList;
    }

    /**
     * Gets the siblings.
     *
     * @param buId the bu id
     * @param filter the filter
     * @return the siblings
     */
    public  List getSiblings(Long buId,String filter)
    {
	String sql=null;
	C3parSession dbsession=new C3parSession();
	Connection con=null;
	Statement stmt =null;
	ResultSet rs=null;
	String bu_name=null;
	List siblingBuList=new ArrayList();
	////hierarchy_detail.NODE_TYPE_ID=3  indicates data_id represents businessunits id 
	try{
	    con=dbsession.getConnection();
	    stmt=con.createStatement();

	    if(filter==null || filter=="")
		sql="select business_unit.id, business_unit.BUSINESS_NAME from hierarchy_detail ,hierarchy_parent_detail, business_unit where  business_unit.IS_ACTIVE!='N' and hierarchy_detail.DATA_ID!= "+buId+" and hierarchy_detail.DATA_ID=business_unit.ID and hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID  and hierarchy_parent_detail.parent_id=(select  hierarchy_parent_detail.parent_id from hierarchy_detail,hierarchy_parent_detail where hierarchy_detail.ID=hierarchy_parent_detail.NODE_ID  and hierarchy_detail.NODE_TYPE_ID=3 and hierarchy_detail.DATA_ID= "+buId+") ORDER BY BUSINESS_NAME";
	    else{
		bu_name=filter.toUpperCase().trim();
		sql="select business_unit.id, business_unit.BUSINESS_NAME from hierarchy_detail ,hierarchy_parent_detail, business_unit where upper(business_unit.BUSINESS_NAME) like '%"+bu_name+"%' and  business_unit.IS_ACTIVE!='N' and hierarchy_detail.DATA_ID!= "+buId+" and hierarchy_detail.DATA_ID=business_unit.ID and hierarchy_parent_detail.NODE_ID=hierarchy_detail.ID  and hierarchy_parent_detail.parent_id=(select  hierarchy_parent_detail.parent_id from hierarchy_detail,hierarchy_parent_detail where hierarchy_detail.ID=hierarchy_parent_detail.NODE_ID  and hierarchy_detail.NODE_TYPE_ID=3 and hierarchy_detail.DATA_ID= "+buId+") ORDER BY BUSINESS_NAME";

		rs=stmt.executeQuery(sql);
		if(rs!=null){
		    while(rs.next()){
			BusinessUnitEntity buEntity=new BusinessUnitEntity();	
			buEntity.setId(Long.valueOf(rs.getLong(1)));
			buEntity.setBusinessName(rs.getString(2));
			siblingBuList.add(buEntity);
		    }
		}
	    }
	}
	catch(Exception e){
	    log.error(e);
	}
	finally{
	    try{
		if(rs!=null)
		    rs.close();
		if(stmt!=null)
		    stmt.close();
		if(con!=null)
		    con.close();
	    }
	    catch(SQLException e){
		log.error(e);
	    }	
	}
	return siblingBuList;
    }

    /**
     * Gets the parent.
     *
     * @param buId the bu id
     * @return the parent
     */
    public  Long  getParent(Long buId)
    {
	C3parSession dbsession=new C3parSession();
	Connection con=null;
	Statement stmt =null;
	ResultSet rs=null;
	Long sectorId=null;
	try
	{
	    con=dbsession.getConnection();
	    stmt=con.createStatement();
	    String sql="select hierarchy_detail.DATA_ID from hierarchy_detail where hierarchy_detail.id =( select hierarchy_parent_detail.parent_id from hierarchy_detail,hierarchy_parent_detail where hierarchy_detail.ID=hierarchy_parent_detail.NODE_ID  and hierarchy_detail.NODE_TYPE_ID=3 and hierarchy_detail.DATA_ID = "+buId+")";
	    rs=stmt.executeQuery(sql);
	    if(rs!=null){
		while(rs.next())
		    sectorId=Long.valueOf(rs.getLong(1));
	    }
	}
	catch(Exception e){
	    log.error(e);
	}
	finally{
	    try{
		if(rs!=null)
		    rs.close();
		if(stmt!=null)
		    stmt.close();
		if(con!=null)      
		    con.close();
	    } 
	    catch(Exception e){
		log.error(e);
	    }	 
	}
	return sectorId;
    }
}
