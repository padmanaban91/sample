package com.citigroup.cgti.c3par.webtier.controller.communication;

import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.communication.domain.MonthViewProcess;

@Controller
public class MonthViewController {
	
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@RequestMapping(value="/monthViewController.act", method={RequestMethod.GET, RequestMethod.POST})
	public String loadMonthView(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		
		log.info("Entering into loadMonthView()..");
				
		MonthViewProcess monthViewProcess=new MonthViewProcess();
		
		Map<String, List<MonthViewProcess>> dataMap = monthViewProcess.getAllDetails();
		
		log.debug("The dataMap: "+dataMap.size());
		
		request.setAttribute("resultMap", dataMap);
		
		this.findTotalCounts(dataMap, request);
		
		log.info("Exit from loadMonthView()..");
		
		return "c3par.communication.monthView.queueView";
	}
	
	private void findTotalCounts(Map resultMap,HttpServletRequest request){
		
		String [] sectorNames = {"CTI","GCB","ICG"};
		
		List tempList = null;
		
		int assignedCounts,completedCounts,j;
		
		Integer [] monthAssignedCounts = null;
		
		Integer [] monthCompletedCounts = null;
		
		
		int sumOfYearAssignedCount;
		int sumOfYearCompletedCount;
		
		if(null != resultMap){
			
			for(String sectorName: sectorNames){				
				
				tempList = (List) resultMap.get(sectorName);
				
				if(null != tempList && tempList.size() > 0){
				
				sumOfYearAssignedCount = 0;
				sumOfYearCompletedCount = 0;
				
				for(int i=0; i< tempList.size(); i++){
					
					sumOfYearAssignedCount = sumOfYearAssignedCount + ((MonthViewProcess)tempList.get(i)).getTotalAssignedCount();
					sumOfYearCompletedCount = sumOfYearCompletedCount + ((MonthViewProcess)tempList.get(i)).getTotalCompleteCancelCount();					
				
				}
				
				j=0; 
				
				monthAssignedCounts = new Integer[12];
				
				monthCompletedCounts = new Integer[12];
				
				if(null != tempList){
					
					for(int k=0; k<12; k++){
						
						assignedCounts = 0; completedCounts =0;
					
						for(int i=0; i< tempList.size(); i++){
						
							assignedCounts = assignedCounts+ ((MonthViewProcess)tempList.get(i)).getMonthAssignedCount()[j].intValue();	
							completedCounts = completedCounts+ ((MonthViewProcess)tempList.get(i)).getMonthCompleteCancelCount()[j].intValue();	
						
						}
						monthAssignedCounts[j] = assignedCounts;						
						monthCompletedCounts[j] = completedCounts;
						j++;
					
					}
					if(monthAssignedCounts.length > 0){
						
						log.debug("The sector: "+sectorName +" The assigned Counts...:"+Arrays.asList(monthAssignedCounts));
					}
					
					if(monthCompletedCounts.length > 0){
						
						log.debug("The sector: "+sectorName +" The completed Counts..:"+Arrays.asList(monthCompletedCounts)); 
					}
					
					request.setAttribute(sectorName+"AssignedCounts", monthAssignedCounts);
					request.setAttribute(sectorName+"CompletedCounts", monthCompletedCounts);	
					request.setAttribute(sectorName+"SumOfYearAssignedCount", ""+sumOfYearAssignedCount);
					request.setAttribute(sectorName+"SumOfYearCompletedCount", ""+sumOfYearCompletedCount);
					
					
				}
			}
				
				
			}
			
		}
		
		
	}
	
	@RequestMapping(value="/getPopupDetails.act", method={RequestMethod.GET, RequestMethod.POST})
	public String getPopupDetails(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		
		log.info("Entering into getPopupDetails()..");
		
		String result = "/pages/communication/PopupCompletedCMPRequest";
		
		String assignedUser = request.getParameter("assignedUser");
		
		String sectorName = request.getParameter("sectorName");
		
		String month = request.getParameter("month");
		
		String userName = request.getParameter("userName");
		
		String status = request.getParameter("status");
		
		log.debug("The User: "+assignedUser+" Sector Name: "+sectorName+" Month: "+month+" User Name: "+userName+" Status:"+status);
		
		request.getSession().setAttribute("selectedMonth", month);
		
		
		Map<String,String> monthMap = this.getMonthInfo(Integer.parseInt(month));
		
		String startDate = monthMap.get("startDate");
		String endDate = monthMap.get("endDate");
		
				
		MonthViewProcess monthViewProcess=new MonthViewProcess();
		
		List<MonthViewProcess> resultList = monthViewProcess.getPopupDetailsDetails(Integer.parseInt(assignedUser),sectorName,startDate,endDate,status);
		
		log.debug("The resultList: "+resultList.size());
		
		request.setAttribute("resultList", resultList);
		
		model.addAttribute("resultList",resultList);
		
		model.addAttribute("lastName",resultList.get(0).getLastName());
		model.addAttribute("firstName",resultList.get(0).getFirstName());
		
		
		log.info("Exit from getPopupDetails()..");
		
		return result;
	}
	
	@RequestMapping(value="/getManagerView.act", method={RequestMethod.GET, RequestMethod.POST})
	public String getManagerViewDetails(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		
		log.info("Entering into getManagerViewDetails()..");
		
		String result = "c3par.communication.monthView.managerView";	
		
		MonthViewProcess monthViewProcess=new MonthViewProcess();
		
		Map<String, List<MonthViewProcess>> resultMap = monthViewProcess.getManagerViewDetails();
		
		log.debug("The resultMap: "+resultMap.size());
		
		request.setAttribute("resultMap", resultMap);
		
		this.findTotalCounts(resultMap, request);
		
		log.info("Exit from getManagerViewDetails()..");
		
		return result;
	}
	
	private Map<String, String> getMonthInfo(int monthInNumber){
		
		Map<String,String> monthMap = new HashMap<String,String>();
		
		switch(monthInNumber){
		
			case 1:
				monthMap.put("startDate", "01/JAN/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "31/JAN/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			case 2:
				monthMap.put("startDate", "01/FEB/"+Calendar.getInstance().get(Calendar.YEAR));
				if(Calendar.getInstance().get(Calendar.YEAR) % 4 == 0){
					
					monthMap.put("endDate", "29/FEB/"+Calendar.getInstance().get(Calendar.YEAR));
				} else {
				monthMap.put("endDate", "28/FEB/"+Calendar.getInstance().get(Calendar.YEAR));
				}
				break;
			case 3:
				monthMap.put("startDate", "01/MAR/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "31/MAR/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			case 4:
				monthMap.put("startDate", "01/APR/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "30/APR/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			case 5:
				monthMap.put("startDate", "01/MAY/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "31/MAY/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			case 6:
				monthMap.put("startDate", "01/JUN/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "30/JUN/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			case 7:
				monthMap.put("startDate", "01/JUL/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "31/JUL/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			case 8:
				monthMap.put("startDate", "01/AUG/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "31/AUG/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			case 9:
				monthMap.put("startDate", "01/SEP/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "30/SEP/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			case 10:
				monthMap.put("startDate", "01/OCT/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "31/OCT/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			case 11:
				monthMap.put("startDate", "01/NOV/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "30/NOV/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			case 12:
				monthMap.put("startDate", "01/DEC/"+Calendar.getInstance().get(Calendar.YEAR));
				monthMap.put("endDate", "31/DEC/"+Calendar.getInstance().get(Calendar.YEAR));
				break;
			
		}
		
		log.debug("monthMap: "+monthMap);
		
		return monthMap;
	}
	
	

}