package com.citigroup.cgti.c3par.util;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.UserTransaction;
import java.util.Properties;
import org.apache.log4j.Logger;


/**
 * The Class TransactionUtil.
 */
public class TransactionUtil
{

    /** The m_transaction. */
    private static UserTransaction m_transaction = null;

    /** The log. */
    private static Logger log = Logger.getLogger(TransactionUtil.class);

    /**
     * Gets the transaction.
     *
     * @return the transaction
     * @throws NamingException the naming exception
     */
    public static UserTransaction getTransaction()
    throws NamingException
    {
	if(m_transaction != null)
	{
	    return m_transaction;
	}

	Context ctx = null;
	try
	{
	    ctx = new InitialContext();
	    m_transaction = (UserTransaction) ctx.lookup(C3parProperties.USER_TRANSACTION_JNDI_NAME);

	    return m_transaction;
	}
	catch(NamingException ex)
	{
	    throw ex;
	} finally {
	    try {
		if(ctx != null) ctx.close();
	    } catch (Exception ex) {
		log.error(ex);
	    }
	}
    }
}