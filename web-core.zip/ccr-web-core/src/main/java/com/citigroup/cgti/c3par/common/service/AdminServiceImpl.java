/**
 *
 */
package com.citigroup.cgti.c3par.common.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.StringType;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.admin.domain.ManageISOContactProcess;
import com.citigroup.cgti.c3par.audit.domain.AuditC3parUsersData;
import com.citigroup.cgti.c3par.common.domain.AdminProcess;
import com.citigroup.cgti.c3par.common.domain.ISOContacts;
import com.citigroup.cgti.c3par.common.domain.TITaskType;
import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyLocationXref;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.user.domain.C3parUserHierarchyXref;
import com.citigroup.cgti.c3par.user.domain.C3parUserRoleXref;
import com.citigroup.cgti.c3par.user.domain.SecurityRole;

/**
 * @author pc79439
 * 
 */
@SuppressWarnings("unchecked")
@Transactional
public class AdminServiceImpl extends BasePersistanceImpl implements AdminServicePersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(AdminServiceImpl.class);

	// get all the Contacts
	@Override
	@Transactional(readOnly = true)
	public List<ISOContacts> getManageISOContactList(ManageISOContactProcess manageISOContactProcess) {
		Session session = getSession();
		Criteria criteria = session.createCriteria(ISOContacts.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.add(Restrictions.eq("isDeleted", "N"));
		criteria.addOrder(Order.asc("id"));
		manageISOContactProcess.setRowCount(getRowCount(criteria));

		if (manageISOContactProcess.isPaginationRequired()) {
			addPagination(criteria, manageISOContactProcess.getOffset(), manageISOContactProcess.getLimit());
		}
		List<ISOContacts> list = criteria.list();

		if (list != null)
			log.debug("AdminServiceImpl :: getManageISOContactList :: size ::" + list.size());
		return list;
	}

	// Add new ISO contact
	@Override
	public void saveManageISOContactList(String soeId) {
		Session session = getSession();
		ISOContacts isoContact = null;
		log.info("saveManageISOContactList :: SOEID -> " + soeId);

		List<ISOContacts> list = (List<ISOContacts>) session
				.createQuery("from ISOContacts isocontact where upper(isocontact.soeID)=upper('" + soeId + "') ")
				.list();
		// Updating SOEID incase of soft delete
		if (list != null && list.size() > 0) {
			log.info("save doNotSendEmail :: UpdateContact");
			isoContact = list.get(0);
			isoContact.setIsDeleted("N");
			isoContact.setUpdated_date(new Date());

		} else {
			// Saving contact to table DO_NOT_SEND_LIST
			log.info("save doNotSendEmail :: SaveContact");
			isoContact = new ISOContacts();
			isoContact.setSoeID(soeId.toUpperCase());
			isoContact.setIsDeleted("N");
			isoContact.setUpdated_date(new Date());
			isoContact.setCreated_date(new Date());
		}

		session.saveOrUpdate(isoContact);
	}

	@Override
	public void deleteManageISOContactList(List<String> soeIdList) {
		log.info("Delete deleteManageISOContactList starts here ...");
		Session session = getSession();
		StringBuffer ssoId = new StringBuffer();
		int i = 0;
		// Fetching SOEID's
		for (String soeId : soeIdList) {
			if (i > 0) {
				ssoId.append(",");
			}
			ssoId.append("'" + soeId.toUpperCase().replace(",", "','") + "'");
			i++;
		}

		SQLQuery sqlQuery = session.createSQLQuery(
				"update ISO_CONTACTS set is_deleted = 'Y' where upper(soe_id) in (" + ssoId.toString() + ")");
		sqlQuery.executeUpdate();

		log.info("Delete deleteManageISOContactList ends here ..." + sqlQuery);
	}

	/**
	 * Retrieve Security Roles
	 */
	@Override
	@Transactional(readOnly = true)
	public List<SecurityRole> getSecurityRoles() {
		Session session = getSession();
		List<SecurityRole> securityRoles = new ArrayList<SecurityRole>();
		// SQLQuery sqlQuery = session.createSQLQuery("select role.* from
		// security_role role where role.name not in ('C3PARUSER','Entitlement
		// Requester')");
		SQLQuery sqlQuery = session.createSQLQuery("select role.* from security_role role");
		sqlQuery.addEntity("role", SecurityRole.class);
		securityRoles = (List<SecurityRole>) sqlQuery.list();
		return securityRoles;
	}

	/**
	 * Save user
	 */
	@Override
	public Long saveUser(C3parUser c3parUser) {
		Session session = getSession();
		List<C3parUserHierarchyXref> userHierarchyList = c3parUser.getUserHierarchyList();
		if (userHierarchyList != null && !userHierarchyList.isEmpty()) {
			for (C3parUserHierarchyXref c3parUserHierarchyXref : userHierarchyList) {
				if (c3parUserHierarchyXref != null && c3parUserHierarchyXref.getCitiHierarchyMaster() != null
						&& c3parUserHierarchyXref.getCitiHierarchyMaster().getSector() != null
						&& c3parUserHierarchyXref.getCitiHierarchyMaster().getRegion() != null) {
					if (c3parUserHierarchyXref.getId() == null || c3parUserHierarchyXref.getId().longValue() <= 0) {
						CitiHierarchyMaster citiHierarchyMaster = getcitiHierarchyMaster(
								c3parUserHierarchyXref.getCitiHierarchyMaster().getRegion().getId(),
								c3parUserHierarchyXref.getCitiHierarchyMaster().getSector().getId(), -1L);
						if (citiHierarchyMaster != null) {
							c3parUserHierarchyXref.setCitiHierarchyMaster(citiHierarchyMaster);
						} else {
							BusinessUnit businessUnit = new BusinessUnit();
							businessUnit.setId(-1L);
							c3parUserHierarchyXref.getCitiHierarchyMaster().setBusinessUnit(businessUnit);
						}
					}
				}
				c3parUserHierarchyXref.setUpdated_date(new Date());
				c3parUserHierarchyXref.setC3parUser(c3parUser);
			}
		}
		if (c3parUser.getId() == null || c3parUser.getId().longValue() <= 0) {
			log.debug(" AdminServiceImpl::saveUser:: new user");
			Long userId = (Long) getHibernateTemplate().save(c3parUser);
			/*
			 * AuditC3parUsersData auditC3parUsersData =
			 * c3parUser.getAuditC3parUsersData();
			 * auditC3parUsersData.setUserId(userId); log.info(
			 * "Printing AuditC3parUsersData"+auditC3parUsersData.toString());
			 * saveAuditUsersDate(auditC3parUsersData);
			 */
			return userId;
		} else {
			log.debug(" AdminServiceImpl::saveUser:: update existing user");
			getHibernateTemplate().update(c3parUser);
			return c3parUser.getId();
		}
	}

	/**
	 * 
	 * @param regId
	 * @param secId
	 * @param buId
	 * @return
	 */
	private CitiHierarchyMaster getcitiHierarchyMaster(Long regId, Long secId, Long buId) {
		Session session = getSession();

		Criteria criteria = session.createCriteria(CitiHierarchyMaster.class);
		criteria.createCriteria("region", "region");
		criteria.add(Restrictions.eq("region.id", regId));
		criteria.createCriteria("sector", "sector");
		criteria.add(Restrictions.eq("sector.id", secId));
		criteria.createCriteria("businessUnit", "businessUnit");
		criteria.add(Restrictions.eq("businessUnit.id", buId));

		List<CitiHierarchyMaster> list = criteria.list();
		if (list != null && list.size() > 0) {
			log.debug("RelationshipServiceImpl :: getcitiHierarchyMaster :: size ::" + list.size());
			return list.get(0);
		}

		return null;
	}

	/**
	 * Retrieve C3parUser
	 */
	@Override
	@Transactional(readOnly = true)
	public C3parUser retrieveC3parUser(Long id) {
		Session session = getSession();
		C3parUser c3parUser = (C3parUser) session.get(C3parUser.class, id);
		lazyInitialize(c3parUser.getUserRoleList());
		lazyInitialize(c3parUser.getUserHierarchyList());
		return c3parUser;
	}

	/**
	 * Retrieve C3parUser
	 */
	@Override
	@Transactional(readOnly = true)
	public C3parUser retrieveC3parUser(String ssoId) {
		Session session = getSession();

		C3parUser c3parUser = null;

		Query query = session.createQuery("from C3parUser where upper(ssoId) = ?").setString(0, ssoId.toUpperCase());

		List<C3parUser> list = (List<C3parUser>) query.list();
		if (list != null && list.size() > 0) {
			c3parUser = list.get(0);
			lazyInitialize(c3parUser.getUserRoleList());
			lazyInitialize(c3parUser.getUserHierarchyList());
			lazyInitialize(c3parUser.getEcmQueueUsersList());
		}

		return c3parUser;
	}

	/**
	 * Validate C3parUser
	 */
	@Override
	@Transactional(readOnly = true)
	public C3parUser validateC3parUser(C3parUser c3parUser) {
		Session session = getSession();
		List<String> validationErrors = new ArrayList<String>();
		if (c3parUser != null && c3parUser.getSsoId() != null
				&& (c3parUser.getId() == null || c3parUser.getId().longValue() <= 0)) {
			Query query = session.createQuery("from C3parUser where upper(ssoId) = ?").setString(0,
					c3parUser.getSsoId().toUpperCase());

			List<C3parUser> list = (List<C3parUser>) query.list();

			if (list != null && list.size() > 0) {
				validationErrors.add(" User Already Exists ... ");
				c3parUser.setValidationErrors(validationErrors);
				return c3parUser;
			}
		}
		return c3parUser;
	}

	@Override
	@Transactional(readOnly = true)
	public List<C3parUserRoleXref> getC3parUserRoleXref(Long userId) throws Exception {
		log.debug("Entering :: " + userId);
		List<C3parUserRoleXref> resultList = null;
		try {
			Session session = getSession();
			Query query = session.createQuery("from C3parUserRoleXref where userId =: userId");
			query.setLong("userId", userId);
			resultList = query.list();
		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException("Exception has occurred :: getC3parUserRoleXref", e);
		}
		log.debug("Exiting ::");
		return resultList;
	}

	@Override
	@Transactional(readOnly = true)
	public List<C3parUserHierarchyXref> getC3parUserHierarchyXref(Long userId) {
		log.debug("Entering :: " + userId);
		List<C3parUserHierarchyXref> resultList = null;
		try {
			Session session = getSession();
			Query query = session.createQuery("from C3parUserHierarchyXref where userId =: userId");
			query.setLong("userId", userId);
			resultList = query.list();
		} catch (Exception e) {
			log.error(e, e);
			throw new ApplicationException("Exception has occurred :: getC3parUserHierarchyXref", e);
		}
		log.debug("Exiting ::");
		return resultList;
	}

	/**
	 * 
	 * @param adminProcess
	 * @return
	 */
	@Transactional(readOnly = true)
	public List<C3parUser> listC3ParUsers(AdminProcess adminProcess) {
		Session session = getSession();

		Criteria criteria = session.createCriteria(C3parUser.class);

		if (adminProcess != null && adminProcess.getSoeID() != null && !adminProcess.getSoeID().isEmpty()) {
			criteria.add(Restrictions.ilike("ssoId", adminProcess.getSoeID().trim()));
		}

		if (adminProcess != null && adminProcess.getFirstName() != null && !adminProcess.getFirstName().isEmpty()) {
			criteria.add(Restrictions.ilike("firstName", adminProcess.getFirstName().trim()));
		}

		if (adminProcess != null && adminProcess.getLastName() != null && !adminProcess.getLastName().isEmpty()) {
			criteria.add(Restrictions.ilike("lastName", adminProcess.getLastName().trim()));
		}

		int rowCount = getRowCount(criteria);

		log.debug("Row Count of C3par Users  " + rowCount);

		adminProcess.setRowCount(rowCount);

		addPagination(criteria, adminProcess.getOffset(), adminProcess.getLimit());

		return criteria.list();
	}

	/**
	 * 
	 * @param adminProcess
	 * @return
	 */
	@Transactional(readOnly = true)
	public List<CitiHierarchyMaster> getConnectionRegSecBU(Long conId) {
		Session session = getSession();

		StringBuilder querystr = new StringBuilder();
		querystr.append(" select chm.* from CITI_HIERARCHY_MASTER chm where id in ");
		querystr.append(
				" (select relxref.citi_hierarchy_master_id from REL_CITI_HIERARCHY_XREF relxref, ti_process tipro ");
		querystr.append(" where tipro.relationship_id = relxref.relationship_id and tipro.id = " + conId + ") ");

		SQLQuery sqlquery = session.createSQLQuery(querystr.toString());
		sqlquery.addEntity("chm", CitiHierarchyMaster.class);

		List<CitiHierarchyMaster> list = sqlquery.list();

		return list;
	}

	/**
	 * get User ID
	 */
	@Override
	@Transactional(readOnly = true)
	public Long getUserId(String ssoId) {
		Session session = getSession();
		Query query = session.createQuery("from C3parUser where upper(ssoId) = ?").setString(0, ssoId.toUpperCase());

		List<C3parUser> list = (List<C3parUser>) query.list();

		if (list != null && list.size() > 0) {
			return list.get(0).getId();
		}
		return null;
	}

	@Override
	public ThirdPartyLocationXref loadThirdPartyLocation(Long thirdpartyId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Transactional(readOnly = true)
	public int saveAuditUsersDate(AuditC3parUsersData auditC3parUsersData) {
		log.info("Entering AdminServiceImpl saveAuditUsersDate..");
		int result = 0;
		try {
			Session session = getSession();
			String insertAuditUsersData = "INSERT INTO audit_c3par_users_data "
					+ "(ID,USER_ID,ACTION,UPDATEDBY_USER,UPDATEDBY_DATE,MGR_APPROVER,MGR_APPROVED_DATE,ISA_APPROVER,"
					+ "ISA_APPROVED_DATE,IS_ACTIVE_CURRENT,IS_ACTIVE_PREV,ROLE_STR_CURRENT,ROLE_STR_PREV,"
					+ "ENT_STR_CURRENT,ENT_STR_PREV,AUDITLOG_INSERTED_DATE,SYSADMIN_APPROVER,SYSADMIN_REVIEWED_DATE,"
					+ "HOST_NAME,LOG_TS,HOST_NAME_ADDRESS,EVENT_DESCRIPTION,AFFECTED_USER)"
					+ " VALUES(SEQ_AUDIT_C3PAR_USERS_DATA.NEXTVAL,:user_id,:action,:updatedByUser,:updatedByDate,:mgrApprover,:mgrApprovedDate,"
					+ ":isaApprover,:isaApprovedDate,:isActiveCurrent,:isActivePrev,:roleStrCurrent,:roleStrPrev,"
					+ ":entStrCurrent,:entStrPrev,:auditLogInsertedDate,:sysadminApprover,:sysadminReviewedDate,"
					+ ":hostName,:log_ts,:hostNameAddress,:eventDescription,:affectedUser)";

			log.debug("Querying String" + insertAuditUsersData);

			SQLQuery query = session.createSQLQuery(insertAuditUsersData);
			query.setParameter("user_id", auditC3parUsersData.getUserId());
			query.setParameter("action", auditC3parUsersData.getAction());
			query.setParameter("updatedByUser", auditC3parUsersData.getUpdatedByUser());
			query.setParameter("updatedByDate", auditC3parUsersData.getUpdated_date());
			query.setParameter("mgrApprover", auditC3parUsersData.getMgrApprover());
			query.setParameter("mgrApprovedDate",
					auditC3parUsersData.getMgrApprovedDate() != null ? auditC3parUsersData.getMgrApprovedDate() : "");
			query.setParameter("isaApprover", auditC3parUsersData.getIsaApprover());
			query.setParameter("isaApprovedDate",
					auditC3parUsersData.getIsaApprovedDate() != null ? auditC3parUsersData.getIsaApprovedDate() : "");
			query.setParameter("isActiveCurrent", auditC3parUsersData.getIsActiveCurrent());
			query.setParameter("isActivePrev", auditC3parUsersData.getIsActivePrev());
			query.setParameter("roleStrCurrent", auditC3parUsersData.getRoleStrCurrent());
			query.setParameter("roleStrPrev", auditC3parUsersData.getRoleStrPrev());
			query.setParameter("entStrCurrent", auditC3parUsersData.getEntStrCurrent());
			query.setParameter("entStrPrev", auditC3parUsersData.getEntStrPrev());
			query.setParameter("auditLogInsertedDate", auditC3parUsersData.getAuditLogInsertedDate() != null
					? auditC3parUsersData.getAuditLogInsertedDate() : "");
			query.setParameter("sysadminApprover", auditC3parUsersData.getSysadminApprover());
			query.setParameter("sysadminReviewedDate", auditC3parUsersData.getSysadminReviewedDate() != null
					? auditC3parUsersData.getSysadminReviewedDate() : "");
			query.setParameter("hostName", auditC3parUsersData.getHostName());
			query.setParameter("log_ts", auditC3parUsersData.getLogDateTime());
			query.setParameter("hostNameAddress", auditC3parUsersData.getHostNameAddress());
			query.setParameter("eventDescription", auditC3parUsersData.getEventDescription());
			query.setParameter("affectedUser", auditC3parUsersData.getAffectedUser());
			result = query.executeUpdate();
			log.debug("Query Execute Result: " + result);
		} catch (DataAccessResourceFailureException e) {
			log.error("DataAccessResourceFailureException in insert Insert Statment..", e);
		} catch (HibernateException e) {
			log.error("HibernateException in insert Insert Statment..", e);
		} catch (IllegalStateException e) {
			log.error("IllegalStateException in insert Insert Statment..", e);
		}
		log.info("Exiting AdminServiceImpl saveAuditUsersDate..");
		return result;
	}

	@Transactional(readOnly = true)
	public AuditC3parUsersData getLastAuditUsersData(Long userId) {
		log.info("Entering AdminServiceImpl getLastAuditUsersData");
		AuditC3parUsersData auditC3parUsersData = new AuditC3parUsersData();
		try {
			Session session = getSession();
			String lastrow = "SELECT * FROM " + "(SELECT a.IS_ACTIVE_CURRENT as isActive,a.ROLE_STR_CURRENT as roleStr,"
					+ "a.ENT_STR_CURRENT as entStr FROM c3par_users c, audit_c3par_users_data a " + "WHERE a.user_id = "
					+ userId + " ORDER BY a.id DESC) " + "WHERE rownum <=1";
			SQLQuery query = session.createSQLQuery(lastrow);
			query.addScalar("isActive", StringType.INSTANCE);
			query.addScalar("roleStr", StringType.INSTANCE);
			query.addScalar("entStr", StringType.INSTANCE);
			List<Object[]> list = query.list();
			log.debug("after List" + list);
			if (list != null && list.size() > 0) {
				Object[] row = list.get(0);
				auditC3parUsersData.setIsActiveCurrent((String) row[0]);
				auditC3parUsersData.setRoleStrCurrent((String) row[1]);
				auditC3parUsersData.setEntStrCurrent((String) row[2]);
			} else {
				auditC3parUsersData = null;
			}

		} catch (DataAccessResourceFailureException e) {
			log.error("DataAccessResourceFailureException in  ..", e);
			e.printStackTrace();
		} catch (HibernateException e) {
			log.error("HibernateException in  ..", e);
			e.printStackTrace();
		} catch (IllegalStateException e) {
			log.error("IllegalStateException in  ..", e);
			e.printStackTrace();
		} catch (Exception e) {
			log.error("IllegalStateException in  ..", e);
			e.printStackTrace();
		}
		log.info("Exiting AdminServiceImpl getLastAuditUsersData");
		return auditC3parUsersData;

	}

	// Retrieve activity names from CCR_TASK_REF
	@Override
	@Transactional(readOnly = true)
	public List<TITaskType> getActivityNameList() {
		log.debug("Entering :: ");
		List<TITaskType> resultList = null;
		try {
			Session session = getSession();
			resultList = session.createCriteria(TITaskType.class).addOrder(Order.asc("task")).list();
		} catch (Exception e) {
			log.error("Exception occurred while getting the getTaskCode : " + e.toString());
			throw new ApplicationException("Exception has occurred :: ", e);
		}
		log.debug("Exiting :: ");
		return resultList;

	}

}
