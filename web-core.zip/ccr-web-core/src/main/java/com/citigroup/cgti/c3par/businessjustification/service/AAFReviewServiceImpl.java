/**
 *
 */
package com.citigroup.cgti.c3par.businessjustification.service;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.businessjustification.domain.soc.persist.AAFReviewServicePersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;

@SuppressWarnings("unchecked")
@Transactional
public class AAFReviewServiceImpl extends BasePersistanceImpl implements
AAFReviewServicePersistable {

	private static Logger log = Logger.getLogger(AAFReviewServiceImpl.class);	

	@Transactional(readOnly = true)
	public Long getPlanningIdForTiRequestId(Long tirequestid) {

		long planningId = 0;
		StringBuffer sql = new StringBuffer();

		if (tirequestid != null && tirequestid.longValue() > 0) {

			sql.append("select planning_id from c3par.ti_request_planning_xref where ti_request_id="
					+ tirequestid.longValue());

			Session session = getSession();

			planningId = ((BigDecimal) session.createSQLQuery(sql.toString())
					.list().get(0)).longValue();

			if (planningId == 0) {
				String planTermSQL = " select max(planning_id) from c3par.ti_request_planning_xref where ti_request_id in (select b.id from c3par.ti_request a ,c3par.ti_request b where a.id="
						+ tirequestid.longValue()
						+ "  and a.process_id=b.process_id ) ";

				planningId = ((BigDecimal) session.createSQLQuery(planTermSQL)
						.list().get(0)).longValue();
			}

		}
		return planningId;
	}
	

}
