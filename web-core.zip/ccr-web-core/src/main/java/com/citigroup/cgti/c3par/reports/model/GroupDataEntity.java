/*
 * Created on Jun 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.reports.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;


/**
 * The Class GroupDataEntity.
 *
 * @author MphasiS
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GroupDataEntity implements Serializable{

    /** The group column name. */
    private List groupColumnName;

    /** The function. */
    private List function;

    /** The summary column name. */
    private List summaryColumnName;

    /**
     * Gets the function.
     *
     * @return Returns the function.
     */
    public List getFunction() {
	return function;
    }

    /**
     * Sets the function.
     *
     * @param function The function to set.
     */
    public void setFunction(List function) {
	this.function = function;
    }

    /**
     * Gets the group column name.
     *
     * @return Returns the groupColumnName.
     */
    public List getGroupColumnName() {
	return groupColumnName;
    }

    /**
     * Sets the group column name.
     *
     * @param groupColumnName The groupColumnName to set.
     */
    public void setGroupColumnName(List groupColumnName) {
	this.groupColumnName = groupColumnName;
    }

    /**
     * Gets the summary column name.
     *
     * @return Returns the summaryColumnName.
     */
    public List getSummaryColumnName() {
	return summaryColumnName;
    }

    /**
     * Sets the summary column name.
     *
     * @param summaryColumnName The summaryColumnName to set.
     */
    public void setSummaryColumnName(List summaryColumnName) {
	this.summaryColumnName = summaryColumnName;
    }



}
