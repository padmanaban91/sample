package com.citigroup.cgti.c3par.service.comments;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.GenericLookupDef;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.persist.comments.SubmitActivityPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetail;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetailAnswer;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCLookup;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.soa.vc.logic.RFCService;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;

/*
 * @nc43495
 */
@SuppressWarnings("unchecked")
@Transactional
public class SubmitActivityImpl extends BasePersistanceImpl  implements SubmitActivityPersistable {


	/** The log. */
	private static Logger log = Logger.getLogger(SubmitActivityImpl.class);
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
    private RFCService rfc;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	@Override
	@Transactional(readOnly = true)
    public List<String> getSelectedSupReviewRoles(Long tiReq,String role) {
	log.info("Begin getSelectedSupReviewRoles::"+tiReq.toString());
	
	Session session = getSession();
	List<String> suppReviewRoles  = (List<String>) session.createSQLQuery("SELECT REVIEWER_ROLE FROM C3PAR.TI_REQ_SUPPLEMENT_REVIEW WHERE TI_REQUEST_ID="+tiReq+
									" AND REQUESTER_ROLE = (SELECT ID FROM C3PAR.ROLE WHERE NAME= "+role+")").list();
	
	log.debug("Supplementary review roles for submitActivity:"+suppReviewRoles);
	return suppReviewRoles;
    }

	
	@Override
	@Transactional(readOnly = true)
	public HashMap<String,String> findInstanceId(Long tiRequestId, Long activityId){
	log.info("SubmitActivityImpl:getInstanceId.."+tiRequestId+""+activityId);	
	Session session = getSession();		
	HashMap<String,String> mp = new HashMap<String,String>();
	
	try {
		
		String sqlQuery = 		("select a.bpm_instance_id, b.name, info_user.name name1 "+
								"from c3par.TI_ACTIVITY_TRAIL a , c3par.role b , c3par.role info_user "+
								"where a.ti_request_id="+tiRequestId.longValue()+"  and a.id = " + activityId.longValue()+" " +
								"and a.user_role_id=b.id (+) " +
								"and a.infouser_role_id =info_user.id(+)");
	    
		SQLQuery query = session.createSQLQuery(sqlQuery);
		log.debug("Query to retrieve roles:"+sqlQuery);
		query.addScalar("BPM_INSTANCE_ID", StringType.INSTANCE);
		query.addScalar("NAME", StringType.INSTANCE);
		query.addScalar("NAME1", StringType.INSTANCE);
		
		List<Object[]> rows = query.list();
		
		for (Object[] obj : rows) {
			
		mp.put("INST_ID", (String)obj[0]);	
		
		if((String)obj[1]!=null){
			
			mp.put("ROLE", (String)obj[1]);	
		}else{
			mp.put("ROLE", (String)obj[2]);	
		}
			
		}
		log.debug("Roles for SubmitActivity"+mp.size());

	} catch (Exception e) {
	    log.error(e,e);

	} 
	return mp;
    }
    
	@Override
	@Transactional(readOnly = true)
	 public List<LookUpVO> getSupReviewRoles(String role) {
			log.info("Begin getSupReviewRoles::"+role);
			List<LookUpVO> list = new ArrayList<LookUpVO>();
			if (role != null){
			    String sql = null;
			    sql = "SELECT GL.VALUE1, GL.VALUE2 FROM C3PAR.GENERIC_LOOKUP GL, C3PAR.GENERIC_LOOKUP_DEFS GLD WHERE GL.DEFINITION_ID=GLD.ID AND GLD.NAME=?";
			    LookUpVO lookupVO = null;
			    String definition = "";
			    if (role.equalsIgnoreCase("Security Engineer")) {
				definition = "SEC_ENG_SUP_REVIEW_ROLE";
			    } else if (role.equalsIgnoreCase("BISO")) {
				definition = "ISO_SUP_REVIEW_ROLE";
				//Added for SE Approval Remodel - Task 3927
			    } else if ((role.equalsIgnoreCase("DESIGN ENGINEER"))|| (role.equalsIgnoreCase("PROJECT COORDINATOR"))) {
				definition = "TEC_ARC_REVIEW_ROLE";
			    }
			    try {
			    SqlRowSet result  = jdbcTemplate.queryForRowSet(sql,new Object[]{definition});
				while (result.next()) {
				    lookupVO= new LookUpVO();
				    lookupVO.setValue((Long.valueOf(result.getString("VALUE1"))).longValue());
				    lookupVO.setName((String) result.getString("VALUE2"));
				    list.add(lookupVO);
				}
			    } catch (Exception e) {
				log.error("Exception during query :- " + e);
			    } 
			}
			log.info("End getSupReviewRoles::"+role);
			return list;
		    }
	
	
	@Override
    public boolean deleteSupReviewRoles(Long tiReq,String roleName){
	log.info("Begin deleteSupReviewRoles::"+tiReq);
	StringBuffer deleteSQL = new StringBuffer("delete from C3PAR.TI_REQ_SUPPLEMENT_REVIEW where TI_REQUEST_ID=? and REQUESTER_ROLE = (SELECT id from C3PAR.ROLE where NAME = ?)");
	 jdbcTemplate.update(deleteSQL.toString(),new Object[]{Long.valueOf(tiReq),roleName});
	log.info("End deleteSupReviewRoles::");
	return true;
    }
    
	@Override
    public boolean insertSupReviewRoles(Long tiReq,String roleName,String[] suppRole) {
	log.info("Begin insertSupReviewRoles::"+tiReq);
	StringBuffer insertSQL = new StringBuffer("INSERT INTO C3PAR.TI_REQ_SUPPLEMENT_REVIEW (TI_REQUEST_ID, REQUESTER_ROLE, " +
	"REVIEWER_ROLE) VALUES (?, (select id from c3par.role where NAME=?), ?)");
	try{
	    if (suppRole != null && suppRole.length > 0) {
		for (int i=0; i < suppRole.length; i++) {
			log.debug("supplementary review : "+roleName +" "+suppRole[i]);
			 jdbcTemplate.update(insertSQL.toString(),new Object[]{Long.valueOf(tiReq),roleName,suppRole[i]});
			log.debug("suppRoles insert:"+insertSQL.toString());
		}
	    }
	}
	catch(Exception e){
	    log.error(e,e);
	}
	
	log.info("End insertSupReviewRoles::");
	return true;
    }
    
	@Override
    public boolean specialInstructionUpdate(long tiReq, String apsSplInstruction,String prxSplInstruction,
	    String firewallSplInstruction,String ipRegSplInstrcomments, String aclVarSplInstruction){
	int rowsUpdated=0;
	try {
	    StringBuffer splSQL = new StringBuffer();
	    splSQL.append("update c3par.con_req set ");
	    splSQL.append(" SPLINSTR_APPSENSE = ?, ");
	    splSQL.append(" SPLINSTR_PROXY = ?, ");
	    splSQL.append(" SPLINSTR_FIREWALL = ?, ");
	    splSQL.append(" SPLINSTR_IPREG = ?, ");
	    splSQL.append(" SPLINSTR_ACLVAR = ? ");
	    splSQL.append(" where id = ( select con.id from con_req con, ");
	    splSQL.append(" ti_request req,ti_request_planning_xref req_xref " );
	    splSQL.append(" where  req.id=req_xref.ti_request_id and " );
	    splSQL.append(" con.id= req_xref.planning_id and req.id=?)");
	    log.debug( tiReq+ "=="+prxSplInstruction + "==" + splSQL.toString());
	     jdbcTemplate.update(splSQL.toString(),new Object[]{apsSplInstruction,prxSplInstruction,firewallSplInstruction,ipRegSplInstrcomments,
	    						aclVarSplInstruction,Long.valueOf(tiReq)});
	} catch (Exception e) {
	    log.error(e,e);

	} 
	log.debug("Rows updated" + rowsUpdated);
	return true;
    }
	
	@Override
    public void addComments(TiRequestComments tiReqComments, String commentType, String actionType) {
	StringBuffer errMsg=new StringBuffer();
	 SqlRowSet result = null;
	if(tiReqComments==null){
	    errMsg.append("Approval is Null");
	}
	if(tiReqComments!=null ){
	    if(tiReqComments.getTiRequest()==null){
		errMsg.append("  Request Id is Empty");
	    }
	    if(tiReqComments.getComments()==null){
		errMsg.append(" Comments is empty  ");
	    }
	    if(tiReqComments.getApproverSoeID()==null){
		errMsg.append(" Approver ID is empty  ");
	    }
	}
	if(errMsg.length()>0){
	    log.error(errMsg.toString());
	}
	
	//insert the approval or the discussion irrespective of the approval type or the action type.
	try{

	    StringBuffer insertSql = new StringBuffer("insert into c3par.TI_REQUEST_COMMENTS(");
	    insertSql.append("ID,TI_REQUEST_ID,COMMENT_TYPE,ROLE_ID,COMMENTS,USER_ID,COMMENT_DATE)");
	    insertSql.append("values(c3par.SEQ_TI_REQUEST_COMMENTS.NEXTVAL,?,?,(select max(id) from c3par.role where upper(name) like upper(?)),?,(select max(id) from c3par.c3par_users where upper(sso_id) like upper(?)),sysdate)");
	   
	    jdbcTemplate.update(insertSql.toString(),new Object[]{tiReqComments.getTiRequest().getId(),commentType,
	    												tiReqComments.getRoleName(),tiReqComments.getComments(),tiReqComments.getApproverSoeID()});
	    log.debug("SubmitActivityImpl:insertSQL"+result);
	}
	catch(Exception e){
	    log.error(e,e);
	}
	 try{
			StringBuffer updateSQL = new StringBuffer("update ti_activity_trail set approval_system = ? where id in (select id from ti_activity_trail " +
					"where bpm_instance_id is not null and ti_request_id = ? and activity_status = 'SCHEDULED')");
			  jdbcTemplate.update(updateSQL.toString(),new Object[]{OneApprovalConstants.APPROVAL_SYSTEM_CCR,tiReqComments.getTiRequest().getId()});
			  log.debug("SubmitActivityImpl:updateSQL"+result);
	 }
	    catch(Exception e){
	    	log.error(e,e);
	    }
	    
	//If its a submit then lock all the records for that particular ti_request
	if(actionType.equalsIgnoreCase("submit")){
	    try{

		StringBuffer updateSQL = new StringBuffer("update c3par.TI_REQUEST_COMMENTS set locked = 'Y' where ti_request_id = ?");
		 jdbcTemplate.update(updateSQL.toString(),new Object[]{tiReqComments.getTiRequest().getId()});
		 log.debug("SubmitActivityImpl:updateSQL 2"+result);
	    }
	    catch(Exception e){
		log.error(e,e);
	    }
	    
	}
    }
	
	@Override
	@Transactional(readOnly = true)
	public List<TiRequestComments> getComments(Long tiReq,String role,String commentType){
		
		List<TiRequestComments> tiReqComments = new ArrayList<TiRequestComments>();
		StringBuffer sqlQuery = new StringBuffer();
		/*sqlQuery.append("SELECT COMMENTS,COMMENT_DATE,UR.SSO_ID,R.NAME FROM TI_REQUEST_COMMENTS TICOMMENTS ");
		sqlQuery.append(" JOIN ROLE R ON R.ID = TICOMMENTS.ROLE_ID");
		sqlQuery.append(" JOIN C3PAR_USERS UR ON UR.ID = TICOMMENTS.USER_ID ");
		sqlQuery.append("  WHERE TICOMMENTS. TI_REQUEST_ID = ? AND tiComments.COMMENT_TYPE = ? order by TICOMMENTS.id desc");
		SqlRowSet result  = jdbcTemplate.queryForRowSet(sqlQuery.toString(),new Object[]{tiReq,commentType});*/
		sqlQuery.append("select COMMENTS,COMMENT_DATE,UR.SSO_ID,R.NAME,ti1.version_number from TI_REQUEST_COMMENTS TICOMMENTS ");
	    sqlQuery.append("JOIN ROLE R ON R.ID = TICOMMENTS.ROLE_ID ");
	    sqlQuery.append(" JOIN C3PAR_USERS UR ON UR.ID =TICOMMENTS.USER_ID ");
	    sqlQuery.append(" JOIN TI_REQUEST ti1 on ti1.id = ticomments.ti_request_id ");
	    sqlQuery.append(" where TI_REQUEST_ID in (select id from TI_REQUEST where PROCESS_ID in (select process_id from ti_request where id = ?)) and COMMENT_TYPE=? order by TICOMMENTS.COMMENT_DATE desc");

	    log.debug("Comments query: "+sqlQuery.toString()+ " tiReq "+tiReq+" role "+role+" commentType "+commentType);
	    SqlRowSet result = jdbcTemplate.queryForRowSet(sqlQuery.toString(),new Object[]{tiReq,commentType});
		while(result.next()){
			TiRequestComments tiComments = new TiRequestComments();
			tiComments.setComments(result.getString(1));
			tiComments.setCommentDate(result.getDate(2));
			tiComments.setApproverSoeID(result.getString(3));
			tiComments.setRoleName(result.getString(4));
			tiComments.setVersionNumber(result.getInt(5)); 
			 
			tiReqComments.add(tiComments);
			
		}
		log.debug("Comments :"+result+""+tiReqComments);
		
		return tiReqComments;
	}
	
	@Override
	 public void isoInformationUpdate(long tiReq, String issCompliance,String accessRisk, Long planningID) {
		log.debug("SubmitActivityImpl:isoUpdate starts here..."+accessRisk+""+issCompliance+""+planningID);
		 String schSQL = "";	
		try {
			    if(planningID!=null){
				schSQL=new String("update c3par.con_req set " +
					"ISS_CONNECTION_COMPLIANCE = ? "+
					" where id = " + planningID.longValue());
			    }
			    else{
				schSQL=new String("update c3par.con_req set " +
					"ISS_CONNECTION_COMPLIANCE = ? "+
					" where id in (select process_id from c3par.ti_request where id="+tiReq+")");
			    }

			    log.info( tiReq+ "=="+issCompliance + "==" + schSQL.toString());
			    jdbcTemplate.update(schSQL,new Object[]{issCompliance});
			    
			} catch (Exception e) {
			    log.error(e,e);
			} 

			try {
			    schSQL=new String("update c3par.ti_request set " +
				    "IS_CITI_RISK_ASSESSED = ? "+
			    " where id =?");

			    jdbcTemplate.update(schSQL,new Object[]{accessRisk,tiReq});
			   
			} catch (Exception e) {
			    log.error(e,e);
			} 
			log.debug("SubmitActivity isoInformationUpdate ends here..."+schSQL);
	 }
	
	
	@Override
	 public void verifySOWUpdate(long tiRequestId, String verificationFlag, String SOW)  {
		 log.info("SubmitActivityImpl VerifySOW answer updtae..."+verificationFlag+"SOW"+SOW);
			try {
			    String schSQL = "";
			    schSQL=new String("update c3par.ti_request set " +
			    				"ANNUAL_VERIFICATION_FLAG =?, " +
			    				"SOW_NUMBER  =? " +
			    				"where id = ?");
			    
			    jdbcTemplate.update(schSQL, new Object[]{verificationFlag,SOW,tiRequestId});
			    log.debug("Update query:"+schSQL);
			} catch (Exception e) {
			    log.error(e,e);
			} 
	}
	
	
	@Override
	 public void tpwgUpdate(long tiRequestId, String reviewType, String reviewStatus, String scheduleDate
			    , String rejectedDate, String reviewTempDate) {
			log.info("SubmitActivityImpl: tpwgupdate method starts here...");
			try {
			    String schSQL = "";
			    schSQL=new String("update c3par.ti_request set " +
				    "TPWAPP_REVIEW_TYPE =?, " +
				    "TPWAPP_REVIEW_STATUS =?, " +
				    "TPWAPP_REVIEW_DATE =to_date(?, 'MM/DD/YYYY'), " +
				    "TPWAPP_REJECTED_DATE =to_date(?, 'MM/DD/YYYY'), " +
				    "TPWAPP_TEMP_APP_DATE =to_date(?, 'MM/DD/YYYY') " +
			    "where id = ?");
			    
			    jdbcTemplate.update(schSQL,new Object[]{reviewType,reviewStatus,scheduleDate,rejectedDate,
			    				reviewTempDate,tiRequestId});
			    log.debug("SubmitActivityImpl: query result:"+schSQL);
			    
			} catch (Exception e) {
			    log.error(e,e);
			} 
		    }
	
	@Override
	public void updateLoggingDetails(long tiRequestId, String loggingDate, int recommendedLoggingPeriod) {
    	log.info("SubmitActivityImpl:update logging details method starts here ...");
    	try {
    	    String schSQL = "";
    	    schSQL=new String("update c3par.ti_request set " +
    		    "LOGGING_UNTIL =to_date(?, 'MM/DD/YYYY'), " +
    		    "REC_LOG_PRD =? " +
    	    "where id = ?");
    	    jdbcTemplate.update(schSQL,new Object[]{loggingDate,recommendedLoggingPeriod,tiRequestId});
    	    log.debug("update Logging Queue details:"+schSQL);
    	} catch (Exception e) {
    	    log.error(e,e);
    	}
        }
	
	@Override
	public void updateOstiaQuestionairre(Long tiRequestId){
		log.info("SubmitActivityImpl :updateOstiaQuestionairre.."+tiRequestId);
		try {
		    String schSQL = "";
		    schSQL=new String("update c3par.con_fw_rule_questionnaire set " +
			    "STATUS =?, " +
			    "UPDATED_DATE =sysdate " +
			  
		    "where STATUS =? and updated_ti_request_id = ?");
		    
		    jdbcTemplate.update(schSQL,new Object[]{"Reviewed","Completed",tiRequestId});
		    log.debug("SubmitActivityImpl:updateOstia"+schSQL);
		} catch (Exception e) {
		    log.error(e,e);
		}
	}
	
	@Override
	 public void gnccImpUpdate(long tireq, Long infomanID, String schTsmp, String compTsmp){
		log.info("SubmitActivity Impl:Sec ACL Update method starts here ...");
			try {
			   
			    String schSQL = "";
			    log.debug("GNCC Completed Date = " + compTsmp);
			    log.debug("GNCC Scheduled Date = " + schTsmp);
			    log.debug("GNCC Infoman Id ="+infomanID );
			    if(compTsmp!=null && compTsmp.trim().equals("")){
				compTsmp = null;
			    }
			    if(schTsmp!=null && schTsmp.trim().equals("")){
				schTsmp = null;
			    }
			    schSQL="update c3par.ti_request set " +
			    "GNCC_INFOMAN_ID = ? " +
			    ",GNCCIMP_SCHEDULED_DATE = to_date(?, 'MM/DD/YYYY') " +
			    ",GNCCIMP_COMPLETED_DATE = to_date(?, 'MM/DD/YYYY HH24:MI:SS') " +
			    "where id =?";
			    log.debug("schSQL.toString()"+ schSQL);
			    
			    jdbcTemplate.update(schSQL,new Object[]{infomanID.longValue(),schTsmp,compTsmp,tireq});
			    
			    log.debug("SubmitActivity Impl SECACL update:"+schSQL);
			} catch (Exception e) {
			    log.error(e,e);
			} 
	}
	
	
	@Override
	public void ipRegopAnalystUpdate(long tiReq, String changeNo, String schTsmp, String compTsmp){
		log.debug("Submit ACtivity impl:IpReg impl update...");
			try {
			    String schSQL = "";
			    log.debug("Firewall Completed Date = " + compTsmp);
			    log.debug("Firewall Scheduled Date = " + schTsmp);
			    log.debug("Firewall Change Id ="+changeNo );
			    if(compTsmp!=null && compTsmp.trim().equals("")){
				compTsmp = null;
			    }
			    if(schTsmp!=null && schTsmp.trim().equals("")){
				schTsmp = null;
			    }
			    
			    schSQL=new String("update c3par.ti_request set " +
				    "	IPREGIMP_SCHEDULED_DATE = to_date(?, 'MM/DD/YYYY') " +
				    "	,IPREGIMP_COMPLETED_DATE = to_date(?, 'MM/DD/YYYY HH24:MI:SS') " +
			    	"	where id =?");

			    jdbcTemplate.update(schSQL,new Object[]{schTsmp,compTsmp,tiReq});
			    
			    if(schTsmp!=null && !schTsmp.trim().equals("")){
				String installSQL=new String("update c3par.rfc_request set  " +
					"	INSTALL_BEGIN_DATE = to_date(?, 'MM/DD/YYYY') " +
					"	,INSTALL_END_DATE = to_date(?, 'MM/DD/YYYY') " +
					"	where ti_request_id =? and create_type='AUTO' and is_ipreg = 'Y'");

				jdbcTemplate.update(installSQL,new Object[]{schTsmp,schTsmp,tiReq});
			    }
			    
			    if(changeNo!=null && !changeNo.isEmpty()){
					String installSQL=new String("update c3par.rfc_request set  " +
						"	RFC_ID = ? " +
						"	where ti_request_id =? and create_type='AUTO' and is_ipreg = 'Y'");

					jdbcTemplate.update(installSQL,new Object[]{changeNo,tiReq});
					
				}
			    String rfcIDSQL=new String("select id as RFC_ID from c3par.rfc_request where ti_request_id =? and create_type='AUTO' and is_ipreg = 'Y'");
			    SqlRowSet rs  = jdbcTemplate.queryForRowSet(rfcIDSQL,new Object[]{tiReq});

				if(rs != null && rs.next()){
					Long rfcId = rs.getLong("RFC_ID");
					//installDate
				    RFCRequest rfcRequest = new RFCRequest();
					rfcRequest.setId(rfcId);
					RFCLookup rfcLookup = (RFCLookup)rfc.getRFCLookup("INSTALL_DATE");
					RFCDetail rfcDetail = new RFCDetail();
					rfcDetail.setRfcLookup(rfcLookup);
					rfcDetail.setRfcRequest(rfcRequest);
					rfcDetail.setSelected(true);
					RFCDetailAnswer rfcDetailAnswer = new RFCDetailAnswer();
					rfcDetailAnswer.setAnswer(compTsmp);
					rfcDetailAnswer.setRfcDetail(rfcDetail);
					List<RFCDetailAnswer> rfcDetailAnswerList = new ArrayList<RFCDetailAnswer>();
					rfcDetailAnswerList.add(rfcDetailAnswer);
					rfcDetail.setRfcDetailAnswerList(rfcDetailAnswerList);
					
					rfc.addRFCDetail(rfcDetail);
					log.debug("update rfc in SUbmitAACtivity impl:"+rfc+"rfcIDSQL");
				}
			} catch (Exception e) {
			    log.error(e,e);
			} 
		    }
	
		 
		@Override
		public void proxyImpUpdate(long tiReq,String schTsmp, String compTsmp) {
		log.info("Submit Activity proxy impl update method starts here...");
		
		try {
		String schSQL = "";
		log.debug("Proxy Completed Date = " + compTsmp);
		log.debug("Proxy Schedule Date = " + schTsmp);
		if(compTsmp!=null && compTsmp.trim().equals("")){
		compTsmp = null;
		}
		if(schTsmp!=null && schTsmp.trim().equals("")){
		schTsmp = null;
		}
		schSQL=new String("update c3par.ti_request set " +
		" PRXIMP_SCHEDULED_DATE = to_date(?, 'MM/DD/YYYY HH24:MI:SS') " +
		",PRXIMP_COMPLETED_DATE = to_date(?, 'MM/DD/YYYY HH24:MI:SS') " +
		"where id =?");
		
		 jdbcTemplate.update(schSQL,new Object[]{schTsmp,compTsmp,tiReq});
		 
		 } catch (Exception e) {
		    log.error(e);
		} 
		}
		
	  @Override
	  public void tpwgtempAppDateUpdate(long tiReq){
		log.info("SubmitActivityImpl:extended date update..");
		try {
		    String schSQL = "";
			schSQL=new String("update c3par.ti_request set " +
			"  TPWAPP_TEMP_APP_DATE = null " +
			" where id = ?");
			
			jdbcTemplate.update(schSQL,new Object[]{tiReq});
			
			Calendar c1 = Calendar.getInstance();
			c1.setTime(new Date());
			c1.add(Calendar.DATE,365);
			Date activationExpDate=c1.getTime();
			
			StringBuilder updateProcSQL=new StringBuilder("update c3par.ti_process set  temp_Approval_flag='N'");
			updateProcSQL.append(" , temp_expiry_gen_flag = 'N'");
			updateProcSQL.append(" , ACTIVATION_EXP_DATE=? ");
			
			updateProcSQL.append(" where id = (select process_id from ti_request where id = ?) ");
			log.debug("updateProcSQL is "+updateProcSQL.toString());
			
			jdbcTemplate.update(updateProcSQL.toString(),new Object[]{new java.sql.Date(activationExpDate.getTime()),tiReq});
			log.debug("extended date query:"+updateProcSQL.toString()+""+schSQL);
			} catch (Exception e) {
			    log.error(e,e);
			} 
		}
	  
	  
	  @Override
	  public void appsenseImpUpdate(long tiReq, Long infomanID, String schTsmp, String compTsmp) {
		  log.info("SubmitActivity impl:proxy update method starts here ...");

			try {
			    String schSQL = "";
			    log.debug("Appsense Completed Date = " + compTsmp);
			    log.debug("Appsense Scheduled Date = " + schTsmp);
			    log.debug("Appsense Infoman Id ="+infomanID );
			    if(compTsmp!=null && compTsmp.trim().equals("")){
				compTsmp = null;
			    }
			    if(schTsmp!=null && schTsmp.trim().equals("")){
				schTsmp = null;
			    }
			    schSQL="update c3par.ti_request set " +
			    "APS_INFOMAN_ID = ? " +
			    ",APSIMP_SCHEDULED_DATE = to_date(?, 'MM/DD/YYYY') " +
			    ",APSIMP_COMPLETED_DATE = to_date(?, 'MM/DD/YYYY HH24:MI:SS') " +
			    "where id =?";
			    log.debug("schSQL.toString()"+ schSQL);
			    
			    jdbcTemplate.update(schSQL,new Object[]{Long.valueOf(infomanID),schTsmp,compTsmp,tiReq});
			    
			   
			} catch (Exception e) {
			    log.error(e);
			} 
		    }
	  
	  	@Override
	  	@Transactional(readOnly = true)
		public String validateADGroupName(AppsenseADGroup appsenseADGroup) {
		log.info("validateADGroupName method begin");
		
		String msg=null;
		try {
		    String sqlQuery = "";
		sqlQuery=new String("select count(name) from ti_ad_group_name where name=?  and id !=?" );
		
		SqlRowSet rs  = jdbcTemplate.queryForRowSet(sqlQuery,new Object[]{appsenseADGroup.getName(),appsenseADGroup.getId()});
		 
		if(rs.next()){
		    int count=rs.getInt(1);
		    if(count >= 1){
			if(msg!=null){
			    msg=msg+" " + " [ "+appsenseADGroup.getName() +"]";
		}else{
		
		    msg="AD Group name [ "+appsenseADGroup.getName() +"]";
		}
		}else{
		log.info("Proxy Instance Name is a new value");
		    }
		}
		log.info("instance name::: "+appsenseADGroup.getName() +"]");
		
		if(msg!=null){
			String headerMsg="Duplicate AD Grioup Name is not allowed . \n";
			msg=headerMsg+msg;
		    }
		} catch (ApplicationException e){
		    log.error(e, e);
		    throw e;
		} catch (Exception e) {
		    log.error(e);
		} 
		log.info("validateADGroupName method ends");
		return msg;
		}
	  	
	  	@Override
	  	public void updateAppsensePolicyID(String policyName,String policyId,String ADGroupName,Long appsId){
	  		log.info("updateAppsensePolicyID ::  method starts");
	  		
	  		try {
	  		    String sql = "update ti_ad_group_name set isnew='N',updated_date=sysdate,policy_name=?,policy_id=?,name=? where id=?" ;
	  		    log.debug( "Sql Query  " + sql.toString());
	  		    jdbcTemplate.update(sql,new Object[]{policyName,policyId,ADGroupName,Long.valueOf(appsId)});
	  		    
	  		} catch (ApplicationException e){
	  		    log.error(e, e);
	  		    throw e;
	  		}catch (Exception ex) {
	  		    ex.printStackTrace();
	  		    log.error(ex);
	  		} 
	  		log.info("updateAppsensePolicyID ::  method ends");

	  	}
	  	
	  	
		@Override	
	  	public void opAnalystUpdate(long tiReq, String schTsmp, String compTsmp) {
			log.info("SubmitActivityImpl:firewall data update");
	  		try {
	  		    String schSQL = "";
	  		    log.debug("Firewall Completed Date = " + compTsmp);
	  		    log.debug("Firewall Scheduled Date = " + schTsmp);
	  		    if(compTsmp!=null && compTsmp.trim().equals("")){
	  			compTsmp = null;
	  		    }
	  		    if(schTsmp!=null && schTsmp.trim().equals("")){
	  			schTsmp = null;
	  		    }
	  		    schSQL=new String("update c3par.ti_request set " +
	  			    " OPEIMP_SCHEDULED_DATE = to_date(?, 'MM/DD/YYYY') " +
	  			    ",OPEIMP_COMPLETED_DATE = to_date(?, 'MM/DD/YYYY HH24:MI:SS') " +
	  		    		"where id =?");
	  		    
	  		  jdbcTemplate.update(schSQL,new Object[]{schTsmp,compTsmp,tiReq});
	  		    
	  		    if(schTsmp!=null && !schTsmp.trim().equals("")){
	  			String installSQL=new String("update c3par.rfc_request set  " +
	  				"INSTALL_BEGIN_DATE = to_date(?, 'MM/DD/YYYY') " +
	  				",INSTALL_END_DATE = to_date(?, 'MM/DD/YYYY') " +
	  			"where ti_request_id =? and create_type='AUTO' and (is_ipreg is null or is_ipreg != 'Y')");

	  			jdbcTemplate.update(installSQL,new Object[]{schTsmp,schTsmp,tiReq});
	  		    }
	  		} catch (Exception e) {
	  		    log.error(e,e);
	  		} 
	  	    }

		@Override
		@Transactional(readOnly = true)
		public List<LookUpVO> getTPASWGReviewStatus(){
			StringBuffer sql=new StringBuffer("select VALUE1,VALUE2 from ");
			sql.append("c3par.GENERIC_LOOKUP");
			sql.append(" WHERE DEFINITION_ID IN ");
			sql.append(" (select id from c3par.GENERIC_LOOKUP_DEFS where name='TPASWG REVIEW STATUS') ");
			List<LookUpVO> objList=getFromLookup(sql.toString());
			return objList;
		 }
		
		@Override
		@Transactional(readOnly = true)
		 public List<LookUpVO> getTPASWGReviewType(){
				StringBuffer sql=new StringBuffer("select VALUE1,VALUE2 from ");
				sql.append("c3par.GENERIC_LOOKUP");
				sql.append(" WHERE DEFINITION_ID IN ");
				sql.append(" (select id from c3par.GENERIC_LOOKUP_DEFS where name='TPASWG REVIEW TYPE') ");
				List<LookUpVO> objList=getFromLookup(sql.toString());
				return objList;
			    }

		
		private List<LookUpVO> getFromLookup(String sql) 
	    {
		LookUpVO obj=null;
		List<LookUpVO> objList=new ArrayList<LookUpVO>();
		try{
		    log.debug("Inside the lookup"+ sql);
		    SqlRowSet rs  = jdbcTemplate.queryForRowSet(sql);
		    if(rs!=null)
		    {
			while(rs.next())
			{
			    obj=new LookUpVO();
			    obj.setName(rs.getString(1));
			    obj.setStatus(rs.getString(2));
			    objList.add(obj);
			}
		    }
		}catch(Exception e){
			e.printStackTrace();
		}
		
		log.info("Size of Value Object List is "+ objList.size());

		return objList;

	    }
		
		@Override
		@Transactional(readOnly = true)
		public String isUTurnConnection(long tiRequestId) {
			String returnStr = "FALSE";
			try{
			    String sql ="select id from c3par.con_req a where a.source_resource_type=1 and a.target_resource_type = 1 " +
			    "and id in( " +
			    "select ti.process_id from c3par.ti_request ti where ti.id = ?)";
			    log.debug("Inside the lookup"+ sql + tiRequestId);
			    SqlRowSet rs  = jdbcTemplate.queryForRowSet(sql,new Object[]{tiRequestId});
			    if(rs!=null)
			    {
				while(rs.next())
				{

				    if(rs.getLong(1)>0)
					returnStr = "TRUE";
				}
			    }
			}//end of try
			catch (Exception e)
			{
			    e.printStackTrace();
			}
			
			return returnStr;
		    }

		@Override
		public void updateRisoDetails(long tiRequestId,String tempApp,String raReNo) {
	    	log.info("SubmitActivityImpl:updateRisoDetails method starts here ...");
	    	try {
	    	    String schSQL = "";
	    	    schSQL=new String("update c3par.ti_request set " +
	    		    "temp_app_reason =?  " +
	    		    ",ra_re_number =? " +
	    	    "where id = ?");
	    	    jdbcTemplate.update(schSQL,new Object[]{tempApp,raReNo,tiRequestId});
	    	    log.debug("update updateRisoDetails:"+schSQL);
	    	} catch (Exception e) {
	    	    log.error(e,e);
	    	}
	        }
		

		@Override
		@Transactional(readOnly = true)
		public List<GenericLookup> getRISOEmail() {
			Session session = getSession();
			List<GenericLookup> list = (List<GenericLookup>) session
					.createQuery(
							"from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.genericLookupDef.id="
									+ getDefinitionId("RISO_EMAIL")).list();

			return list;

		}
		
		@Override
		@Transactional(readOnly = true)
		public List<GenericLookup> getTempApprovalReasons() {
			Session session = getSession();
			List<GenericLookup> list = (List<GenericLookup>) session
					.createQuery(
							"from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.genericLookupDef.id="
									+ getDefinitionId("TEMP_APPROVAL_REASON")).list();

			return list;

		}
		
		
		private Long getDefinitionId(String defName) {
			Session session = getSession();
			GenericLookupDef res = (GenericLookupDef) session.createQuery(
					"from GenericLookupDef def where upper(def.name)=upper('"
							+ defName + "')").uniqueResult();

			return res.getId();

		}
		
		
}
