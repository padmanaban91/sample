package com.citigroup.cgti.c3par.controller.businessjustification;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.ScenarioNames;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.webtier.helper.LookupNameHelper;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class BPMIntegrationController extends BusJusBaseController{

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	
	String bpmActivityId =null;
	
	@RequestMapping(value = "/bpmIntegrationAction.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String initialize(HttpServletRequest request) {
		log.info("BPMIntegrationController :: initialize starts ");
		BusinessJustificationProcess businessJustificationProcess =
				new BusinessJustificationProcess();
		log.debug("BPMIntegrationController::execute method:taskName:"
				+ request.getParameter("taskName"));
		TIRequest tiRequestEntity = null;
		TIProcess tiProcessEntity = null;
		String bpmForward = null;
		String fun_code = null;
		String selTab = null;
		Util util = new Util();
		String activityCode = null;
		
		
		HttpSession session = request.getSession();

		if (request.getParameter("forward") != null) {
			bpmForward = request.getParameter("forward");
			log.debug("BpmIntegrationAction::execute method:bpmForward"
					+ bpmForward);
		}
		String review = "";
		if(request.getParameter("review") != null){
			review = request.getParameter("review");
		}
		log.info("id = " + request.getParameter("id"));

		fun_code = request.getParameter("fun_code");
		selTab = request.getParameter("sel_tab");
		
		String ecmView = request.getParameter("ecmView");
			if(ecmView != null){
				session.setAttribute("ecmView", "true");
			}else{
				session.setAttribute("ecmView", "false");
			}
		String orderId = request.getParameter("orderId");
		log.info("orderId:: " +orderId);
		if(orderId != null){
			session.setAttribute("orderId", orderId);
		}
		log.debug("BpmIntegrationAction::execute method:fun_code"+ fun_code+"reivew:"+review+" sel_tab->"+selTab);
		if (fun_code == null || !review.isEmpty() ||
				((fun_code.equalsIgnoreCase("search") || fun_code.equalsIgnoreCase("mytask") || fun_code.equalsIgnoreCase("myContactTask")) 
						&& request.getParameter("ssoId") != null && request.getParameter("ssoId").length() > 0 )) {
			session.removeAttribute("TI_REQUEST_ENTITY");
			session.removeAttribute("tireqid");
			session.removeAttribute("activityId");
			session.removeAttribute("forward");
			session.removeAttribute("commentsForm");
			session.removeAttribute("bpmActivityId");
			session.removeAttribute("instanceId");
			session.removeAttribute("MESSAGES");
			session.removeAttribute("MESSAGEXML");
			session.removeAttribute("TPASWGRSTATUS");
			session.removeAttribute("TPASWGRTYPE");
			session.removeAttribute("ISUTURN");
			session.removeAttribute("displayMode");
			/* SearchAction Session varibles are clearing */
			session.removeAttribute("PROCESSLIST");
			session.removeAttribute("TOTALPAGES");
			session.removeAttribute("selected_Tab");

			//request.getSession().removeAttribute("reviewing");
			request.getSession().removeAttribute("iPRequestForm");
			request.getSession().removeAttribute("bususr_mcontact");

			try {
				remAttrReview(request);
				removeIPReviewAttributes(request);
				clearRelationshipSesValues(request);
			} catch (BusinessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			if (request.getSession().getAttribute("forward") != null)
				bpmForward = (String) request.getSession().getAttribute(
						"forward");
		}
		log.debug("BpmIntegrationAction::Getting from the session:bpmForward"
						+ bpmForward);

		// --------------------------- Remove the session variables for comments
		try {
			String landingTab=request.getParameter("landingTab");
			if(review != null && review.equalsIgnoreCase("true") && landingTab!=null && landingTab.equalsIgnoreCase("true")){
				request.getSession().setAttribute("selected_Tab", "BusinessJustification");
			}else if(review != null && review.equalsIgnoreCase("true")){
				request.getSession().setAttribute("selected_Tab", "ConnectionInformation");
			}
			else if(fun_code != null || selTab != null || bpmForward != null){
				request.getSession().setAttribute("selected_Tab", util.getSelectedTab(fun_code, selTab, bpmForward));
			}
			if (bpmForward != null
					&& (bpmForward.equals("admin")
							|| bpmForward.equals("reports") || bpmForward
							.equals("isareport"))) {
				if (bpmForward.equals("reports")) {
					java.util.Set role = (java.util.Set) request.getSession()
							.getAttribute("ROLE");
					if (role != null) {
						if (!role.contains("C3PARSYSTEMADMIN")
								&& !role.contains("Operational_Analyst")
								&& !role.contains("C3PARSECURITYADMIN")
								&& !role.contains("Support Agent"))
							return "c3par.reports.welcome";

					}
				}
				return findForward(bpmForward,null);
			}
			if (bpmForward != null
					&& (bpmForward.equals("isaedit")
							|| bpmForward.equals("add_multiple_clone") || bpmForward
							.equals("add_for_clone"))) {
				bpmForward = "userentitlement_comments";
			} else if (bpmForward != null
					&& (bpmForward.equals("isa_app") || bpmForward
							.equals("mgr_review"))) {
				if (request.getParameter("forward") != null) {
					request.getSession().setAttribute("forward",
							request.getParameter("forward"));
				}
				if (request.getParameter("instanceId") != null) {
					request.getSession().setAttribute("instanceId",
							request.getParameter("instanceId"));
				}
				if (request.getParameter("bpmActivityId") != null) {
					request.getSession().setAttribute("bpmActivityId",
							request.getParameter("bpmActivityId"));
					 bpmActivityId = (String) request.getParameter("bpmActivityId");
					 log.debug("BPMActivity id:"+bpmActivityId);
					
				}
				if (request.getParameter("ssoId") != null) {
					String ssoId = request.getParameter("ssoId");
					if (ssoId.length() > 0)
						ssoId = ssoId.toLowerCase();
					request.getSession().setAttribute("ssoId", ssoId);
				}
				bpmForward = "userentitlement_comments";
			} else {
				log.debug("BpmIntegrationAction::execute method:TiRequestDao getting block");
				log.info(" ssoId value :: "+request.getParameter("ssoId"));
				//for inbox search
				if (request.getParameter("ssoId") != null) {
					String ssoId = request.getParameter("ssoId");
					if (ssoId.length() > 0)
						ssoId = ssoId.toLowerCase();
					request.getSession().setAttribute("ssoId", ssoId);
				}
				
				// get the ti_request id
				Long tiRequestId = null;
				if (request.getParameter("tiRequestId") != null) {
					tiRequestId = Long.valueOf(request
							.getParameter("tiRequestId"));
				}
				if (tiRequestId != null) {
					request.getSession().setAttribute("tireqid",
							tiRequestId + "");
				}
				log.info("activityId value from parameter:: "+request.getParameter("activityId"));
				log.info("activityTrailId value from parameter:: "+request.getParameter("activityTrailId"));
				if (request.getParameter("activityTrailId") != null) {
					request.getSession().setAttribute("activityid",request.getParameter("activityTrailId"));
				}
				if (request.getParameter("forward") != null) {
					request.getSession().setAttribute("forward",
							request.getParameter("forward"));
				}
				if (request.getParameter("instanceId") != null) {
					request.getSession().setAttribute("instanceId",
							request.getParameter("instanceId"));
				}
				if (request.getParameter("bpmActivityId") != null) {
					request.getSession().setAttribute("bpmActivityId",
							request.getParameter("bpmActivityId"));
					 bpmActivityId = (String) request.getParameter("bpmActivityId");
					 log.debug("BPMActivity id:"+bpmActivityId);
				}
				
				if (tiRequestId != null) {
					
					tiRequestEntity = businessJustificationProcess.getTIRequestDetails(tiRequestId);
					tiProcessEntity = tiRequestEntity.getTiProcess();
					log.debug("BpmIntegrationAction::execute method:Tirequestid is :" + tiRequestId + "tiReqEntity:"
							+ tiRequestEntity + "TiprocessEntity:"
							+ tiProcessEntity);

					if (bpmForward != null
							&& (bpmForward.equals("bus_jus") || bpmForward
									.equals("ip_det"))) {
						request.getSession().setAttribute("TI_REQUEST_ENTITY",
								tiRequestEntity);
					} else if (bpmForward != null
							&& (bpmForward.equals("tec_arc") || bpmForward
									.equals("ost_upd") || bpmForward.equals("tec_arc_faf"))) {
						request.getSession().setAttribute("TI_REQUEST_ENTITY",
								tiRequestEntity);
					} else if (bpmForward != null
							&& (bpmForward.equals("bus_jus_review")
									|| bpmForward.equals("ip_det_review") || bpmForward
									.equals("faf_review"))) {
						request.getSession().setAttribute("TI_REQUEST_ENTITY",
								tiRequestEntity);
					} else if (bpmForward != null
							&& bpmForward.equals("business_user")) {
						request.getSession().setAttribute("TI_REQUEST_ENTITY",
								tiRequestEntity);
						bpmForward = "business_user";
					} else if(!review.isEmpty()){
						request.getSession().setAttribute("TI_REQUEST_ENTITY",
								tiRequestEntity);
						if (tiRequestEntity != null) {
							request.getSession().setAttribute("TI_PROCESS_ID",
									tiProcessEntity.getId());
						}
						bpmForward = "review";
					} else {
						request.getSession().setAttribute("TI_REQUEST_ENTITY",
								tiRequestEntity);
						if (tiRequestEntity != null) {
							request.getSession().setAttribute("TI_PROCESS_ID",
									tiRequestEntity.getId());
						}
						bpmForward = "comments";
					}
				}
			}

			ActivityData activityData = null;
			String taskName = request.getParameter("taskName");
			log.debug("BpmIntegration :tireqid:"
					+ request.getSession().getAttribute("tireqid")
					+ "TaskName:" + taskName + "fun_code" + fun_code
					+ "activitydata" + activityData);
			
			String con_type=request.getParameter("con_type");
			if(con_type!=null && !con_type.isEmpty()){
				request.getSession().setAttribute("con_type",con_type);
			}else{
				request.getSession().setAttribute("con_type","Firewall");
			}
			
			if (fun_code == null
					&& (request.getSession().getAttribute("tireqid") != null)
					&& (taskName != null) && !taskName.equals("")) {
				log
						.debug("BpmIntegrationAction::execute method:tireqid and taskName is not null block:taskname"
								+ request.getParameter("taskName"));
				activityData = util.getCurrentActivitybyTiRequestId(
						(String) request.getSession().getAttribute("tireqid"),
						null, taskName);
				log.debug("BpmIntegrationAction::execute method:status"
						+ activityData.getActivityStatus() + "locked:"
						+ activityData.getLockedBy() + "albmpmid:"
						+ activityData.getId());
			} else if (fun_code == null
					&& (request.getSession().getAttribute("tireqid") != null)
					&& (request.getSession().getAttribute("forward") != null)) {
				log
						.debug("BpmIntegrationAction::execute method:tireqid and forward is not null block ");
				activityData = util.getCurrentActivitybyTiRequestId(
						(String) request.getSession().getAttribute("tireqid"),
						(String) request.getSession().getAttribute("forward"),
						null);
			}
			if (activityData != null) {
				if ((request.getParameter("ssoId") != null
						&& activityData.getActivityStatus() != null && activityData
						.getActivityStatus().equals("SCHEDULED"))
						&& ((activityData.getLockedBy() != null && activityData
								.getLockedBy().equals(
										(String) request.getParameter("ssoId"))) || activityData
								.getLockedBy() == null)) {
					log
							.debug("BpmIntegrationAction::execute method:settgin current activity in session ");
					session.setAttribute("displayMode", "Edit");
					session.setAttribute("currentActivityData", activityData);
					session.setAttribute("workflowActivityData", activityData);
					session.setAttribute("activityId", activityData.getId()+"");
					session.setAttribute("ssoId", activityData.getLockedBy());
					session.setAttribute("forward", activityData
							.getEncodedAlbpmActivity());
					session.setAttribute("activityName", activityData
							.getActivityName());
					log.debug("displayMode is Edit");
					
					
					 bpmActivityId = (String) request.getParameter("bpmActivityId");
					 log.debug("BPMActivity id:"+bpmActivityId);
				}
			}

			if (fun_code == null && activityData != null && activityData.getId() != null && review.isEmpty()) {
				fun_code = util.getFunctionCode(activityData
						.getId()+"");
				log
						.debug("BpmIntegrationAction::execute method:getFunctionCode based on albm activity id:"
								+ fun_code);
			} else if (fun_code != null && !(fun_code.equals("comments"))) {
				activityData = util.getCurrentActivitybyFuncode(
						(String) request.getSession().getAttribute("tireqid"),
						fun_code);
				session.setAttribute("currentActivityData", activityData);
				log
						.debug("BpmIntegrationAction::execute method:getActivitydata based on function code and tireqid"+activityData);
				log.debug("ActivityData Details:ActStatus:"+activityData.getActivityStatus()+":LockedBy:"+activityData.getLockedBy()
						+"SSOID:"+request.getSession().getAttribute("ssoId"));
			}else if (fun_code != null && fun_code.equals("comments")){
				activityData = util.getCurrentActivitybyTiRequestId(
						(String) request.getSession().getAttribute("tireqid"),
						null,
						null);
				session.setAttribute("currentActivityData", activityData);
				log
						.debug("BpmIntegrationAction::execute method comments block:getActivitydata based on function code and tireqid"+activityData);
				log.debug("ActivityData Details:comments block:ActStatus:"+activityData.getActivityStatus()+":LockedBy:"+activityData.getLockedBy()
						+"SSOID:"+request.getSession().getAttribute("ssoId"));
			}
			if(fun_code != null && fun_code.equals("bus_usr_mng_contacts")){
				request.getSession().setAttribute("bususr_mcontact", "YES");
			}
			if (((activityData = (ActivityData) request.getSession()
					.getAttribute("currentActivityData")) != null && activityData
					.getActivityStatus().equals("SCHEDULED"))
					&& (request.getSession().getAttribute("ssoId") != null
							&& activityData.getLockedBy() != null && activityData
							.getLockedBy().equals(
									(String) request.getSession().getAttribute(
											"ssoId")))){
				log.debug("BpmIntegrationAction::execute method:set session variables for comments");
				session.setAttribute("displayMode", "Edit");
				session.setAttribute("activityId", activityData
						.getId()+"");
				session.setAttribute("ssoId", activityData.getLockedBy());
				session.setAttribute("forward", activityData
						.getEncodedAlbpmActivity());
				session.setAttribute("activityName", activityData
						.getActivityName());
				log.debug("displayMode is Edit");
				log.debug("BpmIntegrationAction::execute method:displayMode is Edit");
			} else {
				if ("true".equalsIgnoreCase(review) && request.getSession().getAttribute("ssoId") == null && request.getParameter("ssoId") != null) {
					session.setAttribute("ssoId", request.getParameter("ssoId"));
				}
				session.setAttribute("displayMode", "View");
				log.debug("BpmIntegrationAction::execute method:displayMode is View");
			}
			if (bpmForward != null && bpmForward.equalsIgnoreCase("userentitlement_comments")) {
				session.removeAttribute("forward");
				log.debug("BpmIntegrationAction::execute method::before end::userentitlement_comments..clearing session - forward");
			} 

		} catch (Exception e) {
			log.error(e,e);
		}
		Long tiRequestId = getTirequestID(request);	
		if(tiRequestId!=null){
		Long planningId = businessJustificationProcess.getPlanningId(tiRequestId);
		ConnectionRequest conreq = businessJustificationProcess.getConnectionRequest(planningId);
		TIRequest tirequest = businessJustificationProcess.getTIRequestDetails(tiRequestId);
		//completion check
		completionCheck(request, conreq, tirequest) ;
		}
		log.info("BpmIntegrationAction::execute method:"+bpmForward);
		log.info("BpmIntegrationAction::execute methods Ends...");
		
		if("comments".equalsIgnoreCase(fun_code)){
			String activityId =  (String)session.getAttribute("activityId");
			activityCode = util.getTaskCode(Long.valueOf(activityId));
			log.debug("Activity Code for comments page"+activityCode);
			return findForward(fun_code,activityCode);
		} else if ((fun_code == null || fun_code.isEmpty()) && "comments".equalsIgnoreCase(bpmForward)){
			String activityId =  request.getParameter("activityId");
			log.info("activityId :: "+activityId);
			if(!StringUtil.isNullorEmpty(activityId)){
				activityCode = util.getTaskCode(Long.valueOf(activityId));
			}
			if(activityCode!=null && activityCode.equals("admin_support") && request.getParameter("forward") != null){
			    activityCode=request.getParameter("forward");
			}
			log.debug("Activity Code for comments page"+activityCode);
			return findForward(bpmForward, activityCode);
		}
		
		if (fun_code == null) {
			log.debug("bpmForward is:" + bpmForward);
			return findForward(bpmForward,null);
		}
		
		log.info("BpmIntegrationAction::execute method:"+fun_code);
		return findForward(fun_code,null);
	}
	
	
	private String findForward(String forward,String activityCode) {
		if ("bus_jus".equals(forward)) {
			return "forward:/loadBusinessCase.act";
		} else if ("tec_arc_faf".equals(forward)) {
			return "forward:/faf_listTickets.action?fromPage=implPage";
		} else if ("bus_jus_review".equals(forward)) {
			return "forward:/loadBusinessCase.act";
		} else if ("reports".equals(forward)) {
			return "forward:/initializereport.act?type=GENERIC";
		} else if ("admin".equals(forward)) {
			return "c3par.admin.homepage";
		} else if ("isareport".equals(forward)) {
			return "forward:/isaReportAction.do";
		} else if ("faf_review".equals(forward)) {
			return "forward:/fAFReviewAction.do";
		}else if("con_relationship".equals(forward)){
			return "forward:/loadRelationship.act";
		}else if ("connectionBusinessCase".equals(forward)) {
			return "forward:/loadBusinessCase.act";
		}  else if ("con_basic_info".equals(forward)) {
			return "forward:/loadConnectionBasicInfo.act";
		}  else if ("citi_contacts".equals(forward)) {
			return "forward:/loadTargetContacts.act";
		}  else if ("tp_contacts".equals(forward)) {
			return "forward:/loadThirdPartyContacts.act";
		}  else if ("requester_contacts".equals(forward)) {
			return "forward:/loadRequesterContacts.act";
		}  else if ("data_info".equals(forward)) {
			return "forward:/businessCaseAction.do?action=save&#x0026;forwardTo=dataInfo";
		}  else if ("new_instance".equals(forward)) {
			return "forward:/newInstance.act";
		}  else if ("update_filter".equals(forward)) {
			return "forward:/load.act?tab=manageProxy";
		}  else if ("add_pac".equals(forward)) {
			return "forward:/addPac.act";
		}  else if ("update_pac".equals(forward)) {
			return "forward:/load.act?tab=managePacFile";
		}  else if ("update_plug".equals(forward)) {
			return "forward:/load.act?tab=managePlug";
		}  else if ("update_socks".equals(forward)) {
			return "forward:/load.act?tab=manageSocks";
		}  else if ("free_url".equals(forward)) {
			return "forward:/load.act?tab=manageUrlAccess";
		}  else if ("aclvariance".equals(forward)) {
			return "forward:/manageAclVarianceController.act";
		}  else if ("manage_network".equals(forward)) {
			return "forward:/loadFirewallRules.act";
		}  else if ("ost_upd".equals(forward)) {
			return "forward:/listFirewallOstia.act?fromPage=implPage&sel_tab=Impl";
		}  else if ("manage_network_FAFReview".equals(forward)) {
			return "forward:/initializeBusinessCaseAction.do?forward=manage_network_FAFReview";
		}  else if ("manage_appsense".equals(forward)) {
			return "forward:/loadAppsense.act";
		}   else if ("search".equals(forward)) {
			return "forward:/loadSearch.act";
		}   else if ("mytask".equals(forward)) {
			return "forward:/loadMyTasksController.act";   
		}   else if ("myContactTask".equals(forward)) {
			return "forward:/myConnectionInitialize.act"; 
		}   else if ("emer_buscrit_questions".equals(forward)) {
			return "forward:/emerbuscritload.act";
		}   else if ("bus_usr_mng_contacts".equals(forward)) {
			return "forward:/initializeBusinessCaseAction.do?forward=business_user";
		}   else if ("ip_identify_contacts".equals(forward)) {
			return "forward:/iPCitigroupContactsAction.do?action=initialize";
		}   else if ("ip_RegisterIP".equals(forward)) {
			return "forward:/iPRegistrationAction.do?action=initialize";
		}   else if ("review".equals(forward)) {
			return "forward:/loadBusinessCase.act";
		}   else if ("comments".equals(forward)) {
			return getSubmitForward(activityCode);
		}   else if ("userentitlement_comments".equals(forward)) {
			return "forward:/comment.do?action=load";
		}   else if ("createrelationship".equals(forward)) {
			return "forward:/loadRelationshipListController.act"; 
		}   else if ("showDetail".equals(forward)) {
			return "forward:/showDetail.act"; 
		}   else {
			return null;
		}
	} 
	
	  /**
     * Rem attr review.
     *
     * @param request the request
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ServletException the servlet exception
     * @throws BusinessException the business exception
     */
    private void remAttrReview(HttpServletRequest request)
    throws IOException, ServletException, BusinessException
    {
	log.debug("Entering remAttrReview");
	try{
	    request.getSession().removeAttribute("connectionRequestForm");
	    request.getSession().removeAttribute("TI_REQUEST_ENTITY");
	    request.getSession().removeAttribute("PROCESS_TYPE");
	    request.getSession().removeAttribute("PROCESS_NAME");
	    request.getSession().removeAttribute("RELATIONSHIP_ENTITY");
	    request.getSession().removeAttribute("CONNECTION_REQUEST_ENTITY");
	    request.getSession().removeAttribute(ScenarioNames.ATTRIBUTE_NAME);
	    request.getSession().removeAttribute(ScenarioNames.PROCESS_CONTEXT);
	    request.getSession().removeAttribute(LookupNameHelper.PRIORITY);
	    request.getSession().removeAttribute("reviewConnections");
	    request.getSession().removeAttribute("review");
	    request.getSession().removeAttribute("ID_LIST");
	    request.getSession().removeAttribute("TYPE");
	    request.getSession().removeAttribute("PATH.DO");
	    request.getSession().removeAttribute("reviewing");
	    request.getSession().removeAttribute("iPRequestForm");
	    request.getSession().removeAttribute("connectionRequestForm");
	    request.getSession().removeAttribute("approval_list");
	    request.getSession().removeAttribute("currentPage");
	    request.getSession().removeAttribute("requestId");
	    log.info("Cleared Review Session");

	    log.debug("Exiting remAttrReview");

	}catch(Exception ex){
	    log.error(ex);
	}
    }

    private void clearRelationshipSesValues(HttpServletRequest request) throws IOException, ServletException, BusinessException
    {
		log.debug("Entering clearRelationshipSesValues");
		try{
			 request.getSession().removeAttribute("VALIDATION_ERROR_LIST");
			 
			 request.getSession().removeAttribute("CITI_CONTACT_ASSIGN_TO");
			 request.getSession().removeAttribute("CITI_LOCATION_ASSIGN_TO");
			 
			 request.getSession().removeAttribute("CITI_LOCATION_REQ");
			 request.getSession().removeAttribute("CITI_LOCATION_TAR");
			 request.getSession().removeAttribute("CITI_LOCATION_ALL");
			 
			 request.getSession().removeAttribute("CITI_TP_CONTACT_ASSIGN_TO");
			 request.getSession().removeAttribute("CITI_TP_CONTACT_LIST");
			 
			 request.getSession().removeAttribute("CITI_TP_LOCATION_ASSIGN_TO");
			 request.getSession().removeAttribute("CITI_TP_LOCATIONS");
			 request.getSession().removeAttribute("CITI_TP_LOCATIONS_ASSIGNED");
	
			 request.getSession().removeAttribute("ASSIGN_TO");
			 request.getSession().removeAttribute("THIRD_PARTY_LIST");
			 request.getSession().removeAttribute("ALL_THIRD_PARTY_LIST");
			 request.getSession().removeAttribute("THIRD_PARTY_DETAIL_LIST");
			 request.getSession().removeAttribute("THIRD_PARTY_ID");
			 request.getSession().removeAttribute("TARGET_THIRD_PARTY_ID");
		    log.info("Cleared clearRelationshipSesValues");
		}catch(Exception ex){
		    log.error(ex);
		}
    }
    /**
     * Removes the ip review attributes.
     *
     * @param request the request
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ServletException the servlet exception
     * @throws BusinessException the business exception
     */
    private void removeIPReviewAttributes(HttpServletRequest request)
    throws IOException, ServletException, BusinessException
    {
	try{
	    request.getSession().removeAttribute("reviewIps");
	    request.getSession().removeAttribute("ID_LIST");
	    request.getSession().removeAttribute("review");
	    request.getSession().removeAttribute("ipRegisProcessID");
	    request.getSession().removeAttribute("iPRequestForm");
	    request.getSession().removeAttribute("connectionRequestForm");
	    request.getSession().removeAttribute("TYPE");
	    request.getSession().removeAttribute("PATH.DO");
	    request.getSession().removeAttribute("approval_list");
	    request.getSession().removeAttribute("currentPage");
	    request.getSession().removeAttribute("requestId");
	    request.getSession().removeAttribute("forward");
	    request.getSession().removeAttribute("TI_REQUEST_ENTITY");
	    request.getSession().removeAttribute("reviewing");
	    request.getSession().removeAttribute("iPRequestFormRetrieve");

	}catch(Exception ex){
	    log.error(ex);
	}
    }
    
    private String getSubmitForward(String activityCode){
    	log.info("BPMIntegrationController getSubmitForward method starts here .."+activityCode+"BPMActivityId"+bpmActivityId);
    	if ("bus_jus".equals(activityCode) || "tec_arc".equalsIgnoreCase(activityCode)) {
			return "forward:/loadBJSubmit.act"; //BJ submit activity
		}else if("bu_mgr_app".equals(activityCode)){
			return "forward:/loadBMASubmit.act"; //BMA submit Activity
		}else if("se_app".equals(activityCode)){
			return "forward:/loadGlobalEnggSubmit.act"; //Global design engg submit activity
		}else if("act_con".equals(activityCode)){
			return "forward:/loadRequestValidationSubmit.act"; //Request validation
		}else if("iso_app".equalsIgnoreCase(activityCode)){
			return "forward:/loadISOSubmit.act"; //ISO submit activity
		}else if("uat_appsense_imp".equalsIgnoreCase(activityCode)){
			return "forward:/loadUATAppsenseSubmit.act"; //UAT Appsense Impl submit activity
		}else if("uat_request_validation".equalsIgnoreCase(activityCode)){
			return "forward:/loadUATReqValSubmit.act"; //UAT Request Validation submit activity
		}else if((bpmActivityId!=null && (((ActivityDataDTO.Activity_PC_INT_ACV).equalsIgnoreCase(bpmActivityId)) || 
				((ActivityDataDTO.Activity_ISO_INT_ACV).equalsIgnoreCase(bpmActivityId)) ||
				((ActivityDataDTO.Activity_TC_INT_ACV).equalsIgnoreCase(bpmActivityId)) ||
				((ActivityDataDTO.Activity_ADMIN_INT_ACV).equalsIgnoreCase(bpmActivityId)) ||
				((ActivityDataDTO.Activity_BU_INT_ACV).equalsIgnoreCase(bpmActivityId)) ||
				((ActivityDataDTO.Activity_VER_SOW).equalsIgnoreCase(bpmActivityId)) ||
				((ActivityDataDTO.Activity_TC_EXT_ACV).equalsIgnoreCase(bpmActivityId)) || 
				((ActivityDataDTO.Activity_PC_EXT_ACV).equalsIgnoreCase(bpmActivityId)) ||
				((ActivityDataDTO.Activity_ISO_EXT_ACV).equalsIgnoreCase(bpmActivityId)) ||
				((ActivityDataDTO.Activity_BU_EXT_ACV).equalsIgnoreCase(bpmActivityId)) ||
				((ActivityDataDTO.Activity_ADMIN_EXT_ACV).equalsIgnoreCase(bpmActivityId))))) {
			return "forward:/loadACVSubmit.act?bpmActivityId="+bpmActivityId;
		}else if((activityCode!=null && (((ActivityDataDTO.Activity_PC_INT_ACV).equalsIgnoreCase(activityCode)) || 
				((ActivityDataDTO.Activity_ISO_INT_ACV).equalsIgnoreCase(activityCode)) ||
				((ActivityDataDTO.Activity_TC_INT_ACV).equalsIgnoreCase(activityCode)) ||
				((ActivityDataDTO.Activity_ADMIN_INT_ACV).equalsIgnoreCase(activityCode)) ||
				((ActivityDataDTO.Activity_BU_INT_ACV).equalsIgnoreCase(activityCode)) ||
				((ActivityDataDTO.Activity_VER_SOW).equalsIgnoreCase(activityCode)) ||
				((ActivityDataDTO.Activity_TC_EXT_ACV).equalsIgnoreCase(activityCode)) || 
				((ActivityDataDTO.Activity_PC_EXT_ACV).equalsIgnoreCase(activityCode)) ||
				((ActivityDataDTO.Activity_ISO_EXT_ACV).equalsIgnoreCase(activityCode)) ||
				((ActivityDataDTO.Activity_BU_EXT_ACV).equalsIgnoreCase(activityCode)) ||
				((ActivityDataDTO.Activity_ADMIN_EXT_ACV).equalsIgnoreCase(activityCode))))) {
			return "forward:/loadACVSubmit.act?bpmActivityId="+activityCode;
		}else if("pro_inf".equalsIgnoreCase(activityCode) ||"pro_inf1".equalsIgnoreCase(activityCode)
				|| "pro_inf2".equalsIgnoreCase(activityCode) || "pro_inf3".equalsIgnoreCase(activityCode)
				|| "pro_inf4".equalsIgnoreCase(activityCode) || "pro_inf5".equalsIgnoreCase(activityCode)
				|| "pro_inf6".equalsIgnoreCase(activityCode) || "pro_inf7".equalsIgnoreCase(activityCode)
				|| "pro_inf8".equalsIgnoreCase(activityCode) || "pro_inf9".equalsIgnoreCase(activityCode)
				|| "mad_pro_inf".equalsIgnoreCase(activityCode) || "otrm_pro_inf".equalsIgnoreCase(activityCode)
				|| "pro_inf10".equalsIgnoreCase(activityCode) || "pro_inf11".equalsIgnoreCase(activityCode)
				|| "uat_appsense_provide_info".equalsIgnoreCase(activityCode)){
			
			return "forward:/loadProvideInfoSubmit.act"; //ProvideInfo submit activity
		}else if("otrm_app".equalsIgnoreCase(activityCode) || "mad_app".equalsIgnoreCase(activityCode)){
			return "forward:/loadGISSubmit.act?activityCode="+activityCode; //GIS/MAD submit activity
		}else if("otrm_ret_app".equalsIgnoreCase(activityCode) || "mad_ret_app".equalsIgnoreCase(activityCode)){
			return "forward:/loadRetroActiveSubmit.act?activityCode="+activityCode; //GIS/MAD Retroactive Approval submit activity
		}else if("tpw_app".equalsIgnoreCase(activityCode) || "tpw_ret_app".equalsIgnoreCase(activityCode)){
			return "forward:/loadTPASWGSubmit.act"; //TPASWG and TPASWG Retroactive Approval submit activity
		}else if("gncc_imp".equalsIgnoreCase(activityCode)){
			return "forward:/loadACLSubmit.act"; //Sec ACL implementation activity
		}else if("han_rfc_exc".equalsIgnoreCase(activityCode)){
			return "forward:/loadHandleChangeSubmit.act"; //Handle Change Exception implementation activity
		}else if("ope_ipreg_imp".equalsIgnoreCase(activityCode)){
			return "forward:/loadIPREGSubmit.act"; //IP Registration Implementation
		}else if("proxy_imp".equalsIgnoreCase(activityCode)){
			return "forward:/loadProxySubmit.act"; //Proxy Implementation
		}else if("appsense_imp".equalsIgnoreCase(activityCode)){
			return "forward:/loadApsImplSubmit.act"; //Appsense Implementation
		}else if("ost_upd".equalsIgnoreCase(activityCode)){
			return "forward:/loadOstiaUpdateSubmit.act"; //Ostia Update
		}else if("rec_exp".equalsIgnoreCase(activityCode)){
			return "forward:/loadReconcileSubmit.act"; //Reconcile Expiration
		}
		else if("inc_exp".equalsIgnoreCase(activityCode)){
			return "forward:/loadIncompleteExpSubmit.act";	//InComplete Expiration inc_exp
		}
		else if("impl_exp".equalsIgnoreCase(activityCode)){
			return "forward:/loadImplementationExpSubmit.act";	//Implementation Expiration 
		}
		else if("app_exp".equalsIgnoreCase(activityCode)){
			return "forward:/loadApprovalExpSubmit.act";	//Approval Expiration
		}
		else if("acv_exp".equalsIgnoreCase(activityCode)){
			return "forward:/loadACVExpSubmit.act";	//ACV Expiration 
		}
		else if("tmp_exp".equalsIgnoreCase(activityCode)){
			return "forward:/loadTempAppSubmit.act"; //TempApproval Expiration
		}else if("ope_imp".equalsIgnoreCase(activityCode)){
			return "forward:/loadFwImplSubmit.act"; //Firewall Implementation
		}else if("han_rfc_exc_proxy".equalsIgnoreCase(activityCode)){
			return "forward:/loadHandleProxySubmit.act"; //Handle Proxy change Exceptionoa_log
		}else if(("impl_sn_bypass".equalsIgnoreCase(activityCode)) || "proxy_impl_sn_bypass".equalsIgnoreCase(activityCode)){
			return "forward:/loadSNOWByPassSubmit.act"; //Servicenow By Pass Implementation
			
		}
		else if(("OALoggingQueue".equalsIgnoreCase(bpmActivityId)) || "LoggingQueue".equalsIgnoreCase(bpmActivityId) ||
				("TCLoggingQueue".equalsIgnoreCase(bpmActivityId)) ||
				("PCLoggingQueue".equalsIgnoreCase(bpmActivityId)) ){
					return "forward:/loadLogQueueSubmit.act?bpmActivityId="+bpmActivityId;
			
		}else {
    		return null;	
    	}
    	
    	
    }
	
    private Long getTirequestID(HttpServletRequest request){

		Long tirequestId = null;
		if(request.getSession().getAttribute("tireqid") != null){
			tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());			
		}else if(request.getParameter("tireqid") != null){
			tirequestId = Long.valueOf(request.getParameter("tireqid").trim());			
		}else if(request.getSession().getAttribute("tiRequestId") != null){ 
			tirequestId = Long.valueOf(request.getParameter("tiRequestId"));
		}
		log.info("BusinessJustificationController :: getTirequestID :: tirequestId - "+tirequestId);
		return tirequestId;
	}
	
}