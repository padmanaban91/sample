/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.dashboard.webtier.helper;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;



/**
 * The Class AttributeToListPositionMapBuilder.
 *
 * @author pkadam
 */
public class AttributeToListPositionMapBuilder {

    /** The type map. */
    private Map typeMap = new HashMap();

    /** The registered types. */
    private String[] registeredTypes ;

    /** The object with id list. */
    private List objectWithIdList ;

    /** The log. */
    private static Logger log = Logger.getLogger(AttributeToListPositionMapBuilder.class);

    /**
     * Instantiates a new attribute to list position map builder.
     *
     * @param objectWithIdList the object with id list
     * @param type the type
     */
    public AttributeToListPositionMapBuilder(List objectWithIdList, String[] type) {
	this.objectWithIdList = objectWithIdList ;
	this.registeredTypes = type ;

	rebuild();
    }

    /**
     * Rebuild.
     */
    public void rebuild() {
	typeMap.clear();

	for (String registeredType : registeredTypes) {
	    typeMap.put(registeredType, new HashMap());
	}

	if(objectWithIdList == null) {
	} else {

	    int size = objectWithIdList.size();

	    for(int i=0;i<size;i++) {
		Object o = objectWithIdList.get(i);
		if(o != null) {
		    try {
			for (String registeredType : registeredTypes) {
			    Method method = o.getClass().getMethod(registeredType, new Class[]{});

			    Long Id = (Long) method.invoke(o, new Object[] {});

			    if(Id == null) {
				// if we don't find an Id we will drop that : REVISIT
				log.debug("ID is null " + o.getClass().getName());
			    } else {
				Map m = (Map) typeMap.get(registeredType);
				m.put(Id, Integer.valueOf(i));
			    }
			}
		    } catch (Exception e) {
			log.error(e); // REVISIT
		    }
		}
	    }
	}
    }

    /**
     * Gets the position.
     *
     * @param type the type
     * @param id the id
     * @return the position
     */
    public Integer getPosition(String type, Long id) {
	Integer i = null ;
	Map t = (Map) typeMap.get(type);
	if(t != null) {
	    i = (Integer) t.get(id); 
	}

	return i ;
    }
}

