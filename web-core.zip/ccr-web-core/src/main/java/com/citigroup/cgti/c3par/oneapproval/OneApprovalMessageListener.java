package com.citigroup.cgti.c3par.oneapproval;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;

import com.citigroup.cgti.c3par.mailmodule.action.AbstractActionFactory;

/*
 * Receives the messages from OneApproval
 */
/**
 * 
 * @author ne36745
 *
 */
public class OneApprovalMessageListener implements MessageListener{
	
	/**
	 * 
	 */
	Logger log = Logger.getLogger(OneApprovalMessageListener.class);
	
	/**
	 * 
	 */
	private AbstractActionFactory factory;
	
	/**
	 * @return the factory
	 */
	public AbstractActionFactory getFactory() {
		return factory;
	}

	/**
	 * @param factory the factory to set
	 */
	public void setFactory(AbstractActionFactory factory) {
		this.factory = factory;
	}

	/**
	 * 
	 */
	public void onMessage(Message message)
	{
		log.info("OneApprovalMessageListener starts here ...");
		TextMessage textMessage = (TextMessage)message;
		
		try {
			
			log.debug("JMS Message ID Recieved: "+message.getJMSMessageID());
			
			log.debug("OneApproval parse text ..."+textMessage.getText());
			
			OneApprovalMessageLog oneApprovalMessageLog; 
			
			//To parse the xml into OneApprovalMessageLog
			oneApprovalMessageLog = OneApprovalMessageLog.parse(textMessage.getText());
			
			if (oneApprovalMessageLog != null) {
				
				//Save or update the message log
				boolean duplicate = oneApprovalMessageLog.saveorUpdateMessageLog();
				
				if (!duplicate) {
					try {
						//get the corresponding bean class to handle and process the message
						log.debug("OneApprovalMessageListener :: oneApprovalMessageLog.getActivity() - "+oneApprovalMessageLog.getActivity());
						OneApprovalAction action = factory.getBeanFactory().getBean(oneApprovalMessageLog.getActivity()+"OneApproval", OneApprovalAction.class);
						if (action != null) {
							action.process(oneApprovalMessageLog);
						}
					} catch(NoSuchBeanDefinitionException e) {
						log.error(e);
					}
				}
			}			
			log.info("OneApprovalMessageListener ends here ...");
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e,e);
		}
	}
}
