package com.citigroup.cgti.c3par.search.webtier.validator;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
 
import com.citigroup.cgti.c3par.admin.domain.ListLookupProcess;
 
 

 
public class ListLookupValidator implements Validator {
	
	private static Logger log = Logger.getLogger(ListLookupValidator.class);
	 public boolean supports(Class<?> paramClass) { 
	        return ListLookupProcess.class.equals(paramClass); 
	    } 
	  
	@Override
	public void validate(Object obj, Errors errors) { 
	 	log.debug("Validate List look up Enter::loadLookup methods starts...");  
	 	ListLookupProcess isoProcessObj = (ListLookupProcess) obj;  
	    if(isoProcessObj.getLookupValue().isEmpty())
        {        
        	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lookupValue", "valid");      
        }   
	    if(isoProcessObj.getLookupDefId()==null)
        {        
        	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lookupDefId", "valid");      
        }   
        log.debug("Validate List look up Enter::loadLookup methods  Ends..."); 
       } 
 
    }
    


