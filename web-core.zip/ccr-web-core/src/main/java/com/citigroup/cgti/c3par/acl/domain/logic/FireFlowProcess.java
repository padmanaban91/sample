/*
 *
 */
package com.citigroup.cgti.c3par.acl.domain.logic;

import java.util.List;

import com.citigroup.cgti.c3par.domain.TIRequest;

// TODO: Auto-generated Javadoc
/**
 * The Interface FireFlowProcess.
 */
@SuppressWarnings("unchecked")
public interface FireFlowProcess {

    /**
     * Gets the fire flow requests.
     *
     * @param tiRequest the ti request
     * @return the fire flow requests
     */
    public List getFireFlowRequests(TIRequest tiRequest);

    /**
     * Gets the fire flow requests.
     *
     * @param processId the process id
     * @param pageNo the page no
     * @param noOfRecords the no of records
     * @return the fire flow requests
     */
    public List getFireFlowRequests(long processId, int pageNo, int noOfRecords);

    /**
     * Gets the total fire flow requests.
     *
     * @param processId the process id
     * @return the total fire flow requests
     */
    public int getTotalFireFlowRequests(long processId);

}
