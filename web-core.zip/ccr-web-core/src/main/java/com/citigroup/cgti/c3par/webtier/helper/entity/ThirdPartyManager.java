package com.citigroup.cgti.c3par.webtier.helper.entity;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import com.mentisys.dao.DatabaseException;

import com.mentisys.dao.DatabaseSession;
import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.*;
import com.citigroup.cgti.c3par.model.*;

import com.mentisys.dao.query.*;


/**
 * The Class ThirdPartyManager.
 */
public class ThirdPartyManager
{
    //=======================================================================================
    //	static public void update(BusinessUnitEntity entity, DatabaseSession dbs) throws DatabaseException
    //	{
    //		if(entity != null)
    //		{
    //			BusinessUnitDAO dao = new BusinessUnitDAO(dbs);
    //			dao.insert(entity);
    //			BusinessUnitLookup lookup = BusinessUnitLookup.getInstance();
    //			lookup.reset();
    //			lookup.initialize(new C3parSession());
    //		}
    //	}

    //=======================================================================================
    /**
     * Update.
     *
     * @param entity the entity
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void update(ThirdPartyEntity entity, C3parSession dbs) throws DatabaseException
    {
	if(entity != null)
	{
	    ThirdPartyDAO dao = new ThirdPartyDAO(dbs);
	    dao.update(entity, dbs.getArchiver());
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void delete(String id, C3parSession dbs) throws DatabaseException
    {
	if(id != null && id.length() > 0)
	{
	    ThirdPartyManager.delete(Long.valueOf(id), dbs);
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param id the id
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void delete(Long id, C3parSession dbs) throws DatabaseException
    {
	if(id != null)
	{
	    ThirdPartyEntity entity = ThirdPartyManager.get(id, dbs);
	    ThirdPartyManager.delete(entity, dbs);
	}
    }

    //=======================================================================================
    /**
     * Delete.
     *
     * @param entity the entity
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void delete(ThirdPartyEntity entity, C3parSession dbs) throws DatabaseException
    {
	if(entity != null)
	{
	    ThirdPartyContactDAO contact_dao = new ThirdPartyContactDAO(dbs);
	    List contacts = entity.getContact();
	    Iterator iter = contacts.iterator();
	    while(iter.hasNext())
	    {
		contact_dao.delete((ThirdPartyContactEntity)iter.next(), dbs.getArchiver());
	    }

	    ThirdPartyDAO dao = new ThirdPartyDAO(dbs);
	    dao.delete(entity, dbs.getArchiver());

	    // THE FOLLOWING SHOULD NOT BE DONE BEFORE THE ThirdParty
	    // IS DELETED. If that happens we are sure to get Constraint Violation.
	    // Thats just because the Xref instances would not have been removed.
	    // They get removed thru the ThirdPartyDAO.
	    // Third Party deletion must also take care of deleting
	    // locations (if necessary). This is because the Location are 
	    // in Association relationship with Xref entity
	    // and if their are no entities using that location
	    // it must be removed otherwise they would remain dangling/unused
	    List locations = entity.getLocation();
	    // NOTE : Could not use iterator. Got a java.util.ConcurrentModificationException
	    // Had to use for(;;)
	    for(int pos=0;pos < locations.size(); pos++) {
		ThirdPartyLocationXrefEntity xref = (ThirdPartyLocationXrefEntity) locations.get(pos);
		removeLocation(entity.getId(), xref, dbs);	
	    }			
	}
    }

    //=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @param dbs the dbs
     * @return the third party entity
     * @throws DatabaseException the database exception
     */
    static public ThirdPartyEntity get(String id, DatabaseSession dbs) throws DatabaseException
    {
	ThirdPartyEntity	entity = null;
	if(id != null && id.length() > 0)
	{
	    entity = ThirdPartyManager.get(Long.valueOf(id), dbs);
	}
	return entity;
    }

    //=======================================================================================
    /**
     * Gets the.
     *
     * @param id the id
     * @param dbs the dbs
     * @return the third party entity
     * @throws DatabaseException the database exception
     */
    static public ThirdPartyEntity get(Long id, DatabaseSession dbs) throws DatabaseException
    {
	ThirdPartyEntity	entity = null;
	if(id != null)
	{
	    ThirdPartyDAO dao = new ThirdPartyDAO(dbs);
	    entity = dao.get(id);
	}
	return entity;	
    }

    //=======================================================================================
    /**
     * Gets the all.
     *
     * @param dbs the dbs
     * @return the all
     * @throws DatabaseException the database exception
     */
    static public List getAll(DatabaseSession dbs) throws DatabaseException
    {
	ThirdPartyDAO dao = new ThirdPartyDAO(dbs);
	Condition condition = new Condition();
	condition.addOrderByField(ThirdPartyDAO.COLUMN_NAME);
	List list = dao.query(condition, false);

	return list;
    }

    //=======================================================================================
    /**
     * Adds the location.
     *
     * @param entity the entity
     * @param location_entity the location_entity
     */
    static public void addLocation(ThirdPartyEntity entity, LocationEntity location_entity)
    {
	ThirdPartyLocationXrefEntity site_xref_entity = new ThirdPartyLocationXrefEntity();
	site_xref_entity.setThirdparty(entity);
	site_xref_entity.setLocation(location_entity);

	entity.getLocation().add(site_xref_entity);
    }

    //=======================================================================================
    /**
     * Removes the location.
     *
     * @param entity the entity
     * @param location_id the location_id
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void removeLocation(ThirdPartyEntity entity, String location_id, C3parSession dbs) throws DatabaseException
    {
	removeLocation(entity, Long.valueOf(location_id), dbs);
    }

    //=======================================================================================
    /**
     * Removes the location.
     *
     * @param entity the entity
     * @param location_id the location_id
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void removeLocation(ThirdPartyEntity entity, Long location_id, C3parSession dbs) throws DatabaseException
    {
	ThirdPartyLocationXrefEntity xref = getLocationXref(entity, location_id);
	if(xref != null)
	{
	    LocationEntity location_entity = xref.getLocation();
	    entity.getLocation().remove(xref);

	    removeLocation(entity.getId(), xref, dbs);			
	}
    }

    /**
     * Removes the location.
     *
     * @param tpid the tpid
     * @param tpLocXref the tp loc xref
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static private void removeLocation(Long tpid, ThirdPartyLocationXrefEntity tpLocXref, C3parSession dbs) throws DatabaseException {
	ThirdPartyLocationXrefDAO xref_dao = new ThirdPartyLocationXrefDAO(dbs);
	xref_dao.delete(tpLocXref, dbs.getArchiver());

	if(mayDeleteLocation(tpLocXref, dbs))
	{
	    LocationEntity location_entity = tpLocXref.getLocation();

	    LocationDAO location_dao = new LocationDAO(dbs);

	    location_dao.delete(location_entity, dbs.getArchiver());
	}		
    }

    //=======================================================================================
    /**
     * May delete location.
     *
     * @param xref the xref
     * @param dbs the dbs
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    static private boolean mayDeleteLocation(ThirdPartyLocationXrefEntity xref, C3parSession dbs) throws DatabaseException
    {
	boolean result = false;
	List referencers = new ArrayList();
	ThirdPartyLocationXrefDAO dao = new ThirdPartyLocationXrefDAO(dbs);
	LocationEntity location_entity = xref.getLocation();

	Condition cond = new Condition();
	Expression expr = new OperatorExpression(ThirdPartyLocationXrefDAO.COLUMN_LOCATION_ID, Operator.EQUAL, location_entity.getId());
	cond.addExpression(expr);
	referencers = dao.query(cond, false);

	// Since this method is invoked after the xref instance is removed from the 
	// database, if the xref was the only instance, then no more referencers 
	// exist. Hence, we test for 0. 
	if(referencers.size() == 0)
	{
	    // since their are not more xref instances for this location
	    // it is a candidate for removal.
	    result = true;	
	}

	return result; 
    }

    //=======================================================================================
    /**
     * Gets the location.
     *
     * @param entity the entity
     * @param location_id the location_id
     * @return the location
     */
    static public LocationEntity getLocation(ThirdPartyEntity entity, Long location_id)
    {
	LocationEntity location_entity = null;
	ThirdPartyLocationXrefEntity xref = getLocationXref(entity, location_id);
	if(xref != null)
	{
	    location_entity = xref.getLocation();
	}			
	return location_entity;
    }

    //=======================================================================================
    /**
     * Gets the all locations.
     *
     * @param entity the entity
     * @return the all locations
     */
    static public List getAllLocations(ThirdPartyEntity entity)
    {
	List locs = new ArrayList();
	Iterator iter = entity.getLocation().iterator();
	while(iter.hasNext())
	{
	    ThirdPartyLocationXrefEntity xref = (ThirdPartyLocationXrefEntity)iter.next();	
	    locs.add(xref.getLocation());
	}			
	return locs;
    }

    //=======================================================================================
    /**
     * Gets the location xref.
     *
     * @param entity the entity
     * @param location_id the location_id
     * @return the location xref
     */
    static public ThirdPartyLocationXrefEntity getLocationXref(ThirdPartyEntity entity, Long location_id)
    {
	ThirdPartyLocationXrefEntity xref = null; 
	Iterator iter = entity.getLocation().iterator();
	while(iter.hasNext() && xref == null)
	{
	    xref = (ThirdPartyLocationXrefEntity)iter.next();	
	    LocationEntity location_entity = xref.getLocation();

	    if(!location_id.equals(location_entity.getId()))
	    {

		xref = null;					
	    }
	}
	return xref;
    }

    //=======================================================================================
    /**
     * Adds the contact.
     *
     * @param entity the entity
     * @param contact the contact
     */
    static public void addContact(ThirdPartyEntity entity, ThirdPartyContactEntity contact)
    {
	entity.getContact().add(contact);
    }

    //=======================================================================================
    /**
     * Removes the contact.
     *
     * @param entity the entity
     * @param contact_id the contact_id
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void removeContact(ThirdPartyEntity entity, String contact_id, C3parSession dbs) throws DatabaseException
    {
	removeContact(entity, Long.valueOf(contact_id), dbs);
    }

    //=======================================================================================
    /**
     * Removes the contact.
     *
     * @param entity the entity
     * @param contact_id the contact_id
     * @param dbs the dbs
     * @throws DatabaseException the database exception
     */
    static public void removeContact(ThirdPartyEntity entity, Long contact_id, C3parSession dbs) throws DatabaseException
    {
	ThirdPartyContactEntity contact = getContact(entity, contact_id);
	if(contact != null)
	{
	    entity.getContact().remove(contact);
	    ThirdPartyContactDAO tpc_dao = new ThirdPartyContactDAO(dbs);
	    tpc_dao.delete(contact, dbs.getArchiver());
	}
    }

    //=======================================================================================
    /**
     * Gets the all contacts.
     *
     * @param entity the entity
     * @return the all contacts
     */
    static public List getAllContacts(ThirdPartyEntity entity)
    {
	return entity.getContact();
    }

    //=======================================================================================
    /**
     * Gets the contact.
     *
     * @param entity the entity
     * @param id the id
     * @return the contact
     */
    static public ThirdPartyContactEntity getContact(ThirdPartyEntity entity, Long id)
    {
	ThirdPartyContactEntity contact = null;
	Iterator iter = getAllContacts(entity).iterator();
	while(iter.hasNext() && contact == null)
	{
	    contact = (ThirdPartyContactEntity)iter.next();
	    if(!id.equals(contact.getId()))
	    {
		contact = null;
	    }
	}
	return contact;
    }
}


