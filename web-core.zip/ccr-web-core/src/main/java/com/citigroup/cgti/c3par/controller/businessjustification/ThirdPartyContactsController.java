package com.citigroup.cgti.c3par.controller.businessjustification;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;

@Controller
public class ThirdPartyContactsController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@RequestMapping(value = "/loadThirdPartyContacts.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String loadTargetContacts(HttpServletRequest request, ModelMap model) {
		log.info("ThirdPartyContactsController :: loadTargetContacts :: start ");
		BusinessJustificationProcess busjusProcess = new BusinessJustificationProcess();
		
		Long tiRequestId = getTirequestID(request);
		TIRequest tirequest = busjusProcess.getTIRequestDetails(tiRequestId);	
		if (tirequest != null && tirequest.getTiProcess().getId() != null) {
			log.debug("Ti Process:inside loadTargetContacts:: "+ tirequest.getTiProcess().getId());
		}
		busjusProcess.setTirequest(tirequest);

		//copy contacts from relationship contacts table (first time)
		busjusProcess.copyContactsFromRelationship(tiRequestId);
		
		Long planningId = busjusProcess.getPlanningId(tiRequestId);		
		log.debug("planningId :: loadTargetContacts::...."+planningId);
		
		busjusProcess.setCurrVersionNo(busjusProcess.getTirequest().getVersionNumber());		
		busjusProcess.setTargetTPContacts(busjusProcess.getTargetTPContactsList(planningId));
		busjusProcess.setRequesterTPContacts(busjusProcess.getRequesterTPContactsList(planningId));
		if (busjusProcess.getTargetTPContacts() !=null) {
			log.debug("Planning ID "+planningId+" Target TP Contacts Size "+busjusProcess.getTargetTPContacts().size());
		}
		if (busjusProcess.getRequesterContacts() !=null) {
			log.debug("Planning ID "+planningId+" Requester TP Contacts Size "+busjusProcess.getRequesterTPContacts().size());
		}
		model.addAttribute("busjusProcess",busjusProcess);
		log.debug("ThirdPartyContactsController :: loadTargetContacts :: ends");
		return "c3par.businessjustification.tpContacts";
	}
	

	@RequestMapping(value = "/continueThirdPartyContacts.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String continueThirdPartyContacts(HttpServletRequest request, @ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess, ModelMap model) {
		String forwardTo = "";

		Long tirequestId = getTirequestID(request);
		if(busjusProcess.isBuscritEmerConnection(tirequestId)){
    		forwardTo = "redirect:/emerbuscritload.act";
    	}else{
    		forwardTo = "redirect:/loadFirewallRules.act";
    	}
		
		return forwardTo;
	}
	
	private Long getTirequestID(HttpServletRequest request){
		log.debug("ThirdPartyContactsController :: getTirequestID :: start");
		Long tirequestId = 0L;
		if(request.getSession().getAttribute("tireqid") != null){
			tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());			
		}else if(request.getParameter("tireqid") != null){
			tirequestId = Long.valueOf(request.getParameter("tireqid").trim());			
		}else { 
			tirequestId = Long.valueOf(request.getParameter("tiRequestId"));
		}
		log.debug("getTirequestID..... "+tirequestId);
		log.debug("ThirdPartyContactsController :: getTirequestID :: ends");
		return tirequestId;
	}

}
