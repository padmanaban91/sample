package com.citigroup.cgti.c3par.soa.vc;

import javax.xml.namespace.QName;
import javax.xml.rpc.handler.Handler;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;

import org.apache.log4j.Logger;

//import weblogic.logging.NonCatalogLogger;


/**
 * * Class that implements a handler in the handler chain, used to access the
 * SOAP * request and response message. *
 * <p>
 * * The class implements the <code>javax.xml.rpc.handler.Handler</code> *
 * interface. The class simply prints the SOAP request and response messages *
 * to a log file before the messages are processed by the backend component. * * @author
 * Copyright (c) 2003 by BEA Systems. All Rights Reserved.
 */
public final class LogHandler implements Handler {

    /** The log. */
    protected Logger log = Logger.getLogger(this.getClass().getName());

    /** The handler info. */
    private HandlerInfo handlerInfo;

    /**
     * * Initializes the instance of the handler. Creates a nonCatalogLogger to
     * * log messages to.
     *
     * @param hi the hi
     */
    public void init(HandlerInfo hi) {
//	log = new NonCatalogLogger("WebService-LogHandler");
	handlerInfo = hi;
    }

    /** * Destroys the Handler instance. */
    public void destroy() {
    }

    /* (non-Javadoc)
     * @see javax.xml.rpc.handler.Handler#getHeaders()
     */
    public QName[] getHeaders() {
	return handlerInfo.getHeaders();
    }

    /**
     * * Specifies that the SOAP request message be logged to a log file before
     * the * message is sent to the Java class backend component.
     *
     * @param mc the mc
     * @return true, if successful
     */
    public boolean handleRequest(MessageContext mc) {
	SOAPMessageContext messageContext = (SOAPMessageContext) mc;
	System.out.println("** Request: "
		+ messageContext.getMessage().toString());
	log.info(messageContext.getMessage().toString());
	return true;
    }

    /**
     * * Specifies that the SOAP response message be logged to a log file before
     * the * message is sent back to the client application that invoked the Web
     * service.
     *
     * @param mc the mc
     * @return true, if successful
     */
    public boolean handleResponse(MessageContext mc) {
	SOAPMessageContext messageContext = (SOAPMessageContext) mc;
	System.out.println("** Response: "
		+ messageContext.getMessage().toString());
	log.info(messageContext.getMessage().toString());
	return true;
    }

    /**
     * * Specifies that a message be logged to the log file if a SOAP fault is *
     * thrown by the Handler instance.
     *
     * @param mc the mc
     * @return true, if successful
     */
    public boolean handleFault(MessageContext mc) {
	SOAPMessageContext messageContext = (SOAPMessageContext) mc;
	System.out.println("** Fault: "
		+ messageContext.getMessage().toString());
	log.info(messageContext.getMessage().toString());
	return true;
    }
}
