package com.citigroup.cgti.c3par.controller.reports;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.citigroup.cgti.c3par.reports.domain.GenericReport;
import com.citigroup.cgti.c3par.reports.domain.GenericReportProcess;

@Controller
public class GenericReportController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@Autowired
	GenericReportProcess genericReportProcess;
	
	int currentRecordCount;
	
	final int MaximumRecordCount = 500;

	public int getCurrentRecordCount() {
		return currentRecordCount;
	}

	public void setCurrentRecordCount(int currentRecordCount) {
		this.currentRecordCount = currentRecordCount;
	}

	@RequestMapping(value = "/initializereport.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String getReportsNameList(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		log.debug("Entering into getReportsNameList()..");

		String result = "c3par.reports.genericreports";

		String packageName = request.getParameter("type");

		log.debug("The packageName: " + packageName);

		String remoteUser = request.getHeader("SM_USER");

		List<GenericReport> genericReportList = genericReportProcess
				.getGenericReportList(packageName, remoteUser);

		genericReportProcess.setReportList(genericReportList);

		List<String> genericReportNameList = new ArrayList<String>();

		HashMap<String, String> nameIdMap = new HashMap<String, String>();

		for (GenericReport reportObj : genericReportList) {

			genericReportNameList.add(reportObj.getName());

			nameIdMap.put(reportObj.getName(), reportObj.getId());
		}

		request.getSession().setAttribute("nameIdMap", nameIdMap);

		log.debug("The ReportNameList: " + genericReportNameList);

		log.debug("The nameIdMap: " + nameIdMap);

		genericReportProcess.setReportNameList(genericReportNameList);

		model.addAttribute("ReportProcess", genericReportProcess);

		model.addAttribute("reportNameList",
				genericReportProcess.getReportNameList());

		log.debug("Exit from getReportsNameList()..");

		return result;
	}

	@RequestMapping(value = "/populatereport.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String getReportDetails(ModelMap model, HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute GenericReportProcess genericReportProcess)
			throws Exception {
		log.debug("Entering into getReportDetails()...");

		String result = "/pages/jsp/Reports/reportsDetail";

		String selectedReportName = request.getParameter("selectedeReportName");
		
		if(null == selectedReportName){
			
			selectedReportName = request.getSession().getAttribute("selectedReportName").toString();
		}

		log.debug("The Selected Report Name: " + selectedReportName);

		request.getSession().setAttribute("selectedReportName",
				selectedReportName);

		@SuppressWarnings("unchecked")
		String selectedReportId = ((HashMap<String, String>) request.getSession().getAttribute(
				"nameIdMap")).get(selectedReportName).toString();

		log.debug("The Selected ReportId: " + selectedReportId);

		List<String> reportColumNameList = null;

		// Getting the report column names from DB
		if (!"".equals(selectedReportId)) {
			reportColumNameList = this.getGenericReportProcess()
					.getReportColumnNames(Long.parseLong(selectedReportId));
		} else {
			log.debug("The selected report id is not valid.");
		}

		model.addAttribute("reportColumNameList", reportColumNameList);

		// Getting the report data from DB
		List<Object[]> reportDataList = this.getGenericReportProcess()
				.getReportData(Long.parseLong(selectedReportId));

		log.debug("reportDataList.size() : " + reportDataList.size());
		
		boolean isNextVisible = false; boolean isPreviousVisible = false;

		List<List<Object>> dataList = new ArrayList<List<Object>>();		

		for (Object[] obj : reportDataList) {
			
			List<Object> tempList = new ArrayList<Object>();
			
			for(int i=0; i< obj.length; i++){
				//first two elements are not required.
				if(i > 1){
					tempList.add(obj[i]);
				}
			}			

			//log.debug("tempList: " + tempList);

			dataList.add(tempList);
		}
		
		
		String type = request.getParameter("type");
		
		log.debug("type:"+type);
		
		if("next".equalsIgnoreCase(type)){
			
			dataList = this.getPageList(dataList, "next");
			
			if(reportDataList.size() > this.getCurrentRecordCount()){
				
				isNextVisible = true;
			}
			
			isPreviousVisible = true;
			
		} else if("previous".equalsIgnoreCase(type)){
			
			dataList = this.getPageList(dataList,"previous");
			
			isPreviousVisible = false;
			
			if(this.getCurrentRecordCount() > 0){
				
				isPreviousVisible = true;
			}
			
			isNextVisible = true;
			
		} else {
			
			dataList = this.getPageList(dataList, "");
			isPreviousVisible = false;
			
			if(reportDataList.size() > this.MaximumRecordCount){
				
				isNextVisible = true;
			}
		}

		model.addAttribute("isNextVisible", isNextVisible);
		
		model.addAttribute("isPreviousVisible", isPreviousVisible);

		log.debug("dataList.size() : " + dataList.size());

		model.addAttribute("reportDataList", dataList);

		model.addAttribute("selectedReportName", selectedReportName);

		request.setAttribute("reportDataList", dataList);

		log.debug("Exit from getReportDetails()..");

		return result;

	}

	private ArrayList<List<Object>> getPageList(List<List<Object>> fullList, String type) {					

		ArrayList<List<Object>> list = null;
		
		list = new ArrayList<List<Object>>();
		
		int count = 1;
		
		int recordCount =0;	
		
		int totalRecordCount = fullList.size();
		
		if("previous".equalsIgnoreCase(type)){
			
			recordCount= this.getCurrentRecordCount()/MaximumRecordCount-1;
			recordCount = recordCount*MaximumRecordCount;
			this.setCurrentRecordCount(recordCount);
			
					
		} if("next".equalsIgnoreCase(type)){
			
			recordCount= this.getCurrentRecordCount();
		}
		
		log.debug("The Record Count: "+recordCount);

		while (count <= MaximumRecordCount && recordCount < totalRecordCount) {

			list.add(fullList.get(recordCount));
			
			recordCount++;
			
			count++;
		}
		
		if(! "previous".equalsIgnoreCase(type)){
		this.setCurrentRecordCount(recordCount);
		}

		return list;
	}

	@RequestMapping(value = "/exportreport.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView exportReport(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute GenericReportProcess genericReportProcess)
			throws Exception {
		log.debug("Entering into exportReport()...");

		String selectedReportName = (String) request.getSession().getAttribute(
				"selectedReportName");

		log.debug("report name selected...: " + selectedReportName);

		List<String> reportNameList = new ArrayList<String>();
		reportNameList.add(selectedReportName);

		//String result = "c3par.reports.genericreportsdetail";

		@SuppressWarnings("unchecked")
		String selectedReportId = ((HashMap<String, String>) request.getSession().getAttribute(
				"nameIdMap")).get(selectedReportName).toString();

		log.debug("The Selected ReportId: " + selectedReportId);

		List<String> reportColumNameList = null;

		// Getting the report column names from DB
		if (!"".equals(selectedReportId)) {
			reportColumNameList = this.getGenericReportProcess()
					.getReportColumnNames(Long.parseLong(selectedReportId));
		} else {
			log.debug("The selected report id is not valid.");
		}

		// Getting the report data from DB
		List<Object[]> reportDataList = this.getGenericReportProcess()
				.getReportData(Long.parseLong(selectedReportId));

		log.debug("reportDataList.size() : " + reportDataList.size());

		List<List<Object>> dataList = new ArrayList<List<Object>>();

		for (Object[] obj : reportDataList) {
			
			List<Object> tempList = new ArrayList<Object>();
			
			for(int i=0; i< obj.length; i++){
				//First two elements are not required.
				if(i > 1){
					tempList.add(obj[i]);
				}
			}			

			//log.debug("tempList: " + tempList);

			dataList.add(tempList);
		}	

		log.debug("dataList.size() : " + dataList.size());

		Map<String, List> resultMap = new HashMap<String, List>();

		resultMap.put("reportColumNameList", reportColumNameList);
		resultMap.put("dataList", dataList);
		resultMap.put("reportName", reportNameList);

		log.debug("ResultMap Size: " + resultMap.size());

		log.debug("Exit from exportReport()..");

		return new ModelAndView("GenericReportExcel", "resultMap", resultMap);
	}

	public GenericReportProcess getGenericReportProcess() {
		return genericReportProcess;
	}

	public void setGenericReportProcess(
			GenericReportProcess genericReportProcess) {
		this.genericReportProcess = genericReportProcess;
	}

}
