package com.citigroup.cgti.c3par.webtier.helper ;


/**
 * The Interface RelationshipConnectionStatusNames.
 */
public interface RelationshipConnectionStatusNames {

    /** The Constant PENDING. */
    public static final String PENDING 		= "Pending" ;

    /** The Constant ACTIVE. */
    public static final String ACTIVE 		= "Active" ;

    /** The Constant IN_ACTIVE. */
    public static final String IN_ACTIVE 	= "In Active" ;

    /** The Constant REJECTED. */
    public static final String REJECTED 	= "Rejected" ;

    /** The Constant TERMINATED. */
    public static final String TERMINATED 	= "Terminated" ;
}