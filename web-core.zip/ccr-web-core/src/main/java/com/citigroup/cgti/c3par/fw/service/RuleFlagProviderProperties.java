package com.citigroup.cgti.c3par.fw.service;



public class RuleFlagProviderProperties {
	
	
	private String ruleproviderflag;

	public String getRuleproviderflag() {
		return ruleproviderflag;
	}

	public void setRuleproviderflag(String ruleproviderflag) {
		this.ruleproviderflag = ruleproviderflag;
	}
	
	
	

}
