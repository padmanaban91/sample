package com.citigroup.cgti.c3par.controller.submitActivity;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

/*
 * @nc43495
 */
@Controller
public class UATReqValSubmitController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(UATReqValSubmitController.class);
	Util util=new Util();
	
	@Autowired
	WsPapiFacade papiFacade;
	
	@Autowired
	WorkflowUtil workflowUtil;

	@RequestMapping(value = "/loadUATReqValSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(ModelMap model,@ModelAttribute("uatReqVal") SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session){
		log.info("UAT Request Validation Submit Controller load method starts here...");
		
		String tiReq = (String)session.getAttribute("tireqid");
		String actId = (String)session.getAttribute("activityid");
		
		Long tiReqId = Long.valueOf(0);
		Long activityId = Long.valueOf(0);
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		if(actId!=null){
		    try{activityId=Long.valueOf(actId);}catch(Exception e){activityId = Long.valueOf(0);}
		}
		log.debug("tiReq:"+tiReq+"ActivityId"+activityId);
		

		String taskId = (String) session.getAttribute("taskId");
		if(StringUtil.isNullorEmpty(actId)){
			activityId = workflowUtil.getAuditTrailId(activityId, taskId);
		}
		submitActivityProcess = new SubmitActivityProcess();
		
		//supplementary review roles display
		HashMap<String,String> roles = submitActivityProcess.findInstanceId(tiReqId, activityId);
		submitActivityProcess.setRoles(roles);
		List<LookUpVO> supReviewRole = submitActivityProcess.getSupReviewRoles((String)roles.get("ROLE"));
		log.debug("UAT Request Validation Submit Controller:"+supReviewRole.size());
		submitActivityProcess.setSupReviewRoles(supReviewRole);
		
		//set activity role
		submitActivityProcess.setActivityRole((String)roles.get("ROLE"));
		session.setAttribute("activityRole",submitActivityProcess.getActivityRole());
		log.debug("activity role:"+submitActivityProcess.getActivityRole());
		
		/*//setInstanceID
		String instanceId = (String)roles.get("INST_ID");
		session.setAttribute("instanceID", instanceId);
		log.debug("instanceId"+instanceId);*/
		
		// setTaskID
		log.debug("*********taskId************" + taskId);
		

		//Approval comments display
		String role = (String)roles.get("ROLE");
		submitActivityProcess.setTiReqCmtsList(submitActivityProcess.getComments(tiReqId, role, "A"));
		
		//Discussion comments display
		submitActivityProcess.setDiscussCmtsList(submitActivityProcess.getComments(tiReqId, role, "D"));
		
		model.addAttribute("uatReqVal", submitActivityProcess);
		
		return "c3par.uatReqValSubmit";
	}
	
	@RequestMapping(value = "/saveUATReqValSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String save(ModelMap model,@ModelAttribute("uatReqVal") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request) throws Exception{
	log.info("UAT Appsense Submit Controller:Save method starts here...");
	formSubmit(submitActivityProcess,result,session,request);
	return "forward:/logon.act?forwardTo=bpm";
		
	}
	
	
	@RequestMapping(value = "/submitUatReqValSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String submit(ModelMap model,@ModelAttribute("uatReqVal") SubmitActivityProcess submitActivityProcess,BindingResult result,
			HttpSession session,HttpServletRequest request){
	log.info("UAT Request Validation Submit Controller:Save method starts here...");
	
	try {
		formSubmit(submitActivityProcess,result,session,request);
		log.debug("UAT Request Validation Submit PAPI Enter ");
		
	//	WsPapiFacade papiFacade = new WsPapiFacade ();
		
		String taskId = (String)session.getAttribute("taskId");
		String userId  = request.getHeader("SM_USER");
		String nextSelectedAction = submitActivityProcess.getCurrentAction();
		
		log.debug("taskId: " + taskId +"action"+nextSelectedAction);
		log.debug("userId: " + userId);
		
		log.debug("Before calling PAPI For BJ Submit");
		
		String nextRole = null;

		if("REJECTED".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getRejectRole());
		}else if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			nextRole = util.moveToActivity(submitActivityProcess.getProvideInfoRole());
		}else {
			nextRole = util.moveToActivity(submitActivityProcess.getCurrentRole());
		}
		
		log.debug("Selected role:"+nextRole);
		
		if ("UNLOCKED".equals( nextSelectedAction ) || "COMPLETED".equals( nextSelectedAction ) ) {
			papiFacade.completeActivity(userId, taskId, nextSelectedAction); 
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("REJECTED".equalsIgnoreCase(nextSelectedAction)){
			log.debug("inside Rejected scenario..."+nextSelectedAction);
			papiFacade.completeActivity(userId, taskId, WsPapiFacade.ActivityStatus.REJECTED, WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		
		if("PROVIDEINFO".equalsIgnoreCase(nextSelectedAction)){
			papiFacade.completeActivity(userId, taskId, WsPapiFacade.ActivityStatus.PROVIDEINFO,WsPapiFacade.ActivityRejectedToRole.valueOf(nextRole));
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
	} catch (OperationException_Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return "forward:/defaultInboxView.act";
	}
	
	
	//data collection
    private void formSubmit(SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session,
			HttpServletRequest request)throws Exception{
    	log.debug("UAT Request Validation Submit Controller form Submit begins...");
    	String messgXML = (String)request.getSession().getAttribute("MESSAGEXML");
		log.info("messgXML::"+messgXML);
		
		String tiReq = (String)session.getAttribute("tireqid");
		
		submitActivityProcess.setActivityRole((String)session.getAttribute("activityRole"));
		log.debug("activity role inside form submit:"+submitActivityProcess.getActivityRole());
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );
		
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		
		//Getting request type
		TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
		
		if(submitActivityProcess.getCurrentAction()==null){
			submitActivityProcess.setCurrentAction(ActivityData.STATUS_COMPLETED);
		}
		
		if(submitActivityProcess.getCurrentRole()==null){
			submitActivityProcess.setCurrentRole(submitActivityProcess.getActivityRole());
		}

		log.info("Request Parameters::"+request.getParameterNames());
		log.info("Request current role="+request.getParameter("currentRole"));
		log.info("current action =" + submitActivityProcess.getCurrentAction());
		log.info("current role=" + submitActivityProcess.getCurrentRole());
		log.info("comments = " + submitActivityProcess.getComments());
		

		String ssoID = request.getHeader("SM_USER");
		
		TiRequestComments tiReqComments = new TiRequestComments();
		tiReqComments.setTiRequest(tiRequest);
		tiReqComments.setComments(submitActivityProcess.getComments());
		tiReqComments.setRoleName(submitActivityProcess.getActivityRole());
		tiReqComments.setApproverSoeID(ssoID);
		
		
		
		//updating tiRequest comments
		if(!"PROVIDEINFO".equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
			submitActivityProcess.addComments(tiReqComments, "A", "save");
		}else {
			submitActivityProcess.addComments(tiReqComments, "D", "save");
		}
			
    }
}
