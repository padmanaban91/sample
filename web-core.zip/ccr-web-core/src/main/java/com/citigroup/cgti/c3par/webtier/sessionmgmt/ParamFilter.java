package com.citigroup.cgti.c3par.webtier.sessionmgmt;


/*
 * Struts 1 Fix for CVE2014-0114
 * Targeted to Servlet v2.3 (Struts 1.3.x)
 * Note: Servlet v2.2 does not support Filters
 * Note: Servlet v3.0 is used in Struts 2
 * 
 * Configure the location of your error page in web.xml with parameter 'errorPage'
 * Configure location of temp folder to write uploaded files to within web.xml's parameter 'filleUploadTempRepository'
 * You will need to log the request when an invalid String is found according to how your app is performing logging
 */

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class ParamFilter implements Filter {
	
 private String excludeParams;
 private String unicodePattern;
 private String octalPattern;
 private String errorPage;
 private Pattern classLoaderPattern;
 private Pattern unicodeCompiledPattern;
 private Pattern octalCompiledPattern;
 private String fileUploadTempRepository;
 //public static final String DEFAULT_COMMAND_PATTERN = "(.*\.|^|.*|\[('|" + '))(c|C)lass(\\.|('+"'"+'|")]|\[).*';
 public static final String DEFAULT_COMMAND_PATTERN = "(.*\\.|^|.*|\\[('|\"))(c|C)lass(\\.|('|\")]|\\[).*";
 
 private static Logger log = Logger.getLogger(ParamFilter.class);
 	
 
public void init(FilterConfig config) throws ServletException {
	
	//excludeParams = config.getInitParameter("excludeParams");
	//unicodePattern = config.getInitParameter("unicodePattern");
	//octalPattern = config.getInitParameter("octalPattern");
	
	classLoaderPattern = Pattern.compile(DEFAULT_COMMAND_PATTERN, Pattern.CASE_INSENSITIVE|Pattern.DOTALL);
	unicodeCompiledPattern = Pattern.compile("\\\\u([A-Fa-f0-9]{4})");
	octalCompiledPattern = Pattern.compile("\\\\([0-7]{1,4})");
	errorPage = config.getInitParameter("errorPage");
	fileUploadTempRepository = config.getInitParameter("fileUploadTempRepository");
	
}

public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {		// check the request type
	
//	log.debug("doFilter in ParamFilter Starts");
	
	if (req instanceof HttpServletRequest) {
			HttpServletRequest request = (HttpServletRequest) req;
			HttpServletResponse response = (HttpServletResponse) res;
			
			boolean isParameterValid = true;
			boolean isCookieValid = true;
			
			//request.setCharacterEncoding("UTF-8");
			
			//Check if it is a multi-part post 
			if (request.getContentType()!=null && request.getContentType().toUpperCase().startsWith(("MULTIPART"))) {
				//Get the multi-part post 
				try {
					request = new MultiReadHttpServletRequest(request);
					isParameterValid = validateMultiPart((MultiReadHttpServletRequest) request);
				} catch (FileUploadException fue) {
					log.error(fue,fue);
				}
			} else {
				// normal request, handle with parameter map
				if (request.getParameterMap() != null) {
					isParameterValid = validateParameter(request.getParameterMap()); 
				} 
			}
			
			//Get the cookie values (checks name and value) - do this only if the parameter check was successful
			if (isParameterValid && request.getCookies() != null) {
				Cookie[] cookies = request.getCookies();
				isCookieValid = validateCookies(cookies);
			} else {
				isCookieValid = true;
			}
			
			// Customize this if you want to handle it according to your app's error handling paradigm.
			if (!isParameterValid || !isCookieValid) {
				// [TODO: Customize by logging the attempt here. Depends on how your app logs]
				response.reset();
				response.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
				response.sendRedirect(request.getContextPath()+errorPage);
				request.getSession().invalidate();
				return;	
			} else {
				// no problems with request, continue the chain
				chain.doFilter(request, response);
			}
		} else {
			// not an HTTP request
			chain.doFilter(req, res);
		}
	//log.debug("doFilter in ParamFilter Ends");
}

private boolean validateMultiPart(MultiReadHttpServletRequest request) throws UnsupportedEncodingException, FileUploadException {
	//log.debug("validateMultiPart in ParamFilter Starts");
	DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
	fileItemFactory.setRepository(new File(fileUploadTempRepository));
	ServletFileUpload upload = new ServletFileUpload(fileItemFactory);
	boolean isMpParamValid = true;
	
	List items = upload.parseRequest(request);
	Iterator it = items.iterator();
	while (it.hasNext()) {
		FileItem item = (FileItem) it.next();
		if (item.isFormField()) {
			// this is a form field
			Matcher matcher = classLoaderPattern.matcher(decode(item.getFieldName())); //name of form field
			if (matcher.find()) {
				isMpParamValid = false;
				break;
			}else{
				matcher.reset();
			}

			matcher = classLoaderPattern.matcher(decode(item.getString())); //name of form value
			if (matcher.find()) {
				isMpParamValid = false;
				break;
			}else{
				matcher.reset();
			}
			
		} else {	
			// this is a file we are looking at
			Matcher matcher = classLoaderPattern.matcher(decode(item.getFieldName())); //name of form field
			if (matcher.find()) {
				isMpParamValid = false;
				break;
			}else{
				matcher.reset();
			}
			matcher = classLoaderPattern.matcher(decode(item.getName())); //filename
			if (matcher.find()) {
				isMpParamValid = false;
				break;
			}
			matcher.reset();
		}
    }
	//log.debug("validateMultiPart in ParamFilter Ends");
	return isMpParamValid;

}

/**
 * Returns boolean indicating whether the cookies are valid.
 */
private boolean validateCookies(Cookie[] cookies) {
	//log.debug("validateCookies in ParamFilter Starts");
	boolean isCookieValid = true;
	for (int i = 0; i < cookies.length; i++) {
		String name = cookies[i].getName();
		String value = cookies[i].getValue();
		Matcher matcher = classLoaderPattern.matcher(decode(name));
		if (matcher.find()) {
			isCookieValid = false;
			break;
		}else{
		matcher.reset();
		}
		matcher = classLoaderPattern.matcher(decode(value));
		if (matcher.find()) {
			isCookieValid = false;
			break;
		}else{
			matcher.reset();
		}
		matcher.reset();
	}
	//log.debug("validateCookies in ParamFilter Ends");
	return isCookieValid;
}

/**
 * Returns boolean indicating whether the request parameters are valid.
 */
private boolean validateParameter(Map map) {
	//log.debug("validateParameter in ParamFilter Starts");
	boolean isParamValid = true;
	Iterator entries = map.entrySet().iterator();
	while (entries.hasNext()) {
		Entry thisEntry = (Entry) entries.next();
		String paramName = (String) thisEntry.getKey();
		String[] paramValues = (String[]) thisEntry.getValue();
		Matcher matcher = classLoaderPattern.matcher(decode(paramName));
		if (matcher.find()) {
			isParamValid = false;
			break;			
		}else{
			matcher.reset();
		}
		
		for (int i = 0; i < paramValues.length; i++) {
			matcher = classLoaderPattern.matcher(decode(paramValues[i]));
			if (matcher.find()) {
				isParamValid = false;
				break;
			}else{
				matcher.reset();
		    }
		matcher.reset();
	}
 }
	//log.debug("validateParameter in ParamFilter Ends");
	return isParamValid;
}
private String decode(String input) {
	//log.debug("decode in ParamFilter Starts");
	String result = null;
	
	if (input == null)
		return null;
	
	// URL decoding
	String urlDecode = null;
	try {
		urlDecode = URLDecoder.decode(input);
	}
	catch (Exception ex) {
		urlDecode = input;
	}
	result = urlDecode;
	//System.out.println("URL decoding result: " + result);
	
	try {
		String temp = null;
		// decode unicode
		Matcher m1 = unicodeCompiledPattern.matcher(result);      
		StringBuffer b1 = new StringBuffer();
		while (m1.find())
		{
			temp = String.valueOf(((char)Integer.parseInt(m1.group(1), 16)));
			m1.appendReplacement(b1, convertDollarOrBackslash(temp));
		}
		m1.appendTail(b1);
		result = b1.toString();
		//System.out.println("Unicode decoding result: " + result);
		//debugLog("Unicode decoding result: " + result);
				
		// decode hex code
		/*Matcher m2 = hexPattern.matcher(result);
		StringBuffer b2 = new StringBuffer();
		while (m2.find())
		{
			temp = String.valueOf(((char)Integer.parseInt(m2.group(1), 16)));
			m2.appendReplacement(b2, convertDollarOrBackslash(temp));
		}
		m2.appendTail(b2);
		result = b2.toString();
		debugLog("Hex decoding result: " + result);
		*/
		// decode octal code	
		Matcher m3 = octalCompiledPattern.matcher(result);
		StringBuffer b3 = new StringBuffer();
		while (m3.find())
		{
			temp = String.valueOf(((char)Integer.parseInt(m3.group(1), 8)));
			m3.appendReplacement(b3, convertDollarOrBackslash(temp));
		}
		m3.appendTail(b3);
		result = b3.toString();
		//System.out.println("Octal decoding result: " + result);
		//debugLog("Octal decoding result: " + result);
		
	}
	catch (Throwable th) {
		log.error("Filter decoding result: " + result);
		//errorLog(th.getMessage());
	}
	//log.debug("decode in ParamFilter Ends");
	return result;
}

private String convertDollarOrBackslash(String input) {
	if ("\\".equals(input))
		return "\\\\";
	else if ("$".equals(input))
		return "\\$";
	else
		return input;
}

public void destroy() { }

}
