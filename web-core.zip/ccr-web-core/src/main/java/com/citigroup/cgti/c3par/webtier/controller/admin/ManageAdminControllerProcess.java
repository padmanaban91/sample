package com.citigroup.cgti.c3par.webtier.controller.admin;

import java.util.List;

import com.citigroup.cgti.c3par.common.domain.ISOContacts;

public class ManageAdminControllerProcess {
    
    
    
    private List<ISOContacts> isoContactList;
    
    private ISOContacts  isoContacts; 

    public List<ISOContacts> getIsoContactList() { 
        return isoContactList;
    }

    public void setIsoContactList(List<ISOContacts> isoContactList) {
        this.isoContactList = isoContactList;
    }

    public ISOContacts getIsoContacts() {
        return isoContacts;
    }

    public void setIsoContacts(ISOContacts isoContacts) {
        this.isoContacts = isoContacts;
    }
    
    
}
