package com.citigroup.cgti.c3par.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.citigroup.cgti.c3par.C3parThinSession;
import com.citigroup.cgti.c3par.dao.C3parUsersDAO;
import com.citigroup.cgti.c3par.dao.SecurityRoleDAO;
import com.citigroup.cgti.c3par.lookup.C3parUsersLookup;
//import com.citigroup.cgti.c3par.dao.lookup.ContainerGroupsLookup;
import com.citigroup.cgti.c3par.model.C3parUserRoleXrefEntity;
import com.citigroup.cgti.c3par.model.C3parUsersEntity;
//import com.citigroup.cgti.c3par.model.ContainerGroupsEntity;
import com.citigroup.cgti.c3par.model.SecurityRoleEntity;
import com.citigroup.cgti.c3par.webtier.helper.LookupsManager;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;
import com.mentisys.util.databaserealm.PasswordEncryption;
import com.mentisys.util.databaserealm.PasswordEncryptionException;
import org.apache.log4j.Logger;

//ENTITLEMENT CHANGE : USED INITIALLY TO ADD USERS THRU CMD ;NEW ENTITLEMENTS ARE NOT REFLECTED HERE
/**
 * The Class AddC3parUsers.
 */
public class AddC3parUsers
{

    /** The m_user id. */
    private String m_userId;

    /** The m_first name. */
    private String m_firstName;

    /** The m_last name. */
    private String m_lastName;

    /** The m_c3par role. */
    private String m_c3parRole;

    /** The m_group. */
    private String m_group;

    /** The m_is admin. */
    private boolean m_isAdmin;

    /** The log. */
    private static Logger log = Logger.getLogger(AddC3parUsers.class);

    /**
     * Instantiates a new adds the c3par users.
     *
     * @param userId the user id
     * @param c3parRole the c3par role
     * @param group the group
     * @param firstName the first name
     * @param lastName the last name
     * @param isAdmin the is admin
     */
    public AddC3parUsers(String userId, String c3parRole, String group,
	    String firstName, String lastName,
	    boolean isAdmin)
    {
	m_userId = userId;
	m_c3parRole = c3parRole;
	m_group = group;
	m_firstName = firstName;
	m_lastName = lastName;
	m_isAdmin = isAdmin;
    }

    /**
     * Adds the user.
     *
     * @throws Exception the exception
     */
    public void AddUser()
    throws Exception
    {
	try
	{
	    C3parUsersEntity c3parUsersEntity = new C3parUsersEntity();
	    c3parUsersEntity.setFirstName(m_firstName.trim());
	    c3parUsersEntity.setLastName(m_lastName.trim());
	    c3parUsersEntity.setSsoId(m_userId.trim().toLowerCase());
	    String password = m_userId.toLowerCase() + "!!";
	    password = PasswordEncryption.getInstance().encrypt(password);
	    c3parUsersEntity.setPassword(password);
	    c3parUsersEntity.setIsActive("Y");
	    c3parUsersEntity.setIsAdmin(Boolean.valueOf(m_isAdmin));
	    LookupsManager.resetRoleLookup(new C3parThinSession());
	    SecurityRoleEntity securityRoleEntity = null;
	    Condition condition = new Condition();
	    OperatorExpression roleIdExp =
		new OperatorExpression(SecurityRoleDAO.COLUMN_NAME, Operator.EQUAL, m_c3parRole.trim());
	    condition.addExpression(roleIdExp);

	    SecurityRoleDAO securityRoledao = new SecurityRoleDAO(new C3parThinSession());
	    List list = securityRoledao.query(condition, false);
	    Iterator it = list.iterator();
	    while(it.hasNext())
	    {
		securityRoleEntity = (SecurityRoleEntity) it.next();
		break;
	    }
	    log.debug("The group name is : " + m_group);
	    /* ENTITLEMENT CHNAGE COMMENT FROM LINE 78-109*/
	    /*ContainerGroupsLookup.getInstance().initialize(new C3parThinSession());
			ContainerGroupsEntity groupEntity = ContainerGroupsLookup.getInstance().getByName(m_group.trim());

			if(securityRoleEntity != null && groupEntity != null)
			{
				C3parUserRoleXrefEntity xrefEntity = new C3parUserRoleXrefEntity();
				xrefEntity.setRole(securityRoleEntity);
				xrefEntity.setUser(c3parUsersEntity);

				c3parUsersEntity.getRole().add(xrefEntity);

				c3parUsersEntity.setGroup(groupEntity);
				C3parThinSession c3parSession = new C3parThinSession();
				C3parUsersDAO dao = new C3parUsersDAO(c3parSession);
				try
				{
					dao.update(c3parUsersEntity);
					LookupsManager.resetC3parUserLookup(new C3parThinSession());
				}
				catch(DatabaseException ex)
				{

					c3parSession.rollback();
					throw ex;
				}
				finally
				{
					if(c3parSession != null) c3parSession.releaseConnection();
				}
			}
			else
				log.debug("The role given is not valid or the group is not valid!!!."); */

	}
	catch(PasswordEncryptionException ex)
	{
	    log.error(ex);
	}
    }

    /**
     * The main method.
     *
     * @param args the arguments
     * @throws Exception the exception
     */
    public static void main(String args[])
    throws Exception
    {
	if(args.length != 1)
	{
	    log.debug("The usage is AddC3parUsers <file>");
	    System.exit(1);
	}

	String userId;
	String c3parRole;
	String group;
	String firstName;
	String lastName;
	String isAdmin;

	String fileName = args[0];
	BufferedReader reader = new BufferedReader(new FileReader(fileName));
	//	C3parUsersLookup.getInstance().initialize(new C3parThinSession());

	while(true)
	{
	    String line = reader.readLine();
	    if(line != null)
	    {
		StringTokenizer token = new StringTokenizer(line, ",");
		userId = token.nextToken();
		c3parRole = token.nextToken();
		group = token.nextToken();
		firstName = token.nextToken();
		lastName = token.nextToken();
		isAdmin = token.nextToken();
		if(userId == null || c3parRole == null || group == null || firstName == null || lastName ==  null || isAdmin == null)
		{
		    log.debug("The user file should be of the format <ssoid>,<role>,<group>,<firstName>,<lastName>,<isAdmin>");
		    System.exit(1);
		}
		C3parUsersEntity entity = C3parUsersLookup.getInstance().getBySsoId(userId.trim().toLowerCase());
		if(entity == null)
		{
		    AddC3parUsers addC3parUsers =
			new AddC3parUsers(userId.toLowerCase(), c3parRole, group, firstName, lastName,	Boolean.valueOf(isAdmin).booleanValue());
		    addC3parUsers.AddUser();
		}
		else
		    log.debug("user with soe id : " + entity.getSsoId() + " already exists !!!");
	    }
	    else
		break;
	}

    }
}