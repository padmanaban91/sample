/**
 * 
 */
package com.citigroup.cgti.c3par.scheduler;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.context.ApplicationContext;

import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;

/**
 * @author ka58098
 *
 */
public class CSIApplicationSynchJob implements Job {
    private static Logger log = Logger.getLogger(CSIApplicationSynchJob.class);
    private ApplicationContext appContext = null;
  
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.info("Start job ::");
        appContext = CCRApplicationContextUtils.getApplicationContext();
        CSIApplicationSynchScheduler csiApplicationSynchScheduler = (CSIApplicationSynchScheduler) appContext.getBean("csiApplicationSynchScheduler");
        csiApplicationSynchScheduler.synchCSIApplication();
        log.info("End job ::");
    }
}
