package com.citigroup.cgti.c3par.controller.reports;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.reports.domain.RiskRatingReportProcess;

@Controller
public class FirewallApplicationsReportController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@RequestMapping(value = "/firewallAppReport", method = { RequestMethod.GET, RequestMethod.POST })
	public String firewallAppReport(ModelMap model, @ModelAttribute("riskratingProcess") RiskRatingReportProcess riskratingProcess){
		log.info("FirewallApplicationsController :: firewallAppReport method starts");
		if(riskratingProcess == null){
			riskratingProcess = new RiskRatingReportProcess();
		}
		if (riskratingProcess.getFirewallName() != null) {
			riskratingProcess.setFirewallReportList(riskratingProcess.getFirewallApplications(riskratingProcess.getFirewallName(), "N"));
		}
		model.addAttribute("riskratingProcess",riskratingProcess);
		return "c3par.reports.firewall.app";
	}
	
	@RequestMapping(value = "/firewallAppExport", method = { RequestMethod.GET, RequestMethod.POST })
	public String firewallAppExport(ModelMap model, @ModelAttribute("riskratingProcess") RiskRatingReportProcess riskratingProcess){
		log.info("FirewallApplicationsController :: firewallAppExport method starts");
		if(riskratingProcess == null){
			riskratingProcess = new RiskRatingReportProcess();
		}
		if (riskratingProcess.getFirewallName() != null) {
			riskratingProcess.setFirewallReportList(riskratingProcess.getFirewallApplications(riskratingProcess.getFirewallName(), "Y"));
		}
		model.addAttribute("riskratingProcess",riskratingProcess);
		return "pages/reports/FirewallAppReportExport";
	}

	}
