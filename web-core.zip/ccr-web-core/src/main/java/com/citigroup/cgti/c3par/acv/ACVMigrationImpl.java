package com.citigroup.cgti.c3par.acv;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade.CreateProcessActivity;

public class ACVMigrationImpl {
	
	protected Logger log = Logger.getLogger(this.getClass().getName());
	
	private ACVMigration acvMigration;
	
	public ACVMigration getAcvMigration() {
		return acvMigration;
	}

	public void setAcvMigration(ACVMigration acvMigration) {
		this.acvMigration = acvMigration;
	}

	public void completeExistingAcvs(String userId) throws InterruptedException
	{
		WsPapiFacade papiFacade = new WsPapiFacade ();
		
		
		
		log.info("fetching data from db started.."+new Date());
		
		log.info("acvMigration..."+acvMigration);
		
		//Get ACV Expiration Records + ACV Records from CCR database
		Map<String,List> map = acvMigration.getACVRecords(100,100);
		
		log.info("fetching data from db completed.."+new Date());
		
		Set<java.util.Map.Entry<String, List>> set =  map.entrySet();
		
		log.info("papi started.."+new Date());
		
		String instancePresent = null;
		Long processId= null;
		Long tiRequestId = null;
		String taskType =  null;
		String bpm_instance = null;		
		String papi_call = null;
		boolean isInstanceExists = false;
		
				
		for(java.util.Map.Entry<String, List> entry : set)
		{
			instancePresent = null;
			processId= Long.valueOf(entry.getKey());
			tiRequestId = Long.valueOf(entry.getValue().get(0)+"");
			taskType =  entry.getValue().get(1)+"";
			bpm_instance = entry.getValue().get(2)+"";			
			isInstanceExists = papiFacade.isInstanceExists(userId, bpm_instance);

			if(!isInstanceExists)
			{
				//Instance missing at BPM End.
				//Update current status as Trigger-ACV and make Active
				
				acvMigration.triggerACVForMissingInstances(Long.valueOf(entry.getKey()));
				acvMigration.updateACVStatusFlag(processId,tiRequestId,"P");
				instancePresent = "N";
				
			}else{
				
				//Call papiService and make Active if it is in ACV. If it is ACVExpiration, callPapi to move to ACV and then make Active
				//Update status as Trigger-ACV in ACV
				//Make ti_process acv expiration as less than today
				
				instancePresent = "Y";
				
				try {
					
					acvMigration.updateACVFlag(tiRequestId);
						
						if(taskType.equals("ver_sow"))
						{
							acvMigration.updateACVMigrationLog(processId,tiRequestId,"CompletingACV","STARTED",instancePresent);
							
							papi_call = "completeActivity PAPI";
							
							//PAPI call for completing ACV
							papiFacade.completeActivity(userId, bpm_instance, "COMPLETED");
							
							acvMigration.updateACVMigrationLog(processId,tiRequestId,"CompletingACV","COMPLETED",instancePresent);
							
							acvMigration.updateACVStatusFlag(processId,tiRequestId,"P");
							
							acvMigration.updateACVDate(processId);
							
						}else if(taskType.equals("acv_exp"))
						{
							acvMigration.updateACVMigrationLog(processId,tiRequestId,"CompletingACVExpiration","STARTED",instancePresent);
							
							papi_call = "completeACVExpiration PAPI";
							
							//PAPI call for completing expiration activity
							papiFacade.completeACVExpiration(userId, bpm_instance);
							
							acvMigration.updateACVStatusFlag(processId,tiRequestId,"A");
							
							acvMigration.updateACVMigrationLog(processId,tiRequestId,"CompletingACVExpiration","COMPLETED",instancePresent);

						}
					
				} catch (OperationException_Exception e) {
					
					acvMigration.updateACVMigrationLog(processId,tiRequestId,"Exception in "+papi_call,"Exception PAPI",instancePresent);
					log.error(e.getMessage());
					if(e.getMessage().indexOf("is not running")!=-1 && taskType.equals("acv_exp"))
					{
						acvMigration.triggerACVForMissingInstances(Long.valueOf(entry.getKey()));
						acvMigration.updateACVStatusFlag(processId,tiRequestId,"P");
						instancePresent = "N";
					}
				}
				
			}		
		}
	}
	
	public void completeAcvs(String userId) throws InterruptedException
	{
		String instancePresent = null;
		Long processId= null;
		Long tiRequestId = null;
		String bpm_instance = null;		
		String papi_call = null;
		
		WsPapiFacade papiFacade = new WsPapiFacade ();
		
		//Get ACV records which were completed Expiration in previous step
		Map<Long,Long> acvRecords = acvMigration.getACVRecordsAfterExpiration();
		
		if(acvRecords!=null && acvRecords.size()>0)
		{
			Thread.sleep(90000);
			Set<java.util.Map.Entry<Long, Long>> setACV =  acvRecords.entrySet();
			
			for(java.util.Map.Entry<Long, Long> recs : setACV)
			{
				instancePresent="Y";
				papi_call = "completeActivity PAPI";
				
				processId = recs.getKey();
				tiRequestId = recs.getValue();
				
				//Get latest bpmInstanceId for a connection
				bpm_instance = acvMigration.getLatestBpmInstanceId(processId);
				if(bpm_instance!=null)
				{
				
				try {
					//PAPI call for completing ACV
					papiFacade.completeActivity(userId, bpm_instance, "COMPLETED");
					acvMigration.updateACVMigrationLog(processId,tiRequestId,"CompletingACV","COMPLETED",instancePresent);
					acvMigration.updateACVStatusFlag(processId,tiRequestId,"P");
				} catch (OperationException_Exception e) {
					acvMigration.updateACVMigrationLog(processId,tiRequestId,"Exception in "+papi_call,"Exception PAPI",instancePresent);
					log.error(e.getMessage());
				}
				
				acvMigration.updateACVDate(processId);
				}
			}
		}
	}
	
	public void revertACVDates() throws InterruptedException
	{
		String instancePresent = null;
		Long processId= null;
		Long tiRequestId = null;
		
		//Revert back ACV dates
		Map<Long,Long> acvLatest =  acvMigration.getActiveACVRecords();
		
		if(acvLatest!=null && acvLatest.size()>0)
		{
//			Thread.sleep(15000);			
			Set<java.util.Map.Entry<Long, Long>> setACVLatest =  acvLatest.entrySet();
			
			for(java.util.Map.Entry<Long, Long> recs : setACVLatest)
			{
//				Thread.sleep(3500);
				processId = recs.getKey();
				tiRequestId = recs.getValue();
				acvMigration.updateACVDatesCorrectly(processId);
				acvMigration.updateACVStatusFlag(processId,tiRequestId,"C");
				acvMigration.updateAuditForACV(tiRequestId);
				acvMigration.updateACVMigrationLog(processId,tiRequestId,"ACVDatesReverted","COMPLETED",instancePresent);
			}
		}
	}
	
	
	public void moveACVsToNewVersion() throws InterruptedException
	{
		String instancePresent = null;
		Long processId= null;
		Long tiRequestId = null;
		
		//Revert back ACV dates
		Map<Long,Long> acvLatest =  acvMigration.getValidConnectionsForACV();
		
		if(acvLatest!=null && acvLatest.size()>0)
		{
//			Thread.sleep(15000);			
			Set<java.util.Map.Entry<Long, Long>> setACVLatest =  acvLatest.entrySet();
			
			for(java.util.Map.Entry<Long, Long> recs : setACVLatest)
			{
//				Thread.sleep(3500);
				processId = recs.getKey();
				tiRequestId = recs.getValue();
				acvMigration.updateACVDatesCorrectly(processId);
				acvMigration.updateACVStatusFlag(processId,tiRequestId,"C");
				acvMigration.updateAuditForACV(tiRequestId);
				acvMigration.updateACVMigrationLog(processId,tiRequestId,"ACVDatesReverted","COMPLETED",instancePresent);
			}
		}
	}
	
	
	public void markACVsComplete(String userId,int maxACV, int maxACVExp) throws InterruptedException
	{
		WsPapiFacade papiFacade = new WsPapiFacade ();
		
		log.info("fetching data from db started.."+new Date());
		
		//Get ACV Expiration Records + ACV Records from CCR database
		Map<String,List> map = acvMigration.getACVRecords(maxACV, maxACVExp);
		
		log.info("fetching data from db completed.."+new Date());
		
		Set<java.util.Map.Entry<String, List>> set =  map.entrySet();
		
		log.info("papi started.."+new Date());
		
		Long processId= null;
		Long tiRequestId = null;
		SortedSet<Long> li  = new TreeSet<Long>();
		List<Long> temp_list = new ArrayList<Long>();
		List<Long> temp_list2 = new ArrayList<Long>();
		
		int counter = 0;
		
		for(java.util.Map.Entry<String, List> entry : set)
		{
			counter=counter+1;
			processId= Long.valueOf(entry.getKey());
			temp_list.add(processId);
			temp_list2.add(processId);
			
			if(!temp_list2.removeAll(temp_list.subList(0, (temp_list.size()>2?temp_list.size()-2:temp_list.size()-1))))
			{
				log.info(counter+":-"+processId);
				tiRequestId = Long.valueOf(entry.getValue().get(0)+"");
				//Update current status as Trigger-ACV and make Active
				acvMigration.triggerACVForMissingInstances(Long.valueOf(entry.getKey()));
				acvMigration.updateACVStatusFlag(processId,tiRequestId,"P");
				try {
					papiFacade.callCreateProcessForACV(userId, "ACV", processId, WsPapiFacade.CreateProcessActivityForACV.FWACVProcess);
//					Thread.sleep(1500);
				} catch (OperationException_Exception e) {
					acvMigration.updateACVMigrationLog(processId,tiRequestId,"Exception in Creating ACV","Exception PAPI","N");
					e.printStackTrace();
				}
			}
			temp_list2 = new ArrayList<Long>();
		}
	}
	
	
	
	public void processAcvs(String userId,int maxACV, int maxACVExp) throws InterruptedException
	{
		
		WsPapiFacade papiFacade = new WsPapiFacade ();
		 markACVsComplete(userId,maxACV,maxACVExp);
		
//		Set<Long> connectionIds = acvMigration.getIdsForACV();
		/*
		log.info("Total connections moving to new ACV phase.."+connectionIds.size());
		try {
			papiFacade.callCreateProcessForACV(userId, "ACV", connectionIds, WsPapiFacade.CreateProcessActivityForACV.FWACVProcess);
		} catch (OperationException_Exception e) {
			e.printStackTrace();
		}*/
//		completeExistingAcvs(userId);
//		completeAcvs(userId);
		
//		Thread.sleep(90000);
		
//		revertACVDates();
		
		//PAPI call to Run ACV job for creating newer version of ACV		
		/*try {
			papiFacade.callCreateProcess(userId, null, CreateProcessActivity.FWACVRun);
		} catch (OperationException_Exception e) {		
			log.error(e.getMessage());
		}*/
	}

}
