/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright  2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.webtier.sessionmgmt;

//import java.io.IOException;
import java.util.Map;

import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * 
 * This implements the CorruptSessionResponseHandler interface. The implementation uses
 * the request servlet path to identify the response.
 * 
 * @author pkadam
 *
 */
public class DefaultCorruptSessionResponseHandler implements CorruptSessionResponseHandler {

    /** The action to response map. */
    private final Map actionToResponseMap ;

    /**
     * This creates an instance using the servlet path to response map information.
     *
     * @param responseMap the response map
     */
    public DefaultCorruptSessionResponseHandler (Map responseMap) {
	this.actionToResponseMap = responseMap ;
    }

    /**
     * This returns a boolean indicating whether the request was successfully handled.
     * A true value indicates successful handling.
     * 
     * The method uses the request object to get the servlet path (i.e. the struts action)
     * and identifies the response to be generated from the configured responseMap in this
     * instance. It gets a request dispatcher for the response url and forwards the request.
     * 
     * Any exception during this operation is unsuccessful handling and false is returned.
     *
     * @param request the request
     * @param response the response
     * @return true, if successful
     */
    public boolean handle(HttpServletRequest request, HttpServletResponse response) {
	boolean handled = false ;

	try {
	    String servletPath = request.getServletPath();
	    String responseURL = (String) actionToResponseMap.get(servletPath);

	    RequestDispatcher dispatcher = request.getRequestDispatcher(responseURL);

	    dispatcher.forward(request, response);

	    handled = true ;
	} catch (Exception e) {
	    e.printStackTrace();
	}

	return handled ;
    }
}
