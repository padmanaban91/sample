package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;
import java.util.List;

import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;

public class ProjectCoordinatorRejectAction extends MailAction {

Logger log = Logger.getLogger(ProjectCoordinatorRejectAction.class);
	
private final static String ROLE_NAME = "PROJECT COORDINATOR";
	@Override
	public void process(IncomingMessage message) {
		
		log.info("Inside ProjectCoordinatorRejectAction process method ");
		
		super.processReject(message,ROLE_NAME);
	}
	
}
