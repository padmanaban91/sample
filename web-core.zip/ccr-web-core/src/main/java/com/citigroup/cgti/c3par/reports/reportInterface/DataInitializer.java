/*
 * Created on May 27, 2005
 *
 *  
 */
package com.citigroup.cgti.c3par.reports.reportInterface;

import com.citigroup.cgti.c3par.reports.model.DataSourceEntity;
import com.citigroup.cgti.c3par.reports.model.ReportMetaEntity;



/**
 * The Interface DataInitializer.
 *
 * @author Gerald Robinson
 * </br>
 * <h1>Description</h1>
 * This interface provides methods to initialize the data necessary to present a report.
 */
public interface DataInitializer {

    /**
     * This method initializes the data necessary for a report. It is expected that
     * the client should call this method atleast once before any request for data is
     * made.
     *
     * @throws ReportException the report exception
     */
    public void intialize() throws ReportException;

    /**
     * This method returns the DataSourceEntity instance for this DataInitializer.
     *
     * @return the data source entity
     */
    public DataSourceEntity getDataSourceEntity();


    /**
     * Gets the report meta entity.
     *
     * @return the report meta entity
     */
    public ReportMetaEntity getReportMetaEntity();

}
