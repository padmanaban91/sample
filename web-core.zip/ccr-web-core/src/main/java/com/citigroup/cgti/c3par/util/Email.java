/*
 * Created on Jul 24, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.util;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;



/**
 * The Class Email.
 *
 * @author gr61093
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Email {

    /*	private static Logger log = Logger.getLogger(Email.class.getName());

		public static void send(String smtpServer, String to, String from
				, String subject, String body){
			try
			{
			      Properties props = System.getProperties();
			      props.put("mail.smtp.host", smtpServer);
				  Session session = Session.getDefaultInstance(props, null);
				  Message msg = new MimeMessage(session);
				  msg.setFrom(new InternetAddress(from));
				  msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to, false));
				  msg.setSubject(subject);
				  msg.setText(body);
				  msg.setSentDate(new Date());
				  Transport.send(msg);
				  log.info("Message sent OK.");
			}
		    catch (Exception ex)
		    {
		      log.error("Error while sending email");
		      log.error(ex,ex);
		    }
		} */
}

