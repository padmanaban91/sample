package com.citigroup.cgti.c3par.mailmodule.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.lob.LobHandler;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;

public abstract class MailAction {
	private Logger log = Logger.getLogger(MailAction.class);
	private JdbcTemplate jdbcTemplate;
	public LobHandler lobHandler;
	
	private IMailModule mailModuleImpl;
	
	public static final String TECHNICAL_ARCHITECTURE = "tec_arc";
	public static final String BUSINESS_JUSTIFICATION = "bus_jus";
	private static final String  OTRMDLGROUP = "dl.otrm.us.ccr@imcnam.ssmb.com";
	private static final String  SYSTEMADMIN = "System Admin ";
	
	private static final String DESIGNENGINEER = "DESIGN ENGINEER";
	private static final String PROJECTCOORDINATOR = "PROJECT COORDINATOR";
	private static final String C3PARSYSTEMADMIN = "C3PARSYSTEMADMIN";
	private static final String BISO = "BISO";
	private static final String SUCCESS = "Successful";
	private static final String FAILURE = "Failed";
	private static final String ACTION = "Responsibility Rejection";
	private static final String Y = "Y";
	private static final String N = "N";
	  	
	public void setMailModuleImpl(IMailModule mailModuleImpl) {
		this.mailModuleImpl = mailModuleImpl;
	}
	
	public IMailModule getMailModuleImpl() {
		return mailModuleImpl;
	}
	
	public LobHandler getLobHandler() {
		return lobHandler;
	}
	
	public void setLobHandler(LobHandler lobHandler) {
		this.lobHandler = lobHandler;
	}
		
	/**
	 * @return the jdbcTemplate
	 */
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	/**
	 * @param jdbcTemplate the jdbcTemplate to set
	 */
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
		
	public abstract void process(IncomingMessage message);
		
	/**
	 * 
	 * @param comments
	 * @param tiRequestId
	 * @param roleName
	 * @param userId
	 * @return
	 */
	protected boolean addComments(String comments, Long tiRequestId, String roleName, Long userId) {
		
		final StringBuilder insertSql =  new StringBuilder();
		insertSql.append("INSERT INTO C3PAR.TI_REQUEST_COMMENTS(ID,TI_REQUEST_ID,COMMENT_TYPE,ROLE_ID,COMMENTS,USER_ID,COMMENT_DATE) " );
		insertSql.append(" VALUES(C3PAR.SEQ_TI_REQUEST_COMMENTS.NEXTVAL,?,?,(SELECT MAX(ID) FROM C3PAR.ROLE WHERE UPPER(NAME) LIKE UPPER(?)),?,?,SYSDATE) ");
		
		getJdbcTemplate().update(insertSql.toString(), new Object[]{tiRequestId, "A", roleName, comments, userId});
		
		final StringBuilder updateSql =  new StringBuilder();
		updateSql.append("update ti_activity_trail set approval_system = ? where id in (select id from ti_activity_trail "+
					" where bpm_instance_id is not null and ti_request_id = ? and activity_status = 'SCHEDULED')");
		
		getJdbcTemplate().update(updateSql.toString(), new Object[]{OneApprovalConstants.APPROVAL_SYSTEM_EMAIL,tiRequestId});
		return true;
	}
	
	/**
	 * 
	 * @param processId
	 * @return
	 */
	protected Long getTIRequestID(Long processId) {
		Long tiRequestId = null;
		SqlRowSet rs = getJdbcTemplate().queryForRowSet("SELECT MAX(ID) FROM TI_REQUEST WHERE PROCESS_ID = ?", new Object[] {processId});
		
		if (rs.next()) {
			tiRequestId = rs.getLong(1);
		}
		return tiRequestId;
	}
	
	/**
	 * 
	 * @param email
	 * @return
	 */
	protected Long getUserID(String ssoId) {
		Long userId = null;
		SqlRowSet rs = getJdbcTemplate().queryForRowSet("SELECT MAX(ID) FROM C3PAR_USERS WHERE SSO_ID IS NOT NULL AND UPPER(SSO_ID) = ?",  new Object[] {ssoId.toUpperCase()});
		
		if (rs.next()) {
			userId = rs.getLong(1);
		}
		return userId;
	}
	
	protected Long getTaskId(Long connectionId, Long tiRequestId){
	    Long taskId=null;
	    try{
	        String query="select max(task_id) from ccr_task_ref where connection_id =?  and ti_request_id=?";
	        SqlRowSet rs=getJdbcTemplate().queryForRowSet(query,new Object[]{connectionId,tiRequestId});
	        if(rs.next()){
	            taskId=rs.getLong(1);
	        }    
	    }catch(Exception e){
	        log.error("Error has occurred in getTaskId():: "+e.toString());
	    }
	    
	    return taskId;
	}
	
	protected String getInstanceId(Long processId){
	    String instanceId=null;
	    try{
	        SqlRowSet rs = getJdbcTemplate().queryForRowSet("select bpm_instance_id from ti_activity_trail "+
	                " where bpm_instance_id is not null and ti_request_id = (select max(id) from ti_request where process_id = "+processId+") and activity_status = 'SCHEDULED'");
	        
	        if (rs.next()) {
	            instanceId = rs.getString(1);
	        }
	        log.info(" instanceId :: "+instanceId);
	    }catch(Exception e){
	        log.error("Error has occurred in  getInstanceId ::"+e.toString());
	    }
	    return instanceId;
	   
	}
	protected String toCheckACVActivity(Long processId,Long tiRequestId,String ssoId){
        log.info("processId "+processId+" tiRequestId :: "+tiRequestId+" ssoId "+ssoId);
        try{
            SqlRowSet rs = getJdbcTemplate().queryForRowSet("select TASK_ID from CCR_TASK_REF WHERE ti_request_id="+tiRequestId+" and ACTIVITY_STATUS ='Ready' and TASK_ROLE='Project_Coordinator' and PHASE='ACV'");
            if (rs.next()) {
               return "LOCK";
            }
            rs = getJdbcTemplate().queryForRowSet("select TASK_PARTICIPANT from CCR_TASK_REF WHERE ti_request_id="+tiRequestId+" and ACTIVITY_STATUS ='Reserved' and TASK_ROLE='Project_Coordinator' and PHASE='ACV'");
            if(rs.next()){
                log.info(" rs.getString(1) "+rs.getString(1));
                if(ssoId.equalsIgnoreCase(rs.getString(1))){
                    return "COMPLETE"; 
                }else{
                    return "UNLOCK"; 
                }
            }
        }catch(Exception e){
            log.error("Error has occurred in  getInstanceId ::"+e.toString());
        }
        return null;
       
    }
	
	protected String toCheckActivity(Long processId,Long tiRequestId,String ssoId){
        log.info("processId "+processId+" tiRequestId :: "+tiRequestId+" ssoId "+ssoId);
        try{
            SqlRowSet rs = getJdbcTemplate().queryForRowSet("select TASK_ID from CCR_TASK_REF WHERE ti_request_id="+tiRequestId+" and connection_id="+processId+" and ACTIVITY_STATUS ='Ready' and ACTIVITY_NAME='bu_mgr_app'");
            if (rs.next()) {
               return "LOCK";
            }
            rs = getJdbcTemplate().queryForRowSet("select TASK_PARTICIPANT from CCR_TASK_REF WHERE ti_request_id="+tiRequestId+" and connection_id="+processId+" and ACTIVITY_STATUS ='Reserved' and ACTIVITY_NAME='bu_mgr_app'");
            if(rs.next()){
                log.info(" rs.getString(1) "+rs.getString(1));
                if(ssoId.equalsIgnoreCase(rs.getString(1))){
                    return "COMPLETE"; 
                }else{
                    return "UNLOCK"; 
                }
            }
        }catch(Exception e){
            log.error("Error has occurred in  getInstanceId ::"+e.toString());
        }
        return null;
       
    }
	
	
	protected Map<String,String> getAcvInstanceId(Long processId,Long tiRequestId,String ssoId){
        String instanceId=null;
        String role = null;
        String activityId = null;
        StringBuilder taskIdForACVSQL = null;
        Map<String,String> taskIdDetails = null;
        try{
        	log.info("MailAction :: getAcvInstanceId : processId :"+processId);
			log.info("MailAction :: getAcvInstanceId : tiRequestId :"+tiRequestId);
			log.info("MailAction :: getAcvInstanceId : ssoId :"+ssoId);
        	taskIdForACVSQL = new StringBuilder();
        	taskIdDetails = new HashMap<String,String>();
        	taskIdForACVSQL.append(" SELECT A.TASK_ID,A.TASK_ROLE,TI_AUDITTRAIL_ID,DECODE(A.TASK_ROLE,'C3PARSYSTEMADMIN','1','Design_Engineer','2','Project_Coordinator','3',  ");
        	taskIdForACVSQL.append(" 'Business User','4','BISO','5','1') TASK_ROLE_PRIORITY FROM CCR_TASK_REF A,  ");
        	taskIdForACVSQL.append(" SECURITY_ROLE B, C3PAR_USER_ROLE_XREF C, C3PAR_USERS D WHERE A.TASK_ROLE = B.NAME  ");
        	taskIdForACVSQL.append(" AND A.TASK_ROLE IN ('C3PARSYSTEMADMIN','Design_Engineer','Project_Coordinator','Business User','BISO')   ");
        	taskIdForACVSQL.append(" AND B.ID = C.ROLE_ID AND C.USER_ID = D.ID AND UPPER(D.SSO_ID) = UPPER(?)  ");
        	taskIdForACVSQL.append(" AND A.TI_REQUEST_ID=? AND A.CONNECTION_ID=? AND CON_TYPE='ACV'  ");
        	taskIdForACVSQL.append(" ORDER BY TASK_ROLE_PRIORITY  ");
        	log.info("MailAction :: getAcvInstanceId : taskIdForACVSQL :"+taskIdForACVSQL.toString());
			SqlRowSet rs = jdbcTemplate.queryForRowSet(taskIdForACVSQL.toString(), new Object[]{ssoId,tiRequestId,processId});
            if (rs.next()) {
                instanceId = rs.getString(1);
                role = rs.getString(2);
                activityId = rs.getString(3);
                taskIdDetails.put("instanceId", instanceId);
				taskIdDetails.put("role", role);
				taskIdDetails.put("activityId", activityId);
            }
            log.info("MailAction :: getAcvInstanceId : instanceId :"+instanceId);
            log.info("MailAction :: getAcvInstanceId : role :"+role);
            log.info("MailAction :: getAcvInstanceId : activityId :"+activityId);
        }catch(Exception e){
            log.error("Error has occurred in  getAcvInstanceId ::"+e.toString());
        }
        return taskIdDetails;
    }
	
	protected long getAcvActivityTrailId(String taskId){
        long activityTrailId=0;
        try{
            SqlRowSet rs = getJdbcTemplate().queryForRowSet("SELECT TI_AUDITTRAIL_ID FROM CCR_TASK_REF WHERE TASK_ID='"+taskId+"' ");
            if (rs.next()) {
            	activityTrailId = rs.getLong(1);
            }
            log.info(" activityTrailId :: "+activityTrailId);
        }catch(Exception e){
            log.error("Error has occurred in  getAcvActivityTrailId ::"+e.toString());
        }
        return activityTrailId;
       
    }
	
	/**
	 * 
	 * @param userId
	 * @return
	 */
	protected String getSSOID(Long userId) {
		String ssoId = null;
		SqlRowSet rs = getJdbcTemplate().queryForRowSet("SELECT SSO_ID FROM C3PAR_USERS WHERE SSO_ID IS NOT NULL AND ID = ?", new Object[] {userId});
		
		if (rs.next()) {
			ssoId = rs.getString(1);
		}
		return ssoId;
	}
		
	/**
	 * 
	 * @param name
	 * @return
	 */
	//get role id for a given role
	public int getRole(String name){
		
		int id = 0;
		SqlRowSet rs = getJdbcTemplate().queryForRowSet("SELECT ID FROM ROLE WHERE NAME = ? ",  new Object[] {name} );
		
		if(rs.next()){
			id=rs.getInt(1);
		}		
		return id;		
	}
		
	/**
	 * 
	 * @param processId
	 * @return
	 */
	//check current activity is TA or BJ
	public String checkConnectionStage(Long processId){
		String connStage = null;
		
		final StringBuilder query = new StringBuilder();
		query.append("  SELECT TASK_CODE FROM TI_TASK_TYPE WHERE ID=(SELECT ACTIVITY_ID FROM TI_ACTIVITY_TRAIL WHERE TI_REQUEST_ID =  ");
		query.append("  (SELECT MAX(ID) FROM TI_REQUEST WHERE PROCESS_ID= ?) AND ACTIVITY_STATUS='SCHEDULED' AND ACTIVITY_ID IN(SELECT ID FROM TI_TASK_TYPE WHERE TASK IN ('Technical Architecture','Business Justification' ))) ");
				
		SqlRowSet rs = getJdbcTemplate().queryForRowSet( query.toString(), new Object[] {processId});
		
		if(rs.next()){
			connStage = rs.getString(1);
		}
		return connStage;
	}
	
	/**
	 * 
	 * @param conId
	 * @param roleId
	 * @param mail
	 * @return
	 */
	//update the contact table with the reject value
	public int updateContactStatus(Long conId, int roleId, String ssoId,int verNum){
		String tableName = null, relationShipType = null;
		
		SqlRowSet rs = getJdbcTemplate().queryForRowSet(" SELECT RELATIONSHIP_TYPE FROM RELATIONSHIP WHERE ID=(SELECT RELATIONSHIP_ID FROM TI_PROCESS WHERE ID = ? )",new Object[] {conId});
		
		if( rs.next() ) {
			relationShipType = rs.getString(1);
			if("CITI_CON".equalsIgnoreCase(relationShipType) || "U_TURN".equalsIgnoreCase(relationShipType)){
				tableName = "con_req_cit_rqcon_xref"; 
			}
			else{
				tableName = "con_req_citi_contact_xref";
			}
		}		
		final StringBuilder query = new StringBuilder();
		query.append ( " UPDATE ");
		query.append ( tableName );
		query.append ("  SET IS_REJECT='Y',PRIMARY_CONTACT = 'N',NOTIFY_CONTACT = 0 " );
		query.append ( " WHERE REQUEST_ID=(SELECT P.ID FROM PLANNING P,TI_REQUEST_PLANNING_XREF TRPX,TI_REQUEST TR  " );
		query.append ( " WHERE P.ID=TRPX.PLANNING_ID AND TRPX.TI_REQUEST_ID = TR.ID AND  " );
		query.append ( " TR.ID=(SELECT ID FROM TI_REQUEST WHERE PROCESS_ID= ? AND VERSION_NUMBER= ?))  AND  " );
		query.append ( " ROLE_ID= ?  AND CITI_CONTACT_ID in (SELECT ID FROM CITI_CONTACT WHERE SSO_ID=?) " );
		
		int i = getJdbcTemplate().update(	query.toString(), new Object[] {conId,verNum,roleId,ssoId.toUpperCase()} );
		 
		return i;
	}
	
	/**
	 * 
	 * @param conId
	 * @param role
	 * @return
	 */
	//retrieving contact details of TA or SA 
	public List<ContactDetailsDTO> getContactDetails(Long conId, String role, String roleDesc, int versionNumber) {
		List<ContactDetailsDTO> contactList = new ArrayList<ContactDetailsDTO>();
		String techArchRole = null;
		ContactDetailsDTO contact = null;
		String ssoId=null;
	
			techArchRole = DESIGNENGINEER;
			 	
		final StringBuilder query = new StringBuilder();
		query.append(" SELECT FIRST_NAME,LAST_NAME,EMAIL,SSO_ID FROM CITI_CONTACT WHERE ID IN (SELECT CITI_CONTACT_ID FROM CON_REQ_CITI_CONTACT_XREF WHERE REQUEST_ID= ");
		query.append("(SELECT P.ID FROM PLANNING P,TI_REQUEST_PLANNING_XREF TRPX,TI_REQUEST TR  " );
		query.append ( " WHERE P.ID=TRPX.PLANNING_ID AND TRPX.TI_REQUEST_ID = TR.ID AND  " );
		query.append ( " TR.ID=(SELECT ID FROM TI_REQUEST WHERE PROCESS_ID= ? AND VERSION_NUMBER= ?))"); 
		query.append(" AND ROLE_ID=(SELECT ID FROM ROLE WHERE NAME = ?) UNION ");
		query.append(" SELECT CITI_CONTACT_ID FROM CON_REQ_CIT_RQCON_XREF WHERE REQUEST_ID = ");
		query.append("(SELECT P.ID FROM PLANNING P,TI_REQUEST_PLANNING_XREF TRPX,TI_REQUEST TR  " );
		query.append ( " WHERE P.ID=TRPX.PLANNING_ID AND TRPX.TI_REQUEST_ID = TR.ID AND  " );
		query.append ( " TR.ID=(SELECT ID FROM TI_REQUEST WHERE PROCESS_ID= ? AND VERSION_NUMBER= ?)) ");
		query.append("AND ROLE_ID=(SELECT ID FROM ROLE WHERE NAME = ?)) ");
		
		SqlRowSet rs = getJdbcTemplate().queryForRowSet (query.toString(),new Object[] {conId,versionNumber,techArchRole,conId,versionNumber,techArchRole} );
				
		while(rs.next()){
			contact = new ContactDetailsDTO();
			contact.setName(rs.getString(1)+" "+rs.getString(2));
			contact.setEmailID(rs.getString(3));
			if(ssoId!=null && !"".equals(ssoId) && !"null".equals(ssoId)){
			    contact.setSsoID(rs.getString(4));
			}else{
			    contact.setSsoID(rs.getString(3));
			}
			contact.setRole(role);
			contactList.add(contact);
			}
		if(N.equals(roleDesc)){
			contact = new ContactDetailsDTO();
			contact.setName(SYSTEMADMIN);
			contact.setEmailID(OTRMDLGROUP);
			contact.setSsoID(OTRMDLGROUP);
			contact.setRole(role);
			contactList.add(contact);
		}
	return contactList;
	}
	
	protected boolean updateVerificationFlag(Long tiRequestId, String verificationFlag) {
		final String insertSql = "UPDATE C3PAR.TI_REQUEST SET ANNUAL_VERIFICATION_FLAG = ? WHERE ID = ?";
	 
		getJdbcTemplate().update(insertSql, new Object[]{verificationFlag, tiRequestId});
		return true;
	}
		
	protected String getRolesForACVApproval(String ssoId) {
		String role = null;
		final StringBuilder query = new StringBuilder();
		query.append(" SELECT SR.NAME FROM C3PAR_USER_ROLE_XREF CURX, security_role SR, C3PAR_USERS CU WHERE CURX.USER_ID=CU.ID AND CURX.ROLE_ID=SR.ID AND "); 
		query.append(" UPPER(CU.SSO_ID) IN(?) AND SR.NAME IN (?,?,?,?) " );
		
		SqlRowSet rs = getJdbcTemplate().queryForRowSet( query.toString(), new Object[] {ssoId,PROJECTCOORDINATOR,DESIGNENGINEER,C3PARSYSTEMADMIN,BISO} );
		
		if (rs.next()) {
			role = rs.getString(1);
		}
		return role;
	}
	
	protected boolean checkReferenceNumber(String referenceId, Long tiRequestId,String ssoID){
		
		boolean actionTaken = false;
		final StringBuilder query = new StringBuilder();
		query.append("select ACTION_TAKEN  from ti_mail_audit_response where TI_MAIL_AUDIT_ID in ");
		query.append("(select id from TI_MAIL_AUDIT where EMAIL_REFERENCE_NO = ? ) and ACTION_TAKEN ='Y'");
		
		SqlRowSet rs1 = getJdbcTemplate().queryForRowSet(query.toString(), new Object[] {referenceId});												
		if (rs1.next()) {
			actionTaken = true;
		}
		log.debug("Action Taken: "+actionTaken);
		String emailId="";
		
		final String selQuery = "SELECT email FROM citi_contact WHERE upper(sso_id)= ?";
		SqlRowSet rs2 = getJdbcTemplate().queryForRowSet(selQuery, new Object[]{ssoID.toUpperCase()});
		
		if (rs2.next()) {
			emailId = rs2.getString(1);
		}
		log.debug("emailId: "+emailId);
		
		if(!actionTaken){			
			SqlRowSet rs = getJdbcTemplate().queryForRowSet("SELECT id ,to_list FROM ti_mail_audit "+
							"WHERE ti_request_id = ? AND email_reference_no = ? AND (upper(to_list) like ('%"+emailId.toUpperCase()+"%') "+
							"OR upper(to_list) like ('%"+ssoID.toUpperCase()+"%') ) ", new Object[]{tiRequestId, referenceId});
			if(rs.next()){
				return true;
			}
		}
		return false;		
	}
		
	/*
	 * Logging the response mails in TI_MAIL_AUDIT_RESPONSE
	 * nc43495
	 */
	
	public Long saveMail(String referenceNo,String ssoID,String mailSub,final String mailBody){
		Long tiMailID=0L;
		Long id=0L;
		
		SqlRowSet rs1 = getJdbcTemplate().queryForRowSet("SELECT C3PAR.SEQ_TI_MAIL_AUDIT_RESPONSE.NEXTVAL FROM DUAL");
		if (rs1.next()) {
			id = rs1.getLong(1);
		}
		log.debug("Ti_mail_audit_response id :"+id);
		log.info("**referenceNo  value :: "+referenceNo);
		
		final String selIdQuery = "SELECT ID FROM TI_MAIL_AUDIT where EMAIL_REFERENCE_NO = ? ";
		SqlRowSet rs = getJdbcTemplate().queryForRowSet(selIdQuery, new Object[]{referenceNo});

		if (rs.next()) {
			tiMailID = rs.getLong(1);
		}
		log.debug("Ti mail audit ID :"+tiMailID);
		
		String insertMailSql = "INSERT INTO C3PAR.TI_MAIL_AUDIT_RESPONSE("
    		+ " ID,TI_MAIL_AUDIT_ID,FROM_USER_ID,MAIL_SUBJECT,ACTION_TAKEN,REMARKS,CREATED_DATE,UPDATED_DATE)"
    		+ " VALUES(?,?,?,?,?,?"
    		+ ",sysdate,sysdate)";
		
		getJdbcTemplate().update(insertMailSql,new Object[]{id,tiMailID,ssoID,mailSub,"",""});	
		
		//updating mailbody		
		/*String sql = "UPDATE C3PAR.TI_MAIL_AUDIT_RESPONSE SET MAIL_BODY = ? WHERE ID ="+id;		
		getJdbcTemplate().execute(sql,new AbstractLobCreatingPreparedStatementCallback(lobHandler){
			@Override
			protected void setValues(PreparedStatement ps) throws SQLException {
				ps.setBinaryStream(0, IOUtils.toInputStream(mailContentString, "UTF-8"),mailContent.length);
			}		     
			}
			);
		//getJdbcTemplate().execute(sql);
		 * 
*/	  String sql = "UPDATE C3PAR.TI_MAIL_AUDIT_RESPONSE SET MAIL_BODY = ? WHERE ID ="+id;	
        getJdbcTemplate().update(sql,  mailBody);
		return id;
	}
	
	
	/*
	 * Updating Remarks and Action taken in TI_MAIL_AUDIT_RESPONSE
	 * nc43495
	 */
	
	public void update(Long mailID,String referenceNo,String action,String remarks){
		
		log.info("Inside MailAction Update method starts here...");
		/*Long tiMailID=0L;
		
		final String selIdQuery = "SELECT ID FROM TI_MAIL_AUDIT where EMAIL_REFERENCE_NO = ? ";
		SqlRowSet rs = getJdbcTemplate().queryForRowSet(selIdQuery, new Object[]{referenceNo});
		if (rs.next()) {
			tiMailID = rs.getLong(1);
		}
		log.debug("Ti mail audit ID of update method :"+tiMailID);*/
		
		String sql = "UPDATE C3PAR.TI_MAIL_AUDIT_RESPONSE set ACTION_TAKEN =?, REMARKS = ? WHERE ID =?";
		
		getJdbcTemplate().update(sql,new Object[]{action,remarks,mailID});
		log.debug("Query for ti_mail_audit_response-> "+sql+"   - Parameters - action-> "+action+", remarks-> "+remarks+", mailID-> "+mailID);
		
		log.info("Inside MailAction Update method ends here...");
	}
	
	public void sendAckMail(String action,String ssoId,Long processId,String status,String role){
		log.info("Send Acknowledge Mail");
		ContactDetailsDTO contact = new ContactDetailsDTO();
		final String selMailQuery = "SELECT FIRST_NAME,LAST_NAME,EMAIL,SSO_ID FROM CITI_CONTACT WHERE SSO_ID = UPPER(?)";
		SqlRowSet rs = getJdbcTemplate().queryForRowSet(selMailQuery, new Object[]{ssoId});
		if(rs.next()){
			contact.setName(rs.getString(1)+" "+rs.getString(2));
			contact.setEmailID(rs.getString(3));
			if(ssoId!=null && !"".equals(ssoId) && !"null".equals(ssoId)){
			    contact.setSsoID(rs.getString(4));
			}else{
			    contact.setSsoID(rs.getString(3));
			}
			contact.setRole(role);
		}
		mailModuleImpl.sendAckMail(processId,contact,getTIRequestID(processId),status,action);
	}
	
	
	public void processReject(IncomingMessage message,String roleName) {
		
		log.info("Inside process "+roleName+" reject method ");
		
		int roleId = 0;
		Long processId = null;
		String connStage = null, isTA = null;
		
		if (message != null && message.getProcessId() != null) {
			processId = Long.parseLong(message.getProcessId());
		}
		Long tiRequestId = getTIRequestID(processId);
		
		if (checkReferenceNumber(message.getReferenceNo(), tiRequestId,message.getSsoId())) {
		int i =0;
		//get current activity of connection
		connStage = checkConnectionStage(processId);
		
		//get role ID for business tester
		roleId = getRole(roleName);
		
		//update the contact column with reject status
		try {
			i=updateContactStatus(processId, roleId, message.getSsoId(), message.getVersion());
			 if(i > 0){
				 sendAckMail(ACTION,message.getSsoId(),processId,SUCCESS,message.getEntity());
				update(message.getMailID(),message.getReferenceNo(),Y,"Action completed successfully"); 
			}else {
				sendAckMail(ACTION,message.getSsoId(),processId,FAILURE,message.getEntity());
				update(message.getMailID(),message.getReferenceNo(),N,"Not able to perform the action due to exception");
			}
			
		} catch (Exception e) {
			log.error("Exception Occured");
			sendAckMail(ACTION,message.getSsoId(),processId,FAILURE,message.getEntity());
			update(message.getMailID(),message.getReferenceNo(),N,getExceptionMessage(e));
			e.printStackTrace();
		}
		//check activity and send mail to respective person requesting action
		if(i>0){
			if(TECHNICAL_ARCHITECTURE.equalsIgnoreCase(connStage) || BUSINESS_JUSTIFICATION.equalsIgnoreCase(connStage)){
				isTA = Y;
				List conList = getContactDetails(processId,message.getEntity(),isTA,message.getVersion());
				sendMailToAddContact(processId,message.getSsoId(),conList);
				log.debug("Inside TA Block of "+roleName+" Reject Action");
			}
			else{
				isTA = N;
				List conList = getContactDetails(processId,message.getEntity(),isTA,message.getVersion());
				sendMailToAddContact(processId,message.getSsoId(),conList);
				log.debug("Inside SA Block of "+roleName+" Reject Action");
			}
		}
		else{
			log.debug("Mail to TA or SA for adding contact is not sent since rejection was not successful");
		}
		} else {
			sendAckMail(ACTION,message.getSsoId(),processId,FAILURE,message.getEntity());
			update(message.getMailID(),message.getReferenceNo(),"N","The response Email from the user is not authorized");
			log.debug("Refernce ID not matching "+ message.getReferenceNo());
		}
	}

	/**
	 * 
	 * @param conId
	 * @param contactList
	 */
	//send mail
	public void sendMailToAddContact(Long conId,String ssoID,List contactList){
		mailModuleImpl.sendMailToAddContact(conId,ssoID,contactList,getTIRequestID(conId));		
	}
	
	// parse the exception message and return only the message content
	public String getExceptionMessage(Exception exception){
		if(exception != null){
			String message = exception.getMessage();
			if(!message.isEmpty() && message.length() > 200){
				return message.substring(0, 200);
			}else if(!message.isEmpty()){
				return message;
			}
		}
		return "Not able to perform the action due to exception";
	}
}
