package com.citigroup.cgti.c3par.webtier.helper ;


/**
 * The Interface Transformer.
 */
public interface Transformer {

    /**
     * Transform.
     *
     * @param obj the obj
     * @return the object
     */
    public Object transform (Object obj) ;
}