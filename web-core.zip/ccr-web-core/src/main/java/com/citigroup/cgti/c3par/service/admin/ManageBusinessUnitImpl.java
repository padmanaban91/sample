package com.citigroup.cgti.c3par.service.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.soc.persist.ManageBusinessUnitPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.Sector;

@Transactional
public class ManageBusinessUnitImpl extends BasePersistanceImpl implements
ManageBusinessUnitPersistable {
	

	 /** The log. */
    private static Logger log = Logger.getLogger(ManageBusinessUnitImpl.class);

    public List<Region> getRegionList() throws Exception
    {
		List<Region> regionList = null;
		Session session = getSession();
		log.info("In ManageBusinessUnitImpl getRegionList");
		    try{
		    	String fetchRegionSql = "from Region where isactive='Y'";
		    					 
		    	regionList=  (List<Region>) session.createQuery(fetchRegionSql).list();
		    	
		      }
		    catch (HibernateException e)
		    {
		    	log.error(e,e);
			throw new Exception("Exception has occured",e);
		    }
		    
		return regionList;
	    }
    
    @Transactional(readOnly = true)
	public List<Sector> getSectorList() throws Exception
    {
		List<Sector> sectorList = null;
		Session session = getSession();
		List<Long> regionIDList = new ArrayList<Long>();
		log.info("In ManageBusinessUnitImpl getSectorList");
		    try{
		    	
		    	String fetchSectorSql = "from Sector where isactive='Y'" ;
		    	sectorList=  (List<Sector>) session.createQuery(fetchSectorSql).list();
		    	log.debug("In ManageBusinessUnitImpl getSectorList details"+session.createQuery(fetchSectorSql)+"   "+sectorList.size());
		      }
		    catch (HibernateException e)
		    {
		    	log.error(e,e);
		    	throw new Exception("Exception has occured",e);
		    }
		    
		return sectorList;
	    }
	
	public List<BusinessUnit> getBusinessUnitList(String sector) throws Exception 
    {
		List<BusinessUnit> businessUnitList =null ;
		Session session = getSession();
				    try{
				    	String fetchBusinessUnitSql = "from BusinessUnit as bu where bu.sector.id="+sector+" and bu.isactive='Y' order by bu.businessName";
				    	businessUnitList=  (List<BusinessUnit>) session.createQuery(fetchBusinessUnitSql).list();
				    
				    	log.debug("In ManageBusinessUnitImpl getSectorList details"+businessUnitList.size());
				      }
				    catch (HibernateException e)
				    {
				    	log.error(e,e);
				    	throw new Exception("Exception has occured",e);
				    }
				
				return businessUnitList;
    }
		
	public List<Relationship> getRelationshipList(CitiHierarchyMaster citiHierarchyMaster) 
    {
		/*List<Relationship> relationshipList =null ;
		Session session = getSession();
				
				    try{
				    	String fetchRelationshipSql = "Select * from RELATIONSHIP r  where r.ID in (Select c.RELATIONSHIP_ID from RelCitiHierarchyXref h, CitiHierarchyMaster c where  c.ID ="+citiHierarchyMaster.getId() +" and c.RELATIONSHIP_ID = h.CITIHIERARCHYMASTER_ID)";
				    	relationshipList=  (List<Relationship>) session.createQuery(fetchRelationshipSql);
				      }
				    catch (HibernateException e)
				    {
				    	log.error(e,e);
				//	throw new DatabaseException("Could not load " + EntitlementDataDAO.ENTITY_NAME + " with id = " + id_to_get, e);
				    }
				*/
				return null;
    }
		
/*
	public List<BusinessUnit> getLocationList(CitiHierarchyMaster citiHierarchyMaster) 
    {
		List<BusinessUnit> relationshipList =null ;
		Session session = getSession();
				
				    try{
				    	String fetchRelationshipSql = "Select * from RELATIONSHIP r  where r.ID in (Select c.RELATIONSHIP_ID from RelCitiHierarchyXref h, CitiHierarchyMaster c where  c.ID ="+citiHierarchyMaster.getId() +" and c.RELATIONSHIP_ID = h.CITIHIERARCHYMASTER_ID)";
				    	relationshipList=  (List<BusinessUnit>) session.createQuery(fetchRelationshipSql);
				      }
				    catch (HibernateException e)
				    {
				    	log.error(e,e);
				//	throw new DatabaseException("Could not load " + EntitlementDataDAO.ENTITY_NAME + " with id = " + id_to_get, e);
				    }
				
				return relationshipList;
    }
	*/
	public String addBusinessUnit(BusinessUnit bUnit) throws Exception{
		Session session = getSession();
		String result="";
		try{
			String checkBusinessUnitSql = "from BusinessUnit as bu where bu.sector.id="+bUnit.getSector().getId()+" and bu.businessName='"+bUnit.getBusinessName()+"' and bu.isactive='Y'";
			log.debug("SQL"+checkBusinessUnitSql);
			List<BusinessUnit> list = session.createQuery(checkBusinessUnitSql).list();			
			if(list.isEmpty()){			
		    Long key = Long.valueOf(session.createSQLQuery( "select SEQ_BUSINESS_UNITS.nextval from dual").uniqueResult().toString());
		    bUnit.setId(key);
			session.save(bUnit) ;
			result = "Business Unit Creation Successful";
			} else{
				result = "This Business Unit already exists for this sector";
			}
		}catch (HibernateException e)
	    {
			
	    	log.error(e,e);
	    	throw new Exception("Exception has occured",e);
	    }
		return result;
		
	}
	public String mapHierarcy(CitiHierarchyMaster citiHierarchyMaster) throws Exception {
		Session session = getSession();
		String result="";
		try{
			String fetchCitihierMasterSql = "from CitiHierarchyMaster as c where c.region.id ="+citiHierarchyMaster.getRegion().getId().toString()+
					" and c.sector.id ="+citiHierarchyMaster.getSector().getId().toString()+" and c.businessUnit.id="+citiHierarchyMaster.getBusinessUnit().getId().toString();
			log.debug(fetchCitihierMasterSql);
			List<CitiHierarchyMaster> list = session.createQuery(fetchCitihierMasterSql).list();
			
			if(list.isEmpty()){
			session.save(citiHierarchyMaster) ;
			result = "Mapping Successful";
			} else {
				result = "Mapping exists";
				log.info("Mapping exists");
			}
			
		}catch (HibernateException e)
	    {
			log.error(e,e);
			throw new Exception("Exception has occured",e); 
	    	
	
	    }
		return result;
	}
	
	}
