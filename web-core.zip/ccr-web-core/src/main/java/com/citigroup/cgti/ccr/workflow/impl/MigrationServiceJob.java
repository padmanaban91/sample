/**
 * 
 */
package com.citigroup.cgti.ccr.workflow.impl;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.context.ApplicationContext;

import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;

/**
 * @author ka58098
 *
 */

public class MigrationServiceJob  implements Job  {
    private static Logger log = Logger.getLogger(MigrationServiceJob.class);
    private ApplicationContext appContext = null;
  
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.info("Start job ::");
        appContext = CCRApplicationContextUtils.getApplicationContext();
        log.info("context is : " + context);
        MigrationServiceScheduler migrationServiceScheduler = (MigrationServiceScheduler) appContext.getBean("migrationServiceScheduler");
        migrationServiceScheduler.startMigration();
        log.info("End job ::");
    }


}
