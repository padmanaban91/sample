package com.citigroup.cgti.c3par.oneapproval;

import net.nsroot.eur.servicesolutions.cate.integration.MessageTypeEnum;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionStatusEnum;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.kie.api.task.model.TaskSummary;
import org.springframework.beans.factory.annotation.Autowired;

import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.bpm.papiwebservice.OperationException_Exception;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;
import com.citigroup.cgti.ccr.workflow.CCRWorkflowConstants;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

/**
 * 
 * @author ne36745
 *
 */
public class ACVOneApprovalAction extends OneApprovalAction {

    Logger log = Logger.getLogger(ACVOneApprovalAction.class);

    /**
     * Process ACV Approve Action
     */
    @Autowired
    WsPapiFacade papiFacade;
    @Autowired
    WorkflowCallServiceHelper wrkflowCallServiceHelper;
    @Autowired
    WorkflowUtil workflowUtil;
    @Autowired
	ManageTIProcessImpl manageTIProcessImpl;

    @Override
    public void process(OneApprovalMessageLog message) {

        String ssoId = null;
        String status = null;
        String comments = null;
        String messageType = null;
        String instanceId = null;
        String role = null;
        String activityId = null;
        long activityTrialId = 0;

        // To get GEID, status and comments
        if (message.getOneApprovalmsgTextList() != null && message.getOneApprovalmsgTextList().size() > 0) {
            String geId = message.getOneApprovalmsgTextList().get(0).getUpdatedByGEId();
            status = message.getOneApprovalmsgTextList().get(0).getStatus();
            comments = message.getOneApprovalmsgTextList().get(0).getComments();
            messageType = message.getOneApprovalmsgTextList().get(0).getMessageType();
            ssoId = getSSOID(geId);
        }
        log.debug("ACVOneApprovalAction Status: " + status);
        //String role = getRolesForACVApproval(ssoId);
        String approvalSystem = OneApprovalConstants.APPROVAL_SYSTEM_OA;

        if (message.getApproverType() != null && message.getApproverType().equalsIgnoreCase("F")) {
            approvalSystem = OneApprovalConstants.APPROVAL_SYSTEM_OA_FWD;
        } else if (message.getApproverType() != null && message.getApproverType().equalsIgnoreCase("D")) {
            approvalSystem = OneApprovalConstants.APPROVAL_SYSTEM_OA_DEL;
        }
        Long responseId = 0L;
        // Only if the status is APPROVED or REJECTED
        // TODO:Will check messageType in UAT (in DEV messageType coming as
        // Fulfil)
        if (MessageTypeEnum.UPDATE.toString().equalsIgnoreCase(messageType)
                && PurchaseOptionStatusEnum.APPROVED.toString().equals(status)) {
            try {
                responseId = saveMail(message.getOrderingSystemMappingId(), ssoId,
                        "OA:" + message.getActivity() + "/" + message.getOrderId());
                log.debug("ACVOneApprovalAction activity status to bpm: " + OneApprovalConstants.STATUS_COMPLETED);
                updateVerificationFlag(message.getTiRequestId(), "Y");           
                Long userId = getUserID(ssoId);
                Long tiRequestId = message.getTiRequestId();
                Long processId = null;
                //String instanceId = getAcvInstanceId(processId, tiRequestId, ssoId);
                Map<String,String> taskIdDetails = getAcvInstanceId(processId, tiRequestId,ssoId);
                if(taskIdDetails!=null)
    			{
                	instanceId = (String)taskIdDetails.get("instanceId");
                	role = (String)taskIdDetails.get("role");
                	activityId = (String)taskIdDetails.get("activityId");
    			}
                //long activityTrialId = getAcvActivityTrailId(instanceId);
                if(instanceId!=null && activityId!=null){
                log.info(" instanceId value:: " + instanceId);
                try{activityTrialId=Long.valueOf(activityId);}catch(Exception e){activityTrialId = Long.valueOf(0);}
                log.info(" activityTrialId value:: " + activityTrialId);
                String nextAction = toCheckActivity(processId, tiRequestId, ssoId);
                log.info(" nextAction value:: " + nextAction);
                Map<String, Object> userFlowParams = new HashMap<String, Object>();
                if (nextAction != null && "UNLOCK".equals(nextAction)) {
                    update(responseId, "N", "Activity is already locked by someone.");
                } else if (nextAction != null && "LOCK".equals(nextAction)){
    				log.info("Before calling lock Activity");
    				TaskSummary taskSummary = workflowUtil.getTaskSummary(Long.parseLong(instanceId));
    				userFlowParams.put("soeid", ssoId);
    				userFlowParams.put(CCRWorkflowConstants.TASK_SUMMARY,taskSummary );
    				log.info(" process instance id ==>"+taskSummary.getProcessInstanceId());
    				wrkflowCallServiceHelper.callWorkflowService(FlowType.ACV, userFlowParams, WorkflowEvent.LOCK, tiRequestId);
                    log.info("Before calling updateBPMInstanceId : instanceId -->"+instanceId);
        			manageTIProcessImpl.updateBPMInstanceId(message.getTiRequestId(), instanceId);
                    addComments(comments, message.getTiRequestId(), role, getUserID(ssoId), approvalSystem);
                    papiFacade.completeACVActivity(ssoId, instanceId,
                            OneApprovalConstants.STATUS_COMPLETED,activityTrialId,tiRequestId);                    
                    update(responseId, "Y", "Action completed successfully");
                } else{
                    update(responseId, "N", "Please contact the helpdesk for further assistance.");
                }
                }

            } catch (OperationException_Exception e) {
                update(responseId, "N", getExceptionMessage(e));
                log.error(e, e);
            }
        }
    }

}
