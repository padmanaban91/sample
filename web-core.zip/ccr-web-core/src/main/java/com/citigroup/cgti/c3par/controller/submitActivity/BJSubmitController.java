package com.citigroup.cgti.c3par.controller.submitActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.ManageActivityImpl;
import com.citigroup.cgti.c3par.bpm.wspapi.WsPapiFacade;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FafFireflowTicket;
import com.citigroup.cgti.c3par.soa.vc.util.RFCConstants;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.validator.submitActivtity.BJValidator;
import com.citigroup.cgti.c3par.webtier.helper.FAFReviewThread;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.citigroup.cgti.ccr.workflow.domain.JBPMTaskRef;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

/*
 * @nc43495
 */
@Controller
public class BJSubmitController {
	
	private static final String ADMIN_SUPPORT_ACTIVITY = "admin_support";


	private static final String BUS_JUS_ACTIVITY = "bus_jus";


	/** The log. */
	private static Logger log = Logger.getLogger(BJSubmitController.class);
	

	private static final String COMPLETEDSTATUS = "COMPLETED";
	private static final String ABORTEDSTATUS = "ABORTED";
	private static final String UNLOCKEDSTATUS = "UNLOCKED";
	
	@Autowired
	@Qualifier("bjValidator") 
	private BJValidator validator;
	
	@Autowired
	WsPapiFacade papiFacade;
	
	@Autowired
	WorkflowUtil workflowUtil;
	
	@Autowired
	ManageActivityImpl manageActivityImpl;
	
	 Util util;
	
	@RequestMapping(value = "/loadBJSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String load(ModelMap model,@ModelAttribute("bjSubmitProcess") SubmitActivityProcess submitActivityProcess,
			BindingResult result,HttpSession session,HttpServletRequest request){
		
		log.info("BJSubmitController load mthod begins here ...");
		session.removeAttribute("OSTIARISKCHECKNOTDONE");
		String tiReq = (String)session.getAttribute("tireqid");
		String actId = (String)session.getAttribute("activityid");
		Util util=new Util();
		Long tiReqId = Long.valueOf(0);
		Long activityId = Long.valueOf(0);
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		if(actId!=null){
		    try{activityId=Long.valueOf(actId);}catch(Exception e){activityId = Long.valueOf(0);}
		}
		log.debug("tiReq:"+tiReq+"ActivityId"+activityId);
		
		//Validation messages display
		List<ObjectError> bjMsgList = validator.getBusinessJustificationMessage(tiReqId);
		List<ObjectError> taMsgList = validator.getTechnialArchitectureMessage(tiReqId);
		
		//Removing duplicate error object from the list - business justification
		HashSet<ObjectError> tempSet = new HashSet<ObjectError>();
		tempSet.addAll(bjMsgList);		
		List<ObjectError> bjMsgListFinal = new ArrayList<ObjectError>();
		bjMsgListFinal.addAll(tempSet);		
				
		//Removing duplicate error object from the list - technical architecture
		tempSet = new HashSet<ObjectError>();
		tempSet.addAll(taMsgList);		
		List<ObjectError> taMsgListFinal = new ArrayList<ObjectError>();
		taMsgListFinal.addAll(tempSet);
				
		for (ObjectError error : bjMsgListFinal) {
					
			result.addError(error);
		}
				
		for (ObjectError error : taMsgListFinal) {
					
			result.addError(error);
		}
				
		
		request.setAttribute("errorMsg", result.getAllErrors());
		if (result.getAllErrors() != null && !result.getAllErrors().isEmpty()){
			if (result.getAllErrors().size() == 1
					&& (result.getAllErrors().get(0) == null || result.getAllErrors().get(0).getCode() == null 
					|| result.getAllErrors().get(0).getCode().isEmpty())) {
				request.setAttribute("errorMsgCount", 0);
			} else {
			request.setAttribute("errorMsgCount", result.getAllErrors().size());
			}
		}else{
			request.setAttribute("errorMsgCount", 0);
		}
		
		
		log.debug("error log:"+bjMsgList+"count:"+ result.getErrorCount()
				+""+result.getAllErrors().size());
		log.debug("errorlog technical architecture"+taMsgList);
		
		 submitActivityProcess = new SubmitActivityProcess();
		
		//supplementary review roles display
		 //temporary fix -start for finxing session issue
		HashMap<String,String> roles = submitActivityProcess.findInstanceId(tiReqId, activityId);
		roles.put("ROLE", "PROJECT COORDINATOR");
		submitActivityProcess.setRoles(roles);
		//temporary fix -End for finxing session issue
		List<LookUpVO> supReviewRole = submitActivityProcess.getSupReviewRoles((String)roles.get("ROLE"));
		log.debug("SubmitActivityController:"+supReviewRole.size());
		submitActivityProcess.setSupReviewRoles(supReviewRole);
		
		//Shared Question display
		String ssQuestion=util.getSharedServicesAttestQuestion();
		if(ssQuestion!=null && !(ssQuestion.trim().equalsIgnoreCase(""))){
			submitActivityProcess.setSharedServQuestion(ssQuestion);
		    String con_type = "";
		    String ssAnswer=submitActivityProcess.getSharedServAttestation(tiReqId, con_type);
		    if(ssAnswer!=null){
		    	submitActivityProcess.setSharedServAnswer(ssAnswer);
		    }
		    
		}
		
		//set activity role
		submitActivityProcess.setActivityRole((String)roles.get("ROLE"));
		session.setAttribute("activityRole",submitActivityProcess.getActivityRole());
		log.debug("activity role:"+submitActivityProcess.getActivityRole());
		
		/*//setInstanceID
		String instanceId = (String)roles.get("INST_ID");
		session.setAttribute("instanceID", instanceId);
		log.debug("instanceId"+instanceId);*/
		
		// setTaskID
		String taskId = (String) session.getAttribute("taskId");
		log.debug("*********taskId************" + taskId);
		
		//Approval comments display
		String role = (String)roles.get("ROLE");
		submitActivityProcess.setTiReqCmtsList(submitActivityProcess.getComments(tiReqId, role, "A"));
		
		//Discussion comments display
		submitActivityProcess.setDiscussCmtsList(submitActivityProcess.getComments(tiReqId, role, "D"));
		
		//CSI update
		//CSIUtil csiUtil = new CSIUtil();
	//	csiUtil.refreshCSIValuesInTIApplication(csiUtil.getTiApplicationIdsForGivenProcessId(csiUtil.getProcessid(tiReqId)),request.getHeader("SM_USER"));
		
		//Ostia risk 
		boolean ostiaRiskCheckNotDone = false;
	    	try {
				ostiaRiskCheckNotDone = util.isOstiaRiskCheckNotDone(tiReqId);
			} catch (Exception e) {
				e.printStackTrace();
			}
	    	session.setAttribute("OSTIARISKCHECKNOTDONE", ostiaRiskCheckNotDone);
	    
	    
		model.addAttribute("bjSubmitProcess",submitActivityProcess);
		
		return "c3par.BJSubmit";
	}
	
	@RequestMapping(value = "/saveBJSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String save(ModelMap model,@ModelAttribute("bjSubmitProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session,
			HttpServletRequest request) throws Exception{
		
		log.info("BJSubmitController save method...");
		formSubmit(submitActivityProcess,result,session,request);
		session.setAttribute("bpmSubmitFlag","true");
		log.debug("BJSubmitActivityController.save() END");
		return "forward:/logon.act?forwardTo=bpm";
	}
	
	 // Papi webservice call for BPM submit
    @RequestMapping(value = "/submitBJSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
    public String submit(ModelMap model,@ModelAttribute("bjSubmitProcess") SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session,
			HttpServletRequest request)   { 
		try {
			
			String tiReq = (String)session.getAttribute("tireqid");

			Long tiReqId = Long.valueOf(0);

			if(tiReq!=null){
			    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
			}
			
			//String instanceId = (String)session.getAttribute("instanceId");
			String instanceId=String.valueOf(workflowUtil.getWorkItemByTiRequestId(Long.parseLong(tiReq)));
			//Click on back button you will empty value
			if (StringUtil.isNullorEmpty(instanceId)) {
				return "forward:/defaultInboxView.act";
			} else {
				JBPMTaskRef jbpmTaskRef = workflowUtil.getTaskRefByTaskId(Long.parseLong(instanceId));
				if (jbpmTaskRef == null || !(BUS_JUS_ACTIVITY.equalsIgnoreCase(jbpmTaskRef.getActivityName())
						|| ADMIN_SUPPORT_ACTIVITY.equalsIgnoreCase(jbpmTaskRef.getActivityName()))) {
				return "forward:/defaultInboxView.act";
				}
			}
			
			formSubmit(submitActivityProcess,result,session,request);
			
			log.debug("BJandTAActivitySubmit Enter ");
			
		//	WsPapiFacade papiFacade = new WsPapiFacade ();
			
			
			String userId  = request.getHeader("SM_USER");
			String nextSelectedAction = submitActivityProcess.getCurrentAction();
			
			
			
			log.debug("Instanceid: " + instanceId +"action"+nextSelectedAction);
			log.debug("userId: " + userId);
						
			//Getting request type
			TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
			String request_Type = tiRequest.getTiRequestType().getName();
			//ConnectionId
			Long connectionId = tiRequest.getTiProcess().getId();
			
			
			log.debug("Before calling PAPI For BJ Submit");
			
			
		if (ABORTEDSTATUS.equals(nextSelectedAction) || UNLOCKEDSTATUS.equals(nextSelectedAction)) {
			papiFacade.completeActivity(userId, instanceId, nextSelectedAction); 
			//return "forward:/logon.act?forwardTo=bpm";
			return "forward:/defaultInboxView.act";
		}
		if (COMPLETEDSTATUS.equals(nextSelectedAction)) {
			//Fix Technical Architecture Appears on Audit Trail after GIS-Start
			JBPMTaskRef taskRefByTaskId = workflowUtil.getTaskRefByTaskId(Long.parseLong(instanceId));
			if (taskRefByTaskId != null && taskRefByTaskId.getAuditTrailId() != null) {
				this.manageActivityImpl.completeActivity(taskRefByTaskId.getAuditTrailId(),userId,
								!StringUtil.isNullorEmpty(nextSelectedAction) ? nextSelectedAction: COMPLETEDSTATUS);
			}
			//Fix Technical Architecture Appears on Audit Trail after GIS-End
			papiFacade.completeActivity(userId, instanceId, nextSelectedAction);
			if("Terminate".equalsIgnoreCase(request_Type)) {
				insertFAFQueueRequest(request,Long.valueOf(connectionId),"terminateall");
			}else{
				insertFAFQueueRequest(request,Long.valueOf(connectionId),"all");
			}
	    }
	else
		log.error ("Invalid Next Selected Action called: " + nextSelectedAction);	
		} catch (Exception e) {
			log.debug("BJandTAActivitySubmit Failed ",e);
		}
		return "forward:/defaultInboxView.act";
	}
		
	
	
	
    
    
    
    //insert faf queue request
    public void insertFAFQueueRequest(HttpServletRequest request, Long connectionRequestId, String requestType)
    throws Exception {
	log.debug("TIRequestCommentsAction.insertFAFQueueRequest() START");
	Util util=new Util();
	if("all".equals(requestType)){
	    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculate","N");
	    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculatepaf","N");
	    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"recalculateaaf","N");
	} else if("terminateall".equals(requestType)){
	    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminatefaf","N");
	    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminateaaf","N");
	    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),"terminatepaf","N");
	} else {
	    util.queueFAFRequest(connectionRequestId,request.getHeader("SM_USER"),requestType,"N");
	}
	FAFReviewThread.getInstance().startThread(request);
	FAFReviewThread.getInstance().notifyThread();
	log.debug("TIRequestCommentsAction.insertFAFQueueRequest() END");
    }
    
    //data collection
    private void formSubmit(SubmitActivityProcess submitActivityProcess,BindingResult result,HttpSession session,
			HttpServletRequest request)throws Exception{
    	String messgXML = (String)request.getSession().getAttribute("MESSAGEXML");
		log.info("messgXML::"+messgXML);
		
		String tiReq = (String)session.getAttribute("tireqid");
		
		submitActivityProcess.setActivityRole((String)session.getAttribute("activityRole"));
		log.debug("activity role inside form submit:"+submitActivityProcess.getActivityRole());
		Long tiReqId = Long.valueOf(0);
		log.info(" tireq=" + tiReq );
		
		
		if(tiReq!=null){
		    try{tiReqId=Long.valueOf(tiReq);}catch(Exception e){tiReqId = Long.valueOf(0);}
		}
		
		//Getting request type
		TIRequest tiRequest = submitActivityProcess.getTIRequest(tiReqId);
		String tiRequestType = tiRequest.getTiRequestType().getName();
		
		if(submitActivityProcess.getCurrentAction()==null){
			submitActivityProcess.setCurrentAction(ActivityData.STATUS_COMPLETED);
		}
		
		if(submitActivityProcess.getCurrentRole()==null){
			submitActivityProcess.setCurrentRole(submitActivityProcess.getActivityRole());
		}

		log.info("Request Parameters::"+request.getParameterNames());
		log.info("Request current role="+request.getParameter("currentRole"));
		log.info("current action =" + submitActivityProcess.getCurrentAction());
		log.info("current role=" + submitActivityProcess.getCurrentRole());
		log.info("comments = " + submitActivityProcess.getComments());
		
		//Ostia ByPass
		log.debug("************** Ostia Risk check ==> ");
		if(submitActivityProcess.getOstiaRiskCheckByPassed() != null && submitActivityProcess.getOstiaRiskCheckByPassed().equalsIgnoreCase("Y")){
			log.debug("************** Ostia Risk check ==> "+submitActivityProcess.getOstiaRiskCheckByPassed());
			Util util= new Util();
			util.updateOstiaQuestionnaireStaus(tiReqId);
		}else if(submitActivityProcess.getOstiaRiskCheckByPassed() != null && submitActivityProcess.getOstiaRiskCheckByPassed().equalsIgnoreCase("N")){
			log.debug("************** Ostia Risk check ==> "+submitActivityProcess.getOstiaRiskCheckByPassed());
		    String message = "Ostia Risk check is not completed for some of the tuples";
		    session.setAttribute("bpmSubmitMessage", message);
		    throw new BusinessException(message);
		}
		 
		
		String ssoID = request.getHeader("SM_USER");
		
		TiRequestComments tiReqComments = new TiRequestComments();
		tiReqComments.setTiRequest(tiRequest);
		tiReqComments.setComments(submitActivityProcess.getComments());
		tiReqComments.setRoleName(submitActivityProcess.getActivityRole());
		tiReqComments.setApproverSoeID(ssoID);
		
		    String validRequestorMessage = "success";
		   
			if (submitActivityProcess.getSharedServAnswer() != null) {
			    if (submitActivityProcess.getSharedServAnswer()
				    .equalsIgnoreCase(
					    RFCConstants.SHARED_SERV_DEFER)&& ActivityData.STATUS_COMPLETED
					    .equalsIgnoreCase(submitActivityProcess
						    .getCurrentAction()) ) {
				validRequestorMessage = "Your request cannot be processed until you accept the shared services attestation";
				session.setAttribute("bpmSubmitMessage",
					validRequestorMessage);

				throw new BusinessException(validRequestorMessage);
			    }else{
				if(session.getAttribute("bpmSubmitMessage")!=null){
				    session.removeAttribute("bpmSubmitMessage");
				}
			    }
			   
			    submitActivityProcess.insertSharedServAttestation(tiReqId,submitActivityProcess.getSharedServAnswer());
			}
			
		   
			
			//Director approver comments insert/delete
			String priority = (String) session.getAttribute("selected_priority");
			log.info("priority :: " + priority);
			
			if (priority != null && !(priority.trim().equals("BAU"))){
			    String comment = submitActivityProcess.getDirAprComments();
			    Util util = new Util();
			    int update = util.storeDirectorApprovalComments(tiReqId, comment);
			    log.info("director approval comments updated succesfully :: " + update);
			}
			
			
			//Supplementary review insert and delete
			log.info("request supReviewRoles::"+request.getParameter("selectedSupReviewRoles"));
			
			if(submitActivityProcess.getSelectedSupReviewRoles()!=null && submitActivityProcess.getSelectedSupReviewRoles().equals("-1")){
				submitActivityProcess.setSelectedSupReviewRoles(null);
			}
			
			
			
			//submitActivityProcess.deleteSupReviewRoles(tiReqId,submitActivityProcess.getActivityRole());
			submitActivityProcess.insertSupReviewRoles(tiReqId,submitActivityProcess.getActivityRole(),submitActivityProcess.getSelectedSupReviewRoles());
	
		   


		
		//Special instructions update
		if (submitActivityProcess.getCurrentAction()!=null){
			submitActivityProcess.specialInstructionUpdate(tiReqId,submitActivityProcess.getAppSplInstrcomments(),
		    										submitActivityProcess.getPrxSplInstrcomments(),submitActivityProcess.getFirwallSplInstrcomments(),
		    										submitActivityProcess.getIpRegSplInstrcomments(), submitActivityProcess.getAclVarSplInstrcomments());
		   
		}
		
		
		//Computation wait notification
		if(ActivityData.STATUS_COMPLETED.equalsIgnoreCase(submitActivityProcess.getCurrentAction())){
			
			TIProcess tiProcess = submitActivityProcess.getProcessData(tiReqId.longValue());
			
			if((tiRequestType!=null && !tiRequestType.equalsIgnoreCase("Terminate")) && (ActivityData.IS_NEW.equals(tiProcess.getProcessActivityMode()) || ActivityData.IS_REWORK.equals(tiProcess.getProcessActivityMode()))){
			    insertFAFQueueRequest(request,tiProcess.getId(),"all");
			} else if(tiRequestType!=null &&  tiRequestType.equalsIgnoreCase("Terminate")){
			    log.debug("***********Terminate FAF Computation Notification Started************");
			    Util.writeMessage(tiProcess.getId());
			    log.debug("***********Terminate FAF Computation Notification End************");
			}
		}
		
		//Fireflow ticket -flag -update
		if(submitActivityProcess.getCurrentAction()!=null && (submitActivityProcess.getCurrentAction().trim().equalsIgnoreCase(ActivityData.ACTIVITY_ABORTED)))
			{
			FafFireflowTicket ticket = new FafFireflowTicket();
			String fireFlowFlag = null;
			if (tiRequest != null) {
				FAFRequest fafRequest = new FAFRequest();
				log.debug("tiRequestEntity Id   :: "+tiRequest.getId());
				TIRequest TiReq = fafRequest.getTIRequest(tiRequest
						.getId());
				if (TiReq.getFireflowFlag() != null) {
					fireFlowFlag = TiReq.getFireflowFlag();
				}
			}
			if (fireFlowFlag != null
					&& fireFlowFlag.equalsIgnoreCase("Y")) {
				
			
			List<FafFireflowTicket> fireflowTicketsToBeResolved = ticket.findFafFireflowTicketsByReqId(tiReqId);
			log.info("commentsForm.getCurrentAction() : No of tickets found to being resolved : "+submitActivityProcess.getCurrentAction()+":"+fireflowTicketsToBeResolved.size());
				
				if (fireflowTicketsToBeResolved !=null && fireflowTicketsToBeResolved.size() > 0) {
					for (FafFireflowTicket tickets : fireflowTicketsToBeResolved) {
						tickets.setStatus(tickets.REJECTED);
						log.debug("fireFlowFlag  :: "+fireFlowFlag);
						
							tickets.updateFireflowTicketStatus(tickets,request.getCookies());
						
					}
				}}else{
					List<FafFireflowTicket> fireflowTicketsToBeResolved = ticket.findFafFireflowTicketsByReqIdNew(tiReqId);
					log.info("commentsForm.getCurrentAction() : No of tickets found to being resolved : "+submitActivityProcess.getCurrentAction()+":"+fireflowTicketsToBeResolved.size());
						
						if (fireflowTicketsToBeResolved !=null && fireflowTicketsToBeResolved.size() > 0) {
							for (FafFireflowTicket tickets : fireflowTicketsToBeResolved) {
								tickets.setStatus(tickets.REJECTED);
								log.debug("fireFlowFlag  :: "+fireFlowFlag);
								
									tickets.updateFireflowTicket(tickets);
								
							}
						}
					
				}
			}
		
		submitActivityProcess.addComments(tiReqComments, "A", "save");
    }
}
