/**
 *
 */
package com.citigroup.cgti.c3par.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.admin.domain.ContactPopUpProcess;
import com.citigroup.cgti.c3par.admin.domain.LocationPopUpProcess;
import com.citigroup.cgti.c3par.common.domain.soc.persist.ThirdPartyPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnitLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.ResourceTypeLocXref;
import com.citigroup.cgti.c3par.relationship.domain.ThirdParty;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartySearchProcess;

/**
 * @author ne36745
 * 
 */
@SuppressWarnings("unchecked")
@Transactional
public class ThirdPartyImpl extends BasePersistanceImpl implements ThirdPartyPersistable {

	/** The log. */
	private static Logger log = Logger.getLogger(ThirdPartyImpl.class);
	
	@Override
	@Transactional(readOnly = true)
	public List<ThirdParty> getThirdPartyList(String search) {
		Session session = getSession();
		Criteria criteria = session.createCriteria(ThirdParty.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		if(search!= null && !search.isEmpty()){
			criteria.add(Restrictions.like("name", search));
		}
		criteria.addOrder(Order.desc("id"));
		
		List<ThirdParty> list = criteria.list();
		
		if(list != null)
			log.debug("CommonServiceImpl :: getThirdPartyList :: size ::"+list.size());
		
		return list;
	}

	@Override
	public void deleteThirdParty(Long id) {
		
		log.debug("CommonServiceImpl::deleteThirdParty starts... ");  
		SQLQuery delContacts = getSession().createSQLQuery("delete from tp_contact where thirdparty_id= "+id);
		int tpcRows = delContacts.executeUpdate();
		log.debug("contacts deleted" +tpcRows);
		SQLQuery delLocation = getSession().createSQLQuery("delete from tp_loc_xref where thirdparty_id= "+id);
		int tplRows = delLocation.executeUpdate();
		log.debug("locations deleted" +tplRows);
    	SQLQuery query1 = getSession().createSQLQuery("delete from third_party where id = "+id);
		int rows = query1.executeUpdate();
		log.debug("third party "+rows); 
		
		log.debug("CommonServiceImpl::deleteThirdParty ends... ");  
	}

	@Override
	@Transactional(readOnly = true)
	public List<ThirdPartyContact> getTpContactsForId(Long id) {
		log.debug("into tp contacts method");
		Session session = getSession();
		List<ThirdPartyContact> tpc;
		Criteria criteria = session.createCriteria(ThirdPartyContact.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.createCriteria("thirdParty", "thirdParty");
		criteria.add(Restrictions.eq("thirdParty.id", id));
		tpc = criteria.list();
		log.debug("list size for tpCOntacts" +tpc.size());
		return tpc;
	}

	@Override
	@Transactional(readOnly = true)
	public List<Location> getTpLocationsForId(Long id) {
		log.debug("into tp location method");
		Session session = getSession();
		List <Location> tpl;
		SQLQuery query = session.createSQLQuery("select * from location where id in (select location_id from tp_loc_xref where thirdparty_id= "+id+ ")" );
		query.addEntity(Location.class);
		tpl = query.list();
		log.debug("list size" +tpl.size());
		return tpl;
	}

	@Override
	@Transactional(readOnly = true)
	public List<Relationship> getTpRelationshipForId(Long id) {
		log.debug("into tp relationship method");
		Session session = getSession();
		List<Relationship> tpr;
		Criteria criteria = session.createCriteria(Relationship.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.createCriteria("thirdParty", "thirdParty");
		criteria.add(Restrictions.eq("thirdParty.id", id));
		tpr =criteria.list();
		log.debug("tpRel size" +tpr.size());
		return tpr;
	}

	@Override
	@Transactional(readOnly = true)
	public ThirdPartyContact getThirdPartyForId(Long id) {
		Session session = getSession();
		ThirdPartyContact tpc;
		Criteria criteria = session.createCriteria(ThirdPartyContact.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.add(Restrictions.eq("id", id));
		tpc = (ThirdPartyContact) criteria.uniqueResult();
		return tpc;
	}

	@Override
	@Transactional(readOnly = true)
	public int getTpRelationshipForContact(long id) {
		log.debug("intogetTpRelationshipForContact method");
		Session session = getSession();
		int count;
		SQLQuery query = session.createSQLQuery("select * from REL_TP_CONT_XREF where tp_contact_id= "+id );
		List i = query.list();
		count = i.size();
		log.debug("list size" +count);
		return count;
	}

	@Override
	public void deleteContactById(Long id) {
		Session session = getSession();

    	SQLQuery query = session.createSQLQuery("delete from tp_contact where id = "+id);
		int rows = query.executeUpdate();
		
		log.debug("deleteContactById::rows"+rows);
		
	}

	@Override
	public void saveThirdPartyContact(ContactPopUpProcess contactPopUpProcess) {
		log.info("Into saveThirdPartyContact" );
		ThirdPartyContact tp = new ThirdPartyContact();
		Location loc = new Location();
		loc= contactPopUpProcess.getTpLocation();
		Long id = 0L;
		log.debug("loc id" +loc.getId());
		if(loc.getId()==null){
			log.debug("into if");
			id = (Long) getHibernateTemplate().save(loc);
			loc.setId(id);
		}
		else{
			log.debug("into else");
		getHibernateTemplate().update(loc);
		}
		
		tp= contactPopUpProcess.getTpContact();
		tp.setLocation(loc);
		log.debug("loc id" +tp.getLocation().getId() +tp.getThirdParty().getId());
		log.debug("save Tp conatct" +tp.getId() +tp.getPager());
		if(tp.getId()==null){
			log.debug("into if of tp");
			id = (Long) getHibernateTemplate().save(tp);
		}
		else{
			log.debug("into else of tp");
			getHibernateTemplate().update(tp);
		}
			log.info("Out of saveThirdPartyContact" );
		
	}

	@Override
	@Transactional(readOnly = true)
	public Location getLocation(Long id) {
		log.info("Into getThirdPartyLocation ");
		Session session = getSession();
		Location loc;
		Criteria criteria = session.createCriteria(Location.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.add(Restrictions.eq("id", id));
		loc =(Location) criteria.uniqueResult();
		log.info("Out of getThirdPartyLocation");
		return loc;
	}

	@Override
	public void saveLocationDetails(LocationPopUpProcess locationPopUpProcess) {
		Location loc = locationPopUpProcess.getLocation();
		Long id = 0L;
		
		if(locationPopUpProcess.getRequestType() != null){
			if(loc.getId() == null || loc.getId().longValue() <= 0){
				id = (Long) getHibernateTemplate().save(loc);
				loc.setId(id);				
				log.debug("Into saveLocationDetails");				
				if(locationPopUpProcess.getRequestType().equalsIgnoreCase("ThirdParty")){					
					ThirdPartyLocationXref locXref = new ThirdPartyLocationXref();
					locXref = locationPopUpProcess.getTpLocXref();
					locXref.setLocation(loc);
					id = (Long) getHibernateTemplate().save(locXref);
					locXref.setId(id); 
					log.debug("Into saveLocationDetails::ThirdParty-"+id);
				}else if(locationPopUpProcess.getRequestType().equalsIgnoreCase("BusinessUnit")){
					log.debug("Into saveLocationDetails::BusinessUnit start ");
					BusinessUnitLocationXref locXref = locationPopUpProcess.getBuLocXref();
					locXref.setLocation(loc);
					id = (Long) getHibernateTemplate().save(locXref);
					locXref.setId(id); 
					log.debug("Into saveLocationDetails::BusinessUnit-"+id);
				}else if(locationPopUpProcess.getRequestType().equalsIgnoreCase("ResourceType")){
					log.debug("Into saveLocationDetails::ResourceType start ");
					ResourceTypeLocXref locXref = locationPopUpProcess.getResTypeLocXref();
					locXref.setLocation(loc);
					id = (Long) getHibernateTemplate().save(locXref);
					locXref.setId(id); 
					log.debug("Into saveLocationDetails::ResourceType-"+id);
				}
			}else{
				getHibernateTemplate().update(loc);
			}
		}		
		locationPopUpProcess.setLocation(loc);
		log.debug("xref id" +id);
	}

	@Override
	@Transactional(readOnly = true)
	public Map<Long,String> getListofCountries() {
		log.info("Into getListofCountries");
		Map<Long,String> country = new HashMap<Long,String>();
		List<Object[]> result = new ArrayList();
		Session session = getSession();
		result = session.createSQLQuery("select id,value1 from generic_lookup where definition_id= (select id from generic_lookup_defs where name='Country' ) order by value1").addScalar("id",LongType.INSTANCE).addScalar("value1",StringType.INSTANCE).list();
		
		if(result.size()>0){
			for( Object[]  i : result){
				country.put((Long)i[0],(String)i[1]);
			}
		}
		log.debug("list size" +country.size());
		log.info("out of getListofCountries");
		return country;
	}

	@Override
	@Transactional(readOnly = true)
	public Map<Long, String> getListOfRegions() {
		log.info("Into getListOfRegions");
		Map<Long,String> region = new HashMap<Long,String>();
		List<Object[]> result = new ArrayList();
		Session session = getSession();
		result = session.createSQLQuery("select id,value1 from generic_lookup where definition_id= (select id from generic_lookup_defs where name='Region' ) order by value1").addScalar("id",LongType.INSTANCE).addScalar("value1",StringType.INSTANCE).list();
		
		if(result.size()>0){
			for( Object[]  i : result){
				region.put((Long)i[0],(String)i[1]);
			}
		}
		log.debug("list size" +region.size());
		log.info("out of getListOfRegions");
		return region;
	}

	@Override
	@Transactional(readOnly = true)
	public int getTpRelationshipForLocation(Long id) {
		log.debug("Into getTpRelationshipForLocation method");
		Session session = getSession();
		int count = 0;
		SQLQuery query = session.createSQLQuery("select * from REL_TP_LOC_XREF where location_id= "+id );
		List lst = query.list();
		if(lst != null){
			count = lst.size();
			log.debug("list size" +count);
		}
		return count;
	}

	@Override
	public void deleteLocationById(Long id) {
		log.debug("Into deleteLocationById ");
		Session session = getSession();

    	SQLQuery query = session.createSQLQuery("delete from tp_loc_xref where location_id = "+id);
		int rows = query.executeUpdate();
		
		log.debug("deleteLocationById::rows"+rows);		
	}

	@Override
	public int getRelationshipForCitiLocation(Long id) {
		log.debug("Into getRelationshipForCitiLocation method");
		Session session = getSession();
		int reqcount = 0, tarcount = 0;
		
		SQLQuery query = session.createSQLQuery("select * from REL_REQ_CITI_LOC_XREF where location_id= "+id );
		List lst = query.list();
		if(lst != null){
			reqcount = lst.size();
			log.debug("requester list size" +reqcount);
		}		
		
		query = session.createSQLQuery("select * from REL_CITI_LOC_XREF where location_id= "+id );
		lst = query.list();
		if(lst != null){
			tarcount = lst.size();
			log.debug("target list size" +tarcount);
		}		

		return reqcount + tarcount;
	}

	@Override
	public void deleteCitiLocationXrefById(Long id) {
		log.debug("Into deleteCitiLocationXrefById ");
		Session session = getSession();

    	SQLQuery query = session.createSQLQuery("delete from RES_TYP_LOC_XREF where location_id = "+id);
		int rows = query.executeUpdate();		
		log.debug("deleteCitiLocationXrefById::ResourceType rows"+rows);		

    	query = session.createSQLQuery("delete from BU_LOC_XREF where location_id = "+id);
		rows = query.executeUpdate();		
		log.debug("deleteCitiLocationXrefById::BusinessUnit rows"+rows);		
	}


	@Override
	@Transactional(readOnly = true)
	public List<ThirdParty> loadThirdPartyProcessList(ThirdPartySearchProcess thirdPartySearchProcess) {
		Session session = getSession();
		Criteria criteria = session.createCriteria(ThirdParty.class);
		 
		if(thirdPartySearchProcess != null){					 
			if(thirdPartySearchProcess.getDetailIdFilter() != null){
				criteria.add(Restrictions.eq("detailId",  thirdPartySearchProcess.getDetailIdFilter())); 
			}
			if (thirdPartySearchProcess.getCaspIdFilter() != null) {		 
				criteria.add(Restrictions.eq("caspId", Long.valueOf(thirdPartySearchProcess.getCaspIdFilter())));		  
			}	
			if (thirdPartySearchProcess.getParentIdFilter() != null) {		 
				criteria.add(Restrictions.eq("parentId", thirdPartySearchProcess.getParentIdFilter()));		  
			}		 
		}
		 
		criteria.addOrder(Order.desc("id"));		 
		List<ThirdParty> list = criteria.list();
		
		if(list != null)
			log.debug("third party List Size ::"+list.size());
		
		return list;
	}

	@Override
	public Long saveThirdPartyDetails(ThirdParty thirdParty){
		Long id = 0L;
		if(thirdParty.getId()==null){
			id = (Long) getHibernateTemplate().save(thirdParty);
		}
		log.debug("ThirdPartyImpl :: saveThirdPartyDetails :: id - "+id );
		return id;
	}
}
