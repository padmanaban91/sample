package com.citigroup.cgti.c3par.controller.secacl;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.acl.domain.ACLVariance;
import com.citigroup.cgti.c3par.acl.domain.ManageAclVarianceProcess;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.webtier.helper.Util;

@Controller
public class ManageAclVarianceController {

	private static Logger log = Logger.getLogger(ManageAclVarianceController.class);

	@RequestMapping(value = "/manageAclVarianceController.act", method = RequestMethod.GET)
	public String load(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String forwardTo = "c3par.secacl.manageAclVariance";
		Long processId = null;
		ManageAclVarianceProcess sec = new ManageAclVarianceProcess();

		Long tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());

		log.info("tirequestId:: in load review()::" + tirequestId);
		
		TIRequest tirequest = sec.getTIRequestDetails(tirequestId);
		
		//request.getSession().setAttribute("displayMode", "Edit");
		
		String requestType = null;
		if (tirequest.getTiRequestType() != null
				&& tirequest.getTiRequestType().getName() != null) {
			requestType = tirequest.getTiRequestType().getName();
			
			if (requestType != null	&& requestType.equalsIgnoreCase("Terminate")) {
				log.info("Setting DisplayMode to View for Termination Cycle");
				request.getSession().setAttribute("displayMode", "View");
			}
		}
		if (request.getParameter("processId") != null) {
			processId = Long.valueOf(request.getParameter("processId"));
			sec.setOriginalConnectionRequestId(processId);
		} else if (processId == null && tirequest != null) {
			processId = tirequest.getTiProcess().getId();
			sec.setOriginalConnectionRequestId(processId);
		} else {
			processId = sec.getOriginalConnectionRequestId();
		}
		
		if (processId == null) {
			Util util = new Util();
			processId = util.getPlanningIdForTiRequestId(tirequestId);
			log.info("processId in the null :: " + processId);
		}
		if (processId != null) {
			TIProcess tiProcess = new TIProcess();
			TIRequest tiRequest = new TIRequest();
			tiRequest.setId(tirequestId);
			tiProcess.setId(processId);
			tiProcess.setTiRequest(tiRequest);
			ACLVariance aclVariance = sec.getACLVarianceData(tiProcess);
			if (aclVariance == null) {
				aclVariance = new ACLVariance();
				aclVariance.setTiProcess(tiProcess);
				aclVariance.setTiRequest(tiRequest);
			}
			sec.setAclVariance(aclVariance);
		}

		model.addAttribute("SecAclProcess", sec);

		return forwardTo;
	}

	@RequestMapping(value = "/storemanageAclVarianceController.act", method = RequestMethod.POST)
	private String store(ModelMap model,
			@ModelAttribute("SecAclProcess") ManageAclVarianceProcess secAclProcess,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String forwardTo = "c3par.secacl.manageAclVariance";
		ACLVariance aclVariance = secAclProcess.getAclVariance();
		
		log.info("aclVariance.getAcl_name():" + aclVariance.getAcl_name()+"aclVariance.getAcl_device_routers():"
				+ aclVariance.getAcl_device_routers()+"aclVariance.getAcl_justification():"+ aclVariance.getAcl_justification());

		if (aclVariance != null) {
			secAclProcess.storeACLVariance(aclVariance);
		}
		/*ACLVariance acrvar = secAclProcess.getACLVarianceData(secAclProcess.getAclVariance().getTiProcess());
		secAclProcess.setAclVariance(acrvar);*/
		model.addAttribute("SecAclProcess", secAclProcess);

		return forwardTo;
	}

	@RequestMapping(value = "/deletemanageAclVarianceController.act", method = RequestMethod.POST)
	private String delete(ModelMap model,
			@ModelAttribute("SecAclProcess") ManageAclVarianceProcess sec,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String forwardTo = "c3par.secacl.manageAclVariance";
		ACLVariance aclVariance = sec.getAclVariance();

		if (aclVariance != null) {
			sec.deleteACLVariance(aclVariance);
		}
		aclVariance.setAcl_name(null);
		aclVariance.setAcl_device_routers(null);
		aclVariance.setAcl_justification(null);

		sec.setAclVariance(aclVariance);
		model.addAttribute("SecAclProcess", sec);

		return forwardTo;
	}

	@RequestMapping(value = "/updatemanageAclVarianceController.act", method = RequestMethod.POST)
	private String update(ModelMap model,
			@ModelAttribute("SecAclProcess") ManageAclVarianceProcess sec,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String forwardTo = "c3par.secacl.manageAclVariance";
		ACLVariance aclVariance = sec.getAclVariance();

		aclVariance.getAcl_device_routers();
		aclVariance.getAcl_device_routers();
		aclVariance.getAcl_justification();

		if (aclVariance != null) {
			sec.updateACLVariance(aclVariance);
		}
		model.addAttribute("SecAclProcess", sec);

		return forwardTo;
	}

	@RequestMapping(value = "/manageAclVarianceloadReviewController.act", method = {RequestMethod.GET, RequestMethod.POST })
	private String loadReview(ModelMap model,
			@ModelAttribute("SecAclProcess") ManageAclVarianceProcess sec,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String forwardTo = "c3par.secacl.manageAclVariance";
		String reviewStatus = null;
		Long connectionRequestId = null;
		Long processId = null;

		Util util = new Util();

		Long tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());

		TIRequest tirequest = sec.getTIRequestDetails(tirequestId);
		sec.setTirequest(tirequest);

		connectionRequestId = tirequest.getTiProcess().getId();
		sec.setOriginalConnectionRequestId(connectionRequestId);
		sec.setConName(tirequest.getTiProcess().getProcessName());
		
		Long planningId = sec.getPlanningId(tirequestId);
		
		log.info("ManageAclVarianceController :: loadReview :: tirequestId "+ tirequestId.longValue() + " :: planningId :: " + planningId);

		Planning planning = sec.getPlanningDetails(planningId);
		sec.setPlanning(planning);
		int version = 0;

		if (request.getParameter("reviewStatus") != null) {

			reviewStatus = request.getParameter("reviewStatus");

			if ("reviewCurrent".equals(reviewStatus)) {
				version = util.getLatestVersionIdForACLVariance(connectionRequestId);
			} else {
				version = sec.getVersionNo();
				version = version - 1;
			}

		} else {
			reviewStatus = "reviewCurrent";
			version = util.getLatestVersionIdForACLVariance(connectionRequestId);
		}

		processId = sec.getOriginalConnectionRequestId();
		if (processId != null) {
			TIProcess tiProcess = new TIProcess();
			tiProcess.setId(processId);
			tiProcess.setVersionNumber(version);

			ACLVariance aclVariance = sec.getACLVariance(tiProcess);
			sec.setAclVariance(aclVariance);
		}

		request.setAttribute("displayDocs", "true");
		String rationale = util.getRationaleByVersion(connectionRequestId,	new Long(version), "ACL");
		sec.setRationale(rationale);
		Map<String, String> sowAndCmp = util.getCMPAndSOWByVersion(connectionRequestId, new Long(version), "ACL");
		sec.setCMPReview(sowAndCmp.get("CMP"));
		sec.setSOWReview(sowAndCmp.get("SOW"));
		sec.setVersionNo(version);
		sec.setOriginalConnectionRequestId(connectionRequestId);
		
		Long tiReqId = util.getTIRequestIdForVersion(connectionRequestId,version);
		
		sec.setRequestor(util.getRequesterDetails(connectionRequestId));		
		sec.setBusinessContacts(util.getBusinessContactsDetails(connectionRequestId, Long.valueOf(version)));
		
		if (planning != null && planning.getId() != connectionRequestId) {
			sec.setCurrCycleRequestor(util.getRequesterDetails(planning.getId()));
			
		sec.setCurrBusJustfi(util.getCurrentBusJustfication(tiReqId));	

		sec.setOrigBusJustification(util.getOrigBusJustification(
						connectionRequestId, Long.valueOf(version)));
		
		log.debug("util.getOrigBusJustification(connectionRequestId,Long.valueOf(version))::"
					+ util.getOrigBusJustification(connectionRequestId,
							Long.valueOf(version)));
		}
		Map implInfo = util.getImplementationInfo(connectionRequestId,Long.valueOf(version), "ACL");

		if (implInfo.size() > 0) {
			sec.setFafSplInstruction((String) implInfo.get("SPL_INSTR"));
			sec.setFafCompletionDate((String) implInfo.get("COMPLETION_DATE"));
			sec.setFafInfomanId((Long) implInfo.get("INFOMAN_ID"));
		}

		String acl_implementer = util.getCurrentProcess_status(sec.getOriginalConnectionRequestId(), Long.valueOf(version),	ActivityData.ACL_VARIANCE_IMP);
		request.setAttribute("acl_implementer", acl_implementer);

		ArrayList uploadedDocumentList = (ArrayList) util.getUploadedDocumentList(tiReqId, "'ACL_Current','ACL_Changes'");	
		sec.setUploadedDocumentACLList(uploadedDocumentList);
		model.addAttribute("SecAclProcess", sec);
		
		return forwardTo;
	}

	@RequestMapping(value = "/exportmanageAclVarianceloadReviewController.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	private String export(ModelMap model,
			@ModelAttribute("SecAclProcess") ManageAclVarianceProcess sec,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String forwardTo = "c3par.secacl.manageAclVariance";
		Long connectionRequestId = null;
		
		Util util = new Util();
		Long tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());
		TIRequest tirequest = sec.getTIRequestDetails(tirequestId);

		connectionRequestId = tirequest.getTiProcess().getId();
		sec.setOriginalConnectionRequestId(connectionRequestId);

		Long planningId = sec.getPlanningId(tirequestId);
		Planning planning = sec.getPlanningDetails(planningId);
		sec.setPlanning(planning);

		int version = sec.getVersionNo();

		request.setAttribute("displayDocs", "true");

		Long tiReqId = util.getTIRequestIdForVersion(connectionRequestId,version);		
		String acl = sec.getSECACLAccessFormText(tiReqId, connectionRequestId,Long.valueOf(version));
		acl = acl.replaceAll("\n", "\r\n");
		log.debug("acl string in export::" +acl);
		sec.setAclString(acl);

		response.setContentType("text/plain; charset=utf-8");
		response.setHeader("Content-Disposition", "attachment; filename="+ connectionRequestId + "-" + version + ".txt");
		

		forwardTo = "pages/secacl/ManageAclVarianceExport";

		model.addAttribute("SecAclProcess", sec);

		return forwardTo;
	}

	@RequestMapping(value = "/exportAllmanageAclVarianceloadReviewController.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	private String exportAll(ModelMap model,
			@ModelAttribute("SecAclProcess") ManageAclVarianceProcess sec,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String forwardTo = "pages/secacl/ManageAclVarianceExport";
		Long connectionRequestId = null;
		
		Long tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());

		TIRequest tirequest = sec.getTIRequestDetails(tirequestId);
		connectionRequestId = tirequest.getTiProcess().getId();
		sec.setOriginalConnectionRequestId(connectionRequestId);
		
		String acl = sec.getAllACLAccessFormText(tirequestId,connectionRequestId);
		acl = acl.replaceAll("\n", "\r\n");
		
		sec.setAclString(acl);

		response.setContentType("text/plain; charset=utf-8");
		response.setHeader("Content-Disposition", "attachment; filename="+ connectionRequestId + ".txt");

		
		model.addAttribute("SecAclProcess", sec);

		return forwardTo;
	}

	@RequestMapping(value = "/viewDocumentmanageAclVarianceloadReviewController.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	private String viewDocument(ModelMap model,
			@ModelAttribute("SecAclProcess") ManageAclVarianceProcess sec,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		try {
			byte[] docBytes = null;
			String docMimeType = null;

			String pk = request.getParameter("pk");
			docMimeType = request.getParameter("docmimetype");
			String docName = request.getParameter("docName");

			Util util = new Util();
			docBytes = util.getDocumentContent(pk,new C3parSession().getConnection());
			
			if (docMimeType != null && docBytes != null && docBytes.length != 0) {
				java.io.OutputStream os = response.getOutputStream();
				response.setContentType(docMimeType);
				response.setHeader("Content-Disposition","attachment; filename=" + docName);

				os.write(docBytes);
			} else {
				java.io.PrintWriter out = response.getWriter();
				response.setContentType("text/html");
				out.println("<HTML><BODY>There was no file attached!</BODY></HTML>");
			}
		} catch (Exception e) {
			log.error(e);
			java.io.PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			out.println("<HTML><BODY>There was an error retrieving the requested file!</BODY></HTML>");
		}

		model.addAttribute("SecAclProcess", sec);
		return null;
	}

}
