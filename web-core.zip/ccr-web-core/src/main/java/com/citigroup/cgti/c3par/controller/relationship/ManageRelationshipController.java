package com.citigroup.cgti.c3par.controller.relationship;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.communication.domain.AgentViewProcess;
import com.citigroup.cgti.c3par.dashboard.webtier.helper.CommonCode;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.CoLookupData;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiHierarchyXref;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.RelationshipProcess;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.relationship.domain.ThirdParty;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartySearchProcess;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.validator.relationship.RelationshipValidator;
import com.citigroup.cgti.c3par.webtier.helper.C3parStatusLookupNames;
import com.citigroup.cgti.c3par.webtier.helper.GenericHelper;
import com.citigroup.cgti.ccr.workflow.FlowType;
import com.citigroup.cgti.ccr.workflow.WorkflowCallServiceHelper;
import com.citigroup.cgti.ccr.workflow.WorkflowEvent;
import com.citigroup.cgti.ccr.workflow.WorkflowResult;
import com.citigroup.cgti.ccr.workflow.domain.JBPMTaskRef;
import com.citigroup.cgti.ccr.workflow.util.WorkflowUtil;

@Controller
public class ManageRelationshipController extends RelationshipBaseController {

	private static final long serialVersionUID = 1L;

	private Logger log = Logger.getLogger(this.getClass().getName());
	@Autowired
	WorkflowUtil workflowUtil;

	@Autowired
	WorkflowCallServiceHelper wrkflowCallServiceHelper;

	public static String PORT_RES_TYPE = "Port Template";
	public static String IP_RES_TYPE = "IP Template";
	public static String THIRD_RES_TYPE = "3rd Party/CEP";
	public static String SAVE = "save";
	public static String SAVE_CONTINUE = "save_continue";
	public static String UPDATE_CONTINUE = "update_continue";
	public static String EDIT = "edit";
	public static final String ADD = "add";
	public static final String VIEW = "view";
	public static final String FALSE = "false";
	public static final String TRUE = "true";
	public static final String DISPLAYMODE = "displayMode";

	// load relationship details for view
	@RequestMapping(value = "/loadRelationship.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadRelationship(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess, BindingResult result,
			HttpServletRequest request) {
		log.debug("ManageRelationshipController::loadRelationship methods starts...");
		String forwardPage = "c3par.relationship.addEditRelationship";
		Long relId = null;
		Long tiRequestId = getTirequestID(request);
		log.info(" loadRelationship  tiRequestId :: " + tiRequestId);
		relId = relationshipProcess.getRelationshipId(tiRequestId);
		log.info(" loadRelationship  relId :: " + relId);
		// get relationship id from request object
		if (request.getParameter("relId") != null && Long.parseLong(request.getParameter("relId")) != 0) {
			relId = Long.parseLong(request.getParameter("relId"));
		} else if (relationshipProcess != null && relationshipProcess.getRelationship() != null
				&& relationshipProcess.getRelationship().getId() != null) {
			relId = relationshipProcess.getRelationship().getId();
		}
		// load relationship details and set relationship mode as view
		relationshipProcess = new RelationshipProcess();
		log.debug("ManageRelationshipController::loadRelationship::relId ==> " + relId);
		Relationship relationship = relationshipProcess.getRelationshipDetails(relId);
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.THIRD_PARTY)
				|| relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.U_TURN)) {
			log.info("relationship.getThirdParty() :: "+relationship.getThirdParty());
			log.info("relationship.getUturnThirdParty() :: "+relationship.getUturnThirdParty());
			if(relationship.getThirdParty()==null)
			 relationship.setThirdParty(new ThirdParty());
			if(relationship.getUturnThirdParty()==null)
			relationship.setUturnThirdParty(new ThirdParty());	
			
		}
		String disPlayMode = (String) request.getSession().getAttribute(DISPLAYMODE);
		if (!StringUtil.isNullorEmpty(disPlayMode) && EDIT.equalsIgnoreCase(disPlayMode))
			relationshipProcess.setRelationshipMode(EDIT);
		else
			relationshipProcess.setRelationshipMode(VIEW);
		relationshipProcess.setPerform(UPDATE_CONTINUE);
		relationshipProcess.setTiRequestId(tiRequestId);
		List processNameList = relationshipProcess.getProcessName(tiRequestId);
		if (!CollectionUtils.isEmpty(processNameList)) {
			Object[] obj = (Object[]) processNameList.get(0);
			relationshipProcess.setConnectionName(String.valueOf(obj[1]));
			relationshipProcess.setConnectionId(Long.parseLong(String.valueOf(obj[0])));
		}
		relationshipProcess.setRelationship(relationship);
		// load relationship region, sector, business unit and resource type
		// dropdown lists
		relationshipProcess.setRegList(relationshipProcess.getRegionList());
		relationshipProcess.setRegListSize(relationshipProcess.getRegList().size());
		loadSectorBuList(relationshipProcess);
		loadResourceTypeList(relationshipProcess);
		// load contacts, location and thirdparty details
		relationshipProcess.loadRelationshipReferences(relationshipProcess);
		relationshipProcess.setCanEdit(Boolean.TRUE);
		if (relationshipProcess.relationshipBusValidation(tiRequestId)) {
			relationshipProcess.setIsRules(TRUE);
		} else {
			relationshipProcess.setIsRules(FALSE);
		}
		// set relationshipProcess into session
		setInSession(request, relationshipProcess);
		model.addAttribute("relationshipProcess", relationshipProcess);
		log.info("ManageRelationshipController::loadRelationship methods ends...forwardPage ==> " + forwardPage);
		return forwardPage;
	}

	private Long getTirequestID(HttpServletRequest request) {

		Long tirequestId = 0L;
		if (request.getSession().getAttribute("tireqid") != null) {
			tirequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());
		} else if (request.getParameter("tireqid") != null) {
			tirequestId = Long.valueOf(request.getParameter("tireqid").trim());
		} else if (request.getParameter("tiRequestId") != null) {
			tirequestId = Long.valueOf(request.getParameter("tiRequestId"));
		}
		log.info("BusinessJustificationController :: getTirequestID :: tirequestId - " + tirequestId);
		return tirequestId;
	}

	// load relationship details for edit
	@RequestMapping(value = "/editRelationship.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String editRelationship(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess, BindingResult result,
			HttpServletRequest request) {
		log.debug("ManageRelationshipController::editRelationship methods starts...");
		String forwardPage = "c3par.relationship.addEditRelationship";

		// set relationship mode as edit
		relationshipProcess.setRelationshipMode("edit");
		relationshipProcess.setRegList(relationshipProcess.getRegionList());
		relationshipProcess.setRegListSize(relationshipProcess.getRegList().size());
		relationshipProcess.getRelationship().setRelcitiHierarchyXrefs(
				relationshipProcess.getRelationshipCitiHierarchy(relationshipProcess.getRelationship().getId()));

		// load relationship sector, business unit and resource type dropdown
		// lists
		loadSectorBuList(relationshipProcess);
		loadResourceTypeList(relationshipProcess);

		// set edit parameters in relationshipForm which is used for contacts,
		// location and third party popup
		RelationshipProcess relprocess = getRelationshipProcess(request);
		relprocess.setCanEdit(Boolean.TRUE);
		setInSession(request, relprocess);
		Relationship relationship=relprocess.getRelationship();
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.THIRD_PARTY)
				|| relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.U_TURN)) {
			log.info("relationship.getThirdParty() :: "+relationship.getThirdParty());
			log.info("relationship.getUturnThirdParty() :: "+relationship.getUturnThirdParty());
			if(relationship.getThirdParty()==null)
			 relationship.setThirdParty(new ThirdParty());
			if(relationship.getUturnThirdParty()==null)
			relationship.setUturnThirdParty(new ThirdParty());	
			relprocess.setRelationship(relationship);
		}
		if (request.getSession().getAttribute("VALIDATION_ERROR_LIST") != null) {
			List<String> errorMessages = (List<String>) request.getSession().getAttribute("VALIDATION_ERROR_LIST");

			for (String errorMsg : errorMessages) {
				result.addError(new ObjectError("relationshipId", errorMsg));
			}
		}

		model.addAttribute("relationshipProcess", relationshipProcess);
		log.info("ManageRelationshipController::editRelationship methods ends...forwardPage ==> " + forwardPage);
		return forwardPage;
	}

	// delete relationship details
	@RequestMapping(value = "/deleteRelationship.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String deleteRelationship(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess,
			HttpServletRequest request) {
		String forwardPage = "redirect:/loadRelationshipListController.act?fromPage=saveRelationship";
		log.debug("ManageRelationshipController::deleteRelationship methods starts...");

		// check whether relationship is exists
		if (relationshipProcess.getRelationship().getId() != null
				&& relationshipProcess.getRelationship().getId().longValue() > 0) {

			// check whether relationship is used in any connection
			if (relationshipProcess.isRelationshipUsedInCon(relationshipProcess.getRelationship())) {
				// if the relationship is used in connection, show the error
				log.debug("ManageRelationshipController::deleteRelationship:: connections using relationship."
						+ relationshipProcess.getRelationship().getId());

				request.setAttribute("relId", relationshipProcess.getRelationship().getId());
				request.getSession().setAttribute("errorMessageDelete",
						"Relationship is in use by a connection and so it can't be edited / deleted.");

				forwardPage = "forward:/loadRelationship.act";
			} else {
				// if the connection is not used in any connection, proceed for
				// delete
				try {
					// delete contacts, location and thirdparty details
					relationshipProcess.deleteRelationshipReferences(relationshipProcess.getRelationship());
					log.debug(
							"ManageRelationshipController::deleteRelationship::deleteRelationshipReferences completed ..."
									+ relationshipProcess.getRelationship().getId());

					// delete relationship and region, sector, business unit
					// details
					relationshipProcess.deleteRelationshipDetails(relationshipProcess.getRelationship());
					log.debug(
							"ManageRelationshipController::deleteRelationship::deleteRelationshipDetails completed ..."
									+ relationshipProcess.getRelationship().getId());
				} catch (Exception e) {
					log.error(e, e);
					e.printStackTrace();
				}
			}
		} else {// if relationship not exists, display the error
			log.debug("ManageRelationshipController::deleteRelationship:: Error while deleting relationship details");
			request.getSession().setAttribute("errorMessageDelete", "Error while deleting relationship details");
		}

		model.addAttribute("relationshipProcess", relationshipProcess);
		log.info("ManageRelationshipController::deleteRelationship methods ends...forwardPage ==> " + forwardPage);

		return forwardPage;
	}

	// load default values for new relationship
	@RequestMapping(value = "/addRelationship.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String addRelationship(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess,
			HttpServletRequest request) {
		String addNewRelationshipforwardPage = "c3par.relationship.addEditRelationship";
		String addNewRelationshipCreateConnectionforwardPage = "c3par.relationship.addNewRelationshipCreateConnection";
		String pageNavigationFrom = request.getParameter("relationshipPageFrom");
		String connectionName = relationshipProcess.getConnectionName();
		log.info(" addRelationship connectionName  value ::" + connectionName);
		Relationship relationship = new Relationship();
		if (relationshipProcess != null && relationshipProcess.getRelationship() != null
				&& relationshipProcess.getRelationship().getRelationshipType() != null
				&& !relationshipProcess.getRelationship().getRelationshipType().isEmpty()) {
			log.info("ManageRelationshipController::setNewRelationshipValues. if... setRelationshipType ==> "
					+ relationshipProcess.getRelationship().getRelationshipType());
			relationship.setRelationshipType(relationshipProcess.getRelationship().getRelationshipType());
		} else {
			log.info("ManageRelationshipController::setNewRelationshipValues else part ");
			relationship.setRelationshipType("THIRD_PARTY");
		}
		relationshipProcess = new RelationshipProcess();
		relationshipProcess.setRegList(relationshipProcess.getRegionList());
		relationshipProcess.setRegListSize(relationshipProcess.getRegionList().size());
		relationshipProcess.setSecList(new ArrayList<Sector>());
		relationshipProcess.setBusUnitList(new ArrayList<BusinessUnit>());
		relationshipProcess.setSector(new Sector());
		relationshipProcess.setBusinessUnit(new BusinessUnit());
		relationship.setId(0L);
		relationship.setAccessCitiData("N");
		relationship.setAccessCustomerData("N");
		relationship.setCobRedundencyReq("N");
		relationship.setConnectivityExists("N");
		relationship.setDataIsPublic("N");
		relationship.setGnccApprovalAttained("N");
		relationship.setIsoutsourceProvider("N");
		relationship.setDeleted("N");
		relationship.setRequestDate(new Date());
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.THIRD_PARTY)
				|| relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.U_TURN)) {
			relationship.setThirdParty(new ThirdParty());
			relationship.setUturnThirdParty(new ThirdParty());
		}

		relationship.setRequesterResourceType(new ResourceType());
		relationship.setTargetResourceType(new ResourceType());
		relationship.getRequesterResourceType().setId(0L);
		relationship.getTargetResourceType().setId(0L);

		// set default resource type based on relationship type
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE)
				|| relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)
				|| relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)) {
			relationship.getRequesterResourceType().setPerimeter(C3parStaticNames.INTERNAL);
		} else {
			relationship.getRequesterResourceType().setPerimeter(C3parStaticNames.EXTERNAL);
		}

		List<ResourceType> reqrestypelst = new ArrayList<ResourceType>();
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)) {
			reqrestypelst.add(relationshipProcess.getResourceTypeByName(PORT_RES_TYPE));
			relationship.setRequesterResourceType(reqrestypelst.get(0));
		} else {
			reqrestypelst = relationshipProcess
					.getResourceTypeByPerimeter(relationship.getRequesterResourceType().getPerimeter());
		}
		relationshipProcess.setRequesterResourceTypeList(reqrestypelst);

		relationship.getTargetResourceType().setPerimeter(C3parStaticNames.INTERNAL);
		List<ResourceType> tarrestypelst = new ArrayList<ResourceType>();
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE)) {
			tarrestypelst.add(relationshipProcess.getResourceTypeByName(IP_RES_TYPE));
			relationship.setTargetResourceType(tarrestypelst.get(0));
		} else if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)) {
			tarrestypelst.add(relationshipProcess.getResourceTypeByName(PORT_RES_TYPE));
			relationship.setTargetResourceType(tarrestypelst.get(0));
		} else if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)) {
			tarrestypelst.add(relationshipProcess.getResourceTypeByName(C3parStaticNames.TEMPLATE));
			relationship.setTargetResourceType(tarrestypelst.get(0));
		} else {
			tarrestypelst = relationshipProcess
					.getResourceTypeByPerimeter(relationship.getTargetResourceType().getPerimeter());
		}
		relationshipProcess.setTargetResourceTypeList(tarrestypelst);
		relationshipProcess.setRelationship(relationship);
		relationshipProcess.setRelationshipMode(ADD);
		// set RelationshipEntity default values which is used to load Contacts,
		// ThirdParty and Locations popup
		relationshipProcess.setCanEdit(Boolean.TRUE);
		relationshipProcess.setPerform(SAVE_CONTINUE);
		relationshipProcess.setIsConnection(FALSE);
		relationshipProcess.setRelationshipType(relationshipProcess.getRelationship().getRelationshipType());
		if (!StringUtil.isNullorEmpty(connectionName))
			relationshipProcess.setConnectionName(connectionName);
		setInSession(request, relationshipProcess);
		model.addAttribute("relationshipProcess", relationshipProcess);
		log.info("ManageRelationshipController::addRelationship methods ends...forwardPage ==> "
				+ addNewRelationshipforwardPage);
		if (pageNavigationFrom != null && pageNavigationFrom.equals("CreateRelationshipPage")) {
			log.info("CreateRelationshipPage::addRelationship methods ends...forwardPage ==> " + pageNavigationFrom);
			return addNewRelationshipforwardPage;
		} else {
			log.info("addNewRelationshipCreateConnectionforwardPage::addRelationship methods ends...forwardPage ==> "
					+ pageNavigationFrom);
			return addNewRelationshipCreateConnectionforwardPage;
		}
	}

	// Save the new or existing relationship details
	@RequestMapping(value = "/saveRelationship.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String saveRelationship(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess, BindingResult result,
			HttpServletRequest request) {
		log.info("ManageRelationshipController::saveRelationship methods starts..");
		String forward = "";
		String ssoId = request.getHeader("SM_USER").toLowerCase();
		String action = (String) request.getParameter("perform");
		log.info("  action  value is ::  " + action);
		Relationship relationship = relationshipProcess.getRelationship();
		Long relId = 0L;
		Long tiRequestId = null;
		List<String> errorMessages = new ArrayList<String>();
		validateRelationship(relationshipProcess, errorMessages, request);
		if (!StringUtil.isNullorEmpty(request.getParameter("tiRequestId")))
			tiRequestId = Long.parseLong(request.getParameter("tiRequestId"));
		log.info("tiRequestId  value ::" + tiRequestId);
		if (action != null && (action.equalsIgnoreCase(SAVE) || action.equalsIgnoreCase(SAVE_CONTINUE))
				&& (relationship.getId() == null || relationship.getId().longValue() <= 0)) {
			log.info("ManageRelationshipController::saveRelationship:: save default values for new relationship");
			// if the relationship is new then set default values before saving
			relationship.setRequesterId(ssoId);
			relationship.setEstRevenueGenerated(0.0);
			relationship.setEstCostSaving(0.0);
			relationship.setOneTimeCost(0.0);
			relationship.setMonthlyCost(0.0);
			setDefaultValuesForSave(relationshipProcess, relationship);
		}
		// validateDuplicateRelationship(relationshipProcess, errorMessages,
		// request);
		// if there is no error then save / update relationship
		log.info("");
		if (errorMessages == null || errorMessages.isEmpty()) {
			// check whether relationship is new or existing
			log.info("relationship.getId()  value is:: " + relationship.getId());
			if (action != null && (action.equalsIgnoreCase(SAVE) || action.equalsIgnoreCase(SAVE_CONTINUE))
					&& (relationship.getId() == null || relationship.getId().longValue() <= 0)) {
				log.info("ManageRelationshipController::relationship status - " + relationship.getStatus());
				CoLookupData lookupdata = new CoLookupData();
				// set the common lookup data id into relationship
				relationship.setLookupId(lookupdata);
				// save relationship details
				relId = relationshipProcess.saveRelationshipDetails(relationship);
				log.info("relId value :: " + relId);
				// save region, sector and business unit details
				if (!StringUtil.isNullorEmpty(relationshipProcess.getSelectedRegions()))
					relationshipProcess.saveRegSecBuForRel(relId, relationshipProcess.getSelectedRegions(),
							relationshipProcess.getSector().getId(), relationshipProcess.getBusinessUnit().getId());
			} else if (action != null && (action.equalsIgnoreCase("update") || action.equalsIgnoreCase(UPDATE_CONTINUE)
					|| action.equalsIgnoreCase("updateStatus"))) {
				// if the relationship is already exists, the update it
				log.info(
						"ManageRelationshipController::saveRelationship::action-update:: update existing relationship - "
								+ relationship.getId());

				String oldRelStatus = relationshipProcess.getRelationshipStatus(relationship.getId());
				log.info("ManageRelationshipController::saveRelationship::action-update:: oldRelStatus - "
						+ oldRelStatus + "::status - " + relationship.getStatus());

				relationshipProcess.updateConnectionName(relationshipProcess.getConnectionName(),
						relationshipProcess.getConnectionId());

				log.info(" id: " + relationshipProcess.getRelationship().getId() + " requestor resource type id:" + " "
						+ relationshipProcess.getRelationship().getRequesterResourceType().getId() + " target id :: "
						+ relationshipProcess.getRelationship().getTargetResourceType().getId());
				// update resource type detail in relationship tables.
				relationshipProcess.updateResourceType(relationshipProcess.getRelationship().getId(),
						relationshipProcess.getRelationship().getRequesterResourceType().getId(),
						relationshipProcess.getRelationship().getTargetResourceType().getId());

				// If relationship is not certified then update relationship
				// details like relationship info, status, region, sector,
				// businessUnit
				if (action.equalsIgnoreCase("updateStatus")) {
					relationship.setStatus(C3parStatusLookupNames.CERTIFIED);
				}
				// set existing region, sector and business unit details
				relationship.setRelcitiHierarchyXrefs(
						relationshipProcess.getRelationshipCitiHierarchy(relationship.getId()));
				log.info(
						"ManageRelationshipController::saveRelationship::action-update:: getRelationshipCitiHierarchy - "
								+ relationship.getRelcitiHierarchyXrefs().size());
				// update relationship details
				if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.THIRD_PARTY)
						|| relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.U_TURN)) {
					if (relationship.getThirdParty().getId() == null || relationship.getThirdParty().getId().longValue() == 0) {
						relationship.setThirdParty(null);
					}
					if (relationship.getUturnThirdParty().getId() == null
							|| relationship.getUturnThirdParty().getId().longValue() == 0) {
						relationship.setUturnThirdParty(null);
					}
				}
				relationshipProcess.updateRelationshipDetails(relationship, relationshipProcess.getSelectedRegions(),
						relationshipProcess.getSector().getId(), relationshipProcess.getBusinessUnit().getId());
				// update region, sector and business unit details
				if (!StringUtil.isNullorEmpty(relationshipProcess.getSelectedRegions()))
					relationshipProcess.saveRegSecBuForRel(relationship.getId(),
							relationshipProcess.getSelectedRegions(), relationshipProcess.getSector().getId(),
							relationshipProcess.getBusinessUnit().getId());

				relId = relationshipProcess.getRelationship().getId();
			}
			log.info("relationshipProcess.getIsConnection() ::" + relationshipProcess.getIsConnection());
			if (relationshipProcess.getIsConnection() != null && FALSE.equals(relationshipProcess.getIsConnection())) {
				log.info("Relationship Id" + relId);
				try {
					tiRequestId = createCCRConnection(request, relId.toString(), relationshipProcess);
					relationshipProcess.setTiRequestId(tiRequestId);
					relationshipProcess.setIsConnection(TRUE);
				} catch (Exception e) {
					log.error("Error has occurred while create connection ::" + e.toString());
				}
				log.info("tiRequestId value :: " + tiRequestId);
			}

			// if relationship is successfully created / updated then add /
			// update reference data like contacts, location and third party
			if (relId != null) {
				log.info(
						"ManageRelationshipController::saveRelationship::saveRelationshipReferences:: add/update RelationshipReferences - "
								+ relId);
				// save or update reference data like contacts, location and
				// third party
				RelationshipProcess relprocess = getRelationshipProcess(request);
				relprocess.getRelationship().setId(relId);
				boolean success = relationshipProcess.saveRelationshipReferences(relprocess);
				if (!success) { // if any error while saving reference data then
								// show error message
					request.setAttribute("errorMessage", "Unable to save Contacts/Location data. Please try again");
					setRelationshipValuesForOnLoad(relationshipProcess);
					forward = "c3par.relationship.addEditRelationship";
				}
			}

			if (action.equalsIgnoreCase(SAVE_CONTINUE) && tiRequestId != null) {
				JBPMTaskRef jbpmTaskRef = workflowUtil.getTaskRefByTiRequestId(tiRequestId);
				forward = "forward:/workFlowEventLock.act?forward=bus_jus&tiRequestId=" + jbpmTaskRef.getTiReqId()
						+ "&activityTrailId=" + jbpmTaskRef.getAuditTrailId() + "&activityId=12&taskId="
						+ jbpmTaskRef.getTaskId() + "&lockedBy=null&processId=" + jbpmTaskRef.getConnectionId()
						+ "&bpmActivityId=BusinessJustification&activity=Business Justification&ssoId=" + ssoId;
				log.info("forward  value :: " + forward);
				return forward;
			}

		} else {// if any validation error then display the error message
			if (action != null && action.equalsIgnoreCase("save")) {
				forward = "c3par.relationship.addEditRelationship";

				// set default values and list like region, sector, business
				// unit and resource type
				setRelationshipValuesForOnLoad(relationshipProcess);

				for (String errorMsg : errorMessages) {
					result.addError(new ObjectError("relationshipId", errorMsg));
				}
			} else if (action != null && action.equalsIgnoreCase("update") || action.equalsIgnoreCase("updateStatus")) {
				request.getSession().setAttribute("VALIDATION_ERROR_LIST", errorMessages);
				if (action.equalsIgnoreCase("updateStatus")) {
					relationshipProcess.getRelationship().setStatus(C3parStatusLookupNames.NOT_CERTIFIED);
				}
				forward = "forward:/editRelationship.act";
			}
		}
		if (tiRequestId != null)
			if (relationshipProcess.relationshipBusValidation(tiRequestId)) {
				relationshipProcess.setIsRules(TRUE);
			} else {
				relationshipProcess.setIsRules(FALSE);
			}
		log.info("relationshipProcess.getIsRules() ::" + relationshipProcess.getIsRules());
		if (action != null && action.equalsIgnoreCase(UPDATE_CONTINUE)) {
			forward = "forward:/bpmIntegrationAction.act?fun_code=connectionBusinessCase&tiRequestId=" + tiRequestId;
		} else {
			setRelationshipValuesForOnLoad(relationshipProcess);
			forward = "c3par.relationship.addEditRelationship";
		}

		model.addAttribute("relationshipProcess", relationshipProcess);
		log.info("ManageRelationshipController::saveRelationship methods ends.. forward ==> " + forward
				+ " relationshipID ==> " + relId);
		return forward;
	}

	// update relationship requester / target resource type
	@RequestMapping(value = "/updateRelationshipResourceType.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String updateRelationshipResourceType(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess,
			HttpServletRequest request) {
		log.info("ManageRelationshipController::updateRelationshipResourceType methods starts..");
		String forward = "redirect:/loadRelationshipListController.act?fromPage=saveRelationship";

		// get the logged in user role
		boolean isAdmin = CommonCode.isAdmin(request.getSession());
		boolean isSupportAgent = CommonCode.isSupportAgentRole(request.getSession());

		// check whether logged in user is admin or support agent
		if (isAdmin || isSupportAgent && (relationshipProcess.getRelationship() != null
				&& relationshipProcess.getRelationship().getRequesterResourceType() != null
				&& relationshipProcess.getRelationship().getTargetResourceType() != null)) {
			setDefaultValuesForSave(relationshipProcess, relationshipProcess.getRelationship());
			// update requester / target resource type
			relationshipProcess.updateRelResourceType(relationshipProcess.getRelationship().getId(),
					relationshipProcess.getRelationship().getName(),
					relationshipProcess.getRelationship().getRequesterResourceType().getId(),
					relationshipProcess.getRelationship().getTargetResourceType().getId());
		} else { // if user is not admin or support agent then do not update
			log.info("ManageRelationshipController::updateRelationshipResourceType:: not called.. the values are null");
		}
		log.info("ManageRelationshipController::updateRelationshipResourceType methods ends.. forward ==> " + forward);
		return forward;
	}

	// load third party data into relationship
	@RequestMapping(value = "/loadThirdParties.act", method = { RequestMethod.GET, RequestMethod.POST })
	public String loadThirdParties(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess, HttpServletRequest request,
			BindingResult result) {
		String forwardPage = "c3par.relationship.addEditRelationship";
		log.info("ManageRelationshipController::loadThirdParties method starts ...");

		// get relationship from session
		RelationshipProcess relprocess = getRelationshipProcess(request);

		// set default values
		setRelationshipValuesForOnLoad(relationshipProcess);
		log.info("ManageRelationshipController::setRelationshipValuesForOnLoad after ...");

		// get the third party detail from session
		ThirdPartySearchProcess tpRelInfo = (ThirdPartySearchProcess) request.getSession()
				.getAttribute("thirdPartySearchProcess");

		boolean isValidationError = false;

		if (tpRelInfo != null) {
			// if the third paty detail selected for endpoint A
			log.info("THIRD_PARTY_ID value is ::  " + request.getSession().getAttribute("THIRD_PARTY_ID"));
			if (request.getSession().getAttribute("THIRD_PARTY_ID") != null) {
				isValidationError = validateUTurnThirdParty(request, relationshipProcess, tpRelInfo, "requester");
				log.info("isValidationError  " + isValidationError);
				if (!isValidationError) {
					log.info("THIRD_PARTY_ID " + request.getSession().getAttribute("THIRD_PARTY_ID"));
					relationshipProcess.getRelationship().getThirdParty().setId(
							Long.valueOf(String.valueOf(request.getSession().getAttribute("THIRD_PARTY_ID")).trim()));
					relationshipProcess.getRelationship().getThirdParty().setName(tpRelInfo.getName());
					relationshipProcess.getRelationship().getThirdParty().setParentName(tpRelInfo.getParentName());
					relationshipProcess.getRelationship().getThirdParty().setRegion(tpRelInfo.getRegion());
					relationshipProcess.getRelationship().getThirdParty().setCountry(tpRelInfo.getCountry());
					relationshipProcess.getRelationship().getThirdParty().setMainCategory(tpRelInfo.getMainCategory());
					relationshipProcess.getRelationship().getThirdParty().setSubcategory(tpRelInfo.getSubCategory());

					relationshipProcess.getRelationship().getThirdParty().setCaspId(tpRelInfo.getCaspId());
					relationshipProcess.getRelationship().getThirdParty().setDetailId(tpRelInfo.getDetailId());
					relationshipProcess.getRelationship().getThirdParty().setParentId(tpRelInfo.getParentId());
					log.info("tpRelInfo.getParentName() :: " + tpRelInfo.getParentName());
					request.getSession().removeAttribute("THIRD_PARTY_ID");
					// relprocess.setRequesterThirdPartyContacts(null);
					// relprocess.setRequesterThirdPartyLocations(null);
				}
			}

			// if the third paty detail selected for endpoint B
			if (request.getSession().getAttribute("TARGET_THIRD_PARTY_ID") != null) {
				isValidationError = validateUTurnThirdParty(request, relationshipProcess, tpRelInfo, "target");

				if (!isValidationError) {
					relationshipProcess.getRelationship().getUturnThirdParty().setId(
							Long.valueOf(String.valueOf(request.getSession().getAttribute("TARGET_THIRD_PARTY_ID"))));

					relationshipProcess.getRelationship().getUturnThirdParty()
							.setName(tpRelInfo.getTargetThirdPartyName());
					relationshipProcess.getRelationship().getUturnThirdParty()
							.setParentName(tpRelInfo.getTargetThirdPartyParentName());
					relationshipProcess.getRelationship().getUturnThirdParty()
							.setRegion(tpRelInfo.getTargetThirdPartyRegion());
					relationshipProcess.getRelationship().getUturnThirdParty()
							.setCountry(tpRelInfo.getTargetThirdPartyCountry());
					relationshipProcess.getRelationship().getUturnThirdParty()
							.setMainCategory(tpRelInfo.getTargetThirdPartyMainCategory());
					relationshipProcess.getRelationship().getUturnThirdParty()
							.setSubcategory(tpRelInfo.getTargetThirdPartySubCategory());

					relationshipProcess.getRelationship().getUturnThirdParty().setCaspId(tpRelInfo.getTargetCaspId());
					relationshipProcess.getRelationship().getUturnThirdParty()
							.setDetailId(tpRelInfo.getTargetDetailId());
					relationshipProcess.getRelationship().getUturnThirdParty()
							.setParentId(tpRelInfo.getTargetParentId());

					request.getSession().removeAttribute("TARGET_THIRD_PARTY_ID");
					// relprocess.setTargetThirdPartyContacts(null);
					// relprocess.setTargetThirdPartyLocations(null);
				}
			}
		}

		if (isValidationError) {
			result.addError(new ObjectError("ThirdPartyId",
					"Data should not be same for both target and requester in third party"));
		}
		// remove the third party details from session
		request.getSession().removeAttribute("THIRD_PARTY_LIST");
		request.getSession().removeAttribute("THIRD_PARTY_DETAIL_LIST");

		log.info("ManageRelationshipController::before setRelationshipName ...");

		// form relationship name based on third party details
		setRelationshipName(relationshipProcess);

		// set the relationshipProcess in session which is used in popups like
		// contacts, location etc..
		relprocess.getRelationship().setThirdParty(relationshipProcess.getRelationship().getThirdParty());
		relprocess.getRelationship().setUturnThirdParty(relationshipProcess.getRelationship().getUturnThirdParty());
		relprocess.setRelationshipName(relationshipProcess.getRelationship().getName());
		relprocess.getRelationship().setName(relationshipProcess.getRelationship().getName());
		setInSession(request, relprocess);

		log.info(":relationshipProcess.getRelationshipType():" + relationshipProcess.getRelationshipType());
		log.info("::relationshipProcess.getRelationship().getRelationshipType()::"
				+ relationshipProcess.getRelationship().getRelationshipType());
		model.addAttribute("relationshipProcess", relationshipProcess);
		log.info("ManageRelationshipController::loadThirdParties methods ends...forwardPage ==> " + forwardPage);
		return forwardPage;
	}

	// save requester / target resource types
	@RequestMapping(value = "/saveResourceTypeInSession.act", method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody String saveResourceTypeInSession(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess,
			HttpServletRequest request) {
		log.info("ManageRelationshipController::saveResourceTypeInSession method starts...");
		// get the requester / target resource type from request session
		String reqResourceTypeId = request.getParameter("requesterResourceTypeId");
		String tarResourceTypeId = request.getParameter("targetResourceTypeId");
		log.info("ManageRelationshipController::saveResourceTypeInSession method- requesterResourceTypeId ==> "
				+ reqResourceTypeId + ",targetResourceTypeId==>" + tarResourceTypeId);

		// set the requester / target resource type into RelationshipForm which
		// is used for validation
		RelationshipProcess relprocess = getRelationshipProcess(request);

		if (reqResourceTypeId != null && !reqResourceTypeId.isEmpty()) {
			relprocess.setRequesterResourceTypeId(Long.parseLong(reqResourceTypeId));
		}
		if (tarResourceTypeId != null && !tarResourceTypeId.isEmpty()) {
			relprocess.setTargetResourceTypeId(Long.parseLong(tarResourceTypeId));
		}
		relprocess.setRelReqCitiLocXrefList(null);
		relprocess.setRelCitiLocXrefList(null);
		setInSession(request, relprocess);

		return "";
	}

	// retrieve the resource type options list
	@RequestMapping(value = "/setSelectedResourceType.act", method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody String setSelectedResourceType(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess, HttpServletRequest request)
			throws Exception {

		// get the perimeter from request object
		String perimeterID = request.getParameter("perimeterId").toString();
		String endPoint = request.getParameter("endpoint").toString();
		log.info("ManageRelationshipController::setSelectedResourceType method- perimeterID ==> " + perimeterID
				+ ",endPoint==>" + endPoint);

		StringBuffer resourcetypeJSONSB = new StringBuffer();
		List<ResourceType> resTypeList = new ArrayList<ResourceType>();

		// if requester perimeter is changed, the load requester resource type
		// list
		if (("Request").equals(endPoint)) {
			relationshipProcess
					.setRequesterResourceTypeList(relationshipProcess.getResourceTypeByPerimeter(perimeterID));
			resTypeList = relationshipProcess.getRequesterResourceTypeList();
		} else { // if target perimeter is changed, the load target resource
					// type list
			relationshipProcess.setTargetResourceTypeList(relationshipProcess.getResourceTypeByPerimeter(perimeterID));
			resTypeList = relationshipProcess.getTargetResourceTypeList();
		}

		// set the resource type list in JSON object format
		resourcetypeJSONSB.append("[");
		resourcetypeJSONSB.append("{\"item\":\"\",\"label\":\"---Select a ResourceType---\"}");
		for (ResourceType resType : resTypeList) {
			resourcetypeJSONSB
					.append(",{\"item\":\"" + resType.getId() + "\",\"label\":\"" + resType.getName() + "\"}");
		}
		resourcetypeJSONSB.append("]");
		request.setAttribute("comboValues", resourcetypeJSONSB.toString());

		log.info("ManageRelationshipController::setSelectedResourceType method ends..." + resourcetypeJSONSB);
		return resourcetypeJSONSB.toString();
	}

	private void setDefaultValuesForSave(RelationshipProcess relationshipProcess, Relationship relationship) {
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.U_TURN)
				|| relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.THIRD_PARTY)) {
			relationship.setRequesterResourceType(new ResourceType());
			relationship.setRequesterResourceType(relationshipProcess.getResourceTypeByName(THIRD_RES_TYPE));
		}
		setRelationshipName(relationshipProcess);
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.THIRD_PARTY)
				|| relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.U_TURN)) {
			if (relationship.getThirdParty().getId() == null || relationship.getThirdParty().getId().longValue() == 0) {
				relationship.setThirdParty(null);
			}
			if (relationship.getUturnThirdParty().getId() == null
					|| relationship.getUturnThirdParty().getId().longValue() == 0) {
				relationship.setUturnThirdParty(null);
			}
		}
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.U_TURN)) {
			relationship.setTargetResourceType(new ResourceType());
			relationship.setTargetResourceType(relationshipProcess.getResourceTypeByName(THIRD_RES_TYPE));
		}
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.CITI_CON)
				&& relationshipProcess.getIpreg().equalsIgnoreCase("true")) {
			relationship.setTargetResourceType(null);
		}

		List<ResourceType> reqrestypelst = new ArrayList<ResourceType>();
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)) {
			relationship.setRequesterResourceType(new ResourceType());
			reqrestypelst.add(relationshipProcess.getResourceTypeByName(PORT_RES_TYPE));
			relationship.setRequesterResourceType(reqrestypelst.get(0));
		}
		List<ResourceType> tarrestypelst = new ArrayList<ResourceType>();
		if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE)) {
			relationship.setTargetResourceType(new ResourceType());
			relationship.getTargetResourceType().setPerimeter(C3parStaticNames.INTERNAL);
			tarrestypelst.add(relationshipProcess.getResourceTypeByName(IP_RES_TYPE));
			relationship.setTargetResourceType(tarrestypelst.get(0));
		} else if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)) {
			relationship.setTargetResourceType(new ResourceType());
			relationship.getTargetResourceType().setPerimeter(C3parStaticNames.INTERNAL);
			tarrestypelst.add(relationshipProcess.getResourceTypeByName(PORT_RES_TYPE));
			relationship.setTargetResourceType(tarrestypelst.get(0));
		} else if (relationship.getRelationshipType().equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)) {
			relationship.setTargetResourceType(new ResourceType());
			relationship.getTargetResourceType().setPerimeter(C3parStaticNames.INTERNAL);
			tarrestypelst.add(relationshipProcess.getResourceTypeByName(C3parStaticNames.TEMPLATE));
			relationship.setTargetResourceType(tarrestypelst.get(0));
		}
	}

	private void validateRegSecBuCombination(RelationshipProcess relationshipProcess, List<String> errorMessages) {
		if (!relationshipProcess.validateRegSecBu(relationshipProcess.getSelectedRegions(),
				relationshipProcess.getSector().getId(), relationshipProcess.getBusinessUnit().getId())) {
			errorMessages.add(
					"The business unit selected is not associated with one or more of the checked regions. Please contact the helpdesk for further assistance.");
		}
	}

	private void validateDuplicateRelationship(RelationshipProcess relationshipProcess, List<String> errorMessages,
			HttpServletRequest request) {
		Long relId = relationshipProcess.isRelationShipNameUnique(relationshipProcess.getRelationship());
		if (relId > 0) {
			log.debug("ManageRelationshipController::validateDuplicateRelationship:: duplicate relationship");
			errorMessages.add("Relationship " + relationshipProcess.getRelationship().getName() + " with ID " + relId
					+ " Already Exists, Please Try With Other Combinations.");
		}
	}

	private void validateRelationship(RelationshipProcess relationshipProcess, List<String> errorMessages,
			HttpServletRequest request) {
		String relationship = "true";
		log.info("ManageRelationshipController::validateRelationship .... getIpreg ==> "
				+ relationshipProcess.getIpreg());

		if (StringUtil.isNullorEmpty(relationshipProcess.getConnectionName())) {
			errorMessages.add("Please enter connection name.");
		}

		if (relationshipProcess.getSelectedRegions() == null
				|| relationshipProcess.getSelectedRegions().trim().length() <= 0) {
			errorMessages.add("Please select Region.");

		}
		if (relationshipProcess.getSector() == null || relationshipProcess.getSector().getId() == null
				|| relationshipProcess.getSector().getId() <= 0) {
			errorMessages.add("Please select Sector.");

		}
		if (relationshipProcess.getBusinessUnit() == null || relationshipProcess.getBusinessUnit().getId() == null
				|| relationshipProcess.getBusinessUnit().getId() <= 0) {
			errorMessages.add("Please select BusinessUnit.");

		}

		if (relationshipProcess.getRelationship() != null) {
			if (C3parStaticNames.CITI_IP.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())
					|| C3parStaticNames.IP_TEMPLATE
							.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())
					|| C3parStaticNames.TEMPLATE_OBJ
							.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())
					|| C3parStaticNames.CITI_CON
							.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
				if (relationshipProcess.getRelationship().getRequesterResourceType() == null
						|| relationshipProcess.getRelationship().getRequesterResourceType().getId() == null
						|| relationshipProcess.getRelationship().getRequesterResourceType().getId().longValue() == 0) {
					errorMessages.add("Requester Resource Type is required.");

				}
			}
			boolean targetValidate = false;
			if (C3parStaticNames.CITI_CON.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())
					|| C3parStaticNames.THIRD_PARTY
							.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
				targetValidate = true;
				if (relationshipProcess.getIpreg() != null && relationshipProcess.getIpreg().equalsIgnoreCase("true")) {
					targetValidate = false;
				}
				if (targetValidate && FALSE.equals(relationshipProcess.getIsRules())
						&& (relationshipProcess.getRelationship().getTargetResourceType() == null
								|| relationshipProcess.getRelationship().getTargetResourceType().getId() == null
								|| relationshipProcess.getRelationship().getTargetResourceType().getId()
										.longValue() == 0)) {
					errorMessages.add("Target Resource Type is required.");

				}
			}
		}
		if (relationshipProcess.getRelationship().getStatus() != null && relationshipProcess.getRelationship()
				.getStatus().equalsIgnoreCase(C3parStatusLookupNames.CERTIFIED)) {
			if ((relationshipProcess.getRelationship().getRelationshipType() != null) && (C3parStaticNames.THIRD_PARTY
					.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())
					|| C3parStaticNames.U_TURN
							.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType()))) {
				if (relationshipProcess.getRelationship().getThirdParty().getId() == null
						|| (relationshipProcess.getRelationship().getThirdParty().getId().longValue() == 0)) {
					// errorMessages.add("Third Party not selected.");
					log.info("Error message 6::");
					relationship = "false";
				}
				if (C3parStaticNames.U_TURN
						.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
					if (relationshipProcess.getRelationship().getUturnThirdParty().getId() == null
							|| (relationshipProcess.getRelationship().getUturnThirdParty().getId().longValue() == 0)) {
						// errorMessages.add("Target Third Party not
						// selected.");
						log.info("Error message 7::");
						relationship = "false";
					}
				}
			}
		}

		if ((relationshipProcess.getRelationship().getRelationshipType() != null) && C3parStaticNames.U_TURN
				.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
			if ((relationshipProcess.getRelationship().getThirdParty().getCaspId() != null
					&& relationshipProcess.getRelationship().getUturnThirdParty().getCaspId() != null
					&& relationshipProcess.getRelationship().getThirdParty().getCaspId()
							.longValue() == relationshipProcess.getRelationship().getUturnThirdParty().getCaspId()
									.longValue())
					&& (relationshipProcess.getRelationship().getThirdParty().getDetailId() != null
							&& relationshipProcess.getRelationship().getUturnThirdParty().getDetailId() != null
							&& relationshipProcess.getRelationship().getThirdParty().getDetailId()
									.longValue() == relationshipProcess.getRelationship().getUturnThirdParty()
											.getDetailId().longValue())
					&& (relationshipProcess.getRelationship().getThirdParty().getParentId() != null
							&& relationshipProcess.getRelationship().getUturnThirdParty().getParentId() != null
							&& relationshipProcess.getRelationship().getThirdParty().getParentId()
									.longValue() == relationshipProcess.getRelationship().getUturnThirdParty()
											.getParentId().longValue())) {
				// errorMessages.add("Data should not be same for both target
				// and requester in third party");
				log.info("Error message 8::");
				relationship = "false";
			}
		}
		RelationshipProcess sessionrelprocess = getRelationshipProcess(request);

		if (relationshipProcess.getRelationship().getStatus() != null && relationshipProcess.getRelationship()
				.getStatus().equalsIgnoreCase(C3parStatusLookupNames.CERTIFIED)) {
			log.info("Error message 9::");
			GenericHelper genHelper = new GenericHelper();
			RelationshipValidator relValidator = new RelationshipValidator();

			if (C3parStaticNames.THIRD_PARTY
					.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
				if (!relValidator.isUTurnCitiContactExist(null, sessionrelprocess.getRelCitiContXrefList())) {
					// errorMessages.add("Missing Employees for ISO and
					// Technical Coordinator in relationship");
					relationship = "false";
				}
				if (!relValidator.isThirdPartyContactExist(sessionrelprocess.getRequesterThirdPartyContacts(),
						relationshipProcess.getRelationship().getThirdParty().getId())) {
					// errorMessages.add("Atleast one Third party contacts
					// should be assigned to the relationship before it can get
					// certified");
					relationship = "false";
				}
				if (((genHelper.chkIsZero(relationshipProcess.getRelationship().getThirdParty().getParentId())
						|| genHelper.chkIsZero(relationshipProcess.getRelationship().getThirdParty().getCaspId())
						|| genHelper.chkIsNull(relationshipProcess.getRelationship().getThirdParty().getRegion())
						|| genHelper.chkIsNull(relationshipProcess.getRelationship().getThirdParty().getCountry())
						|| genHelper.chkIsNull(relationshipProcess.getRelationship().getThirdParty().getMainCategory())
						|| genHelper
								.chkIsNull(relationshipProcess.getRelationship().getThirdParty().getSubcategory())))) {
					// errorMessages.add("CaspKeys should be assigned to the
					// relationship before it can get certified");
					relationship = "false";
				}
			} /*
				 * else if (C3parStaticNames.CITI_CON.equalsIgnoreCase(
				 * relationshipProcess.getRelationship().getRelationshipType()))
				 * { if (!relValidator.isCitiContactExist(sessionrelprocess.
				 * getRelReqCitiContactXrefList(),null)) { //errorMessages.add(
				 * "Atleast one Requester Citigroup contacts should be assigned to the relationship before it can get certified"
				 * ); relationship="false"; } } else if
				 * (C3parStaticNames.U_TURN.equalsIgnoreCase(relationshipProcess
				 * .getRelationship().getRelationshipType())) { if
				 * (!relValidator.isCitiContactExist(sessionrelprocess.
				 * getRelReqCitiContactXrefList(),null)) { //errorMessages.add(
				 * "Atleast one Requester Citigroup contacts should be assigned to the relationship before it can get certified"
				 * ); relationship="false";
				 * 
				 * } }
				 */ else if (C3parStaticNames.CITI_IP
					.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
				/*
				 * if (!relValidator.isCitiContactExist(sessionrelprocess.
				 * getRelReqCitiContactXrefList(),null)) { errorMessages.add(
				 * "Atleast one Requester Citigroup contacts should be assigned to the relationship before it can get certified"
				 * ); relationship="false"; } if
				 * (!relValidator.isISOCitiContactExist(sessionrelprocess.
				 * getRelReqCitiContactXrefList(),null)){ errorMessages.add(
				 * "Missing Employee for ISO in relationship");
				 * relationship="false"; }
				 * 
				 * if (!relValidator.isUTurnCitiContactExist(sessionrelprocess.
				 * getRelReqCitiContactXrefList(),null)){ errorMessages.add(
				 * "Missing Employees for ISO and Technical Coordinator in relationship"
				 * ); }
				 * 
				 */

				if (!relValidator.isThirdPartyContactExist(sessionrelprocess.getRequesterThirdPartyContacts(),
						relationshipProcess.getRelationship().getThirdParty().getId())) {
					errorMessages.add(
							"Atleast one Third party contacts should be assigned to the relationship before it can get certified");
				}

				if (((genHelper.chkIsZero(relationshipProcess.getRelationship().getThirdParty().getParentId())
						|| genHelper.chkIsZero(relationshipProcess.getRelationship().getThirdParty().getCaspId())
						|| genHelper.chkIsNull(relationshipProcess.getRelationship().getThirdParty().getRegion())
						|| genHelper.chkIsNull(relationshipProcess.getRelationship().getThirdParty().getCountry())
						|| genHelper.chkIsNull(relationshipProcess.getRelationship().getThirdParty().getMainCategory())
						|| genHelper
								.chkIsNull(relationshipProcess.getRelationship().getThirdParty().getSubcategory())))) {
					// errorMessages.add("CaspKeys should be assigned to the
					// relationship before it can get certified");
					relationship = "false";
				}

				/*
				 * if(!relValidator.isThirdPartyContactExist(sessionrelprocess.
				 * getRequesterThirdPartyContacts(),
				 * relationshipProcess.getRelationship().getUturnThirdParty().
				 * getId())){ errorMessages.add(
				 * "Atleast one Target Third party contacts should be assigned to the relationship before it can get certified"
				 * ); }
				 */
				if (((genHelper.chkIsZero(relationshipProcess.getRelationship().getUturnThirdParty().getParentId())
						|| genHelper.chkIsZero(relationshipProcess.getRelationship().getUturnThirdParty().getCaspId())
						|| genHelper.chkIsNull(relationshipProcess.getRelationship().getUturnThirdParty().getRegion())
						|| genHelper.chkIsNull(relationshipProcess.getRelationship().getUturnThirdParty().getCountry())
						|| genHelper
								.chkIsNull(relationshipProcess.getRelationship().getUturnThirdParty().getMainCategory())
						|| genHelper.chkIsNull(
								relationshipProcess.getRelationship().getUturnThirdParty().getSubcategory())))) {
					// errorMessages.add("Target CaspKeys should be assigned to
					// the relationship before it can get certified");
					relationship = "false";
				}
			}
			/*
			 * else if(C3parStaticNames.IP_TEMPLATE.equalsIgnoreCase(
			 * relationshipProcess.getRelationship().getRelationshipType())){ if
			 * (!relValidator.isUTurnCitiContactExist(null,sessionrelprocess.
			 * getRelCitiContXrefList())){ errorMessages.add(
			 * "Missing Employees for ISO and Technical Coordinator in relationship"
			 * ); } }else if(C3parStaticNames.PORT_TEMPLATE.equalsIgnoreCase(
			 * relationshipProcess.getRelationship().getRelationshipType())){ if
			 * (!relValidator.isUTurnCitiContactExist(null,sessionrelprocess.
			 * getRelCitiContXrefList())){ errorMessages.add(
			 * "Missing Employees for ISO and Technical Coordinator in relationship"
			 * ); } } else if(C3parStaticNames.TEMPLATE_OBJ.equalsIgnoreCase(
			 * relationshipProcess.getRelationship().getRelationshipType())){ if
			 * (!relValidator.isUTurnCitiContactExist(null,sessionrelprocess.
			 * getRelCitiContXrefList())){ errorMessages.add(
			 * "Missing Employees for ISO and Technical Coordinator in relationship"
			 * ); } }
			 */
		}
		// request.getSession().setAttribute("isRelationshipComplete",
		// relationship);
		log.info("ManageRelationshipController::validateRelationship methods ends.. errorMessages ==> "
				+ errorMessages.size());
	}

	private void loadSectorBuList(RelationshipProcess relationshipProcess) {
		log.debug("ManageRelationshipController::loadSectorBuList methods starts...");
		StringBuilder str = new StringBuilder();
		Long secid = 0L;

		if (relationshipProcess.getRelationship().getRelcitiHierarchyXrefs() != null
				&& relationshipProcess.getRelationship().getRelcitiHierarchyXrefs().size() > 0) {
			log.debug("ManageRelationshipController::loadSectorBuList:: RelcitiHierarchyXrefs available");
			for (RelCitiHierarchyXref xrefs : relationshipProcess.getRelationship().getRelcitiHierarchyXrefs()) {
				str.append(xrefs.getCitiHierarchyMaster().getRegion().getId() + ",");
				secid = xrefs.getCitiHierarchyMaster().getSector().getId();
				relationshipProcess.setSector(xrefs.getCitiHierarchyMaster().getSector());
				relationshipProcess.setBusinessUnit(xrefs.getCitiHierarchyMaster().getBusinessUnit());
			}
			if (str != null && str.length() > 0) {
				relationshipProcess.setSelectedRegions(str.substring(0, str.length() - 1));
				relationshipProcess
						.setSecList(relationshipProcess.getSectorList(relationshipProcess.getSelectedRegions()));
				relationshipProcess.setBusUnitList(
						relationshipProcess.getBusinessUnitList(relationshipProcess.getSelectedRegions(), secid));
			}
		} else {
			log.debug("ManageRelationshipController::loadSectorBuList:: RelcitiHierarchyXrefs is null");
			relationshipProcess.setSecList(new ArrayList<Sector>());
			relationshipProcess.setBusUnitList(new ArrayList<BusinessUnit>());
		}
		log.debug("ManageRelationshipController::loadSectorBuList methods Ends...");
	}

	private void loadResourceTypeList(RelationshipProcess relationshipProcess) {
		List<ResourceType> reqrestypelst = new ArrayList<ResourceType>();
		if (relationshipProcess.getRelationship().getRelationshipType()
				.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)) {
			reqrestypelst.add(relationshipProcess.getResourceTypeByName(PORT_RES_TYPE));
		} else {
			reqrestypelst = relationshipProcess.getResourceTypeByPerimeter(
					relationshipProcess.getRelationship().getRequesterResourceType().getPerimeter());
		}
		relationshipProcess.setRequesterResourceTypeList(reqrestypelst);

		List<ResourceType> tarrestypelst = new ArrayList<ResourceType>();
		if (relationshipProcess.getRelationship().getRelationshipType()
				.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE)) {
			tarrestypelst.add(relationshipProcess.getResourceTypeByName(IP_RES_TYPE));
		} else if (relationshipProcess.getRelationship().getRelationshipType()
				.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)) {
			tarrestypelst.add(relationshipProcess.getResourceTypeByName(PORT_RES_TYPE));
		} else if (relationshipProcess.getRelationship().getRelationshipType()
				.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)) {
			tarrestypelst.add(relationshipProcess.getResourceTypeByName(C3parStaticNames.TEMPLATE));
		} else if (relationshipProcess.getRelationship().getTargetResourceType() != null
				&& relationshipProcess.getRelationship().getTargetResourceType().getPerimeter() != null) {
			tarrestypelst = relationshipProcess.getResourceTypeByPerimeter(
					relationshipProcess.getRelationship().getTargetResourceType().getPerimeter());
		}

		if (relationshipProcess.getRelationship().getRelationshipType().equalsIgnoreCase(C3parStaticNames.CITI_CON)
				&& (relationshipProcess.getRelationship().getTargetResourceType() == null
						|| relationshipProcess.getRelationship().getTargetResourceType().getId() == null
						|| relationshipProcess.getRelationship().getTargetResourceType().getId().longValue() == 0)) {
			relationshipProcess.setIpreg("true");
		} else {
			relationshipProcess.setIpreg("false");
		}
		relationshipProcess.setTargetResourceTypeList(tarrestypelst);
	}

	private void setRelationshipValuesForOnLoad(RelationshipProcess relationshipProcess) {
		relationshipProcess.setRegList(relationshipProcess.getRegionList());
		relationshipProcess.setRegListSize(relationshipProcess.getRegList().size());
		String regionIDs = "";
		if (relationshipProcess.getSelectedRegions() != null
				&& relationshipProcess.getSelectedRegions().trim().length() > 0) {
			regionIDs = relationshipProcess.getSelectedRegions();
			log.info("ManageRelationshipController::loadThirdParties ==>LOADING SECTOR-" + regionIDs);
			List<Sector> sectorList = relationshipProcess.getSectorList(regionIDs);
			relationshipProcess.setSecList(sectorList);
		} else {
			relationshipProcess.setSecList(new ArrayList<Sector>());
		}
		Long sectorID = 0L;
		if (relationshipProcess.getSector().getId() != null
				&& Long.valueOf(relationshipProcess.getSector().getId()) > 0) {
			sectorID = relationshipProcess.getSector().getId();
			log.info("ManageRelationshipController::loadThirdParties ==>LOADING BUSINESS UNIT-regionID-" + regionIDs
					+ "-sectorID-" + sectorID);
			List<BusinessUnit> buList = relationshipProcess.getBusinessUnitList(regionIDs, sectorID);
			relationshipProcess.setBusUnitList(buList);
		} else {
			relationshipProcess.setBusUnitList(new ArrayList<BusinessUnit>());
		}
		loadResourceTypeList(relationshipProcess);
	}

	private boolean validateUTurnThirdParty(HttpServletRequest request, RelationshipProcess relationshipProcess,
			ThirdPartySearchProcess tpRelInfo, String endpoint) {
		boolean isError = false;
		if ("requester".equals(endpoint)) {
			if (relationshipProcess.getRelationship().getUturnThirdParty() != null
					&& relationshipProcess.getRelationship().getThirdParty() != null
					&& (relationshipProcess.getRelationship().getUturnThirdParty().getCaspId() != null
							&& tpRelInfo.getCaspId() != null
							&& relationshipProcess.getRelationship().getUturnThirdParty().getCaspId()
									.longValue() == tpRelInfo.getCaspId().longValue())
					&& (relationshipProcess.getRelationship().getUturnThirdParty().getDetailId() != null
							&& tpRelInfo.getDetailId() != null
							&& relationshipProcess.getRelationship().getUturnThirdParty().getDetailId()
									.longValue() == tpRelInfo.getDetailId().longValue())
					&& (relationshipProcess.getRelationship().getUturnThirdParty().getParentId() != null
							&& tpRelInfo.getParentId() != null
							&& relationshipProcess.getRelationship().getUturnThirdParty().getParentId()
									.longValue() == tpRelInfo.getParentId().longValue())) {

				// addFieldError(ERROR_FIELD,"Data should not be same for both
				// target and requester in third party");
				request.getSession().removeAttribute("THIRD_PARTY_ID");
				isError = true;
			}
		} else if ("target".equals(endpoint)) {
			if (relationshipProcess.getRelationship().getUturnThirdParty() != null
					&& relationshipProcess.getRelationship().getThirdParty() != null
					&& (relationshipProcess.getRelationship().getThirdParty().getCaspId() != null
							&& tpRelInfo.getTargetCaspId() != null
							&& relationshipProcess.getRelationship().getThirdParty().getCaspId()
									.longValue() == tpRelInfo.getTargetCaspId().longValue())
					&& (relationshipProcess.getRelationship().getThirdParty().getDetailId() != null
							&& tpRelInfo.getTargetDetailId() != null
							&& relationshipProcess.getRelationship().getThirdParty().getDetailId()
									.longValue() == tpRelInfo.getTargetDetailId().longValue())
					&& (relationshipProcess.getRelationship().getThirdParty().getParentId() != null
							&& tpRelInfo.getTargetParentId() != null
							&& relationshipProcess.getRelationship().getThirdParty().getParentId()
									.longValue() == tpRelInfo.getTargetParentId().longValue())) {

				// addFieldError(ERROR_FIELD,"Data should not be same for both
				// target and requester in third party");
				request.getSession().removeAttribute("TARGET_THIRD_PARTY_ID");
				isError = true;
			}
		}
		log.debug("ManageRelationshipController::validateUTurnThirdParty " + " :: endpoint - " + endpoint
				+ " :: isError - " + isError);
		return isError;
	}

	private void setRelationshipName(RelationshipProcess relationshipProcess) {
		String region = "", sector = "", businessUnit = "", reqrestype = "", tarrestype = "";
		if (relationshipProcess.getSelectedRegions() != null
				&& relationshipProcess.getSelectedRegions().trim().length() != 0) {
			log.debug("ManageRelationshipController::setRelationshipName regionIDs..."
					+ relationshipProcess.getSelectedRegions());
			List<Region> reglist = relationshipProcess.getRegionForIds(relationshipProcess.getSelectedRegions());
			for (Region reg : reglist) {
				region = region + reg.getName() + "-";
			}
		}
		if (relationshipProcess.getSector() != null && relationshipProcess.getSector().getId() != null) {
			log.debug("ManageRelationshipController::setRelationshipName Sector..."
					+ relationshipProcess.getSector().getId());
			relationshipProcess.setSector(relationshipProcess.getSectorForId(relationshipProcess.getSector().getId()));
			sector = relationshipProcess.getSector().getName();
		}
		if (relationshipProcess.getBusinessUnit() != null && relationshipProcess.getBusinessUnit().getId() != null) {
			log.debug("ManageRelationshipController::setRelationshipName BusinessUnit..."
					+ relationshipProcess.getBusinessUnit().getId());
			relationshipProcess.setBusinessUnit(
					relationshipProcess.getBusinessUnitForId(relationshipProcess.getBusinessUnit().getId()));
			businessUnit = relationshipProcess.getBusinessUnit().getBusinessName();
		}
		if (relationshipProcess.getRelationship().getRequesterResourceType() != null
				&& relationshipProcess.getRelationship().getRequesterResourceType().getId() != null) {
			log.debug("ManageRelationshipController::setRelationshipName RequesterResourceType..."
					+ relationshipProcess.getRelationship().getRequesterResourceType().getId());
			relationshipProcess.getRelationship().setRequesterResourceType(relationshipProcess
					.getResourceType(relationshipProcess.getRelationship().getRequesterResourceType().getId()));
			reqrestype = relationshipProcess.getRelationship().getRequesterResourceType().getName();
		}
		if (relationshipProcess.getRelationship().getTargetResourceType() != null
				&& relationshipProcess.getRelationship().getTargetResourceType().getId() != null) {
			log.debug("ManageRelationshipController::setRelationshipName TargetResourceType..."
					+ relationshipProcess.getRelationship().getTargetResourceType().getId());
			relationshipProcess.getRelationship().setTargetResourceType(relationshipProcess
					.getResourceType(relationshipProcess.getRelationship().getTargetResourceType().getId()));
			tarrestype = relationshipProcess.getRelationship().getTargetResourceType().getName();
		}

		if ((relationshipProcess.getRelationship().getRelationshipType() != null)
				&& "THIRD_PARTY".equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
			relationshipProcess.getRelationship().setName(region + sector + "-" + businessUnit + "-"
					+ ((relationshipProcess.getRelationship().getThirdParty().getName() == null
							|| relationshipProcess.getRelationship().getThirdParty().getName().trim().length() == 0)
									? "3rdParty" : relationshipProcess.getRelationship().getThirdParty().getName())
					+ "-" + tarrestype);
		} else if ((relationshipProcess.getRelationship().getRelationshipType() != null)
				&& "CITI_CON".equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
			relationshipProcess.getRelationship()
					.setName(region + sector + "-" + businessUnit + "-" + reqrestype + "-" + tarrestype);
		} else if ((relationshipProcess.getRelationship().getRelationshipType() != null) && C3parStaticNames.IP_TEMPLATE
				.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
			relationshipProcess.getRelationship()
					.setName("IPT-" + region + sector + "-" + businessUnit + "-" + reqrestype);
		} else if ((relationshipProcess.getRelationship().getRelationshipType() != null)
				&& C3parStaticNames.PORT_TEMPLATE
						.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
			relationshipProcess.getRelationship().setName("PTT-" + region + sector + "-" + businessUnit);
		} else if ((relationshipProcess.getRelationship().getRelationshipType() != null)
				&& C3parStaticNames.TEMPLATE_OBJ
						.equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
			relationshipProcess.getRelationship()
					.setName("FWT-" + region + sector + "-" + businessUnit + "-" + reqrestype);
		} else if ((relationshipProcess.getRelationship().getRelationshipType() != null)
				&& "CITI_IP".equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
			relationshipProcess.getRelationship().setName(region + sector + "-" + businessUnit + "-" + reqrestype);
		} else if ((relationshipProcess.getRelationship().getRelationshipType() != null)
				&& "U_TURN".equalsIgnoreCase(relationshipProcess.getRelationship().getRelationshipType())) {
			relationshipProcess.getRelationship().setName(region + sector + "-" + businessUnit + "-"
					+ ((relationshipProcess.getRelationship().getThirdParty().getName() == null
							|| relationshipProcess.getRelationship().getThirdParty().getName().trim().length() == 0)
									? "3rdParty" : relationshipProcess.getRelationship().getThirdParty().getName())
					+ "-" + (relationshipProcess.getRelationship().getUturnThirdParty().getName() == null ? "3rdParty"
							: relationshipProcess.getRelationship().getUturnThirdParty().getName()));
		}
		log.info("ManageRelationshipController::setRelationshipName getRelationship.getName...."
				+ relationshipProcess.getRelationship().getName());
	}

	@RequestMapping(value = "/loadSector.act", method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody String loadSector(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess,
			HttpServletRequest request) {
		log.info("ManageRelationshipController::loadSector method starts...");
		String regionIDs = request.getParameter("regionIDs");
		log.debug("ManageRelationshipController::loadSector regionIDs..." + regionIDs);
		List<Sector> sectorList = relationshipProcess.getSectorList(regionIDs);
		relationshipProcess.setSecList(sectorList);
		StringBuffer sectorJSONSB = new StringBuffer();
		sectorJSONSB.append("[");
		sectorJSONSB.append("{\"item\":\"\",\"label\":\"---Select Sector---\"}");
		for (Sector sector : sectorList) {
			sectorJSONSB.append(",{\"item\":\"" + sector.getId() + "\",\"label\":\"" + sector.getName() + "\"}");
		}
		sectorJSONSB.append("]");
		request.setAttribute("comboValues", sectorJSONSB.toString());
		log.info("ManageRelationshipController::loadSector method ends...");
		return sectorJSONSB.toString();
	}

	@RequestMapping(value = "/loadBusinessUnit.act", method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody String loadBusinessUnit(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess,
			HttpServletRequest request) {
		log.info("ManageRelationshipController::loadBusinessUnit method starts...");
		String regionIDs = request.getParameter("regionIDs");
		Long sectorID = Long.parseLong(request.getParameter("sectorID"));
		log.debug("ManageRelationshipController::loadBusinessUnit regionIDs..." + regionIDs);
		List<BusinessUnit> bulist = relationshipProcess.getBusinessUnitList(regionIDs, sectorID);
		relationshipProcess.setBusUnitList(bulist);
		StringBuffer businessunitJSONSB = new StringBuffer();
		businessunitJSONSB.append("[");
		businessunitJSONSB.append("{\"item\":\"\",\"label\":\"---Select Business Unit---\"}");
		for (BusinessUnit businessunit : bulist) {
			businessunitJSONSB.append(",{\"item\":\"" + businessunit.getId() + "\",\"label\":\""
					+ businessunit.getBusinessName() + "\"}");
		}
		businessunitJSONSB.append("]");
		request.setAttribute("comboValues", businessunitJSONSB.toString());

		RelationshipProcess relprocess = getRelationshipProcess(request);
		relprocess.setSector(relationshipProcess.getSectorForId(sectorID)); // .getName()
		setInSession(request, relprocess);

		log.info("ManageRelationshipController::loadBusinessUnit method ends...");
		return businessunitJSONSB.toString();
	}

	@RequestMapping(value = "/setBusinessUnit.act", method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody String setBusinessUnit(ModelMap model,
			@ModelAttribute("relationshipProcess") RelationshipProcess relationshipProcess,
			HttpServletRequest request) {
		log.info("ManageRelationshipController::setBusinessUnit method starts...");
		Long businessUnitId = Long.parseLong(request.getParameter("businessUnitId"));

		RelationshipProcess relprocess = getRelationshipProcess(request);
		relprocess.setSector(relationshipProcess.getSectorForId(relationshipProcess.getSector().getId()));
		relprocess.setBusinessUnit(relationshipProcess.getBusinessUnitForId(businessUnitId));
		setRelationshipName(relationshipProcess);
		relprocess.setRelationshipName(relationshipProcess.getRelationship().getName());
		relprocess.getRelationship().setName(relationshipProcess.getRelationship().getName());

		relprocess.setRelReqCitiLocXrefList(null);
		relprocess.setRelCitiLocXrefList(null);
		setInSession(request, relprocess);

		log.info("ManageRelationshipController::setBusinessUnit method ends...");
		return "";
	}

	public Long createCCRConnection(HttpServletRequest request, String relId, RelationshipProcess relationshipProcess)
			throws Exception {
		log.info("AgentViewController::createCCRConnection method starts :: " + relId);
		final String NULL_STRING = "null";
		HttpSession session = request.getSession();
		AgentViewProcess agentViewProcess = new AgentViewProcess();
		String connectionName = relationshipProcess.getConnectionName();
		String cmpOrderId = (String) request.getParameter("orderId");
		String relStatus = (String) request.getParameter("relStatus");
		String ssoId = (String) request.getHeader("SM_USER");
		String processType = TIProcess.CONNECTION;
		String priority = "";
		Long tiRequestId = 0L;
		log.info("connectionName::" + connectionName + "::relId::" + relId + "::relStatus::" + relStatus
				+ "::cmpOrderId:: " + cmpOrderId);
		Long relationshipId = 0L;
		if (relId != null) {
			relationshipId = Long.valueOf(relId);
		}
		try {
			if (connectionName != null && relId != null && relStatus != null) {
				if (relStatus.equalsIgnoreCase("NOT CERTIFIED")) {
					priority = TIProcessDTO.BUSCRIT;
				} else {
					priority = TIProcessDTO.BAU;
				}
				TIProcessDTO tiProcessDTO = new TIProcessDTO();
				tiProcessDTO.setName(relationshipProcess.getConnectionName());
				tiProcessDTO.setRelationshipId(relationshipId);
				tiProcessDTO.setProcessType(processType);
				tiProcessDTO.setRequestorSOEId(ssoId);
				tiProcessDTO.setPriority(priority);
				tiRequestId = agentViewProcess.insertProcess(tiProcessDTO);
				request.getSession().setAttribute("tireqid", String.valueOf(tiRequestId));
				log.info("tiRequestId");
				if (tiRequestId != null) {
					log.info("AgentViewController::createCCRConnection method before send to bpm:" + tiRequestId);
					this.intiatePlanningPhase(tiRequestId);
					/*
					 * WsPapiFacade papiCall = new WsPapiFacade();
					 * papiCall.callCreateProcess(
					 * tiProcessDTO.getRequestorSOEId(), tiRequestId,
					 * WsPapiFacade.CreateProcessActivity.FWRequest);
					 */

					if (cmpOrderId != null && !NULL_STRING.equals(cmpOrderId)) {
						int count = agentViewProcess.updateCCRId(cmpOrderId, tiRequestId);
						log.info("CCR Id updated successfully");

						agentViewProcess.updateCmpId(cmpOrderId, tiRequestId);

					}
				}
			}
			if (session.getAttribute("orderId") != null) {
				session.removeAttribute("orderId");
			}
		} catch (Exception ex) {
			log.error(ex, ex);
			String errorMsg = ex.toString();
			errorMsg = (errorMsg.lastIndexOf(":") != -1) ? errorMsg.substring(errorMsg.lastIndexOf(":") + 1) : errorMsg;
			log.error("errorMsg.." + errorMsg);
		}
		log.info("AgentViewController::createCCRConnection method ends");
		return tiRequestId;
	}

	private void intiatePlanningPhase(long tiRequestId) {
		Map<String, Object> workFlowParams = workflowUtil.buildWorkflowParamsForPlanning(tiRequestId);
		// Intiate Planning phase
		WorkflowResult workResult = wrkflowCallServiceHelper.callWorkflowService(FlowType.PLANNING, workFlowParams,
				WorkflowEvent.CREATE, null);
	}
}
