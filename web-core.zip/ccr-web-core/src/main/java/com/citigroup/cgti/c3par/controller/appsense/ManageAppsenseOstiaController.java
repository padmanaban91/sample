package com.citigroup.cgti.c3par.controller.appsense;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseApplication;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseDTO;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseOstiaQuestion;
import com.citigroup.cgti.c3par.appsense.domain.AppsensePortMaster;
import com.citigroup.cgti.c3par.appsense.domain.ConnectionOstiaGroup;
import com.citigroup.cgti.c3par.appsense.domain.ManageAppsenseProcess;
import com.citigroup.cgti.c3par.controller.firewall.BaseController;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.webtier.helper.AppsenseUtil;
import com.citigroup.cgti.c3par.webtier.helper.Util;

/**
 * 
 * @author ne36745
 *
 */
@SuppressWarnings("unchecked")
@Controller
public class ManageAppsenseOstiaController extends BaseController {

	/** The log. */
	public static Logger log = Logger
			.getLogger(ManageAppsenseOstiaController.class);
	

	/** The util. */
	Util util = new Util();
	
	AppsenseUtil appsenseUtil = new AppsenseUtil();

	/** The props. */
	private static ResourceBundle props = ResourceBundle.getBundle(System.getProperty("ccr-application"), Locale.getDefault());
	

	//To Load the Appsense OStia Tab
	/**
	 * 
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/loadAppsenseOstia.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	 public String loadOstiaApplication(ModelMap model,
				HttpServletRequest request){

			String forwardTo = "c3par.appsense.ostia";
			
			log.info("ManageAppsenseProcess.loadOstiaApplication()::Starts");
			
			ManageAppsenseProcess manageAppsenseProcess = new ManageAppsenseProcess();
			
			String tiReq = (String) request.getSession().getAttribute("tireqid");
			log.info("tiReq from SESSION===" + tiReq);
			
			Long tiRequestId = Long.valueOf(tiReq);
			
			log.info("tiRequestId===" + tiRequestId);
			
			TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
			TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
			manageAppsenseProcess.setTirequest(tiRequest);
			AppsenseDTO apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
			manageAppsenseProcess.setOffset(0);
			manageAppsenseProcess.setPageNo(1);
			manageAppsenseProcess.setLimit(5);
			
			List<AppsenseApplication> appsenseApplicationList = manageAppsenseProcess.loadAppsenseOstiaApplications(apsProcess,manageAppsenseProcess);
			log.info("appsenseApplicationList--->>>" + appsenseApplicationList);
			
			//To calculate no of pages
			int rowCount = manageAppsenseProcess.getRowCount();
			int totalPages = 0;
			int limit = 5;
			
			if (rowCount%limit > 0) {
				totalPages = Math.round((rowCount/limit)+0.5f);
			} else {
				totalPages = Math.round(rowCount/limit);
			}
			manageAppsenseProcess.setTotalPages(totalPages);
			
			log.info("appsenseApplicationList--->>>" + appsenseApplicationList);
			manageAppsenseProcess.setAppsenseApplicationList(appsenseApplicationList);
			manageAppsenseProcess.setApsProcess(apsProcess);
			request.getSession().setAttribute("selectedAps", appsenseApplicationList);
			model.addAttribute("appsenseData",manageAppsenseProcess);
			
			isAppsenseCompleteCheck(request);
			log.info("ManageAppsenseProcess.loadOstiaApplication()::Ends");

			return forwardTo;
		    }
	
	
	//To paginate the ostia records
	/**
	 * 
	 * @param model
	 * @param request
	 * @param manageAppsenseProcess
	 * @return
	 */
	@RequestMapping(value = "/paginateAppsenseOstia.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String paginateAppsense(ModelMap model, HttpServletRequest request, @ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess) {
		log.info("ManageAppsenseController:load method starts here ...");
	
		int curOffSet = manageAppsenseProcess.getOffset();
		int limit = manageAppsenseProcess.getLimit();
		int pageNo = manageAppsenseProcess.getPageNo();
		String type = (String)request.getParameter("type");
		
		log.debug("ManageAppsenseController::paginateIPs type..."+type);
		
		manageAppsenseProcess = new ManageAppsenseProcess();
		AppsenseDTO apsProcess = new AppsenseDTO();
		

		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		manageAppsenseProcess.setTirequest(tiRequest);

		apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		manageAppsenseProcess.setLimit(limit);
		if ("N".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(curOffSet+manageAppsenseProcess.getLimit());
			manageAppsenseProcess.setPageNo(pageNo+1);
		} else if ("P".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(curOffSet-manageAppsenseProcess.getLimit());
			manageAppsenseProcess.setPageNo(pageNo-1);
		} else if ("X".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(limit * (pageNo-1));
			manageAppsenseProcess.setPageNo(pageNo);
		} else if ("L".equalsIgnoreCase(type)) {
			manageAppsenseProcess.setOffset(0);
			manageAppsenseProcess.setPageNo(1);
		} else {
			manageAppsenseProcess.setOffset(0);
			manageAppsenseProcess.setPageNo(1);
		}
		
		List<AppsenseApplication> appsenseApplicationList = manageAppsenseProcess.loadAppsenseOstiaApplications(apsProcess,manageAppsenseProcess);
		
		//To calculate no of pages
		int rowCount = manageAppsenseProcess.getRowCount();
		int totalPages = 0;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		manageAppsenseProcess.setTotalPages(totalPages);
		
		log.info("appsenseApplicationList--->>>" + appsenseApplicationList);
		manageAppsenseProcess.setAppsenseApplicationList(appsenseApplicationList);
		manageAppsenseProcess.setApsProcess(apsProcess);
		
		request.getSession().setAttribute("selectedAps", appsenseApplicationList);
		model.addAttribute("appsenseData", manageAppsenseProcess);

		log.info("ManageAppsenseProcess.load()::Ends");
		return "c3par.appsense.ostia";
	}
	
	
	//To load the ostia questions for adding answers
	/**
	 * 
	 * @param model
	 * @param manageAppsenseProcess
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/loadOstiaPage.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String loadOstiaPage(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		
		log.info("ManageAppsenseProcess.loadOstiaPage()::Starts");
		request.getSession().removeAttribute("selectedAps");
		AppsenseApplication appsenseApplication = manageAppsenseProcess
				.getAppsenseApplication();
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		manageAppsenseProcess.setTirequest(tiRequest);
		
		AppsenseDTO apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		manageAppsenseProcess.setApsProcess(apsProcess);
		
		List<AppsenseApplication> appsenseApplicationList = manageAppsenseProcess.getAppsenseApplicationList();
		log.debug("inside appsense:"+appsenseApplicationList.size());
		List<AppsenseApplication> apsList = new ArrayList<AppsenseApplication>();
		manageAppsenseProcess.setOstiaList(manageAppsenseProcess.getDeviceTypes());
		
		AppsensePortMaster apsPortMaster = appsenseApplication.getApsPortMaster();
		ConnectionOstiaGroup connectionOstiaGroup = apsPortMaster.getConOstiaGroup();
		String selectedTab = request.getParameter("tab");
		log.info("ManageAppsenseProcess.loadOstiaPage():: selectedTab"
				+ selectedTab);
		
		for (AppsenseApplication appsApplication : appsenseApplicationList) {
			if (appsApplication.isSelected()) {
				apsList.add(appsApplication);
			}
			
		}
		
		List<AppsenseOstiaQuestion> ostiaQuestionList = new ArrayList<AppsenseOstiaQuestion>();
		
		Util util = new Util();
		int questionCount = util.getOstiaQuestionCount();
		log.debug("loadOstiaPage::ostiaQuestionList.questionlist:"+questionCount);
		for (int i = 0; i < questionCount; i++) {
			log.debug("inside count:"+i);
			AppsenseOstiaQuestion ostiaQuestion = new AppsenseOstiaQuestion();
			ostiaQuestion.setQuestionID(Long.valueOf(i + 1));
			ostiaQuestionList.add(ostiaQuestion);
		}
		log.info("loadOstiaPage::ostiaQuestionList" + ostiaQuestionList.size());
		connectionOstiaGroup.setOstiaQuestionList(ostiaQuestionList);
		connectionOstiaGroup.setStatus("Not Started");
		apsPortMaster.setConOstiaGroup(connectionOstiaGroup);
		appsenseApplication.setApsPortMaster(apsPortMaster);
		appsenseApplication.setTiProcess(tiProcess);
		manageAppsenseProcess.setAppsenseApplication(appsenseApplication);
		
		manageAppsenseProcess.setAppsenseOstiaList(apsList);
		log.debug("application ostia list:"+apsList.size());
		model.addAttribute("appsenseData", manageAppsenseProcess);
		request.getSession().setAttribute("selectedAps",manageAppsenseProcess.getAppsenseOstiaList());
		request.getSession().setAttribute("ostiaQuestDisplay", "addOstia");
		request.getSession().setAttribute("showOstiaQuestions",
				"showOstiaQuestions");
		log.info("ManageAppsenseProcess.loadOstiaPage()::Ends");
		return "c3par.appsense.ostiaqns";
	}
	
	//To open the ostia questions for editing
	/**
	 * 
	 * @param model
	 * @param manageAppsenseProcess
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/loadEditOstiaPage.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String loadEditOstiaPage(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		
		String forwardTo = "c3par.appsense.ostiaqns";
		String editIndexId = request.getParameter("indexId");
		if (editIndexId == null || "".equals(editIndexId)
				|| "null".equalsIgnoreCase(editIndexId)) {
			throw new BusinessException("Invalid Selection");
		}
		ConnectionOstiaGroup conOstiaGroup = new ConnectionOstiaGroup();
		AppsenseApplication appsenseApplication = new AppsenseApplication();
		int indexId = Integer.parseInt(editIndexId);
		List<AppsenseApplication> appsenseApplicationList = ((List<AppsenseApplication>)request.getSession().getAttribute("selectedAps"));
		manageAppsenseProcess.setOstiaList(manageAppsenseProcess.getDeviceTypes());
		String tiReq = (String) request.getSession().getAttribute("tireqid");
		log.info("tiReq from SESSION===" + tiReq);
		
		Long tiRequestId = Long.valueOf(tiReq);
		
		log.info("tiRequestId===" + tiRequestId);
		
		TIProcess tiProcess = manageAppsenseProcess.getTIProcess(tiRequestId);
		TIRequest tiRequest = manageAppsenseProcess.getTIRequest(tiRequestId);
		manageAppsenseProcess.setTirequest(tiRequest);
		AppsenseDTO apsProcess = manageAppsenseProcess.getAppsenseProcess(tiProcess.getId());
		manageAppsenseProcess.setApsProcess(apsProcess);
		tiProcess.getRelationship().setRelationshipType(
				C3parStaticNames.THIRD_PARTY);
		if (appsenseApplicationList == null
				|| appsenseApplicationList.size() == 0) {	
			throw new BusinessException("No AppsenseApplication Found");
		} else {
			for (int i = 0; i < appsenseApplicationList.size(); i++) {
				AppsenseApplication apsApplication = (AppsenseApplication) appsenseApplicationList
						.get(i);
				apsApplication.setSelected(false);
			}
			appsenseApplication = (AppsenseApplication) appsenseApplicationList
					.get(indexId);
			appsenseApplication.setSelected(true);
			boolean isOstiaQuestionsExists = false;
			if (appsenseApplication.getApsPortMaster() != null) {
				if (appsenseApplication.getApsPortMaster().getConOstiaGroup() != null) {
					conOstiaGroup = appsenseApplication.getApsPortMaster()
							.getConOstiaGroup();
					log.info("Group ID-1" + conOstiaGroup.getId());
					Long groupId = conOstiaGroup.getId();
					  ConnectionOstiaGroup tempConnectionOstiaGroup = manageAppsenseProcess
					  .getOstiaGroup(conOstiaGroup.getId());
					  log.info("Size of::ostiaQuestionList in loadEditOstia-2"
					  + tempConnectionOstiaGroup.getOstiaQuestionList()
					 .size()); log.info("Group ID-2" +
					  tempConnectionOstiaGroup.getId());
					 
					 if (tempConnectionOstiaGroup.getOstiaQuestionList() != null) {
							if (tempConnectionOstiaGroup.getOstiaQuestionList()
								.size() > 0) {
							    conOstiaGroup = new ConnectionOstiaGroup();
							    conOstiaGroup.setId(groupId);
							    List ostiaQuestionList = new ArrayList();
							    ostiaQuestionList.addAll(tempConnectionOstiaGroup
								    .getOstiaQuestionList());
							    conOstiaGroup
								    .setOstiaQuestionList(ostiaQuestionList);
							    conOstiaGroup.setStatus(tempConnectionOstiaGroup
								    .getStatus());
							    Collections.sort(conOstiaGroup
								    .getOstiaQuestionList(),
								    new OstiaQuestionComparator());
							    isOstiaQuestionsExists = true;
							}
						    }
				}
			}

			if (!isOstiaQuestionsExists) {
				List<AppsenseOstiaQuestion> ostiaQuestionList = new ArrayList<AppsenseOstiaQuestion>();
				Util util = new Util();
				int questionCount = util.getOstiaQuestionCount();
				for (int i = 0; i < questionCount; i++) {
					AppsenseOstiaQuestion ostiaQuestion = new AppsenseOstiaQuestion();
					ostiaQuestion.setQuestionID(Long.valueOf(i + 1));
					ostiaQuestionList.add(ostiaQuestion);
				}
				conOstiaGroup.setOstiaQuestionList(ostiaQuestionList);
				conOstiaGroup.setStatus("Not Started");
			}
		}
		
		manageAppsenseProcess.setAppsenseApplication(appsenseApplication);
		
		appsenseApplicationList = new ArrayList<AppsenseApplication>();
		
		appsenseApplicationList.add(appsenseApplication);
		
		request.getSession().setAttribute("selectedAps", appsenseApplicationList);
		
		String applicationName = appsenseApplication.getApplication()
				.getApplicationName();
		log.info("loadEditOstia:::applicationName" + applicationName);
		request.setAttribute("apsNames", applicationName);
		log.info("Size of::ostiaQuestionList in loadEditOstia before setting to Form"
				+ conOstiaGroup.getOstiaQuestionList().size());
		manageAppsenseProcess.getAppsenseApplication().getApsPortMaster()
				.setConOstiaGroup(conOstiaGroup);
		request.getSession().setAttribute("showOstiaQuestions",
				"showOstiaQuestions");
		request.getSession().setAttribute("ostiaQuestDisplay", "editOstia");
		model.addAttribute("appsenseData", manageAppsenseProcess);
		return forwardTo;
	}
	
	
	//To update the ostia answers by Ostia Group
	/**
	 * 
	 * @param model
	 * @param manageAppsenseProcess
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/updateOstiaGroup.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String updateOstiaGroup(ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request,HttpServletResponse response){
		
		AppsenseDTO appsenseProcess = manageAppsenseProcess.getApsProcess();
		AppsenseApplication appsenseApplication = manageAppsenseProcess
			.getAppsenseApplication();
		ConnectionOstiaGroup connectionOstiaGroup = appsenseApplication
			.getApsPortMaster().getConOstiaGroup();

		if (connectionOstiaGroup.getOstiaQuestionList() != null) {
		    if (connectionOstiaGroup.getOstiaQuestionList().size() > 0) {
			boolean isComplete = true;
			for (int i = 0; i < connectionOstiaGroup.getOstiaQuestionList()
				.size(); i++) {
			    AppsenseOstiaQuestion ostiaQuestion = (AppsenseOstiaQuestion) connectionOstiaGroup
				    .getOstiaQuestionList().get(i);
			    if ((ostiaQuestion.getAnswerDesc() == null || ""
				    .equalsIgnoreCase(ostiaQuestion.getAnswerDesc()
					    .trim()))
				    && (!appsenseUtil.excludeQuestion(ostiaQuestion.getQuestionID()
					    .toString(), appsenseProcess
					    .getRelationshipType()))) {
				connectionOstiaGroup.setStatus("Incomplete");
				ostiaQuestion.setAnswerDesc(null);
				isComplete = false;

			    } else if ((ostiaQuestion.getAnswerDesc() != null)
				    && (!"".equalsIgnoreCase(ostiaQuestion
					    .getAnswerDesc().trim()))) {
				ostiaQuestion.setAnswerDesc(ostiaQuestion
					.getAnswerDesc().replace('\'', '`'));
			    }

			    if ((ostiaQuestion.getAnswerDesc() != null)
				    && ("".equalsIgnoreCase(ostiaQuestion
					    .getAnswerDesc().trim()))) {
				ostiaQuestion.setAnswerDesc(null);
			    }
			}

			if (isComplete) {
			    connectionOstiaGroup.setStatus("Complete");
			}
		    }
		} else {
		    connectionOstiaGroup.setStatus("Not Started");
		}
		appsenseProcess.setAppsenseApplicationList(manageAppsenseProcess
			.getAppsenseApplicationList());
		
		manageAppsenseProcess.updateOstiaGroup(appsenseProcess, connectionOstiaGroup);
		request.getSession().removeAttribute("showOstiaQuestions");
		return "forward:/loadAppsenseOstia.act";
	}
	
	
	//To load the ostia questions
	/**
	 * 
	 * @param model
	 * @param manageAppsenseProcess
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/loadEditGroup.act", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String loadEditGroup(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		
		String forwardTo = "c3par.appsense";
		String editIndexId = request.getParameter("indexId");
		String selectedTab = request.getParameter("tab");
		log.info("selectedTab---" + selectedTab);
		if (editIndexId == null || "".equals(editIndexId)
				|| "null".equalsIgnoreCase(editIndexId)) {
			throw new BusinessException("Invalid Selection");
		}
		List<AppsenseApplication> appsenseApplicationList = manageAppsenseProcess
				.getAppsenseApplicationList();
		ConnectionOstiaGroup connectionOstiaGroup = new ConnectionOstiaGroup();
		AppsenseApplication appsenseApplication = new AppsenseApplication();
		int indexId = Integer.parseInt(editIndexId);
		if (appsenseApplicationList == null
				|| appsenseApplicationList.size() == 0) {
			throw new BusinessException("No AppsenseApplication Found");
		} else {
			appsenseApplication = (AppsenseApplication) appsenseApplicationList
					.get(indexId);
			appsenseApplication.setSelected(true);
			appsenseApplication.getApsPortMaster().getConOstiaGroup()
					.setSelected(true);
			boolean isOstiaQuestionsExists = false;
			if (appsenseApplication.getApsPortMaster().getConOstiaGroup() != null) {
				connectionOstiaGroup = appsenseApplication.getApsPortMaster()
						.getConOstiaGroup();
				log.info("GROUPID in loadEditGroup-1+"
						+ connectionOstiaGroup.getId());
				
				 connectionOstiaGroup =manageAppsenseProcess.getOstiaGroup(connectionOstiaGroup .getId());
				  log.info("GROUPID in loadEditGroup-2+" +
				  connectionOstiaGroup.getId());
				 log.info("Size of::ostiaQuestionList in loadEditGroup" +
				  connectionOstiaGroup.getOstiaQuestionList().size()); 
				 /*if(connectionOstiaGroup.getOstiaQuestionList() != null) {
					
					 if (connectionOstiaGroup.getOstiaQuestionList().size() > 0) {
						 	Collections.sort(connectionOstiaGroup
						 			.getOstiaQuestionList(), new OstiaQuestionComparator());
				 isOstiaQuestionsExists = true; 
				 }
					 
				 }*/
				 
			}
			if (!isOstiaQuestionsExists) {
				List<AppsenseOstiaQuestion> ostiaQuestionList = new ArrayList<AppsenseOstiaQuestion>();
				Util util = new Util();
				int questionCount = util.getOstiaQuestionCount();
				for (int i = 0; i < questionCount; i++) {
					AppsenseOstiaQuestion ostiaQuestion = new AppsenseOstiaQuestion();
					ostiaQuestion.setQuestionID(Long.valueOf(i + 1));
					ostiaQuestionList.add(ostiaQuestion);
				}
				connectionOstiaGroup.setOstiaQuestionList(ostiaQuestionList);
				connectionOstiaGroup.setStatus("Not Started");
			}
		}
		request.setAttribute("apsNames", appsenseApplication.getApplication()
				.getApplicationName().toString());
		log.info("Size of::ostiaQuestionList in loadEditGroup before setting to Form"
				+ connectionOstiaGroup.getOstiaQuestionList().size());
		manageAppsenseProcess.getAppsenseApplication().getApsPortMaster()
				.setConOstiaGroup(connectionOstiaGroup);
		request.getSession().setAttribute("showOstiaQuestions",
				"showOstiaQuestions");
		request.getSession()
				.setAttribute("ostiaQuestDisplay", "editOstiaGroup");
		request.getSession().setAttribute("selectedTab", selectedTab);
		return forwardTo;
	}
	
	/**
	 * 
	 * @param model
	 * @param manageAppsenseProcess
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/addOstiaAnswers.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String addOstiaAnswers(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		log.info("ManageAppsenseProcess-addOstiaAnswers START::");
		
		AppsenseDTO appsenseProcess = manageAppsenseProcess.getApsProcess();
		List<AppsenseApplication> appsenseApplicationList = ((List<AppsenseApplication>)request.getSession().getAttribute("selectedAps"));
		log.info("appsenseApplicationList---" + appsenseApplicationList.size());
		
		ConnectionOstiaGroup connectionOstiaGroup = manageAppsenseProcess.getAppsenseApplication().getApsPortMaster().getConOstiaGroup();

		if (appsenseApplicationList != null) {
			log.info("-appsenseApplicationList != null--");
			
			if (connectionOstiaGroup.getOstiaQuestionList() != null) {
				
				if (connectionOstiaGroup.getOstiaQuestionList().size() > 0) {
					
					log.info("addOstiaAnswers::ostiaQuestionList"+ connectionOstiaGroup.getOstiaQuestionList().size());
					
					boolean isComplete = true;
					
					for (int i = 0; i < connectionOstiaGroup.getOstiaQuestionList().size(); i++) {
						AppsenseOstiaQuestion ostiaQuestion = (AppsenseOstiaQuestion) connectionOstiaGroup.getOstiaQuestionList().get(i);
						if ((ostiaQuestion.getAnswerDesc() == null || "".equalsIgnoreCase(ostiaQuestion.getAnswerDesc().trim()))
								&& (!appsenseUtil.excludeQuestion(ostiaQuestion.getQuestionID().toString(),
										manageAppsenseProcess.getApsProcess().getRelationshipType()))) {
							log.info("No Ostia Answers description "+ostiaQuestion.getQuestionID());

							connectionOstiaGroup.setStatus("Incomplete");
							ostiaQuestion.setAnswerDesc(null);
							isComplete = false;
						} else if ((ostiaQuestion.getAnswerDesc() != null)
								&& (!"".equalsIgnoreCase(ostiaQuestion
										.getAnswerDesc().trim()))) {
							log.info("Ostia Answers "
									+ ostiaQuestion.getAnswerDesc());
							ostiaQuestion.setAnswerDesc(ostiaQuestion
									.getAnswerDesc().replace('\'', '`'));
						} else {
							log.info("Ostia Answers Else part  "
									+ ostiaQuestion.getAnswerDesc());
						}
						ostiaQuestion.setConOstiagroup(connectionOstiaGroup);
						ostiaQuestion.setCreated_date(new Date());
						ostiaQuestion.setUpdated_date(new Date());
						
					}
					

					if (isComplete) {
						connectionOstiaGroup.setStatus("Complete");
					}
				}
			} else {
				connectionOstiaGroup.setStatus("Not Started");
			}

		}
		
	
		log.info("Status of connectionOstiaGroup"
				+ connectionOstiaGroup.getStatus());
		log.info("Calling.....TechnialArchitectureFacade.addOstiaAnswers");
		log.info("Size of::ostiaQuestionList"
				+ connectionOstiaGroup.getOstiaQuestionList().size());
	
		  appsenseProcess.setAppsenseApplicationList(appsenseApplicationList);
		  
		  Long groupId=manageAppsenseProcess.saveConOstiaGroup(connectionOstiaGroup);
		  connectionOstiaGroup.setId(groupId);
		  log.debug("conostia group"+connectionOstiaGroup.getId());
		 manageAppsenseProcess.addOstiaAnswers(appsenseProcess,groupId);
		request.getSession().removeAttribute("showOstiaQuestions");
		request.getSession().setAttribute("viewIndex", "view");
		log.info("END:::ManageAppsenseProcess-addOstiaAnswers::");
		return "forward:/loadAppsenseOstia.act";
	}
	

	/**
	 * 
	 * @param model
	 * @param manageAppsenseProcess
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/updateOstiaAnswers.act", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String updateOstiaAnswers(
			ModelMap model,
			@ModelAttribute("appsenseData") ManageAppsenseProcess manageAppsenseProcess,
			HttpServletRequest request) {
		log.info("ManageAppsenseProcess-updateOstiaAnswers START::");
		List<AppsenseApplication> appsenseApplicationList = null;
		AppsenseDTO appsenseProcess = manageAppsenseProcess.getApsProcess();
		appsenseApplicationList = ((List<AppsenseApplication>)request.getSession().getAttribute("selectedAps"));
		AppsenseApplication appsenseApplication = manageAppsenseProcess
				.getAppsenseApplication();
		ConnectionOstiaGroup connectionOstiaGroup = appsenseApplication
				.getApsPortMaster().getConOstiaGroup();
		log.info("updateOstiaAnswers.appsenseApplicationList---"
				+ appsenseApplicationList.size());

		if (appsenseApplicationList != null) {
			if (connectionOstiaGroup.getOstiaQuestionList() != null) {
				if (connectionOstiaGroup.getOstiaQuestionList().size() > 0) {
					boolean isComplete = true;
					for (int i = 0; i < connectionOstiaGroup
							.getOstiaQuestionList().size(); i++) {
						AppsenseOstiaQuestion ostiaQuestion = (AppsenseOstiaQuestion) connectionOstiaGroup
								.getOstiaQuestionList().get(i);
						if ((ostiaQuestion.getAnswerDesc() == null || ""
								.equalsIgnoreCase(ostiaQuestion.getAnswerDesc()
										.trim()))
								&& (!appsenseUtil.excludeQuestion(ostiaQuestion
										.getQuestionID().toString(),
										appsenseProcess.getRelationshipType()))) {
							connectionOstiaGroup.setStatus("Incomplete");
							ostiaQuestion.setAnswerDesc(null);
							isComplete = false;
						} else if ((ostiaQuestion.getAnswerDesc() != null)
								&& (!"".equalsIgnoreCase(ostiaQuestion
										.getAnswerDesc().trim()))) {
							ostiaQuestion.setAnswerDesc(ostiaQuestion
									.getAnswerDesc().replace('\'', '`'));
						}

						if ((ostiaQuestion.getAnswerDesc() != null)
								&& ("".equalsIgnoreCase(ostiaQuestion
										.getAnswerDesc().trim()))) {
							ostiaQuestion.setAnswerDesc(null);
						}
						
						ostiaQuestion.setConOstiagroup(connectionOstiaGroup);
						ostiaQuestion.setUpdated_date(new Date());
					}

					if (isComplete) {
						connectionOstiaGroup.setStatus("Complete");
					}
				}
			} else {
				connectionOstiaGroup.setStatus("Not Started");
			}
			
			log.info("updateOstiaAnswers.Status of connectionOstiaGroup "+ connectionOstiaGroup.getId() +" "
					+ connectionOstiaGroup.getStatus());
			try {
				Long groupId=manageAppsenseProcess.saveConOstiaGroup(connectionOstiaGroup);
			} catch (Exception e) {
				log.error(e, e);
			}
			  
			appsenseProcess.setAppsenseApplicationList(appsenseApplicationList);
			manageAppsenseProcess.addOstiaAnswers(appsenseProcess, connectionOstiaGroup.getId());
			 
		}
		log.info("updateOstiaAnswers.Status of connectionOstiaGroup"
				+ connectionOstiaGroup.getStatus());
		log.info("updateOstiaAnswers::Calling.....TechnialArchitectureFacade.addOstiaAnswers");
		request.getSession().setAttribute("selectedTab", "ostia");
		request.getSession().removeAttribute("showOstiaQuestions");
		request.getSession().setAttribute("viewIndex", "view");
		request.getSession().setAttribute("ostiaQuestDisplay", "addOstia");

		log.info("ManageAppsenseProcess-updateOstiaAnswers END::");
		return "forward:/loadAppsenseOstia.act";
	}
	
	
	 /**
     * The Class OstiaQuestionComparator.
     */
    class OstiaQuestionComparator implements Comparator {
	// Compare two Strings. Callback for sort.
	// effectively returns a-b;
	// e.g. +1 (or any +ve number) if a > b
	// 0 if a == b
	// -1 (or any -ve number) if a < b
	/*
	 * (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	public final int compare(Object a, Object b) {
	    Long startQuestion = ((AppsenseOstiaQuestion) a).getQuestionID();
	    Long endQuestion = ((AppsenseOstiaQuestion) b).getQuestionID();
	    return (startQuestion.longValue() < endQuestion.longValue()) ? -1
		    : (startQuestion.longValue() == endQuestion.longValue()) ? 0
			    : 1;
	} //

    }

}
