package com.citigroup.cgti.c3par.controller.login;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.citigroup.cgti.c3par.util.C3parProperties;

/**
 * 
 * @author ne36745
 *
 */
@Controller
public class LogoutController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(LogoutController.class);
	
	@RequestMapping(value = "/logout.act")
	public String logout(HttpServletRequest request){
		String userId = request.getHeader("SM_USER"); 
		log.info("LogoutController starts here for userId : "+userId);
		try {
		    request.getSession().invalidate();
		    request.setAttribute("LOGOUT_URL", C3parProperties.LOGOUT_URL);
		log.info("Invalidated the session for the user : "+userId);
		} catch (IllegalStateException lse) {
		}

		return "login/bpmLogout";
	}
	
}
