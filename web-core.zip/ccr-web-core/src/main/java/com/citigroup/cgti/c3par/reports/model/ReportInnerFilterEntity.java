/*
 * Created on Jun 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.reports.model;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import com.citigroup.cgti.c3par.reports.model.RequestedReportEntity;
import com.citigroup.cgti.c3par.reports.reportInterface.ReportException;
import com.citigroup.cgti.c3par.reports.util.Util;


/**
 * The Class ReportInnerFilterEntity.
 *
 * @author MphasiS
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ReportInnerFilterEntity  implements Serializable{

    /** The column names. */
    private List columnNames;

    /** The condition. */
    private List condition;

    /** The compare value. */
    private List compareValue;

    /** The is compare to column. */
    private List isCompareToColumn;

    /** The outer condition. */
    private List outerCondition;
    //	private Util util;

    /**
     * Instantiates a new report inner filter entity.
     */
    public ReportInnerFilterEntity(){
	//		util = new Util();
    }


    /**
     * Gets the outer condition.
     *
     * @return Returns the outerCondition.
     */
    public List getOuterCondition() {
	return outerCondition;
    }

    /**
     * Sets the outer condition.
     *
     * @param outerCondition The outerCondition to set.
     */
    public void setOuterCondition(List outerCondition) {
	this.outerCondition = outerCondition;
    }

    /**
     * Gets the column names.
     *
     * @return Returns the columnNames.
     */
    public List getColumnNames() {
	return columnNames;
    }

    /**
     * Sets the column names.
     *
     * @param columnNames The columnNames to set.
     */
    public void setColumnNames(List columnNames) {
	this.columnNames = columnNames;
    }

    /**
     * Gets the compare value.
     *
     * @return Returns the compareValue.
     */
    public List getCompareValue() {
	return compareValue;
    }

    /**
     * Sets the compare value.
     *
     * @param compareValue The compareValue to set.
     */
    public void setCompareValue(List compareValue) {
	this.compareValue = compareValue;
    }

    /**
     * Gets the condition.
     *
     * @return Returns the condition.
     */
    public List getCondition() {
	return condition;
    }

    /**
     * Sets the condition.
     *
     * @param condition The condition to set.
     */
    public void setCondition(List condition) {
	this.condition = condition;
    }

    /**
     * Gets the compare to column.
     *
     * @return Returns the isCompareToColumn.
     */
    public List getCompareToColumn() {
	return isCompareToColumn;
    }

    /**
     * Sets the compare to column.
     *
     * @param compareToColumn the new compare to column
     */
    public void setCompareToColumn(List compareToColumn) {
	this.isCompareToColumn = compareToColumn;
    }
}
