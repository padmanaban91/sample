/**
 *
 */
package com.citigroup.cgti.c3par.fw.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.StringType;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.Application;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleApplication;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.IPDetailsRequest;
import com.citigroup.cgti.c3par.fw.domain.soc.persist.IPDetailsPersistable;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;

/**
 * @author ne36745
 *
 */
@SuppressWarnings("unchecked")
@Transactional
public class IPDetailsServiceImpl extends BasePersistanceImpl implements
	IPDetailsPersistable {

    /** The log. */
    private static Logger log = Logger.getLogger(IPDetailsServiceImpl.class);

    /**
     * 
     */
   @Transactional(readOnly = true)
   public List<FireWallRuleIP> loadIPDetails(IPDetailsRequest ipDetailsRequest) {
	   log.info("IPDetailsServiceImpl::loadIPDetails methods starts...");
	   log.debug("IPDetailsServiceImpl::TIRequest..."+ipDetailsRequest.getTiRequest());
	   Session session = getSession();
	   StringBuffer ipdetailsQuery = new StringBuffer();
	   String isIpReg= ipDetailsRequest.getIsIpReg();
	   String isIp = "";
	   if(isIpReg=="Y")
		{
			isIp = "rule.is_ipreg='Y'";
		}
		else
		{
			isIp = "(rule.is_ipreg!='Y' or rule.is_ipreg is null)";
		}
	   if (!"EndB".equalsIgnoreCase(ipDetailsRequest.getFilterType())) {
		   ipdetailsQuery.append(" select distinct mst.*,rt.name as resourcetype from con_ip_master mst ");
		   ipdetailsQuery.append(" left outer join con_fw_rule_source_ip sip on sip.ip_id=mst.id and sip.deleted_ti_request_id is null ");
		   ipdetailsQuery.append(" left outer join con_fw_rule rule on rule.id = sip.rule_id and rule.deleted_ti_request_id is null ");
		   ipdetailsQuery.append(" left outer join resourcetype rt on rt.id = rule.src_nwzone_id ");
		   ipdetailsQuery.append(" left outer join con_fw_rule_application fwrapp on fwrapp.deleted_ti_request_id is null and fwrapp.ip_id = mst.id and fwrapp.rule_id = rule.id ");
		   ipdetailsQuery.append(" left outer join ti_application app on fwrapp.application_id = app.id ");
		   ipdetailsQuery.append(" where rule.ti_request_id = "+ipDetailsRequest.getTiRequest()+" and "+isIp);
		   if ("IP".equalsIgnoreCase(ipDetailsRequest.getFilterType()) 
				   && ipDetailsRequest.getFilterText() != null && !ipDetailsRequest.getFilterText().isEmpty()) {
			   ipdetailsQuery.append(" and upper(mst.ip_address) like ('%"+ipDetailsRequest.getFilterText().toUpperCase().trim()+"%')");
	   	   } else if ("NAT".equalsIgnoreCase(ipDetailsRequest.getFilterType()) 
				   && ipDetailsRequest.getFilterText() != null && !ipDetailsRequest.getFilterText().isEmpty()) {
			   ipdetailsQuery.append(" and upper(sip.nat) like ('%"+ipDetailsRequest.getFilterText().toUpperCase().trim()+"%')");
	   	   } else if ("APP".equalsIgnoreCase(ipDetailsRequest.getFilterType()) 
				   && ipDetailsRequest.getFilterText() != null && !ipDetailsRequest.getFilterText().isEmpty()) {
			   ipdetailsQuery.append(" and upper(app.application_name) like ('%"+ipDetailsRequest.getFilterText().toUpperCase().trim()+"%')");
	   	   } else if ("DEV".equalsIgnoreCase(ipDetailsRequest.getFilterType()) 
				   && ipDetailsRequest.getFilterText() != null && !ipDetailsRequest.getFilterText().isEmpty()) {
			   ipdetailsQuery.append(" and upper(app.DEVICE_MODEL) like ('%"+ipDetailsRequest.getFilterText().toUpperCase().trim()+"%')");
	   	   } else if ("INC".equalsIgnoreCase(ipDetailsRequest.getFilterType())) {
	   		   ipdetailsQuery.append(" and rt.name <> '3rd Party/CEP' ");
			   ipdetailsQuery.append(" and (select count(*) from con_fw_rule_application fra where fra.deleted_ti_request_id is null and fra.id = fwrapp.id) <= 0 ");
	   	   } else if ("Retired".equalsIgnoreCase(ipDetailsRequest.getFilterType())) {
			   ipdetailsQuery.append(" and app.is_decommissioned = 'Y' ");
	   	   }
	   }
	   if (!("EndB".equalsIgnoreCase(ipDetailsRequest.getFilterType()) || "EndA".equalsIgnoreCase(ipDetailsRequest.getFilterType()))) {
		   ipdetailsQuery.append(" union ");
	   }
	   if (!"EndA".equalsIgnoreCase(ipDetailsRequest.getFilterType())) {
		   ipdetailsQuery.append(" select distinct mst.*,rt.name as resourcetype from con_ip_master mst ");
		   ipdetailsQuery.append(" left outer join con_fw_rule_destination_ip dip on dip.ip_id=mst.id  and dip.deleted_ti_request_id is null ");
		   ipdetailsQuery.append(" left outer join con_fw_rule rule on rule.id = dip.rule_id  and rule.deleted_ti_request_id is null ");
		   ipdetailsQuery.append(" left outer join resourcetype rt on rt.id = rule.dst_nwzone_id ");
		   ipdetailsQuery.append(" left outer join con_fw_rule_application fwrapp on fwrapp.deleted_ti_request_id is null and fwrapp.ip_id = mst.id and fwrapp.rule_id = rule.id ");
		   ipdetailsQuery.append(" left outer join ti_application app on fwrapp.application_id = app.id ");
		   ipdetailsQuery.append(" where rule.ti_request_id = "+ipDetailsRequest.getTiRequest()+" and "+isIp);
		   if ("IP".equalsIgnoreCase(ipDetailsRequest.getFilterType()) 
				   && ipDetailsRequest.getFilterText() != null && !ipDetailsRequest.getFilterText().isEmpty()) {
			   ipdetailsQuery.append(" and upper(mst.ip_address) like ('%"+ipDetailsRequest.getFilterText().toUpperCase().trim()+"%')");
	   	   } else if ("NAT".equalsIgnoreCase(ipDetailsRequest.getFilterType()) 
				   && ipDetailsRequest.getFilterText() != null && !ipDetailsRequest.getFilterText().isEmpty()) {
			   ipdetailsQuery.append(" and upper(dip.nat) like ('%"+ipDetailsRequest.getFilterText().toUpperCase().trim()+"%')");
	   	   } else if ("APP".equalsIgnoreCase(ipDetailsRequest.getFilterType()) 
				   && ipDetailsRequest.getFilterText() != null && !ipDetailsRequest.getFilterText().isEmpty()) {
			   ipdetailsQuery.append(" and upper(app.application_name) like ('%"+ipDetailsRequest.getFilterText().toUpperCase().trim()+"%')");
	   	   } else if ("DEV".equalsIgnoreCase(ipDetailsRequest.getFilterType()) 
				   && ipDetailsRequest.getFilterText() != null && !ipDetailsRequest.getFilterText().isEmpty()) {
			   ipdetailsQuery.append(" and upper(app.DEVICE_MODEL) like ('%"+ipDetailsRequest.getFilterText().toUpperCase().trim()+"%')");
	   	   } else if ("INC".equalsIgnoreCase(ipDetailsRequest.getFilterType())) {
	   		   ipdetailsQuery.append(" and rt.name not in ('3rd Party/CEP','IP Reg ACL') ");
			   ipdetailsQuery.append(" and (select count(*) from con_fw_rule_application fra where fra.deleted_ti_request_id is null and fra.id = fwrapp.id) <= 0 ");
	   	   } else if ("Retired".equalsIgnoreCase(ipDetailsRequest.getFilterType())) {
			   ipdetailsQuery.append(" and app.is_decommissioned = 'Y' ");
	   	   }
	   }
	   log.debug("IPDetailsServiceImpl::loadIPDetails query - >"+ipdetailsQuery.toString());
	   SQLQuery query = session.createSQLQuery(ipdetailsQuery.toString());
	   query.addEntity("mst", IPAddress.class);
	   query.addScalar("resourcetype", StringType.INSTANCE);
	   int rowCount = getRowCount(ipdetailsQuery.toString());
	   ipDetailsRequest.setRowCount(rowCount);
	   addPagination(query, ipDetailsRequest.getOffset(), ipDetailsRequest.getLimit());
	   List<FireWallRuleIP> ipList = new ArrayList<FireWallRuleIP>();
	   FireWallRuleIP fireWallRuleIP = null;
		
	   List<Object[]> rows = query.list();
		
	   for (Object[] obj : rows) {
			fireWallRuleIP = new FireWallRuleIP();
			fireWallRuleIP.setIpAddress((IPAddress)obj[0]);
			fireWallRuleIP.setResourceType((String)obj[1]);
			ipList.add(fireWallRuleIP);
	   }
	   log.info("IPDetailsServiceImpl::loadIPDetails methods ends...");
	   return ipList;
   }
   
 /*@Override
   public List<FirewallRuleApplication> getFirewallRuleApplications(IPDetailsRequest ipDetailsRequest) {
	   log.info("IPDetailsServiceImpl::getFirewallRuleApplications methods starts...");
		Session session = getSession();
		List<FirewallRuleApplication> firewallRuleApplications = new ArrayList<FirewallRuleApplication>(); 
		StringBuffer fwApplqueryStr = new StringBuffer();
		
		fwApplqueryStr.append("select fra.* from con_fw_rule_application fra left outer join con_ip_master mst " +
				"on mst.id = fra.ip_id where fra.deleted_ti_request_id is null ");
		
		if (ipDetailsRequest != null && ipDetailsRequest.getSelectedIPs() != null && ipDetailsRequest.getSelectedIPs().size() > 0) {
			fwApplqueryStr.append("and mst.id in (");
			
			int i=0;
			for (Long selIp : ipDetailsRequest.getSelectedIPs()) {
				if (i > 0) {
					fwApplqueryStr.append(",");
				}
				fwApplqueryStr.append(selIp);
				i++;
			}
			fwApplqueryStr.append(") ");
		}
		
		if (ipDetailsRequest != null && ipDetailsRequest.getSelectedRuleId() != null && ipDetailsRequest.getSelectedRuleId().longValue() > 0) {
			fwApplqueryStr.append("and fra.rule_id ="+ipDetailsRequest.getSelectedRuleId());
		}
		
		fwApplqueryStr.append(" and fra.ti_request_id = "+ipDetailsRequest.getTiRequest());
		
		SQLQuery query = session.createSQLQuery(fwApplqueryStr.toString());
		log.debug("IPDetailsServiceImpl::getFirewallRuleApplications query---"+query.getQueryString());
		query.addEntity("fra", FirewallRuleApplication.class);
		
		addPagination(query, ipDetailsRequest.getOffset(), ipDetailsRequest.getLimit());
		int rowCount = getRowCount(fwApplqueryStr.toString());
	   	ipDetailsRequest.setRowCount(rowCount);
		
		firewallRuleApplications = (List<FirewallRuleApplication>) query.list();
		log.debug("IPDetailsServiceImpl::getFirewallRuleApplications size---"
				+firewallRuleApplications != null ? firewallRuleApplications.size():"");
		log.info("IPDetailsServiceImpl::getFirewallRuleApplications methods ends...");
		return firewallRuleApplications;
   }*/
   
   @Override
   @Transactional(readOnly = true)
   public List<FirewallRuleApplication> getFirewallRuleApplications(IPDetailsRequest ipDetailsRequest) {
	   log.info("IPDetailsServiceImpl::getFirewallRuleApplications methods starts...");
		Session session = getSession();
		Criteria criteria = session.createCriteria(FirewallRuleApplication.class);
		criteria.createCriteria("tiRequest", "tiRequest");
		
		if (ipDetailsRequest.getTiRequest() != 0) {
		    criteria.add(Restrictions.eq("tiRequest.id", ipDetailsRequest.getTiRequest()));
		}
		
		List<FirewallRuleApplication> firewallRuleApplications = new ArrayList<FirewallRuleApplication>(); 
		
		if (ipDetailsRequest != null && ipDetailsRequest.getSelectedIPs() != null 
				&& ipDetailsRequest.getSelectedIPs().size() > 0) {
			criteria.createCriteria("ipAddress", "ipAddress");
			criteria.add(Restrictions.in("ipAddress.id", ipDetailsRequest.getSelectedIPs()));
		}
		
		if (ipDetailsRequest != null && ipDetailsRequest.getSelectedRuleId() != null 
				&& ipDetailsRequest.getSelectedRuleId().longValue() > 0) {
			criteria.createCriteria("fireWallRule", "fireWallRule");
			
			criteria.add(Restrictions.eq("fireWallRule.id", ipDetailsRequest.getSelectedRuleId()));
			
			if (ipDetailsRequest.getIsIpReg() != null 
					&& !ipDetailsRequest.getIsIpReg().isEmpty()) {
				if (ipDetailsRequest.getIsIpReg().equals("Y")) {
					criteria.add(Restrictions.eq("fireWallRule.isIpReg", "Y"));
				} else {
					criteria.add(Restrictions.sqlRestriction("(IS_IPREG is null or IS_IPREG != 'Y')"));
				}
			}
			
		} else if (ipDetailsRequest != null && ipDetailsRequest.getIsIpReg() != null 
				&& !ipDetailsRequest.getIsIpReg().isEmpty()) {
			criteria.createCriteria("fireWallRule", "fireWallRule");
			if (ipDetailsRequest.getIsIpReg().equals("Y")) {
				criteria.add(Restrictions.eq("fireWallRule.isIpReg", "Y"));
			} else {
				criteria.add(Restrictions.sqlRestriction("(IS_IPREG is null or IS_IPREG != 'Y')"));
			}
		}
		
		session.enableFilter("excludeDeleted");
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		/*ProjectionList projectionList = Projections.projectionList();        
		projectionList.add(Projections.sqlGroupProjection(
	            "application_id as appID, ip_id as ipID", "application_id as appID, ip_id as ipID", new String[] {
	                    "appID", "ipID" }, new Type[] { Hibernate.LONG,
	                    Hibernate.LONG }));
     
		criteria.setProjection(projectionList);*/
		int rowCount = getRowCount(criteria);
		ipDetailsRequest.setRowCount(rowCount);
		addPagination(criteria, ipDetailsRequest.getOffset(), ipDetailsRequest.getLimit());
		
		firewallRuleApplications = (List<FirewallRuleApplication>) criteria.list();
		
		log.debug("IPDetailsServiceImpl::getFirewallRuleApplications size---"
				+firewallRuleApplications != null ? firewallRuleApplications.size():"");
		/*
		//To Group the Applications
		Set<String> ruleList = new HashSet<String>();
		List<FirewallRuleApplication> firewallRuleApplicationList = new ArrayList<FirewallRuleApplication>();
		if (ipDetailsRequest != null && ipDetailsRequest.getSelectedIPs() != null 
				&& ipDetailsRequest.getSelectedIPs().size() > 0 && ipDetailsRequest.getSelectedRuleId() != null 
				&& ipDetailsRequest.getSelectedRuleId().longValue() > 0) {	
			//Already Grouped
			firewallRuleApplicationList.addAll(firewallRuleApplications);
			ipDetailsRequest.setRowCount(getFirewallRuleApplicationsRowCount(ipDetailsRequest, null));
		} else if (ipDetailsRequest != null && ipDetailsRequest.getSelectedIPs() != null 
				&& ipDetailsRequest.getSelectedIPs().size() > 0) {
			//Group by Application, IPAddress
			for (FirewallRuleApplication firewallRuleApplication : firewallRuleApplications) {
				if (ruleList.add(firewallRuleApplication.getIpAddress().getId().toString()
						+firewallRuleApplication.getApplication().getId().toString())) {
					firewallRuleApplicationList.add(firewallRuleApplication);
				}
			}
			log.debug("IPDetailsServiceImpl::firewallRuleApplicationList size---"
					+firewallRuleApplicationList != null ? firewallRuleApplicationList.size():"");
			ipDetailsRequest.setRowCount(getFirewallRuleApplicationsRowCount(ipDetailsRequest, "fra.application_id, fra.ip_id"));
		} else if (ipDetailsRequest != null && ipDetailsRequest.getSelectedRuleId() != null 
				&& ipDetailsRequest.getSelectedRuleId().longValue() > 0) {
			//Group by Application
			for (FirewallRuleApplication firewallRuleApplication : firewallRuleApplications) {
				if (ruleList.add(firewallRuleApplication.getApplication().getId().toString())) {
					firewallRuleApplicationList.add(firewallRuleApplication);
				}
			}
			ipDetailsRequest.setRowCount(getFirewallRuleApplicationsRowCount(ipDetailsRequest, "fra.application_id"));
		}*/
		
		log.info("IPDetailsServiceImpl::getFirewallRuleApplications methods ends...");
		return firewallRuleApplications;
   }
   
   private int getFirewallRuleApplicationsRowCount(IPDetailsRequest ipDetailsRequest, String groupBy) {
	   log.info("IPDetailsServiceImpl::getFirewallRuleApplicationsRowCount methods starts...");
		Session session = getSession();
		StringBuffer fwApplqueryStr = new StringBuffer();
		
		if (groupBy != null) {
			fwApplqueryStr.append("select "+groupBy);
		} else {
			fwApplqueryStr.append("select fra.id ");
		}
		fwApplqueryStr.append(" from con_fw_rule_application fra left outer join con_ip_master mst " +
				"on mst.id = fra.ip_id where fra.deleted_ti_request_id is null ");
		
		if (ipDetailsRequest != null && ipDetailsRequest.getSelectedIPs() != null && ipDetailsRequest.getSelectedIPs().size() > 0) {
			fwApplqueryStr.append("and mst.id in (");
			
			int i=0;
			for (Long selIp : ipDetailsRequest.getSelectedIPs()) {
				if (i > 0) {
					fwApplqueryStr.append(",");
				}
				fwApplqueryStr.append(selIp);
				i++;
			}
			fwApplqueryStr.append(") ");
		}
		
		if (ipDetailsRequest != null && ipDetailsRequest.getSelectedRuleId() != null && ipDetailsRequest.getSelectedRuleId().longValue() > 0) {
			fwApplqueryStr.append("and fra.rule_id ="+ipDetailsRequest.getSelectedRuleId());
		}
		
		fwApplqueryStr.append(" and fra.ti_request_id = "+ipDetailsRequest.getTiRequest());
		if (groupBy != null) {
			fwApplqueryStr.append(" group by "+groupBy);
		}
		
		
		int rowCount = getRowCount(fwApplqueryStr.toString());
		log.debug("IPDetailsServiceImpl::getFirewallRuleApplicationsRowCount ..."+fwApplqueryStr.toString());
		log.debug("IPDetailsServiceImpl::getFirewallRuleApplicationsRowCount ..."+rowCount);
		log.info("IPDetailsServiceImpl::getFirewallRuleApplicationsRowCount methods ends...");
		return rowCount;
   }
   
   @Override
   @Transactional(readOnly = true)
   public List<FireWallRule> getFirewallRulesByIPId(IPDetailsRequest ipDetailsRequest) {
	   log.info("IPDetailsServiceImpl::getFirewallRulesByIPId methods starts...");
	   String isIpReg= ipDetailsRequest.getIsIpReg();
	   String isIp = "";
	   if(isIpReg=="Y")
		{
			isIp = " and rule.is_ipreg='Y'";
		}
		else
		{
			isIp = " and (rule.is_ipreg!='Y' or rule.is_ipreg is null)";
		}
		Session session = getSession();
		List<FireWallRule> firewallRules = new ArrayList<FireWallRule>(); 
		StringBuffer fwApplqueryStr = new StringBuffer();
		fwApplqueryStr.append(" select distinct rule.* from con_ip_master mst "
							 +" left outer join CON_FW_RULE_SOURCE_IP sip on sip.ip_id = mst.id  and sip.deleted_ti_request_id is null "
							 +" left outer join con_fw_rule rule on rule.id = sip.rule_id  and rule.deleted_ti_request_id is null "
							 +" where rule.ti_request_id = " + ipDetailsRequest.getTiRequest() +
							  " and mst.id = " + ipDetailsRequest.getIpAddress().getId() + isIp);
		fwApplqueryStr.append(" union select distinct rule.* from con_ip_master mst "
				 			+" left outer join con_fw_rule_destination_ip dip on dip.ip_id = mst.id  and dip.deleted_ti_request_id is null "
				 			+" left outer join con_fw_rule rule on rule.id = dip.rule_id  and rule.deleted_ti_request_id is null "
				 			+" where rule.ti_request_id = " + ipDetailsRequest.getTiRequest() +
				 			 " and mst.id = " + ipDetailsRequest.getIpAddress().getId() + isIp);
		
		SQLQuery query = session.createSQLQuery(fwApplqueryStr.toString());
		query.addEntity("rule", FireWallRule.class);
		log.debug("IPDetailsServiceImpl::getFirewallRulesByIPId query---"+query.getQueryString());
		firewallRules = (List<FireWallRule>) query.list();
		log.debug("IPDetailsServiceImpl::getFirewallRulesByIPId size---"
				+firewallRules != null ? firewallRules.size():"");
		log.info("IPDetailsServiceImpl::getFirewallRulesByIPId methods ends...");
		return firewallRules;
   }
   
   
   @Override
   @Transactional(readOnly = true)
   public List<IPAddress> getIPsByFirewallRuleId(IPDetailsRequest ipDetailsRequest) {
	   log.info("IPDetailsServiceImpl::getIPsByFirewallRuleId methods starts...");
		Session session = getSession();
		List<IPAddress> firewallRules = new ArrayList<IPAddress>(); 
		StringBuffer fwApplqueryStr = new StringBuffer();
		fwApplqueryStr.append("select distinct mst.* from con_ip_master mst "
							 +" left outer join CON_FW_RULE_SOURCE_IP sip on sip.ip_id = mst.id  and sip.deleted_ti_request_id is null "
							 +" left outer join con_fw_rule rule on rule.id = sip.rule_id  and rule.deleted_ti_request_id is null "
							 +" where rule.ti_request_id = " + ipDetailsRequest.getTiRequest() +
							 		" and rule.id = " + ipDetailsRequest.getSelectedRuleId());
		fwApplqueryStr.append(" union select distinct mst.* from con_ip_master mst "
				 +" left outer join con_fw_rule_destination_ip dip on dip.ip_id = mst.id  and dip.deleted_ti_request_id is null "
				 +" left outer join con_fw_rule rule on rule.id = dip.rule_id  and rule.deleted_ti_request_id is null "
				 +" where rule.ti_request_id = " + ipDetailsRequest.getTiRequest() +
				 		" and rule.id = " + ipDetailsRequest.getSelectedRuleId());
		
		SQLQuery query = session.createSQLQuery(fwApplqueryStr.toString());
		query.addEntity("rule", IPAddress.class);
		log.debug("IPDetailsServiceImpl::getIPsByFirewallRuleId query---"+query.getQueryString());
		firewallRules = (List<IPAddress>) query.list();
		log.debug("IPDetailsServiceImpl::getIPsByFirewallRuleId size---"
				+firewallRules != null ? firewallRules.size():"");
		log.info("IPDetailsServiceImpl::getIPsByFirewallRuleId methods ends...");
		return firewallRules;
   }
   
   @Override
   public void saveFirewallRuleApplications(IPDetailsRequest ipDetailsRequest) {
	   Session session = getSession();
	   FireWallRule fireWallRule = null;
	   TIRequest tiRequest = new TIRequest();
	   tiRequest.setId(ipDetailsRequest.getTiRequest());
	   List<FirewallRuleApplication> firewallRuleApplications = ipDetailsRequest.getFirewallRuleAppList();
	   List<FirewallRuleApplication> toInsertList = new ArrayList<FirewallRuleApplication>();
	  //To set the Firewall Rule Objects
	   for (FirewallRuleApplication firewallRuleApplication : firewallRuleApplications) {
	   		if (firewallRuleApplication.getFireWallRule().getUpdated_date() == null
	   				|| firewallRuleApplication.getFireWallRule().getUpdated_date().toString().isEmpty()) {
	   			fireWallRule = (FireWallRule) session.get(
	   					FireWallRule.class, firewallRuleApplication.getFireWallRule().getId());
	   			firewallRuleApplication.setFireWallRule(fireWallRule);
	   		}
	   		
	   		if (firewallRuleApplication.getApplication() != null && 
	   				firewallRuleApplication.getApplication().getIsDevice() != null && 
	   				firewallRuleApplication.getApplication().getIsDevice().equalsIgnoreCase("Y")) {
	   			StringBuffer queryStr = new StringBuffer();
	   			queryStr.append(" from com.citigroup.cgti.c3par.common.domain.Application app where ");
	   			queryStr.append(" app.deviceTypeId="+firewallRuleApplication.getApplication().getDeviceTypeId());
	   			queryStr.append(" and upper(app.deviceModel) = upper('"+firewallRuleApplication.getApplication().getDeviceModel()+"')");
	   			
	   			Application app = null;
	   			List<Application> appList = (List<Application>)session.createQuery(queryStr.toString()).list();
	   			if (appList != null && appList.size() > 0) {
	   				app = appList.get(0);
	   				if(firewallRuleApplication.getApplication().getSecClassification() != null){
	   					app.setSecClassification(firewallRuleApplication.getApplication().getSecClassification());
	   				}if(firewallRuleApplication.getApplication().getPerDataIndicator() != null){
	   					app.setPerDataIndicator(firewallRuleApplication.getApplication().getPerDataIndicator());
	   				}
	   				firewallRuleApplication.setApplication(app);
	   			}
	   			if (app != null && app.getId() != null) {
		   			queryStr = new StringBuffer();
		   			queryStr.append(" from FirewallRuleApplication fa where fa.ipAddress.id = "+firewallRuleApplication.getIpAddress().getId());
		   			queryStr.append(" and fa.fireWallRule.id = "+firewallRuleApplication.getFireWallRule().getId());
		   			queryStr.append(" and fa.application.id = "+app.getId());
		   			List<FirewallRuleApplication> fwappList = (List<FirewallRuleApplication>)session.createQuery(queryStr.toString()).list();
		   			if (fwappList == null || fwappList.size() <= 0) {
		   				toInsertList.add(firewallRuleApplication);
		   			}else{
		   				FirewallRuleApplication fwRuleApplication = fwappList.get(0);
		   				if(fwRuleApplication != null && fwRuleApplication.getDeletedTIRequest() != null){
		   					fwRuleApplication.setDeletedTIRequest(null);
		   					fwRuleApplication.setUpdatedTIRequest(tiRequest);
		   					toInsertList.add(fwRuleApplication);
		   				}			   				
		   			}
	   			} else {
		   			toInsertList.add(firewallRuleApplication);
	   			}	   			
	   		} else {
	   			if (firewallRuleApplication.getApplication().getIsCSI().equalsIgnoreCase("Y")) {
	   				StringBuffer queryStr = new StringBuffer();
		   			queryStr.append(" from com.citigroup.cgti.c3par.common.domain.Application app where ");
		   			queryStr.append(" app.applicationID = "+firewallRuleApplication.getApplication().getApplicationID());
		   			
		   			Application app = null;
		   			List<Application> appList = (List<Application>)session.createQuery(queryStr.toString()).list();
		   			if (appList != null && appList.size() > 0) {
		   				app = appList.get(0);
		   				if(firewallRuleApplication.getApplication().getSecClassification() != null){
		   					app.setSecClassification(firewallRuleApplication.getApplication().getSecClassification());
		   				}if(firewallRuleApplication.getApplication().getPerDataIndicator() != null){
		   					app.setPerDataIndicator(firewallRuleApplication.getApplication().getPerDataIndicator());
		   				}
		   				firewallRuleApplication.setApplication(app);
		   			}
		   			if (app != null && app.getId() != null) {
			   			queryStr = new StringBuffer();
			   			queryStr.append(" from FirewallRuleApplication fa where fa.ipAddress.id = "+firewallRuleApplication.getIpAddress().getId());
			   			queryStr.append(" and fa.fireWallRule.id = "+firewallRuleApplication.getFireWallRule().getId());
			   			queryStr.append(" and fa.application.id = "+app.getId());
			   			List<FirewallRuleApplication> fwappList = (List<FirewallRuleApplication>)session.createQuery(queryStr.toString()).list();
			   			if (fwappList == null || fwappList.size() <= 0) {
			   				toInsertList.add(firewallRuleApplication);
			   			}else{
			   				FirewallRuleApplication fwRuleApplication = fwappList.get(0);
			   				if(fwRuleApplication != null && fwRuleApplication.getDeletedTIRequest() != null){
			   					fwRuleApplication.setDeletedTIRequest(null);
			   					fwRuleApplication.setUpdatedTIRequest(tiRequest);
			   					toInsertList.add(fwRuleApplication);
			   				}			   				
			   			}
		   			} else {
		   				toInsertList.add(firewallRuleApplication);
		   			}
		   		} else {
		   			StringBuffer queryStr = new StringBuffer();
		   			queryStr.append(" from com.citigroup.cgti.c3par.common.domain.Application app where ");
		   			queryStr.append(" upper(app.applicationName)= upper('"+firewallRuleApplication.getApplication().getApplicationName()+"')");
		   			queryStr.append(" and upper(app.function) = upper('"+firewallRuleApplication.getApplication().getFunction()+"')");
		   			queryStr.append(" and upper(app.appOwnerFullName) = upper('"+firewallRuleApplication.getApplication().getAppOwnerFullName()+"')");
		   			queryStr.append(" and upper(app.appOwnerGEID) = upper('"+firewallRuleApplication.getApplication().getAppOwnerGEID()+"')");
		   			
		   			Application app = null;
		   			List<Application> appList = (List<Application>)session.createQuery(queryStr.toString()).list();
		   			if (appList != null && appList.size() > 0) {
		   				app = appList.get(0);
		   				firewallRuleApplication.setApplication(app);
		   			}
		   			if (app != null && app.getId() != null) {
			   			queryStr = new StringBuffer();
			   			queryStr.append(" from FirewallRuleApplication fa where fa.ipAddress.id = "+firewallRuleApplication.getIpAddress().getId());
			   			queryStr.append(" and fa.fireWallRule.id = "+firewallRuleApplication.getFireWallRule().getId());
			   			queryStr.append(" and fa.application.id = "+app.getId());
			   			List<FirewallRuleApplication> fwappList = (List<FirewallRuleApplication>)session.createQuery(queryStr.toString()).list();
			   			if (fwappList == null || fwappList.size() <= 0) {
			   				toInsertList.add(firewallRuleApplication);
			   			}else{
			   				FirewallRuleApplication fwRuleApplication = fwappList.get(0);
			   				if(fwRuleApplication != null && fwRuleApplication.getDeletedTIRequest() != null){
			   					fwRuleApplication.setDeletedTIRequest(null);
			   					fwRuleApplication.setUpdatedTIRequest(tiRequest);
			   					toInsertList.add(fwRuleApplication);
			   				}			   				
			   			}
		   			} else {
		   				toInsertList.add(firewallRuleApplication);
		   			}
		   		}
	   		}
	   }
	   if(toInsertList!=null && toInsertList.size()>0){
		   for(FirewallRuleApplication firewallRuleApplication:toInsertList){
			   getHibernateTemplate().saveOrUpdate(firewallRuleApplication);  
		   }
	   }
	   
   }
   
   @Override
	public void editFirewallRuleApplications(Application app, List<Long> selectedIPs, List<Long>  selectedRules) {
		log.info("IPDetailsServiceImpl::editFirewallRuleApplications methods starts...");
		Long appId = app.getId();
		
		log.debug("IPDetailsServiceImpl::editFirewallRuleApplications App Id at beginning :-" + appId );
		
		Session session = getSession();
				
		log.debug("IPDetailsServiceImpl::editFirewallRuleApplications final app ID :-" + appId );
		
		String ips = selectedIPs.toString().substring(selectedIPs.toString().indexOf("[")+1, selectedIPs.toString().indexOf("]"));
		String rules = selectedRules.toString().substring(selectedRules.toString().indexOf("[")+1, selectedRules.toString().indexOf("]"));
		
		String sql = "update con_fw_rule_application " + 
				"set APPLICATION_ID =" + appId + " "+ 
				"where IP_ID in (" + ips+ ") " + " and RULE_ID in (" + rules + ")";
		
		log.debug("IPDetailsServiceImpl::editFirewallRuleApplications update sql stmt :-" + sql);
		
		SQLQuery updatequery = getSession().createSQLQuery(sql);
		int updatedrows = updatequery.executeUpdate();
		
		log.debug("IPDetailsServiceImpl::editFirewallRuleApplications sql stmt :-" + updatedrows);		
		log.info("IPDetailsServiceImpl::editFirewallRuleApplications methods ends...");
	}
   
   @Override
   public Application checkApplicationExists(Application app){
	   Long appId = app.getId();
		
		log.info("IPDetailsServiceImpl::editFirewallRuleApplications App Id at beginning :-" + appId );
		
		Session session = getSession();
		StringBuffer queryStr = null;
		if (app != null && app.getIsDevice().equalsIgnoreCase("Y")) {
			queryStr = new StringBuffer();
			queryStr.append(" from com.citigroup.cgti.c3par.common.domain.Application app where ");
			queryStr.append(" app.deviceTypeId=" + app.getDeviceTypeId());
			queryStr.append(" and upper(app.deviceModel) = upper('" + app.getDeviceModel() + "')");
			
			log.info("IPDetailsServiceImpl::editFirewallRuleApplications IS device == Y query :-" + queryStr.toString() );
			
			List<Application> appList = (List<Application>) session.createQuery(queryStr.toString()).list();
			
			if (appList != null && appList.size() > 0) {
				app = appList.get(0);				
			} else {
				appId = (Long) getHibernateTemplate().save(app);
				app = getHibernateTemplate().get(Application.class, appId);
			}
		} else if (app != null && app.getIsCSI().equalsIgnoreCase("N")) {
			queryStr = new StringBuffer();
			queryStr.append(" from com.citigroup.cgti.c3par.common.domain.Application app where ");
			queryStr.append(" upper(app.applicationName)= upper('" + app.getApplicationName() + "')");
			queryStr.append(" and upper(app.function) = upper('" + app.getFunction() + "')");
			queryStr.append(" and upper(app.appOwnerFullName) = upper('" + app.getAppOwnerFullName() + "')");
			queryStr.append(" and upper(app.appOwnerGEID) = upper('" + app.getAppOwnerGEID() + "')");
			
			log.info("IPDetailsServiceImpl::editFirewallRuleApplications IS CSI == N query :-" + queryStr.toString() );
			
			List<Application> appList = (List<Application>) session.createQuery(queryStr.toString()).list();
			if (appList != null && appList.size() > 0) {
				app = appList.get(0);				
			} else {
				appId = (Long) getHibernateTemplate().save(app);
				app = getHibernateTemplate().get(Application.class, appId);
			}
		}
		return app;
   }
   
   
   @Override
   @Transactional(readOnly = true)
   public FirewallRuleApplication getFirewallRuleApplication(Long id) {
	   log.info("IPDetailsServiceImpl::getFirewallRuleApplication methods starts...");
		Session session = getSession();
		FirewallRuleApplication firewallRuleApplication = null;
		StringBuffer fwApplqueryStr = new StringBuffer();
		
		fwApplqueryStr.append("from FirewallRuleApplication fwrapp where fwrapp.id = "+id);
		
		Query query = session.createQuery(fwApplqueryStr.toString());
		log.debug("IPDetailsServiceImpl::getFirewallRuleApplications query---"+query.getQueryString());
		firewallRuleApplication = (FirewallRuleApplication) query.uniqueResult();
		log.info("IPDetailsServiceImpl::getFirewallRuleApplication methods ends...");
		return firewallRuleApplication;
   }
   
   @Override
   public void deleteFirewallRuleApplications(IPDetailsRequest ipDetailsRequest) {
		Session session = getSession();
		
		List<FirewallRuleApplication> firewallRuleApplications = ipDetailsRequest.getFirewallRuleAppList();
    	List<Long> selectedIDs = new ArrayList<Long>();
    	for (FirewallRuleApplication firewallRuleApplication : firewallRuleApplications) {
    		if (firewallRuleApplication.isSelected()) {
    			selectedIDs.add(firewallRuleApplication.getId());
    			StringBuffer fwApplqueryStr = new StringBuffer();
    			fwApplqueryStr.append("update con_fw_rule_application set deleted_ti_request_id = "+ipDetailsRequest.getTiRequest());
    			
    			fwApplqueryStr.append(" where application_id = "+firewallRuleApplication.getApplication().getId());
    			if (ipDetailsRequest != null && ipDetailsRequest.getSelectedIPs() != null && ipDetailsRequest.getSelectedIPs().size() > 0) {
    				fwApplqueryStr.append(" and ip_id = "+firewallRuleApplication.getIpAddress().getId());
    			}
    			
    			if (ipDetailsRequest != null && ipDetailsRequest.getSelectedRuleId() != null && ipDetailsRequest.getSelectedRuleId().longValue() > 0) {
    				fwApplqueryStr.append(" and rule_id ="+ipDetailsRequest.getSelectedRuleId());
    			}
    			
    			fwApplqueryStr.append(" and ti_request_id = "+ipDetailsRequest.getTiRequest());
    			
    			SQLQuery query = session.createSQLQuery(fwApplqueryStr.toString());
    			int rows = query.executeUpdate();
    			log.debug("IPDetailsServiceImpl::deleteFirewallRuleApplications count---"+rows);
    		}
    	}
   }

}
