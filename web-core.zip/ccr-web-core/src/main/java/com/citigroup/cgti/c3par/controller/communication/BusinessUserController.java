package com.citigroup.cgti.c3par.controller.communication;

import java.sql.Clob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.communication.domain.BusinessUserProcess;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestContactXref;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestNotes;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;

@Controller
public class BusinessUserController {  
	
	private static Logger log = Logger.getLogger(BusinessUserController.class);
	
	/**
	 * 
	 * @param model
	 * TO loadEcmEmailTool  
	 * @param request
	 * @return
	 * @throws SQLException 
	 */  
	@RequestMapping(value = "/businessUserComments.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String loadCmpDetailsView(ModelMap model,@ModelAttribute("businessUserProcess") BusinessUserProcess businessUserProcess,HttpServletRequest request) throws SQLException {
		log.debug("Start BusinessUserController.....");
		if(businessUserProcess == null){
			businessUserProcess = new BusinessUserProcess();
        }
		String cmpReqId = request.getParameter("cmpId"); 
		businessUserProcess.setCmpId(cmpReqId);
		businessUserProcess.setActCode(request.getParameter("actCode"));
		//businessUserProcess.setReqAdditionalInfo(businessUserProcess.getAdditionalText());
		log.debug("cmpereqId in loadactcode: "+businessUserProcess.getActCode());
		CMPRequest cmpRequest =null;
		if(cmpReqId != null && !cmpReqId.isEmpty()){
			cmpRequest = businessUserProcess.getCMPRequestDetails(cmpReqId);
			log.info("CmpDetailsViewController :: cmpRequest inside "+cmpRequest);
			if(cmpRequest != null){
			if (cmpRequest.getCcrId() != null
					&& !cmpRequest.getCcrId().isEmpty()) {
				if(cmpRequest.getCcrId().indexOf(".") > 0){
					cmpRequest.setCcrId(cmpRequest.getCcrId().substring(0, cmpRequest.getCcrId().indexOf(".")));
				}
				
				cmpRequest.setChangeRequestDetails(businessUserProcess
						.getChangeRequestDetails(Long.valueOf(cmpRequest
								.getCcrId().trim())
								,cmpRequest.getOrderId()));
			}
			
		}
		for(CMPRequestNotes cmpNote :  cmpRequest.getCmpRequestNotes() ){
			try{
			if(cmpNote!=null && cmpNote.getNewNotes()!=null){	
				Clob clob = cmpNote.getNewNotes();
				log.info("Clob Length "+clob.length());
				String wholeClob = clob.getSubString(1, (int) clob.length());
				cmpNote.setNotes(wholeClob);
			}
			}
			catch(Exception e){
				log.error(e,e);
			}
		}
		//log.info("BusinessUserController Load :: cmpRequest  Order item iD"+cmpRequest.getOrderItemId());
		businessUserProcess.setCmpRequest(cmpRequest); 
		}
		List<String> urlKey = new ArrayList<String>();
		urlKey.add("CASP_URL");
		// urlKey.add("GLOBAL_DIR_URL");
		urlKey.add("RESOLVE_IT_DETAIL_URL");
		List<GenericLookup> urlList = businessUserProcess
				.loadGenericLookupData(urlKey);
		if (urlList != null) {
			for (GenericLookup url : urlList) {
				if (url != null && url.getValue1().equalsIgnoreCase("CASP_URL")) {
					businessUserProcess.setCaspUrl(url.getValue2());
					/*
					 * } else if(url != null &&
					 * url.getValue1().equalsIgnoreCase("GLOBAL_DIR_URL")){
					 * emailGenerationViewProcess
					 * .setGlobalDirUrl(url.getValue2());
					 */
				} else if (url != null
						&& url.getValue1().equalsIgnoreCase(
								"RESOLVE_IT_DETAIL_URL")) {
					businessUserProcess.setResolveItDetailUrl(url
							.getValue2());
				}
			}
		}

		
		model.addAttribute("businessUserProcess", businessUserProcess); 
				
		log.debug("BusinessUserController :: loadCmpDetailsView :: Ends .....");      
		
		return "c3par.communication.businessUser";
		//return "pages/communication/BusinessUser";
	}
	
	@RequestMapping(value = "/businessUserCommentsSubmit.act", method = {RequestMethod.GET,RequestMethod.POST})
	public String submitUserComments(ModelMap model,@ModelAttribute("businessUserProcess") BusinessUserProcess businessUserProcess,BindingResult result,HttpServletRequest request) throws SQLException {
		log.debug("Start submitUserComments.....");
		String cmpReqId = businessUserProcess.getCmpId(); 
		String  actCode = businessUserProcess.getActCode();
		 log.debug("cmpereqId in submitUserComments: "+cmpReqId);
		 log.debug("cmpereqId in submitUserCommentsactcode: "+actCode);
		String agentSsoId = request.getHeader("SM_USER").toUpperCase();
		String forward = "c3par.communication.businessUser";
		CMPRequest cmpRequest = null;
		
		CommonsMultipartFile commonsMultipartFile= businessUserProcess.getAddUploadfile();
		if(commonsMultipartFile != null){
			log.debug("Uploaded File Name: "+commonsMultipartFile.getOriginalFilename()); 
		}
		
		//CMPRequest cmpRequest =null;
		if(cmpReqId != null && !cmpReqId.isEmpty()){
			cmpRequest = businessUserProcess.getCMPRequestDetails(cmpReqId);
			log.info("CmpDetailsViewController :: cmpRequest inside submitUserComments"+cmpRequest);
			if(cmpRequest != null){
			if (cmpRequest.getCcrId() != null
					&& !cmpRequest.getCcrId().isEmpty()) {
				if(cmpRequest.getCcrId().indexOf(".") > 0){
					cmpRequest.setCcrId(cmpRequest.getCcrId().substring(0, cmpRequest.getCcrId().indexOf(".")));
				}
				cmpRequest.setChangeRequestDetails(businessUserProcess
						.getChangeRequestDetails(Long.valueOf(cmpRequest
								.getCcrId().trim()),cmpRequest.getOrderId()));
			}
		

		//Validation starts
		if(!businessUserProcess.isWaitingforECMUserReply(cmpRequest.getId(), actCode)){
			  result.addError(new ObjectError("cmpRequestId","BusinessUser comments already submitted. Awaiting for ECMUser reply."));
			  return forward;
		}
		
		businessUserProcess.setCmpRequest(cmpRequest); 
		}
		}
		//ADD NOTE
		CMPRequestNotes cmpRequestNotes = new CMPRequestNotes();
		cmpRequestNotes.setCmpRequest(cmpRequest);
		cmpRequestNotes.setNotes(businessUserProcess.getAddNote());	
		
		cmpRequestNotes.setCreated_date(new Date());	
		cmpRequestNotes.setType("BusinessUser");
		cmpRequestNotes.setFiletype(commonsMultipartFile.getOriginalFilename());
		cmpRequestNotes.setUploadfile(commonsMultipartFile.getBytes());
		
		if(actCode != null && !actCode.isEmpty()){
			if(actCode.equalsIgnoreCase("awaiting_additional_info")){
				actCode = "awaiting_additional_info_resp";
			} else if(actCode.equalsIgnoreCase("awaiting_paf_faf_verify")){
				actCode = "awaiting_paf_faf_verify_resp";
			} else if(actCode.equalsIgnoreCase("awaiting_assist_term_log")){
				actCode = "awaiting_assist_term_log_resp";
			} else if(actCode.equalsIgnoreCase("awaiting_additional_info_assign")){
				actCode = "awaiting_additional_info_assign_resp";
			}
		}
		//log.debug("getid:"+cmpRequest.getId());
		//businessUserProcess.cmpActivityTrail(cmpRequest.getId(), agentSsoId, actCode, ECMConstants.STATUS_SCHEDULED);
		//log.debug("tHE ORDERED ID: "+cmpRequest.getOrderId()+"/ User Comments: "+ cmpRequestNotes.getNotes()+" /Uploded File: " /*+new String(cmpRequestNotes.getUploadfile())*/ );
        log.info("BusinessUserController enter: sendEmailGeneration: starts - emailGenerationViewProcess.getChooseEmail()");
		
		CmpRequestDTO cmpRequestDTO = new CmpRequestDTO();
		CitiContact citiContact = null;
		
		citiContact = businessUserProcess.getAgentDetails(agentSsoId);
		if(cmpRequestDTO != null && cmpRequest != null){
		cmpRequestDTO.setCmpId(cmpRequest.getOrderItemId());
		cmpRequestDTO.setSsoId(agentSsoId);
		cmpRequestDTO.setSecondTemplate(false);
		for(CMPRequestNotes cmpNote :  cmpRequest.getCmpRequestNotes() ){
			if(cmpNote!=null && cmpNote.getNewNotes()!=null){	
				try{
				Clob clob = cmpNote.getNewNotes();
				String wholeClob = clob.getSubString(1, (int) clob.length());
				cmpRequestDTO.setBusinessResponse(wholeClob);
				}
				catch(Exception e){
					log.error(e,e);
				}
			}
		}
		cmpRequestDTO.setBusinessResponse(businessUserProcess.getAddNote()); 
		cmpRequestDTO.setCcrId(cmpRequest.getCcrId());
		cmpRequestDTO.setCmpRequestId(cmpRequest.getId());
		cmpRequestDTO.setBj(cmpRequest.getBusinessjustification());	 		
		cmpRequestDTO.setRegion(cmpRequest.getRegion());
		cmpRequestDTO.setSector(cmpRequest.getAssignedGroup());			
		cmpRequestDTO.setUrgency(cmpRequest.getRequestUrgency());
		cmpRequestDTO.setRequestType(cmpRequest.getRequestType());
		
		cmpRequestDTO.setTextForSubject(businessUserProcess.getTextForSubject());
		cmpRequestDTO.setAddInfo(businessUserProcess.getAdditionalText()); 
		cmpRequestDTO.setAssistanceRequested(businessUserProcess.getAssistanceRequested());
		cmpRequestDTO.setCancelReason(businessUserProcess.getCancelReason());
		cmpRequestDTO.setReAssignedUser(businessUserProcess.getAssignedUser());
		
		cmpRequestDTO.setAgentName(citiContact.getFirstName()+ " " +citiContact.getLastName());
		cmpRequestDTO.setAgentPhone(citiContact.getPhone());
		cmpRequestDTO.setAgentEmail(citiContact.getEmail());	
		cmpRequestDTO.setChooseEmail(actCode);

		// read attached file
		if (businessUserProcess.getAddUploadfile() != null
				&& !businessUserProcess.getAddUploadfile().isEmpty()) {
			log.info("BusinessUserController :: sendEmailGeneration :: file Uploaded ");
			HashMap<String, byte[]> fileToAttach = new HashMap<String, byte[]>();

			CommonsMultipartFile uploadedFile = businessUserProcess.getAddUploadfile();
			log.info("BusinessUserController :: sendEmailGeneration :: file Uploaded :: fileName - "
					+ uploadedFile.getOriginalFilename()
					+ " :: Size - "
					+ uploadedFile.getSize());

			byte[] bytefileContent = uploadedFile.getBytes();

			fileToAttach.put(uploadedFile.getOriginalFilename(),bytefileContent);
			cmpRequestDTO.setFileAttachments(fileToAttach);
		}
		}
		StringBuilder requestorName = new StringBuilder("");
		StringBuilder primaryOwnerName = new StringBuilder("");
		StringBuilder secondaryOwnerName = new StringBuilder("");
		StringBuilder isoName = new StringBuilder("");
		StringBuilder toAddress = new StringBuilder("");
		StringBuilder ccAddress = new StringBuilder("");
		//StringBuilder chgId = new StringBuilder("");
		//StringBuilder chgDate = new StringBuilder("");
		
		
		
			
		//log.debug("enter"+cmpRequest.getCmpRequestContactXrefs());
		if(cmpRequest != null){
		for (CMPRequestContactXref cmpRequestContactXref : cmpRequest.getCmpRequestContactXrefs()){
            String role = cmpRequestContactXref.getRole().getName();
            
            if(role != null && role.length() > 0 && cmpRequestContactXref.getCiticontact() != null){
            
            if("Requestor".equalsIgnoreCase(role)){
            	if(requestorName.length() < 1){
            		requestorName.append(cmpRequestContactXref.getCiticontact().getFirstName()+ " " +cmpRequestContactXref.getCiticontact().getLastName());
            	}
            	else{
            		requestorName.append(", " +cmpRequestContactXref.getCiticontact().getFirstName()+ " " +cmpRequestContactXref.getCiticontact().getLastName());
            	}
            	if(toAddress.length() < 1){
            		toAddress.append(cmpRequestContactXref.getCiticontact().getEmail());
            	}
            	else{
            		toAddress.append("; " +cmpRequestContactXref.getCiticontact().getEmail());
            	}
            	if(!"E".equalsIgnoreCase(cmpRequestContactXref.getCiticontact().getEmployeeType())){
            		cmpRequestDTO.setSecondTemplate(true);
            	}
            }
            else if("Business_Owner".equalsIgnoreCase(role)){
            	if(primaryOwnerName.length() < 1){
            		primaryOwnerName.append(cmpRequestContactXref.getCiticontact().getFirstName()+ " " +cmpRequestContactXref.getCiticontact().getLastName());
            	}
            	else{
            		primaryOwnerName.append(", " +cmpRequestContactXref.getCiticontact().getFirstName()+ " " +cmpRequestContactXref.getCiticontact().getLastName());
            	}
            	if(ccAddress.length() < 1){
            		ccAddress.append(cmpRequestContactXref.getCiticontact().getEmail());                		
            	}
            	else{
            		ccAddress.append("; " +cmpRequestContactXref.getCiticontact().getEmail());
            	}
            }
            else if("Sec_Business_Owner".equalsIgnoreCase(role)){
            	if(secondaryOwnerName.length() < 1){
            		secondaryOwnerName.append(cmpRequestContactXref.getCiticontact().getFirstName()+ " " +cmpRequestContactXref.getCiticontact().getLastName());
            	}
            	else{
            		secondaryOwnerName.append(", " +cmpRequestContactXref.getCiticontact().getFirstName()+ " " +cmpRequestContactXref.getCiticontact().getLastName());
            	}
            	if(ccAddress.length() < 1){
            		ccAddress.append(cmpRequestContactXref.getCiticontact().getEmail());                		
            	}
            	else{
            		ccAddress.append("; " +cmpRequestContactXref.getCiticontact().getEmail());
            	}
            }
            else if("BISO".equalsIgnoreCase(role)){
            	if(isoName.length() < 1){
            		isoName.append(cmpRequestContactXref.getCiticontact().getFirstName()+ " " +cmpRequestContactXref.getCiticontact().getLastName());
            	}
            	else{
            		isoName.append(", " +cmpRequestContactXref.getCiticontact().getFirstName()+ " " +cmpRequestContactXref.getCiticontact().getLastName());
            	}
            	if(ccAddress.length() < 1){
            		ccAddress.append(cmpRequestContactXref.getCiticontact().getEmail());                		
            	}
            	else{
            		ccAddress.append("; " +cmpRequestContactXref.getCiticontact().getEmail());
            	}
            }
            else {
            	if(ccAddress.length() < 1){
            		ccAddress.append(cmpRequestContactXref.getCiticontact().getEmail());                		
            	}
            	else{
            		ccAddress.append("; " +cmpRequestContactXref.getCiticontact().getEmail());
            	}                
            }
            }
		}		
		}
		//cmpRequestDTO.setChgId(chgId.toString());
		//cmpRequestDTO.setChgDate(chgDate.toString());
		if(cmpRequest != null && cmpRequestDTO != null){
		if(cmpRequest.getAssignedUser()!=null){
			cmpRequestDTO.setRequestorName(cmpRequest.getAssignedUser().getFirstName()+" "+cmpRequest.getAssignedUser().getLastName());
			cmpRequestDTO.setToAddresses(cmpRequest.getAssignedUser().getEmail());
		}
		cmpRequestDTO.setPrimaryOwnerName(primaryOwnerName.toString());
		cmpRequestDTO.setSecondaryOwnerName(secondaryOwnerName.toString());
		cmpRequestDTO.setIsoName(isoName.toString());
		//cmpRequestDTO.setToAddresses(cmpRequest.getAssignedUser().getEmail()); 
		
		
		//send Email
		log.info("start send email");
		String businessEmail = "BUSINESS_USER_REPLY";
		businessUserProcess.sendEmailGenerationView(businessEmail , cmpRequestDTO);
		
		cmpRequestNotes.setCmpRequest(cmpRequest);
		cmpRequestNotes.setCreated_date(new Date());
		
		businessUserProcess.updateAddNoteDetails(cmpRequestNotes);	
		businessUserProcess.setAddNote("");
		}
		request.setAttribute("message", "Thank you for your comments. You may now close this window.");
		model.addAttribute("businessUserProcess", businessUserProcess);
		
		log.debug("End submitUserComments .....");
		return forward;
		
	}
	
	
}
