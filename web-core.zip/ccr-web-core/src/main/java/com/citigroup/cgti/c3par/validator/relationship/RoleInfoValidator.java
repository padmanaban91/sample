package com.citigroup.cgti.c3par.validator.relationship;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
* The Class RoleInfoValidator.
*/
public class RoleInfoValidator {

	/** The m. */
	Map<Long,Set> m = new HashMap<Long,Set>();

	/**
	 * Validate contact role.
	 *
	 * @param contactId the contact id
	 * @param roleId the role id
	 * @return true, if successful
	 */
	public boolean validateContactRole(Long contactId, Long roleId) {
	    boolean isValid = true ;

	    if(contactId == null) {
		// this should never happen as the web application functionality
		// never allows to enter a null contact.
	    } else {
			Set<Long> roleIdSet = null ;
	
			if(m.containsKey(contactId))
			    roleIdSet = (Set<Long>) m.get(contactId);
			else {
			    roleIdSet = new HashSet<Long>();
			    m.put(contactId, roleIdSet);
			}
	
			if(roleId == null) {
			    // if this is the case it is ok.
			    // a contact may not have been assigned any role.
			} else {
			    if (roleIdSet.contains(roleId)) {
					// following implies that the 
					// contact already has an entry with the 
					// given role. So it is invalid
					isValid = false ;
			    } else {
					// since this is the first time the roleId is identified
					// put it into the set.
					roleIdSet.add(roleId);
			    }
			}
	    }
	    return isValid ; 
	}
}
