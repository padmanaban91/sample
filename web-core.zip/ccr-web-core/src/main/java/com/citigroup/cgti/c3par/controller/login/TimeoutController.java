package com.citigroup.cgti.c3par.controller.login;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.citigroup.cgti.c3par.util.C3parProperties;

@Controller
public class TimeoutController {
	
	/** The log. */
	private static Logger log = Logger.getLogger(TimeoutController.class);
	
	@RequestMapping(value = "/timeout.act")
	public String disclaimer(HttpServletRequest request){
		log.info("TimeoutController starts here..");
		try {
		    request.getSession().invalidate();
		    request.setAttribute("TIMEOUT_URL", C3parProperties.TIMEOUT_URL);

		} catch (IllegalStateException lse) {
		}

		return "login/timeout";
	}
	
}
