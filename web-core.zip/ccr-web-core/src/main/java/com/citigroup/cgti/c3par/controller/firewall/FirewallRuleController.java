package com.citigroup.cgti.c3par.controller.firewall;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Blob;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.decisionservice.TiRequestDTO;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FireWallPolicyGroup;
import com.citigroup.cgti.c3par.fw.domain.FireWallRule;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleDestinationIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleSourceIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallZone;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleApplication;
import com.citigroup.cgti.c3par.fw.domain.FirewallRulePolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRuleQuestionnaire;
import com.citigroup.cgti.c3par.fw.domain.FirewallRulesExport;
import com.citigroup.cgti.c3par.fw.domain.HistoryFireWallRule;
import com.citigroup.cgti.c3par.fw.domain.HistoryFirewallRulePolicy;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.IPDetailsRequest;
import com.citigroup.cgti.c3par.fw.domain.PersonalObject;
import com.citigroup.cgti.c3par.fw.domain.PersonalObjectIP;
import com.citigroup.cgti.c3par.fw.domain.PersonalObjectPort;
import com.citigroup.cgti.c3par.fw.domain.Port;
import com.citigroup.cgti.c3par.fw.domain.SearchFirewallRuleRequest;
import com.citigroup.cgti.c3par.fw.domain.TIUploadedDocs;
import com.citigroup.cgti.c3par.fw.domain.TemplateConnection;
import com.citigroup.cgti.c3par.fw.service.FirewallRulesExportService;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiHierarchyXref;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.webtier.helper.ExcelReader;
import com.citigroup.cgti.c3par.webtier.helper.RiskExecutionThread;

@Controller
public class FirewallRuleController extends BaseController {
	
	 private static final String ON_IN_PROGRESS = "ONINPROGRESS";

    private static final String OFF = "OFF";

    private static final String FIREWALL_RULE_DOCTYPE = "FW_BULK_UPLOAD";
    
    private static final String IP_REG_DOCTYPE = "IPREG_BULK_UPLOAD";
    
    private static final String FIREWALL_RULE_CONTENT_TYPE = "application/vnd.ms-excel";
    
    private static final String FLOW_OF_DATA_ATOB = "Endpoint A -> Endpoint B";
    
    private static final String OBJECT = "OBJECT";
    
    private static final String FIREWALLGROUP_TEMPLATE = "TEMPLATE_FIREWALLGROUP";
    
    @Autowired
    FirewallRulesExportService firewallRulesExportService;

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	//To load the Firewall Rules
	/**
	 * 
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/loadFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String loadFirewallRules(HttpServletRequest request, ModelMap model) {
		log.info("FirewallRuleController::loadFirewallRules methods starts...");
        String forwardPage = "c3par.firewall.listfirewallRules";
         FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
          List<FireWallRule> fireWallRules = null;
          List<HistoryFireWallRule> fireWallRulesTemp = null;
          log.debug("In ManageFWRule Action Load FWRule getFirewallRulesCollectionLimit ---"+firewallRuleProcess.getCollectionLimit());
          TIRequest tiRequest = null;
          String requestType =  null;
          tiRequest = getTirequest(request);
          if (tiRequest.getTiRequestType() != null
                      && tiRequest.getTiRequestType().getName() != null) {
                requestType = tiRequest.getTiRequestType().getName() ;
                log.debug(" Request Type :: " + requestType);
                if (requestType != null
                            && requestType.equalsIgnoreCase("Terminate")) {
                      log.debug("Setting DisplayMode to View for Termination Cycle");
                      request.getSession().setAttribute("displayMode", "View");
                }
          }
          
          Long tiRequestID = 0L, processID = 0L;
          
          String fromPage = request.getParameter("fromPage");
          
          String con_type = (String) request.getSession().getAttribute("con_type");
          log.debug(" ConnectionType :: " + con_type);
          
          if("ipReg".equalsIgnoreCase(con_type)){
                firewallRuleProcess.setIsIpReg("Y");
                log.debug(" IPRegistration :: " + con_type);
          }else{
                firewallRuleProcess.setIsIpReg("N");
                log.debug(" Firewall :: " + con_type);
          }
          log.info("FirewallRuleController::loadFirewallRules fromPage..."+fromPage);
    
          if(fromPage != null && !fromPage.isEmpty() && fromPage.equalsIgnoreCase("viewTemplate")){
                if(request.getParameter("processID") != null)
                      processID = Long.valueOf(request.getParameter("processID"));
                //Modified for task 42665-starts
                if(request.getParameter("tiRequestID") != null)
                    tiRequestID = getPreviousVersionTiRequestIDForTemplate(processID, request);
                //Modified for task 42665-ends
                forwardPage = "pages/jsp/fw/TemplateListFirewallRules";
                firewallRuleProcess.setIsIpReg(null);
                log.info("Inside viewTemplate*******************tiRequestID===>"+tiRequestID+"processID===>"+processID);
          }else{                  
                processID = tiRequest.getTiProcess().getId();
                tiRequestID = getPreviousVersionTiRequestID(processID, request);
          }
          log.debug("TiRequestID in FirewallController -- "+tiRequestID);
          firewallRuleProcess.setTiRequest(tiRequestID);
          firewallRuleProcess.setTiProcess(processID);
          firewallRuleProcess.setOffset(0);
          firewallRuleProcess.setPageNo(1);
          firewallRuleProcess.setLimit(10);
          firewallRuleProcess.setCollectionLimit(10);
          if(fromPage != null && !fromPage.isEmpty() && fromPage.equalsIgnoreCase("viewTemplate")){
        	   fireWallRulesTemp = firewallRuleProcess.findFirewallRulesForTemplate();  
          }else{
        	   fireWallRules = firewallRuleProcess.findFirewallRules();
          }
          
          int rowCount = firewallRuleProcess.getRowCount();     
          log.debug(" Row count :: " + rowCount);
          int totalPages = 0;           
          int limit = 10; 
          
          if (rowCount%limit > 0) {
                totalPages = Math.round((rowCount/limit)+0.5f);
          } else {
                totalPages = Math.round(rowCount/limit);
          }           
          firewallRuleProcess.setTotalPages(totalPages); 
          
          //Modified for task 42665-starts
          if(fromPage != null && !fromPage.isEmpty() && fromPage.equalsIgnoreCase("viewTemplate")){
        	  firewallRuleProcess.setHistoryFireWallRules(fireWallRulesTemp);
         }else{
        	 firewallRuleProcess.setFireWallRules(fireWallRules);
         }
         //Modified for task 42665-ends
          
          
          isCompleteCheck(request);

          //set relationship for the TIRequestID
          setRelationshipType(tiRequestID, firewallRuleProcess);
          model.addAttribute("firewallRuleProcess", firewallRuleProcess);
          
          log.info("FirewallRuleController::loadFirewallRules methods ends..."+forwardPage);
          return forwardPage;
	}
	
	 /*
     * To List the Firewall Rules in the Firewall Rules Screen.
     * To Paginate the Firewall Rules.
     * To Filter the Firewall Rules.
     * Criteria : Source IP, Destination IP, FW Policy, FW Group, Port, Zone
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/paginateFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String paginateFirewallRules(HttpServletRequest request, @ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess, 
			ModelMap model, BindingResult bresult) {
	    log.info("FirewallRuleController::paginateFirewallRules methods starts...");
	    String forwardPage = "pages/jsp/fw/FirewallRules";
		log.debug("In ManageFWRule Action PaginateFWRule getFirewallRulesCollectionLimit ---"+firewallRuleProcess.getCollectionLimit());
		Long tiRequestID = 0L, processID = 0L;
		
		String fromPage = request.getParameter("fromPage");
		log.info("FirewallRuleController::loadFirewallRules fromPage..."+fromPage);
		if(fromPage != null && !fromPage.isEmpty() && fromPage.equalsIgnoreCase("viewTemplate")){
			if(request.getParameter("tiRequestID") != null)
				tiRequestID = Long.valueOf(request.getParameter("tiRequestID"));
			if(request.getParameter("processID") != null)
				processID = Long.valueOf(request.getParameter("processID"));
			
			forwardPage = "pages/jsp/fw/TemplateListFirewallRules";
		}else{
			processID = getTiProcessId(request);
			tiRequestID = getPreviousVersionTiRequestID(processID, request);
		}
		String con_type = (String) request.getSession().getAttribute("con_type");
		log.debug(" ConnectionType :: " + con_type);
		
		
		String type = (String)request.getParameter("type");	   
		int curOffSet = firewallRuleProcess.getOffset();		
		int limit = firewallRuleProcess.getLimit();
		int collectionLimit = firewallRuleProcess.getCollectionLimit();	
		int pageNo = firewallRuleProcess.getPageNo();
		
		String sourceIP = firewallRuleProcess.getSourceIPAddress();
		String destIP = firewallRuleProcess.getDestinationIPAddress();
		String portNo = firewallRuleProcess.getPortNumber();
		String firewallGroup = firewallRuleProcess.getPolicyGroup();
		String zone = firewallRuleProcess.getSourceZone();
		boolean incompleteRules = firewallRuleProcess.isIncompleteRules();
		
		firewallRuleProcess = new FireWallRuleProcess();
		//set relationship for the TIRequestID
		setRelationshipType(tiRequestID, firewallRuleProcess);

		firewallRuleProcess.setTiRequest(tiRequestID);
		firewallRuleProcess.setTiProcess(processID);
		firewallRuleProcess.setLimit(limit);
		firewallRuleProcess.setCollectionLimit(collectionLimit);
		
		firewallRuleProcess.setSourceIPAddress(sourceIP);
		firewallRuleProcess.setDestinationIPAddress(destIP);
		firewallRuleProcess.setPortNumber(portNo);
		firewallRuleProcess.setPolicyGroup(firewallGroup);
		firewallRuleProcess.setSourceZone(zone);
		firewallRuleProcess.setDestinationZone(zone);
		firewallRuleProcess.setIncompleteRules(incompleteRules);
		if("ipReg".equalsIgnoreCase(con_type))
		{
			firewallRuleProcess.setIsIpReg("Y");
			log.debug(" IPRegistration :: " + con_type);
		}else
		{
			firewallRuleProcess.setIsIpReg("N");
			log.debug(" Firewall :: " + con_type);
		}
		if ("N".equalsIgnoreCase(type)) {
			firewallRuleProcess.setOffset(curOffSet+firewallRuleProcess.getLimit());
			firewallRuleProcess.setPageNo(pageNo+1);
		} else if ("P".equalsIgnoreCase(type)) {
			firewallRuleProcess.setOffset(curOffSet-firewallRuleProcess.getLimit());
			firewallRuleProcess.setPageNo(pageNo-1);
		} else if ("X".equalsIgnoreCase(type)) {
			firewallRuleProcess.setOffset(limit * (pageNo-1));
			firewallRuleProcess.setPageNo(pageNo);
		} else if ("L".equalsIgnoreCase(type)) {
			firewallRuleProcess.setOffset(0);
			firewallRuleProcess.setPageNo(1);
		} else {
			firewallRuleProcess.setOffset(0);
			firewallRuleProcess.setPageNo(1);
		}
		
		List<FireWallRule> fireWallRules = firewallRuleProcess.findFirewallRules();		
		int rowCount = firewallRuleProcess.getRowCount();		
		int totalPages = 0;
		
		if (rowCount%limit > 0) {
			totalPages = Math.round((rowCount/limit)+0.5f);
		} else {
			totalPages = Math.round(rowCount/limit);
		}
		
		firewallRuleProcess.setTotalPages(totalPages);	
		firewallRuleProcess.setFireWallRules(fireWallRules);
		model.addAttribute("firewallRuleProcess", firewallRuleProcess);
		log.info("FirewallRuleController::paginateFirewallRules methods ends...");
		return forwardPage;
    }
	
	//To get the service name
	/**
	 * 
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/getServiceName.act", method = { RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody String getServiceName(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallRuleController::getServiceName method starts...");
    	FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
	    String portNumber = request.getParameter("portNumber");
	    String serviceName = null;
	    try {
		serviceName = firewallRuleProcess.getServiceName(Long.valueOf(portNumber));
	    } catch (BusinessException be) {
		    log.error(be, be);
		    serviceName = be.getMessage();
		}
	    log.info("FirewallRuleController::getServiceName method ends...");
		return serviceName;
	 }

    /*
     * View the Firewall Rule from List Firewall Rules Screen.
     * The Page will be displayed On Clicking More Link.
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/viewFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String viewFirewallRules(HttpServletRequest request, ModelMap model) {
	    log.info("FirewallRuleController::viewFirewallRules methods starts...");
	    FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
	
		FireWallRuleProcess fwRuleProcess = new FireWallRuleProcess();
	
		fwRuleProcess.setTiRequest(getTirequestID(request));
		fwRuleProcess.setTiProcess(getTiProcessId(request));
		String ruleId = request.getParameter("ruleId");
		fwRuleProcess.setRuleId(Long.valueOf(ruleId));
	
		FireWallRule fireWallRule = fwRuleProcess.findFirewallRule();
		firewallRuleProcess.setFireWallRule(fireWallRule);

		//set relationship for the TIRequestID
		setRelationshipType(getTirequestID(request), firewallRuleProcess);

		firewallRuleProcess.setControlMessagesList((firewallRuleProcess.getControlMessages()));
		model.addAttribute("firewallRuleProcess", firewallRuleProcess);
		log.info("FirewallRuleController::viewFirewallRules methods ends...");
		return "c3par.firewall.viewfirewalls";
    }
	
	/*
     * To Add the New Firewall Rule.
     * 
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/addNewFirewallRule.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String addNewFirewallRule(HttpServletRequest request, ModelMap model) {
		log.info("LoadFirewallRulesAction::addNewFirewall methods starts...");
		
		//Remove Session Attributes
		removeSessionAttributes(request);
		
		FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
		TIRequest tiRequest =  firewallRuleProcess.getTIRequest(getTirequestID(request));
		
		List<FirewallLocation> fwLocations = firewallRuleProcess.getFirewallLocations();
		List<GenericLookup> connectivityTypes = firewallRuleProcess.getConnectivityTypeList();
		
		String con_type= "";
		if(request.getSession().getAttribute("con_type") != null){
			con_type = (String) request.getSession().getAttribute("con_type");
		}
		
		ResourceType tmpSrcResourceType = new ResourceType();
		
		if("ipReg".equalsIgnoreCase(con_type)){
			List<ResourceType> ipResourceTypes = firewallRuleProcess.getResourceTypeListIP(getTiProcessId(request));
			 firewallRuleProcess.setIpResourceTypes(ipResourceTypes);
			  if(ipResourceTypes != null && ipResourceTypes.size() > 0){
            	ResourceType tmpSrc1ResourceType  =  (ResourceType)ipResourceTypes.get(0);
            	 tmpSrcResourceType.setId(tmpSrc1ResourceType.getId());
			  }
             
		} 
		
		List<ResourceType> resourceTypes = firewallRuleProcess.getResourceTypeList(getTiProcessId(request));
		firewallRuleProcess.setResourceTypes(resourceTypes);			
				
		firewallRuleProcess.setFwLocations(fwLocations);
		firewallRuleProcess.setConnectivityTypes(connectivityTypes);
		List<GenericLookup> ProtocolList = firewallRuleProcess.getProtocols();
		firewallRuleProcess.setProtocolList(ProtocolList);
		
		List<FireWallPolicyGroup> firewallGroupList = new ArrayList<FireWallPolicyGroup>();
		
		firewallRuleProcess.setFirewallGroupList(firewallGroupList);
		
		List<FireWallZone> zones = new ArrayList<FireWallZone>();
		firewallRuleProcess.setFirewallZones(zones);
		
		firewallRuleProcess.setControlMessagesList((firewallRuleProcess.getControlMessages()));
		firewallRuleProcess.setResourceTypes((firewallRuleProcess.getResourceTypes()));

		//set relationship for the TIRequestID
		setRelationshipType(getTirequestID(request), firewallRuleProcess);
		
		FireWallRule fireWallRule = new FireWallRule();
		
		IPAddress sipAddress1 = new IPAddress();
		sipAddress1.setIpAddress("");
	
		IPAddress dipAddress1 = new IPAddress();
		dipAddress1.setIpAddress("");
	
		Port port1 = new Port();
		port1.setProtocol("TCP");
		port1.setPortNumber("");
		
		FirewallPolicy firewallPolicy = new FirewallPolicy();
	
		FireWallRuleSourceIP fireWallRuleSourceIP1 = new FireWallRuleSourceIP();
		fireWallRuleSourceIP1.setIpAddress(sipAddress1);
	
		FireWallRuleDestinationIP fireWallRuleDestinationIP1 = new FireWallRuleDestinationIP();
		fireWallRuleDestinationIP1.setIpAddress(dipAddress1);
	
		FireWallRulePort fireWallRulePort1 = new FireWallRulePort();
		fireWallRulePort1.setPort(port1);

		fireWallRule.setTiRequest(tiRequest);
		firewallRuleProcess.setFireWallRule(fireWallRule);

		ResourceType tmpResourceType = new ResourceType();
		tmpResourceType.setId(Long.valueOf(firewallRuleProcess.getTemplateResourceType()));
		
		if(con_type != null && "ipReg".equalsIgnoreCase(con_type)){
			fireWallRule.setIsIpReg("Y");
			
			List<FireWallRuleSourceIP> ipRegSourceIPs = firewallRuleProcess.getIPRegSoureIp(getTiProcessId(request),getTirequestID(request));
			if(ipRegSourceIPs != null && ipRegSourceIPs.size() > 0){
				fireWallRuleSourceIP1 = ipRegSourceIPs.get(0);
				fireWallRuleSourceIP1.setId(null);
				fireWallRuleSourceIP1.setIsNew("Y");
				fireWallRuleSourceIP1.setDisabled(true);
			}
			firewallPolicy = firewallRuleProcess.getFirewallPolicyForIPReg();
			if (firewallPolicy != null) {
				firewallRuleProcess.getFireWallRule().setPolicy(firewallPolicy);
				fireWallRule.setPolicyGroup(firewallPolicy.getFireWallPolicyGroup());
				
				Long fwLocationId = fireWallRule.getPolicyGroup().getConnectionFWLocation().getId();
				Long connectivityType = fireWallRule.getPolicyGroup().getConnectivityType().getId();
			    firewallGroupList = firewallRuleProcess.findFirewallGroups(fwLocationId, connectivityType);
				
				firewallRuleProcess.setFirewallGroupList(firewallGroupList);
			}
			if(firewallRuleProcess.getResourceTypes() != null){
				for(ResourceType resType:firewallRuleProcess.getResourceTypes()){
					if(resType != null && resType.getName().equalsIgnoreCase("GRN")){
						tmpResourceType.setId(resType.getId());
					}
				}
			}
		}

		//Set SESSION Attributes
		setSessionAttributes(firewallRuleProcess, request);
		
		FirewallRulePolicy firewallRulePolicy = new FirewallRulePolicy();
		firewallRulePolicy.setFirewallPolicy(firewallPolicy);
	
		fireWallRule.setSourceIPs(new ArrayList<FireWallRuleSourceIP>());
		fireWallRule.setDestinationIPs(new ArrayList<FireWallRuleDestinationIP>());
		fireWallRule.setPorts(new ArrayList<FireWallRulePort>());
		fireWallRule.setPolicies(new ArrayList<FirewallRulePolicy>());
	
		fireWallRule.getSourceIPs().add(fireWallRuleSourceIP1);
		fireWallRule.getDestinationIPs().add(fireWallRuleDestinationIP1);
		fireWallRule.getPorts().add(fireWallRulePort1);
		fireWallRule.getPolicies().add(firewallRulePolicy);

		fireWallRule.setSourceNetworkZone(tmpSrcResourceType);
		fireWallRule.setDestinationNetworkZone(tmpResourceType);
		
		fireWallRule.setBidirectional("OFF");	
		model.addAttribute("firewallRuleProcess",firewallRuleProcess);
		log.info("......LoadFirewallRulesAction::addNewFirewall methods ends.");
		return "c3par.firewall.addnewfirewallrule";
    }
	
	 /*
  	To Save the Firewall Rule on Add, Edit and Clone
 
 	Before Saving the Rule:
 	-----------------------
 	Check whether Rule modified
 	Validating IPs and Ports
	Formatting IPs and Ports
	IP Subnet and Range Calculation 
	Check Duplicates in the list of Source IPs
	Check Duplicates in the list of Dest IPs
	Check Duplicates in the list of Source IPs and Dest IPs
	Check Duplicates in the list of Ports
	Check Duplicate Rule within TIrequest
	Check IP exists with different Network Zone 
	Find the Existing IPs and Ports
	Delete Applications of the Deleted IP
 */
/**
 * 
 * @return
 */
	@RequestMapping(value = "/saveFirewallRule.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String saveFirewallRule(HttpServletRequest request, @ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess, 
			ModelMap model, BindingResult bresult) {
    log.info("FirewallRuleController::saveFirewallRule method starts...");

	String result = "add_new_firewallrule";
	boolean deleted = false;		
	String fromPage = request.getParameter("fromPage");
	String status = null;
	
	Long cloneFromRuleID = firewallRuleProcess.getCloneFromRuleID();
	
	String relationshipType = firewallRuleProcess.getRelationshipType();
	log.info("FirewallRuleController::saveFirewallRule::relationshipType-->"+relationshipType);
	

	TIRequest tiRequest = getTirequest(request);
	
	log.debug("FirewallRuleController::...updated date..."
			+firewallRuleProcess.getFireWallRule().getUpdated_date());
	
	log.debug("FirewallRuleController:SAVE Firewall Rule:...updated tirequest..."+
			firewallRuleProcess.getFireWallRule().getUpdatedTIRequest());
	firewallRuleProcess.setTiRequest(tiRequest.getId());
			
	log.debug("FirewallRuleController:SAVE Firewall Rule:...status..."+status);
	if ("N".equalsIgnoreCase(firewallRuleProcess.getFireWallRule().getIsNew())) {
		status = firewallRuleProcess.getFireWallRule().getStatus();
	} else {
		firewallRuleProcess.getFireWallRule().setIsNew("Y");
		firewallRuleProcess.getFireWallRule().setStatus("ADD");
	}
	
	firewallRuleProcess.getFireWallRule().setUpdatedTIRequest(tiRequest);

	if (firewallRuleProcess.getFireWallRule().getPolicyGroup() == null
			|| firewallRuleProcess.getFireWallRule().getPolicyGroup().getId() == null
			|| firewallRuleProcess.getFireWallRule().getPolicyGroup().getId().longValue() <= 0) {
		firewallRuleProcess.getFireWallRule().setPolicyGroup(null);
	}
	
	if (firewallRuleProcess.getFireWallRule().getSourceZone() == null
			|| firewallRuleProcess.getFireWallRule().getSourceZone().getId() == null
			|| firewallRuleProcess.getFireWallRule().getSourceZone().getId().longValue() <= 0) {
		firewallRuleProcess.getFireWallRule().setSourceZone(null);
	}
	
	if (firewallRuleProcess.getFireWallRule().getDestinationZone() == null
			|| firewallRuleProcess.getFireWallRule().getDestinationZone().getId() == null
			|| firewallRuleProcess.getFireWallRule().getDestinationZone().getId().longValue() <= 0) {
		firewallRuleProcess.getFireWallRule().setDestinationZone(null);
	}	

	if (firewallRuleProcess.getFireWallRule().getSourceNetworkZone() == null
			|| firewallRuleProcess.getFireWallRule().getSourceNetworkZone().getId() == null
			|| firewallRuleProcess.getFireWallRule().getSourceNetworkZone().getId().longValue() <= 0) {
		firewallRuleProcess.getFireWallRule().setSourceNetworkZone(null);
	}		

	if (firewallRuleProcess.getFireWallRule().getDestinationNetworkZone() == null
			|| firewallRuleProcess.getFireWallRule().getDestinationNetworkZone().getId() == null
			|| firewallRuleProcess.getFireWallRule().getDestinationNetworkZone().getId().longValue() <= 0) {
		firewallRuleProcess.getFireWallRule().setDestinationNetworkZone(null);
	}
	
	if (firewallRuleProcess.getFireWallRule().getSourceObject() == null
			|| firewallRuleProcess.getFireWallRule().getSourceObject().getIpAddress() == null
			|| firewallRuleProcess.getFireWallRule().getSourceObject().getIpAddress().isEmpty()) {
		firewallRuleProcess.getFireWallRule().setSourceObject(null);
	} else {
		firewallRuleProcess.getFireWallRule().getSourceObject().setTemplateFlag("Y");
	}

	if (firewallRuleProcess.getFireWallRule().getDestinationObject() == null
			|| firewallRuleProcess.getFireWallRule().getDestinationObject().getIpAddress() == null
			|| firewallRuleProcess.getFireWallRule().getDestinationObject().getIpAddress().isEmpty()) {
		firewallRuleProcess.getFireWallRule().setDestinationObject(null);
	} else {
		firewallRuleProcess.getFireWallRule().getDestinationObject().setTemplateFlag("Y");
	}

	if (firewallRuleProcess.getFireWallRule().getPortObject() == null
			|| firewallRuleProcess.getFireWallRule().getPortObject().getPortNumber() == null
			|| firewallRuleProcess.getFireWallRule().getPortObject().getPortNumber().isEmpty()) {
		firewallRuleProcess.getFireWallRule().setPortObject(null);
	} else {
		firewallRuleProcess.getFireWallRule().getPortObject().setTemplateFlag("Y");
		firewallRuleProcess.getFireWallRule().getPortObject().setProtocol(OBJECT);
		firewallRuleProcess.getFireWallRule().getPortObject().setFlowOfData(FLOW_OF_DATA_ATOB);
	}
	
	List<FireWallRuleSourceIP> sourceIPs = firewallRuleProcess.getFireWallRule().getSourceIPs();
	List<FireWallRuleSourceIP> newSourceIPs = new ArrayList<FireWallRuleSourceIP>();
	if (sourceIPs != null && !sourceIPs.isEmpty()) {
	    for (FireWallRuleSourceIP fireWallRuleSourceIP : sourceIPs) {
	    	if (!"N".equalsIgnoreCase(fireWallRuleSourceIP.getIsNew())) {
	    		fireWallRuleSourceIP.setIsNew("Y");
	    	}
			fireWallRuleSourceIP.setFireWallRule(firewallRuleProcess.getFireWallRule());
			if(fireWallRuleSourceIP.isDeleted()) {
				if (fireWallRuleSourceIP.getId() != null && fireWallRuleSourceIP.getId().longValue() > 0) {
					deleted = true;
					fireWallRuleSourceIP.setDeletedTIRequest(tiRequest);
					//fireWallRuleSourceIP.setUpdatedTIRequest(tiRequest);
					if ("ADD".equalsIgnoreCase(status)) {
						status = "DELETE";
					} else if ("EDIT".equalsIgnoreCase(status)) {
						status = "EDORDEL";
					}
				} else {
					continue;
				}
			} else {
				if (fireWallRuleSourceIP.getId() == null || fireWallRuleSourceIP.getId().longValue() <= 0) {
					fireWallRuleSourceIP.setUpdatedTIRequest(tiRequest);
				}
				fireWallRuleSourceIP.setDeletedTIRequest(null);
			}
			
			newSourceIPs.add(fireWallRuleSourceIP);
	    }
	    firewallRuleProcess.getFireWallRule().setSourceIPs(newSourceIPs);
	}

	List<FireWallRuleDestinationIP> destinationIPs = firewallRuleProcess.getFireWallRule().getDestinationIPs();
	List<FireWallRuleDestinationIP> newDestIPs = new ArrayList<FireWallRuleDestinationIP>();
	if (destinationIPs != null && !destinationIPs.isEmpty()) {
	    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : destinationIPs) {
	    	if (!"N".equalsIgnoreCase(fireWallRuleDestinationIP.getIsNew())) {
	    		fireWallRuleDestinationIP.setIsNew("Y");
	    	}
			fireWallRuleDestinationIP.setFireWallRule(firewallRuleProcess.getFireWallRule());
			if(fireWallRuleDestinationIP.isDeleted()) {
				if (fireWallRuleDestinationIP.getId() != null && fireWallRuleDestinationIP.getId().longValue() > 0) {
					deleted = true;
					fireWallRuleDestinationIP.setDeletedTIRequest(tiRequest);
					//fireWallRuleDestinationIP.setUpdatedTIRequest(tiRequest);
					if ("ADD".equalsIgnoreCase(status)) {
						status = "DELETE";
					} else if ("EDIT".equalsIgnoreCase(status)) {
						status = "EDORDEL";
					}
				} else {
					continue;
				}
			} else {
				if (fireWallRuleDestinationIP.getId() == null || fireWallRuleDestinationIP.getId().longValue() <= 0) {
					fireWallRuleDestinationIP.setUpdatedTIRequest(tiRequest);
				}
				fireWallRuleDestinationIP.setDeletedTIRequest(null);
			}
			newDestIPs.add(fireWallRuleDestinationIP);
	    }
	    firewallRuleProcess.getFireWallRule().setDestinationIPs(newDestIPs);
	}

	List<FireWallRulePort> ports = firewallRuleProcess.getFireWallRule().getPorts();
	List<FireWallRulePort> newPorts = new ArrayList<FireWallRulePort>();
	if (ports != null && !ports.isEmpty()) {
	    for (FireWallRulePort fireWallRulePort : ports) {
	    	if (fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("ICMP"))
	    	{
	    		fireWallRulePort.getPort().setPortNumber(fireWallRulePort.getPort().getProtocol());
	    	}
	    	
	    	String isDCEProtocol = fireWallRulePort.getPort().getDceProtocol();
	    	String protocolName = fireWallRulePort.getPort().getProtocol();
    		System.out.println("DCE Protocol  : "+isDCEProtocol);
    		System.out.println("Protocol  : "+protocolName);
    		if(isDCEProtocol!=null && isDCEProtocol.length()!=0)
    		{
    			System.out.println("if DCE Protocol  : "+isDCEProtocol);
    			//fireWallRulePort.getPort().setPortNumber(isDCEProtocol);
    			fireWallRulePort.getPort().setProtocol(isDCEProtocol);
    		}
    		else
    		{
    			System.out.println("else DCE Protocol  : "+isDCEProtocol);
    		}
			fireWallRulePort.getPort().setFlowOfData(FLOW_OF_DATA_ATOB);
			if (!"N".equalsIgnoreCase(fireWallRulePort.getIsNew())) {
				fireWallRulePort.setIsNew("Y");
			}
			fireWallRulePort.setFireWallRule(firewallRuleProcess.getFireWallRule());
			if(fireWallRulePort.isDeleted()) {
				if (fireWallRulePort.getId() != null && fireWallRulePort.getId().longValue() > 0) {
					deleted = true;
					fireWallRulePort.setDeletedTIRequest(tiRequest);
					//fireWallRulePort.setUpdatedTIRequest(tiRequest);
					if ("ADD".equalsIgnoreCase(status)) {
						status = "DELETE";
					} else if ("EDIT".equalsIgnoreCase(status)) {
						status = "EDORDEL";
					}
				} else {
					continue;
				}
			} else {
				if (fireWallRulePort.getId() == null || fireWallRulePort.getId().longValue() <= 0) {
					fireWallRulePort.setUpdatedTIRequest(tiRequest);
				}
				fireWallRulePort.setDeletedTIRequest(null);
			}
			newPorts.add(fireWallRulePort);
	    }
	    firewallRuleProcess.getFireWallRule().setPorts(newPorts);
	}
	
	List<FirewallRulePolicy> policies = firewallRuleProcess.getFireWallRule().getPolicies();
	List<FirewallRulePolicy> newPolicies = new ArrayList<FirewallRulePolicy>();
	if (policies != null && !policies.isEmpty()) {
	    for (FirewallRulePolicy firewallRulePolicy : policies) {
			if (!"N".equalsIgnoreCase(firewallRulePolicy.getIsNew())) {
				firewallRulePolicy.setIsNew("Y");
			}
			firewallRulePolicy.setFireWallRule(firewallRuleProcess.getFireWallRule());
			if(firewallRulePolicy.isDeleted()) {
				if (firewallRulePolicy.getId() != null && firewallRulePolicy.getId().longValue() > 0) {
					deleted = true;
					firewallRulePolicy.setDeletedTIRequest(tiRequest);
					if ("ADD".equalsIgnoreCase(status)) {
						status = "DELETE";
					} else if ("EDIT".equalsIgnoreCase(status)) {
						status = "EDORDEL";
					}
				} else {
					continue;
				}
			} else {
				if (firewallRulePolicy.getId() == null || firewallRulePolicy.getId().longValue() <= 0) {
					firewallRulePolicy.setUpdatedTIRequest(tiRequest);
				}
				firewallRulePolicy.setDeletedTIRequest(null);
			}
			newPolicies.add(firewallRulePolicy);
	    }
	    firewallRuleProcess.getFireWallRule().setPolicies(newPolicies);
	}

	log.debug("FirewallRuleController:SAVE Firewall Rule:...updated date hdn..."
			+firewallRuleProcess.getFireWallRule().getUpdated_date_hdn());
	if (firewallRuleProcess.getFireWallRule().getUpdated_date_hdn() != null && 
			!firewallRuleProcess.getFireWallRule().getUpdated_date_hdn().isEmpty()) {
		firewallRuleProcess.getFireWallRule().setUpdated_date(
				getDateTime(firewallRuleProcess.getFireWallRule().getUpdated_date_hdn()));
	}
	
	if (firewallRuleProcess.getFireWallRule().getSourceIPs() != null && !firewallRuleProcess.getFireWallRule()
			.getSourceIPs().isEmpty()) {
	    for (FireWallRuleSourceIP fireWallRuleSourceIP : firewallRuleProcess.getFireWallRule().getSourceIPs()) {
	    	if (fireWallRuleSourceIP.getUpdated_date_hdn() != null && 
	    			!fireWallRuleSourceIP.getUpdated_date_hdn().isEmpty()) {
	    		fireWallRuleSourceIP.setUpdated_date(getDateTime(fireWallRuleSourceIP.getUpdated_date_hdn()));
	    	}
	    }
	}
	
	if (firewallRuleProcess.getFireWallRule().getDestinationIPs() != null && !firewallRuleProcess.getFireWallRule()
			.getDestinationIPs().isEmpty()) {
	    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : firewallRuleProcess.getFireWallRule().getDestinationIPs()) {
	    	if (fireWallRuleDestinationIP.getUpdated_date_hdn() != null && 
	    			!fireWallRuleDestinationIP.getUpdated_date_hdn().isEmpty()) {
	    		fireWallRuleDestinationIP.setUpdated_date(getDateTime(fireWallRuleDestinationIP.getUpdated_date_hdn()));
	    	}
	    }
	}

	if (firewallRuleProcess.getFireWallRule().getPorts() != null && !firewallRuleProcess.getFireWallRule()
			.getPorts().isEmpty()) {
	    for (FireWallRulePort fireWallRulePort : firewallRuleProcess.getFireWallRule().getPorts()) {
	    	if (fireWallRulePort.getUpdated_date_hdn() != null && 
	    			!fireWallRulePort.getUpdated_date_hdn().isEmpty()) {
	    		fireWallRulePort.setUpdated_date(getDateTime(fireWallRulePort.getUpdated_date_hdn()));
	    	}
	    }
	}
	
	if (firewallRuleProcess.getFireWallRule().getPolicies() != null && !firewallRuleProcess.getFireWallRule()
			.getPolicies().isEmpty()) {
	    for (FirewallRulePolicy firewallRulePolicy : firewallRuleProcess.getFireWallRule().getPolicies()) {
	    	if (firewallRulePolicy.getUpdated_date_hdn() != null && 
	    			!firewallRulePolicy.getUpdated_date_hdn().isEmpty()) {
	    		firewallRulePolicy.setUpdated_date(getDateTime(firewallRulePolicy.getUpdated_date_hdn()));
	    	}
	    }
	}
	
	log.debug("FirewallRuleController:SAVE Firewall Rule:...updated date..."
			+firewallRuleProcess.getFireWallRule().getUpdated_date());
	
	String con_type= "";
	if(request.getSession().getAttribute("con_type") != null){
		con_type = (String) request.getSession().getAttribute("con_type");
	}
	

	if(con_type != null && "ipReg".equalsIgnoreCase(con_type)){
		firewallRuleProcess.setIsIpReg("Y");
		List<ResourceType> ipResourceTypes = firewallRuleProcess.getResourceTypeListIP(getTiProcessId(request));
		firewallRuleProcess.setIpResourceTypes(ipResourceTypes);
		
	} 
	else {
		firewallRuleProcess.setIsIpReg("N");
	}
	Long fireWallRuleId = null;
	try {
		firewallRuleProcess.getFireWallRule().setValidationErrors(new ArrayList<String>());
		
		//To Validate IPs and Ports
		FireWallRule validatedFireWallRule = firewallRuleProcess.getFireWallRule().validateIPsandPorts();
		if (validatedFireWallRule.getValidationErrors() != null && validatedFireWallRule.getValidationErrors().size() > 0) {
			for (String error : validatedFireWallRule.getValidationErrors()) {
				bresult.addError(new ObjectError("firewallRuleProcess.fireWallRule", error));
			}
			loadSessionAttributes(firewallRuleProcess, request);
			
			result =  "c3par.firewall.addnewfirewallrule";
			if ("Clone".equalsIgnoreCase(fromPage)) {
				result = "c3par.firewall.clonefirewallrule";
			} else if ("Edit".equalsIgnoreCase(fromPage)) {
				result = "c3par.firewall.editfirewallrule";
			}
			model.addAttribute("firewallRuleProcess", firewallRuleProcess);
			return result;
		}
		//To Check whether Rule Modified or not
		if (firewallRuleProcess.getFireWallRule().getId() != null && firewallRuleProcess.getFireWallRule().getId().longValue() > 0) {
			boolean modified = validatedFireWallRule.isRuleModified();
			
			log.debug("FirewallRuleController:SAVE Firewall Rule:...modfied..."+modified);
			if (modified) {
				log.debug("FirewallRuleController:SAVE Firewall Rule:...status..."+status);
				if (status != null && !status.isEmpty()) {
					if ("ADD".equalsIgnoreCase(status)) {
						status = "EDIT";
					} else if ("DELETE".equalsIgnoreCase(status)) {
						status = "EDORDEL";
					}
				}
			} else if (!modified && !deleted) {
				log.debug("There are no changes to save");
				bresult.addError(new ObjectError("firewallRuleProcess.fireWallRule", "There are no changes to save"));
				loadSessionAttributes(firewallRuleProcess, request);
				result =  "c3par.firewall.addnewfirewallrule";
				if ("Clone".equalsIgnoreCase(fromPage)) {
					result = "c3par.firewall.clonefirewallrule";
				} else if ("Edit".equalsIgnoreCase(fromPage)) {
					result = "c3par.firewall.editfirewallrule";
				}
				model.addAttribute("firewallRuleProcess", firewallRuleProcess);
				return result;
			} 
			log.debug("FirewallRuleController:SAVE Firewall Rule:...status..."+status);
			if (status != null && !status.isEmpty()) {
				firewallRuleProcess.getFireWallRule().setStatus(status);
			}
			
						
		}			
		//To Identify the Duplicate Rule
		validatedFireWallRule = validatedFireWallRule.identifyExistingRules();
		if (validatedFireWallRule.getValidationErrors() != null && validatedFireWallRule.getValidationErrors().size() > 0) {
			for (String error : validatedFireWallRule.getValidationErrors()) {
				bresult.addError(new ObjectError("firewallRuleProcess.fireWallRule", error));
			}
			loadSessionAttributes(firewallRuleProcess, request);
			result =  "c3par.firewall.addnewfirewallrule";
			if ("Clone".equalsIgnoreCase(fromPage)) {
				result = "c3par.firewall.clonefirewallrule";
			} else if ("Edit".equalsIgnoreCase(fromPage)) {
				result = "c3par.firewall.editfirewallrule";
			}
			model.addAttribute("firewallRuleProcess", firewallRuleProcess);
			return result;
		}			
		//To identify the Existing IPs and Ports
		validatedFireWallRule = validatedFireWallRule.identifyExistingIPsandPorts();
		firewallRuleProcess.setFireWallRule(validatedFireWallRule);
		
		
		fireWallRuleId = firewallRuleProcess.getFireWallRule().save();
		
		log.debug("fw Rule id"+fireWallRuleId);
		firewallRuleProcess.resetFAFGeneratedStatus();
		
	} catch (BusinessException be) {
		log.error("Business Exception Occured... - "+be.getMessage());
		bresult.addError(new ObjectError("firewallRuleProcess.fireWallRule", be.getMessage()));
		result =  "c3par.firewall.addnewfirewallrule";
		if ("Clone".equalsIgnoreCase(fromPage)) {
			result = "c3par.firewall.clonefirewallrule";
		} else if ("Edit".equalsIgnoreCase(fromPage)) {
			result = "c3par.firewall.editfirewallrule";
		}
	} catch (Exception e) {
		log.error(e, e);
		log.error("Exception Occured... - "+e.getMessage());
		bresult.addError(new ObjectError("firewallRuleProcess.fireWallRule", "Not able to save the Firewall Rule. Execption Occured."));
		result =  "c3par.firewall.addnewfirewallrule";
		if ("Clone".equalsIgnoreCase(fromPage)) {
			result = "c3par.firewall.clonefirewallrule";
		} else if ("Edit".equalsIgnoreCase(fromPage)) {
			result = "c3par.firewall.editfirewallrule";
		}
	}
	if (result.equalsIgnoreCase("c3par.firewall.addnewfirewallrule")) {
		loadSessionAttributes(firewallRuleProcess, request);
	}
	//If the FirewallRule is Cloned or Reversed, Then copy the Application details also.
	log.debug("FirewallRuleController :: clone/reverse application details :: cloneFromRuleID ==> "+cloneFromRuleID + " :: fromPage ==>" +fromPage);
	if(fromPage != null && cloneFromRuleID != null && cloneFromRuleID.longValue() > 0 && (fromPage.equalsIgnoreCase("Clone") || fromPage.equalsIgnoreCase("Reverse"))){
		FireWallRule fwrule = new FireWallRule();
		fwrule.setId(fireWallRuleId);
		IPDetailsRequest addApplication = new IPDetailsRequest();
		addApplication.setTiRequest(tiRequest.getId());
		addApplication.setSelectedRuleId(cloneFromRuleID);
		addApplication.setSourceRuleId(fwrule.getId());
		List<FirewallRuleApplication> fwRuleApplications = firewallRuleProcess.getFirewallRuleApplications(addApplication);
		if(fwRuleApplications != null && fwRuleApplications.size() > 0){
			for(FirewallRuleApplication fwApplication:fwRuleApplications){
				fwApplication.setFireWallRule(fwrule);
				fwApplication.setId(null);
				fwApplication.setIsNew("Y");
			}
			log.debug("FirewallRuleController :: clone/reverse application details :: fwRuleApplications.size()==>"+fwRuleApplications.size());
			addApplication.setFirewallRuleAppList(fwRuleApplications);
			addApplication.saveFirewallRuleApplications();
		}
	}
	
	String lockedBy = null;
		ActivityData activityData = null;
		if(request.getSession().getAttribute("workflowActivityData")!= null){
			activityData = (ActivityData)request.getSession().getAttribute("workflowActivityData");
			if (activityData != null) {
				lockedBy = activityData.getLockedBy();
			}
		}
	
	try {
		firewallRuleProcess.executeRiskRules(fireWallRuleId, tiRequest, getTIRequestDTO(request), false, lockedBy);
		firewallRuleProcess.updateFirewallRuleQuestionnaire(fireWallRuleId);
	} catch(Exception e) {
		log.error(e, e);
		log.error("Exception Occured... - "+e.getMessage());
	}
	try {
		firewallRuleProcess.setRuleId(fireWallRuleId);
		FireWallRule fireWallRule = firewallRuleProcess.findFirewallRule();
		List<Long> templateRuleIds=new ArrayList<Long>();			
		if(fireWallRule.getTemplateID() != null && fireWallRule.getTemplateID().longValue() > 0){
			templateRuleIds.add(fireWallRule.getTemplateID());
			
		}
		List<FireWallRulePort> rulePorts=fireWallRule.getPorts();
		List<FireWallRuleSourceIP> ruleSourceIPs=fireWallRule.getSourceIPs();
		List<FireWallRuleDestinationIP> ruleDestinationIPs=fireWallRule.getDestinationIPs();
		if(rulePorts!=null && !rulePorts.isEmpty()){
			for(FireWallRulePort rulePort:rulePorts){
				if(rulePort.getObjRuleID()!=null && rulePort.getObjRuleID().longValue()>0){
					templateRuleIds.add(rulePort.getObjRuleID());
				}
			}
		}
		if(ruleSourceIPs!=null && !ruleSourceIPs.isEmpty()){
			for(FireWallRuleSourceIP ruleSourceIP:ruleSourceIPs){
				if(ruleSourceIP.getObjRuleID()!=null && ruleSourceIP.getObjRuleID().longValue()>0){
					templateRuleIds.add(ruleSourceIP.getObjRuleID());
				}
			}
		}
		if(ruleDestinationIPs!=null && !ruleDestinationIPs.isEmpty()){
			for(FireWallRuleDestinationIP ruleDestinationIP:ruleDestinationIPs){
				if(ruleDestinationIP.getObjRuleID()!=null && ruleDestinationIP.getObjRuleID().longValue()>0){
					templateRuleIds.add(ruleDestinationIP.getObjRuleID());
				}
			}
		}
		for(Long templateRuleId:templateRuleIds){
			FirewallRuleQuestionnaire templateQuestionnaire =firewallRuleProcess.findFWQuestionnaireByRuleId(fireWallRule.getTemplateID());
			FirewallRuleQuestionnaire currentQuestionnaire =firewallRuleProcess.findFWQuestionnaireByRuleId(fireWallRule.getId());
			if (templateQuestionnaire != null && currentQuestionnaire!=null) {
				
			}
			List<Long> toupdate = new ArrayList<Long>();
			if(currentQuestionnaire!=null){
				toupdate.add(currentQuestionnaire.getId());
			}
			firewallRuleProcess.copyTemplateOstiaAnswers(fireWallRule.getTemplateID(),fireWallRule.getId());
			if(toupdate.size()>0){
				firewallRuleProcess.updateAnswer(toupdate);
			}
			firewallRuleProcess.updateFirewallRuleQuestionnaire(fireWallRuleId);
		}
	} catch(Exception e) {
		log.error(e, e);
		log.error("Exception Occured on copying the ostia answers from templates... - "+e.getMessage());
	}
	model.addAttribute("firewallRuleProcess", firewallRuleProcess);
	log.info("FirewallRuleController::Save Ends..... Updated/Created FirewallRuleId... - "+fireWallRuleId);
	return "forward:/loadFirewallRules.act";
}
	
	
	 /*
     * Edit the Firewall Rule from List/View Firewall Rules Screen.
     * The Page will be displayed On Clicking Edit Link.
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/editFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String editFirewallRules(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallRuleController::editFirewallRules method starts...");
		
    	//Remove Session Attributes
		removeSessionAttributes(request);
		
		String con_type= "";
		if(request.getSession().getAttribute("con_type") != null){
			con_type = (String) request.getSession().getAttribute("con_type");
		}
		
		FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
		
		firewallRuleProcess.setControlMessagesList((firewallRuleProcess.getControlMessages()));
		firewallRuleProcess.setResourceTypes((firewallRuleProcess.getResourceTypes()));
		firewallRuleProcess.setIpResourceTypes(firewallRuleProcess.getIpResourceTypes());
		
		firewallRuleProcess.setTiRequest(getTirequestID(request));
		firewallRuleProcess.setTiProcess(getTiProcessId(request));
		String ruleId = request.getParameter("ruleId");
		firewallRuleProcess.setRuleId(Long.valueOf(ruleId));

		//set relationship for the TIRequestID
		setRelationshipType(getTirequestID(request), firewallRuleProcess);

		FireWallRule fireWallRule = firewallRuleProcess.findFirewallRule();
		
		
		if (!C3parStaticNames.IP_TEMPLATE.equals(firewallRuleProcess.getRelationshipType())
				&& !C3parStaticNames.PORT_TEMPLATE.equals(firewallRuleProcess.getRelationshipType())
				&& !C3parStaticNames.TEMPLATE_OBJ.equals(firewallRuleProcess.getRelationshipType())) {
			if (fireWallRule.getTemplateID() != null 
					&& fireWallRule.getTemplateID().longValue() > 0) {
				if (fireWallRule.getSourceIPs() != null && !fireWallRule.getSourceIPs().isEmpty()
						&& fireWallRule.getSourceIPs().size() == 1
						&& fireWallRule.getSourceIPs().get(0) != null
						&& fireWallRule.getSourceIPs().get(0).getObjRuleID() != null
						&& fireWallRule.getSourceIPs().get(0).getObjRuleID().longValue() > 0) {
					firewallRuleProcess.setSipNotEditable(true);
				}
				if (fireWallRule.getPorts() != null && !fireWallRule.getPorts().isEmpty()
						&& fireWallRule.getPorts().size() == 1
						&& fireWallRule.getPorts().get(0) != null
						&& fireWallRule.getPorts().get(0).getObjRuleID() != null
						&& fireWallRule.getPorts().get(0).getObjRuleID().longValue() > 0) {
					firewallRuleProcess.setPortNotEditable(true);
				}
				if (fireWallRule.getDestinationIPs() != null && !fireWallRule.getDestinationIPs().isEmpty()
						&& fireWallRule.getDestinationIPs().size() == 1
						&& fireWallRule.getDestinationIPs().get(0) != null
						&& fireWallRule.getDestinationIPs().get(0).getObjRuleID() != null
						&& fireWallRule.getDestinationIPs().get(0).getObjRuleID().longValue() > 0) {
					firewallRuleProcess.setDipNotEditable(true);
				}
			}

			if((fireWallRule.getSourceIPs() == null || fireWallRule.getSourceIPs().isEmpty()) 
					&& (con_type != null && "ipReg".equalsIgnoreCase(con_type))){
				List<FireWallRuleSourceIP> ipRegSourceIPs = firewallRuleProcess.getIPRegSoureIp(getTiProcessId(request),getTirequestID(request));
				if(ipRegSourceIPs != null && ipRegSourceIPs.size() > 0){
					FireWallRuleSourceIP fireWallRuleSourceIP1 = ipRegSourceIPs.get(0);
					fireWallRuleSourceIP1.setId(null);
					fireWallRuleSourceIP1.setIsNew("Y");
					fireWallRuleSourceIP1.setDisabled(true);
					fireWallRule.setSourceIPs(new ArrayList<FireWallRuleSourceIP>());
					fireWallRule.getSourceIPs().add(fireWallRuleSourceIP1);
				}
			}
			if (fireWallRule.getSourceIPs() == null || fireWallRule
					.getSourceIPs().isEmpty()) {
				IPAddress sipAddress1 = new IPAddress();
				sipAddress1.setIpAddress("");
				FireWallRuleSourceIP fireWallRuleSourceIP1 = new FireWallRuleSourceIP();
				fireWallRuleSourceIP1.setIpAddress(sipAddress1);
				fireWallRule.setSourceIPs(new ArrayList<FireWallRuleSourceIP>());
				fireWallRule.getSourceIPs().add(fireWallRuleSourceIP1);				
			}
			
			if (fireWallRule.getDestinationIPs() == null || fireWallRule
					.getDestinationIPs().isEmpty()) {
				IPAddress dipAddress1 = new IPAddress();
				dipAddress1.setIpAddress("");
				FireWallRuleDestinationIP fireWallRuleDestinationIP1 = new FireWallRuleDestinationIP();
				fireWallRuleDestinationIP1.setIpAddress(dipAddress1);
				fireWallRule.setDestinationIPs(new ArrayList<FireWallRuleDestinationIP>());
				fireWallRule.getDestinationIPs().add(fireWallRuleDestinationIP1);
			}
			
		}
		
		HashMap<Long, Integer> appCount = firewallRuleProcess.applicationCountForIPs();
		
		TIRequest tiRequest =  firewallRuleProcess.getTIRequest(getTirequestID(request));
		
		fireWallRule.setTiRequest(tiRequest);
		
		firewallRuleProcess.setFireWallRule(fireWallRule);
		
		List<FirewallLocation> fwLocations = firewallRuleProcess.getFirewallLocations();
		List<GenericLookup> connectivityTypes = firewallRuleProcess.getConnectivityTypeList();

		if(con_type != null && "ipReg".equalsIgnoreCase(con_type)){
			fireWallRule.setIsIpReg("Y");
			List<ResourceType> ipResourceTypes = firewallRuleProcess.getResourceTypeListIP(getTiProcessId(request));
			firewallRuleProcess.setIpResourceTypes(ipResourceTypes);
		} 
		List<ResourceType> resourceTypes = firewallRuleProcess.getResourceTypeList(getTiProcessId(request));
		firewallRuleProcess.setFwLocations(fwLocations);
		firewallRuleProcess.setConnectivityTypes(connectivityTypes);
		firewallRuleProcess.setResourceTypes(resourceTypes);
		
		
		List<GenericLookup> ProtocolList = firewallRuleProcess.getProtocols();
		firewallRuleProcess.setProtocolList(ProtocolList);
		
		if (fireWallRule.getPolicyGroup()!= null && fireWallRule.getPolicyGroup().getConnectionFWLocation() != null
				&& fireWallRule.getPolicyGroup().getConnectivityType() != null) {
			Long fwLocationId = fireWallRule.getPolicyGroup().getConnectionFWLocation().getId();
			Long connectivityType = fireWallRule.getPolicyGroup().getConnectivityType().getId();
		    List<FireWallPolicyGroup> firewallGroupList = firewallRuleProcess.findFirewallGroups(fwLocationId, connectivityType);
			
			firewallRuleProcess.setFirewallGroupList(firewallGroupList);
		} else {
			firewallRuleProcess.setFirewallGroupList(new ArrayList<FireWallPolicyGroup>());
		}
		
		
		Long fwGroupId = null;
		Long fwPolicyId = null;
		
		if (fireWallRule.getPolicyGroup() != null) {
			fwGroupId = fireWallRule.getPolicyGroup().getId();
		}
		if (fireWallRule.getPolicy() != null) {
			fwPolicyId = fireWallRule.getPolicy().getId();
		}
		
		List<FireWallZone> zones = firewallRuleProcess.findFirewallZones(fwGroupId, fwPolicyId);
	
		if (zones != null) {
			firewallRuleProcess.setFirewallZones(zones);
		} else {
			firewallRuleProcess.setFirewallZones(new ArrayList<FireWallZone>());
		}
		
		log.debug("FirewallRuleController::...updated date..."
				+firewallRuleProcess.getFireWallRule().getUpdated_date());
		
		if (firewallRuleProcess.getFireWallRule().getUpdated_date() != null) {
			firewallRuleProcess.getFireWallRule().setUpdated_date_hdn(
					firewallRuleProcess.getFireWallRule().getUpdated_date().toString());
		}
		
		if (firewallRuleProcess.getFireWallRule().getSourceIPs() != null && !firewallRuleProcess.getFireWallRule()
				.getSourceIPs().isEmpty()) {
		    for (FireWallRuleSourceIP fireWallRuleSourceIP : firewallRuleProcess.getFireWallRule().getSourceIPs()) {
		    	if (fireWallRuleSourceIP != null && fireWallRuleSourceIP.getIpAddress() != null && appCount != null) {
		    		fireWallRuleSourceIP.setAppCount(appCount.get(fireWallRuleSourceIP.getIpAddress().getId()));
		    	}
		    	if (fireWallRuleSourceIP != null && fireWallRuleSourceIP.getUpdated_date() != null) {
		    		fireWallRuleSourceIP.setUpdated_date_hdn(fireWallRuleSourceIP.getUpdated_date().toString());
		    	}
		    }
		}
	
		if (firewallRuleProcess.getFireWallRule().getDestinationIPs() != null && !firewallRuleProcess.getFireWallRule()
				.getDestinationIPs().isEmpty()) {
		    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : firewallRuleProcess.getFireWallRule().getDestinationIPs()) {
		    	if (fireWallRuleDestinationIP != null && fireWallRuleDestinationIP.getIpAddress() != null && appCount != null) {
		    		fireWallRuleDestinationIP.setAppCount(appCount.get(fireWallRuleDestinationIP.getIpAddress().getId()));
			    }
		    	if (fireWallRuleDestinationIP != null && fireWallRuleDestinationIP.getUpdated_date() != null) {
		    		fireWallRuleDestinationIP.setUpdated_date_hdn(fireWallRuleDestinationIP.getUpdated_date().toString());
		    	}
		    }
		}
	
		if (firewallRuleProcess.getFireWallRule().getPorts() != null && !firewallRuleProcess.getFireWallRule()
				.getPorts().isEmpty()) {
		    for (FireWallRulePort fireWallRulePort : firewallRuleProcess.getFireWallRule().getPorts()) {
		    	if (fireWallRulePort != null && fireWallRulePort.getUpdated_date() != null) {
		    		fireWallRulePort.setUpdated_date_hdn(fireWallRulePort.getUpdated_date().toString());
		    	}
		    }
		}
		
		if (firewallRuleProcess.getFireWallRule().getPolicies() != null && !firewallRuleProcess.getFireWallRule()
				.getPolicies().isEmpty()) {
		    for (FirewallRulePolicy firewallRulePolicy : firewallRuleProcess.getFireWallRule().getPolicies()) {
		    	if (firewallRulePolicy != null && firewallRulePolicy.getUpdated_date() != null) {
		    		firewallRulePolicy.setUpdated_date_hdn(firewallRulePolicy.getUpdated_date().toString());
		    	}
		    }
		}
		
		setObjectNamePrefix(getTirequest(request),true, firewallRuleProcess);
		
		//Set SESSION Attributes
		setSessionAttributes(firewallRuleProcess, request);
		model.addAttribute("firewallRuleProcess", firewallRuleProcess);
		log.info("FirewallRuleController::editFirewallRules method ends...");
		return "c3par.firewall.editfirewallrule";
    }
	
	/*
     * Delete the Firewall Rule from List/View Firewall Rules Screen.
     * On Clicking Delete Link.
     */
    /**
     * 
     * @return
     */
    @RequestMapping(value = "/reExecuteRiskRules.act", method = { RequestMethod.GET, RequestMethod.POST})
		public String reExecuteRiskRules(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallRulesController::deleteFirewallRules method starts...");
		
		FireWallRuleProcess fwRuleProcess = new FireWallRuleProcess();
	
		TIRequest tiRequestEntity = null;
		tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
	
		String ruleId = request.getParameter("ruleId");
		fwRuleProcess.setRuleId(Long.valueOf(ruleId));
		fwRuleProcess.setTiRequest(tiRequestEntity.getId());
		
		TIRequest tiRequest = new TIRequest();
		tiRequest.setId(tiRequestEntity.getId());
	
		String lockedBy = null;
  		ActivityData activityData = null;
  		if(request.getSession().getAttribute("workflowActivityData")!= null){
  			activityData = (ActivityData)request.getSession().getAttribute("workflowActivityData");
  			if (activityData != null) {
  				lockedBy = activityData.getLockedBy();
  			}
  		}
		
		try {
			fwRuleProcess.executeRiskRules(Long.valueOf(ruleId), tiRequest, getTIRequestDTO(request), false, lockedBy);
		} catch(Exception e) {
			log.error(e, e);
			log.error("Exception occured while executing Rule... - "+e.getMessage());
		}
		
		log.info("FirewallRulesController::deleteFirewallRules method ends...");
		return "forward:/loadFirewallRules.act";
    }
	
	/*
     * Clone the Firewall Rule from List/View Firewall Rules Screen.
     * The Page will be displayed On Clicking Edit Link.
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/cloneFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String cloneFirewallRules(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallRuleController::cloneFirewallRules method starts...");
    	
    	//Remove Session Attributes
		removeSessionAttributes(request);

		String con_type= "";
		if(request.getSession().getAttribute("con_type") != null){
			con_type = (String) request.getSession().getAttribute("con_type");
		}
		
		FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
		firewallRuleProcess.setControlMessagesList(firewallRuleProcess.getControlMessages());
		firewallRuleProcess.setResourceTypes((firewallRuleProcess.getResourceTypes()));
		firewallRuleProcess.setIpResourceTypes(firewallRuleProcess.getIpResourceTypes());
		
		FireWallRuleProcess fwRuleProcess = new FireWallRuleProcess();
	
		fwRuleProcess.setTiRequest(getTirequestID(request));;
		fwRuleProcess.setTiProcess(getTiProcessId(request));
		String ruleId = request.getParameter("ruleId");
		fwRuleProcess.setRuleId(Long.valueOf(ruleId));
		firewallRuleProcess.setCloneFromRuleID(Long.valueOf(ruleId));
		
		//set relationship for the TIRequestID
		setRelationshipType(getTirequestID(request), firewallRuleProcess);

		FireWallRule fireWallRule = fwRuleProcess.findFirewallRule();
		
		if (!C3parStaticNames.IP_TEMPLATE.equals(firewallRuleProcess.getRelationshipType())
				&& !C3parStaticNames.PORT_TEMPLATE.equals(firewallRuleProcess.getRelationshipType())
				&& !C3parStaticNames.TEMPLATE_OBJ.equals(firewallRuleProcess.getRelationshipType())) {
			if (fireWallRule.getTemplateID() != null 
					&& fireWallRule.getTemplateID().longValue() > 0) {
				if (fireWallRule.getSourceIPs() != null && !fireWallRule.getSourceIPs().isEmpty()
						&& fireWallRule.getSourceIPs().size() == 1
						&& fireWallRule.getSourceIPs().get(0) != null
						&& fireWallRule.getSourceIPs().get(0).getObjRuleID() != null
						&& fireWallRule.getSourceIPs().get(0).getObjRuleID().longValue() > 0) {
					firewallRuleProcess.setSipNotEditable(true);
				}
				if (fireWallRule.getPorts() != null && !fireWallRule.getPorts().isEmpty()
						&& fireWallRule.getPorts().size() == 1
						&& fireWallRule.getPorts().get(0) != null
						&& fireWallRule.getPorts().get(0).getObjRuleID() != null
						&& fireWallRule.getPorts().get(0).getObjRuleID().longValue() > 0) {
					firewallRuleProcess.setPortNotEditable(true);
				}
				if (fireWallRule.getDestinationIPs() != null && !fireWallRule.getDestinationIPs().isEmpty()
						&& fireWallRule.getDestinationIPs().size() == 1
						&& fireWallRule.getDestinationIPs().get(0) != null
						&& fireWallRule.getDestinationIPs().get(0).getObjRuleID() != null
						&& fireWallRule.getDestinationIPs().get(0).getObjRuleID().longValue() > 0) {
					firewallRuleProcess.setDipNotEditable(true);
				}
			}
		}
		
		fireWallRule.setSourceObject(null);
		fireWallRule.setDestinationObject(null);
		fireWallRule.setPortObject(null);
		
		fireWallRule.setStatus(null);
		fireWallRule.setIsNew(null);
		fireWallRule.setFAFGenerated(null);
		
		TIRequest tiRequest =  firewallRuleProcess.getTIRequest(getTirequestID(request));
		
		fireWallRule.setTiRequest(tiRequest);
		
		fireWallRule.setId(null);
		fireWallRule.setUpdated_date(null);
		
		firewallRuleProcess.setFireWallRule(fireWallRule);
		
		List<FirewallLocation> fwLocations = firewallRuleProcess.getFirewallLocations();
		List<GenericLookup> connectivityTypes = firewallRuleProcess.getConnectivityTypeList();
		if(con_type != null && "ipReg".equalsIgnoreCase(con_type)){
			fireWallRule.setIsIpReg("Y");
			List<ResourceType> ipResourceTypes = firewallRuleProcess.getResourceTypeListIP(getTiProcessId(request));
			firewallRuleProcess.setIpResourceTypes(ipResourceTypes);
		} 
		List<ResourceType> resourceTypes = firewallRuleProcess.getResourceTypeList(getTiProcessId(request));
		
		firewallRuleProcess.setFwLocations(fwLocations);
		firewallRuleProcess.setConnectivityTypes(connectivityTypes);
		firewallRuleProcess.setResourceTypes(resourceTypes);
	
		List<GenericLookup> ProtocolList = firewallRuleProcess.getProtocols();
		firewallRuleProcess.setProtocolList(ProtocolList);
		
		if (fireWallRule.getPolicyGroup()!= null && fireWallRule.getPolicyGroup().getConnectionFWLocation() != null
				&& fireWallRule.getPolicyGroup().getConnectivityType() != null) {
			Long fwLocationId = fireWallRule.getPolicyGroup().getConnectionFWLocation().getId();
			Long connectivityType = fireWallRule.getPolicyGroup().getConnectivityType().getId();
		    List<FireWallPolicyGroup> firewallGroupList = firewallRuleProcess.findFirewallGroups(fwLocationId, connectivityType);
			
			firewallRuleProcess.setFirewallGroupList(firewallGroupList);
		} else {
			firewallRuleProcess.setFirewallGroupList(new ArrayList<FireWallPolicyGroup>());
		}
		
		
		Long fwGroupId = null;
		Long fwPolicyId = null;
		
		if (fireWallRule.getPolicyGroup() != null) {
			fwGroupId = fireWallRule.getPolicyGroup().getId();
		}
		if (fireWallRule.getPolicy() != null) {
			fwPolicyId = fireWallRule.getPolicy().getId();
		}
		
		List<FireWallZone> zones = firewallRuleProcess.findFirewallZones(fwGroupId, fwPolicyId);
	
		if (zones != null) {
			firewallRuleProcess.setFirewallZones(zones);
		} else {
			firewallRuleProcess.setFirewallZones(new ArrayList<FireWallZone>());
		}
		
		//Set SESSION Attributes
		setSessionAttributes(firewallRuleProcess, request);
	
		if (firewallRuleProcess.getFireWallRule().getSourceIPs() != null && !firewallRuleProcess.getFireWallRule()
				.getSourceIPs().isEmpty()) {
		    for (FireWallRuleSourceIP fireWallRuleSourceIP : firewallRuleProcess.getFireWallRule().getSourceIPs()) {
		    	fireWallRuleSourceIP.setId(null);
		    	fireWallRuleSourceIP.setUpdated_date(null);
		    	fireWallRuleSourceIP.setDisabled(true);
		    }
		}
	
		if (firewallRuleProcess.getFireWallRule().getDestinationIPs() != null && !firewallRuleProcess.getFireWallRule()
				.getDestinationIPs().isEmpty()) {
		    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : firewallRuleProcess.getFireWallRule().getDestinationIPs()) {
		    	fireWallRuleDestinationIP.setId(null);
		    	fireWallRuleDestinationIP.setUpdated_date(null);
		    	fireWallRuleDestinationIP.setDisabled(true);
		    }
		}
	
		if (firewallRuleProcess.getFireWallRule().getPorts() != null && !firewallRuleProcess.getFireWallRule()
				.getPorts().isEmpty()) {
		    for (FireWallRulePort fireWallRulePort : firewallRuleProcess.getFireWallRule().getPorts()) {
		    	fireWallRulePort.setId(null);
		    	fireWallRulePort.setUpdated_date(null);
		    	fireWallRulePort.setDisabled(true);
		    }
		}
		
		if (firewallRuleProcess.getFireWallRule().getPolicies() != null && !firewallRuleProcess.getFireWallRule()
				.getPolicies().isEmpty()) {
		    for (FirewallRulePolicy firewallRulePolicy : firewallRuleProcess.getFireWallRule().getPolicies()) {
		    	firewallRulePolicy.setId(null);
		    	firewallRulePolicy.setUpdated_date(null);
		    	//firewallRulePolicy.setDisabled(true);
		    }
		}
		model.addAttribute("firewallRuleProcess", firewallRuleProcess);
		
		log.info("FirewallRuleController::cloneFirewallRules method ends...");
		return "c3par.firewall.clonefirewallrule";
    }
	
	/*
     * Reverse the Firewall Rule from List/View Firewall Rules Screen.
     * The Page will be displayed On Clicking Edit Link.
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/reverseFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String reverseFirewallRules(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallRuleController::cloneFirewallRules method starts...");
    	
    	//Remove Session Attributes
		removeSessionAttributes(request);
		
		FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
		firewallRuleProcess.setControlMessagesList(firewallRuleProcess.getControlMessages());
		firewallRuleProcess.setResourceTypes((firewallRuleProcess.getResourceTypes()));
	
		FireWallRuleProcess fwRuleProcess = new FireWallRuleProcess();
	
		fwRuleProcess.setTiRequest(getTirequestID(request));
		fwRuleProcess.setTiProcess(getTiProcessId(request));
		String ruleId = request.getParameter("ruleId");
		fwRuleProcess.setRuleId(Long.valueOf(ruleId));
		firewallRuleProcess.setCloneFromRuleID(Long.valueOf(ruleId));
		//set relationship for the TIRequestID
		setRelationshipType(getTirequestID(request), firewallRuleProcess);

		FireWallRule fireWallRule = fwRuleProcess.findFirewallRule();
						
		fireWallRule.setSourceObject(null);
		fireWallRule.setDestinationObject(null);
		fireWallRule.setPortObject(null);
		
		fireWallRule.setStatus(null);
		fireWallRule.setIsNew(null);
		fireWallRule.setFAFGenerated(null);
		
		TIRequest tiRequest =  getTirequest(request);
		
		fireWallRule.setTiRequest(tiRequest);
		
		fireWallRule.setId(null);
		fireWallRule.setUpdated_date(null);
		
		firewallRuleProcess.setFireWallRule(fireWallRule);
		
		List<FirewallLocation> fwLocations = firewallRuleProcess.getFirewallLocations();
		List<GenericLookup> connectivityTypes = firewallRuleProcess.getConnectivityTypeList();
		List<ResourceType> resourceTypes = firewallRuleProcess.getResourceTypeList(tiRequest.getTiProcess().getId());

		firewallRuleProcess.setFwLocations(fwLocations);
		firewallRuleProcess.setConnectivityTypes(connectivityTypes);
		firewallRuleProcess.setResourceTypes(resourceTypes);
		
		List<GenericLookup> ProtocolList = firewallRuleProcess.getProtocols();
		firewallRuleProcess.setProtocolList(ProtocolList);
		
		if (fireWallRule.getPolicyGroup()!= null && fireWallRule.getPolicyGroup().getConnectionFWLocation() != null
				&& fireWallRule.getPolicyGroup().getConnectivityType() != null) {
			Long fwLocationId = fireWallRule.getPolicyGroup().getConnectionFWLocation().getId();
			Long connectivityType = fireWallRule.getPolicyGroup().getConnectivityType().getId();
		    List<FireWallPolicyGroup> firewallGroupList = firewallRuleProcess.findFirewallGroups(fwLocationId, connectivityType);
			
			firewallRuleProcess.setFirewallGroupList(firewallGroupList);
		} else {
			firewallRuleProcess.setFirewallGroupList(new ArrayList<FireWallPolicyGroup>());
		}
		
		
		Long fwGroupId = null;
		Long fwPolicyId = null;
		
		if (fireWallRule.getPolicyGroup() != null) {
			fwGroupId = fireWallRule.getPolicyGroup().getId();
		}
		if (fireWallRule.getPolicy() != null) {
			fwPolicyId = fireWallRule.getPolicy().getId();
		}
		
		List<FireWallZone> zones = firewallRuleProcess.findFirewallZones(fwGroupId, fwPolicyId);
	
		if (zones != null) {
			firewallRuleProcess.setFirewallZones(zones);
		} else {
			firewallRuleProcess.setFirewallZones(new ArrayList<FireWallZone>());
		}
		
		//Set SESSION Attributes
		setSessionAttributes(firewallRuleProcess, request);
		
		//Reverse the NW Zones
		ResourceType srcNwZone = firewallRuleProcess.getFireWallRule().getDestinationNetworkZone();
		ResourceType dstNwZone = firewallRuleProcess.getFireWallRule().getSourceNetworkZone();
		firewallRuleProcess.getFireWallRule().setSourceNetworkZone(srcNwZone);
		firewallRuleProcess.getFireWallRule().setDestinationNetworkZone(dstNwZone);
		
		List<FireWallRuleSourceIP> sourceIPs = new ArrayList<FireWallRuleSourceIP>();
		
		List<FireWallRuleDestinationIP> destinationIPs = new ArrayList<FireWallRuleDestinationIP>();
			
		if (firewallRuleProcess.getFireWallRule().getSourceIPs() != null && !firewallRuleProcess.getFireWallRule()
				.getSourceIPs().isEmpty()) {
			FireWallRuleDestinationIP destinationIP = null;
		    for (FireWallRuleSourceIP fireWallRuleSourceIP : firewallRuleProcess.getFireWallRule().getSourceIPs()) {
		    	destinationIP = new FireWallRuleDestinationIP();
		    	destinationIP.setId(null);
		    	destinationIP.setUpdated_date(null);
		    	destinationIP.setIpAddress(fireWallRuleSourceIP.getIpAddress());
		    	destinationIP.setNAT(fireWallRuleSourceIP.getNAT());
		    	destinationIP.setObjRuleID(fireWallRuleSourceIP.getObjRuleID());
		    	destinationIP.setDisabled(true);
		    	destinationIPs.add(destinationIP);
		    }
		}
	
		if (firewallRuleProcess.getFireWallRule().getDestinationIPs() != null && !firewallRuleProcess.getFireWallRule()
				.getDestinationIPs().isEmpty()) {
			FireWallRuleSourceIP sourceIP = null;
		    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : firewallRuleProcess.getFireWallRule().getDestinationIPs()) {
		    	sourceIP = new FireWallRuleSourceIP();
		    	sourceIP.setId(null);
		    	sourceIP.setUpdated_date(null);
		    	sourceIP.setIpAddress(fireWallRuleDestinationIP.getIpAddress());
		    	sourceIP.setNAT(fireWallRuleDestinationIP.getNAT());
		    	sourceIP.setObjRuleID(fireWallRuleDestinationIP.getObjRuleID());
		    	sourceIP.setDisabled(true);
		    	sourceIPs.add(sourceIP);
		    }
		}
	
		firewallRuleProcess.getFireWallRule().setSourceIPs(sourceIPs);
		firewallRuleProcess.getFireWallRule().setDestinationIPs(destinationIPs);
		
		if (firewallRuleProcess.getFireWallRule().getPorts() != null && !firewallRuleProcess.getFireWallRule()
				.getPorts().isEmpty()) {
		    for (FireWallRulePort fireWallRulePort : firewallRuleProcess.getFireWallRule().getPorts()) {
		    	fireWallRulePort.setId(null);
		    	fireWallRulePort.setUpdated_date(null);
		    	fireWallRulePort.setDisabled(true);
		    }
		}
		
		if (firewallRuleProcess.getFireWallRule().getPolicies() != null && !firewallRuleProcess.getFireWallRule()
				.getPolicies().isEmpty()) {
		    for (FirewallRulePolicy firewallRulePolicy : firewallRuleProcess.getFireWallRule().getPolicies()) {
		    	firewallRulePolicy.setId(null);
		    	firewallRulePolicy.setUpdated_date(null);
		    	firewallRulePolicy.setDisabled(true);
		    }
		}
		
		model.addAttribute("firewallRuleProcess", firewallRuleProcess);
		
		log.info("FirewallRuleController::cloneFirewallRules method ends...");
		return "c3par.firewall.reversefirewallrule";
    }
	    
    /*
     * Split the Firewall Rule from List/View Firewall Rules Screen.
     * The Page will be displayed On Clicking Edit Link.
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/splitFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String splitFirewallRules(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallRuleController::splitFirewallRules method starts...");
		
    	FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
    	TIRequest tiRequest =  getTirequest(request);
		firewallRuleProcess.setTiRequest(tiRequest.getId());
		firewallRuleProcess.setTiProcess(tiRequest.getTiProcess().getId());
		String ruleId = request.getParameter("ruleId");
		firewallRuleProcess.setRuleId(Long.valueOf(ruleId));
	
		FireWallRule fireWallRule = firewallRuleProcess.findFirewallRule();
		
		//set relationship for the TIRequestID
		setRelationshipType(tiRequest.getId(), firewallRuleProcess);
		
		firewallRuleProcess.setFireWallRule(fireWallRule);
		model.addAttribute("firewallRuleProcess", firewallRuleProcess);
		log.info("FirewallRuleController::splitFirewallRules method ends...");
		return "c3par.firewall.splitfirewallrules";
    }
	
	
	 /*
     * To Search the Firewall Policy
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/loadSearchFirewallPolicy.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String loadSearchFirewallPolicy(HttpServletRequest request, ModelMap model) {
    	log.info("FirewallRuleController::searchFirewallPolicy method starts...");
    	String fwType = null;
    	String fwPolicy = null;
    	int offSet = 0;
    	String result = "pages/jsp/fw/SearchFirewallPolicy";
    	String type = null;
    	String field = request.getParameter("field");
    	String policyGroup = request.getParameter("groupId");
    	String fwName = null;
    	
    	FireWallRuleProcess searchFWRuleProcess = new FireWallRuleProcess();
	    searchFWRuleProcess.setOffset(offSet);
	    searchFWRuleProcess.setPolicy(fwPolicy);
	    searchFWRuleProcess.setFwType(fwType);
	    searchFWRuleProcess.setField(field);
	    searchFWRuleProcess.setFwName(fwName);
	    searchFWRuleProcess.setPolicyGroup(policyGroup);
	    List<FirewallPolicy> firewallPolicyList = new ArrayList<FirewallPolicy>();
	    firewallPolicyList = searchFWRuleProcess.getFirewallPolicies();
	    searchFWRuleProcess.setFirewallPolicyList(firewallPolicyList);
	    List<GenericLookup> firewallTypes = searchFWRuleProcess.getFirewallTypeList();
	    searchFWRuleProcess.setFirewallTypes(firewallTypes);
	    
		log.info("FirewallRuleController::searchFirewallPolicy..."+getTirequestID(request));
		//set relationship for the TIRequestID
		setRelationshipType(getTirequestID(request), searchFWRuleProcess);
		model.addAttribute("searchFWRuleProcess", searchFWRuleProcess);

	    log.info("FirewallRuleController::searchFirewallPolicy method ends..."+searchFWRuleProcess.getRelationshipType());
		return result;
    }
	
	 /*
     * To Search the Firewall Policy
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/searchFirewallPolicy.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String searchFirewallPolicy(HttpServletRequest request, ModelMap model,  @ModelAttribute("searchFWRuleProcess") FireWallRuleProcess searchFWRuleProcess) {
    	log.info("FirewallRuleController::searchFirewallPolicy method starts...");
    	String fwType = null;
    	String fwPolicy = null;
    	int offSet = 0;
    	String result = "pages/jsp/fw/SearchFirewallPolicy";
    	String type = null;
    	String field = request.getParameter("field");
    	String policyGroup = request.getParameter("groupId");
    	String fwName = null;
    	log.debug("chk searchFWRuleProcess "+searchFWRuleProcess);
    	if (searchFWRuleProcess != null) {
    		field = searchFWRuleProcess.getField();
    		fwPolicy = searchFWRuleProcess.getPolicy();
    		fwType = searchFWRuleProcess.getFwType();
    		offSet = searchFWRuleProcess.getOffset();
    		result = "pages/jsp/fw/FirewallPolicy";
    		type = (String)request.getParameter("type");
    		policyGroup = searchFWRuleProcess.getPolicyGroup();
    		fwName = searchFWRuleProcess.getFwName();
    		
    		if ("N".equalsIgnoreCase(type)) {
        		offSet = offSet+10;
        	} else if ("P".equalsIgnoreCase(type)) {
        		offSet = offSet-10;
        	}
    	}
    	
	    searchFWRuleProcess = new FireWallRuleProcess();
	    searchFWRuleProcess.setOffset(offSet);
	    searchFWRuleProcess.setPolicy(fwPolicy);
	    searchFWRuleProcess.setFwType(fwType);
	    searchFWRuleProcess.setField(field);
	    searchFWRuleProcess.setFwName(fwName);
	    searchFWRuleProcess.setPolicyGroup(policyGroup);
	    List<FirewallPolicy> firewallPolicyList = new ArrayList<FirewallPolicy>();
	    firewallPolicyList = searchFWRuleProcess.getFirewallPolicies();
	    searchFWRuleProcess.setFirewallPolicyList(firewallPolicyList);
	    List<GenericLookup> firewallTypes = searchFWRuleProcess.getFirewallTypeList();
	    searchFWRuleProcess.setFirewallTypes(firewallTypes);
	    
		log.info("FirewallRuleController::searchFirewallPolicy..."+getTirequestID(request));
		//set relationship for the TIRequestID
		setRelationshipType(getTirequestID(request), searchFWRuleProcess);
		model.addAttribute("searchFWRuleProcess", searchFWRuleProcess);

	    log.info("FirewallRuleController::searchFirewallPolicy method ends..."+searchFWRuleProcess.getRelationshipType());
		return result;
    }
	
	/*
     * To Populate the Firewall Group
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/populateFirewallGroup.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String populateFirewallGroup(HttpServletRequest request, ModelMap model
			,  @ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess, BindingResult bresult) {
		String result = "c3par.firewall.addnewfirewallrule";
		String fromPage = request.getParameter("fromPage");
		
		log.info("FirewallRuleController::populateFirewallGroup methods starts..."+fromPage);
		try {
		if ("Clone".equalsIgnoreCase(fromPage) || "Clone_FWGroupSearch".equalsIgnoreCase(fromPage)) {
			result = "c3par.firewall.clonefirewallrule";
		} else if ("Edit".equalsIgnoreCase(fromPage) || "Edit_FWGroupSearch".equalsIgnoreCase(fromPage)) {
			result = "c3par.firewall.editfirewallrule";
		}
		
		TIRequest tiRequest =  getTirequest(request);
		
		if ("_FWGroupSearch".equalsIgnoreCase(fromPage) || "Clone_FWGroupSearch".equalsIgnoreCase(fromPage) 
				|| "Edit_FWGroupSearch".equalsIgnoreCase(fromPage)){ 
			//search firewall group - load firewall groups
			log.info("search firewall group - load firewall groups");
			Long groupID = 0L;
			String groupIDStr = request.getParameter("firewallGroupID");
			if(groupIDStr != null && !groupIDStr.isEmpty()){
				groupID = Long.valueOf(groupIDStr);
			}
			FireWallPolicyGroup firewallGroup = firewallRuleProcess.getFirewallPolicyGroup(groupID);
			if (firewallGroup != null) {
				firewallRuleProcess.getFireWallRule().setPolicyGroup(firewallGroup);
			}else{
				log.error("Firewall Group not Exists");
				bresult.addError(new ObjectError("firewallRuleProcess.fireWallRule", "Firewall Group not Exists"));
				loadSessionAttributes(firewallRuleProcess, request);
				return result;
			}
		} else { 
			//search firewall policy - Load firewall policies
			log.info("search firewall policy - Load firewall policies");
			FireWallPolicyGroup firewallGroup = firewallRuleProcess.getFireWallRule().getPolicyGroup();
			
			if (firewallGroup != null) {
				firewallGroup = firewallRuleProcess.getFirewallPolicyGroup(firewallGroup.getId());
				firewallRuleProcess.getFireWallRule().setPolicyGroup(firewallGroup);
			} else {
				log.error("Firewall Group not Exists");
				bresult.addError(new ObjectError("firewallRuleProcess.fireWallRule", "Firewall Group not Exists"));
				loadSessionAttributes(firewallRuleProcess, request);
				return result;
			}
		}
		
		List<FirewallLocation> fwLocations = firewallRuleProcess.getFirewallLocations();
		List<GenericLookup> connectivityTypes = firewallRuleProcess.getConnectivityTypeList();
		
		firewallRuleProcess.setFwLocations(fwLocations);
		firewallRuleProcess.setConnectivityTypes(connectivityTypes);
		
		Long fwLocationId = firewallRuleProcess.getFireWallRule().getPolicyGroup().getConnectionFWLocation().getId();
		Long connectivityType = firewallRuleProcess.getFireWallRule().getPolicyGroup().getConnectivityType().getId();
	    List<FireWallPolicyGroup> firewallGroupList = firewallRuleProcess.findFirewallGroups(fwLocationId, connectivityType);
		
		firewallRuleProcess.setFirewallGroupList(firewallGroupList);
		
		Long fwGroupId = null;
		Long fwPolicyId = null;
		
		if (firewallRuleProcess.getFireWallRule().getPolicyGroup() != null) {
			fwGroupId = firewallRuleProcess.getFireWallRule().getPolicyGroup().getId();
		}
		if (firewallRuleProcess.getFireWallRule().getPolicy() != null) {
			fwPolicyId = firewallRuleProcess.getFireWallRule().getPolicy().getId();
		}
		setObjectNamePrefix(getTirequest(request),false,firewallRuleProcess);
		
		List<FireWallZone> zones = firewallRuleProcess.findFirewallZones(fwGroupId, fwPolicyId);
		firewallRuleProcess.setFirewallZones(zones);
		
		firewallRuleProcess.setControlMessagesList((firewallRuleProcess.getControlMessages()));
		firewallRuleProcess.setResourceTypes(firewallRuleProcess.getResourceTypeList(tiRequest.getTiProcess().getId()));
		firewallRuleProcess.setIpResourceTypes(firewallRuleProcess.getResourceTypeListIP(tiRequest.getTiProcess().getId()));
		List<GenericLookup> ProtocolList = firewallRuleProcess.getProtocols();
		firewallRuleProcess.setProtocolList(ProtocolList);
		
		//Set SESSION Attributes
		setSessionAttributes(firewallRuleProcess, request);
		
		//firewallRuleProcess.setFireWallRule(fwRuleProcess.getFireWallRule());
		
		firewallRuleProcess.getFireWallRule().setTiRequest(tiRequest);

		//set relationship for the TIRequestID
		setRelationshipType(tiRequest.getId(), firewallRuleProcess);
		
		if (!C3parStaticNames.IP_TEMPLATE.equals(firewallRuleProcess.getRelationshipType())
				&& !C3parStaticNames.PORT_TEMPLATE.equals(firewallRuleProcess.getRelationshipType())
				&& !C3parStaticNames.TEMPLATE_OBJ.equals(firewallRuleProcess.getRelationshipType())) {
			if (firewallRuleProcess.getFireWallRule().getTemplateID() != null 
					&& firewallRuleProcess.getFireWallRule().getTemplateID().longValue() > 0) {
				if (firewallRuleProcess.getFireWallRule().getSourceIPs() != null && !firewallRuleProcess.getFireWallRule().getSourceIPs().isEmpty()
						&& firewallRuleProcess.getFireWallRule().getSourceIPs().size() == 1
						&& firewallRuleProcess.getFireWallRule().getSourceIPs().get(0) != null
						&& firewallRuleProcess.getFireWallRule().getSourceIPs().get(0).getObjRuleID() != null
						&& firewallRuleProcess.getFireWallRule().getSourceIPs().get(0).getObjRuleID().longValue() > 0) {
					firewallRuleProcess.setSipNotEditable(true);
				}
				if (firewallRuleProcess.getFireWallRule().getPorts() != null && !firewallRuleProcess.getFireWallRule().getPorts().isEmpty()
						&& firewallRuleProcess.getFireWallRule().getPorts().size() == 1
						&& firewallRuleProcess.getFireWallRule().getPorts().get(0) != null
						&& firewallRuleProcess.getFireWallRule().getPorts().get(0).getObjRuleID() != null
						&& firewallRuleProcess.getFireWallRule().getPorts().get(0).getObjRuleID().longValue() > 0) {
					firewallRuleProcess.setPortNotEditable(true);
				}
				if (firewallRuleProcess.getFireWallRule().getDestinationIPs() != null && !firewallRuleProcess.getFireWallRule().getDestinationIPs().isEmpty()
						&& firewallRuleProcess.getFireWallRule().getDestinationIPs().size() == 1
						&& firewallRuleProcess.getFireWallRule().getDestinationIPs().get(0) != null
						&& firewallRuleProcess.getFireWallRule().getDestinationIPs().get(0).getObjRuleID() != null
						&& firewallRuleProcess.getFireWallRule().getDestinationIPs().get(0).getObjRuleID().longValue() > 0) {
					firewallRuleProcess.setDipNotEditable(true);
				}
			}
			
		}
		} catch (Exception e) {
			log.error(e,e);
		}
		model.addAttribute("firewallRuleProcess", firewallRuleProcess);
		log.info("......FirewallRuleController::populateFirewallGroup methods ends.");
		return result;
    }
	
	
	/*
     * Save the Split Firewall Rule.
     * The Page will be displayed On Clicking More Link.
     */
    /**
     * 
     * @return
     */
	@RequestMapping(value = "/saveSplitFirewallRule.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String saveSplitFirewallRule(HttpServletRequest request, @ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess, 
			ModelMap model, BindingResult bresult) {
	    log.info("FirewallRuleController::saveSplitFirewallRule method starts...");
	    String type = request.getParameter("splittype");
	    
		TIRequest tiRequest = getTirequest(request);
		
		FireWallRuleProcess fwRuleProcess = firewallRuleProcess;
		fwRuleProcess.setTiRequest(tiRequest.getId());
		fwRuleProcess.setTiProcess(tiRequest.getTiProcess().getId());
		
		firewallRuleProcess = new FireWallRuleProcess();
	
		log.debug("Rule Id ---->"+fwRuleProcess.getFireWallRule().getId());
		firewallRuleProcess.setTiRequest(tiRequest.getId());
		firewallRuleProcess.setRuleId(fwRuleProcess.getFireWallRule().getId());
	
		FireWallRule fireWallRule = firewallRuleProcess.findFirewallRule();
		fireWallRule.setTiRequest(tiRequest);
		
		FireWallRule fireWallRuleorg = new FireWallRule();
		
		ConvertUtils.register(new DateConverter(null), Date.class);
		
		try {
			BeanUtils.copyProperties(fireWallRuleorg, fireWallRule);
		} catch (IllegalAccessException e) {
			log.error(e, e);
		} catch (InvocationTargetException e) {
			log.error(e, e);
		}
	
		fireWallRule.setId(null);
		fireWallRule.setUpdated_date(null);
		firewallRuleProcess.setFireWallRule(fireWallRule);
		
		/*firewallRuleProcess.getFireWallRule().setRuleNumber(
			(firewallRuleProcess.getFirewallRulesRowCount(fwRuleProcess)+1));*/
	
		List<FireWallRuleSourceIP> sourceIPs = fwRuleProcess
			.getFireWallRule().getSourceIPs();
		List<FireWallRuleSourceIP> newSourceIPs = new ArrayList<FireWallRuleSourceIP>();
		List<FireWallRuleSourceIP> orgSourceIPs = new ArrayList<FireWallRuleSourceIP>();
		FireWallRuleSourceIP sourceIP = null;
		if (sourceIPs != null && !sourceIPs.isEmpty()) {
		    for (FireWallRuleSourceIP fireWallRuleSourceIP : sourceIPs) {
		    	sourceIP = getSelectedFirewallRuleSourceIP(
    					firewallRuleProcess.getFireWallRule().getSourceIPs(), fireWallRuleSourceIP.getId());
		    	FireWallRuleSourceIP fireWallRuleSourceIPorg = new FireWallRuleSourceIP();
		    	try {
					BeanUtils.copyProperties(fireWallRuleSourceIPorg, sourceIP);
				} catch (IllegalAccessException e) {
					log.error(e, e);
				} catch (InvocationTargetException e) {
					log.error(e, e);
				}
				log.debug("SIP isSelected ---->"+fireWallRuleSourceIP.isSelected());
		    		if (fireWallRuleSourceIP.isSelected()) {
		    			sourceIP.setId(null);
		    			sourceIP.setUpdated_date(null);
						newSourceIPs.add(sourceIP);
						if (fireWallRuleSourceIPorg != null && "sip".equals(type)) {
							fireWallRuleSourceIPorg.setDeletedTIRequest(tiRequest);
						}
		    		}
		    		orgSourceIPs.add(fireWallRuleSourceIPorg);
		    }
		    firewallRuleProcess.getFireWallRule().setSourceIPs(newSourceIPs);
		    fireWallRuleorg.setSourceIPs(orgSourceIPs);
		}
	
		List<FireWallRuleDestinationIP> destinationIPs = fwRuleProcess
			.getFireWallRule().getDestinationIPs();
		List<FireWallRuleDestinationIP> newDestIPs = new ArrayList<FireWallRuleDestinationIP>();
		List<FireWallRuleDestinationIP> orgDestIPs = new ArrayList<FireWallRuleDestinationIP>();
		FireWallRuleDestinationIP destinationIP = null;
		if (destinationIPs != null && !destinationIPs.isEmpty()) {
		    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : destinationIPs) {
		    	destinationIP = getSelectedFirewallRuleDestinationIP(
	    				firewallRuleProcess.getFireWallRule().getDestinationIPs(), fireWallRuleDestinationIP.getId());
		    	FireWallRuleDestinationIP fireWallRuleDestinationIPorg = new FireWallRuleDestinationIP();
		    	try {
					BeanUtils.copyProperties(fireWallRuleDestinationIPorg, destinationIP);
				} catch (IllegalAccessException e) {
					log.error(e, e);
				} catch (InvocationTargetException e) {
					log.error(e, e);
				}
		    	log.debug("DIP isSelected ---->"+fireWallRuleDestinationIP.isSelected());
		    	if (fireWallRuleDestinationIP.isSelected()) { 
		    		destinationIP.setId(null);
		    		destinationIP.setUpdated_date(null);
					newDestIPs.add(destinationIP);
					if (fireWallRuleDestinationIPorg != null && "dip".equals(type)) {
						fireWallRuleDestinationIPorg.setDeletedTIRequest(tiRequest);
					}
		    	}
		    	orgDestIPs.add(fireWallRuleDestinationIPorg);
		    }
		    firewallRuleProcess.getFireWallRule().setDestinationIPs(newDestIPs);
		    fireWallRuleorg.setDestinationIPs(orgDestIPs);
		}
	
		List<FireWallRulePort> ports = fwRuleProcess.getFireWallRule()
			.getPorts();
		List<FireWallRulePort> newPorts = new ArrayList<FireWallRulePort>();
		List<FireWallRulePort> orgPorts = new ArrayList<FireWallRulePort>();
		FireWallRulePort rulePort = null;
		if (ports != null && !ports.isEmpty()) {
		    for (FireWallRulePort fireWallRulePort : ports) {
		    	rulePort = getSelectedFirewallRulePort(
	    				firewallRuleProcess.getFireWallRule().getPorts(), fireWallRulePort.getId());
		    	log.debug("PRT isSelected ---->"+fireWallRulePort.isSelected());
		    	FireWallRulePort fireWallRulePortorg = new FireWallRulePort();
		    	try {
					BeanUtils.copyProperties(fireWallRulePortorg, rulePort);
				} catch (IllegalAccessException e) {
					log.error(e, e);
				} catch (InvocationTargetException e) {
					log.error(e, e);
				}
		    	if (fireWallRulePort.isSelected()) {
		    		rulePort.setId(null);
		    		rulePort.setUpdated_date(null);
			    	newPorts.add(rulePort);
			    	if (fireWallRulePortorg != null && "prt".equals(type)) {
			    		fireWallRulePortorg.setDeletedTIRequest(tiRequest);
					}
		    	}
		    	orgPorts.add(fireWallRulePortorg);
		    }
		    firewallRuleProcess.getFireWallRule().setPorts(newPorts);
		    fireWallRuleorg.setPorts(orgPorts);
		}
		
		List<FirewallRulePolicy> policies = fwRuleProcess.getFireWallRule()
		.getPolicies();
		List<FirewallRulePolicy> newPolicies = new ArrayList<FirewallRulePolicy>();
		List<FirewallRulePolicy> orgPolicies = new ArrayList<FirewallRulePolicy>();
		FirewallRulePolicy rulePolicy = null;
		if (policies != null && !policies.isEmpty()) {
	    for (FirewallRulePolicy firewallRulePolicy : policies) {
	    	rulePolicy = getSelectedFirewallRulePolicy(
    				firewallRuleProcess.getFireWallRule().getPolicies(), firewallRulePolicy.getId());
	    	log.debug("PRT isSelected ---->"+firewallRulePolicy.isSelected());
	    	FirewallRulePolicy firewallRulePolicyorg = new FirewallRulePolicy();
	    	try {
				BeanUtils.copyProperties(firewallRulePolicyorg, rulePolicy);
			} catch (IllegalAccessException e) {
				log.error(e, e);
			} catch (InvocationTargetException e) {
				log.error(e, e);
			}
	    	if (firewallRulePolicy.isSelected()) {
	    		rulePolicy.setId(null);
	    		rulePolicy.setUpdated_date(null);
		    	newPolicies.add(rulePolicy);
		    	if (firewallRulePolicyorg != null && "fwp".equals(type)) {
		    		firewallRulePolicyorg.setDeletedTIRequest(tiRequest);
				}
	    	}
	    	orgPolicies.add(firewallRulePolicyorg);
	    }
	    firewallRuleProcess.getFireWallRule().setPolicies(newPolicies);
	    fireWallRuleorg.setPolicies(orgPolicies);
	}
		
		if (firewallRuleProcess.getFireWallRule().getSourceIPs() != null && !firewallRuleProcess.getFireWallRule()
				.getSourceIPs().isEmpty()) {
		    for (FireWallRuleSourceIP fireWallRuleSourceIP : firewallRuleProcess.getFireWallRule().getSourceIPs()) {
		    	if (fireWallRuleSourceIP.getObjRuleID() != null && 
		    			fireWallRuleSourceIP.getObjRuleID().longValue() == 0) {
		    		fireWallRuleSourceIP.setObjRuleID(null);
		    	}
		    }
		}
		
		if (firewallRuleProcess.getFireWallRule().getDestinationIPs() != null && !firewallRuleProcess.getFireWallRule()
				.getDestinationIPs().isEmpty()) {
		    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : firewallRuleProcess.getFireWallRule().getDestinationIPs()) {
		    	if (fireWallRuleDestinationIP.getObjRuleID() != null && 
		    			fireWallRuleDestinationIP.getObjRuleID().longValue() == 0) {
		    		fireWallRuleDestinationIP.setObjRuleID(null);
		    	}
		    }
		}
	
		if (firewallRuleProcess.getFireWallRule().getPorts() != null && !firewallRuleProcess.getFireWallRule()
				.getPorts().isEmpty()) {
		    for (FireWallRulePort fireWallRulePort : firewallRuleProcess.getFireWallRule().getPorts()) {
		    	if (fireWallRulePort.getObjRuleID() != null && 
		    			fireWallRulePort.getObjRuleID().longValue() == 0) {
		    		fireWallRulePort.setObjRuleID(null);
		    	}
		    }
		}
		
		String lockedBy = null;
  		ActivityData activityData = null;
  		if(request.getSession().getAttribute("workflowActivityData")!= null){
  			activityData = (ActivityData)request.getSession().getAttribute("workflowActivityData");
  			if (activityData != null) {
  				lockedBy = activityData.getLockedBy();
  			}
  		}
	
		fwRuleProcess = null;
		fireWallRuleorg.setFwOstiaQuestionnaires(null);
		Long fireWallRuleId = null;
		try {
			firewallRuleProcess.getFireWallRule().setSourceObject(null);
			firewallRuleProcess.getFireWallRule().setDestinationObject(null);
			firewallRuleProcess.getFireWallRule().setPortObject(null);
			
			firewallRuleProcess.getFireWallRule().setStatus("ADD");
			firewallRuleProcess.getFireWallRule().setFwOstiaQuestionnaires(null);
			fireWallRuleId = firewallRuleProcess.getFireWallRule().save();
			firewallRuleProcess.updateFirewallRuleQuestionnaire(fireWallRuleId);
			firewallRuleProcess.resetFAFGeneratedStatus();
			log.debug("FirewallRuleController::Splitted FirewallRuleId... - "+fireWallRuleId);
			
			try {
				firewallRuleProcess.executeRiskRules(fireWallRuleId, tiRequest, getTIRequestDTO(request), false, lockedBy);
				firewallRuleProcess.updateFirewallRuleQuestionnaire(fireWallRuleId);
			} catch(Exception e) {
				log.error("Exception Occured... - "+e.getMessage());
			}
			
			firewallRuleProcess.setFireWallRule(fireWallRuleorg);
			if ("N".equals(firewallRuleProcess.getFireWallRule().getIsNew())) {
				log.debug("FirewallRuleController::saveFirewallRule..... N");
				if (firewallRuleProcess.getFireWallRule().getStatus() != null &&
						!firewallRuleProcess.getFireWallRule().getStatus().isEmpty()) {
					String status = firewallRuleProcess.getFireWallRule().getStatus();
					if ("ADD".equalsIgnoreCase(status)) {
						status = "DELETE";
					} else if ("EDIT".equalsIgnoreCase(status)) {
						status = "EDORDEL";
					}
					firewallRuleProcess.getFireWallRule().setStatus(status);
				}
			}
			
			fireWallRuleId = firewallRuleProcess.getFireWallRule().save();
			firewallRuleProcess.updateFirewallRuleQuestionnaire(fireWallRuleId);
			firewallRuleProcess.resetFAFGeneratedStatus();
			log.debug("FirewallRuleController::Updated Original FirewallRuleId... - "+fireWallRuleId);
		} catch (Exception e) {
			log.error(e, e);
			log.error("Exception Occured... - "+e.getMessage());
			return "save_firewallrules";
		}
		try {
			firewallRuleProcess.executeRiskRules(fireWallRuleId, tiRequest, getTIRequestDTO(request), false, lockedBy);
			firewallRuleProcess.updateFirewallRuleQuestionnaire(fireWallRuleId);
		} catch(Exception e) {
			log.error("Exception Occured... - "+e.getMessage());
		}
		log.info("FirewallRuleController::saveSplitFirewallRule method ends...");
		return "forward:/loadFirewallRules.act";
    }
    
    /**
     * 
     * @param ports
     * @param id
     * @return
     */
    private FireWallRulePort getSelectedFirewallRulePort(List<FireWallRulePort> ports, Long id) {
    	FireWallRulePort selected = null;

    		if (ports != null && !ports.isEmpty()) {
    		    for (FireWallRulePort fireWallRulePort : ports) {
    		    	if (fireWallRulePort.getId() != null && fireWallRulePort.getId().equals(id)) {
    		    		selected = fireWallRulePort;
    		    		break;
    		    	}
    		    }
    		}
    	return selected;
    }
    
    /**
     * 
     * @param ports
     * @param id
     * @return
     */
    private FirewallRulePolicy getSelectedFirewallRulePolicy(List<FirewallRulePolicy> policies, Long id) {
    	FirewallRulePolicy selected = null;

    		if (policies != null && !policies.isEmpty()) {
    		    for (FirewallRulePolicy firewallRulePolicy : policies) {
    		    	if (firewallRulePolicy.getId() != null && firewallRulePolicy.getId().equals(id)) {
    		    		selected = firewallRulePolicy;
    		    		break;
    		    	}
    		    }
    		}
    	return selected;
    }
    
    /**
     * 
     * @param sourceIPs
     * @param id
     * @return
     */
    private FireWallRuleSourceIP getSelectedFirewallRuleSourceIP(List<FireWallRuleSourceIP> sourceIPs, Long id) {
		FireWallRuleSourceIP selected = null;
		
		if (sourceIPs != null && !sourceIPs.isEmpty()) {
		    for (FireWallRuleSourceIP fireWallRuleSourceIP : sourceIPs) {
		    		if (fireWallRuleSourceIP.getId() != null && fireWallRuleSourceIP.getId().equals(id)) { 
		    			selected = fireWallRuleSourceIP;
		    			break;
		    		}
		    }
		}

		return selected;
    }
    
    /**
     * 
     * @param destinationIPs
     * @param id
     * @return
     */
    private FireWallRuleDestinationIP getSelectedFirewallRuleDestinationIP(List<FireWallRuleDestinationIP> destinationIPs, Long id) {
    	FireWallRuleDestinationIP selected = null;

		if (destinationIPs != null && !destinationIPs.isEmpty()) {
		    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : destinationIPs) {
		    	if (fireWallRuleDestinationIP.getId() != null && fireWallRuleDestinationIP.getId().equals(id)) { 
		    		selected = fireWallRuleDestinationIP;
		    		break;
		    	}
		    }
		}

		return selected;	
    }
    

	private TiRequestDTO getTIRequestDTO(HttpServletRequest request) {
	BusinessJustificationProcess busjusProcess = new BusinessJustificationProcess();
		
	Long tirequestId = getTirequestID(request);
	
	Long planningId = busjusProcess.getPlanningId(tirequestId);
	
	TIRequest tiRequest = busjusProcess.getTIRequestDetails(tirequestId);
	
	ConnectionRequest conreq = busjusProcess.getConnectionRequest(planningId);
	
	String relationshipType = null;
	String sourceResourceType = null;
	String targetResourceType = null;
	String requestPriority = null;
	String region = null;
	String sector = null;
	String businessUnit = null;
	String thirdParty = null;
	String uturnThirdParty = null;
	String connectionType = null;
	 
	
	if (tiRequest != null && tiRequest.getTiProcess() != null) {
		requestPriority =  tiRequest.getPriority().getValue2();
		Relationship relationship =tiRequest.getTiProcess().getRelationshipId();
		if (relationship != null) {
			sourceResourceType = relationship.getRequesterResourceType().getName();
			if (relationship.getTargetResourceType() != null) {
				targetResourceType = relationship.getTargetResourceType().getName();
			} else {
				targetResourceType = "";
			}
			relationshipType = relationship.getRelationshipType();
			
			
			if (relationship.getRelcitiHierarchyXrefs() != null && relationship.getRelcitiHierarchyXrefs().size() > 0) {
				RelCitiHierarchyXref relXref = (RelCitiHierarchyXref)relationship.getRelcitiHierarchyXrefs().get(0);
				if(relXref.getCitiHierarchyMaster() !=null && relXref.getCitiHierarchyMaster().getBusinessUnit() != null) {
					businessUnit = relXref.getCitiHierarchyMaster().getBusinessUnit().getBusinessName();
					region = relXref.getCitiHierarchyMaster().getRegion().getName();
					sector = relXref.getCitiHierarchyMaster().getSector().getName();
	                log.debug("ManageFafAction:CitiHierMaster:"+businessUnit);
				}
				
				
			}
				
			if (relationship.getThirdParty() != null) {
				thirdParty = relationship.getThirdParty().getName();
			}
			if (relationship.getUturnThirdParty() != null) {
				uturnThirdParty = relationship.getUturnThirdParty().getName();
			}
			
			
		}
	}
	
	log.debug("relationshipType: "+relationshipType);
	log.debug("sourceResourceType: "+sourceResourceType);
	log.debug("targetResourceType: "+targetResourceType);
	log.debug("requestPriority: "+requestPriority);
	log.debug("region: "+region);
	log.debug("sector: "+sector);
	log.debug("businessUnit: "+businessUnit);
	log.debug("thirdParty: "+thirdParty);
	log.debug("uturnThirdParty: "+uturnThirdParty);
	log.debug("connectionType: "+connectionType);
	TiRequestDTO tiRequestDTO = new TiRequestDTO();
	tiRequestDTO.setRelationshipType(relationshipType);
	tiRequestDTO.setSourceResourceType(sourceResourceType);
	tiRequestDTO.setTargetResourceType(targetResourceType);
	tiRequestDTO.setRequestPriority(requestPriority);
	tiRequestDTO.setRegion(region);
	tiRequestDTO.setSector(sector);
	tiRequestDTO.setBusinessUnit(businessUnit);
	tiRequestDTO.setConnectionType(connectionType);
	tiRequestDTO.setThirdParty(thirdParty);
	tiRequestDTO.setUturnThirdParty(uturnThirdParty);
	
	return tiRequestDTO;
}
	
	public void setRelationshipType(Long tiRequestID, FireWallRuleProcess fwRuleProcess){
		//get relationship for the TIRequestID
		ArrayList relationshipDetails = (ArrayList) fwRuleProcess.getTIReqeustRelationshipDetails(tiRequestID);

		fwRuleProcess.setRequesterResourceType((Integer)relationshipDetails.get(0));
		fwRuleProcess.setTargetResourceType((Integer)relationshipDetails.get(1));
		fwRuleProcess.setRelationshipType(String.valueOf(relationshipDetails.get(2)));
		fwRuleProcess.setTemplateResourceType((Integer)relationshipDetails.get(3));		
    }
	
	 private void setSessionAttributes(FireWallRuleProcess firewallRuleProc, HttpServletRequest request) {
	    	request.getSession().setAttribute("CONTROLMSGS",firewallRuleProc.getControlMessagesList());
	    	request.getSession().setAttribute("FWLOCATION",firewallRuleProc.getFwLocations());
	    	request.getSession().setAttribute("CONNECTIVITYTYPE",firewallRuleProc.getConnectivityTypes());
	    	request.getSession().setAttribute("RESOURCETYPE",firewallRuleProc.getResourceTypes());
	    	request.getSession().setAttribute("RESOURCETYPEIP",firewallRuleProc.getIpResourceTypes());
	    	request.getSession().setAttribute("FWGROUP",firewallRuleProc.getFirewallGroupList());
	    	request.getSession().setAttribute("FWZONES",firewallRuleProc.getFirewallZones());
	    	request.getSession().setAttribute("PROTOCOLLIST",firewallRuleProc.getProtocolList());
	    }
	    
	    private void loadSessionAttributes(FireWallRuleProcess firewallRuleProc, HttpServletRequest request) {
	    	firewallRuleProc.setControlMessagesList((List<GenericLookup>)request.getSession().getAttribute("CONTROLMSGS"));
	    	firewallRuleProc.setFwLocations((List<FirewallLocation>)request.getSession().getAttribute("FWLOCATION"));
	    	firewallRuleProc.setConnectivityTypes((List<GenericLookup>)request.getSession().getAttribute("CONNECTIVITYTYPE"));
	    	firewallRuleProc.setFirewallGroupList((List<FireWallPolicyGroup>)request.getSession().getAttribute("FWGROUP"));
	    	firewallRuleProc.setResourceTypes((List<ResourceType>)request.getSession().getAttribute("RESOURCETYPE"));
	    	firewallRuleProc.setIpResourceTypes((List<ResourceType>)request.getSession().getAttribute("RESOURCETYPEIP"));
	    	firewallRuleProc.setFirewallZones((List<FireWallZone>)request.getSession().getAttribute("FWZONES"));
	    	firewallRuleProc.setProtocolList((List<GenericLookup>)request.getSession().getAttribute("PROTOCOLLIST"));
	    }
	    
	    private void removeSessionAttributes(HttpServletRequest request) {
	    	request.getSession().removeAttribute("CONTROLMSGS");
	    	request.getSession().removeAttribute("FWLOCATION");
	    	request.getSession().removeAttribute("CONNECTIVITYTYPE");
	    	request.getSession().removeAttribute("RESOURCETYPE");
	    	request.getSession().removeAttribute("RESOURCETYPEIP");
	    	request.getSession().removeAttribute("FWGROUP");
	    	request.getSession().removeAttribute("FWZONES");
	    	request.getSession().removeAttribute("PROTOCOLLIST");
	    }
	    
	    private Date getDateTime(String dateString) {
	    	SimpleDateFormat format =
	            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    	Date parsed = null;
			try {
				parsed = format.parse(dateString);
			} catch (ParseException e) {
				log.error("FirewallRuleController::getDateTime..."+e.getMessage());
				e.printStackTrace();
			}
	    	return parsed;
	    }
	    
	    public void setObjectNamePrefix(TIRequest tiRequestEntity,boolean isEdit, FireWallRuleProcess firewallRuleProcess) {
			String relationshiptype = firewallRuleProcess.getRelationshipType();
			log.info("setObjectNamePrefix ,relationshiptype ==>"+relationshiptype);
			if(relationshiptype != null && ( relationshiptype.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE) 
					|| relationshiptype.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE) 
					|| relationshiptype.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ))){	
				
				FirewallRulePolicy firewallRulePolicy = null;
				
				if (firewallRuleProcess.getFireWallRule() != null 
						&& firewallRuleProcess.getFireWallRule().getPolicies() != null
						&& firewallRuleProcess.getFireWallRule().getPolicies().size() > 0) {
					firewallRulePolicy = firewallRuleProcess.getFireWallRule().getPolicies().get(0);
				}
				if(firewallRulePolicy != null && firewallRulePolicy.getFirewallPolicy() != null){
					String policyname = firewallRulePolicy.getFirewallPolicy().getName();
					log.info("populateFirewallGroup ,policyname ==>"+policyname);
					String objectPrefix = null;
					if(policyname != null && policyname.equalsIgnoreCase("ALL FIREWALL")){
						objectPrefix = "g_grp_"+tiRequestEntity.getTiProcess().getId()+"_";
						firewallRuleProcess.setObjectNamePrefix(objectPrefix);
					}else{
						objectPrefix = "l_grp_"+tiRequestEntity.getTiProcess().getId()+"_";
					}
					log.info("populateFirewallGroup ,objectPrefix ==>"+objectPrefix);
					
					firewallRuleProcess.setObjectNamePrefix(objectPrefix);
					if(isEdit == false){
						if(firewallRuleProcess.getFireWallRule().getSourceObject() == null){
							firewallRuleProcess.getFireWallRule().setSourceObject(new IPAddress());
						}
						firewallRuleProcess.getFireWallRule().getSourceObject().setIpAddress(objectPrefix);
						
						if(firewallRuleProcess.getFireWallRule().getDestinationObject() == null){
							firewallRuleProcess.getFireWallRule().setDestinationObject(new IPAddress());
						}
						firewallRuleProcess.getFireWallRule().getDestinationObject().setIpAddress(objectPrefix);
						
						if(firewallRuleProcess.getFireWallRule().getPortObject() == null){
							firewallRuleProcess.getFireWallRule().setPortObject(new Port());
						}
						firewallRuleProcess.getFireWallRule().getPortObject().setPortNumber(objectPrefix);
					}
				}
			}		
	    }
	    
	    
	    /*
	     * retrieve Firewall and Circuit Details
	     * 
	     */
	    @RequestMapping(value = "/loadFWCircuitDetails.act", method = { RequestMethod.GET, RequestMethod.POST})
		public String loadFWCircuitDetails(HttpServletRequest request, ModelMap model) {
	    	log.info("FirewallRuleController::loadFWCircuitDetails methods starts...");
	    	FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
	    	//read the tiRequestID
	    	Long tiRequestID = 0L , processID = 0L;
			List<FirewallPolicy> fwpolicyList = null;
			List<FireWallPolicyGroup> fwpolicyGrpList = null;
			tiRequestID = getTirequestID(request);
			log.info("FirewallRuleController::tiRequestID ---> "+tiRequestID);
			String con_type = (String) request.getSession().getAttribute("con_type");
			log.debug(" ConnectionType :: " + con_type);
			processID = getTiProcessId(request);
			//retrieve the Firewall and Circuit details
			tiRequestID = getPreviousVersionTiRequestID(processID, request);
			firewallRuleProcess.setTiRequest(tiRequestID);
			//set pagination parameters
			firewallRuleProcess.setOffset(0);
			firewallRuleProcess.setPageNo(1);
			firewallRuleProcess.setLimit(10);
			if("ipReg".equalsIgnoreCase(con_type))
			{
				firewallRuleProcess.setIsIpReg("Y");
				log.debug(" IPRegistration :: " + con_type);
			}else
			{
				firewallRuleProcess.setIsIpReg("N");
				log.debug(" Firewall :: " + con_type);
			}
			TIRequest tiRequest =  firewallRuleProcess.getTIRequest(tiRequestID);
			log.info("FirewallRuleController::loadFWCircuitDetails method, FireflowFlag==>"+tiRequest.getFireflowFlag());
			if(tiRequest != null && tiRequest.getFireflowFlag() != null
					&& tiRequest.getFireflowFlag().equalsIgnoreCase("N")){
				fwpolicyList = firewallRuleProcess.getFirewallCircuitPolicyList();
			}else{
				fwpolicyGrpList = firewallRuleProcess.getFirewallCircuitGroupList();			
			}

			int rowCount = firewallRuleProcess.getRowCount();		
			//To calculate no of pages
			int totalPages = 0;
			int limit = 10;		
			if (rowCount%limit > 0) {
				totalPages = Math.round((rowCount/limit)+0.5f);
			} else {
				totalPages = Math.round(rowCount/limit);
			}		
			firewallRuleProcess.setTotalPages(totalPages);
			//set result into form
			firewallRuleProcess.setFirewallPolicyList(fwpolicyList);
			firewallRuleProcess.setFirewallGroupList(fwpolicyGrpList);
			firewallRuleProcess.setFireWallRule(new FireWallRule());
			firewallRuleProcess.getFireWallRule().setTiRequest(new TIRequest());
			firewallRuleProcess.getFireWallRule().getTiRequest().setFireflowFlag(tiRequest.getFireflowFlag());
			
			isCompleteCheck(request);
			
			model.addAttribute("firewallRuleProcess", firewallRuleProcess);
			
			log.info("FirewallRuleController::loadFWCircuitDetails methods ends...");	
	    	return "c3par.firewall.firewallCircuitDetails";
	    }
	    
	    
	    /**
	     * 
	     * @return
	     */
	    @RequestMapping(value = "/paginateFirewallAndCircuitDetails.act", method = { RequestMethod.GET, RequestMethod.POST})
		public String paginateFirewallAndCircuitDetails(HttpServletRequest request, ModelMap model, @ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess) {
		    log.info("FirewallRulesController::paginateFirewallAndCircuitDetails methods starts...");		
			String type = (String)request.getParameter("pageType");	
			//read the tiRequestID
	    	Long tiRequestID = 0L;
			List<FirewallPolicy> fwpolicyList = null;
			List<FireWallPolicyGroup> fwpolicyGrpList = null;
			tiRequestID = getTirequestID(request);
			log.info("FirewallRulesController::tiRequestID ---> "+tiRequestID+",type..."+type);
			String con_type = (String) request.getSession().getAttribute("con_type");
			log.debug(" ConnectionType :: " + con_type);
			int curOffSet = firewallRuleProcess.getOffset();		
			int limit = firewallRuleProcess.getLimit();		
			int pageNo = firewallRuleProcess.getPageNo();
			
			firewallRuleProcess = new FireWallRuleProcess();
			firewallRuleProcess.setLimit(limit);
			firewallRuleProcess.setTiRequest(tiRequestID);
			
			if ("N".equalsIgnoreCase(type)) {
				firewallRuleProcess.setOffset(curOffSet+firewallRuleProcess.getLimit());
				firewallRuleProcess.setPageNo(pageNo+1);
			} else if ("P".equalsIgnoreCase(type)) {
				firewallRuleProcess.setOffset(curOffSet-firewallRuleProcess.getLimit());
				firewallRuleProcess.setPageNo(pageNo-1);
			} else if ("X".equalsIgnoreCase(type)) {
				firewallRuleProcess.setOffset(limit * (pageNo-1));
				firewallRuleProcess.setPageNo(pageNo);
			} else if ("L".equalsIgnoreCase(type)) {
				firewallRuleProcess.setOffset(0);
				firewallRuleProcess.setPageNo(1);
			} else {
				firewallRuleProcess.setOffset(0);
				firewallRuleProcess.setPageNo(1);
			}
			
			TIRequest tiRequest =  firewallRuleProcess.getTIRequest(tiRequestID);
			log.info("FirewallRulesController::paginateFirewallAndCircuitDetails method, FireflowFlag==>"+tiRequest.getFireflowFlag());
			if("ipReg".equalsIgnoreCase(con_type))
			{
				firewallRuleProcess.setIsIpReg("Y");
				log.debug(" IPRegistration :: " + con_type);
			}else
			{
				firewallRuleProcess.setIsIpReg("N");
				log.debug(" Firewall :: " + con_type);
			}
			if(tiRequest != null && tiRequest.getFireflowFlag() != null
					&& tiRequest.getFireflowFlag().equalsIgnoreCase("N")){
				fwpolicyList = firewallRuleProcess.getFirewallCircuitPolicyList();
				if(fwpolicyList != null)
					log.info("FirewallRulesController::fwpolicyList..."+fwpolicyList.size());
			}else{
				fwpolicyGrpList = firewallRuleProcess.getFirewallCircuitGroupList();
				if(fwpolicyGrpList != null)
					log.info("FirewallRulesController::fwpolicyGrpList..."+fwpolicyGrpList.size());			
			}
			
			int rowCount = firewallRuleProcess.getRowCount();		
			int totalPages = 0;		
			if (rowCount%limit > 0) {
				totalPages = Math.round((rowCount/limit)+0.5f);
			} else {
				totalPages = Math.round(rowCount/limit);
			}		
			firewallRuleProcess.setTotalPages(totalPages);
			//set result into form
			firewallRuleProcess.setFirewallPolicyList(fwpolicyList);
			firewallRuleProcess.setFirewallGroupList(fwpolicyGrpList);
			firewallRuleProcess.setFireWallRule(new FireWallRule());
			firewallRuleProcess.getFireWallRule().setTiRequest(new TIRequest());
			firewallRuleProcess.getFireWallRule().getTiRequest().setFireflowFlag(tiRequest.getFireflowFlag());
			
			model.addAttribute("firewallRuleProcess", firewallRuleProcess);
			
			log.info("FirewallRulesController::firewallRuleProcess methods ends...");
			return "c3par.firewall.firewallCircuitDetails";
	    }
	    
	    
	    /*
	     * retrieve Template connections
	     * 
	     */
	    @RequestMapping(value = "/getViewTemplate.act", method = { RequestMethod.GET, RequestMethod.POST})
		public String getViewTemplate(HttpServletRequest request, ModelMap model) {
			log.info("FirewallRulesController::getViewTemplate methods starts...");
			
			FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();

			String tiRequestID = (String) request.getSession().getAttribute("tireqid");
			Long tiReqID = 0L;
			if(tiRequestID != null && !tiRequestID.isEmpty()){
				tiReqID = Long.parseLong(tiRequestID);
			}
			firewallRuleProcess.setTiRequest(tiReqID);
			//set pagination parameters
			firewallRuleProcess.setOffset(0);
			firewallRuleProcess.setPageNo(1);
			firewallRuleProcess.setLimit(10);
			
			List<TemplateConnection> resultList = firewallRuleProcess.getViewTemplate();
			
			int rowCount = firewallRuleProcess.getRowCount();		
			//To calculate no of pages
			int totalPages = 0;
			int limit = 10;		
			if (rowCount%limit > 0) {
				totalPages = Math.round((rowCount/limit)+0.5f);
			} else {
				totalPages = Math.round(rowCount/limit);
			}		
			firewallRuleProcess.setTotalPages(totalPages);
			//set result into form
			firewallRuleProcess.setTemplateConnectionList(resultList);
			
			model.addAttribute("firewallRuleProcess", firewallRuleProcess);
			
			log.info("FirewallRulesController::getViewTemplate methods ends..."+resultList.size());
			return "c3par.firewall.viewtemplates";
	    }

	    @RequestMapping(value = "/paginateViewTemplate.act", method = { RequestMethod.GET, RequestMethod.POST})
		public String paginateViewTemplate(HttpServletRequest request, ModelMap model, @ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess) {
		    log.info("FirewallRulesController::paginateViewTemplate methods starts...");		
			String type = (String)request.getParameter("pageType");	
			//read the tiRequestID
			String tiRequestID = (String) request.getSession().getAttribute("tireqid");
			Long tiReqID = 0L;
			if(tiRequestID != null && !tiRequestID.isEmpty()){
				tiReqID = Long.parseLong(tiRequestID);
			}
			log.info("FirewallRulesController::tiRequestID ---> "+tiRequestID+",type..."+type);
			int curOffSet = firewallRuleProcess.getOffset();		
			int limit = firewallRuleProcess.getLimit();		
			int pageNo = firewallRuleProcess.getPageNo();
			long validConnectionID=firewallRuleProcess.getValidConnectionID();
			String validConnectionName=firewallRuleProcess.getValidConnectionName();
			String filterText=firewallRuleProcess.getFilterText();
			
			firewallRuleProcess = new FireWallRuleProcess();
			firewallRuleProcess.setLimit(limit);
			firewallRuleProcess.setTiRequest(tiReqID);
			firewallRuleProcess.setValidConnectionID(validConnectionID);
			firewallRuleProcess.setValidConnectionName(validConnectionName);
			firewallRuleProcess.setFilterText(filterText);
			if ("N".equalsIgnoreCase(type)) {
				firewallRuleProcess.setOffset(curOffSet+firewallRuleProcess.getLimit());
				firewallRuleProcess.setPageNo(pageNo+1);
			} else if ("P".equalsIgnoreCase(type)) {
				firewallRuleProcess.setOffset(curOffSet-firewallRuleProcess.getLimit());
				firewallRuleProcess.setPageNo(pageNo-1);
			} else if ("X".equalsIgnoreCase(type)) {
				firewallRuleProcess.setOffset(limit * (pageNo-1));
				firewallRuleProcess.setPageNo(pageNo);
			} else if ("L".equalsIgnoreCase(type)) {
				firewallRuleProcess.setOffset(0);
				firewallRuleProcess.setPageNo(1);
			} else {
				firewallRuleProcess.setOffset(0);
				firewallRuleProcess.setPageNo(1);
			}
			
			List<TemplateConnection> resultList = firewallRuleProcess.getViewTemplate();
			log.info("FirewallRulesController::templateconnection List..."+resultList.size());
			
			int rowCount = firewallRuleProcess.getRowCount();		
			int totalPages = 0;		
			if (rowCount%limit > 0) {
				totalPages = Math.round((rowCount/limit)+0.5f);
			} else {
				totalPages = Math.round(rowCount/limit);
			}		
			firewallRuleProcess.setTotalPages(totalPages);
			//set result into form
			firewallRuleProcess.setTemplateConnectionList(resultList);
			
			model.addAttribute("firewallRuleProcess", firewallRuleProcess);
			
			log.info("FirewallRulesController::paginateViewTemplate methods ends...");
			return "c3par.firewall.viewtemplates";
	    }

	    @RequestMapping(value = "/saveTemplateFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
	  	public String saveTemplateFirewallRules(HttpServletRequest request, ModelMap model, @ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess) {
		    log.info("FirewallRulesController::saveTemplateFirewallRules methods starts...");

			//read the processID
			String processID = (String) request.getParameter("processID");
			Long procID = 0L, tiReqID = 0L;
			if(processID != null && !processID.isEmpty()){
				procID = Long.parseLong(processID);
			}
			
			tiReqID = getPreviousVersionTiRequestIDForTemplate(procID, request);
			//Modified for task 42665-ends
			TIRequest tiRequest = getTirequest(request);
			
			//retrieve the firewall rules
			FireWallRuleProcess fwRuleProcess = new FireWallRuleProcess();
			fwRuleProcess.setTiProcess(procID);
			fwRuleProcess.setTiRequest(tiReqID);
			//Modified for task 42665-starts
			List<HistoryFireWallRule> fireWallRules = fwRuleProcess.getTemplateFirewallRules();
			//Modified for task 42665-ends
			log.info("FirewallRulesController::fireWallRules.size() ---> "+fireWallRules.size());
			//Save the firewall rules
			firewallRuleProcess.setTiRequest(tiRequest.getId());
			
			List<FireWallRule> newFireWallRules = new ArrayList<FireWallRule>();
			
			String con_type= "";
			if(request.getSession().getAttribute("con_type") != null){
				con_type = (String) request.getSession().getAttribute("con_type");
			}
			
			FirewallPolicy firewallPolicy = null;
			
			//Modified for task 42665-starts
			for(HistoryFireWallRule fwrule:fireWallRules){
				FireWallRule newFWRule = new FireWallRule();
				
				newFWRule.setSourceIPs(new ArrayList<FireWallRuleSourceIP>());
				newFWRule.setDestinationIPs(new ArrayList<FireWallRuleDestinationIP>());
				newFWRule.setPorts(new ArrayList<FireWallRulePort>());
				newFWRule.setPolicies(new ArrayList<FirewallRulePolicy>());
				newFWRule.setSourceObject(null);
				newFWRule.setDestinationObject(null);
				newFWRule.setPortObject(null);
					
				newFWRule.setTiRequest(tiRequest);
				newFWRule.setUpdatedTIRequest(tiRequest);
				newFWRule.setTemplateID(fwrule.getRuleId());
				newFWRule.setIsNew("Y");
				newFWRule.setStatus("ADD");	
				newFWRule.setFAFGenerated("N");
				
				newFWRule.setSourceZone(fwrule.getSourceZone());
				newFWRule.setDestinationZone(fwrule.getDestinationZone());
				newFWRule.setSourceNetworkZone(fwrule.getSourceNetworkZone());
				newFWRule.setDestinationNetworkZone(fwrule.getDestinationNetworkZone());			
				newFWRule.setBidirectional(fwrule.getBidirectional());
				newFWRule.setRuleType(fwrule.getRuleType());
		
				if(con_type != null && "ipReg".equalsIgnoreCase(con_type)){	
					if(firewallPolicy == null){
						firewallPolicy = firewallRuleProcess.getFirewallPolicyForIPReg();
					}
					if (firewallPolicy != null) {
						newFWRule.setPolicy(firewallPolicy);
						newFWRule.setPolicyGroup(firewallPolicy.getFireWallPolicyGroup());
						
						FirewallRulePolicy newPolicy = new FirewallRulePolicy();
						newPolicy.setFirewallPolicy(firewallPolicy);							
						newPolicy.setFireWallRule(newFWRule);
						newPolicy.setUpdatedTIRequest(tiRequest);
						newPolicy.setIsNew("Y");			
						newFWRule.getPolicies().add(newPolicy);
					}
					ResourceType srcResourceType = null;
					List<ResourceType> ipResourceTypes = firewallRuleProcess.getResourceTypeListIP(getTiProcessId(request));
					if(ipResourceTypes != null && ipResourceTypes.size() > 0){
						srcResourceType  =  (ResourceType)ipResourceTypes.get(0);
						newFWRule.setSourceNetworkZone(srcResourceType); 
					}
					newFWRule.setIsIpReg("Y");
				}else{
					newFWRule.setPolicyGroup(fwrule.getPolicyGroup());
					newFWRule.setIsIpReg("N");
				}
				if(fwrule.getSourceIPs() != null && !fwrule.getSourceIPs().isEmpty() && fwrule.getSourceObject() != null
						&&  fwrule.getSourceObject().getId() != null){
					FireWallRuleDestinationIP newDestIP = new FireWallRuleDestinationIP();
					newDestIP.setIpAddress(fwrule.getSourceObject());						
					newDestIP.setUpdatedTIRequest(tiRequest);
					newDestIP.setIsNew("Y");
					newDestIP.setFireWallRule(newFWRule);
					newDestIP.setObjRuleID(fwrule.getRuleId());
					newFWRule.getDestinationIPs().add(newDestIP);
					
				}else{
					newFWRule.setDestinationIPs(null);
				}
				
				newFWRule.setSourceIPs(null);
				
				if(fwrule.getPorts() != null && !fwrule.getPorts().isEmpty()
						&& fwrule.getPortObject() != null && fwrule.getPortObject().getId() != null){
					//Port port = fwport.getPort();
					FireWallRulePort newPort = new FireWallRulePort();
					newPort.setPort(fwrule.getPortObject());							
					newPort.setFireWallRule(newFWRule);
					newPort.setUpdatedTIRequest(tiRequest);
					newPort.getPort().setIsNew("Y");
					newPort.setIsNew("Y");			
					newPort.setObjRuleID(fwrule.getRuleId());
					
					newFWRule.getPorts().add(newPort);
				}else{
					newFWRule.setPorts(null);
				}			
				newFireWallRules.add(newFWRule);
				
				if(newFWRule.getIsIpReg() != null && newFWRule.getIsIpReg().equalsIgnoreCase("N")){
					if(fwrule.getPolicies() != null && !fwrule.getPolicies().isEmpty()){
					//Port port = fwport.getPort();
					for (HistoryFirewallRulePolicy  firewallRulePolicy : fwrule.getPolicies()) {
						FirewallRulePolicy newPolicy = new FirewallRulePolicy();
						newPolicy.setFirewallPolicy(firewallRulePolicy.getFirewallPolicy());							
						newPolicy.setFireWallRule(newFWRule);
						newPolicy.setUpdatedTIRequest(tiRequest);
						newPolicy.setIsNew("Y");			
						newFWRule.getPolicies().add(newPolicy);
					}
					
				}else{
					newFWRule.setPolicies(null);
				}	
				}
				newFireWallRules.add(newFWRule);
			}
			try {
				firewallRuleProcess.saveTemplateFireWallRules(newFireWallRules);
			} catch (Exception e) {
				log.error(e, e);
			}
			log.info("FirewallRulesController::saveTemplateFirewallRules Ends ....");
			
	    	return "forward:/loadFirewallRules.act";
	    }
	    
	    @RequestMapping(value = "/deleteTemplateFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
  		public String deleteTemplateFirewallRules(HttpServletRequest request, ModelMap model, @ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess) {
			//read the tiRequestID
			String templateID = (String) request.getParameter("templateID");
			Long tempID = 0L;
			if(templateID != null && !templateID.isEmpty()){
				tempID = Long.parseLong(templateID);
			}

			TIRequest tiRequest = getTirequest(request);
			
			log.info("FirewallRulesController::deleteTemplateFirewallRules ....templateID=>"+tempID+", TIRequestID=>"+tiRequest.getId());
			
			firewallRuleProcess.setTemplateID(tempID);
			firewallRuleProcess.setTiRequest(tiRequest.getId());
			firewallRuleProcess.deleteTemplateFirewallRules();
			
			return "forward:/loadFirewallRules.act";
	    }
	    
	    /*
	     * Delete the Firewall Rule from List/View Firewall Rules Screen.
	     * On Clicking Delete Link.
	     */
	    /**
	     * 
	     * @return
	     */
	    @RequestMapping(value = "/deleteFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
  		public String deleteFirewallRules(HttpServletRequest request, ModelMap model) {
	    	log.info("FirewallRulesController::deleteFirewallRules method starts...");
			
			FireWallRuleProcess fwRuleProcess = new FireWallRuleProcess();
		
			TIRequest tiRequestEntity = null;
			tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
		
			String ruleId = request.getParameter("ruleId");
			fwRuleProcess.setRuleId(Long.valueOf(ruleId));
			fwRuleProcess.setTiRequest(tiRequestEntity.getId());
			
			TIRequest tiRequest = new TIRequest();
			tiRequest.setId(tiRequestEntity.getId());
		
			try {
				fwRuleProcess.deleteFirewallRule();
			} catch(Exception e) {
				log.error(e, e);
				log.error("Exception occured... - "+e.getMessage());
			}
			
			String lockedBy = null;
	  		ActivityData activityData = null;
	  		if(request.getSession().getAttribute("workflowActivityData")!= null){
	  			activityData = (ActivityData)request.getSession().getAttribute("workflowActivityData");
	  			if (activityData != null) {
	  				lockedBy = activityData.getLockedBy();
	  			}
	  		}
			
			try {
				fwRuleProcess.executeRiskRules(Long.valueOf(ruleId), tiRequest, getTIRequestDTO(request), true, lockedBy);
			} catch(Exception e) {
				log.error(e, e);
				log.error("Exception occured while executing Rule... - "+e.getMessage());
			}
			
			log.info("FirewallRulesController::deleteFirewallRules method ends...");
			return "forward:/loadFirewallRules.act";
	    }
	    
	    @RequestMapping(value = "/reEvaluateRules.act", method = { RequestMethod.GET, RequestMethod.POST})
	  	public String reEvaluateRules(HttpServletRequest request, ModelMap model) {
	    	TIRequest tiRequestEntity = null;
	  		tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
	  		String lockedBy = null;
	  		ActivityData activityData = null;
	  		if(request.getSession().getAttribute("workflowActivityData")!= null){
	  			activityData = (ActivityData)request.getSession().getAttribute("workflowActivityData");
	  			if (activityData != null) {
	  				lockedBy = activityData.getLockedBy();
	  			}
	  		}
	  		
	    	RiskExecutionThread.getInstance().startThread(tiRequestEntity.getId(),getTIRequestDTO(request), lockedBy);    	
	    	return "c3par.firewall.riskInProgress";
	    }
	    
	    @RequestMapping(value = "/rulesExistWithOlderBaseline.act", method = { RequestMethod.GET, RequestMethod.POST})
	  	public @ResponseBody String rulesExistWithOlderBaseline(HttpServletRequest request, ModelMap model) {
	    	TIRequest tiRequestEntity = null;
	  		tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
	  		FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
	    	String exists = "false";
	    	
	    	if (firewallRuleProcess.isRiskExecutionInProgress(tiRequestEntity.getId())) {
	    		exists = "progress";
	    	} else {
		    	List<Long> ruleIds =  firewallRuleProcess.rulesExistsWithOlderBaseline(tiRequestEntity.getId(),"Y");
		    	
		       	if (ruleIds != null && !ruleIds.isEmpty()) {
		       		
		    		exists = "true";
		    	}
		       	
		       	List<Long> fwruleIds = firewallRuleProcess.rulesExistsWithOlderBaseline(tiRequestEntity.getId(),"N");
		      
				 if (fwruleIds != null && !fwruleIds.isEmpty()) {
					 	
					    exists = "true";
				}
	    	}
	    	    	
	    	return exists;
	    }
	    
	    
	    /*
	     * To upload the Firewall Rules
	     * 
	     */
	    /**
	     * 
	     * @return
	     */
	    @RequestMapping(value = "/bulkUploadFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
	  	public String bulkUploadFirewallRules(HttpServletRequest request, ModelMap model) {
			log.info("FirewallRuleController::bulkUploadFirewallRules methods starts...");
			
			FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();

			String tiRequestID = (String) request.getSession().getAttribute("tireqid");
			Long tiReqID = 0L;

			String con_type= "";
			String docType = "";
			List<TIUploadedDocs> fileList = null;
			if(request.getSession().getAttribute("con_type") != null){
				con_type = (String) request.getSession().getAttribute("con_type");
			}
			
			if(tiRequestID != null && !tiRequestID.isEmpty()){
				tiReqID = Long.parseLong(tiRequestID);
			}
			//get the Uploaded fileName List
			if("ipReg".equalsIgnoreCase(con_type))
			{
			fileList = firewallRuleProcess.getFireWallRuleBulkUploadFileList(tiReqID,IP_REG_DOCTYPE);
			}
			else{
				fileList = firewallRuleProcess.getFireWallRuleBulkUploadFileList(tiReqID,FIREWALL_RULE_DOCTYPE);	
			}
			firewallRuleProcess.setBulkUploadFiles(fileList);
			
			model.addAttribute("firewallRuleProcess", firewallRuleProcess);
			
			log.info("FirewallRuleController::bulkUploadFirewallRules methods ends...");
			return "c3par.firewall.bulkuploadfwrule";
	    }
	    
	    /*
	     * To submit the Bulk Upload
	     * 
	     */
	    @RequestMapping(value = "/submitBulkUpload.act", method = { RequestMethod.GET, RequestMethod.POST})
	  	public String submitBulkUpload(HttpServletRequest request, ModelMap model, 
	  			@ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess, BindingResult bresult,
	  			@RequestParam("uploadedFile") CommonsMultipartFile uploadedFile) {
			log.info("FirewallRuleController::submitBulkUpload methods starts...");	
			String forwardPage = "c3par.firewall.bulkuploadfwrule";
			try{
				ExcelReader excelReader = new ExcelReader();
				POIFSFileSystem fileSystem = null;
				String docType = "";
				if(uploadedFile == null){	
					log.info("FirewallRuleController::File not found error");		
					bresult.addError(new ObjectError("firewallRuleProcess.fireWallRule", "File not Found"));
					return forwardPage;
				}
			    fileSystem = new POIFSFileSystem(uploadedFile.getInputStream());
			    //read the xls file and save the data as arraylist
			    HSSFWorkbook workBook = new HSSFWorkbook(fileSystem);
			    ArrayList resultList = (ArrayList) excelReader.parseSheet(workBook, workBook.getSheetName(0),2,17);

				TIRequest tiRequestEntity = null;
				tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
				
				String con_type= "";
				String isIpReg = "";
				if(request.getSession().getAttribute("con_type") != null){
					con_type = (String) request.getSession().getAttribute("con_type");
				}
				if("ipReg".equalsIgnoreCase(con_type))
				{
					isIpReg = "Y";
					firewallRuleProcess.setIsIpReg("Y");
					docType = IP_REG_DOCTYPE;
				}
				else{
					isIpReg = "N";
					docType = FIREWALL_RULE_DOCTYPE;
				}
			    if(resultList != null && resultList.size() > 0){//read the tiRequestID
					String tiRequestID = (String) request.getSession().getAttribute("tireqid");
					Long tiReqID = 0L;
					if(tiRequestID != null && !tiRequestID.isEmpty()){
						tiReqID = Long.parseLong(tiRequestID);
					}
					String relationshiptype = firewallRuleProcess.getRelationshipType();
					if(relationshiptype == null || relationshiptype.trim().length() <= 0){
						//set relationship for the TIRequestID
						setRelationshipType(tiReqID, firewallRuleProcess);
						relationshiptype = firewallRuleProcess.getRelationshipType();
					}
			    	//parse the file data into FireWallRule Object
			    	List<FireWallRule> result = parseIntoFireWallRule(resultList, firewallRuleProcess, request);
			    	//Validate the firewall rules
			    	List<FireWallRule> resultWithErr = validationsForFirewalRule(tiRequestEntity.getTiProcess().getId(),
			    			relationshiptype,result,isIpReg,tiReqID,firewallRuleProcess,request);
					
					//read the uploaded fileName to save the same in DB
					String fileName = firewallRuleProcess.getBulkUploadFileName();
					log.info("FirewallRuleController::submitBulkUpload::FileName="+fileName);	
					//create the workbook, write the data and error into the workbook.
			    	HSSFWorkbook newWorkBook = excelReader.writeIntoExcel(resultList, resultWithErr);
					//create the file in temp directory.
					File file = File.createTempFile(tiRequestID, ".xls");			
					log.debug("FirewallRuleController::submitBulkUpload::file Path - "+file.getAbsolutePath());
					FileOutputStream out = new FileOutputStream(file);	
					newWorkBook.write(out);
					out.close();
					//read the file as byte array for writing it into database
					long lenth = file.length();
					byte fileContent[] = new byte[(int)lenth];
					FileInputStream input = new FileInputStream(file);
					input.read(fileContent);
					input.close();				
					//Insert the file into Database	
					firewallRuleProcess.saveFireWallRuleBulkUpload(tiReqID, docType, FIREWALL_RULE_CONTENT_TYPE, fileName, fileContent);				
					//get the Lastest Uploaded fileName List
					List<TIUploadedDocs> fileList = firewallRuleProcess.getFireWallRuleBulkUploadFileList(tiReqID,docType);
					firewallRuleProcess.setBulkUploadFiles(fileList);
					model.addAttribute("firewallRuleProcess", firewallRuleProcess);
			    }		    
				log.info("FirewallRuleController::submitBulkUpload methods ends...");			
			}catch(IOException io){
				log.error("FirewallRuleController::submitBulkUpload..."+io.getMessage());
				io.printStackTrace();
			}catch(Exception e){
				log.error("FirewallRuleController::submitBulkUpload..."+e.getMessage());
				e.printStackTrace();
			}
			return forwardPage;
	    }

	    /*
	     * Download Firewall rule file
	     * 
	     */
	    @RequestMapping(value = "/downloadBulkUploadFile.act", method = { RequestMethod.GET, RequestMethod.POST})
	  	public String downloadBulkUploadFile(HttpServletRequest request,HttpServletResponse response, ModelMap model) {
			log.info("FirewallRuleController::downloadBulkUploadFile methods starts...");
			String fileName = request.getParameter("fileId");
			
			Long fileId = Long.valueOf(fileName);			
			log.info("FirewallRuleController::download fileId ->"+fileId);
			FireWallRuleProcess firewallRuleProcess = new FireWallRuleProcess();
			TIUploadedDocs file = firewallRuleProcess.getFireWallRuleDownloadFile(fileId);		
			firewallRuleProcess.setFirewallRuleFile(file);		
			try{
				Blob fileContent = file.getContent();
				int length = (int) fileContent.length();
				
			    java.io.OutputStream os = response.getOutputStream();
			    response.setContentType(FIREWALL_RULE_CONTENT_TYPE);
			    response.setHeader("Content-Disposition", "attachment; filename="+file.getDocName());
			    os.write(fileContent.getBytes(1, length));
			}catch(Exception e){
				log.info("FirewallRuleController::downloadBulkUploadFile::File not found error");	
				log.error(e);
				java.io.PrintWriter out = null;
				try{ 
					out = response.getWriter();
					response.setContentType("text/html");
					out.println("<HTML><BODY>There was an error retrieving the requested file!</BODY></HTML>");
				}catch(IOException io){log.error(io);}
			}
			log.info("FirewallRuleController::downloadBulkUploadFile methods Ends...");	
			
			return null;
	    }
	    
	    
	    private List<FireWallRule> parseIntoFireWallRule(List uploadedFile, FireWallRuleProcess firewallRuleProcess, HttpServletRequest request){
	    	boolean isNewFWRule = false,isFirstRow = false;
	    	List<FireWallRule> xlsObject = new ArrayList<FireWallRule>();
	    	FireWallRule fwRule = null;
	    	// Set TIRequestID to FireWallRule
			TIRequest tiRequestEntity = null;
			tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");					
			TIRequest tiRequest = new TIRequest();
			tiRequest.setId(tiRequestEntity.getId());
	    	for (int i = 0; i < uploadedFile.size(); i++) {
				ArrayList rowList = (ArrayList) uploadedFile.get(i);
				short cellIndx = 5;
				if (rowList != null) {
					String celValue = (String)rowList.get(0);
					if (celValue != null && (!celValue.isEmpty()) && celValue.length() > 0) {
						isNewFWRule = true;
						isFirstRow = true;
						cellIndx = 0;
						log.debug("FirewallRuleController::parseIntoFireWallRule::Reading Firewall Rule"+ celValue);
					}
					for (; cellIndx < 16; cellIndx++) {
						if (isNewFWRule == true) {
							if (fwRule != null){ // && FWRule.size() > 0)
								xlsObject.add(fwRule);
							}
							fwRule = new FireWallRule();
							
							fwRule.setTiRequest(tiRequest);
							fwRule.setUpdatedTIRequest(tiRequest);
							fwRule.setSourceIPs(new ArrayList<FireWallRuleSourceIP>());
							fwRule.setDestinationIPs(new ArrayList<FireWallRuleDestinationIP>());
							fwRule.setPorts(new ArrayList<FireWallRulePort>());
							fwRule.setPolicies(new ArrayList<FirewallRulePolicy>());
							fwRule.setFAFGenerated("N");
							isNewFWRule = false;
						}
						if (isFirstRow) {
							String cellValue = (String)rowList.get(cellIndx);
							log.debug("FirewallRuleController::parseIntoFireWallRule::" + cellValue);
							if (cellValue != null) {
								if (cellIndx == 0) {// read RuleNumber
									fwRule.setRuleNumber(new Integer(new Double(cellValue).intValue()));
								} else if (cellIndx == 1 && !cellValue.isEmpty()) {// FirewallPolicy
									//fwRule.setPolicy(firewallRuleProcess.getFirewallPolicyByName(cellValue));
									FirewallPolicy firewallPolicy = firewallRuleProcess.getFirewallPolicyByName(cellValue);
									FirewallRulePolicy firewallRulePolicy = new FirewallRulePolicy();
									firewallRulePolicy.setUpdatedTIRequest(tiRequest);
									firewallRulePolicy.setIsNew("Y");
									firewallRulePolicy.setFirewallPolicy(firewallPolicy);
									fwRule.getPolicies().add(firewallRulePolicy);
									if (firewallPolicy != null && firewallPolicy.getFireWallPolicyGroup() != null) {
										fwRule.setPolicyGroup(firewallPolicy.getFireWallPolicyGroup());
									}
								}else if(cellIndx == 2 && !cellValue.isEmpty()){ // Rule Type
									fwRule.setRuleType(cellValue.equalsIgnoreCase("Allow")?"A":"D");
								}else if (cellIndx == 3 && !cellValue.isEmpty()) {// Source NetworkZone
									ResourceType resourceType = new ResourceType();
									resourceType.setName(cellValue);
									fwRule.setSourceNetworkZone(firewallRuleProcess.getNetworkZone(cellValue));
								} else if (cellIndx == 4 && !cellValue.isEmpty()) {// Destination NetworkZone
									ResourceType resourceType = new ResourceType();
									resourceType.setName(cellValue);
									fwRule.setDestinationNetworkZone(firewallRuleProcess.getNetworkZone(cellValue));
									isFirstRow = false;
								} /*else if (cellIndx == 5) {// BiDirection
									fwRule.setBidirectional(getBiDirectional(cellValue));
									isFirstRow = false;
								}*/
							} 
						} else {
							String cellValue = (String)rowList.get(cellIndx);
							log.debug("FirewallRuleController::parseIntoFireWallRule::" + cellValue);
							if (cellValue != null){
								if (cellIndx == 5) {// SourceIP
									if(!cellValue.isEmpty() && cellValue.length() > 0){
										FireWallRuleSourceIP fwRuleSourceIP = new FireWallRuleSourceIP();
										fwRuleSourceIP.setUpdatedTIRequest(tiRequest);
										IPAddress ipAddress = new IPAddress();
										ipAddress.setIpAddress(cellValue);								
										fwRuleSourceIP.setIpAddress(ipAddress);
										fwRuleSourceIP.setIsNew("Y");
										// Source NAT IP
										cellIndx++; // cellIndx == 6
										String NATIP = (String)rowList.get(cellIndx);
										if (NATIP != null) {
											fwRuleSourceIP.setNAT(NATIP);
										}
										
										fwRule.getSourceIPs().add(fwRuleSourceIP);
									}
								}else if (cellIndx == 7) {// DestinationIP
									if(!cellValue.isEmpty() && cellValue.length() > 0){
										FireWallRuleDestinationIP fwRuleDestinationIP = new FireWallRuleDestinationIP();
										fwRuleDestinationIP.setUpdatedTIRequest(tiRequest);
										IPAddress ipAddress = new IPAddress();
										ipAddress.setIpAddress(cellValue);								
										fwRuleDestinationIP.setIpAddress(ipAddress);
										fwRuleDestinationIP.setIsNew("Y");
										// Destination NAT IP
										cellIndx++; // cellIndx == 8
										String NATIP = (String)rowList.get(cellIndx);
										if (NATIP != null)
											fwRuleDestinationIP.setNAT(NATIP);
										
										fwRule.getDestinationIPs().add(fwRuleDestinationIP);
									}
								}else if (cellIndx == 9) {// Protocol
									// Port No.
									cellIndx++; // cellIndx == 10
									String portNo = (String)rowList.get(cellIndx);
									if((!cellValue.isEmpty() && cellValue.length() > 0)
											|| (portNo != null && !portNo.isEmpty() && portNo.length() > 0)){						
										FireWallRulePort fwRulePort = new FireWallRulePort();
										fwRulePort.setUpdatedTIRequest(tiRequest);
										fwRulePort.setPort(new Port());
										fwRulePort.getPort().setFlowOfData(FLOW_OF_DATA_ATOB);
										fwRulePort.getPort().setProtocol(cellValue.toUpperCase());
										fwRulePort.getPort().setIsNew("Y");
										fwRulePort.setIsNew("Y");
										
										if ("TCP".equalsIgnoreCase(fwRulePort.getPort().getProtocol())
												|| "UDP".equalsIgnoreCase(fwRulePort.getPort().getProtocol())) {
											
											if (portNo != null){
												try {
													portNo = String.valueOf(new Double(portNo).intValue());
												} catch (NumberFormatException n) {
													
												}
												fwRulePort.getPort().setPortNumber(portNo);
											}
										} else {
											fwRulePort.getPort().setPortNumber(fwRulePort.getPort().getProtocol());
										}
										if ("TCP".equalsIgnoreCase(fwRulePort.getPort().getProtocol())
												|| "UDP".equalsIgnoreCase(fwRulePort.getPort().getProtocol())){
											// Service Name
											cellIndx++; // cellIndx == 11
											String serviceName = (String)rowList.get(cellIndx);
											if (serviceName != null && !serviceName.isEmpty()){
												fwRulePort.setServiceName(serviceName);
											}
											// Default/Other
											cellIndx++; // cellIndx == 12
											String defaultOrOther = (String)rowList.get(cellIndx);
											if (defaultOrOther != null && !defaultOrOther.isEmpty()){
												if(defaultOrOther.equalsIgnoreCase("default"))
													fwRulePort.setDefaultService("Y");
												else if(defaultOrOther.equalsIgnoreCase("other"))
													fwRulePort.setDefaultService("N");
												else 
													fwRulePort.setDefaultService(defaultOrOther);
											}
											//if service not there, retrieve the same from database
											String newServiceName = "";
											if(serviceName == null || serviceName.isEmpty() 
													|| defaultOrOther == null || defaultOrOther.isEmpty()){
												String portNumber = fwRulePort.getPort().getPortNumber();			    				    
						    				    try {
						    				    	newServiceName = firewallRuleProcess.getServiceName(Long.valueOf(portNumber));
						    				    } catch (BusinessException be) {
						    					    log.error(be, be);
						    					    newServiceName = "";
						    					}catch (Exception be) {
						    					    log.error(be, be);
						    					    newServiceName = "";
						    					}
						    				    if(serviceName == null || serviceName.isEmpty()){
							    				    fwRulePort.setServiceName(newServiceName);
							    				    rowList.set(11,newServiceName);
							    				    if(newServiceName != null && !newServiceName.isEmpty() && newServiceName.length() > 0){
								    				    fwRulePort.setDefaultService("Y");
						    				    		rowList.set(12,"Default");
							    				    }
						    				    }else if(defaultOrOther == null || defaultOrOther.isEmpty()){
						    				    	if(serviceName != null && newServiceName != null && serviceName.equalsIgnoreCase(newServiceName)){
						    				    		fwRulePort.setDefaultService("Y");
						    				    		rowList.set(12,"Default");
						    				    	}else{
						    				    		fwRulePort.setDefaultService("N");
						    				    		rowList.set(12,"Other");
						    				    	}
						    				    }
											} 
											// Traffic Type
											cellIndx++; // cellIndx == 13
											String trafficType = (String)rowList.get(cellIndx);
											if (trafficType != null)
												fwRulePort.setTypeOfTraffic(trafficType);
											// Justification
											cellIndx++; // cellIndx == 14
											String justification = (String)rowList.get(cellIndx);
											if (justification != null)
												fwRulePort.setDescription(justification);
											
										}  
										if ("ICMP".equalsIgnoreCase(fwRulePort.getPort().getProtocol())){
											// Control Message
											cellIndx = 15; // cellIndx == 15
											String controlMessage = (String)rowList.get(cellIndx);
											if (controlMessage != null){
												GenericLookup genericlookup = firewallRuleProcess.getControlMessage(controlMessage);
												if(genericlookup != null){
													fwRulePort.getPort().setControlMsgId(genericlookup.getId());
												}
											}
										}
										fwRule.getPorts().add(fwRulePort);
									}
								}
							}	
						}
					}
					log.debug("FirewallRuleController::parseIntoFireWallRule::Row Completed");
				}
			}
			if (fwRule != null)
				xlsObject.add(fwRule);
			
	    	return xlsObject;
	    }
	    
	    private List<FireWallRule> validationsForFirewalRule(Long processID, String relationshiptype, List<FireWallRule> fwRuleList, 
	    		String isIpReg, Long tiReqID, FireWallRuleProcess firewallRuleProcess, HttpServletRequest request){
	    	log.debug("FirewallRuleController::validationsForFirewalRule::Validations Starting..");
	    	//Get list of Protocol from DataBase
	    	HashMap<String, String> protocolMap = new HashMap<String, String>();
	    	List<GenericLookup> ProtocolList = firewallRuleProcess.getProtocols();
	    	for (GenericLookup protocallist : ProtocolList) {
	    		if(!protocallist.getValue1().equalsIgnoreCase("OBJECT")){
		    		protocolMap.put(protocallist.getValue1(), protocallist.getValue2());
		    		log.debug("protocolMap"+protocolMap.toString());
	    		}
	    	}
	    	
	    	List<ResourceType> resourceTypes = firewallRuleProcess.getResourceTypeList(processID);
	    	HashMap<String, String> networkZoneMap = new HashMap<String, String>();
	    	for (ResourceType resourceType : resourceTypes) {
	    		networkZoneMap.put(resourceType.getName(), resourceType.getName());
	    		log.debug("networkZoneMap => "+resourceType.getName());
	    	}
	    	List<ResourceType> resourceTypes1 = firewallRuleProcess.getResourceTypeListIP(processID);
	    	HashMap<String, String> networkZoneMap1 = new HashMap<String, String>();
	    	for (ResourceType resourceType1 : resourceTypes1) {
	    		networkZoneMap1.put(resourceType1.getName(), resourceType1.getName());
	    		log.debug("networkZoneMap1 => "+resourceType1.getName());
	    	}

	    	TiRequestDTO tIRequestDTO = getTIRequestDTO(request);
	    	
	    	String lockedBy = null;
	  		ActivityData activityData = null;
	  		if(request.getSession().getAttribute("workflowActivityData")!= null){
	  			activityData = (ActivityData)request.getSession().getAttribute("workflowActivityData");
	  			if (activityData != null) {
	  				lockedBy = activityData.getLockedBy();
	  			}
	  		}
	  		
	  		
	  		String firewallPolicyIPReg = "Global-VPN-RPod-Policy";
	  		
	  		FirewallPolicy fwPolicyForIPREG = firewallRuleProcess.getFirewallPolicyForIPReg();
	  		
	  		if (fwPolicyForIPREG != null && fwPolicyForIPREG.getName() != null && !fwPolicyForIPREG.getName().isEmpty()) {
	  			firewallPolicyIPReg = fwPolicyForIPREG.getName();
	  		}
	  		
	    	
			//Validate the Firewall rules
	    	for(FireWallRule fireWallRule:fwRuleList){
	    		String fwSrcIP = "";
	    		String fwExistingSrcIP = "";
	    		if("Y".equalsIgnoreCase(isIpReg)){
	      			if(fwSrcIP == null || fwSrcIP.isEmpty()){
	      				log.debug("fwip" +fireWallRule);
	      				if("N".equals(firewallRuleProcess.getIpRegSourceIP(fireWallRule.getSourceIPs().get(0).getIpAddress(),relationshiptype))){
	      					
	      				}else{
	      					fwSrcIP = fireWallRule.getSourceIPs().get(0).getIpAddress().getIpAddress().trim();
	      					log.debug("fwiiiip" +fwSrcIP);
	      				}
	      			List<FireWallRuleSourceIP> ipRegSourceIPs = firewallRuleProcess.getIPRegSoureIp(processID,tiReqID);
	       			if(ipRegSourceIPs != null && ipRegSourceIPs.size() > 0){
	       				fwExistingSrcIP = ipRegSourceIPs.get(0).getIpAddress().getIpAddress().trim();
	       				log.debug("existing src ip" +fwExistingSrcIP);
	    			   
	    			}
	      			}
	      		}
	    		fireWallRule.setValidationErrors(new ArrayList<String>());
	    		if(fireWallRule.getPolicies() == null || fireWallRule.getPolicies().size() <= 0
	    				|| fireWallRule.getPolicies().get(0) == null
	    				|| fireWallRule.getPolicies().get(0).getFirewallPolicy() == null) {
	    			fireWallRule.getValidationErrors().add("Please enter the Valid Firewall Policy");
	    		} else if(mandatoryCheck(fireWallRule.getPolicies().get(0).getFirewallPolicy().getName())){
	    			fireWallRule.getValidationErrors().add("Please enter the Firewall Policy");
	    		} else if("Y".equalsIgnoreCase(isIpReg)){
	    			log.debug("policies" +fireWallRule.getPolicies());
	    			log.debug("policy" +fireWallRule.getPolicies().get(0).getFirewallPolicy()+ "asdfd" +firewallRuleProcess.getFirewallPolicyForIPReg());
	    			log.debug("zone" +fireWallRule.getSourceNetworkZone());
	    			
	    			if(!fireWallRule.getPolicies().get(0).getFirewallPolicy().getName().equalsIgnoreCase(firewallPolicyIPReg)){
	    			fireWallRule.getValidationErrors().add("IPRegistration can have only "+firewallPolicyIPReg+" as the policy");
	    			}
	    		}
	    		
	    		if(fireWallRule.getPolicyGroup() == null){
	    			fireWallRule.getValidationErrors().add("Please enter the Firewall Policy which is mapped to the Valid Firewall Group");
	    		}else if(mandatoryCheck(fireWallRule.getPolicyGroup().getName())){
	    			fireWallRule.getValidationErrors().add("Please enter the Firewall Policy which is mapped to the Valid Firewall Group");
	    		}

	    		if(fireWallRule.getSourceNetworkZone() == null){
	    			fireWallRule.getValidationErrors().add("Please enter the Valid Source Network Zone");
	    		}else if(mandatoryCheck(fireWallRule.getSourceNetworkZone().getName())){
	    			fireWallRule.getValidationErrors().add("Please enter the Source Network Zone");
	    		}else if("Y".equalsIgnoreCase(isIpReg)){
	    			if(!networkZoneMap1.containsKey(fireWallRule.getSourceNetworkZone().getName())){
	        			fireWallRule.getValidationErrors().add("IPRegistration can have only 'IP Reg ACL' as the source network zone");
	        		}
	        	}else if("N".equalsIgnoreCase(isIpReg)){
	        			if(!networkZoneMap.containsKey(fireWallRule.getSourceNetworkZone().getName())){	    					
					fireWallRule.getValidationErrors().add("Please enter the Valid Source Network Zone");
				}
	        	}

	    		if(fireWallRule.getDestinationNetworkZone() == null){
	    			fireWallRule.getValidationErrors().add("Please enter the Valid Destination Network Zone");
	    		}else if(mandatoryCheck(fireWallRule.getDestinationNetworkZone().getName())){
	    			fireWallRule.getValidationErrors().add("Please enter the Destination Network Zone");
	    		}else if("Y".equalsIgnoreCase(isIpReg)){
	    			if(!networkZoneMap.containsKey(fireWallRule.getDestinationNetworkZone().getName())){
	        			fireWallRule.getValidationErrors().add("Please enter a valid Destination Network Zone for IPRegistration");
	        		}
	        	}else if("N".equalsIgnoreCase(isIpReg)){
	        			if(!networkZoneMap.containsKey(fireWallRule.getDestinationNetworkZone().getName())){	    					
					fireWallRule.getValidationErrors().add("Please enter the Valid Destination Network Zone");
				}
	        	}
	    		
	    		if(fireWallRule.getSourceNetworkZone() != null 
	    				&& fireWallRule.getSourceNetworkZone().getId() != null 
	    				&& fireWallRule.getDestinationNetworkZone() != null 
	    				&& fireWallRule.getDestinationNetworkZone().getId() != null 
	    				&& fireWallRule.getSourceNetworkZone().getId().equals(fireWallRule.getDestinationNetworkZone().getId())
	    				&& !("CITI_CON".equalsIgnoreCase(relationshiptype)
	    						&& ("DMZ".equalsIgnoreCase(fireWallRule.getSourceNetworkZone().getName())
	    						|| "Citiplex".equalsIgnoreCase(fireWallRule.getSourceNetworkZone().getName())))){
	    			if(!(fireWallRule.getSourceNetworkZone().getId().intValue() == firewallRuleProcess.getRequesterResourceType()
	    					&& fireWallRule.getDestinationNetworkZone().getId().intValue() == firewallRuleProcess.getTargetResourceType())) {
	    				fireWallRule.getValidationErrors().add("Source Network Zone and Destination Network Zone cannot be the same");
	    			}
	    		}

	    		List<FireWallRuleSourceIP> fwSourceIPs = fireWallRule.getSourceIPs();
	    		if(fwSourceIPs == null || fwSourceIPs.isEmpty() || fwSourceIPs.size() == 0){
	    			fireWallRule.getValidationErrors().add("There are no Souce IPs found");
	    		}else if("Y".equalsIgnoreCase(isIpReg)){
	    			fireWallRule.setIsIpReg("Y");
	    			
	    			FireWallRuleSourceIP fwSourceIP = fwSourceIPs.get(0);
	      			
	    			log.debug( "first src"+fwSrcIP+ "fwSource" +fwSourceIP.getIpAddress().getIpAddress().trim());
	    			if(!(fwExistingSrcIP == null || fwExistingSrcIP.isEmpty())){
	    				if(!fwSourceIP.getIpAddress().getIpAddress().trim().equalsIgnoreCase(fwExistingSrcIP)){
	    					fireWallRule.getValidationErrors().add("Source IP cannot be different from existing rule for IPRegistration.. ");
	    				}
	    				else if("N".equals(firewallRuleProcess.getIpRegSourceIP(fwSourceIP.getIpAddress(),relationshiptype))){
	    					fireWallRule.getValidationErrors().add("Please enter a valid source IP for IPRegistration.");
	    				} 
	    			}
	    			else{
	    				if(!(fwSrcIP == null || fwSrcIP.isEmpty())){
	    				if(fwSourceIP.getIpAddress().getIpAddress().trim().equalsIgnoreCase(fwSrcIP)){
	    					if("N".equals(firewallRuleProcess.getIpRegSourceIP(fwSourceIP.getIpAddress(),relationshiptype))){
	        					fireWallRule.getValidationErrors().add("Please enter a valid source IP for IPRegistration..");
	        				}
	    				}
	    				else{
	    					fireWallRule.getValidationErrors().add("Source IP cannot be different for each rule for IPRegistration...");
	    				}
	    			}else{
	    				fireWallRule.getValidationErrors().add("Please enter a valid source IP for IPRegistration...");
	    			}
	    			}
	        	}
	    		List<FireWallRuleDestinationIP> fwDestinationIPs = fireWallRule.getDestinationIPs();
	    		if(fwDestinationIPs == null || fwDestinationIPs.isEmpty() || fwDestinationIPs.size() == 0){
	    			fireWallRule.getValidationErrors().add("There are no Destination IPs found");
	    		}

	    		List<FireWallRulePort> ports = fireWallRule.getPorts();
	    		
	    		if(ports != null && !ports.isEmpty() && ports.size() > 0){
	    			
		    		for (FireWallRulePort fireWallRulePort : ports) {
		    			if(fireWallRulePort.getPort() == null){
		    				fireWallRule.getValidationErrors().add("Please enter the Valid Ports");
		    			}else if(mandatoryCheck(fireWallRulePort.getPort().getProtocol())){
		    				fireWallRule.getValidationErrors().add("Please enter the Protocol");
		    			}else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("TCP") 
		    				|| fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("UDP")){
		    				
		    				if(mandatoryCheck(fireWallRulePort.getPort().getPortNumber())){
			    				fireWallRule.getValidationErrors().add("Please enter the PortNumber");
		    				}
		    				if(mandatoryCheck(fireWallRulePort.getServiceName())){
			    				fireWallRule.getValidationErrors().add("Please enter the ServiceName");
		    				}
		    				
		    				if(mandatoryCheck(fireWallRulePort.getDefaultService())){
		    					fireWallRule.getValidationErrors().add("Please enter the ServiceMode (Default/Other)");
		    				}else if(!fireWallRulePort.getDefaultService().equalsIgnoreCase("y")
		    						&& !fireWallRulePort.getDefaultService().equalsIgnoreCase("n")){
		    					fireWallRule.getValidationErrors().add("Please enter the Valid ServiceMode (Default/Other)");	    					   
		    				}else if(fireWallRulePort.getDefaultService().equalsIgnoreCase("n")
		    					&& mandatoryCheck(fireWallRulePort.getDescription())){
			    					fireWallRule.getValidationErrors().add("Please enter the Justification");
		    				}
		    			}else if(fireWallRulePort.getPort().getProtocol().equalsIgnoreCase("ICMP")){
		    				if(fireWallRulePort.getPort() == null || fireWallRulePort.getPort().getControlMsgId() == null || fireWallRulePort.getPort().getControlMsgId() <= 0){
			    				fireWallRule.getValidationErrors().add("Please enter the Valid ControlMessage");
			    			}
		    			}else{	    				
		    				if(!protocolMap.containsKey(fireWallRulePort.getPort().getProtocol())){	    					
		    					fireWallRule.getValidationErrors().add("Please enter the valid Protocol");
		    				}
		    			}
		    		}
	    		} else {
	    			fireWallRule.getValidationErrors().add("There are no Ports found");
	    		}
	    		log.debug("FirewallRuleController::validationsForFirewalRule::Mandatory Validations completed");
	        	FireWallRuleProcess validateProcess = new FireWallRuleProcess();
	        	fireWallRule = fireWallRule.validateIPsandPorts();
	        	if(fireWallRule.getValidationErrors().size() == 0){
	        		fireWallRule = fireWallRule.identifyExistingRules();
	        	}
	        	//If no validation errors then save the Firewall Rule
	        	if(fireWallRule.getValidationErrors().size() == 0){
	        		fireWallRule.setStatus("ADD");
	        		fireWallRule.setIsNew("Y");
	        		fireWallRule = fireWallRule.identifyExistingIPsandPorts();
		    		firewallRuleProcess.setFireWallRule(fireWallRule);
		    		Long fireWallRuleId = firewallRuleProcess.getFireWallRule().save();
		    		firewallRuleProcess.resetFAFGeneratedStatus();
		    		fireWallRule.setId(fireWallRuleId);
		    		firewallRuleProcess.setRuleId(fireWallRuleId);
		    		FireWallRule savedFirewallRule = firewallRuleProcess.findFirewallRule();
		    		fireWallRule.getValidationErrors().add("Firewall Rule saved successfully with Rule Number - "+savedFirewallRule.getRuleNumber());
		    		//Check for HighRiskPort, If yes, add OstiaQuestions
		    		TIRequest tiRequestEntity = null;
		    		tiRequestEntity = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");	    	
		    		TIRequest tiRequest = new TIRequest();
		    		tiRequest.setId(tiRequestEntity.getId());
		    		try {
		    			firewallRuleProcess.executeRiskRules(fireWallRuleId, tiRequest, tIRequestDTO, false, lockedBy);
		    			firewallRuleProcess.updateFirewallRuleQuestionnaire(fireWallRuleId);
		    		} catch(Exception e) {
		    			log.error(e, e);
		    			log.error("Exception Occured... - "+e.getMessage());
		    		}
	        	}
	    	}
	    	log.debug("FirewallRuleController::validationsForFirewalRule::All Validations completed");
	    	return fwRuleList;
	    }
	    
	    private Boolean mandatoryCheck(String fieldValue){
	    	log.debug("FirewallRuleController::validationsForFirewalRule::Validations mandatoryCheck"+fieldValue);
	    	if(fieldValue == null || fieldValue.isEmpty()) {
	    		return true;
	    	}
	    	return false;
	    }
	    
	    
	    /*
	     * To Load IP Personal Object
	     */
	    /**
	     * 
	     * @return
	     */
	    @RequestMapping(value = "/loadPersonalObjectIP.act", method = { RequestMethod.GET, RequestMethod.POST})
	  	public @ResponseBody String loadPersonalObjectIP(HttpServletRequest request,HttpServletResponse response, ModelMap model) {
	    	log.info("FirewallRuleController::loadPersonalObjectIP methods starts...");
	    	
	    	Long objectId = Long.valueOf(request.getParameter("objectId"));
	    	
	    	SearchFirewallRuleRequest searchFirewallRuleRequest = new SearchFirewallRuleRequest();
	    	searchFirewallRuleRequest.setObjectId(objectId);
	    	PersonalObject personalObject = searchFirewallRuleRequest.findPersonalObject();
	    	searchFirewallRuleRequest.setPersonalObject(personalObject);
	    	
	    	List<PersonalObjectIP> personalObjectIPs = personalObject.getPersonalObjectIPs();
	    	String ip = "";
		    String natip = "";
	    	int i=0;
	    	StringBuffer personalObjects = new StringBuffer();
	    	personalObjects.append("[");
	 	    for (PersonalObjectIP personalObjectIP : personalObjectIPs) {
	 	    	ip = "";
	 	    	natip = "";
	 	    	
	 	    	if (personalObjectIP.getIpAddress().getIpAddress() != null) {
	 	    		ip = personalObjectIP.getIpAddress().getIpAddress();
	 	    	}
	 	    	
	 	    	if (personalObjectIP.getNAT() != null) {
	 	    		natip = personalObjectIP.getNAT();
	 	    	}
	 	    	
	 	    	if(i > 0) {
	 	    		personalObjects.append(",");
	 	    	}
	 	    	personalObjects.append("{\"ip\":\""+ip+"\",\"nat\":\""+natip+"\"}");
	 	    	i++;
	 	    }
	 	   personalObjects.append("]");
	    	
	 	   log.info("FirewallRuleController::loadPersonalObjectIP methods ends...");
		   return  personalObjects.toString();
	    }
	    
	    /*
	     * To Load IP Personal Object
	     */
	    /**
	     * 
	     * @return
	     */
	    @RequestMapping(value = "/loadPersonalObjectPort.act", method = { RequestMethod.GET, RequestMethod.POST})
	  	public @ResponseBody String loadPersonalObjectPort(HttpServletRequest request,HttpServletResponse response, ModelMap model) {
	    	log.info("FirewallRuleController::loadPersonalObjectPort methods starts...");
	    	
	    	Long objectId = Long.valueOf(request.getParameter("objectId"));
	    	
	    	SearchFirewallRuleRequest searchFirewallRuleRequest = new SearchFirewallRuleRequest();
	    	searchFirewallRuleRequest.setObjectId(objectId);
	    	PersonalObject personalObject = searchFirewallRuleRequest.findPersonalObject();
	    	searchFirewallRuleRequest.setPersonalObject(personalObject);
	    	
	    	List<PersonalObjectPort> personalObjectPorts = personalObject.getPersonalObjectPorts();
	    	
	    	String protocol = "";
	    	String port = "";
	    	String service = "";
	    	String def = "";
	    	String traffic = "";
	    	String just = "";
	    	String cntlMsg = "";
	    	
	    	int i=0;
	    	StringBuffer personalObjects = new StringBuffer();
	    	personalObjects.append("[");
	 	    for (PersonalObjectPort personalObjectPort : personalObjectPorts) {
	 	    	protocol = "";
	 	    	port = "";
	 	    	service = "";
	 	    	def = "";
	 	    	traffic = "";
	 	    	just = "";
	 	    	cntlMsg = "";
	 	    	
	 	    	if (personalObjectPort.getPort().getProtocol() != null) {
	 	    		protocol = personalObjectPort.getPort().getProtocol();
	 	    	}
	 	    	
	 	    	if (personalObjectPort.getPort().getPortNumber() != null) {
	 	    		port = personalObjectPort.getPort().getPortNumber();
	 	    	}
	 	    	
	 	    	if (personalObjectPort.getServiceName()!= null) {
	 	    		service = personalObjectPort.getServiceName();
	 	    	}
	 	    	
	 	    	if (personalObjectPort.getDefaultService() != null ) {
	 	    		def = personalObjectPort.getDefaultService();
	 	    	}
	 	    	
	 	    	if (personalObjectPort.getTypeOfTraffic() != null) {
	 	    		traffic = personalObjectPort.getTypeOfTraffic();
	 	    	}
	 	    	
	 	    	if (personalObjectPort.getDescription() != null) {
	 	    		just = personalObjectPort.getDescription();
	 	    	}
	 	    	
	 	    	if (personalObjectPort.getPort().getControlMsgId() != null) {
	 	    		cntlMsg = personalObjectPort.getPort().getControlMsgId().toString();
	 	    	}
	 	    	
	 	    	if(i > 0) {
	 	    		personalObjects.append(",");
	 	    	}
	 	    	personalObjects.append("{\"protocol\":\""+protocol+"\"" +
	 	    			",\"portNumber\":\""+port+"\"" +
	 	    			",\"serviceName\":\""+service+"\"" +
	 	    			",\"defService\":\""+def+"\"" +
	 	    			",\"trafficType\":\""+traffic+"\"" +
	 	    			",\"justification\":\""+just+"\"" +
	 	    			",\"controlMsg\":\""+cntlMsg+"\"" +
	 	    					"}");
	 	    	i++;
	 	    }
	 	   personalObjects.append("]");
	    	
	 	   log.info("FirewallRuleController::loadPersonalObjectPort methods ends...");
		   return  personalObjects.toString();
	    }
	    
	    /*
	    * To Reload the Application Count
	     */
	    /**
	     * 
	     * @return
	     */
	    @RequestMapping(value = "/reloadApplications.act", method = { RequestMethod.GET, RequestMethod.POST})
	  	public String reloadApplications(HttpServletRequest request,HttpServletResponse response, ModelMap model,  @ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess) {
			log.info("FirewallRuleController::reloadApplications methods starts...");
			String fromPage = request.getParameter("fromPage");
			
			String result =  "c3par.firewall.addnewfw.ajax";
			if ("Clone".equalsIgnoreCase(fromPage)) {
				result = "c3par.firewall.clonefw.ajax";
			} else if ("Edit".equalsIgnoreCase(fromPage)) {
				result = "c3par.firewall.editfw.ajax";
			}
			TIRequest tiRequestEntity = null;
			tiRequestEntity = (TIRequest) request.getSession().getAttribute(
				"TI_REQUEST_ENTITY");
			firewallRuleProcess.setTiRequest(tiRequestEntity.getId());
			firewallRuleProcess.setRuleId(firewallRuleProcess.getFireWallRule().getId());
			//Load SESSION Attributes
			loadSessionAttributes(firewallRuleProcess, request);
			
			HashMap<Long, Integer> appCount = firewallRuleProcess.applicationCountForIPs();
			
			if (firewallRuleProcess.getFireWallRule().getSourceIPs() != null && !firewallRuleProcess.getFireWallRule()
					.getSourceIPs().isEmpty()) {
			    for (FireWallRuleSourceIP fireWallRuleSourceIP : firewallRuleProcess.getFireWallRule().getSourceIPs()) {
			    	if (fireWallRuleSourceIP != null && fireWallRuleSourceIP.getIpAddress() != null && appCount != null) {
			    		fireWallRuleSourceIP.setAppCount(appCount.get(fireWallRuleSourceIP.getIpAddress().getId()));
			    	}
			    }
			}
		
			if (firewallRuleProcess.getFireWallRule().getDestinationIPs() != null && !firewallRuleProcess.getFireWallRule()
					.getDestinationIPs().isEmpty()) {
			    for (FireWallRuleDestinationIP fireWallRuleDestinationIP : firewallRuleProcess.getFireWallRule().getDestinationIPs()) {
			    	if (fireWallRuleDestinationIP != null && fireWallRuleDestinationIP.getIpAddress() != null && appCount != null) {
			    		fireWallRuleDestinationIP.setAppCount(appCount.get(fireWallRuleDestinationIP.getIpAddress().getId()));
				    }
			    }
			}
			
			model.addAttribute("firewallRuleProcess", firewallRuleProcess);
			log
				.info("......FirewallRuleController::reloadApplications methods ends.");
			return result;
	    }
	    
	    /**
	     * @param request
	     * @param response
	     * @param firewallRuleProcess
	     * @param model
	     * @param bresult
	     * @return
	     */
	    @RequestMapping(value = "/exportAllFirewallRules.act", method = { RequestMethod.GET, RequestMethod.POST})
		public String exportAllFirewallRules(HttpServletRequest request,HttpServletResponse response, @ModelAttribute("firewallRuleProcess") FireWallRuleProcess firewallRuleProcess, 
				ModelMap model, BindingResult bresult) {
	    	Long tiRequestId = Long.valueOf(request.getSession().getAttribute("tireqid").toString());
	    	String conType = request.getSession().getAttribute("con_type").toString();
	    	System.out.println(request.getSession().getAttribute("TI_PROCESS_ID"));
	    	TIRequest tiRequest = (TIRequest) request.getSession().getAttribute("TI_REQUEST_ENTITY");
	    	Long connectionId = tiRequest.getTiProcess().getId();
	    	Integer versionNumber = tiRequest.getVersionNumber();
	    	log.debug("TiRequest Id = " + tiRequestId + " ConType: " + conType + " ConnectionId: " + connectionId);
	    	
	    	try {
				FirewallRulesExport result = firewallRulesExportService.exportFirewallRules(tiRequestId, connectionId, conType, versionNumber);
				String ruleData = firewallRulesExportService.transformObjectXMLtoXSLTemplate(result, conType.equals("Firewall")?"FRE":"IPFRE");
				ruleData = ruleData.replaceAll("\n", "\r\n");
				log.debug(ruleData);
				firewallRuleProcess.setDescription(ruleData);
				response.setContentType("text/plain; charset=utf-8");
				response.setHeader("Content-Disposition", "attachment; filename=" + connectionId + "-"+ "Rules.txt");
			} catch (Exception e) {
				e.printStackTrace();
			}
	    	return "pages/jsp/fw/rulesExport";
	    }
	    
	    /*method to initialize the size of Collection using WebDataBinder*/

        @InitBinder
        public void initBinder(WebDataBinder binder) {

            binder.setAutoGrowCollectionLimit(1500);

        }


}
