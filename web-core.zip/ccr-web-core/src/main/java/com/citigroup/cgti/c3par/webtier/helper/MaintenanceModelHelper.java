/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright � [2002-2003] Mentisys, Inc.  All rights reserved.
 * The contents of this material are confidential and proprietary to
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.webtier.helper;

import javax.servlet.http.HttpServletRequest;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.NetworkConnectionDAO;
import com.citigroup.cgti.c3par.dao.MaintenanceDAO;
import com.citigroup.cgti.c3par.model.NetworkConnectionEntity;
import com.citigroup.cgti.c3par.model.MaintenanceEntity;
import com.mentisys.dao.DatabaseException;
import org.apache.log4j.Logger;


/**
 * The Class MaintenanceModelHelper.
 *
 * @author mnrao
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class MaintenanceModelHelper 
{

    /** The log. */
    private static Logger log = Logger.getLogger(MaintenanceModelHelper.class);

    /**
     * Save maintenance entity.
     *
     * @param maintenanceEntity the maintenance entity
     * @param status the status
     * @param request the request
     * @return the string
     */
    public static String saveMaintenanceEntity(MaintenanceEntity maintenanceEntity, String status,
	    HttpServletRequest request)
    {
	String forwardTo = "success";
	C3parSession c3parSession = new C3parSession();
	try
	{
	    /*
			c3parSession.getConnection();
			c3parSession.startTransaction();
			insertOrUpdateNetwork(maintenanceEntity, c3parSession);
			MaintenanceDAO maintenanceDAO = new MaintenanceDAO(c3parSession);
			maintenanceEntity.setStatus(status);
			maintenanceDAO.update(maintenanceEntity);
			c3parSession.commit();
	     */
	}
	catch(Exception ex)
	{
	    log.error(ex);
	    forwardTo = "failure";
	    try
	    {
		c3parSession.rollback();
	    }
	    catch(Exception ex2){log.error(ex2);}
	}
	finally {
	    if(c3parSession != null)
		c3parSession.releaseConnection();

	    request.getSession().removeAttribute("connectionRequestForm");
	}

	return forwardTo;
    }

    /**
     * Insert or update network.
     *
     * @param maintenanceEntity the maintenance entity
     * @param c3parSession the c3par session
     * @throws DatabaseException the database exception
     */
    private static void insertOrUpdateNetwork(MaintenanceEntity maintenanceEntity, C3parSession c3parSession)
    throws DatabaseException
    {
	/*
		if(maintenanceEntity.getNetCon() != null)
		{
			NetworkConnectionEntity networkConnectionEntity = maintenanceEntity.getNetCon();
			NetworkConnectionDAO dao = new NetworkConnectionDAO(c3parSession);
			dao.update(networkConnectionEntity);
		}
	 */
    }
}
