package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;
import java.util.List;

import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;

public class ISORejectAction extends MailAction {

Logger log = Logger.getLogger(ISORejectAction.class);
	
private final static String ROLE_NAME= "BISO";

	@Override
	public void process(IncomingMessage message) {
		
		log.info("Inside ISORejectAction process method ");
		
		super.processReject(message,ROLE_NAME);
	}
	
}
