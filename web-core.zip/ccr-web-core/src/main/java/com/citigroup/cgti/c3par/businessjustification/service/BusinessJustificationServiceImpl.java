/**
 *
 */
package com.citigroup.cgti.c3par.businessjustification.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiContactXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiReqConXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqTPContactXref;
import com.citigroup.cgti.c3par.businessjustification.domain.soc.persist.BusinessJustificationServicePersistable;
import com.citigroup.cgti.c3par.common.domain.AuditLog;
import com.citigroup.cgti.c3par.common.domain.AuditObjectType;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.GenericLookupDef;
import com.citigroup.cgti.c3par.common.domain.HistoryContact;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.relationship.domain.CoLookupData;
import com.citigroup.cgti.c3par.util.C3parStaticNames;

/**
 * @author pc79439
 * 
 */ 
@SuppressWarnings("unchecked")
@Transactional
public class BusinessJustificationServiceImpl extends BasePersistanceImpl implements BusinessJustificationServicePersistable {

	private static Logger log = Logger.getLogger(BusinessJustificationServiceImpl.class);
	private static String RELID="RELID";
	private static String TPID="TPID";
	private JdbcTemplate jdbcTemplateGDW;
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplateGDW() {
		return jdbcTemplateGDW;
	}

	public void setJdbcTemplateGDW(JdbcTemplate jdbcTemplateGDW) {
		this.jdbcTemplateGDW = jdbcTemplateGDW;
	}
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	

	@Override
	@Transactional(readOnly = true)
	public List<GenericLookup> getGenericLookupDropDown(String defName) {
		Session session = getSession();
		List<GenericLookup> list = (List<GenericLookup>) session
				.createQuery("from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.genericLookupDef.id="
								+ getDefinitionId(defName)+" order by gen.value2").list();

		return list;
	}

	@Override
	public void updateConnectionBasicInfoBySA(String connectionName, String oldConnectionName, Long tiRequestId, String soeId) {
		Session session = getSession();
		
		SQLQuery sqlQuery = session.createSQLQuery("update con_req set connection_name = '"+connectionName+"' where " +
				" id in (select con.id from con_req con, ti_request_planning_xref trpx, ti_request tr " +  
				" where con.id = trpx.planning_id and tr.id  = trpx.ti_request_id and tr.process_id = " +
				" (select process_id from ti_request where id = "+tiRequestId+"))"); 
		sqlQuery.executeUpdate();
		
		 sqlQuery = session.createSQLQuery("update connection set name = '"+connectionName+"' where " +
				" connection_request_id in (select con.id from con_req con, ti_request_planning_xref trpx, ti_request tr " +  
				" where con.id = trpx.planning_id and tr.id  = trpx.ti_request_id and tr.process_id = " +
				" (select process_id from ti_request where id = "+tiRequestId+"))"); 
		sqlQuery.executeUpdate();
		
		sqlQuery = session.createSQLQuery("update ti_process set process_name = '"+connectionName+"' where " +
				" id  = (select process_id from ti_request where id = "+tiRequestId+")"); 
		sqlQuery.executeUpdate();
		
		TIRequest tiRequest = new TIRequest();
		tiRequest.setId(tiRequestId);
		
		AuditLog auditLog = new AuditLog();
		auditLog.setSoeID(soeId);
		auditLog.setAction("Update");
		auditLog.setCreated_date(new Date());
		auditLog.setObjectName("Connection");
		auditLog.setObjectAttribute("Name");
		auditLog.setNewValue(connectionName);
		auditLog.setOldValue(oldConnectionName);
		auditLog.setNewDisplayValue(connectionName);
		auditLog.setOldDisplayValue(oldConnectionName);
		auditLog.setTiRequest(tiRequest);
		auditLog.setIsReference("N");
		
		HibernateTemplate ht = getHibernateTemplate();
		ht.save(auditLog);
	}

	@Override
	public void updateConnectionBasicInfo(Long tiRequestID, Long priority, String donotimpl, String vtTicketNo, Date date){
		Session session = getSession();
		boolean isPriorityChanged = false;
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		
   	 	log.info("BusinessJustificationServiceImpl :: updateConnectionBasicInfo ::tiRequestID "+tiRequestID+",priority::"+priority+", donotimpl::"+donotimpl+",vtTicketNo::"+vtTicketNo +"dta" +date);

		//check whether the priority(BAU, BUSCRIT, EMER) is changed by user
		SQLQuery query = session.createSQLQuery("select count(id) count from ti_request where id = "+tiRequestID+" and priority_id != "+priority);
		query.addScalar("count", IntegerType.INSTANCE);
		Integer isRecordAvailable = (Integer)query.uniqueResult();
		
		if(isRecordAvailable != null && isRecordAvailable.intValue() > 0){
			isPriorityChanged = true;
		}
		if(isPriorityChanged){
			//below 2 updates required to update Firewall and IPReg rfc flag because it has seperate flags for rfc generation
			//reset FirewallRule RFC flag
			SQLQuery query1 = session.createSQLQuery("update TI_REQUEST set rfc_generate_flag = 'N' where id = "+tiRequestID+" and exists (select 1 from rfc_request where ti_request_id = "+tiRequestID+" and rfc_type != 'Generic' and (is_ipreg is null or is_ipreg = 'N'))");
			query1.executeUpdate();
			//reset IPReg Rule RFC flag
			SQLQuery query2 = session.createSQLQuery("update TI_REQUEST set ip_rfc_generate_flag = 'N' where id = "+tiRequestID+" and exists (select 1 from rfc_request where ti_request_id = "+tiRequestID+" and rfc_type != 'Generic' and is_ipreg = 'Y')");
			query2.executeUpdate();
		}
		
		if(vtTicketNo == null){
			vtTicketNo = "";
		}
		
		SQLQuery query3 = session.createSQLQuery("update TI_REQUEST set PRIORITY_ID = "+priority+", VT_TICKET_NO = '"+vtTicketNo+"' ,request_deadline= TO_DATE('"+format.format(date)+"', 'mm-dd-yy HH24:MI:SS')  where id = "+tiRequestID);
		query3.executeUpdate();

		if(donotimpl != null && donotimpl.length() > 0){
			SQLQuery query4 = session.createSQLQuery("update PLANNING set DONT_IMPL_BEFORE_DATE = TO_DATE('"+donotimpl+"', 'mm/dd/yyyy') where id in (select planning_id from ti_request_planning_xref where ti_request_id = "+tiRequestID+")");
			query4.executeUpdate();			
		}			

   	 	log.info("BusinessJustificationServiceImpl :: updateConnectionBasicInfo :: completed");
	}

	@Override
	public void updateBusinessCaseInfo(TIRequest tirequest,ConnectionRequest conreq,String[] virtualConReason){
		Session session = getSession();

		TIRequest tireq = (TIRequest) session.get(TIRequest.class, tirequest.getId());
		ConnectionRequest connectionRequest = (ConnectionRequest) session.get(ConnectionRequest.class, conreq.getId());
		
		//save TIRequest Data
		tireq.setCmpId(tirequest.getCmpId());
		tireq.setSnowId(tirequest.getSnowId());
		tireq.setEnggcmpId(tirequest.getEnggcmpId());
		tireq.setSowNumber(tirequest.getSowNumber());
		session.saveOrUpdate(tireq);
		
		//update CMP ID
		if((tirequest.getCmpId() == null || tirequest.getCmpId().isEmpty() || tirequest.getCmpId().length() <= 0) || 
				(tirequest.getSnowId() != null && !tirequest.getSnowId().isEmpty() && tirequest.getSnowId().length() > 0)){
			SQLQuery updateQuery = getSession().createSQLQuery("update resolve_it_notify_log set ti_request_id = null where ti_request_id = "+tirequest.getId());
			updateQuery.executeUpdate();
		}
		
		//save CoLookup Data
		Long lookupid = conreq.getColookup().getId();
		CoLookupData colookup;
		if (lookupid != null && lookupid.longValue() > 0){
			colookup  = (CoLookupData) session.get(CoLookupData.class, lookupid.longValue());
			
			colookup.setCitigroupDataId(conreq.getColookup().getCitigroupDataId());
			colookup.setCustomerDataId(conreq.getColookup().getCustomerDataId());
			
			session.saveOrUpdate(colookup);
		}else{
			colookup = new CoLookupData();
			colookup.setCitigroupDataId(conreq.getColookup().getCitigroupDataId());
			colookup.setCustomerDataId(conreq.getColookup().getCustomerDataId());
			
			Long id = (Long) session.save(colookup);
			CoLookupData newcolookupdata = (CoLookupData) session.get(CoLookupData.class, id);
			connectionRequest.setColookup(newcolookupdata);
		}
		
		//save ConnectionRequest Data
		connectionRequest.setDetailedInfo(conreq.getDetailedInfo());
		connectionRequest.setRationale(conreq.getRationale());		
		connectionRequest.setConnectivityEstimate(conreq.getConnectivityEstimate());
		connectionRequest.setConforcustclient(conreq.getConforcustclient());
		connectionRequest.setExportLicenseCoordinatorNew(conreq.getExportLicenseCoordinatorNew());
		connectionRequest.setCapappGroupCode(conreq.getCapappGroupCode());
		connectionRequest.setPlcode(conreq.getPlcode());
		connectionRequest.setDirectAccessByThirdparty(conreq.getDirectAccessByThirdparty());

		session.saveOrUpdate(connectionRequest);
		
		//save virtual connection reason
		if(virtualConReason != null && virtualConReason.length > 0){
			/*Criteria criteria = session.createCriteria(VirtualConnReason.class);
			criteria.add(Restrictions.eq("conreq.id", connectionRequest.getId()));

			List<VirtualConnReason> list = criteria.list();			
			if(list != null&&list.size()>0){

			}*/
	    	SQLQuery query = getSession().createSQLQuery("delete from VIRTUAL_CONN_REASON where CON_REQ_ID = "+connectionRequest.getId());
			int rows = query.executeUpdate();
			log.debug("BusinessJustificationServiceImpl :: updateBusinessCaseInfo :: VIRTUAL_CONN_REASON deleted rows - "+rows);
			
			for(String vircon:virtualConReason){
				SQLQuery query1 = getSession().createSQLQuery(" insert into VIRTUAL_CONN_REASON(ID,CON_REQ_ID,GENERIC_LOOKUP_ID) " +
											" values(SEQ_VIRTUAL_CONN_REASON.nextval,"+connectionRequest.getId()+","+vircon+") ");
				query1.executeUpdate();
				
				log.debug("BusinessJustificationServiceImpl :: updateBusinessCaseInfo :: VIRTUAL_CONN_REASON add - "+vircon);
			}
		}
		
	}

	@Override
	@Transactional(readOnly = true)
	public Long getTiRequestForVersion(Integer version, Long processId) {
		Session session = getSession();
		
		SQLQuery sqlQuery = (SQLQuery)session.createSQLQuery("select id as tireq from ti_request where version_number = ? and process_id=? order by id desc").setLong(0, version).setLong(1, processId);
		sqlQuery.addScalar("tireq", LongType.INSTANCE);
		
		List<Long> tiReqIds = (List<Long>)sqlQuery.list();
		
		if (tiReqIds != null && tiReqIds.size() > 0) {
			return tiReqIds.get(0);
		}
		return null;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<ConReqCitiReqConXref> getRequesterContactsList(Long planningId){
		Session session = getSession();
		List<ConReqCitiReqConXref> reqlist = (List<ConReqCitiReqConXref>) session
				.createQuery("from ConReqCitiReqConXref where requestid.id = "+planningId).list();
		
		if (reqlist != null) {
			log.debug("Requester Contacts :"+reqlist.size());
				
				for (ConReqCitiReqConXref conReqCitiReqConXref : reqlist) {
			    	String  issoiddExist = null;
			    	if(conReqCitiReqConXref != null && conReqCitiReqConXref.getCiticontact() != null && conReqCitiReqConXref.getCiticontact().getSsoId()!=null){
			    		issoiddExist = isUserIDExistsInCCR(conReqCitiReqConXref.getCiticontact().getSsoId());
			    		conReqCitiReqConXref.setIsexistsInCCR(issoiddExist);
			    	}
			    	
			   }
		}
		
		
		
		return reqlist;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<ConReqTPContactXref> getRequesterTPContactsList(Long planningId){
		Session session = getSession();
		List<ConReqTPContactXref> reqTPlist = null; 
		
		String queryString = "select distinct tpconxref.* "+
	    " from CON_REQ_TP_CONTACT_XREF tpconxref,Planning pln,ti_request_planning_xref xref,ti_request tireq,ti_process tipro, relationship rel, tp_contact tpcon "+
	    " where pln.id = "+planningId+" and pln.id = tpconxref.request_id and pln.id = xref.planning_id and xref.ti_request_id = tireq.id "+
	    " and tireq.process_id = tipro.id and tipro.relationship_id = rel.id and rel.third_party_id = tpcon.thirdparty_id "+
	    " and tpcon.id = tpconxref.tp_contact_id ";
		
		SQLQuery query =  session.createSQLQuery(queryString);
		query.addEntity("tpconxref",ConReqTPContactXref.class);
		
		reqTPlist = query.list();
		
		if (reqTPlist != null) {
			log.debug("Requester TP Contacts :"+reqTPlist.size());
		}
		return reqTPlist;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<ConReqTPContactXref> getTargetTPContactsList(Long planningId){
		Session session = getSession();
		List<ConReqTPContactXref> tarTPlist = null; 
		
		String queryString = "select distinct tpconxref.* "+
	    " from CON_REQ_TP_CONTACT_XREF tpconxref,Planning pln,ti_request_planning_xref xref,ti_request tireq,ti_process tipro, relationship rel, tp_contact tpcon "+
	    " where pln.id = "+planningId+" and pln.id = tpconxref.request_id and pln.id = xref.planning_id and xref.ti_request_id = tireq.id "+
	    " and tireq.process_id = tipro.id and tipro.relationship_id = rel.id and rel.uturn_third_party_id = tpcon.thirdparty_id "+
	    " and tpcon.id = tpconxref.tp_contact_id ";
		
		SQLQuery query =  session.createSQLQuery(queryString);
		query.addEntity("tpconxref",ConReqTPContactXref.class);
		
		tarTPlist = query.list();
		
		if (tarTPlist != null) {
			log.debug("Target TP Contacts :"+tarTPlist.size());
		}
		return tarTPlist;
	}

	@Override
	@Transactional(readOnly = true)
	public List<ConReqCitiContactXref> getTargetContactsList(Long planningId){
		Session session = getSession();
		List<ConReqCitiContactXref> tarlist = (List<ConReqCitiContactXref>) session
				.createQuery("from ConReqCitiContactXref where requestid.id = "+planningId).list();
		
    	
    	if (tarlist != null) {
			log.debug("Target Contacts :"+tarlist.size());
			
			for (ConReqCitiContactXref conReqCitiContactXref : tarlist) {
		    	String  issoiddExist = null;
		    	if(conReqCitiContactXref != null && conReqCitiContactXref.getCiticontact() != null && conReqCitiContactXref.getCiticontact().getSsoId()!=null){
		    		issoiddExist = isUserIDExistsInCCR(conReqCitiContactXref.getCiticontact().getSsoId());
		    		conReqCitiContactXref.setIsexistsInCCR(issoiddExist);
		    	}
		    	
		   }
		}
		return tarlist;
	}
	
	public void copyFromRelationship(Long planningId, Long tiReqId) {
		
	}
	
	public List<Long> saveConReqCitiContactXref(Long planningId, CitiContact citiContact, String[] roleIds) {
		List<Long> ids = new ArrayList<Long>();
		Long id  = null;
		citiContact = getCitiContact(citiContact);
		ConReqCitiContactXref citiContactXref = null;
		Role role = null;
		Planning planning = null;
		for (String roleId : roleIds) {
			if (!isConReqCitiContactExists(planningId, citiContact, roleId)) {
				citiContactXref = new ConReqCitiContactXref();
				citiContactXref.setCiticontact(citiContact);
				role = new Role();
				role.setId(Long.parseLong(roleId));
				citiContactXref.setRole(role);
				planning = new Planning();
				planning.setId(planningId);
				citiContactXref.setRequestid(planning);
				if ("E".equalsIgnoreCase(citiContact.getEmployeeType())) {
					citiContactXref.setPrimaryContact("Y");
				} else {
					citiContactXref.setPrimaryContact("N");
				}
				citiContactXref.setNotifyContact("Y");
				citiContactXref.setSystemGenerated("N");
				citiContactXref.setIsreject("N");
				citiContactXref.setNotifyCount(0L);
				id = (Long)getHibernateTemplate().save(citiContactXref);
				ids.add(id);
			}
		}
		
		return ids;
	}
	
	public void updateConReqCitiContactXref(List<ConReqCitiContactXref> citiContactXrefs) {
		
		if(citiContactXrefs!=null && citiContactXrefs.size()>0){
			for(ConReqCitiContactXref conReqCitiContactXref:citiContactXrefs){
				getHibernateTemplate().saveOrUpdate(conReqCitiContactXref);
			}
		}
		
		
	}
	
	public void deleteConReqCitiContactXref(String[] conIds) {
		Session session = getSession();
		ConReqCitiContactXref citiContactXref = null;
		for (String id : conIds) {
			citiContactXref = (ConReqCitiContactXref)session.get(ConReqCitiContactXref.class, Long.parseLong(id)) ;
			session.delete(citiContactXref);
		}
	}
	
	private boolean isConReqCitiContactExists(Long planningId, CitiContact citiContact, String roleId) {
		Session session = getSession();
		Query query = session.createQuery("from ConReqCitiContactXref where requestid.id = ? and role.id = ? and citicontact.id = ?").setLong(0, planningId)
		.setLong(1, Long.parseLong(roleId)).setLong(2, citiContact.getId());
		List<ConReqCitiContactXref> tarlist = query.list();
		
		if (tarlist != null && tarlist.size() > 0) {
			return true;
		}
		return false;
	}
	
	public List<Long> saveConReqCitiReqContactXref(Long planningId, CitiContact citiContact, String[] roleIds) {
		List<Long> ids = new ArrayList<Long>();
		Long id  = null;
		citiContact = getCitiContact(citiContact);
		ConReqCitiReqConXref citiContactXref = null;
		Role role = null;
		Planning planning = null;
		for (String roleId : roleIds) {
			if (!isConReqCitiReqContactExists(planningId, citiContact, roleId)) {
				citiContactXref = new ConReqCitiReqConXref();
				citiContactXref.setCiticontact(citiContact);
				role = new Role();
				role.setId(Long.parseLong(roleId));
				citiContactXref.setRole(role);
				planning = new Planning();
				planning.setId(planningId);
				citiContactXref.setRequestid(planning);
				if ("E".equalsIgnoreCase(citiContact.getEmployeeType())) {
					citiContactXref.setPrimaryContact("Y");
				} else {
					citiContactXref.setPrimaryContact("N");
				}
				citiContactXref.setNotifyContact("Y");
				citiContactXref.setSystemGenerated("N");
				citiContactXref.setIsreject("N");
				citiContactXref.setNotifyCount(0L);
				id = (Long)getHibernateTemplate().save(citiContactXref);
				ids.add(id);
			}
		}
		
		return ids;
	}
	
	public void updateConReqCitiReqContactXref(List<ConReqCitiReqConXref> citiContactXrefs) {
	    for(ConReqCitiReqConXref conReqCitiReqConXref : citiContactXrefs){
	        getHibernateTemplate().saveOrUpdate(conReqCitiReqConXref);
	    }
	}
	
	public void deleteConReqCitiReqContactXref(String[] conIds) {
		Session session = getSession();
		ConReqCitiReqConXref citiContactXref = null;
		for (String id : conIds) {
			citiContactXref = (ConReqCitiReqConXref)session.get(ConReqCitiReqConXref.class, Long.parseLong(id)) ;
			getHibernateTemplate().delete(citiContactXref);
		}
	}
	
	@Override
	public void addContactsBySA(List<HistoryContact> historyContacts, Long tiRequestId, String soeId, String requestFrom) {
		
		TIRequest tiRequest = new TIRequest();
		tiRequest.setId(tiRequestId);
		
		AuditLog auditLog = null;
		
		String objectName = "";
		
		if ("requester".equalsIgnoreCase(requestFrom)) {
			objectName = "con_req_cit_rqcon_xref";
		} else {
			objectName = "con_req_citi_contact_xref";
		}
		
		HibernateTemplate ht = getHibernateTemplate();
		for (HistoryContact historyContact : historyContacts) {
			auditLog = new AuditLog();
			auditLog.setSoeID(soeId);
			auditLog.setCreated_date(new Date());
			auditLog.setObjectName("Connection");
			auditLog.setObjectAttribute("Contact");
			auditLog.setNewValue(String.valueOf(historyContact.getXrefId()));
			auditLog.setNewDisplayValue(historyContact.getSoeId());
			auditLog.setAction("Add");
			auditLog.setTiRequest(tiRequest);
			auditLog.setIsReference("Y");
			auditLog.setNewAuditObjectType(getAuditObjectType(objectName));
			ht.save(auditLog);
		}
		
	}
	
	@Override
	public void deleteContactsBySA(List<HistoryContact> historyContacts, Long tiRequestId, String soeId, String requestFrom) {
		
		TIRequest tiRequest = new TIRequest();
		tiRequest.setId(tiRequestId);
		
		AuditLog auditLog = null;
		
		String objectName = "";
		
		if ("requester".equalsIgnoreCase(requestFrom)) {
			objectName = "con_req_cit_rqcon_xref";
		} else {
			objectName = "con_req_citi_contact_xref";
		}
		
		Long historyContactId = null;
		HibernateTemplate ht = getHibernateTemplate();
		for (HistoryContact historyContact : historyContacts) {
			historyContactId = (Long)ht.save(historyContact);
			auditLog = new AuditLog();
			auditLog.setSoeID(soeId);
			auditLog.setCreated_date(new Date());
			auditLog.setObjectName("Connection");
			auditLog.setObjectAttribute("Contact");
			auditLog.setOldValue(String.valueOf(historyContactId));
			auditLog.setOldDisplayValue(historyContact.getSoeId());
			auditLog.setAction("Delete");
			auditLog.setTiRequest(tiRequest);
			auditLog.setIsReference("Y");
			auditLog.setOldAuditObjectType(getAuditObjectType(objectName));
			ht.save(auditLog);
		}
		
	}
	
	@Override
	public void updateContactsBySA(Map<Integer, HistoryContact> newHistoryContacts, 
			Map<Integer, HistoryContact> oldHistoryContacts, Long tiRequestId, String soeId, String requestFrom) {
		
		TIRequest tiRequest = new TIRequest();
		tiRequest.setId(tiRequestId);
		
		AuditLog auditLog = null;
		
		HistoryContact newHistoryContact = null;
		
		HistoryContact oldHistoryContact = null;
		Long oldHistoryContactId = null;
		HibernateTemplate ht = getHibernateTemplate();
		
		String objectName = "";
		
		if ("requester".equalsIgnoreCase(requestFrom)) {
			objectName = "con_req_cit_rqcon_xref";
		} else {
			objectName = "con_req_citi_contact_xref";
		}
		
		if (newHistoryContacts != null) {
		
			int size = 0;
			
			if (newHistoryContacts.entrySet() != null) {
				size = newHistoryContacts.entrySet().size();
			}
			
			for (int i = 1; i<=size; i++) {
				newHistoryContact = newHistoryContacts.get(Integer.valueOf(i));
				
				oldHistoryContact = oldHistoryContacts.get(Integer.valueOf(i));
				oldHistoryContactId = (Long)ht.save(oldHistoryContact);
				
				auditLog = new AuditLog();
				auditLog.setSoeID(soeId);
				auditLog.setCreated_date(new Date());
				auditLog.setObjectName("Connection");
				auditLog.setObjectAttribute("Contact");
				auditLog.setNewValue(String.valueOf(newHistoryContact.getXrefId()));
				auditLog.setNewDisplayValue(newHistoryContact.getSoeId());
				auditLog.setNewAuditObjectType(getAuditObjectType(objectName));
				auditLog.setAction("Update");
				auditLog.setOldValue(String.valueOf(oldHistoryContactId));
				auditLog.setOldDisplayValue(oldHistoryContact.getSoeId());
				auditLog.setOldAuditObjectType(getAuditObjectType(objectName));
				auditLog.setTiRequest(tiRequest);
				auditLog.setIsReference("Y");
				ht.save(auditLog);
				
			}
			
		}
	}

	@Override
	public void updateBusinessCaseBySA(Long relationshipId, Long oldRelationshipId, Long tiRequestId, String soeId) {
		Session session = getSession();
		
		// To update the relationship id and resource types in con_req on Relationship ID Update
		SQLQuery sqlQuery = session.createSQLQuery("update con_req set relationship_id = "+relationshipId+
				" , source_resource_type = (select requester_resource_type_id from relationship where id = "+relationshipId+") " +
				" , target_resource_type = (select target_resource_type_id from relationship where id = "+relationshipId+")" +
				" where id = " +
				"(select con.id from con_req con, ti_request_planning_xref trpx  where con.id = trpx.planning_id and " +
				"trpx.ti_request_id = "+tiRequestId+")"); 
		sqlQuery.executeUpdate();
		
		// To update the relationship id in connection on Relationship ID Update
		sqlQuery = session.createSQLQuery("update connection set relationship_id = "+relationshipId+
			"	where connection_request_id = (select con.id from con_req con, ti_request_planning_xref trpx  "+
			"	where con.id = trpx.planning_id and trpx.ti_request_id = "+tiRequestId+")"); 
		sqlQuery.executeUpdate();
		
		// To update the relationship id in ti_process on Relationship ID Update
		sqlQuery = session.createSQLQuery("update ti_process set relationship_id = "+relationshipId+" where id = (select process_id from ti_request where id = "+tiRequestId+")"); 
		sqlQuery.executeUpdate();
		
		TIRequest tiRequest = new TIRequest();
		tiRequest.setId(tiRequestId);
		
		AuditLog auditLog = new AuditLog();
		auditLog.setSoeID(soeId);
		auditLog.setAction("Update");
		auditLog.setCreated_date(new Date());
		auditLog.setObjectName("Connection");
		auditLog.setObjectAttribute("RelationshipID");
		auditLog.setNewValue(String.valueOf(relationshipId));
		auditLog.setOldValue(String.valueOf(oldRelationshipId));
		auditLog.setNewDisplayValue(String.valueOf(relationshipId));
		auditLog.setOldDisplayValue(String.valueOf(oldRelationshipId));
		auditLog.setTiRequest(tiRequest);
		auditLog.setIsReference("N");
		
		HibernateTemplate ht = getHibernateTemplate();
		ht.save(auditLog);
	}
	
	@Override
	public void copyContactsFromRelationship(Long tiRequestId) {
		Session session = getSession();

		Query q1 = session.createSQLQuery("{ call copy_contacts_from_rel(?) }");
		q1.setLong(0, tiRequestId); // first parameter, index starts with 0
		
		q1.executeUpdate();		
	}
	
	private AuditObjectType getAuditObjectType(String objectName) {
	
		AuditObjectType auditObjectType = null;
		List<AuditObjectType> auditObjectTypes = (List<AuditObjectType>) getSession().
					createQuery(" from AuditObjectType where objectName = '"+objectName+"'").list();
		
		if (auditObjectTypes != null && !auditObjectTypes.isEmpty()) {
			auditObjectType =  auditObjectTypes.get(0);
		} 
		return auditObjectType;
		
	}
		
	private boolean isConReqCitiReqContactExists(Long planningId, CitiContact citiContact, String roleId) {
		Session session = getSession();
		Query query = session.createQuery("from ConReqCitiReqConXref where requestid.id = ? and role.id = ? and citicontact.id = ?").setLong(0, planningId)
		.setLong(1, Long.parseLong(roleId)).setLong(2, citiContact.getId());
		List<ConReqCitiReqConXref> reqlist = query.list();
		
		if (reqlist != null && reqlist.size() > 0) {
			return true;
		}
		return false;
	}
	
	@Override
	public boolean isValidateThridPartyConts(Long relId, String relType, Long reqTpId, Long tarTpId) {
		log.info(" Entering isValidateThridPartyConts ::");	
		try{
		List resultList=null;	
		Session session = getSession();
		if(C3parStaticNames.THIRD_PARTY.equalsIgnoreCase(relType)){
			resultList=session.createSQLQuery(QueryConstants.TP_CONTACTS).setLong(RELID, relId).list();
			if(CollectionUtils.isEmpty(resultList))
				return false;
			
		}
		if(C3parStaticNames.U_TURN.equalsIgnoreCase(relType)){
			resultList=session.createSQLQuery(QueryConstants.UTURN_TP_CONTACTS).setLong(RELID, relId).setLong(TPID, reqTpId).list();
			if(CollectionUtils.isEmpty(resultList))
				return false;
			resultList=session.createSQLQuery(QueryConstants.UTURN_TP_CONTACTS).setLong(RELID, relId).setLong(TPID, tarTpId).list();
			if(CollectionUtils.isEmpty(resultList))
				return false;
		}
		if(C3parStaticNames.CITI_CON.equalsIgnoreCase(relType) || C3parStaticNames.IP_TEMPLATE.equalsIgnoreCase(relType) ||  C3parStaticNames.TEMPLATE_OBJ.equalsIgnoreCase(relType)){
			resultList=session.createSQLQuery(QueryConstants.REL_CITI_LOCs).setLong(RELID, relId).list();
			if(CollectionUtils.isEmpty(resultList))
				return false;
		}else{
			resultList=session.createSQLQuery(QueryConstants.TP_LOCATION).setLong(RELID, relId).list();
			if(CollectionUtils.isEmpty(resultList))
				return false;
				
			}
		}
		
		catch(Exception e){
			log.error("Error has occurred whild validation third party contacts details::");
		}
		log.info(" Exiting isValidateThridPartyConts ::");	
		return true;
	}
	
	
	private CitiContact getCitiContact(CitiContact citiContact) {
		Session session = getSession();
		Query query = session.createQuery("from CitiContact where ssoId = ?").setString(0, citiContact.getSsoId());
		List<CitiContact> list = query.list();
		
		CitiContact contact = null; 
		if (list != null && list.size() > 0) {
			contact = list.get(0);
		}
		
		if (contact != null && contact.getId() != null) {
			contact.setUpdated_date(new Date());
			contact.setEmployeeType(citiContact.getEmployeeType());
			contact.setEmail(citiContact.getEmail());
			contact.setPhone(citiContact.getPhone());
			contact.setManagerGeId(citiContact.getManagerGeId());
			contact.setEmployeeStatus(citiContact.getEmployeeStatus());
			contact.setIsTerminated(citiContact.getIsTerminated());
			contact.setGeId(citiContact.getGeId());
			contact.setRitsId(citiContact.getRitsId());
			contact.setGocCode(citiContact.getGocCode());
			contact.setManSegmentId(citiContact.getManSegmentId());
			contact.setDsmtRegionId(citiContact.getDsmtRegionId());
			contact.setDsmtRegionName(citiContact.getDsmtRegionName());
			contact.setDsmtSectorId(citiContact.getDsmtSectorId());
			contact.setDsmtSectorName(citiContact.getDsmtSectorName());
			contact.setDsmtBusinessUnitId(citiContact.getDsmtBusinessUnitId());
			contact.setDsmtBusinessUnitName(citiContact.getDsmtBusinessUnitName());
			getHibernateTemplate().update(contact);
			return contact;
			
		} else {
			citiContact.setUpdated_date(new Date());
			Long id = (Long)getHibernateTemplate().save(citiContact);
			citiContact.setId(id);
			return citiContact;
		}
		
	}
	
	private Long getDefinitionId(String defName) {
		Session session = getSession();
		GenericLookupDef res = (GenericLookupDef) session.createQuery("from GenericLookupDef def where upper(def.name)=upper('" + defName + "')").uniqueResult();

		return res.getId();
	}
	
	@Transactional(readOnly = true)
	public List<Role> getRoles() {
		Session session = getSession();

		Criteria criteria = session.createCriteria(Role.class);
		criteria.add(Restrictions.eq("citi", "Y"));
		criteria.add(Restrictions.eq("iscontact", "Y"));
		criteria.addOrder(Order.asc("displayName"));

		List<Role> list = criteria.list();
		if(list != null)
			log.debug("BusinessJustificationServiceImpl ::  getResourceList :: size ::"+list.size());
		
		return list;
	}
	
	@Transactional(readOnly = true)
	public String getConnectionBusinessJustification(Long processId, Long tiRequestId){
		Session session = getSession();
		
		SQLQuery sqlQuery = (SQLQuery)session.createSQLQuery(" select nvl(con.rationale,'') busjus from con_req con where con.id = "+
					" (select planning_id from ti_request_planning_xref where ti_request_id in (select max(id) " +
					" from ti_request where id < "+tiRequestId+" and process_id = "+processId+")) ");
		
		sqlQuery.addScalar("busjus", StringType.INSTANCE);		
		List<String> busjustlist = (List<String>)sqlQuery.list();
		
		if (busjustlist != null && busjustlist.size() > 0) {
			return busjustlist.get(0);
		}
		
		return "";
	}
	
	private String isUserIDExistsInCCR(String ssoID ) {
		 
		Session session = getSession();
		
		StringBuffer str=new StringBuffer("select id from c3par_users where upper(sso_id) = upper('"+ssoID+"')");
        log.debug("isUserIDExistsInCCR::getSSOID::str==>"+str.toString());

        SQLQuery sqlQuery = (SQLQuery)session.createSQLQuery(str.toString());
        sqlQuery.addScalar("id", LongType.INSTANCE);		
		List<Long> list = (List<Long>)sqlQuery.list();
		
		if (list != null && list.size() > 0) {
			log.debug("isUserIDExistsInCCR::size::str==>"+list.size()+"...ssoID.."+ssoID);
			return "Y";
		}
		return "N";
	}
	
	@Transactional(readOnly = true)
	public CitiContact getGDWDataBySSOId(final String ssoId){
		log.info("Entering BusinessJustificationServiceImpl getGDWDataBySSOId.");
		StringBuilder query=new StringBuilder("");
		query.append(" SELECT GOC.MAN_SEG_ID ,                                                                                                        ");
		query.append("   GDW.GOC_CODE ,                                                                                                               ");
		query.append("   GEO.MAN_GEOID_L2_ID                                                                                    AS Region_id ,        ");
		query.append("   GEO.MAN_GEOID_L2_NAME                                                                                  AS Region ,           ");
		query.append("   SEG.MAN_SEGID_L4_ID                                                                                    AS Sector_id,         ");
		query.append("   SEG.MAN_SEGID_L4_NAME                                                                                  AS Sector ,           ");
		query.append("   NVL(SEG.MAN_SEGID_L8_ID,NVL(SEG.MAN_SEGID_L7_ID,NVL(SEG.MAN_SEGID_L6_ID,SEG.MAN_SEGID_L5_ID)))         AS Business_Unit_id , ");
		query.append("   NVL(SEG.MAN_SEGID_L8_NAME,NVL(SEG.MAN_SEGID_L7_NAME,NVL(SEG.MAN_SEGID_L6_NAME,SEG.MAN_SEGID_L5_NAME))) AS Business_Unit      ");
		query.append(" FROM RDSPR.GDW_USER GDW                                                                                                        ");
		query.append(" LEFT JOIN rdspr.D_DSMT_GOC GOC                                                                                                 ");
		query.append(" ON GDW.GOC_CODE = GOC.C_GOC_ID                                                                                                 ");
		query.append(" LEFT JOIN rdspr.D_DSMT_SEGMENT SEG                                                                                             ");
		query.append(" ON GOC.MAN_SEG_ID = SEG.MAN_SEGID                                                                                              ");
		query.append(" LEFT JOIN rdspr.D_DSMT_GEOGRAPHY GEO                                                                                           ");
		query.append(" ON GOC.MAN_GEO_ID = GEO.MAN_GEOID                                                                                              ");
		query.append(" WHERE upper(GDW.SOEID)       = ?		                                                                                                  ");
		CitiContact citiContact  = null;
		try {
			citiContact = jdbcTemplateGDW.query(query.toString(),
			new PreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement preparedStatement) throws
				SQLException {
					preparedStatement.setString(1, ssoId);
				}
			},
			new ResultSetExtractor<CitiContact>() {
				@Override
				public CitiContact extractData(ResultSet resultSet) throws SQLException,
				DataAccessException {
					if (resultSet.next()) {
						CitiContact citiContact = new CitiContact();
						citiContact.setGocCode(resultSet.getString(1));
						citiContact.setManSegmentId(resultSet.getString(2));
						citiContact.setDsmtRegionId(resultSet.getString(3));
						citiContact.setDsmtRegionName(resultSet.getString(4));
						citiContact.setDsmtSectorId(resultSet.getString(5));
						citiContact.setDsmtSectorName(resultSet.getString(6));
						citiContact.setDsmtBusinessUnitId(resultSet.getString(7));
						citiContact.setDsmtBusinessUnitName(resultSet.getString(8));
						return citiContact;
					}
					return null;
				}
			});
			if(citiContact!=null){
				log.debug("gocCode value from GDW DB: "+citiContact.getGocCode());
			} else {
				log.debug("Record not found!!!");
			}
		} catch (DataAccessException e) {
			log.error("Exception in BusinessJustificationServiceImpl getGDWDataBySSOId. ");
		} 
		log.info("Exiting BusinessJustificationServiceImpl getGDWDataBySSOId.");
		return citiContact;
	}
	
	public CitiContact getBusinessOwnerDetails(final Long tiRequestId,String relationType){
		log.info("Entering SearchProcessesImpl getBusinessOwnerDetails.");
		log.debug("Relation Type for Connection: "+relationType);
		StringBuilder query = new StringBuilder();
		query.append(" SELECT DISTINCT 			         ");
		query.append("   upper(cc.first_name),            ");
		query.append("   upper(cc.last_name),                    ");
		query.append("   cc.goc_code,                     ");
		query.append("   cc.man_segment_id,               ");
		query.append("   cc.dsmt_region_name,             ");
		query.append("   cc.dsmt_sector_name,             ");
		query.append("   cc.dsmt_business_unit_name,      ");
		query.append("   cc.sso_id					      ");
		query.append(" FROM ti_process tp                 ");
		query.append(" JOIN ti_request tr                 ");
		query.append(" ON tp.id=tr.process_id             ");
		query.append(" JOIN ti_request_planning_xref trpx ");
		query.append(" ON trpx.ti_request_id=tr.id        ");
		query.append(" JOIN planning p                    ");
		query.append(" ON p.id=trpx.planning_id           ");
		//For Target/Requester Contacts check
		if(C3parStaticNames.THIRD_PARTY.equals(relationType) || C3parStaticNames.TEMPLATE_OBJ.equals(relationType) ||
				C3parStaticNames.IP_TEMPLATE.equals(relationType) || C3parStaticNames.PORT_TEMPLATE.equals(relationType) || 
				"TARGET".equalsIgnoreCase(relationType) ){
			query.append(" JOIN CON_REQ_CITI_CONTACT_XREF cr  "); //For TargetContact Screen
		} else if(C3parStaticNames.U_TURN.equals(relationType) || C3parStaticNames.CITI_CON.equals(relationType) ||
				"REQUESTER".equalsIgnoreCase(relationType) ){
			query.append(" JOIN CON_REQ_CIT_RQCON_XREF cr  "); //For RequesterContact Screen
		} else {
			query.append(" JOIN CON_REQ_CITI_CONTACT_XREF cr  "); //To avoid exception, how ever data will not available.
		}
		query.append(" ON cr.request_id=p.id              ");
		query.append(" JOIN citi_contact cc               ");
		query.append(" ON cc.id=cr.citi_contact_id        ");
		query.append(" JOIN role r                        ");
		query.append(" ON cr.role_id = r.id               ");
		query.append(" WHERE r.name  = 'Business_Owner'   ");
		query.append(" AND cr.primary_contact = 'Y'    	  ");
		query.append(" AND tr.id     =?           	      ");
		log.debug("Query to get Business Owner details: "+query.toString()+" tiRequestId  :: "+tiRequestId);
		CitiContact citiContact=null;
		try {
			 citiContact =jdbcTemplate.query(query.toString(),
					new PreparedStatementSetter() {
						@Override
						public void setValues(PreparedStatement preparedStatement) throws
						SQLException {
							preparedStatement.setLong(1, tiRequestId);
						}
					}, 
					new ResultSetExtractor<CitiContact>() {
						@Override
						public CitiContact extractData(ResultSet resultSet) throws SQLException,
						DataAccessException {
							if (resultSet.next()) {
								CitiContact citiContact = new CitiContact();
								citiContact.setFirstName(resultSet.getString(1));
								citiContact.setLastName(resultSet.getString(2));
								citiContact.setGocCode(resultSet.getString(3));
								citiContact.setManSegmentId(resultSet.getString(4));
								citiContact.setDsmtRegionName(resultSet.getString(5));
								citiContact.setDsmtSectorName(resultSet.getString(6));
								citiContact.setDsmtBusinessUnitName(resultSet.getString(7));
								citiContact.setSsoId(resultSet.getString(8));
								return citiContact; 
							}
							log.info("inside the else condition ");
							return new CitiContact();
						}
					});
			if(citiContact==null){
				log.debug("No Records Found...");
			}
		} catch (DataAccessException e) {
			log.error("Exception in SearchProcessesImpl getBusinessOwnerDetails.",e);
		}
		log.info("Exiting SearchProcessesImpl getBusinessOwnerDetails.");
		return citiContact;
	}
	
}
