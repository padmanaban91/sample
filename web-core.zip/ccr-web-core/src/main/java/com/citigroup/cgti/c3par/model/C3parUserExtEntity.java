package com.citigroup.cgti.c3par.model;


/**
 * The Class C3parUserExtEntity.
 */
public class C3parUserExtEntity extends C3parUsersEntity{

    /** The employee type. */
    private String employeeType;


    /**
     * Gets the employee type.
     *
     * @return the employee type
     */
    public String getEmployeeType() {
	return employeeType;
    }

    /**
     * Sets the employee type.
     *
     * @param employeeType the new employee type
     */
    public void setEmployeeType(String employeeType) {
	this.employeeType = employeeType;
    }



}
