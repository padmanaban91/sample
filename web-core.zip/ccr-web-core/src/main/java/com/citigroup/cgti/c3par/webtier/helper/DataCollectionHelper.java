package com.citigroup.cgti.c3par.webtier.helper;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.C3parSession;
//import oracle.jdbc.driver.OracleTypes;


/**
 * The Class DataCollectionHelper.
 *
 * @author
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DataCollectionHelper
{

    /** The debug. */
    public static boolean debug = false;

    /** The Constant OSTIA_PAIR. */
    public static final String OSTIA_PAIR = "OSTIA_PAIR";

    /** The Constant OSTIA_PORT. */
    public static final String OSTIA_PORT = "OSTIA_PORT";

    /** The Constant IP_PAIR. */
    public static final String IP_PAIR = "IP_PAIR";

    /** The Constant IP_PORT. */
    public static final String IP_PORT = "IP_PORT";

    /** The Constant PAIR_TAB. */
    public static final String PAIR_TAB= "OSTIA_TAB";

    /** The Constant OSTIA_TAB. */
    public static final String OSTIA_TAB= "OSTIA_TAB";

    /** The Constant OSTIA_PORT_EDIT_INDEX. */
    public static final String OSTIA_PORT_EDIT_INDEX = "indexPairId";

    /** The Constant COMMON_PORT_OSTIA. */
    public static final String COMMON_PORT_OSTIA="COMMON_PORT_OSTIA";

    /** The Constant COMMON_PORT_PAIR. */
    public static final String COMMON_PORT_PAIR="COMMON_PORT_PAIR";

    /** The SELEC t_ al l_ mod e_ fo r_ i p_ detaila. */
    private final String SELECT_ALL_MODE_FOR_IP_DETAILA = "selectAllA";

    /** The SELEC t_ al l_ mod e_ fo r_ i p_ detailb. */
    private final String SELECT_ALL_MODE_FOR_IP_DETAILB = "selectAllB";

    /** The SELEC t_ al l_ mod e_ fo r_ osti a_ pairs. */
    private final String SELECT_ALL_MODE_FOR_OSTIA_PAIRS = "selectAllOSTIApairs";

    /** The SELEC t_ al l_ mod e_ fo r_ osti a_ ports. */
    private final String SELECT_ALL_MODE_FOR_OSTIA_PORTS = "selectAllOSTIAports";

    /** The SELEC t_ al l_ mod e_ fo r_ i p_ pair. */
    private final String SELECT_ALL_MODE_FOR_IP_PAIR="selectAllPairs";

    /** The SELEC t_ al l_ mod e_ fo r_ i p_ port. */
    private final String SELECT_ALL_MODE_FOR_IP_PORT="selectAllPairPort";

    /** The UNSELECTE d_ ip a_ list. */
    private final String UNSELECTED_IPA_LIST = "unselectedIPAList";

    /** The UNSELECTE d_ ip b_ list. */
    private final String UNSELECTED_IPB_LIST = "unselectedIPBList";

    /** The UNSELECTE d_ ostiapai r_ list. */
    private final String UNSELECTED_OSTIAPAIR_LIST = "unselectedOSTIAPAIRList";

    /** The UNSELECTE d_ ostiapor t_ list. */
    private final String UNSELECTED_OSTIAPORT_LIST = "unselectedOSTIAPORTList";

    /** The UNSELECTE d_ ippai r_ list. */
    private final String UNSELECTED_IPPAIR_LIST = "unselectedIPPAIRList";

    /** The UNSELECTE d_ ippor t_ list. */
    private final String UNSELECTED_IPPORT_LIST = "unselectedIPPORTList";

    /** The SELECTE d_ ip a_ list. */
    private final String SELECTED_IPA_LIST = "selectedIPAList";

    /** The SELECTE d_ ip b_ list. */
    private final String SELECTED_IPB_LIST = "selectedIPBList";

    /** The SELECTE d_ ostiapai r_ list. */
    private final String SELECTED_OSTIAPAIR_LIST = "selectedOSTIAPAIRList";

    /** The SELECTE d_ ostiapor t_ list. */
    private final String SELECTED_OSTIAPORT_LIST = "selectedOSTIAPORTList";

    /** The SELECTE d_ ippai r_ list. */
    private final String SELECTED_IPPAIR_LIST = "selectedIPPAIRList";

    /** The SELECTE d_ ippor t_ list. */
    private final String SELECTED_IPPORT_LIST = "selectedIPPORTList";

    /** The CITIGROU p_ i p_ destination. */
    private final String CITIGROUP_IP_DESTINATION = "Citigroup Internal";

    /** The THIRDPART y_ i p_ destination. */
    private final String THIRDPARTY_IP_DESTINATION = "Third Party";

    /** The DMZ. */
    private final String DMZ = "DMZ";

    /** The GRN. */
    private final String GRN = "GRN";

    /** The Constant COMMON_IDS. */
    public static final String COMMON_IDS = "COMMON_IDS";

    /** The util. */
    private Util util= new Util();

    /** The log. */
    private static Logger log = Logger.getLogger(DataCollectionHelper.class);


 
    /**
     * Checks if is app application tab complete.
     *
     * @param ipProcessID the ip process id
     * @return true, if is app application tab complete
     */
    public boolean isAppApplicationTabComplete(Long ipProcessID){
	boolean isAppApplicationTabComplete = false;
	Connection connection = null;
	Statement statement = null;
	ResultSet result = null;
	int count=0;
	try{
	    String  sql="select count(*) from aps_appsense_policy where process_id='"+ipProcessID+"' and record_type='A'";
	    C3parSession c3parSession = new C3parSession();
	    connection = c3parSession.getConnection();
	    statement = connection.createStatement();
	    result = statement.executeQuery(sql);
	    while(result.next()){
		count=result.getInt(1);

	    }

	    if(count>0)
		isAppApplicationTabComplete = true;
	    else
		isAppApplicationTabComplete= false;

	}catch(Exception e){
	    log.error(e);
	}finally{
	    try{
		result.close();
		statement.close();
		connection.close();
	    }catch(Exception e){
		log.error(e);
	    }
	}
	return isAppApplicationTabComplete;
    }	

    /**
     * Checks if is app user tab complete.
     *
     * @param ipProcessID the ip process id
     * @return true, if is app user tab complete
     */
    public boolean isAppUserTabComplete(Long ipProcessID){
	boolean isAppUserTabComplete = false;
	Connection connection = null;
	Statement statement = null;
	ResultSet result = null;
	int count=0;
	//int applnCount=0;
	try{
	    //String appsenseApplnSQL="select count(*) from aps_appsense_policy where process_id='"+ipProcessID+"' and record_type='A'";
	    String  sql="select count(*) from aps_appsense_policy where process_id='"+ipProcessID+"' and record_type='U'";
	    C3parSession c3parSession = new C3parSession();
	    connection = c3parSession.getConnection();
	    statement = connection.createStatement();

	    result = statement.executeQuery(sql);

	    while(result.next()){
		count=result.getInt(1);
	    }
	    if( count <=0){
		isAppUserTabComplete=false;
	    }else if(count >0){
		isAppUserTabComplete= true;
	    } 
	}catch(Exception e){
	    log.error(e);
	}finally{
	    try{
		result.close();
		statement.close();
		connection.close();
	    }catch(Exception e){
		log.error(e);
	    }
	}

	return isAppUserTabComplete;
    }


    /**
     * Checks if is app ostia tab complete.
     *
     * @param ipProcessID the ip process id
     * @return true, if is app ostia tab complete
     */
    public boolean isAppOstiaTabComplete(Long ipProcessID){
	boolean isAppOstiaTabComplete = false;
	Connection connection = null;
	Statement statement = null;
	ResultSet result = null;
	int count=0;
	int riskPort_Count=0;
	try{
	    String  sql="SELECT count(*) FROM  CON_OSTIA_GROUP WHERE ID IN "+
	    "(SELECT PORT_MASTER.ostia_group_id FROM APS_PORT_MASTER PORT_MASTER WHERE PORT_MASTER.ID IN"+
	    "(SELECT aps_port_master_id FROM APS_APPSENSE_POLICY  WHERE PROCESS_ID ='"+ipProcessID+"'"+
	    " AND RECORD_TYPE='A' AND aps_port_master_id is not null) "+
	    "AND PORT_MASTER.ostia_group_id is not null AND PORT_MASTER.port_lookup_id IN ("+
	    "SELECT PORT.ID FROM CON_PORT_LOOKUP PORT WHERE PORT.ID IN("+
	    "SELECT PORT_MASTER1.port_lookup_id FROM APS_PORT_MASTER PORT_MASTER1 WHERE PORT_MASTER1.ID IN"+ 
	    "(SELECT aps_port_master_id FROM APS_APPSENSE_POLICY  WHERE PROCESS_ID ='"+ipProcessID+"'"+
	    "AND RECORD_TYPE='A'AND aps_port_master_id is not null )) AND port.is_blacklisted ='Y' ))" +
	    " AND (status IS NULL OR status ='Incomplete')";

	    C3parSession c3parSession = new C3parSession();
	    connection = c3parSession.getConnection();
	    statement = connection.createStatement();

	    result = statement.executeQuery(sql);

	    while(result.next()){
		count=result.getInt(1);

	    }
	    String riskPortSQL="SELECT count(*)FROM APS_PORT_MASTER PORT_MASTER WHERE PORT_MASTER.ID IN"+
	    "(SELECT aps_port_master_id FROM APS_APPSENSE_POLICY  WHERE PROCESS_ID ='"+ipProcessID+"'"+
	    "AND RECORD_TYPE='A' AND aps_port_master_id is not null) "+
	    "AND PORT_MASTER.port_lookup_id IN (SELECT PORT.ID FROM CON_PORT_LOOKUP PORT WHERE PORT.ID IN("+
	    " SELECT PORT_MASTER1.port_lookup_id FROM APS_PORT_MASTER PORT_MASTER1 WHERE PORT_MASTER1.ID IN"+
	    "(SELECT aps_port_master_id FROM APS_APPSENSE_POLICY  WHERE PROCESS_ID ='"+ipProcessID+"'"+
	    "AND RECORD_TYPE='A'AND aps_port_master_id is not null )) AND port.is_blacklisted ='Y') AND PORT_MASTER.ostia_group_id is NULL ";

	    result = statement.executeQuery(riskPortSQL);
	    while(result.next()){
		riskPort_Count=result.getInt(1);

	    }
	    if(count>0 || riskPort_Count>0){
		isAppOstiaTabComplete = false;
	    }else{
		isAppOstiaTabComplete = true;
	    }

	}catch(Exception e){
	    log.error(e);
	}finally{
	    try{
		result.close();
		statement.close();
		connection.close();
	    }catch(Exception e){
		log.error(e);
	    }
	}

	return isAppOstiaTabComplete;
    }
  
    /**
     * Checks if is app proxy filter tab complete.
     *
     * @param ipProcessID the ip process id
     * @return true, if is app proxy filter tab complete
     */
    public boolean isAppProxyFilterTabComplete(Long ipProcessID){
	boolean isAppProxyFilterTabComplete = false;
	Connection connection = null;
	Statement statement = null;
	ResultSet result = null;

	try{
	    String manageProxy="select count(*)  from prx_proxy_filter filter where filter.proxy_inst_mst_id in" +
	    " (select id from prx_instance_master where upper(prx_instance_master.record_type)=upper('BASIC')) and "+ 
	    " process_id='"+ipProcessID+"'";
	    String manageProxyFilter=" and filter.app_id is NULL";//"select count(*) from prx_proxy_filter where process_id='"+conReqId+"'";
	    C3parSession c3parSession = new C3parSession();
	    connection=c3parSession.getConnection();
	    log.info("connection::"+connection.isClosed());
	    statement = connection.createStatement();
	    result=statement.executeQuery(manageProxy);
	    if(result.next()){
		int count=result.getInt(1);
		log.info("result is::"+result.getInt(1));
		if(count>0){
		    String sql=manageProxy+manageProxyFilter;
		    statement = connection.createStatement();
		    result=statement.executeQuery(sql);
		    if(result.next()){
			if(result.getInt(1)>0){
			    isAppProxyFilterTabComplete = false;
			    log.info("Appsense Proxy Filter present ::"+result.getInt(1)); 
			}else{
			    isAppProxyFilterTabComplete = true;
			}
		    }
		}else{
		    isAppProxyFilterTabComplete = true; 
		}
	    }
	}catch(Exception e){
	    log.error(e);
	}finally{
	    try{
		result.close();
		statement.close();
		connection.close();
	    }catch(Exception e){
		log.error(e);
	    }
	}

	return isAppProxyFilterTabComplete;
    }

}
