/**
 * 
 */
package com.citigroup.cgti.c3par.webtier.job;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.context.ApplicationContext;

import com.citigroup.cgti.c3par.soa.vc.logic.RFCServiceImpl;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author ka58098
 *
 */
public class RFCNetInfoJob implements Job{
    private static Logger log = Logger.getLogger(RFCNetInfoJob.class);
CCRBeanFactory ccrBeanFactory;
    
    {
        ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
        ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
    } 
  
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        try{
        log.info("Start job ::");
       
        ccrBeanFactory.getRfc().storeConCPFWNetInfoDetails();
        log.info("End job ::");
        }
        catch(Exception e){
            log.error("Exception occured while executing RFCNetInfoJob **********"+e.toString() );
            log.error(e,e);
        }
    }
}
