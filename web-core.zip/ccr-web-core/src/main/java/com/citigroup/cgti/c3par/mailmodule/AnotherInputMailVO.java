package com.citigroup.cgti.c3par.mailmodule;

import com.citigroup.cgti.c3par.domain.BaseMailVO;


/**
 * The Class AnotherInputMailVO.
 */
public class AnotherInputMailVO extends BaseMailVO {
    // The below variable MAY or MAY NOT be present in the passed object (depends on the template requirement)
    /** The connection name. */
    private String connectionName;

    /** The sector. */
    private String sector;

    /** The business unit. */
    private String businessUnit;

    /** The region. */
    private String region;

    /** The requester. */
    private MailRequester requester;

    /**
     * Gets the connection name.
     *
     * @return the connection name
     */
    public String getConnectionName() {
	return connectionName;
    }

    /**
     * Sets the connection name.
     *
     * @param connectionName the new connection name
     */
    public void setConnectionName(String connectionName) {
	this.connectionName = connectionName;
    }

    /**
     * Gets the requester.
     *
     * @return the requester
     */
    public MailRequester getRequester() {
	return requester;
    }

    /**
     * Sets the requester.
     *
     * @param requester the new requester
     */
    public void setRequester(MailRequester requester) {
	this.requester = requester;
    }

    /**
     * Gets the sector.
     *
     * @return the sector
     */
    public String getSector() {
	return sector;
    }

    /**
     * Sets the sector.
     *
     * @param sector the new sector
     */
    public void setSector(String sector) {
	this.sector = sector;
    }

    /**
     * Gets the business unit.
     *
     * @return the business unit
     */
    public String getBusinessUnit() {
	return businessUnit;
    }

    /**
     * Sets the business unit.
     *
     * @param businessUnit the new business unit
     */
    public void setBusinessUnit(String businessUnit) {
	this.businessUnit = businessUnit;
    }

    /**
     * Gets the region.
     *
     * @return the region
     */
    public String getRegion() {
	return region;
    }

    /**
     * Sets the region.
     *
     * @param region the new region
     */
    public void setRegion(String region) {
	this.region = region;
    }
}
