package com.citigroup.cgti.c3par.webtier.helper;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import java.lang.reflect.Method;
import org.apache.log4j.Logger;


/**
 * The Class BeanValueParser.
 */
public class BeanValueParser
{

    /** The log. */
    private static Logger log = Logger.getLogger(BeanValueParser.class);

    /**
     * Bean2 list.
     *
     * @param bean the bean
     * @param props the props
     * @return the list
     */
    static public List bean2List(Object bean, List props)
    {
	List values = new ArrayList(props.size());
	Iterator iter = props.iterator();

	try
	{
	    while(iter.hasNext())
	    {
		String prop_chain = (String)iter.next();			
		String bean_props[] = prop_chain.split("\\x2e");
		Object obj = bean;
		String bean_prop;
		String getter;
		Object value = null;

		for(int i = 0; i < bean_props.length && obj != null; ++i)
		{
		    bean_prop = bean_props[i];
		    getter = "get" + Character.toUpperCase(bean_prop.charAt(0)) + bean_prop.substring(1);


		    Method m = obj.getClass().getMethod(getter, null);
		    obj = m.invoke(obj, null);
		}

		/*				
				if(obj != null)
				{
//					value = obj.toString();
					value = obj;
					if(obj instanceof Boolean)
					{
						if(((Boolean)obj).booleanValue())
						{
							value = new String("Yes");							
						}
						else
						{
							value = new String("No");							
						}
					}
				}

				values.add(value);
		 */
		values.add(obj);
	    }
	}
	catch(Exception e)
	{
	    log.error(e);
	}
	return values;
    }
}
