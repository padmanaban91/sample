package com.citigroup.cgti.c3par.firemonpoc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FiremonController {
	private String url;
	private String jsonInputString;
	private String queryParameters;
	
	String firemonURL = "https://fusmwdc-fmon01-620es.nam.nsroot.net/securitymanager/api/domain/";

	Logger log = Logger.getLogger(FiremonController.class);
	
	
	@RequestMapping(value = "/domain.act",method = {
			RequestMethod.GET, RequestMethod.POST })
	public ModelAndView printWelcome() {
		ModelAndView model = new ModelAndView();
		model.setViewName("/pages/jsp/test/FiremonPOC");
		return model;
	}
	
	
	@RequestMapping(value = "/domain/{domainId}/devicegroup.act", method = {
			RequestMethod.GET}, produces="application/json")
	@ResponseBody
	public String getDeviceGroups(@PathVariable("domainId") String domainId) throws Exception {
		log.debug("calling get method now...");
		String returnedstring="";
		StringBuffer sb = new StringBuffer();

		try {
			java.net.URL urlObj = new java.net.URL(firemonURL + domainId
					+ "/devicegroup?page=0&pageSize=50");
			
			HttpsURLConnection conn = this.connect(urlObj, "GET");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			log.debug("Output from Server .... \n");
			while ((returnedstring = br.readLine()) != null) {
				sb.append(returnedstring);
				log.debug("**********returnedstring="+returnedstring);
			}

			conn.disconnect();

		} catch (MalformedURLException e) {
			e.printStackTrace();
	  } catch (IOException e) {
		log.error(e);
	  }
		return  sb.toString();
	}
	
	@RequestMapping(value = "/domain/{domainId}/devicegroup/{id}/device.act", method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public String getDevicesForGroup(@PathVariable("domainId") String domainId, 
			@PathVariable("id") String deviceGroupId) throws Exception {
		log.debug("calling get method now...");
		String returnedstring="";
		StringBuffer sb = new StringBuffer();

		try {
			java.net.URL urlObj = new java.net.URL(firemonURL + domainId
					+ "/devicegroup/"+deviceGroupId+"/device?page=0&pageSize=10");
			
			HttpsURLConnection conn = this.connect(urlObj, "GET");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			log.debug("Output from Server .... \n");
			while ((returnedstring = br.readLine()) != null) {
				sb.append(returnedstring);
				log.debug("**********returnedstring="+returnedstring);
			}

			conn.disconnect();

		} catch (MalformedURLException e) {
			e.printStackTrace();
	  } catch (IOException e) {
		log.error(e);
	  }
		return  sb.toString();
	}

	@RequestMapping(value = "/domain/{domainId}/devicegroup/addnew.act", method = RequestMethod.POST, produces="application/json")
	@ResponseBody
	public String addDeviceGroupToDomain(@PathVariable("domainId") String domainId, 
			@RequestParam(value="jsonInputString", required = false) String jsonInputString) throws Exception {

		log.debug("calling post method now...");
		StringBuffer sb = new StringBuffer();
		String returnedstring = "";
		
		HttpsURLConnection con = this.connect(new URL(firemonURL+domainId+"/devicegroup"), "POST");

		OutputStreamWriter out = new OutputStreamWriter(con.getOutputStream());
		out.write(jsonInputString);
		out.close();
		int status = con.getResponseCode();
		log.debug("Firemon Response Status -->" + status);
		InputStream in = null;
		if (status >= HttpStatus.SC_BAD_REQUEST)
			in = con.getErrorStream();
		else
			in = con.getInputStream();

		System.out.println(con);
		byte[] b = new byte[in.available()];
		in.read(b);
		
		
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(con.getInputStream())));

		log.debug("Output from Server .... \n");
		while ((returnedstring = br.readLine()) != null) {
			sb.append(returnedstring);
			log.debug("**********returnedstring="+returnedstring);
		}
		con.disconnect();
		
		log.debug("Server response="+sb.toString());

		log.debug("jsonInputString -->" + jsonInputString);
		log.debug("queryParameters -->" + queryParameters);

		return sb.toString();

	}

	/*
	 * The is the common method to open an new http connection to connect to the
	 * firemon serve. Currently, we are bypassingt he hostname verification and
	 * so no certificate is required for now. In setDomainEnv.sh we are setting
	 * -DhttpProtocol=TLSv1 for successful handshake at JVM level.
	 * 
	 * It just needs the Rest API url and the requestMethod (GET,PUT or POST) to
	 * open the connection.
	 */

	private HttpsURLConnection connect(URL url, String requestMethod) {

		HttpsURLConnection con = null;
		try {

			// Create a context that doesn't check certificates.
			SSLContext ssl_ctx = SSLContext.getInstance("TLS");

			// get the trust manager and initialize context
			TrustManager[] trust_mgr = get_trust_mgr();
			ssl_ctx.init(null, // key manager
					trust_mgr, // trust manager
					new SecureRandom()); // random number generator

			// create a https url connection using the TLS context
			HttpsURLConnection.setDefaultSSLSocketFactory(ssl_ctx
					.getSocketFactory());
			// Open the URL connection
			con = (HttpsURLConnection) url.openConnection();
			if(con == null){
				log.debug("Connection object returned is null");
			}
			con.setRequestProperty("Accept", "application/json");

			// Guard against "bad hostname" errors during handshake.
			con.setHostnameVerifier(new HostnameVerifier() {
				public boolean verify(String host, SSLSession sess) {
					if (host.equals("karina.eur.nsroot.net"))
						return true;
					else
						return false;
				}
			});
			// pass the username and password
			String userpass = "firemon" + ":" + "C1t!Fir3moN";
			String basicAuth = "Basic "
					+ new String(new Base64().encode(userpass.getBytes()));
			con.setRequestProperty("Authorization", basicAuth);
			// Content type set to JSON
			con.setRequestProperty("Content-Type",
					"application/json; charset=utf-8");
			con.setRequestProperty("Accept", "application/json");
			con.setDoOutput(true);
			con.setRequestMethod(requestMethod);
			con.connect();

		} catch (Exception e) {
			log.error("failed to get connection", e);
		}
		return con;
	}

	private static TrustManager[] get_trust_mgr() {
		TrustManager[] certs = new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String t) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String t) {
			}
		} };
		return certs;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getJsonInputString() {
		return jsonInputString;
	}

	public void setJsonInputString(String jsonInputString) {
		this.jsonInputString = jsonInputString;
	}

	public String getQueryParameters() {
		return queryParameters;
	}

	public void setQueryParameters(String queryParameters) {
		this.queryParameters = queryParameters;
	}
	
}
