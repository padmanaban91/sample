package com.citigroup.cgti.c3par.controller.relationship;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.relationship.domain.SearchRelationshipProcess;

@Controller
public class SearchRelationshipPopUpController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@RequestMapping(value = "/searchRelationshipForPopup.act", method = { RequestMethod.GET, RequestMethod.POST})
	 public String searchRelationshipForPopup(HttpServletRequest request, @ModelAttribute("searchRelProcess") SearchRelationshipProcess searchRelProcess,ModelMap model) {
	    	log.info("SearchRelationshipController :: searchRelationshipForPopup ::  starts...");
	    	
	    	int offSet = 0;
	    	String result = "pages/relationship/SearchRelationshipPopup";
	    	String relationshipId = null;
	    	String relationshipName = null;
	    	String relationshipType = null;
	    	String status = null;
	    	String createdBy = null;
	    	String type = null;
	    	String oldRelationshipID = null;
	    	
	    	oldRelationshipID = request.getParameter("oldRelationshipID");

	    	if (searchRelProcess != null) {
	    		relationshipId = searchRelProcess.getRelationshipId();
	    		offSet = searchRelProcess.getOffset();
	    		relationshipName = searchRelProcess.getRelationshipName();
	    		status = searchRelProcess.getStatus();
	    		relationshipType = searchRelProcess.getRelationshipType();
	    		createdBy = searchRelProcess.getCreatedBy();
	    		type = (String)request.getParameter("type");
	    		
	    		if ("N".equalsIgnoreCase(type)) {
	        		offSet = offSet+10;
	        	} else if ("P".equalsIgnoreCase(type)) {
	        		offSet = offSet-10;
	        	}
	    		log.info("SearchRelationshipController :: searchRelationshipForPopup :: type - "+type+" :: offSet - "+offSet);
	    	}
	    	log.debug("SearchRelationshipController :: searchRelationshipForPopup :: oldRelationshipID ==> "+oldRelationshipID);
		    searchRelProcess = new SearchRelationshipProcess();
		    searchRelProcess.setRelationshipId(relationshipId);
		    searchRelProcess.setOffset(offSet);
		    searchRelProcess.setLimit(10);
		    searchRelProcess.setRelationshipName(relationshipName);
		    searchRelProcess.setStatus(status);
		    searchRelProcess.setRelationshipType(relationshipType);
		    searchRelProcess.setCreatedBy(createdBy);
		    searchRelProcess.setOldRelationshipId(oldRelationshipID);
		    
		    List<RelationshipDTO> relationships = searchRelProcess.getRelationshipList();
		    
		    if(relationships != null && relationships.isEmpty() == false && relationships.size() > 0){
		    	RelationshipDTO dto = relationships.get(0);
		    	searchRelProcess.setRelationshipType(dto.getType());
		    	searchRelProcess.setStatus(dto.getStatus());
		    }
		    
		    searchRelProcess.setRelationships(relationships);
		    
		    log.info("SearchRelationshipController :: searchRelationshipForPopup :: ends...");

			model.addAttribute("searchRelProcess",searchRelProcess);
			
			return result;
	    }	 
}
