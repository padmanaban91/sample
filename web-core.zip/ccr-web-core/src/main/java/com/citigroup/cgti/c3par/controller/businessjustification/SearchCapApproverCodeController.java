package com.citigroup.cgti.c3par.controller.businessjustification;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.bpm.ejb.vc.ManageRFCImpl;
import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.util.PeopleRecord;

@Controller
public class SearchCapApproverCodeController {

	/** The log. */
	private Logger log = Logger.getLogger(this.getClass().getName());

	@Autowired
    private ManageRFCImpl cabApproverManageRFC;
	
	@RequestMapping(value = "/getCapApproverCodeList.act", method = { RequestMethod.GET,RequestMethod.POST })
	public String getCapApproverCodeList(HttpServletRequest request, @ModelAttribute("busjusProcess") BusinessJustificationProcess busjusProcess, ModelMap model) {
		try {
			log.debug("SearchCapApproverCodeController :: getCapApproverCodeList :: starts ");
			String action = request.getParameter("action");

			busjusProcess = new BusinessJustificationProcess();	
			
			if(action != null && action.equalsIgnoreCase("search")){
				request.getSession().removeAttribute("ERRORMSG");
				request.getSession().removeAttribute("CAB_APPRV_CODE");
				
				String approverGroupName = request.getParameter("approverGroupName");
				if(approverGroupName == null || approverGroupName.isEmpty()){
					approverGroupName = "";
				}
				Map<String, String> cabApprvRespose = null;			
				if(cabApproverManageRFC != null){
					cabApprvRespose = cabApproverManageRFC.getCabApproverCode(approverGroupName.trim());
				}
				
				List<PeopleRecord> peopleRecList = new ArrayList<PeopleRecord>();
				PeopleRecord peopleRecord = null;
				if (cabApprvRespose != null && !cabApprvRespose.containsKey("ERRORMSG")) {
					Set<String> keySet = cabApprvRespose.keySet();
					for (Iterator<String> iterator = keySet.iterator(); iterator.hasNext();) {
						String key = iterator.next();
						peopleRecord = new PeopleRecord();
						peopleRecord.setSoeid(key);
						peopleRecord.setInfoManName(cabApprvRespose.get(key));
						peopleRecList.add(peopleRecord);
					}
					busjusProcess.setCapApproverCodeList(peopleRecList);
				} else if (cabApprvRespose.containsKey("ERRORMSG")) {
					//addActionError((String) cabApprvRespose.get("ERRORMSG"));
					request.setAttribute("getCapApproverCode_ErrMsg", (String) cabApprvRespose.get("ERRORMSG"));
				}
			}
			model.addAttribute("busjusProcess",busjusProcess);
		} catch (Exception e) {
			log.error(e, e);
			//addActionError(e.toString());
		}
		return "pages/businessjustification/SearchCapApproverCode";
	}

	@RequestMapping(value = "/selectCapApproverCode.act", method = { RequestMethod.GET,RequestMethod.POST })
	public String selectCapApproverCode(HttpServletRequest request,ModelMap model) {
		try {
			String selectedGroupId = request.getParameter("selectedGroupId");
			log.debug("SearchCapApproverCodeController :: selectCapApproverCode :: selectedGroupId :: "+ selectedGroupId);
			request.getSession().removeAttribute("ERRORMSG");
			request.getSession().setAttribute("CAB_APPRV_CODE", selectedGroupId);
		} catch (Exception e) {
			log.error(e, e);
			//addActionError(e.toString());
		}
		return "pages/common/SearchPopupCloser";
	}
}
