package com.citigroup.cgti.c3par.dashboard.webtier.helper;

import java.sql.ResultSet;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.citigroup.cgti.c3par.dao.CitiResourceDAO;
import com.citigroup.cgti.c3par.model.CitiResourceEntity;
import com.citigroup.cgti.c3par.webtier.helper.FieldValidator;
import com.mentisys.dao.AccessObject;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;


/**
 * The Class SearchCitiResource.
 */
public class SearchCitiResource extends AccessObject
{

    /** The user id. */
    private Long userId;

    /** The group id. */
    private Long groupId;

    /** The is admin. */
    private boolean isAdmin;

    /**
     * Instantiates a new search citi resource.
     *
     * @param session the session
     * @param rsession the rsession
     */
    public SearchCitiResource(DatabaseSession session, HttpSession rsession)
    {
	super(session);
	isAdmin = CommonCode.isAdmin(rsession);
    }
    /* ENTITLEMENT remove groupID from constructor  */
    /*public SearchCitiResource(DatabaseSession session, boolean isAdmin, Long groupId)
	{
		super(session);
		this.isAdmin = isAdmin;
		this.groupId = groupId;
	}*/

    /**
     * Instantiates a new search citi resource.
     *
     * @param session the session
     * @param isAdmin the is admin
     */
    public SearchCitiResource(DatabaseSession session, boolean isAdmin)
    {
	super(session);
	this.isAdmin = isAdmin;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#loadModelReferences(java.lang.Object)
     */
    protected void loadModelReferences(Object obj)
    throws DatabaseException
    {}

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#createModel(java.sql.ResultSet)
     */
    protected Object createModel(ResultSet rs)
    throws DatabaseException
    {
	CitiResourceEntity resourceEntity = new CitiResourceEntity();
	resourceEntity.setReferencesLoaded(false);
	resourceEntity.setId(getLongFromResultSet(rs, CitiResourceDAO.COLUMN_ID));
	resourceEntity.setPrimaryKey(resourceEntity.getId());
	resourceEntity.setName(getStringFromResultSet(rs, CitiResourceDAO.COLUMN_NAME));
	resourceEntity.setIpAddress(getStringFromResultSet(rs, CitiResourceDAO.COLUMN_IPADDRESS));
	resourceEntity.setUrl(getStringFromResultSet(rs, CitiResourceDAO.COLUMN_URL));
	resourceEntity.setDnsName(getStringFromResultSet(rs, CitiResourceDAO.COLUMN_DNSNAME));
	resourceEntity.setCriticality(CommonCode.getFromLookup(getLongFromResultSet(rs, CitiResourceDAO.COLUMN_CRITICALITY_ID)));
	resourceEntity.setClassification(CommonCode.getFromLookup(getLongFromResultSet(rs, CitiResourceDAO.COLUMN_CLASSIFICATION_ID)));
	resourceEntity.setAccessType(CommonCode.getFromLookup(getLongFromResultSet(rs, CitiResourceDAO.COLUMN_ACCESSTYPE_ID)));
	resourceEntity.setCwhiId(getLongFromResultSet(rs, CitiResourceDAO.COLUMN_CWHIID));
	return resourceEntity;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	String stmt = null;

	stmt = "SELECT DISTINCT  "
	    + getQualifiedColumnName(CitiResourceDAO.TABLE, CitiResourceDAO.COLUMN_ID, true)
	    + getQualifiedColumnName(CitiResourceDAO.TABLE, CitiResourceDAO.COLUMN_NAME, true)
	    + getQualifiedColumnName(CitiResourceDAO.TABLE, CitiResourceDAO.COLUMN_IPADDRESS, true)
	    + getQualifiedColumnName(CitiResourceDAO.TABLE, CitiResourceDAO.COLUMN_URL, true)
	    + getQualifiedColumnName(CitiResourceDAO.TABLE, CitiResourceDAO.COLUMN_DNSNAME, true)
	    + getQualifiedColumnName(CitiResourceDAO.TABLE, CitiResourceDAO.COLUMN_CRITICALITY_ID, true)
	    + getQualifiedColumnName(CitiResourceDAO.TABLE, CitiResourceDAO.COLUMN_CLASSIFICATION_ID, true)
	    + getQualifiedColumnName(CitiResourceDAO.TABLE, CitiResourceDAO.COLUMN_CWHIID, true)
	    + getQualifiedColumnName(CitiResourceDAO.TABLE, CitiResourceDAO.COLUMN_ACCESSTYPE_ID, false);

	stmt = stmt + getFromClause(new String[]{CitiResourceDAO.TABLE});

	return stmt;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getWhereExpression(com.mentisys.dao.query.Condition)
     */
    protected String getWhereExpression(Condition c)
    {
	StringBuffer buf = new StringBuffer();
	buf.append(c.getWhereExpression());

	return buf.toString();
    }


    /**
     * Run query.
     *
     * @param resourceName the resource name
     * @param resourceId the resource id
     * @param userId the user id
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List runQuery(String resourceName, String resourceId, Long userId)
    throws DatabaseException
    {
	Condition condition = new Condition();
	if (FieldValidator.isValidString(resourceName)) {
	    OperatorExpression resourceNameLike =
		new OperatorExpression(CitiResourceDAO.COLUMN_NAME, Operator.LIKE, resourceName.trim());
	    condition.addExpression(resourceNameLike);
	}

	if (FieldValidator.isValidString(resourceId)) {
	    OperatorExpression resourceIdLike =
		new OperatorExpression(CitiResourceDAO.COLUMN_RESOURCEID, Operator.LIKE, resourceId.trim());
	    condition.addExpression(resourceIdLike);
	}

	this.userId = userId;

	condition.addOrderByField("UPPER(" + CitiResourceDAO.COLUMN_NAME + ")");
	return query(condition, false);
    }
}
