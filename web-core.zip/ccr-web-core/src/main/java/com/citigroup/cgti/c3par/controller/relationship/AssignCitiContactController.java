package com.citigroup.cgti.c3par.controller.relationship;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityErrors;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.relationship.domain.AssignCitiContactProcess;
import com.citigroup.cgti.c3par.relationship.domain.RelCitiContXref;
import com.citigroup.cgti.c3par.relationship.domain.RelReqCitiContactXref;
import com.citigroup.cgti.c3par.relationship.domain.RelationshipProcess;
import com.citigroup.cgti.c3par.validator.relationship.RoleInfoValidator;

@Controller
public class AssignCitiContactController extends RelationshipBaseController{

	private static Logger log = Logger.getLogger(AssignCitiContactController.class);

	@RequestMapping(value = "/populateCitiContacts.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String populateCitiContacts(ModelMap model, @ModelAttribute("assignCitiContactProcess") AssignCitiContactProcess assignCitiContactProcess, HttpServletRequest request) {
		log.debug("AssignCitiContactController :: populateCitiContact :: Method Starts");
		
		String assignTo = request.getParameter("assignTo");
		
		if (assignTo != null && !assignTo.isEmpty()) {
			request.getSession().setAttribute("CITI_CONTACT_ASSIGN_TO",	assignTo);
		}	
		log.debug("AssignCitiContactController :: populateCitiContacts :: assignTo - "+assignTo);
		
		RelationshipProcess relprocess = getRelationshipProcess(request);
		
		assignCitiContactProcess.setCanEdit(relprocess.isCanEdit());
		assignCitiContactProcess.setRelCitiContXrefList(relprocess.getRelCitiContXrefList());
		assignCitiContactProcess.setRelReqCitiContactXrefList(relprocess.getRelReqCitiContactXrefList());
		assignCitiContactProcess.setRelationshipName(relprocess.getRelationship().getName());
		assignCitiContactProcess.setBusinessUnitName(relprocess.getBusinessUnit().getBusinessName());
		assignCitiContactProcess.setSectorName(relprocess.getSector().getName());
		
		model.addAttribute("assignCitiContactProcess",assignCitiContactProcess);

		return "pages/relationship/AssignCitiContacts";
	}

	@RequestMapping(value = "/assignCitiContacts.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String assignCitiContacts(ModelMap model, @ModelAttribute("assignCitiContactProcess") AssignCitiContactProcess assignCitiContactProcess
										,BindingResult result,HttpServletRequest request) {
		log.debug("AssignCitiContactController :: assignCitiContacts :: Method Starts");
		
		String assignTo = (String) request.getSession().getAttribute("CITI_CONTACT_ASSIGN_TO");	
		RelationshipProcess relprocess = getRelationshipProcess(request);
		
		log.debug("AssignCitiContactController :: assignTo - "+assignTo);
		RoleInfoValidator validator = new RoleInfoValidator();
		
		if (assignTo != null && !assignTo.isEmpty() && !"null".equalsIgnoreCase(assignTo)) {

			if ("requester".equalsIgnoreCase(assignTo)) {
				List<RelReqCitiContactXref> relReqCitiContactList = new ArrayList<RelReqCitiContactXref>();
				//add old contacts into validator for duplicate check
				if(relprocess.getRelReqCitiContactXrefList() != null && !relprocess.getRelReqCitiContactXrefList().isEmpty()){
					for(RelReqCitiContactXref existingContact:relprocess.getRelReqCitiContactXrefList()){
						CitiContact citicont = assignCitiContactProcess.getCitiContact(existingContact.getContactId().getSsoId());
						validator.validateContactRole(citicont.getId(), existingContact.getRole().getId());
				
						log.debug("AssignCitiContactController :: assignCitiContacts :: existingContact :: getContactId "+citicont.getId());
						log.debug("AssignCitiContactController :: assignCitiContacts :: existingContact :: getRole "+existingContact.getRole().getId());
					}
					relReqCitiContactList = relprocess.getRelReqCitiContactXrefList();
				}
				
				CitiContact sessionCitiContact = (CitiContact) request.getSession().getAttribute("RITS_CITI_CONTACT_ENTITY");
				if(sessionCitiContact != null){				
					CitiContact citiContact = assignCitiContactProcess.getCitiContact(sessionCitiContact);
					
					if(citiContact != null){
						String[] roleIds = (String[]) request.getSession().getAttribute("CITI_CONTACT_ROLEID");				
						if(roleIds != null && roleIds.length > 0){
							boolean isDuplicate = false;
							List<RelReqCitiContactXref> newRelReqCitiContactList = new ArrayList<RelReqCitiContactXref>();
							for (String roldId:roleIds) {					
								log.debug("AssignCitiContactController :: requester roldId - "+roldId);
								
								Role role = assignCitiContactProcess.getRole(Long.parseLong(roldId));
						   		if(role != null && "ISO".equals(role.getDisplayName())){
							   	    boolean isExist = assignCitiContactProcess.validateISOContact(citiContact.getSsoId());   		
							   		  	  
							   		log.debug("ISOValidation::isExist: "+isExist); 
							   		  
							   		 if(!isExist){
							   			result.addError(new ObjectError("ISOValidationError",new String[]{SubmitActivityErrors.BJ_ISO_CONTACTS_LIST},null,null));
							   			isDuplicate = true;
										break;
							   		 } 
						   		} 
						   		
								if(validator.validateContactRole(citiContact.getId(), Long.parseLong(roldId))){
									RelReqCitiContactXref relCitiContactXref = new RelReqCitiContactXref();
									
									relCitiContactXref.setRole(role);
									relCitiContactXref.setContactId(citiContact);
									newRelReqCitiContactList.add(relCitiContactXref);
								}else{
									result.addError(new ObjectError("citiContact", "The relationship contains duplicate entries for a Citi contacts (i.e. Contact and Role are same)."));
									isDuplicate = true;
									break;
								}
							}
							if(!isDuplicate){
								relReqCitiContactList.addAll(newRelReqCitiContactList);
							}
						}
					}
				}
				log.debug("AssignCitiContactController :: requester relReqCitiContactList - "+relReqCitiContactList.size());
				
				assignCitiContactProcess.setRelReqCitiContactXrefList(relReqCitiContactList);
				relprocess.setRelReqCitiContactXrefList(relReqCitiContactList);
				
			} else if ("target".equalsIgnoreCase(assignTo)){
				List<RelCitiContXref> relCitiContXrefList = new ArrayList<RelCitiContXref>();
				//add existing contacts into validator for duplicate check
				if(relprocess.getRelCitiContXrefList() != null && !relprocess.getRelCitiContXrefList().isEmpty()){
					for(RelCitiContXref existingContact:relprocess.getRelCitiContXrefList()){
						CitiContact citicont = assignCitiContactProcess.getCitiContact(existingContact.getContactId().getSsoId());
						validator.validateContactRole(citicont.getId(), existingContact.getRole().getId());
						
						log.debug("AssignCitiContactController :: assignCitiContacts :: target existingContact :: getContactId "+citicont.getId());
						log.debug("AssignCitiContactController :: assignCitiContacts :: target existingContact :: getRole "+existingContact.getRole().getId());
					}
					relCitiContXrefList = relprocess.getRelCitiContXrefList();
				}
				CitiContact sessionCitiContact = (CitiContact) request.getSession().getAttribute("RITS_CITI_CONTACT_ENTITY");
				
				if(sessionCitiContact != null){		
					CitiContact citiContact = assignCitiContactProcess.getCitiContact(sessionCitiContact);
					
					if(citiContact != null){
						String[] roleIds = (String[]) request.getSession().getAttribute("CITI_CONTACT_ROLEID");
						
						if(roleIds != null && roleIds.length > 0){
							boolean isDuplicate = false;
							List<RelCitiContXref> newRelCitiContXrefList = new ArrayList<RelCitiContXref>();	
							for (String roldId:roleIds) {							
								log.debug("AssignCitiContactController :: target roldId - "+roldId);

								Role role = assignCitiContactProcess.getRole(Long.parseLong(roldId));
						   		if(role != null && "ISO".equals(role.getDisplayName())){
							   	    boolean isExist = assignCitiContactProcess.validateISOContact(citiContact.getSsoId());   		
							   		  	  
							   		log.debug("ISOValidation::isExist: "+isExist); 
							   		  
							   		 if(!isExist){
							   			result.addError(new ObjectError("ISOValidationError",new String[]{SubmitActivityErrors.BJ_ISO_CONTACTS_LIST},null,null));
							   			isDuplicate = true;
										break;
							   		 } 
						   		} 
						   		
								if(validator.validateContactRole(citiContact.getId(), Long.parseLong(roldId))){
									RelCitiContXref citiContactXref = new RelCitiContXref();
											
									citiContactXref.setRole(role);
									citiContactXref.setContactId(citiContact);
									newRelCitiContXrefList.add(citiContactXref);
								}else{
									result.addError(new ObjectError("citiContact", "The relationship contains duplicate entries for a Citi contacts (i.e. Contact and Role are same)."));
									isDuplicate = true;
									break;
								}
							}
							if(!isDuplicate){
								relCitiContXrefList.addAll(newRelCitiContXrefList);
							}
						}
					}
				}
				log.debug("AssignCitiContactController :: target relCitiContXrefList - "+relCitiContXrefList.size());
				
				assignCitiContactProcess.setRelCitiContXrefList(relCitiContXrefList);
				relprocess.setRelCitiContXrefList(relCitiContXrefList);
			}
		}		
		request.getSession().removeAttribute("RITS_CITI_CONTACT_ENTITY");
		request.getSession().removeAttribute("CITI_CONTACT_ROLEID");
		
		model.addAttribute("assignCitiContactProcess",assignCitiContactProcess);
		setInSession(request, relprocess);
		
		return "pages/relationship/AssignCitiContacts";
	}

	@RequestMapping(value = "/unAssignCitiContacts.act", method = { RequestMethod.GET, RequestMethod.POST})
	public String unAssignCitiContacts(ModelMap model,@ModelAttribute("assignCitiContactProcess") AssignCitiContactProcess assignCitiContactProcess,HttpServletRequest request) {
		log.debug("AssignCitiContactController :: unAssignCitiContacts :: Method Starts");

		RelationshipProcess relprocess = getRelationshipProcess(request);
		String assignTo = (String) request.getSession().getAttribute("CITI_CONTACT_ASSIGN_TO");

		log.debug("AssignCitiContactController :: assignTo - "+assignTo);
		
		if (assignTo != null && !assignTo.isEmpty()) {
			int indexId = 0;
			
			if ("requester".equalsIgnoreCase(assignTo)) {			
				List<RelReqCitiContactXref> relReqCitiContactList = relprocess.getRelReqCitiContactXrefList();
				
				String[] seletedContactIds = assignCitiContactProcess.getUnSelected();
				if(seletedContactIds != null &&  seletedContactIds.length > 0){
					int count = 0;
					for (String contactId : seletedContactIds) {					
						log.debug("AssignCitiContactController :: unAssignCitiContacts ::requester contactId - "+contactId);
						
						indexId = Integer.valueOf(contactId);
						relReqCitiContactList.remove(indexId-count);
						count++;
					}
				}
				assignCitiContactProcess.setRelReqCitiContactXrefList(relReqCitiContactList);
				relprocess.setRelReqCitiContactXrefList(relReqCitiContactList);
				model.addAttribute("assignCitiContactProcess",	assignCitiContactProcess);
			} else if ("target".equalsIgnoreCase(assignTo)){
				List<RelCitiContXref> relCitiContXrefList = relprocess.getRelCitiContXrefList();
				
				String[] seletedContactIds = assignCitiContactProcess.getUnSelected();
				if(seletedContactIds != null &&  seletedContactIds.length > 0){
					int count = 0;
					for (String contactId : seletedContactIds) {					
						log.debug("AssignCitiContactController ::target unAssignCitiContacts ::contactId - "+contactId);
						
						indexId = Integer.valueOf(contactId);
						relCitiContXrefList.remove(indexId-count);
						count++;
					}
				}
				assignCitiContactProcess.setRelCitiContXrefList(relCitiContXrefList);
				relprocess.setRelCitiContXrefList(relCitiContXrefList);
				model.addAttribute("assignCitiContactProcess",assignCitiContactProcess);
			}
		}
		assignCitiContactProcess.setUnSelected(null);
		setInSession(request, relprocess);
		
		return "pages/relationship/AssignCitiContacts";
	}

}
