package com.citigroup.cgti.c3par.mailmodule.action;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.mailmodule.IncomingMessage;

public class TechnicalCoordinatorRejectAction extends MailAction {

Logger log = Logger.getLogger(TechnicalCoordinatorRejectAction.class);
	
private final static String ROLE_NAME = "DESIGN ENGINEER";

	@Override
	public void process(IncomingMessage message) {
		
		log.info("Inside TechnicalCoordinatorRejectAction process method ");
		
		super.processReject(message,ROLE_NAME);
		
	}
}
