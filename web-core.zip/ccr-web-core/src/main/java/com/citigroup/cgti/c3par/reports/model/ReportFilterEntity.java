/*
 * Created on Jun 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.reports.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

import java.util.List;

import com.citigroup.cgti.c3par.reports.reportInterface.ReportException;
import com.citigroup.cgti.c3par.reports.util.Util;


/**
 * The Class ReportFilterEntity.
 *
 * @author MphasiS
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ReportFilterEntity  implements Serializable{

    /** The report inner filters. */
    private List reportInnerFilters;

    /** The condition. */
    private List condition;
    //	private Util util;

    /**
     * Instantiates a new report filter entity.
     */
    public ReportFilterEntity(){
	//		util = new Util();
    }



    /**
     * Gets the condition.
     *
     * @return Returns the condition.
     */
    public List getCondition() {
	return condition;
    }

    /**
     * Sets the condition.
     *
     * @param condition The condition to set.
     */
    public void setCondition(List condition) {
	this.condition = condition;
    }

    /**
     * Gets the report inner filters.
     *
     * @return Returns the reportInnerFilters.
     */
    public List getReportInnerFilters() {
	return reportInnerFilters;
    }

    /**
     * Sets the report inner filters.
     *
     * @param reportInnerFilters The reportInnerFilters to set.
     */
    public void setReportInnerFilters(List reportInnerFilters) {
	this.reportInnerFilters = reportInnerFilters;
    }
}
