package com.citigroup.cgti.c3par.gdw;

public class CCR_GDW_Queries {
	
	public static final String CCR_SOE_IDS_QUERY = "SELECT upper(sso_id) sso_id FROM c3par.CITI_CONTACT group by upper(sso_id) having upper(sso_id) is not null";
	
	public static final String GDW_SELECT_QUERY = "SELECT  EMP.SOEID,EMP.EMPLOYEE_STATUS,EMP.SUPERVISOR_GEID managerGEID,emp.BO_EMP_TERM_DATE employee_termination_date,MGR.email managerEmail,emp.GEID employeeGEID, 'UPDATE C3PAR.CITI_CONTACT SET EMPLOYEE_STATUS='''||EMP.EMPLOYEE_STATUS||''''||' , SUPERVISOR_GEID='''||EMP.SUPERVISOR_GEID||''''    ||', EMPLOYEE_TERMINATION_DATE='''||emp.BO_EMP_TERM_DATE||''''||', supervisor_email='''||MGR.email||''', GEID='''||emp.GEID||''' WHERE UPPER(SSO_ID)=UPPER('''|| EMP.SOEID||''');' updateStmt    FROM rdspr.gdw_user EMP, rdspr.gdw_user MGR    WHERE    EMP.SUPERVISOR_GEID=MGR.GEID(+) AND UPPER(EMP.SOEID) IN(   ";
	
	public static final String CCR_UPDATE_QUERY = "UPDATE C3PAR.CITI_CONTACT SET EMPLOYEE_STATUS=? , SUPERVISOR_GEID=?, EMPLOYEE_TERMINATION_DATE=to_date(substr(?,1,instr(?,'.')-1),'RRRR-MM-DD HH24:MI;SS'), supervisor_email=?, GEID=?,updated_date=sysdate, LATEST_SUPERVISOR_GEID=? WHERE UPPER(SSO_ID)=UPPER(?)";
	
	private static StringBuilder sb_CCR_SUPERVISOR_GEID_QUERY = new StringBuilder();
	
	public static final String CCR_SUPERVISOR_GEID_QUERY = getSelectedSupervisorGEIDQuery().toString();
	
	public static final String GDW_SELECT_FOR_CCR_INSERT_QUERY = getSelectedGDWRecords().toString();
	
	public static final String CCR_DYNAMIC_INSERT_QUERY = getDynamicCCRInsert().toString();
	
	public static final String CCR_CITI_CONTACT_XREF_UPDATES_PROC = "{call c3par.UPDATE_CITI_CONTACT_XREFS}";
	
	private static StringBuilder dynamicUpdate = new StringBuilder();
	
	private static StringBuilder getDynamicCCRInsert()
	{
		dynamicUpdate = new StringBuilder();
		dynamicUpdate.append("INSERT INTO C3PAR.CITI_CONTACT(ID,FIRST_NAME,LAST_NAME,RITS_ID,EMAIL,SSO_ID,EMPLOYEE_TYPE,GEID,EMPLOYEE_STATUS,SUPERVISOR_GEID,");
		dynamicUpdate.append("EMPLOYEE_TERMINATION_DATE,LATEST_SUPERVISOR_GEID,CREATED_DATE) ");
		dynamicUpdate.append("SELECT c3par.seq_CITI_CONTACT.nextval,?,?,?,?,?,?,?,?,?,to_date(substr(?,1,instr(?,'.')-1),'RRRR-MM-DD HH24:MI;SS'),?,sysdate FROM DUAL WHERE NOT EXISTS(SELECT 1 FROM C3PAR.CITI_CONTACT where sso_id=UPPER(?))");
		return dynamicUpdate;
	}
	
	private static StringBuilder constantBuild = new StringBuilder();
	
	public static StringBuilder getGDWRecords()
	{
		return getSelectedGDWRecords();
	}
	
	private static StringBuilder getSelectedGDWRecords()
	{
		constantBuild = new StringBuilder();
		constantBuild.append("SELECT  ");
		constantBuild.append("GEID, EMPLOYEE_CLASS, EMPLOYEE_CLASS_DESC, EMPLOYEE_STATUS, EMPLOYEE_STATUS_DESC, FIRSTNAME, MIDDLENAME, LASTNAME, NAME_PREFIX, LOCATION_CODE, EXPENSE_CODE, PHONE, FAX, DEPARTMENT_CODE, DEPARTMENT_NAME, DEPT_MGR_GEID, EMAIL, JOB_CODE, JOB_TTL, RITS_ID, PRIMARY_LOGINID, SOEID, TERMINATIONDATE, LASTUPDATETM, EFFDATE, PENDING_HIRE_INDICATOR, HRGEN_GEID, SSID, OFFICER_TITLE_CD, BUILDING, BLDG_FLOOR, BLDG_ZONE, PAGER, RITS_EMPL_TYPE_CODE, RITS_EMPL_TYPE_CODE_DESC, RITS_EMPL_STATUS_CODE, RITS_EMPL_STATUS_CODE_DESC, SUFFIX, COUNTRY, STREET, STREET2, CITY, STATE, ZIPCODE, OFF_TTL, FCIID_1, FCIID_2, FCIID_3, FCIID_4, FCIID_5, FCIID_6, FCIID_7, FCIID_8, PHONE2, DEPTCOMPANY_ABB, STARTDATE, DATASOURCE, COMPANY_NAME, DATAOWNER_RITSID, DM1, GOC_CODE, TSA_INDICATOR, DIRECT_MANAGER1_NAME, SUPERVISOR_NAME, HRGEN_NAME, SRC_CREATED_ON, SRC_CREATED_BY_SOEID, SRC_CREATED_BY_NAME, SRC_UPDATED_ON, SRC_UPDATED_BY_SOEID, SRC_UPDATED_BY_NAME, BO_CREATED_BY, BO_CREATED_ON, BO_UPDATED_BY, BO_UPDATED_ON, BO_EMP_TERM_DATE, DIRECT_MANAGER1_GEID, SUPERVISOR_GEID, COMPANY_CODE, COUNTRY_NAME, FULL_NAME ");
		constantBuild.append("FROM rdspr.gdw_user WHERE GEID IN( ");
		return constantBuild;
	}
	
	private static StringBuilder getSelectedSupervisorGEIDQuery()
	{
		sb_CCR_SUPERVISOR_GEID_QUERY = new StringBuilder();
		sb_CCR_SUPERVISOR_GEID_QUERY.append("SELECT ");
		sb_CCR_SUPERVISOR_GEID_QUERY.append("DISTINCT TERM.SUPERVISOR_GEID ");
		sb_CCR_SUPERVISOR_GEID_QUERY.append("FROM c3par.CITI_CONTACT term, c3par.citi_contact active ");
		sb_CCR_SUPERVISOR_GEID_QUERY.append("WHERE  ");
		sb_CCR_SUPERVISOR_GEID_QUERY.append("TERM.EMPLOYEE_STATUS IS NOT NULL ");
		sb_CCR_SUPERVISOR_GEID_QUERY.append("AND TERM.SUPERVISOR_GEID IS NOT NULL AND ");
		sb_CCR_SUPERVISOR_GEID_QUERY.append("TERM.SUPERVISOR_GEID=ACTIVE.GEID(+) AND ");
		sb_CCR_SUPERVISOR_GEID_QUERY.append("active.sso_id is null ");
	return sb_CCR_SUPERVISOR_GEID_QUERY;
	}
}
