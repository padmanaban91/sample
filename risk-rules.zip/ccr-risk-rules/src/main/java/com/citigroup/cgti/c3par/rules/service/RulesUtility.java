/**
 * 
 */
package com.citigroup.cgti.c3par.rules.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.kie.api.KieBase;
import org.kie.api.cdi.KBase;
import org.kie.api.runtime.KieSession;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.citigroup.cgti.c3par.rules.model.FirewallRuleDTO;
import com.citigroup.cgti.c3par.rules.model.FlagDTO;
import com.citigroup.cgti.c3par.rules.model.IpAddressDTO;
import com.citigroup.cgti.c3par.rules.model.NetworkSegmentDTO;
import com.citigroup.cgti.c3par.rules.model.OstiaQuestionDTO;
import com.citigroup.cgti.c3par.rules.model.PortDTO;
import com.citigroup.cgti.c3par.rules.model.PossibleAnswersDTO;
import com.citigroup.cgti.c3par.rules.model.RiskDefinitionDTO;

/**
 * @author VR56524
 *
 */
@Component
public class RulesUtility {

	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@KBase
	private KieBase kbase;
	
	public KieBase getKieSession() {
		return kbase;
	}

	public void setDestinationIps(FirewallRuleDTO firewallRuleDTO,
			KieSession ruleSession) {
		for (IpAddressDTO ipAddressDto : firewallRuleDTO
				.getDestinationIPAddress()) {
			ruleSession.insert(ipAddressDto);
		}
	}

	public void setSourceIps(FirewallRuleDTO firewallRuleDTO,
			KieSession ruleSession) {
		for (IpAddressDTO ipAddressDto : firewallRuleDTO.getSourceIPAddress()) {
			ruleSession.insert(ipAddressDto);
		}
	}

	public void setPorts(FirewallRuleDTO firewallRuleDTO, KieSession ruleSession) {
		for (PortDTO portDTO : firewallRuleDTO.getPort()) {
			log.debug("getPortNumber"+portDTO.getPortNumber());
			log.debug("Portcol"+portDTO.getProtocol());
			log.debug("getStartPort"+portDTO.getStartPort());
			log.debug("getEndPort"+portDTO.getEndPort());
			ruleSession.insert(portDTO);
		}
	}

	public void setTiRequest(FirewallRuleDTO firewallRuleDTO,
			KieSession ruleSession) {
		if (firewallRuleDTO.getTiRequest() != null) {
			ruleSession.insert(firewallRuleDTO.getTiRequest());
			for (FlagDTO flagDTO : firewallRuleDTO.getTiRequest()
					.getRiskCheckFlags()) {
				log.debug("TIREQUEST KEY"+flagDTO.getKey());
				log.debug("TIREQUEST sVALUE"+flagDTO.getValue());
				ruleSession.insert(flagDTO);
			}
		}
	}

	public void setFlags(FirewallRuleDTO firewallRuleDTO, KieSession ruleSession) {
		for (FlagDTO flagDTO : firewallRuleDTO.getRiskCheckFlags()) {
			log.debug(" KEY"+flagDTO.getKey());
			log.debug(" sVALUE"+flagDTO.getValue());
			ruleSession.insert(flagDTO);
		}
	}

	public void setCommonProperties(FirewallRuleDTO firewallRuleDTO,
			KieSession ruleSession) {
		ruleSession.insert(firewallRuleDTO);
		ruleSession.insert(firewallRuleDTO.getOstiaQuestionnaires());
		//TODO:Will move the code to c3par project
		NetworkSegmentDTO networkDto=new NetworkSegmentDTO();
		networkDto.setSourceNetworkSegment(firewallRuleDTO.getSourceNetworkSegment());
		networkDto.setDestinationNetworkSegment(firewallRuleDTO.getDestinationNetworkSegment());
		log.debug(" getSourceNetworkSegment Count()"+firewallRuleDTO.getSourceNetworkSegment());
		log.debug(" Risk Definition Count()"+firewallRuleDTO.getSourceNetworkSegment());
		firewallRuleDTO.setNetworkSegmentDto(networkDto);
		ruleSession.insert(firewallRuleDTO.getNetworkSegmentDto());
		ruleSession.setGlobal("fireWallDto", firewallRuleDTO);
	}

	public void output(FirewallRuleDTO outputFirewallRuleDTO) {
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("								RULE OUTPUT::");
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("Risk Definition Count()"
				+ " for CCR "
				+ outputFirewallRuleDTO.getTransactionId()
				+ " is :: "
				+ outputFirewallRuleDTO.getOstiaQuestionnaires()
						.getRiskDefinitions().size());
	     System.out.println("Risk Definition Count()"
				+ " for CCR "
				+ outputFirewallRuleDTO.getTransactionId()
				+ " is :: "
				+ outputFirewallRuleDTO.getOstiaQuestionnaires()
						.getRiskDefinitions().size());
		for (int i = 0; i < outputFirewallRuleDTO.getOstiaQuestionnaires()
				.getRiskDefinitions().size(); i++) {
			RiskDefinitionDTO riskDefinition = (RiskDefinitionDTO) outputFirewallRuleDTO
					.getOstiaQuestionnaires().getRiskDefinitions().get(i);
			log.debug("Number of Ostia Questions for Risk Definition ["
					+ (i + 1) + "] :: " + riskDefinition.getRiskCode()
					+ " " + riskDefinition.getRiskCategory()
					+ " are :: "
					+ riskDefinition.getOstiaQuestion().size());
			System.out.println("Number of Ostia Questions for Risk Definition ["
						+ (i + 1) + "] :: " + riskDefinition.getRiskCode()
						+ " " + riskDefinition.getRiskCategory()
						+ " are :: "
						+ riskDefinition.getOstiaQuestion().size());
			log.debug("----------------------");
			for (int j = 0; j < riskDefinition.getOstiaQuestion().size(); j++) {
				OstiaQuestionDTO ostiaQuestion = (OstiaQuestionDTO) riskDefinition
						.getOstiaQuestion().get(j);
				System.out.println("Ostia Question ["
						+ (j + 1)
						+ "] :: Question Control Code :: "
						+ ostiaQuestion.getQuestionControlNumber()
						+ " :: Question :: "
						+ ostiaQuestion.getQuestion()
						+ " :: Answer Type :: "
						+ ostiaQuestion.getAnswerType()
						+ ":: optionsGroupName"
						+ ostiaQuestion.getOptionsGroupName()
						+ " :: Answer Group :: "
						+ getPossibleAnswers(ostiaQuestion
								.getPossibleAnswers()));
				log.debug("Ostia Question ["
						+ (j + 1)
						+ "] :: Question Control Code :: "
						+ ostiaQuestion.getQuestionControlNumber()
						+ " :: Question :: "
						+ ostiaQuestion.getQuestion()
						+ " :: Answer Type :: "
						+ ostiaQuestion.getAnswerType()
						+ ":: optionsGroupName"
						+ ostiaQuestion.getOptionsGroupName()
						+ " :: Answer Group :: "
						+ getPossibleAnswers(ostiaQuestion
								.getPossibleAnswers()));
				log.debug("Risk Defination"
						+ riskDefinition.getRiskCategory());
			}
			log.debug("----------------------");
		}
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("								REQUEST OUTPUT::");
		log.debug("------------------------------------------------------------------------------------------------------------------");
        if(outputFirewallRuleDTO.getTiRequest()!=null && outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires()!=null && outputFirewallRuleDTO.getTiRequest()
				.getOstiaQuestionnaires().getRiskDefinitions()!=null){
		log.debug("Risk Definition Count()"
				+ " for CCR "
				+ outputFirewallRuleDTO.getTransactionId()
				+ " is :: "
				+ outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires()
						.getRiskDefinitions().size());
		System.out.println("------------------------------------------------------------------------------------------------------------------");
		System.out.println("								REQUEST OUTPUT::");
		System.out.println("Risk Definition Count()"
				+ " for CCR "
				+ outputFirewallRuleDTO.getTransactionId()
				+ " is :: "
				+ outputFirewallRuleDTO.getTiRequest().getOstiaQuestionnaires()
						.getRiskDefinitions().size());
		for (int i = 0; i < outputFirewallRuleDTO.getTiRequest()
				.getOstiaQuestionnaires().getRiskDefinitions().size(); i++) {
			RiskDefinitionDTO riskDefinition = (RiskDefinitionDTO) outputFirewallRuleDTO
					.getTiRequest().getOstiaQuestionnaires()
					.getRiskDefinitions().get(i);
			log.debug("Number of Ostia Questions for Risk Definition ["
					+ (i + 1) + "] :: " + riskDefinition.getRiskCode()
					+ " " + riskDefinition.getRiskCategory()
					+ " are :: " + " are :: "
					+ riskDefinition.getOstiaQuestion().size());
			System.out.println("Number of Ostia Questions for Risk Definition ["
					+ (i + 1) + "] :: " + riskDefinition.getRiskCode()
					+ " " + riskDefinition.getRiskCategory()
					+ " are :: " + " are :: "
					+ riskDefinition.getOstiaQuestion().size());
			log.debug("----------------------");
			for (int j = 0; j < riskDefinition.getOstiaQuestion().size(); j++) {
				OstiaQuestionDTO ostiaQuestion = (OstiaQuestionDTO) riskDefinition
						.getOstiaQuestion().get(j);
				log.debug("Ostia Question ["
						+ (j + 1)
						+ "] :: Question Control Code :: "
						+ ostiaQuestion.getQuestionControlNumber()
						+ " :: Question :: "
						+ ostiaQuestion.getQuestion()
						+ " :: Answer Type :: "
						+ ostiaQuestion.getAnswerType()
						+ ":: optionsGroupName"
						+ ostiaQuestion.getOptionsGroupName()
						+ " :: Answer Group :: "
						+ getPossibleAnswers(ostiaQuestion
								.getPossibleAnswers()));
				System.out.println("Ostia Question ["
						+ (j + 1)
						+ "] :: Question Control Code :: "
						+ ostiaQuestion.getQuestionControlNumber()
						+ " :: Question :: "
						+ ostiaQuestion.getQuestion()
						+ " :: Answer Type :: "
						+ ostiaQuestion.getAnswerType()
						+ ":: optionsGroupName"
						+ ostiaQuestion.getOptionsGroupName()
						+ " :: Answer Group :: "
						+ getPossibleAnswers(ostiaQuestion
								.getPossibleAnswers()));
			}
			log.debug("----------------------");
		}
		}
	}

	private static String getPossibleAnswers(
			List<PossibleAnswersDTO> possibleAnswers) {
		StringBuffer buffer = new StringBuffer();
		for (PossibleAnswersDTO possibleAnswersDTO : possibleAnswers) {
			if (possibleAnswersDTO != null) {
				buffer.append(possibleAnswersDTO.getAnswer() + " , ");
			}
		}
		return buffer.toString();
	}

	public void input(FirewallRuleDTO firewallRuleDTO) {
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("								INPUT::");
		log.debug("------------------------------------------------------------------------------------------------------------------");
		log.debug("								INPUT::");
		log.debug("CCR " + firewallRuleDTO.getTransactionId());
		log.debug("Source IP(s)::");
		// System.out.println();
		IpAddressDTO ipAddress;
		if (firewallRuleDTO.getSourceIPAddress() != null) {
			for (int ipCount = 0; ipCount < firewallRuleDTO
					.getSourceIPAddress().size(); ipCount++) {
				ipAddress = (IpAddressDTO) firewallRuleDTO.getSourceIPAddress()
						.get(ipCount);
				System.out.println("IPAddress:: " + ipAddress.getIpAddress()
						+ "  is TPA:: " + ipAddress.isTpa());
				log.debug("IPAddress:: " + ipAddress.getIpAddress()
						+ "  is TPA:: " + ipAddress.isTpa());
			}
		}
		System.out.println("----------------------");
		// System.out.println();
		System.out.println("Destination IP(s)::");
		System.out.println("----------------------");
		// System.out.println();
		if (firewallRuleDTO.getDestinationIPAddress() != null) {
			for (int ipCount = 0; ipCount < firewallRuleDTO
					.getDestinationIPAddress().size(); ipCount++) {
				ipAddress = (IpAddressDTO) firewallRuleDTO
						.getDestinationIPAddress().get(ipCount);
				System.out.println("IPAddress:: " + ipAddress.getIpAddress()
						+ "  is TPA:: " + ipAddress.isTpa());
				log.debug("IPAddress:: " + ipAddress.getIpAddress()
				+ "  is TPA:: " + ipAddress.isTpa());
			}
		}
		System.out.println("----------------------");
		// System.out.println();
		System.out.println("Port(s)::");
		System.out.println("----------------------");
		// System.out.println();
		PortDTO port;
		if (firewallRuleDTO.getPort() != null) {
			for (int portCount = 0; portCount < firewallRuleDTO.getPort()
					.size(); portCount++) {
				port = (PortDTO) firewallRuleDTO.getPort().get(portCount);
				System.out.println("Port Number:: " + port.getPortNumber()
						+ " :: Protocol:: " + port.getProtocol()
						+ " :: Default Service :: " + port.isDefaultService());
				log.debug("Port Number:: " + port.getPortNumber()
						+ " :: Protocol:: " + port.getProtocol()
						+ " :: Default Service :: " + port.isDefaultService());
			}
		}
		
		if(firewallRuleDTO.getTiRequest()!=null){
			log.debug("BusinessUnit :: " + firewallRuleDTO.getTiRequest().getBusinessUnit()
					+ " :: RelationshipType :: " + firewallRuleDTO.getTiRequest().getRelationshipType()
					+ " :: DestinationNetworkSegment :: " +firewallRuleDTO.getDestinationNetworkSegment()
					+ " :: SourceNetworkSegment :: " +firewallRuleDTO.getSourceNetworkSegment());
		}
	}

	public static String trim(String value) {
		String newValue = value;
		if (StringUtils.hasLength(value)) {
			newValue = value.trim();
		}
		return newValue;
	}

}
