package com.citigroup.cgti.c3par.rules.service;

import java.io.File;

/**
 * @author vr56524
 *
 */
public class CCRRulesConstant {

	public static  final String SLASH="/";
	
	public static final String WEB_INF_CLASSES = "/classes/";
	
	public static final String RELEASE_ID = "releaseId";

	public static final String DOUBLE_QUOTES = "";

	public static final String K_BASE_NAME = "kBaseName";

	public static final String CLASSPATH = "classpath:/";
	
	public static final String WEB_INF_FOLDER = "WEB-INF" + File.separator
			+ "classes" + File.separator;
	
	public static final String SCOPE = "scope";

	public static final String TRUE = "true";

	public static final String COMMA = ",";
}
