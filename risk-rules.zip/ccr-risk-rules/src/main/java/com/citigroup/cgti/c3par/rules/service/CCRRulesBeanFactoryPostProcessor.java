package com.citigroup.cgti.c3par.rules.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Map;

import org.apache.log4j.Logger;
import org.drools.compiler.kie.builder.impl.ClasspathKieProject;
import org.drools.compiler.kie.builder.impl.InternalKieModule;
import org.drools.compiler.kie.builder.impl.KieBuilderImpl;
import org.drools.compiler.kproject.ReleaseIdImpl;
import org.drools.compiler.kproject.models.KieBaseModelImpl;
import org.drools.compiler.kproject.models.KieModuleModelImpl;
import org.drools.compiler.kproject.models.KieSessionModelImpl;
import org.kie.api.KieServices;
import org.kie.api.builder.ReleaseId;
import org.kie.api.builder.model.KieModuleModel;
import org.kie.api.builder.model.KieSessionModel;
import org.kie.api.conf.DeclarativeAgendaOption;
import org.kie.api.conf.EqualityBehaviorOption;
import org.kie.api.conf.EventProcessingOption;
import org.kie.api.runtime.conf.ClockTypeOption;
import org.kie.spring.factorybeans.KBaseFactoryBean;
import org.kie.spring.factorybeans.KModuleFactoryBean;
import org.kie.spring.factorybeans.KSessionFactoryBean;
import org.springframework.beans.BeansException;
import org.springframework.beans.PropertyValue;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanExpressionContext;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * Its used to load the rules at runtime using KIE API
 * @author VR56524
 *
 */
//@Component("kiePostProcessor")
public class CCRRulesBeanFactoryPostProcessor /*implements
		BeanFactoryPostProcessor, ApplicationContextAware*/ {
	private static final int MegaBytes = 10241024;
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	protected URL configFileURL;
	protected ReleaseId releaseId;

	private String configFilePath;

	private ApplicationContext context;
	
	private ConfigurableListableBeanFactory beanFactoryRef;
	
	private String environment;
	
	//@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		
		try {
			log.debug("setApplicationContext");
			Enumeration<URL> urls2 = getClass().getClassLoader()
					.getResources(".");
			while (urls2.hasMoreElements()) {
				URL url = urls2.nextElement();
					System.out.println("url new "+url.getPath());
			}
			if (true) {
				Enumeration<URL> urls = getClass().getClassLoader()
						.getResources("/com/");
				while (urls.hasMoreElements()) {
					URL url = urls.nextElement();
					if (url.getPath().contains("ccr-risk-rules-1.0-SNAPSHOT.jar")) {
						System.out.println("Condition true");
						configFileURL = url;
						break;
					}
				}
			} else {
				configFileURL = applicationContext.getResource(CCRRulesConstant.CLASSPATH)
						.getURL();
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		log.debug("classpath root URL: in new class " + configFileURL);
	}

	private boolean isEapContext(ApplicationContext applicationContext)
			throws IOException {
		URL url = applicationContext.getResource(CCRRulesConstant.CLASSPATH).getURL();
		if (isEapUrl(url)) {
			return true;
		} else {
			Enumeration<URL> urls = getClass().getClassLoader().getResources(
					CCRRulesConstant.SLASH);
			while (urls.hasMoreElements()) {
				URL urls_new = urls.nextElement();
				log.debug("setApplicationContext -->urls.nextElement()"
						+ urls_new);
				if (isEapUrl(urls_new)) {
					return true;
				}
			}
		}
		return false;
	}

	public CCRRulesBeanFactoryPostProcessor() {
		initConfigFilePath();
	}

	protected void initConfigFilePath() {

		try {
			log.debug("setApplicationContext");
			Enumeration<URL> urls2 = getClass().getClassLoader()
					.getResources(".");
			while (urls2.hasMoreElements()) {
				URL url = urls2.nextElement();
					System.out.println("url new "+url.getPath());
			}
			Enumeration<URL> urls = getClass().getClassLoader().getResources("/com/");
			if (urls != null)
				while (urls.hasMoreElements()) {
					URL url = urls.nextElement();
					System.out.println("path "+url.getPath());
					if (url.getPath().contains("ccr-risk-rules-1.0-SNAPSHOT.jar")) {
						System.out.println("Condition true");
						configFilePath = url.getPath();
						break;
					}
				}

		} catch (Exception ex) {
			log.debug("Error in initConfigFilePath" + ex);
		}
		log.debug("ConfigFilePath for EAP" + configFilePath);
		/*if (!StringUtils.hasLength(configFilePath)) {
			try {
				configFilePath = getClass().getResource(CCRRulesConstant.SLASH).toURI().getPath();
			} catch (URISyntaxException e) {
				configFilePath = getClass().getResource(CCRRulesConstant.SLASH).getPath();
			}
		}*/
		System.out.println("Final configFilePath is " + configFilePath);
		log.debug("Final configFilePath is " + configFilePath);
	}

	public void setReleaseId(ReleaseId releaseId) {
		this.releaseId = releaseId;
	}

	private boolean isEapUrl(URL url) {
		return url.toString().endsWith(CCRRulesConstant.WEB_INF_CLASSES);
	}

	public void postProcessBeanFactory(
			ConfigurableListableBeanFactory beanFactory) throws BeansException {
		log.debug(":: BeanFactoryPostProcessor::postProcessBeanFactory called ::");
		boolean isRulesNotLoaded= (beanFactoryRef == null);
		beanFactoryRef=beanFactory;
		if (releaseId == null && configFilePath != null) {
			String pomProperties = null;
			if (configFilePath.contains("/com/")) {
				String configFilePathForWebApps = configFilePath.substring(0,
						configFilePath.indexOf("ccr-risk-rules-1.0-SNAPSHOT.jar!"));
				System.out.println("configFilePathForWebApps"+configFilePathForWebApps);
				pomProperties = ClasspathKieProject
						.getPomProperties(configFilePathForWebApps);
			}
			System.out.println("configFilePath"+configFilePath);
			/*if (pomProperties == null) {
				pomProperties = ClasspathKieProject
						.getPomProperties(configFilePath);
			}
			if (pomProperties != null) {
				releaseId = ReleaseIdImpl.fromPropertiesString(pomProperties);
			} else {*/
				releaseId = new ReleaseIdImpl("org.default", "artifact",
						"1.0.0-SNAPSHOT");
			//}
			log.debug("Found project with releaseId: " + releaseId);
			// KieSpringUtils.setDefaultReleaseId(releaseId);
		}
System.out.println("beanFactory"+beanFactory.getBean(KModuleFactoryBean.class));
//System.out.println("beanFactory"+beanFactory.getBeanDefinitionNames());
		for (String beanDef : beanFactory.getBeanDefinitionNames()) {
			System.out.println("beanDef");
			BeanDefinition beanDefinition = beanFactory
					.getBeanDefinition(beanDef);
			if (beanDefinition.getBeanClassName() != null
					&& beanDefinition.getBeanClassName().equalsIgnoreCase(
							KModuleFactoryBean.class.getName())) {
				KieModuleModel kieModuleModel = fetchKieModuleModel(beanFactory,isRulesNotLoaded);
				addKieModuleToRepo(kieModuleModel,isRulesNotLoaded);
			}
		}
	}

	private KieModuleModel fetchKieModuleModel(
			ConfigurableListableBeanFactory beanFactory,boolean isRulesNotLoaded) {
		KieModuleModelImpl kieModuleModel = new KieModuleModelImpl();
		addKieBaseModels(beanFactory, kieModuleModel,isRulesNotLoaded);
		return kieModuleModel;
	}

	private void addKieModuleToRepo(KieModuleModel kieProject,boolean isRulesNotLoaded) {
		KieBuilderImpl.setDefaultsforEmptyKieModule(kieProject);

		InternalKieModule kJar = createKieModule(kieProject);
       System.out.println("Kjar"+kJar);
		if (kJar != null) {
			KieServices ks = KieServices.Factory.get();
			log.debug("adding KieModule from " + configFileURL.toExternalForm()
					+ " to repository.");
			System.out.println("adding KieModule from " + configFileURL.toExternalForm()
					+ " to repository.");
			ks.getRepository().addKieModule(kJar);
			if (context != null) {
				// KieSpringUtils.setReleaseIdForContext(releaseId, context);
				// KieSpringUtils.setDefaultReleaseId(releaseId);
			}
		}
	}

	protected InternalKieModule createKieModule(KieModuleModel kieProject) {

		if (configFilePath == null) {
			configFilePath = getClass().getResource(CCRRulesConstant.SLASH).getPath();
		}

		String rootPath = configFilePath;
		if (rootPath.lastIndexOf(':') > 0) {
			rootPath = configFilePath.substring(rootPath.lastIndexOf(':') + 1);
		}

		return ClasspathKieProject.createInternalKieModule(configFileURL,
				configFilePath, kieProject, releaseId, "/opt/middleware/cloudapp/cloudapp_Runtime/profiles/cloudappCell/cloudapp2/installedApps/cloudappCell/ccr-ear.ear/ccr.war/WEB-INF/classes/");
	}

	private void addKieBaseModels(ConfigurableListableBeanFactory beanFactory,
			KieModuleModelImpl kieModuleModel,boolean isRulesNotLoaded) {
		BeanExpressionContext context = new BeanExpressionContext(beanFactory,
				null);
		for (String beanDef : beanFactory.getBeanDefinitionNames()) {
			System.out.println("Bean"+beanDef);
			BeanDefinition beanDefinition = beanFactory
					.getBeanDefinition(beanDef);
			if (beanDefinition.getBeanClassName() != null
					&& beanDefinition.getBeanClassName().equalsIgnoreCase(
							KBaseFactoryBean.class.getName())) {
				System.out.println("addKieBaseModels"+beanDefinition.getBeanClassName());
				KieBaseModelImpl kBase = new KieBaseModelImpl();
				kBase.setKModule(kieModuleModel);

				kBase.setName(getPropertyValue(beanDefinition, CCRRulesConstant.K_BASE_NAME));
				kBase.setDefault(CCRRulesConstant.TRUE.equals(getPropertyValue(beanDefinition,
						"def")));
                 
				String packages = getPropertyValue(beanDefinition, "packages");
				
			/*	if("DEV".equals(getEnvironment()) && isRulesNotLoaded){
					packages= "com.citigroup.cgti.c3par.rules.initialize";
				}*/
				
				if (!packages.isEmpty()) {
					packages = checkAndResolveSpringExpression(beanFactory,
							context, packages);
					for (String pkg : packages.split(CCRRulesConstant.COMMA)) {
						kBase.addPackage(pkg.trim());
					}
				}

				String includes = getPropertyValue(beanDefinition, "includes");
				if (!includes.isEmpty()) {
					includes = checkAndResolveSpringExpression(beanFactory,
							context, includes);
					for (String include : includes.split(CCRRulesConstant.COMMA)) {
						kBase.addInclude(include.trim());
					}
				}

				String eventMode = getPropertyValue(beanDefinition,
						"eventProcessingMode");
				if (!eventMode.isEmpty()) {
					eventMode = checkAndResolveSpringExpression(beanFactory,
							context, eventMode);
					kBase.setEventProcessingMode(EventProcessingOption
							.determineEventProcessingMode(eventMode));
				}

				String equalsBehavior = getPropertyValue(beanDefinition,
						"equalsBehavior");
				if (!equalsBehavior.isEmpty()) {
					equalsBehavior = checkAndResolveSpringExpression(
							beanFactory, context, equalsBehavior);
					kBase.setEqualsBehavior(EqualityBehaviorOption
							.determineEqualityBehavior(equalsBehavior));
				}

				String declarativeAgenda = getPropertyValue(beanDefinition,
						"declarativeAgenda");
				if (!declarativeAgenda.isEmpty()) {
					declarativeAgenda = checkAndResolveSpringExpression(
							beanFactory, context, declarativeAgenda);
					kBase.setDeclarativeAgenda(DeclarativeAgendaOption
							.determineDeclarativeAgenda(declarativeAgenda));
				}

				String scope = getPropertyValue(beanDefinition, CCRRulesConstant.SCOPE);
				if (!scope.isEmpty()) {
					scope = checkAndResolveSpringExpression(beanFactory,
							context, scope);
					kBase.setScope(scope.trim());
				}

				kieModuleModel.getRawKieBaseModels()
						.put(kBase.getName(), kBase);
				beanDefinition.getPropertyValues().addPropertyValue(
						new PropertyValue(CCRRulesConstant.RELEASE_ID, releaseId));
				addKieSessionModels(beanFactory, kBase);
			}
		}
	}

	private String getPropertyValue(BeanDefinition beanDefinition,
			String propertyName) {
		PropertyValue propertyValue = beanDefinition.getPropertyValues()
				.getPropertyValue(propertyName);
		return propertyValue != null ? (String) propertyValue.getValue() : CCRRulesConstant.DOUBLE_QUOTES;
	}

	protected String checkAndResolveSpringExpression(
			ConfigurableListableBeanFactory beanFactory,
			BeanExpressionContext context, String expression) {
		if (expression.startsWith("#{") && expression.endsWith("}")) {
			return (String) beanFactory.getBeanExpressionResolver().evaluate(
					expression, context);
		}
		return expression;
	}

	private void addKieSessionModels(
			ConfigurableListableBeanFactory beanFactory, KieBaseModelImpl kBase) {
		for (String beanDef : beanFactory.getBeanDefinitionNames()) {
			BeanDefinition beanDefinition = beanFactory
					.getBeanDefinition(beanDef);
			if (beanDefinition.getBeanClassName() != null
					&& beanDefinition.getBeanClassName().equalsIgnoreCase(
							KSessionFactoryBean.class.getName())) {
				String kBaseName = getPropertyValue(beanDefinition, CCRRulesConstant.K_BASE_NAME);
				if (kBase.getName().equalsIgnoreCase(kBaseName)) {
					String name = getPropertyValue(beanDefinition, "name");
					String type = getPropertyValue(beanDefinition, "type");
					KieSessionModelImpl kSession = new KieSessionModelImpl(
							kBase, name);

					kSession.setType(!type.isEmpty() ? KieSessionModel.KieSessionType
							.valueOf(type.toUpperCase())
							: KieSessionModel.KieSessionType.STATEFUL);
					Map<String, KieSessionModel> rawKieSessionModels = kBase
							.getRawKieSessionModels();
					rawKieSessionModels.put(kSession.getName(), kSession);
					beanDefinition.getPropertyValues().addPropertyValue(
							new PropertyValue(CCRRulesConstant.RELEASE_ID, releaseId));

					kSession.setDefault(CCRRulesConstant.TRUE.equals(getPropertyValue(
							beanDefinition, "def")));

					String clockType = getPropertyValue(beanDefinition,
							"clockType");
					if (!clockType.isEmpty()) {
						kSession.setClockType(ClockTypeOption.get(clockType));
					}

					String scope = getPropertyValue(beanDefinition, CCRRulesConstant.SCOPE);
					if (!scope.isEmpty()) {
						kSession.setScope(scope.trim());
					}
				}
			}
		}
	}

	public ConfigurableListableBeanFactory getBeanFactoryRef() {
		return beanFactoryRef;
	}

	public void setBeanFactoryRef(ConfigurableListableBeanFactory beanFactoryRef) {
		this.beanFactoryRef = beanFactoryRef;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

}
