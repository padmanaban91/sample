package com.citigroup.cgti.c3par.rules.listeners;

import org.apache.log4j.Logger;
import org.kie.api.event.rule.ObjectDeletedEvent;
import org.kie.api.event.rule.ObjectInsertedEvent;
import org.kie.api.event.rule.ObjectUpdatedEvent;
import org.kie.api.event.rule.RuleRuntimeEventListener;
import org.springframework.stereotype.Component;

/**
 * @author VR56524
 *
 */
@Component
public class CCRRuleRuntimeEventListener implements RuleRuntimeEventListener {
	
	private Logger log = Logger.getLogger(this.getClass().getName());
	//@Override
	public void objectUpdated(ObjectUpdatedEvent event) {
		// TODO Auto-generated method stub
		System.out.println("objectUpdated"+event);
		log.info("objectUpdated"+event);
	}
	
	//@Override
	public void objectInserted(ObjectInsertedEvent event) {
		// TODO Auto-generated method stub
		System.out.println("objectInserted"+event);
		log.info("objectInserted"+event);
	}
	
	//@Override
	public void objectDeleted(ObjectDeletedEvent event) {
		// TODO Auto-generated method stub
		System.out.println("objectDeleted"+event);
		log.info("objectDeleted"+event);
	}
}
