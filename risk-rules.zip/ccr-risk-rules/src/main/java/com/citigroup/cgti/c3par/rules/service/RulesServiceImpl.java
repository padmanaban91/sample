package com.citigroup.cgti.c3par.rules.service;

import java.io.File;

import org.apache.log4j.Logger;
import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.builder.KieModule;
import org.kie.api.builder.KieRepository;
import org.kie.api.io.Resource;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.citigroup.cgti.c3par.rules.listeners.CCRAgendaEventListener;
import com.citigroup.cgti.c3par.rules.listeners.CCRProcessEventListener;
import com.citigroup.cgti.c3par.rules.listeners.CCRRuleRuntimeEventListener;
import com.citigroup.cgti.c3par.rules.model.FirewallRuleDTO;
import com.citigroup.cgti.c3par.rules.model.PortDTO;
import com.citigroup.cgti.c3par.rules.model.TiRequestDTO;
/**
 * @author VR56524
 *
 */
@Service
public class RulesServiceImpl implements RulesService {

	private Logger log = Logger.getLogger(this.getClass().getName());
	
	@Autowired
	private RulesUtility rulesUtility;
	
	//@Autowired
	private KieBase kbase;
	
	ApplicationContext context;
	
	KieContainer kieContainer=null;
	
	@Autowired
	private CCRProcessEventListener ccrProcessEventListener;
	@Autowired
	private CCRRuleRuntimeEventListener ccrRuleRuntimeEventListener;
	@Autowired
	private CCRAgendaEventListener ccrAgendaEventListener;
	public RulesServiceImpl(){
		System.out.println("RulesServiceImpl --start");
		KieServices services = KieServices.Factory.get();
		kieContainer=services.getKieClasspathContainer();
		final KieSession kSession = kieContainer.newKieSession();
		System.out.println("kSession"+kSession);
		System.out.println("RulesServiceImpl --End"+kieContainer);
		
		/*KieServices ks = KieServices.Factory.get(); 
		KieRepository kr = ks.getRepository();

		Resource kieresource = ks.getResources(). newFileSystemResource( new File(" c:/ Users/ simo/ git/ masterjbpm6/ pizzadelivery/ target/ classes/")); 
		// or ks.getResources(). newFileSystemResource( new

		File(" c:/ Users/ simo/ git/ masterjbpm6/ pizzadelivery/ target/ pizzadelivery-1.0. jar")); // add to the 
		 KieModule kModule = kr.addKieModule( kieresource); 
		// load and use the module 
		 KieContainer kContainer = ks.newKieContainer( kproj.getReleaseId());*/

	}
	
	
	
	/* (non-Javadoc)
	 * Used fo executing the rules
	 * @see com.citigroup.cgti.c3par.rules.service.RulesService#executeRules(com.citigroup.cgti.c3par.rules.model.FirewallRuleDTO)
	 */
	public void executeRules(FirewallRuleDTO firewallRuleDTO) {
		System.out.println("executeRules -- Start in Rule Service Impl");
		KieSession ruleSession = getRuleSession();
		if(ruleSession==null){
			return;
		}
		/*if (kbase != null) {
			log.debug("kbase" + kbase);
			ruleSession = kbase.newKieSession();
		} else {
			log.debug("kbase is null");
			return;
		}*/
		//testPortByTemplateRule();
		/*ruleSession.addEventListener(ccrProcessEventListener); // process
																// listnere
		ruleSession.addEventListener(ccrRuleRuntimeEventListener);
		ruleSession.addEventListener(ccrAgendaEventListener);*/
		try {
			rulesUtility.input(firewallRuleDTO);
			rulesUtility.setCommonProperties(firewallRuleDTO, ruleSession);
			rulesUtility.setDestinationIps(firewallRuleDTO, ruleSession);
			rulesUtility.setSourceIps(firewallRuleDTO, ruleSession);
			rulesUtility.setFlags(firewallRuleDTO, ruleSession);
			rulesUtility.setPorts(firewallRuleDTO, ruleSession);
			rulesUtility.setTiRequest(firewallRuleDTO, ruleSession);
			StopWatch watch = new StopWatch();
			watch.start();
			ruleSession.fireAllRules();
			watch.stop();
			log.debug("Total execution time to run the rules: "
					+ watch.getTotalTimeMillis());
			rulesUtility.output(firewallRuleDTO);
			System.out.println("rulesUtility -- End");
		} catch (Exception ex) {
			System.out.println("Exception while  executing the rules ");
			log.debug("Exception while  executing the rules ", ex);
		} finally {
			log.debug("Dispose Session");
			ruleSession.dispose();
		}
		System.out.println("executeRules -- End");
	}
	/* (non-Javadoc)
	 * TODO:will remove below method once testing completed
	 * @see com.citigroup.cgti.c3par.rules.service.RulesService#testPortByTemplateRule()
	 */
	public void testPortByTemplateRule() {
		log.debug("testPortByTemplateRule @@@ -Start");
		KieSession ruleSession=null;
		if(kbase != null){
		  log.debug("In KIEBASE"+kbase);
		  ruleSession=kbase.newKieSession();
		}
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		ruleSession.insert(fireWallDto);
		TiRequestDTO tiRequest=new TiRequestDTO();
		tiRequest.setRelationshipType("IP_TEMPLATE");
		ruleSession.insert(tiRequest);
		PortDTO portDto=new PortDTO();
		portDto.setProtocol("TCP");
		portDto.setPortNumber("7744");
		portDto.setDefaultService(true);
		ruleSession.insert(portDto);
		ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		ruleSession.setGlobal("fireWallDto", fireWallDto);
		PortDTO portDto1=new PortDTO();
		portDto1.setProtocol("UDP");
		portDto1.setPortNumber("111");
		portDto1.setDefaultService(true);
		ruleSession.insert(portDto1);
		//int rulesFired = ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("RiskPortBYTEmplates") );
		int rulesFired = ruleSession.fireAllRules();
		rulesUtility.output(fireWallDto);
		log.debug("Rules fired in testPortByTemplateRule"+rulesFired);
		log.debug("testPortByTemplateRule @@@ -End");
	}
	public KieSession  getRuleSession(){
	final KieSession kSession = kieContainer.newKieSession();
	kSession.addEventListener(new CCRProcessEventListener()); //process listnere
	kSession.addEventListener(new CCRRuleRuntimeEventListener());
	return kSession;
	}
}
