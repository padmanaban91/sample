/**
 * 
 */
package com.citigroup.cgti.c3par.rules.listeners;



import org.apache.log4j.Logger;
import org.kie.api.event.rule.AfterMatchFiredEvent;
import org.kie.api.event.rule.AgendaEventListener;
import org.kie.api.event.rule.AgendaGroupPoppedEvent;
import org.kie.api.event.rule.AgendaGroupPushedEvent;
import org.kie.api.event.rule.BeforeMatchFiredEvent;
import org.kie.api.event.rule.MatchCancelledEvent;
import org.kie.api.event.rule.MatchCreatedEvent;
import org.kie.api.event.rule.RuleFlowGroupActivatedEvent;
import org.kie.api.event.rule.RuleFlowGroupDeactivatedEvent;
import org.springframework.stereotype.Component;

/**
 * @author VR56524
 *
 */
@Component
public class CCRAgendaEventListener implements AgendaEventListener {
	
	private Logger log = Logger.getLogger(this.getClass().getName());

	public void matchCreated(MatchCreatedEvent event) {
        System.out.println("matchCreated");
		log.info("matchCreated");
	}
	
	//@Override
	public void matchCancelled(MatchCancelledEvent event) {
		System.out.println("matchCancelled");
		log.info("matchCancelled");
	}
	
	//@Override
	public void beforeRuleFlowGroupDeactivated(
			RuleFlowGroupDeactivatedEvent event) {
		System.out.println("beforeRuleFlowGroupDeactivated");
		log.info("beforeRuleFlowGroupDeactivated");
	}
	
	//@Override
	public void beforeRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
		System.out.println("beforeRuleFlowGroupActivated");
		// TODO Auto-generated method stub
		log.info("beforeRuleFlowGroupActivated");
	}
	
	//@Override
	public void beforeMatchFired(BeforeMatchFiredEvent event) {
		System.out.println("beforeMatchFired");
		// TODO Auto-generated method stub
		log.info("beforeMatchFired");
	}
	
	//@Override
	public void agendaGroupPushed(AgendaGroupPushedEvent event) {
		System.out.println("agendaGroupPushed");
		// TODO Auto-generated method stub
		log.info("agendaGroupPushed");
	}
	
	//@Override
	public void agendaGroupPopped(AgendaGroupPoppedEvent event) {
		System.out.println("agendaGroupPopped");
		// TODO Auto-generated method stub
		log.info("agendaGroupPopped");
	}
	
	//@Override
	public void afterRuleFlowGroupDeactivated(
			RuleFlowGroupDeactivatedEvent event) {
		// TODO Auto-generated method stub
		System.out.println("afterRuleFlowGroupDeactivated");
		log.info("afterRuleFlowGroupDeactivated");
	}
	
	//@Override
	public void afterRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
		System.out.println("afterRuleFlowGroupActivated");
		log.info("afterRuleFlowGroupActivated");
	}
	
	//@Override
	public void afterMatchFired(AfterMatchFiredEvent event) {
		System.out.println("afterMatchFired");
		log.info("afterMatchFired");
	}

}
