package com.citigroup.cgti.c3par.rules.model;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Logger;

/**
 * @author VR56524
 *
 */
public class OstiaQuestionnaireDTO {
	protected String code;
	protected String type;
	protected String description;
	protected String baselineName="2015test";
	protected String baselineReportUrl;
	protected List<RiskDefinitionDTO> riskDefinitions = new ArrayList<RiskDefinitionDTO>();
	private static final String COMMA = ",";
	
	private Logger log = Logger.getLogger(this.getClass().getName());

	/**
	 * Gets the value of the code property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the value of the code property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCode(String value) {
		this.code = value;
	}

	/**
	 * Gets the value of the type property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the value of the type property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setType(String value) {
		this.type = value;
	}

	/**
	 * Gets the value of the description property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the value of the description property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setDescription(String value) {
		this.description = value;
	}

	/**
	 * Gets the value of the baselineName property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBaselineName() {
		return baselineName;
	}

	/**
	 * Sets the value of the baselineName property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setBaselineName(String value) {
		this.baselineName = value;
	}

	/**
	 * Gets the value of the baselineReportUrl property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBaselineReportUrl() {
		return baselineReportUrl;
	}

	/**
	 * Sets the value of the baselineReportUrl property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setBaselineReportUrl(String value) {
		this.baselineReportUrl = value;
	}

	/**
	 * Gets the value of the riskDefinitions property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a
	 * snapshot. Therefore any modification you make to the returned list will
	 * be present inside the JAXB object. This is why there is not a
	 * <CODE>set</CODE> method for the riskDefinitions property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getRiskDefinitions().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link RiskDefinitionDTO }
	 * 
	 * 
	 */
	public List<RiskDefinitionDTO> getRiskDefinitions() {
		if (riskDefinitions == null) {
			riskDefinitions = new ArrayList<RiskDefinitionDTO>();
		}
		return this.riskDefinitions;
	}
	
	public boolean addRiskDefinition(Object riskDefinitionObj) {
		boolean isAdded=false;
		RiskDefinitionDTO riskDefinitionDTO=(RiskDefinitionDTO)riskDefinitionObj;
		log.info("Start addRiskDefinition Risk Code ===> "
				+ riskDefinitionDTO.getRiskCode());
		System.out.println("Start addRiskDefinition Risk Code ===> "
				+ riskDefinitionDTO.getRiskCode());
		String riskCode= riskDefinitionDTO.getRiskCode();
		boolean exist = false;
		for (RiskDefinitionDTO riskDef : this.riskDefinitions) {
			if (riskCode.equals(riskDef.riskCode)) {
				exist = true;
				break;
			}
		}
		if (!exist) {
			this.riskDefinitions.add(riskDefinitionDTO);
			isAdded=true;
		}
		return isAdded;
	}
	public boolean isAddGenericRisk(String riskCodes) {
		StringTokenizer stk = new StringTokenizer(riskCodes, COMMA);
		List<String> exceptionRiskCodes = new ArrayList<String>();
		while (stk.hasMoreTokens()) {
			exceptionRiskCodes.add(stk.nextToken());
		}
		log.info("isAddGenericRisk"+riskCodes);
		boolean isAddGenericRisk = false;
		for (String exceptionRiskCode : exceptionRiskCodes) {
			for (RiskDefinitionDTO riskDefDto : this.getRiskDefinitions()) {
				isAddGenericRisk = true; //Add Generic risk if any risk added
				if (exceptionRiskCode
						.equalsIgnoreCase(riskDefDto.getRiskCode())) {
					isAddGenericRisk = false;
					break;
				}
			}
			if (!isAddGenericRisk)
				break;
		}
		log.info("isAddGenericRisk"+isAddGenericRisk);
		return isAddGenericRisk;
	}
}
