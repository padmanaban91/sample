package com.citigroup.cgti.c3par.rules.model;

/**
 * @author VR56524
 *
 */
public class PossibleAnswersDTO {
	
	protected String optionsGroupName;
	protected String answer;

	/**
	 * Gets the value of the optionsGroupName property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOptionsGroupName() {
		return optionsGroupName;
	}

	/**
	 * Sets the value of the optionsGroupName property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setOptionsGroupName(String value) {
		this.optionsGroupName = value;
	}

	/**
	 * Gets the value of the answer property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAnswer() {
		return answer;
	}

	/**
	 * Sets the value of the answer property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setAnswer(String value) {
		this.answer = value;
	}
}
