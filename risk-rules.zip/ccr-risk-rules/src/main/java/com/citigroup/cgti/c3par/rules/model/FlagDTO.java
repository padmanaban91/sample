package com.citigroup.cgti.c3par.rules.model;


/**
 * @author VR56524
 *
 */
public class FlagDTO {
	
	protected String key;
    protected String value;
    protected boolean tiRequest=false;

    /**
     * Gets the value of the key property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets the value of the key property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKey(String value) {
        this.key = value;
    }

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

	public boolean isTiRequest() {
		return tiRequest;
	}

	public void setTiRequest(boolean tiRequest) {
		this.tiRequest = tiRequest;
	}
}
