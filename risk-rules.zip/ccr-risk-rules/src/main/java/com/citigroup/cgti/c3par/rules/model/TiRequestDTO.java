package com.citigroup.cgti.c3par.rules.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author VR56524
 *
 */
public class TiRequestDTO {
	protected List<FlagDTO> riskCheckFlags;
    protected String sourceResourceType;
    protected String targetResourceType;
    protected String relationshipType;
    protected String requestPriority;
    protected String region;
    protected String sector;
    protected String businessUnit;
    protected String thirdParty;
    protected String uturnThirdParty;
    protected String connectionType;
    protected OstiaQuestionnaireDTO ostiaQuestionnaires=new OstiaQuestionnaireDTO();

    /**
     * Gets the value of the riskCheckFlags property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the riskCheckFlags property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRiskCheckFlags().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FlagDTO }
     * 
     * 
     */
    public List<FlagDTO> getRiskCheckFlags() {
        if (riskCheckFlags == null) {
            riskCheckFlags = new ArrayList<FlagDTO>();
        }
        return this.riskCheckFlags;
    }

    /**
     * Gets the value of the sourceResourceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceResourceType() {
        return sourceResourceType;
    }

    /**
     * Sets the value of the sourceResourceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceResourceType(String value) {
        this.sourceResourceType = value;
    }

    /**
     * Gets the value of the targetResourceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetResourceType() {
        return targetResourceType;
    }

    /**
     * Sets the value of the targetResourceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetResourceType(String value) {
        this.targetResourceType = value;
    }

    /**
     * Gets the value of the relationshipType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipType() {
        return relationshipType;
    }

    /**
     * Sets the value of the relationshipType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipType(String value) {
        this.relationshipType = value;
    }

    /**
     * Gets the value of the requestPriority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestPriority() {
        return requestPriority;
    }

    /**
     * Sets the value of the requestPriority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestPriority(String value) {
        this.requestPriority = value;
    }

    /**
     * Gets the value of the region property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegion() {
        return region;
    }

    /**
     * Sets the value of the region property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegion(String value) {
        this.region = value;
    }

    /**
     * Gets the value of the sector property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSector() {
        return sector;
    }

    /**
     * Sets the value of the sector property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSector(String value) {
        this.sector = value;
    }

    /**
     * Gets the value of the businessUnit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessUnit() {
        return businessUnit;
    }

    /**
     * Sets the value of the businessUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessUnit(String value) {
        this.businessUnit = value;
    }

    /**
     * Gets the value of the thirdParty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThirdParty() {
        return thirdParty;
    }

    /**
     * Sets the value of the thirdParty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThirdParty(String value) {
        this.thirdParty = value;
    }

    /**
     * Gets the value of the uturnThirdParty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUturnThirdParty() {
        return uturnThirdParty;
    }

    /**
     * Sets the value of the uturnThirdParty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUturnThirdParty(String value) {
        this.uturnThirdParty = value;
    }

    /**
     * Gets the value of the connectionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConnectionType() {
        return connectionType;
    }

    /**
     * Sets the value of the connectionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConnectionType(String value) {
        this.connectionType = value;
    }

	public OstiaQuestionnaireDTO getOstiaQuestionnaires() {
		return ostiaQuestionnaires;
	}

	public void setOstiaQuestionnaires(OstiaQuestionnaireDTO ostiaQuestionnaires) {
		this.ostiaQuestionnaires = ostiaQuestionnaires;
	}
    
}
