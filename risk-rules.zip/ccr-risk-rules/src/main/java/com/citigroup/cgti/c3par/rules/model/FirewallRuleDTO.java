package com.citigroup.cgti.c3par.rules.model;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.kie.api.runtime.KieRuntime;

/**
 * @author VR56524
 *
 */
public class FirewallRuleDTO {
	
	private Logger log = Logger.getLogger(this.getClass().getName());
	protected List<FlagDTO> riskCheckFlags;
	protected TiRequestDTO tiRequest;
	protected List<IpAddressDTO> sourceIPAddress;
	protected List<IpAddressDTO> destinationIPAddress;
	protected List<PortDTO> port;
	protected NetworkSegmentDTO networkSegmentDto;
	protected OstiaQuestionnaireDTO ostiaQuestionnaires=new OstiaQuestionnaireDTO();
	protected Long id;
	protected String sourceNetworkSegment;
	protected String destinationNetworkSegment;
	protected String transactionId;

	public OstiaQuestionnaireDTO getOstiaQuestionnaires() {
		return ostiaQuestionnaires;
	}

	public void setOstiaQuestionnaires(OstiaQuestionnaireDTO ostiaQuestionnaires) {
		this.ostiaQuestionnaires = ostiaQuestionnaires;
	}

	public List<FlagDTO> getRiskCheckFlags() {
		if (riskCheckFlags == null) {
            riskCheckFlags = new ArrayList<FlagDTO>();
        }
        return this.riskCheckFlags;
	}

	public void setRiskCheckFlags(List<FlagDTO> riskCheckFlags) {
		this.riskCheckFlags = riskCheckFlags;
	}

	public TiRequestDTO getTiRequest() {
		return tiRequest;
	}

	public void setTiRequest(TiRequestDTO tiRequest) {
		this.tiRequest = tiRequest;
	}

	public List<IpAddressDTO> getSourceIPAddress() {
		return sourceIPAddress;
	}

	public void setSourceIPAddress(List<IpAddressDTO> sourceIPAddress) {
		this.sourceIPAddress = sourceIPAddress;
	}

	public List<IpAddressDTO> getDestinationIPAddress() {
		return destinationIPAddress;
	}

	public void setDestinationIPAddress(List<IpAddressDTO> destinationIPAddress) {
		this.destinationIPAddress = destinationIPAddress;
	}

	public List<PortDTO> getPort() {
		return port;
	}

	public void setPort(List<PortDTO> port) {
		this.port = port;
	}

	


	public NetworkSegmentDTO getNetworkSegmentDto() {
		return networkSegmentDto;
	}

	public void setNetworkSegmentDto(NetworkSegmentDTO networkSegmentDto) {
		this.networkSegmentDto = networkSegmentDto;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void addRiskToSession(RiskDefinitionDTO riskDefDto,
			 KieRuntime krt) {
        log.info("Add Risk to Session"+riskDefDto.getRiskCode());
		if (this.getOstiaQuestionnaires().addRiskDefinition(riskDefDto)) {
			krt.insert(riskDefDto);
		}
	}

	public String getSourceNetworkSegment() {
		return sourceNetworkSegment;
	}

	public void setSourceNetworkSegment(String sourceNetworkSegment) {
		this.sourceNetworkSegment = sourceNetworkSegment;
	}

	public String getDestinationNetworkSegment() {
		return destinationNetworkSegment;
	}

	public void setDestinationNetworkSegment(String destinationNetworkSegment) {
		this.destinationNetworkSegment = destinationNetworkSegment;
	}		
	
}
