package com.citigroup.cgti.c3par.rules.listeners;

import org.apache.log4j.Logger;
import org.drools.core.event.DefaultProcessEventListener;
import org.kie.api.event.process.ProcessNodeLeftEvent;
import org.kie.api.event.process.ProcessNodeTriggeredEvent;
import org.springframework.stereotype.Component;

/**
 * @author VR56524
 *
 */
@Component
public class CCRProcessEventListener extends DefaultProcessEventListener {
	private Logger log = Logger.getLogger(this.getClass().getName());
	@Override
	public void afterNodeLeft(ProcessNodeLeftEvent event) {
		log.info("After node left {}"+event.getNodeInstance()
				.getNodeName());
	}

	@Override
	public void afterNodeTriggered(ProcessNodeTriggeredEvent event) {
		log.info("After node triggered {}"+event.getNodeInstance()
				.getNodeName());
	}

	@Override
	public void beforeNodeLeft(ProcessNodeLeftEvent event) {
		log.info("Before node left {}"+event.getNodeInstance()
				.getNodeName());
	}

	@Override
	public void beforeNodeTriggered(ProcessNodeTriggeredEvent event) {
		log.info("Before node triggered {}"+event.getNodeInstance()
				.getNodeName());
	}
}
