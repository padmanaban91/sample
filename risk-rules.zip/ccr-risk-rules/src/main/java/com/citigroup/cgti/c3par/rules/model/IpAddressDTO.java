package com.citigroup.cgti.c3par.rules.model;


/**
 * @author VR56524
 *
 */
public class IpAddressDTO {
	protected String ipAddress;
	protected boolean tpa;
	protected boolean anyIP;
	protected Long id;
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public boolean isTpa() {
		return tpa;
	}
	public void setTpa(boolean tpa) {
		this.tpa = tpa;
	}
	public boolean isAnyIP() {
		return anyIP;
	}
	public void setAnyIP(boolean anyIP) {
		this.anyIP = anyIP;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
}
