package com.citigroup.cgti.c3par.rules.model;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.kie.api.runtime.KieRuntime;

/**
 * @author VR56524
 *
 */
public class OstiaQuestionDTO {
	private static final String COMMA = ",";
	protected String questionControlNumber;
	protected String question;
	protected String answerType;
	protected String hint;
	protected String optionsGroupName;
	protected List<PossibleAnswersDTO> possibleAnswers;

	/**
	 * Gets the value of the questionControlNumber property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getQuestionControlNumber() {
		return questionControlNumber;
	}

	/**
	 * Sets the value of the questionControlNumber property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setQuestionControlNumber(String value) {
		this.questionControlNumber = value;
	}

	/**
	 * Gets the value of the question property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getQuestion() {
		return question;
	}

	/**
	 * Sets the value of the question property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setQuestion(String value) {
		this.question = value;
	}

	/**
	 * Gets the value of the answerType property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAnswerType() {
		return answerType;
	}

	/**
	 * Sets the value of the answerType property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setAnswerType(String value) {
		this.answerType = value;
	}

	/**
	 * Gets the value of the hint property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getHint() {
		return hint;
	}

	/**
	 * Sets the value of the hint property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setHint(String value) {
		this.hint = value;
	}

	/**
	 * Gets the value of the possibleAnswers property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a
	 * snapshot. Therefore any modification you make to the returned list will
	 * be present inside the JAXB object. This is why there is not a
	 * <CODE>set</CODE> method for the possibleAnswers property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getPossibleAnswers().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link PossibleAnswersDTO }
	 * 
	 * 
	 */
	public List<PossibleAnswersDTO> getPossibleAnswers() {
		if (possibleAnswers == null) {
			possibleAnswers = new ArrayList<PossibleAnswersDTO>();
		}
		return this.possibleAnswers;
	}
	
	public void addPossibleAnswers(String answers,KieRuntime krt){
		//System.out.println(" :: Start addPossibleAnswers :: Options Group Name :: " + answer);
		StringTokenizer options=new StringTokenizer(answers,COMMA);
		while (options.hasMoreElements()) {
			PossibleAnswersDTO possibleAnswers = new PossibleAnswersDTO();
			possibleAnswers.setOptionsGroupName(this.getOptionsGroupName());
			possibleAnswers.setAnswer((String)options.nextElement());
			System.out.println(possibleAnswers.getAnswer());
			getPossibleAnswers().add(possibleAnswers);
		}
		
	}

	public String getOptionsGroupName() {
		return optionsGroupName;
	}

	public void setOptionsGroupName(String optionsGroupName) {
		this.optionsGroupName = optionsGroupName;
	}
	
	
}
