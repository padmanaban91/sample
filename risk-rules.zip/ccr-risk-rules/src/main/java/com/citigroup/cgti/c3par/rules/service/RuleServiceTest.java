package com.citigroup.cgti.c3par.rules.service;



public class RuleServiceTest { /*extends TestCase {
	protected ClassPathXmlApplicationContext context;
	
	@Autowired
	RulesService rulesService;
	
	@Autowired
	RulesUtility ruleUtility;
	
	@Autowired
	private KieBase kbase;
	
	KieSession ruleSession;
	
	public void setUp() throws Exception
	{
		 this.context = new ClassPathXmlApplicationContext(new String[]{
			// "classpath*:rules-context.xml",
				 "file:resources/rules-context.xml",
		 });
	}
	
	public void getSession() {
	    try {
	    	 // create the session
	    	kbase=(KieBase)context.getBean("kbase1");
	    	
	    	//rulesService=(RulesService)context.getBean("kbase1");
	    	rulesService=(RulesService)context.getBean("rulesServiceImpl");
	    	//rulesService.testPortByTemplateRule();
	    	ruleUtility=(RulesUtility)context.getBean("rulesUtility");
	    	ruleSession=kbase.newKieSession();
	    } catch ( Exception e ) {
	        e.printStackTrace();
	    }
	}
	
	public void testInialize() throws Exception {
		getSession();
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		ruleSession.insert(fireWallDto);
		TiRequestDTO tiRequest=new TiRequestDTO();
		tiRequest.setRelationshipType("IP_TEMPLATE");
		ruleSession.insert(tiRequest);
		
		int rulesFired = ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("InitializeBaseLine") );
		//int rulesFired = ruleSession.fireAllRules();
	    Assert.assertEquals( 2, rulesFired );
	}
	public void testPortByTemplateRule() throws Exception {
		getSession();
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		ruleSession.insert(fireWallDto);
		TiRequestDTO tiRequest=new TiRequestDTO();
		tiRequest.setRelationshipType("IP_TEMPLATE");
		ruleSession.insert(tiRequest);
		PortDTO portDto=new PortDTO();
		portDto.setProtocol("TCP");
		portDto.setPortNumber("20");
		portDto.setDefaultService(true);
		ruleSession.insert(portDto);
		ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		//ruleSession.setGlobal("fireWallDto", fireWallDto);
		PortDTO portDto1=new PortDTO();
		portDto1.setProtocol("UDP");
		portDto1.setPortNumber("111");
		portDto1.setDefaultService(true);
		ruleSession.insert(portDto1);
		ruleSession.setGlobal("fireWallDto", fireWallDto);
		int rulesFired = ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("RiskPortBYTEmplates") );
		//int rulesFired = ruleSession.fireAllRules();
	    Assert.assertEquals( 2, rulesFired );
	}
	
	
	public void testriskBYFirewallRuleFlagsRule() throws Exception {
		getSession();
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		ruleSession.insert(fireWallDto);
		FlagDTO flagDto=new FlagDTO();
		flagDto.setKey("TPA");	
		flagDto.setValue("Y");
		ruleSession.insert(flagDto);
		ruleSession.setGlobal("fireWallDto", fireWallDto);
	    int rulesFired = ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("RiskBYFirewallRuleFlags") );	
	    Assert.assertEquals( 1, rulesFired );
	}
	
	public void testriskByRelationshipsRule() throws Exception {
		getSession();
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		TiRequestDTO tiRequest=new TiRequestDTO();
		fireWallDto.setTiRequest(tiRequest);
		ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		ruleSession.insert(fireWallDto);
		tiRequest.setRelationshipType("IP_TEMPLATE");
		ruleSession.insert(tiRequest);
		ruleSession.setGlobal("fireWallDto", fireWallDto);
	    int rulesFired = ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("RiskByRelationships") );	
		// ruleSession.fireAllRules();	
	    Assert.assertEquals( 1, rulesFired );
	}
	public void testalwaysRiskRules() throws Exception {
		getSession();
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		PortDTO portDto=new PortDTO();
		portDto.setProtocol("IPSEC");
		portDto.setPortNumber("IPSEC");
		ruleSession.insert(portDto);
		ruleSession.setGlobal("fireWallDto", fireWallDto);
	    int rulesFired = ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("AlwaysRiskRules") );	
	    Assert.assertEquals( 1, rulesFired );
	}
	public void testalwaysDestinationIps() throws Exception {
		getSession();
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		ruleSession.insert(fireWallDto);
		ruleSession.setGlobal("fireWallDto", fireWallDto);
		List<IpAddressDTO> destinationLst=new ArrayList<IpAddressDTO>();
		
	    IpAddressDTO ipAddress = new IpAddressDTO();
		ipAddress.setId(new Long(1));
		ipAddress.setIpAddress("10.9.89.89");
		ipAddress.setTpa(true);
		ipAddress.setAnyIP(true);
		IpAddressDTO ipAddress1 = new IpAddressDTO();
		ipAddress1.setId(new Long(1));
		ipAddress1.setIpAddress("10.9.89.89");
		ipAddress1.setTpa(true);
		ipAddress1.setAnyIP(true);
		destinationLst.add(ipAddress);
		destinationLst.add(ipAddress1);
		fireWallDto.setDestinationIPAddress(destinationLst);
	    ruleSession.insert(ipAddress);
		fireWallDto.getDestinationIPAddress().add(ipAddress1);
		ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		
		int rulesFired=ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("alwaysRiskRulesByDestinationIPs"));
		 Assert.assertEquals( 1, rulesFired );
	}
	public void testriskPortByNetworkSegmentRule() throws Exception {
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		ruleSession.setGlobal("fireWallDto", fireWallDto);
		ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		
		PortDTO portDto=new PortDTO();
		portDto.setProtocol("TCP");
		portDto.setPortNumber("20");
		portDto.setStartPort(21L);
		portDto.setEndPort(21L);
		portDto.setDefaultService(true);
		ruleSession.insert(portDto);
		FlagDTO flagDto=new FlagDTO();
		flagDto.setKey("THIRD_PARTY");	
		flagDto.setValue("Y");
		NetworkSegmentDTO networkSegment=new NetworkSegmentDTO();
		networkSegment.setSourceNetworkSegment("CITIFT");
		networkSegment.setDestinationNetworkSegment("DMZ");
		ruleSession.insert(networkSegment);
		ruleSession.insert(flagDto);
		//ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("riskPortByNetworkSegments"));
		OstiaQuestionDTO ostQstDto=new OstiaQuestionDTO();
		ostQstDto.setOptionsGroupName("TCP_21_Q1_Answers");
	//	ruleSession.insert(ostQstDto);
		ruleUtility.input(fireWallDto);
		ruleSession.fireAllRules();
	//	ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("OstiaQuestionsByRiskRules"));
	//	ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("AnswersByOstiaQuestions"));
	//	ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("AnswersGroupInventory"));
		ruleUtility.output(fireWallDto);
		List<RiskDefinitionDTO> riskDefinitionsLst = fireWallDto.getOstiaQuestionnaires().getRiskDefinitions();
		System.out.println(riskDefinitionsLst.size());
		for(RiskDefinitionDTO riskDef:riskDefinitionsLst){
			System.out.println(riskDef.getRiskCode());
			System.out.println(riskDef.getOstiaQuestion().size());
			
		}
		
	}
	
	public void testPortWithOtherServicesRule() throws Exception {
		getSession();
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		//ruleSession.insert(fireWallDto);
		ruleSession.setGlobal("fireWallDto", fireWallDto);
		PortDTO portDto=new PortDTO();
		portDto.setProtocol("TCP");
		portDto.setPortNumber("20");
		portDto.setStartPort(21L);
		portDto.setEndPort(21L);
		portDto.setDefaultService(false);
		ruleSession.insert(portDto);
		FlagDTO flagDto=new FlagDTO();
		flagDto.setKey("THIRD_PARTY");	
		flagDto.setValue("Y");
		NetworkSegmentDTO networkSegment=new NetworkSegmentDTO();
		networkSegment.setSourceNetworkSegment("Citiplex");
		networkSegment.setDestinationNetworkSegment("CITIFT");
		ruleSession.insert(networkSegment);
		ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		ruleSession.insert(flagDto);
		//ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("PortWithOtherServices"));
		//ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("addGenericRisk"));
		int rulesFired=ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("PortWithOtherServices"));
		Assert.assertEquals( 1, rulesFired );
	}
	

	public void testAddNoQuestionRule() throws Exception {
		getSession();
		RiskDefinitionDTO riskDef=new RiskDefinitionDTO();
		riskDef.setRiskCode("BROAD_ACCESS_RISK");
		ruleSession.insert(riskDef);
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		ruleSession.setGlobal("fireWallDto", fireWallDto);
		int rulesFired=ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("RequestRiskRuleInventory"));
		Assert.assertEquals( 1, rulesFired );
	}
	public void testAnswersByOstiaQuestions() throws Exception {
		testriskPortByNetworkSegmentRule();
	}
	
	@Test
	@Ignore
	public void testQuestinInventoryRules() throws Exception {
		testriskPortByNetworkSegmentRule();
		ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("QuestionInventoryRules"));
	}
	
	public void testAnswersGroupInventoryRule() throws Exception {
		getSession();
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		//ruleSession.insert(fireWallDto);
		ruleSession.setGlobal("fireWallDto", fireWallDto);
		OstiaQuestionDTO ostQstDto=new OstiaQuestionDTO();
		ostQstDto.setOptionsGroupName("TCP_21_Q1_Answers");
		ruleSession.insert(ostQstDto);
		int rulesFired=ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("AnswersGroupInventory"));
		Assert.assertEquals( 1, rulesFired );
	}
	
	public void testNoAddGenerickRisk() throws Exception {
	//	testriskPortByNetworkSegmentRule();
		getSession();
		RiskDefinitionDTO riskDef=new RiskDefinitionDTO();
		riskDef.setRiskCode("TPA_EXCEPTION_1494_DMZ_GRN");
		ruleSession.insert(riskDef);
		RiskDefinitionDTO riskDef1=new RiskDefinitionDTO();
		riskDef1.setRiskCode("BROAD_ACCESS_RISK");
		ruleSession.insert(riskDef1);
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		fireWallDto.getOstiaQuestionnaires().getRiskDefinitions().add(riskDef1);
		ruleSession.insert(	fireWallDto.getOstiaQuestionnaires());
		ruleSession.setGlobal("fireWallDto", fireWallDto);
		int rulesFired=ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("AddGenericRisk"));
		Assert.assertEquals(2, rulesFired );
	}
	
	public void testAddGenerickRisk() throws Exception {
	//	testriskPortByNetworkSegmentRule();
		getSession();
		RiskDefinitionDTO riskDef=new RiskDefinitionDTO();
		riskDef.setRiskCode("PORT_111");
		ruleSession.insert(riskDef);
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		fireWallDto.getOstiaQuestionnaires().getRiskDefinitions().add(riskDef);
		ruleSession.insert(	fireWallDto.getOstiaQuestionnaires());
		ruleSession.setGlobal("fireWallDto", fireWallDto);
		//int rulesFired=ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("AddGenericRisk"));
		int rulesFired=ruleSession.fireAllRules();
		Assert.assertEquals( 2, rulesFired );
	}
	
	public void testExplicitlyNotRiskyRules() throws Exception {
	//	testriskPortByNetworkSegmentRule();
		getSession();
		RiskDefinitionDTO riskDef=new RiskDefinitionDTO();
		riskDef.setRiskCode("TPA_EXCEPTION_1494_DMZ_GRN");
		ruleSession.insert(riskDef);
		FirewallRuleDTO fireWallDto=new FirewallRuleDTO();
		//ruleSession.insert(fireWallDto);
		ruleSession.setGlobal("fireWallDto", fireWallDto);
		
		FlagDTO flagDto=new FlagDTO();
		flagDto.setKey("SRCTPA");	
		flagDto.setValue("Y");
		ruleSession.insert(flagDto);
		
		TiRequestDTO tiRequest=new TiRequestDTO();
		tiRequest.setSourceResourceType("DMZ");
		tiRequest.setTargetResourceType("GRN");
		ruleSession.insert(tiRequest);
		
		NetworkSegmentDTO networkSegment=new NetworkSegmentDTO();
		networkSegment.setSourceNetworkSegment("DMZ");
		networkSegment.setDestinationNetworkSegment("GRN");
		ruleSession.insert(networkSegment);
		
		PortDTO portDto=new PortDTO();
		portDto.setProtocol("TCP");
		portDto.setPortNumber("2598");
		portDto.setStartPort(5800L);
		portDto.setEndPort(5810L);
	//	portDto.setDefaultService(false);
		ruleSession.insert(portDto);
		//fireWallDto.getOstiaQuestionnaires().getRiskDefinitions().add(riskDef1);
		//ruleSession.insert(fireWallDto.getOstiaQuestionnaires());
		int rulesFired=ruleSession.fireAllRules(new RuleNameStartsWithAgendaFilter("riskPortByNetworkSegmentsDMZGRN"));
		Assert.assertEquals(1, rulesFired );
	}*/
}
