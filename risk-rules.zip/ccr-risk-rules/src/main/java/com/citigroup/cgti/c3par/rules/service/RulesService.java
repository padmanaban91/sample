package com.citigroup.cgti.c3par.rules.service;

import org.springframework.stereotype.Service;

import com.citigroup.cgti.c3par.rules.model.FirewallRuleDTO;
/**
 * @author VR56524
 *
 */
@Service
public interface RulesService {
	 
     public void executeRules(FirewallRuleDTO firewallRuleDTO);
     
     //TODO: Will Remove the below method once testing compelted
     public void testPortByTemplateRule();
     
}
