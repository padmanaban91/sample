package com.citigroup.cgti.c3par.rules.model;

/**
 * @author VR56524
 *
 */
public class PortDTO {
	protected String portNumber;
	protected Long startPort;
	protected Long endPort;
	protected String protocol;
	protected boolean defaultService;

	public String getPortNumber() {
		return portNumber;
	}

	public void setPortNumber(String portNumber) {
		this.portNumber = portNumber;
	}

	public Long getStartPort() {
		return startPort;
	}

	public void setStartPort(Long startPort) {
		this.startPort = startPort;
	}

	public Long getEndPort() {
		return endPort;
	}

	public void setEndPort(Long endPort) {
		this.endPort = endPort;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public boolean isDefaultService() {
		return defaultService;
	}

	public void setDefaultService(boolean defaultService) {
		this.defaultService = defaultService;
	}

}
