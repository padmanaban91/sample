package com.citigroup.cgti.c3par.rules.model;

/**
 * @author VR56524
 *
 */
public class NetworkSegmentDTO {
	protected String sourceNetworkSegment;
	protected String destinationNetworkSegment;
	public String getSourceNetworkSegment() {
		return sourceNetworkSegment;
	}
	public void setSourceNetworkSegment(String sourceNetworkSegment) {
		this.sourceNetworkSegment = sourceNetworkSegment;
	}
	public String getDestinationNetworkSegment() {
		return destinationNetworkSegment;
	}
	public void setDestinationNetworkSegment(String destinationNetworkSegment) {
		this.destinationNetworkSegment = destinationNetworkSegment;
	}
}
