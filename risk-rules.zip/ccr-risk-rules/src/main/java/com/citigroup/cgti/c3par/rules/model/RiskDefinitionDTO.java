package com.citigroup.cgti.c3par.rules.model;

import java.util.ArrayList;
import java.util.List;

import org.kie.api.runtime.KieRuntime;

/**
 * @author VR56524
 *
 */
public class RiskDefinitionDTO {
	protected String riskCode;
	protected String riskName;
	protected String riskDescription;
	protected String riskCategory;
	protected List<OstiaQuestionDTO> ostiaQuestion;
	protected Double riskRating;

	/**
	 * Gets the value of the riskCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRiskCode() {
		return riskCode;
	}

	/**
	 * Sets the value of the riskCode property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRiskCode(String value) {
		this.riskCode = value;
	}

	/**
	 * Gets the value of the riskName property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRiskName() {
		return riskName;
	}

	/**
	 * Sets the value of the riskName property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRiskName(String value) {
		this.riskName = value;
	}

	/**
	 * Gets the value of the riskDescription property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRiskDescription() {
		return riskDescription;
	}

	/**
	 * Sets the value of the riskDescription property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRiskDescription(String value) {
		this.riskDescription = value;
	}

	/**
	 * Gets the value of the riskCategory property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRiskCategory() {
		return riskCategory;
	}

	/**
	 * Sets the value of the riskCategory property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRiskCategory(String value) {
		this.riskCategory = value;
	}

	/**
	 * Gets the value of the ostiaQuestion property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a
	 * snapshot. Therefore any modification you make to the returned list will
	 * be present inside the JAXB object. This is why there is not a
	 * <CODE>set</CODE> method for the ostiaQuestion property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getOstiaQuestion().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link OstiaQuestionDTO }
	 * 
	 * 
	 */
	public List<OstiaQuestionDTO> getOstiaQuestion() {
		if (ostiaQuestion == null) {
			ostiaQuestion = new ArrayList<OstiaQuestionDTO>();
		}
		return this.ostiaQuestion;
	}

	/**
	 * Gets the value of the riskRating property.
	 * 
	 * @return possible object is {@link Double }
	 * 
	 */
	public Double getRiskRating() {
		return riskRating;
	}

	/**
	 * Sets the value of the riskRating property.
	 * 
	 * @param value
	 *            allowed object is {@link Double }
	 * 
	 */
	public void setRiskRating(Double value) {
		this.riskRating = value;
	}
	
	public OstiaQuestionDTO addOstiaQuestion(String questionCode,KieRuntime krt){
		System.out.println(" :: Start addOstiaQuestion :: Question Code :: " + questionCode+"Risk COde is"+this.getRiskCode());
		
		//TODO:will remove this code once eval funcation issue resolved
		if(this.getOstiaQuestion().size()!=0 && "NO_QUESTION".equalsIgnoreCase(questionCode)){
			System.out.println(" Size of the list " + this.getOstiaQuestion().size());
			return null;
		}
		OstiaQuestionDTO ostiaQuestion = new OstiaQuestionDTO();
		ostiaQuestion.setQuestionControlNumber(questionCode);
		krt.insert(ostiaQuestion);
		this.getOstiaQuestion().add(ostiaQuestion);
		return ostiaQuestion;
	}
}
